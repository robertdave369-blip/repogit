"""Case plan for the combined ICE + EV EDR CAN-C specification.

One place that decides, for every EDR CAN-C parameter, which test cases exist and what
number each one carries. Both the workbook builder and the EV script generator read this
module, so the specification and the scripts cannot drift apart.

Which cases exist
-----------------
The U171 scripts in ``projects/U171/modules/EDR/scripts`` decide which cases the ICE
parameters carry. They are matched to the V4 authoring workbook by what each case tests -
its kind and scope - not by number, and the V4 case a case came from is kept on it so the
workbook builder can reuse its text. Missing Message Timeout and Node Absent cases and the
under- and over-voltage cases are then added where the frame topology allows them.

Numbering (review comment 1)
----------------------------
Every parameter is numbered from 1 in one fixed order, whatever order its cases were
found or added in: Nominal; Node Absent full, pre, post; Message Timeout; Message Content;
Signal Content; DBC invalid; Signal Never Received; Variant Code Error; DBC reserved;
DBC out of range; Under Voltage; Over Voltage; CAN wakeup always last. Each fault family
runs full, pre, post. Signal Never Received and Variant Code Error need an ignition cycle,
so they are full interval only. ``REVIEW_ORDER`` holds the order; ``renumber`` applies it.

EV parameters occupy the numbers the ICE specification leaves free - 26 to 28, 46 to 48
and 53 to 65. The allocation follows the element order of the common ICE/EV specification
``Common_EDR_CANC_0455_045B_U171_M314_v7_authoring.xlsx``, in which exactly these
nineteen EV-only CAN-received parameters sit in exactly these gaps.

Offline only: reads configuration and writes a JSON plan. Nothing here drives a bench.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
U171_SCRIPTS = REPOSITORY_ROOT / "projects" / "U171" / "modules" / "EDR" / "scripts"
V4_WORKBOOK = (
    REPOSITORY_ROOT
    / "project_testcases" / "ice_common_spec" / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design" / "03_Authoring_Versions" / "V4"
    / "V1.7_8_DES_SW_EDR_SwQTS_ICE.xlsx"
)
V7_WORKBOOK = (
    REPOSITORY_ROOT
    / "project_testcases" / "ice_common_spec" / "EDR"
    / "Common_EDR_CANC_0455_045B_U171_M314_v7_authoring.xlsx"
)

# Under- and over-voltage DTCs come from the shared configuration control file, which is
# the only place they are defined, so the specification states what the scripts expect. A
# supply excursion is not a CAN fault, so its DTC reads active - 0x8B - rather than taking
# the warning-lamp-off or historic status a CAN fault's timing gives it.
_CONFIGURATION_CONTROL = importlib.util.spec_from_file_location(
    "_configuration_control", REPOSITORY_ROOT / "shared_libraries" / "configuration_control.py")
_configuration_control = importlib.util.module_from_spec(_CONFIGURATION_CONTROL)
_CONFIGURATION_CONTROL.loader.exec_module(_configuration_control)
UNDER_VOLTAGE_DTC = _configuration_control.Under_Voltage
OVER_VOLTAGE_DTC = _configuration_control.Over_Voltage
VOLTAGE_DTC_STATUS = _configuration_control.DTC_status["DTC_active"]


# --------------------------------------------------------------------------------------
# Case kinds
# --------------------------------------------------------------------------------------

# kind -> (human label, is a CAN-C recording fault case, carries the DTC read in the
# Test Step Action column). The review names Message Timeout, Node Absent and the two
# voltage cases; the same wording is applied to every CAN-C recording case, so half the
# specification does not read one way and half the other.
KINDS: dict[str, tuple[str, bool, bool]] = {
    "nominal": ("Nominal", False, False),
    "wakeup": ("CAN wakeup", False, False),
    "node_absent": ("Node Absent", True, True),
    "message_timeout": ("Message Timeout", True, True),
    "message_content": ("Message Content", True, True),
    "signal_content": ("Signal Content", True, True),
    "signal_never_received": ("Signal Never Received", True, True),
    "variant_code_error": ("Variant Code Error", True, True),
    "dbc_invalid": ("DBC invalid input", False, False),
    "dbc_out_of_range": ("DBC encodable out-of-range input", False, False),
    "dbc_reserved": ("DBC reserved input", False, False),
    "under_voltage": ("Under Voltage", True, True),
    "over_voltage": ("Over Voltage", True, True),
    # Hardware ignition OFF, the ECU woken and kept awake by the network-management PDU
    # alone (ACTIVE_WAKEUP_BIT = Active). EV only; the last case of every EV series.
    "can_nm": ("CAN NM wakeup", False, False),
    # The two whole-record checks. They drive no CAN signal: the point is what the record
    # holds for allocations nothing ever feeds.
    "record_reserved": ("Reserved bytes record 0x00", False, False),
    "record_not_configured": ("Not-configured allocations record 0xFF", False, False),
}

SCOPES = ("full", "pre", "post")

# Short tag carried in every test case name, so the name says what the case does without
# anyone having to look the number up. Scope is appended for the families that have one.
KIND_TAGS = {
    "nominal": "Nominal",
    "wakeup": "CAN_Wakeup",
    "node_absent": "NA",
    "message_timeout": "MTO",
    "message_content": "MCF",
    "signal_content": "SCF",
    "signal_never_received": "SNR",
    "variant_code_error": "VC",
    "dbc_invalid": "Invalid",
    "dbc_out_of_range": "OOR",
    "dbc_reserved": "Reserved",
    "under_voltage": "UV",
    "over_voltage": "OV",
    "can_nm": "CAN_NM",
    "record_reserved": "Record_00",
    "record_not_configured": "Record_FF",
}

# Families whose tag carries the part of the interval the fault covers.
SCOPED_KINDS = {"node_absent", "message_timeout", "message_content", "signal_content",
                "under_voltage", "over_voltage"}


def case_tag(kind: str, scope: str | None) -> str:
    tag = KIND_TAGS[kind]
    if kind in SCOPED_KINDS and scope:
        return f"{tag}_{scope.capitalize()}"
    return tag


# Review comment 1: the order every parameter's cases are numbered in. Signal Content and
# DBC invalid are not named in the comment; both are content faults, so they follow
# Message Content. Bus-off has no cases yet and would sit just before CAN wakeup. The CAN
# NM case closes every EV series (user direction 2026-10-07); ICE has none.
REVIEW_ORDER = [
    "nominal",
    "node_absent",
    "message_timeout",
    "message_content",
    "signal_content",
    "dbc_invalid",
    "signal_never_received",
    "variant_code_error",
    "dbc_reserved",
    "dbc_out_of_range",
    "under_voltage",
    "over_voltage",
    "wakeup",
    "can_nm",
]
SCOPE_ORDER = {"full": 0, None: 0, "pre": 1, "post": 2}


def review_order_key(case: "Case") -> tuple[int, int, int]:
    return REVIEW_ORDER.index(case.kind), SCOPE_ORDER[case.scope], case.number


@dataclass
class Case:
    """One test case in the combined specification."""

    signal: int
    number: int
    kind: str
    scope: str | None = None          # full / pre / post, or None
    variant: str = "ICE"              # ICE or EV
    parameter: str = ""               # name used in the test case title
    source: str = "existing"          # existing / renumbered / new
    source_name: str | None = None    # the name this case carried in V4 or v7
    note: str = ""
    v4_number: int | None = None      # the V4 workbook case whose text this case reuses

    @property
    def tag(self) -> str:
        return case_tag(self.kind, self.scope)

    @property
    def name(self) -> str:
        return (f"EDR_Element_ID_{self.parameter}_TestCase_"
                f"{self.signal}_{self.number}_{self.tag}")


@dataclass
class ParameterPlan:
    """Every case for one EDR element, in number order."""

    signal: int
    parameter: str
    variant: str
    canc_signal: str
    edr_parameter: str | None
    frame: str | None = None
    key_frame: str | None = None
    timeout_frame: str | None = None
    periodicity: int | None = None
    samples: int = 1
    sample_range: dict[str, float] | None = None
    recording_model: str = "snapshot"
    cases: list[Case] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    # Whether the element records anything after the crash. The record layout decides it:
    # an interval that ends at T0 has no post-crash sample to hold a reaction, and one that
    # runs past T0 does. Left as None so `has_post_crash` reads the sample range.
    post_crash_supported: bool | None = None
    # Highest case number the element has ever used, removals included. New cases are
    # appended above it so a number vacated by a removal is never handed to a different
    # case while a script of that name still sits on disk.
    highest_reserved: int = 0

    @property
    def has_post_crash(self) -> bool:
        """An element whose interval ends at T0 has nothing to record after the crash."""
        if self.recording_model != "interval" or not self.sample_range:
            return False
        if self.post_crash_supported is not None:
            return self.post_crash_supported
        return float(self.sample_range.get("end", 0.0)) > 0.0

    @property
    def fault_scopes(self) -> list[str]:
        """Which timing scopes a fault case can have on this element.

        A snapshot element records one value, so a fault either covers that value or it
        does not: there is nothing to split into pre-crash and post-crash.
        """
        if self.recording_model != "interval":
            return ["full"]
        return ["full", "pre"] + (["post"] if self.has_post_crash else [])

    def interval_text(self) -> str:
        if self.recording_model != "interval" or not self.sample_range:
            return ""
        start = float(self.sample_range["start"])
        end = float(self.sample_range["end"])
        return f"({start:+.2f}s to {end:+.2f}s)".replace("+-", "-")


# --------------------------------------------------------------------------------------
# Configuration loading
# --------------------------------------------------------------------------------------


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _own_record(edr: Any, vehicle_class: str) -> dict[str, Any]:
    """The record as this vehicle class defines it.

    Every edr_config lists the whole common EDR record, the other class's elements
    included (each entry's 'variants' says which classes define it). The case plan is about
    what this class records, so an element only the other class defines is left out - it
    would otherwise be found by position and checked where this class has no allocation.
    """
    return {name: entry for name, entry in edr.EDR_PARAMETERS_BY_NAME.items()
            if vehicle_class in entry.get("variants", [vehicle_class])}


def load_configs() -> dict[str, Any]:
    u_canc = _load_module(
        REPOSITORY_ROOT / "projects" / "U171" / "config" / "canc_config.py", "_u171_canc")
    u_edr = _load_module(
        REPOSITORY_ROOT / "projects" / "U171" / "config" / "edr_config.py", "_u171_edr")
    m_canc = _load_module(
        REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "config" / "canc_config.py",
        "_m314_canc")
    m_edr = _load_module(
        REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "config" / "edr_config.py",
        "_m314_edr")
    return {
        "u171_canc": u_canc,
        "u171_signals": u_canc.MAH_CAN_SIGNAL_DEFS,
        "u171_records": _own_record(u_edr, "ICE"),
        "m314_canc": m_canc,
        "m314_signals": m_canc.MAH_CAN_SIGNAL_DEFS,
        "m314_records": _own_record(m_edr, "EV"),
        "u171_reserved": getattr(u_edr, "RESERVED_ALLOCATIONS", []),
        "m314_reserved": getattr(m_edr, "RESERVED_ALLOCATIONS", []),
    }


# --------------------------------------------------------------------------------------
# The ICE side: read the authoritative numbering out of the U171 scripts
# --------------------------------------------------------------------------------------

# A script file name, in either spelling: the original SUBS_-prefixed one with no fault
# tag, and the current one that drops the prefix and ends in the tag. Both are accepted so
# the plan can be rebuilt either side of the rename.
SCRIPT_NAME = re.compile(
    r"^(?:SUBS_)?EDR_Element_ID_(.+?)_TestCase_(\d+)_(\d+)"
    r"(?:_(?:Nominal|CAN_Wakeup|CAN_NM|NA|MTO|MCF|SCF|SNR|VC|Invalid|OOR|Reserved|UV|OV"
    r"|Record_00|Record_FF)"
    r"(?:_(?:Full|Pre|Post))?)?$")

_CATEGORY_KIND = [
    ("Nominal", "nominal"),
    ("CAN wakeup", "wakeup"),
    ("CAN NM wakeup", "can_nm"),
    ("Node Absent", "node_absent"),
    ("Message Timeout", "message_timeout"),
    ("Message Content", "message_content"),
    ("Signal Content", "signal_content"),
    ("Signal Never Received", "signal_never_received"),
    ("Variant Code Error", "variant_code_error"),
    ("DBC invalid input", "dbc_invalid"),
    ("DBC encodable out-of-range input", "dbc_out_of_range"),
    ("DBC reserved input", "dbc_reserved"),
    # The voltage categories are read back too, so a rebuild that re-reads the scripts it
    # wrote last time produces the same plan rather than appending a second set.
    ("Under Voltage", "under_voltage"),
    ("Over Voltage", "over_voltage"),
]


def _kind_and_scope(category: str | None) -> tuple[str | None, str | None]:
    if not category:
        return None, None
    for prefix, kind in _CATEGORY_KIND:
        if category.startswith(prefix):
            if kind == "nominal":
                # A nominal case has no fault, so it has no fault window either; it is
                # held at "full" on both sides so the two readings agree.
                return kind, "full"
            if "only in pre crash" in category:
                return kind, "pre"
            if "only in post crash" in category:
                return kind, "post"
            if "in full interval" in category:
                return kind, "full"
            return kind, None
    return None, None


def _script_field(text: str, key: str) -> str | None:
    """Read a single- or multi-line identity field out of a generated script."""
    joined = re.search(
        rf"^\s*{key} = \(\s*\n((?:\s*'[^\n]*'\s*\n|\s*\"[^\n]*\"\s*\n)+)\s*\)", text, re.M)
    if joined:
        return " ".join(re.findall(r"['\"](.*?)['\"]", joined.group(1)))
    single = re.search(rf"^\s*{key} = ['\"](.*?)['\"]\s*$", text, re.M)
    return single.group(1) if single else None


def _script_signal_key(text: str, configs: dict[str, Any] | None) -> str | None:
    """The MAH_CAN_SIGNAL_DEFS key a script simulates.

    A script names it directly - ``MAH_CAN_SIGNAL_DEFS['KEY']`` - or imports the signal
    dictionary itself - ``signal_def = CAN_NAME`` - in which case the key is the one the
    registry files that same dictionary under.
    """
    direct = re.search(r"MAH_CAN_SIGNAL_DEFS\['([^']+)'\]", text)
    if direct:
        return direct.group(1)
    named = re.search(r"^\s*signal_def = (CAN_\w+)\s*$", text, re.M)
    if not named or not configs:
        return None
    definition = getattr(configs["u171_canc"], named.group(1), None)
    return next((key for key, value in configs["u171_signals"].items()
                 if value is definition), None)


def read_u171_scripts(configs: dict[str, Any] | None = None) -> dict[int, dict[str, Any]]:
    """Signal number -> parameter name, config keys and the cases on disk.

    The EV scripts live in the same folder, so they are skipped: they are this module's
    own output, and reading them back would let the EV allocation collide with itself.
    """
    generated = {(signal, parameter)
                 for signal, _, parameter, _ in EV_GAP_ALLOCATION}
    signals = (configs or {}).get("u171_signals") or {}
    found: dict[int, dict[str, Any]] = {}
    for path in sorted(U171_SCRIPTS.glob("*EDR_Element_ID_*_TestCase_*.py")):
        match = SCRIPT_NAME.match(path.stem)
        if not match:
            continue
        parameter, signal, number = match.group(1), int(match.group(2)), int(match.group(3))
        if (signal, parameter) in generated:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        signal_key = _script_signal_key(text, configs)
        if not signal_key:
            continue  # a crash-parameter or housekeeping script, not a CAN-C element
        # The element is either written into the script or taken from the signal's
        # EDR_Parameter in canc_config at run time; the plan reads it the same way.
        edr_parameter = _script_field(text, "edr_param") or (
            _resolve_signal(signals, signal_key)[0].get("EDR_Parameter") if signals else None)
        entry = found.setdefault(signal, {
            "parameter": parameter,
            "canc_signal": signal_key,
            "edr_parameter": edr_parameter,
            "cases": {},
        })
        if entry["parameter"] != parameter:
            continue  # a different element sharing this number, outside EDR_CANC
        kind, scope = _kind_and_scope(_script_field(text, "tc_category"))
        entry["cases"][number] = {"kind": kind, "scope": scope}
    return found


# --------------------------------------------------------------------------------------
# Appendix A
# --------------------------------------------------------------------------------------

# Signals whose "invalid" case the review replaces with an out-of-range case.
APPENDIX_A_INVALID_TO_OUT_OF_RANGE = {
    1, 2, 6, 7, 8, 9, 11, 13, 14, 15, 16, 17, 18, 19, 21, 22, 66,
}

# Signals the review leaves as "reserved" rather than turning into out of range.
APPENDIX_A_KEEP_RESERVED = {4, 7, 18, 19, 24, 29, 30, 31, 39, 40, 41, 42, 43, 44, 45, 51, 66}

# Case numbers Appendix A assigns, per signal, for the cases it asks to be added. Held so
# the builder can report where the review's numbering and the scripts' disagree without
# changing either.
APPENDIX_A_NUMBERS: dict[int, dict[str, list[int]]] = {
    1:  {"under_voltage": [9], "over_voltage": [10], "out_of_range": [8]},
    2:  {"under_voltage": [7], "over_voltage": [8], "out_of_range": [6]},
    3:  {"under_voltage": [5], "over_voltage": [6]},
    4:  {"under_voltage": [7], "over_voltage": [8]},
    5:  {"under_voltage": [5], "over_voltage": [6]},
    6:  {"under_voltage": [17, 18, 19], "over_voltage": [20, 21, 22], "out_of_range": [16]},
    7:  {"under_voltage": [17, 18, 19], "over_voltage": [20, 21, 22]},
    8:  {"under_voltage": [17, 18, 19], "over_voltage": [20, 21, 22], "out_of_range": [16]},
    9:  {"under_voltage": [17, 18, 19], "over_voltage": [20, 21, 22], "out_of_range": [16]},
    10: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15], "message_timeout": [16]},
    11: {"under_voltage": [14, 15, 16], "over_voltage": [17, 18, 19]},
    12: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15], "message_timeout": [16]},
    13: {"under_voltage": [13, 14, 15], "over_voltage": [16, 17, 18]},
    14: {"under_voltage": [13, 14, 15], "over_voltage": [16, 17, 18]},
    15: {"under_voltage": [13, 14, 15], "over_voltage": [16, 17, 18]},
    16: {"under_voltage": [13, 14, 15], "over_voltage": [16, 17, 18]},
    17: {"under_voltage": [13, 14, 15], "over_voltage": [16, 17, 18]},
    18: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15], "message_timeout": [16]},
    19: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    20: {"under_voltage": [16, 17, 18], "over_voltage": [19, 20, 21]},
    21: {"under_voltage": [16, 17, 18], "over_voltage": [19, 20, 21]},
    22: {"under_voltage": [16, 17, 18], "over_voltage": [19, 20, 21]},
    23: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    24: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    25: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    29: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    30: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    31: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    32: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    33: {"under_voltage": [8, 9, 10], "over_voltage": [11, 12, 13]},
    34: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    35: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    36: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    37: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    38: {"under_voltage": [10, 11, 12], "over_voltage": [13, 14, 15]},
    39: {"under_voltage": [8, 9, 10], "over_voltage": [11, 12, 13]},
    40: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    41: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    42: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    43: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    44: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    45: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    49: {"under_voltage": [7, 8, 9], "over_voltage": [10, 11, 12]},
    50: {"under_voltage": [7, 8, 9], "over_voltage": [10, 11, 12]},
    51: {"under_voltage": [11, 12, 13], "over_voltage": [14, 15, 16]},
    52: {"under_voltage": [14, 15, 16], "over_voltage": [17, 18, 19]},
    66: {"under_voltage": [12, 13, 14], "over_voltage": [15, 16, 17]},
}

# Items the review notes mark as unclear or self-contradicting. Left unchanged, reported.
APPENDIX_A_OPEN_ITEMS = [
    ("66", "Clutch Status: the signal numbers in the heading and the side notes about "
           "trigger / pre-crash are not legible, and which post-crash cases are removed "
           "is not stated case by case."),
    ("45", "The full signal name is cut off in the photo; the specification keeps "
           "ELK_OVERTAKING_WARNING1 from the U171 scripts."),
    ("44", "ELK Side Warning: the notes say UV/OV pending, with no case numbers."),
    ("43", "ELK Oncoming: the notes say UV/OV pending, with no case numbers."),
    ("35", "LKA Hands-off Display Warning: the notes write 36_1 for this element; "
           "whether it is signal 35 or 36 is not resolved."),
    ("30", "AES-SYS-STS: cases 30_1 to 30_9 are not visible in the photo."),
    ("33", "ADAS-DAS-Standard: the MTA note in the header is unclear, and 33_7 is marked "
           "'DTC to be added' without saying which DTC."),
    ("19", "Door Lock: 19_11 is written as both 'reserved' and the first UV case."),
    ("18", "Gear: 18_16 is written as both 'reserved' and 'MTA'."),
    ("7",  "Brake Switch: 7_22 is written as both OV and 'reserved', the MTO line is not "
           "visible, and what replaces 7_16 is not clear."),
    ("22", "Long Accel: the OV case numbers are cut off in the photo."),
]


# --------------------------------------------------------------------------------------
# EV gap allocation
# --------------------------------------------------------------------------------------

# Confirmed with the user. The order is the element order of the v7 common specification,
# in which these nineteen EV-only CAN-received parameters occupy exactly the numbers the
# ICE specification leaves free.
EV_GAP_ALLOCATION: list[tuple[int, str, str, int]] = [
    # (ICE-scheme signal number, canc_config signal key, v7 parameter name, v7 signal number)
    (26, "RCTA_WARN", "RCTA_WARN", 30),
    (27, "SEB_WARNING_LEFT", "SEB_WARNING_LEFT", 31),
    (28, "SEB_WARNING_RIGHT", "SEB_WARNING_RIGHT", 32),
    (46, "RCW_WARN", "RCW_WARN", 50),
    (47, "VCU_OPRT_REQ", "VCU_OPRT_REQ", 51),
    (48, "VCU_TRQ_CMD", "VCU_TRQ_CMD", 52),
    (53, "STS_ABS", "STS_ABS", 57),
    (54, "STS_EBD", "STS_EBD", 58),
    (55, "STS_ESC", "STS_ESC", 59),
    (56, "STS_TCS", "STS_TCS", 60),
    (57, "PADDLE_SHIFT_POSITION", "PADDLE_SHIFT_POSITION", 61),
    (58, "VCU_IGN_STS", "VCU_IGN_STS", 62),
    (59, "EMERGENCY_BRAKING_REQ", "EMERGENCY_BRAKING_REQ", 63),
    (60, "TORQUE_SPLIT_RATIO", "TORQUE_SPLIT_RATIO", 64),
    (61, "ALERT_MESSAGE", "ALERT_MESSAGE", 65),
    (62, "VCU_DRV_ADV_MODE", "VCU_DRV_ADV_MODE", 66),
    (63, "VCU_DRV_ADV_MODE_STS", "VCU_DRV_ADV_MODE_STS", 67),
    (64, "CTRL_BRAKE_LIGHT", "CTRL_BRAKE_LIGHT", 74),
    (65, "PIB_ACTIVE", "PIB_ACTIVE", 75),
]


# --------------------------------------------------------------------------------------
# Building the plans
# --------------------------------------------------------------------------------------


def _out_of_range_possible(definition: dict[str, Any]) -> bool:
    """True when the signal can encode a value above its valid maximum.

    canc_onfail.md: an out-of-range case is only meaningful when the DBC width leaves
    room above the valid range. Where it does not, the invalid code stays the case.
    """
    bits = definition.get("bit_length")
    maximum = definition.get("MAX")
    if not bits or maximum is None:
        return False
    # A raw the DBC already names - invalid, default - is a marker, not an out-of-range
    # measurement: an 8-bit signal valid to 254 with 255 as its invalid code has no
    # out-of-range value to drive.
    markers = set()
    for value in (definition.get("State_Values") or {}).values():
        try:
            markers.add(int(value))
        except (TypeError, ValueError):
            pass
    try:
        return any(raw not in markers
                   for raw in range(int(maximum) + 1, (1 << int(bits))))
    except (TypeError, ValueError):
        return False


# --------------------------------------------------------------------------------------
# The M314 DBCs: the authority for which content cases an EV signal has
# --------------------------------------------------------------------------------------

M314_DBC_FILES = [
    REPOSITORY_ROOT / "project_dbc" / "m314_dbc" / "SRS_FD_SVNID_41243.dbc",
    REPOSITORY_ROOT / "project_dbc" / "m314_dbc" / "SRS_HSCAN_SVNID_41243.dbc",
]
# The SRS's own node names in the two M314 DBCs. A frame they transmit is the ECU's
# output, so the restbus cannot drive it and no CAN fault can be injected on it.
M314_SRS_NODES = {"SRS_FD", "SRS_HSCAN"}

_DBC_FRAME = re.compile(r"^BO_\s+(\d+)\s+(\w+)\s*:\s*(\d+)\s+(\w+)")
_DBC_SIGNAL = re.compile(
    r"^\s*SG_\s+(\w+)\s*:\s*(\d+)\|(\d+)@(\d)([+-])\s*\(([^,]+),([^)]+)\)"
    r"\s*\[([^|]*)\|([^\]]*)\]")
_DBC_VALUES = re.compile(r"^VAL_\s+(\d+)\s+(\w+)\s+(.*);")

_M314_DBC_CACHE: dict[tuple[str, str], dict[str, Any]] | None = None


def read_m314_dbc() -> dict[tuple[str, str], dict[str, Any]]:
    """(frame, signal) -> width, conversion, valid range, value table and transmitter."""
    global _M314_DBC_CACHE
    if _M314_DBC_CACHE is not None:
        return _M314_DBC_CACHE
    signals: dict[tuple[str, str], dict[str, Any]] = {}
    by_id: dict[tuple[int, str], dict[str, Any]] = {}
    for path in M314_DBC_FILES:
        if not path.is_file():
            continue
        frame = None
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            match = _DBC_FRAME.match(line)
            if match:
                frame = (int(match.group(1)), match.group(2), match.group(4))
                continue
            match = _DBC_SIGNAL.match(line)
            if match and frame:
                entry = {
                    "frame_id": frame[0], "frame": frame[1], "transmitter": frame[2],
                    "bit_length": int(match.group(3)), "signed": match.group(5) == "-",
                    "factor": float(match.group(6)), "offset": float(match.group(7)),
                    "minimum": float(match.group(8)), "maximum": float(match.group(9)),
                    "values": {}, "dbc": path.name,
                }
                signals.setdefault((frame[1], match.group(1)), entry)
                by_id.setdefault((frame[0], match.group(1)), entry)
                continue
            match = _DBC_VALUES.match(line)
            if match:
                entry = by_id.get((int(match.group(1)), match.group(2)))
                if entry is not None:
                    entry["values"] = {int(raw): label for raw, label
                                       in re.findall(r'(-?\d+)\s+"([^"]*)"', match.group(3))}
    _M314_DBC_CACHE = signals
    return signals


def dbc_codes(definition: dict[str, Any]) -> dict[str, Any]:
    """What the M314 DBC says about one canc_config signal.

    invalid   the raw codes the value table names invalid - signal content failure is
              tested by driving the first of them, and exists only where there is one
    reserved  the raw codes the value table names reserved
    oor       the out-of-range raw: the highest raw the bit length can carry above the
              DBC maximum that the value table does not name (default, reserved, invalid
              or any other state) and that is not the signal's default. None when there
              is no such raw - then there is no out-of-range case
    internal  the frame is transmitted by the SRS itself
    """
    entry = read_m314_dbc().get((str(definition.get("frame")), str(definition.get("signal"))))
    if not entry:
        return {"found": False, "invalid": [], "reserved": [], "oor": None,
                "internal": False, "named": set()}
    named = set(entry["values"])
    invalid = sorted(raw for raw, label in entry["values"].items() if "invalid" in label.lower())
    reserved = sorted(raw for raw, label in entry["values"].items()
                      if "reserved" in label.lower())
    raw_max = int(round((entry["maximum"] - entry["offset"]) / entry["factor"]))
    raw_min = int(round((entry["minimum"] - entry["offset"]) / entry["factor"]))
    bits = entry["bit_length"]
    top = (1 << (bits - 1)) - 1 if entry["signed"] else (1 << bits) - 1
    default = definition.get("Default_Value")
    oor = next((raw for raw in range(top, raw_max, -1)
                if raw not in named and raw != default), None)
    return {
        "found": True, "invalid": invalid, "reserved": reserved, "oor": oor,
        "named": named, "raw_min": raw_min, "raw_max": raw_max, "top": top,
        "bit_length": bits, "signed": entry["signed"],
        "internal": entry["transmitter"] in M314_SRS_NODES,
        "transmitter": entry["transmitter"], "values": entry["values"],
    }


def _resolve_signal(signals: dict[str, Any], key: str) -> tuple[dict[str, Any], str]:
    """The canc_config entry a script names, and a note when it had to be found for it.

    One script family names a key canc_config does not have. Rather than plan that element
    blind, the entry whose key the script's key ends with is used, and the mismatch is
    reported: it is a defect in the script, which this work is not allowed to change.
    """
    if key in signals:
        return signals[key], ""
    candidates = [name for name in signals
                  if name and key.endswith(name) and name != key]
    # The other direction too: a script key one suffix short of the configured one
    # (LKA_HANDSOFF_DISPLAY_WARNING for LKA_HANDSOFF_DISPLAY_WARNING1).
    candidates = candidates or [name for name in signals
                                if name and name.startswith(key) and name != key]
    if not candidates:
        return {}, (f"the scripts read MAH_CAN_SIGNAL_DEFS[{key!r}], which canc_config does "
                    f"not define, and no other entry matches. Fault topology for this "
                    f"element could not be determined")
    best = max(candidates, key=len)
    return signals[best], (
        f"the scripts read MAH_CAN_SIGNAL_DEFS[{key!r}], which canc_config does not "
        f"define - it defines {best!r} on {signals[best].get('frame')}. The scripts raise "
        f"KeyError as they stand; this plan uses {best!r}")


def _resolve_record(records: dict[str, Any], name: str | None) -> tuple[str | None, str]:
    """The record element a script names, and a note when it had to be found for it.

    Two script families name an element by a shorter form than the record uses - the
    record's own name is the authority, since that is what the decoder looks up. The
    match is on the record name ending with the script's, which is how both differ.
    """
    if not name or name in records:
        return name, ""
    candidates = [candidate for candidate in records
                  if candidate.endswith(name) and candidate != name]
    if not candidates:
        return name, (f"the scripts read edr_config element {name!r}, which the record "
                      f"layout does not define, and no other element matches")
    best = min(candidates, key=len)
    return best, (f"the scripts read edr_config element {name!r}; the record layout calls "
                  f"it {best!r}. The specification and the scripts now use the record's "
                  f"name, which is the one the decoder looks up")


# Public alias: other tools resolve element names the same way.
resolve_record_name = _resolve_record


def _timeout_frame(definition: dict[str, Any], fault_logic: dict[str, Any]) -> str | None:
    """The frame to stop for a Message Timeout.

    canc_onfail.md is explicit: the timeout is created on the message that carries the
    signal being simulated, not on some other slave of the same node, because stopping a
    frame the element does not read leaves it consuming values rather than holding the
    last valid one. Where the configuration names that frame it is used; where it does
    not, the signal's own frame is it, unless that frame is the key message - stopping the
    key message is a Node Absent, not a Message Timeout.
    """
    configured = fault_logic.get("non_key_timeout_frame")
    if configured:
        return configured
    frame = definition.get("frame")
    return frame if frame and frame != fault_logic.get("key_message") else None


def build_ice_plans(configs: dict[str, Any],
                    v4_cases: dict[int, dict[int, dict[str, Any]]]) -> dict[int, ParameterPlan]:
    """One plan per ICE element, numbered the way the U171 scripts number their cases.

    The V4 workbook predates the CAN wakeup case, so wherever the scripts hold the wakeup
    case partway up the list every V4 case at or above that position moves up by one. The
    shift is measured from the scripts rather than assumed, and each shifted V4 case is
    checked against the script that shares its new number.
    """
    scripts = read_u171_scripts(configs)
    signals = configs["u171_signals"]
    records = configs["u171_records"]
    plans: dict[int, ParameterPlan] = {}

    for number, entry in sorted(scripts.items()):
        definition, resolution = _resolve_signal(signals, entry["canc_signal"])
        element, element_note = _resolve_record(records, entry["edr_parameter"])
        record = records.get(element or "") or {}
        fault_logic = definition.get("fault_logic") or {}
        script_cases = entry["cases"]
        plan = ParameterPlan(
            signal=number,
            parameter=entry["parameter"],
            variant="ICE",
            # The configured key, where the scripts name one canc_config does not have.
            canc_signal=(entry["canc_signal"] if entry["canc_signal"] in signals else
                         next((key for key, value in signals.items() if value is definition),
                              entry["canc_signal"])),
            edr_parameter=element,
            frame=definition.get("frame"),
            key_frame=fault_logic.get("key_message"),
            timeout_frame=_timeout_frame(definition, fault_logic),
            periodicity=definition.get("periodicity"),
            samples=int(record.get("data_samples_number") or 1),
            sample_range=record.get("sample_range"),
            recording_model=record.get("recording_model") or "snapshot",
        )
        if resolution:
            plan.notes.append(resolution)
        if element_note:
            plan.notes.append(element_note)

        # V4 and the scripts are matched on what a case tests, not on its number: the
        # scripts are numbered in review order, V4 in the order it was written.
        v4_by_test: dict[tuple[str, str | None], int] = {}
        for v4_number, v4_case in sorted((v4_cases.get(number) or {}).items()):
            if v4_case["scope"] == "post" and not plan.has_post_crash:
                plan.notes.append(
                    f"V4 case {v4_number} ({KINDS[v4_case['kind']][0]} post-crash) dropped: "
                    f"this element records nothing after T0 and the scripts carry no such "
                    f"case")
                continue
            v4_by_test.setdefault((v4_case["kind"], v4_case["scope"]), v4_number)

        # The scripts decide which cases exist; V4 only lends its text. Where there are no
        # scripts yet, the V4 cases are the starting set.
        merged: dict[int, dict[str, Any]] = {}
        if script_cases:
            for case_number, case in sorted(script_cases.items()):
                if case["kind"] is None:
                    plan.notes.append(
                        f"case {case_number}: the script carries no recognised category")
                    continue
                v4_number = v4_by_test.get((case["kind"], case["scope"]))
                if (v4_number is None and case["kind"] == "dbc_out_of_range"
                        and number in APPENDIX_A_INVALID_TO_OUT_OF_RANGE):
                    # Appendix A turned the V4 invalid case into this one; it keeps that
                    # case's tracker ID and authored rows.
                    v4_number = v4_by_test.get(("dbc_invalid", None))
                merged[case_number] = {**case, "source": "existing", "v4_number": v4_number}
            scripted = {(case["kind"], case["scope"]) for case in merged.values()}
            for (kind, scope), v4_number in sorted(v4_by_test.items(), key=lambda i: i[1]):
                if (kind, scope) not in scripted:
                    plan.notes.append(
                        f"V4 case {v4_number} ({KINDS[kind][0]} {scope or ''}".rstrip()
                        + ") has no script; the scripts decide which cases exist")
        else:
            for (kind, scope), v4_number in v4_by_test.items():
                merged[v4_number] = {"kind": kind, "scope": scope, "source": "existing",
                                     "v4_number": v4_number}

        already_out_of_range = any(
            case["kind"] == "dbc_out_of_range" for case in merged.values())
        for case_number in sorted(merged):
            case = merged[case_number]
            kind, scope = case["kind"], case["scope"]
            source = case["source"]
            note = ""
            if kind == "dbc_invalid" and number in APPENDIX_A_INVALID_TO_OUT_OF_RANGE:
                if already_out_of_range:
                    # Appendix A marks this case for removal rather than conversion: the
                    # element already has an out-of-range case, and two would be the same
                    # test twice. The number is left vacant so nothing else moves.
                    plan.notes.append(
                        f"case {case_number} (DBC invalid input) removed: Appendix A "
                        f"replaces the invalid case with out of range, and case "
                        f"{next(n for n, c in merged.items() if c['kind'] == 'dbc_out_of_range')}"
                        f" already is one. The number is left vacant; script "
                        f"{plan.parameter}_TestCase_{number}_{case_number}.py still exists "
                        f"on disk")
                    continue
                if _out_of_range_possible(definition):
                    kind, source = "dbc_out_of_range", "renumbered"
                    note = "Appendix A: invalid case replaced by out of range"
                else:
                    plan.notes.append(
                        f"case {case_number}: Appendix A asks for out of range, but "
                        f"{plan.canc_signal} can encode no value above its valid maximum "
                        f"({definition.get('MAX')} in {definition.get('bit_length')} bits), "
                        f"so the DBC invalid code case is kept")
            # A case converted to out of range keeps the V4 invalid case it replaces; the
            # workbook builder rewrites its description from the note.
            plan.cases.append(Case(number, case_number, kind, scope, "ICE",
                                   entry["parameter"], source, note=note,
                                   v4_number=case["v4_number"]))

        plan.highest_reserved = max([*merged, *script_cases], default=0)
        _append_missing_fault_cases(plan)
        _append_voltage_cases(plan)
        plans[number] = plan
    return plans


def _append_missing_fault_cases(plan: ParameterPlan) -> None:
    """Add the Message Timeout and Node Absent cases the element is missing.

    Which cases are possible follows the frame topology in canc_config, not a wish list:
    Node Absent needs a key message, Message Timeout needs a signal-carrying message that
    is not the key message.
    """
    present = {(case.kind, case.scope) for case in plan.cases}
    next_number = _next_number(plan)
    wanted = plan.fault_scopes

    if plan.canc_signal == "STS_ENG":
        # canc_onfail.md: this signal only times out when it carries 0x1 or 0x5, which
        # takes ten seconds to qualify, so the fault cannot be confined to one side of the
        # crash. The full-interval case the scripts already carry is the only one possible.
        wanted = ["full"]
        plan.notes.append(
            "STS_ENG qualifies a timeout only while the signal carries 0x1 or 0x5, which "
            "takes 10 s, so no pre-crash or post-crash timing case is possible")

    if plan.key_frame:
        for scope in wanted:
            if ("node_absent", scope) in present:
                continue
            plan.cases.append(Case(plan.signal, next_number, "node_absent", scope, "ICE",
                                   plan.parameter, "new",
                                   note=f"Node Absent on key message {plan.key_frame}"))
            next_number += 1
    else:
        plan.notes.append("no key message in canc_config, so no Node Absent case")

    if plan.timeout_frame and plan.timeout_frame != plan.key_frame:
        carries_signal = plan.timeout_frame == plan.frame
        for scope in wanted:
            if ("message_timeout", scope) in present:
                continue
            note = f"Message Timeout on {plan.timeout_frame}"
            if not carries_signal:
                note += (f" - this frame does not carry {plan.frame}, so the element keeps"
                         f" receiving and records its normal valid value")
            plan.cases.append(Case(plan.signal, next_number, "message_timeout", scope,
                                   "ICE", plan.parameter, "new", note=note))
            next_number += 1
    elif not plan.timeout_frame:
        plan.notes.append(
            "no non-key message in canc_config, so no Message Timeout case is possible")
    else:
        plan.notes.append(
            f"the only message {plan.timeout_frame} is the key message, so a timeout on it "
            f"is a Node Absent, not a Message Timeout")


def _next_number(plan: ParameterPlan) -> int:
    used = max((case.number for case in plan.cases), default=0)
    return max(used, plan.highest_reserved) + 1


def _append_voltage_cases(plan: ParameterPlan) -> None:
    present = {(case.kind, case.scope) for case in plan.cases}
    next_number = _next_number(plan)
    for kind in ("under_voltage", "over_voltage"):
        # A snapshot element's only scope is "full", the same word the generated script's
        # category carries, so re-reading that script matches the case already planned
        # instead of appending a second one.
        for scope in plan.fault_scopes:
            if (kind, scope) in present:
                continue
            plan.cases.append(Case(plan.signal, next_number, kind, scope,
                                   plan.variant, plan.parameter, "new",
                                   note="Appendix A: added"))
            next_number += 1


def ev_routes_for_shared(configs: dict[str, Any], ice: dict[int, ParameterPlan]
                         ) -> list[tuple[int, str, str, str | None]]:
    """The ICE series that M314 also carries, as EV allocations.

    A series is shared when M314 both records the element and has a signal that feeds it.
    Three do not survive that test - engine state, doors open status and clutch status -
    and those series numbers are simply absent from the EV specification, the same way the
    EV-only numbers are absent from the ICE one.
    """
    signals = configs["m314_signals"]
    records = configs["m314_records"]

    by_element: dict[str | None, list[str]] = {}
    for key, definition in signals.items():
        if not isinstance(definition, dict) or not definition.get("EDR_Parameter"):
            continue
        element, _ = _resolve_record(records, definition["EDR_Parameter"])
        by_element.setdefault(element, []).append(key)

    shared = []
    for number in sorted(ice):
        plan = ice[number]
        element = _same_element(plan.edr_parameter, configs["u171_records"], records)
        if element is None:
            continue
        # Failing an element match, the M314 registry key is the ICE key or the DBC signal
        # the ICE entry drives (VEHSPD_LGT_AT_TIME_ZERO drives VEHICLE_SPEED_ESC12).
        dbc_signal = (configs["u171_signals"].get(plan.canc_signal) or {}).get("signal")
        keys = _feeding_key(signals, by_element.get(element) or [], number,
                            plan.canc_signal) or [
            key for key in (plan.canc_signal, dbc_signal) if key in signals][:1]
        if keys:
            # A series number means the same element in both variants, so the EV plan
            # takes the M314 record's own name for the element the ICE plan resolved.
            shared.append((number, keys[0], plan.parameter, element))
    return shared


def _feeding_key(signals: dict[str, Any], candidates: list[str], number: int,
                 ice_key: str | None) -> list[str]:
    """The M314 signal key that feeds a shared series, out of those naming its element.

    The EDR parameter name is common to every project, while the message and signal that
    carry it are the project's own, so several M314 keys can name one element: aliases of
    one signal definition (VEHICLE_SPEED, VEHICLE_SPEED_ESC12, VehSpdLgt), or a different
    signal copied with the ICE name (BRK_PEDAL1, the pedal travel, next to BRK_SWITCH,
    which feeds the brake switch status). The definition that holds this series' own
    arrays is the one the series is written for; among aliases of it, the U171 key keeps
    the name both variants share, then the key named after its own signal.
    """
    holding = [key for key in candidates
               if (signals.get(key) or {}).get(f"TestCase_{number}_Values") is not None]
    pool = holding or candidates
    for key in (ice_key, *(key for key in pool if key == (signals.get(key) or {}).get("signal"))):
        if key in pool:
            return [key]
    return pool[:1]


def _normalised(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def _same_element(name: str | None, u171_records: dict[str, Any],
                  m314_records: dict[str, Any]) -> str | None:
    """The M314 record element that is the U171 element ``name``.

    Every edr_config names an element by its common name (U171's, see
    build_edr_config_from_diag.COMMON_ELEMENT_NAMES), so the name usually matches
    directly. Failing that, both describe the same 0x0455 record, so the element is found
    by where it sits: same start byte, length and bit range. Where the two layouts
    disagree on the allocation the names are compared with punctuation and case ignored
    (STS_LOW_BEAM, STS_LOWBEAM).
    """
    if not name:
        return None
    if name in m314_records:
        return name
    record = u171_records.get(name) or {}
    placed = [key for key, other in m314_records.items()
              if record and other.get("data_start_byte") == record.get("data_start_byte")
              and other.get("data_byte_length") == record.get("data_byte_length")
              and other.get("range") == record.get("range")]
    if len(placed) == 1:
        return placed[0]
    named = [key for key in (placed or m314_records) if _normalised(key) == _normalised(name)]
    return named[0] if named else None


def build_ev_plans(configs: dict[str, Any],
                   ice: dict[int, ParameterPlan] | None = None) -> dict[int, ParameterPlan]:
    """One plan per EV element, on the recording axis the M314 record actually has.

    The EV specification carries every series the variant records: the shared ones on
    their M314 routes, and the EV-only ones in the numbers the ICE scheme leaves free. A
    series number means the same element in both specifications, so a tracker can be read
    against the other.

    The interval and the sample count come from the EV diagnostic specification by way of
    the M314 edr_config, not from the v7 common workbook: the two disagree for several
    elements, and the record layout is what the ECU writes.
    """
    signals = configs["m314_signals"]
    records = configs["m314_records"]
    plans: dict[int, ParameterPlan] = {}
    internal: dict[int, ParameterPlan] = {}

    # (series, signal key, parameter, v7 element number, record element). An EV-only
    # series resolves its element from the M314 signal; a shared one is handed the element
    # the ICE plan already verified against the record.
    allocation: list[tuple[int, str, str, int | None, str | None]] = [
        (number, key, parameter, v7, None)
        for number, key, parameter, v7 in EV_GAP_ALLOCATION]
    if ice:
        allocation += [(number, key, parameter, None, element)
                       for number, key, parameter, element
                       in ev_routes_for_shared(configs, ice)]

    for number, signal_key, parameter, v7_number, known_element in sorted(allocation):
        definition = signals.get(signal_key)
        if not definition:
            continue
        fault_logic = definition.get("fault_logic") or {}
        # The plan carries the record's own name - the common name - and resolves a
        # signal's EDR_Parameter to it where the two still differ.
        if known_element:
            element, element_note = known_element, ""
        else:
            element, element_note = _resolve_record(records,
                                                    definition.get("EDR_Parameter"))
        record = records.get(element or "") or {}
        codes = dbc_codes(definition)
        # canc_onfail.md: a Message Timeout stops the frame that carries the signal. Where
        # that frame is the node's key message, stopping it is a Node Absent, so there is
        # no timeout case - whatever other frame the configuration may name.
        frame = definition.get("frame")
        key_frame = fault_logic.get("key_message")
        plan = ParameterPlan(
            signal=number,
            parameter=parameter,
            variant="EV",
            canc_signal=signal_key,
            edr_parameter=element,
            frame=frame,
            key_frame=key_frame,
            timeout_frame=frame if frame and key_frame and frame != key_frame else None,
            periodicity=definition.get("periodicity"),
            samples=int(record.get("data_samples_number") or 1),
            sample_range=record.get("sample_range"),
            recording_model=record.get("recording_model") or "snapshot",
        )
        if codes["internal"]:
            # The ECU transmits this frame itself (M314 YAW_RATE, LATERAL_ACCEL, LONG_ACCEL
            # on SRS1_FD_10, from the internal IMU), so the restbus cannot drive the value
            # and no CAN fault can be injected. The element is recorded from the ECU's own
            # sensor: it belongs to the IMU recording specification, not to CAN-C, and it
            # is not a not-configured allocation either (user direction 2026-10-07).
            plan.notes.append(
                f"{frame} is transmitted by {codes['transmitter']} - the ECU itself - so "
                f"{parameter} is not a CAN-C input on EV; covered by the EV IMU recording "
                f"specification")
            internal[number] = plan
            continue
        if not record:
            plan.notes.append(
                f"{definition.get('EDR_Parameter')!r} is not in the M314 edr_config, so "
                f"this element has no record layout to verify against")
        if v7_number:
            plan.notes.append(f"v7 common specification element {v7_number}")
        if element_note:
            plan.notes.append(element_note)

        wanted = plan.fault_scopes
        next_number = 1
        plan.cases.append(Case(number, next_number, "nominal", "full", "EV", parameter, "new"))
        next_number += 1
        # Planning order only: renumber() puts the wakeup case last and numbers every case
        # in review order, the same way it numbers the ICE ones.
        plan.cases.append(Case(number, next_number, "wakeup", None, "EV", parameter, "new"))
        next_number += 1

        if plan.key_frame:
            for scope in wanted:
                plan.cases.append(Case(number, next_number, "node_absent", scope, "EV",
                                       parameter, "new"))
                next_number += 1
        if plan.timeout_frame:
            for scope in wanted:
                plan.cases.append(Case(number, next_number, "message_timeout", scope, "EV",
                                       parameter, "new",
                                       note=f"Message Timeout on {plan.timeout_frame}"))
                next_number += 1
        else:
            plan.notes.append(
                f"{signal_key} is carried on the key message {plan.key_frame}, so it has no "
                f"Message Timeout case")
        if fault_logic.get("message_content_failure_dtcs"):
            for scope in wanted:
                plan.cases.append(Case(number, next_number, "message_content", scope, "EV",
                                       parameter, "new"))
                next_number += 1
        # Signal content failure is driving the DBC invalid code, so it exists exactly where
        # the M314 DBC defines one - whether or not the DTC list gives it a DTC. There is no
        # separate "invalid" case.
        if codes["invalid"]:
            for scope in wanted:
                plan.cases.append(Case(number, next_number, "signal_content", scope, "EV",
                                       parameter, "new"))
                next_number += 1
            if not fault_logic.get("signal_content_failure_dtc"):
                plan.notes.append(
                    f"the M314 DBC defines invalid code {codes['invalid'][0]} for "
                    f"{definition.get('signal')}, but the EV DTC list has no signal content "
                    f"failure DTC for it, so its SCF cases expect the crash DTCs only")
        plan.cases.append(Case(number, next_number, "signal_never_received", "full", "EV",
                               parameter, "new"))
        next_number += 1
        plan.cases.append(Case(number, next_number, "variant_code_error", "full", "EV",
                               parameter, "new"))
        next_number += 1

        # A reserved code the DBC names is tested as reserved; out of range is tested where
        # the bit length leaves a raw above the DBC maximum that names nothing. The two are
        # independent: one signal can have both, either or neither.
        if codes["reserved"]:
            plan.cases.append(Case(number, next_number, "dbc_reserved", None, "EV",
                                   parameter, "new"))
            next_number += 1
        if codes["oor"] is not None:
            plan.cases.append(Case(number, next_number, "dbc_out_of_range", None, "EV",
                                   parameter, "new"))
            next_number += 1
        if not codes["reserved"] and codes["oor"] is None:
            plan.notes.append(
                "the DBC names no reserved value and leaves no unnamed raw above the valid "
                "range, so there is no reserved or out-of-range case")

        _append_voltage_cases(plan)
        # Hardware ignition OFF, woken by the network-management PDU; numbered last by
        # renumber(), after the CAN wakeup case.
        plan.cases.append(Case(number, _next_number(plan), "can_nm", None, "EV", parameter,
                               "new"))
        plans[number] = plan
    _EV_INTERNAL.clear()
    _EV_INTERNAL.update(internal)
    return plans


# EV series whose signal the ECU transmits itself, filled by build_ev_plans: excluded from
# the CAN-C plan and from the not-configured check, covered by the IMU recording spec.
_EV_INTERNAL: dict[int, ParameterPlan] = {}


# --------------------------------------------------------------------------------------
# The v7 recording axes, read once so the EV plans carry real sample counts
# --------------------------------------------------------------------------------------

_AXIS = re.compile(r"Recording time \[s\] \((\d+) values\): \[([^\]]*)\]")

# How a case description in either authoring workbook names its fault. Ordered, because
# "Signal Content" and "Signal Never Received" share a prefix.
_DESCRIPTION_KIND = [
    ("wakeup", "wakeup"),
    ("can wake", "wakeup"),
    ("woken by can", "wakeup"),
    ("node absent", "node_absent"),
    ("message timeout", "message_timeout"),
    ("message counter", "message_content"),
    ("message content", "message_content"),
    ("signal never received", "signal_never_received"),
    ("signal content", "signal_content"),
    ("variant code", "variant_code_error"),
    ("out-of-range", "dbc_out_of_range"),
    ("out of range", "dbc_out_of_range"),
    ("reserved", "dbc_reserved"),
    ("invalid", "dbc_invalid"),
    ("nominal", "nominal"),
]


def _classify_description(description: str | None) -> tuple[str | None, str | None]:
    text = (description or "").lower()
    for marker, kind in _DESCRIPTION_KIND:
        if marker in text:
            if kind == "nominal":
                return kind, "full"
            if not KINDS[kind][1]:
                return kind, None
            if "only in pre crash" in text or "pre-crash" in text:
                return kind, "pre"
            if "only in post crash" in text or "post-crash" in text:
                return kind, "post"
            return kind, "full"
    return None, None


def read_v4_cases() -> dict[int, dict[int, dict[str, Any]]]:
    """Signal number -> case number -> kind and scope, as the V4 workbook has them.

    Only the EDR_CANC folder is read. The folder runs from the first case after the
    EDR_CANC folder row to the row before the next folder row, so the crash-parameter,
    sensor and multi-event folders below it are not picked up.
    """
    import openpyxl

    workbook = openpyxl.load_workbook(V4_WORKBOOK, data_only=True)
    sheet = workbook["Export"]
    cases: dict[int, dict[int, dict[str, Any]]] = {}
    inside = False
    for row in range(2, sheet.max_row + 1):
        name = sheet.cell(row, 3).value
        if not name:
            continue
        if str(sheet.cell(row, 14).value or "") == "Folder":
            inside = str(name) == "EDR_CANC"
            continue
        if not inside:
            continue
        match = re.match(r"SUBS_EDR_Element_ID_(.+?)_TestCase_(\d+)_(\d+)$", str(name))
        if not match:
            continue
        kind, scope = _classify_description(str(sheet.cell(row, 4).value or ""))
        if kind is None:
            continue
        cases.setdefault(int(match.group(2)), {})[int(match.group(3))] = {
            "kind": kind, "scope": scope, "parameter": match.group(1), "row": row,
        }
    return cases


def read_v7_axes() -> dict[str, dict[str, Any]]:
    """Parameter -> sample count and interval, taken from the v7 Pre-Action text."""
    import openpyxl

    workbook = openpyxl.load_workbook(V7_WORKBOOK, data_only=True)
    sheet = workbook["Sheet1"]
    axes: dict[str, dict[str, Any]] = {}
    for row in range(2, sheet.max_row + 1):
        name = sheet.cell(row, 3).value
        if not name:
            continue
        match = re.match(r"SUBS_EDR_Element_ID_(.+?)_TestCase_(\d+)_(\d+)$", str(name))
        if not match or match.group(1) in axes:
            continue
        pre_action = str(sheet.cell(row, 6).value or "")
        axis = _AXIS.search(pre_action)
        if not axis:
            continue
        times = [float(value) for value in axis.group(2).split(",") if value.strip()]
        if not times:
            continue
        step = round(times[1] - times[0], 4) if len(times) > 1 else 0.0
        axes[match.group(1)] = {
            "samples": int(axis.group(1)),
            "sample_range": {"start": times[0], "end": times[-1], "step": step},
        }
    return axes


# --------------------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------------------


# The two whole-record checks, numbered as the V4 workbook numbered them.
RECORD_CHECKS = {
    9001: ("RESERVED_BYTES", "record_reserved"),
    9000: ("NOT_CONFIGURED", "record_not_configured"),
}


def not_configured_elements(records: dict[str, Any], own: dict[int, ParameterPlan],
                            other: dict[int, ParameterPlan],
                            other_records: dict[str, Any] | None = None,
                            fed_internally: dict[int, ParameterPlan] | None = None
                            ) -> list[dict[str, Any]]:
    """Record allocations this variant does not feed, which must read all ones.

    The common record carries every element either variant records. An element the other
    variant routes and this one does not is never written here, so its allocation stays at
    the deconfigured value. An element this variant does test is not in the list, however
    the other variant names it - which is what put battery voltage in the ICE list before:
    the record calls it ZONAL_BATT_VOLT and the CAN signal is BATT_VOLT, so the route
    looked absent when it is not.

    ``fed_internally`` holds this variant's series that the ECU feeds from its own sensor
    rather than over CAN (EV yaw rate and accelerations): they are recorded, so they are not
    not-configured either.
    """
    internal = fed_internally or {}
    tested = {plan.edr_parameter for plan in (*own.values(), *internal.values())}
    entries = []
    for number in sorted(other):
        plan = other[number]
        # The other variant's edr_config may name the element differently; this record's
        # own name for it is the one that counts.
        element = plan.edr_parameter
        if element not in records and other_records is not None:
            element = _same_element(element, other_records, records)
        if number in own or number in internal or element in tested:
            continue
        record = records.get(element or "")
        if not record:
            continue
        # A sub-byte element shares its byte with elements this variant does feed, so
        # the check masks to the bits it owns rather than comparing the whole byte.
        high = low = None
        bits = str(record.get("range") or "")
        match = re.match(r"(\d+)\.(\d+)(?:-\d+\.(\d+))?$", bits)
        if match:
            low = int(match.group(2))
            high = int(match.group(3)) if match.group(3) else low
        entries.append({
            "name": element,
            "start_byte": record["data_start_byte"],
            "byte_length": record["data_byte_length"],
            "high_bit": high,
            "low_bit": low,
        })
    return entries


def _append_record_checks(configs: dict[str, Any], ice: dict[int, ParameterPlan],
                          ev: dict[int, ParameterPlan]) -> None:
    """Give each variant its reserved-bytes and not-configured checks."""
    for plans, other, key in ((ice, ev, "u171_records"), (ev, ice, "m314_records")):
        variant = "ICE" if key == "u171_records" else "EV"
        records = configs[key]
        other_records = configs["m314_records" if key == "u171_records" else "u171_records"]
        for number, (parameter, kind) in RECORD_CHECKS.items():
            plan = ParameterPlan(
                signal=number, parameter=parameter, variant=variant,
                canc_signal="", edr_parameter=None, recording_model="snapshot")
            plan.cases.append(Case(number, 1, kind, None, variant, parameter, "new"))
            if kind == "record_not_configured":
                internal = _EV_INTERNAL if variant == "EV" else None
                count = len(not_configured_elements(records, plans, other, other_records,
                                                    internal))
                plan.notes.append(
                    f"{count} allocation(s) the {variant} variant does not feed")
            plans[number] = plan


def renumber(plans: dict[int, ParameterPlan]) -> None:
    """Number every parameter's cases from 1 in review order (review comment 1).

    The whole-record checks are not a parameter's cases and keep their own numbers.
    """
    for plan in plans.values():
        if plan.signal in RECORD_CHECKS:
            continue
        plan.cases.sort(key=review_order_key)
        for number, case in enumerate(plan.cases, start=1):
            case.number = number
        plan.highest_reserved = len(plan.cases)


def build_all() -> dict[str, Any]:
    configs = load_configs()
    ice = build_ice_plans(configs, read_v4_cases())
    ev = build_ev_plans(configs, ice)
    renumber(ice)
    renumber(ev)
    _append_record_checks(configs, ice, ev)
    gaps = {number for number, _, _, _ in EV_GAP_ALLOCATION}
    collisions = sorted(gaps & set(ice))
    if collisions:
        raise SystemExit(f"EV gap allocation collides with ICE series: {collisions}")
    return {"ice": ice, "ev": ev, "ev_internal": dict(_EV_INTERNAL)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="write the plan to this file")
    parser.add_argument("--signal", type=int, action="append",
                        help="print only these signal numbers")
    arguments = parser.parse_args()

    plans = build_all()
    combined = {**plans["ice"], **plans["ev"]}

    total = 0
    for number in sorted(combined):
        plan = combined[number]
        if arguments.signal and number not in arguments.signal:
            continue
        total += len(plan.cases)
        header = (f"{number:>3} {plan.variant:<3} {plan.parameter:<32} "
                  f"{plan.samples:>3} sample(s) {plan.interval_text():<20} "
                  f"{len(plan.cases):>3} case(s)")
        print(header)
        for case in plan.cases:
            label = KINDS[case.kind][0] + (f" {case.scope}" if case.scope else "")
            mark = {"existing": " ", "renumbered": "~", "new": "+"}[case.source]
            print(f"       {mark} {case.number:>3}  {label}")
        for note in plan.notes:
            print(f"         note: {note}")
    print()
    print(f"{len(combined)} parameter(s), {total} case(s)"
          f"  [ICE {len(plans['ice'])}, EV {len(plans['ev'])}]")

    if arguments.json:
        payload = {
            "parameters": [
                {**{k: v for k, v in asdict(plan).items() if k != "cases"},
                 "cases": [asdict(case) for case in plan.cases]}
                for plan in (combined[n] for n in sorted(combined))
            ],
            "appendix_a_numbers": APPENDIX_A_NUMBERS,
            "appendix_a_open_items": APPENDIX_A_OPEN_ITEMS,
        }
        arguments.json.write_text(json.dumps(payload, indent=1), encoding="utf-8")
        print(f"plan written to {arguments.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
