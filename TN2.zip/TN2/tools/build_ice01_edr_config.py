"""Build the ICE_01 EDR configuration from the common DRBFM record layout.

Emits `projects/ICE_01/config/edr_config.py`. The DRBFM analysis sheet defines the
0x0455 / 0x045B record layout - byte position, bit position, sampling interval, samples
per second, and EDR resolution/offset - so it is the source for every field here.

Offline only: reads the DRBFM workbook, writes one Python config file.

Usage:
    py -3.14 tools/build_ice01_edr_config.py
"""

from __future__ import annotations

import argparse
import pprint
import re
import sys
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "tests"))
sys.path.insert(0, str(REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "scripts"))

import test_common_edr_canc_specification as spec  # noqa: E402

PROJECTS = {"ICE_01": "ICE", "EV_01": "EV"}

BYTE_RANGE = re.compile(r"(\d+)\s*[-to]+\s*(\d+)")
SINGLE_BYTE = re.compile(r"^\s*(\d+)\s*$")


def _numeric(value: object) -> float | None:
    if value is None:
        return None
    text = re.sub(r"[^0-9.eE+-]", "", str(value))
    try:
        return float(text)
    except ValueError:
        return None


def _byte_span(element: Any) -> tuple[int | None, int | None]:
    text = str(element.values.get("Byte position") or "")
    match = BYTE_RANGE.search(text)
    if match:
        return int(match.group(1)), int(match.group(2))
    single = SINGLE_BYTE.match(text)
    if single:
        return int(single.group(1)), int(single.group(1))
    return None, None


def _sample_range(element: Any) -> dict[str, float] | None:
    schedule = spec.sampling_schedule(element)
    if len(schedule) < 2:
        return None
    step = round(schedule[1] - schedule[0], 6)
    return {"start": schedule[0], "end": schedule[-1], "step": step}


def build_parameters() -> list[dict[str, Any]]:
    parameters = []
    for element in spec.load_drbfm_analysis():
        name = element.parameter_name
        if not name or name.lower().startswith("reserved"):
            continue
        start_byte, end_byte = _byte_span(element)
        byte_length = spec._field_byte_length(element)
        samples = len(spec.sampling_schedule(element))
        sample_range = _sample_range(element)
        bytes_per_sample = None
        if sample_range and byte_length and samples:
            bytes_per_sample = max(1, byte_length // samples) if byte_length >= samples else None

        parameters.append(
            {
                "name": name,
                "logical_id": element.logical_id or None,
                "drbfm_row": element.source_row,
                "data_start_byte": start_byte,
                "data_end_byte": end_byte,
                "data_byte_length": byte_length,
                "data_samples_number": samples if sample_range else 1,
                "data_bytes_per_sample": bytes_per_sample,
                "scaling_factor": _numeric(element.values.get("Resolution_EDR")) or 1,
                "offset": _numeric(element.values.get("Offset_EDR")) or 0,
                "unit": element.values.get("Units") or None,
                "sample_range": sample_range,
                "recording_model": spec.recording_model(element),
                "not_captured_value": element.values.get("Not captured value") or None,
                "value_description": element.values.get("Value description") or None,
            }
        )
    return parameters


HEADER = '''"""
Module Configuration: EDR - {project} (common {vehicle_class} baseline)
============================================================

Location: projects/{project}/config/edr_config.py

GENERATED FILE - do not edit by hand.
Rebuild with: py -3.14 tools/build_ice01_edr_config.py --project {project}

Source: the common EDR DRBFM analysis sheet "{sheet}", which defines the
0x0455 / 0x045B record layout for every {vehicle_class} variant.

Field meanings
--------------
  data_start_byte / data_end_byte  Byte span of the element inside the record.
  data_samples_number              Samples stored; 1 for a snapshot element.
  sample_range                     start/end/step in seconds relative to T0. None means
                                   the element has no recording interval, so it has no
                                   pre-crash or post-crash variant and is verified by
                                   repeating the case per value instead.
  scaling_factor / offset          EDR storage conversion: physical = raw * factor + offset.
                                   This is the EDR conversion, which is not always the
                                   same as the CAN conversion in canc_config.
  not_captured_value               Value recorded when the element was not captured.

Deconfigured and reserved encoding
----------------------------------
An element that does not apply to this variant records all ones (0xFF per byte) across
its allocation. A reserved bit or byte records 0x00.
"""

PROJECT_NAME = "{project}"
MODULE_NAME = "EDR"
VEHICLE_CLASS = "{vehicle_class}"

# Event record DIDs. Both records share the layout below.
EDR_DIDS = {{
    "EDR_EVENT_1": 0x0455,
    "EDR_EVENT_2": 0x045B,
}}

# Value recorded for an element that is not configured on this variant, per byte.
DECONFIGURED_BYTE_VALUE = 0xFF
# Value recorded for a reserved bit or byte.
RESERVED_BYTE_VALUE = 0x00

'''

FOOTER = '''

EDR_PARAMETERS_BY_NAME = {parameter["name"]: parameter for parameter in EDR_PARAMETERS}

# Elements that record across an interval, so they support pre-crash and post-crash cases.
INTERVAL_PARAMETERS = [p["name"] for p in EDR_PARAMETERS if p["sample_range"] is not None]

# Elements recorded as a single snapshot, verified by repeating the case per value.
SNAPSHOT_PARAMETERS = [p["name"] for p in EDR_PARAMETERS if p["sample_range"] is None]


def get_sample_range(parameter_name: str) -> dict | None:
    """Recording interval for an element, or None when it has no interval."""
    parameter = EDR_PARAMETERS_BY_NAME.get(parameter_name)
    return None if parameter is None else parameter["sample_range"]


def get_sample_interval_ms(parameter_name: str, default_ms: int = 500) -> int:
    """Spacing between recorded samples, in milliseconds."""
    sample_range = get_sample_range(parameter_name)
    if not sample_range:
        return default_ms
    return int(round(float(sample_range["step"]) * 1000))
'''


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", default="ICE_01", choices=sorted(PROJECTS))
    arguments = parser.parse_args()
    output = REPOSITORY_ROOT / "projects" / arguments.project / "config" / "edr_config.py"
    parameters = build_parameters()
    body = (
        HEADER.format(
            sheet=spec.DRBFM_ANALYSIS_SHEET,
            project=arguments.project,
            vehicle_class=PROJECTS[arguments.project],
        )
        + "EDR_PARAMETERS = "
        + pprint.pformat(parameters, width=112, sort_dicts=False)
        + FOOTER
    )
    output.write_text(body, encoding="utf-8")
    interval = sum(1 for p in parameters if p["sample_range"])
    print(f"Wrote {output}")
    print(f"  parameters : {len(parameters)} ({interval} interval, {len(parameters) - interval} snapshot)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
