"""Generate the common EDR CAN-C test scripts and their runner, per baseline project.

One script per case in the common EDR CAN-C specification, written in the same shape as
the proven U171 EDR scripts: the shared-library import block, then `def run_test():`
with the whole procedure inside it and nothing at module level. Everything a script
needs is read from `canc_config` and `edr_config` at run time, so there is no separate
case config to keep in step.

Two projects are supported:

    ICE_01  the common ICE baseline, driven by the U171 routes of the specification.
    EV_01   the common EV baseline, driven by the M314 routes.

ICE_01 additionally gets the two whole-record checks: reserved bytes must record 0x00,
and CAN allocations that do not apply to the variant must record 0xFF.

Edit this generator, never the generated scripts.

Offline only: writes Python files. Running a generated script drives a bench.

Usage:
    py -3.14 tools/generate_ice01_edr_canc_scripts.py --project ICE_01 --clean
    py -3.14 tools/generate_ice01_edr_canc_scripts.py --project EV_01 --clean
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "tests"))
sys.path.insert(0, str(REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "scripts"))

PROJECTS = {
    "ICE_01": {"vehicle_class": "ICE", "spec_variant": "U171", "runner": "run_all_ice_common_scripts.py"},
    "EV_01": {"vehicle_class": "EV", "spec_variant": "M314", "runner": "run_all_ev_common_scripts.py"},
}

NEWLINE = chr(10)
BYTE_RANGE = re.compile(r"(\d+)\s*[-to]+\s*(\d+)")
SINGLE_BYTE = re.compile(r"^\s*(\d+)\s*$")

PREAMBLE = '''# Author: Christy, Krishna
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_ice01_edr_canc_scripts.py --project {project}

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- MAGIC IMPORT: gives access to everything in shared_libraries instantly ---
from Framework_IOEM_Py.shared_libraries.import_list import *

# -- ARIA bring-up -----------------------------------------------------------
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# -- Config imports (project-specific) ---------------------------------------
from Framework_IOEM_Py.projects.{project}.config.edr_config import *
from Framework_IOEM_Py.projects.{project}.config.cannm_config import qualification_ms
from Framework_IOEM_Py.projects.{project}.config.canc_config import *


def run_test():
'''

FAULT_SETUP: dict[str, dict[str, Any]] = {
    "node_absent": {
        "create": [
            'RESULT.InsertComment(f"Disabling node key frame {key_frame} to create Node Absent.")',
            "CAN.PeriodicDisableFrame(key_frame)",
        ],
        "heal": ["CAN.ReloadDefaultPeriodicFrame(key_frame)"],
        "event": "node_absent",
        "target": "key_frame",
        "behaviour": "latch",
    },
    "message_timeout": {
        "create": [
            'RESULT.InsertComment(f"Disabling signal-carrying frame {timeout_frame} to create Message Timeout.")',
            "CAN.PeriodicDisableFrame(timeout_frame)",
        ],
        "heal": ["CAN.ReloadDefaultPeriodicFrame(timeout_frame)"],
        "event": "message_timeout",
        "target": "timeout_frame",
        "behaviour": "latch",
    },
    "message_content": {
        "create": [
            'RESULT.InsertComment(f"Disabling CRC / alive counter {integrity_signal} on {msg} to create Message Content Failure.")',
            "CAN.DynamicDisableSignal(msg, integrity_signal)",
        ],
        "heal": ["CAN.DynamicEnableSignal(msg, integrity_signal)"],
        "event": "message_content_failure",
        "target": "msg",
        "behaviour": "latch",
    },
    "signal_content": {
        "create": [
            'RESULT.InsertComment(f"Sending DBC invalid code {invalid_raw} on {sig} to create Signal Content Failure.")',
            "CAN.ChangeSignalValue(msg, sig, str(invalid_raw))",
        ],
        "heal": [],
        "event": "signal_invalid",
        "target": "sig",
        "behaviour": "consume",
    },
    "signal_never_received": {
        "create": [
            'RESULT.InsertComment(f"Clearing node bit for {key_frame} in the variant code to create Signal Never Received.")',
            'manage_variant_code(key_frame, "disable", project=PROJECT_NAME, base_from_project_default=True)',
            "PS.Power_Cycle()",
            "Sleep(1)",
        ],
        "heal": ['manage_variant_code(key_frame, "enable", project=PROJECT_NAME, base_from_project_default=True)'],
        "event": None,
        "target": "key_frame",
        "behaviour": "default",
    },
    "variant_code_error": {
        "create": [
            'RESULT.InsertComment("Disabling the Variant Code, then one ignition cycle to qualify Variant Code Error.")',
            'manage_variant_code(key_frame, "disable", project=PROJECT_NAME, base_from_project_default=True)',
            "PS.Power_Cycle()",
            "Sleep(1)",
        ],
        "heal": ['manage_variant_code(key_frame, "enable", project=PROJECT_NAME, base_from_project_default=True)'],
        "event": None,
        "target": "key_frame",
        "behaviour": "default",
    },
}


def _indent(lines: list[str], spaces: int) -> str:
    pad = " " * spaces
    return "".join(f"{pad}{line}{NEWLINE}" if line else NEWLINE for line in lines)


def _finish(body: list[str], project: str) -> str:
    """Wrap a rendered body in the preamble and entry point, with no trailing spaces."""
    tail = NEWLINE + NEWLINE + 'if __name__ == "__main__":' + NEWLINE + "    run_test()" + NEWLINE
    script = PREAMBLE.format(project=project) + _indent(body, 4) + tail
    return "".join(line.rstrip() + NEWLINE for line in script.splitlines())


def _byte_span(element: Any) -> tuple[int | None, int | None]:
    text = str(element.values.get("Byte position") or "")
    match = BYTE_RANGE.search(text)
    if match:
        return int(match.group(1)), int(match.group(2))
    single = SINGLE_BYTE.match(text)
    if single:
        return int(single.group(1)), int(single.group(1))
    return None, None


def _render(case: dict[str, Any], group: int, sequence: int, project: str) -> str:
    fault_mode = case["fault_mode"]
    scope = case["timing_scope"]
    setup = FAULT_SETUP.get(fault_mode or "", {})
    behaviour = setup.get("behaviour", "none")
    body: list[str] = []

    body.append(f'tc_id = "{group}.{sequence}"')
    body.append("tc_desc = (")
    body.append(f"    {case['description']!r}")
    body.append(")")
    body.append("")
    body.append(f"signal_def = MAH_CAN_SIGNAL_DEFS[{case['signal']!r}]")
    body.append('msg = signal_def["frame"]')
    body.append('sig = signal_def["signal"]')
    body.append('periodicity = signal_def["periodicity"]')
    body.append(f"values = signal_def.get('TestCase_{group}_values') or []")
    body.append('edr_param = signal_def["EDR_Parameter"]')
    body.append('edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)')
    body.append("sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)")
    body.append('factor = signal_def.get("Factor", 1)')
    body.append('offset = signal_def.get("Offset", 0)')
    body.append("if not isinstance(values, list):")
    body.append("    values = [values]")
    body.append("")
    body.append('fault_logic = signal_def["fault_logic"]')
    body.append('key_frame = fault_logic["key_message"]')
    body.append('timeout_frame = fault_logic.get("non_key_timeout_frame")')

    if fault_mode == "message_content":
        body.append("integrity_signal = choose_message_content_failure_signal(msg)")
    if fault_mode == "signal_content":
        body.append(f"invalid_raw = (signal_def.get('TestCase_{group}_Invalid_Values') or [0])[0]")

    if setup.get("event") == "signal_invalid":
        body.append("can_dtc_code = resolve_dtc_for_event('signal_invalid', msg, sig)")
    elif setup.get("event") == "message_content_failure":
        body.append("can_dtc_code = get_message_content_failure_dtcs(msg).get(integrity_signal)")
    elif setup.get("event"):
        body.append(f"can_dtc_code = resolve_dtc_for_event({setup['event']!r}, {setup['target']})")
    else:
        body.append("can_dtc_code = None")
    body.append('combined_can_dtc = (can_dtc_code + " " + DTC_status["DTC_active"]) if can_dtc_code else ""')

    if fault_mode:
        body.append("")
        body.append("# Qualification time is a count of message periods, not a fixed value.")
        body.append(f"qualification = qualification_ms({fault_mode!r}, periodicity)")
    body.append("")
    body.append("test_case_file = os.path.splitext(os.path.basename(__file__))[0]")
    body.append("can_ids = resolve_can_log_ids([signal_def])")
    body.append("report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)")
    body.append("")
    body.append("fault_free_profile_classic_can()")

    if case.get("can_wakeup"):
        body.append("")
        body.append("# CAN wakeup: hardware ignition stays OFF and the ECU is woken over CAN.")
        body.append("PS.IGN_OFF()")
        body.append("Sleep(1)")

    startup_fault = fault_mode in {"signal_never_received", "variant_code_error"}
    if startup_fault:
        body.append("")
        body.extend(setup["create"])
    else:
        body.append("PS.Power_Cycle()")
        body.append("Sleep(1)")

    body.append("read_software_version()")
    body.append('crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"')
    body.append("")
    body.append("for x in range(2):")
    body.append('    did = f"{0x455 + (x * 0x6):04X}"')
    body.append("    load_crash_curves(crash_type)")
    body.append("")
    body.append("    time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)")
    body.append("    t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)")
    body.append("    trigger_idx = t0_sample_idx - 1")
    body.append("    sample_interval_s = sample_interval_ms / 1000.0")
    body.append("    simulation_time_axis = [t - sample_interval_s for t in time_axis]")
    body.append("")

    if fault_mode and not startup_fault:
        if scope == "pre":
            body.append("    # Pre-crash only: fault starts at the first sample and is healed at T0.")
            body.append("    fault_start_idx = 0")
            body.append("    fault_end_idx = t0_sample_idx")
        elif scope == "post":
            body.append("    # Post-crash only: pre-crash samples stay valid, fault starts at T0.")
            body.append("    fault_start_idx = t0_sample_idx")
            body.append("    fault_end_idx = None")
        else:
            body.append("    # Full interval: the fault is active for every sample.")
            body.append("    fault_start_idx = 0")
            body.append("    fault_end_idx = None")
        body.append("    latched_raw = values[fault_start_idx - 1] if fault_start_idx > 0 else (values[0] if values else 0)")
        body.append("")

    body.append('    print(f"EDR parameter: {edr_param}")')
    body.append('    print(f"Recording time axis: {time_axis}")')
    body.append('    print(f"Simulation time axis: {simulation_time_axis}")')
    body.append('    print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")')
    body.append('    print(f"T0 sample index: {t0_sample_idx}, crash trigger index: {trigger_idx}")')
    body.append('    print(f"Total values to simulate: {len(values)}")')
    body.append("")
    body.append(f'    aria_reports.add_group(f"{{test_case_file}} - DID {{did}} - {case["category"]}")')

    if fault_mode and not startup_fault:
        body.append("    fault_active = False")
    body.append("")
    body.append("    for idx, val in enumerate(values):")
    body.append("        simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)")
    body.append("        recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)")
    body.append("")

    if fault_mode and not startup_fault:
        body.append("        # Create the fault at the first sample it applies to.")
        body.append("        if not fault_active and idx == fault_start_idx:")
        body.extend(f"            {line}" for line in setup["create"])
        body.append("            fault_active = True")
        body.append("")

    body.append("        CAN.ChangeSignalValue(msg, sig, str(val))")
    body.append("        Wait(sample_interval_ms)")
    body.append("        received_val = CAN.GetSignalFromFrame(msg, sig)")
    body.append("        try:")
    body.append('            received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)')
    body.append("        except Exception:")
    body.append("            received_val_int = int(received_val)")
    body.append("")
    body.append("        RESULT.InterpretEqualResult(")
    body.append('            f"Check {sig} set to {val} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)",')
    body.append("            str(received_val_int),")
    body.append("            str(val))")
    body.append("")
    body.append("        expected_phys = (val * factor) + offset")
    body.append("        received_phys = (received_val_int * factor) + offset")
    body.append("        RESULT.InterpretEqualResult(")
    body.append('            f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s)",')
    body.append("            str(received_phys),")
    body.append("            str(expected_phys))")
    body.append("")

    if fault_mode and not startup_fault and scope == "pre":
        body.append("        # Heal at T0 so post-crash samples record the recovered values.")
        body.append("        if fault_active and fault_end_idx is not None and idx == fault_end_idx:")
        body.extend(f"            {line}" for line in setup["heal"])
        body.append("            fault_active = False")
        body.append("            Sleep(1)")
        body.append("")

    body.append("        if idx == trigger_idx:")
    body.append("            TriggerCrash()")
    body.append("            continue")
    body.append("")
    body.append("    # The interval is complete; hold the fault for its qualification time.")
    if fault_mode:
        body.append("    if qualification:")
        body.append("        Wait(qualification)")
    body.append("    Sleep(1)")
    body.append('    combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]')
    body.append('    final_combined_dtc = combined_crash_dtc + ((" " + combined_can_dtc) if combined_can_dtc else "")')
    body.append('    Read_DTC("Front Crash", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)')
    body.append("    aria_reports.close_group()")
    body.append("")
    body.append("    Sleep(5)")
    body.append("    edr_read = read_edr_parameters([edr_param], did=did, crash_type=crash_type, return_data=True)")
    body.append("    Sleep(2)")
    body.append("")
    body.append("    decoded_samples = []")
    body.append("    if isinstance(edr_read, dict):")
    body.append('        decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []')
    body.append("")
    body.append('    scaling = edr_def.get("scaling_factor", 1) if edr_def else 1')
    body.append('    offset_edr = edr_def.get("offset", 0) if edr_def else 0')
    body.append("")
    body.append(f'    aria_reports.add_group("EDR Output Verification - {case["category"]}")')
    body.append("    for i in range(len(values)):")
    body.append("        if i >= len(decoded_samples):")
    body.append('            RESULT.LogCustomAction(f"{edr_param} Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)')
    body.append("            continue")
    body.append("        observed = decoded_samples[i]")
    body.append("        recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)")
    body.append("")

    if not fault_mode:
        body.append("        expected_edr_phys = values[i] * scaling + offset_edr")
        body.append('        description = "simulated valid value"')
    elif behaviour == "latch":
        body.append("        in_fault = i >= fault_start_idx and (fault_end_idx is None or i < fault_end_idx)")
        body.append("        if in_fault:")
        body.append("            expected_edr_phys = latched_raw * scaling + offset_edr")
        body.append('            description = "last valid value retained while the fault is active"')
        body.append("        else:")
        body.append("            expected_edr_phys = values[i] * scaling + offset_edr")
        body.append('            description = "simulated valid value"')
    elif behaviour == "consume":
        body.append("        expected_edr_phys = invalid_raw * scaling + offset_edr")
        body.append('        description = "invalid code consumed as received"')
    else:
        body.append('        default_raw = signal_def.get("Default_Value", 0)')
        body.append("        expected_edr_phys = default_raw * scaling + offset_edr")
        body.append('        description = "default value recorded"')

    body.append("")
    body.append("        RESULT.InterpretEqualResult(")
    body.append('            f"{edr_param} recorded at {recording_time:g}s in DID {did} - {description}",')
    body.append("            str(observed),")
    body.append("            str(expected_edr_phys)")
    body.append("        )")
    body.append("    aria_reports.close_group()")
    body.append("")
    body.append('CAN.ChangeSignalValue(msg, sig, "0")')
    if fault_mode:
        body.extend(setup["heal"])
    body.append("CAN.ReloadDefaultPeriodicFrame(msg)")
    body.append("fault_free_profile_classic_can()")
    body.append("aria_reports.write_to_file()")
    body.append("aria_reports.close_group()")

    return _finish(body, project)


def _render_aggregate(kind: str, project: str, allocations: list[dict[str, Any]]) -> str:
    """Render one of the two whole-record checks.

    reserved        every DRBFM reserved bit and byte must record 0x00.
    not_configured  every allocation whose CAN parameter does not apply to this variant
                    must record all ones, 0xFF per byte.

    Neither drives a functional CAN stimulus: the point is what the record holds for
    allocations that were never fed, so the bench stays fault free throughout.
    """
    if kind == "reserved":
        title = "Reserved bytes and bits record 0x00"
        expected_name = "RESERVED_BYTE_VALUE"
        description = "Verify every DRBFM reserved byte and bit records 0x00 in both EDR records."
    else:
        title = "Not-configured CAN allocations record 0xFF"
        expected_name = "DECONFIGURED_BYTE_VALUE"
        description = (
            "Verify every DRBFM CAN allocation that is not applicable to this variant "
            "records all ones (0xFF per byte) in both EDR records."
        )

    body: list[str] = []
    body.append(f"tc_desc = {description!r}")
    body.append("")
    if kind == "reserved":
        body.append("# Reserved fields are bit ranges inside a byte owned by the element above them")
        body.append("# in the DRBFM sheet: (name, byte, high bit, low bit, DRBFM row).")
        body.append("ALLOCATIONS = [")
        for entry in allocations:
            body.append(
                f"    ({entry['name']!r}, {entry['byte']!r}, {entry['high_bit']!r}, "
                f"{entry['low_bit']!r}, {entry['drbfm_row']!r}),"
            )
        body.append("]")
    else:
        body.append("# Byte allocations from the DRBFM record layout:")
        body.append("# (name, start byte, byte length, DRBFM row).")
        body.append("ALLOCATIONS = [")
        for entry in allocations:
            body.append(
                f"    ({entry['name']!r}, {entry['start_byte']!r}, "
                f"{entry['byte_length']!r}, {entry['drbfm_row']!r}),"
            )
        body.append("]")
    body.append("")
    body.append(f"expected_byte = {expected_name}")
    body.append("test_case_file = os.path.splitext(os.path.basename(__file__))[0]")
    body.append("create_report_and_logging(test_case_file, direct_write=False, tc_desc=tc_desc)")
    body.append("")
    body.append("# No CAN stimulus: the record is checked for allocations that are never fed.")
    body.append("fault_free_profile_classic_can()")
    body.append("PS.Power_Cycle()")
    body.append("Sleep(1)")
    body.append("read_software_version()")
    body.append('crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"')
    body.append("")
    body.append("load_crash_curves(crash_type)")
    body.append("TriggerCrash()")
    body.append("Sleep(1)")
    body.append('combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]')
    body.append('Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc, Read_DTC_Req)')
    body.append("")
    body.append("Sleep(5)")
    body.append("for did_value in (0x0455, 0x045B):")
    body.append('    did = f"{did_value:04X}"')
    body.append(f'    aria_reports.add_group(f"{title} - DID {{did}}")')
    body.append("    record = read_edr_record(did=did, crash_type=crash_type, return_data=True)")
    body.append('    payload = record.get("raw", record) if isinstance(record, dict) else record')
    body.append("")

    if kind == "reserved":
        body.append("    for name, byte_index, high_bit, low_bit, drbfm_row in ALLOCATIONS:")
        body.append("        if byte_index is None or high_bit is None or low_bit is None:")
        body.append("            RESULT.LogCustomAction(")
        body.append('                name,')
        body.append('                f"DRBFM row {drbfm_row} gives no byte/bit position",')
        body.append('                "Byte and bit position required",')
        body.append("                TestStatus.Failed,")
        body.append("            )")
        body.append("            continue")
        body.append("        # Mask just this field out of its owning byte; the rest of the byte")
        body.append("        # belongs to another element and is not checked here.")
        body.append("        width = high_bit - low_bit + 1")
        body.append("        mask = ((1 << width) - 1) << low_bit")
        body.append("        observed = (payload[byte_index] & mask) >> low_bit")
        body.append("        RESULT.InterpretEqualResult(")
        body.append('            f"{name}: byte {byte_index} bits {high_bit}..{low_bit} in DID {did} (DRBFM row {drbfm_row})",')
        body.append('            f"0x{observed:02X}",')
        body.append('            f"0x{expected_byte:02X}",')
        body.append("        )")
    else:
        body.append("    for name, start_byte, byte_length, drbfm_row in ALLOCATIONS:")
        body.append("        if start_byte is None or not byte_length:")
        body.append("            RESULT.LogCustomAction(")
        body.append('                name,')
        body.append('                f"DRBFM row {drbfm_row} gives no byte allocation",')
        body.append('                "Byte allocation required",')
        body.append("                TestStatus.Failed,")
        body.append("            )")
        body.append("            continue")
        body.append("        observed = list(payload[start_byte:start_byte + byte_length])")
        body.append("        expected = [expected_byte] * byte_length")
        body.append("        RESULT.InterpretEqualResult(")
        body.append('            f"{name}: bytes {start_byte}..{start_byte + byte_length - 1} in DID {did} (DRBFM row {drbfm_row})",')
        body.append('            " ".join(f"{value:02X}" for value in observed),')
        body.append('            " ".join(f"{value:02X}" for value in expected),')
        body.append("        )")

    body.append("    aria_reports.close_group()")
    body.append("")
    body.append("aria_reports.write_to_file()")

    return _finish(body, project)


RUNNER_HEAD = '''"""Run the {project} common EDR CAN-C scripts.

GENERATED FILE - regenerate with:
    py -3.14 tools/generate_ice01_edr_canc_scripts.py --project {project}

Every generated script is listed in SCRIPT_FILES. Comment a line out with # to skip
that script. Filters let you run a subset without editing the list:

    py {runner}                       # everything uncommented
    py {runner} --only VehSpdLgt      # name contains VehSpdLgt
    py {runner} --fault node_absent   # one fault family
    py {runner} --nominal             # nominal cases only
    py {runner} --list                # show what would run

Results are written to {results}.

These scripts drive a bench. Run them only against a rig you are authorized to use.
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
RESULTS_FILE = SCRIPT_DIR / "{results}"

# Comment out a line to skip that script.
SCRIPT_FILES = [
{script_list}]

# Fault family per script, used by --fault and --nominal.
SCRIPT_FAULTS = {fault_map}
'''

RUNNER_BODY = '''

def select_scripts(arguments):
    selected, missing = [], []
    for name in SCRIPT_FILES:
        if arguments.only and arguments.only.lower() not in name.lower():
            continue
        fault = SCRIPT_FAULTS.get(name)
        if arguments.fault and fault != arguments.fault:
            continue
        if arguments.nominal and fault is not None:
            continue
        path = SCRIPT_DIR / name
        if path.is_file():
            selected.append(path)
        else:
            missing.append(name)
    if missing:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for name in missing:
            print("- " + name)
        print()
    return selected


def build_environment():
    env = os.environ.copy()
    import_root = SCRIPT_DIR.parents[4].parent
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(import_root) + (os.pathsep + existing if existing else "")
    return env


def run_script(path, env):
    print("=" * 100)
    print("Running: " + path.name)
    print("=" * 100)
    completed = subprocess.run(
        [sys.executable, str(path)],
        cwd=str(SCRIPT_DIR),
        env=env,
        capture_output=True,
        text=True,
    )
    if completed.stdout:
        print(completed.stdout, end="")
    if completed.stderr:
        print(completed.stderr, end="", file=sys.stderr)
    status = "PASSED" if completed.returncode == 0 else "FAILED"
    print(status + ": " + path.name + " (exit code " + str(completed.returncode) + ")")
    return completed.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="run scripts whose name contains this text")
    parser.add_argument("--fault", help="run one fault family, for example node_absent")
    parser.add_argument("--nominal", action="store_true", help="run nominal cases only")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()

    scripts = select_scripts(arguments)
    if arguments.list:
        for path in scripts:
            print(path.name + "  [" + str(SCRIPT_FAULTS.get(path.name) or "nominal") + "]")
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    env = build_environment()
    results = {}
    for path in scripts:
        results[path.name] = run_script(path, env)
    failed = [name for name, code in results.items() if code != 0]
    RESULTS_FILE.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print("=" * 100)
    print("Ran " + str(len(results)) + " script(s): " + str(len(results) - len(failed)) + " passed, " + str(len(failed)) + " failed")
    for name in failed:
        print("  FAILED: " + name)
    print("Results written to " + RESULTS_FILE.name)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
'''


BIT_RANGE = re.compile(r"bit\s*(\d+)\s*[-:to]+\s*(\d+)", re.IGNORECASE)
SINGLE_BIT = re.compile(r"bit\s*(\d+)", re.IGNORECASE)


def _bit_span(element: Any) -> tuple[int | None, int | None]:
    """High and low bit of a reserved field inside its owning byte."""
    text = str(element.values.get("Bit position") or "")
    match = BIT_RANGE.search(text)
    if match:
        first, second = int(match.group(1)), int(match.group(2))
        return max(first, second), min(first, second)
    single = SINGLE_BIT.search(text)
    if single:
        return int(single.group(1)), int(single.group(1))
    return None, None


def _aggregate_allocations(spec: Any, matrix: list[dict[str, Any]], kind: str, spec_variant: str) -> list[dict[str, Any]]:
    """Allocations covered by the reserved-0x00 and not-configured-0xFF checks.

    Reserved fields are bit ranges that sit inside a byte owned by the element above
    them in the DRBFM sheet, so they carry no byte position of their own. Walking the
    rows in order lets each reserved row inherit the byte span it belongs to.
    """
    state_key = "u171_state" if spec_variant == "U171" else "m314_state"
    absent = {"No verified CAN route", "Configured route absent from selected DBC"}
    entries = []
    owning_start: int | None = None
    owning_end: int | None = None

    for row in matrix:
        element = row["element"]
        start_byte, end_byte = _byte_span(element)
        if start_byte is not None:
            owning_start, owning_end = start_byte, end_byte

        if kind == "reserved":
            if row["classification"] != "Reserved":
                continue
            high_bit, low_bit = _bit_span(element)
            entries.append(
                {
                    "name": row["parameter_name"],
                    "byte": start_byte if start_byte is not None else owning_end or owning_start,
                    "high_bit": high_bit,
                    "low_bit": low_bit,
                    "drbfm_row": row["source_row"],
                }
            )
            continue

        if row["classification"] not in {"External CAN", "ECU-generated CAN"}:
            continue
        if row[state_key] not in absent:
            continue
        entries.append(
            {
                "name": row["parameter_name"],
                "start_byte": start_byte,
                "byte_length": spec._field_byte_length(element),
                "drbfm_row": row["source_row"],
            }
        )
    return entries


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", default="ICE_01", choices=sorted(PROJECTS))
    parser.add_argument("--include-on-hold", action="store_true")
    parser.add_argument("--clean", action="store_true")
    arguments = parser.parse_args()

    import test_common_edr_canc_specification as spec

    settings = PROJECTS[arguments.project]
    spec_variant = settings["spec_variant"]
    runner_name = settings["runner"]
    results_name = runner_name.replace("run_all_", "").replace(".py", "_results.json")
    output_directory = REPOSITORY_ROOT / "projects" / arguments.project / "modules" / "EDR_CANC" / "scripts"

    contexts = {name: spec.load_variant_context(name) for name in ("U171", "M314")}
    matrix = spec.build_route_matrix(spec.load_drbfm_analysis(), contexts)

    output_directory.mkdir(parents=True, exist_ok=True)
    if arguments.clean:
        for existing in output_directory.glob("SUBS_EDR_*.py"):
            existing.unlink()

    written: list[tuple[str, str | None]] = []
    skipped = 0
    for plan in spec.build_case_plans(matrix):
        if plan.name.startswith("SUBS_EDR_ICE_"):
            continue  # the two whole-record checks are rendered separately below
        if not arguments.include_on_hold and plan.status != "IN REVIEW":
            continue
        route = plan.route_by_variant.get(spec_variant)
        if route is None or route.get("dbc") is None:
            skipped += 1
            continue
        group_text, sequence_text = plan.name.rsplit("_TestCase_", 1)[-1].split("_")
        case = {
            "signal": route["dbc"]["signal"],
            "description": plan.description,
            "category": plan.category,
            "fault_mode": plan.fault_mode,
            "timing_scope": plan.timing_scope,
            "can_wakeup": plan.can_wakeup,
        }
        (output_directory / f"{plan.name}.py").write_text(
            _render(case, int(group_text), int(sequence_text), arguments.project), encoding="utf-8"
        )
        written.append((f"{plan.name}.py", plan.fault_mode))

    # The two whole-record checks belong to the ICE baseline: the not-configured set is
    # exactly what the ICE variant does not carry.
    if arguments.project == "ICE_01":
        for kind, name in (
            ("reserved", "SUBS_EDR_ICE_RESERVED_BYTES_RECORD_00_TestCase_9001_1"),
            ("not_configured", "SUBS_EDR_ICE_NOT_CONFIGURED_RECORDS_FF_TestCase_9000_1"),
        ):
            allocations = _aggregate_allocations(spec, matrix, kind, spec_variant)
            (output_directory / f"{name}.py").write_text(
                _render_aggregate(kind, arguments.project, allocations), encoding="utf-8"
            )
            written.append((f"{name}.py", None))
            print(f"  {kind}: {len(allocations)} allocation(s)")

    script_list = "".join('    "' + name + '",' + NEWLINE for name, _ in written)
    fault_map = "{" + NEWLINE + "".join(
        '    "' + name + '": ' + repr(fault) + "," + NEWLINE for name, fault in written
    ) + "}"
    runner_text = RUNNER_HEAD.format(
        project=arguments.project,
        runner=runner_name,
        results=results_name,
        script_list=script_list,
        fault_map=fault_map,
    ) + RUNNER_BODY
    (output_directory / runner_name).write_text(runner_text, encoding="utf-8")

    init_file = output_directory / "__init__.py"
    if not init_file.exists():
        init_file.write_text("", encoding="utf-8")

    print(f"Wrote {len(written)} scripts to {output_directory}")
    print(f"  runner : {runner_name}")
    if skipped:
        print(f"  skipped {skipped} case(s) with no {settings['vehicle_class']} CAN route")
    return 0


if __name__ == "__main__":
    sys.exit(main())
