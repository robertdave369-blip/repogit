# Tool Logbook

Use one Markdown file per month, named `YYYY-MM.md`. Append an entry whenever a
tool is added, changed, run to create a retained artifact, validated, or used to
archive or remove material.

```markdown
## YYYY-MM-DD - Short activity title

- What and why: <tool activity and purpose>
- Paths: <repository-relative inputs and outputs>
- Command: <command without credentials or sensitive arguments>
- Outcome: <summary and validation result>
- Retention: <keep/archive/delete rationale and review date if applicable>
```

Never record credentials, tokens, sensitive customer data, or bench commands
that could actuate hardware.