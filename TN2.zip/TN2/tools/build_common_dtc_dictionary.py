"""Build docs/project_documents/Common_DTC_List/common_dtc_dictionary.py from the EV and ICE DTC lists.

Author: Kris

Sources (the single 'DTC List' sheet of each workbook, every row, columns found by header name):
    docs/project_documents/Common_DTC_List/EV_DTC_LIST/EV_DTC.xlsx
    docs/project_documents/Common_DTC_List/ICE_DTC_LIST/ICE_DTC.xlsx

The two lists are merged on the DTC (DTC + FTB columns, e.g. B000111). Each entry says what the DTC is,
whether it applies to EV, ICE or both, and how to create it: the workbook's pre-condition, set and heal
conditions and mature / demature times, plus the bench method of the agent_sc3.md section 25.5
fault-creation catalog with the framework functions that implement it. Where the workbook contradicts
itself (hex column, set condition of another fault type, ...) the entry lists it under workbook_issues
instead of correcting it, and DTC_LIST_CONFLICTS.md (same folder) lists all of them for review.
common_fault_list.py (same folder) holds the same DTCs in fault-list form: one dict per DTC, named by
its mnemonic.

    py -3.14 tools/build_common_dtc_dictionary.py          # write the dictionary, fault list, conflicts
    py -3.14 tools/build_common_dtc_dictionary.py --check  # rebuild in memory and compare
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import Counter
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
DTC_DIR = ROOT / "docs" / "project_documents" / "Common_DTC_List"
WORKBOOKS = {
    "EV": DTC_DIR / "EV_DTC_LIST" / "EV_DTC.xlsx",
    "ICE": DTC_DIR / "ICE_DTC_LIST" / "ICE_DTC.xlsx",
}
OUTPUT = DTC_DIR / "common_dtc_dictionary.py"
CONFLICTS = DTC_DIR / "DTC_LIST_CONFLICTS.md"
FAULT_LIST = DTC_DIR / "common_fault_list.py"
CATALOG = "agent_sc3.md §25.5"

# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

# Row-1 header (whitespace collapsed, lower case) -> field. Both workbooks carry all of them.
HEADERS = {
    "s.no": "s_no",
    "dtc": "dtc",
    "ftb": "ftb",
    "dtc (hex)": "hex_cell",
    "description": "description",
    "pre-condition": "precondition",
    "set - conditions": "set_condition",
    "heal - conditions": "heal_condition",
    "dtc 'priority'": "priority",
    "repair action/demature requires ign toggle": "ign_toggle",
    "ageing": "ageing",
    "warning lamp status active status": "warning_lamp",
    "error reaction": "error_reaction",
    "ram / eeprom / other": "memory",
    "mature time": "mature_time",
    "demature time": "demature_time",
    "mature/demature time tolerance": "tolerance",
    "m&m": "mm_remark",
    "supplier": "supplier_remark",
    "status": "status",
}
EV_VARIANTS_HEADER = "m312/m112/w613/m314"   # EV list only: Yes/No applicability to the EV variants

# Columns the dictionary does not carry; the build stops if one of them ever holds a real value.
UNUSED_FIELDS = {"priority": {None, "NA"}, "mm_remark": {None}, "status": {None}}

CHARACTERS = {"\xa0": " ", "‑": "-", "–": "-", "—": "-", "‘": "'", "’": "'",
              "“": '"', "”": '"', "_x000a_": "\n"}


def clean(value, title: bool = False):
    """Workbook cell -> value with presentation artefacts removed: runs of blanks, empty lines,
    wrapping quotes and bullet dashes. Lines are joined with '; ' (with ' ' after a full stop or colon,
    and always for a title wrapped over two lines). Engineering text (values, typos included) is kept
    as written."""
    if value is None:
        return None
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    if not isinstance(value, str):
        return value
    for old, new in CHARACTERS.items():
        value = value.replace(old, new)
    lines = []
    for line in value.splitlines():
        line = " ".join(line.split())
        if line.startswith('"'):
            line = line[1:].lstrip()
        if line.endswith('"') and line.count('"') % 2:
            line = line[:-1].rstrip()
        if line == "-" or line.startswith("- "):
            line = line[1:].lstrip()
        if line:
            lines.append(line)
    text = ""
    for line in lines:
        text = line if not text else text + (" " if title or text[-1] in ".:;," else "; ") + line
    return text or None


def read_workbook(variant: str) -> tuple[list[dict], dict]:
    path = WORKBOOKS[variant]
    if not path.is_file():
        raise SystemExit(f"{variant} DTC list not found: {path}")
    workbook = openpyxl.load_workbook(path, data_only=True)
    if len(workbook.worksheets) != 1 or "dtc list" not in workbook.worksheets[0].title.lower():
        raise SystemExit(f"{path.name}: expected one 'DTC List' sheet, found {workbook.sheetnames}")
    sheet = workbook.worksheets[0]
    header = {}
    for col in range(1, sheet.max_column + 1):
        if sheet.cell(1, col).value is not None:
            header[" ".join(str(sheet.cell(1, col).value).split()).lower()] = col
    columns = {}
    for name, field in HEADERS.items():
        if name not in header:
            raise SystemExit(f"{path.name}: column '{name}' not found in row 1 of sheet '{sheet.title}'")
        columns[field] = header[name]
    # The full DTC (e.g. B000111) sits in the unnamed column right after DTC (HEX).
    if sheet.cell(1, columns["hex_cell"] + 1).value is not None:
        raise SystemExit(f"{path.name}: expected the unnamed full-DTC column after 'DTC (HEX)'")
    columns["code_cell"] = columns["hex_cell"] + 1
    if variant == "EV":
        if EV_VARIANTS_HEADER not in header:
            raise SystemExit(f"{path.name}: column '{EV_VARIANTS_HEADER}' not found in row 1")
        columns["ev_variants"] = header[EV_VARIANTS_HEADER]
    unnamed = [col for col in range(1, sheet.max_column + 1) if col not in columns.values()]

    rows, skipped = [], []
    for row in range(2, sheet.max_row + 1):
        stray = [sheet.cell(row, col).coordinate for col in unnamed if clean(sheet.cell(row, col).value)]
        if stray:
            raise SystemExit(f"{path.name}: values in columns the build does not read: {stray}")
        values = {field: clean(sheet.cell(row, col).value, title=field == "description")
                  for field, col in columns.items()}
        for field in ("ign_toggle", "ev_variants"):
            if str(values.get(field)).upper() in ("YES", "NO"):
                values[field] = str(values[field]).capitalize()
        tolerance = sheet.cell(row, columns["tolerance"])
        if isinstance(tolerance.value, (int, float)) and tolerance.number_format.endswith("%"):
            values["tolerance"] = f"{tolerance.value * 100:g}%"
        if not values["dtc"]:
            if any(values[field] for field in values if field != "s_no"):
                raise SystemExit(f"{path.name} row {row}: data without a DTC")
            skipped.append(f"row {row} (S.No {values['s_no']}): no DTC")
            continue
        for field, allowed in UNUSED_FIELDS.items():
            if values[field] not in allowed:
                raise SystemExit(f"{path.name} row {row}: '{field}' = {values[field]!r}; the dictionary "
                                 f"does not carry this column yet - extend the build")
        values["row"] = row
        rows.append(values)

    hidden = sum(1 for dim in sheet.row_dimensions.values() if dim.hidden)
    info = {"path": path.relative_to(ROOT).as_posix(), "sheet": sheet.title, "rows": len(rows),
            "skipped": skipped, "filter": sheet.auto_filter.ref, "hidden_rows": hidden}
    return rows, info


# ---------------------------------------------------------------------------
# DTC code
# ---------------------------------------------------------------------------

def dtc_key(row: dict, path: str) -> str:
    key = str(row["dtc"]).strip().upper() + str(row["ftb"]).strip().upper().zfill(2)
    if not re.fullmatch(r"[PCBU][0-3][0-9A-F]{3}[0-9A-F]{2}", key):
        raise SystemExit(f"{path} row {row['row']}: DTC {row['dtc']!r} / FTB {row['ftb']!r} is not a DTC")
    return key


def dtc_hex(key: str) -> str:
    """SAE J2012 / ISO 14229 3-byte DTC: 2 bits system letter, then the 14-bit code, then the FTB."""
    number = ("PCBU".index(key[0]) << 14) | (int(key[1], 16) << 12) | int(key[2:5], 16)
    return f"0x{number:04X}{key[5:]}"


# ---------------------------------------------------------------------------
# Classification: group and fault type from the description
# ---------------------------------------------------------------------------

GROUP = {
    "SQUIB": "Squib / deployment loop",
    "RSU": "Remote crash sensor (PSI5 satellite)",
    "DCS": "Seat belt buckle switch (DCS)",
    "ODS": "Occupant detection sensor (ODS)",
    "STPS": "Seat track position sensor (STPS)",
    "PAB_SWITCH": "Passenger airbag (PAB) switch",
    "OUTPUT": "Hardwired output / lamp",
    "LAMP_CAN": "Airbag warning lamp (reported over CAN)",
    "POWER": "Power supply",
    "CRASH": "Crash lock",
    "ECU": "ECU internal / configuration",
    "IMU": "On-board IMU",
    "CAN": "CAN communication",
    "UNEXPECTED_LOAD": "Unexpected load",
}

FAULT_TYPE = {
    "STG": "Short circuit to ground",
    "STB": "Short circuit to battery",
    "OPEN": "Open circuit",
    "STG_OR_OPEN": "Short to ground or open circuit",
    "LOW_RES": "Resistance too low",
    "HIGH_RES": "Resistance too high",
    "INVALID_RES": "Resistance in the invalid window",
    "CROSS_CONNECT": "Cross connection",
    "UNEXPECTED_SQUIB": "Unexpected squib",
    "CONFIG_ERROR": "Configuration error",
    "COMM_ERROR": "Communication error",
    "INTERNAL": "Internal error",
    "SAMPLING_RATE": "Sampling rate fault",
    "OUTPUT_RAILED": "Output railed",
    "SHORT_TO_OTHER_SENSOR": "Short to another remote sensor",
    "UNCONFIRMED_CRASH": "Unconfirmed crash",
    "LAMP_FAILURE": "Lamp failure",
    "UNDER_VOLTAGE": "Supply voltage low",
    "OVER_VOLTAGE": "Supply voltage high",
    "CRASH_LOCK": "ECU locked after a crash",
    "PLANT_MODE": "ECU in plant mode",
    "ECU_CONFIG_ERROR": "ECU configuration error",
    "SCRAP": "Loops enabled for vehicle scrapping",
    "EDR_FULL": "EDR deployment record full",
    "SVD_DEPLOYMENT": "Loops deployed by the SVD function",
    "CALIBRATION": "Calibration fault",
    "IMU_FAULT": "IMU fault",
    "NODE_ABSENT": "Node absent",
    "MESSAGE_TIMEOUT": "Message timeout",
    "MESSAGE_CONTENT": "Message content failure",
    "SIGNAL_CONTENT": "Signal content failure",
    "BUS_OFF": "CAN bus off",
    "VIN_MISMATCH": "VIN mismatch",
    "VARIANT_CODE": "Variant code error",
    "FEATURE_CODE": "Feature code error",
    "UNEXPECTED_LOAD": "Unexpected load",
}

# Fault type words of the description, first match wins.
DESCRIPTION_KINDS = [
    ("UNEXPECTED_SQUIB", r"UNEXPECTED SQUIB|SQUIB UNEXPECTED"),
    ("CONFIG_ERROR", r"CONFIGURATION ERROR"),
    ("COMM_ERROR", r"COMMUNICATION ERROR"),
    ("INTERNAL", r"INTERNAL ERROR"),
    ("SAMPLING_RATE", r"SAMPLING RATE"),
    ("OUTPUT_RAILED", r"OUTPUT RAILED"),
    ("SHORT_TO_OTHER_SENSOR", r"SHORT TO ANOTHER REMOTE SENSOR"),
    ("UNCONFIRMED_CRASH", r"UNCONFIRMED CRASH"),
    ("CROSS_CONNECT", r"CROSS ?CONNECT"),
    ("INVALID_RES", r"INVALID RESISTANCE"),
    ("LOW_RES", r"LOW RES"),
    ("HIGH_RES", r"HIGH RES"),
    ("STG_OR_OPEN", r"GROUND OR OPEN"),
    ("STG", r"SHORT (CIRCUIT )?TO GROUND"),
    ("STB", r"SHORT (CIRCUIT )?TO BATTERY|LEAK TO PLUS|ACN BATTERY"),
    ("OPEN", r"\bOPEN\b"),
]

CAN_KINDS = [
    ("NODE_ABSENT", r"NODE ABSENT"),
    ("MESSAGE_TIMEOUT", r"MESSAGE TIME ?OUT"),
    ("MESSAGE_CONTENT", r"MESSAGE CONTEN"),
    ("SIGNAL_CONTENT", r"SIGNAL CONTENT"),
    ("BUS_OFF", r"BUS[ _]OFF"),
    ("VIN_MISMATCH", r"\bVIN\b"),
    ("VARIANT_CODE", r"VARIANT CODE"),
    ("FEATURE_CODE", r"FEATURE CODE"),
]

# DTCs whose description alone does not say what they are.
SPECIAL = {
    "B101349": ("ECU", "INTERNAL"),
    "B142A16": ("POWER", "UNDER_VOLTAGE"),
    "B142A17": ("POWER", "OVER_VOLTAGE"),
    "B120000": ("ECU", "PLANT_MODE"),
    "B120200": ("ECU", "ECU_CONFIG_ERROR"),
    "B121300": ("ECU", "SCRAP"),
    "B121400": ("ECU", "SVD_DEPLOYMENT"),
    "B121500": ("ECU", "EDR_FULL"),
    "B124700": ("ECU", "CALIBRATION"),
    "B124800": ("ECU", "CALIBRATION"),
    "B125200": ("CRASH", "CRASH_LOCK"),
    "B00D200": ("LAMP_CAN", "LAMP_FAILURE"),
}


def classify(key: str, description: str) -> tuple[str, str]:
    text = description.upper()
    if key in SPECIAL:
        return SPECIAL[key]

    def kind_of(patterns):
        for kind, pattern in patterns:
            if re.search(pattern, text):
                return kind
        raise SystemExit(f"{key} '{description}': no fault type rule matches - add one to the build")

    if key.startswith("U"):
        return "CAN", kind_of(CAN_KINDS)
    if text.startswith("ECU LOCKED"):
        return "CRASH", "CRASH_LOCK"
    if "IMU" in text:
        return "IMU", "IMU_FAULT"
    if "UNEXPECTED LOAD" in text:
        return "UNEXPECTED_LOAD", "UNEXPECTED_LOAD"
    if re.search(r"AIRBAG (ENABLE |DISABLE )?SWITCH", text) and "PYROTECHNIC" not in text:
        return "PAB_SWITCH", kind_of(DESCRIPTION_KINDS)
    if re.search(r"LAMP|\bLED\b|CRASH OUTPUT|\bACN\b", text):
        return "OUTPUT", kind_of(DESCRIPTION_KINDS)
    if re.search(r"\bODS\b", text):
        return "ODS", kind_of(DESCRIPTION_KINDS)
    if "STPS" in text:
        return "STPS", kind_of(DESCRIPTION_KINDS)
    if re.search(r"SEAT BELT LEAK|\bDC'?S?\b", text):
        return "DCS", kind_of(DESCRIPTION_KINDS)
    if re.search(r"RSU|PRESSURE SENSOR|UNDER BODY SENSOR", text):
        return "RSU", kind_of(DESCRIPTION_KINDS)
    if re.search(r"SQUIB|AIRBAG|PRE-?TENSIONER|PELVIS|PYROTECHNIC", text):
        return "SQUIB", kind_of(DESCRIPTION_KINDS)
    raise SystemExit(f"{key} '{description}': no group rule matches - add one to the build")


# ---------------------------------------------------------------------------
# What it is
# ---------------------------------------------------------------------------

WHAT = {
    ("SQUIB", "STG"): "The ECU measures the firing loop shorted to ground.",
    ("SQUIB", "STB"): "The ECU measures the firing loop shorted to the battery supply.",
    ("SQUIB", "OPEN"): "The firing-loop resistance is above the open-circuit threshold: squib disconnected "
                       "or loop broken.",
    ("SQUIB", "LOW_RES"): "The firing-loop resistance is below the valid squib window.",
    ("SQUIB", "HIGH_RES"): "The firing-loop resistance is above the valid squib window but below open.",
    ("SQUIB", "CROSS_CONNECT"): "The firing loop is cross-connected (short circuit) with another "
                                "deployment loop.",
    ("SQUIB", "UNEXPECTED_SQUIB"): "The EOL configuration says this loop is not fitted, yet a squib "
                                   "(resistance in the valid range) is connected to it.",
    ("RSU", "OPEN"): "The satellite line is open: sensor not connected to the harness.",
    ("RSU", "STG"): "The satellite line is shorted to ground.",
    ("RSU", "STB"): "The satellite line is shorted to the battery supply.",
    ("RSU", "COMM_ERROR"): "The ECU receives invalid data from the satellite (the workbook names a "
                           "sensor with a wrong serial number).",
    ("RSU", "INTERNAL"): "The satellite reports an internal failure.",
    ("RSU", "CONFIG_ERROR"): "The satellite does not match the EOL configuration: data from a sensor "
                             "that is not configured, or the wrong sensor configuration.",
    ("RSU", "SAMPLING_RATE"): "The satellite reports a sampling-rate fault.",
    ("RSU", "OUTPUT_RAILED"): "The satellite output is stuck at its rail (saturated).",
    ("RSU", "SHORT_TO_OTHER_SENSOR"): "The satellite line is shorted to the line of another remote sensor.",
    ("RSU", "UNCONFIRMED_CRASH"): "The satellite reported crash-level data that the ECU did not confirm.",
    ("DCS", "STB"): "The buckle switch line has a leak / short to battery (+).",
    ("DCS", "CROSS_CONNECT"): "The buckle switch line is cross-connected with another DCS channel.",
    ("ODS", "STG"): "The occupant detection sensor line is shorted to ground.",
    ("ODS", "STB"): "The occupant detection sensor line is shorted to the battery supply.",
    ("ODS", "OPEN"): "The occupant detection sensor connector is open.",
    ("ODS", "LOW_RES"): "The occupant detection sensor resistance is below its valid range.",
    ("ODS", "HIGH_RES"): "The occupant detection sensor resistance is above its valid range.",
    ("ODS", "CROSS_CONNECT"): "The occupant detection sensor line is cross-connected with another channel.",
    ("STPS", "STG"): "The seat track position sensor line is shorted to ground.",
    ("STPS", "STB"): "The seat track position sensor line is shorted to the battery supply.",
    ("STPS", "OPEN"): "The seat track position sensor connector is open.",
    ("STPS", "CROSS_CONNECT"): "The seat track position sensor line is cross-connected with another "
                               "channel.",
    ("STPS", "CONFIG_ERROR"): "The seat track position sensor does not match the EOL configuration.",
    ("PAB_SWITCH", "STG"): "The PAB switch input is shorted to ground.",
    ("PAB_SWITCH", "STB"): "The PAB switch input is shorted to the battery supply.",
    ("PAB_SWITCH", "OPEN"): "The PAB switch input resistance is above the open threshold.",
    ("PAB_SWITCH", "LOW_RES"): "The PAB switch resistance is in its low-resistance fault window.",
    ("PAB_SWITCH", "HIGH_RES"): "The PAB switch resistance is in its high-resistance fault window.",
    ("PAB_SWITCH", "INVALID_RES"): "The PAB switch resistance is between the ON and OFF codes "
                                   "(invalid window).",
    ("PAB_SWITCH", "CONFIG_ERROR"): "The PAB switch is connected although the EOL configuration "
                                    "disables it.",
    ("OUTPUT", "STG"): "The hardwired output line is shorted to ground.",
    ("OUTPUT", "STB"): "The hardwired output line is shorted to the battery supply.",
    ("OUTPUT", "OPEN"): "The hardwired output line is open (load disconnected).",
    ("OUTPUT", "STG_OR_OPEN"): "The hardwired output line is shorted to ground or open.",
    ("OUTPUT", "CONFIG_ERROR"): "The output's connection type or presence does not match the EOL "
                                "configuration.",
    ("LAMP_CAN", "LAMP_FAILURE"): "The instrument cluster (IP) reports over CAN that the airbag warning "
                                  "lamp has failed.",
    ("POWER", "UNDER_VOLTAGE"): "The supply voltage measured by the ECU is below the low-voltage "
                                "threshold (9 V in the workbook).",
    ("POWER", "OVER_VOLTAGE"): "The supply voltage measured by the ECU is above the high-voltage "
                               "threshold (16 V in the workbook).",
    ("CRASH", "CRASH_LOCK"): "The ECU detected the crash named in the description and locked itself; "
                             "the DTC cannot be cleared.",
    ("ECU", "INTERNAL"): "The ECU detected one of its internal faults.",
    ("ECU", "PLANT_MODE"): "The ECU is in plant mode: faults were present at the first IGN ON; the "
                           "warning lamp flashes at 1 Hz.",
    ("ECU", "ECU_CONFIG_ERROR"): "At least one EOL configuration fault is present (DCS, RSU, loop or "
                                 "lamp configuration).",
    ("ECU", "SCRAP"): "The deployment loops were enabled for vehicle scrapping.",
    ("ECU", "SVD_DEPLOYMENT"): "Loops were deployed by the SVD function.",
    ("ECU", "EDR_FULL"): "The deployment data record (EDR) memory is full.",
    ("ECU", "CALIBRATION"): "The ECU calibration is missing or incorrect (see the description).",
    ("IMU", "IMU_FAULT"): "The on-board inertial measurement unit (IMU) reports the fault in the "
                          "description.",
    ("CAN", "NODE_ABSENT"): "The node's key message is not received: the node is absent.",
    ("CAN", "MESSAGE_TIMEOUT"): "At least one non-key message of the node is missing.",
    ("CAN", "MESSAGE_CONTENT"): "The frame is received with a wrong DLC, CRC or alive counter.",
    ("CAN", "SIGNAL_CONTENT"): "The signal is received with an invalid value.",
    ("CAN", "BUS_OFF"): "The ECU's CAN controller went bus-off.",
    ("CAN", "VIN_MISMATCH"): "The VIN is not received, received wrong, or its frame HPC_Ad5_500 is "
                             "missing or has a wrong DLC.",
    ("CAN", "VARIANT_CODE"): "The variant code status bit is not set (ECU not variant-coded).",
    ("CAN", "FEATURE_CODE"): "Feature code error.",
    ("UNEXPECTED_LOAD", "UNEXPECTED_LOAD"): "A load is connected to a channel of the named type that the "
                                            "configuration does not use.",
}

# ---------------------------------------------------------------------------
# How to create it on the bench (agent_sc3.md section 25.5, framework functions)
# ---------------------------------------------------------------------------

ASK = "Not in the agent_sc3.md §25.5 fault-creation catalog: ask before scripting it."
NVM = "The EOL write is an NVM write: ask before running it (agent_sc3.md §23)."
EOL_ROUTE = ("EOL-configure the {what} as not fitted while it stays connected (the 64 DTCs of "
             "eol_config.EOL_FEATURE_AVAILABLE_DTCS); ECU CONFIGURATION ERROR B120200 "
             "(eol_config.EOL_CONFIG_ERROR_DTC) is expected with it. " + NVM)
EOL_PRECEDENT = "M310 Fault_List EOL scripts (EOL route is not in §25.5)"

SQUIB_RELAY = ("SQUIB.SendRequest('LOOP<n>', squibs_config.Squib_Fault_Description['{load}']); remove: "
               "SQUIB.SendRequest('LOOP<n>', Squib_Fault_Description['NoFault']).")
SQUIB_LEAK = ("PS.{leak_set}(), then SQUIB.SendRequest('LOOP<n>', squibs_config.Squib_Fault_Description"
              "['{load}']); remove: loop back to Squib_Fault_Description['NoFault'], then PS.{leak_clear}().")
RSU_FAULT = ("SetRsuFaultCondition('{fault}', <rsu>, '') ({aria}); remove: "
             "RemoveRsuFaultCondition('{fault}', <rsu>, <config path>).")
SLS_FAULT = ("SLS.SendRequest({device}, {load}){leak}; remove: back to {rest}{unleak}.")
GPO_FAULT = ("SetGpoFaultCondition('{output}', '{fault}'); remove: SetGpoFaultCondition('{output}', "
             "'INHERENT') (the wrapper settles 4-5 s itself).")
CRASH = ("Crash at T0: load_crash_curves(<{curve} curve>) then TriggerCrash() or perform_crash(<type>). "
         "Permanent lock - the ECU cannot be reused: never run it uninvited (agent_sc3.md §23).")

LEAKS = {"STB": ("SetLeakageVBATBusHigh", "ClearLeakageVBATBusHigh")}


def gpo_output(description: str) -> str | None:
    text = description.upper()
    if "DISABLE LAMP" in text:
        return "PAB_OFF"
    if "PAB ON LED" in text:
        return "PAB_ON"
    if "CRASH OUTPUT LINE" in text:
        return "ENS"
    return None


def bench_method(key: str, group: str, kind: str, description: str) -> tuple[str, str]:
    """(how to create it on the bench, where the recipe comes from)."""
    text = description.upper()
    if group == "SQUIB":
        if kind in ("OPEN", "LOW_RES", "HIGH_RES"):
            load = {"OPEN": "Open", "LOW_RES": "LoRes", "HIGH_RES": "HiRes"}[kind]
            return SQUIB_RELAY.format(load=load), f"{CATALOG} #12"
        if kind == "STB":
            return (SQUIB_LEAK.format(leak_set="SetLeakageVBATBusHigh", leak_clear="ClearLeakageVBATBusHigh",
                                      load="S2B"), f"{CATALOG} #12 + #16")
        if kind == "STG":
            return (SQUIB_LEAK.format(leak_set="SetLeakageGNDBusLow", leak_clear="ClearLeakageGNDBusLow",
                                      load="S2G"), f"{CATALOG} #12 + #16")
        if kind == "CROSS_CONNECT":
            return ("Put this loop and a second active loop on squibs_config.Squib_Fault_Description"
                    "['CrossConnect'] (both on the bus line, no leakage); each loop reports its own "
                    "cross-connect DTC. Remove: both loops back to 'NoFault'.", f"{CATALOG} #12")
        if kind == "UNEXPECTED_SQUIB":
            return EOL_ROUTE.format(what="loop"), EOL_PRECEDENT
    if group == "RSU":
        if kind in ("OPEN", "STG", "STB"):
            fault, aria = {"OPEN": ("OPEN", "ARIA RSU.SetFaultOpen, 'OPEN-NC'"),
                           "STG": ("S2G", "ARIA RSU.SetFaultShortGround, 'STG'"),
                           "STB": ("S2B", "ARIA RSU.SetFaultShortBattery, 'STB'")}[kind]
            return RSU_FAULT.format(fault=fault, aria=aria), f"{CATALOG} #13"
        if kind == "COMM_ERROR":
            return ("The workbook sets it with a sensor of the wrong serial number. Bench precedent: "
                    "SetRsuFaultCondition('COMM', <rsu>, '') = RSU.SetFaultParity (M310 Fault_List); ARIA also "
                    "offers 'ID-Fault' - confirm which one the ECU reports as this DTC.", f"{CATALOG} #13")
        if kind == "INTERNAL":
            return ("SetRsuFaultCondition('INTERNAL', <rsu>, '') saturates the sensor with "
                    "rsu_config.RSU_INTERNAL_SATURATION_DATA through RSU.SetAcceleration; still an open item "
                    "on M310 - confirm before relying on it.", f"{CATALOG} #13")
        if kind == "CONFIG_ERROR":
            return EOL_ROUTE.format(what="satellite"), EOL_PRECEDENT
        return ASK, "-"
    if group == "DCS":
        if kind == "STB":
            return (SLS_FAULT.format(device="dcs_config.DCSName[<channel>]", load="canc_config.CANC_DCS_FAULT_LOAD",
                                     leak=" with PS.SetLeakageVBATBusHigh()",
                                     rest="dcs_config.DCS_Fault_Description['unbuckle']",
                                     unleak=", then PS.ClearLeakageVBATBusHigh()"),
                    f"{CATALOG} #14 + #16")
        if kind == "CROSS_CONNECT":
            return ("Put this buckle channel and its partner (canc_config.CANC_BELT_CROSS_CONNECT_PARTNER) on "
                    "dcs_config.DCS_Fault_Description['CrossConnect'] with SLS.SendRequest; remove: both back "
                    "to DCS_Fault_Description['unbuckle'].", f"{CATALOG} #14")
    if group in ("ODS", "STPS"):
        device, rest = {"ODS": ("ods_config.ODSChannelName[<channel>]", "canc_config.CANC_ODS_LOADS['NOT_PRESENT']"),
                        "STPS": ("dcs_config.STPSName[<channel>]", "canc_config.CANC_STPS_LOADS['ZONE_1']")}[group]
        if kind in ("STB", "STG"):
            leak = {"STB": "VBATBusHigh", "STG": "GNDBusHigh"}[kind]
            method = SLS_FAULT.format(device=device, load="canc_config.CANC_DCS_FAULT_LOAD",
                                      leak=f" with PS.SetLeakage{leak}()", rest=rest,
                                      unleak=f", then PS.ClearLeakage{leak}()")
            if group == "STPS" and kind == "STG":
                method += " STPS short to ground is still an open item on M310 - confirm."
            return method, f"{CATALOG} #14 + #16"
        if kind == "OPEN":
            return (SLS_FAULT.format(device=device, load="'OPEN'", leak="", rest=rest, unleak="")
                    + " 'OPEN' is the ARIA DCS-card open preset.", f"{CATALOG} #14")
        if kind == "CROSS_CONNECT":
            return ("Put this channel and a second one of the same kind on the cross-connect load with "
                    "SLS.SendRequest (M310 Fault_List cross-connect scripts); remove: both back to "
                    f"{rest}.", f"{CATALOG} #14")
        if kind in ("LOW_RES", "HIGH_RES"):
            return ("Resistance-coded load on the channel (agent_sc3.md §27.1) inside the workbook's fault "
                    "window; the project config names no load for it - ask.", f"{CATALOG} #14")
        if kind == "CONFIG_ERROR":
            return EOL_ROUTE.format(what="seat track position sensor"), EOL_PRECEDENT
    if group == "PAB_SWITCH":
        if kind == "CONFIG_ERROR":
            return EOL_ROUTE.format(what="PAB switch"), EOL_PRECEDENT
        return ("Resistance-coded switch input on the SLS card (agent_sc3.md §27.1): set a resistance "
                "inside the workbook window" + (", with power-card leakage for the short" if kind in ("STB", "STG")
                                                else "")
                + ". No PAB-switch fault recipe exists in the framework yet - ask.", f"{CATALOG} #14")
    if group == "OUTPUT":
        output = gpo_output(description)
        if kind in ("STB", "STG", "OPEN") and output:
            fault = {"STB": "S2B", "STG": "S2G", "OPEN": "OPEN"}[kind]
            return GPO_FAULT.format(output=output, fault=fault), f"{CATALOG} #11"
        if kind in ("STB", "STG", "OPEN") and "ECALL" in text:
            return ("The E-Call line is not a gpo_config GPO, so SetGpoFaultCondition refuses it; drive it with "
                    "the steps SetGpoFaultCondition uses for ENS (M310 Fault_List E-Call scripts).",
                    f"{CATALOG} #11")
        if kind == "CONFIG_ERROR":
            return EOL_ROUTE.format(what="output"), EOL_PRECEDENT
        return ("No set condition in the workbook and no SetGpoFaultCondition output for it. " + ASK, "-")
    if group == "LAMP_CAN":
        return ("CAN.ChangeSignalValue(<bus>, <frame>, <lamp-failure signal>, <failure value>) from the "
                "instrument cluster frame; signal and value are not in the workbook - take them from the DBC / "
                "canc_config.", f"{CATALOG} #5 (pattern)")
    if group == "POWER":
        level, dtc = {"UNDER_VOLTAGE": ("below 9 V", "Under_Voltage"),
                      "OVER_VOLTAGE": ("above 16 V", "Over_Voltage")}[kind]
        return (f"Set_ECU_PowerVoltage(<{level}>) and hold past the mature time; back to nominal to heal. DTC "
                f"bytes: shared configuration_control.{dtc}. The DTC stays 08 while the fault is active "
                f"(agent_sc3.md §16.3).", f"{CATALOG} #8")
    if group == "CRASH":
        if key == "B125200":
            return CRASH.format(curve="under-body sensor") + " The workbook heal is ECU replacement.", f"{CATALOG} #17"
        curve = next((c for c in ("ROLL OVER", "FRONT", "REAR", "SIDE", "PRETENSIONER") if c in text), "")
        curve = {"PRETENSIONER": "pretensioner-firing", "ROLL OVER": "roll-over"}.get(curve, curve.lower())
        return CRASH.format(curve=curve), f"{CATALOG} #17"
    if group == "ECU":
        if kind == "ECU_CONFIG_ERROR":
            return ("Create any EOL configuration fault (loop, RSU, DCS or lamp configuration error / unexpected "
                    "squib - see those DTCs); eol_config.EOL_CONFIG_ERROR_DTC is expected with them. " + NVM,
                    EOL_PRECEDENT)
        if kind == "PLANT_MODE":
            return ("Needs an ECU in plant mode (NVM state) with any fault present at the first IGN ON; it heals "
                    "after 30 s error free. " + ASK, "-")
        return ASK, "-"
    if group == "IMU":
        return ("SPI EVT flow: SPI.UpdateProtocolInfo, SPI.SendEvt (twice), SPI.TriggerEvtErrors, "
                "SPI.SimulateSensor - needs an EVT file carrying this IMU error; ask if none exists.",
                f"{CATALOG} #15")
    if group == "CAN":
        if kind == "NODE_ABSENT":
            return ("CAN.PeriodicDisableFrame(<bus>, <key frame named in the set condition>); remove: re-enable "
                    "it. Whole bus: disable_all_node_absent_frames() / enable_all_node_absent_frames().",
                    f"{CATALOG} #1")
        if kind == "MESSAGE_TIMEOUT":
            return ("CAN.PeriodicDisableFrame(<bus>, <a non-key frame of the node>); remove: re-enable it. Whole "
                    "bus: disable_all_message_timeout_frames().", f"{CATALOG} #2")
        if kind == "MESSAGE_CONTENT":
            return ("CRC / alive counter: CAN.DisableDynamicSignal(<frame>, <CRC or counter signal>), remove "
                    "with CAN.EnableDynamicSignal. Wrong DLC: redefine the periodic frame with another DLC (ask "
                    "if the bus refuses it).", f"{CATALOG} #3 / #4")
        if kind == "SIGNAL_CONTENT":
            return ("CAN.ChangeSignalValue(<bus>, <frame>, <signal>, str(<invalid raw>)) with the invalid value "
                    "from canc_config / DBC; send the valid value again to heal.", f"{CATALOG} #5")
        if kind == "BUS_OFF":
            return ("No clean wrapper: needs error-frame injection or physical bus manipulation - ask how it is "
                    "done on your bench.", f"{CATALOG} #18")
        if kind == "VIN_MISMATCH":
            return ("Per the workbook set condition: stop HPC_Ad5_500 (CAN.PeriodicDisableFrame), send a wrong "
                    "VIN (CAN.ChangeSignalValue) or HPC_Ad5_500 with a wrong DLC.", f"{CATALOG} #2 / #5 / #4")
        if kind == "VARIANT_CODE":
            return ("Create_Variant_code_error(); heal: clear_Variant_code_error(). Both send a UDS 2E write "
                    "whose payload is hard-coded in the wrapper, then power-cycle - an NVM write: check the "
                    "payload fits the project and ask before running it (agent_sc3.md §23).", f"{CATALOG} #7")
        return ASK, "-"
    if group == "UNEXPECTED_LOAD":
        return ASK, "-"
    raise SystemExit(f"{key} '{description}': no bench method for {group} / {kind} - add one to the build")


# ---------------------------------------------------------------------------
# Workbook consistency checks (reported per entry, never corrected)
# ---------------------------------------------------------------------------

# Fault type the set condition text describes, first match wins.
SET_KINDS = [
    ("COMM_ERROR", r"WRONG SN"),
    ("INTERNAL", r"INTERNAL (FAILURE|FAULT)"),
    ("CROSS_CONNECT", r"CROSS ?CONNECT"),
    ("OPEN", r"OPEN THRESHOLD|NOT CONNECTED TO THE HARNESS|CONNECTOR OPEN|CONNECTION OPEN|-OPEN\b"),
    ("STB", r"BATTERY|\bSTB\b|\bPLUS\b"),
    ("STG", r"\bGND\b|GROUND"),
    ("LOW_RES", r"TOO LOW|RESISTANCE\s*<"),
    ("HIGH_RES", r"TOO HIGH|RESISTANCE\s*>"),
]
COMPARABLE = {"OPEN", "STG", "STB", "COMM_ERROR", "INTERNAL", "LOW_RES", "HIGH_RES", "CROSS_CONNECT"}
CRASH_WORDS = [("ROLL OVER", r"ROLL ?OVER"), ("FRONT", r"FRONT"), ("REAR", r"REAR"), ("SIDE", r"SIDE"),
               ("PRETENSIONER", r"PRETENSIONER")]


def set_kind(text: str | None) -> str | None:
    if not text:
        return None
    for kind, pattern in SET_KINDS:
        if re.search(pattern, text.upper()):
            return kind
    return None


def first_word(text: str, words) -> str | None:
    return next((word for word, pattern in words if re.search(pattern, text.upper())), None)


def issue(category: str, variant: str, row: dict, text: str, **details) -> dict:
    """One workbook conflict: its category (CONFLICT_TITLES), where it is and the entry text."""
    return {"category": category, "variant": variant, "row": row["row"], "s_no": row["s_no"],
            "text": f"{variant}: {text}", **details}


def row_issues(variant: str, key: str, row: dict, group: str, kind: str) -> list[dict]:
    issues = []
    expected = dtc_hex(key)[2:]
    cell = str(row["hex_cell"]).strip().upper()
    hex_ok = (cell[2:] if cell.startswith("0X") else cell) == expected
    if not hex_ok:
        issues.append(issue("code", variant, row, f"DTC (HEX) cell reads {row['hex_cell']!r}; DTC {row['dtc']} + "
                                                  f"FTB {row['ftb']} give 0x{expected}.",
                            column="DTC (HEX)", cell=row["hex_cell"], expected=f"0x{expected}"))
    if str(row["code_cell"]).strip().upper() != key:
        agrees = f" (the hex column agrees with {key})" if hex_ok else ""
        issues.append(issue("code", variant, row, f"full-DTC cell reads {row['code_cell']!r}; DTC {row['dtc']} + "
                                                  f"FTB {row['ftb']} give {key}{agrees}.",
                            column="full DTC (after DTC (HEX))", cell=row["code_cell"], expected=key))
    set_text, heal_text = row["set_condition"], row["heal_condition"]
    if set_text in (None, "NA"):
        issues.append(issue("no_set", variant, row, f"no set condition ({set_text or 'blank'}).",
                            value=set_text or "blank"))
    if group in ("SQUIB", "RSU", "DCS", "ODS", "STPS", "PAB_SWITCH", "OUTPUT"):
        found = set_kind(set_text)
        if kind in COMPARABLE and found in COMPARABLE and found != kind:
            issues.append(issue("foreign_set", variant, row, f"set condition '{set_text}' describes "
                                f"{FAULT_TYPE[found].lower()}, but the DTC is {FAULT_TYPE[kind].lower()}.",
                                set_text=set_text, describes=found))
        if kind == "CONFIG_ERROR" and found == "OPEN":
            issues.append(issue("config_open", variant, row, f"set condition '{set_text}' reads like an open "
                                f"circuit, not a configuration error (other config-error rows say 'Wrong sensor "
                                f"configuration').", set_text=set_text, heal_text=heal_text))
        if kind in ("LOW_RES", "HIGH_RES") and set_text and heal_text:
            # Only single-threshold rows: a window '(52 ohms < R < 72 ohms)' healed by 'is out of' is fine.
            ops = [re.findall(r"[<>]", t) for t in (set_text, heal_text)]
            if len(ops[0]) == 1 and ops[0] == ops[1]:
                issues.append(issue("heal_same", variant, row, f"heal condition '{heal_text}' uses the same "
                                    f"comparison as the set condition.", set_text=set_text, heal_text=heal_text))
    if group == "CRASH" and set_text:
        said, stored = first_word(row["description"], CRASH_WORDS), first_word(set_text, CRASH_WORDS)
        if said and stored and said != stored:
            issues.append(issue("crash_word", variant, row, f"the description says {said.lower()} but the set "
                                f"condition says '{set_text}'.", set_text=set_text, reaction=row["error_reaction"]))
    return issues


def shifted_blocks(conflicts: list[dict]) -> tuple[Counter, list[str]]:
    """DTC bases (one sensor each) where 3 or more DTCs carry the set condition of another fault type."""
    foreign = Counter(dtc[:5] for dtc in {c["dtc"] for c in conflicts if c["category"] == "foreign_set"})
    return foreign, sorted(base for base, count in foreign.items() if count >= 3)


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------

def merged(rows: dict, field: str):
    """One value when every list agrees, else {'EV': ..., 'ICE': ...}."""
    values = {variant: row[field] for variant, row in rows.items()}
    distinct = list(dict.fromkeys(values.values()))
    return distinct[0] if len(distinct) == 1 else values


def build() -> tuple[dict, dict, list[dict]]:
    tables, infos = {}, {}
    for variant in WORKBOOKS:
        rows, info = read_workbook(variant)
        table = {}
        for row in rows:
            key = dtc_key(row, info["path"])
            if key in table:
                raise SystemExit(f"{info['path']}: {key} on rows {table[key]['row']} and {row['row']}")
            table[key] = row
        tables[variant], infos[variant] = table, info

    keys = set(tables["EV"]) | set(tables["ICE"])
    order = sorted(keys, key=lambda k: (int((tables["ICE"].get(k) or tables["EV"][k])["s_no"] or 0), k))
    dictionary, conflicts = {}, []
    for key in order:
        rows = {variant: tables[variant][key] for variant in WORKBOOKS if key in tables[variant]}
        issues = []
        ev_flag = rows["EV"]["ev_variants"] if "EV" in rows else None
        if "EV" in rows and str(ev_flag or "").strip().lower() == "no":
            issues.append(issue("ev_flag", "EV", rows["EV"], "listed but marked No in the M312/M112/W613/M314 "
                                "column - treated as not EV.", value=ev_flag))
            del rows["EV"]
        elif "EV" in rows and not ev_flag:
            issues.append(issue("ev_flag", "EV", rows["EV"], "the M312/M112/W613/M314 applicability cell is "
                                "blank - confirm it applies to EV.", value=None))
        applicable = tuple(rows)
        description = merged(rows, "description")
        name = description if isinstance(description, str) else rows["ICE" if "ICE" in rows else "EV"]["description"]
        group, kind = classify(key, name)
        for variant, row in rows.items():
            issues.extend(row_issues(variant, key, row, group, kind))
        for item in issues:
            item["dtc"] = key
        conflicts.extend(issues)
        method, reference = bench_method(key, group, kind, name)
        dictionary[key] = {
            "description": description,
            "applicability": "BOTH" if len(applicable) == 2 else f"{applicable[0]} ONLY",
            "applicable_to": applicable,
            "dtc_hex": dtc_hex(key),
            "dtc": key[:5],
            "ftb": key[5:],
            "dtc_type": DTC_TYPE[key[0]],
            "group": GROUP[group],
            "fault_type": FAULT_TYPE[kind],
            "what_it_is": WHAT[(group, kind)],
            "how_to_create": {
                "precondition": merged(rows, "precondition"),
                "set_condition": merged(rows, "set_condition"),
                "heal_condition": merged(rows, "heal_condition"),
                "mature_time": merged(rows, "mature_time"),
                "demature_time": merged(rows, "demature_time"),
                "time_tolerance": merged(rows, "tolerance"),
                "bench_method": method,
                "recipe_source": reference,
            },
            "warning_lamp": merged(rows, "warning_lamp"),
            "error_reaction": merged(rows, "error_reaction"),
            "ageing_cycles": merged(rows, "ageing"),
            "ign_toggle_to_heal": merged(rows, "ign_toggle"),
            "memory": merged(rows, "memory"),
            "remark": merged(rows, "supplier_remark"),
            "ev_variants_m312_m112_w613_m314": ev_flag,
            "workbook_issues": [item["text"] for item in issues],
            "source": {variant: {"row": row["row"], "s_no": row["s_no"]} for variant, row in rows.items()},
        }
    return dictionary, infos, conflicts


# ---------------------------------------------------------------------------
# Render
# ---------------------------------------------------------------------------

def literal(value, indent: int) -> str:
    pad = " " * indent
    if isinstance(value, dict):
        if not value:
            return "{}"
        if all(not isinstance(v, (dict, list, tuple)) for v in value.values()) and len(value) <= 2 \
                and len(json.dumps(value, ensure_ascii=False)) < 60:
            return "{" + ", ".join(f"{literal(k, 0)}: {literal(v, 0)}" for k, v in value.items()) + "}"
        inner = "".join(f"{pad}    {literal(k, 0)}: {literal(v, indent + 4)},\n" for k, v in value.items())
        return "{\n" + inner + pad + "}"
    if isinstance(value, list):
        if not value:
            return "[]"
        return "[\n" + "".join(f"{pad}    {literal(v, indent + 4)},\n" for v in value) + pad + "]"
    if isinstance(value, tuple):
        return "(" + ", ".join(literal(v, 0) for v in value) + ("," if len(value) == 1 else "") + ")"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    return repr(value)


def render(dictionary: dict, infos: dict, conflicts: list[dict]) -> str:
    applicability = Counter(entry["applicability"] for entry in dictionary.values())
    groups = Counter(entry["group"] for entry in dictionary.values())
    with_issues = [key for key, entry in dictionary.items() if entry["workbook_issues"]]
    both = [key for key, entry in dictionary.items() if entry["applicability"] == "BOTH"]
    differing = Counter(field for key in both
                        for field, value in {**dictionary[key], **dictionary[key]["how_to_create"]}.items()
                        if field != "source" and isinstance(value, dict) and set(value) == {"EV", "ICE"})
    can_both = [key for key in both if key.startswith("U")]
    ev, ice = infos["EV"], infos["ICE"]
    foreign, shifted = shifted_blocks(conflicts)

    def source_line(info):
        line = f"    {info['path']} (sheet '{info['sheet']}'): {info['rows']} DTC rows"
        if info["skipped"]:
            count = len(info["skipped"])
            line += f", {count} row{'s' if count > 1 else ''} without a DTC skipped"
        return line

    observations = [
        f"The ICE workbook is saved with a filter ({ice['filter']}) that hides {ice['hidden_rows']} rows; "
        f"every row was read regardless." if ice["hidden_rows"] else None,
        f"Every EV DTC is also in the ICE list, and the {len(both)} common DTCs read the same in both "
        f"lists" + (f" except {', '.join(f'{n} {f}' for f, n in sorted(differing.items()))}" if differing else "")
        + f". The {len(can_both)} common U-codes therefore name EV nodes and frames (VCU, IEB, FR_ZONE, HPCC, "
        f"HPCAd, EPS) in the ICE list too - confirm them against the ICE DBC." if both else None,
        f"{', '.join(shifted)}: in each of these blocks {min(foreign[b] for b in shifted)} or more rows carry "
        f"the set condition of another fault type of the same sensor - the conditions look shifted by one "
        f"row (inference). Go by the description, not the set condition." if shifted else None,
        "The DTC 'Priority' column is NA for every DTC (the column note says all faults have the same "
        "priority); M&M and Status are empty. None of the three is carried.",
    ]
    lines = [
        '"""',
        "Common DTC dictionary: EV + ICE",
        "",
        "Every DTC of the EV and ICE DTC lists, merged on the DTC (DTC + FTB), with what it is, which",
        "vehicles it applies to and how to create it.",
        "",
        "Sources:",
        source_line(ev),
        source_line(ice),
        "Built with tools/build_common_dtc_dictionary.py; rebuild it there rather than edit by hand.",
        "The workbook conflicts are listed for review in DTC_LIST_CONFLICTS.md, and the same DTCs in",
        "fault-list form (one dict per DTC, named by its mnemonic) are in common_fault_list.py (same folder).",
        "",
        f"{len(dictionary)} DTCs: {applicability['BOTH']} BOTH, {applicability['EV ONLY']} EV ONLY, "
        f"{applicability['ICE ONLY']} ICE ONLY; {len(with_issues)} carry workbook_issues.",
        "",
        "Each entry (key = DTC as read with 19 02, e.g. 'B000111'):",
        "    description        workbook description",
        "    applicability      'BOTH', 'EV ONLY' or 'ICE ONLY' (applicable_to: the same as a tuple)",
        "    dtc_hex            3-byte DTC (SAE J2012 encoding of DTC + FTB), dtc / ftb its two parts",
        "    dtc_type           SAE J2012 system letter: B (Body), C (Chassis), P (Powertrain), U (Network)",
        "    group, fault_type  what kind of device and fault it is",
        "    what_it_is         plain description of the fault the ECU detects",
        "    how_to_create      precondition, set_condition, heal_condition, mature_time, demature_time,",
        "                       time_tolerance: the workbook's own words",
        "                       bench_method: how to create it on the ARIA bench with framework functions;",
        "                       recipe_source: agent_sc3.md §25.5 catalog item it follows ('-': none, ask)",
        "    warning_lamp, error_reaction, ageing_cycles, ign_toggle_to_heal, memory, remark: workbook",
        "    ev_variants_m312_m112_w613_m314   EV list's applicability cell (None: ICE only or blank)",
        "    workbook_issues    contradictions found in the workbook rows (not corrected here)",
        "    source             workbook row and S.No per list",
        "",
        "A field where the EV and ICE lists disagree holds {'EV': ..., 'ICE': ...} instead of one value.",
        "",
        "Workbook observations:",
    ]
    lines += [f"- {text}" for text in observations if text]
    lines += [
        '"""',
        "",
        "# DTCs per group: " + ", ".join(f"{name} {count}" for name, count in groups.most_common()),
        "COMMON_DTC_DICTIONARY = {",
    ]
    for key, entry in dictionary.items():
        lines.append(f"    {literal(key, 0)}: {literal(entry, 4)},")
    lines.append("}")
    lines.append("")
    for name, test in (("BOTH_DTCS", "BOTH"), ("EV_ONLY_DTCS", "EV ONLY"), ("ICE_ONLY_DTCS", "ICE ONLY")):
        keys = [key for key, entry in dictionary.items() if entry["applicability"] == test]
        lines.append(f"{name} = (")
        lines += [f"    {literal(key, 0)}," for key in keys]
        lines.append(")")
    lines += [
        "",
        "",
        "def dtcs_for(vehicle):",
        '    """DTCs that apply to vehicle \'EV\' or \'ICE\' (its own list plus the common ones)."""',
        "    vehicle = vehicle.upper()",
        "    if vehicle not in (\"EV\", \"ICE\"):",
        "        raise ValueError(f\"vehicle must be 'EV' or 'ICE', not {vehicle!r}\")",
        "    return [dtc for dtc, entry in COMMON_DTC_DICTIONARY.items() if vehicle in entry[\"applicable_to\"]]",
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Fault list (common_fault_list.py): one dict per DTC, named by its mnemonic
# ---------------------------------------------------------------------------

MAX_NAME = 31   # MISRA C:2012 rule 5.1: external identifiers distinct within 31 characters (C99)
NAME_PATTERN = r"[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*"
MODULE_NAMES = {"MNEMONIC_GLOSSARY", "NAMING_NOTES", "COMMON_FAULT_LIST", "FAULT_BY_DTC_HEX"}

# Controlled vocabulary: every word of a mnemonic must be here (CAN mnemonics excepted: they keep the
# DBC frame or signal name). Only the words in use are written to the fault list.
VOCABULARY = {
    "DRV": "driver side, front row (workbook DRIVER)",
    "PSG": "passenger side, front row (workbook PASSENGER / CO-DRIVER)",
    "LH": "left-hand side (workbook LEFT)",
    "RH": "right-hand side (workbook RIGHT)",
    "CTR": "centre (workbook CENTER)",
    "MID": "middle seat (workbook MIDDLE)",
    "R2": "second seat row",
    "R3": "third seat row",
    "FRONT": "front",
    "REAR": "rear",
    "SIDE": "side",
    "UB": "under body",
    "APLR": "A-pillar",
    "BPLR": "B-pillar",
    "CPLR": "C-pillar",
    "DAB": "driver airbag",
    "PAB": "passenger airbag",
    "AV": "dual active vent squib of the airbag",
    "SAB": "side (thorax) airbag",
    "IC": "inflatable curtain airbag (workbook CURTAIN AIRBAG)",
    "KAB": "knee airbag",
    "FSAB": "far-side airbag",
    "PT": "belt pretensioner",
    "LAP": "lap belt",
    "BFL": "belt force limiter (workbook PRE-TENSIONER ADAPTIVE LOAD LIMITER; bench squibs_config DBFL / PBFL)",
    "PRC": "pelvis restraint cushion",
    "PYRO": "pyrotechnic",
    "SW": "switch",
    "DIS": "disable",
    "EN": "enable / enabled",
    "FRSU": "front remote sensing unit (crash satellite)",
    "SRSU": "side remote sensing unit (crash satellite)",
    "RSU": "remote sensing unit (crash satellite)",
    "PRES": "pressure",
    "SNS": "sensor",
    "BKL": "seat belt buckle switch (DCS channel)",
    "ODS": "occupant detection sensor",
    "STPS1": "seat track position sensor 1",
    "STPS2": "seat track position sensor 2",
    "OFF": "off",
    "ON": "on",
    "LMP": "lamp",
    "LED": "light-emitting diode output",
    "CRASH": "crash",
    "OUT": "hardwired output line",
    "ECALL": "emergency call (eCall)",
    "SBR": "seat belt reminder",
    "ACN": "automatic crash notification",
    "LOOP": "deployment (squib) loop",
    "DCS": "buckle switch input (DCS)",
    "GPO": "general purpose output",
    "AWL": "airbag warning lamp",
    "FAIL": "failure",
    "VBAT": "battery supply voltage",
    "UV": "under-voltage",
    "OV": "over-voltage",
    "ECU": "airbag control unit",
    "LOCK": "ECU locked after a crash (permanent)",
    "ROLLOVER": "roll-over",
    "UNDERSTRIKE": "under-body strike",
    "DEPLOY": "deployment",
    "PLANT": "plant (production)",
    "MODE": "mode",
    "SCRAP": "vehicle scrapping",
    "SVD": "SVD function (workbook term; its expansion is not given)",
    "EDR": "event data recorder",
    "RECORD": "record",
    "FULL": "full",
    "CAL": "calibration",
    "MISSING": "missing",
    "INCORRECT": "incorrect",
    "IMU": "inertial measurement unit (on-board)",
    "CRC": "cyclic redundancy check",
    "SPI": "serial peripheral interface",
    "ERR": "error",
    "CNT": "counter",
    "SELF": "self",
    "TEST": "test",
    "RECOV": "recoverable",
    "INTEGRITY": "data integrity check",
    "SEV": "SEV1 / SEV2 / SEV3 failure",
    "OOR": "out of range",
    "X": "X axis",
    "Y": "Y axis",
    "Z": "Z axis",
    "YAW": "yaw",
    "ROLL": "roll",
    "PITCH": "pitch",
    "TEMP": "temperature",
    "STG": "short circuit to ground (SAE J2012-DA FTB 0x11)",
    "STB": "short circuit to battery (FTB 0x12)",
    "OPEN": "open circuit (FTB 0x13)",
    "RES": "circuit resistance: RES_LOW below threshold (FTB 0x1A), RES_HIGH above threshold (FTB 0x1B), "
           "RES_OOR out of range (FTB 0x1E)",
    "LOW": "low / below threshold",
    "HIGH": "high / above threshold",
    "XCONN": "cross connection with another channel or sensor (FTB 0x2B signal cross coupled; the "
             "workbook uses 0x01 for squib loops)",
    "UNEXPECTED": "connected although the configuration says not fitted (workbook FTB 0x64)",
    "LOAD": "load",
    "CONFIG": "configuration error: device and EOL configuration disagree (workbook FTB 0x64)",
    "COMM": "communication error: invalid serial data received (FTB 0x81)",
    "INTERNAL": "internal failure (FTB 0x96 component internal failure; 0x49 for the ECU)",
    "SAMPLE": "sampling",
    "RATE": "rate",
    "RAILED": "output railed: stuck at its limit (workbook FTB 0x87)",
    "UNCONF": "unconfirmed",
    "NODE": "CAN node",
    "ABSENT": "absent: its key message is missing",
    "MTO": "message timeout: a non-key message is missing",
    "MCF": "message content failure: wrong DLC, CRC or alive counter",
    "SCF": "signal content failure: invalid signal value",
    "SRS": "the SRS ECU itself",
    "HSCAN": "high-speed CAN",
    "BUS": "bus",
    "VIN": "vehicle identification number",
    "MISMATCH": "mismatch",
    "VARIANT": "variant",
    "CODE": "code",
    "FEATURE": "feature",
}

# Device (location + component) per DTC base, for the device groups. Bench names in comments.
DEVICE_BY_BASE = {
    "B0001": "DAB", "B1261": "DAB_AV", "B18F1": "DAB_AV", "B0010": "PAB", "B1262": "PAB_AV", "B18FD": "PAB_AV",
    "B0070": "RH_PT", "B0072": "LH_PT",                         # bench RPT / LPT
    "B1263": "RH_BFL", "B1264": "LH_BFL",                       # bench DBFL / PBFL
    "B1203": "RH_LAP_PT", "B1204": "LH_LAP_PT",                 # bench RLPT / LLPT
    "B1206": "RH_SAB", "B1208": "LH_SAB",                       # bench RSA / LSA
    "B1207": "RH_IC", "B1209": "LH_IC",                         # bench RCA / LCA
    "B1211": "DRV_KAB", "B1233": "CTR_FSAB",                    # bench DKA / CAB
    "B190F": "R2_RH_PT", "B1914": "R2_LH_PT",                   # bench R2RPT / R2LPT
    "B1910": "DRV_PRC", "B1911": "PSG_PRC", "B1912": "PYRO_SW",
    "B0090": "LH_FRSU", "B0095": "RH_FRSU",
    "B120A": "LH_BPLR_SRSU", "B120B": "RH_BPLR_SRSU", "B121B": "LH_CPLR_SRSU", "B121C": "RH_CPLR_SRSU",
    "B1236": "LH_APLR_SRSU", "B1240": "LH_APLR_SRSU", "B1237": "RH_APLR_SRSU", "B1239": "RH_APLR_SRSU",
    "B120D": "LH_SRSU", "B120E": "RH_SRSU", "B1238": "REAR_RSU", "B1252": "UB_SNS",
    "B1212": "LH_PRES_SNS", "B1216": "RH_PRES_SNS",
    "B1033": "DRV_BKL", "B1253": "DRV_BKL", "B1032": "PSG_BKL", "B1254": "PSG_BKL",
    "B1242": "R2_LH_BKL", "B1257": "R2_LH_BKL", "B1243": "R2_RH_BKL", "B1255": "R2_RH_BKL",
    "B1244": "R2_MID_BKL", "B1256": "R2_MID_BKL", "B1245": "R3_LH_BKL", "B1259": "R3_LH_BKL",
    "B1246": "R3_RH_BKL", "B1258": "R3_RH_BKL",
    "B18F4": "R2_LH_ODS", "B18F5": "R2_RH_ODS", "B18F6": "R2_MID_ODS", "B18F7": "R3_LH_ODS", "B18F8": "R3_RH_ODS",
    "B1913": "PSG_ODS",
    "B18F9": "DRV_STPS1", "B18FA": "DRV_STPS2", "B18FB": "PSG_STPS1", "B18FC": "PSG_STPS2",
    "B1205": "PAB_DIS_SW", "B120C": "PAB_DIS_SW", "B1241": "PAB_EN_SW",   # bench eol_config PABD_SWITCH = B1205
    "B1210": "PAB_OFF_LMP", "B1024": "PAB_ON_LED", "B1218": "CRASH_OUT",   # bench gpo PAB_OFF / PAB_ON / ENS
    "B190E": "ECALL_OUT", "B120F": "PSG_SBR_LMP", "B1213": "ACN_OUT",
    "B1919": "LOOP", "B191A": "DCS", "B191B": "RSU", "B191C": "GPO",
}

FAULT_SUFFIX = {
    "STG": "STG", "STB": "STB", "OPEN": "OPEN", "STG_OR_OPEN": "STG_OPEN", "LOW_RES": "RES_LOW",
    "HIGH_RES": "RES_HIGH", "INVALID_RES": "RES_OOR", "CROSS_CONNECT": "XCONN", "SHORT_TO_OTHER_SENSOR": "XCONN",
    "UNEXPECTED_SQUIB": "UNEXPECTED", "UNEXPECTED_LOAD": "UNEXPECTED_LOAD", "CONFIG_ERROR": "CONFIG",
    "COMM_ERROR": "COMM", "INTERNAL": "INTERNAL", "SAMPLING_RATE": "SAMPLE_RATE", "OUTPUT_RAILED": "RAILED",
    "UNCONFIRMED_CRASH": "UNCONF_CRASH",
}

# DTCs of the non-device groups, named one by one.
NAME_BY_DTC = {
    "B101349": "ECU_INTERNAL", "B142A16": "VBAT_UV", "B142A17": "VBAT_OV", "B00D200": "AWL_FAIL",
    "B106196": "ECU_LOCK_FRONT", "B191600": "ECU_LOCK_RH_SIDE", "B120100": "ECU_LOCK_LH_SIDE",
    "B121E00": "ECU_LOCK_REAR", "B191500": "ECU_LOCK_ROLLOVER", "B121A00": "ECU_LOCK_PT_DEPLOY",
    "B125200": "ECU_LOCK_UNDERSTRIKE", "B120000": "ECU_PLANT_MODE", "B120200": "ECU_CONFIG",
    "B121300": "LOOP_SCRAP_EN", "B121400": "LOOP_SVD_DEPLOY", "B121500": "EDR_RECORD_FULL",
    "B124700": "CAL_MISSING", "B124800": "CAL_INCORRECT",
    "B121F00": "IMU_CRC_ERR_CNT", "B122000": "IMU_SPI_ERR_CNT", "B122100": "IMU_SELF_TEST",
    "B122200": "IMU_INTERNAL", "B122300": "IMU_INTERNAL_RECOV", "B122400": "IMU_CAL_INTEGRITY",
    "B122500": "IMU_SEV_X", "B122600": "IMU_SEV_Y", "B122700": "IMU_SEV_Z", "B122800": "IMU_SEV_YAW",
    "B122900": "IMU_SEV_ROLL", "B122A00": "IMU_SEV_PITCH", "B122B00": "IMU_SEV_TEMP",
    "B122C00": "IMU_OOR_X", "B122D00": "IMU_OOR_Y", "B122E00": "IMU_OOR_Z", "B122F00": "IMU_OOR_YAW",
    "B123000": "IMU_OOR_ROLL", "B123100": "IMU_OOR_PITCH", "B123200": "IMU_OOR_TEMP",
    "U120600": "SRS_BUS_OFF", "U127100": "HSCAN_BUS_OFF", "U130600": "SRS_VIN_MISMATCH",
    "U150600": "SRS_VARIANT_CODE_ERR", "U280600": "SRS_FEATURE_CODE_ERR",
}

# Names that needed a judgement; a location word that the description does not carry needs a note here.
NAMING_NOTES = {
    "B009097": "Description reads 'UNCONFIRMED CRASH CoRIGHT FRSU'; named LH from its DTC base B0090, which the "
               "lists use for the LEFT FRSU (inference).",
    "B120D97": "Description reads 'UNCONFIRMED CRASH CoRIGHT SRSU' and B120D has no other DTC; named LH like "
               "B009097 'CoRIGHT FRSU' of the LEFT FRSU base (inference). No pillar given.",
    "B120E97": "No pillar given in the description; B120E has no other DTC.",
    "B12411B": "Description reads 'PASSENGER AIRBAG SWITCH-HIGH RESISTANCE' without ENABLE; named from its DTC "
               "base B1241, the PAB enable switch.",
    "B120C1A": "DTC base B120C; named with the B1205 PAB (disable) switch, both 'PASSENGER AIRBAG SWITCH'.",
    "B120C1B": "DTC base B120C; named with the B1205 PAB (disable) switch, both 'PASSENGER AIRBAG SWITCH'.",
    "B120C1E": "DTC base B120C; named with the B1205 PAB (disable) switch, both 'PASSENGER AIRBAG SWITCH'.",
    "B12392B": "DTC base B1239, not B1237 like the other A-pillar right SRSU DTCs; same satellite by its "
               "description.",
    "B12402B": "DTC base B1240, not B1236 like the other A-pillar left SRSU DTCs; same satellite by its "
               "description.",
    "B123200": "Description reads 'Out of Range failure on YAW Temperature'; named for temperature like B122B00 "
               "(inference).",
}

# Location words of a mnemonic and the description text that must back each one.
LOCATION_WORDS = {
    "DRV": r"(?<!CO-)(?<!CO )(?<!CO)DRIVER", "PSG": r"PASSENGER|CO[- ]?DRIVER", "LH": r"\bLEFT\b",
    "RH": r"\bRIGHT\b", "R2": r"\b(2ND|SECOND) ROW", "R3": r"\b(3RD|THIRD) ROW", "MID": r"\bMIDDLE\b",
    "CTR": r"\bCENT(ER|RE)\b",
}


def can_name(key: str, kind: str, description: str) -> str:
    """CAN DTCs keep the node, frame or signal name of the workbook (= DBC name)."""
    if kind in ("NODE_ABSENT", "MESSAGE_TIMEOUT"):
        node = re.sub(r"[^A-Z0-9_]", "", description.split()[0].upper())
        return f"{node}_{'NODE_ABSENT' if kind == 'NODE_ABSENT' else 'MTO'}"
    if kind == "MESSAGE_CONTENT":
        frame = re.match(r"[A-Za-z0-9_]+", description)
        if frame:
            return f"{frame.group(0).upper()}_MCF"
    if kind == "SIGNAL_CONTENT":
        signal = re.match(r"(.+?)\s+signal", description, re.IGNORECASE)
        if signal:
            return re.sub(r"[^A-Z0-9]+", "_", signal.group(1).upper()).strip("_") + "_SCF"
    raise SystemExit(f"{key} '{description}': no CAN naming rule - add it to NAME_BY_DTC")


DTC_TYPE = {"P": "P (Powertrain)", "C": "C (Chassis)", "B": "B (Body)", "U": "U (Network)"}   # SAE J2012 letter


def lamp_state(value):
    """Workbook 'Warning Lamp Status Active Status' -> ON / OFF / FLASHING_1HZ, None for NA or blank."""
    if isinstance(value, dict):
        return {variant: lamp_state(text) for variant, text in value.items()}
    if value in (1, "1"):
        return "ON"
    if value in (0, "0"):
        return "OFF"
    if isinstance(value, str) and re.search(r"flash", value, re.IGNORECASE) and re.search(r"1\s*hz", value, re.I):
        return "FLASHING_1HZ"
    return None


def to_ms(value) -> int | float | None:
    """'2000ms' / '1.5 Sec' / '30s' -> ms; None for anything that is not a plain time with a unit."""
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(ms|s|sec)", str(value or "").strip(), re.IGNORECASE)
    if not match:
        return None
    ms = float(match.group(1)) * (1 if match.group(2).lower() == "ms" else 1000)
    return int(ms) if ms.is_integer() else ms


def build_fault_list(dictionary: dict) -> tuple[list[tuple[str, dict]], dict, dict]:
    """(name, fields) per DTC in dictionary order, naming notes per name, and the DTCs that share a fault."""
    names, groups = {}, {}
    for key, entry in dictionary.items():
        description = entry["description"] if isinstance(entry["description"], str) else entry["description"]["ICE"]
        group, kind = classify(key, description)
        groups[key] = group
        if key in NAME_BY_DTC:
            names[key] = NAME_BY_DTC[key]
        elif group == "CAN":
            names[key] = can_name(key, kind, description)
        elif key[:5] not in DEVICE_BY_BASE or kind not in FAULT_SUFFIX:
            raise SystemExit(f"{key} '{description}': no device name for base {key[:5]} or no suffix for {kind}")
        else:
            names[key] = f"{DEVICE_BY_BASE[key[:5]]}_{FAULT_SUFFIX[kind]}"

    # Two DTCs of one fault: the DTC of the device's main base keeps the name, the other gets its base added.
    base_size = Counter(key[:5] for key in dictionary)
    order = {key: index for index, key in enumerate(dictionary)}
    shared = {}
    for name in [n for n, count in Counter(names.values()).items() if count > 1]:
        keys = sorted((k for k in names if names[k] == name), key=lambda k: (-base_size[k[:5]], order[k]))
        shared[name] = keys
        for key in keys[1:]:
            names[key] = f"{name}_{key[:5]}"

    notes = {names[key]: note for key, note in NAMING_NOTES.items() if key in names}
    for name, keys in shared.items():
        for key in keys[1:]:
            notes[names[key]] = (f"Same fault as {keys[0]} ({name}); named with its DTC base added. See "
                                 f"DTC_LIST_CONFLICTS.md.")

    faults, seen = [], set()
    for key, entry in dictionary.items():
        name, how = names[key], entry["how_to_create"]
        if not re.fullmatch(NAME_PATTERN, name) or len(name) > MAX_NAME or name in seen or name in MODULE_NAMES:
            raise SystemExit(f"{key}: mnemonic {name!r} breaks the naming rules (pattern, <= {MAX_NAME} characters, "
                             f"unique)")
        seen.add(name)
        if groups[key] != "CAN":
            unknown = [word for word in name.split("_") if word not in VOCABULARY
                       and not re.fullmatch(r"[BCPU][0-9A-F]{4}", word)]
            if unknown:
                raise SystemExit(f"{key}: mnemonic {name} uses {unknown}, which are not in VOCABULARY")
        description = str(entry["description"]).upper()
        for word, pattern in LOCATION_WORDS.items():
            if word in name.split("_") and not re.search(pattern, description) and key not in NAMING_NOTES:
                raise SystemExit(f"{key}: mnemonic {name} says {word} but the description '{description}' "
                                 f"does not - fix the name or add a NAMING_NOTES entry")

        def text(value):
            return value if value is None or isinstance(value, (str, dict)) else str(value)

        tolerance = re.fullmatch(r"(\d+(?:\.\d+)?)%", str(how["time_tolerance"] or ""))
        faults.append((name, {
            "dtc_hex": entry["dtc_hex"],
            "applicable_to": entry["applicable_to"],
            "mnemonic": name,
            "short_notation": f"{key[:5]}-{key[5:]}",
            "dtc_type": DTC_TYPE[key[0]],
            "ftb": f"0x{key[5:]}",
            "fault_type": entry["fault_type"],
            "set_condition": how["set_condition"],
            "heal_condition": how["heal_condition"],
            "memory": entry["memory"],
            "time_tolerance_pct": (int(float(tolerance.group(1))) if float(tolerance.group(1)).is_integer()
                                   else float(tolerance.group(1))) if tolerance else None,
            "mature_time": text(how["mature_time"]),
            "mature_time_ms": to_ms(how["mature_time"]),
            "demature_time": text(how["demature_time"]),
            "demature_time_ms": to_ms(how["demature_time"]),
            "precondition": how["precondition"],
            "ageing_cycles": entry["ageing_cycles"] if isinstance(entry["ageing_cycles"], int) else None,
            "warning_lamp": lamp_state(entry["warning_lamp"]),
            "group": entry["group"],
            "description": entry["description"],
        }))
    return faults, notes, shared


def render_fault_list_block(faults: list[tuple[str, dict]], notes: dict, infos: dict) -> str:
    """The common DTC section: identical in common_fault_list.py and in every project's fault_list_config.py."""
    used = {word for name, _ in faults for word in name.split("_")}
    applicability = Counter(len(fields["applicable_to"]) for _, fields in faults)
    rule = f"# {'=' * 100}"
    lines = [
        rule,
        "# Common EV / ICE DTC list: one dict per DTC, named by the DTC's mnemonic",
        rule,
        "# Sources: " + "; ".join(f"{info['path']} (sheet '{info['sheet']}')" for info in infos.values()),
        "# Built with tools/build_common_dtc_dictionary.py; rebuild it there rather than edit by hand. What each",
        "# DTC is and how to create it: docs/project_documents/Common_DTC_List/common_dtc_dictionary.py;",
        "# workbook conflicts: docs/project_documents/Common_DTC_List/DTC_LIST_CONFLICTS.md.",
        f"# {len(faults)} DTCs: {applicability[2]} for EV and ICE, "
        f"{sum(1 for _, f in faults if f['applicable_to'] == ('EV',))} EV only, "
        f"{sum(1 for _, f in faults if f['applicable_to'] == ('ICE',))} ICE only.",
        "#",
        "# Fields of each DTC:",
        "#   dtc_hex             3-byte DTC as ISO 14229-1 reports it (e.g. 0x800111)",
        "#   applicable_to       ('EV', 'ICE'), ('EV',) or ('ICE',)",
        "#   mnemonic            the dict's own name (naming rules below)",
        "#   short_notation      SAE J2012 five-character DTC, '-', failure type byte (e.g. B0001-11)",
        "#   dtc_type            SAE J2012 system letter: B (Body), C (Chassis), P (Powertrain), U (Network)",
        "#   ftb                 failure type byte, SAE J2012-DA (e.g. 0x11)",
        "#   fault_type          what fails, in words",
        "#   set_condition, heal_condition, precondition: the workbook's text",
        "#   memory              where the DTC is stored (workbook RAM / EEPROM / Other)",
        "#   time_tolerance_pct  mature / demature time tolerance in percent (None: '-' or blank)",
        "#   mature_time, demature_time: the workbook's text; mature_time_ms / demature_time_ms the same in ms,",
        "#                       None where the workbook gives no plain time (NA, Immediate, 1 IGN Cycle,",
        "#                       within PDC(...), network management sheet, a number without unit)",
        "#   ageing_cycles       IGN cycles a healed DTC stays stored before it ages out (None: NA or blank)",
        "#   warning_lamp        airbag warning lamp while the DTC is active: 'ON', 'OFF', 'FLASHING_1HZ'",
        "#                       (None: NA or blank in the workbook)",
        "#   group               device group",
        "#   description         workbook description, for traceability",
        "# A field where the EV and ICE lists disagree holds {'EV': ..., 'ICE': ...}.",
        "#",
        "# Naming rules (ISO 26262-6 asks for naming conventions in the coding guidelines but prescribes no DTC",
        "# names; these are the ones applied and checked by the build):",
        "# - Mnemonic = <LOCATION>_<COMPONENT>_<FAULT>, e.g. R2_LH_PT_STB: location and component from the",
        "#   workbook description, fault from the DTC's failure type (SAE J2012-DA FTB names where the workbook",
        "#   uses the FTB that way). CAN DTCs: <NODE>_NODE_ABSENT, <NODE>_MTO, <FRAME>_MCF, <SIGNAL>_SCF with the",
        "#   workbook's (DBC) node, frame or signal name.",
        f"# - Upper-case words joined by '_', letters and digits only, at most {MAX_NAME} characters (MISRA C:2012",
        "#   rule 5.1), unique: usable unchanged as a C symbol or AUTOSAR SHORT-NAME (e.g. a DEM event).",
        "# - Every word comes from MNEMONIC_GLOSSARY (CAN frame and signal names excepted); every location word",
        "#   (DRV, PSG, LH, RH, R2, R3, MID, CTR) is backed by the description, or explained in NAMING_NOTES.",
        "# - Two DTCs for the same fault: the one of the device's main DTC base keeps the name, the other gets its",
        "#   DTC base appended (NAMING_NOTES).",
        "# - Field names are lower-case snake_case and carry their unit when numeric (_ms, _pct, ageing_cycles).",
        rule,
        "",
        "MNEMONIC_GLOSSARY = {",
        *[f"    {literal(word, 0)}: {literal(meaning, 0)}," for word, meaning in VOCABULARY.items() if word in used],
        "}",
        "",
        "NAMING_NOTES = {",
        *[f"    {literal(name, 0)}: {literal(note, 0)}," for name, note in notes.items()],
        "}",
        "",
    ]
    for name, fields in faults:
        lines += [f"# {fields['dtc_type'][0]} code - {fields['dtc_type'][3:-1]}: {fields['short_notation']}",
                  f"{name} = {literal(fields, 0)}", ""]
    lines += ["COMMON_FAULT_LIST = (", *[f"    {name}," for name, _ in faults], ")", "",
              'FAULT_BY_DTC_HEX = {fault["dtc_hex"]: fault for fault in COMMON_FAULT_LIST}',
              "",
              "",
              "def faults_for(vehicle):",
              '    """Faults that apply to vehicle \'EV\' or \'ICE\' (its own list plus the common ones)."""',
              "    vehicle = vehicle.upper()",
              "    if vehicle not in (\"EV\", \"ICE\"):",
              "        raise ValueError(f\"vehicle must be 'EV' or 'ICE', not {vehicle!r}\")",
              "    return [fault for fault in COMMON_FAULT_LIST if vehicle in fault[\"applicable_to\"]]",
              ""]
    return "\n".join(lines)


def render_fault_list(faults: list[tuple[str, dict]], notes: dict, infos: dict) -> str:
    return "\n".join([
        '"""',
        "Common fault list: EV + ICE",
        "",
        "Every DTC of the EV and ICE DTC lists as one dict, named by the DTC's mnemonic. The same section is in",
        "every project's config/fault_list_config.py; the fields and naming rules are described below.",
        "Built with tools/build_common_dtc_dictionary.py; rebuild it there rather than edit by hand.",
        '"""',
        "",
        render_fault_list_block(faults, notes, infos),
    ])


# Projects whose config/fault_list_config.py carries the common DTC section, and their vehicle type.
# M310_M314_M110, U171, Z121: edr_config.VEHICLE_CLASS; UPP_EV, W610 (EV) and W616 (ICE): the user, 2026-10-22.
# M210 (EV, its own M210 DBC): the user, 2026-10-22 ("separate configs for EVs as the dbc are different").
PROJECT_VEHICLE = {"M310_M314_M110": "EV", "M210": "EV", "UPP_EV": "EV", "W610": "EV", "U171": "ICE", "Z121": "ICE",
                   "W616": "ICE"}
# The EV projects' fault_list_config.py (M310_M314_M110, M210: the EV fault list is common, user
# 2026-10-22) is written by tools/build_m310_fault_list_config.py, which appends fault_list_settings()
# and render_fault_list_block() after the fault list.
OWN_BUILDER = {"M310_M314_M110", "M210"}


def fault_list_settings(project: str) -> list[str]:
    """Fault_List module settings the per-DTC scripts read (the same keys in every project)."""
    lag_note = ("canc_config.FAULT_TIME_MEASUREMENT_LAG_MS, measured on this bench" if project == "M310_M314_M110"
                else "not measured on this bench: the upper timing limit gets no lag allowance")
    lag = 60 if project == "M310_M314_M110" else 0
    return [
        "# Vehicle type: the per-DTC scripts cover faults_for(VEHICLE_TYPE).",
        f'VEHICLE_TYPE = "{PROJECT_VEHICLE[project]}"',
        "# IGN OFF time of one ignition cycle (PS.IGN_OFF, wait, PS.IGN_ON) - the 4 s of PS.Power_Cycle.",
        "IGN_OFF_TIME_MS = 4000",
        "# Read interval while waiting for the warning lamp to change.",
        "LAMP_POLL_INTERVAL_MS = 10",
        f"# faultTimeMeasurement sees a DTC change at most this late ({lag_note}).",
        f"FAULT_TIME_MEASUREMENT_LAG_MS = {lag}",
    ]


def render_project_fault_list(project: str, faults, notes, infos) -> str:
    return "\n".join([
        '"""',
        "Module Configuration: Fault_List",
        f"Project: {project}",
        "=" * 60,
        "",
        f"Location: projects/{project}/config/fault_list_config.py",
        "",
        "The common EV / ICE DTC list (one dict per DTC, named by its mnemonic) and the Fault_List settings of",
        "the per-DTC scripts. Built with tools/build_common_dtc_dictionary.py; rebuild it there rather than",
        "edit by hand.",
        '"""',
        "",
        f'PROJECT_NAME = "{project}"',
        'MODULE_NAME = "Fault_List"',
        "",
        "ENABLED = True",
        "TIMEOUT_SECONDS = 30",
        "RETRY_COUNT = 1",
        "",
        "# ── Fault_List Settings ──",
        "MONITOR_INTERVAL = 0.5",
        "AUTO_CLEAR_ON_START = True",
        *fault_list_settings(project),
        "",
        "",
        render_fault_list_block(faults, notes, infos),
    ])


def project_config_path(project: str) -> Path:
    return ROOT / "projects" / project / "config" / "fault_list_config.py"


def common_section(project: str) -> str:
    """Fault_List settings + common DTC section, for a project whose fault_list_config.py has its own builder."""
    dictionary, infos, _ = build()
    faults, notes, _ = build_fault_list(dictionary)
    return "\n".join([*fault_list_settings(project), "", "", render_fault_list_block(faults, notes, infos)])


# ---------------------------------------------------------------------------
# Conflicts for review (DTC_LIST_CONFLICTS.md)
# ---------------------------------------------------------------------------

CONFLICT_TITLES = {
    "foreign_set": "Set condition describes a different fault",
    "code": "DTC code cells that disagree with DTC + FTB",
    "crash_word": "Crash lock: description and set condition name different crashes",
    "heal_same": "Heal condition uses the same comparison as the set condition",
    "config_open": "Configuration error rows whose set condition reads like an open circuit",
    "ev_flag": "EV applicability cell (M312/M112/W613/M314) blank",
    "no_set": "No set condition (blank or NA)",
    "duplicate_fault": "Two DTCs for the same fault",
}

# Evidence from other documents, shown under the conflict of that DTC.
NOTES = {
    "B123313": "The ICE common diag spec (docs/project_documents/Common Diag Spec/ICE_COMMON_SRS_V1.6_DIAG_RE.md, "
               "DTC List row 246) has the same B123413 next to hex 923313, and its version history (v1.3) lists "
               "B123313 among the DTCs 'corrected/updated'.",
}


def md(value) -> str:
    """Markdown table cell."""
    if value is None or value == "":
        return "_blank_"
    if isinstance(value, dict):
        return "<br>".join(f"{variant}: {md(text)}" for variant, text in value.items())
    return str(value).replace("|", "\\|")


def table(header: list[str], rows: list[list]) -> list[str]:
    lines = ["| " + " | ".join(header) + " |", "|" + "|".join(["---"] * len(header)) + "|"]
    return lines + ["| " + " | ".join(md(cell) for cell in row) + " |" for row in rows] + [""]


def where(items: list[dict]) -> str:
    return ", ".join(f"{item['variant']} row {item['row']} (S.No {item['s_no']})" for item in items)


def per_dtc(items: list[dict], fields: list[str]) -> list[list[dict]]:
    """Conflicts of one category, EV and ICE on one line where they read the same."""
    groups: dict[tuple, list[dict]] = {}
    for item in items:
        groups.setdefault((item["dtc"],) + tuple(repr(item.get(field)) for field in fields), []).append(item)
    return list(groups.values())


def render_conflicts(dictionary: dict, infos: dict, conflicts: list[dict]) -> str:
    by_category = {category: [c for c in conflicts if c["category"] == category] for category in CONFLICT_TITLES}
    foreign, shifted = shifted_blocks(conflicts)
    both = [key for key, entry in dictionary.items() if entry["applicability"] == "BOTH"]
    differences = [(key, field, value) for key in both
                   for field, value in {**dictionary[key], **dictionary[key]["how_to_create"]}.items()
                   if field != "source" and isinstance(value, dict) and set(value) == {"EV", "ICE"}]
    can_both = [key for key in both if key.startswith("U")]
    ev, ice = infos["EV"], infos["ICE"]

    def desc(key):
        value = dictionary[key]["description"]
        return value if isinstance(value, str) else value.get("ICE") or value.get("EV")

    def rows_of(key):
        return ", ".join(f"{variant} row {src['row']}" for variant, src in dictionary[key]["source"].items())

    def set_of(key):
        value = dictionary[key]["how_to_create"]["set_condition"]
        return value if isinstance(value, str) else None

    def kind_of(key):
        return classify(key, desc(key))[1]

    def peer_text(key):
        """Most common set condition of the other DTCs of the same group and fault type that fits it."""
        kind, entry = kind_of(key), dictionary[key]
        texts = Counter(set_of(other) for other, peer in dictionary.items()
                        if other != key and peer["group"] == entry["group"]
                        and peer["fault_type"] == entry["fault_type"] and set_kind(set_of(other)) == kind)
        if not texts:
            return "no other row of this fault type"
        text, count = texts.most_common(1)[0]
        return f"{text} ({count} row{'s' if count > 1 else ''})"

    lines = [
        "# EV / ICE DTC list conflicts",
        "",
        "Contradictions and gaps in the two DTC list workbooks, found while building",
        "`common_dtc_dictionary.py`. The dictionary does not correct them: each DTC keeps the workbook text",
        "and lists its issues under `workbook_issues`.",
        "",
        f"- EV: `{ev['path']}`, sheet '{ev['sheet']}'",
        f"- ICE: `{ice['path']}`, sheet '{ice['sheet']}'"
        + (f" - saved with a filter ({ice['filter']}) that hides {ice['hidden_rows']} rows: clear it to see the "
           f"rows quoted here" if ice["hidden_rows"] else ""),
        "",
        "Rows are Excel row numbers; S.No is the workbook's own serial number. Workbook text is quoted as",
        "read (only line breaks and repeated blanks normalised). Columns headed *Reads as* or *Likely* are the",
        "build's reading of the text (inference) - confirm them with the owner of the DTC list.",
        "",
        "Built with tools/build_common_dtc_dictionary.py; rebuild it there rather than edit by hand.",
        "",
        "## Summary",
        "",
    ]
    summary = []
    for number, (category, title) in enumerate(CONFLICT_TITLES.items(), start=1):
        items = by_category[category]
        summary.append([number, title, len({item["dtc"] for item in items}),
                        sum(item["variant"] == "EV" for item in items), sum(item["variant"] == "ICE" for item in items)])
    summary.append([len(CONFLICT_TITLES) + 1, "EV and ICE lists disagree on a common DTC",
                    len({key for key, _, _ in differences}), "-", "-"])
    summary.append([len(CONFLICT_TITLES) + 2, "ICE CAN rows naming EV nodes and frames", len(can_both), "-",
                    len(can_both)])
    lines += table(["#", "Conflict", "DTCs", "EV rows", "ICE rows"], summary)

    def section(number, category, intro):
        lines.extend([f"## {number}. {CONFLICT_TITLES[category]}", "", *intro, ""])
        if not by_category[category]:
            lines.extend(["None found.", ""])
            return False
        return True

    # 1. Set condition of another fault type
    if section(1, "foreign_set", [
            "The set condition names another fault type than the DTC (fact: the texts below), so it cannot be",
            "used as the recipe for that DTC. The dictionary's bench method follows the description."]):
        if shifted:
            lines += ["### Sensor blocks whose conditions look shifted by one row", "",
                      "In each sensor below several rows carry the set condition of a neighbouring fault type",
                      "(inference: the set / heal columns slipped by one row). The last column says where the text",
                      "that fits each DTC actually sits.", ""]
            for base in shifted:
                keys = [key for key in dictionary if key[:5] == base and kind_of(key) in COMPARABLE | {"CONFIG_ERROR"}]
                name = os.path.commonprefix([desc(key).upper() for key in keys]).strip(" -")
                lines += [f"#### {base}xx {name} ({dictionary[keys[0]]['applicability']}, "
                          f"{foreign[base]} DTCs affected)", ""]
                block = []
                for key in keys:
                    kind, reads = kind_of(key), set_kind(set_of(key))
                    homes = [other for other in keys if other != key and set_kind(set_of(other)) == kind]
                    home = "this row" if reads == kind else ", ".join(homes) or "nowhere in this block"
                    block.append([key, desc(key), rows_of(key), dictionary[key]["how_to_create"]["set_condition"],
                                  FAULT_TYPE[reads] if reads else "-", home])
                lines += table(["DTC", "Description", "Rows", "Set condition in the workbook", "Reads as",
                                "Text for this DTC's fault is on"], block)
        others = [group for group in per_dtc(by_category["foreign_set"], ["set_text"])
                  if group[0]["dtc"][:5] not in shifted]
        if others:
            lines += ["### Other rows", ""]
            lines += table(["DTC", "Description", "Rows", "Set condition in the workbook", "Reads as",
                            "Likely: what the other rows of this fault type say"],
                           [[g[0]["dtc"], desc(g[0]["dtc"]), where(g), g[0]["set_text"],
                             FAULT_TYPE[g[0]["describes"]], peer_text(g[0]["dtc"])] for g in others])

    # 2. DTC code cells
    if section(2, "code", [
            "The DTC key of the dictionary is DTC + FTB (columns B and C), encoded to hex per SAE J2012; these",
            "cells of the DTC (HEX) column or of the unnamed full-DTC column next to it do not match it."]):
        groups = per_dtc(by_category["code"], ["column", "cell"])
        lines += table(["DTC", "Description", "Rows", "Column", "Cell reads", "DTC + FTB give"],
                       [[g[0]["dtc"], desc(g[0]["dtc"]), where(g), g[0]["column"], g[0]["cell"], g[0]["expected"]]
                        for g in groups])
        notes = [f"- {key}: {note}" for key, note in NOTES.items() if any(g[0]["dtc"] == key for g in groups)]
        if notes:
            lines += notes + [""]

    # 3. Crash lock
    if section(3, "crash_word", ["The error reaction is quoted as well: it may carry the same copy."]):
        lines += table(["DTC", "Description", "Rows", "Set condition", "Error reaction"],
                       [[g[0]["dtc"], desc(g[0]["dtc"]), where(g), g[0]["set_text"], g[0]["reaction"]]
                        for g in per_dtc(by_category["crash_word"], ["set_text", "reaction"])])

    # 4. Heal with the set comparison
    if section(4, "heal_same", [
            "Likely the heal condition should use the opposite comparison (inference)."]):
        lines += table(["DTC", "Description", "Rows", "Set condition", "Heal condition"],
                       [[g[0]["dtc"], desc(g[0]["dtc"]), where(g), g[0]["set_text"], g[0]["heal_text"]]
                        for g in per_dtc(by_category["heal_same"], ["set_text", "heal_text"])])

    # 5. Configuration errors with an open-circuit text
    config_texts = Counter(set_of(key) for key, entry in dictionary.items()
                           if entry["fault_type"] == FAULT_TYPE["CONFIG_ERROR"] and set_of(key)
                           and set_kind(set_of(key)) != "OPEN")
    if section(5, "config_open", [
            "Other configuration-error rows say: "
            + "; ".join(f"'{text}' ({count})" for text, count in config_texts.most_common(4)) + "."]):
        lines += table(["DTC", "Description", "Rows", "Set condition", "Heal condition"],
                       [[g[0]["dtc"], desc(g[0]["dtc"]), where(g), g[0]["set_text"], g[0]["heal_text"]]
                        for g in per_dtc(by_category["config_open"], ["set_text", "heal_text"])])

    # 6. EV applicability cell
    if section(6, "ev_flag", [
            "These DTCs are in the EV list, so the dictionary marks them EV, but the EV list's own",
            "applicability column is empty for them."]):
        lines += table(["DTC", "Description", "EV row", "Also in ICE", "EV set condition"],
                       [[item["dtc"], desc(item["dtc"]), where([item]),
                         "yes" if "ICE" in dictionary[item["dtc"]]["source"] else "no",
                         dictionary[item["dtc"]]["how_to_create"]["set_condition"]]
                        for item in by_category["ev_flag"]])

    # 7. No set condition
    if section(7, "no_set", [
            "Without a set condition the workbook does not say how the DTC is created; the dictionary's bench",
            "method for these is the catalog recipe of the fault type or 'ask'. EV / ICE: what the list",
            "has (blank, NA, given) or 'not listed'."]):
        state = {(item["dtc"], item["variant"]): item["value"] for item in by_category["no_set"]}
        keys = list(dict.fromkeys(item["dtc"] for item in by_category["no_set"]))
        for group in dict.fromkeys(dictionary[key]["group"] for key in keys):
            lines += [f"### {group}", ""]
            lines += table(["DTC", "Description", "Applicability", "EV", "ICE"],
                           [[key, desc(key), dictionary[key]["applicability"],
                             *[state.get((key, variant), "given" if variant in dictionary[key]["source"]
                                         else "not listed") for variant in ("EV", "ICE")]]
                            for key in keys if dictionary[key]["group"] == group])

    # 8. Two DTCs for one fault
    if section(8, "duplicate_fault", [
            "These DTCs describe the same fault of the same device. In common_fault_list.py the DTC of the",
            "device's main DTC base keeps the mnemonic and the other one gets its DTC base appended."]):
        rows = []
        for fault in dict.fromkeys(item["fault"] for item in by_category["duplicate_fault"]):
            items = [item for item in by_category["duplicate_fault"] if item["fault"] == fault]
            for key in dict.fromkeys(item["dtc"] for item in items):
                rows.append([fault, key, desc(key), where([item for item in items if item["dtc"] == key])])
        lines += table(["Fault (mnemonic)", "DTC", "Description", "Rows"], rows)

    # 9. EV and ICE disagree
    number = len(CONFLICT_TITLES) + 1
    lines += [f"## {number}. EV and ICE lists disagree on a common DTC", ""]
    if differences:
        lines += table(["DTC", "Description", "Field", "EV", "ICE"],
                       [[key, desc(key), field, value["EV"], value["ICE"]] for key, field, value in differences])
    else:
        lines += ["None found.", ""]

    # 9. CAN rows of the ICE list
    lines += [f"## {number + 1}. ICE CAN rows naming EV nodes and frames", "",
              f"Every EV DTC is also in the ICE list with the same text, so these {len(can_both)} U-codes name",
              "EV nodes and frames (VCU, IEB, FR_ZONE, HPCC, HPCAd, EPS, OCS) in the ICE list too. Confirm the",
              "nodes and frames against the ICE DBC.", ""]
    lines += table(["DTC", "Description", "Set condition"],
                   [[key, desc(key), dictionary[key]["how_to_create"]["set_condition"]] for key in can_both])
    lines += ["## Not carried into the dictionary", "",
              "- DTC 'Priority' is NA for every DTC (its column note: all faults have the same priority).",
              "- M&M and Status are empty in both lists.",
              *[f"- {variant}: {', '.join(info['skipped'])} (skipped)." for variant, info in infos.items()
                if info["skipped"]],
              ""]
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    dictionary, infos, conflicts = build()
    faults, notes, shared = build_fault_list(dictionary)
    for fault, keys in shared.items():
        for key in keys:
            others = ", ".join(other for other in keys if other != key)
            for variant, src in dictionary[key]["source"].items():
                text = f"{variant}: same fault as {others} (both {fault} in common_fault_list.py)."
                conflicts.append({"category": "duplicate_fault", "variant": variant, "row": src["row"],
                                  "s_no": src["s_no"], "text": text, "dtc": key, "fault": fault})
                dictionary[key]["workbook_issues"].append(text)
    outputs = {OUTPUT: render(dictionary, infos, conflicts),
               FAULT_LIST: render_fault_list(faults, notes, infos),
               CONFLICTS: render_conflicts(dictionary, infos, conflicts)}
    for project in PROJECT_VEHICLE:
        if project not in OWN_BUILDER:
            outputs[project_config_path(project)] = render_project_fault_list(project, faults, notes, infos)
    for path, text in outputs.items():
        if path.suffix == ".py":
            compile(text, str(path), "exec")
    if "--check" in argv:
        stale = [path.name for path, text in outputs.items()
                 if not path.is_file() or path.read_text(encoding="utf-8") != text]
        stale = [path.relative_to(ROOT).as_posix() for path, text in outputs.items()
                 if not path.is_file() or path.read_text(encoding="utf-8") != text]
        print(f"{', '.join(stale)} differ from the DTC lists" if stale else f"{len(outputs)} files up to date")
        return 1 if stale else 0
    for path, text in outputs.items():
        path.write_text(text, encoding="utf-8", newline="\n")
    applicability = Counter(entry["applicability"] for entry in dictionary.values())
    issues = sum(1 for entry in dictionary.values() if entry["workbook_issues"])
    for variant, info in infos.items():
        print(f"{variant}: {info['rows']} DTC rows read from {info['path']}; skipped: {info['skipped'] or 'none'}")
    print(f"{len(dictionary)} DTCs written to {OUTPUT.relative_to(ROOT).as_posix()}: {dict(applicability)}; "
          f"{issues} with workbook issues")
    print(f"{len(faults)} faults written to {FAULT_LIST.relative_to(ROOT).as_posix()}; longest mnemonic "
          f"{max(len(name) for name, _ in faults)} characters; {len(notes)} naming notes")
    print("Common DTC section written to the fault_list_config.py of "
          + ", ".join(p for p in PROJECT_VEHICLE if p not in OWN_BUILDER)
          + f"; {', '.join(OWN_BUILDER)} gets it from its own builder")
    print(f"{len(conflicts)} conflicts ({dict(Counter(c['category'] for c in conflicts))}) written to "
          f"{CONFLICTS.relative_to(ROOT).as_posix()}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
