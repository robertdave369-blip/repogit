"""Write the combined ICE + EV EDR CAN-C test specification workbook.

The V4 ICE workbook is the starting point. Everything outside its EDR_CANC folder - the
crash parameters, the sensor recording, the multi-event and single-event folders - is
copied through untouched. Inside EDR_CANC the case list is rebuilt from
``tools/edr_canc_review_model.py``, which numbers every parameter's cases in review
order (comment 1) and adds what the Appendix A review asks for.

Where a case already exists its authored rows are reused, renumbered where the numbering
moved. Where a case is new its rows are derived from the same element's nominal case, so
the recording axis, the simulation windows and the value vectors are the authored ones
rather than invented. The EV cases come from the v7 common ICE/EV workbook for the fault
families it already carries, and are derived the same way for the rest.

Offline only: reads two workbooks and writes a third. Nothing here drives a bench.

Usage:
    py -3.14 tools/build_edr_canc_ice_ev_spec.py [--output PATH]
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import edr_canc_review_model as model  # noqa: E402
import edr_canc_case_text as compose  # noqa: E402

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DIRECTORY = (
    REPOSITORY_ROOT
    / "project_testcases" / "ice_common_spec" / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design" / "03_Authoring_Versions" / "V5"
)

# One workbook per tracker.
OUTPUTS = {
    "ICE": "V1.8_DES_SW_EDR_SwQTS_ICE.xlsx",
    "EV": "V1.8_DES_SW_EDR_SwQTS_EV.xlsx",
}

COLUMNS = [
    "ID", "Priority", "Name", "Description", "Pre-Action", "Post-Action",
    "Test Steps.Action", "Test Steps.Expected result", "Test Steps.Critical",
    "Test Steps.Id", "Test Parameters", "Verifies", "Status", "Type", "_Project",
    "Reviewer(s)", "_LatestResult", "_Original_Id", "Referenced Reviews", "_ScriptPath",
    "_TestType", "_VerificationMethod", "_TestTechnique",
]
COL = {name: index + 1 for index, name in enumerate(COLUMNS)}

# The sentence the review asks to be carried in the Test Step Action column rather than
# the Expected result column, for every CAN-C recording case.
DTC_READ_SENTENCE = ("Read DTC once the recording interval has completed and the fault "
                     "qualification time has elapsed.")

CRASH_DTC_TEXT = ("DTC: ECU Locked Due to Front Crash\r\nDTC Code: 90 61 96 8B\r\n\r\n"
                  "DTC: ECU Locked Due to Pretensioner Deployment\r\nDTC Code: 92 1A 00 8B")

# Voltage levels used to create the faults (power_config in each project). Stated in the
# step text so the bench operator does not have to look them up; the configuration file
# itself is never named in the specification.
UNDER_VOLTAGE_LEVEL = 6.5
OVER_VOLTAGE_LEVEL = 20.0


def _dtc_text(code: str | None, status: str) -> str | None:
    """Render a DTC the way the workbook writes it: bare hex bytes, status last."""
    if not code:
        return None
    parts = [part[2:] if part.lower().startswith("0x") else part for part in code.split()]
    suffix = status[2:] if status.lower().startswith("0x") else status
    return " ".join(parts + [suffix]).upper()


# --------------------------------------------------------------------------------------
# Reading the source workbooks
# --------------------------------------------------------------------------------------


class SourceCase:
    """One authored case: the header row's values plus every step row."""

    def __init__(self, header: dict[int, Any], steps: list[dict[int, Any]]):
        self.header = header
        self.steps = steps

    def value(self, column: str) -> Any:
        return self.header.get(COL[column])

    def clone(self) -> "SourceCase":
        return SourceCase(dict(self.header), [dict(step) for step in self.steps])


def _read_blocks(sheet, first_row: int, last_row: int) -> list[tuple[str, SourceCase]]:
    """Case blocks between two rows: a header row and the step rows that follow it."""
    blocks: list[tuple[str, SourceCase]] = []
    current: SourceCase | None = None
    name = ""
    for row in range(first_row, last_row + 1):
        values = {column: sheet.cell(row, column).value
                  for column in range(1, len(COLUMNS) + 1)}
        if values.get(COL["Name"]):
            if current is not None:
                blocks.append((name, current))
            name = str(values[COL["Name"]])
            current = SourceCase(values, [])
        elif current is not None and any(
                values.get(COL[c]) is not None
                for c in ("Test Steps.Action", "Test Steps.Expected result")):
            current.steps.append(values)
    if current is not None:
        blocks.append((name, current))
    return blocks


def read_v4(path: Path) -> dict[str, Any]:
    """The V4 workbook split into the EDR_CANC cases and everything around them."""
    import openpyxl

    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook["Export"]

    folder_rows = [row for row in range(2, sheet.max_row + 1)
                   if str(sheet.cell(row, COL["Type"]).value or "") == "Folder"]
    canc_row = next(row for row in folder_rows
                    if str(sheet.cell(row, COL["Name"]).value) == "EDR_CANC")
    next_folder = next((row for row in folder_rows if row > canc_row), sheet.max_row + 1)

    canc: dict[tuple[int, int], SourceCase] = {}
    for name, block in _read_blocks(sheet, canc_row + 1, next_folder - 1):
        match = re.match(r"SUBS_EDR_Element_ID_(.+?)_TestCase_(\d+)_(\d+)$", name)
        if match:
            canc[(int(match.group(2)), int(match.group(3)))] = block

    tail_rows = [
        {column: sheet.cell(row, column).value for column in range(1, len(COLUMNS) + 1)}
        for row in range(next_folder, sheet.max_row + 1)
    ]
    canc_folder = {column: sheet.cell(canc_row, column).value
                   for column in range(1, len(COLUMNS) + 1)}
    choices = [workbook["ChoiceValues"].cell(row, 1).value
               for row in range(1, workbook["ChoiceValues"].max_row + 1)]
    return {"canc_folder": canc_folder, "canc": canc, "tail": tail_rows, "choices": choices}


def read_v7_ev(path: Path) -> dict[tuple[str, str, str | None], SourceCase]:
    """EV cases from the v7 common workbook, keyed by parameter, fault kind and scope."""
    import openpyxl

    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook["Sheet1"]
    wanted = {parameter for _, _, parameter, _ in model.EV_GAP_ALLOCATION}

    # The v7 sheet carries an extra Applicability column at position 4, so every column
    # from Description onwards sits one to the right of the V4 layout.
    cases: dict[tuple[str, str, str | None], SourceCase] = {}
    current: SourceCase | None = None
    key: tuple[str, str, str | None] | None = None
    for row in range(2, sheet.max_row + 1):
        name = sheet.cell(row, 3).value
        if name:
            current, key = None, None
            match = re.match(r"SUBS_EDR_Element_ID_(.+?)_TestCase_(\d+)_(\d+)$", str(name))
            if not match or match.group(1) not in wanted:
                continue
            if str(sheet.cell(row, 4).value) != "EV":
                continue
            kind, scope = model._classify_description(str(sheet.cell(row, 5).value or ""))
            if kind is None:
                continue
            header = {COL["Priority"]: sheet.cell(row, 2).value}
            for offset, column in enumerate(COLUMNS[2:], start=3):
                header[COL[column]] = sheet.cell(row, offset + 1).value
            header[COL["Name"]] = str(name)
            current = SourceCase(header, [])
            key = (match.group(1), kind, scope)
            cases[key] = current
        elif current is not None:
            action = sheet.cell(row, 8).value
            expected = sheet.cell(row, 9).value
            if action is None and expected is None:
                continue
            current.steps.append({
                COL["Test Steps.Action"]: action,
                COL["Test Steps.Expected result"]: expected,
                COL["Test Steps.Critical"]: sheet.cell(row, 10).value,
                COL["Test Steps.Id"]: sheet.cell(row, 11).value,
            })
    return cases


# --------------------------------------------------------------------------------------
# Text for a case
# --------------------------------------------------------------------------------------

_ARRAY = re.compile(r"^(\s*)(Input raw CAN hex|Input raw CAN decimal|Input physical [^:]*|"
                    r"Expected recorded raw CAN hex|Expected recorded raw CAN decimal|"
                    r"Expected recorded physical [^:]*): \[([^\]]*)\]\s*$", re.M)


def _arrays(text: str) -> dict[str, list[str]]:
    """Every labelled value array in a Pre-Action or Post-Action block."""
    return {match.group(2): [value.strip() for value in match.group(3).split(",")]
            for match in _ARRAY.finditer(text or "")}


def _replace_array(text: str, label: str, values: list[str]) -> str:
    def swap(match: re.Match) -> str:
        if match.group(2) != label:
            return match.group(0)
        return f"{match.group(1)}{match.group(2)}: [{', '.join(values)}]"
    return _ARRAY.sub(swap, text or "")


def _t0_index(plan: model.ParameterPlan, count: int) -> int:
    """Index of the sample recorded at T0."""
    if plan.recording_model != "interval" or not plan.sample_range or count <= 1:
        return 0
    start = float(plan.sample_range["start"])
    step = float(plan.sample_range["step"]) or 1.0
    return max(0, min(count - 1, int(round((0.0 - start) / step))))


def _latched(values: list[str], plan: model.ParameterPlan, scope: str | None) -> list[str]:
    """What the record holds when the element stops being updated.

    The value retained is the last one received before the fault: the first sample when
    the fault covers the whole interval or its start, the value at T0 when it starts after
    the crash. Outside the fault window the recorded value is the simulated one.
    """
    if not values:
        return values
    t0 = _t0_index(plan, len(values))
    if scope == "post":
        retained = values[t0]
        return values[:t0 + 1] + [retained] * (len(values) - t0 - 1)
    retained = values[0]
    if scope == "pre":
        # A pre-crash fault covers the samples before T0; T0 records the valid value, as
        # the authored V4 cases and the scripts have it.
        return [retained] * t0 + values[t0:]
    return [retained] * len(values)


def _scope_text(plan: model.ParameterPlan, scope: str | None) -> str:
    if plan.recording_model != "interval" or not plan.sample_range or scope is None:
        return ""
    start = float(plan.sample_range["start"])
    end = float(plan.sample_range["end"])
    if scope == "pre":
        return f"only in pre crash ({start:.2f}s to T0)"
    if scope == "post":
        return f"only in post crash (T0 to {end:+.2f}s)"
    return f"in full interval ({start:.2f}s to {end:+.2f}s)"


def _description(plan: model.ParameterPlan, case: model.Case) -> str:
    label = model.KINDS[case.kind][0]
    if case.kind == "record_reserved":
        return (f"Verify every reserved byte and bit named by the diagnostic specification "
                f"records 0x00 in both EDR records, for {plan.variant}.")
    if case.kind == "record_not_configured":
        return (f"Verify every CAN-fed EDR allocation the {plan.variant} variant does not "
                f"carry records the deconfigured value in both EDR records.")
    project = "U171" if plan.variant == "ICE" else "M314"
    if case.kind == "nominal":
        return (f"Verify nominal {plan.parameter} recording in both EDR records for "
                f"{plan.variant}.")
    if case.kind == "wakeup":
        return (f"Verify {plan.parameter} recording during a crash when the ECU is woken "
                f"by CAN with hardware ignition OFF, for {plan.variant}.")
    if case.kind == "can_nm":
        return (f"Verify {plan.parameter} recording during a crash when the ECU is woken "
                f"and kept awake by the CAN NM message with hardware ignition OFF, for "
                f"{plan.variant}.")
    if case.kind in ("dbc_invalid", "dbc_out_of_range", "dbc_reserved"):
        what = {"dbc_invalid": "the DBC-defined invalid value",
                "dbc_out_of_range": "a DBC-encodable value above the valid range",
                "dbc_reserved": "a DBC reserved value"}[case.kind]
        return (f"Verify {plan.parameter} recording for {what} in {plan.variant} "
                f"({project}).")
    scope = _scope_text(plan, case.scope)
    if scope:
        return (f"Verify {plan.parameter} recording when {label} is applied {scope} for "
                f"{plan.variant} ({project}).")
    return f"Verify {plan.parameter} recording when {label} is applied for {plan.variant} ({project})."


def _fault_target(plan: model.ParameterPlan, kind: str) -> str:
    if plan.variant == "EV":
        target = _ev_fault_target(plan, kind)
        if target is not None:
            return target
    if kind == "node_absent":
        return (f"3. Fault injection target for Node Absent:\r\n"
                f"Key message: {plan.key_frame}")
    if kind == "message_timeout":
        target = f"3. Fault injection target for Message Timeout:\r\nSignal-carrying message: {plan.timeout_frame}"
        if plan.timeout_frame != plan.frame:
            target += (f"\r\nNote: {plan.timeout_frame} does not carry {plan.frame}, so "
                       f"{plan.canc_signal} keeps being received and the record holds its "
                       f"normal valid value while the timeout DTC qualifies.")
        return target
    if kind == "under_voltage":
        return (f"3. Fault injection target for Under Voltage:\r\n"
                f"Supply voltage driven to {UNDER_VOLTAGE_LEVEL:.1f} V, below the "
                f"undervoltage threshold. The CAN signal keeps "
                f"transmitting its simulated values throughout.")
    if kind == "over_voltage":
        return (f"3. Fault injection target for Over Voltage:\r\n"
                f"Supply voltage driven to {OVER_VOLTAGE_LEVEL:.1f} V, above the "
                f"overvoltage threshold. The CAN signal keeps "
                f"transmitting its simulated values throughout.")
    if kind == "signal_never_received":
        return (f"3. Fault injection target for Signal Never Received:\r\n"
                f"Node bit for {plan.key_frame} cleared in the variant code, then one "
                f"ignition cycle.")
    if kind == "variant_code_error":
        return (f"3. Fault injection target for Variant Code Error:\r\n"
                f"Variant code disabled, then one ignition cycle.")
    return ""


_CONFIGS: dict[str, Any] | None = None


def _configs() -> dict[str, Any]:
    """The project configurations, loaded once per run."""
    global _CONFIGS
    if _CONFIGS is None:
        _CONFIGS = model.load_configs()
    return _CONFIGS


def _ev_fault_target(plan: model.ParameterPlan, kind: str) -> str | None:
    """Step 3 of an EV case's Pre-Action for the families the shared text does not cover.

    Read from the M314 configuration the EV scripts read, so the specification names the
    same frame, signal and code the script drives. None means: use the shared text.
    """
    configs = _configs()
    definition = configs["m314_signals"].get(plan.canc_signal) or {}
    fault_logic = definition.get("fault_logic") or {}
    canc = configs.get("m314_canc")
    setting = (lambda name: getattr(canc, name, None)) if canc else (lambda name: None)
    if kind == "signal_content":
        invalid = (definition.get(f"TestCase_{plan.signal}_Invalid_Values") or [None])[0]
        text = (f"3. Fault injection target for Signal Content:\r\n"
                f"Signal-carrying message: {plan.frame}\r\n"
                f"DBC invalid code driven on {definition.get('signal')}: "
                f"0x{int(invalid or 0):X} ({invalid} decimal)")
        if not fault_logic.get("signal_content_failure_dtc"):
            text += ("\r\nNote: the EV DTC list defines no signal content failure DTC for "
                     "this signal, so only the crash DTCs are expected.")
        return text
    if kind == "message_content":
        codes = fault_logic.get("message_content_failure_dtcs") or {}
        integrity = next((name for name in codes if "CNT" in name.upper()
                          or "COUNT" in name.upper()), next(iter(codes), None))
        return (f"3. Fault injection target for Message Content:\r\n"
                f"Integrity signal disabled: {integrity} in {plan.frame}; the valid values "
                f"keep being simulated in the same frame.")
    if kind == "wakeup":
        return (f"3. CAN wakeup check:\r\n"
                f"Hardware ignition OFF, restbus stopped until bus sleep, then restarted. "
                f"The ECU reports the wakeup in {setting('CAN_WAKEUP_STATUS_FRAME')} / "
                f"{setting('CAN_WAKEUP_STATUS_SIGNAL')} = "
                f"{setting('CAN_WAKEUP_STATUS_VALUE')} (IGN ON due to CAN wakeup).")
    if kind == "can_nm":
        return (f"3. CAN NM wakeup check:\r\n"
                f"Hardware ignition OFF, restbus stopped until bus sleep, then restarted "
                f"with {setting('CAN_NM_WAKEUP_FRAME')} / {setting('CAN_NM_WAKEUP_SIGNAL')} = "
                f"{setting('CAN_NM_WAKEUP_VALUE')} (Active): the network is requested by NM. "
                f"The ECU answers with {setting('CAN_NM_SRS_FRAME')} and reports "
                f"{setting('CAN_WAKEUP_STATUS_FRAME')} / {setting('CAN_WAKEUP_STATUS_SIGNAL')}"
                f" = {setting('CAN_WAKEUP_STATUS_VALUE')} (IGN ON due to CAN wakeup).")
    return None


def _case_dtc(plan: model.ParameterPlan, kind: str, scope: str | None,
              fault_logic: dict[str, Any]) -> str | None:
    """The CAN or power DTC a case qualifies, with the status byte it is read with.

    A fault still present when the DTC is read is active with the warning lamp off; a
    pre-crash fault is healed at T0, so by then it has become historic. canc_onfail.md
    fixes the voltage DTCs at status 0x08 whatever the timing.
    """
    historic, active = "0x08", "0x0B"
    # The EV scripts read a voltage DTC healed at T0 as historic, the way they read a CAN
    # fault; the ICE text keeps the authored 0x8B whatever the timing.
    voltage_status = (historic if plan.variant == "EV" and scope == "pre"
                      else model.VOLTAGE_DTC_STATUS)
    if kind == "under_voltage":
        return _dtc_text(model.UNDER_VOLTAGE_DTC, voltage_status)
    if kind == "over_voltage":
        return _dtc_text(model.OVER_VOLTAGE_DTC, voltage_status)
    status = historic if scope == "pre" else active
    if kind == "node_absent":
        return _dtc_text(fault_logic.get("node_absent_dtc"), status)
    if kind == "message_timeout":
        return _dtc_text(fault_logic.get("message_timeout_dtc"), status)
    if kind == "signal_content":
        return _dtc_text(fault_logic.get("signal_content_failure_dtc"), status)
    if kind == "message_content":
        codes = fault_logic.get("message_content_failure_dtcs") or {}
        first = next(iter(codes.values()), None)
        return _dtc_text(first, status)
    return None


def _fault_step_action(plan: model.ParameterPlan, kind: str) -> str:
    if plan.variant == "EV" and kind in ("signal_content", "message_content"):
        return {
            "signal_content": "Simulate Signal Content Failure by driving the DBC invalid "
                              "code listed in step 3 of Pre-Action",
            "message_content": "Simulate Message Content Failure by disabling the integrity "
                               "signal listed in step 3 of Pre-Action",
        }[kind]
    return {
        "node_absent": f"Simulate Node Absent by disabling the key message "
                       f"{plan.key_frame} listed in step 3 of Pre-Action",
        "message_timeout": f"Simulate Message Time OUT Fault by disabling the "
                           f"signal-carrying message listed in step 3 of Pre-Action",
        "under_voltage": f"Simulate Under Voltage by driving the supply to "
                         f"{UNDER_VOLTAGE_LEVEL:.1f} V as listed in step 3 of Pre-Action",
        "over_voltage": f"Simulate Over Voltage by driving the supply to "
                        f"{OVER_VOLTAGE_LEVEL:.1f} V as listed in step 3 of Pre-Action",
        "signal_never_received": "Clear the node bit in the variant code as listed in "
                                 "step 3 of Pre-Action, then power cycle",
        "variant_code_error": "Disable the variant code as listed in step 3 of "
                              "Pre-Action, then power cycle",
    }.get(kind, "")


def _scope_sentence(plan: model.ParameterPlan, kind: str, scope: str | None) -> str:
    label = model.KINDS[kind][0]
    if scope == "pre":
        return (f"{label} fault is active from the start of the recording interval and is "
                f"healed at T0.")
    if scope == "post":
        return f"{label} fault is created at T0 and stays active to the end of the interval."
    return f"{label} fault is active across the complete recording interval."


# --------------------------------------------------------------------------------------
# Building one case
# --------------------------------------------------------------------------------------


def _steps_for_new_case(plan: model.ParameterPlan, case: model.Case,
                        fault_logic: dict[str, Any],
                        iterations: int = 2) -> list[dict[int, Any]]:
    """The seven-step sequence, with the DTC read in the Action column.

    ``iterations`` is how many crashes the case makes; beyond one pair (EDR1 and EDR2)
    the sequence is repeated for the next pair.
    """
    crash_action = "Simulate Front Crash and Read DTC"
    if model.KINDS[case.kind][2]:
        crash_action = f"Simulate Front Crash. {DTC_READ_SENTENCE}"

    expected_dtc = CRASH_DTC_TEXT
    case_dtc = _case_dtc(plan, case.kind, case.scope, fault_logic)
    if case_dtc:
        expected_dtc += (f"\r\n\r\nDTC Qualifies: {model.KINDS[case.kind][0]} DTC: "
                         f"{case_dtc}.")

    steps: list[tuple[str, str]] = [
        ("Set bench to normal condition", "System is in normal state, no faults present."),
    ]
    if case.kind == "wakeup":
        steps.append((
            "Switch hardware ignition OFF and wake the ECU over CAN",
            "ECU is awake with hardware ignition OFF and no faults present."))
    if case.kind == "can_nm":
        steps.append((
            "Switch hardware ignition OFF and wake the ECU with the CAN NM message as listed "
            "in step 3 of Pre-Action",
            "ECU is awake and kept awake by the NM network request with hardware ignition "
            "OFF; it transmits its NM message and no faults are present."))
    action = _fault_step_action(plan, case.kind)
    if action:
        steps.append((action, _scope_sentence(plan, case.kind, case.scope)))
    steps.append(("Simulate Valid Values as specified in step 2 of Pre Action",
                  "Values simulated on CAN as mentioned in step 2 of Pre-Action."))
    steps.append((crash_action, expected_dtc))
    crash_step = len(steps)  # the step the second record's repeat has to run up to
    steps.extend([
        (f"Read EDR and observe bytes for {plan.parameter} EDR Parameter",
         f"EDR records the values for {plan.parameter} exactly as listed in the "
         f"Post-Action of this test case."),
        (f"Repeat steps 2 till test step {crash_step} and read EDR2 and observe bytes "
         f"for the {plan.parameter} EDR Parameter.",
         f"EDR records the values for {plan.parameter} exactly as listed in the "
         f"Post-Action of this test case."),
        ("Clear NVM and Clear DTC",
         "All DTCs and NVM data are cleared; system returns to normal state, only where "
         "permitted by the approved project procedure."),
    ])
    if iterations > len(compose.RECORDS):
        steps.append((
            "Repeat from step 1 with the next pair of iterations listed in step 2 of "
            "Pre-Action, until every iteration has been recorded and read",
            "Each iteration records the value listed for it in the Post-Action, in the "
            "record named for it."))
    return [{COL["Test Steps.Action"]: action,
             COL["Test Steps.Expected result"]: expected,
             COL["Test Steps.Critical"]: "false",
             COL["Test Steps.Id"]: index + 1}
            for index, (action, expected) in enumerate(steps)]


def _apply_steps(block: SourceCase, steps: list[dict[int, Any]]) -> None:
    """Put a fresh step list on a case.

    The workbook keeps the first step on the case's own row and every later step on a row
    of its own, so the first step replaces what the template case left in the header.
    """
    for column in ("Test Steps.Action", "Test Steps.Expected result",
                   "Test Steps.Critical", "Test Steps.Id"):
        block.header[COL[column]] = steps[0].get(COL[column]) if steps else None
    block.steps = steps[1:]


def _move_dtc_read_into_action(block: SourceCase) -> None:
    """Item 7 of the review: the DTC read belongs in the Action column.

    The authored cases carry the sentence at the end of the fault step's expected result.
    It moves to the crash step's action, and the expected result keeps only the DTC status
    and the recorded values.
    """
    rows = [block.header] + block.steps
    for step in rows:
        expected = step.get(COL["Test Steps.Expected result"])
        if isinstance(expected, str) and DTC_READ_SENTENCE in expected:
            step[COL["Test Steps.Expected result"]] = (
                expected.replace(DTC_READ_SENTENCE, "").rstrip())

    for step in rows:
        action = step.get(COL["Test Steps.Action"])
        if isinstance(action, str) and DTC_READ_SENTENCE in action:
            return
    for step in rows:
        action = step.get(COL["Test Steps.Action"])
        if isinstance(action, str) and "Crash" in action:
            step[COL["Test Steps.Action"]] = (
                action.replace(" and Read DTC", "").rstrip(". ")
                + f". {DTC_READ_SENTENCE}")
            return


def _record_behaviour(plan: model.ParameterPlan, case: model.Case) -> str:
    """What the record holds while the case's fault is active.

    latch     the last value received before the fault, because the element stops being
              updated - the frame is gone, its integrity check fails, or the supply is
              outside the range the element can be written at.
    default   the value the on-fail calibration configures, because the node was never
              there to be received from at all.
    consume   the value on the bus, because the signal keeps transmitting: a DBC marker
              code is recorded as it stands, an out-of-range value is converted like any
              other measurement.
    none      the simulated values, unchanged.
    """
    if case.kind in ("node_absent", "message_content", "under_voltage", "over_voltage"):
        return "latch"
    if case.kind == "message_timeout":
        # A timeout on a frame that does not carry this signal sets the DTC but leaves the
        # element receiving, so the record holds its normal valid value.
        return "latch" if plan.timeout_frame == plan.frame else "none"
    if case.kind in ("signal_never_received", "variant_code_error"):
        return "default"
    if case.kind in ("signal_content", "dbc_invalid", "dbc_out_of_range", "dbc_reserved"):
        return "consume"
    return "none"


def _input_marker(plan: model.ParameterPlan, case: model.Case, behaviour: str,
                  definition: dict[str, Any]) -> str | None:
    """What the Pre-Action input arrays show while the fault is active, if not the values."""
    if case.kind == "node_absent" or (
            case.kind == "message_timeout" and plan.timeout_frame == plan.frame):
        return "FAULT_ACTIVE"
    if case.kind in ("signal_never_received", "variant_code_error"):
        # ICE keeps simulating valid values on the bus; the ECU ignores them because the
        # node is cleared from the variant code, so the inputs are the values themselves.
        return None if plan.variant == "ICE" else "NOT_TRANSMITTED"
    if behaviour == "consume":
        return None  # handled per array, because hex and decimal differ
    return None


def _windowed(values: list[str], plan: model.ParameterPlan, scope: str | None,
              replacement: str) -> list[str]:
    """Replace the samples the fault covers, leaving the rest as they are."""
    if not values:
        return values
    t0 = _t0_index(plan, len(values))
    if scope == "pre":
        return [replacement] * t0 + values[t0:]
    if scope == "post":
        return values[:t0 + 1] + [replacement] * (len(values) - t0 - 1)
    return [replacement] * len(values)


def _format_like(values: list[str], raw: int | None, label: str) -> str:
    """Render a raw value the way the array it joins renders its own."""
    if raw is None:
        return "DEFAULT"
    sample = next((value for value in values if value), "")
    if label.endswith("hex") or sample.lower().startswith("0x"):
        digits = max(1, len(sample) - 2) if sample.lower().startswith("0x") else 1
        return f"0x{raw:0{digits}X}"
    return str(raw)


def _plain(value: float) -> str:
    """A physical value without exponent notation or trailing zeros."""
    return f"{value:.6f}".rstrip("0").rstrip(".")


def _format_code(values: list[str], raw: int | None, label: str,
                 definition: dict[str, Any]) -> str:
    """A driven code in the form of the array it joins; physical arrays get its value."""
    if raw is not None and "physical" in label:
        physical = raw * float(definition.get("Factor", 1)) + float(definition.get("Offset", 0))
        return _plain(physical)
    return _format_like(values, raw, label)


def _single_code_snapshot(pre: str, post: str, code: int | None,
                          definition: dict[str, Any]) -> tuple[str, str]:
    """A snapshot case that drives one code: one crash per event record.

    The code is driven into one crash recorded in EDR1 (0x0455) and again into one
    recorded in EDR2 (0x045B), so the case has two iterations whatever the nominal case's
    value list was.
    """
    pre = re.sub(r"Iterate the case \d+ time\(s\)[^\r\n]*",
                 "Iterate the case 2 time(s): the first crash is recorded in EDR1 (0x0455) and "
                 "the second in EDR2 (0x045B), each with the value listed below.", pre, count=1)
    for text_name in ("pre", "post"):
        text = pre if text_name == "pre" else post
        for label, values in _arrays(text).items():
            text = _replace_array(text, label, values[:1] * 2)
        text = re.sub(r"(?m)^(Recorded at|Simulation window): \[([^,\]]+)(?:, [^\]]*)?\]",
                      lambda m: f"{m.group(1)}: [{m.group(2)}, {m.group(2)}]", text)
        if text_name == "pre":
            pre = text
        else:
            post = text
    if code is not None:
        physical = code * float(definition.get("Factor", 1)) + float(definition.get("Offset", 0))
        unit = definition.get("UNIT") or "value"
        lines = [f"Iteration {k}: {record} records raw 0x{code:X} ({code} decimal, "
                 f"{_plain(physical)} {unit})."
                 for k, record in ((1, "EDR1 (0x0455)"), (2, "EDR2 (0x045B)"))]
        post = re.sub(r"(?:Iteration \d+:[^\r\n]*(?:\r?\n)?)+", "\r\n".join(lines) + "\r\n",
                      post, count=1)
    return pre, post


def _default_raw(definition: dict[str, Any]) -> int | None:
    value = definition.get("Default_Value")
    if value is not None:
        return int(value)
    for name, raw in (definition.get("State_Values") or {}).items():
        if "default" in str(name).lower():
            return int(raw)
    return 0


def _exception_raw(kind: str, definition: dict[str, Any],
                   plan: model.ParameterPlan | None = None) -> int | None:
    """The single code a DBC exception case drives.

    For ICE the per-series arrays in canc_config are the ones the U171 scripts drive, so
    they come first: reserved codes, the DBC invalid code, and the out-of-range value -
    the highest raw the signal's bit length carries above the DBC maximum that is not the
    invalid code.
    """
    if plan is not None and plan.variant == "ICE":
        key = {"dbc_reserved": "Reserved_Values", "dbc_invalid": "Invalid_Values",
               "signal_content": "Invalid_Values",
               "dbc_out_of_range": "OutofRange_Values"}.get(kind)
        configured = definition.get(f"TestCase_{plan.signal}_{key}") if key else None
        if configured:
            return int(configured[0])
    states = definition.get("State_Values") or {}
    if kind == "dbc_reserved":
        for name, raw in states.items():
            if "reserved" in str(name).lower():
                return int(raw)
        return None
    if kind in ("dbc_invalid", "signal_content"):
        if definition.get("Invalid_Value") is not None:
            return int(definition["Invalid_Value"])
        for name, raw in states.items():
            if "invalid" in str(name).lower():
                return int(raw)
        return None
    if kind == "dbc_out_of_range":
        maximum, bits = definition.get("MAX"), definition.get("bit_length")
        if maximum is None or not bits:
            return None
        candidate = int(maximum) + 1
        return candidate if candidate <= (1 << int(bits)) - 1 else None
    return None


def _replace_closing_sentence(post: str, sentence: str) -> str:
    """Swap the trailing plain-language sentence that says what the record holds."""
    trimmed = re.sub(r"\r?\n\r?\n[^\r\n]*\.\s*\Z", "", post or "")
    return trimmed.rstrip() + "\r\n\r\n" + sentence


def _retained_sentence(case: model.Case) -> str:
    fault = ("the voltage fault" if case.kind in ("under_voltage", "over_voltage")
             else "the fault")
    if case.scope == "pre":
        return (f"The last value received before {fault} is retained until T0, where "
                f"{fault} is healed and the simulated values are recorded again.")
    if case.scope == "post":
        return "The value received at T0 is retained for every sample after the crash."
    return (f"The last value received before {fault} is retained for the whole recording "
            f"interval.")


def _required_values(plan: model.ParameterPlan, case: model.Case,
                     definition: dict[str, Any]) -> list[int] | None:
    """The on-fail requirement's values for SNR / VC where they differ from the default.

    For ICE, canc_config carries them per series; a list of several means the record may
    hold any of them.
    """
    if plan.variant != "ICE" or case.kind not in ("signal_never_received", "variant_code_error"):
        return None
    tag = "SNR" if case.kind == "signal_never_received" else "VC"
    values = definition.get(f"TestCase_{plan.signal}_{tag}_Values")
    return [int(v) for v in values] if values else None


def _format_required(values: list[str], required: list[int], label: str,
                     definition: dict[str, Any]) -> str:
    """One required value, a contiguous range, or a set, in the array's own form."""
    shown = [_format_code(values, raw, label, definition) for raw in sorted(required)]
    if len(shown) == 1:
        return shown[0]
    ordered = sorted(required)
    if ordered == list(range(ordered[0], ordered[-1] + 1)):
        return f"{shown[0]}-{shown[-1]}"
    return "/".join(shown)


def _default_sentence(plan: model.ParameterPlan, case: model.Case,
                      definition: dict[str, Any]) -> str:
    raw = _default_raw(definition)
    if plan.variant == "ICE":
        return (f"The node is cleared from the variant code, so the ECU ignores the valid values "
                f"simulated on the bus and every sample records the on-fail default value {raw} "
                f"for {plan.parameter}.")
    return (f"The node never transmits, so every sample records the on-fail default value "
            f"{raw} for {plan.parameter}.")


def _consumed_sentence(case: model.Case, code: int | None) -> str:
    what = {"dbc_reserved": "reserved", "dbc_out_of_range": "out-of-range",
            "dbc_invalid": "invalid", "signal_content": "invalid"}[case.kind]
    if code is None:
        return (f"The signal keeps transmitting, so the {what} value on the bus is what "
                f"the record holds.")
    if case.kind == "dbc_out_of_range":
        return (f"The signal keeps transmitting, so raw {code} is converted like any other "
                f"measurement; whether the result still fits the recording field is what "
                f"this case shows.")
    return (f"The signal keeps transmitting, so the {what} code {code} is recorded as it "
            f"stands rather than put through the physical conversion.")


def _compose_record_check(plan: model.ParameterPlan, case: model.Case,
                          configs: dict[str, Any]) -> SourceCase:
    """One of the two whole-record checks.

    Neither drives a CAN stimulus: the point is what the record holds for allocations
    nothing ever feeds, so the bench stays fault free and only the record is read.
    """
    crlf = "\r\n"
    variant = plan.variant
    records = configs["u171_records" if variant == "ICE" else "m314_records"]
    if case.kind == "record_reserved":
        entries = configs["u171_reserved" if variant == "ICE" else "m314_reserved"]
        listing = [f"Reserved byte {e['data_byte']}, bits {e['high_bit']}..{e['low_bit']}"
                   for e in entries]
        what = ("Every reserved bit records the reserved value 0x00.")
        heading = f"3. Reserved fields checked ({len(listing)}):"
    else:
        own, other = ((configs["_ice"], configs["_ev"]) if variant == "ICE"
                      else (configs["_ev"], configs["_ice"]))
        other_records = configs["m314_records" if variant == "ICE" else "u171_records"]
        internal = configs.get("_ev_internal") if variant == "EV" else None
        entries = model.not_configured_elements(records, own, other, other_records, internal)
        listing = []
        for entry in entries:
            if entry["high_bit"] is not None:
                listing.append(f"{entry['name']}: byte {entry['start_byte']}, bits "
                               f"{entry['high_bit']}..{entry['low_bit']}")
            else:
                last = entry["start_byte"] + entry["byte_length"] - 1
                listing.append(f"{entry['name']}: bytes {entry['start_byte']}..{last}")
        what = ("Every allocation listed records the deconfigured value: all ones across "
                "the bits it owns, 0xFF for a whole byte. An allocation that shares its "
                "byte with an element this variant does feed is checked on its own bits "
                "only, because the rest of that byte carries real data.")
        heading = (f"3. Allocations this variant does not feed ({len(listing)}):")

    pre = crlf.join([
        "1. Verify the approved EDR feature configuration and confirm the selected variant "
        "is fault free.",
        "",
        "2. No CAN signal is simulated. The bench stays fault free and the record is read "
        "for allocations that are never fed.",
        "",
        heading,
        *listing,
    ])
    post = crlf.join([
        f"Expected EDR recording in DID 0x0455 (EDR1) and DID 0x045B (EDR2):",
        what,
    ])

    header: dict[int, Any] = {
        COL["Priority"]: "High",
        COL["Description"]: _description(plan, case),
        COL["Pre-Action"]: pre,
        COL["Post-Action"]: post,
        COL["Status"]: "IN REVIEW",
        COL["Type"]: "Functional",
        COL["_Project"]: ("Common EDR - EV variant" if variant == "EV" else None),
        COL["_LatestResult"]: "NOT YET TESTED",
        COL["_TestType"]: "Manual",
        COL["_VerificationMethod"]: "Requirements-based test",
        COL["_TestTechnique"]: "Checklist Based",
    }
    steps = [
        ("Set bench to normal condition", "System is in normal state, no faults present."),
        ("Simulate Front Crash and Read DTC", CRASH_DTC_TEXT),
        (f"Read EDR record {plan.parameter} allocations and observe the bytes",
         f"EDR records the values exactly as listed in the Post-Action of this test case."),
        ("Repeat step 2 and read EDR2, observing the same allocations",
         f"EDR records the values exactly as listed in the Post-Action of this test case."),
        ("Clear NVM and Clear DTC",
         "All DTCs and NVM data are cleared; system returns to normal state, only where "
         "permitted by the approved project procedure."),
    ]
    block = SourceCase(header, [])
    _apply_steps(block, [{COL["Test Steps.Action"]: action,
                          COL["Test Steps.Expected result"]: expected,
                          COL["Test Steps.Critical"]: "false",
                          COL["Test Steps.Id"]: index + 1}
                         for index, (action, expected) in enumerate(steps)])
    return block


def _compose_case(plan: model.ParameterPlan, case: model.Case,
                  definition: dict[str, Any], fault_logic: dict[str, Any]) -> SourceCase:
    """Build an EV case from configuration, with no authored row to start from.

    The EV specification has no source workbook for the series it shares with ICE, and
    borrowing the ICE text would put the ICE recording axis and the ICE sample vector into
    an EV case. Everything here comes from the M314 record and the M314 signal instead.
    """
    behaviour = _record_behaviour(plan, case)
    dtc = _case_dtc(plan, case.kind, case.scope, fault_logic)
    pre, post = compose.compose(
        plan, case, definition, fault_logic, "EV", "M314", behaviour,
        _fault_target(plan, case.kind), dtc)

    header: dict[int, Any] = {
        COL["Priority"]: "Highest" if model.KINDS[case.kind][1] else "High",
        COL["Description"]: _description(plan, case),
        COL["Pre-Action"]: pre,
        COL["Post-Action"]: post,
        COL["Status"]: "IN REVIEW",
        COL["Type"]: "Functional",
        COL["_Project"]: "Common EDR - EV variant",
        COL["_LatestResult"]: "NOT YET TESTED",
        COL["_TestType"]: "Manual",
        COL["_VerificationMethod"]: ("Fault Injection test" if model.KINDS[case.kind][1]
                                     else "Requirements-based test"),
        COL["_TestTechnique"]: ("Fault Injection" if model.KINDS[case.kind][1]
                                else "Boundary Value Analysis"),
    }
    block = SourceCase(header, [])
    iterations = len(compose._crashes(plan, case, definition)) or 2
    _apply_steps(block, _steps_for_new_case(plan, case, fault_logic, iterations))
    return block


def _derive_from_nominal(plan: model.ParameterPlan, case: model.Case,
                         nominal: SourceCase, fault_logic: dict[str, Any],
                         definition: dict[str, Any]) -> SourceCase:
    """Build a new case out of the element's authored nominal case.

    Everything about the element - its recording axis, its simulation windows, the values
    it is driven with - is already correct in the nominal case. Only what the fault does
    to the record is new.
    """
    block = nominal.clone()
    block.header[COL["Description"]] = _description(plan, case)
    block.header[COL["Priority"]] = "Highest" if model.KINDS[case.kind][1] else "High"
    block.header[COL["ID"]] = None
    block.header[COL["_Original_Id"]] = None
    block.header[COL["Status"]] = "IN REVIEW"
    if model.KINDS[case.kind][1]:
        block.header[COL["_VerificationMethod"]] = "Fault Injection test"
        block.header[COL["_TestTechnique"]] = "Fault Injection"

    pre = str(nominal.value("Pre-Action") or "")
    post = str(nominal.value("Post-Action") or "")

    # The Pre-Action's opening sentence names the case, so it is rewritten; the recording
    # axis and simulation window lines are the element's and stay as they are.
    scope = _scope_text(plan, case.scope)
    intro = (f"2. Simulate {plan.parameter} CAN signal with "
             f"{model.KINDS[case.kind][0]}"
             + (f" {scope}" if scope else "")
             + f" for {plan.variant} ({'U171' if plan.variant == 'ICE' else 'M314'}):")
    pre = re.sub(r"^2\. Simulate .*?:\s*$", intro.replace("\\", "\\\\"), pre, count=1,
                 flags=re.M)
    pre = re.sub(r"\r?\n\r?\n3\. .*\Z", "", pre, flags=re.S)
    target = _fault_target(plan, case.kind)
    if target:
        pre = pre.rstrip() + "\r\n\r\n" + target

    behaviour = _record_behaviour(plan, case)
    marker = _input_marker(plan, case, behaviour, definition)
    if marker is not None:
        for label, values in _arrays(pre).items():
            if label.startswith("Input"):
                pre = _replace_array(pre, label, _windowed(values, plan, case.scope, marker))

    if behaviour == "latch":
        for label, values in _arrays(post).items():
            if label.startswith("Expected recorded"):
                post = _replace_array(post, label, _latched(values, plan, case.scope))
        post = _replace_closing_sentence(post, _retained_sentence(case))
    elif behaviour == "default":
        required = _required_values(plan, case, definition)
        for label, values in _arrays(post).items():
            if label.startswith("Expected recorded"):
                held = (_format_required(values, required, label, definition) if required
                        else _format_like(values, _default_raw(definition), label))
                post = _replace_array(post, label, [held] * len(values))
        if required:
            shown = _format_required(["0x0"], required, "hex", definition)
            post = _replace_closing_sentence(post, (
                f"Per the on-fail requirement the record consumes {shown}"
                + (" (any one of them)" if len(required) > 1 else "")
                + f" for {plan.parameter} while the fault is active; the valid values keep "
                  f"being simulated on the bus."))
        else:
            post = _replace_closing_sentence(post, _default_sentence(plan, case, definition))
    elif behaviour == "consume":
        code = _exception_raw(case.kind, definition, plan)
        # The code is what is driven while the case's condition is active, and what the
        # record then holds: both the input and the expected arrays carry it.
        for label, values in _arrays(pre).items():
            if label.startswith("Input"):
                pre = _replace_array(pre, label, _windowed(
                    values, plan, case.scope, _format_code(values, code, label, definition)))
        for label, values in _arrays(post).items():
            if label.startswith("Expected recorded"):
                post = _replace_array(post, label, _windowed(
                    values, plan, case.scope, _format_code(values, code, label, definition)))
        if plan.recording_model != "interval":
            pre, post = _single_code_snapshot(pre, post, code, definition)
        post = _replace_closing_sentence(post, _consumed_sentence(case, code))

    block.header[COL["Pre-Action"]] = pre
    block.header[COL["Post-Action"]] = post
    _apply_steps(block, _steps_for_new_case(plan, case, fault_logic))
    return block


# --------------------------------------------------------------------------------------
# Assembling the workbook
# --------------------------------------------------------------------------------------


def build(output: Path, variant: str) -> dict[str, Any]:
    """Write one variant's workbook.

    The two trackers take one specification each, so a series that belongs only to the
    other variant is simply not in this file: the ICE workbook has no 26, 27 or 28, and
    the EV workbook has no 4, 5 or 66. A series number means the same element in both.
    """
    import openpyxl
    from openpyxl.styles import Alignment, Font

    v4 = read_v4(model.V4_WORKBOOK)
    v7 = read_v7_ev(model.V7_WORKBOOK)
    configs = model.load_configs()
    plans = model.build_all()
    configs["_ice"], configs["_ev"] = plans["ice"], plans["ev"]
    configs["_ev_internal"] = plans["ev_internal"]
    combined = plans["ice" if variant == "ICE" else "ev"]

    report: dict[str, Any] = {"reused": 0, "renumbered": 0, "derived": 0, "missing": []}

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Export"
    for column, name in enumerate(COLUMNS, start=1):
        cell = sheet.cell(1, column, name)
        cell.font = Font(bold=True)

    out_row = 2

    def write(values: dict[int, Any]) -> None:
        nonlocal out_row
        for column, value in values.items():
            if value is not None:
                sheet.cell(out_row, column, value)
        out_row += 1

    write(v4["canc_folder"])

    for signal in sorted(combined):
        plan = combined[signal]
        signals = configs["u171_signals"] if plan.variant == "ICE" else configs["m314_signals"]
        definition = signals.get(plan.canc_signal) or {}
        fault_logic = definition.get("fault_logic") or {}

        # The element's nominal case is the template every derived case starts from.
        if plan.variant == "ICE":
            nominal = next((v4["canc"].get((signal, c.v4_number))
                            for c in plan.cases if c.kind == "nominal"), None)
        else:
            nominal = v7.get((plan.parameter, "nominal", "full"))

        for case in plan.cases:
            block: SourceCase | None = None
            if plan.variant == "ICE":
                source_number = _v4_number(plan, case)
                if source_number is not None:
                    block = v4["canc"].get((signal, source_number))
            # EV cases are composed from configuration rather than reused, so one
            # variant's recording axis can never leak into the other's specification.

            # An out-of-range case Appendix A made out of a V4 invalid case keeps that case's
            # tracker identity, but its rows describe the invalid code, so its text is
            # derived afresh from the element's nominal case.
            tracker_identity = None
            if (block is not None and plan.variant == "ICE"
                    and (case.kind == "dbc_out_of_range"
                         or _required_values(plan, case, definition))):
                tracker_identity = (block.header.get(COL["ID"]),
                                    block.header.get(COL["_Original_Id"]))
                block = None

            if block is not None:
                block = block.clone()
                report["reused"] += 1
                if case.source == "renumbered" or plan.variant == "EV":
                    report["renumbered"] += 1
                if case.kind in ("dbc_out_of_range",) and case.note:
                    block.header[COL["Description"]] = _description(plan, case)
            else:
                # Every new case is derived from the element's own nominal case. Deriving
                # from a sibling of the same fault family at another scope would carry that
                # sibling's fault window into the new one, which is exactly what has to
                # change, so the nominal case is the only safe starting point.
                if case.kind in ("record_reserved", "record_not_configured"):
                    block = _compose_record_check(plan, case, configs)
                elif plan.variant == "EV":
                    block = _compose_case(plan, case, definition, fault_logic)
                elif nominal is not None:
                    block = _derive_from_nominal(plan, case, nominal, fault_logic,
                                                 definition)
                else:
                    report["missing"].append(case.name)
                    continue
                report["derived"] += 1
                if tracker_identity:
                    block.header[COL["ID"]], block.header[COL["_Original_Id"]] = tracker_identity

            block.header[COL["Name"]] = case.name
            if model.KINDS[case.kind][2]:
                _move_dtc_read_into_action(block)
            if plan.variant == "EV":
                block.header[COL["_Project"]] = "Common EDR - EV variant"
            write(block.header)
            for step in block.steps:
                write({COL["Test Steps.Action"]: step.get(COL["Test Steps.Action"]),
                       COL["Test Steps.Expected result"]:
                           step.get(COL["Test Steps.Expected result"]),
                       COL["Test Steps.Critical"]: step.get(COL["Test Steps.Critical"]),
                       COL["Test Steps.Id"]: step.get(COL["Test Steps.Id"])})

    # The crash-parameter, sensor, multi-event and single-event folders belong to the ICE
    # specification this was built from; they are copied through there and nowhere else.
    if variant == "ICE":
        for values in v4["tail"]:
            write(values)

    widths = {"Name": 60, "Description": 70, "Pre-Action": 90, "Post-Action": 90,
              "Test Steps.Action": 60, "Test Steps.Expected result": 70}
    for name, width in widths.items():
        sheet.column_dimensions[
            openpyxl.utils.get_column_letter(COL[name])].width = width
    for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    choices = workbook.create_sheet("ChoiceValues")
    for index, value in enumerate(v4["choices"], start=1):
        if value is not None:
            choices.cell(index, 1, value)

    output.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output)
    report["variant"] = variant
    report["rows"] = out_row - 1
    report["parameters"] = len(combined)
    report["cases"] = sum(len(plan.cases) for plan in combined.values())
    return report


def _v4_number(plan: model.ParameterPlan, case: model.Case) -> int | None:
    """The number this case carried in the V4 workbook, if it was in it.

    The plan matches V4 to the scripts by what a case tests and keeps the V4 number on
    the case, since review-order numbering no longer says which V4 case it was.
    """
    if case.source == "new":
        return None
    return case.v4_number


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=sorted(OUTPUTS),
                        help="build one variant; both by default")
    parser.add_argument("--output-directory", type=Path, default=DEFAULT_DIRECTORY)
    arguments = parser.parse_args()

    variants = [arguments.variant] if arguments.variant else sorted(OUTPUTS)
    for variant in variants:
        output = arguments.output_directory / OUTPUTS[variant]
        report = build(output, variant)
        print(f"{variant}: {output.name}")
        print(f"  {report['parameters']} series, {report['cases']} case(s), "
              f"{report['rows']} row(s)")
        print(f"  reused {report['reused']}, of which renumbered {report['renumbered']}; "
              f"derived {report['derived']}")
        if report["missing"]:
            print(f"  {len(report['missing'])} case(s) could not be built:")
            for name in report["missing"]:
                print(f"    {name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
