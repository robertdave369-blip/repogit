"""Approval-gated mutation planning for Codebeamer items and trackers."""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .client import (
    CodebeamerClient,
    CodebeamerConflictError,
    CodebeamerResponseError,
    CodebeamerScopeError,
)

_PLAN_SCHEMA_VERSION = 1
_MUTATION_OPERATIONS = frozenset(
    {
        "create-item",
        "update-item",
        "create-tracker",
        "update-tracker",
    }
)
_CREDENTIAL_FIELD_NAMES = frozenset(
    {
        "apikey",
        "authorization",
        "credential",
        "credentials",
        "password",
        "secret",
        "token",
        "username",
    }
)


@dataclass(frozen=True)
class MutationPlan:
    """A reviewed, scope-bound request to change one Codebeamer resource."""

    schema_version: int
    plan_id: str
    operation: str
    project_id: int
    tracker_id: int | None
    item_id: int | None
    payload: dict[str, Any]
    precondition_fingerprint: str | None
    created_at_utc: str


@dataclass(frozen=True)
class MutationResult:
    """The non-persisted response to one approved Codebeamer mutation."""

    plan: MutationPlan
    response: dict[str, Any]


def build_mutation_plan(
    client: CodebeamerClient,
    *,
    operation: str,
    project_id: int | str,
    tracker_id: int | str | None,
    item_id: int | str | None,
    payload: Mapping[str, Any],
) -> MutationPlan:
    """Preflight a requested mutation and create a non-executing local plan."""
    normalized_operation = _normalize_operation(operation)
    normalized_project_id = _positive_identifier(project_id, "project")
    normalized_tracker_id = _optional_identifier(tracker_id, "tracker")
    normalized_item_id = _optional_identifier(item_id, "item")
    _validate_target_shape(
        normalized_operation,
        normalized_tracker_id,
        normalized_item_id,
    )
    normalized_payload = _normalize_payload(client, payload)

    current_resource = _validate_live_scope(
        client,
        operation=normalized_operation,
        project_id=normalized_project_id,
        tracker_id=normalized_tracker_id,
        item_id=normalized_item_id,
    )
    precondition_fingerprint = (
        _fingerprint(current_resource) if current_resource is not None else None
    )
    created_at_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    plan_body = _plan_body(
        schema_version=_PLAN_SCHEMA_VERSION,
        operation=normalized_operation,
        project_id=normalized_project_id,
        tracker_id=normalized_tracker_id,
        item_id=normalized_item_id,
        payload=normalized_payload,
        precondition_fingerprint=precondition_fingerprint,
        created_at_utc=created_at_utc,
    )
    return MutationPlan(
        plan_id=_fingerprint(plan_body),
        **plan_body,
    )


def apply_mutation_plan(
    client: CodebeamerClient,
    plan: MutationPlan,
    *,
    approval_token: str,
) -> MutationResult:
    """Apply one plan only after exact approval and a fresh scope check."""
    _validate_plan_integrity(plan)
    _normalize_payload(client, plan.payload)
    if not hmac.compare_digest(plan.plan_id, str(approval_token).strip()):
        raise CodebeamerScopeError(
            "The Codebeamer approval token does not match the reviewed plan."
        )

    current_resource = _validate_live_scope(
        client,
        operation=plan.operation,
        project_id=plan.project_id,
        tracker_id=plan.tracker_id,
        item_id=plan.item_id,
    )
    if plan.precondition_fingerprint is not None:
        if current_resource is None or _fingerprint(current_resource) != plan.precondition_fingerprint:
            raise CodebeamerConflictError(
                "The Codebeamer target changed after planning; create a new plan."
            )

    if plan.operation == "create-item":
        response = client.create_item(_require_identifier(plan.tracker_id, "tracker"), plan.payload)
    elif plan.operation == "update-item":
        response = client.update_item(_require_identifier(plan.item_id, "item"), plan.payload)
    elif plan.operation == "create-tracker":
        response = client.create_tracker(plan.project_id, plan.payload)
    elif plan.operation == "update-tracker":
        response = client.update_tracker(
            _require_identifier(plan.tracker_id, "tracker"),
            plan.payload,
        )
    else:
        raise CodebeamerScopeError("The Codebeamer mutation operation is invalid.")
    return MutationResult(plan=plan, response=response)


def default_plan_path(output_root: str | Path, plan: MutationPlan) -> Path:
    """Return a unique local path for a reviewed mutation plan."""
    timestamp = plan.created_at_utc.replace(":", "-").replace("+00:00", "Z")
    return (
        Path(output_root)
        / "plans"
        / f"{timestamp}_{plan.operation}_{plan.plan_id[:12]}.json"
    )


def write_mutation_plan(plan: MutationPlan, output_path: str | Path) -> Path:
    """Persist one reviewed plan without overwriting prior approval evidence."""
    _validate_plan_integrity(plan)
    destination = Path(output_path)
    if destination.exists():
        raise FileExistsError("Refusing to overwrite an existing Codebeamer plan.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(plan_to_dict(plan), indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    return destination


def load_mutation_plan(plan_path: str | Path) -> MutationPlan:
    """Load and integrity-check a previously reviewed mutation plan."""
    try:
        data = json.loads(Path(plan_path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise CodebeamerScopeError("The Codebeamer plan file is not valid JSON.") from error
    if not isinstance(data, Mapping):
        raise CodebeamerScopeError("The Codebeamer plan must be a JSON object.")
    try:
        plan = MutationPlan(
            schema_version=_positive_identifier(data["schema_version"], "plan schema"),
            plan_id=str(data["plan_id"]),
            operation=_normalize_operation(str(data["operation"])),
            project_id=_positive_identifier(data["project_id"], "project"),
            tracker_id=_optional_identifier(data.get("tracker_id"), "tracker"),
            item_id=_optional_identifier(data.get("item_id"), "item"),
            payload=_normalize_untrusted_payload(data["payload"]),
            precondition_fingerprint=_optional_fingerprint(
                data.get("precondition_fingerprint")
            ),
            created_at_utc=str(data["created_at_utc"]),
        )
    except (KeyError, TypeError, ValueError) as error:
        raise CodebeamerScopeError("The Codebeamer plan has an invalid structure.") from error
    _validate_plan_integrity(plan)
    return plan


def plan_to_dict(plan: MutationPlan) -> dict[str, Any]:
    """Serialize a plan using stable fields suitable for approval review."""
    return {"plan_id": plan.plan_id, **_plan_body_from_plan(plan)}


def write_mutation_receipt(
    result: MutationResult,
    output_root: str | Path,
) -> Path:
    """Write a minimal local audit receipt without remote content or credentials."""
    created_at = datetime.now(timezone.utc).replace(microsecond=0)
    response_id = _mapping_identifier(result.response)
    receipt = {
        "schema_version": _PLAN_SCHEMA_VERSION,
        "plan_id": result.plan.plan_id,
        "operation": result.plan.operation,
        "project_id": result.plan.project_id,
        "tracker_id": result.plan.tracker_id,
        "item_id": result.plan.item_id,
        "response_id": response_id,
        "applied_at_utc": created_at.isoformat(),
    }
    destination = (
        Path(output_root)
        / "receipts"
        / f"{created_at.strftime('%Y%m%dT%H%M%SZ')}_{result.plan.plan_id[:12]}.json"
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(receipt, indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    return destination


def _validate_live_scope(
    client: CodebeamerClient,
    *,
    operation: str,
    project_id: int,
    tracker_id: int | None,
    item_id: int | None,
) -> dict[str, Any] | None:
    """Confirm every target remains within the user-selected project scope."""
    _assert_project_visible(client, project_id)
    if tracker_id is not None:
        _assert_tracker_in_project(client, project_id, tracker_id)

    if operation == "update-item":
        item = client.get_item(_require_identifier(item_id, "item"))
        _assert_item_in_tracker(item, _require_identifier(tracker_id, "tracker"))
        return item
    if operation == "update-tracker":
        return client.get_tracker(_require_identifier(tracker_id, "tracker"))
    return None


def _assert_project_visible(client: CodebeamerClient, project_id: int) -> None:
    project_ids = {_mapping_identifier(project) for project in client.list_projects()}
    if project_id not in project_ids:
        raise CodebeamerScopeError(
            "The selected Codebeamer project is not visible to the configured account."
        )


def _assert_tracker_in_project(
    client: CodebeamerClient,
    project_id: int,
    tracker_id: int,
) -> None:
    tracker_ids = {
        _mapping_identifier(tracker)
        for tracker in client.list_project_trackers(project_id)
    }
    if tracker_id not in tracker_ids:
        raise CodebeamerScopeError(
            "The selected Codebeamer tracker does not belong to the selected project."
        )


def _assert_item_in_tracker(item: Mapping[str, Any], tracker_id: int) -> None:
    tracker = item.get("tracker")
    if not isinstance(tracker, Mapping):
        raise CodebeamerResponseError(
            "Codebeamer did not provide tracker ownership for the selected item."
        )
    if _mapping_identifier(tracker) != tracker_id:
        raise CodebeamerScopeError(
            "The selected Codebeamer item does not belong to the selected tracker."
        )


def _normalize_operation(operation: str) -> str:
    normalized = operation.strip().lower()
    if normalized not in _MUTATION_OPERATIONS:
        raise CodebeamerScopeError("The Codebeamer mutation operation is not supported.")
    return normalized


def _validate_target_shape(
    operation: str,
    tracker_id: int | None,
    item_id: int | None,
) -> None:
    if operation == "create-item" and tracker_id is not None and item_id is None:
        return
    if operation == "update-item" and tracker_id is not None and item_id is not None:
        return
    if operation == "create-tracker" and tracker_id is None and item_id is None:
        return
    if operation == "update-tracker" and tracker_id is not None and item_id is None:
        return
    raise CodebeamerScopeError(
        "The Codebeamer mutation target does not match the selected operation."
    )


def _normalize_payload(
    client: CodebeamerClient,
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    normalized_payload = _normalize_untrusted_payload(payload)
    if client.contains_configured_credential(_canonical_json(normalized_payload)):
        raise CodebeamerScopeError(
            "Codebeamer credentials must not appear in a mutation payload or plan."
        )
    return normalized_payload


def _normalize_untrusted_payload(payload: object) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise CodebeamerScopeError("The Codebeamer mutation payload must be a JSON object.")
    _reject_credential_fields(payload)
    try:
        return json.loads(_canonical_json(payload))
    except (TypeError, ValueError) as error:
        raise CodebeamerScopeError(
            "The Codebeamer mutation payload must be JSON serializable."
        ) from error


def _reject_credential_fields(value: object) -> None:
    if isinstance(value, Mapping):
        for key, nested_value in value.items():
            canonical_key = "".join(
                character for character in str(key).casefold() if character.isalnum()
            )
            if canonical_key in _CREDENTIAL_FIELD_NAMES:
                raise CodebeamerScopeError(
                    "Credentials must not be included in a Codebeamer mutation payload."
                )
            _reject_credential_fields(nested_value)
    elif isinstance(value, (list, tuple)):
        for nested_value in value:
            _reject_credential_fields(nested_value)


def _validate_plan_integrity(plan: MutationPlan) -> None:
    if plan.schema_version != _PLAN_SCHEMA_VERSION:
        raise CodebeamerScopeError("The Codebeamer plan schema version is unsupported.")
    _validate_target_shape(plan.operation, plan.tracker_id, plan.item_id)
    _normalize_untrusted_payload(plan.payload)
    if not plan.created_at_utc.strip() or not plan.plan_id.strip():
        raise CodebeamerScopeError("The Codebeamer plan is missing approval metadata.")
    expected_plan_id = _fingerprint(_plan_body_from_plan(plan))
    if not hmac.compare_digest(plan.plan_id, expected_plan_id):
        raise CodebeamerScopeError("The Codebeamer plan was modified after review.")


def _plan_body_from_plan(plan: MutationPlan) -> dict[str, Any]:
    return _plan_body(
        schema_version=plan.schema_version,
        operation=plan.operation,
        project_id=plan.project_id,
        tracker_id=plan.tracker_id,
        item_id=plan.item_id,
        payload=plan.payload,
        precondition_fingerprint=plan.precondition_fingerprint,
        created_at_utc=plan.created_at_utc,
    )


def _plan_body(
    *,
    schema_version: int,
    operation: str,
    project_id: int,
    tracker_id: int | None,
    item_id: int | None,
    payload: dict[str, Any],
    precondition_fingerprint: str | None,
    created_at_utc: str,
) -> dict[str, Any]:
    return {
        "schema_version": schema_version,
        "operation": operation,
        "project_id": project_id,
        "tracker_id": tracker_id,
        "item_id": item_id,
        "payload": payload,
        "precondition_fingerprint": precondition_fingerprint,
        "created_at_utc": created_at_utc,
    }


def _fingerprint(value: object) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _canonical_json(value: object) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _mapping_identifier(value: object) -> int | None:
    if not isinstance(value, Mapping):
        return None
    for key in ("id", "projectId", "trackerId", "itemId"):
        if key in value:
            try:
                return _positive_identifier(value[key], "resource")
            except CodebeamerScopeError:
                return None
    return None


def _positive_identifier(value: object, label: str) -> int:
    if isinstance(value, bool):
        raise CodebeamerScopeError(f"The Codebeamer {label} identifier is invalid.")
    text = str(value).strip()
    if not text.isdecimal() or int(text) <= 0:
        raise CodebeamerScopeError(f"The Codebeamer {label} identifier is invalid.")
    return int(text)


def _optional_identifier(value: object, label: str) -> int | None:
    return None if value is None else _positive_identifier(value, label)


def _require_identifier(value: int | None, label: str) -> int:
    if value is None:
        raise CodebeamerScopeError(f"The Codebeamer {label} identifier is required.")
    return value


def _optional_fingerprint(value: object) -> str | None:
    if value is None:
        return None
    fingerprint = str(value).strip()
    if len(fingerprint) != 64 or any(character not in "0123456789abcdef" for character in fingerprint):
        raise CodebeamerScopeError("The Codebeamer plan precondition is invalid.")
    return fingerprint