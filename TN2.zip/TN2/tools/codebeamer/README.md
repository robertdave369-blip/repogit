# Codebeamer Tracker Planner

This read-only utility connects to the Codebeamer REST API v3, fetches selected
requirements, test-case, and task trackers, and writes a dated daily planner plus
an AI-readable traceability snapshot. It does not create, update, or delete any
Codebeamer item.

## Security

- Connection values are read only from `tools/codebeamer/.env` with
  `python-dotenv`; they are not accepted on the command line.
- The local `.env`, generated plans, and generated snapshots are ignored by Git.
- The client requires HTTPS, rejects URLs containing user information, uses Basic
  authentication only in the HTTPS session, and never logs response bodies.
- Console output and persisted tracker text pass through a redactor. The planner
  never writes task-assignee identities or configured connection values.

The repository did not contain a Codebeamer Python SDK, and the checked PyPI names
did not resolve to a maintained Codebeamer-specific client. The tool therefore uses
the well-supported `requests` library against Codebeamer's REST API v3 directly.

## Install

Use the framework analysis interpreter:

```powershell
py -3.14 -m pip install -r tools/codebeamer/requirements.txt
```

Populate only the already-created local `tools/codebeamer/.env` file using the
placeholder names in `.env.example`. Do not put credentials in scripts, terminal
commands, scheduled-task arguments, source control, or planner outputs.

## Validate Access

```powershell
py -3.14 -m tools.codebeamer validate
```

Validation performs an authenticated `GET /api/v3/projects` request. The Codebeamer
instance must expose REST API v3 and permit HTTPS Basic authentication for the
configured account. If the instance uses SSO or another approved authentication
mechanism, obtain the project-approved API access method before changing the client.

## Discover Tracker IDs

```powershell
py -3.14 -m tools.codebeamer list-trackers --project-id <project-id>
```

Use the returned IDs to select the requirements, test-case, and task trackers for
one project. The planner verifies that all three belong to that project before it
reads tracker items.

## Create a Daily Plan

```powershell
py -3.14 -m tools.codebeamer daily-plan `
  --project-id <project-id> `
  --requirements-tracker-id <requirements-tracker-id> `
  --test-cases-tracker-id <test-cases-tracker-id> `
  --tasks-tracker-id <tasks-tracker-id>
```

By default, the task view includes open tasks whose owner field matches the local
configured account. The account identity is used only for filtering and is never
written to disk or console. Add `--include-all-tasks` to review all open tasks in the
task tracker.

Each run writes these ignored local artifacts:

```text
tools/codebeamer/plans/YYYY-MM-DD.md
tools/codebeamer/snapshots/YYYY-MM-DD.json
```

The Markdown file groups tasks by overdue, due today, next seven days, later, and no
confirmed deadline. The JSON snapshot preserves selected requirement/test-case text,
status, priorities, deadlines, and explicit links so later AI analysis can trace the
same evidence.

The tool calls a requirement missing a test case only when the returned test-case
items include an explicit relation/reference/link field. If those fields are absent,
it reports traceability as unverified instead of inventing a coverage gap.

## Run Daily on Windows

This wrapper changes to the repository root and invokes the same read-only CLI:

```powershell
& .\tools\codebeamer\run_daily_planner.ps1 `
  -ProjectId <project-id> `
  -RequirementsTrackerId <requirements-tracker-id> `
  -TestCasesTrackerId <test-cases-tracker-id> `
  -TasksTrackerId <tasks-tracker-id>
```

Schedule this wrapper with Windows Task Scheduler at the desired local time. The
scheduled action needs only tracker IDs; it reads connection values from the local
ignored `.env` file and creates the date-based planner artifacts above.