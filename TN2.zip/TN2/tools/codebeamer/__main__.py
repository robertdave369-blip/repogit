"""Command-line entry point for the read-only Codebeamer planning utilities."""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path
from typing import Any, Sequence

from .client import CodebeamerClient, CodebeamerError, create_codebeamer_client
from .planner import TrackerScope, collect_daily_plan, write_daily_plan

_DEFAULT_ENV_FILE = Path(__file__).with_name(".env")


def build_argument_parser() -> argparse.ArgumentParser:
    """Create the command-line parser without reading any credentials."""
    parser = argparse.ArgumentParser(
        description=(
            "Read Codebeamer trackers and create a local, credential-free daily plan."
        )
    )
    parser.add_argument(
        "--env-file",
        type=Path,
        default=_DEFAULT_ENV_FILE,
        help="Path to the local Codebeamer dotenv file.",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=float,
        default=30.0,
        help="HTTPS request timeout in seconds (default: 30).",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser(
        "validate",
        help="Validate authenticated, read-only access to the REST API.",
    )

    trackers_parser = commands.add_parser(
        "list-trackers",
        help="List tracker IDs available in one project.",
    )
    trackers_parser.add_argument(
        "--project-id",
        type=_positive_identifier,
        required=True,
        help="Codebeamer project ID.",
    )

    plan_parser = commands.add_parser(
        "daily-plan",
        help="Create dated Markdown and JSON planning artifacts.",
    )
    plan_parser.add_argument(
        "--project-id",
        type=_positive_identifier,
        required=True,
        help="Codebeamer project ID.",
    )
    plan_parser.add_argument(
        "--requirements-tracker-id",
        type=_positive_identifier,
        required=True,
        help="Tracker ID containing the requirements to analyze.",
    )
    plan_parser.add_argument(
        "--test-cases-tracker-id",
        type=_positive_identifier,
        required=True,
        help="Tracker ID containing the test cases to analyze.",
    )
    plan_parser.add_argument(
        "--tasks-tracker-id",
        type=_positive_identifier,
        required=True,
        help="Tracker ID containing project tasks and due dates.",
    )
    plan_parser.add_argument(
        "--include-all-tasks",
        action="store_true",
        help="Include open tasks from the whole task tracker, not only assigned tasks.",
    )
    plan_parser.add_argument(
        "--plan-date",
        type=_iso_date,
        help="Date used for deadline grouping in YYYY-MM-DD format.",
    )
    plan_parser.add_argument(
        "--output-root",
        type=Path,
        default=Path(__file__).parent,
        help="Directory that receives ignored plans/ and snapshots/ folders.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run a read-only Codebeamer command with safe console error handling."""
    args = build_argument_parser().parse_args(argv)
    client: CodebeamerClient | None = None
    try:
        # Client construction validates credentials with a harmless GET request.
        client = create_codebeamer_client(
            dotenv_path=args.env_file,
            timeout_seconds=args.timeout_seconds,
        )
        if args.command == "validate":
            print("Codebeamer REST API access validated.")
            return 0
        if args.command == "list-trackers":
            _print_trackers(client, args.project_id)
            return 0
        if args.command == "daily-plan":
            return _create_daily_plan(client, args)
    except CodebeamerError as error:
        message = client.redact(error) if client is not None else str(error)
        print(f"Codebeamer operation failed: {message}", file=sys.stderr)
        return 2
    except OSError:
        print(
            "Codebeamer operation failed while writing local planner artifacts.",
            file=sys.stderr,
        )
        return 3
    except Exception:
        # Do not echo unexpected exception details, which may contain external data.
        print("Codebeamer operation failed unexpectedly.", file=sys.stderr)
        return 1
    finally:
        if client is not None:
            client.close()


def _create_daily_plan(client: CodebeamerClient, args: argparse.Namespace) -> int:
    """Read the chosen tracker scope and write a dated local plan."""
    scope = TrackerScope(
        project_id=args.project_id,
        requirements_tracker_id=args.requirements_tracker_id,
        test_cases_tracker_id=args.test_cases_tracker_id,
        tasks_tracker_id=args.tasks_tracker_id,
    )
    snapshot = collect_daily_plan(
        client,
        scope,
        include_all_tasks=args.include_all_tasks,
        plan_date=args.plan_date,
    )
    plan_path, snapshot_path = write_daily_plan(snapshot, args.output_root)

    # Paths, counts, and evidence status are safe to display; identities are not.
    print(f"Daily plan created: {client.redact(plan_path)}")
    print(f"AI snapshot created: {client.redact(snapshot_path)}")
    print(f"Open tasks included: {len(snapshot.tasks)}")
    print(f"Traceability status: {snapshot.traceability.coverage_status}")
    return 0


def _print_trackers(client: CodebeamerClient, project_id: int) -> None:
    """Display tracker IDs and names without serializing raw server responses."""
    trackers = client.list_project_trackers(project_id)
    print("Tracker ID\tName\tType")
    for tracker in sorted(trackers, key=lambda item: _tracker_id(item)):
        tracker_id = _tracker_id(tracker)
        tracker_name = _safe_tracker_text(client, tracker, ("name", "title", "summary"))
        tracker_type = _safe_tracker_text(client, tracker, ("type", "trackerType"))
        print(f"{tracker_id}\t{tracker_name}\t{tracker_type}")


def _tracker_id(tracker: dict[str, Any]) -> int:
    """Read one tracker ID while making malformed API data visible to the caller."""
    value = tracker.get("id") or tracker.get("trackerId")
    return _positive_identifier(str(value))


def _safe_tracker_text(
    client: CodebeamerClient,
    tracker: dict[str, Any],
    keys: tuple[str, ...],
) -> str:
    """Render a small tracker metadata field after credential redaction."""
    for key in keys:
        value = tracker.get(key)
        if value is not None:
            return client.redact(_as_text(value))
    return "Not supplied"


def _as_text(value: object) -> str:
    """Convert a common API label field to a single display string."""
    if isinstance(value, dict):
        for key in ("name", "title", "value", "displayName"):
            if key in value:
                return _as_text(value[key])
        return " ".join(_as_text(nested_value) for nested_value in value.values())
    if isinstance(value, list):
        return ", ".join(_as_text(nested_value) for nested_value in value)
    return str(value)


def _positive_identifier(value: str) -> int:
    """Validate CLI IDs before adding them to a Codebeamer request path."""
    if not value.isdecimal() or int(value) <= 0:
        raise argparse.ArgumentTypeError("Value must be a positive integer.")
    return int(value)


def _iso_date(value: str) -> date:
    """Accept only an unambiguous ISO date for daily-planner grouping."""
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("Date must use YYYY-MM-DD format.") from error


if __name__ == "__main__":
    raise SystemExit(main())
