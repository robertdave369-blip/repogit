"""Build evidence-preserving Codebeamer traceability and daily-planning artifacts."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from .client import CodebeamerClient, CodebeamerResponseError, CodebeamerScopeError

_TITLE_FIELDS = {"name", "summary", "title"}
_DESCRIPTION_FIELDS = {"description", "details", "content"}
_STATUS_FIELDS = {"status", "state"}
_PRIORITY_FIELDS = {"priority", "severity"}
_DUE_DATE_FIELDS = {
    "duedate",
    "deadline",
    "enddate",
    "plannedenddate",
    "targetdate",
}
_OWNER_FIELDS = {"assignee", "assignedto", "owner", "responsible", "members"}
_REFERENCE_FIELD_TOKENS = {
    "reference",
    "relation",
    "link",
    "verifies",
    "requirement",
    "upstream",
    "downstream",
}
_FIELD_CONTAINERS = ("fields", "fieldValues", "customFields", "attributes")
_COMPLETED_STATUSES = {
    "closed",
    "completed",
    "done",
    "rejected",
    "resolved",
}
_ISSUE_REFERENCE_PATTERN = re.compile(r"\[ISSUE:(\d+)\]", re.IGNORECASE)


@dataclass(frozen=True)
class TrackerScope:
    """Codebeamer tracker IDs used to build one planner snapshot."""

    project_id: int
    requirements_tracker_id: int
    test_cases_tracker_id: int
    tasks_tracker_id: int

    def __post_init__(self) -> None:
        """Reject unsafe or incomplete tracker selection before network access."""
        for field_name, value in (
            ("project", self.project_id),
            ("requirements tracker", self.requirements_tracker_id),
            ("test-case tracker", self.test_cases_tracker_id),
            ("task tracker", self.tasks_tracker_id),
        ):
            if value <= 0:
                raise CodebeamerScopeError(
                    f"The Codebeamer {field_name} identifier must be a positive integer."
                )


@dataclass(frozen=True)
class PlannerItem:
    """Safe, normalized representation of a requirement, test case, or task."""

    item_id: str
    title: str
    description: str | None
    status: str | None
    priority: str | None
    due_date: date | None


@dataclass(frozen=True)
class TraceabilityResult:
    """Explicit requirement-to-test-case links extracted from tracker item data."""

    requirement_to_test_cases: dict[str, tuple[str, ...]]
    test_case_to_requirements: dict[str, tuple[str, ...]]
    evidence_available: bool

    @property
    def coverage_status(self) -> str:
        """Describe whether no-link results can safely be called coverage gaps."""
        if self.evidence_available:
            return "verified_from_explicit_links"
        return "unverified_no_explicit_links"


@dataclass(frozen=True)
class DailyPlanSnapshot:
    """One dated, redacted view of selected Codebeamer trackers."""

    plan_date: date
    generated_at_utc: datetime
    scope: TrackerScope
    requirements: tuple[PlannerItem, ...]
    test_cases: tuple[PlannerItem, ...]
    tasks: tuple[PlannerItem, ...]
    traceability: TraceabilityResult
    task_scope: str


def collect_daily_plan(
    client: CodebeamerClient,
    scope: TrackerScope,
    *,
    include_all_tasks: bool = False,
    plan_date: date | None = None,
) -> DailyPlanSnapshot:
    """Fetch selected trackers and build a redacted, evidence-backed snapshot."""
    _validate_scope_trackers(client, scope)

    # Read only the explicitly selected project trackers; no data is changed remotely.
    raw_requirements = client.list_tracker_items(scope.requirements_tracker_id)
    raw_test_cases = client.list_tracker_items(scope.test_cases_tracker_id)
    raw_tasks = client.list_tracker_items(scope.tasks_tracker_id)

    requirements = _normalize_items(raw_requirements, client.redact)
    test_cases = _normalize_items(raw_test_cases, client.redact)
    tasks = _select_tasks(raw_tasks, client, include_all_tasks)
    traceability = build_traceability(raw_requirements, raw_test_cases)

    return DailyPlanSnapshot(
        plan_date=plan_date or date.today(),
        generated_at_utc=datetime.now(timezone.utc).replace(microsecond=0),
        scope=scope,
        requirements=tuple(
            sorted(requirements, key=lambda item: _id_sort_key(item.item_id))
        ),
        test_cases=tuple(
            sorted(test_cases, key=lambda item: _id_sort_key(item.item_id))
        ),
        tasks=tuple(sorted(tasks, key=_task_sort_key)),
        traceability=traceability,
        task_scope=(
            "all_tasks_in_tracker"
            if include_all_tasks
            else "tasks_assigned_to_configured_account"
        ),
    )


def build_traceability(
    raw_requirements: Sequence[Mapping[str, Any]],
    raw_test_cases: Sequence[Mapping[str, Any]],
) -> TraceabilityResult:
    """Map only explicit requirement links; never infer a missing test case."""
    requirement_ids = {_item_id(item) for item in raw_requirements}
    requirement_to_test_cases: dict[str, set[str]] = {
        item_id: set() for item_id in requirement_ids
    }
    test_case_to_requirements: dict[str, tuple[str, ...]] = {}
    explicit_link_data_seen = not raw_test_cases

    for test_case in raw_test_cases:
        test_case_id = _item_id(test_case)
        linked_requirement_ids, has_explicit_link_data = _reference_ids(
            test_case,
            requirement_ids,
        )
        explicit_link_data_seen = explicit_link_data_seen or has_explicit_link_data
        ordered_links = tuple(sorted(linked_requirement_ids, key=_id_sort_key))
        test_case_to_requirements[test_case_id] = ordered_links
        for requirement_id in ordered_links:
            requirement_to_test_cases[requirement_id].add(test_case_id)

    return TraceabilityResult(
        requirement_to_test_cases={
            requirement_id: tuple(sorted(test_case_ids, key=_id_sort_key))
            for requirement_id, test_case_ids in requirement_to_test_cases.items()
        },
        test_case_to_requirements=test_case_to_requirements,
        evidence_available=explicit_link_data_seen,
    )


def write_daily_plan(
    snapshot: DailyPlanSnapshot,
    output_root: str | Path | None = None,
) -> tuple[Path, Path]:
    """Write one readable Markdown plan and one AI-readable JSON snapshot by date."""
    root = Path(output_root) if output_root is not None else Path(__file__).parent
    plans_directory = root / "plans"
    snapshots_directory = root / "snapshots"
    plans_directory.mkdir(parents=True, exist_ok=True)
    snapshots_directory.mkdir(parents=True, exist_ok=True)

    date_stem = snapshot.plan_date.isoformat()
    plan_path = plans_directory / f"{date_stem}.md"
    snapshot_path = snapshots_directory / f"{date_stem}.json"
    plan_path.write_text(render_daily_plan(snapshot), encoding="utf-8")
    snapshot_path.write_text(
        json.dumps(snapshot_to_dict(snapshot), indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    return plan_path, snapshot_path


def render_daily_plan(snapshot: DailyPlanSnapshot) -> str:
    """Render a date-based planner without exposing the authenticated identity."""
    requirements_by_id = {item.item_id: item for item in snapshot.requirements}
    lines = [
        f"# Codebeamer Daily Planner - {snapshot.plan_date.isoformat()}",
        "",
        "## Scope",
        f"- Project ID: `{snapshot.scope.project_id}`",
        f"- Requirements tracker ID: `{snapshot.scope.requirements_tracker_id}`",
        f"- Test-case tracker ID: `{snapshot.scope.test_cases_tracker_id}`",
        f"- Task tracker ID: `{snapshot.scope.tasks_tracker_id}`",
        f"- Task selection: `{snapshot.task_scope}`",
        "",
        "## Traceability Evidence",
        f"- Status: `{snapshot.traceability.coverage_status}`",
        f"- Requirements read: {len(snapshot.requirements)}",
        f"- Test cases read: {len(snapshot.test_cases)}",
    ]

    if snapshot.traceability.evidence_available:
        covered_count = sum(
            1
            for test_case_ids in snapshot.traceability.requirement_to_test_cases.values()
            if test_case_ids
        )
        lines.append(f"- Requirements with explicit test links: {covered_count}")
    else:
        lines.extend(
            [
                "- Coverage gaps are not asserted because the test-case responses did not",
                "  include explicit requirement-link data.",
            ]
        )

    _append_task_sections(lines, snapshot.tasks, snapshot.plan_date)
    _append_traceability_sections(lines, snapshot, requirements_by_id)
    lines.extend(
        [
            "",
            "## Provenance",
            "- Source: Codebeamer REST API v3, selected tracker items only.",
            f"- Generated (UTC): {snapshot.generated_at_utc.isoformat()}",
            "- Credentials and assignee identities are excluded from this artifact.",
            "",
        ]
    )
    return "\n".join(lines)


def snapshot_to_dict(snapshot: DailyPlanSnapshot) -> dict[str, Any]:
    """Produce an AI-readable, credential-free JSON representation of a plan."""
    requirement_to_tests = snapshot.traceability.requirement_to_test_cases
    test_to_requirements = snapshot.traceability.test_case_to_requirements
    return {
        "schema_version": 1,
        "plan_date": snapshot.plan_date.isoformat(),
        "generated_at_utc": snapshot.generated_at_utc.isoformat(),
        "source": {
            "system": "Codebeamer REST API v3",
            "project_id": snapshot.scope.project_id,
            "requirements_tracker_id": snapshot.scope.requirements_tracker_id,
            "test_cases_tracker_id": snapshot.scope.test_cases_tracker_id,
            "tasks_tracker_id": snapshot.scope.tasks_tracker_id,
            "task_scope": snapshot.task_scope,
        },
        "requirements": [
            _item_to_dict(
                item,
                linked_test_case_ids=requirement_to_tests.get(item.item_id, ()),
            )
            for item in snapshot.requirements
        ],
        "test_cases": [
            _item_to_dict(
                item,
                linked_requirement_ids=test_to_requirements.get(item.item_id, ()),
            )
            for item in snapshot.test_cases
        ],
        "tasks": [_item_to_dict(item) for item in snapshot.tasks],
        "traceability": {
            "coverage_status": snapshot.traceability.coverage_status,
            "explicit_link_evidence_available": snapshot.traceability.evidence_available,
            "requirements_without_test_cases": (
                [
                    item.item_id
                    for item in snapshot.requirements
                    if not requirement_to_tests.get(item.item_id)
                ]
                if snapshot.traceability.evidence_available
                else []
            ),
        },
    }


def _validate_scope_trackers(client: CodebeamerClient, scope: TrackerScope) -> None:
    """Ensure all selected tracker IDs actually belong to the requested project."""
    project_trackers = client.list_project_trackers(scope.project_id)
    available_ids = {_item_id(tracker) for tracker in project_trackers}
    selected_ids = {
        str(scope.requirements_tracker_id),
        str(scope.test_cases_tracker_id),
        str(scope.tasks_tracker_id),
    }
    if not selected_ids.issubset(available_ids):
        raise CodebeamerScopeError(
            "At least one selected tracker does not belong to the requested project."
        )


def _normalize_items(
    items: Sequence[Mapping[str, Any]],
    redact: Callable[[object], str],
) -> list[PlannerItem]:
    """Normalize every item and fail if Codebeamer returned duplicate IDs."""
    normalized = [_normalize_item(item, redact) for item in items]
    item_ids = [item.item_id for item in normalized]
    if len(item_ids) != len(set(item_ids)):
        raise CodebeamerResponseError(
            "Codebeamer returned duplicate item identifiers in one tracker export."
        )
    return normalized


def _normalize_item(
    item: Mapping[str, Any],
    redact: Callable[[object], str],
) -> PlannerItem:
    """Keep only planning and traceability fields, redacting all display text."""
    item_id = _item_id(item)
    title = _display_text(_first_named_value(item, _TITLE_FIELDS), redact)
    description = _display_text(_first_named_value(item, _DESCRIPTION_FIELDS), redact)
    status = _display_text(_first_named_value(item, _STATUS_FIELDS), redact)
    priority = _display_text(_first_named_value(item, _PRIORITY_FIELDS), redact)
    due_date = _parse_due_date(_first_named_value(item, _DUE_DATE_FIELDS))
    return PlannerItem(
        item_id=item_id,
        title=title or f"Item {item_id}",
        description=description or None,
        status=status or None,
        priority=priority or None,
        due_date=due_date,
    )


def _select_tasks(
    raw_tasks: Sequence[Mapping[str, Any]],
    client: CodebeamerClient,
    include_all_tasks: bool,
) -> list[PlannerItem]:
    """Keep only open tasks for the configured account unless all tasks were requested."""
    selected: list[PlannerItem] = []
    for task in raw_tasks:
        if not include_all_tasks and not client.matches_current_user(
            _owner_values(task)
        ):
            continue
        normalized = _normalize_item(task, client.redact)
        if _is_complete(normalized.status):
            continue
        selected.append(normalized)
    return selected


def _reference_ids(
    item: Mapping[str, Any],
    known_requirement_ids: set[str],
) -> tuple[set[str], bool]:
    """Extract IDs only from fields explicitly named as a relation or reference."""
    linked_ids: set[str] = set()
    link_data_seen = False
    for field_name, value in _named_values(item):
        canonical_name = _canonical_name(field_name)
        if not any(token in canonical_name for token in _REFERENCE_FIELD_TOKENS):
            continue
        link_data_seen = True
        linked_ids.update(_ids_in_reference_value(value, known_requirement_ids))
    return linked_ids, link_data_seen


def _ids_in_reference_value(value: object, known_requirement_ids: set[str]) -> set[str]:
    """Find known item IDs in a structured Codebeamer relation value."""
    found: set[str] = set()
    if isinstance(value, Mapping):
        for nested_value in value.values():
            found.update(_ids_in_reference_value(nested_value, known_requirement_ids))
        return found
    if isinstance(value, (list, tuple, set)):
        for nested_value in value:
            found.update(_ids_in_reference_value(nested_value, known_requirement_ids))
        return found

    text = str(value)
    if text in known_requirement_ids:
        found.add(text)
    found.update(
        identifier
        for identifier in _ISSUE_REFERENCE_PATTERN.findall(text)
        if identifier in known_requirement_ids
    )
    return found


def _append_task_sections(
    lines: list[str],
    tasks: Sequence[PlannerItem],
    plan_date: date,
) -> None:
    """Group open tasks into deadline-based planner sections."""
    lines.extend(["", "## Work Queue"])
    buckets = {
        "Overdue": [],
        "Due today": [],
        "Next 7 days": [],
        "Later": [],
        "No confirmed deadline": [],
    }
    for task in tasks:
        buckets[_task_bucket(task.due_date, plan_date)].append(task)

    for heading, bucket_tasks in buckets.items():
        lines.extend(["", f"### {heading}"])
        if not bucket_tasks:
            lines.append("- None")
            continue
        for task in bucket_tasks:
            lines.append(_task_markdown(task))


def _append_traceability_sections(
    lines: list[str],
    snapshot: DailyPlanSnapshot,
    requirements_by_id: Mapping[str, PlannerItem],
) -> None:
    """Render confirmed coverage gaps or the reason they cannot be asserted."""
    lines.extend(["", "## Requirement Coverage"])
    if not snapshot.traceability.evidence_available:
        lines.append(
            "- Unverified: obtain explicit Codebeamer relation/reference fields before "
            "calling any requirement uncovered."
        )
        return

    missing_requirement_ids = [
        requirement_id
        for requirement_id, test_case_ids in snapshot.traceability.requirement_to_test_cases.items()
        if not test_case_ids
    ]
    if not missing_requirement_ids:
        lines.append(
            "- Every fetched requirement has at least one explicit test-case link."
        )
        return

    lines.append("- Requirements without an explicit test-case link:")
    for requirement_id in sorted(missing_requirement_ids, key=_id_sort_key):
        requirement = requirements_by_id[requirement_id]
        lines.append(f"  - `{requirement_id}`: {_markdown_text(requirement.title)}")


def _item_to_dict(
    item: PlannerItem,
    *,
    linked_test_case_ids: Sequence[str] | None = None,
    linked_requirement_ids: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Serialize a normalized item without owner or authentication information."""
    result: dict[str, Any] = {
        "id": item.item_id,
        "title": item.title,
        "description": item.description,
        "status": item.status,
        "priority": item.priority,
        "due_date": item.due_date.isoformat() if item.due_date else None,
    }
    if linked_test_case_ids is not None:
        result["linked_test_case_ids"] = list(linked_test_case_ids)
    if linked_requirement_ids is not None:
        result["linked_requirement_ids"] = list(linked_requirement_ids)
    return result


def _item_id(item: Mapping[str, Any]) -> str:
    """Return a required Codebeamer item ID without accepting malformed values."""
    for key in ("id", "itemId", "item_id"):
        value = item.get(key)
        if value is not None and str(value).strip().isdecimal():
            return str(value).strip()
    raise CodebeamerResponseError(
        "Codebeamer returned an item without a valid numeric identifier."
    )


def _named_values(item: Mapping[str, Any]) -> list[tuple[str, object]]:
    """Expose direct and custom field names without serializing unrelated raw data."""
    values = [(str(key), value) for key, value in item.items()]
    for container_name in _FIELD_CONTAINERS:
        container = item.get(container_name)
        if isinstance(container, Mapping):
            values.extend((str(key), value) for key, value in container.items())
        elif isinstance(container, list):
            for field_data in container:
                if not isinstance(field_data, Mapping):
                    continue
                field_name = _field_name(field_data)
                if field_name is not None:
                    values.append((field_name, _field_value(field_data)))
    return values


def _first_named_value(item: Mapping[str, Any], names: set[str]) -> object | None:
    """Get the first direct or custom field matching a canonical field name."""
    for field_name, value in _named_values(item):
        if _canonical_name(field_name) in names:
            return value
    return None


def _field_name(field_data: Mapping[str, Any]) -> str | None:
    """Locate a human-readable custom field name in a Codebeamer field object."""
    for key in ("name", "fieldName", "label", "title"):
        value = field_data.get(key)
        if value is not None:
            return str(value)
    return None


def _field_value(field_data: Mapping[str, Any]) -> object:
    """Return a custom field value without treating its name as a value."""
    for key in ("value", "values", "fieldValue", "content"):
        if key in field_data:
            return field_data[key]
    return field_data


def _owner_values(item: Mapping[str, Any]) -> list[object]:
    """Return owner-field values for internal filtering only; they are never persisted."""
    return [
        value
        for field_name, value in _named_values(item)
        if _canonical_name(field_name) in _OWNER_FIELDS
    ]


def _display_text(value: object | None, redact: Callable[[object], str]) -> str:
    """Normalize a display value and redact configured credentials before storage."""
    if value is None:
        return ""
    text = _text_value(value)
    return redact(text).strip()


def _text_value(value: object) -> str:
    """Turn common Codebeamer field shapes into a readable string."""
    if isinstance(value, Mapping):
        for key in ("name", "summary", "title", "value", "content", "text"):
            if key in value:
                return _text_value(value[key])
        return " ".join(_text_value(nested_value) for nested_value in value.values())
    if isinstance(value, (list, tuple, set)):
        return ", ".join(_text_value(nested_value) for nested_value in value)
    return str(value)


def _parse_due_date(value: object | None) -> date | None:
    """Parse only ISO-style dates to avoid making an ambiguous deadline claim."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value

    text = _text_value(value).strip()
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def _is_complete(status: str | None) -> bool:
    """Classify known completed task statuses without assuming unknown statuses."""
    return status is not None and _canonical_name(status) in _COMPLETED_STATUSES


def _task_bucket(due_date: date | None, plan_date: date) -> str:
    """Select the planner deadline section for one task."""
    if due_date is None:
        return "No confirmed deadline"
    if due_date < plan_date:
        return "Overdue"
    if due_date == plan_date:
        return "Due today"
    if due_date <= plan_date + timedelta(days=7):
        return "Next 7 days"
    return "Later"


def _task_markdown(task: PlannerItem) -> str:
    """Render an open task without assignee identity or credential information."""
    details = [f"`{task.item_id}`", _markdown_text(task.title)]
    if task.due_date:
        details.append(f"Due: {task.due_date.isoformat()}")
    if task.status:
        details.append(f"Status: {_markdown_text(task.status)}")
    if task.priority:
        details.append(f"Priority: {_markdown_text(task.priority)}")
    task_line = "- [ ] " + " | ".join(details)
    if not task.description:
        return task_line
    return f"{task_line}\n  - Details: {_markdown_text(task.description)}"


def _task_sort_key(task: PlannerItem) -> tuple[bool, date, tuple[int, str]]:
    """Order deadlines first and undated work last in every planner output."""
    return (
        task.due_date is None,
        task.due_date or date.max,
        _id_sort_key(task.item_id),
    )


def _id_sort_key(item_id: str) -> tuple[int, str]:
    """Sort numeric IDs numerically while still accepting API string IDs."""
    return int(item_id), item_id


def _canonical_name(value: object) -> str:
    """Normalize field labels across API and custom-field naming conventions."""
    return re.sub(r"[^a-z0-9]", "", str(value).casefold())


def _markdown_text(value: str) -> str:
    """Keep tracker text readable and safe inside a one-line Markdown list item."""
    return " ".join(value.replace("|", "\\|").split())
