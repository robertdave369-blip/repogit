[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$ProjectId,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$RequirementsTrackerId,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$TestCasesTrackerId,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$TasksTrackerId,

    [switch]$IncludeAllTasks
)

$repositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$arguments = @(
    "-3.14",
    "-m",
    "tools.codebeamer",
    "daily-plan",
    "--project-id",
    $ProjectId,
    "--requirements-tracker-id",
    $RequirementsTrackerId,
    "--test-cases-tracker-id",
    $TestCasesTrackerId,
    "--tasks-tracker-id",
    $TasksTrackerId
)

if ($IncludeAllTasks) {
    $arguments += "--include-all-tasks"
}

Push-Location $repositoryRoot
try {
    # Authentication remains in tools\codebeamer\.env and is never passed here.
    & py @arguments
    exit $LASTEXITCODE
}
finally {
    Pop-Location
}