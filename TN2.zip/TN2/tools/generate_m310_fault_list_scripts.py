"""Generate the M310_M314_M110 Fault_List test scripts.

Author: Kris

Writes one flat script per fault family into
projects/M310_M314_M110/modules/Fault_List/scripts (45 scripts) and the suite runner
run_fault_list_suite.py. Each script takes its targets, DTCs, loads and timing from the
M310_M314_M110 configuration at run time (squibs, GPO, DCS, ODS, RSU, EOL, CAN-C and the
fault list configuration) and calls only shared-library functions; no DBC, JSON or workbook is
read. Every target gets its own report; a failing target is logged and the sweep goes on.

Test objective (fault list verification criteria): set the fault for longer than its
maturation time - the DTC is raised; remove it for longer than the dematuration time - the DTC
is inactive in the same cycle, or only in the next cycle for a latched fault. Timing is graded
with the shared fault_time_check over nominal - tolerance .. nominal + tolerance + the
measured faultTimeMeasurement lag (canc_config FAULT_TIME_MEASUREMENT_LAG_MS).

Usage:
    py -3.14 tools/generate_m310_fault_list_scripts.py          # write the scripts
    py -3.14 tools/generate_m310_fault_list_scripts.py --check  # compare only, exit 1 on a difference
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import textwrap
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = "M310_M314_M110"
OUT_DIR = ROOT / "projects" / PROJECT / "modules" / "Fault_List" / "scripts"
CONFIG_PACKAGE = f"Framework_IOEM_Py.projects.{PROJECT}.config"

sys.path.insert(0, str(ROOT.parent))
os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", PROJECT)
from Framework_IOEM_Py.projects.M310_M314_M110.config import (  # noqa: E402
    canc_config, dcs_config, e_call_config, eol_config, fault_list_config, gpo_config, ods_config, squibs_config)

# Config names a script may import, per module. A script imports the ones its code uses.
CONFIG_IMPORTS = {
    "canc_config": [
        "CANC_BELT_CHANNEL", "CANC_BELT_CROSS_CONNECT_PARTNER", "CANC_BELT_ODS", "CANC_DCS_FAULT_LOAD",
        "CANC_ODS_CHANNEL", "CANC_ODS_LOADS", "CANC_STPS_CHANNEL", "CANC_STPS_LOADS",
        "CAN_DLC_ERROR_PAYLOAD_LENGTH", "CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC", "CAN_FAULT_POLL_INTERVAL_MS",
        "CAN_FAULT_TIMING_TOLERANCE_PERCENT", "CAN_SIGNAL_START_BIT", "CAN_TX_MESSAGE_CONFIG",
        "FAULT_TIME_MEASUREMENT_LAG_MS", "MAH_CAN_SIGNAL_DEFS", "get_frame_message_content_failure_dtc",
        "get_message_content_failure_dtcs", "get_message_content_failure_signals", "is_key_message",
        "qualification_ms", "recovery_ms", "resolve_dtc_for_event",
    ],
    "dcs_config": ["DCSName", "DCS_Fault_Description", "DCS_fault_time", "STPSName"],
    "e_call_config": ["ECALL_ARIA_FUNCTION"],
    "eol_config": ["EOL_CONFIG_ERROR_DTC", "EOL_FEATURE_AVAILABLE_DTCS", "EOL_GPO_TESTS", "EOL_LOOP_TESTS",
                   "EOL_PAB_Dependencies", "EOL_RSU_TESTS", "EOL_SWITCH_DCS_TESTS"],
    "fault_list_config": ["DCS_FAULT_BY_CHANNEL", "GPO_FAULT_BY_OUTPUT", "LOOP_FAULT_BY_SQUIB"],
    "gpo_config": ["GPO_FaultDescription", "GPO_Names", "gpo_fault_time"],
    "ods_config": ["ODSChannelName", "ODSName"],
    "power_config": ["NOMINAL_VOLTAGE"],
    "project_config": ["CAN_FD_CHANNEL_NAME", "DIAG_TX_ID", "PROJECT_NAME"],
    "rsu_config": ["DTC_RSU_fault", "RSU_CHANNELS", "RSU_CHANNEL_TO_SENSOR", "RSU_FAULT_TIME", "rsu_fault_code"],
    "squibs_config": ["ActiveSquibName", "SquibNumber", "Squib_Fault_Description", "squib_fault_time"],
}

# Bench names the scripts read from the configuration (2026-10-22: no value is written into a script).
ECALL_ARIA_FUNCTION = e_call_config.ECALL_ARIA_FUNCTION   # the ARIA function of the E-Call output
DCS_OPEN_LOAD = dcs_config.DCS_Fault_Description["Open"]  # the open-circuit preset of the DCS card
GPO_REST_LOAD = gpo_config.GPO_FaultDescription["NoFault"]  # an output's rest state (INHERENT)

# EOL switch / DCS feature -> DCS or ODS channel. Both sides are configuration names
# (eol_config.EOL_SWITCH_DCS_FEATURES, dcs_config.DCSName / ods_config.ODSChannelName); no
# configuration table links them, so the generator writes this one into the script.
EOL_SEAT_CHANNEL = {
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH": "DCS_DRVR",
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH": "DCS_PSGR",
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH": "DCS_Second_Row_Right",
    "SECOND_ROW_RIGHT_ODS": "DCS_Second_Row_Right_ODS",
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH": "DCS_Second_Row_Middle",
    "SECOND_ROW_MIDDLE_ODS": "DCS_Second_Row_Middle_ODS",
    "SECOND_ROW_LEFT_BUCKLE_SWITCH": "DCS_Second_Row_Left",
    "SECOND_ROW_LEFT_ODS": "DCS_Second_Row_Left_ODS",
    "THIRD_ROW_RIGHT_BUCKLE_SWITCH": "DCS_Third_Row_Right",
    "THIRD_ROW_RIGHT_ODS": "DCS_Third_Row_Right_ODS",
    "THIRD_ROW_LEFT_BUCKLE_SWITCH": "DCS_Third_Row_Left",
    "THIRD_ROW_LEFT_ODS": "DCS_Third_Row_Left_ODS",
}


# ---------------------------------------------------------------------------
# Text building
# ---------------------------------------------------------------------------

def blk(text: str, indent: int) -> str:
    """Dedent a template block and indent it by `indent` spaces (blank lines stay empty)."""
    lines = textwrap.dedent(text).strip("\n").splitlines()
    return "\n".join((" " * indent + line) if line.strip() else "" for line in lines)


class Body:
    """Lines of run_test(), added block by block at a given indentation."""

    def __init__(self):
        self.parts: list[str] = []

    def add(self, indent: int, text: str):
        self.parts.append(blk(text, indent))

    def text(self) -> str:
        return "\n".join(self.parts)


@dataclass
class Script:
    name: str
    objective: str
    targets: str
    timing: str
    body: str
    notes: list[str] = field(default_factory=list)
    stdlib: list[str] = field(default_factory=list)
    module_imports: list[str] = field(default_factory=list)


def wrap_field(label: str, text: str) -> list[str]:
    first = f"# {label:<11}: "
    lines = textwrap.wrap(text, 100 - len(first)) or [""]
    return [first + lines[0]] + ["#" + " " * (len(first) - 1) + line for line in lines[1:]]


def render(script: Script) -> str:
    # No generated-file marker or rebuild line: on 2026-10-16 both were taken out of the CAN-C
    # scripts and of the repository's script templates, so these scripts carry neither. Running
    # this generator still rewrites every script, hand edits included.
    out = [
        "# Author: Kris",
        "#",
    ]
    out += wrap_field("Script", script.name)
    out += wrap_field("Objective", script.objective)
    out += wrap_field("Targets", script.targets)
    out += wrap_field("Timing", script.timing)
    for index, note in enumerate(script.notes):
        out += wrap_field("Notes" if index == 0 else "", note)
    out += ["", "import os", "import sys", "import time", "from pathlib import Path"]
    out += script.stdlib
    out += [
        "",
        "# -- Make Framework_IOEM_Py importable as a top-level package ----------------",
        "_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]",
        "if str(_FRAMEWORK_ROOT.parent) not in sys.path:",
        "    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))",
        "",
        "# -- Shared library ----------------------------------------------------------",
        "# import_list re-exports every shared library the framework provides; the two",
        "# ARIA calls come through it and run before anything below uses the reporter.",
        "from Framework_IOEM_Py.shared_libraries.import_list import *",
        "",
        "ensure_apym_on_path()",
        "init_aria()",
        "",
        f"# -- {PROJECT} project configuration -------------------------------------",
    ]
    code = script.body
    if len(re.findall(r"\blamp_on\b", code)) == 1:
        code = re.sub(r"\n    lamp_on = .*", "", code)
    for module in script.module_imports:
        out.append(f"from {CONFIG_PACKAGE} import {module}")
    for module, names in CONFIG_IMPORTS.items():
        used = sorted({name for name in names if re.search(rf"\b{re.escape(name)}\b", code)},
                      key=lambda n: (n.lower(), n))
        if used:
            out.append(f"from {CONFIG_PACKAGE}.{module} import (")
            out += [f"    {name}," for name in used]
            out.append(")")
    out += ["", "", "def run_test():", code, "", "", 'if __name__ == "__main__":', "    run_test()", ""]
    text = "\n".join(out)
    left = re.findall(r"@[A-Z_]+@", text)
    assert not left, f"{script.name}: unreplaced markers {left}"
    return text


# ---------------------------------------------------------------------------
# Shared blocks (written at indent 0, placed with Body.add)
# ---------------------------------------------------------------------------

PROLOGUE = """
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_on = lamp_def['State_Values']['Lamp ON']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
"""

POLL = """
    poll_started = time.monotonic()
    while True:
        poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
        poll_text = str(poll_text).strip()
        try:
            poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
        except ValueError:
            poll_value = poll_text
        poll_seconds = time.monotonic() - poll_started
        if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
            break
        time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
    RESULT.InterpretEqualResult(
        f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
        str(poll_value), str(poll_expected))
"""

TAIL = """
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
@CLEANUP@
        finally:
            aria_reports.write_to_file()
"""


def poll(body: Body, indent: int, def_expr: str, expected_expr: str, label_expr: str):
    """Read an ECU signal until it shows the expected value or PROVEOUT_COMPLETION_TIME has passed,
    then grade it: an ECU-side update lags the bench change (on 2026-10-15 a fault lamp came on
    1 s after its DTC, the belt status followed a load change after about 1 s)."""
    body.add(indent, f"poll_def = {def_expr}\npoll_expected = {expected_expr}\npoll_label = {label_expr}")
    body.add(indent, POLL)


def lamp(body: Body, indent: int, state: str, label: str):
    poll(body, indent, "lamp_def", "lamp_on" if state == "on" else "lamp_off", label)


def missing(body: Body, pairs: list[tuple[str, str]]):
    lines = ["missing = [label for label, value in ("]
    lines += [f"    ({label}, {value})," for label, value in pairs]
    lines += [
        ") if not value]",
        "if missing:",
        "    RESULT.LogCustomAction(",
        '        "Configuration the case needs", "Present in the M310_M314_M110 configuration",',
        '        "Missing: " + ", ".join(missing), False)',
        "    continue",
    ]
    body.add(12, "\n".join(lines))


def report(body: Body, log_defs: str = "[lamp_def]"):
    body.add(8, f"""
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids({log_defs}), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
    """)


def precondition(body: Body, resting: str = "", can: bool = False):
    resp, req = ("Read_DTC_Resp_CANC", "Read_DTC_Req_CANC") if can else ("Read_DTC_Resp", "Read_DTC_Req")
    body.add(12, "aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')")
    body.add(12, "PS.SetVoltage(NOMINAL_VOLTAGE)")
    if resting:
        body.add(12, resting)
    body.add(12, f"""
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', {resp}, {req})
        aria_reports.close_group()
    """)


def dtc_list(status: str, can: bool = False) -> str:
    resp = "Read_DTC_Resp_CANC" if can else "Read_DTC_Resp"
    return f"\" \".join([{resp}] + [f\"{{dtc}} {{DTC_status['{status}']}}\" for dtc in fault_dtcs])"


def read_dtc(body: Body, indent: int, label: str, status: str, can: bool = False):
    req = "Read_DTC_Req_CANC" if can else "Read_DTC_Req"
    body.add(indent, f"Read_DTC({label!r},\n         {dtc_list(status, can)},\n         {req})")


def measure(body: Body, indent: int, var: str, status: str):
    body.add(indent, f"{var} = faultTimeMeasurement(\n    \";\".join(f\"{{dtc}} {{DTC_status['{status}']}}\" "
                     f"for dtc in fault_dtcs))")


def grade(body: Body, indent: int, var: str, what: str, which: str, nominal: str | None = None):
    """fault_time_check over nominal - tolerance .. nominal + tolerance + measurement_lag_ms (the
    shared check takes the centre and the half width of the window)."""
    nominal = nominal or f"{which}_nominal_ms"
    tol, pct = f"{which}_tolerance_ms", f"{which}_tolerance_percent"
    body.add(indent, f"""
        expected_ms = {nominal}
        lower_ms = expected_ms - {tol}
        upper_ms = expected_ms + {tol} + measurement_lag_ms
        RESULT.InsertComment(f"{what} of {{timed_dtcs}}: expected {{expected_ms:g}} ms, "
                             f"limits {{lower_ms:g}} ms (-{{{pct}:g}} %) to {{upper_ms:g}} ms "
                             f"(+{{{pct}:g}} % and the {{measurement_lag_ms}} ms measurement lag)")
        fault_time_check({var}, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
    """)


def record(body: Body, indent: int, var: str, what: str):
    body.add(indent, f"RESULT.LogAction(f\"{what} (ms)\", None if {var} is None else round({var}))")


def qualify_step(body: Body, graded: bool = True, can: bool = False, why: str = "", lamp_state: str = "on"):
    status = "DTC_active_WLOFF" if can else "DTC_active"
    measure(body, 12, "qualification_time_ms", status)
    if graded:
        grade(body, 12, "qualification_time_ms", "Qualification time", "qualify")
    else:
        record(body, 12, "qualification_time_ms", f"Time until {{timed_dtcs}} is active, not graded: {why}")
    read_dtc(body, 12, "DTC active after the qualification time", status, can)
    if lamp_state == "on":
        lamp(body, 12, "on", 'f"Warning lamp ON with {timed_dtcs} active"')
    else:
        lamp(body, 12, "off", 'f"Warning lamp stays OFF with {timed_dtcs} active (no lamp for this fault)"')


def recover_step(body: Body, graded: bool = True, can: bool = False, nominal: str | None = None):
    measure(body, 12, "dequalification_time_ms", "DTC_healed")
    if graded:
        grade(body, 12, "dequalification_time_ms", "Dequalification time", "recover", nominal)
    else:
        record(body, 12, "dequalification_time_ms", "Time until {timed_dtcs} is healed, not graded")
    read_dtc(body, 12, "DTC healed after the dequalification time", "DTC_healed", can)
    lamp(body, 12, "off", 'f"Warning lamp OFF with {timed_dtcs} healed"')


def historic_step(body: Body, step: int, can: bool = False, settle: bool = False):
    body.add(12, f"""
        aria_reports.add_group('Step {step}: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
    """)
    if settle:
        measure(body, 12, "settle_time_ms", "DTC_historic")
        record(body, 12, "settle_time_ms", "Time until {timed_dtcs} is historic after the start-up")
    read_dtc(body, 12, "DTC historic after the IGN cycle", "DTC_historic", can)
    lamp(body, 12, "off", 'f"Warning lamp OFF with {timed_dtcs} historic"')
    body.add(12, "aria_reports.close_group()")


def clear_step(body: Body, step: int, can: bool = False):
    resp, req = ("Read_DTC_Resp_CANC", "Read_DTC_Req_CANC") if can else ("Read_DTC_Resp", "Read_DTC_Req")
    body.add(12, f"""
        aria_reports.add_group('Step {step}: Clear DTC and read DTC')
        ClearDTC()
        Read_DTC('No DTC present after clearing', {resp}, {req})
        aria_reports.close_group()
    """)


def tail(body: Body, cleanup: str):
    body.add(8, TAIL.replace("@CLEANUP@", blk(cleanup, 12)))


def timing(body: Body, table: str, quali: str, dequali: str | None, offset: str | None = None,
           source: str = ""):
    plus = f" + {table}['{offset}']" if offset else ""
    body.add(4, f"# Nominal fault times and tolerances (percent) from {source}.")
    body.add(4, f"qualify_nominal_ms = {table}['{quali}']{plus}")
    body.add(4, f"qualify_tolerance_percent = {table}['Qualification_Tolerance']")
    body.add(4, "qualify_tolerance_ms = qualify_nominal_ms * qualify_tolerance_percent / 100")
    if dequali:
        body.add(4, f"recover_nominal_ms = {table}['{dequali}']{plus}")
        body.add(4, f"recover_tolerance_percent = {table}['Dequalification_Tolerance']")
        body.add(4, "recover_tolerance_ms = recover_nominal_ms * recover_tolerance_percent / 100")


LEAKAGE = {
    "vbat_high": ("SetLeakageVBATBusHigh", "ClearLeakageVBATBusHigh", "leakage VBAT to bus high"),
    "gnd_low": ("SetLeakageGNDBusLow", "ClearLeakageGNDBusLow", "leakage GND to bus low"),
    "gnd_high": ("SetLeakageGNDBusHigh", "ClearLeakageGNDBusHigh", "leakage GND to bus high"),
}


def leak_set(body: Body, leak: str | None, indent: int = 12):
    if leak:
        call, _, text = LEAKAGE[leak]
        body.add(indent, f'RESULT.InterpretEqualResult("Power card {text} set", PS.{call}(), "0000")')


def leak_clear(body: Body, leak: str | None, indent: int = 12):
    if leak:
        _, call, text = LEAKAGE[leak]
        body.add(indent, f'RESULT.InterpretEqualResult("Power card {text} cleared", PS.{call}(), "0000")')


def relay(body: Body, indent: int, var: str, call: str, device: str, load: str, label: str,
          stop: bool = True):
    """A relay / load change graded against the '<load> for <device> set OK.' answer of the
    shared wrapper; with stop, a refused change ends the target (nothing to measure)."""
    expected = f'f"{{{load}}} for {{{device}}} set OK."'
    body.add(indent, f"{var} = {call}({device}, {load})")
    body.add(indent, f"RESULT.InterpretEqualResult({label}, {var},\n                            {expected})")
    if stop:
        body.add(indent, f"if {var} != {expected}:\n    aria_reports.close_group()\n    continue")


# ---------------------------------------------------------------------------
# Squib loops
# ---------------------------------------------------------------------------

LOOP_KINDS = {
    "Open": ("an open circuit", None),
    "LoRes": ("a low resistance", None),
    "HiRes": ("a high resistance", None),
    "S2B": ("a short to battery", "vbat_high"),
    "S2G": ("a short to ground", "gnd_low"),
}
LOOP_SCRIPT = {"Open": "Open", "LoRes": "LoRes", "HiRes": "HiRes", "S2B": "S2B", "S2G": "S2G"}


def loop_single(kind: str) -> Script:
    text, leak = LOOP_KINDS[kind]
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"""
        fault_kind = {kind!r}
        fault_load = Squib_Fault_Description[fault_kind]
        inherent_load = Squib_Fault_Description['NoFault']
    """)
    timing(b, "squib_fault_time", "Qualification_Time", "Dequalification_Time", source="squibs_config.squib_fault_time")
    b.add(4, """
        targets = list(ActiveSquibName)
        print(f"{script_name}: {len(targets)} squib loops")
        for target_no, squib in enumerate(targets, start=1):
            loop_device = f"LOOP{SquibNumber[squib]}"
            fault_entry = LOOP_FAULT_BY_SQUIB.get(squib, {}).get(fault_kind)
            fault_dtcs = [fault_entry['dtc']] if fault_entry and fault_entry['dtc'] else []
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{script_name}_{target_no:02d}_{squib}"
    """)
    b.add(8, f"""
        fault_text = f"{text} on {{squib}} ({{loop_device}}: {{fault_load}}{' and the power card leakage' if leak else ''})"
        tc_desc = (f"Verify that {text} on {{squib}} sets its DTC within the qualification time with the "
                   f"warning lamp on, heals within the dequalification time and is historic after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"fault list DTC of {squib} {fault_kind}"', "fault_dtcs")])
    precondition(b)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    leak_set(b, leak)
    relay(b, 12, "fault_response", "SQUIB.SendRequest", "loop_device", "fault_load",
          'f"{loop_device} ({squib}) set to {fault_load}"')
    qualify_step(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Remove fault - {loop_device} back to {inherent_load}")')
    relay(b, 12, "heal_response", "SQUIB.SendRequest", "loop_device", "inherent_load",
          'f"{loop_device} ({squib}) set back to {inherent_load}"', stop=False)
    leak_clear(b, leak)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4)
    clear_step(b, 5)
    cleanup = "SQUIB.SendRequest(loop_device, inherent_load)"
    if leak:
        cleanup += f"\nPS.{LEAKAGE[leak][1]}()"
    tail(b, cleanup)
    notes = []
    if leak:
        notes.append(f"The fault is the loop relay on {squibs_config.Squib_Fault_Description[kind]} plus the power card "
                     f"{LEAKAGE[leak][2]} (set before the relay, cleared after it).")
    notes.append("DTCs come from fault_list_config.LOOP_FAULT_BY_SQUIB, which also covers the five squibs whose "
                 "squibs_config.DTC_Squib_FaultCode is None (CAB, R2LPT, R2RPT, DBFL, PBFL).")
    return Script(f"Fault_List_Loop_Fault_{LOOP_SCRIPT[kind]}",
                  f"Each active squib loop with {text}: DTC active (status 0x8B) within the qualification "
                  f"time and warning lamp ON; DTC healed (0x0A) within the dequalification time and lamp OFF; "
                  f"historic (0x08) after an IGN cycle; cleared.",
                  "squibs_config.ActiveSquibName (one report per loop).",
                  "squibs_config.squib_fault_time 2000 ms / 4000 ms, tolerances read as percent (10 % / 20 %); "
                  "upper limit + FAULT_TIME_MEASUREMENT_LAG_MS.",
                  b.text(), notes)


def loop_xconn() -> Script:
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, """
        fault_kind = 'CrossConnect'
        fault_load = Squib_Fault_Description[fault_kind]
        inherent_load = Squib_Fault_Description['NoFault']
    """)
    timing(b, "squib_fault_time", "Qualification_Time", "Dequalification_Time", source="squibs_config.squib_fault_time")
    b.add(4, """
        # Consecutive active loops are paired (the last one with the first when the count is odd):
        # both on the same bus line are cross-connected and each must report its own DTC.
        targets = [(ActiveSquibName[index], ActiveSquibName[(index + 1) % len(ActiveSquibName)])
                   for index in range(0, len(ActiveSquibName), 2)]
        print(f"{script_name}: {len(targets)} loop pairs")
        for target_no, (first_squib, second_squib) in enumerate(targets, start=1):
            first_device = f"LOOP{SquibNumber[first_squib]}"
            second_device = f"LOOP{SquibNumber[second_squib]}"
            fault_entries = [LOOP_FAULT_BY_SQUIB.get(squib, {}).get(fault_kind) for squib in (first_squib, second_squib)]
            fault_dtcs = [entry['dtc'] for entry in fault_entries if entry and entry['dtc']]
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{script_name}_{target_no:02d}_{first_squib}_{second_squib}"
            fault_text = f"cross connection of {first_squib} ({first_device}) and {second_squib} ({second_device})"
            tc_desc = (f"Verify that a cross connection of {first_squib} and {second_squib} sets both cross-connect "
                       f"DTCs within the qualification time with the warning lamp on, that both heal within the "
                       f"dequalification time and are historic after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"fault list cross-connect DTCs of {first_squib} and {second_squib}"', "len(fault_dtcs) == 2")])
    precondition(b)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    relay(b, 12, "first_response", "SQUIB.SendRequest", "first_device", "fault_load",
          'f"{first_device} ({first_squib}) set to {fault_load}"')
    relay(b, 12, "second_response", "SQUIB.SendRequest", "second_device", "fault_load",
          'f"{second_device} ({second_squib}) set to {fault_load}"')
    qualify_step(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Remove fault - both loops back to {inherent_load}")')
    relay(b, 12, "first_response", "SQUIB.SendRequest", "first_device", "inherent_load",
          'f"{first_device} ({first_squib}) set back to {inherent_load}"', stop=False)
    relay(b, 12, "second_response", "SQUIB.SendRequest", "second_device", "inherent_load",
          'f"{second_device} ({second_squib}) set back to {inherent_load}"', stop=False)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4)
    clear_step(b, 5)
    tail(b, "SQUIB.SendRequest(first_device, inherent_load)\nSQUIB.SendRequest(second_device, inherent_load)")
    return Script("Fault_List_Loop_Fault_CrossConnect",
                  "Pairs of active squib loops cross-connected (both on the bus line): both cross-connect DTCs "
                  "active (0x8B) within the qualification time and lamp ON; healed (0x0A) within the "
                  "dequalification time and lamp OFF; historic (0x08) after an IGN cycle; cleared.",
                  "Consecutive pairs of squibs_config.ActiveSquibName (8 pairs for 16 loops).",
                  "squibs_config.squib_fault_time 2000 ms / 4000 ms (tolerance percent 10 / 20); the time is "
                  "to the second DTC; upper limit + FAULT_TIME_MEASUREMENT_LAG_MS.",
                  b.text(),
                  ["Fault = both loop relays on Squib_Fault_Description['CrossConnect'] (BUSS_HI_ON) without "
                   "leakage; the DTCs come from fault_list_config.LOOP_FAULT_BY_SQUIB."])


# ---------------------------------------------------------------------------
# GPO outputs (ENS, PAB ON / OFF lamps, E-Call)
# ---------------------------------------------------------------------------

GPO_KINDS = {"OPEN": ("Open", "an open circuit", None), "S2B": ("S2B", "a short to battery", "vbat_high"),
             "S2G": ("S2G", "a short to ground", "gnd_high")}
GPO_SCRIPT_KIND = {"OPEN": "Open", "S2B": "S2B", "S2G": "S2G"}


def gpo(output: str, kind: str) -> Script:
    config_key, text, leak = GPO_KINDS[kind]
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"""
        gpo_output = {output!r}
        fault_kind = {kind!r}
        gpo_name = next((name for name in GPO_Names if name.upper().removesuffix('_LAMP') == gpo_output), None)
        fault_load = GPO_FaultDescription[{config_key!r}]
        rest_load = GPO_FaultDescription['NoFault']
    """)
    timing(b, "gpo_fault_time", "Qualification_Time", "Dequalification_Time", "gpo_faultcounter_offset",
           "gpo_config.gpo_fault_time (fault counter offset added)")
    b.add(4, f"""
        targets = [gpo_output]
        for target_no, gpo_output in enumerate(targets, start=1):
            fault_entry = GPO_FAULT_BY_OUTPUT.get(gpo_output, {{}}).get(fault_kind)
            fault_dtcs = [fault_entry['dtc']] if fault_entry and fault_entry['dtc'] else []
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{{script_name}}_{{target_no:02d}}_{{gpo_output}}"
            fault_text = f"{text} on the {{gpo_output}} output ({{gpo_name}}: {{fault_load}}{' and the power card leakage' if leak else ''})"
            tc_desc = (f"Verify that {text} on the {{gpo_output}} output sets its DTC within the qualification "
                       f"time with the warning lamp on, heals within the dequalification time and is historic "
                       f"after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"GPO output {gpo_output} in gpo_config.GPO_Names"', "gpo_name"),
                ('f"fault list DTC of {gpo_output} {fault_kind}"', "fault_dtcs")])
    precondition(b, "SetGpoFaultCondition(gpo_name, GPO_FaultDescription['NoFault'])")
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    b.add(12, """
        # SetGpoFaultCondition sets the power card leakage of a short (S2B: VBAT, S2G: GND, both on
        # bus high) and then the output relay; its answer is the relay acknowledgement.
        fault_response = SetGpoFaultCondition(gpo_name, fault_kind)
        RESULT.InterpretEqualResult(f"{gpo_name} set to {fault_kind}", str(fault_response),
                                    f"{fault_load} for {gpo_name} set OK.")
        if fault_response != f"{fault_load} for {gpo_name} set OK.":
            aria_reports.close_group()
            continue
    """)
    qualify_step(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Remove fault - {gpo_name} back to {rest_load}")')
    b.add(12, """
        # The rest state (gpo_config GPO_FaultDescription['NoFault'], INHERENT) clears both leakage
        # paths and puts the relay back.
        heal_response = SetGpoFaultCondition(gpo_name, rest_load)
        RESULT.InterpretEqualResult(f"{gpo_name} set back to {rest_load}", str(heal_response),
                                    f"{rest_load} for {gpo_name} set OK.")
    """)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4)
    clear_step(b, 5)
    tail(b, "SetGpoFaultCondition(gpo_name, GPO_FaultDescription['NoFault'])")
    notes = [f"Fault = SetGpoFaultCondition(<GPO>, '{kind}'): relay {gpo_config.GPO_FaultDescription[config_key]}"
             + (f" with the power card {LEAKAGE[leak][2]}." if leak else ".")]
    if output == "ENS":
        notes.append("The previous script had fault_free_profile() commented out (reason not recorded); the "
                     "precondition is the same as for every other Fault_List script.")
    return Script(f"Fault_List_GPO_{output}_{GPO_SCRIPT_KIND[kind]}",
                  f"{output} output with {text}: DTC active (0x8B) within the qualification time and lamp ON; "
                  f"healed (0x0A) within the dequalification time and lamp OFF; historic (0x08) after an IGN "
                  f"cycle; cleared.",
                  f"The {output} output (gpo_config.GPO_Names); DTC from fault_list_config.GPO_FAULT_BY_OUTPUT.",
                  "gpo_config.gpo_fault_time 2000 ms / 4000 ms + gpo_faultcounter_offset (10 ms), tolerance "
                  "percent 10 / 20; upper limit + FAULT_TIME_MEASUREMENT_LAG_MS.",
                  b.text(), notes)


def ecall(kind: str) -> Script:
    config_key, text, leak = GPO_KINDS[kind]
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"""
        fault_kind = {kind!r}
        # The E-Call output is not a gpo_config GPO, so SetGpoFaultCondition refuses it. It is driven
        # through its ARIA function (e_call_config ECALL_ARIA_FUNCTION) with the steps SetGpoFaultCondition
        # uses for the ENS output.
        ecall_device = ECALL_ARIA_FUNCTION
        fault_load = GPO_FaultDescription[{config_key!r}]
        rest_load = GPO_FaultDescription['NoFault']
    """)
    timing(b, "gpo_fault_time", "Qualification_Time", "Dequalification_Time", "gpo_faultcounter_offset",
           "gpo_config.gpo_fault_time (fault counter offset added)")
    b.add(4, f"""
        targets = ['ECALL']
        for target_no, gpo_output in enumerate(targets, start=1):
            fault_entry = GPO_FAULT_BY_OUTPUT.get(gpo_output, {{}}).get(fault_kind)
            fault_dtcs = [fault_entry['dtc']] if fault_entry and fault_entry['dtc'] else []
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{{script_name}}_{{target_no:02d}}_{{gpo_output}}"
            fault_text = f"{text} on the E-Call output ({{ecall_device}}: {{fault_load}}{' and the power card leakage' if leak else ''})"
            tc_desc = (f"Verify that {text} on the E-Call crash output sets its DTC within the qualification "
                       f"time with the warning lamp on, heals within the dequalification time and is historic "
                       f"after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"fault list DTC of {gpo_output} {fault_kind}"', "fault_dtcs")])
    precondition(b, """
        PS.ClearLeakageGNDBusHigh()
        PS.ClearLeakageVBATBusHigh()
        LAMPS.configure_lamp(ecall_device, rest_load)
    """)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    leak_set(b, leak)
    b.add(12, """
        fault_response = LAMPS.configure_lamp(ecall_device, fault_load)[1]
        RESULT.InterpretEqualResult(f"{ecall_device} set to {fault_load}", fault_response,
                                    f"{fault_load} for {ecall_device} set OK.")
        if fault_response != f"{fault_load} for {ecall_device} set OK.":
            aria_reports.close_group()
            continue
    """)
    qualify_step(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Remove fault - {ecall_device} back to {rest_load}")')
    leak_clear(b, leak)
    b.add(12, """
        heal_response = LAMPS.configure_lamp(ecall_device, rest_load)[1]
        RESULT.InterpretEqualResult(f"{ecall_device} set back to {rest_load}", heal_response,
                                    f"{rest_load} for {ecall_device} set OK.")
    """)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4)
    clear_step(b, 5)
    tail(b, """
        PS.ClearLeakageGNDBusHigh()
        PS.ClearLeakageVBATBusHigh()
        LAMPS.configure_lamp(ecall_device, rest_load)
    """)
    return Script(f"Fault_List_GPO_ECALL_{GPO_SCRIPT_KIND[kind]}",
                  f"E-Call crash output with {text}: DTC active (0x8B) within the qualification time and lamp "
                  f"ON; healed (0x0A) within the dequalification time and lamp OFF; historic (0x08) after an IGN "
                  f"cycle; cleared.",
                  "The E-Call output; DTC from fault_list_config.GPO_FAULT_BY_OUTPUT['ECALL'] (GPO driver 3).",
                  "gpo_config.gpo_fault_time 2000 ms / 4000 ms + gpo_faultcounter_offset (10 ms), tolerance "
                  "percent 10 / 20 (the fault list gives the E-Call output the same 2000 / 4000 ms).",
                  b.text(),
                  [f"The ARIA function '{ECALL_ARIA_FUNCTION}' is e_call_config ECALL_ARIA_FUNCTION "
                   "(aria_projects/M314/M314.project.json slot_map[64]); with E-Call in gpo_config.GPO_Names "
                   "the script could use SetGpoFaultCondition like the ENS scripts.",
                   f"Fault = relay {gpo_config.GPO_FaultDescription[config_key]}"
                   + (f" with the power card {LEAKAGE[leak][2]}." if leak else ".")])


# ---------------------------------------------------------------------------
# DCS belt buckles, ODS, STPS
# ---------------------------------------------------------------------------

DCS_TIMING_NOTE = ("dcs_config.DCS_fault_time {q} ms + dcs_faultcounter_offset (10 ms), tolerance percent 10; "
                   "upper limit + FAULT_TIME_MEASUREMENT_LAG_MS.")


def dcs_like_single(script: str, family: str, kind: str) -> Script:
    """Short to battery / ground or open circuit on a DCS belt, ODS or STPS channel."""
    if family == "belt":
        targets_code = "list(CANC_BELT_CHANNEL.values())"
        device = "DCSName[dcs_channel]"
        rest = "DCS_Fault_Description['unbuckle']"
        what = "belt buckle"
        targets_doc = "Every belt buckle channel of canc_config.CANC_BELT_CHANNEL (dcs_config.DCSName devices)."
    elif family == "ods":
        targets_code = "list(ODSName)"
        device = "ODSChannelName[dcs_channel]"
        rest = "CANC_ODS_LOADS['NOT_PRESENT']"
        what = "ODS"
        targets_doc = "Every ODS channel of ods_config.ODSName (ods_config.ODSChannelName devices)."
    else:
        targets_code = ("[name for names in CANC_STPS_CHANNEL.values() for name in names\n"
                        "               if fault_kind in DCS_FAULT_BY_CHANNEL.get(name, {})]")
        device = "STPSName[dcs_channel]"
        rest = "CANC_STPS_LOADS['ZONE_1']"
        what = "seat track position sensor"
        targets_doc = ("The STPS channels of canc_config.CANC_STPS_CHANNEL that have this fault in "
                       "fault_list_config.DCS_FAULT_BY_CHANNEL (sensor 1 of driver and passenger; the sensor 2 "
                       "faults are struck out of the fault list).")
    if kind == "S2B":
        text, leak, load = "a short to battery", "vbat_high", "CANC_DCS_FAULT_LOAD"
    elif kind == "S2G":
        text, leak, load = "a short to ground", "gnd_high", "CANC_DCS_FAULT_LOAD"
    else:
        text, leak, load = "an open circuit", None, "DCS_Fault_Description['Open']"
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"""
        fault_kind = {kind!r}
        fault_load = {load}
        rest_load = {rest}
    """)
    if kind == "Open":
        b.add(4, "# dcs_config DCS_Fault_Description['Open'] is the open-circuit preset of the ARIA DCS card.")
    timing(b, "DCS_fault_time", "Qualification", "Dequalification", "dcs_faultcounter_offset",
           "dcs_config.DCS_fault_time (fault counter offset added)")
    b.add(4, f"""
        targets = {targets_code}
        print(f"{{script_name}}: {{len(targets)}} channels")
        for target_no, dcs_channel in enumerate(targets, start=1):
            dcs_device = {device}
            fault_entry = DCS_FAULT_BY_CHANNEL.get(dcs_channel, {{}}).get(fault_kind)
            fault_dtcs = [fault_entry['dtc']] if fault_entry and fault_entry['dtc'] else []
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{{script_name}}_{{target_no:02d}}_{{dcs_channel}}"
            fault_text = f"{text} on {what} {{dcs_channel}} ({{dcs_device}}: {{fault_load}}{' and the power card leakage' if leak else ''})"
            tc_desc = (f"Verify that {text} on {what} {{dcs_channel}} sets its DTC within the qualification "
                       f"time with the warning lamp on, heals within the dequalification time and is historic "
                       f"after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"fault list DTC of {dcs_channel} {fault_kind}"', "fault_dtcs")])
    rest_code = (f"PS.{LEAKAGE[leak][1]}()\n" if leak else "") + \
        'RESULT.InterpretEqualResult(f"{dcs_device} at rest ({rest_load})", SLS.SendRequest(dcs_device, rest_load),\n' \
        '                            f"{rest_load} for {dcs_device} set OK.")'
    precondition(b, rest_code)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    leak_set(b, leak)
    relay(b, 12, "fault_response", "SLS.SendRequest", "dcs_device", "fault_load",
          'f"{dcs_device} ({dcs_channel}) set to {fault_load}"')
    qualify_step(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Remove fault - {dcs_device} back to {rest_load}")')
    leak_clear(b, leak)
    relay(b, 12, "heal_response", "SLS.SendRequest", "dcs_device", "rest_load",
          'f"{dcs_device} ({dcs_channel}) set back to {rest_load}"', stop=False)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4)
    clear_step(b, 5)
    cleanup = (f"PS.{LEAKAGE[leak][1]}()\n" if leak else "") + "SLS.SendRequest(dcs_device, rest_load)"
    tail(b, cleanup)
    notes = ["Loads are set with SLS.SendRequest (the relay call SET_DCS_LOADS makes, without its 1 s wait), "
             "so the measurement starts when the load changes."]
    if leak:
        notes.append(f"Fault = {canc_config.CANC_DCS_FAULT_LOAD} load with the power card {LEAKAGE[leak][2]} "
                     "(project note dcs_ocs_stps_prompt.md: faulty = card BUS + power card leakage).")
    if family == "stps":
        notes.append("Rest load = canc_config.CANC_STPS_LOADS['ZONE_1'] (14 mA, the zone-1 default state), as in "
                     "the CAN-C STPS scripts; the previous scripts healed to 6 mA (zone 2), which is also fault free.")
    return Script(script,
                  f"{what.capitalize()} channels with {text}: DTC active (0x8B) within the qualification time "
                  f"and lamp ON; healed (0x0A) within the dequalification time and lamp OFF; historic (0x08) after "
                  f"an IGN cycle; cleared.",
                  targets_doc, DCS_TIMING_NOTE.format(q="3200 / 3200"), b.text(), notes)


def dcs_like_xconn(script: str, family: str) -> Script:
    if family == "belt":
        targets_code = """
            # Pairs from canc_config.CANC_BELT_CROSS_CONNECT_PARTNER, each pair once.
            targets = []
            for belt_key, partner_key in CANC_BELT_CROSS_CONNECT_PARTNER.items():
                pair = (CANC_BELT_CHANNEL[belt_key], CANC_BELT_CHANNEL[partner_key])
                if pair not in targets and pair[::-1] not in targets:
                    targets.append(pair)
        """
        device, rest, what = "DCSName", "DCS_Fault_Description['unbuckle']", "belt buckles"
        targets_doc = "Belt buckle pairs of canc_config.CANC_BELT_CROSS_CONNECT_PARTNER, each pair once (4 pairs)."
    elif family == "ods":
        targets_code = """
            # Consecutive ODS channels are paired (the last one with the first when the count is odd).
            targets = [(ODSName[index], ODSName[(index + 1) % len(ODSName)]) for index in range(0, len(ODSName), 2)]
        """
        device, rest, what = "ODSChannelName", "CANC_ODS_LOADS['NOT_PRESENT']", "ODS channels"
        targets_doc = "Consecutive pairs of ods_config.ODSName (3 pairs for 5 channels, the last with the first)."
    else:
        targets_code = """
            stps_channels = [name for names in CANC_STPS_CHANNEL.values() for name in names
                             if fault_kind in DCS_FAULT_BY_CHANNEL.get(name, {})]
            targets = [(stps_channels[index], stps_channels[(index + 1) % len(stps_channels)])
                       for index in range(0, len(stps_channels), 2)]
        """
        device, rest, what = "STPSName", "CANC_STPS_LOADS['ZONE_1']", "seat track position sensors"
        targets_doc = "Driver and passenger STPS sensor 1 (canc_config.CANC_STPS_CHANNEL with the fault in the list)."
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"""
        fault_kind = 'CrossConnect'
        fault_load = CANC_DCS_FAULT_LOAD
        rest_load = {rest}
    """)
    timing(b, "DCS_fault_time", "Qualification_CC", "Dequalification_CC", "dcs_faultcounter_offset",
           "dcs_config.DCS_fault_time (cross-connect times, fault counter offset added)")
    b.add(4, targets_code)
    b.add(4, f"""
        print(f"{{script_name}}: {{len(targets)}} channel pairs")
        for target_no, (first_channel, second_channel) in enumerate(targets, start=1):
            first_device = {device}[first_channel]
            second_device = {device}[second_channel]
            fault_entries = [DCS_FAULT_BY_CHANNEL.get(name, {{}}).get(fault_kind) for name in (first_channel, second_channel)]
            fault_dtcs = [entry['dtc'] for entry in fault_entries if entry and entry['dtc']]
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{{script_name}}_{{target_no:02d}}_{{first_channel}}_{{second_channel}}"
            fault_text = f"cross connection of {{first_channel}} and {{second_channel}} (both on {{fault_load}})"
            tc_desc = (f"Verify that a cross connection of {{first_channel}} and {{second_channel}} sets both "
                       f"cross-connect DTCs within the qualification time with the warning lamp on, that both heal "
                       f"within the dequalification time and are historic after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"fault list cross-connect DTCs of {first_channel} and {second_channel}"', "len(fault_dtcs) == 2")])
    precondition(b, """
        RESULT.InterpretEqualResult(f"{first_device} at rest ({rest_load})", SLS.SendRequest(first_device, rest_load),
                                    f"{rest_load} for {first_device} set OK.")
        RESULT.InterpretEqualResult(f"{second_device} at rest ({rest_load})", SLS.SendRequest(second_device, rest_load),
                                    f"{rest_load} for {second_device} set OK.")
    """)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    relay(b, 12, "first_response", "SLS.SendRequest", "first_device", "fault_load",
          'f"{first_device} ({first_channel}) set to {fault_load}"')
    relay(b, 12, "second_response", "SLS.SendRequest", "second_device", "fault_load",
          'f"{second_device} ({second_channel}) set to {fault_load}"')
    qualify_step(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Remove fault - both channels back to {rest_load}")')
    relay(b, 12, "first_response", "SLS.SendRequest", "first_device", "rest_load",
          'f"{first_device} ({first_channel}) set back to {rest_load}"', stop=False)
    relay(b, 12, "second_response", "SLS.SendRequest", "second_device", "rest_load",
          'f"{second_device} ({second_channel}) set back to {rest_load}"', stop=False)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4)
    clear_step(b, 5)
    tail(b, "SLS.SendRequest(first_device, rest_load)\nSLS.SendRequest(second_device, rest_load)")
    return Script(script,
                  f"Pairs of {what} cross-connected (both on the {canc_config.CANC_DCS_FAULT_LOAD} load, no leakage): both "
                  f"cross-connect DTCs active (0x8B) within the qualification time and lamp ON; healed (0x0A) "
                  f"within the dequalification time and lamp OFF; historic (0x08) after an IGN cycle; cleared.",
                  targets_doc, DCS_TIMING_NOTE.format(q="1900 / 1900 (cross connect)"), b.text(),
                  ["Loads are set with SLS.SendRequest (no 1 s wait as in SET_DCS_LOADS)."])


# The passenger belt status follows the buckle switch only with the passenger seat occupied for the OCS;
# with the seat empty the ECU sends it as Buckled whatever the switch (system requirement tables 1.7 / 1.9,
# seen on the bench on 2026-10-15). fault_free_profile leaves the bench CAN simulation alone, so a script
# that reads belt statuses sets the OCS class itself and reloads the bench default OCS frame afterwards.
OCS_OCCUPIED = """
    # Passenger seat occupied for the OCS (50th-percentile adult): with the seat empty the ECU sends the
    # passenger belt as Buckled whatever the switch (system requirement tables 1.7 / 1.9).
    CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'], ocs_class_def['signal'],
                          str(ocs_class_def['State_Values']['PERCENTILE_50TH_ADULT_DEFAULT']))
"""
OCS_RELOAD = "CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])"
OCS_NOTE = ("Passenger belt: the OCS class (bench-simulated OCS1_500) is set to the 50th-percentile adult in the "
            "precondition, because with the seat empty the ECU sends STS_SEAT_BLT_PSGR as Buckled whatever the "
            "switch (system requirement tables 1.7 / 1.9; ECU on 2026-10-15); the cleanup reloads the bench default "
            "OCS1_500 frame.")


def belt_targets(body: Body, pairs: bool):
    if pairs:
        body.add(4, """
            # Pairs from canc_config.CANC_BELT_CROSS_CONNECT_PARTNER, each pair once.
            targets = []
            for belt_key, partner_key in CANC_BELT_CROSS_CONNECT_PARTNER.items():
                if (belt_key, partner_key) not in targets and (partner_key, belt_key) not in targets:
                    targets.append((belt_key, partner_key))
        """)
    else:
        body.add(4, "targets = [(belt_key,) for belt_key in CANC_BELT_CHANNEL]")


def ods_prerequisite(body: Body):
    """Rear belt status is valid only with the seat ODS present (project note); front belts have
    no ODS in canc_config.CANC_BELT_ODS."""
    body.add(12, """
        for seat_key in seat_keys:
            ods_key = CANC_BELT_ODS.get(seat_key)
            if not ods_key:
                continue
            ods_device = ODSChannelName[CANC_ODS_CHANNEL[ods_key]]
            RESULT.InterpretEqualResult(f"{ods_device} set to ODS present", SLS.SendRequest(ods_device, CANC_ODS_LOADS['PRESENT']),
                                        f"{CANC_ODS_LOADS['PRESENT']} for {ods_device} set OK.")
    """)
    body.add(12, """
        for seat_key in seat_keys:
            ods_key = CANC_BELT_ODS.get(seat_key)
            if not ods_key:
                continue
    """)
    poll(body, 16, "MAH_CAN_SIGNAL_DEFS[ods_key]", "MAH_CAN_SIGNAL_DEFS[ods_key]['State_Values']['PRESENT']",
         'f"{ods_key} with the seat ODS present"')


def belt_poll(body: Body, state_expr: str, label: str):
    body.add(12, "for seat_key in seat_keys:")
    body.add(16, "seat_states = MAH_CAN_SIGNAL_DEFS[seat_key]['State_Values']")
    poll(body, 16, "MAH_CAN_SIGNAL_DEFS[seat_key]", state_expr, label)


def dcs_status(variant: str) -> Script:
    """Belt status signals: buckled, unbuckled, short to battery, cross connection."""
    pairs = variant == "xconn"
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, """
        unbuckle_load = DCS_Fault_Description['unbuckle']
        buckle_load = DCS_Fault_Description['buckle']
        fault_load = CANC_DCS_FAULT_LOAD
        ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
    """)
    if variant == "s2b":
        timing(b, "DCS_fault_time", "Qualification", "Dequalification", "dcs_faultcounter_offset",
               "dcs_config.DCS_fault_time (fault counter offset added)")
    elif variant == "xconn":
        timing(b, "DCS_fault_time", "Qualification_CC", "Dequalification_CC", "dcs_faultcounter_offset",
               "dcs_config.DCS_fault_time (cross-connect times, fault counter offset added)")
    belt_targets(b, pairs)
    fault_kind = {"s2b": "S2B", "xconn": "CrossConnect"}.get(variant)
    b.add(4, """
        print(f"{script_name}: {len(targets)} targets")
        for target_no, seat_keys in enumerate(targets, start=1):
            seat_channels = [CANC_BELT_CHANNEL[seat_key] for seat_key in seat_keys]
            seat_devices = [DCSName[name] for name in seat_channels]
    """)
    if fault_kind:
        b.add(8, f"""
            fault_entries = [DCS_FAULT_BY_CHANNEL.get(name, {{}}).get({fault_kind!r}) for name in seat_channels]
            fault_dtcs = [entry['dtc'] for entry in fault_entries if entry and entry['dtc']]
        """)
    else:
        b.add(8, "fault_dtcs = []")
    b.add(8, 'timed_dtcs = " and ".join(fault_dtcs)')
    b.add(8, 'seat_text = " and ".join(seat_keys)')
    b.add(8, 'tc_name = f"{script_name}_{target_no:02d}_" + "_".join(seat_keys)')
    texts = {
        "buckled": ("belt buckled ({buckle_load})",
                    "Verify that buckling {seat} is sent as Buckled on CAN without any DTC, also after an IGN cycle."),
        "unbuckled": ("belt unbuckled ({unbuckle_load}) after buckled",
                      "Verify that unbuckling {seat} is sent as Not Buckled on CAN without any DTC, also after an IGN cycle."),
        "s2b": ("short to battery on the belt buckle ({fault_load} and the power card leakage)",
                "Verify that a short to battery on {seat} is sent as Buckle Faulty on CAN with its DTC and the lamp on, "
                "and that the status returns to Not Buckled when the fault heals."),
        "xconn": ("cross connection of the belt buckles (both on {fault_load})",
                  "Verify that a cross connection of {seat} is sent as Buckle Faulty for both seats on CAN with both "
                  "DTCs and the lamp on, and that the statuses return to Not Buckled when the fault heals."),
    }
    fault_text, desc = texts[variant]
    b.add(8, f'fault_text = f"{fault_text} - {{seat_text}}"')
    b.add(8, f'tc_desc = f"{desc.replace("{seat}", "{seat_text}")}"')
    report(b, "[MAH_CAN_SIGNAL_DEFS[seat_key] for seat_key in seat_keys] + [lamp_def, ocs_class_def]")
    b.add(8, "try:")
    if fault_kind:
        missing(b, [('"fault list DTCs of " + " and ".join(seat_channels)', "len(fault_dtcs) == len(seat_keys)")])
    rest = textwrap.dedent("""
        for seat_device in seat_devices:
            RESULT.InterpretEqualResult(f"{seat_device} at rest ({unbuckle_load})", SLS.SendRequest(seat_device, unbuckle_load),
                                        f"{unbuckle_load} for {seat_device} set OK.")
        for seat_key in seat_keys:
            if CANC_BELT_ODS.get(seat_key):
                SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
    """).strip("\n")
    rest = textwrap.dedent(OCS_OCCUPIED).strip("\n") + "\n" + rest
    if variant == "s2b":
        rest = "PS.ClearLeakageVBATBusHigh()\n" + rest
    precondition(b, rest)
    b.add(12, "aria_reports.add_group('Step 2: Seat ODS present where the belt status needs it')")
    ods_prerequisite(b)
    b.add(12, "aria_reports.close_group()")
    if variant in ("buckled", "unbuckled"):
        b.add(12, "aria_reports.add_group('Step 3: Buckle the belt')")
        b.add(12, """
            for seat_device in seat_devices:
                RESULT.InterpretEqualResult(f"{seat_device} set to {buckle_load}", SLS.SendRequest(seat_device, buckle_load),
                                            f"{buckle_load} for {seat_device} set OK.")
        """)
        belt_poll(b, "seat_states['Buckled']", 'f"{seat_key} buckled"')
        b.add(12, "aria_reports.close_group()")
        step = 4
        final = "seat_states['Buckled']"
        if variant == "unbuckled":
            b.add(12, "aria_reports.add_group('Step 4: Unbuckle the belt')")
            b.add(12, """
                for seat_device in seat_devices:
                    RESULT.InterpretEqualResult(f"{seat_device} set to {unbuckle_load}", SLS.SendRequest(seat_device, unbuckle_load),
                                                f"{unbuckle_load} for {seat_device} set OK.")
            """)
            belt_poll(b, "next(value for label, value in seat_states.items() if label.startswith('Not Buckled'))",
                      'f"{seat_key} unbuckled"')
            b.add(12, "aria_reports.close_group()")
            step = 5
            final = "next(value for label, value in seat_states.items() if label.startswith('Not Buckled'))"
        b.add(12, f"""
            aria_reports.add_group('Step {step}: No DTC with the belt status, also after an IGN cycle')
            Read_DTC('No DTC present', Read_DTC_Resp, Read_DTC_Req)
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
        """)
        belt_poll(b, final, 'f"{seat_key} after the IGN cycle"')
        b.add(12, """
            Read_DTC('No DTC present after the IGN cycle', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
        """)
        tail(b, textwrap.dedent("""
            for seat_device in seat_devices:
                SLS.SendRequest(seat_device, unbuckle_load)
            for seat_key in seat_keys:
                if CANC_BELT_ODS.get(seat_key):
                    SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
        """).strip("\n") + "\n" + OCS_RELOAD)
    else:
        b.add(12, 'aria_reports.add_group(f"Step 3: Create fault - {fault_text}")')
        if variant == "s2b":
            leak_set(b, "vbat_high")
        b.add(12, """
            for seat_device in seat_devices:
                fault_response = SLS.SendRequest(seat_device, fault_load)
                RESULT.InterpretEqualResult(f"{seat_device} set to {fault_load}", fault_response,
                                            f"{fault_load} for {seat_device} set OK.")
        """)
        measure(b, 12, "qualification_time_ms", "DTC_active")
        grade(b, 12, "qualification_time_ms", "Qualification time", "qualify")
        read_dtc(b, 12, "DTC active after the qualification time", "DTC_active")
        belt_poll(b, "seat_states['Buckle Faulty']", 'f"{seat_key} faulty"')
        lamp(b, 12, "on", 'f"Warning lamp ON with {timed_dtcs} active"')
        b.add(12, "aria_reports.close_group()")
        b.add(12, 'aria_reports.add_group(f"Step 4: Remove fault - back to {unbuckle_load}")')
        if variant == "s2b":
            leak_clear(b, "vbat_high")
        b.add(12, """
            for seat_device in seat_devices:
                RESULT.InterpretEqualResult(f"{seat_device} set back to {unbuckle_load}", SLS.SendRequest(seat_device, unbuckle_load),
                                            f"{unbuckle_load} for {seat_device} set OK.")
        """)
        measure(b, 12, "dequalification_time_ms", "DTC_healed")
        grade(b, 12, "dequalification_time_ms", "Dequalification time", "recover")
        read_dtc(b, 12, "DTC healed after the dequalification time", "DTC_healed")
        belt_poll(b, "next(value for label, value in seat_states.items() if label.startswith('Not Buckled'))",
                  'f"{seat_key} unbuckled after the fault healed"')
        lamp(b, 12, "off", 'f"Warning lamp OFF with {timed_dtcs} healed"')
        b.add(12, "aria_reports.close_group()")
        historic_step(b, 5)
        clear_step(b, 6)
        tail(b, ("PS.ClearLeakageVBATBusHigh()\n" if variant == "s2b" else "") + textwrap.dedent("""
            for seat_device in seat_devices:
                SLS.SendRequest(seat_device, unbuckle_load)
            for seat_key in seat_keys:
                if CANC_BELT_ODS.get(seat_key):
                    SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
        """).strip("\n") + "\n" + OCS_RELOAD)
    names = {"buckled": "Fault_List_DCS_Buckled_Signal_Status", "unbuckled": "Fault_List_DCS_Unbuckled_Signal_Status",
             "s2b": "Fault_List_DCS_S2B_Signal_Status", "xconn": "Fault_List_DCS_CrossConnect_Signal_Status"}
    objectives = {
        "buckled": "Belt buckled (800R) is sent as Buckled on CAN without a DTC, and again after an IGN cycle.",
        "unbuckled": "Belt unbuckled (200R) after buckled is sent as Not Buckled on CAN without a DTC, and again "
                     "after an IGN cycle.",
        "s2b": "Belt buckle shorted to battery: DTC active within the qualification time, status Buckle Faulty and "
               "lamp ON; after the heal the DTC is healed, status Not Buckled and lamp OFF; historic after an IGN "
               "cycle; cleared.",
        "xconn": "Belt buckle pair cross-connected: both DTCs active within the qualification time, both statuses "
                 "Buckle Faulty and lamp ON; after the heal both healed, statuses Not Buckled and lamp OFF; historic "
                 "after an IGN cycle; cleared.",
    }
    timing_doc = {"buckled": "Status read until it shows the value or PROVEOUT_COMPLETION_TIME has passed.",
                  "unbuckled": "Status read until it shows the value or PROVEOUT_COMPLETION_TIME has passed.",
                  "s2b": DCS_TIMING_NOTE.format(q="3200 / 3200"),
                  "xconn": DCS_TIMING_NOTE.format(q="1900 / 1900 (cross connect)")}[variant]
    targets_doc = ("Belt pairs of canc_config.CANC_BELT_CROSS_CONNECT_PARTNER, each pair once." if pairs else
                   "Every belt status signal of canc_config.CANC_BELT_CHANNEL (one report per belt).")
    return Script(names[variant], objectives[variant], targets_doc, timing_doc, b.text(),
                  ["Rear belts: the seat ODS is set present first (canc_config.CANC_BELT_ODS; the rear belt "
                   "status needs it) and set back to not present in the cleanup.",
                   OCS_NOTE,
                   "Loads: dcs_config.DCS_Fault_Description buckle 800R / unbuckle 200R, canc_config "
                   "CANC_DCS_FAULT_LOAD for the fault, CANC_ODS_LOADS for the ODS, set with SLS.SendRequest."])


# ---------------------------------------------------------------------------
# RSU satellites
# ---------------------------------------------------------------------------

RSU_KINDS = {
    "Open": ("Open", "an open circuit", "RSU.SetFaultOpen", "Fault 'OPEN-NC' set for RSU {rsu_channel}", True),
    "S2G": ("S2G", "a short to ground", "RSU.SetFaultShortGround", "Fault 'STG' set for RSU {rsu_channel}", True),
    "S2B": ("S2B", "a short to battery", "RSU.SetFaultShortBattery", "Fault 'STB' set for RSU {rsu_channel}", True),
    "Communication": ("Communication_Error", "a communication (parity) error", "RSU.SetFaultParity",
                      "Fault 'Parity' set for RSU {rsu_channel}", False),
}


def rsu(kind: str) -> Script:
    config_key, text, call, answer, graded = RSU_KINDS[kind]
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"fault_kind = {config_key!r}")
    timing(b, "RSU_FAULT_TIME", "Qualification", None, source="rsu_config.RSU_FAULT_TIME")
    b.add(4, """
        # RSU faults are latched (fault list: dematuration "Next Cycle"): once the fault is removed the
        # DTC must stay active over the rsu_config dequalification window and heal only in the next cycle.
        latch_window_ms = int(RSU_FAULT_TIME['Dequalification'] * (1 + RSU_FAULT_TIME['Dequalification_Tolerance'] / 100)
                              + measurement_lag_ms)
        targets = list(RSU_CHANNELS)
        print(f"{script_name}: {len(targets)} RSU channels")
        for target_no, rsu_channel in enumerate(targets, start=1):
            rsu_sensor = RSU_CHANNEL_TO_SENSOR[rsu_channel]
            fault_dtcs = [f"{DTC_RSU_fault[rsu_channel]} {rsu_fault_code[fault_kind]}"] if rsu_channel in DTC_RSU_fault else []
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{script_name}_{target_no:02d}_{rsu_channel}_{rsu_sensor}"
    """)
    b.add(8, f"""
        fault_text = f"{text} on {{rsu_channel}} ({{rsu_sensor}})"
        tc_desc = (f"Verify that {text} on {{rsu_channel}} ({{rsu_sensor}}) sets its DTC with the warning lamp on, "
                   f"that the DTC stays active after the fault is removed (latched) and is historic after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"rsu_config.DTC_RSU_fault of {rsu_channel}"', "fault_dtcs")])
    precondition(b, "RSU.ClearFault(rsu_channel)")
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    b.add(12, f"""
        fault_response = {call}(rsu_channel)
        RESULT.InterpretEqualResult(f"{{rsu_channel}} ({{rsu_sensor}}) fault set", fault_response,
                                    f"{answer}")
        if fault_response != f"{answer}":
            aria_reports.close_group()
            continue
    """)
    qualify_step(b, graded=graded,
                 why="the fault list gives this fault the maturation 2.051 s / 2.134 s, no single nominal")
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group("Step 3: Remove fault - the DTC stays active until the next cycle")')
    b.add(12, """
        heal_response = RSU.ClearFault(rsu_channel)
        RESULT.InterpretEqualResult(f"{rsu_channel} ({rsu_sensor}) fault cleared", heal_response,
                                    f"Fault cleared for RSU {rsu_channel}")
        Wait(latch_window_ms)
    """)
    read_dtc(b, 12, "DTC still active after the fault is removed (latched)", "DTC_active")
    lamp(b, 12, "on", 'f"Warning lamp still ON with {timed_dtcs} latched"')
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4, settle=True)
    clear_step(b, 5)
    tail(b, "RSU.ClearFault(rsu_channel)")
    timing_doc = ("rsu_config.RSU_FAULT_TIME Qualification 1500 ms, tolerance percent 10; upper limit + "
                  "FAULT_TIME_MEASUREMENT_LAG_MS." if graded else
                  "Recorded, not graded: the fault list gives the communication fault the maturation "
                  "2.051 s / 2.134 s, not the 1500 ms of rsu_config.RSU_FAULT_TIME.")
    return Script(f"Fault_List_RSU_Fault_{kind}",
                  f"Each RSU channel with {text}: DTC active (0x8B) and lamp ON; after the fault is removed the DTC "
                  f"stays active (latched, dematuration 'Next Cycle'); historic (0x08) and lamp OFF after an IGN "
                  f"cycle; cleared.",
                  "rsu_config.RSU_CHANNELS (21 channels; the bench descriptor has RSU_CH1-18, so CH19-21 report "
                  "a refused fault).",
                  timing_doc, b.text(),
                  ["Fault through the shared RSU wrappers (the calls SetRsuFaultCondition makes), whose answers "
                   "show whether ARIA took the fault; DTC = rsu_config DTC_RSU_fault + rsu_fault_code.",
                   "Latched: rsu_config RSU_FAULT_TIME gives Dequalification 1500 ms, the fault list 'Next Cycle'; "
                   "the script waits that window and expects the DTC still active."])


def rsu_internal() -> Script:
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, """
        fault_kind = 'Internal_Error'
        # SetRsuFaultCondition('INTERNAL') saturates the sensor through RSU.SetAcceleration, which needs
        # rsu_config.RSU_INTERNAL_SATURATION_DATA and the card address of the channel in RSU_ATTRIBUTES.
        saturation_data = getattr(rsu_config, 'RSU_INTERNAL_SATURATION_DATA', None)
        rsu_attributes = getattr(rsu_config, 'RSU_ATTRIBUTES', {})
        latch_window_ms = int(RSU_FAULT_TIME['Dequalification'] * (1 + RSU_FAULT_TIME['Dequalification_Tolerance'] / 100)
                              + measurement_lag_ms)
        if saturation_data is None or not rsu_attributes:
            tc_name, fault_text = script_name, "RSU internal error (sensor saturation)"
            tc_desc = "Verify the RSU internal-error DTC of every RSU channel."
            report_path, log_path = create_report_and_logging(
                tc_name, can_ids=resolve_can_log_ids([lamp_def]), tc_desc=tc_desc)
            aria_reports.add_report_info("#Test Case Name:", tc_name)
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: rsu_config.RSU_INTERNAL_SATURATION_DATA and rsu_config.RSU_ATTRIBUTES (CH_AD / CH_ID "
                "per RSU channel); no RSU channel can be saturated", False)
            aria_reports.write_to_file()
            return
        targets = [name for name in RSU_CHANNELS if name in rsu_attributes]
        print(f"{script_name}: {len(targets)} RSU channels")
        for target_no, rsu_channel in enumerate(targets, start=1):
            rsu_sensor = RSU_CHANNEL_TO_SENSOR[rsu_channel]
            fault_dtcs = [f"{DTC_RSU_fault[rsu_channel]} {rsu_fault_code[fault_kind]}"] if rsu_channel in DTC_RSU_fault else []
            timed_dtcs = " and ".join(fault_dtcs)
            tc_name = f"{script_name}_{target_no:02d}_{rsu_channel}_{rsu_sensor}"
            fault_text = f"internal error (saturation {saturation_data}) on {rsu_channel} ({rsu_sensor})"
            tc_desc = (f"Verify that a saturated sensor on {rsu_channel} ({rsu_sensor}) sets the internal-error DTC "
                       f"with the warning lamp on, that it stays active after the saturation ends (latched) and is "
                       f"historic after an IGN cycle.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"rsu_config.DTC_RSU_fault of {rsu_channel}"', "fault_dtcs")])
    precondition(b)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    b.add(12, """
        fault_response = SetRsuFaultCondition("INTERNAL", rsu_channel, "")
        if not isinstance(fault_response, (list, tuple)) or fault_response[0] != "0000":
            aria_reports.close_group()
            continue
    """)
    qualify_step(b, graded=False, why="the fault list gives the maturation 2.179 / 2.262 / 3.065 s (sensor busy)")
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group("Step 3: Remove fault - the DTC stays active until the next cycle")')
    b.add(12, """
        # 0 LSB: the sensor reports no acceleration again.
        heal_response = RSU.SetAcceleration(rsu_channel, 0)
        RESULT.InterpretEqualResult(f"{rsu_channel} ({rsu_sensor}) back to 0 LSB", str(heal_response[0]), "0000")
        Wait(latch_window_ms)
    """)
    read_dtc(b, 12, "DTC still active after the saturation ends (latched)", "DTC_active")
    lamp(b, 12, "on", 'f"Warning lamp still ON with {timed_dtcs} latched"')
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4, settle=True)
    clear_step(b, 5)
    tail(b, "RSU.SetAcceleration(rsu_channel, 0)")
    return Script("Fault_List_RSU_Fault_Internal",
                  "Each RSU channel with a saturated sensor (internal error): DTC active (0x8B) and lamp ON; after "
                  "the saturation ends the DTC stays active (latched); historic (0x08) and lamp OFF after an IGN "
                  "cycle; cleared.",
                  "rsu_config.RSU_CHANNELS that have card data in rsu_config.RSU_ATTRIBUTES.",
                  "Recorded, not graded: the fault list gives 2.179 / 2.262 / 3.065 s (sensor busy), no single "
                  "nominal.",
                  b.text(),
                  ["Blocked until rsu_config has RSU_INTERNAL_SATURATION_DATA and RSU_ATTRIBUTES (today both are "
                   "missing or empty): the script then writes one report naming them and stops.",
                   "The saturation is ended with RSU.SetAcceleration(channel, 0) (assumption: 0 LSB is the "
                   "sensor's rest value)."],
                  module_imports=["rsu_config"])


# ---------------------------------------------------------------------------
# EOL configuration
# ---------------------------------------------------------------------------

def eol_dtc_setup(body: Body, indent: int):
    body.add(indent, """
        feature_group = list(EOL_PAB_Dependencies) if feature in EOL_PAB_Dependencies else [feature]
        # eol_config gives each DTC as 'HHLL' plus its failure-type byte ('status_byte').
        fault_dtcs = [f"0x{record['dtc'][:2].upper()} 0x{record['dtc'][2:].upper()} 0x{record['status_byte'].upper()}"
                      for member in feature_group for record in EOL_FEATURE_AVAILABLE_DTCS.get(member, [])]
        if fault_dtcs:
            fault_dtcs.append(f"0x{EOL_CONFIG_ERROR_DTC['dtc'][:2].upper()} 0x{EOL_CONFIG_ERROR_DTC['dtc'][2:].upper()} "
                              f"0x{EOL_CONFIG_ERROR_DTC['status_byte'].upper()}")
        timed_dtcs = " and ".join(fault_dtcs)
    """)


def eol_write(body: Body, indent: int, action: str, label: str):
    """Write the EOL code. 'disable' clears the feature group's bits in the project default; 'default'
    writes the project default back, which enables every tested feature again. Writing 'enable' for the
    group instead would also set PAB_MODE (EOL_PAB_Dependencies), which the project default keeps off.
    The cleanup restores the project default while eol_changed is set."""
    call = ("manage_eol_code(feature_group, 'disable', project=PROJECT_NAME, base_from_project_default=True)"
            if action == "disable" else 'manage_eol_code("DEFAULT", project=PROJECT_NAME)')
    body.add(indent, f"""
        eol_result = {call}
        eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
        RESULT.InterpretEqualResult(f"{label}",
                                    str(eol_status), "PASS")
        if eol_status != "PASS":
            aria_reports.close_group()
            continue
        eol_changed = {action == "disable"}
        # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
    """)


def eol_dtc_flow(body: Body, first_step: int = 2):
    s = first_step
    body.add(12, f'aria_reports.add_group("Step {s}: Disable " + ", ".join(feature_group) + " in the EOL code")')
    eol_write(body, 12, "disable", "EOL code written with {', '.join(feature_group)} disabled")
    measure(body, 12, "settle_time_ms", "DTC_active")
    record(body, 12, "settle_time_ms", "Time until {timed_dtcs} is active after the start-up")
    read_dtc(body, 12, "Configuration DTCs active with the feature disabled", "DTC_active")
    lamp(body, 12, "on", 'f"Warning lamp ON with {timed_dtcs} active"')
    body.add(12, "aria_reports.close_group()")
    body.add(12, f'aria_reports.add_group("Step {s + 1}: Project default EOL code back - " + ", ".join(feature_group) '
                 f'+ " enabled again")')
    eol_write(body, 12, "default", "Project default EOL code written ({', '.join(feature_group)} enabled again)")
    read_dtc(body, 12, "Configuration DTCs historic with the feature enabled again", "DTC_historic")
    lamp(body, 12, "off", 'f"Warning lamp OFF with {timed_dtcs} historic"')
    body.add(12, "aria_reports.close_group()")
    clear_step(body, s + 2)


def eol(kind: str) -> Script:
    tests, what = {"Loop": ("EOL_LOOP_TESTS", "squib loop"), "RSU": ("EOL_RSU_TESTS", "RSU"),
                   "GPO": ("EOL_GPO_TESTS", "GPO output")}[kind]
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, f"""
        targets = list({tests})
        print(f"{{script_name}}: {{len(targets)}} EOL features")
        for target_no, eol_test in enumerate(targets, start=1):
            feature = eol_test['feature']
            eol_changed = False
    """)
    eol_dtc_setup(b, 8)
    b.add(8, f"""
        tc_name = f"{{script_name}}_{{target_no:02d}}_{{feature}}"
        fault_text = f"EOL feature {{feature}} disabled with the {what} present"
        tc_desc = (f"Verify that disabling EOL feature {{feature}} with the {what} present sets its configuration "
                   f"DTC and the ECU configuration error with the warning lamp on, and that both are historic once "
                   f"the feature is enabled again.")
    """)
    report(b)
    b.add(8, "try:")
    missing(b, [('f"eol_config.EOL_FEATURE_AVAILABLE_DTCS of {feature}"', "fault_dtcs")])
    precondition(b)
    eol_dtc_flow(b)
    tail(b, """
        if eol_changed:
            manage_eol_code("DEFAULT", project=PROJECT_NAME)
            Wait(PROVEOUT_COMPLETION_TIME)
    """)
    return Script(f"EOL_{kind}_Test_Cases",
                  f"Each {what} EOL feature of eol_config.{tests} disabled with the hardware present: the feature's "
                  f"configuration DTC and the ECU configuration error (eol_config.EOL_CONFIG_ERROR_DTC) active "
                  f"(0x8B) with the lamp ON; with the feature enabled again both historic (0x08) and the lamp OFF; "
                  f"cleared.",
                  f"eol_config.{tests}; a feature of eol_config.EOL_PAB_Dependencies is switched with its whole "
                  f"PAB group.",
                  "No timing grade: the DTCs are read after the start-up proveout that follows each EOL write "
                  "(manage_eol_code cycles the ignition).",
                  b.text(),
                  ["EOL code written with the shared manage_eol_code: disabled = the project default with the "
                   "feature (group) cleared; enabled again = the project default itself, in which every tested "
                   "feature is on and PAB_MODE of the PAB group stays off. The cleanup writes the project "
                   "default back when the feature was left disabled."])


def eol_switch() -> Script:
    b = Body()
    b.add(4, PROLOGUE)
    table = ["# EOL feature -> DCS / ODS channel. No configuration table links the two; both sides are names",
             "# from eol_config.EOL_SWITCH_DCS_FEATURES and dcs_config.DCSName / ods_config.ODSChannelName.",
             "eol_seat_channel = {"]
    table += [f"    {feature!r}: {channel!r}," for feature, channel in EOL_SEAT_CHANNEL.items()]
    table.append("}")
    b.add(4, "\n".join(table))
    timing(b, "DCS_fault_time", "Qualification", "Dequalification", "dcs_faultcounter_offset",
           "dcs_config.DCS_fault_time (fault counter offset added)")
    b.add(4, """
        fault_load = CANC_DCS_FAULT_LOAD
        ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
        targets = list(EOL_SWITCH_DCS_TESTS)
        print(f"{script_name}: {len(targets)} EOL features")
        for target_no, eol_test in enumerate(targets, start=1):
            feature = eol_test['feature']
            eol_changed = False
            seat_channel = eol_seat_channel.get(feature)
            seat_device = DCSName.get(seat_channel) or ODSChannelName.get(seat_channel)
            rest_load = DCS_Fault_Description['unbuckle'] if seat_channel in DCSName else CANC_ODS_LOADS['NOT_PRESENT']
            status_key = next((key for key, name in list(CANC_BELT_CHANNEL.items()) + list(CANC_ODS_CHANNEL.items())
                               if name == seat_channel), None)
            seat_keys = [status_key] if status_key in CANC_BELT_ODS else []
    """)
    eol_dtc_setup(b, 8)
    b.add(8, """
        if not fault_dtcs and seat_channel:
            fault_entry = DCS_FAULT_BY_CHANNEL.get(seat_channel, {}).get('S2B')
            fault_dtcs = [fault_entry['dtc']] if fault_entry and fault_entry['dtc'] else []
            timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{script_name}_{target_no:02d}_{feature}"
        fault_text = (f"EOL feature {feature} disabled, short to battery on {seat_channel}" if seat_channel and not
                      EOL_FEATURE_AVAILABLE_DTCS.get(feature) else f"EOL feature {feature} disabled with the sensor present")
        tc_desc = (f"Verify the EOL configuration of {feature}: disabled it is not monitored (no DTC for a seat "
                   f"switch, the configuration DTC for a sensor), enabled it is monitored again.")
    """)
    report(b, "[lamp_def, ocs_class_def]")
    b.add(8, "try:")
    missing(b, [('f"expected DTC of EOL feature {feature} (eol_config or the DCS/ODS fault list entry)"',
                 "fault_dtcs"),
                ('f"CAN status signal of {seat_channel}"', "status_key or not seat_channel")])
    precondition(b, textwrap.dedent(OCS_OCCUPIED).strip("\n") + "\n" + textwrap.dedent("""
        if seat_device:
            PS.ClearLeakageVBATBusHigh()
            RESULT.InterpretEqualResult(f"{seat_device} at rest ({rest_load})", SLS.SendRequest(seat_device, rest_load),
                                        f"{rest_load} for {seat_device} set OK.")
    """).strip("\n"))
    b.add(12, """
        if EOL_FEATURE_AVAILABLE_DTCS.get(feature) or not seat_channel:
    """)
    # Sensor features (STPS): configuration DTC flow, one level deeper.
    inner = Body()
    eol_dtc_flow(inner)
    b.parts.append(textwrap.indent(inner.text(), "    "))
    b.add(16, "continue")
    # Seat switches / ODS
    b.add(12, 'aria_reports.add_group("Step 2: Seat ODS present where the belt status needs it")')
    ods_prerequisite(b)
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 3: Disable {feature}, then short {seat_channel} to battery")')
    eol_write(b, 12, "disable", "EOL code written with {', '.join(feature_group)} disabled")
    leak_set(b, "vbat_high")
    relay(b, 12, "fault_response", "SLS.SendRequest", "seat_device", "fault_load",
          'f"{seat_device} ({seat_channel}) set to {fault_load}"')
    b.add(12, """
        # Not configured, the channel is not monitored: no DTC over the qualification time.
        Wait(int(qualify_nominal_ms + qualify_tolerance_ms + measurement_lag_ms))
        Read_DTC('No DTC with the feature disabled', Read_DTC_Resp, Read_DTC_Req)
    """)
    poll(b, 12, "MAH_CAN_SIGNAL_DEFS[status_key]", "MAH_CAN_SIGNAL_DEFS[status_key].get('Default_Value')",
         'f"{status_key} sent as the default with {feature} disabled"')
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 4: Project default EOL code back - {feature} enabled again, '
              'the short still applied")')
    eol_write(b, 12, "default", "Project default EOL code written ({', '.join(feature_group)} enabled again)")
    measure(b, 12, "settle_time_ms", "DTC_active")
    record(b, 12, "settle_time_ms", "Time until {timed_dtcs} is active after the start-up")
    read_dtc(b, 12, "Short-to-battery DTC active with the feature enabled", "DTC_active")
    lamp(b, 12, "on", 'f"Warning lamp ON with {timed_dtcs} active"')
    poll(b, 12, "MAH_CAN_SIGNAL_DEFS[status_key]",
         "next(value for label, value in MAH_CAN_SIGNAL_DEFS[status_key]['State_Values'].items() if 'FAULTY' in label.upper())",
         'f"{status_key} faulty"')
    b.add(12, "aria_reports.close_group()")
    b.add(12, 'aria_reports.add_group(f"Step 5: Remove fault - {seat_device} back to {rest_load}")')
    leak_clear(b, "vbat_high")
    relay(b, 12, "heal_response", "SLS.SendRequest", "seat_device", "rest_load",
          'f"{seat_device} ({seat_channel}) set back to {rest_load}"', stop=False)
    recover_step(b)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 6)
    clear_step(b, 7)
    tail(b, """
        if seat_device:
            PS.ClearLeakageVBATBusHigh()
            SLS.SendRequest(seat_device, rest_load)
        for seat_key in seat_keys:
            SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
        @OCS_RELOAD@
        if eol_changed:
            manage_eol_code("DEFAULT", project=PROJECT_NAME)
            Wait(PROVEOUT_COMPLETION_TIME)
    """.replace("@OCS_RELOAD@", OCS_RELOAD))
    return Script("EOL_Switch_DCS_Test_Cases",
                  "EOL switch / DCS features. Seat switch or ODS: disabled and shorted to battery - no DTC and the "
                  "status sent as the default; enabled again with the short - its DTC active (0x8B), lamp ON, "
                  "status faulty; short removed - healed within the dequalification time; historic after an IGN "
                  "cycle; cleared. STPS sensor: configuration DTC + ECU configuration error active while disabled, "
                  "historic once enabled.",
                  "eol_config.EOL_SWITCH_DCS_TESTS (15 features; DOMS has no expected DTC in the configuration and "
                  "reports that).",
                  DCS_TIMING_NOTE.format(q="3200 / 3200") + " (healing of the seat short).",
                  b.text(),
                  ["The EOL feature -> seat channel table is written into the script (no configuration table links "
                   "them).",
                   "Fault = canc_config CANC_DCS_FAULT_LOAD with the power card leakage VBAT to bus high; DTC from "
                   "fault_list_config.DCS_FAULT_BY_CHANNEL.",
                   "Enabled again = the project default EOL code (manage_eol_code DEFAULT), in which every tested "
                   "feature is on.",
                   OCS_NOTE])


# ---------------------------------------------------------------------------
# CAN-C faults
# ---------------------------------------------------------------------------

# Fault list entry name endings per CAN script kind (fault_list_config.CAN_FAULTS).
CAN_FAULT_LIST_SUFFIX = {"node_absent": "_NODE_ABSENT", "message_timeout": "_TIMEOUT", "crc": "_CRC",
                         "counter": "_COUNTER", "dlc": "_DLC", "scf": "_SCF"}


def can_targets(kind: str) -> list[tuple[str, str | None, str | None]]:
    """(frame, signal key, DTC) of each target, as the generated script selects them at run time."""
    cfg, c = canc_config.CAN_TX_MESSAGE_CONFIG, canc_config
    if kind == "node_absent":
        return [(f, None, c.resolve_dtc_for_event(kind, f)) for f in cfg if c.resolve_dtc_for_event(kind, f)
                and (c.is_key_message(f) or len([n for n in cfg if cfg[n].get("key_node") == cfg[f].get("key_node")]) == 1)]
    if kind == "message_timeout":
        return [(f, None, c.resolve_dtc_for_event(kind, f)) for f in cfg
                if c.resolve_dtc_for_event(kind, f) and not c.is_key_message(f)]
    if kind in ("crc", "counter"):
        return [(f, s, c.get_message_content_failure_dtcs(f).get(s)) for f in cfg
                for s in c.get_message_content_failure_signals(f) if ("CRC" in s.upper()) == (kind == "crc")]
    if kind == "dlc":
        return [(f, None, c.get_frame_message_content_failure_dtc(f)[0] or c.CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(f))
                for f in cfg if c.get_frame_message_content_failure_dtc(f)[0] or c.CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(f)]
    return [(f, s, d) for f in cfg for s, d in (cfg[f].get("signal_content_failure_dtcs") or {}).items()]


def can_coverage_notes(kind: str) -> list[str]:
    """Fault list entries of this kind the configuration gives no target for, and targets whose DTC the
    fault list does not carry."""
    dtcs = {dtc for _, _, dtc in can_targets(kind)}
    listed = {name: entry for name, entry in fault_list_config.CAN_FAULTS.items()
              if name.endswith(CAN_FAULT_LIST_SUFFIX[kind])}
    notes = []
    uncovered = [f"{name} ({entry['dtc']})" for name, entry in listed.items() if entry["dtc"] not in dtcs]
    if uncovered:
        notes.append("Not covered - the M310_M314_M110 CAN configuration defines no target for these fault list "
                     "entries: " + ", ".join(uncovered) + ".")
    extra = sorted({f"{frame} ({dtc})" for frame, _, dtc in can_targets(kind)
                    if dtc not in {entry["dtc"] for entry in listed.values()}})
    if extra:
        notes.append("Covered from canc_config but not in the fault list: " + ", ".join(extra) + ".")
    return notes


CAN_KINDS = {
    "node_absent": ("Fault_List_CAN_Node_Absent_Timing", "node absent"),
    "message_timeout": ("Fault_List_CAN_Message_Timeout_Timing", "message timeout"),
    "crc": ("Fault_List_CAN_Message_Content_Failure_CRC_Timing", "CRC error"),
    "counter": ("Fault_List_CAN_Message_Content_Failure_Alive_Counter_Timing", "alive counter error"),
    "dlc": ("Fault_List_CAN_Message_Content_Failure_DLC_Timing", "wrong DLC"),
    "scf": ("Fault_List_CAN_Signal_Content_Failure_Timing", "signal content failure"),
}


def can(kind: str) -> Script:
    name, text = CAN_KINDS[kind]
    b = Body()
    b.add(4, PROLOGUE)
    b.add(4, """
        qualify_tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT
        recover_tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT
    """)
    if kind == "node_absent":
        b.add(4, """
            fault_mode = 'node_absent'
            # One frame per node: its key frame, or the only frame of a single-frame node.
            targets = []
            for frame_name, frame_config in CAN_TX_MESSAGE_CONFIG.items():
                node_frames = [name for name, entry in CAN_TX_MESSAGE_CONFIG.items()
                               if entry.get('key_node') == frame_config.get('key_node')]
                if resolve_dtc_for_event(fault_mode, frame_name) and (is_key_message(frame_name) or len(node_frames) == 1):
                    targets.append((frame_name, None))
        """)
    elif kind == "message_timeout":
        b.add(4, """
            fault_mode = 'message_timeout'
            # Stopping a key frame raises node absent, which has priority over the timeout, so the timeout
            # is created on the frames that are not key frames.
            targets = [(frame_name, None) for frame_name in CAN_TX_MESSAGE_CONFIG
                       if resolve_dtc_for_event(fault_mode, frame_name) and not is_key_message(frame_name)]
        """)
    elif kind in ("crc", "counter"):
        test = "in" if kind == "crc" else "not in"
        b.add(4, f"""
            fault_mode = 'message_content'
            targets = [(frame_name, signal_key) for frame_name in CAN_TX_MESSAGE_CONFIG
                       for signal_key in get_message_content_failure_signals(frame_name) if 'CRC' {test} signal_key.upper()]
        """)
    elif kind == "dlc":
        b.add(4, """
            fault_mode = 'message_content'
            targets = [(frame_name, None) for frame_name in CAN_TX_MESSAGE_CONFIG
                       if get_frame_message_content_failure_dtc(frame_name)[0]
                       or CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(frame_name)]
        """)
    else:
        b.add(4, """
            fault_mode = 'signal_content'
            targets = [(frame_name, next((key for key, definition in MAH_CAN_SIGNAL_DEFS.items()
                                          if definition['frame'] == frame_name and definition['signal'] == signal_name), signal_name))
                       for frame_name, frame_config in CAN_TX_MESSAGE_CONFIG.items()
                       for signal_name in frame_config.get('signal_content_failure_dtcs', {})]
        """)
    b.add(4, """
        print(f"{script_name}: {len(targets)} targets")
        for target_no, (fault_frame, signal_key) in enumerate(targets, start=1):
            frame_def = next((d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame), None)
            fault_bus = frame_def['bus'] if frame_def else None
    """)
    if kind in ("node_absent", "message_timeout"):
        b.add(8, "fault_dtcs = [dtc for dtc in (resolve_dtc_for_event(fault_mode, fault_frame),) if dtc]")
        apply_code = "CAN.PeriodicDisableFrame(fault_bus, fault_frame)"
        heal_code = "CAN.PeriodicEnableFrame(fault_bus, fault_frame)\nCAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)"
        rest_code = heal_code
        label = 'fault_frame'
        fault_text_code = 'f"stop transmission of {fault_frame} ({fault_bus})"'
        heal_text = 'f"resume valid transmission of {fault_frame}"'
    elif kind in ("crc", "counter"):
        b.add(8, """
            signal_name = MAH_CAN_SIGNAL_DEFS.get(signal_key, {}).get('signal')
            fault_dtcs = [dtc for dtc in (get_message_content_failure_dtcs(fault_frame).get(signal_key),) if dtc]
        """)
        what = "CRC" if kind == "crc" else "alive counter"
        apply_code = "CAN.DynamicDisableSignal(fault_bus, fault_frame, signal_name)"
        heal_code = "CAN.DynamicEnableSignal(fault_bus, fault_frame, signal_name)"
        rest_code = ("CAN.PeriodicEnableFrame(fault_bus, fault_frame)\nCAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)\n"
                     + heal_code)
        label = 'fault_frame + "_" + str(signal_key)'
        fault_text_code = f'f"{what} of {{fault_frame}} no longer updated ({{signal_name}} held)"'
        heal_text = f'f"{what} of {{fault_frame}} updated again"'
    elif kind == "dlc":
        b.add(8, """
            fault_dtcs = [dtc for dtc in (get_frame_message_content_failure_dtc(fault_frame)[0]
                                          or CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(fault_frame),) if dtc]
            dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals(fault_frame)
                               if key in MAH_CAN_SIGNAL_DEFS]
            counter_key = next((key for key in get_message_content_failure_signals(fault_frame) if 'CRC' not in key.upper()), None)
        """)
        apply_code = textwrap.dedent("""
            # The frame itself goes out with the shorter payload (a second simulated frame on the same
            # identifier is refused by ARIA); the bench CRC / alive counter are held while it is short.
            error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[frame_def['dlc']])
            for dynamic_signal in dynamic_signals:
                CAN.DynamicDisableSignal(fault_bus, fault_frame, dynamic_signal)
            CAN.SetPeriodicFrame(fault_bus, fault_frame, frame_def['frame_ID'], frame_def['periodicity'],
                                 error_payload, frame_def['is_fd'])
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        """).strip("\n")
        heal_code = textwrap.dedent("""
            CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
            for dynamic_signal in dynamic_signals:
                CAN.DynamicEnableSignal(fault_bus, fault_frame, dynamic_signal)
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        """).strip("\n")
        rest_code = heal_code
        label = 'fault_frame'
        fault_text_code = 'f"payload of {fault_frame} shortened to {CAN_DLC_ERROR_PAYLOAD_LENGTH.get(frame_def[\'dlc\']) if frame_def else None} bytes"'
        heal_text = 'f"default payload of {fault_frame} reloaded"'
    else:
        b.add(8, """
            signal_def = MAH_CAN_SIGNAL_DEFS.get(signal_key, {})
            signal_name = signal_def.get('signal', signal_key)
            fault_dtcs = [dtc for dtc in (CAN_TX_MESSAGE_CONFIG[fault_frame]['signal_content_failure_dtcs'].get(signal_name),) if dtc]
            invalid_value = signal_def.get('Invalid_Value')
            recovery_value = signal_def.get('SCF_Recovery_Value')
            if recovery_value is None:
                recovery_value = signal_def.get('Default_Value')
        """)
        apply_code = "CAN.ChangeSignalValue(fault_bus, fault_frame, signal_name, str(invalid_value))"
        heal_code = "CAN.ChangeSignalValue(fault_bus, fault_frame, signal_name, str(recovery_value))"
        rest_code = "CAN.PeriodicEnableFrame(fault_bus, fault_frame)\nCAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)"
        label = 'fault_frame + "_" + str(signal_name)'
        fault_text_code = 'f"invalid value {invalid_value} for {signal_name} in {fault_frame}"'
        heal_text = 'f"valid value {recovery_value} for {signal_name} in {fault_frame}"'
    b.add(8, f"""
        timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{{script_name}}_{{target_no:02d}}_" + {label}
        fault_text = {fault_text_code}
        tc_desc = (f"Verify that {text} on {{fault_frame}} sets its DTC within count x period, heals within "
                   f"the recovery count x period and is historic after an IGN cycle.")
    """)
    report(b, "[frame_def] + [lamp_def] if frame_def else [lamp_def]")
    b.add(8, "try:")
    needs = [('f"MAH_CAN_SIGNAL_DEFS entry of {fault_frame}"', "frame_def"),
             (f'f"{text} DTC of {{fault_frame}}"', "fault_dtcs")]
    if kind in ("crc", "counter"):
        needs.append(('f"signal of {signal_key}"', "signal_name"))
    if kind == "scf":
        needs += [('f"invalid value of {signal_name}"', "invalid_value is not None"),
                  ('f"recovery value of {signal_name}"', "recovery_value is not None")]
    missing(b, needs)
    b.add(12, """
        qualify_nominal_ms = qualification_ms(fault_mode, frame_def['periodicity'])
        recover_nominal_ms = recovery_ms(fault_mode, frame_def['periodicity'])
        qualify_tolerance_ms = qualify_nominal_ms * qualify_tolerance_percent / 100
        recover_tolerance_ms = recover_nominal_ms * recover_tolerance_percent / 100
        RESULT.InsertComment(f"{fault_frame} period {frame_def['periodicity']} ms: "
                             f"{qualify_nominal_ms // frame_def['periodicity']} frames to qualify, "
                             f"{recover_nominal_ms // frame_def['periodicity']} frames to heal")
    """)
    precondition(b, rest_code, can=True)
    b.add(12, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
    b.add(12, apply_code)
    qualify_step(b, can=True, lamp_state="off")
    b.add(12, "aria_reports.close_group()")
    b.add(12, f'aria_reports.add_group(f"Step 3: Remove fault - " + {heal_text})')
    if kind == "dlc":
        b.add(12, """
            # The ECU counts valid frames only from the first full-length frame on the bus, so the reload
            # and the first 19 02 read of the measurement are logged: the time from that read to the first
            # full-length frame moves the expected heal time.
            restore_ids = [frame_def['frame_ID'], DIAG_TX_ID]
            restore_file = os.path.splitext(log_path)[0] + '_restore.txt'
            restore_logger = CAN.StartLoggingToFile(
                TestCase_ID=tc_name + '_restore', filepath=restore_file,
                listOption=restore_ids, channel_names=list(dict.fromkeys([fault_bus, CAN_FD_CHANNEL_NAME])))
        """)
        b.add(12, heal_code)
        measure(b, 12, "dequalification_time_ms", "DTC_healed")
        b.add(12, """
            CAN.StopLoggingToFile(restore_logger)
            restore_frames = []
            if os.path.isfile(restore_file):
                # ARIA writes a log with any extension other than .asc/.blf as text, one frame per line:
                # "<time s>\\t<Can|CanFd> <channel>  <RX|TX>  l=<length>, id=<hex>, <payload bytes>".
                with open(restore_file, encoding='utf-8', errors='replace') as restore_log:
                    restore_fields = [line.split(',', 2) for line in restore_log if ' id=' in line and line.count(',') >= 2]
                restore_frames = [
                    SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                    id=int(fields[1].split('=')[1], 16),
                                    payload=bytearray.fromhex(fields[2].strip()))
                    for fields in restore_fields]
            else:
                RESULT.LogCustomAction(f"CAN log {os.path.basename(restore_file)} written", "File present",
                                       "File missing: no frames to evaluate", False)
            # The tester's DTC reads: ReadDTCInformation, reportDTCByStatusMask (configuration_control).
            read_dtc_service = bytes(int(code, 16) for code in (ReadDTCInformation, RDTCI_DTCbyStatusMask))
            restore_reads = [frame_data.timestamp for frame_data in restore_frames
                             if frame_data.id == DIAG_TX_ID and bytes(frame_data.payload[1:3]) == read_dtc_service]
            restore_rows = [frame_data for frame_data in restore_frames if frame_data.id == frame_def['frame_ID']]
            restore_short = [index for index, frame_data in enumerate(restore_rows) if len(frame_data.payload) != frame_def['dlc']]
            restore_full = next((index for index in range((restore_short[-1] + 1) if restore_short else 0, len(restore_rows))
                                 if len(restore_rows[index].payload) == frame_def['dlc']), None)
            if restore_full is None or not restore_reads:
                restart_ms = 0
                RESULT.LogCustomAction(
                    "First full-length frame and first DTC read after the reload", "Both in the CAN log",
                    "Not found: the heal time is graded from the measurement start", False)
            else:
                restart_ms = round((restore_rows[restore_full].timestamp - restore_reads[0]) / 1000, 1)
                RESULT.LogAction(f"{fault_frame} first full-length frame after the reload (ms after the first DTC read)",
                                 restart_ms)
                if restore_short and restore_full > 0:
                    RESULT.LogAction(f"{fault_frame} interval across the reload (ms, period {frame_def['periodicity']} ms)",
                                     round((restore_rows[restore_full].timestamp - restore_rows[restore_full - 1].timestamp) / 1000, 1))
                if counter_key in CAN_SIGNAL_START_BIT:
                    RESULT.LogAction(f"{counter_key} of the first frames after the reload", [
                        extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key],
                                           MAH_CAN_SIGNAL_DEFS[counter_key]['bit_length'])
                        for frame_data in restore_rows[restore_full:restore_full + 3]])
        """)
        grade(b, 12, "dequalification_time_ms", "Dequalification time", "recover", "recover_nominal_ms + restart_ms")
        read_dtc(b, 12, "DTC healed after the dequalification time", "DTC_healed", can=True)
    else:
        b.add(12, heal_code)
        measure(b, 12, "dequalification_time_ms", "DTC_healed")
        grade(b, 12, "dequalification_time_ms", "Dequalification time", "recover")
        read_dtc(b, 12, "DTC healed after the dequalification time", "DTC_healed", can=True)
    b.add(12, "aria_reports.close_group()")
    historic_step(b, 4, can=True)
    clear_step(b, 5, can=True)
    guard = {"crc": "frame_def and signal_name", "counter": "frame_def and signal_name",
             "scf": "frame_def and recovery_value is not None"}.get(kind, "frame_def")
    tail(b, f"if {guard}:\n" + textwrap.indent(heal_code, "    "))
    notes = ["Bench handling as in the CAN-C scripts, proven on the 2026-10-15 run; CAN DTC status 0x0B active "
             "(no lamp), 0x0A healed, 0x08 historic, read with 19 02 0B."]
    if kind == "dlc":
        notes.append("Heal = reload of the default frame; the expected heal time is moved by the time from the "
                     "measurement's first DTC read to the first full-length frame in the CAN log.")
    if kind == "message_timeout":
        notes.append("Fault list: node absent and message timeout take priority over message content failures.")
    if kind in ("node_absent", "message_timeout"):
        notes.append("Key frames from canc_config is_key_message. FR_ZONE's is FR_ZONE2_100, as the ECU showed on "
                     "2026-10-15.")
    notes += can_coverage_notes(kind)
    stdlib = ["from types import SimpleNamespace"] if kind == "dlc" else []
    return Script(name,
                  f"Every CAN-C {text} the configuration defines: DTC active (0x0B) within count x period with the "
                  f"warning lamp off; healed (0x0A) within the recovery count x period; historic (0x08) after an "
                  f"IGN cycle; cleared.",
                  {"node_absent": "One frame per node from canc_config.CAN_TX_MESSAGE_CONFIG: the key frame, or the "
                                  "only frame of a single-frame node, with a node-absent DTC.",
                   "message_timeout": "Every non-key frame of canc_config.CAN_TX_MESSAGE_CONFIG with a "
                                      "message-timeout DTC.",
                   "crc": "Every CRC signal of canc_config get_message_content_failure_signals().",
                   "counter": "Every alive-counter signal of canc_config get_message_content_failure_signals().",
                   "dlc": "Every frame with a DLC (message content failure) DTC in canc_config.",
                   "scf": "Every signal with a signal-content-failure DTC in canc_config.CAN_TX_MESSAGE_CONFIG."}[kind],
                  "Nominal = canc_config qualification_ms / recovery_ms (fault list count x frame period); pass "
                  "window nominal -10 % .. nominal +10 % (CAN_FAULT_TIMING_TOLERANCE_PERCENT) + "
                  "FAULT_TIME_MEASUREMENT_LAG_MS, the measured DTC read lag.",
                  b.text(), notes, stdlib)


# ---------------------------------------------------------------------------
# Suite runner
# ---------------------------------------------------------------------------

RUNNER = '''"""Run the M310/M314/M110 Fault List test scripts in a fixed order.

Author: Kris

Every script sweeps its targets and writes one report per target; a failing target is
reported and the sweep goes on. The suite stops only when a script raises, so the bench
can be restored before anything else runs. Comment out entries for a partial run, or
pass script names on the command line; --list prints the selection.
"""

from __future__ import annotations

import ast
import runpy
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

SELECTED_TESTS = [
@ENTRIES@
]


def run_suite(selection: list[str] | None = None) -> None:
    """Run the selected scripts; stop when one raises."""
    tests = selection or SELECTED_TESTS
    if not tests:
        raise ValueError("No Fault List scripts selected; no tests were executed")
    if len(tests) != len(set(tests)):
        raise ValueError("Fault List selection contains duplicate scripts")
    script_paths = []
    for script_name in tests:
        script_name = script_name if script_name.endswith(".py") else script_name + ".py"
        if Path(script_name).name != script_name or script_name in ("__init__.py", Path(__file__).name):
            raise ValueError(f"Not a Fault List test script: {script_name}")
        script_path = SCRIPT_DIR / script_name
        if not script_path.is_file():
            raise FileNotFoundError(f"Missing Fault List script: {script_name}")
        script_tree = ast.parse(script_path.read_text(encoding="utf-8"), filename=str(script_path))
        if not any(isinstance(node, ast.FunctionDef) and node.name == "run_test" for node in script_tree.body):
            raise ValueError(f"Fault List script has no run_test entry point: {script_name}")
        script_paths.append(script_path)
    for script_path in script_paths:
        print(f"\\n{'=' * 80}\\nRunning {script_path.name}\\n{'=' * 80}")
        try:
            runpy.run_path(str(script_path), run_name="__main__")
        except Exception as error:
            raise RuntimeError(
                f"Fault List suite stopped at {script_path.name}; restore the bench before further testing"
            ) from error


if __name__ == "__main__":
    if "--list" in sys.argv[1:]:
        print("\\n".join(SELECTED_TESTS))
        print(f"{len(SELECTED_TESTS)} scripts")
    else:
        run_suite([arg for arg in sys.argv[1:] if not arg.startswith("-")] or None)
'''

GROUPS = [
    ("Squib loop faults", ["Fault_List_Loop_Fault_Open", "Fault_List_Loop_Fault_S2B", "Fault_List_Loop_Fault_S2G",
                           "Fault_List_Loop_Fault_LoRes", "Fault_List_Loop_Fault_HiRes",
                           "Fault_List_Loop_Fault_CrossConnect"]),
    ("GPO output faults", [f"Fault_List_GPO_{out}_{kind}" for out in ("PAB_OFF", "PAB_ON", "ENS", "ECALL")
                           for kind in ("Open", "S2B", "S2G")]),
    ("DCS belt buckle faults and status", ["Fault_List_DCS_Fault_S2B", "Fault_List_DCS_Fault_CrossConnect",
                                           "Fault_List_DCS_Buckled_Signal_Status",
                                           "Fault_List_DCS_Unbuckled_Signal_Status",
                                           "Fault_List_DCS_S2B_Signal_Status",
                                           "Fault_List_DCS_CrossConnect_Signal_Status"]),
    ("ODS faults", ["Fault_List_ODS_Fault_S2B", "Fault_List_ODS_Fault_CrossConnect"]),
    ("STPS faults", ["Fault_List_STPS_Fault_Open", "Fault_List_STPS_Fault_S2B", "Fault_List_STPS_Fault_S2G",
                     "Fault_List_STPS_Fault_CrossConnect"]),
    ("RSU faults (latched)", ["Fault_List_RSU_Fault_Open", "Fault_List_RSU_Fault_S2G", "Fault_List_RSU_Fault_S2B",
                              "Fault_List_RSU_Fault_Communication", "Fault_List_RSU_Fault_Internal"]),
    ("CAN-C faults", ["Fault_List_CAN_Node_Absent_Timing", "Fault_List_CAN_Message_Timeout_Timing",
                      "Fault_List_CAN_Message_Content_Failure_CRC_Timing",
                      "Fault_List_CAN_Message_Content_Failure_Alive_Counter_Timing",
                      "Fault_List_CAN_Message_Content_Failure_DLC_Timing",
                      "Fault_List_CAN_Signal_Content_Failure_Timing"]),
    ("EOL configuration", ["EOL_Loop_Test_Cases", "EOL_RSU_Test_Cases", "EOL_GPO_Test_Cases",
                           "EOL_Switch_DCS_Test_Cases"]),
]


def render_runner(names: set[str]) -> str:
    listed = [name for _, group in GROUPS for name in group]
    assert sorted(listed) == sorted(names), (sorted(set(listed) ^ names))
    lines = []
    for title, group in GROUPS:
        if lines:
            lines.append("")
        lines.append(f"    # {title}")
        lines += [f'    "{name}.py",' for name in group]
    return RUNNER.replace("@ENTRIES@", "\n".join(lines))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build() -> dict[str, str]:
    scripts = [loop_single(kind) for kind in LOOP_KINDS] + [loop_xconn()]
    scripts += [gpo(out, kind) for out in ("PAB_OFF", "PAB_ON", "ENS") for kind in GPO_KINDS]
    scripts += [ecall(kind) for kind in GPO_KINDS]
    scripts += [dcs_like_single("Fault_List_DCS_Fault_S2B", "belt", "S2B"),
                dcs_like_xconn("Fault_List_DCS_Fault_CrossConnect", "belt")]
    scripts += [dcs_status(variant) for variant in ("buckled", "unbuckled", "s2b", "xconn")]
    scripts += [dcs_like_single("Fault_List_ODS_Fault_S2B", "ods", "S2B"),
                dcs_like_xconn("Fault_List_ODS_Fault_CrossConnect", "ods")]
    scripts += [dcs_like_single(f"Fault_List_STPS_Fault_{kind}", "stps", kind) for kind in ("Open", "S2B", "S2G")]
    scripts += [dcs_like_xconn("Fault_List_STPS_Fault_CrossConnect", "stps")]
    scripts += [rsu(kind) for kind in RSU_KINDS] + [rsu_internal()]
    scripts += [eol(kind) for kind in ("Loop", "RSU", "GPO")] + [eol_switch()]
    scripts += [can(kind) for kind in CAN_KINDS]
    files = {f"{script.name}.py": render(script) for script in scripts}
    assert len(files) == len(scripts) == 45, len(files)
    files["run_fault_list_suite.py"] = render_runner({script.name for script in scripts})
    return files


def validate():
    """Generation-time checks of the configuration names the scripts rely on."""
    for feature, channel in EOL_SEAT_CHANNEL.items():
        assert feature in eol_config.EOL_SWITCH_DCS_FEATURES, feature
        assert channel in dcs_config.DCSName or channel in ods_config.ODSChannelName, channel
    for name in ("ENS", "PAB_ON", "PAB_OFF", "ECALL"):
        assert name in fault_list_config.GPO_FAULT_BY_OUTPUT, name
    absent_nodes = [canc_config.CAN_TX_MESSAGE_CONFIG[frame].get("key_node") for frame, _, _ in can_targets("node_absent")]
    assert len(absent_nodes) == len(set(absent_nodes)), f"more than one node-absent frame for a node: {absent_nodes}"
    for kind in CAN_KINDS:
        assert all(dtc for _, _, dtc in can_targets(kind)), kind
    for module, names in CONFIG_IMPORTS.items():
        mod = __import__(f"{CONFIG_PACKAGE}.{module}", fromlist=["x"])
        absent = [name for name in names if not hasattr(mod, name)]
        assert not absent, f"{module}: {absent}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the M310_M314_M110 Fault_List test scripts.")
    parser.add_argument("--check", action="store_true", help="compare with the files on disk only")
    args = parser.parse_args()
    validate()
    files = build()
    changed = []
    for name, text in files.items():
        path = OUT_DIR / name
        old = path.read_text(encoding="utf-8") if path.is_file() else None
        if old != text:
            changed.append(name)
            if not args.check:
                path.write_text(text, encoding="utf-8", newline="\n")
    print(f"{len(files)} files, {len(changed)} {'differ' if args.check else 'written'}")
    for name in changed:
        print("  " + name)
    return 1 if (args.check and changed) else 0


if __name__ == "__main__":
    sys.exit(main())
