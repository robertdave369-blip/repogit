"""Write the EV IMU recording specification: yaw rate, lateral and longitudinal acceleration.

On M314 these three EDR elements (series 20, 21 and 22 of the common ICE/EV numbering) are
not CAN inputs. Their only M314 CAN route is SRS1_FD_10, a frame the SRS transmits itself
from its on-board IMU, so the restbus cannot drive them and no CAN fault can be injected
on them. They are therefore not in the EV EDR CAN-C specification, and not in its
not-configured check either - they are recorded, from the ECU's own sensor. This workbook
covers that recording instead (user direction 2026-10-07), keeping the same series numbers
so it can be read against the ICE and EV CAN-C specifications.

What each case expects is derived from the M314 record layout (edr_config, built from the
EV diagnostic specification sheet EDR_0455_045B): interval, sample spacing, signed 16-bit
raw, resolution and physical range. Where no source states the expected record content -
an internal IMU fault - the case is written ON HOLD with the open question, rather than
with an expectation nobody has specified.

Offline only: reads configuration and writes one workbook. Nothing here drives a bench.

Usage:
    py -3.14 tools/build_ev_imu_recording_spec.py [--output PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import edr_canc_review_model as model  # noqa: E402
import build_edr_canc_ice_ev_spec as spec  # noqa: E402

OUTPUT = spec.DEFAULT_DIRECTORY / "V1.8_DES_SW_EDR_SwQTS_EV_IMU.xlsx"
CRLF = "\r\n"
RECORDS = ("EDR1 (0x0455)", "EDR2 (0x045B)")

# The IMU channel behind each element. The quantity is the record's; the channel is how
# the bench stimulates the on-board IMU.
CHANNELS = {
    "YAW_RATE": "yaw rate (gyroscope, z axis)",
    "LATERAL_ACCEL": "lateral acceleration (accelerometer, y axis)",
    "LONG_ACCEL": "longitudinal acceleration (accelerometer, x axis)",
}


def _times(plan: model.ParameterPlan) -> list[float]:
    sample_range = plan.sample_range or {"start": 0.0, "step": 1.0}
    return [round(float(sample_range["start"]) + float(sample_range["step"]) * index, 4)
            for index in range(plan.samples)]


def _time_text(value: float) -> str:
    return f"{value:+.2f}" if value else "0.00"


def _plain(value: float) -> str:
    return f"{value:.6f}".rstrip("0").rstrip(".") or "0"


def _raw(physical: float, record: dict[str, Any]) -> int:
    return int(round((physical - float(record.get("offset") or 0))
                     / float(record.get("scaling_factor") or 1)))


def _hex(raw: int, bits: int) -> str:
    return f"0x{raw & ((1 << bits) - 1):0{(bits + 3) // 4}X}"


def _arrays(prefix: str, physical: list[float], record: dict[str, Any]) -> list[str]:
    bits = int(record.get("data_bit_length") or 16)
    unit = record.get("unit") or "value"
    raws = [_raw(value, record) for value in physical]
    return [
        f"{prefix} raw hex: [" + ", ".join(_hex(raw, bits) for raw in raws) + "]",
        f"{prefix} raw decimal: [" + ", ".join(str(raw) for raw in raws) + "]",
        f"{prefix} physical {unit}: [" + ", ".join(_plain(value) for value in physical) + "]",
    ]


def _steps(plan: model.ParameterPlan, wake: str | None) -> list[tuple[str, str]]:
    steps = [("Set bench to normal condition", "System is in normal state, no faults present.")]
    if wake == "wakeup":
        steps.append(("Switch hardware ignition OFF and wake the ECU over CAN as listed in "
                      "step 3 of Pre-Action",
                      "ECU is awake with hardware ignition OFF and no faults present."))
    if wake == "can_nm":
        steps.append(("Switch hardware ignition OFF and wake the ECU with the CAN NM message "
                      "as listed in step 3 of Pre-Action",
                      "ECU is awake and kept awake by the NM network request with hardware "
                      "ignition OFF; it transmits its NM message and no faults are present."))
    steps.append(("Stimulate the on-board IMU as specified in step 2 of Pre-Action",
                  "The IMU channel follows the profile listed in step 2 of Pre-Action."))
    steps.append(("Simulate Front Crash and Read DTC", spec.CRASH_DTC_TEXT))
    crash_step = len(steps)
    steps += [
        (f"Read EDR and observe bytes for {plan.parameter} EDR Parameter",
         f"EDR records the values for {plan.parameter} exactly as listed in the Post-Action "
         f"of this test case."),
        (f"Repeat steps 2 till test step {crash_step} and read EDR2 and observe bytes for the "
         f"{plan.parameter} EDR Parameter.",
         f"EDR records the values for {plan.parameter} exactly as listed in the Post-Action "
         f"of this test case."),
        ("Clear NVM and Clear DTC",
         "All DTCs and NVM data are cleared; system returns to normal state, only where "
         "permitted by the approved project procedure."),
    ]
    return steps


def _case(plan: model.ParameterPlan, number: int, tag: str, description: str,
          pre: str, post: str, steps: list[tuple[str, str]], status: str = "IN REVIEW",
          technique: str = "Boundary Value Analysis") -> spec.SourceCase:
    header: dict[int, Any] = {
        spec.COL["Priority"]: "High",
        spec.COL["Name"]: f"EDR_Element_ID_{plan.parameter}_TestCase_{plan.signal}_{number}_{tag}",
        spec.COL["Description"]: description,
        spec.COL["Pre-Action"]: pre,
        spec.COL["Post-Action"]: post,
        spec.COL["Status"]: status,
        spec.COL["Type"]: "Functional",
        spec.COL["_Project"]: "Common EDR - EV variant",
        spec.COL["_LatestResult"]: "NOT YET TESTED",
        spec.COL["_TestType"]: "Manual",
        spec.COL["_VerificationMethod"]: "Requirements-based test",
        spec.COL["_TestTechnique"]: technique,
    }
    block = spec.SourceCase(header, [])
    spec._apply_steps(block, [{spec.COL["Test Steps.Action"]: action,
                               spec.COL["Test Steps.Expected result"]: expected,
                               spec.COL["Test Steps.Critical"]: "false",
                               spec.COL["Test Steps.Id"]: index + 1}
                              for index, (action, expected) in enumerate(steps)])
    return block


def cases_for(plan: model.ParameterPlan, record: dict[str, Any],
              canc: Any) -> list[spec.SourceCase]:
    times = _times(plan)
    count = len(times)
    unit = record.get("unit") or "value"
    low, high = float(record["minimum"]), float(record["maximum"])
    sweep = [low + (high - low) * index / (count - 1) for index in range(count)]
    channel = CHANNELS.get(plan.parameter, plan.parameter)
    step_ms = int(round((times[1] - times[0]) * 1000))
    intro = [
        "1. Verify the approved EDR feature configuration and confirm the selected variant "
        "is fault free.",
        "",
    ]
    source = (f"Source: SRS on-board IMU, {channel}. The ECU also transmits this quantity in "
              f"{plan.frame} / {plan.canc_signal}; it is an ECU output, so it is not driven "
              f"over CAN.")
    axis = (f"Recording time [s] ({count} values): ["
            + ", ".join(_time_text(value) for value in times) + "]")
    window = (f"Stimulus window: each value is held for the {step_ms} ms ending at its sample "
              f"time; the crash is triggered at T0.")
    record_line = (f"Recorded as signed {record.get('data_bit_length')}-bit raw, "
                   f"{_plain(float(record['scaling_factor']))} {unit} per count, "
                   f"{_plain(low)} to {_plain(high)} {unit}.")
    both = (f"The same profile is applied for the crash recorded in {RECORDS[0]} and again "
            f"for the crash recorded in {RECORDS[1]}.")

    def stimulated(label: str, extra: list[str] | None = None) -> str:
        return CRLF.join(intro + [
            f"2. Stimulate the {plan.parameter} IMU channel with {label} for EV (M314):",
            source, axis, window, record_line, *(extra or []), both,
            *_arrays("IMU stimulus", sweep, record)])

    expected = CRLF.join([
        f"Expected EDR recording for {plan.parameter} in DID 0x0455 (EDR1) and DID 0x045B "
        f"(EDR2):", axis, *_arrays("Expected recorded", sweep, record), "",
        "Every sample records the IMU value at its sample time, converted at the record's "
        "resolution."])
    wake_target = (f"3. CAN wakeup check:{CRLF}Hardware ignition OFF, restbus stopped until "
                   f"bus sleep, then restarted. The ECU reports the wakeup in "
                   f"{canc.CAN_WAKEUP_STATUS_FRAME} / {canc.CAN_WAKEUP_STATUS_SIGNAL} = "
                   f"{canc.CAN_WAKEUP_STATUS_VALUE} (IGN ON due to CAN wakeup).")
    nm_target = (f"3. CAN NM wakeup check:{CRLF}Hardware ignition OFF, restbus stopped until "
                 f"bus sleep, then restarted with {canc.CAN_NM_WAKEUP_FRAME} / "
                 f"{canc.CAN_NM_WAKEUP_SIGNAL} = {canc.CAN_NM_WAKEUP_VALUE} (Active). The ECU "
                 f"answers with {canc.CAN_NM_SRS_FRAME} and reports "
                 f"{canc.CAN_WAKEUP_STATUS_FRAME} / {canc.CAN_WAKEUP_STATUS_SIGNAL} = "
                 f"{canc.CAN_WAKEUP_STATUS_VALUE}.")

    limits = [low, high]
    limit_pre = CRLF.join(intro + [
        f"2. Stimulate the {plan.parameter} IMU channel at the record's range limits for EV "
        f"(M314):", source, axis, window, record_line,
        f"Iterate the case 2 time(s), one crash per iteration: iteration 1 holds the IMU at "
        f"{_plain(low)} {unit} across the whole interval and is recorded in {RECORDS[0]}; "
        f"iteration 2 holds it at {_plain(high)} {unit} and is recorded in {RECORDS[1]}.",
        *_arrays("IMU stimulus (one per iteration)", limits, record)])
    bits = int(record.get("data_bit_length") or 16)
    limit_post = CRLF.join([
        f"Expected EDR recording for {plan.parameter} in DID 0x0455 (EDR1) and DID 0x045B "
        f"(EDR2):", axis,
        *[f"Iteration {k}: {RECORDS[k - 1]} records raw {_hex(_raw(v, record), bits)} "
          f"({_raw(v, record)} decimal, {_plain(v)} {unit}) at every sample."
          for k, v in ((1, low), (2, high))],
        *_arrays("Expected recorded (one per iteration)", limits, record), "",
        "The record holds the full-scale value at every sample: the range limit is "
        "representable in the recording field without saturation."])

    fault_pre = CRLF.join(intro + [
        f"2. Stimulate the {plan.parameter} IMU channel with the nominal profile and create "
        f"an on-board IMU fault across the complete recording interval for EV (M314):",
        source, axis, window, record_line, both, *_arrays("IMU stimulus", sweep, record), "",
        "3. Fault injection target for IMU fault:",
        "On-board IMU fault (sensor error reported to the ECU through the bench's sensor "
        "simulation)."])
    fault_post = CRLF.join([
        f"Expected EDR recording for {plan.parameter} in DID 0x0455 (EDR1) and DID 0x045B "
        f"(EDR2):", axis, "",
        "ON HOLD - requirement to be confirmed. Neither the EV diagnostic specification "
        "(EDR_0455_045B) nor the on-fail matrix states what the record holds while the "
        "on-board IMU is faulted: the last valid value, the CAN signal's invalid code "
        f"({plan.frame} / {plan.canc_signal} names 0xFFFF Signal Invalid), or the faulted "
        "sensor output. Release this case once the reaction and the IMU fault DTC are "
        "stated."])
    fault_steps = _steps(plan, None)
    fault_steps.insert(1, ("Create the on-board IMU fault as listed in step 3 of Pre-Action",
                           "IMU fault is active across the complete recording interval."))

    return [
        _case(plan, 1, "Nominal",
              f"Verify {plan.parameter} recording from the on-board IMU across the recording "
              f"interval in both EDR records for EV.",
              stimulated("a full-range sweep"), expected, _steps(plan, None)),
        _case(plan, 2, "Range_Limits",
              f"Verify {plan.parameter} recording at the minimum and maximum of the record's "
              f"range for EV.", limit_pre, limit_post, _steps(plan, None)),
        _case(plan, 3, "CAN_Wakeup",
              f"Verify {plan.parameter} IMU recording during a crash when the ECU is woken by "
              f"CAN with hardware ignition OFF, for EV.",
              stimulated("a full-range sweep, ECU woken over CAN") + CRLF + CRLF + wake_target,
              expected, _steps(plan, "wakeup")),
        _case(plan, 4, "CAN_NM",
              f"Verify {plan.parameter} IMU recording during a crash when the ECU is woken and "
              f"kept awake by the CAN NM message with hardware ignition OFF, for EV.",
              stimulated("a full-range sweep, ECU woken by CAN NM") + CRLF + CRLF + nm_target,
              expected, _steps(plan, "can_nm")),
        _case(plan, 5, "IMU_Fault_Full",
              f"Verify {plan.parameter} recording while the on-board IMU is faulted across the "
              f"complete recording interval, for EV.", fault_pre, fault_post, fault_steps,
              status="ON HOLD", technique="Fault Injection"),
    ]


def build(output: Path) -> dict[str, Any]:
    import openpyxl
    from openpyxl.styles import Alignment, Font

    configs = model.load_configs()
    internal = model.build_all()["ev_internal"]
    records = configs["m314_records"]
    canc = configs["m314_canc"]

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Export"
    for column, name in enumerate(spec.COLUMNS, start=1):
        sheet.cell(1, column, name).font = Font(bold=True)
    row = 2

    def write(values: dict[int, Any]) -> None:
        nonlocal row
        for column, value in values.items():
            if value is not None:
                sheet.cell(row, column, value)
        row += 1

    write({spec.COL["Priority"]: "Highest", spec.COL["Name"]: "EDR_IMU_RECORDING",
           spec.COL["Status"]: "n/a", spec.COL["Type"]: "Folder"})
    count = 0
    for number in sorted(internal):
        plan = internal[number]
        record = records.get(plan.edr_parameter or "")
        if not record:
            raise SystemExit(f"{plan.parameter}: no M314 record element {plan.edr_parameter!r}")
        for block in cases_for(plan, record, canc):
            count += 1
            write(block.header)
            for step in block.steps:
                write({spec.COL[name]: step.get(spec.COL[name])
                       for name in ("Test Steps.Action", "Test Steps.Expected result",
                                    "Test Steps.Critical", "Test Steps.Id")})

    widths = {"Name": 60, "Description": 70, "Pre-Action": 90, "Post-Action": 90,
              "Test Steps.Action": 60, "Test Steps.Expected result": 70}
    for name, width in widths.items():
        sheet.column_dimensions[openpyxl.utils.get_column_letter(spec.COL[name])].width = width
    for line in sheet.iter_rows(min_row=2, max_row=sheet.max_row):
        for cell in line:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    choices = workbook.create_sheet("ChoiceValues")
    for index, value in enumerate(spec.read_v4(model.V4_WORKBOOK)["choices"], start=1):
        if value is not None:
            choices.cell(index, 1, value)
    output.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output)
    return {"series": sorted(internal), "cases": count, "rows": row - 1}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    arguments = parser.parse_args()
    report = build(arguments.output)
    print(f"{arguments.output.name}: series {report['series']}, {report['cases']} case(s), "
          f"{report['rows']} row(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
