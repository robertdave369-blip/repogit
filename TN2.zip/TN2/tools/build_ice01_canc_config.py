"""Build the ICE_01 common CAN-C configuration.

Emits `projects/ICE_01/config/canc_config.py` in the same shape as
`projects/M310_M314_M110/config/canc_config.py`, with the frame and signal names of the
common ICE bus.

Sources
-------
Signal encoding : the ICE CAN database (U171 SRS DBC).
Fault DTC codes : the ICE reference DTC maps, cross-checked against the DTC List sheet
                  of the common diagnostic specification.
Test arrays     : the common EDR CAN-C specification, so the values a script drives are
                  the values the specification asks for.

Node key frame = the lowest CAN ID a node transmits, because that frame wins arbitration
and is the one node-absent detection monitors.

Offline only: reads a DBC and the generated specification; writes one config file.

Usage:
    py -3.14 tools/build_ice01_canc_config.py
"""

from __future__ import annotations

import argparse
import importlib.util
import pprint
import re
import sys
from pathlib import Path
from typing import Any

import cantools

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "tests"))
sys.path.insert(0, str(REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "scripts"))

VARIANTS = {
    "ICE_01": {
        "vehicle_class": "ICE",
        "spec_variant": "U171",
        "reference_project": "U171",
        "node_prefixes": (
            ("EPS_SAS", "EPS"), ("HPCAd", "HPCAD"), ("MBFM", "MBFM"), ("FRM", "FRM"),
            ("EMS", "EMS"), ("ESC", "ESC"), ("TCU", "TCU"), ("IS", "IS"), ("IC", "IC"),
        ),
    },
    "EV_01": {
        "vehicle_class": "EV",
        "spec_variant": "M314",
        "reference_project": "M310_M314_M110",
        "node_prefixes": (
            ("IEB", "IEB"), ("EPS", "EPS"), ("VCU", "VCU"), ("HPCC", "HPCC"),
            ("HPCAd", "HPCAD"), ("FR_ZONE", "FR_ZONE"), ("OCS", "OCS"),
            ("E_CALL", "E_CALL"), ("MBFM", "MBFM"), ("IC", "IC"), ("IS", "IS"),
        ),
    },
}

NODE_PREFIXES = ()
DIAG_FRAMES = re.compile(r"DIAG|TESTER|GLOBAL|^SRS", re.IGNORECASE)

HELPERS = '''

def is_key_message(frame_name: str) -> bool:
    """True when stopping this frame raises Node Absent rather than Message Timeout."""
    return bool(KEY_TX_FRAMES.get(frame_name))


def get_message_timeout_dtc(frame_name: str) -> str | None:
    return CAN_TX_MESSAGE_CONFIG.get(frame_name, {}).get("message_timeout_dtc")


def get_node_absent_dtc(frame_name: str) -> str | None:
    return CAN_TX_MESSAGE_CONFIG.get(frame_name, {}).get("node_absent_dtc")


def get_signal_content_failure_dtc(signal_name: str) -> str | None:
    return CAN_SIGNAL_CONTENT_FAILURE_DTC.get(signal_name)


def get_message_content_failure_dtcs(frame_name: str) -> dict:
    return CAN_TX_MESSAGE_CONFIG.get(frame_name, {}).get("message_content_failure_dtcs", {})


def get_message_content_failure_signals(frame_name: str) -> list:
    return list(get_message_content_failure_dtcs(frame_name))


def choose_message_content_failure_signal(frame_name: str) -> str | None:
    """Pick the CRC signal where the frame has one, otherwise the alive counter."""
    signals = get_message_content_failure_signals(frame_name)
    if not signals:
        return None
    for name in signals:
        if "CRC" in name.upper():
            return name
    return signals[0]


def get_frame_message_content_failure_dtc(frame_name: str) -> tuple[str | None, str | None]:
    signal = choose_message_content_failure_signal(frame_name)
    if signal is None:
        return None, None
    return signal, get_message_content_failure_dtcs(frame_name).get(signal)


def timeout_frame_for(signal_name: str) -> str | None:
    """Frame to stop for a message-timeout test, or None when no such case exists.

    Message timeout is injected on the frame carrying the signal. If that frame is the
    node key frame, stopping it raises Node Absent instead, so this signal has no
    distinct timeout case.
    """
    definition = MAH_CAN_SIGNAL_DEFS.get(signal_name)
    if definition is None:
        return None
    return definition["fault_logic"].get("non_key_timeout_frame")


def key_frame_for(signal_name: str) -> str | None:
    """Frame to stop for a node-absent test."""
    definition = MAH_CAN_SIGNAL_DEFS.get(signal_name)
    return None if definition is None else definition["fault_logic"].get("key_message")


def resolve_dtc_for_event(event_type: str, frame_name: str | None, signal_name: str | None = None):
    """Resolve the DTC mapped to the requested CANC fault event."""
    if event_type == "message_timeout":
        return get_message_timeout_dtc(frame_name) if frame_name else None
    if event_type == "node_absent":
        return get_node_absent_dtc(frame_name) if frame_name else None
    if event_type == "frame_disabled":
        if not frame_name:
            return None
        return get_node_absent_dtc(frame_name) if is_key_message(frame_name) else get_message_timeout_dtc(frame_name)
    if event_type == "signal_invalid" and signal_name:
        return get_signal_content_failure_dtc(signal_name)
    if event_type == "message_content_failure":
        return get_message_content_failure_dtcs(frame_name) if frame_name else None
    return None
'''

DOCSTRING = '''"""
Module Configuration: CANC
Project: {project} (common {vehicle_class} baseline)
============================================================

Location: projects/{project}/config/canc_config.py

GENERATED FILE - do not edit by hand.
Rebuild with: py -3.14 tools/build_ice01_canc_config.py --project {project}

Same structure as the M310_M314_M110 CANC config, carrying the frame and signal names
of the common {vehicle_class} bus.

Key frames
----------
A node's key frame is the lowest CAN ID it transmits, because that frame wins CAN
arbitration and is the one node-absent detection monitors. Node absent is created by
stopping the key frame. Message timeout is created by stopping the frame carrying the
signal under test; where that frame IS the key frame, `non_key_timeout_frame` is None,
because stopping it raises Node Absent instead and no separate timeout case exists.

Test arrays
-----------
`TestCase_<n>_values` is the input array the specification drives for element group
<n>. `_Invalid_Values` and `_OutofRange_Values` carry the DBC exception codes.
Qualification timing lives in cannm_config; it is a count of message periods, not a
fixed millisecond value.
"""

PROJECT_NAME = "{project}"
MODULE_NAME = "CANC"
VEHICLE_CLASS = "{vehicle_class}"

"""CAN Library - CAN bus communication utilities."""

'''


def node_of(frame: str, prefixes: tuple) -> str | None:
    for prefix, node in prefixes:
        if frame.startswith(prefix):
            return node
    return None


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def symbol_name(signal: str) -> str:
    return "CAN_" + re.sub(r"[^A-Z0-9]+", "_", signal.upper()).strip("_")


def build_test_arrays(spec: Any, matrix: list[dict[str, Any]], spec_variant: str) -> dict[str, dict[str, list]]:
    """Input arrays per signal, keyed by the element group number in the specification."""
    arrays: dict[str, dict[str, list]] = {}
    for plan in spec.build_case_plans(matrix):
        route = plan.route_by_variant.get(spec_variant)
        if route is None or route.get("dbc") is None:
            continue
        signal = route["dbc"]["signal"]
        group = plan.name.rsplit("_TestCase_", 1)[-1].split("_")[0]
        bucket = arrays.setdefault(signal, {})
        if plan.exception_category is not None:
            # DBC exception codes come from the signal's own invalid / reserved /
            # encodable-out-of-range set, not from the nominal sweep.
            vectors = [
                vector for vector in spec.dbc_exception_vectors(route["dbc"])
                if vector["scenario"] == plan.exception_category
            ]
            raw = [int(vector["raw_integer"]) for vector in vectors]
            if not raw:
                continue
            key = "Invalid" if plan.exception_category == "invalid" else "OutofRange"
            bucket.setdefault(f"TestCase_{group}_{key}_Values", raw)
            continue

        decision = None if plan.fault_mode is None else spec.onfail_decision(route, plan.fault_mode)
        points = spec._authoring_vector_points(
            plan.element, route, plan.timing_scope,
            fault_mode=plan.fault_mode, fault_decision=decision,
        )
        raw = [p["input_raw_integer"] for p in points if isinstance(p["input_raw_integer"], int)]
        if raw and plan.fault_mode is None:
            bucket.setdefault(f"TestCase_{group}_values", raw)
    return arrays


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", default="ICE_01", choices=sorted(VARIANTS))
    arguments = parser.parse_args()

    import test_common_edr_canc_specification as spec

    settings = VARIANTS[arguments.project]
    spec_variant = settings["spec_variant"]
    prefixes = settings["node_prefixes"]
    output = REPOSITORY_ROOT / "projects" / arguments.project / "config" / "canc_config.py"
    reference_path = REPOSITORY_ROOT / "projects" / settings["reference_project"] / "config" / "canc_config.py"
    reference = load_module(reference_path, f"{arguments.project}_reference_canc")

    contexts = {name: spec.load_variant_context(name) for name in ("U171", "M314")}
    matrix = spec.build_route_matrix(spec.load_drbfm_analysis(), contexts)
    arrays = build_test_arrays(spec, matrix, spec_variant)

    # The variant's own CAN databases supply the signal encoding.
    databases = [
        cantools.database.load_file(entry["path"])
        for entry in contexts[spec_variant]["dbc_manifest"]
    ]

    edr_by_signal: dict[str, str] = {}
    for row in matrix:
        route = row["routes"][spec_variant]
        if route.get("dbc"):
            edr_by_signal.setdefault(route["dbc"]["signal"], row["parameter_name"])

    frames_by_node: dict[str, list[str]] = {}
    can_id: dict[str, int] = {}
    all_messages = [message for database in databases for message in database.messages]
    for message in all_messages:
        if DIAG_FRAMES.search(message.name):
            continue
        node = node_of(message.name, prefixes)
        if node is None:
            continue
        can_id[message.name] = int(message.frame_id)
        frames_by_node.setdefault(node, []).append(message.name)
    for node in frames_by_node:
        frames_by_node[node].sort(key=lambda frame: can_id[frame])
    node_key_frame = {node: frames[0] for node, frames in frames_by_node.items()}
    frame_to_node = {frame: node for node, frames in frames_by_node.items() for frame in frames}

    node_absent = dict(reference.CAN_NODE_ABSENT_DTC)
    message_timeout = dict(reference.CAN_MESSAGE_TIMEOUT_DTC)
    message_content = dict(reference.CAN_MESSAGE_CONTENT_FAILURE_DTC)
    signal_content = dict(reference.CAN_SIGNAL_CONTENT_FAILURE_DTC)

    signal_blocks: list[tuple[str, str, dict[str, Any]]] = []
    rx_map: dict[str, tuple[str, str]] = {}
    tx_config: dict[str, dict[str, Any]] = {}
    seen_symbols: set[str] = set()

    for message in all_messages:
        if message.name not in frame_to_node:
            continue
        node = frame_to_node[message.name]
        integrity = {
            signal.name: message_content[signal.name]
            for signal in message.signals
            if signal.name in message_content
        }
        tx_config[message.name] = {
            "signals": [signal.name for signal in message.signals],
            "key_node": node,
            "is_key_frame": message.name == node_key_frame[node],
            "node_absent_dtc": node_absent.get(node),
            "message_timeout_dtc": message_timeout.get(node),
            "signal_content_failure_dtcs": {
                signal.name: signal_content[signal.name]
                for signal in message.signals
                if signal.name in signal_content
            },
            "message_content_failure_dtcs": integrity,
        }

        for signal in message.signals:
            # Receiver is SRS on the ICE bus and SRS_FD / SRS_HSCAN on the EV buses.
            receivers = {str(name).upper() for name in (signal.receivers or ())}
            if not any(name.startswith("SRS") for name in receivers):
                continue
            symbol = symbol_name(signal.name)
            if symbol in seen_symbols:
                symbol = f"{symbol}_{message.name}"
            seen_symbols.add(symbol)
            rx_map[signal.name] = (message.name, signal.name)

            choices = {str(label): int(raw) for raw, label in (signal.choices or {}).items()}
            block: dict[str, Any] = {
                "frame": message.name,
                "signal": signal.name,
                "frame_ID": int(message.frame_id),
                "ch": 2,
                "periodicity": int(message.cycle_time or 0),
                "Factor": signal.scale,
                "Offset": signal.offset,
                "UNIT": signal.unit,
                "MIN": signal.minimum,
                "MID": None,
                "MAX": signal.maximum,
                "Default_Value": next(
                    (raw for label, raw in choices.items() if "DEFAULT" in label.upper()), 0x0
                ),
                "State_Values": choices,
            }
            block.update(arrays.get(signal.name, {}))
            block["EDR_Parameter"] = edr_by_signal.get(signal.name)
            timeout_frame = None if message.name == node_key_frame[node] else message.name
            block["fault_logic"] = {
                "key_message": node_key_frame[node],
                "non_key_timeout_frame": timeout_frame,
                "fault_type": "message_timeout" if timeout_frame else "node_absent",
                "node_absent_dtc": node_absent.get(node),
                "message_timeout_dtc": message_timeout.get(node) if timeout_frame else None,
                "signal_content_failure_dtc": signal_content.get(signal.name),
                "message_content_failure_dtcs": integrity,
            }
            signal_blocks.append((symbol, signal.name, block))

    key_tx_frames = {frame: (frame == node_key_frame[node]) for frame, node in frame_to_node.items()}

    exported = (
        [
            "CAN_SIGNAL_Rx_MAP", "CAN_NODE_ABSENT_DTC", "CAN_MESSAGE_TIMEOUT_DTC",
            "CAN_MESSAGE_CONTENT_FAILURE_DTC", "CAN_SIGNAL_CONTENT_FAILURE_DTC",
            "CAN_TX_MESSAGE_CONFIG", "FRAMES_BY_NODE", "NODE_KEY_FRAMES",
        ]
        + [symbol for symbol, _, _ in signal_blocks]
        + [
            "KEY_TX_FRAMES", "MAH_CAN_SIGNAL_DEFS",
            "is_key_message", "get_message_timeout_dtc", "get_node_absent_dtc",
            "get_signal_content_failure_dtc", "get_message_content_failure_dtcs",
            "get_message_content_failure_signals", "choose_message_content_failure_signal",
            "get_frame_message_content_failure_dtc", "resolve_dtc_for_event",
            "timeout_frame_for", "key_frame_for",
        ]
    )

    out: list[str] = [DOCSTRING.format(project=arguments.project, vehicle_class=settings["vehicle_class"])]
    out.append("__all__ = " + pprint.pformat(exported, width=100) + "\n\n")

    def block_out(name: str, comment: str, value: Any) -> None:
        out.append(f"# {comment}\n{name} = {pprint.pformat(value, width=110, sort_dicts=False)}\n\n")

    block_out("FRAMES_BY_NODE", "Frames each node transmits, lowest CAN ID first.", frames_by_node)
    block_out("NODE_KEY_FRAMES", "Key frame per node: the lowest CAN ID it transmits.", node_key_frame)
    block_out("CAN_SIGNAL_Rx_MAP", "Signal name -> (frame, signal) for every signal the SRS receives.", rx_map)
    block_out("CAN_NODE_ABSENT_DTC", "Node absent DTC per node.", node_absent)
    block_out("CAN_MESSAGE_TIMEOUT_DTC", "Message timeout DTC per node.", message_timeout)
    block_out("CAN_MESSAGE_CONTENT_FAILURE_DTC", "Message content failure DTC per CRC / alive counter signal.", message_content)
    block_out("CAN_SIGNAL_CONTENT_FAILURE_DTC", "Signal content failure DTC per signal.", signal_content)
    block_out("CAN_TX_MESSAGE_CONFIG", "Per-frame node, key-frame flag and fault DTCs.", tx_config)

    out.append("# " + "─" * 30 + " Signal definitions " + "─" * 30 + "\n\n")
    for symbol, _, value in signal_blocks:
        out.append(f"{symbol} = {pprint.pformat(value, width=110, sort_dicts=False)}\n\n")

    out.append("# Signal name -> its definition dict.\nMAH_CAN_SIGNAL_DEFS = {\n")
    for symbol, signal, _ in signal_blocks:
        out.append(f'    "{signal}": {symbol},\n')
    out.append("}\n\n")

    block_out(
        "KEY_TX_FRAMES",
        "True where stopping the frame raises Node Absent rather than Message Timeout.",
        key_tx_frames,
    )
    out.append(HELPERS)

    output.write_text("".join(out), encoding="utf-8")
    print(f"Wrote {output}")
    print(f"  nodes            : {len(frames_by_node)}")
    print(f"  frames           : {len(tx_config)}")
    print(f"  signal blocks    : {len(signal_blocks)}")
    print(f"  with test arrays : {sum(1 for _, signal, _ in signal_blocks if signal in arrays)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
