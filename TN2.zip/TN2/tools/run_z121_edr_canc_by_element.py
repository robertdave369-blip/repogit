"""Run Z121 EDR CAN-C cases and segregate outputs by EDR element.

This wrapper reuses the existing Z121 runner selection and executes one case at a
time. After each case exits, its HTML report and CAN log are moved immediately to:

    test_results/Z121/<element-slug>/
    test_logs/Z121/<element-slug>/

Use ``--list`` for an offline selection check. Running without ``--list`` launches the
bench-facing case scripts from the existing runner.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from types import ModuleType


FRAMEWORK_ROOT = Path(__file__).resolve().parents[1]
SOURCE_RUNNER = (
    FRAMEWORK_ROOT
    / "projects"
    / "Z121"
    / "modules"
    / "EDR"
    / "scripts"
    / "run_all_z121_edr_canc_scripts.py"
)
RUNNER_DIR = SOURCE_RUNNER.parent
RESULTS_FILE = RUNNER_DIR / "Z121_edr_canc_by_element_results.json"
REPORTS_ROOT = FRAMEWORK_ROOT / "test_results" / "Z121"
LOGS_ROOT = FRAMEWORK_ROOT / "test_logs" / "Z121"
REPORT_LOG_PATTERN = re.compile(
    r"report=(?P<report>[^,\r\n]+\.html),\s*"
    r"log=(?P<log>[^,\r\n]+\.txt)"
)
ELEMENT_PATTERN = re.compile(r"^EDR_Element_ID_(?P<element>.+?)_TestCase_")


def _load_source_runner() -> ModuleType:
    spec = importlib.util.spec_from_file_location("z121_edr_source_runner", SOURCE_RUNNER)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load source runner: {SOURCE_RUNNER}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _element_slug(script_name: str) -> str:
    match = ELEMENT_PATTERN.match(Path(script_name).stem)
    if match is None:
        return "other"
    slug = re.sub(r"[^a-z0-9]+", "", match.group("element").lower())
    return slug or "other"


def _snapshot(root: Path, suffix: str) -> set[Path]:
    if not root.exists():
        return set()
    return {path.resolve() for path in root.rglob(f"*{suffix}") if path.is_file()}


def _resolve_path(value: str) -> Path:
    path = Path(value.strip().strip('"')).expanduser()
    return path.resolve() if path.is_absolute() else (FRAMEWORK_ROOT / path).resolve()


def _report_log_paths(output: str) -> set[Path]:
    paths: set[Path] = set()
    for match in REPORT_LOG_PATTERN.finditer(output):
        paths.add(_resolve_path(match.group("report")))
        paths.add(_resolve_path(match.group("log")))
    return paths


def _unique_destination(directory: Path, filename: str) -> Path:
    destination = directory / filename
    if not destination.exists():
        return destination
    stem = Path(filename).stem
    suffix = Path(filename).suffix
    index = 2
    while True:
        candidate = directory / f"{stem}_{index}{suffix}"
        if not candidate.exists():
            return candidate
        index += 1


def _move_outputs(paths: set[Path], element: str) -> list[str]:
    moved: list[str] = []
    for source in sorted(paths):
        if not source.is_file():
            continue
        if source.suffix.lower() == ".html":
            target_dir = REPORTS_ROOT / element
        elif source.suffix.lower() == ".txt":
            target_dir = LOGS_ROOT / element
        else:
            continue
        target_dir.mkdir(parents=True, exist_ok=True)
        target = _unique_destination(target_dir, source.name)
        shutil.move(str(source), str(target))
        moved.append(str(target))
    return moved


def _run_script(path: Path, environment: dict[str, str]) -> tuple[int, list[str]]:
    print("=" * 100)
    print(f"Running: {path.name}")
    print("=" * 100)
    before_reports = _snapshot(REPORTS_ROOT, ".html")
    before_logs = _snapshot(LOGS_ROOT, ".txt")
    completed = subprocess.run(
        [sys.executable, str(path)],
        cwd=str(RUNNER_DIR),
        env=environment,
        capture_output=True,
        text=True,
    )
    if completed.stdout:
        print(completed.stdout, end="")
    if completed.stderr:
        print(completed.stderr, end="", file=sys.stderr)

    after_reports = _snapshot(REPORTS_ROOT, ".html")
    after_logs = _snapshot(LOGS_ROOT, ".txt")
    output_paths = _report_log_paths(completed.stdout + completed.stderr)
    output_paths.update(after_reports - before_reports)
    output_paths.update(after_logs - before_logs)
    moved = _move_outputs(output_paths, _element_slug(path.name))
    for output_path in moved:
        print(f"Moved output: {output_path}")

    status = "PASSED" if completed.returncode == 0 else "FAILED"
    print(f"{status}: {path.name} (exit code {completed.returncode})")
    return completed.returncode, moved


def main() -> int:
    source_runner = _load_source_runner()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="run scripts whose name contains this text")
    parser.add_argument("--fault", help="run one fault family, for example node_absent")
    parser.add_argument("--nominal", action="store_true", help="run nominal cases only")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()

    scripts = source_runner.select_scripts(arguments)
    if arguments.list:
        for path in scripts:
            print(path.name + "  [" + str(source_runner.SCRIPT_FAULTS.get(path.name) or "nominal") + "]")
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    environment = source_runner.build_environment()
    results: dict[str, dict[str, object]] = {}
    for path in scripts:
        return_code, moved = _run_script(path, environment)
        results[path.name] = {
            "returncode": return_code,
            "element": _element_slug(path.name),
            "outputs": moved,
        }
        RESULTS_FILE.write_text(json.dumps(results, indent=2), encoding="utf-8")

    failed = [name for name, result in results.items() if result["returncode"] != 0]
    print("=" * 100)
    print(
        f"Ran {len(results)} script(s): "
        f"{len(results) - len(failed)} passed, {len(failed)} failed"
    )
    for name in failed:
        print(f"  FAILED: {name}")
    print(f"Results written to {RESULTS_FILE}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
