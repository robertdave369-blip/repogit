"""Build the fault_list_config.py of the EV projects (M310_M314_M110, M210) from the project fault list.

The EV fault list is common to the EV projects (user 2026-10-22), so M210 gets the same faults; each
project's device names and lookups come from its own module configs.

Author: Kris

Source: project_reuirements/m310_m314_m110/DES_SW_Mahindra_FaultList.xlsx (Codebeamer export, sheet
Export). Every fault that is not obsolete becomes one entry with a short name; the faults the customer
struck out are kept in their own section. The device names come from the project's module configs
(squibs_config, dcs_config, ods_config, gpo_config, rsu_config), so a fault list entry can be looked up
with the same names the bench uses.

    py -3.14 tools/build_m310_fault_list_config.py          # write the configs
    py -3.14 tools/build_m310_fault_list_config.py --check  # rebuild in memory and compare

The generated config is data only: no scripts read the workbook.
"""
from __future__ import annotations

import importlib
import os
import re
import sys
from collections import Counter, OrderedDict
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
WORKBOOK = ROOT / "project_reuirements" / "m310_m314_m110" / "DES_SW_Mahindra_FaultList.xlsx"
# The EV projects whose fault_list_config.py this writes (the EV fault list is common, user 2026-10-22).
EV_PROJECTS = ("M310_M314_M110", "M210")
OUTPUT = ROOT / "projects" / "M310_M314_M110" / "config" / "fault_list_config.py"
os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "M310_M314_M110")
sys.path.insert(0, str(ROOT.parent))
from Framework_IOEM_Py.projects.M310_M314_M110.config import gpo_config, rsu_config, squibs_config  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_common_dtc_dictionary import common_section  # noqa: E402  (tools/ is not a package)

# ---------------------------------------------------------------------------
# Names
# ---------------------------------------------------------------------------

# ECU loop line (LOOP_F_*_<line>) -> squib name. squibs_config names the squibs by their ARIA loop; the
# fault list numbers the ECU lines. They are matched on the squib function the two name (the comments of
# squibs_config, FLTMONR_LOP_E_<function> in the fault list) and checked on the DTC where squibs_config
# has one.
LOOP_LINE_SQUIB = {
    0: "RPT", 1: "LPT", 2: "RSA", 3: "LSA", 4: "RCA", 5: "LCA", 6: "DAB", 7: "PAB", 11: "DKA",
    12: "RLPT", 13: "LLPT", 16: "R2RPT", 17: "CAB", 18: "R2LPT", 19: "DBFL", 20: "PBFL",
    # struck out by the customer
    14: "DFV", 15: "PFV", 21: "HVBD", 22: "PPC", 23: "DPC",
}
LOOP_LINE_FUNCTION = {   # the FLTMONR_LOP_E_<function> text each line must carry
    0: "DRIVER_PRE_TENSIONER", 1: "PASSENGER_PRE_TENSIONER", 2: "DRIVER_SIDE_AIRBAG", 3: "PASSENGER_SIDE_AIRBAG",
    4: "RIGHT_CURTAIN_AIRBAG", 5: "LEFT_CURTAIN_AIRBAG", 6: "DRIVER_AIRBAG_SQUIB", 7: "PASSENGER_AIRBAG_SQUIB",
    11: "DRIVER_KNEE_AIRBAG", 12: "DRIVER_LAP_PRETENSIONER", 13: "PASSENGER_LAP_PRETENSIONER",
    14: "AIRBAG_DRIVER_FRONTAL_VENT", 15: "AIRBAG_PASSENGER_FRONTAL_VENT", 16: "2ND_ROW_RIGHT_PRE_TENSIONER",
    17: "SEATBAG_CENTER_FAR_SIDE_SEAT", 18: "2ND_ROW_LEFT_PRE_TENSIONER", 19: "BELTFORCE_LIMITER_DRIVER",
    20: "BELTFORCE_LIMITER_PASSENGER", 21: "HIGH_VOLTAGE_OR_BATTERY_DISABLE", 22: "PASSENGER_PELVIS_CUSHION",
    23: "DRIVER_PELVIS_CUSHION",
}
SQUIB_TEXT = {"DFV": "driver frontal vent", "PFV": "passenger frontal vent", "HVBD": "HV / battery disable",
              "PPC": "passenger pelvis cushion", "DPC": "driver pelvis cushion"}
# LOOP_F_<type> -> (name suffix, key of the squibs_config Squib_FaultTypeCode style index)
LOOP_TYPES = {
    "OPEN": ("OPEN", "Open"), "SHORT_TO_GND": ("S2G", "S2G"), "SHORT_TO_BATT": ("S2B", "S2B"),
    "LOW_RES": ("LORES", "LoRes"), "HIGH_RES": ("HIRES", "HiRes"), "CROSS_CONNECT": ("XCONN", "CrossConnect"),
    "UNEXPECTED_LOAD": ("UNEXPECTED", "UNEX"), "INTERNAL": ("INTERNAL", "Internal"),
    "ISRC": ("CURRENT_SOURCE", "CurrentSource"), "SQUIB_SUPPLY": ("SUPPLY", "Supply"),
    "LS_TRANS": ("LOW_SIDE_SWITCH", "LowSideSwitch"), "HS_TRANS": ("HIGH_SIDE_SWITCH", "HighSideSwitch"),
    "GROUND_LOSS": ("GROUND_LOSS", "GroundLoss"), "CSR_CROSS_CONNECT": ("CSR_XCONN", "CsrCrossConnect"),
    "PDC_ABORTED_INTERNAL": ("PDC_ABORT_INT", "PdcAbortInternal"),
    "PDC_ABORTED_EXTERNAL": ("PDC_ABORT_EXT", "PdcAbortExternal"), "DWELL_FTL": ("DWELL", "Dwell"),
}
LOOP_ASIC_TYPES = {"CMT": "LOOP{n}_CURRENT_MONITOR", "ASIC_VRCM": "LOOP_ASIC{n}_VRCM",
                   "ASIC_LOCKING": "LOOP_ASIC{n}_LOCKING", "ASIC_CONFIG": "LOOP_ASIC{n}_CONFIG",
                   "DEP_COMMAND": "LOOP_ASIC{n}_DEPLOY_COMMAND", "DEP_CMP": "LOOP_ASIC{n}_DEPLOY_COMPARE"}

# GPO driver -> output name (gpo_config DTC_GPO_fault keys; driver 3, the E-Call output, is not in
# gpo_config). Checked on the DTC.
GPO_DRIVER = {0: "PAB_OFF", 1: "PAB_ON", 2: "ENS", 3: "ECALL"}
GPO_TYPES = {"SHORT_GND": ("S2G", "S2G"), "SHORT_BAT": ("S2B", "S2B"), "OPEN": ("OPEN", "OPEN"),
             "CFG": ("CONFIG", "CONFIG"), "THERMAL": ("THERMAL", "THERMAL"), "INTERNAL": ("INTERNAL", "INTERNAL"),
             "SPI": ("SPI", "SPI"), "UNEXPECTED_LOAD": ("UNEXPECTED", "UNEX")}

# DCS sensor -> (short name, dcs_config / ods_config channel name)
DCS_SENSOR = {
    0: ("R2R_BELT", "DCS_Second_Row_Right"), 1: ("DRV_BELT", "DCS_DRVR"), 2: ("PSGR_BELT", "DCS_PSGR"),
    3: ("R2L_BELT", "DCS_Second_Row_Left"), 4: ("R2M_BELT", "DCS_Second_Row_Middle"),
    5: ("DRV_STPS1", "DCS_Driver_Seat_Track_Sensor_1"), 6: ("DRV_STPS2", "DCS_Driver_Seat_Track_Sensor_2"),
    7: ("PSGR_STPS1", "DCS_Passenger_Seat_Track_Sensor_1"), 8: ("PSGR_STPS2", "DCS_Passenger_Seat_Track_Sensor_2"),
    9: ("R2R_ODS", "DCS_Second_Row_Right_ODS"), 10: ("R2L_ODS", "DCS_Second_Row_Left_ODS"),
    11: ("R2M_ODS", "DCS_Second_Row_Middle_ODS"), 12: ("R3R_BELT", "DCS_Third_Row_Right"),
    13: ("R3L_BELT", "DCS_Third_Row_Left"), 14: ("R3R_ODS", "DCS_Third_Row_Right_ODS"),
    15: ("R3L_ODS", "DCS_Third_Row_Left_ODS"), 16: ("DCS16", None),
}
DCS_SENSOR_FUNCTION = {   # the FLTMONR_DCS_E_<function> text each sensor's faults carry
    0: "SECOND_ROW_RIGHT_BUCKLE", 1: "DRIVER_SEAT_BELT", 2: "PASSENGER_SEAT_BELT", 3: "SECOND_ROW_LEFT_BUCKLE",
    4: "SECOND_ROW_MIDDLE_BUCKLE", 5: "DRIVER_STPS1", 6: "DRIVER_STPS2", 7: "PASSENGER_STPS1",
    8: "PASSENGER_STPS2", 9: "SECOND_ROW_RIGHT_ODS", 10: "SECOND_ROW_LEFT_ODS", 11: "SECOND_ROW_MIDDLE_ODS",
    12: "THIRD_ROW_RIGHT_BUCKLE", 13: "THIRD_ROW_LEFT_BUCKLE", 14: "THIRD_ROW_RIGHT_ODS", 15: "THIRD_ROW_LEFT_ODS",
}
DCS_TYPES = {"SHORT_PLUS": ("S2B", "S2B"), "SHORT_GND": ("S2G", "S2G"), "OPEN": ("OPEN", "Open"),
             "CROSS_CONNECT": ("XCONN", "CrossConnect"), "UNEXPECTED_LOAD": ("UNEXPECTED", "UNEX"),
             "INTERNAL": ("ASIC", "Internal"), "SPI": ("SPI", "SPI")}

# RSU: satellite name from the side/pillar rsu_config gives the DTC base (A_PILLAR_LEFT_X -> A_PILLAR_LEFT)
RSU_TYPES = {"SAT_OPEN": ("OPEN", "Open"), "SAT_SHORT_GND": ("S2G", "S2G"), "SAT_SHORT_BAT": ("S2B", "S2B"),
             "SAT_COMM": ("COMM", "Communication_Error"), "SAT_INTERNAL": ("INTERNAL", "Internal_Error"),
             "SAT_CFG": ("CONFIG", "Config"), "SAT_UNEXPECTED_LOAD": ("UNEXPECTED", "UNEX")}

# Module tag for internal faults: <MODULE>_F_<what> -> <TAG>_<what>
MODULE_TAG = {
    "ASICCTRL": "ASIC", "HSS": "HSS", "SAF": "SAFING", "PWR": "PWR", "WDG": "WATCHDOG", "MCAL": "MCAL",
    "FLS": "FLASH", "EXTFLS": "EXT_FLASH", "FEE": "FEE", "TASKMONR": "TASK", "TRAPSMGR": "TRAP",
    "SCRAPMGR": "SCRAP", "NVMBLKMGR": "NVM_BLOCK", "OPSCSHMGR": "ALGO", "OPSSGPOOLMGR": "OPS",
    "SYSCHAR": "SYS", "SYSMODMGR": "SYS_MODE", "DPLMTMGR": "DEPLOY", "RESETDRVR": "RESET",
    "DEVICECFGMGR": "DEVICE_CFG", "CYBER": "CYBER", "MANUDATA": "MANUFACTURING", "RSTEDR": "EDR",
    "SYNC": "SYNC", "IMUSGPOOLMGR": "IMU", "IMUMGR": "IMU", "NVM": "NVM",
}
EXPLICIT = {   # customer-visible faults with a plainer name
    "SYSCHAR_F_PWR_BATT_UNDER": "BATT_UNDERVOLTAGE", "SYSCHAR_F_PWR_BATT_OVER": "BATT_OVERVOLTAGE",
    "VIN_MISMATCH_ERROR": "VIN_MISMATCH", "CAN_BUS_OFF_FAULT": "FD_BUS_OFF", "HSCAN_BUS_OFF_FAULT": "HS_BUS_OFF",
    "SRS_VARIANT_CODE_ERROR": "VARIANT_CODE_ERROR", "ECU_CONFIGURATION_ERROR": "ECU_CONFIG_ERROR",
    "ECU_IN_PLANT_MODE": "PLANT_MODE", "UNDERSTRIKE_CRASH_EVENT": "UNDERSTRIKE_CRASH",
    "SCRAPMGR_F_SCRAP_DEPLOYED_BY_SCRAP": "SCRAP_DEPLOYED", "SCRAPMGR_F_SCRAP_ENTERED_SCRAP": "SCRAP_ENTERED",
    "RSTEDR_F_EDR_LOCKED_EVENT": "EDR_LOCKED", "FLTMONR_E_EVENT_0_TRAP": "EVENT_TRAP",
    "F_E2E_PIB_CRC_MISMATCH": "E2E_PIB_CRC", "F_E2E_PIB_ALIVE_COUNTER": "E2E_PIB_COUNTER",
    "NVM_F_NVM_INTEGRITY_FAILED": "NVM_INTEGRITY", "F_SMU_ALARM_OCCURRED": "SMU_ALARM",
    "F_MCU_PRERUN_TEST_FAILED_LBIST": "MCU_LBIST", "F_MCU_PRERUN_TEST_FAILED_MONBIST": "MCU_MONBIST",
    "F_MCU_PRERUN_TEST_FAILED_MBIST": "MCU_MBIST", "OPS_E_PRETENSIONERS_FIRED": "PRETENSIONERS_FIRED",
    "OPS_E_STRAP_RETURN_PRETENSIONER_FIRED": "STRAP_PRETENSIONER_FIRED",
    "OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBIT": "FRONTAL_BAGS_FIRED_PAB_OFF",
    "ADAS_DES_STRWHL_ANGLE_CMD_SIGNAL_CONTENT_FAILURE": "STEER_ANGLE_CMD_SCF",
    "ODOMTR_READING_IS_SIGNAL_CONTENT_FAILURE": "ODOMETER_SCF",
    "STEERING_ABSOLUTE_ANGLE_SIGNAL_CONTENT_FAILURE": "STEERING_ANGLE_SCF",
    "MOTOR_SPD_SIGNAL_CONTENT_FAILURE": "MOTOR_SPEED_SCF",
}


def can_name(summary: str) -> str:
    """CAN supervision faults: <node>_NODE_ABSENT, <frame>_TIMEOUT / _CRC / _DLC / _COUNTER, <signal>_SCF."""
    s = summary
    if s.endswith("_NODE_ABSENT"):
        return s.replace("FR_ZONE", "FR_ZONE")
    if s.endswith("_SIGNAL_CONTENT_FAILURE"):
        return s[: -len("_SIGNAL_CONTENT_FAILURE")] + "_SCF"
    m = re.fullmatch(r"(.+?)_(MESSAGE_TIMEOUT|CRC_MISMATCH|DLC_MISMATCH|ALIVECOUNTER_MISMATCH)", s)
    if not m:
        return ""
    frame, kind = m.group(1), m.group(2)
    frame = frame.replace("_FD", "").replace("HPCAD_", "HPCAD").replace("HPCC_", "HPCC").replace("FRZONE", "FR_ZONE")
    return frame + {"MESSAGE_TIMEOUT": "_TIMEOUT", "CRC_MISMATCH": "_CRC", "DLC_MISMATCH": "_DLC",
                    "ALIVECOUNTER_MISMATCH": "_COUNTER"}[kind]


# Plain words for the abbreviations in the fault monitor names (applied in order).
WORDS = [
    (r"_DEC_", "_SATURATION_"), (r"_OCR_", "_OFFSET_"), (r"^OPS_HIG_", "OPS_HIGH_G_"), (r"^OPS_LOG_", "OPS_LOW_G_"),
    (r"^OPS_FRNTALG_", "FRONT_"), (r"^OPS_REALG_", "REAR_"), (r"^OPS_SIDEALG_", "SIDE_"), (r"^OPS_ROLLALG_", "ROLL_"),
    (r"^OPS_PEDALG_", "PEDESTRIAN_"), (r"^MEM_", ""), (r"_WRONG_DRIVER_STATE$", "_WRONG_STATE"), (r"^ECU_", ""),
    (r"^CONFG_", "CONFIG_"), (r"^MCAL_", ""), (r"^NVM_", ""), (r"^IMU_", ""),
]


def generic_name(summary: str) -> str:
    m = re.fullmatch(r"([A-Z0-9]+)_F_(.+)", summary)
    if not m:
        return summary
    module, what = m.group(1), m.group(2)
    tag = MODULE_TAG.get(module, module)
    what = what.replace("TOO_", "")
    for prefix in (tag + "_", "ASIC_" if tag == "ASIC" else "\0", module + "_"):
        if what.startswith(prefix):
            what = what[len(prefix):]
    for pattern, repl in WORDS:
        what = re.sub(pattern, repl, what)
    if tag == "ALGO" and what.startswith("OPS_"):
        what = what[4:]
    return f"{tag}_{what}"


# ---------------------------------------------------------------------------
# Values
# ---------------------------------------------------------------------------

def dtc_text(raw) -> str | None:
    digits = re.sub(r"[^0-9A-Fa-f]", "", str(raw or "").upper().replace("0X", ""))
    if len(digits) != 6:
        return None
    return " ".join(f"0x{digits[i:i + 2]}" for i in range(0, 6, 2))


def plain(text) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def ms_value(text: str):
    """A maturation / dematuration time the list gives as plain milliseconds, else None."""
    t = plain(text)
    m = re.fullmatch(r"(?:Current Value:\s*)?(\d+)\s*ms", t, re.I) or re.fullmatch(r"(\d{3,})", t)
    return int(m.group(1)) if m else None


def count_value(text: str):
    m = re.fullmatch(r"Counts:\s*(\d+)", plain(text), re.I)
    return int(m.group(1)) if m else None


def latched(text):
    t = plain(text).lower()
    if t.startswith("not"):
        return False
    if t.startswith("latched") or t.startswith("permanent"):
        return True
    return None


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

def load_rows() -> list[dict]:
    wb = openpyxl.load_workbook(WORKBOOK, read_only=True, data_only=True)
    ws = wb["Export"]
    rows = list(ws.iter_rows(values_only=True))
    header = rows[0]
    return [dict(zip(header, r)) for r in rows[1:]]


def rsu_satellites() -> dict:
    """DTC base (0xXXXX) -> satellite name, from rsu_config: the sensor name without its axis."""
    sat = {}
    for channel, base in rsu_config.DTC_RSU_fault.items():
        sensor = rsu_config.RSU_CHANNEL_TO_SENSOR[channel]
        name = re.sub(r"_RSU$", "", re.sub(r"_(X|Y|Z)$", "", sensor))
        key = base.replace("0x", "").replace(" ", "").upper()
        sat.setdefault(key, name)
    return sat


def build():
    rows = load_rows()
    live = [r for r in rows if r.get("Type") != "Heading" and str(r.get("_ReqStatus")) != "Obsolete"]
    rsu_sat = rsu_satellites()
    sat_order = {name: index for index, name in enumerate(dict.fromkeys(rsu_sat.values()))}
    faults = OrderedDict()            # name -> (section, entry)
    index = {"LOOP": {}, "DCS": {}, "GPO": {}, "RSU": {}}
    problems = []

    def add(section, name, row, order=None):
        name = re.sub(r"[^A-Z0-9_]", "_", name.upper())
        if name in faults:
            problems.append(f"duplicate name {name}: {row['Summary']} / {faults[name][1]['monitor']}")
            return None
        q_text, d_text = plain(row.get("_Fault_Monitor_Maturation_Time")), plain(row.get("_Fault_Monitor_Dematuration_Time"))
        entry = OrderedDict()
        entry["dtc"] = dtc_text(row.get("_DTC_Number"))
        q_ms, d_ms = ms_value(q_text), ms_value(d_text)
        q_cnt, d_cnt = count_value(q_text), count_value(d_text)
        if q_cnt is not None or d_cnt is not None:
            entry["qualify_counts"], entry["dequalify_counts"] = q_cnt, d_cnt
        else:
            entry["qualify_ms"], entry["dequalify_ms"] = q_ms, d_ms
            if q_ms is None or d_ms is None:
                entry["timing"] = f"maturation: {q_text or 'not given'}; dematuration: {d_text or 'not given'}"
        entry["latched"] = latched(row.get("_Fault_Monitor_Latched_status"))
        entry["monitor"] = str(row["Summary"]).strip()
        entry["req"] = int(float(row["ID"]))
        entry["text"] = plain(row.get("Description")).replace("(FLTMONR", " (FLTMONR").replace("  ", " ")
        faults[name] = (section, entry, order if order is not None else (9999, name))
        return name

    for row in live:
        summary = str(row["Summary"]).strip()
        parent = plain(row.get("Parent"))
        struck = parent.startswith("Customer StrikeOut")
        text = plain(row.get("Description"))
        dtc = dtc_text(row.get("_DTC_Number"))
        m = re.fullmatch(r"LOOP_F_(.+)_(\d+)", summary)
        if m and m.group(1) in LOOP_TYPES:
            line = int(m.group(2))
            suffix, key = LOOP_TYPES[m.group(1)]
            squib = LOOP_LINE_SQUIB.get(line, f"LINE{line:02d}")
            function = LOOP_LINE_FUNCTION.get(line)
            if function and "FLTMONR_LOP_E_" in text and function not in text:
                problems.append(f"{summary}: expected {function} in '{text}'")
            base = squibs_config.DTC_Squib_FaultCode.get(squib)
            if base and dtc and "FLTMONR_LOP_E_" in text and not dtc.startswith(base):
                problems.append(f"{summary}: DTC {dtc} vs squibs_config {squib} {base}")
            name = add("STRUCK" if struck else "LOOP", f"{squib}_{suffix}", row,
                       (line, list(LOOP_TYPES).index(m.group(1))))
            if name and not struck and squib in squibs_config.SquibNumber:
                index["LOOP"].setdefault(squib, OrderedDict())[key] = name
            continue
        if m and m.group(1) in LOOP_ASIC_TYPES:
            add("STRUCK" if struck else "LOOP", LOOP_ASIC_TYPES[m.group(1)].format(n=int(m.group(2))), row,
                (100 + list(LOOP_ASIC_TYPES).index(m.group(1)), int(m.group(2))))
            continue
        m = re.fullmatch(r"GPO_F_(.+)_(\d+)", summary)
        if m:
            driver, kind = int(m.group(2)), m.group(1)
            out = GPO_DRIVER[driver]
            suffix, key = GPO_TYPES[kind]
            base = gpo_config.DTC_GPO_fault.get(out)
            if base and dtc and dtc != "0x90 0x13 0x49" and not dtc.startswith(base):
                problems.append(f"{summary}: DTC {dtc} vs gpo_config {out} {base}")
            name = add("STRUCK" if struck else "GPO", f"{out}_{suffix}", row, (driver, list(GPO_TYPES).index(kind)))
            if name and not struck:
                index["GPO"].setdefault(out, OrderedDict())[key] = name
            continue
        m = re.fullmatch(r"DCS_F_(.+)_(\d+)", summary)
        if m and m.group(1) in DCS_TYPES:
            sensor = int(m.group(2))
            short, channel = DCS_SENSOR[sensor]
            suffix, key = DCS_TYPES[m.group(1)]
            function = DCS_SENSOR_FUNCTION.get(sensor)
            if function and "FLTMONR_DCS_E_" in text and function not in text:
                problems.append(f"{summary}: expected {function} in '{text}'")
            name = add("STRUCK" if struck else "DCS", f"{short}_{suffix}", row,
                       (sensor, list(DCS_TYPES).index(m.group(1))))
            if name and channel and not struck:
                index["DCS"].setdefault(channel, OrderedDict())[key] = name
            continue
        m = re.fullmatch(r"RSU_F_(SAT_[A-Z_]+?)_(\d+)", summary)
        if m and m.group(1) in RSU_TYPES:
            slot = re.search(r"(SB3_M|EX3_0) CH(\d+) S(\d+)", text)
            base = (dtc or "").replace("0x", "").replace(" ", "")[:4]
            sat = rsu_sat.get(base)
            if sat is None:
                func = re.search(r"RSU_SAT_([A-Z_]+?)_(?:OPEN|SHORT|STG|STB|COMM|INTERNAL|CFG|CONFIG|UNEXPECTED|MANCHESTER)",
                                 text)
                sat = f"SAT{int(m.group(2)):02d}" if not func else func.group(1)
            suffix, key = RSU_TYPES[m.group(1)]
            where = f"_S{slot.group(3)}" if slot else f"_{int(m.group(2)):02d}"
            name = add("STRUCK" if struck else "RSU", f"{sat}{where}_{suffix}", row,
                       (sat_order.setdefault(sat, len(sat_order)), where, list(RSU_TYPES).index(m.group(1))))
            if name and slot and not struck:
                index["RSU"].setdefault(f"{sat}{where}", OrderedDict())[key] = name
            continue
        m = re.fullmatch(r"RSU_F_ASIC_CHANNEL_([A-Z_]+)_(\d+)", summary)
        if m:
            add("STRUCK" if struck else "RSU", f"RSU_CHANNEL{int(m.group(2)):02d}_{m.group(1)}", row,
                (500, int(m.group(2)), m.group(1)))
            continue
        cname = can_name(summary)
        if cname:
            final = EXPLICIT.get(summary, cname)
            kind = next((i for i, tail in enumerate(("_NODE_ABSENT", "_TIMEOUT", "_CRC", "_DLC", "_COUNTER", "_SCF"))
                         if final.endswith(tail)), 9)
            add("STRUCK" if struck else "CAN", final, row, (kind, final))
            continue
        if summary in EXPLICIT:
            section = {"Loops Fired": "FIRED", "CRASH_DTC": "CRASH"}.get(parent, "SYSTEM")
            add("STRUCK" if struck else section, EXPLICIT[summary], row)
            continue
        if parent == "CRASH_DTC":
            add("CRASH", summary, row, (0, len(faults)))
            continue
        if parent == "Loops Fired":
            add("FIRED", summary.replace("OPS_E_", ""), row, (0, len(faults)))
            continue
        m = re.fullmatch(r"DRVR_F_LOGARS_(.+)_(\d+)", summary)
        if m:
            add("IMU", f"IMU{int(m.group(2))}_{m.group(1).replace('_RECOV', '_RECOVERABLE')}", row)
            continue
        m = re.fullmatch(r"DRVR_F_HIG_(.+)_(\d+)", summary)
        if m:
            add("HIGH_G", f"HIGH_G{int(m.group(2))}_{m.group(1)}", row)
            continue
        section = {"IMU": "IMU", "HIG": "HIGH_G", "RSU": "RSU"}.get(parent, "SYSTEM")
        name = generic_name(summary)
        if section == "RSU":
            name = name.replace("OPS_RSU_", "OPS_RSU_")
        if summary.startswith("IMUSGPOOLMGR_F_IMU_") or summary.startswith("IMUMGR_F_IMU_"):
            name = "IMU_" + re.sub(r"^IMU(SGPOOL)?MGR_F_IMU_", "", summary)
        add("STRUCK" if struck else section, name, row)

    if problems:
        raise SystemExit("fault list problems:\n  " + "\n  ".join(problems))
    return faults, index, len(live)


SECTIONS = [
    ("LOOP", "Squib loops", "LOOP_FAULTS",
     "One entry per squib and fault, named <squib>_<fault>; squibs as squibs_config names them (the fault list "
     "numbers the ECU lines: RPT line 0, LPT 1, RSA 2, LSA 3, RCA 4, LCA 5, DAB 6, PAB 7, DKA 11, RLPT 12, "
     "LLPT 13, R2RPT 16, CAB 17, R2LPT 18, DBFL 19, PBFL 20; LINE08-LINE10 are unconfigured lines and "
     "LINE24-LINE31 lines the ECU does not use). LOOP_ASIC<n>_* / LOOP<n>_CURRENT_MONITOR are per ASIC."),
    ("GPO", "General purpose outputs", "GPO_FAULTS",
     "<output>_<fault>: PAB_OFF (driver 0, passenger airbag OFF lamp), PAB_ON (driver 1, PAB ON lamp), "
     "ENS (driver 2, crash output) and ECALL (driver 3, E-Call output; not in gpo_config)."),
    ("DCS", "Belt buckles, seat track sensors and ODS (DCS channels)", "DCS_FAULTS",
     "<seat>_<fault>: DRV / PSGR = front seats, R2L / R2M / R2R = second row left / middle / right, "
     "R3L / R3R = third row; BELT = buckle switch, STPS1/2 = seat track position switch, ODS = occupant "
     "switch; ASIC = sensor ASIC failure. DCS16 is the unassigned sensor 16."),
    ("RSU", "Remote sensing units", "RSU_FAULTS",
     "<satellite>_S<slot>_<fault>, the satellite named as rsu_config names its side and pillar (right-hand "
     "drive: driver = right), S1/S2/S3 its sensor slot on the ASIC channel; RSU_CHANNEL<n>_* are per "
     "ASIC channel; OPS_RSU_* are algorithm checks of RSU line <n>."),
    ("CAN", "CAN supervision", "CAN_FAULTS",
     "<node>_NODE_ABSENT, <frame>_TIMEOUT, <frame>_CRC / _DLC / _COUNTER (message content failure: all "
     "three share the frame's DTC), <signal>_SCF (signal content failure). Times are in frame counts."),
    ("SYSTEM", "Power, ECU and internal faults", "SYSTEM_FAULTS",
     "Supply, VIN, variant code, bus-off, plant mode and every internal fault monitor (most share DTC "
     "0x90 0x13 0x49, ECU internal), named <module>_<monitor>."),
    ("IMU", "IMU", "IMU_FAULTS", "Inertial measurement unit faults and its OPS plausibility checks."),
    ("HIGH_G", "High-g sensors", "HIGH_G_FAULTS", "Central high-g sensor faults and its OPS checks."),
    ("FIRED", "Loops fired", "FIRED_FAULTS", "Records of fired loops (no DTC for the airbag groups)."),
    ("CRASH", "Crash records", "CRASH_FAULTS", "Crash DTCs, set at once and kept (warning lamp ON)."),
    ("STRUCK", "Struck out by the customer", "STRUCK_OUT_FAULTS",
     "Faults the customer struck out of the fault list (heading 'Customer StrikeOut DTC'): kept for "
     "reference, not part of the project's fault set (not in FAULT_LIST)."),
]


def fmt_value(value) -> str:
    return repr(value)


def monitor_var(name: str) -> str:
    """Variable of a fault monitor entry: FM_ + its short name. The plain mnemonics belong to the common DTC
    section at the end of the file (DAB_OPEN there is the DTC B0001-13, FM_DAB_OPEN here its fault monitor);
    the section dicts and lookups keep the short name as key."""
    return f"FM_{name}"


def entry_lines(name: str, entry: dict) -> list[str]:
    parts = [f"{key!r}: {fmt_value(value)}" for key, value in entry.items()]
    lead = f"{name} = {{"
    pad = " " * len(lead)
    lines, current = [], lead
    for i, part in enumerate(parts):
        piece = part + ("}" if i == len(parts) - 1 else ", ")
        if len(current) + len(piece.rstrip()) > 116 and current.strip() != lead.strip():
            lines.append(current.rstrip())
            current = pad
        if len(current) + len(piece.rstrip()) > 116 and part.split(':')[0] in ("'text'", "'timing'"):
            # a long description as adjacent string literals, one per line
            key_text = part.split(':')[0] + ': ('
            words = str(list(entry.values())[i]).split(" ")
            chunk, chunks = "", []
            room = 116 - len(current) - len(key_text) - 3
            for word in words:
                if chunk and len(chunk) + 1 + len(word) > room:
                    chunks.append(chunk + " ")
                    chunk = word
                else:
                    chunk = f"{chunk} {word}" if chunk else word
            chunks.append(chunk)
            tail = ")" + ("}" if i == len(parts) - 1 else ",")
            inner_pad = " " * (len(current) + len(key_text))
            lines.append(current + key_text + repr(chunks[0]))
            for extra in chunks[1:-1]:
                lines.append(inner_pad + repr(extra))
            if len(chunks) > 1:
                lines.append(inner_pad + repr(chunks[-1]) + tail)
            else:
                lines[-1] += tail
            current = pad
            continue
        current += piece
    if current.strip():
        lines.append(current.rstrip())
    return lines


def render(faults, index, total_live: int) -> str:
    out = []
    by_section = OrderedDict((key, []) for key, *_ in SECTIONS)
    for name, (section, entry, order) in faults.items():
        by_section[section].append((order, name, entry))
    for key in by_section:
        by_section[key] = [(name, entry) for _, name, entry in sorted(by_section[key], key=lambda item: item[0])]
    counts = {key: len(items) for key, items in by_section.items()}
    out.append('"""')
    out.append("Module Configuration: Fault_List")
    out.append(f"Project: {PROJECT}")
    out.append("=" * 60)
    out.append("")
    out.append("Every fault of the project fault list, one entry per fault monitor, with a short name.")
    out.append("")
    out.append("Source: project_reuirements/m310_m314_m110/DES_SW_Mahindra_FaultList.xlsx (Codebeamer export)")
    out.append(f"- {total_live} faults that are not obsolete: {total_live - counts['STRUCK']} in the project's fault set")
    out.append(f"  (FAULT_LIST) and {counts['STRUCK']} struck out by the customer (STRUCK_OUT_FAULTS).")
    out.append("Built with tools/build_m310_fault_list_config.py; rebuild it there rather than edit by hand.")
    out.append("")
    out.append("Each fault is a dict:")
    out.append("    dtc               DTC with its failure type byte, as the ECU reports it in 19 02 (None: no DTC)")
    out.append("    qualify_ms        fault monitor maturation time in ms")
    out.append("    dequalify_ms      dematuration time in ms (both None where the list gives no plain ms value;")
    out.append("                      'timing' then quotes the list)")
    out.append("    qualify_counts /  CAN supervision: frames counted to mature / dematurate (time = count x")
    out.append("    dequalify_counts  the frame period)")
    out.append("    latched           True: stays active until cleared / over an IGN cycle (None: not given)")
    out.append("    monitor           fault monitor name in the fault list")
    out.append("    req               Codebeamer requirement ID")
    out.append("    text              fault list description (with the ECU fault event)")
    out.append("")
    out.append("Lookups by bench name: LOOP_FAULT_BY_SQUIB (squibs_config names, Squib_FaultTypeCode keys),")
    out.append("DCS_FAULT_BY_CHANNEL (dcs_config / ods_config names, DCS_FaultTypeCode keys), GPO_FAULT_BY_OUTPUT")
    out.append("(gpo_config names, GPO_FaultStatus keys) and RSU_FAULT_BY_SATELLITE (rsu_fault_code keys).")
    out.append("Each fault monitor entry is the variable FM_<short name>; the dicts and lookups are keyed by the")
    out.append("short name.")
    out.append("")
    out.append("After the project fault list: the Fault_List settings of the per-DTC scripts and the common EV / ICE")
    out.append("DTC list (one dict per DTC, named by its mnemonic) - the same section as in every project's")
    out.append("fault_list_config.py, from tools/build_common_dtc_dictionary.py.")
    out.append('"""')
    out.append("")
    out.append(f'PROJECT_NAME = "{PROJECT}"')
    out.append('MODULE_NAME = "Fault_List"')
    out.append("")
    out.append("ENABLED = True")
    out.append("TIMEOUT_SECONDS = 30")
    out.append("RETRY_COUNT = 1")
    out.append("")
    out.append("# ── Fault_List Settings ──")
    for key, title, dict_name, note in SECTIONS:
        items = by_section[key]
        if not items:
            continue
        out.append("")
        out.append("")
        out.append(f"# {'=' * 100}")
        out.append(f"# {title} ({len(items)})")
        for line in wrap(note, 98):
            out.append(f"# {line}")
        out.append(f"# {'=' * 100}")
        for name, entry in items:
            out.extend(entry_lines(monitor_var(name), entry))
        out.append("")
        out.append(f"{dict_name} = {{")
        for name, _ in items:
            out.append(f"    {name!r}: {monitor_var(name)},")
        out.append("}")
    out.append("")
    out.append("")
    out.append(f"# {'=' * 100}")
    out.append("# Every fault of the project's fault set (the struck-out ones are not in it)")
    out.append(f"# {'=' * 100}")
    out.append("FAULT_LIST = {")
    for key, _, dict_name, _ in SECTIONS:
        if key != "STRUCK" and by_section[key]:
            out.append(f"    **{dict_name},")
    out.append("}")
    lookups = [
        ("LOOP", "LOOP_FAULT_BY_SQUIB", "Squib (squibs_config name) -> fault type (Squib_FaultTypeCode key) -> fault."),
        ("DCS", "DCS_FAULT_BY_CHANNEL", "DCS channel (dcs_config / ods_config name) -> fault type -> fault."),
        ("GPO", "GPO_FAULT_BY_OUTPUT", "GPO output (gpo_config name, plus ECALL) -> fault type -> fault."),
        ("RSU", "RSU_FAULT_BY_SATELLITE", "RSU satellite sensor -> fault type (rsu_fault_code key) -> fault."),
    ]
    device_order = {
        "LOOP": list(squibs_config.SquibName),
        "DCS": [channel for _, channel in DCS_SENSOR.values() if channel],
        "GPO": list(GPO_DRIVER.values()),
        "RSU": list(index["RSU"]),
    }
    kind_order = {
        "LOOP": [key for _, key in LOOP_TYPES.values()], "DCS": [key for _, key in DCS_TYPES.values()],
        "GPO": [key for _, key in GPO_TYPES.values()], "RSU": [key for _, key in RSU_TYPES.values()],
    }
    for key, dict_name, note in lookups:
        out.append("")
        out.append(f"# {note}")
        out.append(f"{dict_name} = {{")
        devices = sorted(index[key], key=lambda d: device_order[key].index(d) if d in device_order[key] else 999)
        for device in devices:
            kinds = OrderedDict(sorted(index[key][device].items(), key=lambda kv: kind_order[key].index(kv[0])))
            inner = ", ".join(f"{kind!r}: {monitor_var(name)}" for kind, name in kinds.items())
            first = f"    {device!r}: {{"
            items = [f"{kind!r}: {monitor_var(name)}" for kind, name in kinds.items()]
            current = first
            pad = " " * len(first)
            lines = []
            for i, item in enumerate(items):
                piece = item + ("}," if i == len(items) - 1 else ", ")
                if len(current) + len(piece.rstrip()) > 116 and current != first:
                    lines.append(current.rstrip())
                    current = pad
                current += piece
            lines.append(current.rstrip())
            out.extend(lines)
            del inner
        out.append("}")
    out.append("")
    out.append("")
    out.append(f"# {'=' * 100}")
    out.append("# Fault_List settings of the per-DTC scripts")
    out.append(f"# {'=' * 100}")
    out.append(common_section(PROJECT))
    return "\n".join(out)


def wrap(text: str, width: int) -> list[str]:
    import textwrap
    return textwrap.wrap(text, width=width)


PROJECT = "M310_M314_M110"


def use_project(project: str) -> Path:
    """Point the builder at one EV project: its module configs and its output file."""
    global PROJECT, gpo_config, rsu_config, squibs_config
    PROJECT = project
    package = f"Framework_IOEM_Py.projects.{project}.config"
    gpo_config = importlib.import_module(f"{package}.gpo_config")
    rsu_config = importlib.import_module(f"{package}.rsu_config")
    squibs_config = importlib.import_module(f"{package}.squibs_config")
    return ROOT / "projects" / project / "config" / "fault_list_config.py"


def main(argv: list[str]) -> int:
    status = 0
    for project in EV_PROJECTS:
        output = use_project(project)
        faults, index, total = build()
        source = render(faults, index, total)
        compile(source, str(output), "exec")
        names = Counter(section for section, _, _ in faults.values())
        if "--check" in argv:
            same = output.exists() and output.read_text(encoding="utf-8") == source
            print(f"{project} fault_list_config.py up to date" if same
                  else f"{project} fault_list_config.py differs from the fault list")
            status = status or (0 if same else 1)
            continue
        output.write_text(source, encoding="utf-8", newline="\n")
        print(f"{len(faults)} faults written to {output}: {dict(names)}")
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv))
