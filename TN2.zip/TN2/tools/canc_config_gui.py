"""CAN-C configuration builder: a window that asks for everything canc_config.py needs.

Work through the tabs in order:

  1 Project     project name, CAN variant key, the folder to write to
  2 Buses       which buses the project has - CAN FD, high-speed CAN, normal (classic)
                CAN - the DBC of each, the ARIA channel it is wired to, the SRS node
  3 Nodes       per node: key frame, node-absent DTC, message-timeout DTC
  4 Frames      per restbus frame: the node that sends it
  5 Fault DTCs  message-content DTC per CRC / alive-counter frame, signal-content DTC
                per signal the DBC gives an invalid code
  6 EDR         the EDR parameter each signal feeds, by its common name (U171's; offered
                from the project's edr_config, or U171's while the project has none)
  7 Network     network-management counts and delays, CAN wakeup and CAN NM wakeup
  8 Crash       the SRS frames read at crash time and the values expected per crash type
  9 Build       what is still open, a preview, then save the inputs and build the config

What the DBCs give is filled in from them (marked DERIVED in the inputs file); the rest
is asked for. Every answer is kept in the project's inputs file (canc_dbc_inputs.py), and
canc_config.py is built by tools/build_canc_config_from_dbc.py's own rules, so this window
and the command line give the same file - in the common structure every project shares
(tools/canc_common_names.py).

Offline only: reads DBCs, writes the inputs file and canc_config.py. It never writes the
hand-maintained U171, Z121 or M310_M314_M110 configs, and asks before replacing a file.

Usage:
    py -3.14 tools/canc_config_gui.py [--project NAME]
"""

from __future__ import annotations

import argparse
import sys
import types
from pathlib import Path
from typing import Any, Callable

sys.path.insert(0, str(Path(__file__).resolve().parent))

import build_canc_config_from_dbc as gen  # noqa: E402
import canc_common_names as common  # noqa: E402

REPOSITORY_ROOT = gen.REPOSITORY_ROOT
ORIGIN = "Written by tools/canc_config_gui.py."
CRASH_KEYS = ("STS_CRASH", "INDC_SRS", "CRASH_LOCATION", "DOOR_UNLOCK")


# --------------------------------------------------------------------------------------
# The session: everything the window edits, with no window in it (so it can be tested)
# --------------------------------------------------------------------------------------


class ValueInputs(gen.Inputs):
    """gen.Inputs over values held in memory instead of a file."""

    def __init__(self, values: dict[str, Any], path: Path | None):
        self.path = path
        self.module = types.SimpleNamespace(**values)


class Session:
    def __init__(self, project: str = ""):
        self.project = project
        self.variant = ""
        self.output_dir: Path | None = None
        # Per bus type: use it, its DBC, the ARIA channel, the legacy ch number, SRS node.
        self.buses: dict[str, dict[str, Any]] = {
            bus_type: {"use": False, "dbc": "", "channel": common.DEFAULT_ARIA_CHANNEL[bus_type],
                       "ch": None, "srs_node": ""}
            for bus_type in common.BUS_TYPES}
        self.values: dict[str, Any] = {}
        self.model: gen.Model | None = None
        self.read_buses: list[gen.Bus] = []

    # -- paths -------------------------------------------------------------------------
    def default_output_dir(self) -> Path:
        return REPOSITORY_ROOT / "projects" / self.project / "config"

    @property
    def folder(self) -> Path:
        return self.output_dir or self.default_output_dir()

    @property
    def inputs_path(self) -> Path:
        return self.folder / gen.INPUTS_FILE_NAME

    @property
    def config_path(self) -> Path:
        return self.folder / "canc_config.py"

    def writes_hand_maintained(self) -> bool:
        try:
            same = self.folder.resolve() == self.default_output_dir().resolve()
        except OSError:
            same = False
        return self.project in gen.HAND_MAINTAINED_PROJECTS and same

    # -- reading ---------------------------------------------------------------------
    def load_inputs(self, path: Path | None = None) -> bool:
        """Take the answers of an existing inputs file (and the DBCs it records)."""
        path = path or self.inputs_path
        if not path.is_file():
            return False
        module = gen.Inputs(path).module
        self.values = {name: getattr(module, name) for name in gen.INPUT_NAMES
                       if hasattr(module, name)}
        self.variant = self.values.get("CAN_VARIANT") or self.variant
        for bus_type, dbc in (self.values.get("DBC_FILES") or {}).items():
            if bus_type in self.buses:
                entry = self.buses[bus_type]
                entry.update(use=True, dbc=dbc)
                entry["channel"] = (self.values.get("BUS_CHANNELS") or {}).get(bus_type, entry["channel"])
                entry["ch"] = (self.values.get("BUS_CH") or {}).get(bus_type)
                entry["srs_node"] = (self.values.get("SRS_NODES") or {}).get(bus_type, "")
        return True

    def _resolve(self, dbc: str) -> Path:
        path = Path(dbc)
        return path if path.is_absolute() else REPOSITORY_ROOT / path

    def read_dbcs(self) -> str:
        """Read the chosen DBCs and fill every answer the DBCs can give that is not set."""
        if not self.project:
            raise ValueError("Give the project a name first (tab 1).")
        chosen = [(bus_type, entry) for bus_type, entry in self.buses.items() if entry["use"]]
        if not chosen:
            raise ValueError("Tick at least one bus and choose its DBC (tab 2).")
        self.read_buses = []
        for bus_type, entry in chosen:
            path = self._resolve(entry["dbc"])
            if not path.is_file():
                raise ValueError(f"{common.BUS_TYPE_LABELS[bus_type]}: no DBC at {path}")
            bus = gen.read_bus(path, bus_type, entry["srs_node"] or None)
            entry["srs_node"] = bus.ecu_node
            self.read_buses.append(bus)
        self.values["BUS_CHANNELS"] = {t: e["channel"] for t, e in chosen}
        self.values["BUS_CH"] = {t: e["ch"] for t, e in chosen if e["ch"] not in (None, "")}
        self.values["CAN_VARIANT"] = self.variant or self.project
        self.rebuild_model()
        derived = gen.derived_inputs(self.model)
        for name, value in derived.items():
            current = self.values.get(name)
            if isinstance(value, dict) and isinstance(current, dict):
                merged = dict(value)
                merged.update({k: v for k, v in current.items() if v is not None or k not in value})
                self.values[name] = merged
            elif current is None or name in ("DBC_FILES", "SRS_NODES"):
                self.values[name] = value
        self.rebuild_model()
        lines = []
        for bus in self.read_buses:
            kinds = [frame.kind for frame in bus.frames]
            lines.append(f"{common.BUS_TYPE_LABELS[bus.bus]} on ARIA channel "
                         f"{self.model.channel[bus.bus]}: {bus.path.name}, SRS node {bus.ecu_node}, "
                         f"{len(bus.frames)} frames ({kinds.count('restbus')} restbus, "
                         f"{kinds.count('ecu_tx')} SRS, {kinds.count('diag')} diagnostic)")
        lines.append(f"{len(self.model.frames_by_node)} nodes, {len(self.model.blocks)} signals.")
        return "\n".join(lines)

    def rebuild_model(self) -> None:
        if not self.read_buses:
            return
        values = dict(self.values, CAN_VARIANT=self.variant or self.project)
        self.model = gen.Model(self.project, self.read_buses,
                               ValueInputs(values, self.inputs_path), values["CAN_VARIANT"])

    # -- writing -----------------------------------------------------------------------
    def command(self) -> str:
        return ("py -3.14 tools/build_canc_config_from_dbc.py --project " + self.project
                + "".join(f" --{gen.OPTION_OF_BUS[bus.bus]} {gen._relative(bus.path)}"
                          for bus in self.read_buses))

    def inputs_text(self) -> str:
        self.rebuild_model()
        return gen.render_inputs(self.model, self.command(), self.values, ORIGIN)

    def config_text(self) -> tuple[str, list[str]]:
        """The config as it would be written, and its open items."""
        self.rebuild_model()
        text = gen.render_config(self.model, self.command())
        return text, list(self.model.open_items)

    def save_inputs(self) -> Path:
        self.folder.mkdir(parents=True, exist_ok=True)
        self.inputs_path.write_text(self.inputs_text(), encoding="utf-8")
        return self.inputs_path

    def build(self) -> tuple[Path, list[str]]:
        """Save the inputs, write canc_config.py, and check it. Returns problems found."""
        if self.writes_hand_maintained():
            raise ValueError(f"projects/{self.project}/config is hand-maintained; choose another "
                             "folder on tab 1.")
        self.save_inputs()
        text, _open = self.config_text()
        self.config_path.write_text(text, encoding="utf-8")
        problems = gen.self_check(self.config_path)
        spec = gen.importlib.util.spec_from_file_location("gui_built_canc", self.config_path)
        module = gen.importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        problems += common.check_config(module, gen.edr_names.COMMON_ELEMENT_NAMES)
        return self.config_path, problems


# --------------------------------------------------------------------------------------
# The window
# --------------------------------------------------------------------------------------


def run_window(session: Session, start: bool = True) -> Any:
    """Open the window. With start=False it is built but not run, and its parts returned
    (for an offline test that fills it in and builds without a person at the screen)."""
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    if sys.platform == "win32":
        # Draw at the screen's real resolution: without this, Windows display scaling
        # stretches the window and blurs the text.
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError):
            pass
    import tkinter.font as tkfont

    root = tk.Tk()
    root.title("CAN-C configuration builder")
    # Sizes follow the display: widths are given at 96 dpi and scaled, the window takes
    # most of the screen, and table rows are as tall as the font needs.
    scale = max(1.0, float(root.tk.call("tk", "scaling")) / (96 / 72))
    width = min(int(root.winfo_screenwidth() * 0.85), int(1320 * scale))
    height = min(int(root.winfo_screenheight() * 0.85), int(820 * scale))
    root.geometry(f"{width}x{height}")
    root.minsize(int(900 * scale), int(560 * scale))
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    style.configure("Hint.TLabel", foreground="#4a4a4a")
    style.configure("Title.TLabel", font=("Segoe UI", 12, "bold"))
    style.configure("Treeview", rowheight=tkfont.nametofont("TkDefaultFont").metrics("linespace") + 8)
    style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    status = tk.StringVar(value="Start on tab 1, then tab 2: tick the buses and read the DBCs.")

    def say(text: str) -> None:
        status.set(text)

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True, padx=8, pady=(8, 0))
    ttk.Label(root, textvariable=status, anchor="w", relief="sunken", padding=(8, 3)).pack(
        fill="x", side="bottom")

    def tab(title: str, heading: str, hint: str) -> ttk.Frame:
        frame = ttk.Frame(notebook, padding=12)
        notebook.add(frame, text=title)
        ttk.Label(frame, text=heading, style="Title.TLabel").pack(anchor="w")
        label = ttk.Label(frame, text=hint, style="Hint.TLabel", justify="left")
        label.pack(anchor="w", fill="x", pady=(2, 10))
        # Wrap the hint to the window's width, whatever size the window is.
        frame.bind("<Configure>", lambda event, label=label: label.configure(
            wraplength=max(300, event.width - 30)), add="+")
        return frame

    class Table:
        """A Treeview whose cells can be edited by double-clicking them."""

        def __init__(self, parent: Any, columns: list[tuple[str, int]], editable: dict[str, Any],
                     on_edit: Callable[[str, str, str], None], height: int = 14,
                     expand: bool = True):
            box = ttk.Frame(parent)
            box.pack(fill="both" if expand else "x", expand=expand)
            self.columns = [name for name, _ in columns]
            self.tree = ttk.Treeview(box, columns=self.columns, show="headings", height=height)
            for name, width in columns:
                self.tree.heading(name, text=name + (" ✎" if name in editable else ""),
                                  anchor="w")
                self.tree.column(name, width=int(width * scale), minwidth=int(60 * scale),
                                 anchor="w", stretch=True)
            scroll = ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
            self.tree.configure(yscrollcommand=scroll.set)
            self.tree.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            self.tree.tag_configure("odd", background="#f4f6f9")
            self.tree.tag_configure("missing", foreground="#b00020")
            self.editable = editable          # column -> None (free text) or callable(row) -> choices
            self.on_edit = on_edit
            self.tree.bind("<Double-1>", self._begin)

        def fill(self, rows: list[tuple[str, list[Any]]]) -> None:
            self.tree.delete(*self.tree.get_children())
            for index, (key, cells) in enumerate(rows):
                shown = ["" if cell is None else str(cell) for cell in cells]
                tags = ["odd"] if index % 2 else []
                if any(cell is None for cell, column in zip(cells, self.columns)
                       if column in self.editable):
                    tags.append("missing")
                self.tree.insert("", "end", iid=key, values=shown, tags=tags)

        def _begin(self, event: Any) -> None:
            row = self.tree.identify_row(event.y)
            column_id = self.tree.identify_column(event.x)
            if not row or not column_id:
                return
            column = self.columns[int(column_id[1:]) - 1]
            if column not in self.editable:
                return
            x, y, width, height = self.tree.bbox(row, column_id)
            current = self.tree.set(row, column)
            choices = self.editable[column]
            if callable(choices):
                editor: Any = ttk.Combobox(self.tree, values=choices(row))
            else:
                editor = ttk.Entry(self.tree)
            editor.insert(0, current)
            editor.place(x=x, y=y, width=width, height=height)
            editor.focus_set()

            def commit(_event: Any = None) -> None:
                text = editor.get().strip()
                editor.destroy()
                self.tree.set(row, column, text)
                self.on_edit(row, column, text)

            editor.bind("<Return>", commit)
            editor.bind("<FocusOut>", commit)
            editor.bind("<Escape>", lambda _e: editor.destroy())

    def none_if_blank(text: str) -> Any:
        return None if text in ("", "None") else text

    def as_number(text: str) -> Any:
        text = text.strip()
        if text in ("", "None"):
            return None
        try:
            return int(text, 0)
        except ValueError:
            return float(text)

    def check_dtc(text: str) -> None:
        if text and not gen.DTC_FORMAT.match(text):
            say(f"'{text}' is not a DTC in the form 0xD1 0x54 0x00 - kept, and flagged at build.")

    # -- 1 Project ---------------------------------------------------------------------
    t1 = tab("1  Project", "Project",
             "The project's folder name under projects/, the CAN variant key (the key of "
             "CAN_SIGNAL_Rx_MAP, which must equal project_config.ACTIVE_CAN_VARIANT), and where "
             "to write canc_dbc_inputs.py and canc_config.py. U171, Z121 and M310_M314_M110 are "
             "hand-maintained: for them choose another folder.")
    form1 = ttk.Frame(t1)
    form1.pack(anchor="w")
    project_var = tk.StringVar(value=session.project)
    variant_var = tk.StringVar(value=session.variant)
    folder_var = tk.StringVar(value=str(session.output_dir or ""))
    paths_var = tk.StringVar()

    def refresh_paths(*_args: Any) -> None:
        session.project = project_var.get().strip()
        session.variant = variant_var.get().strip()
        session.output_dir = Path(folder_var.get()) if folder_var.get().strip() else None
        if session.project:
            note = ("   <- hand-maintained: choose another folder"
                    if session.writes_hand_maintained() else "")
            paths_var.set(f"Inputs:  {session.inputs_path}\nConfig:  {session.config_path}{note}")
        else:
            paths_var.set("")

    for row, (label, var) in enumerate((("Project name", project_var),
                                        ("CAN variant key (default: project name)", variant_var),
                                        ("Folder (default: projects/<project>/config)", folder_var))):
        ttk.Label(form1, text=label).grid(row=row, column=0, sticky="w", pady=4, padx=(0, 10))
        ttk.Entry(form1, textvariable=var, width=60).grid(row=row, column=1, sticky="w")
        var.trace_add("write", refresh_paths)

    def browse_folder() -> None:
        chosen = filedialog.askdirectory(initialdir=str(session.folder))
        if chosen:
            folder_var.set(chosen)

    ttk.Button(form1, text="Browse...", command=browse_folder).grid(row=2, column=2, padx=6)
    ttk.Label(t1, textvariable=paths_var, style="Hint.TLabel", justify="left").pack(
        anchor="w", pady=10)

    def open_existing() -> None:
        refresh_paths()
        if session.load_inputs():
            variant_var.set(session.variant)
            sync_bus_rows()
            say(f"Loaded {session.inputs_path}. Read the DBCs on tab 2 to continue.")
        else:
            say(f"No inputs file at {session.inputs_path} yet - start from the DBCs on tab 2.")

    ttk.Button(t1, text="Open the existing inputs file", command=open_existing).pack(anchor="w")

    # -- 2 Buses -----------------------------------------------------------------------
    t2 = tab("2  Buses", "Buses",
             "Tick every bus the project has and choose its DBC. The ARIA channel is the channel "
             "name on the bench (the shared library knows CANFD, HSCAN, ARIA and Level 61); a "
             "normal-CAN bus has no channel of its own name, so say which one it is wired to. "
             "'ch' is the legacy channel number some scripts log. The SRS node is read from the "
             "DBC; name it only if the DBC lists several nodes.")
    grid = ttk.Frame(t2)
    grid.pack(anchor="w", fill="x")
    for column, title in enumerate(("Use", "Bus", "DBC file", "", "ARIA channel", "ch", "SRS node")):
        ttk.Label(grid, text=title, font=("Segoe UI", 9, "bold")).grid(row=0, column=column,
                                                                       sticky="w", padx=4)
    bus_vars: dict[str, dict[str, Any]] = {}
    for row, bus_type in enumerate(common.BUS_TYPES, start=1):
        entry = session.buses[bus_type]
        v = {"use": tk.BooleanVar(value=entry["use"]), "dbc": tk.StringVar(value=entry["dbc"]),
             "channel": tk.StringVar(value=entry["channel"]),
             "ch": tk.StringVar(value="" if entry["ch"] is None else str(entry["ch"])),
             "srs_node": tk.StringVar(value=entry["srs_node"])}
        bus_vars[bus_type] = v
        ttk.Checkbutton(grid, variable=v["use"]).grid(row=row, column=0, padx=4)
        ttk.Label(grid, text=common.BUS_TYPE_LABELS[bus_type], width=22).grid(row=row, column=1, sticky="w")
        ttk.Entry(grid, textvariable=v["dbc"], width=64).grid(row=row, column=2, sticky="w", pady=3)

        def browse(bus_type: str = bus_type) -> None:
            chosen = filedialog.askopenfilename(initialdir=str(REPOSITORY_ROOT / "project_dbc"),
                                                filetypes=[("CAN database", "*.dbc")])
            if chosen:
                bus_vars[bus_type]["dbc"].set(chosen)
                bus_vars[bus_type]["use"].set(True)

        ttk.Button(grid, text="Browse...", command=browse).grid(row=row, column=3, padx=4)
        ttk.Combobox(grid, textvariable=v["channel"], values=common.ARIA_CHANNELS, width=10).grid(
            row=row, column=4, padx=4)
        ttk.Entry(grid, textvariable=v["ch"], width=5).grid(row=row, column=5, padx=4)
        ttk.Entry(grid, textvariable=v["srs_node"], width=14).grid(row=row, column=6, padx=4)

    def sync_bus_rows() -> None:
        for bus_type, v in bus_vars.items():
            entry = session.buses[bus_type]
            v["use"].set(entry["use"])
            v["dbc"].set(entry["dbc"])
            v["channel"].set(entry["channel"])
            v["ch"].set("" if entry["ch"] in (None, "") else str(entry["ch"]))
            v["srs_node"].set(entry["srs_node"])

    summary = tk.Text(t2, height=8, wrap="word", relief="flat", background="#f4f6f9",
                      font=("Segoe UI", 10), padx=8, pady=6)
    summary.pack(fill="x", pady=10)

    def read_dbcs() -> None:
        refresh_paths()
        for bus_type, v in bus_vars.items():
            session.buses[bus_type].update(
                use=v["use"].get(), dbc=v["dbc"].get().strip(), channel=v["channel"].get().strip(),
                ch=as_number(v["ch"].get()), srs_node=v["srs_node"].get().strip())
        try:
            text = session.read_dbcs()
        except (ValueError, SystemExit) as error:
            messagebox.showerror("Cannot read the DBCs", str(error))
            return
        sync_bus_rows()
        summary.delete("1.0", "end")
        summary.insert("end", text)
        refresh_all()
        say("DBCs read. Work through tabs 3 to 8 - red rows still need an answer - then build on tab 9.")

    ttk.Button(t2, text="Read the DBCs", command=read_dbcs).pack(anchor="w")

    # -- 3 Nodes -----------------------------------------------------------------------
    t3 = tab("3  Nodes", "Nodes, key frames and their DTCs",
             "The key frame of a node is the one whose absence sets Node Absent - take it from "
             "the Node Absent DTC set conditions in the diag spec (it is not always the lowest CAN "
             "ID). DTCs come from the diag spec's DTC List, written 0xD1 0x54 0x00. A node that "
             "sends only its key frame needs no message-timeout DTC.")

    def node_frames(node: str) -> list[str]:
        return list((session.model.frames_by_node if session.model else {}).get(node, []))

    def edit_node(node: str, column: str, text: str) -> None:
        if column == "Key frame":
            session.values.setdefault("KEY_FRAMES", {})[node] = none_if_blank(text)
            session.rebuild_model()
            refresh_all()
        elif column == "Node absent DTC":
            check_dtc(text)
            session.values.setdefault("NODE_ABSENT_DTC", {})[node] = none_if_blank(text)
        elif column == "Message timeout DTC":
            check_dtc(text)
            session.values.setdefault("MESSAGE_TIMEOUT_DTC", {})[node] = none_if_blank(text)

    nodes_table = Table(t3, [("Node", 110), ("Frames", 420), ("Key frame", 160),
                             ("Node absent DTC", 150), ("Message timeout DTC", 160)],
                        {"Key frame": node_frames, "Node absent DTC": None,
                         "Message timeout DTC": None}, edit_node)

    # -- 4 Frames ----------------------------------------------------------------------
    t4 = tab("4  Frames", "Restbus frames and the node that sends each",
             "DERIVED from the frame names (VCU11_FD_10 -> VCU). Correct any the name gets wrong; "
             "leave Node empty for a frame that is never stopped for a node-absent or timeout case.")

    def node_choices(_row: str) -> list[str]:
        return [""] + sorted((session.model.frames_by_node if session.model else {}).keys())

    def edit_frame(frame: str, column: str, text: str) -> None:
        session.values.setdefault("NODE_BY_FRAME", {})[frame] = none_if_blank(text)
        session.rebuild_model()
        refresh_all()

    frames_table = Table(t4, [("Frame", 170), ("Bus", 80), ("ID", 70), ("Cycle ms", 80),
                              ("CRC / counter", 330), ("Node", 120)],
                         {"Node": node_choices}, edit_frame)

    # -- 5 Fault DTCs ------------------------------------------------------------------
    t5 = tab("5  Fault DTCs", "Message-content and signal-content DTCs",
             "Message content: frames with a CRC or alive counter; key by frame (both signals share "
             "the DTC). Signal content: signals the DBC gives an invalid code. Leave a DTC empty "
             "where the DTC list has none - the config keeps it None and lists it as open.")
    pane5 = ttk.Panedwindow(t5, orient="horizontal")
    pane5.pack(fill="both", expand=True)
    left5, right5 = ttk.Frame(pane5), ttk.Frame(pane5)
    pane5.add(left5, weight=1)
    pane5.add(right5, weight=1)
    ttk.Label(left5, text="Message content failure", font=("Segoe UI", 9, "bold")).pack(anchor="w")
    ttk.Label(right5, text="Signal content failure", font=("Segoe UI", 9, "bold")).pack(anchor="w")

    def edit_content(key: str, column: str, text: str) -> None:
        check_dtc(text)
        session.values.setdefault("MESSAGE_CONTENT_FAILURE_DTC", {})[key] = none_if_blank(text)

    def edit_scf(key: str, column: str, text: str) -> None:
        check_dtc(text)
        session.values.setdefault("SIGNAL_CONTENT_FAILURE_DTC", {})[key] = none_if_blank(text)

    content_table = Table(left5, [("Frame or signal", 230), ("DTC", 150)], {"DTC": None}, edit_content)
    scf_table = Table(right5, [("Signal", 260), ("DTC", 150)], {"DTC": None}, edit_scf)

    # -- 6 EDR -------------------------------------------------------------------------
    t6 = tab("6  EDR", "The EDR parameter of each signal",
             "EDR parameter names are the same in every project (U171's: VehSpdLgt, ACC_PED, "
             "GEAR_ACTUAL, ...) although the frame and signal that carry them differ - the gear "
             "comes from the TCU in some projects and from the VCU in others. Only signals that "
             "feed the EDR record need one. The list offers the element names of the project's "
             "edr_config, or U171's while the project has none; any other name can be typed.")

    def edr_names(_row: str) -> list[str]:
        path = REPOSITORY_ROOT / "projects" / session.project / "config" / "edr_config.py"
        if not path.is_file():
            path = (REPOSITORY_ROOT / "projects" / common.REFERENCE_PROJECT / "config"
                    / "edr_config.py")
        if not path.is_file():
            return []
        try:
            spec = gen.importlib.util.spec_from_file_location("gui_edr_names", path)
            module = gen.importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return [""] + [p["name"] for p in module.EDR_PARAMETERS]
        except Exception:                       # a broken edr_config must not stop the window
            return []

    def edit_edr(key: str, column: str, text: str) -> None:
        values = session.values.setdefault("EDR_PARAMETERS", {})
        if text:
            values[key] = text
        else:
            values.pop(key, None)

    edr_table = Table(t6, [("Signal", 260), ("Frame", 170), ("Bus", 80), ("EDR parameter", 330)],
                      {"EDR parameter": edr_names}, edit_edr)

    # -- 7 Network ---------------------------------------------------------------------
    t7 = tab("7  Network", "Network management and wakeup",
             "Network-management counts and delays from the diag spec (sheet NetworkMgmtIdentifiers, "
             "DID 0x0103 / 0x0104): a CAN fault matures on a count of message periods, not a fixed "
             "time. The wakeup settings are DERIVED from the DBC value tables except the bus-sleep "
             "wait (NM timeout + wait-bus-sleep time, plus margin).")
    pane7 = ttk.Panedwindow(t7, orient="horizontal")
    pane7.pack(fill="both", expand=True)
    left7, right7 = ttk.Frame(pane7), ttk.Frame(pane7)
    pane7.add(left7, weight=1)
    pane7.add(right7, weight=1)

    def edit_nm(key: str, column: str, text: str) -> None:
        try:
            session.values.setdefault("NETWORK_MANAGEMENT", {})[key] = as_number(text)
        except ValueError:
            say(f"{key}: '{text}' is not a number.")

    def edit_wakeup(key: str, column: str, text: str) -> None:
        try:
            value = as_number(text)
        except ValueError:
            value = text
        session.values.setdefault("CAN_WAKEUP", {})[key] = value

    nm_table = Table(left7, [("Setting", 330), ("Value", 110)], {"Value": None}, edit_nm, height=24)
    wake_table = Table(right7, [("Setting", 260), ("Value", 170)], {"Value": None}, edit_wakeup,
                       height=24)

    # -- 8 Crash -----------------------------------------------------------------------
    t8 = tab("8  Crash", "Crash outputs",
             "The SRS frames read at crash time (DERIVED: the fastest cyclic SRS frame per bus) and "
             "the values expected per crash type, as hex strings (0x1). The expected values are "
             "proposed from the DBC labels - confirm them against the crash-output requirement.")
    outputs_var = tk.StringVar()
    row8 = ttk.Frame(t8)
    row8.pack(anchor="w", fill="x", pady=(0, 8))
    ttk.Label(row8, text="Frames read at crash time (comma separated):").pack(side="left")
    outputs_entry = ttk.Entry(row8, textvariable=outputs_var, width=60)
    outputs_entry.pack(side="left", padx=6)

    def set_outputs(*_args: Any) -> None:
        frames = [name.strip() for name in outputs_var.get().split(",") if name.strip()]
        session.values["CRASH_OUTPUT_FRAMES"] = frames

    ttk.Button(row8, text="Apply", command=lambda: (set_outputs(), refresh_all())).pack(side="left")

    def edit_crash(crash: str, column: str, text: str) -> None:
        values = session.values.setdefault("CRASH_EXPECTED_VALUES", {}).setdefault(crash, {})
        if text:
            values[column] = text
        else:
            values.pop(column, None)

    crash_table = Table(t8, [("Crash type", 120)] + [(key, 150) for key in CRASH_KEYS],
                        {key: None for key in CRASH_KEYS}, edit_crash, height=8)

    # -- 9 Build -----------------------------------------------------------------------
    t9 = tab("9  Build", "Check, preview and build",
             "Open items are what the config will still not know; it builds anyway and lists them "
             "in CANC_DBC_OPEN_ITEMS. Save the inputs at any time; Build writes both files and "
             "checks the result (it imports, and has the common CAN-C structure).")
    buttons9 = ttk.Frame(t9)
    buttons9.pack(anchor="w", pady=(0, 8))
    output9 = tk.Text(t9, wrap="word", font=("Consolas", 9))
    scroll9 = ttk.Scrollbar(t9, orient="vertical", command=output9.yview)
    across9 = ttk.Scrollbar(t9, orient="horizontal", command=output9.xview)
    output9.configure(yscrollcommand=scroll9.set, xscrollcommand=across9.set)
    scroll9.pack(side="right", fill="y")
    across9.pack(side="bottom", fill="x")
    output9.pack(fill="both", expand=True)

    def show(text: str, code: bool = False) -> None:
        # Messages wrap; the config preview keeps its lines as they will be in the file.
        output9.configure(wrap="none" if code else "word")
        output9.delete("1.0", "end")
        output9.insert("end", text)

    def need_model() -> bool:
        if session.model is None:
            messagebox.showinfo("Read the DBCs first", "Read the DBCs on tab 2 first.")
            return False
        return True

    def open_items() -> None:
        if need_model():
            _text, items = session.config_text()
            show("Still open (the config keeps these None):\n\n"
                 + ("\n".join(f"  - {item}" for item in items) or "  nothing"))

    def preview() -> None:
        if need_model():
            show(session.config_text()[0], code=True)

    def save_inputs() -> None:
        if need_model():
            if session.inputs_path.exists() and not messagebox.askyesno(
                    "Replace?", f"Replace {session.inputs_path}?"):
                return
            say(f"Saved {session.save_inputs()}")

    def build() -> None:
        if not need_model():
            return
        if session.writes_hand_maintained():
            messagebox.showerror("Hand-maintained project",
                                 f"projects/{session.project}/config is hand-maintained. "
                                 "Choose another folder on tab 1.")
            return
        existing = [p for p in (session.inputs_path, session.config_path) if p.exists()]
        if existing and not messagebox.askyesno(
                "Replace?", "Replace\n" + "\n".join(str(p) for p in existing) + " ?"):
            return
        try:
            path, problems = session.build()
        except (ValueError, SystemExit) as error:
            messagebox.showerror("Not built", str(error))
            return
        _text, items = session.config_text()
        show(f"Wrote {session.inputs_path}\nWrote {path}\n\n"
             + ("Checks: passed\n" if not problems else
                "CHECKS FAILED:\n" + "\n".join(f"  - {p}" for p in problems) + "\n")
             + f"\n{len(items)} open item(s):\n" + "\n".join(f"  - {item}" for item in items))
        say(f"Built {path}" + (" - with check failures, see tab 9." if problems else "."))

    for text, command in (("Show open items", open_items), ("Preview canc_config.py", preview),
                          ("Save inputs", save_inputs), ("Build canc_config.py", build)):
        ttk.Button(buttons9, text=text, command=command).pack(side="left", padx=(0, 8))

    # -- filling the tables from the session ---------------------------------------------
    def refresh_all() -> None:
        model = session.model
        if model is None:
            return
        v = session.values
        nodes_table.fill([
            (node, [node, ", ".join(frames), v.get("KEY_FRAMES", {}).get(node),
                    v.get("NODE_ABSENT_DTC", {}).get(node),
                    v.get("MESSAGE_TIMEOUT_DTC", {}).get(node) if node in model.timeout_nodes else "n/a"])
            for node, frames in model.frames_by_node.items()])
        frames_table.fill([
            (frame.name, [frame.name, model.channel[frame.bus], f"0x{frame.frame_id:X}",
                          frame.cycle_ms or "event",
                          ", ".join(model.integrity[frame.name]["crc"] + model.integrity[frame.name]["counter"]),
                          v.get("NODE_BY_FRAME", {}).get(frame.name) or ""])
            for frame in model.ordered if frame.kind == "restbus" and not frame.is_nm])
        content_table.fill([(key, [key, value])
                            for key, value in (v.get("MESSAGE_CONTENT_FAILURE_DTC") or {}).items()])
        scf_table.fill([(key, [key, value])
                        for key, value in (v.get("SIGNAL_CONTENT_FAILURE_DTC") or {}).items()])
        edr = v.get("EDR_PARAMETERS") or {}
        edr_table.fill([
            (f"{b.frame.name}.{b.signal.name}" if not b.preferred else b.signal.name,
             [b.signal.name, b.frame.name, model.channel[b.frame.bus],
              edr.get(f"{b.frame.name}.{b.signal.name}") or (edr.get(b.signal.name) if b.preferred else "")
              or ""])
            for b in model.blocks if b.value.get("direction") == "rx"])
        nm = v.get("NETWORK_MANAGEMENT") or {}
        nm_table.fill([(name, [name, nm.get(name)]) for name in gen.NETWORK_MANAGEMENT_NAMES])
        wake = v.get("CAN_WAKEUP") or {}
        wake_table.fill([(name, [name, wake.get(name)]) for name in gen.WAKEUP_NAMES])
        outputs_var.set(", ".join(v.get("CRASH_OUTPUT_FRAMES") or []))
        expected = v.get("CRASH_EXPECTED_VALUES") or {}
        crash_table.fill([(crash, [crash] + [expected.get(crash, {}).get(key, "") for key in CRASH_KEYS])
                          for crash in gen.CRASH_TYPES])

    refresh_paths()
    if session.project and session.load_inputs():
        variant_var.set(session.variant)
        sync_bus_rows()
        say(f"Loaded {session.inputs_path}. Read the DBCs on tab 2 to continue.")
    parts = types.SimpleNamespace(
        root=root, notebook=notebook, status=status, project_var=project_var,
        variant_var=variant_var, folder_var=folder_var, bus_vars=bus_vars, read_dbcs=read_dbcs,
        open_items=open_items, preview=preview, save_inputs=save_inputs, build=build,
        output=output9, tables={"nodes": nodes_table, "frames": frames_table,
                                "content": content_table, "scf": scf_table, "edr": edr_table,
                                "nm": nm_table, "wakeup": wake_table, "crash": crash_table})
    if start:
        root.mainloop()
    return parts


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--project", default="")
    arguments = parser.parse_args()
    run_window(Session(arguments.project))
    return 0


if __name__ == "__main__":
    sys.exit(main())
