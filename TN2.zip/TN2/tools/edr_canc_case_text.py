"""Compose a test case's Pre-Action and Post-Action from configuration alone.

The ICE specification has authored rows to reuse, so a case there starts from the V4
workbook. The EV specification has no such source for the series it shares with ICE - the
v7 common workbook covers only some of them, on sampling intervals that disagree with the
M314 record - so those cases are composed here instead, from the element's own recording
layout and the sample vector its configuration drives.

The text states what the EV script does, crash by crash, so the specification and the
script cannot tell different stories:

  * An interval element drives one vector per crash; the crash recorded in EDR1 (0x0455)
    and the one recorded in EDR2 (0x045B) are driven alike.
  * A snapshot element takes one value per crash, held from T0 - 500 ms to T0 + 500 ms
    with the crash at T0; odd iterations are recorded in EDR1, even ones in EDR2, and a
    list of odd length repeats its first value so both records are checked.
  * A reserved or out-of-range case drives one code per crash across the whole interval.
  * Valid values keep being driven while a fault is active. A frame that is stopped
    carries nothing (FAULT_ACTIVE); a snapshot drives a different valid value, so a held
    value can be told from a consumed one.
  * A pre-crash fault covers the samples before T0 and heals inside the T0 window, so T0
    records the simulated value.

Everything comes from the project's own configuration: the recording times from the
record's sample range, the values from `canc_config`, the DTC from the signal's fault
logic. Nothing is carried over from the other variant.

Offline only: builds strings.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import edr_canc_review_model as model  # noqa: E402

CRLF = "\r\n"
RECORDS = ("EDR1 (0x0455)", "EDR2 (0x045B)")
SNAPSHOT_HOLD_MS = 500
FAULT_ACTIVE = "FAULT_ACTIVE"

# Frame-stopping faults: nothing is on the bus for the element while they are active.
STOPPED = {"node_absent", "message_timeout"}
LATCH = {"node_absent", "message_timeout", "message_content", "under_voltage", "over_voltage"}
DEFAULT = {"signal_never_received", "variant_code_error"}
CODES = {"dbc_reserved": "Reserved_Values", "dbc_out_of_range": "OutofRange_Values"}


def _times(plan: model.ParameterPlan) -> list[float]:
    """The recording time of each sample, in order."""
    if plan.recording_model != "interval" or not plan.sample_range:
        return [0.0]
    start = float(plan.sample_range["start"])
    step = float(plan.sample_range["step"]) or 1.0
    return [round(start + step * index, 4) for index in range(plan.samples)]


def _time_text(value: float) -> str:
    return f"{value:+.2f}" if value else "0.00"


def t0_index(plan: model.ParameterPlan) -> int:
    times = _times(plan)
    for index, value in enumerate(times):
        if abs(value) < 1e-9:
            return index
    return len(times) - 1


def _window_text(plan: model.ParameterPlan) -> str:
    """The simulation window for each sample: it ends at the moment the sample is taken."""
    times = _times(plan)
    step = round(times[1] - times[0], 4)
    spans = []
    for value in times:
        opening = round(value - step, 4)
        if abs(value) < 1e-9:
            spans.append(f"T0 - {int(step * 1000)} ms to T0")
        else:
            spans.append(f"{_time_text(opening)} s to {_time_text(value)} s")
    return "[" + ", ".join(spans) + "]"


def _array(definition: dict[str, Any], plan: model.ParameterPlan, suffix: str) -> list[int]:
    raw = definition.get(f"TestCase_{plan.signal}_{suffix}") or []
    if not isinstance(raw, list):
        raw = [raw]
    return [int(value) for value in raw]


def _hex(value: int, bits: int | None) -> str:
    digits = max(1, ((bits or 8) + 3) // 4)
    return f"0x{value & ((1 << (bits or 8)) - 1):0{digits}X}"


def _plain(value: float) -> str:
    """A physical value without exponent notation or trailing zeros."""
    return f"{value:.6f}".rstrip("0").rstrip(".") or "0"


def _physical(value: int, definition: dict[str, Any]) -> str:
    factor = definition.get("Factor", 1) or 1
    offset = definition.get("Offset", 0) or 0
    return _plain(value * factor + offset)


def _required(definition: dict[str, Any], plan: model.ParameterPlan,
              case: model.Case) -> list[int] | None:
    """The on-fail requirement's SNR / VC values where they differ from the DBC default."""
    if case.kind not in DEFAULT:
        return None
    tag = "SNR" if case.kind == "signal_never_received" else "VC"
    return _array(definition, plan, f"{tag}_Values") or None


def _shown(values: list[int], render) -> str:
    """One value, a contiguous range or a set, the way the record may hold it."""
    ordered = sorted(values)
    if len(ordered) == 1:
        return render(ordered[0])
    if ordered == list(range(ordered[0], ordered[-1] + 1)):
        return f"{render(ordered[0])}-{render(ordered[-1])}"
    return "/".join(render(value) for value in ordered)


def _crashes(plan: model.ParameterPlan, case: model.Case,
             definition: dict[str, Any]) -> list[list[int]]:
    """What each crash drives, sample by sample, before any fault is applied."""
    snapshot = plan.recording_model != "interval"
    count = len(_times(plan))
    if case.kind in CODES:
        codes = _array(definition, plan, CODES[case.kind])
        crashes = [[code] * count for code in codes]
    elif snapshot:
        crashes = [[value] for value in _array(definition, plan, "Values")[:]]
    else:
        values = (_array(definition, plan, "Values") or [0] * count)[:count]
        crashes = [values, values]
    if crashes and len(crashes) % len(RECORDS):
        crashes = crashes + crashes[:len(RECORDS) - len(crashes) % len(RECORDS)]
    return crashes


def _window(plan: model.ParameterPlan, case: model.Case, count: int) -> tuple[int, int]:
    """First and last-plus-one sample index the fault covers; (0, 0) for no fault.

    A pre-crash fault covers the samples before T0 and is healed inside the T0 window, so
    T0 records the simulated value; a post-crash fault starts after T0.
    """
    if not model.KINDS[case.kind][1]:
        return 0, 0
    index = t0_index(plan)
    if case.scope == "pre":
        return 0, index
    if case.scope == "post":
        return index + 1, count
    return 0, count


def compose(plan: model.ParameterPlan, case: model.Case, definition: dict[str, Any],
            fault_logic: dict[str, Any], variant: str, spec_name: str,
            behaviour: str, target_text: str, dtc_text: str | None) -> tuple[str, str]:
    """The Pre-Action and Post-Action text for one case."""
    snapshot = plan.recording_model != "interval"
    times = _times(plan)
    count = len(times)
    bits = definition.get("bit_length")
    unit = definition.get("UNIT") or "value"
    values = _array(definition, plan, "Values")
    invalid = (_array(definition, plan, "Invalid_Values") or [None])[0]
    required = _required(definition, plan, case)
    default_raw = int(definition.get("Default_Value") or 0)
    first, last = _window(plan, case, count)
    t0 = t0_index(plan)
    crashes = _crashes(plan, case, definition)

    def alternate(value: int) -> int:
        # The script drives the first other valid value of the vector, or a DBC limit.
        others = [other for other in values if other != value] or [
            limit for limit in (definition.get("MIN"), definition.get("MAX"))
            if limit is not None and limit != value]
        return int(others[0]) if others else value

    def driven(crash: list[int], index: int) -> int | None:
        inside = first <= index < last
        if inside and case.kind == "signal_content":
            return invalid
        if inside and case.kind in STOPPED:
            return None
        if inside and snapshot:
            return alternate(crash[index])
        return crash[index]

    def recorded(crash: list[int], index: int):
        inside = first <= index < last
        if not inside:
            return crash[index]
        if case.kind in LATCH:
            return crash[t0] if case.scope == "post" else crash[0]
        if case.kind in DEFAULT:
            return required if required else default_raw
        if case.kind == "signal_content":
            return invalid
        return crash[index]

    def cell(value, render) -> str:
        if value is None:
            return FAULT_ACTIVE
        if isinstance(value, list):
            return _shown(value, render)
        return render(value)

    renders = [("raw CAN hex", lambda v: _hex(v, bits)), ("raw CAN decimal", str),
               (f"physical {unit}", lambda v: _physical(v, definition))]

    def arrays(prefix: str, getter, per_crash: bool) -> list[str]:
        lines = []
        for label, render in renders:
            if per_crash:
                cells = [cell(getter(crash, 0), render) for crash in crashes]
            else:
                cells = [cell(getter(crashes[0], index), render) for index in range(count)]
            suffix = " (one per iteration)" if per_crash else ""
            lines.append(f"{prefix} {label}{suffix}: [" + ", ".join(cells) + "]")
        return lines

    per_iteration = snapshot or case.kind in CODES
    scope_phrase = (f" {_scope_phrase(plan, case.scope)}"
                    if case.scope and model.KINDS[case.kind][1] and not snapshot else "")
    pre_lines = [
        "1. Verify the approved EDR feature configuration and confirm the selected variant "
        "is fault free.",
        "",
        f"2. Simulate {plan.parameter} CAN signal with {model.KINDS[case.kind][0]}"
        f"{scope_phrase} for {variant} ({spec_name}):",
        f"Signal: {plan.frame} / {definition.get('signal')}",
    ]
    if snapshot:
        pre_lines += [
            "Recorded at: T0 (single sample)",
            f"Simulation window: each value is held from T0 - {SNAPSHOT_HOLD_MS} ms to "
            f"T0 + {SNAPSHOT_HOLD_MS} ms, and the crash is triggered at T0.",
        ]
    else:
        pre_lines += [
            f"Recording time [s] ({count} values): ["
            + ", ".join(_time_text(value) for value in times) + "]",
            f"Simulation window: {_window_text(plan)}",
        ]
    if per_iteration:
        pre_lines.append(
            f"Iterate the case {len(crashes)} time(s), one crash per iteration: odd "
            f"iterations are recorded in {RECORDS[0]} and even ones in {RECORDS[1]}, and the "
            f"bench returns to fault free after each pair."
            + (" Each iteration drives its code at every sample of the interval."
               if case.kind in CODES and not snapshot else ""))
    else:
        pre_lines.append(
            f"The same values are driven for the crash recorded in {RECORDS[0]} and again "
            f"for the crash recorded in {RECORDS[1]}.")
    if case.kind in LATCH | DEFAULT and (snapshot or first == 0) and last > first:
        if case.kind in DEFAULT:
            pre_lines.append(
                "The fault is created before the recording starts, so the element never "
                "receives a value; valid values keep being simulated on the bus.")
        else:
            prime_ms = (SNAPSHOT_HOLD_MS if snapshot or count < 2
                        else int(round((times[1] - times[0]) * 1000)))
            pre_lines.append(
                f"Before the fault is created the first value is driven for {prime_ms} ms "
                f"(one sample interval), so the value the element retains is known.")
    if snapshot and case.kind in (LATCH | DEFAULT) - STOPPED and last > first:
        pre_lines.append(
            "While the fault is active a different valid value is driven, so a retained "
            "value can be told from one the ECU kept taking off the bus.")
    pre_lines += arrays("Input", driven, per_iteration)
    pre = CRLF.join(pre_lines)
    if target_text:
        pre += CRLF + CRLF + target_text

    post_lines = [f"Expected EDR recording for {plan.parameter} in DID 0x0455 (EDR1) and "
                  f"DID 0x045B (EDR2):"]
    if per_iteration:
        post_lines.append("Recorded at: T0" if snapshot else
                          f"Recording time [s] ({count} values): ["
                          + ", ".join(_time_text(value) for value in times) + "]")
        for number, crash in enumerate(crashes, start=1):
            value = recorded(crash, 0)
            record = RECORDS[(number - 1) % len(RECORDS)]
            text = (cell(value, lambda v: _hex(v, bits)) + " ("
                    + cell(value, str) + " decimal, "
                    + cell(value, lambda v: _physical(v, definition)) + f" {unit})")
            where = "" if snapshot else " at every sample"
            post_lines.append(f"Iteration {number}: {record} records raw {text}{where}.")
    else:
        post_lines.append(f"Recording time [s] ({count} values): ["
                          + ", ".join(_time_text(value) for value in times) + "]")
    post_lines += arrays("Expected recorded", recorded, per_iteration)
    post_lines += ["", _closing(case, behaviour, plan, definition, required, invalid,
                                default_raw, bits)]
    post = CRLF.join(post_lines)
    if dtc_text:
        post += CRLF + CRLF + f"DTC expected: {dtc_text}."
    return pre, post


def _scope_phrase(plan: model.ParameterPlan, scope: str | None) -> str:
    if plan.recording_model != "interval" or not plan.sample_range or not scope:
        return ""
    start = float(plan.sample_range["start"])
    end = float(plan.sample_range["end"])
    if scope == "pre":
        return f"only in pre crash ({start:.2f}s to T0)"
    if scope == "post":
        return f"only in post crash (T0 to {end:+.2f}s)"
    return f"in full interval ({start:.2f}s to {end:+.2f}s)"


def _closing(case: model.Case, behaviour: str, plan: model.ParameterPlan,
             definition: dict[str, Any], required: list[int] | None, invalid: int | None,
             default_raw: int, bits: int | None) -> str:
    snapshot = plan.recording_model != "interval"
    if case.kind in LATCH:
        fault = ("the voltage fault" if case.kind in ("under_voltage", "over_voltage")
                 else "the fault")
        if snapshot:
            return (f"The value received before {fault} is created is retained; the "
                    f"different value driven while {fault} is active is not recorded.")
        if case.scope == "pre":
            return (f"The last value received before {fault} is retained until T0; {fault} "
                    f"is healed inside the T0 sample window, so T0 and every later sample "
                    f"record the simulated values again.")
        if case.scope == "post":
            return "The value received at T0 is retained for every sample after the crash."
        return (f"The last value received before {fault} is retained for the whole "
                f"recording interval.")
    if case.kind in DEFAULT:
        how = ("The node bit is cleared in the variant code"
               if case.kind == "signal_never_received" else "The variant code is in error")
        if required:
            shown = _shown(required, lambda v: _hex(v, bits))
            return (f"{how}, so the ECU ignores the valid values simulated on the bus; per "
                    f"the on-fail requirement the record holds {shown}"
                    + (" (any one of them)" if len(required) > 1 else "")
                    + f" for {plan.parameter} while the fault is active.")
        return (f"{how}, so the ECU ignores the valid values simulated on the bus and every "
                f"sample records the on-fail default value {_hex(default_raw, bits)} for "
                f"{plan.parameter}.")
    if case.kind == "signal_content":
        where = "" if not case.scope or case.scope == "full" else " inside the fault window"
        return (f"The signal keeps transmitting, so the DBC invalid code "
                f"{_hex(invalid or 0, bits)} is recorded as it stands{where} rather than put "
                f"through the physical conversion.")
    if case.kind == "dbc_reserved":
        return ("The signal keeps transmitting, so each reserved code is consumed and "
                "recorded as driven.")
    if case.kind == "dbc_out_of_range":
        return ("The signal keeps transmitting, so the out-of-range raw is consumed and "
                "converted like any other measurement; whether the result still fits the "
                "recording field is what this case shows.")
    return "Every sample records the value simulated for it."
