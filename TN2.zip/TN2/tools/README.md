# Framework Tools

`tools/` holds offline utilities that inspect, transform, generate, validate,
or publish framework artifacts. A tool must not silently execute a bench test,
actuate hardware, flash an ECU, or create an irreversible ECU state.

## Structure

| Content | Location | Required context |
| --- | --- | --- |
| Single offline utility | `tools/<action>_<subject>.py` | Module docstring with purpose, inputs, outputs, and side effects. |
| Multi-file utility | `tools/<tool-name>/` | `README.md`, explicit dependencies, and a command entry point. |
| Tool-specific generated material | `tools/<tool-name>/runs/YYYY-MM-DD_<purpose>/` | `README.md` with inputs, command, outcome, and retention decision. |
| Reusable analysis dependencies | `tools/analysis-requirements.txt` | Add only when used by more than one tool or mandated by a skill. |

The `can_log_visual_analyzer/` multi-file utility provides a localhost-only,
offline engineering workspace for ARIA/CAN recordings and JSON-exported DBC
metadata. See its `README.md` for invocation, supported data, and explicit
analysis-only safety limits.

Test-related outputs belong under `tests/`, not `tools/`. Customer originals
remain under `docs/`, while processed documents follow the repository document
policy. Runtime bench output remains in the configured `test_logs/` and
`test_results/` locations.

## Names And Metadata

Use action-first names such as `extract_dbc_signals.py` and
`build_aria_config_knowledge.py`. Avoid `new`, `final`, `copy`, and numbered
duplicates. Every new generated-output folder needs a `README.md` describing
what it contains and why it is retained.

Office lock files (`~$*`), `__pycache__/`, and accidental `* (2).*` copies are
not retained. Review the catalogue before removing a copy because names alone
do not prove identical content.

## Logbook And Audit

Record uses, changes, validation, and archival decisions in
`tools/logbook/YYYY-MM.md`; see `tools/logbook/README.md` for the entry format.

```powershell
py -3.13 tools/audit_test_tool_artifacts.py
```

The audit is read-only with respect to the folders it scans. It produces
`ARTIFACT_CATALOG.md` files for both `tests/` and `tools/` and reports hygiene
findings for review.

## Z121 EDR CAN-C Runs By Element

[run_z121_edr_canc_by_element.py](run_z121_edr_canc_by_element.py) takes its case list
and filters (`--only`, `--fault`, `--nominal`) from the Z121 runner
`projects/Z121/modules/EDR/scripts/run_all_z121_edr_canc_scripts.py`. It runs one case
at a time and moves each case's HTML report and CAN log into
`test_results/Z121/<element>/` and `test_logs/Z121/<element>/`.

```powershell
py -3.14 -B tools/run_z121_edr_canc_by_element.py --list
```

`--list` is offline. Without it the selected cases run on the bench.

## Archived Tools

[archive/](archive/README.md) holds tools that newer ones replaced. Do not run them. The
M314 CAN-C generators, signal suite and Fault_List CAN runner from the older framework copy
are in [archive/m314_canc_legacy/](archive/m314_canc_legacy/README.md). The tools that
replaced them are `generate_canc_scripts.py` and `generate_m310_fault_list_scripts.py`.