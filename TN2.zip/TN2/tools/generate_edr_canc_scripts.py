"""Generate the EDR CAN-C test scripts and their runner, per variant.

The ICE scripts live in `projects/U171/modules/EDR/scripts` and read the U171
configuration; the EV scripts live in `projects/M310_M314_M110/modules/EDR_CANC/scripts`
and read M310_M314_M110's. Each variant has its own runner, so running one never runs the
other.

A script is named for what it does - EDR_Element_ID_<element>_TestCase_<series>_<case>_<tag>
where the tag is NA_Full, SCF_Pre, UV_Post, CAN_NM and so on - so the fault family is
readable off the file name without looking the number up.

Each script is rendered from the template of its case family in tools/edr_canc_templates:
`<model>_<tag>.py`, where model is `interval` or `snapshot` after the element's recording
model. The templates are snapshots of the hand-corrected U171 scripts (VehSpdLgt series 6
for interval elements, Odometer series 2 for snapshot ones; GEAR_ACTUAL, VehSpdLgtAtTimeZero
and STS_ENG for the families those two do not have), taken 2026-10-07 and brought level with
those scripts again 2026-10-20 (arrays read as TestCase_<n>_... from the signal's own
canc_config dict, two EDR checks per sample, the trigger t0_offset_ms before T0). They sit
outside the output directories so regenerating cannot consume them. The CAN NM templates are the CAN
wakeup ones with the ECU woken and kept awake by the network-management PDU instead.

The U171 scripts are hand-maintained: never regenerate the ICE variant with --overwrite.

Offline only: writes Python files. Running a generated script drives a bench.

Usage:
    py -3.14 tools/generate_edr_canc_scripts.py --variant EV --overwrite
    py -3.14 tools/generate_edr_canc_scripts.py --variant EV --list
"""

from __future__ import annotations

import argparse
import re
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import edr_canc_review_model as model  # noqa: E402

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
# Each variant writes into its own project, so a shared series can carry the same case
# name in both without the two files colliding.
SCRIPT_DIRECTORIES = {
    "ICE": REPOSITORY_ROOT / "projects" / "U171" / "modules" / "EDR" / "scripts",
    "EV": REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "modules" / "EDR_CANC" / "scripts",
}
# The templates live outside the output directories, so regenerating cannot consume them;
# edit one only to change the shape of every script of its family at once.
TEMPLATE_DIRECTORY = REPOSITORY_ROOT / "tools" / "edr_canc_templates"
VARIANTS: dict[str, dict[str, str]] = {
    "ICE": {
        "project": "U171",
        "runner": "run_all_u171_edr_canc_scripts.py",
        "results": "u171_edr_canc_scripts_results.json",
        "label": "U171 project configuration",
        "spec_name": "U171",
    },
    "EV": {
        "project": "M310_M314_M110",
        "runner": "run_all_ev_edr_canc_scripts.py",
        "results": "ev_edr_canc_scripts_results.json",
        "label": "M310_M314_M110 project configuration (EV variant)",
        "spec_name": "M314",
    },
}

NEWLINE = chr(10)
TEMPLATE_HEADER = "# - do not edit" + NEWLINE + "# " + NEWLINE
TEMPLATE_LABEL = "# -- U171 project configuration ---------------------"

BEHAVIOUR = {
    "nominal": "Every sample records the value simulated for it.",
    "wakeup": "The record is written exactly as it is with hardware ignition on; waking "
              "over CAN changes how the ECU comes up, not what it stores.",
    "can_nm": "The record is written exactly as it is with hardware ignition on; an ECU "
              "kept awake by the CAN NM network request records what it receives.",
    "node_absent": "The last value received before the fault is retained for the whole "
                   "recording interval.",
    "message_timeout": "The last value received before the fault is retained for the "
                       "whole recording interval.",
    "message_content": "The message is rejected, so the last accepted value is retained.",
    "signal_content": "The signal keeps transmitting, so the invalid code on the bus is "
                      "what the record holds.",
    "signal_never_received": "The node never transmits, so every sample records the "
                             "on-fail default value.",
    "variant_code_error": "The variant code is in error from startup - its variant status "
                          "bit is cleared - so every sample records the on-fail default "
                          "value.",
    "dbc_invalid": "The signal keeps transmitting, so the value present on the bus at "
                   "each sample is recorded.",
    "dbc_out_of_range": "The value is a measurement the signal can encode but should not "
                        "carry, so it is converted like any other; whether the result "
                        "still fits the recording field is what this case shows.",
    "dbc_reserved": "A reserved code is a marker, not a measurement, so the record keeps "
                    "it as it stands.",
    "under_voltage": "The element stops being updated while the supply is below the "
                     "undervoltage threshold, so the last value received is retained.",
    "over_voltage": "The element stops being updated while the supply is above the "
                    "overvoltage threshold, so the last value received is retained.",
    "record_reserved": "A reserved field is never written, so it holds the reserved value "
                       "0x00 across every bit the specification reserves.",
    "record_not_configured": "An allocation this variant never feeds holds the "
                             "deconfigured value, all ones across the bits it owns.",
}


def template_name(plan: model.ParameterPlan, case: model.Case) -> str:
    """The template a case is rendered from: its recording model and its family tag."""
    if case.kind in ("record_reserved", "record_not_configured"):
        return f"{case.kind}.py"
    shape = "interval" if plan.recording_model == "interval" else "snapshot"
    return f"{shape}_{case.tag}.py"


def _literal_block(name: str, text: str, indent: int = 4) -> str:
    """Render an identity field the way the U171 scripts render theirs."""
    pad = " " * indent
    lines = textwrap.wrap(text, width=84 - indent)
    if len(lines) == 1:
        return f"{pad}{name} = {lines[0]!r}"
    body = NEWLINE.join(f"{pad}    {line + (' ' if index < len(lines) - 1 else '')!r}"
                        for index, line in enumerate(lines))
    return f"{pad}{name} = ({NEWLINE}{body}{NEWLINE}{pad})"


def _replace_field(text: str, name: str, replacement: str) -> str:
    """Swap a single- or multi-line identity field for a rendered one."""
    multi = re.compile(rf"^([ \t]*){name} = \(\n(?:[ \t]*(?:'[^\n]*'|\"[^\n]*\")\n)+[ \t]*\)$",
                       re.M)
    if multi.search(text):
        return multi.sub(lambda m: replacement, text, count=1)
    single = re.compile(rf"^[ \t]*{name} = (?:'[^\n]*'|\"[^\n]*\")$", re.M)
    return single.sub(lambda m: replacement, text, count=1)


def _category(plan: model.ParameterPlan, case: model.Case) -> str:
    label = model.KINDS[case.kind][0]
    if case.kind in ("record_reserved", "record_not_configured"):
        return label
    if case.kind == "nominal":
        return "Nominal full interval" if plan.recording_model == "interval" \
            else "Nominal static recording"
    if case.kind == "wakeup":
        return "CAN wakeup full interval"
    if case.kind == "can_nm":
        return "CAN NM wakeup full interval"
    if case.kind in ("dbc_invalid", "dbc_out_of_range", "dbc_reserved"):
        return model.KINDS[case.kind][0]
    interval = plan.interval_text().strip("()")
    if plan.recording_model != "interval":
        return f"{label} in full interval"
    start = float(plan.sample_range["start"])
    end = float(plan.sample_range["end"])
    if case.scope == "pre":
        return f"{label} only in pre crash ({start:.2f}s to T0)"
    if case.scope == "post":
        return f"{label} only in post crash (T0 to {end:+.2f}s)"
    return f"{label} in full interval ({interval})"


def _description(plan: model.ParameterPlan, case: model.Case, variant: str) -> str:
    label = model.KINDS[case.kind][0]
    where = f"{variant} ({VARIANTS[variant]['spec_name']})"
    if case.kind == "record_reserved":
        return (f"Verify every reserved byte and bit named by the diagnostic specification "
                f"records 0x00 in both EDR records, for {where}.")
    if case.kind == "record_not_configured":
        return (f"Verify every CAN-fed EDR allocation that {where} does not carry records "
                f"the deconfigured value, all ones across the bits it owns, in both EDR "
                f"records.")
    if case.kind == "nominal":
        return (f"Verify nominal {plan.parameter} recording in both EDR records for "
                f"{where}.")
    if case.kind == "wakeup":
        return (f"Verify {plan.parameter} recording during a crash when the ECU is woken "
                f"by CAN with hardware ignition OFF, for {where}.")
    if case.kind == "can_nm":
        return (f"Verify {plan.parameter} recording during a crash when the ECU is woken "
                f"and kept awake by the CAN NM message with hardware ignition OFF, for "
                f"{where}.")
    if case.kind in ("dbc_invalid", "dbc_out_of_range", "dbc_reserved"):
        what = {"dbc_invalid": "DBC-defined invalid values",
                "dbc_out_of_range": "DBC-encodable out-of-range values",
                "dbc_reserved": "DBC reserved values"}[case.kind]
        return f"Verify {plan.parameter} recording for {what} in {where}."
    scope = _category(plan, case)
    _, _, tail = scope.partition(label + " ")
    return f"Verify {plan.parameter} recording when {label} is applied {tail} for {where}."


def _common(text: str, variant: str) -> str:
    """The substitutions every script shares: header, project and configuration label."""
    settings = VARIANTS[variant]
    text = text.replace("\r\n", NEWLINE)
    text = text.replace(
        TEMPLATE_HEADER,
        "# GENERATED FILE - do not edit by hand." + NEWLINE
        + f"# Rebuild with: py -3.14 tools/generate_edr_canc_scripts.py --variant {variant}"
        + NEWLINE, 1)
    text = text.replace("Framework_IOEM_Py.projects.U171.config.",
                        f"Framework_IOEM_Py.projects.{settings['project']}.config.")
    return text.replace(TEMPLATE_LABEL, f"# -- {settings['label']} ---------------------")


_CONFIGS: dict | None = None


def _configs() -> dict:
    """The project configurations, loaded once per run."""
    global _CONFIGS
    if _CONFIGS is None:
        _CONFIGS = model.load_configs()
    return _CONFIGS


def _project_defines(variant: str, module_name: str, symbol: str) -> bool:
    path = (REPOSITORY_ROOT / "projects" / VARIANTS[variant]["project"] / "config"
            / f"{module_name}.py")
    return bool(re.search(rf"^{symbol}\s*=", path.read_text(encoding="utf-8"), re.M))


# --------------------------------------------------------------------------------------
# Rendering one script
# --------------------------------------------------------------------------------------


def allocation_names(variant: str) -> list[str]:
    """The record elements this variant never feeds, which must read the deconfigured value."""
    configs = _configs()
    plans = model.build_all()
    records = configs["u171_records" if variant == "ICE" else "m314_records"]
    own, other = ((plans["ice"], plans["ev"]) if variant == "ICE"
                  else (plans["ev"], plans["ice"]))
    other_records = configs["m314_records" if variant == "ICE" else "u171_records"]
    internal = plans.get("ev_internal") if variant == "EV" else None
    return [entry["name"] for entry in
            model.not_configured_elements(records, own, other, other_records, internal)]


def _render_record_check(plan: model.ParameterPlan, case: model.Case, variant: str) -> str:
    """One of the two whole-record checks: no CAN stimulus, just what the record holds."""
    text = _common((TEMPLATE_DIRECTORY / template_name(plan, case)).read_text(
        encoding="utf-8"), variant)
    where = f"{variant} ({VARIANTS[variant]['spec_name']})"
    other = "ICE" if variant == "EV" else "EV"
    if case.kind == "record_not_configured":
        start = text.index("    # The CAN-C parameters of the common EDR record that")
        end = text.index("    ]", start) + len("    ]")
        names = allocation_names(variant)
        listing = textwrap.wrap(", ".join(repr(name) for name in names), width=80,
                                initial_indent="        ", subsequent_indent="        ",
                                break_long_words=False, break_on_hyphens=False)
        block = [
            f"    # The CAN-C parameters of the common EDR record that {where} has no script",
            f"    # for: the {other}-only elements. {variant} never feeds them, so each must hold",
            "    # the deconfigured value across its whole allocation. Byte positions come",
            "    # from edr_config, so a layout change is a configuration edit.",
            "    NOT_CONFIGURED = [",
            *[line + ("," if index == len(listing) - 1 else "")
              for index, line in enumerate(listing)],
            "    ]",
        ]
        text = text[:start] + NEWLINE.join(block) + text[end:]
    text = _replace_field(text, "tc_desc",
                          _literal_block("tc_desc", _description(plan, case, variant)))
    text = _replace_field(text, "tc_id", f"    tc_id = '{case.signal}.{case.number}'")
    text = _replace_field(text, "tc_name", f"    tc_name = '{case.name}'")
    return "".join(line.rstrip() + NEWLINE for line in text.splitlines())


def render(plan: model.ParameterPlan, case: model.Case, variant: str) -> str:
    if case.kind in ("record_reserved", "record_not_configured"):
        return _render_record_check(plan, case, variant)
    path = TEMPLATE_DIRECTORY / template_name(plan, case)
    if not path.is_file():
        raise SystemExit(f"{case.name}: no template {path.name} for this case family")
    text = _common(path.read_text(encoding="utf-8"), variant)
    if variant == "EV":
        # The EV supply test levels are canc_config's CANC_UNDERVOLTAGE_TEST_VOLTAGE and
        # CANC_OVERVOLTAGE_TEST_VOLTAGE: the project's power_config keeps NOMINAL_VOLTAGE
        # only. They are imported under the names the templates use.
        text = text.replace(
            "from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (" + NEWLINE
            + "    NOMINAL_VOLTAGE," + NEWLINE + "    OVERVOLTAGE_TEST_VOLTAGE," + NEWLINE
            + "    UNDERVOLTAGE_TEST_VOLTAGE," + NEWLINE + ")" + NEWLINE,
            "from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import NOMINAL_VOLTAGE"
            + NEWLINE + "from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (" + NEWLINE
            + "    CANC_OVERVOLTAGE_TEST_VOLTAGE as OVERVOLTAGE_TEST_VOLTAGE," + NEWLINE
            + "    CANC_UNDERVOLTAGE_TEST_VOLTAGE as UNDERVOLTAGE_TEST_VOLTAGE," + NEWLINE + ")" + NEWLINE)

    text = _replace_field(text, "tc_id", f"    tc_id = '{case.signal}.{case.number}'")
    text = _replace_field(text, "tc_name", f"    tc_name = '{case.name}'")
    text = _replace_field(text, "tc_desc",
                          _literal_block("tc_desc", _description(plan, case, variant)))
    text = _replace_field(text, "tc_category",
                          f"    tc_category = {_category(plan, case)!r}")
    text = _replace_field(text, "tc_behaviour",
                          _literal_block("tc_behaviour", BEHAVIOUR[case.kind]))
    text = _replace_field(
        text, "tc_priority",
        f"    tc_priority = '{'Highest' if model.KINDS[case.kind][1] else 'High'}'")

    text = re.sub(r"MAH_CAN_SIGNAL_DEFS\['[^']+'\]",
                  f"MAH_CAN_SIGNAL_DEFS['{plan.canc_signal}']", text)
    # Every per-series array - values, invalid, reserved, out-of-range, SNR and VC
    # requirement values - is keyed by series number, so only the number changes.
    text = re.sub(r"'TestCase_\d+_", f"'TestCase_{case.signal}_", text)
    text = re.sub(r'"TestCase_\d+_', f'"TestCase_{case.signal}_', text)

    if variant == "EV":
        # The plan resolved the record's own name, the common EDR parameter name. It is
        # written into the script because one M314 signal definition can feed two
        # elements (VEHICLE_SPEED_ESC12: VehSpdLgt and VehSpdLgtAtTimeZero), and its
        # EDR_Parameter names only one of them.
        text = text.replace('    edr_param = signal_def["EDR_Parameter"]',
                            f"    edr_param = {plan.edr_parameter!r}")
    if not _project_defines(variant, "edr_config", "Crash_Parameters"):
        # The U171 nominal cases also read the crash-parameter block for the report; the
        # project's edr_config defines no such list, so that read is left out.
        text = text.replace("    Crash_Parameters," + NEWLINE, "")
        text = re.sub(r"^ *read_edr_parameters\(Crash_Parameters,[^\n]*\n", "", text,
                      flags=re.M)

    fault_logic = (_configs()["m314_signals" if variant == "EV" else "u171_signals"]
                   .get(plan.canc_signal) or {}).get("fault_logic") or {}
    if case.kind == "signal_content" and not fault_logic.get("signal_content_failure_dtc"):
        dbc = "M314" if variant == "EV" else "U171"
        anchor = "    can_dtc_code = resolve_dtc_for_event('signal_invalid', msg, sig)" + NEWLINE
        text = text.replace(anchor, anchor + (
            f"    # The {dbc} DBC defines an invalid code for this signal, but the DTC list"
            + NEWLINE + "    # defines no signal content failure DTC for it, so only the crash DTCs"
            + NEWLINE + "    # are expected. Check this against the DTC list if the ECU sets one."
            + NEWLINE), 1)

    leftovers = sorted(set(re.findall(r"U171|for ICE", text))) if variant == "EV" else []
    if leftovers:
        raise SystemExit(f"{case.name}: template text still names {leftovers}")
    return "".join(line.rstrip() + NEWLINE for line in text.splitlines())


# --------------------------------------------------------------------------------------
# Runner
# --------------------------------------------------------------------------------------

RUNNER_TEMPLATE = '''"""Run the {variant}-variant EDR CAN-C scripts.

GENERATED FILE - regenerate with:
    py -3.14 tools/generate_edr_canc_scripts.py --variant {variant}

Both variants' scripts share this folder. This runner lists only the {variant} elements of
the combined ICE/EV EDR CAN-C specification, which read the {project} configuration, so
running it never runs the other variant.

    py {runner}                       # everything uncommented
    py {runner} --only VehSpdLgt      # name contains VehSpdLgt
    py {runner} --fault node_absent   # one fault family
    py {runner} --nominal             # nominal cases only
    py {runner} --list                # show what would run

Results are written to {results}.

These scripts drive a bench. Run them only against a rig you are authorized to use.
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
RESULTS_FILE = SCRIPT_DIR / "{results}"

# Comment out a line to skip that script.
SCRIPT_FILES = [
{script_list}]

# Fault family per script, used by --fault and --nominal.
SCRIPT_FAULTS = {fault_map}


def select_scripts(arguments):
    selected, missing = [], []
    for name in SCRIPT_FILES:
        if arguments.only and arguments.only.lower() not in name.lower():
            continue
        fault = SCRIPT_FAULTS.get(name)
        if arguments.fault and fault != arguments.fault:
            continue
        if arguments.nominal and fault is not None:
            continue
        path = SCRIPT_DIR / name
        if path.is_file():
            selected.append(path)
        else:
            missing.append(name)
    if missing:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for name in missing:
            print("- " + name)
        print()
    return selected


def build_environment():
    env = os.environ.copy()
    import_root = SCRIPT_DIR.parents[4].parent
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(import_root) + (os.pathsep + existing if existing else "")
    return env


def run_script(path, env):
    print("=" * 100)
    print("Running: " + path.name)
    print("=" * 100)
    completed = subprocess.run(
        [sys.executable, str(path)],
        cwd=str(SCRIPT_DIR),
        env=env,
        capture_output=True,
        text=True,
    )
    if completed.stdout:
        print(completed.stdout, end="")
    if completed.stderr:
        print(completed.stderr, end="", file=sys.stderr)
    status = "PASSED" if completed.returncode == 0 else "FAILED"
    print(status + ": " + path.name + " (exit code " + str(completed.returncode) + ")")
    return completed.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="run scripts whose name contains this text")
    parser.add_argument("--fault", help="run one fault family, for example node_absent")
    parser.add_argument("--nominal", action="store_true", help="run nominal cases only")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()

    scripts = select_scripts(arguments)
    if arguments.list:
        for path in scripts:
            print(path.name + "  [" + str(SCRIPT_FAULTS.get(path.name) or "nominal") + "]")
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    env = build_environment()
    results = {{}}
    for path in scripts:
        results[path.name] = run_script(path, env)
    failed = [name for name, code in results.items() if code != 0]
    RESULTS_FILE.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print("=" * 100)
    print("Ran " + str(len(results)) + " script(s): "
          + str(len(results) - len(failed)) + " passed, " + str(len(failed)) + " failed")
    for name in failed:
        print("  FAILED: " + name)
    print("Results written to " + RESULTS_FILE.name)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
'''


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", required=True, choices=sorted(VARIANTS))
    parser.add_argument("--clean", action="store_true",
                        help="delete this variant's scripts before rebuilding")
    parser.add_argument("--overwrite", action="store_true",
                        help="rewrite scripts that already exist, not only the missing ones")
    parser.add_argument("--list", action="store_true",
                        help="print what would be written, then exit")
    arguments = parser.parse_args()

    variant = arguments.variant
    settings = VARIANTS[variant]
    if variant == "ICE" and (arguments.clean or arguments.overwrite):
        raise SystemExit("The U171 scripts are hand-maintained; --clean and --overwrite are "
                         "refused for ICE so they cannot be regenerated over.")
    script_directory = SCRIPT_DIRECTORIES[variant]
    script_directory.mkdir(parents=True, exist_ok=True)
    init_file = script_directory / "__init__.py"
    if not init_file.exists():
        init_file.write_text("", encoding="utf-8")
    everything = model.build_all()
    plans = everything["ice" if variant == "ICE" else "ev"]
    owned = {(plan.signal, plan.parameter) for plan in plans.values()}
    # Series the ECU feeds from its own sensor are not CAN-C cases, so a script left from
    # when they were is removed with the stale ones.
    retired = ({(plan.signal, plan.parameter) for plan in everything["ev_internal"].values()}
               if variant == "EV" else set())

    if arguments.clean:
        for existing in script_directory.glob("*EDR_Element_ID_*_TestCase_*.py"):
            match = model.SCRIPT_NAME.match(existing.stem)
            if match and (int(match.group(2)), match.group(1)) in owned:
                existing.unlink()

    # A case the specification no longer has, whose script is still on disk, is removed:
    # the review deletes a case by name, and leaving the file behind would put it back in
    # the runner.
    wanted = {f"{case.name}.py" for plan in plans.values() for case in plan.cases}
    stale = []
    for existing in sorted(script_directory.glob("*EDR_Element_ID_*_TestCase_*.py")):
        match = model.SCRIPT_NAME.match(existing.stem)
        if not match:
            continue
        key = (int(match.group(2)), match.group(1))
        if key not in owned and key not in retired:
            continue
        if existing.name not in wanted:
            stale.append(existing.name)
            if not arguments.list:
                existing.unlink()

    written: list[tuple[str, str | None]] = []
    created = kept = 0
    for signal in sorted(plans):
        plan = plans[signal]
        for case in plan.cases:
            file_name = f"{case.name}.py"
            written.append((file_name, case.kind if model.KINDS[case.kind][1] else None))
            path = script_directory / file_name
            if path.is_file() and not arguments.overwrite:
                kept += 1
                continue
            created += 1
            if arguments.list:
                continue
            path.write_text(render(plan, case, variant), encoding="utf-8")

    if arguments.list:
        for name, fault in written:
            print(f"{name}  [{fault or 'nominal'}]")
        print()
        print(f"{len(written)} script(s) for {variant}: {created} would be written, "
              f"{kept} already present")
        for name in stale:
            print(f"  would remove (no longer in the specification): {name}")
        return 0

    script_list = "".join('    "' + name + '",' + NEWLINE for name, _ in written)
    fault_map = "{" + NEWLINE + "".join(
        '    "' + name + '": ' + repr(fault) + "," + NEWLINE for name, fault in written
    ) + "}"
    (script_directory / settings["runner"]).write_text(
        RUNNER_TEMPLATE.format(variant=variant, project=settings["project"],
                               runner=settings["runner"], results=settings["results"],
                               script_list=script_list, fault_map=fault_map),
        encoding="utf-8")

    print(f"{variant}: {len(written)} script(s) in {script_directory}")
    print(f"  written {created}, already present {kept}, parameters {len(plans)}")
    print(f"  runner  {settings['runner']}")
    for name in stale:
        print(f"  removed (no longer in the specification): {name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
