"""Generate one CAN-C EDR test script per case in canc_c_config.py.

Scripts are written to `projects/<project>/modules/EDR_CANC/scripts/`. Every value a
script drives or asserts comes from the config, which is itself generated from the
specification, so scripts, config and specification cannot drift apart.

Edit this generator, never the generated scripts.

Offline only: writes Python files. Running a generated script drives a bench and must
be done deliberately, with authorization.

Usage:
    py -3.14 tools/generate_canc_c_scripts.py [--project U171] [--include-on-hold]
                                              [--only NAME_SUBSTRING] [--clean]
"""

from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]

FAULT_INJECTION = {
    "node_absent": (
        "        # Node absent: stop the node key message.\n"
        "        CAN.PeriodicDisableFrame({key_frame!r})\n"
    ),
    "message_timeout": (
        "        # Message timeout: stop the frame that carries the signal, so the\n"
        "        # receiver holds its last valid value instead of consuming a live one.\n"
        "        CAN.PeriodicDisableFrame({carrying_frame!r})\n"
    ),
    "message_content": (
        "        # Message content failure: break the CRC / alive counter on the carrying frame.\n"
        "        for integrity_signal in {integrity_signals!r}:\n"
        "            CAN.DynamicDisableSignal({carrying_frame!r}, integrity_signal)\n"
    ),
    "signal_content": (
        "        # Signal content failure: transmit the DBC-defined invalid code.\n"
        "        CAN.ChangeSignalValue({carrying_frame!r}, {signal!r}, str(INVALID_RAW))\n"
    ),
    "signal_never_received": (
        "        # Signal never received: clear this node's bit while the variant code stays enabled.\n"
        "        Create_Signal_Never_Received({key_frame!r})\n"
    ),
    "variant_code_error": (
        "        # Variant code error: disable the variant-code bit, then one ignition cycle to qualify.\n"
        "        Create_Variant_code_error({key_frame!r})\n"
        "        PS.Power_Cycle()\n"
    ),
}

FAULT_HEAL = {
    "node_absent": "        CAN.PeriodicEnableFrame({key_frame!r})\n",
    "message_timeout": "        CAN.PeriodicEnableFrame({carrying_frame!r})\n",
    "message_content": (
        "        for integrity_signal in {integrity_signals!r}:\n"
        "            CAN.DynamicEnableSignal({carrying_frame!r}, integrity_signal)\n"
    ),
    "signal_content": "        CAN.ChangeSignalValue({carrying_frame!r}, {signal!r}, str(VALID_RAW_AT_T0))\n",
    "signal_never_received": "        clear_Signal_Never_Received({key_frame!r})\n",
    "variant_code_error": "        clear_Variant_code_error({key_frame!r})\n",
}

TEMPLATE = '''"""{name}

GENERATED FILE - do not edit by hand.
Rebuild with: py -3.14 tools/generate_canc_c_scripts.py --project {project}

{description}

Case            : {name}
Applicability   : {applicability}
Category        : {category}
EDR parameter   : {parameter} (DRBFM analysis row {drbfm_row})
CAN route       : {frame} / {signal}
Records checked : DID 0x0455 (EDR1) and DID 0x045B (EDR2)
{fault_banner}
The recording interval is driven continuously against the sampling grid with the crash
trigger at T0. No wait is inserted between samples beyond the sample interval itself,
and the DTC is read only after the interval has been played out.
"""

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.apym_imports import ensure_apym_on_path, init_aria

ensure_apym_on_path()
init_aria()

from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    Crash_DTC,
    PT_Crash_DTC,
    DTC_status,
    Read_DTC_Req,
    Read_DTC_Resp,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep,
    Wait,
    Read_DTC,
    TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    fault_free_profile_classic_can,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import read_edr_parameters
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

from Framework_IOEM_Py.projects.{project}.config.canc_c_config import CASES_BY_NAME

CASE = CASES_BY_NAME[{name!r}]

# Ordered sample array from the specification: recording time, the raw value to drive,
# and the raw value the EDR is expected to store at that sample.
POINTS = CASE["points"]
FRAME = CASE["frame"]
SIGNAL = CASE["signal"]
FACTOR = CASE["factor"]
OFFSET = CASE["offset"]
SAMPLE_INTERVAL_MS = {sample_interval_ms}
ITERATIONS = CASE["recording_iterations"]


def _raw(value):
    """Config stores raw values as hex text; return an int, or None when not driven."""
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.startswith("0x"):
        return int(value, 16)
    return None


def run_test():
    tc_desc = {description!r}
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([{{"frame": FRAME, "frame_ID": None}}])
    create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
{wakeup_setup}
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"
    driven = [point for point in POINTS if _raw(point["in_hex"]) is not None]
    VALID_RAW_AT_T0 = next(
        (_raw(point["in_hex"]) for point in POINTS if point["t_s"] == 0 and _raw(point["in_hex"]) is not None),
        _raw(POINTS[0]["in_hex"]) if POINTS else 0,
    )
    INVALID_RAW = {invalid_raw}

    for iteration in range(ITERATIONS):
        for record_index in range(2):
            did = f"{{0x455 + (record_index * 0x6):04X}}"
            load_crash_curves(crash_type)
{fault_injection}
            # Drive the array against the sampling grid; the crash fires at T0.
            for index, point in enumerate(POINTS):
{iteration_guard}
                raw_value = _raw(point["in_hex"])
                if raw_value is not None:
                    CAN.ChangeSignalValue(FRAME, SIGNAL, str(raw_value))
                if point["t_s"] == 0:
                    TriggerCrash()
                Wait(SAMPLE_INTERVAL_MS)
{post_crash_injection}
            # Read DTC only after the whole recording interval has been played out.
            expected_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
{fault_dtc}
            Read_DTC("Front crash", Read_DTC_Resp + " " + expected_dtc, Read_DTC_Req)

            recorded = read_edr_parameters([{parameter!r}], did=did, crash_type=crash_type, return_data=True)
            _verify(recorded, did, iteration)

{fault_heal}
    return RESULT


def _verify(recorded, did, iteration):
    """Compare the recorded array against the expected values from the specification."""
    expected = [point for point in POINTS]
    if ITERATIONS > 1:
        expected = [POINTS[iteration]]
    for index, point in enumerate(expected):
        expected_raw = _raw(point["exp_hex"])
        if expected_raw is None:
            RESULT.InterpretResult(
                f"DID {{did}} sample {{index}} ({{point['t_s']}}s): expected value not resolved in the specification",
                False,
            )
            continue
        actual_raw = recorded[index] if isinstance(recorded, (list, tuple)) and index < len(recorded) else recorded
        RESULT.InterpretEqualResult(
            f"DID {{did}} {parameter!r} at {{point['t_s']}}s records raw {{point['exp_hex']}} "
            f"({{point['exp_phys']}} {unit})",
            str(actual_raw),
            str(expected_raw),
        )


if __name__ == "__main__":
    run_test()
'''


def _load_config(project: str) -> Any:
    path = REPOSITORY_ROOT / "projects" / project / "config" / "canc_c_config.py"
    spec = importlib.util.spec_from_file_location(f"{project}_canc_c_config", path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _sample_interval_ms(case: dict[str, Any]) -> int:
    times = sorted({float(point["t_s"]) for point in case["points"]})
    if len(times) < 2:
        return 500
    gaps = [round((second - first) * 1000) for first, second in zip(times, times[1:])]
    positive = [gap for gap in gaps if gap > 0]
    return min(positive) if positive else 500


def _render(case: dict[str, Any], project: str) -> str:
    fault_mode = case["fault_mode"]
    scope = case["timing_scope"]
    substitutions = {
        "key_frame": case["key_frame"],
        "carrying_frame": case["carrying_frame"] or case["frame"],
        "integrity_signals": case["integrity_signals"],
        "signal": case["signal"],
    }

    def reindent(block: str, indent: str) -> str:
        """Re-indent a template block, which is authored at 8 spaces, to `indent`."""
        if not block:
            return ""
        lines = [line for line in block.format(**substitutions).splitlines() if line.strip()]
        return "".join(f"{indent}{line[8:]}\n" for line in lines)

    injection = ""
    post_crash_injection = ""
    heal = ""
    if fault_mode:
        rendered = FAULT_INJECTION.get(fault_mode, "")
        heal_template = FAULT_HEAL.get(fault_mode, "")
        if scope == "post":
            # Inject at T0 so every pre-crash sample stays valid.
            body = reindent(rendered, " " * 20)
            if body:
                post_crash_injection = "                if point['t_s'] == 0:\n" + body
        else:
            injection = reindent(rendered, " " * 12)
        if scope == "pre":
            # A pre-crash-only fault is healed at T0 so post-crash samples recover.
            body = reindent(heal_template, " " * 20)
            if body:
                post_crash_injection = (
                    "                if point['t_s'] == 0:\n"
                    "                    # Heal at T0: the fault applies to pre-crash samples only.\n"
                    + body
                )
        # A pre-crash fault is healed inside the loop; anything else is healed at the end.
        heal = "" if scope == "pre" else reindent(heal_template, " " * 12)

    iteration_guard = ""
    if case["recording_iterations"] > 1:
        iteration_guard = (
            "                if index != iteration:\n"
            "                    continue\n"
        )

    fault_dtc = ""
    if case["dtc_codes"]:
        codes = " ".join(part.replace("0x", "").upper() for part in str(case["dtc_codes"][0]).split())
        fault_dtc = f'            expected_dtc += " {codes} {case["dtc_status"]}"\n'

    invalid_raw = "None"
    if fault_mode == "signal_content":
        for point in case["points"]:
            raw = point["in_hex"]
            if isinstance(raw, str) and raw.startswith("0x"):
                invalid_raw = str(int(raw, 16))
                break

    wakeup_setup = ""
    if case.get("can_wakeup"):
        wakeup_setup = (
            "    # CAN wakeup: hardware ignition stays OFF and the ECU is woken over CAN.\n"
            "    PS.IGN_OFF()\n"
            "    CAN.WakeupNetwork()\n"
            "    Sleep(1)\n"
        )

    fault_banner = (
        f"Fault           : {fault_mode} applied {scope} interval"
        if fault_mode
        else "Fault           : none (nominal recording)"
    )
    if case.get("can_wakeup"):
        fault_banner += "\nWakeup          : ECU woken over CAN with hardware ignition OFF"

    return TEMPLATE.format(
        name=case["name"],
        project=project,
        description=case["category"] + " - " + case["parameter"],
        applicability=case["applicability"],
        category=case["category"],
        parameter=case["parameter"],
        drbfm_row=case["drbfm_row"],
        frame=case["frame"],
        signal=case["signal"],
        unit=case["unit"] or "",
        fault_banner=fault_banner,
        sample_interval_ms=_sample_interval_ms(case),
        fault_injection=injection,
        post_crash_injection=post_crash_injection,
        iteration_guard=iteration_guard,
        fault_dtc=fault_dtc,
        fault_heal=heal,
        wakeup_setup=wakeup_setup,
        invalid_raw=invalid_raw,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", default="U171")
    parser.add_argument("--include-on-hold", action="store_true", help="also generate ON HOLD cases")
    parser.add_argument("--only", default=None, help="only cases whose name contains this text")
    parser.add_argument("--clean", action="store_true", help="remove previously generated scripts first")
    arguments = parser.parse_args()

    config = _load_config(arguments.project)
    output_directory = REPOSITORY_ROOT / "projects" / arguments.project / "modules" / "EDR_CANC" / "scripts"
    output_directory.mkdir(parents=True, exist_ok=True)

    if arguments.clean:
        for existing in output_directory.glob("SUBS_EDR_Element_ID_*.py"):
            existing.unlink()

    cases = config.CANC_C_CASES
    if not arguments.include_on_hold:
        cases = [case for case in cases if case["status"] == "IN REVIEW"]
    if arguments.only:
        cases = [case for case in cases if arguments.only in case["name"]]

    written = 0
    skipped = 0
    for case in cases:
        if not case["points"] or case["frame"] is None:
            skipped += 1
            continue
        (output_directory / f"{case['name']}.py").write_text(_render(case, arguments.project), encoding="utf-8")
        written += 1

    init_file = output_directory / "__init__.py"
    if not init_file.exists():
        init_file.write_text("", encoding="utf-8")

    print(f"Wrote {written} scripts to {output_directory}")
    if skipped:
        print(f"  skipped {skipped} case(s) with no CAN route or no sample array")
    return 0


if __name__ == "__main__":
    sys.exit(main())
