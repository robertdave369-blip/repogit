from __future__ import annotations

from pathlib import Path


OLD_BLOCK = """        PS.IGN_OFF()\n        Sleep(1)\n        PS.IGN_ON()"""
NEW_BLOCK = """        PS.IGN_OFF()\n        Sleep(4)\n        PS.IGN_ON()"""


def main() -> int:
    repo_root = Path(__file__).resolve().parents[1]
    scripts_root = repo_root / "projects"
    updated_files: list[Path] = []

    for script_path in sorted(scripts_root.glob("**/modules/**/scripts/F*_IOControl_Testcase*.py")):
        content = script_path.read_text(encoding="utf-8")
        if OLD_BLOCK not in content:
            continue

        updated_content = content.replace(OLD_BLOCK, NEW_BLOCK)
        if updated_content == content:
            continue

        script_path.write_text(updated_content, encoding="utf-8")
        updated_files.append(script_path)

    print(f"Updated {len(updated_files)} file(s).")
    for path in updated_files:
        print(path.relative_to(repo_root).as_posix())

    return 0


if __name__ == "__main__":
    raise SystemExit(main())