# Author: Christy, Krishna
#
# - do not edit
# 

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides, so a script
# names what it uses rather than where it lives. The two ARIA calls come through it
# too, and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- U171 project configuration ---------------------
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    DECONFIGURED_BYTE_VALUE,
    EDR_DIDS,
    RESERVED_ALLOCATIONS,
    RESERVED_BYTE_VALUE,
)


EDR_RECORD_DIDS = tuple(f"{did:04X}" for did in EDR_DIDS.values())

def run_test():
    tc_desc = (
        'Verify every reserved byte and bit named by the diagnostic specification records '
        '0x00 in both EDR records, for ICE (U171).'
    )

    # Every reserved field the diagnostic specification names, as edr_config carries
    # it: (name, byte, high bit, low bit, byte length). A field spanning whole bytes
    # has bits 7..0 and a length above one; each must read 0x00 in every reserved bit.
    ALLOCATIONS = [
        (f"Reserved byte {entry['data_byte']} bits {entry['high_bit']}..{entry['low_bit']}",
         entry["data_byte"], entry["high_bit"], entry["low_bit"], entry["byte_length"])
        for entry in RESERVED_ALLOCATIONS
    ]

    tc_id = '9001.1'
    tc_name = 'EDR_Element_ID_RESERVED_BYTES_TestCase_9001_1_Record_00'
    expected_byte = RESERVED_BYTE_VALUE
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)

    # No CAN stimulus: the record is checked for allocations that are never fed.
    fault_free_profile()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    # One crash per event record. The first crash writes 0455 and is read before the
    # second crash writes 045B, so each record is checked after it has been written;
    # reading 045B after a single crash would check an empty record. The records come
    # from edr_config, so a DID that changes is a configuration edit.
    for did in EDR_RECORD_DIDS:
        load_crash_curves(crash_type)
        TriggerCrash()
        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc, Read_DTC_Req)
        Sleep(5)

        aria_reports.add_group(f"Reserved bytes and bits record 0x00 - DID {did}")
        payload = read_edr_record_bytes(did=did, crash_type=crash_type)
        if not payload:
            RESULT.InterpretEqualResult(
                f"EDR record DID {did}",
                "No record bytes returned",
                "A decodable event record",
                TestStatus.Failed)
            aria_reports.close_group()
            continue

        for name, byte_index, high_bit, low_bit, byte_length in ALLOCATIONS:
            # Byte numbers already count the response header, so the record is
            # read at payload[byte - 1], the same way read_edr_parameters reads it.
            position = byte_index - 1
            if position + byte_length > len(payload):
                RESULT.InterpretEqualResult(
                    name,
                    f"Record ends before byte {byte_index}",
                    f"{byte_length} byte(s) at byte {byte_index}",
                    TestStatus.Failed)
                continue
            if byte_length > 1:
                # A reserved field spanning whole bytes; every byte must read 0x00.
                observed_bytes = [int(str(v).replace('0x', ''), 16)
                                  for v in payload[position:position + byte_length]]
                RESULT.InterpretEqualResult(
                    f"{name} in DID {did}",
                    " ".join(f"{v:02X}" for v in observed_bytes),
                    " ".join(f"{expected_byte:02X}" for _ in observed_bytes))
                continue
            # Mask just this field out of its owning byte; the rest of the byte
            # belongs to another element and is not checked here.
            width = high_bit - low_bit + 1
            mask = ((1 << width) - 1) << low_bit
            raw_byte = int(str(payload[position]).replace('0x', ''), 16)
            observed = (raw_byte & mask) >> low_bit
            RESULT.InterpretEqualResult(
                f"{name} in DID {did}",
                f"0x{observed:02X}",
                f"0x{expected_byte:02X}")
        aria_reports.close_group()

    # Both records are verified; the bench goes back to fault free, NVM cleared.
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
