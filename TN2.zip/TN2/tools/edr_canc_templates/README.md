# EDR CAN-C Script Templates

## Purpose and contents

These Python files are source templates for
[`generate_edr_canc_scripts.py`](../generate_edr_canc_scripts.py), not executable
bench tests. The generator renders one script per case from `<model>_<tag>.py`, where
`model` is `interval` or `snapshot` after the element's recording model and `tag` is the
case family (`Nominal`, `NA_Full`, `MTO_Pre`, `MCF_Post`, `SCF_Full`, `UV_Full`, `OV_Pre`,
`SNR`, `VC`, `OOR`, `Reserved`, `CAN_Wakeup`, `CAN_NM`, ...). The two whole-record checks
use `record_reserved.py` and `record_not_configured.py`.

The generator replaces the U171 configuration imports with the target project's, so the
templates import from `Framework_IOEM_Py.projects.U171.config`.

## Inputs and provenance

The templates are snapshots of the hand-corrected U171 scripts taken on 2026-10-07 and
brought level with them again on 2026-10-20 (see the generator's module docstring). Project
configuration and the generator's case plan supply the project-specific values; a template
is not an independent diagnostic specification.

## Variant Code Error (VC) cases

[`interval_VC.py`](./interval_VC.py) and [`snapshot_VC.py`](./snapshot_VC.py):

- The fault is the cleared variant status bit, `manage_variant_code("VARIANT_STATUS", ...)`,
  not a node bit (a node bit is the SNR case).
- Every disable, including the snapshot reinjection after the fault-free profile, passes
  `apply_ignition_cycle=False` and checks that the helper returned `PASS`. The template's
  own `PS.Power_Cycle()` is the one ignition cycle that qualifies the error.
- Cleanup enables the same bit with the helper's normal ignition cycle and checks `PASS`.
- The front-crash DTC read also expects `Variant_Code_DTC` with `DTC_status["DTC_active"]`.
  `Variant_Code_DTC` is imported explicitly from `shared_libraries.configuration_control`
  after the project configuration, the same way the UV/OV templates import their DTCs.

Ported on 2026-10-22 from the older framework copy. The same change was applied in place to the
existing VC scripts (U171 46, Z121 46, M310_M314_M110 60), changing only those lines. The U171
(ICE) scripts are hand-maintained, and the generator refuses `--overwrite` for ICE. Do not run
the EV variant with `--overwrite` either: on 2026-10-22 its case plan (1197 cases) no longer
matched the 1159 EV scripts on disk, and it would have removed 145 of them.

[`generate_u171_combined_edr_scripts.py`](../generate_u171_combined_edr_scripts.py) does the same
for the combined VARIANT_CODE_ERROR_FULL run. In every combined run it also reports each
`manage_variant_code` status, because the helper signals a failed write by its status and never
by raising.

## Reporting policy

EDR results show the raw value as read (hex, no decimal) and the physical value. A value
wider than its field is shown in full.

## Validation

List what a variant would write (no scripts are written or removed):

```powershell
py -3.14 tools\generate_edr_canc_scripts.py --variant EV --list
```

Retain these templates as generation inputs. Do not remove them as though they were
generated test outputs. Changes are recorded in the monthly [tool logbook](../logbook/2026-10.md).
