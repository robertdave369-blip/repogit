# Author: Christy, Krishna
#
# - do not edit
# 

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides, so a script
# names what it uses rather than where it lives. The two ARIA calls come through it
# too, and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- U171 project configuration ---------------------
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
)
from Framework_IOEM_Py.projects.U171.config.rsu_config import RSU_T0_OFFSETS
from Framework_IOEM_Py.projects.U171.config.canc_config import PROJECT_NAME
from Framework_IOEM_Py.projects.U171.config.canc_config import *


EDR_RECORD_DIDS = tuple(f"{did:04X}" for did in EDR_DIDS.values())

def run_test():
    tc_id = '6.23'
    tc_name = 'EDR_Element_ID_VehSpdLgt_TestCase_6_23_CAN_Wakeup'
    tc_desc = (
        'Verify VehSpdLgt recording during a crash when the ECU is woken by CAN with '
        'hardware ignition OFF, for ICE (U171).'
    )
    tc_category = 'CAN wakeup full interval'
    tc_behaviour = (
        'The record is written exactly as it is with hardware ignition on; waking over '
        'CAN changes how the ECU comes up, not what it stores.'
    )
    tc_priority = 'High'

    # -- Signal under test, from canc_config ---------------------------------
    signal_def = MAH_CAN_SIGNAL_DEFS['VEHICLE_SPEED_ESC12']
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((parameter for parameter in get_edr_parameters() if parameter.get("name") == edr_param), None)
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    bit_length = signal_def.get("bit_length") or (
        edr_def or {}).get("data_bit_length")
    signal_signed = signal_def.get("Signed", False)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)
    unit = signal_def.get("UNIT") or "value"

    values = signal_def.get('TestCase_6_Values') or []
    if not isinstance(values, list):
        values = [values]

    # -- EDR element under test, from edr_config -----------------------------
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    record_samples = (edr_def or {}).get("data_samples_number") or 1
    # The record keeps its own width and conversion, which are not always the CAN
    # signal's: a pedal can arrive at 0.1 %/bit in ten bits and be stored at 0.4 %/bit
    # in eight. CAN values are read with the signal's conversion, recorded values with
    # the record's.
    edr_bits = (edr_def or {}).get("data_bit_length") or bit_length
    edr_signed = bool((edr_def or {}).get("signed"))
    edr_scaling = (edr_def or {}).get("scaling_factor", 1)
    edr_offset = (edr_def or {}).get("offset", 0)
    # A recorded sample stands for raw x resolution + offset, in the unit of the CAN
    # signal it is taken from.
    edr_unit = signal_def.get("UNIT") or (edr_def or {}).get("unit") or ""
    unit_text = f" {edr_unit}" if edr_unit else ""
    resolution = (f"resolution {format_physical(edr_scaling)}{unit_text}"
                  + (f", offset {format_physical(edr_offset)}{unit_text}" if edr_offset else ""))

    # Without the record layout and the signal width there is nothing to verify. That
    # is a configuration gap rather than a test result, so it stops the case here,
    # before the bench is touched.
    if edr_def is None:
        raise KeyError(f"{edr_param} has no entry in the {PROJECT_NAME} edr_config")
    if not bit_length:
        raise KeyError(f"{sig} has no bit_length in canc_config or data_bit_length in edr_config")

    # A DBC invalid code is a marker, not a measurement, so the record keeps it as it
    # stands rather than putting it through the physical conversion. An out-of-range
    # value is different: it is a measurement the signal can encode but should not
    # carry, so the ECU converts it like any other, and whether the result still fits
    # the recording field is exactly what the case is there to show.
    exception_codes = set(signal_def.get('TestCase_6_Invalid_Values') or [])

    # No CAN fault in this case, so only the crash DTCs are expected.
    combined_can_dtc = ""

    # -- Report and logging --------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Test Case Category:", tc_category)
    aria_reports.add_report_info("#Priority:", tc_priority)
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)
    aria_reports.add_report_info("#EDR Element:", edr_param)

    # The record must be able to hold every sample this case drives.
    RESULT.InterpretEqualResult(
        f"{edr_param} record holds the number of samples the case drives",
        str(record_samples),
        str(len(values) if record_samples > 1 else 1))

    # -- Bench bring-up ------------------------------------------------------
    fault_free_profile()
    PS.Power_Cycle()
    Sleep(1)
    # CAN wakeup: hardware ignition stays OFF and the ECU is woken through CAN alone.
    # Power_Cycle() switches ignition on, so the wakeup comes after it.
    # Legacy call, kept for reference: wake_ecu_over_can()
    # CAN_Wakeup()
    # The wakeup now follows each load_crash_curves() in the crash loop:
    # load_crash_curves() power-cycles the ECU with hardware ignition ON, which would
    # end a wakeup made here.
    read_software_version()
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    # rsu_config gives, per crash type, the time in milliseconds from the trigger to the
    # ECU's T0, and the recording is taken around that T0. So the trigger fires that long
    # before the end of the T0 window, and T0 lands where the T0 sample is recorded. With
    # 0 the trigger fires at the end of the T0 window.
    t0_offset_ms = int(RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS.get("default", 0)) or 0)
    RESULT.InsertComment(
        f"Crash type {crash_type}: T0 = trigger + {t0_offset_ms} ms (RSU_T0_OFFSETS), so"
        + (f" the trigger fires {t0_offset_ms} ms before the end of the T0 window."
           if t0_offset_ms else " the trigger fires at the end of the T0 window."))

    # An element that records an interval stores the whole vector in one crash, so the
    # same vector goes into both event records. An element that stores a single sample
    # needs one crash per value. A DBC exception case drives one code per crash across
    # the whole interval.
    if record_samples > 1:
        per_crash = [values, values]
    else:
        per_crash = [[value] for value in values]

    # The records to read come from edr_config, so a DID that changes is a
    # configuration edit and this script does not have to be touched.
    for pass_start in range(0, len(per_crash), len(EDR_RECORD_DIDS)):
        this_pass = per_crash[pass_start:pass_start + len(EDR_RECORD_DIDS)]

        for record_index, crash_values in enumerate(this_pass):
            did = EDR_RECORD_DIDS[record_index]
            load_crash_curves(crash_type)
            # CAN wakeup after the power cycle of load_crash_curves(), which switches
            # hardware ignition on: the crash is recorded with ignition OFF.
            CAN_Wakeup()

            # Recording times come from the element's own sample range and count from the
            # ECU's T0. The T0 offset moves the trigger, not the recording grid.
            time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type)
            t0_sample_idx = next(
                (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
            sample_interval_s = sample_interval_ms / 1000.0
            simulation_time_axis = [t - sample_interval_s for t in time_axis]
            # The sample at T0 is driven over the window ending at T0, and the ECU takes T0
            # t0_offset_ms after the trigger. So the trigger fires t0_offset_ms before the
            # end of that window: in the window of sample trigger_idx, trigger_lead_ms
            # before its end.
            t0_window_idx = min(t0_sample_idx, len(crash_values) - 1)
            trigger_idx = max(t0_window_idx - t0_offset_ms // sample_interval_ms, 0)
            trigger_lead_ms = t0_offset_ms % sample_interval_ms

            print(f"EDR parameter: {edr_param} in DID {did}")
            print(f"Recording time axis: {time_axis}")
            print(f"Simulation time axis: {simulation_time_axis}")
            print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
            print(f"T0 sample index: {t0_sample_idx}, trigger index: {trigger_idx},"
                  f" T0 offset: {t0_offset_ms} ms")
            print(f"Total values to simulate: {len(crash_values)}")

            crash_reference = None
            observed_inputs = []

            aria_reports.add_group(
                f"{test_case_file} - DID {did} - CAN signal simulation - {tc_category}")
            RESULT.InsertComment(
                f"[{report_timestamp()}] Starting {tc_category} into event record {did}.")

            for idx, val in enumerate(crash_values):
                simulation_start_time = (simulation_time_axis[idx]
                                         if idx < len(simulation_time_axis)
                                         else ((idx * sample_interval_s) - sample_interval_s))
                recording_time = (time_axis[idx] if idx < len(time_axis)
                                  else (idx * sample_interval_s))
                window = (f"simulated from {simulation_start_time}s to {recording_time}s,"
                          f" recorded at {recording_time}s")

                driven = val

                CAN.ChangeSignalValue(msg, sig, str(driven))
                if idx == trigger_idx and crash_reference is None:
                    # The trigger fires trigger_lead_ms before the end of this window, so the
                    # ECU's T0, t0_offset_ms after the trigger, falls on the end of the T0
                    # window. crash_reference counts from that T0.
                    if sample_interval_ms > trigger_lead_ms:
                        Wait(sample_interval_ms - trigger_lead_ms)
                    TriggerCrash()
                    crash_reference = time.monotonic() + t0_offset_ms / 1000.0
                    if trigger_lead_ms:
                        Wait(trigger_lead_ms)
                else:
                    Wait(sample_interval_ms)
                received = CAN.GetSignalFromFrame(msg, sig)
                try:
                    received_raw = (int(str(received), 16)
                                    if str(received).lower().startswith("0x")
                                    else int(received))
                except (TypeError, ValueError):
                    received_raw = None

                if received_raw is None:
                    observed_inputs.append(None)
                    RESULT.InterpretEqualResult(
                        f"{sig} index {idx}",
                        f"Unreadable value {received!r} ({window})",
                        f"An integer raw value ({window})",
                        TestStatus.Failed)
                else:
                    received_signed = (raw_signed(received_raw, bit_length)
                                       if signal_signed else received_raw)
                    observed_inputs.append(received_signed)
                    # Raw hex and physical: a wrong raw value shows in the hex, a wrong
                    # scaling in the physical value.
                    RESULT.InterpretEqualResult(
                        f"{sig} raw hex at index {idx} ({window})",
                        raw_hex(received_raw, bit_length), raw_hex(driven, bit_length))
                    RESULT.InterpretEqualResult(
                        f"{sig} physical value in {unit} at index {idx} ({window})",
                        format_physical(received_signed * factor + offset),
                        format_physical(driven * factor + offset))

                if idx == trigger_idx:
                    # The crash was triggered inside this sample's window, above.
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] Crash triggered"
                        + (f" {t0_offset_ms} ms before T0, in the window of the sample at"
                           f" {recording_time}s; T0 is the end of the T0 window."
                           if t0_offset_ms else
                           f" at the end of the window of the sample at {recording_time}s: T0."))

            Sleep(1)
            combined_crash_dtc = (Crash_DTC + " " + DTC_status["DTC_active"] + " "
                                  + PT_Crash_DTC + " " + DTC_status["DTC_active"])
            final_combined_dtc = (combined_crash_dtc
                                  + ((" " + combined_can_dtc) if combined_can_dtc else ""))
            Read_DTC("Front Crash", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
            aria_reports.close_group()

            # -- EDR output verification -------------------------------------
            Sleep(5)
            RESULT.InsertComment(
                f"[{report_timestamp(crash_reference)}] Reading event record {did}.")
            edr_read = read_edr_parameters(
                [edr_param], did=did, crash_type=crash_type, return_data=True,
                can_wakeup=True)
            Sleep(2)
            response_bytes = edr_read.get("data", []) if isinstance(edr_read, dict) else []
            samples = edr_sample_records(edr_param, response_bytes)

            aria_reports.add_group(
                f"{test_case_file} - DID {did} - EDR output verification - {tc_category}")

            for idx, val in enumerate(crash_values):
                recording_time = (time_axis[idx] if idx < len(time_axis)
                                  else (idx * sample_interval_s))
                state = "valid input"

                expected_can = val

                # Two checks per sample: the raw value the record holds and the physical
                # value it stands for at the record's resolution. The ECU reads the CAN
                # value with the signal's conversion and stores it with the record's; a
                # DBC marker code is not a measurement and is stored as it stands.
                band = expected_can if isinstance(expected_can, tuple) else (expected_can,)
                converted = []
                conversion_exact = True
                for can_raw in band:
                    if can_raw in exception_codes:
                        converted.append(int(can_raw))
                        continue
                    precise = ((can_raw * factor + offset) - edr_offset) / edr_scaling
                    rounded = int(round(precise))
                    converted.append(rounded)
                    if abs(precise - rounded) >= 1e-6:
                        conversion_exact = False
                if len(converted) > 1:
                    # A band: the record may hold anything between its two ends.
                    low, high = min(converted), max(converted)
                    expected_raw_text = (f"{raw_hex(low, edr_bits)} to"
                                         f" {raw_hex(high, edr_bits)}")
                    expected_physical_text = (
                        f"{format_physical(low * edr_scaling + edr_offset)} to"
                        f" {format_physical(high * edr_scaling + edr_offset)}{unit_text}")
                else:
                    expected_raw = converted[0]
                    if expected_raw > (1 << edr_bits) - 1 or expected_raw < -(1 << edr_bits):
                        # The case drives a value larger than the field allocated to record
                        # it, so this sample cannot pass as it stands. It is compared
                        # anyway: what the record holds says which of the two is wrong.
                        RESULT.InsertComment(
                            f"{edr_param} at {recording_time}s: the value {expected_raw}"
                            f" needs more than the {edr_bits} bit(s) the specification"
                            f" allocates (maximum {(1 << edr_bits) - 1}). A recorded value"
                            f" of {expected_raw & ((1 << edr_bits) - 1)} here means the ECU"
                            f" truncated it; anything else is worth reporting against the"
                            f" record layout.")
                    expected_signed = (raw_signed(expected_raw, edr_bits)
                                       if edr_signed else expected_raw)
                    low = high = expected_signed
                    expected_raw_text = raw_hex(expected_raw, edr_bits)
                    if expected_raw > (1 << edr_bits) - 1 or expected_raw < -(1 << edr_bits):
                        # raw_hex prints the field's width; this value needs more.
                        expected_raw_text = (f"{'-' if expected_raw < 0 else ''}0x{abs(expected_raw):X}"
                                             f" - needs more than {edr_bits} bits")
                    expected_physical_text = (
                        f"{format_physical(expected_signed * edr_scaling + edr_offset)}{unit_text}")
                    if not conversion_exact:
                        # The two conversions do not divide evenly, so the record holds
                        # the nearest whole count; one count either side is accepted.
                        low, high = expected_signed - 1, expected_signed + 1
                        expected_raw_text += " +/- 1 count"
                        expected_physical_text += (
                            f" +/- {format_physical(edr_scaling)}{unit_text}")

                sample_name = f"{edr_param} at {recording_time}s ({state})"
                if idx >= len(samples):
                    sample_passed = False
                    observed_raw_text = observed_physical_text = "no sample in the record"
                else:
                    observed = samples[idx]
                    sample_passed = low <= observed["raw"] <= high
                    observed_raw_text = observed['hex']
                    observed_physical_text = f"{format_physical(observed['physical'])}{unit_text}"
                sample_verdict = TestStatus.Passed if sample_passed else TestStatus.Failed
                RESULT.InterpretEqualResult(
                    f"{sample_name} - EDR raw value",
                    observed_raw_text, expected_raw_text, sample_verdict)
                RESULT.InterpretEqualResult(
                    f"{sample_name} - physical value, {resolution}",
                    observed_physical_text, expected_physical_text, sample_verdict)
            aria_reports.close_group()

            # The wake request is released before the next power cycle (with hardware
            # ignition ON the wake request bit must be 0).
            CAN_Wakeup_Restore()

        # Every event record written in this pass has been read and compared, so the NVM
        # can be cleared to make room for the next one. Clearing any earlier would
        # destroy the second record before it was verified.
        numbers = [pass_start + n + 1 for n in range(len(this_pass))]
        if len(numbers) > 1:
            covered = f"Crashes {numbers[0]} and {numbers[-1]} of {len(per_crash)}"
            into = f"records {EDR_RECORD_DIDS[0]} and {EDR_RECORD_DIDS[-1]}"
        else:
            covered = f"Crash {numbers[0]} of {len(per_crash)}"
            into = f"record {EDR_RECORD_DIDS[0]}"
        RESULT.InsertComment(
            f"[{report_timestamp()}] {covered} recorded into {into} and verified;"
            f" clearing NVM.")
        NVM_Clear_L61()

    # -- Restore the bench ---------------------------------------------------
    # The wake request is released and ignition goes back on before the bench
    # returns to fault free.
    CAN_Wakeup_Restore()
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
