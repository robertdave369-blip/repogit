# Author: Christy, Krishna
#
# - do not edit
# 

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides, so a script
# names what it uses rather than where it lives. The two ARIA calls come through it
# too, and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- U171 project configuration ---------------------
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    DECONFIGURED_BYTE_VALUE,
    EDR_DIDS,
    RESERVED_BYTE_VALUE,
)


EDR_RECORD_DIDS = tuple(f"{did:04X}" for did in EDR_DIDS.values())

def run_test():
    tc_desc = (
        'Verify every CAN-fed EDR allocation that ICE (U171) does not carry records the '
        'deconfigured value, all ones across the bits it owns, in both EDR records.'
    )

    # The CAN-C parameters of the common EDR record that ICE (U171) has no script for:
    # the EV-only elements. ICE never feeds them, so each must hold the deconfigured
    # value across its whole allocation. Byte positions come from edr_config, so a
    # layout change is a configuration edit.
    NOT_CONFIGURED = [
        'RCTA_WARN', 'SEB_WARNING_LEFT', 'SEB_WARNING_RIGHT', 'RCW_WARN',
        'VCU_OPRT_REQ', 'VCU_TRQ_CMD', 'STS_ABS', 'STS_EBD', 'STS_ESC', 'STS_TCS',
        'PADDLE_SHIFT_POSITION', 'VCU_IGN_STS', 'EMERGENCY_BRAKING_REQ',
        'TORQUE_SPLIT_RATIO', 'ALERT_MESSAGE', 'VCU_DRV_ADV_MODE',
        'VCU_DRV_ADV_MODE_STS', 'CTRL_BRAKE_LIGHT', 'PIB_ACTIVE',
    ]
    definitions = {parameter.get("name"): parameter for parameter in get_edr_parameters()}
    #   (parameter, start byte, byte length, high bit, low bit); the bits are set only
    #   for a field narrower than its byte, whose other bits belong to another element.
    ALLOCATIONS = []
    for name in NOT_CONFIGURED:
        definition = definitions.get(name) or {}
        high_bit = low_bit = None
        if definition.get("type") in ("bit", "bits"):
            parts = str(definition.get("range") or "").split("-")
            low_bit = int(parts[0].split(".")[1])
            high_bit = int(parts[-1].split(".")[1])
        ALLOCATIONS.append((name, definition.get("data_start_byte"),
                            definition.get("data_byte_length"), high_bit, low_bit))

    tc_id = '9000.1'
    tc_name = 'EDR_Element_ID_NOT_CONFIGURED_TestCase_9000_1_Record_FF'
    expected_byte = DECONFIGURED_BYTE_VALUE
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)

    # No CAN stimulus: the record is checked for allocations that are never fed.
    fault_free_profile()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    # One crash per event record. The first crash writes 0455 and is read before the
    # second crash writes 045B, so each record is checked after it has been written;
    # reading 045B after a single crash would check an empty record. The records come
    # from edr_config, so a DID that changes is a configuration edit.
    for did in EDR_RECORD_DIDS:
        load_crash_curves(crash_type)
        TriggerCrash()
        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc, Read_DTC_Req)
        Sleep(5)

        aria_reports.add_group(f"Not-configured CAN allocations record 0xFF - DID {did}")
        payload = read_edr_record_bytes(did=did, crash_type=crash_type)
        if not payload:
            RESULT.InterpretEqualResult(
                f"EDR record DID {did}",
                "No record bytes returned",
                "A decodable event record",
                TestStatus.Failed)
            aria_reports.close_group()
            continue

        for name, start_byte, byte_length, high_bit, low_bit in ALLOCATIONS:
            if start_byte is None or not byte_length:
                RESULT.InterpretEqualResult(
                    name,
                    f"{name} has no byte allocation in the EDR configuration",
                    "Byte allocation required",
                    TestStatus.Failed)
                continue
            # Byte numbers already count the response header.
            position = start_byte - 1
            if high_bit is not None:
                # This element shares its byte with one the variant does feed, so only
                # its own bits are checked: the rest of the byte carries real data. The
                # deconfigured value for a field narrower than a byte is all ones across
                # the bits it owns.
                width = high_bit - low_bit + 1
                byte = int(str(payload[position]).replace('0x', ''), 16)
                observed_bits = (byte & (((1 << width) - 1) << low_bit)) >> low_bit
                RESULT.InterpretEqualResult(
                    f"{name}: byte {start_byte} bits {high_bit}..{low_bit} in DID {did}",
                    f"0x{observed_bits:02X}",
                    f"0x{(1 << width) - 1:02X}")
                continue
            chunk = payload[position:position + byte_length]
            if len(chunk) < byte_length:
                RESULT.InterpretEqualResult(
                    name,
                    f"Record ends inside bytes {start_byte}..{start_byte + byte_length - 1}",
                    f"{byte_length} byte(s) at byte {start_byte}",
                    TestStatus.Failed)
                continue
            observed = [int(str(value).replace('0x', ''), 16) for value in chunk]
            expected = [expected_byte] * byte_length
            RESULT.InterpretEqualResult(
                f"{name}: bytes {start_byte}..{start_byte + byte_length - 1} in DID {did}",
                " ".join(f"{value:02X}" for value in observed),
                " ".join(f"{value:02X}" for value in expected))
        aria_reports.close_group()

    # Both records are verified; the bench goes back to fault free, NVM cleared.
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
