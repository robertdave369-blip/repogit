# Author: Christy, Krishna
#
# - do not edit
# 

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides, so a script
# names what it uses rather than where it lives. The two ARIA calls come through it
# too, and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- U171 project configuration ---------------------
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
)
from Framework_IOEM_Py.projects.U171.config.rsu_config import RSU_T0_OFFSETS
from Framework_IOEM_Py.projects.U171.config.canc_config import PROJECT_NAME
from Framework_IOEM_Py.projects.U171.config.canc_config import *


EDR_RECORD_DIDS = tuple(f"{did:04X}" for did in EDR_DIDS.values())

def run_test():
    tc_id = '1.3'
    tc_name = 'EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_1_3_MTO_Full'
    tc_desc = (
        'Verify VehSpdLgtAtTimeZero recording when Message Timeout is applied in full '
        'interval for ICE (U171).'
    )
    tc_category = 'Message Timeout in full interval'
    tc_behaviour = (
        'The last value received before the fault is retained for the whole recording '
        'interval.'
    )
    tc_priority = 'Highest'

    # -- Signal under test, from canc_config ---------------------------------
    signal_def = MAH_CAN_SIGNAL_DEFS['VEHICLE_SPEED_ESC12']
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((parameter for parameter in get_edr_parameters() if parameter.get("name") == edr_param), None)
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    bit_length = signal_def.get("bit_length") or (
        edr_def or {}).get("data_bit_length")
    signal_signed = signal_def.get("Signed", False)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)
    unit = signal_def.get("UNIT") or "value"

    values = signal_def.get('TestCase_1_Values') or []
    if not isinstance(values, list):
        values = [values]

    # -- EDR element under test, from edr_config -----------------------------
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    record_samples = (edr_def or {}).get("data_samples_number") or 1
    # The record keeps its own width and conversion, which are not always the CAN
    # signal's: a pedal can arrive at 0.1 %/bit in ten bits and be stored at 0.4 %/bit
    # in eight. CAN values are read with the signal's conversion, recorded values with
    # the record's.
    edr_bits = (edr_def or {}).get("data_bit_length") or bit_length
    edr_signed = bool((edr_def or {}).get("signed"))
    edr_scaling = (edr_def or {}).get("scaling_factor", 1)
    edr_offset = (edr_def or {}).get("offset", 0)
    # A recorded sample stands for raw x resolution + offset, in the unit of the CAN
    # signal it is taken from.
    edr_unit = signal_def.get("UNIT") or (edr_def or {}).get("unit") or ""
    unit_text = f" {edr_unit}" if edr_unit else ""
    resolution = (f"resolution {format_physical(edr_scaling)}{unit_text}"
                  + (f", offset {format_physical(edr_offset)}{unit_text}" if edr_offset else ""))

    # Without the record layout and the signal width there is nothing to verify. That
    # is a configuration gap rather than a test result, so it stops the case here,
    # before the bench is touched.
    if edr_def is None:
        raise KeyError(f"{edr_param} has no entry in the {PROJECT_NAME} edr_config")
    if not bit_length:
        raise KeyError(f"{sig} has no bit_length in canc_config or data_bit_length in edr_config")

    # A DBC invalid code is a marker, not a measurement, so the record keeps it as it
    # stands rather than putting it through the physical conversion. An out-of-range
    # value is different: it is a measurement the signal can encode but should not
    # carry, so the ECU converts it like any other, and whether the result still fits
    # the recording field is exactly what the case is there to show.
    exception_codes = set(signal_def.get('TestCase_1_Invalid_Values') or [])

    # -- Fault under test ----------------------------------------------------
    # scope   which part of the interval the fault covers
    # action  what the record is expected to hold while it is active:
    #         last_valid  the last value received before the fault
    #         consume     the value on the bus, because the signal keeps transmitting
    #         default     the value the on-fail calibration configures
    fault_scope = 'full'
    fault_action = 'last_valid'
    default_raw = signal_def.get('Default_Value', 0)

    fault_logic = signal_def["fault_logic"]
    key_frame = fault_logic["key_message"]
    timeout_frame = fault_logic.get("non_key_timeout_frame")
    invalid_raw = (signal_def.get('TestCase_1_Invalid_Values') or [0])[0]

    can_dtc_code = resolve_dtc_for_event('message_timeout', timeout_frame)
    # A CAN fault reads active-with-warning-lamp-off while it is present. A pre-crash
    # case is healed at T0, so by the time the DTC is read it has become historic.
    can_dtc_status = DTC_status['DTC_active_WLOFF']
    combined_can_dtc = (can_dtc_code + " " + can_dtc_status) if can_dtc_code else ""

    # Qualification is a count of message periods, not a fixed value, so a fault
    # on a 100 ms frame needs ten times as long as the same fault on a 10 ms one.
    periodicity = signal_def["periodicity"]
    qualification = qualification_ms('message_timeout', periodicity)

    # -- Report and logging --------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Test Case Category:", tc_category)
    aria_reports.add_report_info("#Priority:", tc_priority)
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)
    aria_reports.add_report_info("#EDR Element:", edr_param)

    # The record must be able to hold every sample this case drives.
    RESULT.InterpretEqualResult(
        f"{edr_param} record holds the number of samples the case drives",
        str(record_samples),
        str(len(values) if record_samples > 1 else 1))

    # -- Bench bring-up ------------------------------------------------------
    fault_free_profile()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    # rsu_config gives, per crash type, the time in milliseconds from the trigger to the
    # ECU's T0, and the recording is taken around that T0. So the trigger fires that long
    # before the end of the T0 window, and T0 lands where the T0 sample is recorded. With
    # 0 the trigger fires at the end of the T0 window.
    t0_offset_ms = int(RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS.get("default", 0)) or 0)
    RESULT.InsertComment(
        f"Crash type {crash_type}: T0 = trigger + {t0_offset_ms} ms (RSU_T0_OFFSETS), so"
        + (f" the trigger fires {t0_offset_ms} ms before the end of the T0 window."
           if t0_offset_ms else " the trigger fires at the end of the T0 window."))

    # An element that records an interval stores the whole vector in one crash, so the
    # same vector goes into both event records. An element that stores a single sample
    # needs one crash per value. A DBC exception case drives one code per crash across
    # the whole interval.
    if record_samples > 1:
        per_crash = [values, values]
    else:
        per_crash = [[value] for value in values]

    # A snapshot element is checked in both event records: each value is one crash,
    # the first recorded into 0455 and the next into 045B. An odd count would leave
    # 045B unchecked on the last pass, so the first value is repeated to fill it.
    if record_samples == 1 and len(per_crash) % len(EDR_RECORD_DIDS):
        per_crash = per_crash + per_crash[:len(EDR_RECORD_DIDS)
                                          - len(per_crash) % len(EDR_RECORD_DIDS)]

    # The records to read come from edr_config, so a DID that changes is a
    # configuration edit and this script does not have to be touched.
    for pass_start in range(0, len(per_crash), len(EDR_RECORD_DIDS)):
        this_pass = per_crash[pass_start:pass_start + len(EDR_RECORD_DIDS)]

        for record_index, crash_values in enumerate(this_pass):
            did = EDR_RECORD_DIDS[record_index]
            load_crash_curves(crash_type)

            # Recording times come from the element's own sample range and count from the
            # ECU's T0. The T0 offset moves the trigger, not the recording grid.
            time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type)
            t0_sample_idx = next(
                (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
            sample_interval_s = sample_interval_ms / 1000.0
            simulation_time_axis = [t - sample_interval_s for t in time_axis]
            # The sample at T0 is driven over the window ending at T0, and the ECU takes T0
            # t0_offset_ms after the trigger. So the trigger fires t0_offset_ms before the
            # end of that window: in the window of sample trigger_idx, trigger_lead_ms
            # before its end.
            t0_window_idx = min(t0_sample_idx, len(crash_values) - 1)
            trigger_idx = max(t0_window_idx - t0_offset_ms // sample_interval_ms, 0)
            trigger_lead_ms = t0_offset_ms % sample_interval_ms

            # Which samples the fault covers. A pre-crash fault covers the samples
            # before T0 (the authored V4 cases record the valid value at T0) and is
            # healed inside the T0 window; post starts after T0, full covers the interval.
            if fault_scope == "pre":
                fault_from, fault_to = 0, t0_sample_idx
            elif fault_scope == "post":
                fault_from, fault_to = t0_sample_idx + 1, len(crash_values)
            else:
                fault_from, fault_to = 0, len(crash_values)

            # "The last value received before the fault" is the value driven just before
            # it starts: the primed value when the fault covers the first sample, the
            # value at T0 when it starts after the crash.
            retained = crash_values[t0_sample_idx] if fault_scope == "post" else crash_values[0]

            print(f"EDR parameter: {edr_param} in DID {did}")
            print(f"Recording time axis: {time_axis}")
            print(f"Simulation time axis: {simulation_time_axis}")
            print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
            print(f"T0 sample index: {t0_sample_idx}, trigger index: {trigger_idx},"
                  f" T0 offset: {t0_offset_ms} ms")
            print(f"Fault scope: {fault_scope} action: {fault_action}"
                  f" samples {fault_from}..{fault_to}")
            print(f"Total values to simulate: {len(crash_values)}")

            crash_reference = None
            observed_inputs = []
            fault_is_on = False

            aria_reports.add_group(
                f"{test_case_file} - DID {did} - CAN signal simulation - {tc_category}")
            RESULT.InsertComment(
                f"[{report_timestamp()}] Starting {tc_category} into event record {did}.")

            # A fault covering the first sample can only retain the last value
            # received before the fault if the element has received something. On the
            # second record it would otherwise retain whatever the previous crash left,
            # so the first value is driven and received before the fault starts.
            if fault_from == 0 and crash_values:
                CAN.ChangeSignalValue(msg, sig, str(crash_values[0]))
                Wait(sample_interval_ms)
                RESULT.InsertComment(
                    f"[{report_timestamp()}] Primed {sig} with {crash_values[0]} before "
                    f"creating the fault, so the value the element retains is known.")

            for idx, val in enumerate(crash_values):
                simulation_start_time = (simulation_time_axis[idx]
                                         if idx < len(simulation_time_axis)
                                         else ((idx * sample_interval_s) - sample_interval_s))
                recording_time = (time_axis[idx] if idx < len(time_axis)
                                  else (idx * sample_interval_s))
                window = (f"simulated from {simulation_start_time}s to {recording_time}s,"
                          f" recorded at {recording_time}s")
                if record_samples == 1:
                    # A snapshot holds its input across T0: one sample interval before
                    # the crash and the same again after it.
                    window = (f"simulated from {simulation_start_time}s to"
                              f" {recording_time + sample_interval_s}s, crash at"
                              f" {recording_time}s, recorded at {recording_time}s")
                in_fault = fault_from is not None and fault_from <= idx < fault_to
                remaining_ms = sample_interval_ms

                # Create the fault at the first sample it covers.
                if in_fault and not fault_is_on:
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] "
                        + f"Disabling signal-carrying frame {timeout_frame} to create Message Timeout.")
                    try:
                        CAN.PeriodicDisableFrame(timeout_frame)
                        fault_call_error = None
                    except Exception as raised:
                        fault_call_error = raised
                    RESULT.InterpretEqualResult(
                        f"Create Message Timeout at index {idx} ({window})",
                        ("completed at [" + report_timestamp(crash_reference) + "]")
                        if fault_call_error is None else
                        f"raised {type(fault_call_error).__name__}: {fault_call_error}",
                        "the bench call to complete without raising",
                        TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
                    fault_is_on = True
                # Heal it at the first sample it does not, so the recovered values
                # are on the bus for the rest of the interval.
                elif fault_is_on and not in_fault:
                    # Heal half-way through this sample's window, not at its start: the
                    # previous sample is recorded at the start of this window and must
                    # still see the fault, this one is recorded at its end and must see the
                    # healed bus. This sample's value is set from the start of the window;
                    # the rest of it is waited out below. No sleep: the sampling grid of
                    # the recording interval must not move.
                    CAN.ChangeSignalValue(msg, sig, str(val))
                    first_half_ms = sample_interval_ms // 2
                    if (idx == trigger_idx and crash_reference is None
                            and trigger_lead_ms > sample_interval_ms - first_half_ms):
                        # The trigger falls in this first half; see the wait below.
                        Wait(sample_interval_ms - trigger_lead_ms)
                        TriggerCrash()
                        crash_reference = time.monotonic() + t0_offset_ms / 1000.0
                        first_half_ms -= sample_interval_ms - trigger_lead_ms
                    Wait(first_half_ms)
                    remaining_ms = sample_interval_ms - sample_interval_ms // 2
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] "
                        + f"Restoring signal-carrying frame {timeout_frame}.")
                    try:
                        CAN.ReloadDefaultPeriodicFrame(timeout_frame)
                        fault_call_error = None
                    except Exception as raised:
                        fault_call_error = raised
                    RESULT.InterpretEqualResult(
                        f"Heal Message Timeout at index {idx} ({window})",
                        ("completed at [" + report_timestamp(crash_reference) + "]")
                        if fault_call_error is None else
                        f"raised {type(fault_call_error).__name__}: {fault_call_error}",
                        "the bench call to complete without raising",
                        TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
                    fault_is_on = False

                # The values keep being driven as normal while the fault is active, so the
                # case can tell a held or substituted value from one the ECU kept taking
                # off the bus; a stopped frame simply does not carry them. A fault that
                # keeps the signal transmitting drives its invalid code instead.
                if in_fault and fault_action == "consume":
                    driven = invalid_raw
                else:
                    driven = val
                    if in_fault and record_samples == 1:
                        # A snapshot takes one value, so driving that same value while
                        # the fault is active could not show whether the ECU held it. A
                        # different valid value is driven instead.
                        alternatives = [other for other in values if other != val] or [
                            limit for limit in (signal_def.get("MIN"), signal_def.get("MAX"))
                            if limit is not None and limit != val]
                        if alternatives:
                            driven = alternatives[0]
                if (fault_action == "consume" and not in_fault
                        and fault_from is not None and 0 < fault_to == idx):
                    # The fault ends inside this sample's window. The previous sample is
                    # recorded at the start of the window and must still see the invalid
                    # code, so it stays on the bus for the first half.
                    CAN.ChangeSignalValue(msg, sig, str(invalid_raw))
                    first_half_ms = sample_interval_ms // 2
                    if (idx == trigger_idx and crash_reference is None
                            and trigger_lead_ms > sample_interval_ms - first_half_ms):
                        # The trigger falls in this first half; see the wait below.
                        Wait(sample_interval_ms - trigger_lead_ms)
                        TriggerCrash()
                        crash_reference = time.monotonic() + t0_offset_ms / 1000.0
                        first_half_ms -= sample_interval_ms - trigger_lead_ms
                    Wait(first_half_ms)
                    remaining_ms = sample_interval_ms - sample_interval_ms // 2

                if driven is not None:
                    CAN.ChangeSignalValue(msg, sig, str(driven))
                if idx == trigger_idx and crash_reference is None:
                    # The trigger fires trigger_lead_ms before the end of this window, so the
                    # ECU's T0, t0_offset_ms after the trigger, falls on the end of the T0
                    # window. crash_reference counts from that T0.
                    if remaining_ms > trigger_lead_ms:
                        Wait(remaining_ms - trigger_lead_ms)
                    TriggerCrash()
                    crash_reference = time.monotonic() + t0_offset_ms / 1000.0
                    if trigger_lead_ms:
                        Wait(trigger_lead_ms)
                else:
                    Wait(remaining_ms)
                if driven is None:
                    observed_inputs.append(None)
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] {sig} index {idx} ({window}):"
                        f" fault active, no value driven.")
                else:
                    received = CAN.GetSignalFromFrame(msg, sig)
                    try:
                        received_raw = (int(str(received), 16)
                                        if str(received).lower().startswith("0x")
                                        else int(received))
                    except (TypeError, ValueError):
                        received_raw = None

                    if received_raw is None:
                        observed_inputs.append(None)
                        RESULT.InterpretEqualResult(
                            f"{sig} index {idx}",
                            f"Unreadable value {received!r} ({window})",
                            f"An integer raw value ({window})",
                            TestStatus.Failed)
                    else:
                        received_signed = (raw_signed(received_raw, bit_length)
                                           if signal_signed else received_raw)
                        observed_inputs.append(received_signed)
                        # Raw hex and physical: a wrong raw value shows in the hex, a wrong
                        # scaling in the physical value.
                        RESULT.InterpretEqualResult(
                            f"{sig} raw hex at index {idx} ({window})",
                            raw_hex(received_raw, bit_length), raw_hex(driven, bit_length))
                        RESULT.InterpretEqualResult(
                            f"{sig} physical value in {unit} at index {idx} ({window})",
                            format_physical(received_signed * factor + offset),
                            format_physical(driven * factor + offset))

                if idx == trigger_idx:
                    # The crash was triggered inside this sample's window, above.
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] Crash triggered"
                        + (f" {t0_offset_ms} ms before T0, in the window of the sample at"
                           f" {recording_time}s; T0 is the end of the T0 window."
                           if t0_offset_ms else
                           f" at the end of the window of the sample at {recording_time}s: T0."))

                    # A snapshot element records one value, at T0, so the crash has to
                    # land inside the simulated window rather than at its trailing edge.
                    # Whatever was on the bus for the interval before T0 - the value or
                    # the fault - stays there for the same interval after it.
                    if record_samples == 1:
                        Wait(sample_interval_ms)
                        post_window = (f"held for {sample_interval_ms} ms after the crash,"
                                       f" {recording_time}s to"
                                       f" {recording_time + sample_interval_s}s")
                        if driven is None:
                            RESULT.InsertComment(
                                f"[{report_timestamp(crash_reference)}] {sig} {post_window}:"
                                f" fault still active, no value driven.")
                        else:
                            held = CAN.GetSignalFromFrame(msg, sig)
                            try:
                                held_raw = (int(str(held), 16)
                                            if str(held).lower().startswith("0x")
                                            else int(held))
                            except (TypeError, ValueError):
                                held_raw = None
                            if held_raw is not None and signal_signed:
                                held_raw = raw_signed(held_raw, bit_length)
                            RESULT.InterpretEqualResult(
                                f"{sig} raw hex {post_window}",
                                raw_hex(held_raw, bit_length) if held_raw is not None
                                else f"Unreadable value {held!r}",
                                raw_hex(driven, bit_length))
                            RESULT.InterpretEqualResult(
                                f"{sig} physical value in {unit} {post_window}",
                                format_physical(held_raw * factor + offset) if held_raw is not None
                                else f"Unreadable value {held!r}",
                                format_physical(driven * factor + offset))

            if qualification:
                Wait(qualification)
            Sleep(1)
            combined_crash_dtc = (Crash_DTC + " " + DTC_status["DTC_active"] + " "
                                  + PT_Crash_DTC + " " + DTC_status["DTC_active"])
            final_combined_dtc = (combined_crash_dtc
                                  + ((" " + combined_can_dtc) if combined_can_dtc else ""))
            Read_DTC("Front Crash", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
            aria_reports.close_group()

            # -- EDR output verification -------------------------------------
            Sleep(5)
            RESULT.InsertComment(
                f"[{report_timestamp(crash_reference)}] Reading event record {did}.")
            edr_read = read_edr_parameters(
                [edr_param], did=did, crash_type=crash_type, return_data=True)
            Sleep(2)
            response_bytes = edr_read.get("data", []) if isinstance(edr_read, dict) else []
            samples = edr_sample_records(edr_param, response_bytes)

            aria_reports.add_group(
                f"{test_case_file} - DID {did} - EDR output verification - {tc_category}")

            for idx, val in enumerate(crash_values):
                recording_time = (time_axis[idx] if idx < len(time_axis)
                                  else (idx * sample_interval_s))
                in_fault = fault_from is not None and fault_from <= idx < fault_to
                state = "fault active" if in_fault else "valid input"

                if not in_fault:
                    expected_can = val
                elif fault_action == 'consume':
                    expected_can = invalid_raw
                elif fault_action == 'default':
                    expected_can = default_raw
                else:
                    expected_can = retained

                # Two checks per sample: the raw value the record holds and the physical
                # value it stands for at the record's resolution. The ECU reads the CAN
                # value with the signal's conversion and stores it with the record's; a
                # DBC marker code is not a measurement and is stored as it stands.
                band = expected_can if isinstance(expected_can, tuple) else (expected_can,)
                converted = []
                conversion_exact = True
                for can_raw in band:
                    if can_raw in exception_codes:
                        converted.append(int(can_raw))
                        continue
                    precise = ((can_raw * factor + offset) - edr_offset) / edr_scaling
                    rounded = int(round(precise))
                    converted.append(rounded)
                    if abs(precise - rounded) >= 1e-6:
                        conversion_exact = False
                if len(converted) > 1:
                    # A band: the record may hold anything between its two ends.
                    low, high = min(converted), max(converted)
                    expected_raw_text = (f"{raw_hex(low, edr_bits)} to"
                                         f" {raw_hex(high, edr_bits)}")
                    expected_physical_text = (
                        f"{format_physical(low * edr_scaling + edr_offset)} to"
                        f" {format_physical(high * edr_scaling + edr_offset)}{unit_text}")
                else:
                    expected_raw = converted[0]
                    if expected_raw > (1 << edr_bits) - 1 or expected_raw < -(1 << edr_bits):
                        # The case drives a value larger than the field allocated to record
                        # it, so this sample cannot pass as it stands. It is compared
                        # anyway: what the record holds says which of the two is wrong.
                        RESULT.InsertComment(
                            f"{edr_param} at {recording_time}s: the value {expected_raw}"
                            f" needs more than the {edr_bits} bit(s) the specification"
                            f" allocates (maximum {(1 << edr_bits) - 1}). A recorded value"
                            f" of {expected_raw & ((1 << edr_bits) - 1)} here means the ECU"
                            f" truncated it; anything else is worth reporting against the"
                            f" record layout.")
                    expected_signed = (raw_signed(expected_raw, edr_bits)
                                       if edr_signed else expected_raw)
                    low = high = expected_signed
                    expected_raw_text = raw_hex(expected_raw, edr_bits)
                    if expected_raw > (1 << edr_bits) - 1 or expected_raw < -(1 << edr_bits):
                        # raw_hex prints the field's width; this value needs more.
                        expected_raw_text = (f"{'-' if expected_raw < 0 else ''}0x{abs(expected_raw):X}"
                                             f" - needs more than {edr_bits} bits")
                    expected_physical_text = (
                        f"{format_physical(expected_signed * edr_scaling + edr_offset)}{unit_text}")
                    if not conversion_exact:
                        # The two conversions do not divide evenly, so the record holds
                        # the nearest whole count; one count either side is accepted.
                        low, high = expected_signed - 1, expected_signed + 1
                        expected_raw_text += " +/- 1 count"
                        expected_physical_text += (
                            f" +/- {format_physical(edr_scaling)}{unit_text}")

                sample_name = f"{edr_param} at {recording_time}s ({state})"
                if idx >= len(samples):
                    sample_passed = False
                    observed_raw_text = observed_physical_text = "no sample in the record"
                else:
                    observed = samples[idx]
                    sample_passed = low <= observed["raw"] <= high
                    observed_raw_text = observed['hex']
                    observed_physical_text = f"{format_physical(observed['physical'])}{unit_text}"
                sample_verdict = TestStatus.Passed if sample_passed else TestStatus.Failed
                RESULT.InterpretEqualResult(
                    f"{sample_name} - EDR raw value",
                    observed_raw_text, expected_raw_text, sample_verdict)
                RESULT.InterpretEqualResult(
                    f"{sample_name} - physical value, {resolution}",
                    observed_physical_text, expected_physical_text, sample_verdict)
            aria_reports.close_group()

            # This record is verified. The bench still holds whatever state the last
            # sample left it in, so the fault is removed before the next record is
            # driven; without this the next crash would drive valid values into a
            # frame that is still stopped.
            if fault_is_on:
                RESULT.InsertComment(
                    f"[{report_timestamp(crash_reference)}] "
                    + f"Restoring signal-carrying frame {timeout_frame}.")
                try:
                    CAN.ReloadDefaultPeriodicFrame(timeout_frame)
                    fault_call_error = None
                except Exception as raised:
                    fault_call_error = raised
                RESULT.InterpretEqualResult(
                    f"Heal Message Timeout after reading record {did}",
                    ("completed at [" + report_timestamp(crash_reference) + "]")
                    if fault_call_error is None else
                    f"raised {type(fault_call_error).__name__}: {fault_call_error}",
                    "the bench call to complete without raising",
                    TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
                fault_is_on = False
                Sleep(1)

        # Every event record written in this pass has been read and compared, so the NVM
        # can be cleared to make room for the next one. Clearing any earlier would
        # destroy the second record before it was verified.
        numbers = [pass_start + n + 1 for n in range(len(this_pass))]
        if len(numbers) > 1:
            covered = f"Crashes {numbers[0]} and {numbers[-1]} of {len(per_crash)}"
            into = f"records {EDR_RECORD_DIDS[0]} and {EDR_RECORD_DIDS[-1]}"
        else:
            covered = f"Crash {numbers[0]} of {len(per_crash)}"
            into = f"record {EDR_RECORD_DIDS[0]}"
        RESULT.InsertComment(
            f"[{report_timestamp()}] {covered} recorded into {into} and verified;"
            f" clearing faults and NVM.")
        # Both records of this pass are verified, so the bench goes back to fault free -
        # EDR and DTC NVM cleared, EOL and variant code rewritten - before the next pair
        # of values. The last pass is left to the clean-up below.
        if pass_start + len(EDR_RECORD_DIDS) < len(per_crash):
            fault_free_profile()

    # -- Restore the bench ---------------------------------------------------
    CAN.ChangeSignalValue(msg, sig, "0")
    crash_reference = None
    RESULT.InsertComment(
        f"[{report_timestamp(crash_reference)}] "
        + f"Restoring signal-carrying frame {timeout_frame}.")
    try:
        CAN.ReloadDefaultPeriodicFrame(timeout_frame)
        fault_call_error = None
    except Exception as raised:
        fault_call_error = raised
    RESULT.InterpretEqualResult(
        "Heal Message Timeout during cleanup",
        ("completed at [" + report_timestamp(crash_reference) + "]")
        if fault_call_error is None else
        f"raised {type(fault_call_error).__name__}: {fault_call_error}",
        "the bench call to complete without raising",
        TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
    CAN.ReloadDefaultPeriodicFrame(msg)
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
