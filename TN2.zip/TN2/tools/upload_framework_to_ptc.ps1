[CmdletBinding()]
param(
    [string]$SourceRoot = "C:\Project_U171\View_Test_Developement\Tests\SW_Qualification\Framework_IOEM_Py",
    [string]$SandboxRoot = "C:\Project_ALE_Core_Validation\AEI_Validation\IOEM_Validation\Mahindra\Framework_IOEM_Py",
    [string]$PtcProject = "#p=e:/MKSProjects/ALE Core Validation/ALE Core Validation.pj#s=AEI_Validation/AEI_Validation.pj#s=IOEM_Validation/IOEM_Validation.pj#s=Mahindra/Mahindra.pj#s=Framework_IOEM_Py/Framework_IOEM_Py.pj",
    [string]$ChangePackageId = "1491192:1",
    [string]$Description = "Create named Framework_IOEM_Py subprojects and add source initializers",
    [string]$SiPath = "C:\Program Files\Windchill\RVSClient13\bin\si.exe",
    [switch]$Apply,
    [switch]$Preflight,
    [string]$ManifestPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ($Apply -and $Preflight) {
    throw "Use either -Apply or -Preflight, not both."
}

function Resolve-DirectoryPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Label
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "$Label does not exist or is not a directory: $Path"
    }

    return (Resolve-Path -LiteralPath $Path).ProviderPath.TrimEnd(
        [char[]]@([System.IO.Path]::DirectorySeparatorChar)
    )
}

function Get-RelativeSourcePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullName,
        [Parameter(Mandatory = $true)]
        [string]$SourcePrefix
    )

    if (-not $FullName.StartsWith($SourcePrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Source item is outside the requested source root: $FullName"
    }

    return $FullName.Substring($SourcePrefix.Length)
}

function Invoke-SiQuery {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $commandOutput = @(& $Executable @Arguments 2>&1)
    return [PSCustomObject]@{
        ExitCode = $LASTEXITCODE
        Text = (($commandOutput | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine).TrimEnd()
    }
}

function Invoke-SiCommand {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    Write-Host ("Running: {0} {1}" -f $Executable, ($Arguments -join " "))
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Windchill RV&S command failed with exit code ${LASTEXITCODE}: $($Arguments -join ' ')"
    }
}

function Get-RvsRootProjectPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SandboxInfoText
    )

    $projectNameMatch = [regex]::Match($SandboxInfoText, "(?m)^Project Name:\s*(?<Path>.+)$")
    if (-not $projectNameMatch.Success) {
        throw "RV&S sandbox information did not include a root Project Name."
    }

    $projectPath = $projectNameMatch.Groups["Path"].Value.Trim().Replace("\", "/")
    if (-not $projectPath.EndsWith(".pj", [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "RV&S root project path is not a .pj path: $projectPath"
    }

    return $projectPath
}

function Get-NamedSubprojectPlan {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$SourceDirectories,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot,
        [Parameter(Mandatory = $true)]
        [string]$RootProjectPath
    )

    $lastSlashIndex = $RootProjectPath.LastIndexOf("/")
    if ($lastSlashIndex -lt 1) {
        throw "Unable to determine the RV&S root project directory from: $RootProjectPath"
    }
    $rootProjectDirectory = $RootProjectPath.Substring(0, $lastSlashIndex)

    foreach ($sourceDirectory in $SourceDirectories) {
        $relativePath = $sourceDirectory.RelativePath
        $relativeRvsPath = $relativePath.Replace("\", "/")
        $projectName = Split-Path -Path $relativePath -Leaf
        $parentRelativePath = Split-Path -Path $relativePath -Parent
        $parentProjectPath = if ([string]::IsNullOrWhiteSpace($parentRelativePath)) {
            $RootProjectPath
        }
        else {
            $parentName = Split-Path -Path $parentRelativePath -Leaf
            $parentRvsPath = $parentRelativePath.Replace("\", "/")
            "$rootProjectDirectory/$parentRvsPath/$parentName.pj"
        }

        [PSCustomObject]@{
            RelativePath = $relativePath
            RelativeProjectPath = "$relativeRvsPath/$projectName.pj"
            SandboxPath = Join-Path $SandboxRoot $relativePath
            ParentProjectPath = $parentProjectPath
            ProjectPath = "$rootProjectDirectory/$relativeRvsPath/$projectName.pj"
        }
    }
}

function Get-InitializerPlan {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$SourceInitFiles,
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$SubprojectPlan,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot,
        [Parameter(Mandatory = $true)]
        [string]$RootProjectPath
    )

    $subprojectsByRelativePath = @{}
    foreach ($subproject in $SubprojectPlan) {
        $subprojectsByRelativePath[$subproject.RelativePath] = $subproject
    }

    foreach ($sourceInitFile in $SourceInitFiles) {
        $parentRelativePath = Split-Path -Path $sourceInitFile.RelativePath -Parent
        if ([string]::IsNullOrWhiteSpace($parentRelativePath)) {
            $sandboxDirectory = $SandboxRoot
            $projectPath = $RootProjectPath
        }
        else {
            if (-not $subprojectsByRelativePath.ContainsKey($parentRelativePath)) {
                throw "No named subproject was planned for initializer directory: $parentRelativePath"
            }
            $subproject = $subprojectsByRelativePath[$parentRelativePath]
            $sandboxDirectory = $subproject.SandboxPath
            $projectPath = $subproject.ProjectPath
        }

        [PSCustomObject]@{
            SourcePath = $sourceInitFile.SourcePath
            RelativePath = $sourceInitFile.RelativePath
            SandboxPath = Join-Path $SandboxRoot $sourceInitFile.RelativePath
            SandboxDirectory = $sandboxDirectory
            ProjectPath = $projectPath
        }
    }
}

function Test-FileContentEqual {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FirstPath,
        [Parameter(Mandatory = $true)]
        [string]$SecondPath
    )

    $firstFile = Get-Item -LiteralPath $FirstPath -ErrorAction Stop
    $secondFile = Get-Item -LiteralPath $SecondPath -ErrorAction Stop
    if ($firstFile.Length -ne $secondFile.Length) {
        return $false
    }

    return (Get-FileHash -LiteralPath $FirstPath -Algorithm SHA256).Hash -eq `
        (Get-FileHash -LiteralPath $SecondPath -Algorithm SHA256).Hash
}

function Get-ExistingInitializerPaths {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$InitializerPlan,
        [Parameter(Mandatory = $true)]
        [string]$Executable
    )

    $existingInitializerPaths = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($initializer in $InitializerPlan) {
        $projectView = Invoke-SiQuery -Executable $Executable -Arguments @(
            "viewproject",
            "--batch",
            "--norecurse",
            "--fields=name,type,state,pendingcpid",
            "--project=$($initializer.ProjectPath)"
        )
        if ($projectView.ExitCode -ne 0) {
            throw "Unable to inspect initializer project '$($initializer.ProjectPath)'. Details: $($projectView.Text)"
        }

        foreach ($projectEntry in ($projectView.Text -split [Environment]::NewLine)) {
            $entry = $projectEntry.Trim()
            if ($entry -match "^__init__\.py\s+") {
                [void]$existingInitializerPaths.Add($initializer.RelativePath)
            }
            elseif (-not [string]::IsNullOrWhiteSpace($entry) -and $entry -notmatch "\.pj\s+subproject\b") {
                throw "Initializer project contains an unexpected file member: $($initializer.ProjectPath): $entry"
            }
        }
    }

    return $existingInitializerPaths
}

$directorySeparator = [System.IO.Path]::DirectorySeparatorChar
$resolvedSourceRoot = Resolve-DirectoryPath -Path $SourceRoot -Label "SourceRoot"
$repositoryRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).ProviderPath.TrimEnd(
    [char[]]@($directorySeparator)
)
if (
    $resolvedSourceRoot.Equals($repositoryRoot, [System.StringComparison]::OrdinalIgnoreCase) -or
    $resolvedSourceRoot.StartsWith($repositoryRoot + $directorySeparator, [System.StringComparison]::OrdinalIgnoreCase)
) {
    throw "SourceRoot must not be this upload-tool repository or one of its subdirectories: $repositoryRoot"
}
$sourcePrefix = $resolvedSourceRoot + $directorySeparator

$sandboxExists = Test-Path -LiteralPath $SandboxRoot
if ($sandboxExists -and -not (Test-Path -LiteralPath $SandboxRoot -PathType Container)) {
    throw "SandboxRoot is not a directory: $SandboxRoot"
}
$resolvedSandboxRoot = if ($sandboxExists) {
    (Resolve-Path -LiteralPath $SandboxRoot).ProviderPath.TrimEnd([char[]]@($directorySeparator))
}
else {
    [System.IO.Path]::GetFullPath($SandboxRoot).TrimEnd([char[]]@($directorySeparator))
}

$sourceDirectories = @(
    Get-ChildItem -LiteralPath $resolvedSourceRoot -Force -Recurse -Directory |
        ForEach-Object {
            [PSCustomObject]@{
                SourcePath = $_.FullName
                RelativePath = Get-RelativeSourcePath -FullName $_.FullName -SourcePrefix $sourcePrefix
            }
        } |
        Sort-Object @{ Expression = { $_.RelativePath.Length } }, RelativePath
)
$sourceInitFiles = @(
    Get-ChildItem -LiteralPath $resolvedSourceRoot -Force -Recurse -File -Filter "__init__.py" |
        ForEach-Object {
            [PSCustomObject]@{
                SourcePath = $_.FullName
                RelativePath = Get-RelativeSourcePath -FullName $_.FullName -SourcePrefix $sourcePrefix
            }
        } |
        Sort-Object RelativePath
)

$mode = if ($Apply) { "Apply" } elseif ($Preflight) { "Preflight" } else { "DryRun" }
$plan = [PSCustomObject]@{
    Mode = $mode
    SourceRoot = $resolvedSourceRoot
    SandboxRoot = $resolvedSandboxRoot
    PtcProject = $PtcProject
    CurrentWindowsUser = "$env:USERDOMAIN\$env:USERNAME"
    NamedSubprojectsToCreate = $sourceDirectories.Count
    InitializerFilesToAdd = $sourceInitFiles.Count
    NonInitializerFilesToAdd = 0
    NamingRule = "<directory>/<directory-name>.pj"
    ChangePackageId = $ChangePackageId
}

if (-not $Apply -and -not $Preflight) {
    $plan
    Write-Warning "Dry run only. Re-run with -Preflight to validate or -Apply to create named subprojects and add only __init__.py files."
    return
}

if (-not (Test-Path -LiteralPath $SiPath -PathType Leaf)) {
    throw "Windchill RV&S client was not found: $SiPath"
}

$sandboxInfo = Invoke-SiQuery -Executable $SiPath -Arguments @("sandboxinfo", "--batch", "--cwd=$resolvedSandboxRoot")
if ($sandboxInfo.ExitCode -ne 0) {
    throw "RV&S did not recognize the target as a sandbox. Details: $($sandboxInfo.Text)"
}
if ($sandboxInfo.Text -notmatch [regex]::Escape($PtcProject)) {
    throw "The existing RV&S sandbox does not match the configured PTC project target."
}
Write-Host "Reusing validated RV&S sandbox at $resolvedSandboxRoot"

if ([string]::IsNullOrWhiteSpace($ChangePackageId)) {
    throw "ChangePackageId is required. Supply an open RV&S change package ID."
}
$changePackageInfo = Invoke-SiQuery -Executable $SiPath -Arguments @(
    "viewcps", "--batch", "--cwd=$resolvedSandboxRoot", "--fields=id,state,summary", $ChangePackageId
)
$expectedOpenPackage = "(?m)^$([regex]::Escape($ChangePackageId))\s+.*\bOpen\b"
if ($changePackageInfo.ExitCode -ne 0 -or $changePackageInfo.Text -notmatch $expectedOpenPackage) {
    throw "ChangePackageId '$ChangePackageId' is not open. Details: $($changePackageInfo.Text)"
}
Write-Host "Using validated open RV&S change package $ChangePackageId"

$rootProjectPath = Get-RvsRootProjectPath -SandboxInfoText $sandboxInfo.Text
$subprojectPlan = @(Get-NamedSubprojectPlan `
    -SourceDirectories $sourceDirectories `
    -SandboxRoot $resolvedSandboxRoot `
    -RootProjectPath $rootProjectPath)
$initializerPlan = @(Get-InitializerPlan `
    -SourceInitFiles $sourceInitFiles `
    -SubprojectPlan $subprojectPlan `
    -SandboxRoot $resolvedSandboxRoot `
    -RootProjectPath $rootProjectPath)

$projectTree = Invoke-SiQuery -Executable $SiPath -Arguments @(
    "viewproject", "--batch", "--recurse", "--fields=indent,name,type,state,pendingcpid", "--cwd=$resolvedSandboxRoot"
)
if ($projectTree.ExitCode -ne 0) {
    throw "Unable to inspect the RV&S project tree. Details: $($projectTree.Text)"
}
$existingSubprojectPaths = [System.Collections.Generic.HashSet[string]]::new(
    [System.StringComparer]::OrdinalIgnoreCase
)
$projectDirectoriesByDepth = @{}
foreach ($projectEntry in ($projectTree.Text -split [Environment]::NewLine)) {
    $projectEntryMatch = [regex]::Match(
        $projectEntry,
        "^(?<Indent>\s*)(?<Path>.+?\.pj)\s+subproject\b",
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )
    if ($projectEntryMatch.Success) {
        $indentLength = $projectEntryMatch.Groups["Indent"].Value.Length
        if ($indentLength -lt 1 -or (($indentLength - 1) % 2) -ne 0) {
            throw "Unexpected RV&S project-tree indentation: $projectEntry"
        }

        $depth = [int](($indentLength - 1) / 2)
        $entryProjectPath = $projectEntryMatch.Groups["Path"].Value.Replace("\", "/")
        $fullProjectPath = if ($depth -eq 0) {
            $entryProjectPath
        }
        else {
            if (-not $projectDirectoriesByDepth.ContainsKey($depth - 1)) {
                throw "RV&S project-tree parent is missing for: $projectEntry"
            }
            "$($projectDirectoriesByDepth[$depth - 1])/$entryProjectPath"
        }

        $lastProjectSlash = $fullProjectPath.LastIndexOf("/")
        if ($lastProjectSlash -lt 1) {
            throw "Unable to determine the directory for RV&S subproject: $fullProjectPath"
        }
        $projectDirectoriesByDepth[$depth] = $fullProjectPath.Substring(0, $lastProjectSlash)
        foreach ($knownDepth in @($projectDirectoriesByDepth.Keys)) {
            if ($knownDepth -gt $depth) {
                $projectDirectoriesByDepth.Remove($knownDepth)
            }
        }

        [void]$existingSubprojectPaths.Add($fullProjectPath)
    }
}

$expectedSubprojectPaths = [System.Collections.Generic.HashSet[string]]::new(
    [System.StringComparer]::OrdinalIgnoreCase
)
foreach ($subproject in $subprojectPlan) {
    [void]$expectedSubprojectPaths.Add($subproject.RelativeProjectPath)
}

$unexpectedSubprojects = @(
    $existingSubprojectPaths |
        Where-Object { -not $expectedSubprojectPaths.Contains($_) } |
        Sort-Object
)
if ($unexpectedSubprojects.Count -gt 0) {
    $preview = ($unexpectedSubprojects | Select-Object -First 20) -join [Environment]::NewLine
    throw "PTC target contains unexpected subprojects. Refusing to create or upload into a mixed tree. First entries:$([Environment]::NewLine)$preview"
}
$subprojectsToCreate = @(
    $subprojectPlan |
        Where-Object { -not $existingSubprojectPaths.Contains($_.RelativeProjectPath) }
)

$localFiles = @(Get-ChildItem -LiteralPath $resolvedSandboxRoot -Force -Recurse -File)
$expectedInitializerPaths = [System.Collections.Generic.HashSet[string]]::new(
    [System.StringComparer]::OrdinalIgnoreCase
)
foreach ($initializer in $initializerPlan) {
    [void]$expectedInitializerPaths.Add($initializer.SandboxPath)
}
$unexpectedLocalFiles = @(
    $localFiles |
        Where-Object { -not $expectedInitializerPaths.Contains($_.FullName) }
)
if ($unexpectedLocalFiles.Count -gt 0) {
    $preview = ($unexpectedLocalFiles | Select-Object -First 20 -ExpandProperty FullName) -join [Environment]::NewLine
    throw "Sandbox contains files outside the initializer-only plan. First files:$([Environment]::NewLine)$preview"
}

$stagedInitializers = 0
foreach ($initializer in $initializerPlan) {
    if (Test-Path -LiteralPath $initializer.SandboxPath -PathType Leaf) {
        if (-not (Test-FileContentEqual -FirstPath $initializer.SourcePath -SecondPath $initializer.SandboxPath)) {
            throw "Staged initializer differs from the U171 source file: $($initializer.RelativePath)"
        }
        $stagedInitializers++
    }
}
$existingInitializerPaths = Get-ExistingInitializerPaths `
    -InitializerPlan $initializerPlan `
    -Executable $SiPath
$initializersToAdd = @(
    $initializerPlan |
        Where-Object { -not $existingInitializerPaths.Contains($_.RelativePath) }
)

$plan | Add-Member -NotePropertyName RootProjectPath -NotePropertyValue $rootProjectPath
$plan | Add-Member -NotePropertyName ExistingNamedSubprojects -NotePropertyValue $existingSubprojectPaths.Count
$plan | Add-Member -NotePropertyName NamedSubprojectsRemaining -NotePropertyValue $subprojectsToCreate.Count
$plan | Add-Member -NotePropertyName InitializerFilesAlreadyStaged -NotePropertyValue $stagedInitializers
$plan | Add-Member -NotePropertyName InitializerFilesAlreadyAdded -NotePropertyValue $existingInitializerPaths.Count
$plan | Add-Member -NotePropertyName InitializerFilesRemaining -NotePropertyValue $initializersToAdd.Count
$plan

if ($ManifestPath) {
    $manifest = [PSCustomObject]@{
        GeneratedAtUtc = [DateTime]::UtcNow.ToString("o")
        Plan = $plan
        Subprojects = $subprojectPlan | Select-Object RelativePath, RelativeProjectPath, ParentProjectPath, ProjectPath
        Initializers = $initializerPlan | Select-Object RelativePath, ProjectPath
    }
    $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $ManifestPath -Encoding utf8
}

if ($Preflight) {
    [PSCustomObject]@{
        Result = "PTC named-subproject preflight passed"
        SandboxRoot = $resolvedSandboxRoot
        RootProjectPath = $rootProjectPath
        ExistingNamedSubprojects = $existingSubprojectPaths.Count
        NamedSubprojectsRemaining = $subprojectsToCreate.Count
        InitializerFilesToAdd = $initializerPlan.Count
        InitializerFilesAlreadyStaged = $stagedInitializers
        InitializerFilesAlreadyAdded = $existingInitializerPaths.Count
        InitializerFilesRemaining = $initializersToAdd.Count
        NonInitializerFilesToAdd = 0
        ChangePackageId = $ChangePackageId
        ReadyToApply = $true
    }
    return
}

foreach ($subproject in $subprojectsToCreate) {
    if (-not (Test-Path -LiteralPath $subproject.SandboxPath -PathType Container)) {
        New-Item -ItemType Directory -Path $subproject.SandboxPath -ErrorAction Stop | Out-Null
    }
}

foreach ($subproject in $subprojectsToCreate) {
    Invoke-SiCommand -Executable $SiPath -Arguments @(
        "createsubproject",
        "--project=$($subproject.ParentProjectPath)",
        "--changePackageId=$ChangePackageId",
        "--nocloseCP",
        "--nocreateSubprojects",
        "--failOnAmbiguousProject",
        "--batch",
        "--yes",
        "--cwd=$resolvedSandboxRoot",
        $subproject.ProjectPath
    )
}

foreach ($initializer in $initializerPlan) {
    if (-not (Test-Path -LiteralPath $initializer.SandboxPath -PathType Leaf)) {
        Copy-Item -LiteralPath $initializer.SourcePath -Destination $initializer.SandboxPath -ErrorAction Stop
    }
}

foreach ($initializer in $initializersToAdd) {
    Invoke-SiCommand -Executable $SiPath -Arguments @(
        "add",
        "--changePackageId=$ChangePackageId",
        "--nocloseCP",
        "--nocreateSubprojects",
        "--nocreateSubprojectsForEmptyDirectories",
        "--failOnAmbiguousProject",
        "--onExistingArchive=newarchive",
        "--onExistingOutOfTreeArchive=newarchive",
        "--description=$Description",
        "--batch",
        "--yes",
        "--cwd=$($initializer.SandboxDirectory)",
        "__init__.py"
    )
}

[PSCustomObject]@{
    Result = "PTC named subproject and initializer upload completed"
    SandboxRoot = $resolvedSandboxRoot
    RootProjectPath = $rootProjectPath
    NamedSubprojectsCreated = $subprojectsToCreate.Count
    NamedSubprojectsAlreadyPresent = $existingSubprojectPaths.Count
    InitializerFilesCopied = $initializerPlan.Count
    InitializerFilesAlreadyAdded = $existingInitializerPaths.Count
    InitializerFilesAdded = $initializersToAdd.Count
    NonInitializerFilesAdded = 0
    ChangePackageId = $ChangePackageId
}