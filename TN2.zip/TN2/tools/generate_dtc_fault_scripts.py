"""Generate one Fault_List script per DTC for every project, a runner, and the scripts kept for review.

Author: Kris

The DTCs are the common EV / ICE DTC list in each project's config/fault_list_config.py
(COMMON_FAULT_LIST, filtered by VEHICLE_TYPE). At generation time the module configs that own the bench
hardware (squibs_config, rsu_config, gpo_config, dcs_config, canc_config) are read only to decide whether
this project can create the fault and which device does it; the scripts read every value from those
configs and from fault_list_config at run time: no configuration value is written into a script. The
device of a DTC (squib, RSU channel, GPO output, buckle channel, CAN frame / signal) is looked up in its
config from the DTC itself when the script runs; the generator runs those lookups against the config and
stops when they do not find the device it chose. A device bound through canc_config names of its COMMON
... STRUCTURE block (reference values copied from another project) stays in review.

Each script: bench fault free, create the fault, DTC active within the mature time with the warning lamp
as the DTC list says, remove the fault, DTC healed within the demature time (or latched until the next
IGN cycle) with the lamp OFF, then IGN cycles (PS.IGN_OFF / PS.IGN_ON): historic after the first, still
stored after ageing_cycles - 1, aged out (cleared) after ageing_cycles, lamp OFF throughout.

A DTC goes to review when its fault cannot be created with certainty: no recipe in the agent_sc3.md
section 25.5 catalog, no binding in the project's config, an NVM write or a crash, or a workbook conflict
on its set condition. A review script keeps the whole check flow; where the bench binding is known the
fault step is complete, otherwise it is left to fill in and the script stops there.

Output per project, in projects/<P>/modules/Fault_List/scripts/:
    dtc/DTC_<DTC>_<MNEMONIC>.py           scripts whose fault the bench can create
    dtc/run_dtc_fault_list.py             runner over them
    dtc_review/DTC_<DTC>_<MNEMONIC>.py    scripts kept for review
    dtc_review/DTC_SCRIPTS_REVIEW.md      why each one is in review

    py -3.14 tools/generate_dtc_fault_scripts.py                   # every project
    py -3.14 tools/generate_dtc_fault_scripts.py --project U171    # one project (repeatable)
    py -3.14 tools/generate_dtc_fault_scripts.py --check           # compare, write nothing

Run tools/build_common_dtc_dictionary.py and tools/build_m310_fault_list_config.py first.
"""
from __future__ import annotations

import argparse
import importlib
import os
import re
import sys
import textwrap
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_common_dtc_dictionary as common  # noqa: E402  (tools/ is not a package)

SCRIPT_DIR = "dtc"
REVIEW_DIR = "dtc_review"
RUNNER = "run_dtc_fault_list.py"
REVIEW_MD = "DTC_SCRIPTS_REVIEW.md"

# Workbook conflicts (DTC_LIST_CONFLICTS.md) that leave the fault recipe uncertain.
CONFLICT_REASONS = {
    "foreign_set": "the DTC list's set condition describes another fault",
    "heal_same": "the DTC list's heal condition uses the same comparison as its set condition",
    "crash_word": "the DTC list's set condition names another crash",
    "config_open": "the DTC list's set condition reads like an open circuit",
    "no_set": "the DTC list gives no set condition",
    "duplicate_fault": "another DTC of the DTC list describes the same fault",
    "ev_flag": "the EV list leaves its M312/M112/W613/M314 applicability cell blank",
}

SQUIB_LOAD = {"OPEN": "Open", "LOW_RES": "LoRes", "HIGH_RES": "HiRes", "STB": "S2B", "STG": "S2G",
              "CROSS_CONNECT": "CrossConnect"}
SQUIB_LEAK = {"STB": ("SetLeakageVBATBusHigh", "ClearLeakageVBATBusHigh", "VBAT to bus high"),
              "STG": ("SetLeakageGNDBusLow", "ClearLeakageGNDBusLow", "GND to bus low")}
RSU_FAULT = {"OPEN": ("Open", "SetFaultOpen", "OPEN-NC", "an open circuit"),
             "STG": ("S2G", "SetFaultShortGround", "STG", "a short to ground"),
             "STB": ("S2B", "SetFaultShortBattery", "STB", "a short to battery")}
GPO_FAULT = {"OPEN": ("OPEN", "Open", "an open circuit"), "STB": ("S2B", "S2B", "a short to battery"),
             "STG": ("S2G", "S2G", "a short to ground")}
CAN_MODE = {"NODE_ABSENT": "node_absent", "MESSAGE_TIMEOUT": "message_timeout",
            "MESSAGE_CONTENT": "message_content", "SIGNAL_CONTENT": "signal_content"}
FAULT_WORDS = {"OPEN": "an open circuit", "LOW_RES": "a low resistance", "HIGH_RES": "a high resistance",
               "STB": "a short to battery", "STG": "a short to ground", "CROSS_CONNECT": "a cross connection"}


def norm(code) -> str:
    """'0x92 0x0a' -> '0x92 0x0A' (the form the configs and the ECU answer use)."""
    return " ".join(token.upper().replace("0X", "0x") for token in str(code).split())


def dtc_bytes(dtc_hex: str) -> list[str]:
    return [f"0x{dtc_hex[index:index + 2]}" for index in (2, 4, 6)]


def join(*pieces: str) -> str:
    """Code blocks, each dedented on its own, one after the other."""
    return "\n".join(textwrap.dedent(piece).strip("\n") for piece in pieces if piece and piece.strip())


class Body:
    def __init__(self):
        self.lines: list[str] = []

    def add(self, indent: int, text: str):
        for line in textwrap.dedent(text).strip("\n").splitlines():
            self.lines.append(" " * indent + line if line.strip() else "")

    def text(self) -> str:
        return "\n".join(self.lines)


# ---------------------------------------------------------------------------
# Common data and project configs
# ---------------------------------------------------------------------------

def common_data():
    dictionary, _, conflicts = common.build()
    faults, _, shared = common.build_fault_list(dictionary)
    for keys in shared.values():
        for key in keys:
            for variant in dictionary[key]["source"]:
                conflicts.append({"category": "duplicate_fault", "dtc": key, "variant": variant})
    meta = {}
    for name, fields in faults:
        key = fields["short_notation"].replace("-", "")
        entry = dictionary[key]
        description = entry["description"] if isinstance(entry["description"], str) else entry["description"]["ICE"]
        group, kind = common.classify(key, description)
        meta[name] = {"key": key, "group": group, "kind": kind, "description": description,
                      "method": entry["how_to_create"]["bench_method"],
                      "source": entry["how_to_create"]["recipe_source"]}
    issues = {}
    for item in conflicts:
        issues.setdefault((item["dtc"], item["variant"]), set()).add(item["category"])
    return meta, issues


def project_modules(project: str) -> dict:
    os.environ["IOEM_FRAMEWORK_PROJECT"] = project
    modules = {}
    for name in ("fault_list_config", "canc_config", "squibs_config", "rsu_config", "gpo_config", "dcs_config",
                 "power_config", "project_config"):
        try:
            modules[name] = importlib.import_module(f"Framework_IOEM_Py.projects.{project}.config.{name}")
        except Exception as error:  # a missing module only means the project cannot bind those faults
            modules[name] = None
            if name == "fault_list_config":
                raise SystemExit(f"{project}: config/fault_list_config.py does not import: {error}")
    modules["placeholders"], modules["placeholder_source"] = placeholder_names(project)
    flc = modules["fault_list_config"]
    for name in ("COMMON_FAULT_LIST", "VEHICLE_TYPE", "IGN_OFF_TIME_MS", "LAMP_POLL_INTERVAL_MS",
                 "FAULT_TIME_MEASUREMENT_LAG_MS"):
        if not hasattr(flc, name):
            raise SystemExit(f"{project}: fault_list_config has no {name} - run tools/build_common_dtc_dictionary.py "
                             f"(and tools/build_m310_fault_list_config.py) first")
    return modules


def attr(module, name, default=None):
    return getattr(module, name, default) if module is not None else default


PLACEHOLDER_START = re.compile(r"^# === COMMON CANC_CONFIG STRUCTURE \(added from (.+?)\) ===", re.M)
PLACEHOLDER_END = "# === END COMMON CANC_CONFIG STRUCTURE ==="


def placeholder_names(project: str) -> tuple[set[str], str | None]:
    """Names canc_config defines in its COMMON CANC_CONFIG STRUCTURE block, and where they were copied from.

    The block holds another project's values until this project's own DBC arrives, so a fault bound
    through them is not certain.
    """
    path = ROOT / "projects" / project / "config" / "canc_config.py"
    text = path.read_text(encoding="utf-8") if path.is_file() else ""
    match = PLACEHOLDER_START.search(text)
    if not match:
        return set(), None
    end = text.find(PLACEHOLDER_END, match.end())
    block = text[match.end():end if end >= 0 else len(text)]
    names = set(re.findall(r"^([A-Za-z_]\w*)\s*(?::[^=\n]*)?=", block, re.M))
    return names | set(re.findall(r"^def (\w+)", block, re.M)), match.group(1)


def lamp_key(mods: dict) -> tuple[str | None, str | None]:
    """Key of the warning lamp in CAN_SIGNAL_Rx_MAP, or None and the reason.

    The scripts index the lamp maps with project_config ACTIVE_CAN_VARIANT, so the key must be that.
    """
    canc = mods["canc_config"]
    rx, channels, values = attr(canc, "CAN_SIGNAL_Rx_MAP", {}), attr(canc, "CAN_CRASH_FRAME_CHANNEL_MAP", {}), \
        attr(canc, "Signal_Value_2C0", {})
    keys = [key for key, signals in rx.items()
            if "INDC_SRS" in signals and signals["INDC_SRS"][0] in channels.get(key, {})]
    if not (len(keys) == 1 and {"ON", "OFF"} <= set(values)):
        return None, ("canc_config has no warning lamp signal (CAN_SIGNAL_Rx_MAP INDC_SRS with its bus in "
                      "CAN_CRASH_FRAME_CHANNEL_MAP and ON / OFF in Signal_Value_2C0)")
    copied = {"CAN_SIGNAL_Rx_MAP", "CAN_CRASH_FRAME_CHANNEL_MAP", "Signal_Value_2C0"} & mods["placeholders"]
    if copied:
        return None, (f"canc_config {', '.join(sorted(copied))} are {mods['placeholder_source']} reference values "
                      f"(no DBC for this project yet)")
    variant = attr(mods["project_config"], "ACTIVE_CAN_VARIANT")
    if keys[0] != variant:
        return None, (f"canc_config CAN_SIGNAL_Rx_MAP is keyed {keys[0]!r} but project_config ACTIVE_CAN_VARIANT "
                      f"is {variant!r}")
    return keys[0], None


# ---------------------------------------------------------------------------
# Plan: how this project creates the fault (or why it cannot)
# ---------------------------------------------------------------------------

def plan_for(mods: dict, fault: dict, meta: dict, lamp: str | None, issues: dict) -> dict:
    key, group, kind = meta["key"], meta["group"], meta["kind"]
    reasons, notes = [], []
    vehicle = mods["fault_list_config"].VEHICLE_TYPE
    for category in sorted(issues.get((key, vehicle), ())):
        if category in CONFLICT_REASONS:
            reasons.append(CONFLICT_REASONS[category] + " (DTC_LIST_CONFLICTS.md)")
    if lamp is None:
        reasons.append(mods["lamp_reason"])
    if fault["warning_lamp"] not in ("ON", "OFF"):
        reasons.append(f"the DTC list gives the warning lamp as {fault['warning_lamp']!r}, not ON or OFF")
    if not isinstance(fault["ageing_cycles"], int) or fault["ageing_cycles"] < 2:
        reasons.append("the DTC list gives no ageing cycle count")
    pcfg = mods["project_config"]
    if not (attr(pcfg, "DEFAULT_EOL_CODE") and attr(pcfg, "DEFAULT_VARIANT_CODE")):
        reasons.append("project_config has no DEFAULT_EOL_CODE / DEFAULT_VARIANT_CODE for fault_free_profile()")

    binding = None
    if group == "SQUIB":
        binding = squib_plan(mods, fault, kind, reasons, notes)
    elif group == "RSU":
        binding = rsu_plan(mods, fault, kind, reasons, notes)
    elif group == "OUTPUT":
        binding = gpo_plan(mods, fault, kind, reasons, notes)
    elif group == "DCS":
        binding = dcs_plan(mods, fault, kind, reasons, notes)
    elif group == "CAN":
        binding = can_plan(mods, fault, kind, reasons, notes)
    elif group in ("ODS", "STPS"):
        reasons.append(f"no per-DTC binding for {common.GROUP[group]} channels: the project config gives no "
                       f"DTC-to-channel map with fault and rest loads for it")
    elif group == "POWER":
        reasons.append("the under / over-voltage test levels (workbook: below 9 V / above 16 V) are not in "
                       "power_config")
    elif group == "CRASH":
        reasons.append("needs a crash at T0: the lock is permanent, never run uninvited (agent_sc3.md §23)")
    elif group == "PAB_SWITCH":
        reasons.append("no PAB-switch fault recipe in the framework (resistance-coded SLS input)")
    else:
        reasons.append("no fault recipe: " + meta["method"])
    if binding is not None:
        # Any canc_config name the script reads from the COMMON ... STRUCTURE block is another project's value.
        copied = set(family_parts(binding)["imports"].get("canc_config", [])) & mods["placeholders"]
        if copied:
            reasons.append(f"canc_config {', '.join(sorted(copied))} are {mods['placeholder_source']} reference "
                           f"values (no DBC for this project yet)")
    return {"binding": binding, "reasons": list(dict.fromkeys(reasons)), "notes": notes}


def config_dtc(code, ftb: str) -> str:
    return f"{norm(code)} 0x{ftb}"


def heal_shape(fault: dict, reasons: list[str]) -> str | None:
    if fault["mature_time_ms"] is None:
        reasons.append(f"no plain mature time in the DTC list ({fault['mature_time']!r})")
    if isinstance(fault["demature_time_ms"], (int, float)):
        return "timed"
    if str(fault["demature_time"]).strip().upper() == "1 IGN CYCLE":
        return "latched"
    reasons.append(f"no plain demature time in the DTC list ({fault['demature_time']!r})")
    return None


def squib_plan(mods, fault, kind, reasons, notes):
    sq = mods["squibs_config"]
    squib_numbers = attr(sq, "SquibNumber", {})
    codes, active = attr(sq, "DTC_Squib_FaultCode", {}), list(attr(sq, "ActiveSquibName", []) or [])
    descriptions, types = attr(sq, "Squib_Fault_Description", {}), attr(sq, "Squib_FaultTypeCode", {})
    two = " ".join(dtc_bytes(fault["dtc_hex"])[:2])
    if kind == "UNEXPECTED_SQUIB":
        reasons.append("unexpected squib needs an EOL write marking the loop not fitted (NVM - agent_sc3.md §23)")
        return None
    if kind not in SQUIB_LOAD:
        reasons.append(f"no squib recipe for {kind}")
        return None
    squibs = [squib for squib, code in codes.items() if code and norm(code) == two]
    if len(squibs) != 1:
        reasons.append(f"squibs_config.DTC_Squib_FaultCode has {'no squib' if not squibs else 'several squibs'} "
                       f"with {two}")
        return None
    squib, load = squibs[0], SQUIB_LOAD[kind]
    if squib not in active or squib not in squib_numbers:
        reasons.append(f"squib {squib} is not an active loop of squibs_config (ActiveSquibName / SquibNumber)")
        return None
    if load not in descriptions or "NoFault" not in descriptions:
        reasons.append(f"squibs_config.Squib_Fault_Description has no {load!r} / 'NoFault' load")
        return None
    if norm(types.get(load, "")) != f"0x{fault['ftb'][2:]}":
        reasons.append(f"squibs_config.Squib_FaultTypeCode[{load!r}] = {types.get(load)!r}, the DTC's FTB is "
                       f"{fault['ftb']}")
        return None
    shape = heal_shape(fault, reasons)
    binding = {"family": "SQUIB", "squib": squib, "load": load, "kind": kind, "shape": shape}
    if kind == "CROSS_CONNECT":
        order = active[active.index(squib) + 1:] + active[:active.index(squib)]
        partner = next((other for other in order if codes.get(other)), None)
        if partner is None:
            reasons.append("no second active squib with a DTC for the cross connection")
            return None
        binding.update(family="SQUIB_XCONN", partner=partner)
        notes.append(f"Cross connection with the next active loop {partner}; its cross-connect DTC is expected "
                     f"too (squibs_config DTC_Squib_FaultCode + Squib_FaultTypeCode['CrossConnect']).")
    return binding


def rsu_plan(mods, fault, kind, reasons, notes):
    rs = mods["rsu_config"]
    codes, types = attr(rs, "DTC_RSU_fault", {}), attr(rs, "rsu_fault_code", {})
    two = " ".join(dtc_bytes(fault["dtc_hex"])[:2])
    if kind not in RSU_FAULT:
        reasons.append({"COMM_ERROR": "the DTC list sets it with a wrong serial number; the bench precedent is a "
                                      "PSI5 parity error (RSU.SetFaultParity) - confirm which one the ECU reports",
                        "INTERNAL": "the RSU internal fault (saturation through RSU.SetAcceleration) is an open item",
                        "CONFIG_ERROR": "needs an EOL write marking the satellite not fitted (NVM - agent_sc3.md §23)"
                        }.get(kind, f"no RSU recipe for {common.FAULT_TYPE[kind].lower()} in the §25.5 catalog"))
        return None
    channels = [channel for channel, code in codes.items() if norm(code) == two]
    if not channels:
        reasons.append(f"rsu_config.DTC_RSU_fault has no channel with {two}")
        return None
    type_key = RSU_FAULT[kind][0]
    if norm(types.get(type_key, "")) != f"0x{fault['ftb'][2:]}":
        reasons.append(f"rsu_config.rsu_fault_code[{type_key!r}] = {types.get(type_key)!r}, the DTC's FTB is "
                       f"{fault['ftb']}")
        return None
    if len(channels) > 1:
        notes.append(f"rsu_config.DTC_RSU_fault gives this satellite the channels {', '.join(channels)}; the "
                     f"fault goes on {channels[0]}.")
    return {"family": "RSU", "channel": channels[0], "kind": kind, "shape": heal_shape(fault, reasons)}


def gpo_plan(mods, fault, kind, reasons, notes):
    gp = mods["gpo_config"]
    codes, names, descriptions = attr(gp, "DTC_GPO_fault", {}), attr(gp, "GPO_Names", []), \
        attr(gp, "GPO_FaultDescription", None)
    two = " ".join(dtc_bytes(fault["dtc_hex"])[:2])
    if kind == "CONFIG_ERROR":
        reasons.append("needs an EOL write marking the output not fitted (NVM - agent_sc3.md §23)")
        return None
    if kind not in GPO_FAULT:
        reasons.append(f"no output recipe for {common.FAULT_TYPE[kind].lower()}")
        return None
    outputs = [output for output, code in codes.items() if norm(code) == two]
    if len(outputs) != 1:
        reasons.append(f"gpo_config.DTC_GPO_fault has no output with {two} (it maps "
                       + ", ".join(f"{o} {c}" for o, c in codes.items()) + ")" if not outputs
                       else f"gpo_config.DTC_GPO_fault has several outputs with {two}")
        return None
    output = outputs[0]
    if not any(gpo.upper().removesuffix("_LAMP") == output for gpo in names):
        reasons.append(f"gpo_config.GPO_Names has no output {output}")
        return None
    if not descriptions or GPO_FAULT[kind][1] not in descriptions or "NoFault" not in descriptions:
        reasons.append(f"gpo_config has no GPO_FaultDescription[{GPO_FAULT[kind][1]!r}] / ['NoFault'] to check the "
                       f"relay answer")
        return None
    return {"family": "GPO", "output": output, "kind": kind, "shape": heal_shape(fault, reasons)}


def dcs_plan(mods, fault, kind, reasons, notes):
    dc, canc = mods["dcs_config"], mods["canc_config"]
    two = " ".join(dtc_bytes(fault["dtc_hex"])[:2])
    channels_by_name = attr(dc, "DCSName", {})
    types = attr(dc, "DCS_FaultTypeCode", {})
    if attr(canc, "CANC_DCS_FAULT_LOAD") is None or "unbuckle" not in attr(dc, "DCS_Fault_Description", {}):
        reasons.append("canc_config has no CANC_DCS_FAULT_LOAD (the DCS-card fault preset) or dcs_config no "
                       "'unbuckle' rest load")
        return None
    if kind == "STB":
        channels = [ch for ch, code in attr(dc, "DTC_DCS_fault", {}).items()
                    if ch in channels_by_name and norm(code) == two]
        type_key = "S2B"
    elif kind == "CROSS_CONNECT":
        channels = [ch for ch, code in attr(dc, "DTC_DCS_CC_fault", {}).items()
                    if ch in channels_by_name and norm(code) == two]
        type_key = "CrossConnect"
    else:
        reasons.append(f"no buckle recipe for {common.FAULT_TYPE[kind].lower()}")
        return None
    if len(channels) != 1:
        reasons.append(f"dcs_config has {'no' if not channels else 'several'} buckle channel(s) with {two}")
        return None
    if norm(types.get(type_key, "")) != f"0x{fault['ftb'][2:]}":
        reasons.append(f"dcs_config.DCS_FaultTypeCode[{type_key!r}] = {types.get(type_key)!r}, the DTC's FTB is "
                       f"{fault['ftb']}")
        return None
    binding = {"family": "DCS", "channel": channels[0], "kind": kind, "shape": heal_shape(fault, reasons)}
    if kind == "CROSS_CONNECT":
        belt_of = {channel: signal for signal, channel in attr(canc, "CANC_BELT_CHANNEL", {}).items()}
        partner_signal = attr(canc, "CANC_BELT_CROSS_CONNECT_PARTNER", {}).get(belt_of.get(channels[0]))
        partner = attr(canc, "CANC_BELT_CHANNEL", {}).get(partner_signal)
        if partner not in attr(dc, "DTC_DCS_CC_fault", {}):
            reasons.append(f"no cross-connect partner with a DTC for {channels[0]} (canc_config "
                           f"CANC_BELT_CROSS_CONNECT_PARTNER / dcs_config DTC_DCS_CC_fault)")
            return None
        binding.update(family="DCS_XCONN", partner=partner)
        notes.append(f"Cross connection with {partner} (canc_config CANC_BELT_CROSS_CONNECT_PARTNER); its "
                     f"cross-connect DTC is expected too.")
    return binding


def can_plan(mods, fault, kind, reasons, notes):
    canc = mods["canc_config"]
    if kind not in CAN_MODE:
        reasons.append({"BUS_OFF": "CAN bus-off has no clean wrapper (agent_sc3.md §25.5 #18)",
                        "VIN_MISMATCH": "the DTC list gives four ways to set it; the VIN frame / signal binding is "
                                        "not configured for a single recipe",
                        "VARIANT_CODE": "Create_Variant_code_error() is a UDS NVM write with a hard-coded payload "
                                        "(agent_sc3.md §23)",
                        "FEATURE_CODE": "no recipe for the feature code error"}.get(kind, f"no CAN recipe for {kind}"))
        return None
    needed = ("CAN_TX_MESSAGE_CONFIG", "MAH_CAN_SIGNAL_DEFS", "qualification_ms", "recovery_ms", "is_key_message",
              "get_message_content_failure_dtcs")
    missing = [name for name in needed if attr(canc, name) is None]
    if missing:
        reasons.append("canc_config has no " + ", ".join(missing))
        return None
    copied = set(needed) & mods["placeholders"]
    if copied:
        reasons.append(f"canc_config {', '.join(sorted(copied))} are {mods['placeholder_source']} reference values "
                       f"(no DBC for this project yet)")
        return None
    config, defs = canc.CAN_TX_MESSAGE_CONFIG, canc.MAH_CAN_SIGNAL_DEFS
    dtc = norm(" ".join(dtc_bytes(fault["dtc_hex"])))

    def frame_def(frame):
        return next((d for d in defs.values() if d.get("frame") == frame and d.get("periodicity")), None)

    mode = CAN_MODE[kind]
    candidates = []
    if kind == "NODE_ABSENT":
        frames = [f for f, e in config.items() if e.get("node_absent_dtc") and norm(e["node_absent_dtc"]) == dtc]
        nodes = {config[f].get("key_node") for f in frames}
        candidates = [(f, None) for f in frames if canc.is_key_message(f)
                      or len([g for g in config if config[g].get("key_node") in nodes]) == 1]
    elif kind == "MESSAGE_TIMEOUT":
        candidates = [(f, None) for f, e in config.items() if e.get("message_timeout_dtc")
                      and norm(e["message_timeout_dtc"]) == dtc and not canc.is_key_message(f)]
    elif kind == "MESSAGE_CONTENT":
        pairs = [(f, s) for f in config for s, d in canc.get_message_content_failure_dtcs(f).items() if norm(d) == dtc]
        candidates = sorted(pairs, key=lambda pair: "CRC" not in pair[1].upper())
        candidates = [(f, s) for f, s in candidates if defs.get(s, {}).get("signal")]
    else:
        candidates = [(f, s) for f, e in config.items() for s, d in (e.get("signal_content_failure_dtcs") or {}).items()
                      if norm(d) == dtc]
    if not candidates:
        field = {"NODE_ABSENT": "node_absent_dtc", "MESSAGE_TIMEOUT": "message_timeout_dtc"}.get(kind)
        if field:
            own = {norm(e[field]) for e in config.values() if e.get(field)}
        elif kind == "MESSAGE_CONTENT":
            own = {norm(d) for f in config for d in canc.get_message_content_failure_dtcs(f).values()}
        else:
            own = {norm(d) for e in config.values() for d in (e.get("signal_content_failure_dtcs") or {}).values()}
        reasons.append(f"canc_config has no {mode.replace('_', ' ')} DTC {dtc} (its own: "
                       + (", ".join(sorted(own)[:8]) + (" ..." if len(own) > 8 else "") if own else "none") + ")")
        return None
    candidates = [(f, s) for f, s in candidates if frame_def(f)]
    if kind == "MESSAGE_TIMEOUT":
        candidates = [(f, s) for f, s in candidates
                      if any(d.get("frame") == f and d.get("periodicity")
                             and not str(d.get("signal")).upper().startswith("RESERVED") for d in defs.values())]
    if not candidates:
        reasons.append(f"canc_config gives {dtc} only to frames without a MAH_CAN_SIGNAL_DEFS period")
        return None
    frame, signal = candidates[0]
    node = config[frame].get("key_node")
    if node in ("E_CALL", "OCS"):
        reasons.append(f"the {node} frames need their variant-code bit set first (open item)")
    if kind == "SIGNAL_CONTENT":
        sdef = next((k for k, d in defs.items() if d.get("frame") == frame and d.get("signal") == signal), None)
        if sdef is None or defs[sdef].get("Invalid_Value") is None:
            reasons.append(f"MAH_CAN_SIGNAL_DEFS gives {signal} in {frame} no Invalid_Value")
            return None
        if defs[sdef].get("SCF_Recovery_Value") is None and defs[sdef].get("Default_Value") is None:
            reasons.append(f"MAH_CAN_SIGNAL_DEFS gives {signal} in {frame} no recovery / default value")
            return None
        signal = sdef
    named, bound = named_in_list(fault, kind), {"NODE_ABSENT": node, "MESSAGE_TIMEOUT": node,
                                                "MESSAGE_CONTENT": frame}.get(kind)
    if kind == "SIGNAL_CONTENT":
        bound = defs[signal]["signal"]

    def squash(text):
        return "".join(ch for ch in str(text).upper() if ch.isalnum())

    if named and bound and squash(named) not in squash(bound):
        what = (f"node {node}" if kind in ("NODE_ABSENT", "MESSAGE_TIMEOUT")
                else f"signal {bound}" if kind == "SIGNAL_CONTENT" else "frame")
        notes.append(f"canc_config binds this DTC to {frame} ({what}); the DTC list names it {named}.")
    if len(candidates) > 1:
        notes.append(f"canc_config gives this DTC to {len(candidates)} frame / signal pairs; the script uses "
                     f"{frame}" + (f" / {signal}" if signal else "") + ".")
    return {"family": "CAN", "kind": kind, "mode": mode, "frame": frame, "signal": signal, "shape": "can",
            "graded": attr(canc, "CAN_FAULT_TIMING_TOLERANCE_PERCENT") is not None}


def named_in_list(fault, kind) -> str | None:
    """The node, frame or signal the DTC list's description names (first word / text before 'signal')."""
    text = fault["description"] if isinstance(fault["description"], str) else ""
    if kind == "SIGNAL_CONTENT":
        words = text.lower().split(" signal")[0]
        return words.upper().replace(" ", "_") if words else None
    return text.split()[0].split("(")[0] if text else None


# ---------------------------------------------------------------------------
# Script text
# ---------------------------------------------------------------------------

POLL = """
    poll_started = time.monotonic()
    while True:
        poll_text = str(CAN.GetSignalFromFrame(lamp_bus, lamp_frame, lamp_signal)).strip()
        try:
            poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
        except ValueError:
            poll_value = poll_text
        poll_seconds = time.monotonic() - poll_started
        if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
            break
        time.sleep(LAMP_POLL_INTERVAL_MS / 1000)
    RESULT.InterpretEqualResult(f"{poll_label}: {lamp_frame} {lamp_signal} (read for {poll_seconds:.1f} s)",
                                str(poll_value), str(poll_expected))
"""


def lamp_check(body: Body, indent: int, expected: str, label: str):
    body.add(indent, f"poll_expected = {expected}\npoll_label = {label}")
    body.add(indent, POLL)


def read_dtc(body: Body, indent: int, label: str, status: str):
    body.add(indent, f"""
        Read_DTC({label!r},
                 " ".join([read_resp] + [f"{{dtc}} {{{status}}}" for dtc in fault_dtcs]),
                 read_req)
    """)


def measure_and_grade(body: Body, indent: int, var: str, status: str, nominal: str, what: str, graded: bool,
                      why: str):
    body.add(indent, f'{var} = faultTimeMeasurement(";".join(f"{{dtc}} {{{status}}}" for dtc in fault_dtcs))')
    if graded:
        body.add(indent, f"""
            tolerance_ms = {nominal} * tolerance_percent / 100
            lower_ms = {nominal} - tolerance_ms
            upper_ms = {nominal} + tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"{what} of {{timed_dtcs}}: expected {{{nominal}:g}} ms, limits {{lower_ms:g}} ms "
                                 f"(-{{tolerance_percent:g}} %) to {{upper_ms:g}} ms (+{{tolerance_percent:g}} % and "
                                 f"the {{measurement_lag_ms}} ms measurement lag)")
            fault_time_check({var}, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
        """)
    else:
        body.add(indent, f'RESULT.LogAction(f"{what} of {{timed_dtcs}} (ms), not graded: {why}", '
                         f'None if {var} is None else round({var}))')


# A frame the scripts can drive: MAH_CAN_SIGNAL_DEFS gives it a period (run-time condition text).
PERIODIC = "any(d.get('frame') == frame and d.get('periodicity') for d in MAH_CAN_SIGNAL_DEFS.values())"
# A message timeout stops a frame that carries a real signal, not one whose only signals are RESERVED
# fillers (Z121 MBFM_ACTIVE / MBFM_SLEEP, which its own DBC carries since 2026-10-22).
CONTENT = ("any(d.get('frame') == frame and d.get('periodicity') and not str(d.get('signal')).upper()"
           ".startswith('RESERVED') for d in MAH_CAN_SIGNAL_DEFS.values())")


def family_parts(binding: dict) -> dict:
    """Imports, setup (run_test level), rest / create / remove / cleanup code and texts of one family."""
    family, kind = binding["family"], binding["kind"]
    p = {"imports": {}, "setup": "", "rest": "", "create": "", "remove": "", "cleanup": "", "log": "",
         "fault_text": "", "remove_text": ""}
    if family in ("SQUIB", "SQUIB_XCONN"):
        p["imports"]["squibs_config"] = ["DTC_Squib_FaultCode", "SquibNumber", "Squib_Fault_Description"]
        p["setup"] = f"""
            # squibs_config: the squib whose DTC_Squib_FaultCode is this DTC's first two bytes.
            squib = next(name for name, code in DTC_Squib_FaultCode.items()
                         if code and str(code).upper().split() == fault_dtc.upper().split()[:2])
            loop_device = f"LOOP{{SquibNumber[squib]}}"
            fault_load = Squib_Fault_Description[{binding['load']!r}]
            inherent_load = Squib_Fault_Description['NoFault']
        """
        p["rest"] = """
            RESULT.InterpretEqualResult(f"{loop_device} ({squib}) at rest ({inherent_load})",
                                        str(SQUIB.SendRequest(loop_device, inherent_load)),
                                        f"{inherent_load} for {loop_device} set OK.")
        """
        p["cleanup"] = "SQUIB.SendRequest(loop_device, inherent_load)"
        leak = SQUIB_LEAK.get(kind)
        create = join(
            f'RESULT.InterpretEqualResult("Power card leakage {leak[2]} set", str(PS.{leak[0]}()), "0000")'
            if leak else "", """
            fault_response = SQUIB.SendRequest(loop_device, fault_load)
            RESULT.InterpretEqualResult(f"{loop_device} ({squib}) set to {fault_load}", str(fault_response),
                                        f"{fault_load} for {loop_device} set OK.")
            fault_created = fault_response == f"{fault_load} for {loop_device} set OK."
        """)
        remove = join("""
            RESULT.InterpretEqualResult(f"{loop_device} ({squib}) set back to {inherent_load}",
                                        str(SQUIB.SendRequest(loop_device, inherent_load)),
                                        f"{inherent_load} for {loop_device} set OK.")
        """, f'RESULT.InterpretEqualResult("Power card leakage {leak[2]} cleared", str(PS.{leak[1]}()), "0000")'
            if leak else "")
        if leak:
            p["cleanup"] = join(p["cleanup"], f"PS.{leak[1]}()")
        text = FAULT_WORDS[kind]
        p["fault_text"] = (f'f"{text} on {{squib}} ({{loop_device}}: {{fault_load}}'
                           + (f' and the power card leakage {leak[2]}' if leak else "") + ')"')
        if family == "SQUIB_XCONN":
            p["imports"]["squibs_config"] += ["ActiveSquibName", "Squib_FaultTypeCode"]
            p["setup"] = join(p["setup"], f"""
                # The next active loop after it that has a DTC of its own: both go on the bus line.
                partner_squib = next(name for name in (list(ActiveSquibName[ActiveSquibName.index(squib) + 1:])
                                                       + list(ActiveSquibName[:ActiveSquibName.index(squib)]))
                                     if DTC_Squib_FaultCode.get(name))
                partner_device = f"LOOP{{SquibNumber[partner_squib]}}"
                fault_dtcs.append(f"{{DTC_Squib_FaultCode[partner_squib]}} {{Squib_FaultTypeCode['CrossConnect']}}")
                timed_dtcs = " and ".join(fault_dtcs)
            """)
            p["rest"] = join(p["rest"], """
                RESULT.InterpretEqualResult(f"{partner_device} ({partner_squib}) at rest ({inherent_load})",
                                            str(SQUIB.SendRequest(partner_device, inherent_load)),
                                            f"{inherent_load} for {partner_device} set OK.")
            """)
            create = """
                fault_response = SQUIB.SendRequest(loop_device, fault_load)
                RESULT.InterpretEqualResult(f"{loop_device} ({squib}) set to {fault_load}", str(fault_response),
                                            f"{fault_load} for {loop_device} set OK.")
                partner_response = SQUIB.SendRequest(partner_device, fault_load)
                RESULT.InterpretEqualResult(f"{partner_device} ({partner_squib}) set to {fault_load}",
                                            str(partner_response), f"{fault_load} for {partner_device} set OK.")
                fault_created = (fault_response == f"{fault_load} for {loop_device} set OK."
                                 and partner_response == f"{fault_load} for {partner_device} set OK.")
            """
            remove = join(remove, """
                RESULT.InterpretEqualResult(f"{partner_device} ({partner_squib}) set back to {inherent_load}",
                                            str(SQUIB.SendRequest(partner_device, inherent_load)),
                                            f"{inherent_load} for {partner_device} set OK.")
            """)
            p["cleanup"] = join(p["cleanup"], "SQUIB.SendRequest(partner_device, inherent_load)")
            p["fault_text"] = 'f"cross connection of {squib} ({loop_device}) and {partner_squib} ({partner_device})"'
        p["create"], p["remove"] = create, remove
        p["remove_text"] = '"both loops back to the inherent load"' if family == "SQUIB_XCONN" \
            else 'f"{loop_device} back to {inherent_load}"'
    elif family == "RSU":
        type_key, call, aria, text = RSU_FAULT[kind]
        p["imports"]["rsu_config"] = ["DTC_RSU_fault"]
        p["setup"] = """
            # rsu_config: the satellite channel whose DTC_RSU_fault is this DTC's first two bytes.
            rsu_channel = next(channel for channel, code in DTC_RSU_fault.items()
                               if str(code).upper().split() == fault_dtc.upper().split()[:2])
        """
        p["rest"] = """
            RESULT.InterpretEqualResult(f"{rsu_channel} fault free", str(RSU.ClearFault(rsu_channel)),
                                        f"Fault cleared for RSU {rsu_channel}")
        """
        p["create"] = f"""
            fault_response = RSU.{call}(rsu_channel)
            RESULT.InterpretEqualResult(f"{{rsu_channel}} set to {aria}", str(fault_response),
                                        f"Fault '{aria}' set for RSU {{rsu_channel}}")
            fault_created = fault_response == f"Fault '{aria}' set for RSU {{rsu_channel}}"
        """
        p["remove"] = """
            RESULT.InterpretEqualResult(f"{rsu_channel} fault cleared", str(RSU.ClearFault(rsu_channel)),
                                        f"Fault cleared for RSU {rsu_channel}")
        """
        p["cleanup"] = "RSU.ClearFault(rsu_channel)"
        p["fault_text"] = f'f"{text} on RSU {{rsu_channel}}"'
        p["remove_text"] = 'f"{rsu_channel} fault cleared"'
    elif family == "GPO":
        flt, desc_key, text = GPO_FAULT[kind]
        p["imports"]["gpo_config"] = ["DTC_GPO_fault", "GPO_FaultDescription", "GPO_Names"]
        p["setup"] = f"""
            # gpo_config: the output whose DTC_GPO_fault is this DTC's first two bytes.
            gpo_output = next(output for output, code in DTC_GPO_fault.items()
                              if str(code).upper().split() == fault_dtc.upper().split()[:2])
            gpo_name = next((name for name in GPO_Names if name.upper().removesuffix('_LAMP') == gpo_output), None)
            fault_load = GPO_FaultDescription[{desc_key!r}]
            rest_load = GPO_FaultDescription['NoFault']
        """
        p["rest"] = "SetGpoFaultCondition(gpo_name, rest_load)"
        p["create"] = f"""
            # SetGpoFaultCondition sets the power card leakage of a short and then the output relay; its answer
            # is the relay acknowledgement.
            fault_response = SetGpoFaultCondition(gpo_name, {flt!r})
            RESULT.InterpretEqualResult(f"{{gpo_name}} set to {flt}", str(fault_response),
                                        f"{{fault_load}} for {{gpo_name}} set OK.")
            fault_created = fault_response == f"{{fault_load}} for {{gpo_name}} set OK."
        """
        p["remove"] = """
            RESULT.InterpretEqualResult(f"{gpo_name} set back to {rest_load}", str(SetGpoFaultCondition(gpo_name, rest_load)),
                                        f"{rest_load} for {gpo_name} set OK.")
        """
        p["cleanup"] = "SetGpoFaultCondition(gpo_name, rest_load)"
        p["fault_text"] = f'f"{text} on the {{gpo_output}} output ({{gpo_name}}: {{fault_load}})"'
        p["remove_text"] = 'f"{gpo_name} back to {rest_load}"'
    elif family in ("DCS", "DCS_XCONN"):
        table = "DTC_DCS_CC_fault" if family == "DCS_XCONN" else "DTC_DCS_fault"
        p["imports"]["dcs_config"] = ["DCSName", "DCS_Fault_Description", table]
        p["imports"].setdefault("canc_config", []).append("CANC_DCS_FAULT_LOAD")
        p["setup"] = f"""
            # dcs_config: the buckle channel whose {table} is this DTC's first two bytes.
            dcs_channel = next(channel for channel, code in {table}.items()
                               if channel in DCSName and str(code).upper().split() == fault_dtc.upper().split()[:2])
            dcs_device = DCSName[dcs_channel]
            fault_load = CANC_DCS_FAULT_LOAD
            rest_load = DCS_Fault_Description['unbuckle']
        """
        p["rest"] = """
            RESULT.InterpretEqualResult(f"{dcs_device} at rest ({rest_load})", str(SLS.SendRequest(dcs_device, rest_load)),
                                        f"{rest_load} for {dcs_device} set OK.")
        """
        if family == "DCS":
            p["create"] = """
                RESULT.InterpretEqualResult("Power card leakage VBAT to bus high set", str(PS.SetLeakageVBATBusHigh()),
                                            "0000")
                fault_response = SLS.SendRequest(dcs_device, fault_load)
                RESULT.InterpretEqualResult(f"{dcs_device} set to {fault_load}", str(fault_response),
                                            f"{fault_load} for {dcs_device} set OK.")
                fault_created = fault_response == f"{fault_load} for {dcs_device} set OK."
            """
            p["remove"] = """
                RESULT.InterpretEqualResult(f"{dcs_device} set back to {rest_load}",
                                            str(SLS.SendRequest(dcs_device, rest_load)),
                                            f"{rest_load} for {dcs_device} set OK.")
                RESULT.InterpretEqualResult("Power card leakage VBAT to bus high cleared",
                                            str(PS.ClearLeakageVBATBusHigh()), "0000")
            """
            p["cleanup"] = "SLS.SendRequest(dcs_device, rest_load)\nPS.ClearLeakageVBATBusHigh()"
            p["fault_text"] = ('f"a short to battery on buckle {dcs_channel} ({dcs_device}: {fault_load} and the '
                               'power card leakage VBAT to bus high)"')
            p["remove_text"] = 'f"{dcs_device} back to {rest_load}"'
        else:
            p["imports"]["dcs_config"] += ["DCS_FaultTypeCode"]
            p["imports"]["canc_config"] += ["CANC_BELT_CHANNEL", "CANC_BELT_CROSS_CONNECT_PARTNER"]
            p["setup"] = join(p["setup"], f"""
                # canc_config: the belt cross-connected with it (CANC_BELT_CROSS_CONNECT_PARTNER) and its channel.
                belt_of_channel = {{channel: belt for belt, channel in CANC_BELT_CHANNEL.items()}}
                partner_channel = CANC_BELT_CHANNEL[CANC_BELT_CROSS_CONNECT_PARTNER[belt_of_channel[dcs_channel]]]
                partner_device = DCSName[partner_channel]
                fault_dtcs.append(f"{{DTC_DCS_CC_fault[partner_channel]}} {{DCS_FaultTypeCode['CrossConnect']}}")
                timed_dtcs = " and ".join(fault_dtcs)
            """)
            p["rest"] = join(p["rest"], """
                RESULT.InterpretEqualResult(f"{partner_device} at rest ({rest_load})",
                                            str(SLS.SendRequest(partner_device, rest_load)),
                                            f"{rest_load} for {partner_device} set OK.")
            """)
            p["create"] = """
                fault_response = SLS.SendRequest(dcs_device, fault_load)
                RESULT.InterpretEqualResult(f"{dcs_device} set to {fault_load}", str(fault_response),
                                            f"{fault_load} for {dcs_device} set OK.")
                partner_response = SLS.SendRequest(partner_device, fault_load)
                RESULT.InterpretEqualResult(f"{partner_device} set to {fault_load}", str(partner_response),
                                            f"{fault_load} for {partner_device} set OK.")
                fault_created = (fault_response == f"{fault_load} for {dcs_device} set OK."
                                 and partner_response == f"{fault_load} for {partner_device} set OK.")
            """
            p["remove"] = """
                RESULT.InterpretEqualResult(f"{dcs_device} set back to {rest_load}",
                                            str(SLS.SendRequest(dcs_device, rest_load)),
                                            f"{rest_load} for {dcs_device} set OK.")
                RESULT.InterpretEqualResult(f"{partner_device} set back to {rest_load}",
                                            str(SLS.SendRequest(partner_device, rest_load)),
                                            f"{rest_load} for {partner_device} set OK.")
            """
            p["cleanup"] = "SLS.SendRequest(dcs_device, rest_load)\nSLS.SendRequest(partner_device, rest_load)"
            p["fault_text"] = 'f"cross connection of buckles {dcs_channel} and {partner_channel} ({fault_load})"'
            p["remove_text"] = '"both buckles back to the rest load"'
    elif family == "CAN":
        names = ["CAN_TX_MESSAGE_CONFIG", "MAH_CAN_SIGNAL_DEFS", "qualification_ms", "recovery_ms"]
        if binding["graded"]:
            names.append("CAN_FAULT_TIMING_TOLERANCE_PERCENT")
        same_dtc = "upper().split() == fault_dtc.upper().split()"
        if binding["kind"] == "NODE_ABSENT":
            names.append("is_key_message")
            lookup = f"""
                # canc_config: the frame whose node-absent DTC this is - the node's key frame (or its only
                # frame) - that MAH_CAN_SIGNAL_DEFS gives a period.
                node_frames = [entry.get('key_node') for entry in CAN_TX_MESSAGE_CONFIG.values()]
                fault_frame = next(frame for frame, entry in CAN_TX_MESSAGE_CONFIG.items()
                                   if str(entry.get('node_absent_dtc')).{same_dtc}
                                   and (is_key_message(frame) or node_frames.count(entry.get('key_node')) == 1)
                                   and {PERIODIC})
            """
        elif binding["kind"] == "MESSAGE_TIMEOUT":
            names.append("is_key_message")
            lookup = f"""
                # canc_config: the frame whose message-timeout DTC this is (not the node's key frame) that
                # MAH_CAN_SIGNAL_DEFS gives a period and a signal other than a RESERVED filler.
                fault_frame = next(frame for frame, entry in CAN_TX_MESSAGE_CONFIG.items()
                                   if str(entry.get('message_timeout_dtc')).{same_dtc}
                                   and not is_key_message(frame)
                                   and {CONTENT})
            """
        elif binding["kind"] == "MESSAGE_CONTENT":
            names.append("get_message_content_failure_dtcs")
            lookup = f"""
                # canc_config: the frame and its CRC (else its alive counter) whose message content DTC this is.
                fault_frame, signal_key = next(
                    (frame, key) for frame in CAN_TX_MESSAGE_CONFIG
                    for key, dtc in sorted(get_message_content_failure_dtcs(frame).items(),
                                           key=lambda item: 'CRC' not in item[0].upper())
                    if str(dtc).{same_dtc}
                    and MAH_CAN_SIGNAL_DEFS.get(key, {{}}).get('signal')
                    and {PERIODIC})
            """
        else:
            lookup = f"""
                # canc_config: the frame and signal whose signal content DTC this is, and the signal's
                # MAH_CAN_SIGNAL_DEFS entry.
                fault_frame, fault_signal = next(
                    (frame, signal) for frame, entry in CAN_TX_MESSAGE_CONFIG.items()
                    for signal, dtc in (entry.get('signal_content_failure_dtcs') or {{}}).items()
                    if str(dtc).{same_dtc}
                    and {PERIODIC})
                signal_key = next(key for key, d in MAH_CAN_SIGNAL_DEFS.items()
                                  if d.get('frame') == fault_frame and d.get('signal') == fault_signal)
            """
        p["imports"]["canc_config"] = names
        p["setup"] = join(f"fault_mode = {binding['mode']!r}   # the fault family's FAULT_THRESHOLDS key", lookup, """
            frame_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame and d.get('periodicity'))
            fault_bus = frame_def.get('bus')   # None: the CAN wrapper resolves the channel of the frame
        """)
        p["log"] = "[frame_def]"
        restore = "CAN.PeriodicEnableFrame(fault_bus, fault_frame)\nCAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)"
        if binding["kind"] in ("NODE_ABSENT", "MESSAGE_TIMEOUT"):
            p["create"] = """
                RESULT.LogAction(f"Stop {fault_frame}", str(CAN.PeriodicDisableFrame(fault_bus, fault_frame)))
                fault_created = True
            """
            p["remove"] = """
                RESULT.LogAction(f"Resume {fault_frame}", str(CAN.PeriodicEnableFrame(fault_bus, fault_frame)))
                CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
            """
            p["cleanup"] = restore
            p["fault_text"] = 'f"transmission of {fault_frame} stopped"'
            p["remove_text"] = 'f"transmission of {fault_frame} resumed"'
        elif binding["kind"] == "MESSAGE_CONTENT":
            p["setup"] = join(p["setup"], """
                signal_name = MAH_CAN_SIGNAL_DEFS[signal_key]['signal']
            """)
            p["create"] = """
                RESULT.LogAction(f"Hold {signal_name} of {fault_frame}",
                                 str(CAN.DynamicDisableSignal(fault_bus, fault_frame, signal_name)))
                fault_created = True
            """
            p["remove"] = """
                RESULT.LogAction(f"Update {signal_name} of {fault_frame} again",
                                 str(CAN.DynamicEnableSignal(fault_bus, fault_frame, signal_name)))
            """
            p["cleanup"] = restore + "\nCAN.DynamicEnableSignal(fault_bus, fault_frame, signal_name)"
            p["fault_text"] = 'f"{signal_name} of {fault_frame} no longer updated"'
            p["remove_text"] = 'f"{signal_name} of {fault_frame} updated again"'
        else:
            p["setup"] = join(p["setup"], """
                signal_name = MAH_CAN_SIGNAL_DEFS[signal_key]['signal']
                invalid_value = MAH_CAN_SIGNAL_DEFS[signal_key]['Invalid_Value']
                recovery_value = MAH_CAN_SIGNAL_DEFS[signal_key].get('SCF_Recovery_Value')
                if recovery_value is None:
                    recovery_value = MAH_CAN_SIGNAL_DEFS[signal_key].get('Default_Value')
            """)
            p["create"] = """
                RESULT.LogAction(f"{signal_name} of {fault_frame} = {invalid_value} (invalid)",
                                 str(CAN.ChangeSignalValue(fault_bus, fault_frame, signal_name, str(invalid_value))))
                fault_created = True
            """
            p["remove"] = """
                RESULT.LogAction(f"{signal_name} of {fault_frame} = {recovery_value} (valid)",
                                 str(CAN.ChangeSignalValue(fault_bus, fault_frame, signal_name, str(recovery_value))))
            """
            p["cleanup"] = restore
            p["fault_text"] = 'f"invalid value {invalid_value} for {signal_name} in {fault_frame}"'
            p["remove_text"] = 'f"valid value {recovery_value} for {signal_name} in {fault_frame}"'
    return p


def header(project: str, name: str, fault: dict, meta: dict, plan: dict, review: bool) -> str:
    def field(label: str, text: str) -> list[str]:
        wrapped = textwrap.wrap(text, 96) or [""]
        return [f"# {label:<11}: {wrapped[0]}"] + [f"#{' ' * 14}{line}" for line in wrapped[1:]]

    binding = plan["binding"]
    lamp = fault["warning_lamp"]
    shape = binding["shape"] if binding else None
    heal = ("healed (0x0A) within the demature time, lamp OFF" if shape in ("timed", "can")
            else "still active after the fault is removed (latched), lamp as active" if shape == "latched"
            else "healed per the DTC list")
    lines = ["# Author: Kris", "#"]
    lines += field("Script", f"DTC_{meta['key']}_{name}")
    lines += field("DTC", f"{fault['short_notation']} ({fault['dtc_hex']}), {fault['dtc_type']} code - "
                          f"{meta['description']}")
    lines += field("Objective", f"Fault present: DTC active ({'0x8B' if lamp == 'ON' else '0x0B'}) within the mature "
                                f"time, warning lamp {lamp}. Fault removed: DTC {heal}. IGN cycles: historic (0x08) "
                                f"after the first, still stored after ageing_cycles - 1, aged out (no DTC) after "
                                f"ageing_cycles, warning lamp OFF.")
    lines += field("Fault", meta["method"] + f" [{meta['source']}]")
    lines += field("Workbook", f"pre: {fault['precondition']}; set: {fault['set_condition']}; heal: "
                               f"{fault['heal_condition']}; mature {fault['mature_time']} / demature "
                               f"{fault['demature_time']}, tolerance {fault['time_tolerance_pct']} %; ageing "
                               f"{fault['ageing_cycles']}; lamp {lamp}")
    lines += field("Values", f"DTC, times, tolerance, ageing and lamp from fault_list_config.{name}; the device "
                             f"from its own module config. Ageing counted from the first IGN cycle after the "
                             f"fault was removed.")
    if review:
        for index, reason in enumerate(plan["reasons"]):
            lines += field("REVIEW" if index == 0 else "", reason)
    for note in plan["notes"]:
        lines += field("Notes", note)
    return "\n".join(lines)


def render_script(project: str, name: str, fault: dict, meta: dict, plan: dict, lamp: str | None) -> str:
    binding, review = plan["binding"], bool(plan["reasons"])
    parts = family_parts(binding) if binding else None
    imports = {"fault_list_config": sorted([name, "FAULT_TIME_MEASUREMENT_LAG_MS", "IGN_OFF_TIME_MS",
                                            "LAMP_POLL_INTERVAL_MS"]),
               "power_config": ["NOMINAL_VOLTAGE"]}
    if lamp:
        imports["canc_config"] = ["CAN_CRASH_FRAME_CHANNEL_MAP", "CAN_SIGNAL_Rx_MAP", "Signal_Value_2C0"]
        imports["project_config"] = ["ACTIVE_CAN_VARIANT"]
    if parts:
        for module, names in parts["imports"].items():
            imports.setdefault(module, [])
            imports[module] = sorted(set(imports[module]) | set(names))
    can = binding is not None and binding["family"] == "CAN"
    shape = binding["shape"] if binding else None
    graded = (binding["graded"] if can else fault["time_tolerance_pct"] is not None) if binding else False

    out = [header(project, name, fault, meta, plan, review), "", "import os", "import sys", "import time",
           "from pathlib import Path", "",
           "# -- Make Framework_IOEM_Py importable as a top-level package ----------------",
           "_FRAMEWORK_ROOT = Path(__file__).resolve().parents[6]",
           "if str(_FRAMEWORK_ROOT.parent) not in sys.path:",
           "    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))", "",
           "# -- Shared library ----------------------------------------------------------",
           "from Framework_IOEM_Py.shared_libraries.import_list import *", "",
           "ensure_apym_on_path()", "init_aria()", "",
           f"# -- {project} project configuration " + "-" * max(4, 72 - len(project) - 27)]
    for module in sorted(imports):
        out.append(f"from Framework_IOEM_Py.projects.{project}.config.{module} import (")
        out += [f"    {item}," for item in imports[module]]
        out.append(")")
    out += ["", ""]

    b = Body()
    b.add(0, "def run_test():")
    b.add(4, f"""
        script_name = os.path.splitext(os.path.basename(__file__))[0]
        fault = {name}   # this DTC in fault_list_config (common EV / ICE DTC list)
        fault_dtc = " ".join("0x" + fault["dtc_hex"][index:index + 2] for index in (2, 4, 6))
        fault_dtcs = [fault_dtc]
        timed_dtcs = " and ".join(fault_dtcs)
        # Status with the DTC active: warningIndicatorRequested (0x80) set only when the DTC lights the lamp.
        active_status = DTC_status['DTC_active'] if fault['warning_lamp'] == 'ON' else DTC_status['DTC_active_WLOFF']
        healed_status = DTC_status['DTC_healed']
        historic_status = DTC_status['DTC_historic']
        read_req, read_resp = {'Read_DTC_Req_CANC, Read_DTC_Resp_CANC' if can else 'Read_DTC_Req, Read_DTC_Resp'}
        # faultTimeMeasurement sees a DTC change at most FAULT_TIME_MEASUREMENT_LAG_MS late, never early: the
        # upper timing limit gets the lag on top, the lower one does not.
        measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    """)
    if lamp:
        b.add(4, f"""
            lamp_frame, lamp_signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT]['INDC_SRS']
            lamp_bus = CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][lamp_frame]
            lamp_on = int(Signal_Value_2C0['ON'], 16)
            lamp_off = int(Signal_Value_2C0['OFF'], 16)
            lamp_active = lamp_on if fault['warning_lamp'] == 'ON' else lamp_off
        """)
    else:
        b.add(4, """
            # REVIEW: canc_config has no warning lamp signal for this project; fill these in.
            lamp_bus = lamp_frame = lamp_signal = None
            lamp_on, lamp_off = 1, 0
            lamp_active = lamp_on if fault['warning_lamp'] == 'ON' else lamp_off
        """)
    if parts:
        b.add(4, parts["setup"])
        if can:
            b.add(4, """
                qualify_nominal_ms = qualification_ms(fault_mode, frame_def['periodicity'])
                recover_nominal_ms = recovery_ms(fault_mode, frame_def['periodicity'])
            """)
            if graded:
                b.add(4, "tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT")
        else:
            b.add(4, "qualify_nominal_ms = fault['mature_time_ms']")
            if shape == "timed":
                b.add(4, "recover_nominal_ms = fault['demature_time_ms']")
            if graded:
                b.add(4, "tolerance_percent = fault['time_tolerance_pct']")
        b.add(4, f"fault_text = {parts['fault_text']}")
    else:
        b.add(4, f"fault_text = {('REVIEW - fault creation not implemented: ' + meta['description'])!r}")
    b.add(4, f"""
        tc_name = script_name
        tc_desc = (f"Verify that {{fault['short_notation']}} {{fault['mnemonic']}} sets with the warning lamp "
                   f"{{fault['warning_lamp']}}, heals, is historic after an IGN cycle and ages out after "
                   f"{{fault['ageing_cycles']}} IGN cycles with the lamp OFF.")
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids({parts['log'] if parts and parts['log'] else '[]'}), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#DTC:", f"{{fault['short_notation']}} ({{fault['dtc_hex']}}) {{fault['mnemonic']}}")
        aria_reports.add_report_info("#Fault:", fault_text)
    """)
    b.add(4, "try:")

    # Step 1
    b.add(8, "aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')")
    b.add(8, "PS.SetVoltage(NOMINAL_VOLTAGE)")
    if parts and parts["rest"]:
        b.add(8, parts["rest"])
    b.add(8, f"""
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', read_resp, read_req)
    """)
    lamp_check(b, 8, "lamp_off", '"Warning lamp OFF with no DTC present"')
    b.add(8, "aria_reports.close_group()")

    # Step 2
    if parts:
        b.add(8, 'aria_reports.add_group(f"Step 2: Create fault - {fault_text}")')
        b.add(8, parts["create"])
    else:
        b.add(8, f"""
            aria_reports.add_group("Step 2: Create fault - NOT IMPLEMENTED (script under review)")
            # REVIEW: create the fault here and set fault_created from the bench answer. Suggested recipe:
            # {textwrap.shorten(meta['method'], 900)}
            fault_created = False
            RESULT.InterpretEqualResult("Fault created on the bench", "not implemented - script under review",
                                        "fault created")
        """)
    b.add(8, """
        if not fault_created:
            aria_reports.close_group()
            return
    """)
    if parts:
        measure_and_grade(b, 8, "qualification_time_ms", "active_status", "qualify_nominal_ms", "Mature time",
                          graded, "no tolerance in fault_list_config / canc_config")
    else:
        b.add(8, 'qualification_time_ms = faultTimeMeasurement(";".join(f"{dtc} {active_status}" for dtc in fault_dtcs))')
    read_dtc(b, 8, "DTC active", "active_status")
    lamp_check(b, 8, "lamp_active", 'f"Warning lamp {fault[\'warning_lamp\']} with {timed_dtcs} active"')
    b.add(8, "aria_reports.close_group()")

    # Step 3
    remove_text = parts["remove_text"] if parts else '"REVIEW - remove the fault"'
    b.add(8, f'aria_reports.add_group(f"Step 3: Remove fault - " + {remove_text})')
    if parts:
        b.add(8, parts["remove"])
    else:
        b.add(8, "# REVIEW: remove the fault here.")
    if shape == "latched":
        b.add(8, """
            # Latched (DTC list demature: 1 IGN Cycle): the DTC must not heal within the mature time after removal.
            Wait(int(fault['mature_time_ms']))
        """)
        read_dtc(b, 8, "DTC still active after the fault is removed (latched)", "active_status")
        lamp_check(b, 8, "lamp_active", 'f"Warning lamp still {fault[\'warning_lamp\']} with {timed_dtcs} latched"')
    elif parts:
        measure_and_grade(b, 8, "dequalification_time_ms", "healed_status", "recover_nominal_ms", "Demature time",
                          graded, "no tolerance in fault_list_config / canc_config")
        read_dtc(b, 8, "DTC healed", "healed_status")
        lamp_check(b, 8, "lamp_off", 'f"Warning lamp OFF with {timed_dtcs} healed"')
    else:
        read_dtc(b, 8, "DTC healed", "healed_status")
        lamp_check(b, 8, "lamp_off", 'f"Warning lamp OFF with {timed_dtcs} healed"')
    b.add(8, "aria_reports.close_group()")

    # Step 4 / 5: IGN cycles
    b.add(8, """
        aria_reports.add_group('Step 4: IGN cycle 1 after the fault was removed - DTC historic')
        PS.IGN_OFF()
        Wait(IGN_OFF_TIME_MS)
        PS.IGN_ON()
        Wait(PROVEOUT_COMPLETION_TIME)
    """)
    read_dtc(b, 8, "DTC historic after the first IGN cycle", "historic_status")
    lamp_check(b, 8, "lamp_off", 'f"Warning lamp OFF with {timed_dtcs} historic"')
    b.add(8, "aria_reports.close_group()")
    b.add(8, """
        aria_reports.add_group(f"Step 5: Ageing - IGN cycles 2 to {fault['ageing_cycles']}")
        for ign_cycle in range(2, fault['ageing_cycles'] + 1):
            PS.IGN_OFF()
            Wait(IGN_OFF_TIME_MS)
            PS.IGN_ON()
            Wait(PROVEOUT_COMPLETION_TIME)
            if ign_cycle == fault['ageing_cycles'] - 1:
                Read_DTC(f"DTC still stored after {ign_cycle} IGN cycles (one before ageing out)",
                         " ".join([read_resp] + [f"{dtc} {historic_status}" for dtc in fault_dtcs]), read_req)
        Read_DTC(f"DTC aged out (no DTC) after {fault['ageing_cycles']} IGN cycles", read_resp, read_req)
    """)
    lamp_check(b, 8, "lamp_off", 'f"Warning lamp OFF after the {fault[\'ageing_cycles\']} ageing IGN cycles"')
    b.add(8, """
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Clear DTC and read DTC')
        ClearDTC()
        Read_DTC('No DTC present after clearing', read_resp, read_req)
        aria_reports.close_group()
    """)
    b.add(4, """
        except Exception as raised:
            RESULT.InterpretEqualResult("Test execution completes without an exception", repr(raised), "no exception")
        finally:
            try:
    """)
    b.add(12, parts["cleanup"] if parts else "pass  # REVIEW: put the bench back to its rest state here")
    b.add(8, "finally:")
    b.add(12, "aria_reports.write_to_file()")
    out.append(b.text())
    out += ["", "", 'if __name__ == "__main__":', "    run_test()", ""]
    return "\n".join(out)


RUNNER_TEXT = '''"""Run the per-DTC Fault_List scripts of @PROJECT@ in DTC-list order.

Author: Kris

One script per DTC (the common EV / ICE DTC list, @VEHICLE@ DTCs). Each one creates its fault, checks the DTC
and the warning lamp while it is present and after it is removed, then cycles IGN until the DTC ages out -
about @AGEING@ IGN cycles per script. The scripts kept for review are in ../dtc_review and are not run here.
The suite stops when a script raises, so the bench can be restored first. Comment out entries for a
partial run, or pass script names on the command line; --list prints the selection.
"""

from __future__ import annotations

import ast
import runpy
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

SELECTED_TESTS = [
@ENTRIES@
]


def run_suite(selection: list[str] | None = None) -> None:
    """Run the selected scripts; stop when one raises."""
    tests = selection or SELECTED_TESTS
    if not tests:
        raise ValueError("No DTC scripts selected; no tests were executed")
    if len(tests) != len(set(tests)):
        raise ValueError("DTC selection contains duplicate scripts")
    script_paths = []
    for script_name in tests:
        script_name = script_name if script_name.endswith(".py") else script_name + ".py"
        if Path(script_name).name != script_name or script_name in ("__init__.py", Path(__file__).name):
            raise ValueError(f"Not a DTC test script: {script_name}")
        script_path = SCRIPT_DIR / script_name
        if not script_path.is_file():
            raise FileNotFoundError(f"Missing DTC script: {script_name}")
        script_tree = ast.parse(script_path.read_text(encoding="utf-8"), filename=str(script_path))
        if not any(isinstance(node, ast.FunctionDef) and node.name == "run_test" for node in script_tree.body):
            raise ValueError(f"DTC script has no run_test entry point: {script_name}")
        script_paths.append(script_path)
    for script_path in script_paths:
        print(f"\\n{'=' * 80}\\nRunning {script_path.name}\\n{'=' * 80}")
        try:
            runpy.run_path(str(script_path), run_name="__main__")
        except Exception as error:
            raise RuntimeError(
                f"DTC suite stopped at {script_path.name}; restore the bench before further testing"
            ) from error


if __name__ == "__main__":
    if "--list" in sys.argv[1:]:
        print("\\n".join(SELECTED_TESTS))
        print(f"{len(SELECTED_TESTS)} scripts")
    else:
        run_suite([arg for arg in sys.argv[1:] if not arg.startswith("-")] or None)
'''


def render_runner(project: str, vehicle: str, ready: list[tuple[str, dict, dict]]) -> str:
    lines, group = [], None
    for name, fault, meta in ready:
        if fault["group"] != group:
            if lines:
                lines.append("")
            group = fault["group"]
            lines.append(f"    # {group}")
        lines.append(f'    "DTC_{meta["key"]}_{name}.py",')
    ageing = Counter(fault["ageing_cycles"] for _, fault, _ in ready).most_common(1)
    return (RUNNER_TEXT.replace("@PROJECT@", project).replace("@VEHICLE@", vehicle)
            .replace("@AGEING@", str(ageing[0][0]) if ageing else "40").replace("@ENTRIES@", "\n".join(lines)))


def render_review(project: str, vehicle: str, review: list[tuple[str, dict, dict, dict]], ready_count: int) -> str:
    reasons = Counter(reason.split(" (")[0].split(":")[0] for _, _, _, plan in review for reason in plan["reasons"])
    lines = [f"# {project} - per-DTC Fault_List scripts kept for review", "",
             f"{len(review)} of the {len(review) + ready_count} {vehicle} DTC scripts are kept here, not in `../dtc/`, "
             f"because the fault cannot be created with certainty on this project's bench configuration. Each "
             f"script keeps the whole check flow (DTC active / healed / historic / ageing and the warning lamp); "
             f"where the bench binding is known its fault step is complete, otherwise Step 2 is marked "
             f"`REVIEW` and the script stops there.", "",
             "Built with tools/generate_dtc_fault_scripts.py; rebuild it there rather than edit by hand. Once a "
             "reason is resolved (config added, recipe confirmed), rerun the generator: the script moves to "
             "`../dtc/` and into the runner.", "",
             "## Reasons", "", "| Reason | Scripts |", "|---|---|"]
    lines += [f"| {reason} | {count} |" for reason, count in reasons.most_common()]
    lines += ["", "## Scripts", "",
              "| Script | DTC | Fault | Fault step | Why it is in review |", "|---|---|---|---|---|"]
    for name, fault, meta, plan in review:
        step = "complete" if plan["binding"] else "to fill in"
        why = "<br>".join(reason.replace("|", "\\|") for reason in plan["reasons"])
        lines.append(f"| DTC_{meta['key']}_{name}.py | {fault['short_notation']} | "
                     f"{meta['description'].replace('|', '/')} | {step} | {why} |")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

LOOKUP_VARIABLES = {"squib": "squib", "partner": "partner_squib", "channel": "rsu_channel", "output": "gpo_output",
                    "frame": "fault_frame", "signal": "signal_key"}


def check_lookups(project: str, mods: dict, name: str, fault: dict, binding: dict, lamp: str | None) -> None:
    """Run a script's config lookups against the project's config: they must find the generator's binding."""
    parts = family_parts(binding)
    namespace = {"fault": fault, "fault_dtc": " ".join(dtc_bytes(fault["dtc_hex"]))}
    namespace["fault_dtcs"] = [namespace["fault_dtc"]]
    for module, names in parts["imports"].items():
        for item in names:
            namespace[item] = getattr(mods[module], item)
    exec(textwrap.dedent(parts["setup"]), namespace)  # the setup only reads configuration values
    expected = dict(binding)
    if binding["family"].startswith("DCS"):
        expected = {"dcs_channel": binding["channel"], "partner_channel": binding.get("partner")}
    else:
        expected = {LOOKUP_VARIABLES[key]: value for key, value in binding.items() if key in LOOKUP_VARIABLES}
        if binding["family"] == "SQUIB_XCONN":
            expected["partner_squib"] = binding["partner"]
    for variable, value in expected.items():
        if value is not None and namespace.get(variable) != value:
            raise SystemExit(f"{project} {name}: the script's lookup gives {variable} = {namespace.get(variable)!r}, "
                             f"the generator bound {value!r}")
    if lamp is not None:
        assert lamp == mods["project_config"].ACTIVE_CAN_VARIANT, (project, lamp)


def build_project(project: str, meta: dict, issues: dict) -> tuple[dict[Path, str], dict]:
    mods = project_modules(project)
    flc = mods["fault_list_config"]
    vehicle = flc.VEHICLE_TYPE
    lamp, mods["lamp_reason"] = lamp_key(mods)
    folder = ROOT / "projects" / project / "modules" / "Fault_List" / "scripts"
    files: dict[Path, str] = {}
    ready, review = [], []
    for fault in flc.COMMON_FAULT_LIST:
        if vehicle not in fault["applicable_to"]:
            continue
        name = fault["mnemonic"]
        plan = plan_for(mods, fault, meta[name], lamp, issues)
        if plan["binding"] is None and not plan["reasons"]:
            raise SystemExit(f"{project} {name}: neither a binding nor a reason")
        if plan["binding"] is not None:
            check_lookups(project, mods, name, fault, plan["binding"], lamp)
        script = render_script(project, name, fault, meta[name], plan, lamp)
        compile(script, f"{project}/{name}", "exec")
        target = folder / (REVIEW_DIR if plan["reasons"] else SCRIPT_DIR) / f"DTC_{meta[name]['key']}_{name}.py"
        files[target] = script
        (review if plan["reasons"] else ready).append((name, fault, meta[name], plan))
    files[folder / SCRIPT_DIR / RUNNER] = render_runner(project, vehicle, [(n, f, m) for n, f, m, _ in ready])
    files[folder / SCRIPT_DIR / "__init__.py"] = ""
    files[folder / REVIEW_DIR / "__init__.py"] = ""
    files[folder / REVIEW_DIR / REVIEW_MD] = render_review(project, vehicle, review, len(ready))
    stats = {"vehicle": vehicle, "ready": len(ready), "review": len(review),
             "review_complete": sum(1 for *_, plan in review if plan["binding"]),
             "families": Counter(plan["binding"]["family"] for *_, plan in ready)}
    return files, stats


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=(__doc__ or "").splitlines()[0])
    parser.add_argument("--project", action="append", choices=list(common.PROJECT_VEHICLE))
    parser.add_argument("--check", action="store_true", help="compare with the files on disk, write nothing")
    args = parser.parse_args(argv)
    meta, issues = common_data()
    stale, written = [], 0
    for project in args.project or list(common.PROJECT_VEHICLE):
        files, stats = build_project(project, meta, issues)
        folder = ROOT / "projects" / project / "modules" / "Fault_List" / "scripts"
        expected = set(files)
        leftovers = [path for sub in (SCRIPT_DIR, REVIEW_DIR) for path in (folder / sub).glob("DTC_*.py")
                     if path not in expected]
        if args.check:
            stale += [path for path, text in files.items()
                      if not path.is_file() or path.read_text(encoding="utf-8") != text] + leftovers
        else:
            for path in leftovers:
                path.unlink()
            for path, text in files.items():
                path.parent.mkdir(parents=True, exist_ok=True)
                if not path.is_file() or path.read_text(encoding="utf-8") != text:
                    path.write_text(text, encoding="utf-8", newline="\n")
                    written += 1
        print(f"{project} ({stats['vehicle']}): {stats['ready']} scripts in {SCRIPT_DIR}/ "
              f"({dict(stats['families'])}), {stats['review']} in {REVIEW_DIR}/ "
              f"({stats['review_complete']} with the fault step complete)"
              + (f"; {len(leftovers)} old scripts removed" if leftovers and not args.check else ""))
    if args.check:
        print(f"{len(stale)} files differ" + (": " + ", ".join(p.relative_to(ROOT).as_posix() for p in stale[:10])
                                               if stale else ""))
        return 1 if stale else 0
    print(f"{written} files written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
