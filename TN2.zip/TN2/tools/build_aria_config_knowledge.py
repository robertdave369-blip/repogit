from __future__ import annotations

import argparse
import configparser
import json
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET

import fitz
import docx

from aria_config_assistant import DEFAULT_CORPUS_ROOTS, inspect_workbook, parse_dbc


DEFAULT_ROOTS = [
    *DEFAULT_CORPUS_ROOTS,
]

DOC_KEYWORDS = [
    "AriaMain",
    "accf",
    "Configuration",
    "Loadbox",
    "CanConfig",
    "ChassisConfig",
    "SensorsConfig",
    "EventMode",
    "DynamicLibraries",
    "Services.xml",
    "DTCList",
    "RSU",
    "SPI",
]

TEXT_EXTENSIONS = {
    ".json",
    ".json_old",
    ".cfg",
    ".stcfg",
    ".ini",
    ".txt",
    ".sym",
    ".xml",
    ".xsl",
    ".rsu",
    ".rsux",
    ".accf",
}


def detect_category(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".json", ".json_old"}:
        return "json"
    if suffix == ".ini":
        return "ini"
    if suffix == ".accf":
        return "accf"
    if suffix == ".xml":
        return "xml"
    if suffix == ".pdf":
        return "pdf"
    if suffix == ".docx":
        return "docx"
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        return "workbook"
    if suffix == ".dbc":
        return "dbc"
    return "other"


def relative_to_root(path: Path, roots: list[Path]) -> str:
    for root in roots:
        try:
            return str(path.relative_to(root))
        except ValueError:
            continue
    return str(path)


def find_file_references(value: object) -> list[str]:
    refs: list[str] = []
    if isinstance(value, dict):
        for nested in value.values():
            refs.extend(find_file_references(nested))
        return refs
    if isinstance(value, list):
        for nested in value:
            refs.extend(find_file_references(nested))
        return refs
    if not isinstance(value, str):
        return refs

    lowered = value.lower()
    if any(ext in lowered for ext in (".json", ".xml", ".xls", ".xlsx", ".xlsm", ".dbc", ".dll", ".sym", ".acpdf", ".acef", ".ldbx", ".crt")):
        refs.append(value)
    return refs


def flatten_json_keys(payload: object, prefix: str = "") -> list[str]:
    if isinstance(payload, dict):
        keys: list[str] = []
        for key, value in payload.items():
            dotted = f"{prefix}.{key}" if prefix else key
            keys.append(dotted)
            keys.extend(flatten_json_keys(value, dotted))
        return keys
    if isinstance(payload, list):
        keys: list[str] = []
        for index, value in enumerate(payload[:3]):
            dotted = f"{prefix}[{index}]"
            keys.append(dotted)
            keys.extend(flatten_json_keys(value, dotted))
        return keys
    return []


def parse_json_file(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    key_paths = flatten_json_keys(payload)
    references = sorted(set(find_file_references(payload)))
    top_level = sorted(payload.keys()) if isinstance(payload, dict) else []
    return {
        "kind": "json",
        "top_level_keys": top_level,
        "key_paths": key_paths[:250],
        "reference_count": len(references),
        "references": references[:80],
    }


def parse_ini_file(path: Path) -> dict[str, object]:
    parser = configparser.RawConfigParser()
    parser.optionxform = str
    parser.read(path, encoding="utf-8-sig")
    sections: dict[str, dict[str, str]] = {}
    references: list[str] = []
    for section in parser.sections():
        items = {key: value for key, value in parser.items(section)}
        sections[section] = items
        references.extend(find_file_references(items))
    return {
        "kind": "ini",
        "sections": sections,
        "reference_count": len(set(references)),
        "references": sorted(set(references))[:80],
    }


def strip_namespace(tag: str) -> str:
    return tag.split("}", 1)[-1]


def parse_row_definitions(root: ET.Element) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in root.findall("RowName"):
        combo = [param.text for param in row.findall("./Combo/Param") if param.text]
        rows.append(
            {
                "name": row.attrib.get("name", ""),
                "type": (row.findtext("Type") or "").strip(),
                "size": (row.findtext("Size") or "").strip(),
                "value": (row.findtext("Value") or "").strip(),
                "info": (row.findtext("Info") or "").strip(),
                "description": (row.findtext("DESCRIPTION") or row.findtext("Description") or "").strip(),
                "linker": (row.findtext("Linker") or "").strip(),
                "combo": combo[:30],
                "subparameter_count": len(row.findall("./SubParameter/Parm")),
            }
        )
    return rows


def parse_accf_file(path: Path) -> dict[str, object]:
    root = ET.parse(path).getroot()

    communication = []
    for channel in root.findall("./Communication/*"):
        communication.append(
            {
                "tag": strip_namespace(channel.tag),
                "name": channel.attrib.get("Name", ""),
                "device": (channel.findtext("DeviceChannelName") or "").strip(),
                "baudrate": (channel.findtext("Baudrate") or channel.findtext("ArbitrationBitRate") or "").strip(),
                "is_enabled": channel.attrib.get("IsEnabled", ""),
            }
        )

    diagnostics = []
    for channel in root.findall("./Diagnostic/Channels/*"):
        diagnostics.append(
            {
                "tag": strip_namespace(channel.tag),
                "name": channel.attrib.get("Name", ""),
                "request_id": (channel.findtext("RequestId") or "").strip(),
                "response_id": (channel.findtext("ResponseId") or "").strip(),
                "padding_byte": (channel.findtext("PaddingByte") or "").strip(),
                "is_can_fd": (channel.findtext("IsCanFd") or "").strip(),
            }
        )

    periodics = []
    for periodic in root.findall("./Periodics/*"):
        periodics.append(
            {
                "tag": strip_namespace(periodic.tag),
                "name": periodic.attrib.get("Name", ""),
                "dut": (periodic.findtext("Dut") or "").strip(),
                "definitions_file": (periodic.findtext("DefinitionsFile") or "").strip(),
                "channel_identity": (periodic.findtext("CommunicationChannelIdentity") or "").strip(),
            }
        )

    libraries = []
    for entry in root.findall("./DynamicLibraries/*"):
        libraries.append(
            {
                "name": entry.attrib.get("Name", ""),
                "path": (entry.findtext("Path") or "").strip(),
            }
        )

    loadboxes = []
    for props in root.findall(".//LoadboxProperties"):
        loadboxes.append(
            {
                "files_path": props.attrib.get("FilesPath", ""),
                "loadbox_file": (props.findtext("LoadboxFile") or "").strip(),
                "profile_file": (props.findtext("ProfileFile") or "").strip(),
                "load_profile": (props.findtext("LoadProfile") or "").strip(),
            }
        )

    return {
        "kind": "accf",
        "root_tag": strip_namespace(root.tag),
        "root_attributes": dict(root.attrib),
        "communication_channels": communication,
        "diagnostic_channels": diagnostics,
        "periodics": periodics,
        "dynamic_libraries": libraries,
        "loadboxes": loadboxes,
        "events_definition": (root.find("./Events").attrib if root.find("./Events") is not None else {}),
    }


def parse_xml_file(path: Path) -> dict[str, object]:
    root = ET.parse(path).getroot()
    root_tag = strip_namespace(root.tag)

    if root_tag == "ConfigurationServices":
        services = root.findall("./Services/Service")
        return {
            "kind": "xml",
            "xml_type": root_tag,
            "root_attributes": dict(root.attrib),
            "service_count": len(services),
            "services": [service.attrib.get("Name", "") for service in services[:120]],
        }

    if root_tag == "ConfigurationDTC":
        status_errors = root.findall(".//StatusErrors")
        diagnostic_codes = root.findall(".//DiagnosticCode")
        return {
            "kind": "xml",
            "xml_type": root_tag,
            "general_config": {
                "mask_status": (root.findtext("./GeneralConfigCodes/MaskStatus") or "").strip(),
                "mask_code": (root.findtext("./GeneralConfigCodes/MaskCode") or "").strip(),
                "error_byte_size": (root.findtext("./GeneralConfigCodes/ErrorByteSize") or "").strip(),
                "service": (root.findtext("./GeneralConfigCodes/Service") or "").strip(),
            },
            "status_error_count": len(status_errors),
            "diagnostic_code_count": len(diagnostic_codes),
            "sample_diagnostic_codes": [
                {
                    "name": item.attrib.get("Name", ""),
                    "value": (item.findtext("Value") or "").strip(),
                }
                for item in diagnostic_codes[:120]
            ],
        }

    if root_tag == "Config":
        rows = parse_row_definitions(root)
        return {
            "kind": "xml",
            "xml_type": root_tag,
            "row_count": len(rows),
            "rows": rows[:250],
        }

    if root_tag == "Startup":
        sensor = root.find("./Sensor")
        rows = parse_row_definitions(sensor if sensor is not None else root)
        return {
            "kind": "xml",
            "xml_type": root_tag,
            "sensor_name": sensor.attrib.get("name", "") if sensor is not None else "",
            "row_count": len(rows),
            "rows": rows[:250],
        }

    if root_tag == "SENSOR":
        registers = root.findall("./RowName")
        return {
            "kind": "xml",
            "xml_type": root_tag,
            "register_count": (root.findtext("./RegisterInformation/RegisterCount") or "").strip(),
            "repeat_count": (root.findtext("./RegisterInformation/RepeatCount") or "").strip(),
            "sample_registers": [row.attrib.get("name", "") for row in registers[:120]],
        }

    if root_tag == "ConfigurationLIN":
        schedule_tables = []
        for table in root.findall("./ScheduleTables/Table"):
            schedule_tables.append(
                {
                    "id": table.attrib.get("Id", ""),
                    "execution": table.attrib.get("Execution", ""),
                    "frame_count": len(table.findall("./Id")),
                }
            )

        return {
            "kind": "xml",
            "xml_type": root_tag,
            "baud_rate": (root.findtext("BaudRate") or "").strip(),
            "timeout": (root.findtext("Timeout") or "").strip(),
            "nad": (root.findtext("Nad") or "").strip(),
            "is_master": (root.findtext("IsMaster") or "").strip(),
            "schedule_tables": schedule_tables,
            "master_frame_count": len(root.findall("./Master/Id")),
            "slave_frame_count": len(root.findall("./Slaves/Id")),
            "on_event_count": len(root.findall("./OnEvent/Event")),
        }

    if root_tag == "ConfigurationPeriodic":
        frames = root.findall("./Frames/*")
        return {
            "kind": "xml",
            "xml_type": root_tag,
            "frame_count": len(frames),
            "frame_tags": [strip_namespace(frame.tag) for frame in frames[:120]],
        }

    children = [strip_namespace(child.tag) for child in list(root)[:50]]
    return {
        "kind": "xml",
        "xml_type": root_tag,
        "root_attributes": dict(root.attrib),
        "child_tags": children,
    }


def parse_pdf_file(path: Path) -> dict[str, object]:
    document = fitz.open(path)
    hits: list[dict[str, object]] = []
    for page_index in range(document.page_count):
        page_text = document[page_index].get_text("text")
        lowered = page_text.lower()
        for keyword in DOC_KEYWORDS:
            if keyword.lower() not in lowered:
                continue
            lines = [line.strip() for line in page_text.splitlines() if keyword.lower() in line.lower()][:3]
            hits.append(
                {
                    "page": page_index + 1,
                    "keyword": keyword,
                    "lines": lines,
                }
            )
        if len(hits) >= 80:
            break

    metadata = {key: value for key, value in document.metadata.items() if value}
    return {
        "kind": "pdf",
        "pages": document.page_count,
        "metadata": metadata,
        "keyword_hits": hits,
    }


def parse_docx_file(path: Path) -> dict[str, object]:
    document = docx.Document(path)
    headings = []
    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if not text:
            continue
        style_name = paragraph.style.name if paragraph.style is not None else ""
        if "Heading" in style_name:
            headings.append({"style": style_name, "text": text})

    hits = []
    for index, paragraph in enumerate(document.paragraphs, start=1):
        text = paragraph.text.strip()
        if not text:
            continue
        for keyword in DOC_KEYWORDS:
            if keyword.lower() in text.lower():
                hits.append({"paragraph": index, "keyword": keyword, "text": text})
        if len(hits) >= 120:
            break

    return {
        "kind": "docx",
        "paragraph_count": len(document.paragraphs),
        "headings": headings[:120],
        "keyword_hits": hits,
    }


def inspect_file(path: Path) -> dict[str, object]:
    category = detect_category(path)
    if category == "json":
        return parse_json_file(path)
    if category == "ini":
        return parse_ini_file(path)
    if category == "accf":
        return parse_accf_file(path)
    if category == "xml":
        return parse_xml_file(path)
    if category == "pdf":
        return parse_pdf_file(path)
    if category == "docx":
        return parse_docx_file(path)
    if category == "dbc":
        return parse_dbc(path)
    return {"kind": category}


def should_inspect(path: Path) -> bool:
    category = detect_category(path)
    if category in {"json", "ini", "accf", "xml", "pdf", "docx", "dbc"}:
        return True
    if category == "workbook":
        lowered = str(path).lower()
        return any(
            token in lowered
            for token in (
                "harness",
                "eventmode",
                "loadbox",
                "rsu",
                "evt",
                "can_matrix",
                "fault",
                "dtc",
            )
        )
    return False


def summarize_workbook(path: Path) -> dict[str, object]:
    return inspect_workbook(path)


def analyze_roots(roots: list[Path]) -> dict[str, object]:
    inventory: dict[str, object] = {"roots": [], "global_extension_counts": {}, "inspected_file_count": 0}
    extension_counter: Counter[str] = Counter()
    files_to_inspect: list[tuple[Path, Path]] = []

    for root in roots:
        root_files = [path for path in root.rglob("*") if path.is_file()]
        root_counter: Counter[str] = Counter()
        categories: Counter[str] = Counter()
        for path in root_files:
            suffix = path.suffix.lower() or "<noext>"
            root_counter[suffix] += 1
            extension_counter[suffix] += 1
            categories[detect_category(path)] += 1
            if should_inspect(path):
                files_to_inspect.append((root, path))

        inventory["roots"].append(
            {
                "path": str(root),
                "total_files": len(root_files),
                "extension_counts": dict(root_counter.most_common()),
                "category_counts": dict(categories),
                "top_directories": [
                    {
                        "path": str(directory),
                        "count": count,
                    }
                    for directory, count in Counter(path.parent for path in root_files).most_common(20)
                ],
            }
        )

    knowledge: dict[str, object] = {
        "inventory": inventory,
        "artifacts": [],
    }

    for root, path in sorted(files_to_inspect, key=lambda item: str(item[1]).lower()):
        category = detect_category(path)
        try:
            details = summarize_workbook(path) if category == "workbook" else inspect_file(path)
        except Exception as exc:
            details = {
                "kind": category,
                "error": str(exc),
            }
        knowledge["artifacts"].append(
            {
                "root": str(root),
                "relative_path": relative_to_root(path, roots),
                "absolute_path": str(path),
                "category": category,
                "details": details,
            }
        )

    inventory["global_extension_counts"] = dict(extension_counter.most_common())
    inventory["inspected_file_count"] = len(knowledge["artifacts"])
    return knowledge


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a structured ARIA configuration knowledge summary.")
    parser.add_argument(
        "--root",
        action="append",
        dest="roots",
        help="Root directory to analyze. Can be provided multiple times.",
    )
    parser.add_argument(
        "--output",
        default=str(Path("analysis") / "aria_config_assistant" / "knowledge-base.generated.json"),
        help="Output JSON file path.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    roots = [Path(value) for value in args.roots] if args.roots else DEFAULT_ROOTS
    missing = [str(root) for root in roots if not root.exists()]
    if missing:
        raise SystemExit(f"Missing root(s): {', '.join(missing)}")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    knowledge = analyze_roots(roots)
    output_path.write_text(json.dumps(knowledge, indent=2), encoding="utf-8")
    print(f"Wrote knowledge summary to {output_path}")
    print(f"Inspected artifacts: {knowledge['inventory']['inspected_file_count']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())