# Graph Report - tools  (2026-09-17)

## Corpus Check
- Corpus is ~43,788 words - fits in a single context window. You may not need a graph.

## Summary
- 598 nodes · 1372 edges · 25 communities (22 shown, 3 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 29 edges (avg confidence: 0.89)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- CAN-C Configuration
- ARIA Config Assistant
- Codebeamer Mutations
- Workbook Migration
- Memory Graph Building
- Codebeamer Read APIs
- EDR On-Fail Policy
- Codebeamer HTTP Client
- Codebeamer Client Interface
- ARIA Knowledge Extraction
- HTTP Session Security
- Codebeamer CLI
- Daily Plan Collection
- Tracker Field Parsing
- Client Configuration
- Plan Rendering
- Plan Output
- Tool Governance
- Artifact Audit
- Planner Normalization
- PTC Upload
- Current User Filtering
- Requirement Traceability
- Reference ID Parsing

## God Nodes (most connected - your core abstractions)
1. `CodebeamerClient` - 52 edges
2. `CodebeamerScopeError` - 30 edges
3. `generate_project_bundle()` - 21 edges
4. `collect_daily_plan()` - 19 edges
5. `inspect_workbook()` - 18 edges
6. `_normalize_identifier()` - 17 edges
7. `build_memory_graph()` - 16 edges
8. `CodebeamerResponseError` - 16 edges
9. `apply_mutation_plan()` - 16 edges
10. `validate_bundle()` - 14 edges

## Surprising Connections (you probably didn't know these)
- `_validate_live_scope()` --calls--> `List project trackers`  [EXTRACTED]
  codebeamer/operations.py → tools/codebeamer/client.py
- `collect_daily_plan()` --calls--> `Redact configured credentials`  [EXTRACTED]
  codebeamer/planner.py → tools/codebeamer/client.py
- `build_traceability()` --shares_data_with--> `List tracker items`  [INFERRED]
  codebeamer/planner.py → tools/codebeamer/client.py
- `render_daily_plan()` --conceptually_related_to--> `Redact configured credentials`  [INFERRED]
  codebeamer/planner.py → tools/codebeamer/client.py
- `summarize_workbook()` --calls--> `inspect_workbook()`  [EXTRACTED]
  build_aria_config_knowledge.py → aria_config_assistant.py

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **ARIA knowledge extraction pipeline** — aria_config_assistant, build_aria_config_knowledge, build_compact_memory_graph, query_compact_memory_graph [INFERRED 0.80]
- **CAN-C and EDR generation pipeline** — build_edr_onfail_policy, build_canc_c_script_config, build_ice01_canc_config, build_ice01_edr_config, generate_canc_c_scripts, generate_ice01_edr_canc_scripts [INFERRED 0.82]
- **Workbook legacy-ID migration workflow** — update_canc_workbook_with_legacy_ids, export_node_wise_legacy_workbooks, audit_test_tool_artifacts [INFERRED 0.74]
- **Codebeamer daily plan pipeline** — tools_codebeamer_main_main, codebeamer_client_create_codebeamer_client, codebeamer_planner_collect_daily_plan, codebeamer_planner_write_daily_plan, tools_codebeamer_run_daily_planner_wrapper [EXTRACTED 0.90]
- **Tooling governance stack** — tools_readme_framework_tools, tools_artifact_catalog_inventory, tools_analysis_requirements_manifest, tools_logbook_readme_entry_format [EXTRACTED 0.85]
- **PTC upload artifact pair** — tools_upload_framework_to_ptc_ps1_manifest_writer, tools_upload_framework_to_ptc_manifest_generated_manifest [EXTRACTED 0.90]

## Communities (25 total, 3 thin omitted)

### Community 0 - "CAN-C Configuration"
Cohesion: 0.05
Nodes (62): argparse, build_entries(), main(), _points_for(), Any, Emit the CAN-C EDR script configuration from the generated specification. Every…, Rebuild the sample array behind a case so scripts drive the same values., render() (+54 more)

### Community 1 - "ARIA Config Assistant"
Cohesion: 0.11
Nodes (62): adapt_reference_for_output(), add_artifact(), coerce_jsonable(), collect_impact_matches(), copy_directory_if_needed(), copy_file_if_needed(), detect_category(), diff_dbc() (+54 more)

### Community 2 - "Codebeamer Mutations"
Cohesion: 0.09
Nodes (54): CodebeamerConflictError, CodebeamerScopeError, Raised when Codebeamer rejects a stale or conflicting mutation., Raised when a caller requests an invalid Codebeamer identifier., apply_mutation_plan(), _assert_item_in_tracker(), _assert_project_visible(), _assert_tracker_in_project() (+46 more)

### Community 3 - "Workbook Migration"
Cohesion: 0.11
Nodes (40): csv, difflib, build_case_blocks(), build_output_headers(), force_fill_matches(), force_score_match(), load_mapping_module(), main() (+32 more)

### Community 4 - "Memory Graph Building"
Cohesion: 0.14
Nodes (31): _analyze_file(), build_argument_parser(), build_memory_graph(), _extract_public_symbols(), _file_purpose(), _graph(), _graphify_relationships(), _ignore_summary() (+23 more)

### Community 5 - "Codebeamer Read APIs"
Cohesion: 0.11
Nodes (20): _extract_collection(), _has_next_page(), _normalize_identifier(), Any, Return projects visible to the authenticated account., Return one project after validating its identifier., Return tracker metadata for one Codebeamer project., Return one tracker after validating its identifier. (+12 more)

### Community 6 - "EDR On-Fail Policy"
Cohesion: 0.09
Nodes (30): build_policy(), build_records(), classify_reaction(), expand_merged_cells(), main(), normalize_cell(), normalize_raw_value(), Any (+22 more)

### Community 7 - "Codebeamer HTTP Client"
Cohesion: 0.11
Nodes (24): CodebeamerAuthenticationError, CodebeamerAuthorizationError, CodebeamerConnectionError, CodebeamerError, CodebeamerResponseError, _copy_mapping_items(), Secure Codebeamer REST API v3 client with guarded mutations. Credentials are…, Base class for safe-to-display Codebeamer client errors. (+16 more)

### Community 8 - "Codebeamer Client Interface"
Cohesion: 0.08
Nodes (15): CodebeamerClient, Reusable Codebeamer REST API v3 client. Reads are available directly. Mutations…, Return the credential-free API root used by this client., Allow the client to be used as a context manager., Release the underlying HTTP session when the context exits., Close the underlying HTTP session., Mask configured credentials before displaying external text., Detect configured credentials before persisting a mutation plan. (+7 more)

### Community 9 - "ARIA Knowledge Extraction"
Cohesion: 0.18
Nodes (25): analyze_roots(), detect_category(), find_file_references(), flatten_json_keys(), inspect_file(), main(), parse_accf_file(), parse_args() (+17 more)

### Community 10 - "HTTP Session Security"
Cohesion: 0.08
Nodes (16): _HttpSession, Keep the same verified context if a corporate HTTPS proxy is configured., Masks locally configured credentials before any caller displays text., Return display-safe text with every configured credential masked., Return whether text contains a configured credential value., Minimal requests-session interface used by the read-only client., Send a request and return a response-like object., Release session resources. (+8 more)

### Community 11 - "Codebeamer CLI"
Cohesion: 0.14
Nodes (20): _as_text(), build_argument_parser(), _iso_date(), main(), _positive_identifier(), _print_trackers(), Any, ArgumentParser (+12 more)

### Community 12 - "Daily Plan Collection"
Cohesion: 0.14
Nodes (19): _create_daily_plan(), Namespace, Read the chosen tracker scope and write a dated local plan., build_traceability(), collect_daily_plan(), _id_sort_key(), _item_id(), Fetch selected trackers and build a redacted, evidence-backed snapshot. (+11 more)

### Community 13 - "Tracker Field Parsing"
Cohesion: 0.16
Nodes (19): _canonical_name(), _field_name(), _field_value(), _first_named_value(), _is_complete(), _named_values(), _owner_values(), Any (+11 more)

### Community 14 - "Client Configuration"
Cohesion: 0.15
Nodes (14): CodebeamerConfig, CodebeamerConfigurationError, create_codebeamer_client(), _normalize_base_url(), Path, Connection settings held in memory for one client instance only., Read required connection settings from the local dotenv file., Return the REST API v3 root for the configured Codebeamer server. (+6 more)

### Community 15 - "Plan Rendering"
Cohesion: 0.18
Nodes (13): _append_task_sections(), _item_to_dict(), _markdown_text(), PlannerItem, date, Group open tasks into deadline-based planner sections., Serialize a normalized item without owner or authentication information., Select the planner deadline section for one task. (+5 more)

### Community 16 - "Plan Output"
Cohesion: 0.19
Nodes (13): _append_traceability_sections(), DailyPlanSnapshot, Path, Write one readable Markdown plan and one AI-readable JSON snapshot by date., Render a date-based planner without exposing the authenticated identity., Produce an AI-readable, credential-free JSON representation of a plan., Render confirmed coverage gaps or the reason they cannot be asserted., One dated, redacted view of selected Codebeamer trackers. (+5 more)

### Community 17 - "Tool Governance"
Cohesion: 0.18
Nodes (13): Analysis requirements manifest, Tools artifact catalogue, List project trackers, Codebeamer CLI main entry point, Codebeamer tracker listing handler, Codebeamer tracker planner README, Codebeamer requirements, Daily planner wrapper script (+5 more)

### Community 18 - "Artifact Audit"
Cohesion: 0.33
Nodes (11): audit(), _classify(), collect_catalogue(), Finding, main(), Path, Create read-only catalogues and report cleanup candidates in tests and tools.…, _relative_path() (+3 more)

### Community 19 - "Planner Normalization"
Cohesion: 0.24
Nodes (11): _display_text(), _normalize_item(), _normalize_items(), _parse_due_date(), Build evidence-preserving Codebeamer traceability and daily-planning artifacts., Normalize every item and fail if Codebeamer returned duplicate IDs., Keep only planning and traceability fields, redacting all display text., Normalize a display value and redact configured credentials before storage. (+3 more)

### Community 21 - "Current User Filtering"
Cohesion: 0.50
Nodes (3): _flatten_text(), Check an owner field without revealing the configured username., Flatten nested user references for an internal equality check only.

### Community 22 - "Requirement Traceability"
Cohesion: 0.50
Nodes (3): Explicit requirement-to-test-case links extracted from tracker item data., Describe whether no-link results can safely be called coverage gaps., TraceabilityResult

## Knowledge Gaps
- **11 isolated node(s):** `List visible Codebeamer projects`, `Match current configured user`, `Get Codebeamer item`, `Get Codebeamer tracker`, `Create Codebeamer item` (+6 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 203 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `CodebeamerClient` connect `Codebeamer Client Interface` to `Codebeamer Mutations`, `Codebeamer Read APIs`, `Codebeamer HTTP Client`, `HTTP Session Security`, `Codebeamer CLI`, `Daily Plan Collection`, `Tracker Field Parsing`, `Client Configuration`, `Planner Normalization`, `Current User Filtering`?**
  _High betweenness centrality (0.190) - this node is a cross-community bridge._
- **Why does `create_codebeamer_client()` connect `Client Configuration` to `Codebeamer Client Interface`, `Tool Governance`, `Codebeamer CLI`, `Codebeamer HTTP Client`?**
  _High betweenness centrality (0.041) - this node is a cross-community bridge._
- **Why does `Codebeamer CLI main entry point` connect `Tool Governance` to `Plan Output`, `Client Configuration`?**
  _High betweenness centrality (0.035) - this node is a cross-community bridge._
- **Are the 13 inferred relationships involving `CodebeamerClient` (e.g. with `_create_daily_plan()` and `main()`) actually correct?**
  _`CodebeamerClient` has 13 INFERRED edges - model-reasoned connections that need verification._
- **Are the 2 inferred relationships involving `CodebeamerScopeError` (e.g. with `_mapping_identifier()` and `TrackerScope`) actually correct?**
  _`CodebeamerScopeError` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `List visible Codebeamer projects`, `Match current configured user`, `Get Codebeamer item` to the rest of the system?**
  _11 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `CAN-C Configuration` be split into smaller, more focused modules?**
  _Cohesion score 0.05203442879499218 - nodes in this community are weakly interconnected._