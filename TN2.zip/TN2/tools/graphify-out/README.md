# tools/ Knowledge Graph (graphify snapshot, 2026-09-17)

`graph.json`, `graph.html` and `GRAPH_REPORT.md` are a graphify knowledge graph of `tools/`,
built on 2026-09-17 from the Python sources alone (AST extraction, no model calls). `cache/`
holds graphify's per-file extraction cache, and `manifest.json` the files it read.

## It is out of date

The snapshot predates most of the EDR and CAN-C tooling. On 2026-10-22, 21 of the 36
top-level tools were not in it, among them `generate_canc_scripts.py`,
`generate_edr_canc_scripts.py`, `generate_u171_combined_edr_scripts.py`,
`generate_m310_fault_list_scripts.py`, `build_canc_config_from_dbc.py`,
`build_edr_config_from_diag.py`, `edr_canc_review_model.py`, `canc_config_gui.py` and the
`check_*_common.py` checkers. Use it to navigate the older Codebeamer, ARIA and audit tools
only. Check any answer it gives against the source, and don't treat a tool's absence from the
graph as absence from `tools/`.

## Refresh

Run the graphify skill on the folder (incremental: only new or changed files are extracted):

```text
/graphify tools --update
```

## Retention

Keep the folder as a navigation aid. Refresh it before relying on it for the newer tools, and
delete it if it is no longer used. It is generated, so nothing in it should be edited by hand.
