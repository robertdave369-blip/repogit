from __future__ import annotations

import argparse
import csv
import re
from collections import defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

from openpyxl import load_workbook


STOP_WORDS = {
    "a",
    "an",
    "and",
    "as",
    "at",
    "be",
    "becomes",
    "behavior",
    "bench",
    "by",
    "case",
    "check",
    "condition",
    "configured",
    "create",
    "detection",
    "dtc",
    "enable",
    "expected",
    "fault",
    "for",
    "free",
    "from",
    "heal",
    "healed",
    "healing",
    "historic",
    "id",
    "ign",
    "in",
    "is",
    "message",
    "mode",
    "monitor",
    "no",
    "normal",
    "of",
    "on",
    "periodicity",
    "present",
    "qualification",
    "rate",
    "read",
    "reception",
    "remove",
    "result",
    "resume",
    "set",
    "simulation",
    "start",
    "step",
    "stop",
    "stopping",
    "test",
    "that",
    "the",
    "time",
    "to",
    "transmission",
    "update",
    "valid",
    "verify",
    "wait",
    "when",
    "with",
}


def normalize_text(text: str) -> str:
    normalized = text.lower()
    replacements = {
        "alv": "alive",
        "messagecounter": "alive counter",
        "msgcnt": "alive counter",
        "msg id": "message id",
        "time out": "timeout",
        "over voltage": "high voltage",
        "under voltage": "low voltage",
        "vehicle speed": "vehicle_speed",
        "master cyl pressure": "master_cylinder_pressure",
    }
    for source, target in replacements.items():
        normalized = normalized.replace(source, target)
    normalized = normalized.replace("_", " ")
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized.strip()


def tokenize(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", normalize_text(text))
    return {word for word in words if word not in STOP_WORDS and len(word) > 1}


def extract_case_number(name: str) -> int | None:
    match = re.search(r"testcase(\d+)$", name.lower())
    return int(match.group(1)) if match else None


def extract_keywords(text: str) -> set[str]:
    normalized = normalize_text(text)
    keywords: set[str] = set()
    checks = {
        "node_absent": ["node absent", "node absent", "loss of message reception"],
        "timeout": ["timeout"],
        "mcf": ["message content failure"],
        "scf": ["signal content failure", "signal content error", "signal invalid"],
        "dlc": ["dlc"],
        "crc": ["crc"],
        "alive": ["alive counter", "alive"],
        "priority": ["fault priority", "dtc priority", "priority"],
        "hv": ["high voltage"],
        "lv": ["low voltage"],
        "raw_physical": ["raw to physical", "decoding", "decode", "conversion"],
        "normal_rx": ["normal reception", "update rate"],
        "freshness": ["freshness"],
        "mac": ["truncated mac", " mac "],
    }
    for keyword, patterns in checks.items():
        if any(pattern in normalized for pattern in patterns):
            keywords.add(keyword)
    return keywords


@dataclass
class LegacyCase:
    artifact_id: int
    name: str
    description: str
    technique: str
    combined_text: str
    group: str
    message: str | None
    signal_name: str | None
    intent: str | None
    keywords: set[str]
    case_number: int | None


@dataclass
class CurrentCase:
    sheet: str
    row_start: int
    test_case_id: str
    title: str
    objective: str
    combined_text: str
    group: str
    message: str
    signal_name: str | None
    intent: str | None
    keywords: set[str]
    case_number: int | None


def base_intent(intent: str | None) -> str | None:
    if intent is None:
        return None
    if intent.startswith("hv_") or intent.startswith("lv_"):
        return intent[3:]
    return intent


GROUP_MAP = {
    "E_CALL_1_100": "E_CALL",
    "EPS1_FD_10": "EPS",
    "FR_ZONE2_100": "FRZONE",
    "FR_ZONE3_100": "FRZONE",
    "HPCAd_1_10": "HPCAD",
    "HPCAd_2_50": "HPCAD",
    "HPCAd_3_50": "HPCAD",
    "HPCAd_4_10": "HPCAD",
    "HPCC_1_100": "HPCC",
    "HPCC_24_500": "HPCC",
    "IEB1_FD_10": "IEB",
    "VCU1_FD_20": "VCU",
    "VCU11_FD_10": "VCU",
    "VCU2_FD_100": "VCU",
    "VCU4_FD_1500": "VCU",
}


def legacy_group_from_name(name: str) -> str:
    upper_name = name.upper()
    if "E_CALL" in upper_name or "ECALL" in upper_name:
        return "E_CALL"
    if "FRZONE" in upper_name:
        return "FRZONE"
    if "HPCAD" in upper_name:
        return "HPCAD"
    if "HPCC" in upper_name:
        return "HPCC"
    if "IEB" in upper_name:
        return "IEB"
    if "EPS" in upper_name:
        return "EPS"
    if "VCU" in upper_name:
        return "VCU"
    return upper_name


def detect_message(text: str, known_messages: list[str], group: str) -> str | None:
    normalized = normalize_text(text)
    for message in known_messages:
        if normalize_text(message) in normalized:
            return message

    single_message_groups = {
        "E_CALL": "E_CALL_1_100",
        "EPS": "EPS1_FD_10",
        "IEB": "IEB1_FD_10",
    }
    return single_message_groups.get(group)


def extract_signal_name(text: str, known_messages: list[str]) -> str | None:
    excluded = {message.upper() for message in known_messages}
    excluded.update({
        "CANC",
        "DTC",
        "MSG",
        "MSGID",
        "FD",
        "TESTCASE",
        "HIGH",
        "LOW",
        "CRC",
        "DLC",
    })
    for token in re.findall(r"\b[A-Z][A-Z0-9_]{3,}\b", text):
        if "_" not in token:
            continue
        if token in excluded:
            continue
        if token.endswith("TESTCASE"):
            continue
        return token
    return None


def extract_intent(text: str, signal_name: str | None) -> str | None:
    normalized = normalize_text(text)

    if "fault priority scf -> mcf" in normalized:
        return "priority_scf_mcf"
    if "fault priority scf -> na" in normalized:
        return "priority_scf_na"
    if "when node absent" in normalized or "node absent dtc is active" in normalized:
        return None
    if "fault priority" in normalized or "dtc priority" in normalized:
        return None

    voltage_prefix = None
    if "high voltage" in normalized or "over voltage" in normalized:
        voltage_prefix = "hv_"
    elif "low voltage" in normalized or "under voltage" in normalized:
        voltage_prefix = "lv_"

    if (
        "normal reception" in normalized
        or "update rate" in normalized
        or "periodicity shall be around" in normalized
        or ("message is observed" in normalized and "periodicity" in normalized)
    ):
        return "normal_reception"

    if "signal content failure" in normalized and signal_name:
        base = f"scf:{signal_name}"
        return f"{voltage_prefix}{base}" if voltage_prefix else base

    has_mcf = (
        "message content failure" in normalized
        or "incorrect dlc" in normalized
        or "wrong dlc detection" in normalized
        or "crc fault detection" in normalized
        or "incorrect crc" in normalized
        or "incorrect alv" in normalized
        or "incorrect alive" in normalized
    )

    if has_mcf:
        if (
            "incorrect dlc" in normalized
            or "wrong dlc" in normalized
            or "mechanism: dlc" in normalized
            or "(dlc)" in normalized
        ):
            base = "mcf_dlc"
        elif (
            "incorrect crc" in normalized
            or "crc fault detection" in normalized
            or "mechanism: crc" in normalized
            or "(crc)" in normalized
        ):
            base = "mcf_crc"
        elif (
            "incorrect alv" in normalized
            or "incorrect alive" in normalized
            or "incorrect count" in normalized
            or "mechanism: messagecounter" in normalized
            or "mechanism: alive counter" in normalized
            or "(messagecounter)" in normalized
            or "(alive counter)" in normalized
            or ("alive counter" in normalized and "message content failure" in normalized)
        ):
            base = "mcf_alive"
        else:
            base = None
        if base:
            return f"{voltage_prefix}{base}" if voltage_prefix else base

    if "message timeout" in normalized or "timeout" in normalized:
        base = "message_timeout"
        return f"{voltage_prefix}{base}" if voltage_prefix else base

    if "node absent" in normalized or "loss of message reception" in normalized:
        base = "node_absent"
        return f"{voltage_prefix}{base}" if voltage_prefix else base

    return None


def parse_legacy_cases(path: Path, known_messages: list[str]) -> list[LegacyCase]:
    workbook = load_workbook(path, read_only=True, data_only=True)
    worksheet = workbook["Export"]
    header = next(worksheet.iter_rows(min_row=1, max_row=1, values_only=True))
    indexes = {name: idx for idx, name in enumerate(header)}

    cases: list[LegacyCase] = []
    current_case: dict[str, object] | None = None

    for row in worksheet.iter_rows(min_row=2, values_only=True):
        case_id = row[indexes["ID"]]
        case_name = row[indexes["Name"]]

        if case_id is not None and isinstance(case_name, str) and case_name.startswith("CANC_"):
            if current_case is not None:
                combined_text = " ".join(current_case["texts"])
                group = legacy_group_from_name(str(current_case["name"]))
                cases.append(
                    LegacyCase(
                        artifact_id=int(float(current_case["artifact_id"])),
                        name=str(current_case["name"]),
                        description=str(current_case["description"]),
                        technique=str(current_case["technique"]),
                        combined_text=combined_text,
                        group=group,
                        message=detect_message(combined_text, known_messages, group),
                        signal_name=extract_signal_name(combined_text, known_messages),
                        intent=extract_intent(combined_text, extract_signal_name(combined_text, known_messages)),
                        keywords=extract_keywords(combined_text),
                        case_number=extract_case_number(str(current_case["name"])),
                    )
                )

            current_case = {
                "artifact_id": case_id,
                "name": case_name,
                "description": row[indexes["Description"]] or "",
                "technique": row[indexes["_TestTechnique"]] or "",
                "texts": [row[indexes["Description"]] or "", row[indexes["Test Steps.Action"]] or "", row[indexes["Test Steps.Expected result"]] or ""],
            }
            continue

        if current_case is not None:
            action = row[indexes["Test Steps.Action"]] or ""
            expected = row[indexes["Test Steps.Expected result"]] or ""
            if action or expected:
                current_case["texts"].extend([action, expected])

    if current_case is not None:
        combined_text = " ".join(current_case["texts"])
        group = legacy_group_from_name(str(current_case["name"]))
        cases.append(
            LegacyCase(
                artifact_id=int(float(current_case["artifact_id"])),
                name=str(current_case["name"]),
                description=str(current_case["description"]),
                technique=str(current_case["technique"]),
                combined_text=combined_text,
                group=group,
                message=detect_message(combined_text, known_messages, group),
                signal_name=extract_signal_name(combined_text, known_messages),
                intent=extract_intent(combined_text, extract_signal_name(combined_text, known_messages)),
                keywords=extract_keywords(combined_text),
                case_number=extract_case_number(str(current_case["name"])),
            )
        )

    return cases


def parse_current_cases(path: Path) -> tuple[list[CurrentCase], list[str]]:
    workbook = load_workbook(path, read_only=True, data_only=True)
    known_messages = [sheet for sheet in workbook.sheetnames if sheet != "Coverage_Matrix"]
    cases: list[CurrentCase] = []

    for worksheet in workbook.worksheets:
        if worksheet.title == "Coverage_Matrix":
            continue

        header = next(worksheet.iter_rows(min_row=1, max_row=1, values_only=True))
        indexes = {name: idx for idx, name in enumerate(header) if name is not None}
        test_case_id_idx = indexes["Test Case ID"]
        title_idx = indexes.get("Title", indexes.get("Name"))
        objective_idx = indexes.get("Objective", indexes.get("Description"))
        pre_action_idx = indexes.get("Pre Action")
        action_idx = indexes["Test Step Action"]
        expected_idx = indexes["Expected Result"]

        active_case: dict[str, object] | None = None
        for row_index, row in enumerate(worksheet.iter_rows(min_row=2, values_only=True), start=2):
            test_case_id = row[test_case_id_idx]
            if test_case_id:
                if active_case is not None:
                    combined_text = " ".join(active_case["texts"])
                    message = worksheet.title
                    cases.append(
                        CurrentCase(
                            sheet=worksheet.title,
                            row_start=int(active_case["row_start"]),
                            test_case_id=str(active_case["test_case_id"]),
                            title=str(active_case["title"]),
                            objective=str(active_case["objective"]),
                            combined_text=combined_text,
                            group=GROUP_MAP[worksheet.title],
                            message=message,
                            signal_name=extract_signal_name(combined_text, known_messages),
                            intent=extract_intent(combined_text, extract_signal_name(combined_text, known_messages)),
                            keywords=extract_keywords(combined_text),
                            case_number=extract_case_number(str(active_case["test_case_id"])),
                        )
                    )

                active_case = {
                    "row_start": row_index,
                    "test_case_id": test_case_id,
                    "title": row[title_idx] or "" if title_idx is not None else "",
                    "objective": row[objective_idx] or "" if objective_idx is not None else "",
                    "texts": [
                        row[title_idx] or "" if title_idx is not None else "",
                        row[objective_idx] or "" if objective_idx is not None else "",
                        row[pre_action_idx] or "" if pre_action_idx is not None else "",
                        row[action_idx] or "",
                        row[expected_idx] or "",
                    ],
                }
            elif active_case is not None:
                active_case["texts"].extend([row[action_idx] or "", row[expected_idx] or ""])

        if active_case is not None:
            combined_text = " ".join(active_case["texts"])
            message = worksheet.title
            cases.append(
                CurrentCase(
                    sheet=worksheet.title,
                    row_start=int(active_case["row_start"]),
                    test_case_id=str(active_case["test_case_id"]),
                    title=str(active_case["title"]),
                    objective=str(active_case["objective"]),
                    combined_text=combined_text,
                    group=GROUP_MAP[worksheet.title],
                    message=message,
                    signal_name=extract_signal_name(combined_text, known_messages),
                    intent=extract_intent(combined_text, extract_signal_name(combined_text, known_messages)),
                    keywords=extract_keywords(combined_text),
                    case_number=extract_case_number(str(active_case["test_case_id"])),
                )
            )

    return cases, known_messages


def score_match(current_case: CurrentCase, legacy_case: LegacyCase) -> float:
    if current_case.group != legacy_case.group:
        return -1.0

    if current_case.intent is None or legacy_case.intent is None:
        return -1.0

    if current_case.intent != legacy_case.intent:
        return -1.0

    if current_case.intent == "normal_reception":
        current_message = normalize_text(current_case.message)
        legacy_text = normalize_text(legacy_case.combined_text)
        if current_message not in legacy_text:
            return -1.0

    if current_case.signal_name and legacy_case.signal_name and current_case.signal_name != legacy_case.signal_name:
        return -1.0

    score = 30.0
    if legacy_case.message == current_case.message:
        score += 25.0
    elif legacy_case.message is not None and current_case.message != legacy_case.message:
        return -1.0

    if current_case.intent == "normal_reception":
        score += 10.0

    current_keywords = current_case.keywords
    legacy_keywords = legacy_case.keywords
    intersection = current_keywords & legacy_keywords
    score += 9.0 * len(intersection)

    conflicting_pairs = [("dlc", "crc"), ("dlc", "alive"), ("crc", "alive"), ("hv", "lv"), ("raw_physical", "node_absent")]
    for left, right in conflicting_pairs:
        if left in current_keywords and right in legacy_keywords:
            score -= 18.0
        if right in current_keywords and left in legacy_keywords:
            score -= 18.0

    token_overlap = tokenize(current_case.combined_text) & tokenize(legacy_case.combined_text)
    score += min(len(token_overlap), 8) * 2.5

    ratio = SequenceMatcher(None, normalize_text(current_case.combined_text), normalize_text(legacy_case.combined_text)).ratio()
    score += ratio * 20.0

    if current_case.case_number is not None and current_case.case_number == legacy_case.case_number:
        score += 4.0

    return score


def soft_score_match(current_case: CurrentCase, legacy_case: LegacyCase) -> float:
    if current_case.group != legacy_case.group:
        return -1.0

    current_text = normalize_text(current_case.combined_text)
    legacy_text = normalize_text(legacy_case.combined_text)
    current_message = normalize_text(current_case.message)
    legacy_message = normalize_text(legacy_case.message) if legacy_case.message else None
    current_base_intent = base_intent(current_case.intent)
    legacy_base_intent = base_intent(legacy_case.intent)

    explicit_fault_intents = {"node_absent", "message_timeout", "mcf_dlc", "mcf_crc", "mcf_alive", "scf"}
    if current_base_intent in explicit_fault_intents and legacy_message and legacy_message != current_message:
        return -1.0

    score = 0.0

    if legacy_message == current_message:
        score += 35.0
    elif current_message in legacy_text:
        score += 28.0

    if current_case.signal_name and legacy_case.signal_name:
        if current_case.signal_name == legacy_case.signal_name:
            score += 42.0
        elif current_base_intent in {"scf", None}:
            return -1.0

    if current_base_intent and legacy_base_intent and current_base_intent == legacy_base_intent:
        score += 34.0

    if current_case.intent == "priority_scf_mcf":
        if "priority" in legacy_text:
            score += 42.0
        if "dlc" in current_text and "dlc" in legacy_text:
            score += 16.0
        if "crc" in current_text and "crc" in legacy_text:
            score += 16.0
        if "alive" in current_text and "alive" in legacy_text:
            score += 16.0
    elif current_case.intent == "priority_scf_na":
        if "priority" in legacy_text:
            score += 42.0
        if "node absent" in legacy_text:
            score += 18.0

    if current_case.intent == "normal_reception":
        if any(marker in legacy_text for marker in ["message is received", "periodicity shall be around", "message_"]):
            score += 44.0

    if current_case.signal_name and current_case.signal_name in legacy_case.combined_text:
        score += 18.0

    if "alive counter behavior" in current_text or (current_case.signal_name and "msg_cnt" in current_case.signal_name.lower()):
        if any(marker in legacy_text for marker in ["alive", "alv", "counter", "msg count"]):
            score += 32.0

    if any(marker in current_text for marker in ["freshness", "truncated mac", "integrity field"]):
        if any(marker in legacy_text for marker in ["crc", "message is received", "periodicity shall be around", "message_"]):
            score += 26.0

    if any(marker in current_text for marker in ["decoding of", "raw to physical", "physical value"]):
        if current_case.signal_name and legacy_case.signal_name == current_case.signal_name:
            score += 32.0
        elif any(marker in legacy_text for marker in ["message is received", "periodicity shall be around", "message_"]):
            score += 18.0

    current_keywords = current_case.keywords
    legacy_keywords = legacy_case.keywords
    score += 4.0 * len(current_keywords & legacy_keywords)

    token_overlap = tokenize(current_case.combined_text) & tokenize(legacy_case.combined_text)
    score += min(len(token_overlap), 10) * 2.0

    ratio = SequenceMatcher(None, current_text, legacy_text).ratio()
    score += ratio * 24.0

    return score


def compute_matches(current_cases: list[CurrentCase], legacy_cases: list[LegacyCase]) -> tuple[dict[tuple[str, int], LegacyCase], list[dict[str, object]]]:
    candidates: list[tuple[float, CurrentCase, LegacyCase, float]] = []
    report_rows: list[dict[str, object]] = []
    grouped_legacy: defaultdict[str, list[LegacyCase]] = defaultdict(list)
    for legacy_case in legacy_cases:
        grouped_legacy[legacy_case.group].append(legacy_case)

    for current_case in current_cases:
        scored: list[tuple[float, LegacyCase]] = []
        for legacy_case in grouped_legacy.get(current_case.group, []):
            score = score_match(current_case, legacy_case)
            if score > 0:
                scored.append((score, legacy_case))
        scored.sort(key=lambda item: item[0], reverse=True)

        top_score = scored[0][0] if scored else 0.0
        second_score = scored[1][0] if len(scored) > 1 else 0.0
        top_case = scored[0][1] if scored else None

        report_rows.append(
            {
                "sheet": current_case.sheet,
                "row_start": current_case.row_start,
                "test_case_id": current_case.test_case_id,
                "title": current_case.title,
                "matched_legacy_id": top_case.artifact_id if top_case else "",
                "matched_legacy_name": top_case.name if top_case else "",
                "matched_legacy_description": top_case.description if top_case else "",
                "score": round(top_score, 2),
                "second_score": round(second_score, 2),
                "accepted": "",
                "technique": top_case.technique if top_case else "",
            }
        )

        if top_case is not None:
            candidates.append((top_score, current_case, top_case, second_score))

    candidates.sort(key=lambda item: item[0], reverse=True)

    assigned_current: dict[tuple[str, int], LegacyCase] = {}
    used_legacy_ids: set[int] = set()

    for score, current_case, legacy_case, second_score in candidates:
        key = (current_case.sheet, current_case.row_start)
        if key in assigned_current or legacy_case.artifact_id in used_legacy_ids:
            continue
        if score < 72.0:
            continue
        assigned_current[key] = legacy_case
        used_legacy_ids.add(legacy_case.artifact_id)

    soft_candidates: list[tuple[float, CurrentCase, LegacyCase]] = []
    for current_case in current_cases:
        key = (current_case.sheet, current_case.row_start)
        if key in assigned_current:
            continue
        for legacy_case in grouped_legacy.get(current_case.group, []):
            if legacy_case.artifact_id in used_legacy_ids:
                continue
            score = soft_score_match(current_case, legacy_case)
            if score >= 52.0:
                soft_candidates.append((score, current_case, legacy_case))

    soft_candidates.sort(key=lambda item: item[0], reverse=True)

    for score, current_case, legacy_case in soft_candidates:
        key = (current_case.sheet, current_case.row_start)
        if key in assigned_current or legacy_case.artifact_id in used_legacy_ids:
            continue
        assigned_current[key] = legacy_case
        used_legacy_ids.add(legacy_case.artifact_id)

    for report_row in report_rows:
        key = (str(report_row["sheet"]), int(report_row["row_start"]))
        assigned_legacy = assigned_current.get(key)
        if assigned_legacy is not None:
            report_row["matched_legacy_id"] = assigned_legacy.artifact_id
            report_row["matched_legacy_name"] = assigned_legacy.name
            report_row["matched_legacy_description"] = assigned_legacy.description
            report_row["technique"] = assigned_legacy.technique
            report_row["accepted"] = "Y"
        else:
            report_row["accepted"] = ""

    return assigned_current, report_rows


def update_workbook(path: Path, output_path: Path, matches: dict[tuple[str, int], LegacyCase], default_technique: str = "") -> None:
    workbook = load_workbook(path)

    for worksheet in workbook.worksheets:
        if worksheet.title == "Coverage_Matrix":
            continue

        headers = [worksheet.cell(row=1, column=column).value for column in range(1, worksheet.max_column + 1)]
        if not headers or headers[0] != "ID":
            worksheet.insert_cols(1)
            worksheet.cell(row=1, column=1).value = "ID"

        headers = [worksheet.cell(row=1, column=column).value for column in range(1, worksheet.max_column + 1)]
        if "_TestTechnique" not in headers:
            worksheet.cell(row=1, column=worksheet.max_column + 1).value = "_TestTechnique"

        headers = [worksheet.cell(row=1, column=column).value for column in range(1, worksheet.max_column + 1)]
        header_to_column = {value: index + 1 for index, value in enumerate(headers)}
        objective_column = header_to_column.get("Objective")
        if objective_column is None:
            for header, column in header_to_column.items():
                if isinstance(header, str) and header.lower() == "objective":
                    worksheet.cell(row=1, column=column).value = "Objective"
                    objective_column = column
                    break

        id_column = header_to_column["ID"]
        technique_column = header_to_column["_TestTechnique"]
        test_case_id_column = header_to_column["Test Case ID"]

        row = 2
        while row <= worksheet.max_row:
            testcase_value = worksheet.cell(row=row, column=test_case_id_column).value
            if testcase_value:
                match = matches.get((worksheet.title, row))
                worksheet.cell(row=row, column=id_column).value = match.artifact_id if match else None
                technique = match.technique if match and match.technique else default_technique or None
                worksheet.cell(row=row, column=technique_column).value = technique
            row += 1

    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output_path)


def write_report(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "sheet",
                "row_start",
                "test_case_id",
                "title",
                "matched_legacy_id",
                "matched_legacy_name",
                "matched_legacy_description",
                "score",
                "second_score",
                "accepted",
                "technique",
            ],
            delimiter="\t",
        )
        writer.writeheader()
        writer.writerows(rows)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Add legacy Codebeamer IDs and _TestTechnique to the CANC workbook.")
    parser.add_argument("--current", required=True, help="Path to the current workbook.")
    parser.add_argument("--legacy", required=True, help="Path to the legacy Codebeamer export workbook.")
    parser.add_argument("--output", required=True, help="Path for the updated workbook.")
    parser.add_argument("--report", required=True, help="Path for the mapping report TSV.")
    parser.add_argument("--default-technique", default="", help="Optional default _TestTechnique for unmatched rows.")
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    current_path = Path(args.current)
    legacy_path = Path(args.legacy)
    output_path = Path(args.output)
    report_path = Path(args.report)

    current_cases, known_messages = parse_current_cases(current_path)
    legacy_cases = parse_legacy_cases(legacy_path, known_messages)
    matches, report_rows = compute_matches(current_cases, legacy_cases)

    update_workbook(current_path, output_path, matches, default_technique=args.default_technique)
    write_report(report_path, report_rows)

    accepted = sum(1 for row in report_rows if row["accepted"] == "Y")
    unmatched = len(report_rows) - accepted
    print(f"Legacy matches accepted: {accepted}")
    print(f"Legacy matches left blank: {unmatched}")
    print(f"Updated workbook: {output_path}")
    print(f"Mapping report: {report_path}")


if __name__ == "__main__":
    main()