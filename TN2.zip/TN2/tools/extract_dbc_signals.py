"""Extract a CAN DBC into the project's *_signals.json format (agent.md section 16.8).

This is the generator of the ``*_signals.json`` files under ``req\\io_testcases\\M310_DBC\\``
and ``req\\u171_dbc\\``. Reuse/extend this tool instead of re-implementing DBC parsing.

Usage:
    python tools\\extract_dbc_signals.py <path-to.dbc> [output.json]

Requires: cantools  (install into the analysis interpreter, agent.md section 21.1:
    & "C:\\Python 3.14.0\\python.exe" -m pip install cantools)
"""

import json
import os
import sys

import cantools


def extract_signal_info(signal):
    """Extract detailed information about a signal, including value descriptions."""
    choices = {}
    if signal.choices:
        for val, desc in signal.choices.items():
            # NamedSignalValue (and ints) must be stringified before JSON serialization
            choices[str(val)] = str(desc)
    return {
        "name": signal.name,
        "description": signal.comment,
        "start_bit": signal.start,
        "length": signal.length,
        "byte_order": signal.byte_order,
        "is_signed": signal.is_signed,
        "factor": signal.scale,
        "offset": signal.offset,
        "min": signal.minimum,
        "max": signal.maximum,
        "unit": signal.unit,
        "is_multiplexer": signal.is_multiplexer,
        "multiplexer_ids": signal.multiplexer_ids,
        "initial": getattr(signal, "initial", None),
        "invalid": getattr(signal, "invalid", None),
        "receivers": list(signal.receivers) if signal.receivers else [],
        "value_descriptions": choices,
    }


def extract_message_info(message):
    """Extract detailed information about a message and its signals."""
    return {
        "name": message.name,
        "frame_id": hex(message.frame_id),
        "description": message.comment,
        "is_extended_frame": message.is_extended_frame,
        "is_fd": getattr(message, "is_fd", None),
        "length": message.length,
        "senders": list(message.senders) if isinstance(message.senders, (set, frozenset)) else message.senders,
        "receivers": list(message.receivers) if isinstance(message.receivers, (set, frozenset)) else message.receivers,
        "cycle_time": message.cycle_time,
        "send_type": getattr(message, "send_type", None),
        "signals": [extract_signal_info(sig) for sig in message.signals],
    }


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    dbc_path = sys.argv[1]
    if not os.path.isfile(dbc_path):
        print(f"DBC file not found: {dbc_path}")
        sys.exit(1)

    db = cantools.database.load_file(dbc_path)
    messages = [extract_message_info(msg) for msg in db.messages]

    output_json = sys.argv[2] if len(sys.argv) > 2 else os.path.splitext(dbc_path)[0] + "_signals.json"
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(messages, f, indent=2, ensure_ascii=False)

    print(f"Extracted {len(messages)} messages ({sum(len(m['signals']) for m in messages)} signals) to: {output_json}")


if __name__ == "__main__":
    main()
