"""The names every project's canc_config.py shares, whatever buses the project has.

A project can have a CAN-FD bus, a high-speed CAN bus, a normal (classic) CAN bus, or a
mix. The configs do not describe that with names of their own: every one uses the same
variables, holding that project's frames, so a script or tool is written once:

  MAH_CAN_SIGNAL_DEFS          signal key -> signal definition (frame, signal, scaling,
                               values, EDR_Parameter, fault_logic, ...)
  CAN_TX_MESSAGE_CONFIG        every frame the bench transmits, with its node and DTCs
  KEY_TX_FRAMES                the key frame of each node
  CAN_SIGNAL_Rx_MAP            the signals the SRS transmits, on the project's main bus -
                               HSCAN frames in U171 / Z121, CAN-FD frames in M310 / M314
  CAN_HSCAN_SIGNAL_Rx_MAP      the same for the second bus, where a project has two
  CAN_CRASH_FRAME_CHANNEL_MAP  the ARIA channel each SRS frame is read on

EDR parameter names are common too. A signal definition's EDR_Parameter names the EDR
element it feeds by the name every project uses for that element (U171's names, see
build_edr_config_from_diag.COMMON_ELEMENT_NAMES); the frame and signal that carry it are
the project's own. A signal the record does not store keeps the label U171 gives it.

Used by tools/build_canc_config_from_dbc.py and tools/canc_config_gui.py (new configs),
and tools/check_canc_config_common.py (every config). Offline only.
"""

from __future__ import annotations

from typing import Any

# Bus types and how a person would call them - for reading one DBC per bus.
BUS_TYPES = ("CANFD", "HSCAN", "CAN")
BUS_TYPE_LABELS = {
    "CANFD": "CAN FD",
    "HSCAN": "High-speed CAN",
    "CAN": "Normal (classic) CAN",
}
# ARIA channel names the shared library resolves (jscript_translation._normalize_channel_name).
ARIA_CHANNELS = ("CANFD", "HSCAN", "ARIA", "Level 61")
# The channel a bus type is on unless the project says otherwise. A normal-CAN bus has no
# channel of its own name on the bench, so it is asked for; HSCAN is only the default.
DEFAULT_ARIA_CHANNEL = {"CANFD": "CANFD", "HSCAN": "HSCAN", "CAN": "HSCAN"}

# Top-level names every canc_config exposes. CAN_HSCAN_SIGNAL_Rx_MAP exists only where a
# project has a second bus, so it is not required.
COMMON_NAMES = (
    "PROJECT_NAME", "MODULE_NAME", "MAH_CAN_SIGNAL_DEFS", "CAN_TX_MESSAGE_CONFIG",
    "KEY_TX_FRAMES", "CAN_SIGNAL_Rx_MAP", "CAN_CRASH_FRAME_CHANNEL_MAP",
)

# The project whose names the others follow.
REFERENCE_PROJECT = "U171"

# Signal entry layout for configs written by the tools: keys in this order, in these
# groups, so every signal reads the same way.
SIGNAL_KEY_GROUPS = (
    ("where it is", ("frame", "signal", "frame_ID", "bus", "is_fd", "ch",
                     "periodicity", "direction")),
    ("encoding", ("start_bit", "bit_length", "Signed", "byte_order")),
    ("scaling and range", ("Factor", "Offset", "UNIT", "MIN", "MID", "MAX",
                           "RAW_MIN", "RAW_MAX")),
    ("values", ("Default_Value", "Default_Source", "State_Values", "Invalid_Values",
                "Reserved_Values", "OutofRange_Values", "Invalid_Value",
                "SCF_Recovery_Value")),
    ("EDR and fault handling", ("EDR_Parameter", "fault_logic")),
)


def check_config(module: Any, common_names: dict[str, str] | None = None
                 ) -> list[str]:
    """What a loaded canc_config lacks of the common structure (empty when complete).

    ``common_names`` maps a name that is not the common one - an element's specification
    name - to the common name (U171's). An EDR_Parameter spelled the other way is a
    problem: the element is called the same in every project.
    """
    problems = [f"no {name}" for name in COMMON_NAMES if not hasattr(module, name)]
    for name, keys in sorted(edr_parameters(module).items()):
        common = (common_names or {}).get(name)
        if common and common != name:
            problems.append(f"EDR_Parameter {name!r} ({', '.join(keys)}) is the specification "
                            f"name; the common name is {common!r}")
    return problems


def edr_parameters(module: Any) -> dict[str, list[str]]:
    """EDR_Parameter value -> the signal keys that carry it."""
    found: dict[str, list[str]] = {}
    for key, signal_def in (getattr(module, "MAH_CAN_SIGNAL_DEFS", {}) or {}).items():
        name = signal_def.get("EDR_Parameter") if isinstance(signal_def, dict) else None
        if name:
            found.setdefault(name, []).append(key)
    return found
