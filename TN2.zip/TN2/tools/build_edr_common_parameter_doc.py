"""Write the common ICE/EV EDR parameter reference and its gap register.

The common EDR workbooks under docs/project_documents/EDR_Spec Common/ (ICE/ICE_Common
EDR.xlsx and EV/EV_Common EDR.xlsx, the same sheets as ICE_COMMON_SRS_V1.9 and
M312_M112_M210_SRS_V3.4) define one event record, DIDs 0x0455 and 0x045B. This tool reads
both, lines them up element by element, gives every element a short generic name
(NAMES), applies the documented source corrections (ROW_FIXES, TIME_FIXES, CORRECTIONS)
and writes two Markdown files next to the workbooks:

    EDR_COMMON_PARAMETERS.md   every parameter as an edr_config-style dictionary
    EDR_COMMON_GAPS.md         source gaps, what was corrected, open questions, and
                               where each project's edr_config differs from the reference

Edit this tool, not the Markdown. Offline only: reads two workbooks and the project
edr_configs, writes two Markdown files.

Usage:
    py -3.14 tools/build_edr_common_parameter_doc.py
    py -3.14 tools/build_edr_common_parameter_doc.py --check
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SPEC_DIR = REPOSITORY_ROOT / "docs" / "project_documents" / "EDR_Spec Common"
WORKBOOKS = {
    "ICE": SPEC_DIR / "ICE" / "ICE_Common EDR.xlsx",
    "EV": SPEC_DIR / "EV" / "EV_Common EDR.xlsx",
}
# The diagnostic specification each workbook was copied from (sheet for sheet identical).
DIAG_SPECS = {
    "ICE": "ICE/ICE_COMMON_SRS_V1.9_DIAG_RE.xlsx",
    "EV": "EV/M312_M112_M210_SRS_V3.4_DIAG_RE.xlsx",
}
PARAMETERS_DOC = SPEC_DIR / "EDR_COMMON_PARAMETERS.md"
GAPS_DOC = SPEC_DIR / "EDR_COMMON_GAPS.md"
VARIANTS = ("ICE", "EV")
CONFIG_PROJECTS = {"U171": "ICE", "Z121": "ICE", "M310_M314_M110": "EV"}

# Bytes of positive response header (62 04 55) ahead of the specification's payload byte 0,
# plus one because read_edr_parameters indexes a response as data[n - 1]: payload byte b is
# data_start_byte b + 4, the numbering every edr_config uses.
RESPONSE_HEADER_BYTES = 3
BYTE_NUMBER_OFFSET = RESPONSE_HEADER_BYTES + 1

CATEGORIES = [
    ("event", "Event identity and record status"),
    ("crash", "Crash type"),
    ("vehicle_t0", "Vehicle state at T0"),
    ("restraint_t0", "Seat belts, airbag switch and SRS lamps at T0"),
    ("precrash", "Pre-crash driving data"),
    ("chassis", "Tyres, brake pressure, gear and door lock"),
    ("inertial", "Inertial signals"),
    ("deploy_time", "Restraint deployment times"),
    ("deploy_status", "Restraint deployment status"),
    ("delta_v", "Crash pulse (delta-V)"),
    ("adas", "Driver assistance (ADAS)"),
    ("powertrain", "Powertrain and drive mode"),
    ("lamps", "Lamps, chassis-system status and battery voltage"),
    ("occupancy", "Occupancy and classification at T0"),
    ("postcrash", "Post-crash outputs"),
    ("counters", "ECU life counters"),
]

# Specification name -> (generic name, category, meaning). The generic name is short and
# says what the value is; it is neither the CAN message nor the signal, which differ by
# project.
NAMES: list[tuple[str, str, str, str]] = [
    ("LifeTimeEventNb", "LifetimeEventCount", "event", "Number of events the ECU has recorded over its life."),
    ("VehicleSpeed Longitudinal At Time Zero", "VehicleSpeedAtT0", "vehicle_t0", "Longitudinal vehicle speed at T0."),
    ("Battery Voltage", "EcuSupplyVoltage", "vehicle_t0", "Supply voltage the SRS ECU measures itself at T0. The battery voltage received on CAN is BatteryVoltage."),
    ("Odometer", "Odometer", "vehicle_t0", "Odometer reading at T0."),
    ("Front Head Lamp Status", "HeadLampStatus", "vehicle_t0", "Front head lamp status at T0, coded like the high-beam status."),
    ("Engine State", "EngineState", "vehicle_t0", "Engine state at T0."),
    ("Doors Open Status", "DoorOpenStatus", "vehicle_t0", "Open doors and closures at T0, one bit each."),
    ("SRS Malfunction Indicator Lamp On IG Cycle counter", "SrsLampOnCycles", "restraint_t0", "Ignition cycles during which the SRS warning lamp has been on."),
    ("SRS Malfunction Indicator Lamp On Time", "SrsLampOnTime", "restraint_t0", "Time the SRS warning lamp has been on."),
    ("Event Date", "EventDate", "event", "Date of the event: day, month and two-digit year packed in two bytes."),
    ("Event Time", "EventTime", "event", "Time of the event: hour, minute and second packed in three bytes."),
    ("MultiEventNumber", "MultiEventNumber", "event", "Position of this event in a multi-event sequence."),
    ("Front crash", "FrontCrash", "crash", "Front crash detected."),
    ("Left Side crash", "LeftSideCrash", "crash", "Left side crash detected."),
    ("Right Side crash", "RightSideCrash", "crash", "Right side crash detected."),
    ("Rear crash", "RearCrash", "crash", "Rear crash detected."),
    ("Understrike crash", "UnderstrikeCrash", "crash", "Understrike crash detected."),
    ("Rollover crash", "RolloverCrash", "crash", "Rollover detected."),
    ("Near crash", "NearCrash", "crash", "Near crash: below the deployment threshold, recorded but not locked."),
    ("Crash Record Lock Status", "RecordLockStatus", "event", "Record locked (confirmed or deployed crash) or unlocked (near crash)."),
    ("Ignition cycle counter at time of crash", "IgnCycleCountAtCrash", "event", "Ignition cycle count at the time of the crash."),
    ("Seat Belt Status - Driver", "SeatBeltDriver", "restraint_t0", "Buckle status of the driver seat at T0."),
    ("Seat Belt Status - Passenger", "SeatBeltPassenger", "restraint_t0", "Buckle status of the front passenger seat at T0."),
    ("Seat Belt Status - Second Row Left Side Passenger", "SeatBeltRow2Left", "restraint_t0", "Buckle status of the 2nd-row left seat at T0."),
    ("Seat Belt Status - Second Row Middle Side Passenger", "SeatBeltRow2Middle", "restraint_t0", "Buckle status of the 2nd-row middle seat at T0."),
    ("Seat Belt Status - Second Row Right Side Passenger", "SeatBeltRow2Right", "restraint_t0", "Buckle status of the 2nd-row right seat at T0."),
    ("Seat Belt Status - Third Row Left Side Passenger", "SeatBeltRow3Left", "restraint_t0", "Buckle status of the 3rd-row left seat at T0."),
    ("Seat Belt Status - Third Row Right Side Passenger", "SeatBeltRow3Right", "restraint_t0", "Buckle status of the 3rd-row right seat at T0."),
    ("Passenger air bag suppression switch status, front passenger", "PassengerAirbagSwitch", "restraint_t0", "Passenger airbag ON/OFF switch position at T0."),
    ("Front Airbag WarnLamp Status", "FrontAirbagLamp", "restraint_t0", "Front airbag warning lamp at T0."),
    ("SRS MalFunction Indicator Lamp", "SrsLamp", "restraint_t0", "SRS warning lamp at T0."),
    ("Vehicle Speed Longitudinal", "VehicleSpeed", "precrash", "Longitudinal vehicle speed."),
    ("Brake switch status", "BrakeSwitch", "precrash", "Brake pedal switch."),
    ("SRS ECU Status at T0", "EcuPowerStateAtT0", "vehicle_t0", "How the SRS ECU was powered at T0: ignition off, ignition on or CAN wake-up."),
    ("Accelerator pedal, % full", "AccelPedal", "precrash", "Accelerator pedal position."),
    ("ENGINE SPEED", "EngineSpeed", "precrash", "Engine speed."),
    ("ABS_ACTIVE_IEB", "AbsActive", "precrash", "ABS intervention active."),
    ("STEERING_ABSOLUTE_ANGLE", "SteeringAngle", "precrash", "Steering wheel angle."),
    ("ESC_ACTIVE_IEB", "EscActive", "precrash", "ESC intervention active."),
    ("CompletionStatus", "CompletionStatus", "event", "Record complete: set 5 s after T0 when the battery stays connected."),
    ("200ms CompletionStatus", "Completion200ms", "event", "The first 200 ms after T0 were recorded completely (battery cut-off crash)."),
    ("TimeBtwEvents", "TimeBetweenEvents", "event", "Time between this event and the previous one; 0xFFFF for a single event."),
    ("DeltaVLong", "DeltaVLong", "delta_v", "Longitudinal delta-V, every 10 ms from T0."),
    ("DeltaVLat", "DeltaVLat", "delta_v", "Lateral delta-V, every 10 ms from T0."),
    ("TimeMaxDeltaVLgt", "TimeMaxDeltaVLong", "delta_v", "Time from T0 to the maximum longitudinal delta-V."),
    ("TimeMaxDeltaVLat", "TimeMaxDeltaVLat", "delta_v", "Time from T0 to the maximum lateral delta-V."),
    ("MaxDeltaVLgt", "MaxDeltaVLong", "delta_v", "Maximum longitudinal delta-V."),
    ("MaxDeltaVLat", "MaxDeltaVLat", "delta_v", "Maximum lateral delta-V."),
    ("Tyre_Pressure_FL", "TyrePressureFL", "chassis", "Front-left tyre pressure."),
    ("Tyre_Pressure_FR", "TyrePressureFR", "chassis", "Front-right tyre pressure."),
    ("Tyre_Pressure_RL", "TyrePressureRL", "chassis", "Rear-left tyre pressure."),
    ("Tyre_Pressure_RR", "TyrePressureRR", "chassis", "Rear-right tyre pressure."),
    ("Master_Cylinder_Pressure", "BrakePressure", "chassis", "Brake master-cylinder pressure."),
    ("Gear", "Gear", "chassis", "Selected gear or drive direction."),
    ("Driver Door Lock Status", "DriverDoorLock", "chassis", "Driver door lock state."),
    ("YAW_RATE", "YawRate", "inertial", "Yaw rate."),
    ("X_AXIS_ANGULAR", "RollRate", "inertial", "Angular rate about the vehicle X axis (roll)."),
    ("Y_AXIS_ANGULAR", "PitchRate", "inertial", "Angular rate about the vehicle Y axis (pitch)."),
    ("LATERAL_ACCEL", "LateralAccel", "inertial", "Lateral acceleration."),
    ("LONG_ACCEL", "LongitudinalAccel", "inertial", "Longitudinal acceleration."),
    ("Z_AXIS_ACCEL", "VerticalAccel", "inertial", "Vertical (Z axis) acceleration."),
    ("TCS_ACTIVE_IEB", "TcsActive", "precrash", "Traction control intervention active."),
    ("AEB_WARNING_MSG", "AebWarning", "adas", "Autonomous emergency braking warning level."),
    ("AEB_FCTA_WARN", "FctaWarning", "adas", "Front cross-traffic alert warning level."),
    ("RCTA_WARN", "RctaWarning", "adas", "Rear cross-traffic alert warning level."),
    ("SEB_WARNING_LEFT", "SebWarningLeft", "adas", "SEB warning or control, left side."),
    ("SEB_WARNING_RIGHT", "SebWarningRight", "adas", "SEB warning or control, right side."),
    ("AES_Warning", "AesWarning", "adas", "Automatic emergency steering warning or control."),
    ("AES_SYS_STS", "AesState", "adas", "Automatic emergency steering system state."),
    ("ESA_SYS_STS", "EsaState", "adas", "Emergency steering assist system state."),
    ("LDW_LKA_WARNING", "LaneDepartureWarning", "adas", "Lane departure warning, left or right."),
    ("ADAS_Des_StrWhl_Angle_Cmd", "AdasSteeringCmd", "adas", "Steering wheel angle requested by ADAS."),
    ("LDW_LKA_SYS_STATE", "LaneKeepState", "adas", "Lane departure warning / lane keeping system state."),
    ("LKA_HANDSOFF_DISPLAY_WARNING", "LkaHandsOffWarning", "adas", "Lane keeping hands-off warning shown."),
    ("LCF_SYS_STATE", "LaneCenteringState", "adas", "Lane centering function state."),
    ("SPA_SYS_STATE", "SpaState", "adas", "SPA system state."),
    ("SPA_LCF_HANDSOFF_ WARNING", "SpaHandsOffWarning", "adas", "SPA / lane centering hands-off warning level."),
    ("ACC_SYS_STATE", "CruiseState", "adas", "Adaptive or conventional cruise control state."),
    ("NP_SYS_STS", "NpState", "adas", "NP system state."),
    ("RMS_MODE_STATE", "RmsState", "adas", "RMS state: standby, takeover, stop completed or driver takeover."),
    ("LC_PATH_STATE", "LaneChangeState", "adas", "Lane change or lane centering in progress, or not available."),
    ("ELK_Oncoming_Warning", "ElkOncomingWarning", "adas", "Emergency lane keeping, oncoming traffic: warning or control."),
    ("ELK_SIDE_WARNING", "ElkSideWarning", "adas", "Emergency lane keeping, road side: warning or control."),
    ("ELK_Overtaking_Warning", "ElkOvertakingWarning", "adas", "Emergency lane keeping, overtaking traffic: warning or control."),
    ("RCW_WARN", "RcwWarning", "adas", "Rear collision warning."),
    ("VCU_OPRT_REQ", "PowertrainModeRequest", "powertrain", "Operation mode the vehicle control unit requests from the drive."),
    ("VCU_TRQ_CMD", "TorqueCommand", "powertrain", "Drive torque commanded by the vehicle control unit."),
    ("STS_HIGHBEAM", "HighBeam", "lamps", "High beam on or off."),
    ("STS_LOWBEAM", "LowBeam", "lamps", "Low beam on or off."),
    ("STS_TPMS_LED", "TpmsLamp", "lamps", "Tyre pressure warning lamp pattern."),
    ("ZONAL_BATT_VOLT", "BatteryVoltage", "lamps", "Vehicle battery voltage received on CAN."),
    ("STS_ABS", "AbsStatus", "lamps", "ABS available (lamp off) or not available (lamp on)."),
    ("STS_EBD", "EbdStatus", "lamps", "EBD available (lamp off) or not available (lamp on)."),
    ("STS_ESC", "EscStatus", "lamps", "ESC availability."),
    ("STS_TCS", "TcsStatus", "lamps", "Traction control availability."),
    ("PADDLE_SHIFT_POSITION", "PaddleShiftLevel", "powertrain", "Regeneration paddle level."),
    ("VCU_IGN_STS", "IgnitionStatus", "powertrain", "Ignition status sent by the vehicle control unit."),
    ("EMERGENCY_BRAKING_REQ", "EmergencyBrakeRequest", "adas", "Emergency braking request."),
    ("TORQUE_SPLIT_RATIO", "TorqueSplitRatio", "powertrain", "Front/rear torque split ratio."),
    ("ALERT_MESSAGE", "AlertMessage", "powertrain", "Alert message shown to the driver."),
    ("VCU_DRV_ADV_MODE", "DriveMode", "powertrain", "Selected drive mode."),
    ("VCU_DRV_ADV_MODE_STS", "DriveModeStatus", "powertrain", "Drive mode status."),
    ("ODS - Driver at T0", "OccupantDriver", "occupancy", "Driver seat occupied at T0."),
    ("ODS/OCS - Passenger at T0", "OccupantPassenger", "occupancy", "Front passenger seat occupied at T0."),
    ("ODS - Second Row Left Side Passenger at T0", "OccupantRow2Left", "occupancy", "2nd-row left seat occupied at T0."),
    ("ODS - Second Row Middle Side Passenger at T0", "OccupantRow2Middle", "occupancy", "2nd-row middle seat occupied at T0."),
    ("ODS - Second Row Right Side Passenger at T0", "OccupantRow2Right", "occupancy", "2nd-row right seat occupied at T0."),
    ("ODS - Third Row Left Side Passenger at T0", "OccupantRow3Left", "occupancy", "3rd-row left seat occupied at T0."),
    ("ODS - Third Row Right Side Passenger at T0", "OccupantRow3Right", "occupancy", "3rd-row right seat occupied at T0."),
    ("Co Driver seat Type (ODS/OCS)", "PassengerSensorType", "occupancy", "Passenger seat sensing fitted: ODS or OCS."),
    ("OCS Passenger Type Classification at T0", "PassengerClass", "occupancy", "OCS passenger size class at T0."),
    ("Seat Position Zone Driver at T0", "SeatZoneDriver", "occupancy", "Driver seat track position zone at T0."),
    ("Seat Position Zone Co Driver at T0", "SeatZonePassenger", "occupancy", "Front passenger seat track position zone at T0."),
    ("SRS_OPERATION_MODE at T0", "SrsOperationMode", "occupancy", "SRS operation mode at T0."),
    ("DOMS Seat Belt Identification Status at T0", "DomsSeatBelt", "occupancy", "Seat belt detection by the driver monitoring camera (DOMS) at T0."),
    ("1st crash Type (Roll over or Regular) at T0", "FirstCrashRollover", "crash", "Whether the first crash of the event was a rollover."),
    ("SRS_OCS_SUBSEAT_CLASSIFICATION at T0", "ChildSeatClass", "occupancy", "Child seat or booster type on the front passenger seat at T0."),
    ("SRS_OCC_ODS_ADULT at T0", "AdultCount", "occupancy", "Adults present at T0."),
    ("SRS_BKL_CNT at T0", "BuckledCount", "occupancy", "Occupants buckled at T0."),
    ("SRS_ECALL_OCC_CNT at T0", "EcallOccupantCount", "occupancy", "Occupant count reported for eCall at T0."),
    ("SRS_ECALL_OCC_BKL_CNT at T0", "EcallBuckledCount", "occupancy", "Buckled-occupant count reported for eCall at T0."),
    ("STS_CRASH", "CrashOutput", "postcrash", "Crash signal the SRS transmits on CAN."),
    ("CTRL_BRAKE_LIGHT", "BrakeLightCommand", "precrash", "Brake light control."),
    ("PIB_ACTIVE", "PostImpactBraking", "postcrash", "Post-impact braking active."),
    ("ECALL_PWM_ACK_CRASH", "EcallPwmAck", "postcrash", "eCall PWM crash line acknowledgement."),
    ("Reset Cycle Counter", "ResetCount", "counters", "ECU reset count."),
    ("Most Recent Life Timer at T0", "LifeTimerAtT0", "counters", "ECU life timer at T0."),
    ("SRS_PAB_ACTION", "PassengerAirbagAction", "occupancy", "Action taken on the passenger airbag at T0: turned on, turned off or none."),
    ("SRS TX SRS_OCS_PASS_CLASS_FAULT_STS", "PassengerClassFault", "occupancy", "Passenger classification fault status sent by the SRS."),
    ("Clutch Status", "ClutchStatus", "powertrain", "Clutch pedal position (manual transmission, ICE only)."),
]

# Restraint loops, in record order: (specification prefix, generic key, meaning).
DEPLOYMENT_LOOPS = [
    ("Driver Airbag squib", "DriverAirbag", "driver airbag"),
    ("Passenger Airbag squib", "PassengerAirbag", "passenger airbag"),
    ("Driver Pre-tensioner -1 Squib(Belt)", "DriverPretensioner", "driver belt pretensioner"),
    ("Passenger Pre-tensioner -1 Squib(Belt)", "PassengerPretensioner", "passenger belt pretensioner"),
    ("Driver Pre-tensioner -2 Squib(Lap)", "DriverLapPretensioner", "driver lap pretensioner"),
    ("Passenger Pre-tensioner -2 Squib(Lap)", "PassengerLapPretensioner", "passenger lap pretensioner"),
    ("Driver Side Airbag", "DriverSideAirbag", "driver side airbag"),
    ("Passenger Side Airbag", "PassengerSideAirbag", "passenger side airbag"),
    ("Driver Curtain Airbag", "DriverCurtain", "driver curtain airbag"),
    ("Passenger Curtain Airbag", "PassengerCurtain", "passenger curtain airbag"),
    ("Driver Knee Airbag", "DriverKneeAirbag", "driver knee airbag"),
    ("Center airbag", "CenterAirbag", "centre airbag"),
    ("Driver Pretensioner Load Limiter -1Squib(Belt)", "DriverLoadLimiter", "driver load-limiting pretensioner"),
    ("Passenger Pretensioner Load Limiter- 1Squib(Belt)", "PassengerLoadLimiter", "passenger load-limiting pretensioner"),
    ("2nd Row Right Pretensioner Squib", "Row2RightPretensioner", "2nd-row right pretensioner"),
    ("2nd Row Left Pretensioner Squib", "Row2LeftPretensioner", "2nd-row left pretensioner"),
    ("HV-Cutoff", "HvCutoff", "high-voltage cut-off"),
    ("Passenger Pelvis Restraint Cushion", "PassengerPelvis", "passenger pelvis cushion"),
    ("Driver Pelvis Restraint Cushion", "DriverPelvis", "driver pelvis cushion"),
    ("Driver Airbag Active vent", "DriverAirbagVent", "driver airbag active vent"),
    ("Passenger Airbag Active vent", "PassengerAirbagVent", "passenger airbag active vent"),
]
for _prefix, _key_name, _label in DEPLOYMENT_LOOPS:
    NAMES.append((f"{_prefix} - Deployment Time", f"DeployTime{_key_name}", "deploy_time",
                  f"Time from T0 to the {_label} firing command."))
    NAMES.append((f"{_prefix} - Deployment Status", f"DeployStatus{_key_name}", "deploy_status",
                  f"Whether the {_label} deployed."))

# Source cells corrected before anything else is read: (variant, sheet row) -> cells.
ROW_FIXES: dict[tuple[str, int], dict[str, Any]] = {
    ("ICE", 872): {
        "cells": {"POS_IN_BYTES": 801},
        "parameter": "STS_LOWBEAM",
        "spec": "sample at -2 S in byte 800",
        "used": "byte 801",
        "evidence": "Byte 800 holds STS_HIGHBEAM; every other STS_LOWBEAM sample is in byte 801 "
                    "and the EV sheet gives 801 for the same row.",
        "confidence": "High",
    },
}

# Sample-time labels corrected: specification name -> {label in seconds: corrected label}.
TIME_FIXES: dict[str, dict[float, float]] = {
    "AEB_WARNING_MSG": {0.55: 0.25},
}
TIME_FIX_EVIDENCE = {
    "AEB_WARNING_MSG": ("label 'at 0.55 S'", "0.25 s",
                        "The series runs -3 s to +2 s every 0.25 s; 0.25 s is the one label "
                        "missing and 0.55 s is off the grid.", "High"),
}

# Field values corrected after the layout is read. Every field holds (value, the
# specification's own text, evidence, confidence).
CORRECTIONS: dict[str, dict[str, tuple[Any, str, str, str]]] = {
    "LifeTimeEventNb": {
        "maximum": (4294967295.0, "2^32", "A 32-bit unsigned field holds at most 2^32 - 1.", "High"),
    },
    "Reset Cycle Counter": {
        "maximum": (4294967295.0, "2^32", "A 32-bit unsigned field holds at most 2^32 - 1.", "High"),
    },
    "Most Recent Life Timer at T0": {
        "maximum": (4294967295.0, "2^32", "A 32-bit unsigned field holds at most 2^32 - 1.", "High"),
    },
    "Ignition cycle counter at time of crash": {
        "maximum": (4294967295.0, "16",
                    "The field is 4 bytes; a maximum of 16 cycles cannot be meant for a "
                    "lifetime ignition counter. Confirm with the OEM.", "Medium"),
    },
    "ALERT_MESSAGE": {
        "maximum": (46.0, "2E",
                    "'2E' is hexadecimal (0x2E = 46); the field is one byte and the "
                    "ALERT_MESSAGE enum lists codes 0..44.", "Medium"),
    },
    "Doors Open Status": {
        "data_bit_length": (6, "LEN_IN_BITS 5",
                            "The Doors_Open_Status enum is a 6-bit mask (1 back door, 2 hood, "
                            "4 FL, 8 FR, 16 RL, 32 RR, 63 all open) and the STS_DOOR signal is "
                            "6 bits in the U171 and M314 DBCs.", "High"),
        "maximum": (63.0, "1", "All six bits set = 63 (enum 'All Door Open').", "High"),
        "enum": ("Doors_Open_Status", "Value should be taken as per CAN dbc comments",
                 "The enum table defines Doors_Open_Status; no layout row references it.", "High"),
    },
    "SRS_OCS_SUBSEAT_CLASSIFICATION at T0": {
        "data_bit_length": (4, "LEN_IN_BITS 2",
                            "The enum and MAX_VALUE go to 7, which 2 bits cannot hold; the "
                            "SRS_OCS_SUBSEAT_CLASSIFICATION signal is 4 bits in the M314 DBC "
                            "and bits 4..7 of the byte are otherwise unused. Confirm with the "
                            "OEM.", "Medium"),
    },
    "ADAS_Des_StrWhl_Angle_Cmd": {
        "unit": ("deg", "(blank)", "ADAS_DES_STRWHL_ANGLE_CMD is in deg in the U171 and M314 DBCs.", "High"),
        "minimum": (-720.0, "0", "MIN_VALUE 0 / MAX_VALUE 32767 are raw counts; the DBCs give "
                                 "-720..720 deg with this scaling and offset.", "High"),
        "maximum": (720.0, "32767", "See minimum.", "High"),
    },
    "VCU_TRQ_CMD": {
        "unit": ("Nm", "(blank)", "VCU_TRQ_CMD is in Nm in the M314 DBC.", "High"),
    },
    "Z_AXIS_ACCEL": {
        "offset": (-8.0, "0",
                   "LATERAL_ACCEL and LONG_ACCEL, with the same resolution and range, use "
                   "offset -8 and an unsigned raw; Z_AXIS_ACCEL is offset -8, unsigned, in the "
                   "M314 DBC. Confirm with the OEM.", "Medium"),
    },
    "Engine State": {
        "labels_add": ({7: "Reserved"}, "code 6 listed twice, code 7 missing",
                       "A 3-bit field has codes 0..7; the second 'Reserved' is taken as 7.", "Medium"),
    },
    "Seat Position Zone Driver at T0": {
        "enum": ("SRS_STPS_ZONE_DRVR", "ENUM:SRS_STPS_ZONE",
                 "No SRS_STPS_ZONE enum exists; the table has SRS_STPS_ZONE_DRVR.", "High"),
    },
    "Seat Position Zone Co Driver at T0": {
        "enum": ("SRS_STPS_ZONE_PSGR", "ENUM:SRS_STPS_ZONE",
                 "No SRS_STPS_ZONE enum exists; the table has SRS_STPS_ZONE_PSGR "
                 "(written with a leading space).", "High"),
    },
}

# Event Date and Event Time are custom packed fields. The layout sheet gives only their
# bytes; the bit split is the one drawn in the sheet's own example figures, and is the
# one U171's configuration decodes. (field, bits most significant first as (byte, bit)
# relative to the field's first byte, unit, valid minimum and maximum, the U171
# configuration name).
PACKED_FIELDS = {
    "Event Date": [
        ("year", [(0, 7), (0, 6), (0, 5), (0, 4), (0, 3), (0, 2)], "YY", 0.0, 63.0, "EventDtYear"),
        ("month", [(0, 1), (0, 0), (1, 7), (1, 6)], "MM", 1.0, 12.0, "EventDt_Month"),
        ("day", [(1, 5), (1, 4), (1, 3), (1, 2), (1, 1)], "DD", 1.0, 31.0, "EventDt_Day"),
        ("reserved", [(1, 0)], None, 0.0, 0.0, None),
    ],
    "Event Time": [
        ("hour", [(0, 7), (0, 6), (0, 5), (0, 4), (0, 3)], "HH", 0.0, 23.0, "EventTime_Hour"),
        ("minute", [(0, 2), (0, 1), (0, 0), (1, 7), (1, 6), (1, 5)], "MM", 0.0, 59.0, "EventTime_Min"),
        ("second", [(1, 4), (1, 3), (1, 2), (1, 1), (1, 0), (2, 7)], "SS", 0.0, 59.0, "EventTime_Sec"),
        ("reserved", [(2, 6), (2, 5), (2, 4), (2, 3), (2, 2), (2, 1), (2, 0)], None, 0.0, 0.0, None),
    ],
}

# Questions the sources leave open and this reference does not decide.
OPEN_QUESTIONS = [
    ("SrsLampOnTime", "MAX_VALUE 65533 with resolution 10 s: it is unclear whether 65533 is "
     "the raw count (655330 s) or the physical maximum in seconds. Kept as written."),
    ("DeployTime*", "Two-byte fields with MAX_VALUE 255 ms (raw up to 65535). 255 ms is kept "
     "as the physical range; the stored value when a loop never fires is not stated "
     "(U171 decodes FF FF as 'not fired')."),
    ("EventDate / EventTime", "The example figures disagree with themselves: the Event Time "
     "picture shows data 0x50 0x7C 0x00 but its bit row is 0x5C 0x60 0x00, which is what "
     "11:35:00 packs to. The date figure is labelled DD/MM/YY while the unit column says "
     "DDMMYYYY; the year is two digits (6 bits), its century is not stated."),
    ("CrashOutput / PostImpactBraking", "Recorded up to +9 s, while CompletionStatus is set "
     "5 s after T0. Whether samples after +5 s are guaranteed in a complete record is not "
     "stated."),
    ("HeadLampStatus", "Uses the STS_HIGHBEAM enum; whether 'head lamp' means high beam only "
     "is not stated."),
    ("Record 2 (0x045B)", "The sheet is titled EDR_0455_045B and every row carries DID 0x0455; "
     "record 2 is taken to have the same layout."),
    ("Byte 855 bit numbering", "Its fields are numbered from bit 0 upwards (SRS operation mode "
     "bit 0, DOMS bits 1-2, first-crash type bit 3, child-seat class from bit 4), unlike the "
     "rest of the record. This reference follows the only reading without overlaps."),
    ("Unused enum codes", "Several 4-bit fields define fewer codes than they can carry (e.g. "
     "AES_WARNING 0..4, SEB_WARNING_LEFT 0..2, LC_PATH_STATE 0..5). Undefined codes are not "
     "described."),
    ("CAN storage rule", "EDR_Requirements row 3 says CAN signals are stored 'as per the CAN "
     ".dbc M&M_W501_IVN_Communication_Matrix_SRS_V1.25'. Several ICE project signals (e.g. "
     "U171 LONG_ACCEL / YAW_RATE) have a different DBC scaling from this record, so the ECU "
     "converts them; the record scaling here is the authority for decoding."),
]

PREFIX = re.compile(r"^\s*Record\s*1\s*-\s*", re.IGNORECASE)
# The sheet writes a sample time as "at -5 S", "at -5.0 Sec" or "at 250 mS".
TIME_SUFFIX = re.compile(r"\s*at\s*([-+]?\d+(?:\.\d+)?)\s*(m?)s(?:ec)?\s*$", re.IGNORECASE)
LAYOUT_COLUMNS = ("DID", "PARAM_NAME", "LEN_IN_BYTES", "LEN_IN_BITS", "POS_IN_BYTES",
                  "POS_IN_BITS", "OFFSET", "RESOLUTION", "DATA_TYPE", "DATA_FORMAT", "UNIT",
                  "MIN_VALUE", "MAX_VALUE")
CONSISTENT_COLUMNS = ("OFFSET", "RESOLUTION", "DATA_TYPE", "DATA_FORMAT", "UNIT", "MIN_VALUE",
                      "MAX_VALUE")


def _key(text: Any) -> str:
    """A name compared without case, spaces or punctuation."""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _text(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("​", "")).strip()


def _number(value: Any) -> float | None:
    """A numeric cell; '2^32' style powers are evaluated. None for prose or blanks."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    power = re.fullmatch(r"(\d+)\s*\^\s*(\d+)", text)
    if power:
        return float(int(power.group(1)) ** int(power.group(2)))
    try:
        return float(text)
    except ValueError:
        return None


def _integer(value: Any) -> int | None:
    number = _number(value)
    return None if number is None else int(number)


NAME_BY_KEY = {_key(spec): (name, category, meaning) for spec, name, category, meaning in NAMES}
CORRECTIONS_BY_KEY = {_key(spec): fields for spec, fields in CORRECTIONS.items()}
TIME_FIXES_BY_KEY = {_key(spec): fixes for spec, fixes in TIME_FIXES.items()}
PACKED_BY_KEY = {_key(spec): fields for spec, fields in PACKED_FIELDS.items()}


# --------------------------------------------------------------------------- reading


def read_layout(variant: str, workbook: Any) -> list[dict[str, Any]]:
    """Every populated row of the record layout, with its byte inherited where blank."""
    sheet = workbook["EDR_0455_045B"]
    header = {_text(sheet.cell(1, column).value): column
              for column in range(1, sheet.max_column + 1) if sheet.cell(1, column).value}
    rows = []
    owning_byte = None
    for row in range(2, sheet.max_row + 1):
        raw = _text(sheet.cell(row, header["PARAM_NAME"]).value)
        if not raw:
            continue
        cells = {column: sheet.cell(row, header[column]).value for column in LAYOUT_COLUMNS}
        fix = ROW_FIXES.get((variant, row))
        if fix:
            cells.update(fix["cells"])
        name = PREFIX.sub("", raw)
        seconds = None
        match = TIME_SUFFIX.search(name)
        if match:
            seconds = float(match.group(1)) / (1000.0 if match.group(2) else 1.0)
            name = name[: match.start()]
        position = _integer(cells["POS_IN_BYTES"])
        # A bit-packed sample after the first in its byte leaves POS_IN_BYTES blank.
        if position is not None:
            owning_byte = position
        rows.append({
            "row": row,
            "name": _text(name),
            "seconds": seconds,
            "byte": position if position is not None else owning_byte,
            "bit": _integer(cells["POS_IN_BITS"]),
            "len_bytes": _integer(cells["LEN_IN_BYTES"]),
            "len_bits": _integer(cells["LEN_IN_BITS"]),
            "cells": cells,
        })
    return rows


def _enum_value(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip()
    if re.fullmatch(r"0x[0-9a-f]+", text, re.IGNORECASE):
        return int(text, 16)
    if re.fullmatch(r"[0-9]+", text):
        return int(text)
    # Hexadecimal written without 0x: GEAR 'A'..'F', ADAS_Des_StrWhl_Angle_Cmd '7FFF'.
    if re.fullmatch(r"[0-9a-f]*[a-f][0-9a-f]*", text, re.IGNORECASE):
        return int(text, 16)
    return None


def read_enums(workbook: Any) -> tuple[dict[str, dict[int, str]], list[str]]:
    """The enum table, value -> text per enum, and the repeats it contains."""
    sheet = workbook["enum_types"]
    enums: dict[str, dict[int, str]] = {}
    repeats = []
    for row in range(1, sheet.max_row + 1):
        name = _text(sheet.cell(row, 1).value)
        if not name or name.startswith(";") or name == "ENUM_TYPE":
            continue
        value = _enum_value(sheet.cell(row, 3).value)
        text = _text(sheet.cell(row, 2).value)
        if value is None:
            repeats.append(f"{name}: row {row} has no usable value ({sheet.cell(row, 3).value!r})")
            continue
        table = enums.setdefault(name, {})
        if value in table:
            kind = "repeated" if table[value].lower() == text.lower() else "conflicting"
            repeats.append(f"{name}: code {value} {kind} at row {row} ('{text}', first "
                           f"'{table[value]}')")
            continue
        table[value] = text
    return enums, repeats


def read_requirements(workbook: Any) -> dict[str, Any]:
    """General requirements, the two event-scenario tables and the completion table."""
    sheet = workbook["EDR_Requirements"]
    cell = lambda row, column: _text(sheet.cell(row, column).value)  # noqa: E731
    general = [(cell(row, 2), cell(row, 3), cell(row, 5)) for row in range(5, 12)]
    tables = {}
    for title_row, first, last in ((13, 23, 30), (32, 42, 49)):
        rows = [[cell(row, column) for column in range(2, 23)] for row in range(first, last + 1)]
        tables[cell(title_row, 2)] = rows
    completion = [(cell(row, 2), cell(row, 3), cell(row, 4), cell(row, 5))
                  for row in range(53, 56)]
    return {"general": general, "scenarios": tables, "completion": completion,
            "note": cell(57, 2)}


def read_sensors(workbook: Any) -> dict[str, Any]:
    """The crash-sensor DID matrix and the generic sample template."""
    sheet = workbook["EDR Sensor Data"]
    groups = []
    for rate_row, header_row, first, last in ((1, 2, 3, 29), (31, 32, 33, 36)):
        header = {_text(sheet.cell(header_row, column).value): column
                  for column in range(1, 40) if sheet.cell(header_row, column).value}
        projects = [name for name in header
                    if re.fullmatch(r"[A-Z]\d{3}(\(From spec\))?|UPP", name)]
        rates = {name: _text(sheet.cell(rate_row, header[name]).value) for name in projects}
        rows = []
        for row in range(first, last + 1):
            values = {name: _text(sheet.cell(row, column).value) for name, column in header.items()}
            if values.get("RECORD 1"):
                values["row"] = row
                rows.append(values)
        groups.append({"projects": projects, "rates": rates, "rows": rows})
    template = []
    for row in range(49, sheet.max_row + 1):
        name = _text(sheet.cell(row, 2).value)
        if name.startswith("Sensor Data at"):
            template.append((name, _integer(sheet.cell(row, 7).value), _integer(sheet.cell(row, 5).value)))
    first_template = [sheet.cell(49, column).value for column in (9, 10)]
    return {"groups": groups, "template": template, "template_scaling": first_template}


# --------------------------------------------------------------------------- layout


def group_elements(variant: str, rows: list[dict[str, Any]], log: dict[str, list]) -> tuple[
        dict[str, dict[str, Any]], list[dict[str, Any]]]:
    """Rows grouped into elements in sheet order, and the reserved rows."""
    elements: dict[str, dict[str, Any]] = {}
    reserved = []
    for row in rows:
        key = _key(row["name"])
        if key == "reserved":
            reserved.append(row)
            continue
        element = elements.setdefault(key, {"spec_name": row["name"], "rows": []})
        fix = TIME_FIXES_BY_KEY.get(key, {}).get(row["seconds"])
        if fix is not None:
            log["time_fixes"].append((variant, row["row"], row["name"], row["seconds"], fix))
            row = dict(row, seconds=fix)
        if row["seconds"] is not None and any(other["seconds"] == row["seconds"]
                                              for other in element["rows"]):
            # The ICE sheet repeats ECALL_PWM_ACK_CRASH (-1..+1 s) in other bits of the same
            # byte. The first set is the element; it is the one the EV sheet has alone.
            log["dropped"].append((variant, row["row"], row["name"], row["seconds"],
                                   f"{row['byte']}.{row['bit']}"))
            continue
        element["rows"].append(row)
    return elements, reserved


def _width(key: str, element: dict[str, Any]) -> tuple[int, int]:
    """Bits per sample and bytes per sample."""
    first = element["rows"][0]
    corrected = CORRECTIONS_BY_KEY.get(key, {}).get("data_bit_length")
    if corrected:
        return corrected[0], 1
    if first["len_bits"] and first["len_bits"] < 8:
        return first["len_bits"], 1
    size = first["len_bytes"] or 1
    return size * 8, size


def assign_bits(variant: str, elements: dict[str, dict[str, Any]], log: dict[str, list]) -> None:
    """Bits of every single-sample field narrower than a byte.

    POS_IN_BITS is a field's high bit almost everywhere (seat belts at 7, 5, 3, 1). Where
    that reading is impossible (a 3-bit field at bit 0) the position is the low bit. In a
    byte where the high-bit reading makes fields overlap, every field of that byte is read
    from its low bit, which is the only reading without overlaps there.
    """
    by_byte: dict[int, list[str]] = defaultdict(list)
    for key, element in elements.items():
        if len(element["rows"]) == 1 and element["width"] < 8:
            by_byte[element["rows"][0]["byte"]].append(key)

    def bits_for(key: str, reading: str) -> list[int]:
        position = elements[key]["rows"][0]["bit"] or 0
        width = elements[key]["width"]
        if reading == "high" and position - width + 1 >= 0:
            return list(range(position - width + 1, position + 1))
        return list(range(position, position + width))

    for byte, keys in sorted(by_byte.items()):
        assignment: dict[str, list[int]] = {}
        for reading in ("high", "low"):
            assignment = {key: bits_for(key, reading) for key in keys}
            flat = [bit for bits in assignment.values() for bit in bits]
            if len(flat) == len(set(flat)) and max(flat) <= 7:
                break
        else:
            assignment = {key: bits_for(key, "high") for key in keys}
            log["overlaps"].append((variant, byte, "fields overlap under either bit reading"))
        if reading == "low" and any(elements[key]["width"] > 1 for key in keys):
            log["lsb_bytes"].append((variant, byte, [elements[key]["spec_name"] for key in keys]))
        for key, bits in assignment.items():
            elements[key]["bits"] = bits


def occupancy(element: dict[str, Any]) -> list[tuple[int, int]]:
    """Every (payload byte, bit) the element occupies."""
    cells = []
    width = element["width"]
    for row in element["rows"]:
        if width >= 8:
            for byte in range(row["byte"], row["byte"] + element["bytes_per_sample"]):
                cells.extend((byte, bit) for bit in range(8))
        elif "bits" in element:
            cells.extend((row["byte"], bit) for bit in element["bits"])
        else:
            high = row["bit"] if row["bit"] is not None else 7
            cells.extend((row["byte"], bit) for bit in range(high - width + 1, high + 1))
    return cells


def reserved_occupancy(row: dict[str, Any]) -> list[tuple[int, int]]:
    if row["len_bits"] and row["len_bits"] < 8:
        return [(row["byte"], row["bit"] or 0)]
    size = row["len_bytes"] or 1
    return [(byte, bit) for byte in range(row["byte"], row["byte"] + size) for bit in range(8)]


def build_entry(variant: str, key: str, element: dict[str, Any], enums: dict[str, dict[int, str]],
                log: dict[str, list]) -> dict[str, Any]:
    """The element as an edr_config-style dictionary, for one variant."""
    rows = element["rows"]
    first, last = rows[0], rows[-1]
    width, bytes_per_sample = element["width"], element["bytes_per_sample"]
    samples = len(rows)
    sub_byte = width < 8
    start = first["byte"] + BYTE_NUMBER_OFFSET
    end = last["byte"] + BYTE_NUMBER_OFFSET + (0 if sub_byte else bytes_per_sample - 1)
    if samples > 1:
        kind = "multi_sample_bits" if sub_byte else "multi_sample_bytes"
    elif sub_byte:
        kind = "bit" if width == 1 else "bits"
    else:
        kind = "int"

    for column in CONSISTENT_COLUMNS:
        values = {_text(row["cells"][column]) for row in rows}
        if len(values) > 1:
            log["inconsistent"].append((variant, element["spec_name"], column, sorted(values)))

    cells = first["cells"]
    scaling = _number(cells["RESOLUTION"])
    entry: dict[str, Any] = {
        "type": kind,
        "data_start_byte": start,
        "data_end_byte": end,
        "data_byte_length": end - start + 1,
        "data_bit_length": width,
        "data_bytes_per_sample": bytes_per_sample,
        "data_samples_number": samples,
        "scaling_factor": 1.0 if scaling is None else scaling,
        "offset": _number(cells["OFFSET"]) or 0.0,
        "unit": _text(cells["UNIT"]) or None,
        "minimum": _number(cells["MIN_VALUE"]),
        "maximum": _number(cells["MAX_VALUE"]),
        "sample_range": None,
        "recording_model": "interval" if samples > 1 else "snapshot",
    }
    if _text(cells["DATA_FORMAT"]) != "BIG ENDIAN":
        log["inconsistent"].append((variant, element["spec_name"], "DATA_FORMAT",
                                    [_text(cells["DATA_FORMAT"])]))

    if kind in ("bit", "bits"):
        low, high = min(element["bits"]), max(element["bits"])
        entry["range"] = f"{start}.{low}" if low == high else f"{start}.{low}-{start}.{high}"
    if kind == "multi_sample_bits":
        stream = [row["byte"] * 8 + (7 - (row["bit"] if row["bit"] is not None else 7))
                  for row in rows]
        if any(later - earlier != width for earlier, later in zip(stream, stream[1:])):
            log["gapped"].append((variant, element["spec_name"],
                                  [f"{row['byte']}.{row['bit']}" for row in rows]))
        offset_bits = stream[0] - first["byte"] * 8
        if offset_bits:
            entry["data_first_bit_offset"] = offset_bits
    if kind == "multi_sample_bytes":
        positions = [row["byte"] for row in rows]
        if any(later - earlier != bytes_per_sample for earlier, later in zip(positions, positions[1:])):
            log["gapped"].append((variant, element["spec_name"], positions))

    times = [row["seconds"] for row in rows]
    if samples > 1 and all(time is not None for time in times):
        ordered = sorted(times)
        steps = {round(later - earlier, 6) for earlier, later in zip(ordered, ordered[1:])}
        if len(steps) != 1:
            log["irregular"].append((variant, element["spec_name"], ordered))
        if times != ordered:
            log["unordered"].append((variant, element["spec_name"], times))
        entry["sample_range"] = {"start": ordered[0], "end": ordered[-1], "step": min(steps)}

    data_type = _text(cells["DATA_TYPE"])
    enum_name = data_type[5:].strip() if data_type.upper().startswith("ENUM:") else None
    corrections = CORRECTIONS_BY_KEY.get(key, {})
    applied = []
    for field, (value, spec_text, evidence, confidence) in corrections.items():
        if field == "enum":
            enum_name = value
        elif field == "labels_add":
            continue
        elif field != "data_bit_length":
            entry[field] = value
        applied.append((field, value, spec_text, evidence, confidence))
    if enum_name is not None:
        if enum_name in enums:
            labels = dict(sorted(enums[enum_name].items()))
            if "labels_add" in corrections:
                labels.update(corrections["labels_add"][0])
            entry["labels"] = dict(sorted(labels.items()))
        else:
            log["missing_enum"].append((variant, element["spec_name"], enum_name))
    elif key in {_key(name) for name in enums}:
        # A numeric element whose name also has an enum: the enum names special raw codes.
        special = next(table for name, table in enums.items() if _key(name) == key)
        entry["raw_values"] = dict(sorted(special.items()))
    entry["_enum"] = enum_name
    entry["_applied"] = applied
    entry["_rows"] = f"{first['row']}" if samples == 1 else f"{first['row']}-{last['row']}"
    entry["_data_type"] = data_type

    # Signedness comes from the specification's own arithmetic: the raw minimum is
    # (MIN_VALUE - OFFSET) / RESOLUTION, and the raw is two's complement when it is negative.
    minimum, offset, scale = entry["minimum"], entry["offset"], entry["scaling_factor"]
    entry["signed"] = bool(minimum is not None and scale
                           and (minimum - offset) / scale < -1e-9)

    packed = PACKED_BY_KEY.get(key)
    if packed:
        entry["fields"] = {
            field: {
                "range": [f"{start + byte}.{bit}" for byte, bit in bits],
                "unit": unit,
                "minimum": minimum,
                "maximum": maximum,
                **({"config_name": config_name} if config_name else {}),
            }
            for field, bits, unit, minimum, maximum, config_name in packed
        }
    return entry


def analyse() -> dict[str, Any]:
    """Read both workbooks and build the merged reference."""
    import openpyxl

    log: dict[str, list] = defaultdict(list)
    per_variant: dict[str, dict[str, Any]] = {}
    for variant in VARIANTS:
        workbook = openpyxl.load_workbook(WORKBOOKS[variant], data_only=True)
        rows = read_layout(variant, workbook)
        elements, reserved = group_elements(variant, rows, log)
        for key, element in elements.items():
            element["width"], element["bytes_per_sample"] = _width(key, element)
        assign_bits(variant, elements, log)
        enums, repeats = read_enums(workbook)
        entries = {key: build_entry(variant, key, element, enums, log)
                   for key, element in elements.items()}
        owners: dict[tuple[int, int], list[str]] = defaultdict(list)
        for key, element in elements.items():
            for cell in occupancy(element):
                owners[cell].append(element["spec_name"])
        for row in reserved:
            for cell in reserved_occupancy(row):
                owners[cell].append("Reserved")
        for cell, names in sorted(owners.items()):
            if len(names) > 1:
                log["overlaps"].append((variant, cell[0], f"bit {cell[1]}: {', '.join(names)}"))
        last_byte = max(byte for byte, _ in owners)
        unused = [(byte, bit) for byte in range(last_byte + 1) for bit in range(8)
                  if (byte, bit) not in owners]
        per_variant[variant] = {
            "elements": elements, "entries": entries, "reserved": reserved, "enums": enums,
            "enum_repeats": repeats, "last_byte": last_byte, "unused": unused,
            "requirements": read_requirements(workbook), "sensors": read_sensors(workbook),
            "sha256": hashlib.sha256(WORKBOOKS[variant].read_bytes()).hexdigest(),
        }

    order: list[str] = []
    for variant in VARIANTS:
        for key in per_variant[variant]["elements"]:
            if key not in order:
                order.append(key)
    # Record order: by first byte, and inside a shared byte by sheet row.
    order.sort(key=lambda key: min((per_variant[v]["elements"][key]["rows"][0]["byte"],
                                    per_variant[v]["elements"][key]["rows"][0]["row"])
                                   for v in VARIANTS if key in per_variant[v]["elements"]))
    unnamed = [key for key in order if key not in NAME_BY_KEY]
    if unnamed:
        raise SystemExit(f"No generic name for: {unnamed}. Add them to NAMES.")
    return {"variants": per_variant, "order": order, "log": log}


# --------------------------------------------------------------------------- configs


def load_configs() -> dict[str, list[dict[str, Any]]]:
    configs = {}
    for project in CONFIG_PROJECTS:
        path = REPOSITORY_ROOT / "projects" / project / "config" / "edr_config.py"
        spec = importlib.util.spec_from_file_location(f"edr_config_{project}", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        configs[project] = module.EDR_PARAMETERS
    return configs


def config_names(configs: dict[str, list[dict[str, Any]]]) -> tuple[
        dict[str, dict[str, str]], dict[str, str]]:
    """Per element, the name each vehicle class's configurations use, and grouped entries."""
    names: dict[str, dict[str, str]] = defaultdict(dict)
    groups: dict[str, str] = {}
    for project, entries in configs.items():
        variant = CONFIG_PROJECTS[project]
        for entry in entries:
            spec_name = entry.get("spec_name")
            if isinstance(spec_name, list):
                for member in spec_name:
                    groups[_key(member)] = entry["name"]
                continue
            if spec_name is None or entry.get("type") == "custom_bits":
                continue
            names[_key(spec_name)].setdefault(variant, entry["name"])
    return names, groups


COMPARED_FIELDS = ("data_start_byte", "data_end_byte", "data_bit_length", "data_samples_number",
                   "data_first_bit_offset", "range", "signed", "scaling_factor", "offset", "unit",
                   "minimum", "maximum", "sample_range")


def _same(left: Any, right: Any) -> bool:
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(_same(left[k], right[k]) for k in left)
    if isinstance(left, (int, float)) and isinstance(right, (int, float)) \
            and not isinstance(left, bool) and not isinstance(right, bool):
        return abs(left - right) < 1e-9
    return left == right


def config_drift(model: dict[str, Any], configs: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    """Where each project's edr_config differs from this reference."""
    drift = {}
    for project, entries in configs.items():
        variant = CONFIG_PROJECTS[project]
        reference = model["variants"][variant]["entries"]
        covered = set()
        differences = []
        for entry in entries:
            spec_name = entry.get("spec_name")
            if isinstance(spec_name, list):
                covered.update(_key(member) for member in spec_name)
                continue
            if spec_name is None:
                continue
            key = _key(spec_name)
            covered.add(key)
            if entry.get("type") == "custom_bits" or key not in reference:
                if key not in reference and variant in entry.get("variants", [variant]):
                    differences.append((entry["name"], "element", "-", "not in this variant's sheet"))
                continue
            expected = reference[key]
            for field in COMPARED_FIELDS:
                have, want = entry.get(field), expected.get(field)
                if not _same(have, want):
                    differences.append((entry["name"], field, _brief(have), _brief(want)))
            defined_in = [v for v in VARIANTS if key in model["variants"][v]["entries"]]
            if entry.get("variants") is not None and entry["variants"] != defined_in:
                differences.append((entry["name"], "variants", _brief(entry["variants"]),
                                    _brief(defined_in)))
        missing = [model["variants"][variant]["elements"][key]["spec_name"]
                   for key in reference if key not in covered]
        drift[project] = {"variant": variant, "differences": differences, "missing": missing}
    return drift


# --------------------------------------------------------------------------- rendering


def _brief(value: Any) -> str:
    if isinstance(value, dict):
        return "{" + ", ".join(f"{k}: {_brief(v)}" for k, v in value.items()) + "}"
    if isinstance(value, float) and value.is_integer() and abs(value) >= 1e6:
        return str(int(value))
    return str(value)


def _literal(value: Any, indent: int) -> str:
    """Python literal text, one key per line for dictionaries that do not fit a line."""
    pad = " " * indent
    if isinstance(value, dict):
        inline = "{" + ", ".join(f"{_literal(k, 0)}: {_literal(v, 0)}" for k, v in value.items()) + "}"
        if len(inline) + indent <= 96 and not any(isinstance(v, dict) for v in value.values()):
            return inline
        inner = " " * (indent + 4)
        lines = [f"{inner}{_literal(k, 0)}: {_literal(v, indent + 4)}," for k, v in value.items()]
        return "{\n" + "\n".join(lines) + f"\n{pad}}}"
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_literal(v, 0) for v in value) + "]"
    if isinstance(value, str):
        return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'
    if isinstance(value, bool) or value is None:
        return repr(value)
    if isinstance(value, float):
        return repr(value)
    return str(value)


DOC_FIELDS = ("name", "spec_name", "config_name", "config_group", "type", "data_start_byte",
              "data_end_byte", "data_byte_length", "data_bit_length", "data_bytes_per_sample",
              "data_samples_number", "data_first_bit_offset", "range", "signed",
              "scaling_factor", "offset", "unit", "minimum", "maximum", "sample_range",
              "recording_model", "labels", "raw_values", "fields", "variants")


def merged(model: dict[str, Any], key: str, names: dict[str, dict[str, str]],
           groups: dict[str, str]) -> dict[str, Any]:
    """The element's entry with one value per field, or {ICE: .., EV: ..} where they differ."""
    variants = [v for v in VARIANTS if key in model["variants"][v]["entries"]]
    entries = {v: model["variants"][v]["entries"][key] for v in variants}
    spec_names = {v: model["variants"][v]["elements"][key]["spec_name"] for v in variants}
    name, _, _ = NAME_BY_KEY[key]
    result: dict[str, Any] = {"name": name}

    def combine(values: dict[str, Any]) -> Any:
        distinct = list(values.values())
        if all(_same(distinct[0], other) for other in distinct[1:]):
            return distinct[0]
        return dict(values)

    result["spec_name"] = combine(spec_names)
    own = {v: names.get(key, {}).get(v) for v in variants}
    own = {v: n for v, n in own.items() if n}
    if own:
        result["config_name"] = combine(own)
    if key in groups:
        result["config_group"] = groups[key]
    for field in DOC_FIELDS[4:-1]:
        values = {v: entries[v].get(field) for v in variants}
        if all(value is None for value in values.values()) and field in (
                "data_first_bit_offset", "range", "labels", "raw_values", "fields"):
            continue
        result[field] = combine(values)
    result["variants"] = variants
    return result


def _window(entry: dict[str, Any]) -> str:
    sample_range = entry.get("sample_range")
    if not sample_range:
        return "T0"
    if "start" not in sample_range:
        return "; ".join(f"{v} {_window({'sample_range': r})}" for v, r in sample_range.items())
    step = sample_range["step"]
    step_text = f"{step * 1000:g} ms" if step < 0.1 else f"{step:g} s"
    return f"{sample_range['start']:g} to {sample_range['end']:g} s, every {step_text}"


def render_parameters(model: dict[str, Any], names: dict[str, dict[str, str]],
                      groups: dict[str, str]) -> str:
    ice, ev = model["variants"]["ICE"], model["variants"]["EV"]
    docs = {key: merged(model, key, names, groups) for key in model["order"]}
    both = [k for k in model["order"] if docs[k]["variants"] == ["ICE", "EV"]]
    ice_only = [docs[k]["name"] for k in model["order"] if docs[k]["variants"] == ["ICE"]]
    ev_only = [docs[k]["name"] for k in model["order"] if docs[k]["variants"] == ["EV"]]
    differing = [(docs[k]["name"], field) for k in both for field in DOC_FIELDS
                 if isinstance(docs[k].get(field), dict) and set(docs[k][field]) == {"ICE", "EV"}
                 and field not in ("labels", "fields", "sample_range")]
    corrected = sum(1 for k in model["order"] if correction_notes(model, k, docs[k]["variants"]))

    out: list[str] = []
    w = out.append
    w("# Common EDR parameters - ICE and EV")
    w("")
    w("One reference for every parameter of the SRS event data record, DIDs 0x0455 (event 1) "
      "and 0x045B (event 2), in both the ICE and the EV specification. Each parameter is an "
      "`edr_config`-style dictionary under a short generic name; `spec_name` is the name in "
      "the specification and `config_name` the name the project `edr_config` files and "
      "scripts use today.")
    w("")
    w("Source gaps that were corrected are noted under the parameter they affect. The full "
      "list, the open questions and the differences from each project's `edr_config` are in "
      "[EDR_COMMON_GAPS.md](EDR_COMMON_GAPS.md).")
    w("")
    w("Generated by `tools/build_edr_common_parameter_doc.py`; edit the tool, not this file.")
    w("")
    w("## Sources")
    w("")
    w("| Variant | Workbook | Identical to | SHA-256 |")
    w("|---|---|---|---|")
    for variant in VARIANTS:
        rel = WORKBOOKS[variant].relative_to(SPEC_DIR).as_posix()
        w(f"| {variant} | [{rel}](<{rel}>) | EDR sheets of `{DIAG_SPECS[variant]}` | "
          f"`{model['variants'][variant]['sha256']}` |")
    w("")

    w("## 1. The record at a glance")
    w("")
    w("Both specifications use one layout, sheet `EDR_0455_045B`, for both event records. "
      f"Payload bytes 0-{ev['last_byte']} hold the same parameters at the same positions in "
      "both. ICE adds one parameter, ClutchStatus, after the EV record ends, so **the ICE "
      f"record is {ice['last_byte'] - ev['last_byte']} bytes longer**.")
    w("")
    w("| | ICE | EV |")
    w("|---|---|---|")
    w(f"| Payload length (bytes) | {ice['last_byte'] + 1} (bytes 0-{ice['last_byte']}) | "
      f"{ev['last_byte'] + 1} (bytes 0-{ev['last_byte']}) |")
    w(f"| Positive response to `22 04 55` (bytes, with `62 04 55`) | "
      f"{ice['last_byte'] + 1 + RESPONSE_HEADER_BYTES} | {ev['last_byte'] + 1 + RESPONSE_HEADER_BYTES} |")
    w(f"| Last byte in `edr_config` numbering | {ice['last_byte'] + BYTE_NUMBER_OFFSET} | "
      f"{ev['last_byte'] + BYTE_NUMBER_OFFSET} |")
    w(f"| Parameters | {len(ice['entries'])} | {len(ev['entries'])} |")
    w(f"| Reserved allocations (record 0x00) | {len(ice['reserved'])} | {len(ev['reserved'])} |")
    w("")
    w(f"{len(both)} parameters are common. ICE only: {', '.join(ice_only) or 'none'}. "
      f"EV only: {', '.join(ev_only) or 'none'}. The diagnostic specifications give the DID "
      "length only as 'Refer EDR Data Tab', so the length above is where the layout ends.")
    w("")
    w("Where the two specifications define a common parameter differently, the field holds "
      "`{\"ICE\": ..., \"EV\": ...}`. That happens for:")
    w("")
    by_field: dict[str, list[str]] = defaultdict(list)
    for name, field in differing:
        by_field[field].append(name)
    for field, names_list in by_field.items():
        w(f"- `{field}`: {', '.join(names_list)}")
    w("")
    w(f"{corrected} parameters carry a correction to the source; each is listed under the "
      "parameter.")
    w("")

    w("## 2. How to read an entry")
    w("")
    w("| Field | Meaning |")
    w("|---|---|")
    for field, meaning in (
        ("name", "Generic parameter name used in this reference."),
        ("spec_name", "Name in the specification, without the `Record 1 -` prefix and the `at <time>` suffix."),
        ("config_name", "Name the project `edr_config` files (U171, Z121, M310_M314_M110) and their scripts use."),
        ("config_group", "The configs also decode this parameter inside one grouped entry of that name."),
        ("type", "`int` whole bytes; `bit` / `bits` one field inside a byte; `multi_sample_bytes` / `multi_sample_bits` a time series."),
        ("data_start_byte / data_end_byte", "Inclusive byte span in `edr_config` numbering: payload byte + 4 (3-byte response header `62 04 55`, 1-based). Payload byte 0 is `data_start_byte` 4."),
        ("data_byte_length", "`data_end_byte - data_start_byte + 1`."),
        ("data_bit_length", "Width of one sample in bits."),
        ("data_bytes_per_sample", "Bytes per sample for byte-wide samples; 1 for packed bits."),
        ("data_samples_number", "Samples stored; 1 for a snapshot."),
        ("data_first_bit_offset", "Bits between bit 7 of the start byte and the first sample, for a packed series that does not start at bit 7."),
        ("range", "Bits of a `bit`/`bits` field as `byte.low-byte.high` (bit 7 = most significant), `edr_config` numbering."),
        ("signed", "Raw value is two's complement. Derived from the specification's arithmetic: signed when `(minimum - offset) / scaling_factor` is negative. Several fields labelled SIGNED store an unsigned raw shifted by a negative offset."),
        ("scaling_factor / offset", "`physical = raw * scaling_factor + offset`."),
        ("unit / minimum / maximum", "Physical unit and range."),
        ("sample_range", "`start`/`end`/`step` in seconds relative to T0; `None` for a snapshot."),
        ("recording_model", "`interval` (time series) or `snapshot`."),
        ("labels", "Enum codes from the `enum_types` sheet."),
        ("fields", "Sub-fields of a custom packed value (event date and time)."),
        ("variants", "Vehicle classes whose specification defines the parameter."),
    ):
        w(f"| `{field}` | {meaning} |")
    w("")
    w("**Bit packing.** A packed series is a most-significant-first bit stream: inside a byte "
      "the samples step down from bit 7 by their width, then continue at bit 7 of the next "
      "byte. Fields are 1, 2 or 4 bits wide, so no sample straddles a byte. Samples are "
      "stored in time order, earliest first.")
    w("")
    w("**Bit positions in the source.** `POS_IN_BITS` is a field's high bit almost "
      "everywhere. It is the low bit where the high-bit reading is impossible (Engine State, "
      "Doors Open Status) and throughout payload byte 855, where only the low-bit reading "
      "avoids overlaps.")
    w("")
    w("**Default and reserved values.** With no event recorded, the whole DID reads `0xFF`, "
      "reserved bytes included. In a recorded event, a parameter that is not configured on "
      "the variant records all ones (`0xFF` per byte), and reserved bits and bytes record "
      "`0x00`. All multi-byte values are big-endian.")
    w("")

    write_requirements(w, model)

    w("## 4. Parameter index")
    w("")
    w("| # | name | spec_name | config_name | bytes (config) | samples | window | variants |")
    w("|---|---|---|---|---|---|---|---|")
    for index, key in enumerate(model["order"], 1):
        doc = docs[key]
        spec = doc["spec_name"] if isinstance(doc["spec_name"], str) else doc["spec_name"]["ICE"]
        config = doc.get("config_name", "")
        if isinstance(config, dict):
            config = " / ".join(f"{v}: {n}" for v, n in config.items())
        start = doc["data_start_byte"]
        end = doc["data_end_byte"]
        span = f"{start}" if start == end else f"{start}-{end}"
        if isinstance(start, dict) or isinstance(end, dict):
            span = "see entry"
        w(f"| {index} | [{doc['name']}](#{doc['name'].lower()}) | {spec} | {config} | {span} | "
          f"{_brief(doc['data_samples_number'])} | {_window(doc)} | {', '.join(doc['variants'])} |")
    w("")

    w("## 5. Parameters")
    w("")
    for category, title in CATEGORIES:
        keys = [key for key in model["order"] if NAME_BY_KEY[key][1] == category]
        if not keys:
            continue
        w(f"### {title}")
        w("")
        if category == "crash":
            w("The seven crash-type bits and the lock bit share payload byte 22 "
              "(`edr_config` byte 26). The configs also decode bits 0-6 together as "
              "`CrashLocation`.")
            w("")
        if category == "deploy_time":
            w("The configs also decode all 21 times together as `TimetoDeployCmd`. The "
              "resolution differs: 0.5 ms in ICE, 1 ms in EV.")
            w("")
        if category == "deploy_status":
            w("The configs also decode the first 12 status bits together as "
              "`Squib_Deployment_Status`. U171 labels the driver-side loops 'Right' and the "
              "passenger-side loops 'Left' (right-hand drive).")
            w("")
        for key in keys:
            doc = docs[key]
            meaning = NAME_BY_KEY[key][2]
            rows = {v: model["variants"][v]["entries"][key]["_rows"] for v in doc["variants"]}
            w(f"#### {doc['name']}")
            w("")
            w(f"{meaning} Source rows: "
              + ", ".join(f"{v} {r}" for v, r in rows.items()) + ".")
            w("")
            w("```python")
            w(_literal({field: doc[field] for field in DOC_FIELDS if field in doc}, 0))
            w("```")
            w("")
            notes = correction_notes(model, key, doc["variants"])
            if notes:
                w("Corrections:")
                w("")
                for note in notes:
                    w(f"- {note}")
                w("")

    w("## 6. Reserved allocations")
    w("")
    w("Reserved space inside the record. It records `0x00` in an event.")
    w("")
    w("| Payload byte | Bits | `edr_config` byte | Source rows (ICE / EV) | Note |")
    w("|---|---|---|---|---|")
    for ice_row, ev_row in zip(ice["reserved"], ev["reserved"]):
        width = ice_row["len_bits"] if ice_row["len_bits"] and ice_row["len_bits"] < 8 else None
        bits = f"bit {ice_row['bit']}" if width else f"bytes {ice_row['byte']}-{ice_row['byte'] + (ice_row['len_bytes'] or 1) - 1}"
        note = ("deployment-time slot (resolution "
                f"{_text(ice_row['cells']['RESOLUTION'])} ICE / {_text(ev_row['cells']['RESOLUTION'])} EV)"
                if not width else "deployment-status bit")
        w(f"| {ice_row['byte']} | {bits} | {ice_row['byte'] + BYTE_NUMBER_OFFSET} | "
          f"{ice_row['row']} / {ev_row['row']} | {note} |")
    w("")

    write_sensors(w, model)
    return "\n".join(out) + "\n"


def correction_notes(model: dict[str, Any], key: str, variants: list[str]) -> list[str]:
    """What was corrected in the source for this parameter, one sentence each."""
    notes = []
    for variant in variants:
        for field, value, spec_text, evidence, confidence in \
                model["variants"][variant]["entries"][key]["_applied"]:
            note = (f"`{field}`: specification says `{spec_text}`, used "
                    f"`{_brief(value)}`. {evidence} Confidence: {confidence}.")
            if note not in notes:
                notes.append(note)
    for fix in ROW_FIXES.values():
        if _key(fix["parameter"]) == key:
            notes.append(f"ICE source: {fix['spec']}, used {fix['used']}. {fix['evidence']}")
    if key in TIME_FIXES_BY_KEY:
        spec_text, used, evidence, confidence = TIME_FIX_EVIDENCE[
            next(s for s in TIME_FIXES if _key(s) == key)]
        notes.append(f"Sample label: {spec_text}, used {used}. {evidence} "
                     f"Confidence: {confidence}.")
    unordered = [v for v, name, _ in model["log"]["unordered"]
                 if _key(name) == key]
    if unordered:
        notes.append("The source labels its samples out of time order; the slots are "
                     "read in time order, like every other series.")
    dropped = [r for r in model["log"]["dropped"] if _key(r[2]) == key]
    if dropped:
        notes.append(f"The ICE sheet lists these samples twice (rows "
                     f"{dropped[0][1]}-{dropped[-1][1]}, bits "
                     f"{dropped[0][4]}..{dropped[-1][4]}); the first set is used, as in EV.")
    return notes


def write_requirements(w: Any, model: dict[str, Any]) -> None:
    requirements = model["variants"]["ICE"]["requirements"]
    w("## 3. Recording rules (sheet `EDR_Requirements`)")
    w("")
    w("The same in both specifications, apart from wording noted in the gap register.")
    w("")
    w("| # | Topic | Requirement |")
    w("|---|---|---|")
    for number, topic, text in requirements["general"]:
        w(f"| {number} | {topic} | {text.replace('|', '/')} |")
    w("")
    w("Completion status:")
    w("")
    w("| CompletionStatus | Completion200ms | Meaning | Applies to |")
    w("|---|---|---|---|")
    for completion, short, meaning, applies in requirements["completion"]:
        w(f"| {completion} | {short} | {meaning} | {applies} |")
    w("")
    w(f"{requirements['note']}")
    w("")
    w("Event scenarios. Inputs: 0 = near crash (no deployment), 1 = deployment event. "
      "`MEN` multi-event number, `TBE` time between events, `LEN` lifetime event number, "
      "`Lock` record lock status (1 locked).")
    w("")
    head = ("| Event 1 | Event 2 | Event 3 | After event 2: EDR1 / EDR2 | MEN | TBE | LEN | "
            "After event 3: EDR1 / EDR2 | MEN | TBE | LEN | Lock |")
    for title, rows in requirements["scenarios"].items():
        w(f"**{title}**")
        w("")
        w(head)
        w("|" + "---|" * 12)
        for r in rows:
            r = [cell.replace("(less than 5sec)", "(<5 s)") for cell in r]
            w(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} / {r[4]} | {r[5]} / {r[6]} | "
              f"{r[7]} / {r[8]} | {r[9]} / {r[10]} | {r[11]} / {r[12]} | {r[13]} / {r[14]} | "
              f"{r[15]} / {r[16]} | {r[17]} / {r[18]} | {r[19]} / {r[20]} |")
        w("")


SENSOR_NAMES = {
    "0480": "AccelApillarPassengerY", "048A": "AccelApillarPassengerX",
    "047F": "AccelApillarDriverY", "0489": "AccelApillarDriverX",
    "0461": "AccelBpillarPassengerY", "049F": "AccelBpillarPassengerX",
    "0462": "AccelBpillarDriverY", "049E": "AccelBpillarDriverX",
    "045F": "AccelCentralY", "0460": "AccelCentralX",
    "0485": "AccelFrontPassengerY", "0463": "AccelFrontPassengerX",
    "0486": "AccelFrontDriverY", "0464": "AccelFrontDriverX",
    "047B": "AccelCpillarPassengerY", "0488": "AccelCpillarPassengerX",
    "047A": "AccelCpillarDriverY", "0487": "AccelCpillarDriverX",
    "0481": "AccelRearX", "0499": "AccelUnderbodyY", "049A": "AccelUnderbodyZ",
    "0466": "PressureDoorPassenger", "0465": "PressureDoorDriver",
    "048D": "AccelHighGX", "0477": "AccelHighGZ",
    "048B": "RsuDuplicateX", "048C": "RsuDuplicateY",
    "04AB": "ImuX", "04AD": "ImuZ", "04AF": "OnboardY", "04B1": "RollRateSoftware",
}


def write_sensors(w: Any, model: dict[str, Any]) -> None:
    ice, ev = model["variants"]["ICE"]["sensors"], model["variants"]["EV"]["sensors"]
    w("## 7. Crash sensor DIDs (sheet `EDR Sensor Data`)")
    w("")
    w("Separate DIDs, one per sensor channel and event record, read alongside the event record. "
      "`Yes`/`NA` is the sheet's per-project applicability; M210 appears in the EV sheet "
      "only. A DID that does not apply to a variant answers NRC 0x31.")
    w("")
    for index, (ice_group, ev_group) in enumerate(zip(ice["groups"], ev["groups"])):
        projects = list(dict.fromkeys(ice_group["projects"] + ev_group["projects"]))
        rates = {**ice_group["rates"], **ev_group["rates"]}
        w(f"**Group {index + 1}** - sampling: "
          + ", ".join(f"{p.replace('(From spec)', '')} {rates.get(p) or '?'}" for p in projects)
          + ".")
        w("")
        w("| name | Sensor (DID name) | Record 1 | Record 2 | "
          + " | ".join(p.replace("(From spec)", "") for p in projects)
          + " | Range | Resolution | Stored value | Note |")
        w("|" + "---|" * (8 + len(projects)))
        ev_rows = {row["RECORD 1"]: row for row in ev_group["rows"]}
        for row in ice_group["rows"]:
            other = ev_rows.get(row["RECORD 1"], {})
            cells = [other.get(p, "") if p not in ice_group["projects"] else row.get(p, "")
                     for p in projects]
            note = row.get("Comment", "") or row.get("Comments", "")
            w(f"| {SENSOR_NAMES.get(row['RECORD 1'], '')} | {row['DID Name Customer Sheet']} | "
              f"{row['RECORD 1']} | {row['RECORD 2']} | " + " | ".join(cells)
              + f" | {row.get('Range', '')} | {row.get('Resolution', '')} | "
              f"{row.get('Stored Value Formula', '')} | {note} |")
        w("")
    template = ice["template"]
    first, last = template[0], template[-1]
    w(f"**Sample template.** The sheet gives one generic layout: {len(template)} one-byte "
      f"samples, `{first[0]}` at payload byte {first[1]} to `{last[0]}` at byte {last[1]}, "
      "every 0.5 ms. It is not bound to a named DID, and its only scaling cells "
      f"(OFFSET {ice['template_scaling'][0]}, RESOLUTION {ice['template_scaling'][1]}) "
      "contradict the per-sensor stored-value formulas above. The IMU / roll-rate DIDs "
      "(group 2) record -1 s to +9 s every 10 ms on M314 only; their layout is not given.")
    w("")


def render_gaps(model: dict[str, Any], drift: dict[str, Any]) -> str:
    log = model["log"]
    out: list[str] = []
    w = out.append
    w("# Common EDR specification - gaps, corrections and config drift")
    w("")
    w("Companion to [EDR_COMMON_PARAMETERS.md](EDR_COMMON_PARAMETERS.md). It lists what the two "
      "common EDR workbooks get wrong or leave open, what the reference does about each, and "
      "where today's project `edr_config` files differ from the reference. Generated by "
      "`tools/build_edr_common_parameter_doc.py`.")
    w("")
    w("Confidence: **High** = the source contradicts itself or the field width and the fix "
      "follows; **Medium** = the fix rests on other evidence (DBC, sibling fields) and should "
      "be confirmed with the OEM.")
    w("")

    w("## 1. Corrections applied")
    w("")
    w("| # | Parameter | Field | Specification | Used | Evidence | Confidence |")
    w("|---|---|---|---|---|---|---|")
    number = 0
    for key in model["order"]:
        seen = set()
        for variant in VARIANTS:
            entry = model["variants"][variant]["entries"].get(key)
            if not entry:
                continue
            for field, value, spec_text, evidence, confidence in entry["_applied"]:
                if field in seen:
                    continue
                seen.add(field)
                number += 1
                w(f"| {number} | {NAME_BY_KEY[key][0]} | `{field}` | `{spec_text}` | "
                  f"`{_brief(value)}` | {evidence} | {confidence} |")
    for (variant, row), fix in ROW_FIXES.items():
        number += 1
        w(f"| {number} | {NAME_BY_KEY[_key(fix['parameter'])][0]} | {variant} row {row} | "
          f"{fix['spec']} | {fix['used']} | {fix['evidence']} | {fix['confidence']} |")
    for spec, (spec_text, used, evidence, confidence) in TIME_FIX_EVIDENCE.items():
        number += 1
        w(f"| {number} | {NAME_BY_KEY[_key(spec)][0]} | sample label | {spec_text} | {used} | "
          f"{evidence} | {confidence} |")
    if log["dropped"]:
        number += 1
        rows = sorted({r[1] for r in log["dropped"]})
        w(f"| {number} | {NAME_BY_KEY[_key(log['dropped'][0][2])][0]} | ICE rows "
          f"{rows[0]}-{rows[-1]} | samples -1..+1 s listed twice (second set in bits "
          f"{log['dropped'][0][4]}..{log['dropped'][-1][4]}) | first set only (5 samples) | "
          "The second set overlaps the first in the same byte; EV lists the first set only. | High |")
    number += 1
    w(f"| {number} | CompletionStatus | name | EV `Completion Status`, ICE `CompletionStatus` | "
      "one parameter | Same byte, bit and enum in both. | High |")
    w("")

    w("## 2. Open questions")
    w("")
    w("Not corrected; the reference keeps the source value.")
    w("")
    for subject, text in OPEN_QUESTIONS:
        w(f"- **{subject}.** {text}")
    w("")

    w("## 3. Differences between the ICE and EV sources")
    w("")
    w("- Deployment times (21 loops and the three reserved 2-byte slots): resolution 0.5 ms "
      "ICE, 1 ms EV.")
    w("- Clutch Status (payload bytes 880-882) and its CLUTCH_STS enum exist in ICE only, "
      "so the ICE record is 3 bytes longer.")
    w("- `CompletionStatus` (ICE) is written `Completion Status` (EV).")
    w("- ICE row 872 places one STS_LOWBEAM sample in byte 800 (EV: 801); ICE repeats "
      "ECALL_PWM_ACK_CRASH. Both corrected above.")
    w("- `EDR_Requirements`: the multi-event heading reads '>500ms and <5sec' in ICE and "
      "'>500m' in EV; 'DOOR_UNLOCK' is written 'Door_UNLOCK' in EV. Same tables otherwise.")
    w("- `EDR Sensor Data`: EV adds an M210 column (applicability and 0.5 ms sampling). EV's "
      "internal references call several longitudinal (X axis) channels 'ALat...'; ICE "
      "writes 'ALgt...'. EV carries review notes ('Deviation observed', 'To be updated in "
      "current spec') beside the A-/B-pillar rows.")
    w("")

    w("## 4. Layout checks")
    w("")
    w("Run on both variants after the corrections.")
    w("")
    w("| Check | Result |")
    w("|---|---|")
    overlaps = log["overlaps"]
    w(f"| Overlapping bits | {'none' if not overlaps else '; '.join(f'{v} byte {b}: {t}' for v, b, t in overlaps)} |")
    lsb = sorted({(v, b) for v, b, _ in log["lsb_bytes"]})
    w(f"| Bytes numbered from bit 0 upwards | "
      + ("; ".join(f"{v} payload byte {b}" for v, b in lsb) or "none") + " |")
    gapped = log["gapped"]
    w(f"| Series with gaps between samples | {'none' if not gapped else '; '.join(f'{v} {n}' for v, n, _ in gapped)} |")
    unordered = log["unordered"]
    w(f"| Series labelled out of time order | "
      + ("; ".join(f"{v} {n}" for v, n, _ in unordered) or "none")
      + " - read in time order |")
    irregular = log["irregular"]
    w(f"| Series with an irregular time step | {'none' if not irregular else '; '.join(f'{v} {n}' for v, n, _ in irregular)} |")
    inconsistent = log["inconsistent"]
    w(f"| Samples of one series that disagree | {'none' if not inconsistent else '; '.join(f'{v} {n} {c}: {vals}' for v, n, c, vals in inconsistent)} |")
    missing_enum = log["missing_enum"]
    w(f"| Enum referenced but not defined | {'none' if not missing_enum else '; '.join(f'{v} {n}: {e}' for v, n, e in missing_enum)} |")
    for variant in VARIANTS:
        unused = model["variants"][variant]["unused"]
        w(f"| Unallocated bits, {variant} | {_cells(unused) or 'none'} |")
    w("")

    w("## 5. Enum table issues")
    w("")
    w("Repeated codes are read once (first text wins).")
    w("")
    repeats = model["variants"]["ICE"]["enum_repeats"]
    ev_only = [r for r in model["variants"]["EV"]["enum_repeats"] if r not in repeats]
    for line in repeats:
        w(f"- {line}")
    for line in ev_only:
        w(f"- EV: {line}")
    w("- SRS_STPS_ZONE (used by both seat-position zones) is missing; SRS_STPS_ZONE_DRVR and "
      "SRS_STPS_ZONE_PSGR (the latter with a leading space) are used.")
    w("- Doors_Open_Status is defined but no layout row references it (Doors Open Status says "
      "'Value should be taken as per CAN dbc comments').")
    w("")

    w("## 6. Project `edr_config` files against this reference")
    w("")
    w("`tools/build_edr_config_from_diag.py` still builds from `ICE_COMMON_SRS_V1.4` and "
      "`M312_M112_M210_SRS_V2.7`, older than the sheets reviewed here. Only single-element "
      "entries are compared; grouped entries (CrashLocation, TimetoDeployCmd, "
      "Squib_Deployment_Status) and the Event Date/Time sub-fields are not. Nothing here has "
      "been changed in the configs.")
    w("")
    for project, result in drift.items():
        differences = result["differences"]
        w(f"### {project} ({result['variant']})")
        w("")
        if not differences and not result["missing"]:
            w("Matches the reference.")
            w("")
            continue
        if result["missing"]:
            w("Not decoded by any entry: " + ", ".join(result["missing"]) + ".")
            w("")
        if differences:
            w("| config name | field | config | reference |")
            w("|---|---|---|---|")
            for name, field, have, want in differences:
                w(f"| {name} | `{field}` | `{have}` | `{want}` |")
            w("")
    return "\n".join(out) + "\n"


def _cells(cells: list[tuple[int, int]]) -> str:
    """Unused (byte, bit) cells as compact ranges: whole bytes, then partial ones."""
    by_byte: dict[int, list[int]] = defaultdict(list)
    for byte, bit in cells:
        by_byte[byte].append(bit)
    whole = [byte for byte, bits in by_byte.items() if len(bits) == 8]
    parts = []
    run: list[int] = []
    for byte in sorted(whole):
        if run and byte == run[-1] + 1:
            run.append(byte)
        else:
            if run:
                parts.append(run)
            run = [byte]
    if run:
        parts.append(run)
    text = [f"bytes {r[0]}-{r[-1]}" if len(r) > 1 else f"byte {r[0]}" for r in parts]
    for byte, bits in sorted(by_byte.items()):
        if len(bits) < 8:
            text.append(f"{byte}.{','.join(str(b) for b in sorted(bits))}")
    return "; ".join(text) + (" (payload numbering)" if text else "")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true",
                        help="report whether the Markdown files are up to date; write nothing")
    args = parser.parse_args()

    model = analyse()
    configs = load_configs()
    names, groups = config_names(configs)
    documents = {
        PARAMETERS_DOC: render_parameters(model, names, groups),
        GAPS_DOC: render_gaps(model, config_drift(model, configs)),
    }
    stale = [path for path, text in documents.items()
             if not path.exists() or path.read_text(encoding="utf-8") != text]
    if args.check:
        for path in stale:
            print(f"out of date: {path.relative_to(REPOSITORY_ROOT)}")
        return 1 if stale else 0
    for path, text in documents.items():
        path.write_text(text, encoding="utf-8", newline="\n")
        print(f"wrote {path.relative_to(REPOSITORY_ROOT)} ({text.count(chr(10))} lines)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
