"""Generate individual HPCAD cases using existing M314 configuration and wrappers."""

from __future__ import annotations

import argparse
import json
import pprint
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
TOOLS_DIRECTORY = REPOSITORY_ROOT / "tools"
if str(TOOLS_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIRECTORY))

from build_m314_canc_alignment import DBC_FILES
from generate_m314_canc_13c_scripts import load_environment, read_cases, validate_rendered
from generate_m314_canc_2c0_scripts import requirement_evidence


SOURCE_WORKBOOK = REPOSITORY_ROOT / "project_testcases" / "m310_m314_m110" / "CANC" / "HPCAD_Node_TestCases.xlsx"
SCRIPT_DIRECTORY = REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "modules" / "CANC" / "scripts"
ARTIFACT_DIRECTORY = REPOSITORY_ROOT / "tests" / "artifacts" / "m314-canc-hpcad"
REBUILD_COMMAND = "py -3.13 -B tools/m314-canc-signal-suite/generate_m314_canc_hpcad_scripts.py"
CASE_NAME_PATTERN = r"CANC_HPCAd_TestCase_(\d+)"


def plan_case(case: dict[str, Any], environment: dict[str, Any]) -> dict[str, Any]:
    planned = {**case, "blockers": [], "corrections": [], "operations": []}
    planned["requirement_evidence"], planned["blockers"] = requirement_evidence(case, environment)
    text = case["description"] + "\n" + case["pre_action"]
    definitions = environment["canc_config"].MAH_CAN_SIGNAL_DEFS
    signal_match = re.search(r"\b(?:Counter )?Signal:\s*([A-Za-z_][A-Za-z_0-9]*)", case["pre_action"])
    signal_keys = sorted(
        key for key, definition in definitions.items()
        if signal_match is not None and definition["signal"] == signal_match.group(1)
    )
    frames = list(dict.fromkeys(re.findall(r"\bHPCAd_\d+_\d+\b", text)))
    if not frames:
        frames = list(dict.fromkeys(definitions[key]["frame"] for key in signal_keys))
    if not frames:
        raise ValueError(f"{case['name']}: no HPCAD frame or configured signal in objective or preconditions")
    frame_name = next((name for name in frames if not environment["canc_config"].is_key_message(name)), frames[0])
    keys = sorted(key for key, definition in definitions.items() if definition["frame"] == frame_name)
    if not keys:
        raise ValueError(f"{case['name']}: no existing M314 signal definition for {frame_name}")
    planned["signal_key"] = next((key for key in signal_keys if key in keys), keys[0])
    planned["frame"] = frame_name
    message_table = environment["canc_config"].CAN_TX_MESSAGE_CONFIG
    node_name = message_table[frame_name]["key_node"]
    parents = sorted(
        name for name, entry in message_table.items()
        if entry["key_node"] == node_name and environment["canc_config"].is_key_message(name)
    )
    if len(parents) != 1:
        raise ValueError(f"{case['name']}: one configured key frame is required for {node_name}")
    planned["key_frame"] = parents[0]
    definition = definitions[planned["signal_key"]]
    messages = [message for database in environment["databases"] for message in database.messages if message.name == frame_name]
    if not messages:
        raise ValueError(f"{case['name']}: native M314 DBC has no {frame_name}")
    message = messages[0]
    if (message.frame_id, message.length, message.cycle_time) != (
        definition["frame_ID"], definition["dlc"], definition["periodicity"],
    ):
        raise ValueError(f"{case['name']}: existing M314 declaration disagrees with the native DBC")
    tolerance = re.search(r"Tolerance:\s*([0-9.]+)%", case["pre_action"])
    if tolerance is not None and float(tolerance.group(1)) != environment["canc_config"].CAN_FAULT_TIMING_TOLERANCE_PERCENT:
        raise ValueError(f"{case['name']}: source tolerance differs from existing M314 timing policy")
    if "specified periodicity" in case["description"]:
        planned["model"] = "periodicity"
        planned["operations"] = [{"kind": "capture_periodicity"}]
    elif case["number"] in (1, 2, 3, 4, 5, 16, 17, 18, 19, 30, 31, 32, 33, 57, 58, 59, 60):
        planned["model"] = "fault"
        if case["number"] == 1:
            fault_mode, mechanism = "node_absent", "frame"
        elif case["number"] in (16, 30, 57):
            fault_mode, mechanism = "message_timeout", "frame"
        elif case["number"] == 5:
            fault_mode, mechanism = "signal_content", "signal"
        else:
            fault_mode = "message_content"
            mechanism = "dlc" if "Mechanism: DLC" in case["pre_action"] else "counter" if "Mechanism: MessageCounter" in case["pre_action"] else "crc"
        planned["fault_mode"] = fault_mode
        planned["mechanism"] = mechanism
        integrity = environment["canc_config"].CAN_TX_MESSAGE_CONFIG[frame_name]["message_content_failure_dtcs"]
        if mechanism in ("crc", "counter"):
            matches = sorted(name for name in integrity if ("CRC" in name) == (mechanism == "crc"))
            if len(matches) != 1:
                raise ValueError(f"{case['name']}: integrity signal is not unambiguous")
            planned["integrity_signal"] = matches[0]
        if fault_mode == "signal_content":
            invalid_match = re.search(r"Invalid Value:\s*(0[xX][0-9A-Fa-f]+)", case["pre_action"])
            invalid = int(invalid_match.group(1), 16) if invalid_match else None
            references = [(field, index) for field in ("TestCase_Invalid_Values", "TestCase_Reserved_Values")
                          for index, value in enumerate(definition.get(field, [])) if value == invalid]
            if not references or not definition.get("TestCase_values"):
                planned["blockers"].append("The source invalid code and valid recovery vector have no existing M314 configuration reference")
            else:
                planned["invalid_field"], planned["invalid_index"] = references[0]
        if mechanism == "dlc":
            planned["corrections"].append("D-04 surfaced: use the next smaller legal CAN-FD payload as in the existing M314 DLC timing script; this does not resolve the generic smaller-than versus not-equal wording")
        if fault_mode == "message_timeout":
            planned["corrections"].append("D-10: stop the exact slave frame under test and keep HPCAd_1_10 enabled; do not stop the parent to create message timeout")
            linked_requirements = ", ".join(
                f"{entry['id']} (CAN-C Export row {entry['row']}, Description)"
                for entry in planned["requirement_evidence"]
            )
            planned["blockers"].append(
                "Requirement/configuration contradiction: linked Approved requirements "
                + linked_requirements
                + " specify HPCAd_NODE_ABSENT and u8NodeAbsentDetection/u8NodeAbsentRecovery, "
                "while the source objective and configured slave oracle use message timeout. "
                "Evidence unavailable for an approved reconciliation; do not choose the MTO DTC/counts silently"
            )
        planned["operations"] = [
            {"kind": "apply_fault", "mode": fault_mode, "mechanism": mechanism},
            {"kind": "wait_qualification", "config": "qualification_ms"},
            {"kind": "check_dtc", "status": "DTC_active_WLOFF"},
            {"kind": "restore_fault"}, {"kind": "wait_recovery", "config": "recovery_ms"},
            {"kind": "check_dtc", "status": "DTC_healed"},
            {"kind": "ignition_cycle"}, {"kind": "check_dtc", "status": "DTC_historic"},
        ]
        if fault_mode == "node_absent":
            corrected_dtc = environment["canc_config"].CAN_NODE_ABSENT_DTC["HPCAD"]
        elif fault_mode == "message_timeout":
            corrected_dtc = environment["canc_config"].CAN_MESSAGE_TIMEOUT_DTC["HPCAD"]
        elif fault_mode == "signal_content":
            corrected_dtc = environment["canc_config"].CAN_SIGNAL_CONTENT_FAILURE_DTC[definition["signal"]]
        else:
            dtcs = sorted(set(integrity.values()))
            if len(dtcs) != 1:
                raise ValueError(f"{case['name']}: one message-content DTC is required")
            corrected_dtc = dtcs[0]
        planned["corrected_dtc"] = corrected_dtc
        corrected_bytes = [int(token, 16) for token in re.findall(r"0[xX]([0-9A-Fa-f]{2})\b", corrected_dtc)]
        for step in case["steps"]:
            for source_frame in sorted(set(re.findall(r"\bHPCAd_\d+_\d+\b", step["action"]))):
                if source_frame != frame_name and not (fault_mode == "message_timeout" and source_frame == planned["key_frame"]):
                    planned["corrections"].append(f"Export!G{step['row']}: copied recovery/stimulus frame {source_frame} is replaced by the objective's {frame_name}")
            source_bytes = [int(token, 16) for token in re.findall(r"0[xX]([0-9A-Fa-f]{2})\b", step["expected"])]
            source_codes = [source_bytes[index:index + 3] for index in range(0, len(source_bytes) - 3, 4)]
            if source_codes and any(code != corrected_bytes for code in source_codes):
                planned["corrections"].append(f"Export!H{step['row']}: unrelated source DTC expectation {step['expected']!r} is replaced by configured {corrected_dtc} for this fault lifecycle")
        if not any("cycle ign" in step["action"].casefold() for step in case["steps"]):
            last_step = case["steps"][-1]
            planned["corrections"].append(
                f"Export!G{last_step['row']}/H{last_step['row']}: source omits the historic transition; "
                f"after restoring {frame_name} and checking the healed DTC, explicitly cycle IGN "
                f"and check configured {corrected_dtc} with DTC_historic, matching the objective's historic requirement"
            )
    elif "decoded to the correct physical value" in case["description"]:
        planned["model"] = "signal"
        if signal_match is None or not signal_keys:
            raise ValueError(f"{case['name']}: the source signal has no existing M314 definition")
        alias_fields = ("frame", "signal", "frame_ID", "bus", "dlc", "bit_length", "Signed", "byte_order", "Factor", "Offset", "TestCase_values")
        if any(definitions[key].get(field) != definition.get(field) for key in signal_keys for field in alias_fields):
            raise ValueError(f"{case['name']}: existing aliases disagree on the native signal or nominal vector")
        dbc_signal = message.get_signal_by_name(definition["signal"])
        if (dbc_signal.length, dbc_signal.is_signed, dbc_signal.byte_order, dbc_signal.scale, dbc_signal.offset) != (
            definition["bit_length"], definition["Signed"], definition["byte_order"], definition["Factor"], definition["Offset"],
        ):
            raise ValueError(f"{case['name']}: configured signal encoding differs from the native M314 DBC")
        planned["dbc_file"] = next(
            path.relative_to(REPOSITORY_ROOT).as_posix()
            for path, database in zip(DBC_FILES, environment["databases"])
            if any(candidate.name == frame_name for candidate in database.messages)
        )
        planned["dynamic_counter"] = definition["signal"].endswith("_MSG_COUNT")
        if not planned["dynamic_counter"] and not definition.get("TestCase_values"):
            planned["blockers"].append("Existing M314 declaration has no nominal TestCase_values vector")
        planned["operations"] = [
            {"kind": "capture_dynamic_counter" if planned["dynamic_counter"] else "drive_configured_vectors", "field": "TestCase_values"},
            {"kind": "decode_captured_signal", "decoder": "decode_can_signal", "conversion": "raw_to_physical"},
            {"kind": "check_no_dtc"},
        ]
        planned["observation_scope"] = "Fresh bus frames and their decoded raw/physical values; ECU-internal dataframe acceptance is not observable through this route"
        if planned["dynamic_counter"]:
            planned["corrections"].append("Keep the incoming rolling counter dynamic and decode its representative captured values; freezing it for nominal readback would create message-content failure")
        for step in case["steps"]:
            source_signal = re.search(r"raw values for signal\s+([A-Za-z_][A-Za-z_0-9]*)", step["action"])
            if source_signal is not None and source_signal.group(1) != definition["signal"]:
                planned["corrections"].append(f"Export!G{step['row']}: copied {source_signal.group(1)} is replaced by configured {definition['signal']}")
            if "DTC Active:" in step["expected"] or "DTC Healed:" in step["expected"]:
                planned["corrections"].append(f"Export!G{step['row']}/H{step['row']}: copied fault/DTC sequence is replaced by fault-free nominal capture and decoding, matching the objective")
    elif "changing only" in case["description"]:
        planned["model"] = "crc_exclusion"
        planned["blockers"].append("Evidence unavailable. No verified CRC exclusion oracle isolates freshness/MAC changes while every other field remains fixed; CRC and counter faults share the same configured DTC, and freezing the counter can invalidate the claimed normal condition")
    elif "increment, rollover, and reset" in case["description"]:
        planned["model"] = "counter_reset"
        planned["blockers"].append("Evidence unavailable. The incoming HPCAD counter reset stimulus and expected reset value/sequence are not defined by existing M314 configuration; SRS TX EOL rollover D-03 must not be transferred to this incoming 8-bit counter")
    elif "integrity field behavior" in case["description"]:
        planned["model"] = "crc_field"
        planned["blockers"].append("Evidence unavailable. The CRC field layout is configured, but no verified CRC algorithm or expected update-pattern oracle defines the complete integrity-field observation")
    elif "priority" in case["description"] or "overrides" in case["description"]:
        planned["model"] = "priority"
        planned["blockers"].append("Evidence unavailable. Copied priority steps omit or contradict the two independent fault stimuli and intermediate DTC/ignition-cycle verdicts; existing DTC/count maps alone do not define the complete approved priority-transition oracle")
    else:
        raise ValueError(f"{case['name']}: unrecognized source objective; no case may be silently omitted")
    for step in case["steps"]:
        for source_frame in ("IEB1_FD_10", "EPS1_FD_10"):
            if source_frame in step["action"]:
                planned["corrections"].append(
                    f"Export!G{step['row']}: copied {source_frame} stimulus is replaced by the objective's {frame_name} operation"
                )
    planned["readiness"] = "blocked" if planned["blockers"] else "implemented-unexecuted"
    return planned


SETUP_BODY = '''    definition = canc_config.MAH_CAN_SIGNAL_DEFS[case["signal_key"]]
    frame_name = definition["frame"]
    simulation_channel = definition["bus"]
    diagnostic_channel = canc_config.CAN_DIAG_SRS_REQ_DATA["bus"]
    periodicity_ms = definition["periodicity"]
    tolerance_percent = canc_config.CAN_FAULT_TIMING_TOLERANCE_PERCENT
    if periodicity_ms <= 0 or not 0 < tolerance_percent < 100:
        raise ValueError("Invalid existing M314 periodicity or timing tolerance")
    settle_ms = max(canc_config.NM_IGN_ON_STARTUP_DELAY_MS, PROVEOUT_COMPLETION_TIME)
    observation_ms = canc_config.NM_IGN_ON_STARTUP_DELAY_MS
    if frame_name != case["frame"] or not canc_config.is_key_message(case["key_frame"]):
        raise ValueError("Current M314 frame ownership differs from the generated case objective")
    enabled_channels = {
        project_config.CAN_FD_CHANNEL_NAME: project_config.CAN_FD_ENABLED,
        project_config.CAN_HS_CHANNEL_NAME: project_config.CAN_HS_ENABLED,
    }
    if not enabled_channels.get(simulation_channel) or not enabled_channels.get(diagnostic_channel):
        raise ValueError("The declared simulation or diagnostic bus is disabled")
    if case["model"] == "signal":
        database = cantools.database.load_file(str(_FRAMEWORK_ROOT / case["dbc_file"]), strict=False)
        message = database.get_message_by_name(frame_name)
        dbc_signal = message.get_signal_by_name(definition["signal"])
        if (message.frame_id, message.length, message.cycle_time, dbc_signal.length,
            dbc_signal.is_signed, dbc_signal.byte_order, dbc_signal.scale, dbc_signal.offset) != (
            definition["frame_ID"], definition["dlc"], periodicity_ms, definition["bit_length"],
            definition["Signed"], definition["byte_order"], definition["Factor"], definition["Offset"],
        ):
            raise ValueError("Current M314 signal configuration disagrees with the native DBC")
    set_active_project(project_config.PROJECT_NAME)
    ensure_apym_on_path()
    if init_aria() is not True:
        raise RuntimeError("ARIA initialization failed; no case stimulus was applied")
    reporter = get_reporter(strict=True)
    report_ready = False
    capture_handle = None
    execution_error = None
    preparation_started = False
    touched_frames = set()
    reload_frames = set()
    frozen_signals = set()
    try:
        report_path, log_path = create_report_and_logging(
            Path(__file__).stem, can_ids=resolve_can_log_ids([definition]),
            tc_desc=case["description"],
        )
        report_ready = True
        for label, value in (("ID", case["id"]), ("Name", case["name"]),
                             ("Verifies", case["verifies"]), ("Source", __doc__),
                             ("Report", report_path)):
            reporter.add_report_info("#Test Case " + label + ":", str(value))
        for step in case["steps"]:
            RESULT.InsertComment(f"Source Export!G{step['row']}/H{step['row']}: {step['action']} | {step['expected']}")
        for correction in case["corrections"]:
            RESULT.InsertComment("Approved source correction: " + correction)
        preparation_started = True
        fault_free_profile()
        PS.IGN_ON()
        for healthy_frame in sorted({frame_name, case["key_frame"]}):
            touched_frames.add(healthy_frame)
            response = CAN.PeriodicEnableFrame(channel_name=simulation_channel, frame_name=healthy_frame)
            if response != f"Simulation Started on {healthy_frame}":
                raise RuntimeError(f"Cannot enable {healthy_frame}: {response}")
        Wait(settle_ms)
        baseline = CAN.SendDiagByValuesNoLog(diagnostic_channel, Read_DTC_Req_CANC)
        if isinstance(baseline, Exception):
            raise baseline
        obtained = hex_to_bytes(baseline)
        expected = hex_to_bytes(Read_DTC_Resp_CANC)
        RESULT.InterpretEqualResult("Fault-free DTC precondition", obtained.hex(" ").upper(), expected.hex(" ").upper())
        if obtained != expected:
            raise AssertionError("Fault-free DTC precondition failed")
'''


PERIODICITY_BODY = '''        lower_ms = periodicity_ms * (1 - tolerance_percent / 100)
        upper_ms = periodicity_ms * (1 + tolerance_percent / 100)
        for observation in ("initial", "additional"):
            capture_path = Path(log_path).with_name(f"{Path(log_path).stem}_{observation}_{frame_name}.txt")
            capture_handle = CAN.StartLoggingToFile(
                TestCase_ID=f"{case['name']}.{observation}", filepath=str(capture_path),
                listOption=[definition["frame_ID"]], channel_names=[simulation_channel],
                log_all_available_buses=False,
            )
            if capture_handle is None or isinstance(capture_handle, (str, Exception)):
                raise RuntimeError(f"Capture start failed: {capture_handle}")
            Wait(observation_ms)
            response = CAN.StopLoggingToFile(capture_handle)
            if not isinstance(response, (list, tuple)) or not response or response[0] != "0000":
                raise RuntimeError(f"Capture stop failed: {response}")
            capture_handle = None
            captured = CAN.ReadFromCanLogFile(str(capture_path))
            if not isinstance(captured, (list, tuple)) or len(captured) != 2 or captured[0] != "0000":
                raise RuntimeError(f"Capture read failed: {captured}")
            frames = [frame for frame in captured[1] if getattr(frame, "id", None) == definition["frame_ID"]]
            if len(frames) < 3:
                raise AssertionError("At least three fresh frames are required for consecutive-cycle timing")
            for frame in frames:
                if len(frame.payload) != definition["dlc"]:
                    raise AssertionError(f"{frame_name}: captured payload length differs from M314 configuration")
                if type(getattr(frame, "timestamp", None)) is not int or frame.timestamp < 0:
                    raise RuntimeError("Evidence unavailable. APYM integer microsecond timestamp is required")
                direction = getattr(frame, "direction", None)
                direction_name = getattr(direction, "name", str(direction)).casefold()
                if direction_name not in ("rx", "tx"):
                    raise RuntimeError("Capture direction is not verified")
            directions = {getattr(frame.direction, "name", str(frame.direction)).casefold() for frame in frames}
            if len(directions) != 1:
                raise RuntimeError("Mixed RX/TX copies cannot be used to measure periodicity")
            intervals_ms = [us_to_ms(current.timestamp - previous.timestamp) for previous, current in zip(frames, frames[1:])]
            RESULT.LogCustomAction(
                f"{frame_name} {observation} bus periodicity (ms)",
                expected_result=f"Every interval {lower_ms:g} to {upper_ms:g} ms",
                obtained_result=f"{len(frames)} {next(iter(directions)).upper()} frames; intervals {intervals_ms}",
                res=all(lower_ms <= value <= upper_ms for value in intervals_ms),
            )
            if not all(lower_ms <= value <= upper_ms for value in intervals_ms):
                raise AssertionError(f"{frame_name}: periodicity outside {lower_ms:g}..{upper_ms:g} ms: {intervals_ms}")
        response = CAN.SendDiagByValuesNoLog(diagnostic_channel, Read_DTC_Req_CANC)
        if isinstance(response, Exception):
            raise response
        obtained = hex_to_bytes(response)
        RESULT.InterpretEqualResult("No communication faults after normal transmission", obtained.hex(" ").upper(), expected.hex(" ").upper())
        if obtained != expected:
            raise AssertionError("Unexpected DTC after normal transmission")
'''


FAULT_BODY = '''        fault_mode = case["fault_mode"]
        mechanism = case["mechanism"]
        qualification_ms = canc_config.qualification_ms(fault_mode, periodicity_ms)
        recovery_ms = canc_config.recovery_ms(fault_mode, periodicity_ms)
        if not qualification_ms or not recovery_ms:
            raise RuntimeError("Evidence unavailable. Existing fault maturation timing is required")
        if fault_mode == "node_absent":
            dtc_text = canc_config.CAN_NODE_ABSENT_DTC["HPCAD"]
        elif fault_mode == "message_timeout":
            dtc_text = canc_config.CAN_MESSAGE_TIMEOUT_DTC["HPCAD"]
        elif fault_mode == "signal_content":
            dtc_text = canc_config.CAN_SIGNAL_CONTENT_FAILURE_DTC[definition["signal"]]
        else:
            codes = set(canc_config.CAN_TX_MESSAGE_CONFIG[frame_name]["message_content_failure_dtcs"].values())
            if len(codes) != 1:
                raise RuntimeError("One unambiguous configured message-content DTC is required")
            dtc_text = next(iter(codes))
        dtc_code = int.from_bytes(hex_to_bytes(dtc_text), byteorder="big")
        reload_frames.add(frame_name)
        if mechanism == "frame":
            response = CAN.PeriodicDisableFrame(channel_name=simulation_channel, frame_name=frame_name)
            if response != f"Simulation Stopped on {frame_name}":
                raise RuntimeError(f"Frame suppression failed: {response}")
        elif mechanism in ("crc", "counter"):
            frozen_signals.add((frame_name, case["integrity_signal"]))
            response = CAN.DynamicDisableSignal(channel=simulation_channel, CAN_FrameName=frame_name, CAN_SignalName=case["integrity_signal"])
            if response is not None:
                raise RuntimeError(f"Integrity freeze failed: {response}")
        elif mechanism == "dlc":
            corrupt_length = canfd_dlc_to_length(canfd_length_to_dlc(definition["dlc"]) - 1)
            validate_can_dlc(corrupt_length, fd=definition["is_fd"])
            response = CAN.SetPeriodicFrame(
                channel_name=simulation_channel, frame_name=frame_name, frame_id=definition["frame_ID"],
                periodicity=periodicity_ms, payload=bytes(corrupt_length), is_fd=definition["is_fd"],
            )
            if response is not None:
                raise RuntimeError(f"Wrong-DLC stimulus failed: {response}")
        elif mechanism == "signal":
            invalid_raw = definition[case["invalid_field"]][case["invalid_index"]]
            response = CAN.ChangeSignalValue(channel_name=simulation_channel, frame_name=frame_name, signal_name=definition["signal"], value=str(invalid_raw))
            if response is not None:
                raise RuntimeError(f"Invalid signal stimulus failed: {response}")
        else:
            raise RuntimeError(f"Unsupported fault mechanism: {mechanism}")
        RESULT.InsertComment(f"Qualification wait: {qualification_ms} ms from M314 {fault_mode} count x {periodicity_ms} ms period; this is a hold, not a measured transition time")
        Wait(qualification_ms)
        for phase, status_key in (("active", "DTC_active_WLOFF"), ("healed", "DTC_healed"), ("historic", "DTC_historic")):
            if phase == "healed":
                for frozen_frame, frozen_signal in sorted(frozen_signals):
                    response = CAN.DynamicEnableSignal(channel=simulation_channel, CAN_FrameName=frozen_frame, CAN_SignalName=frozen_signal)
                    if response is not None:
                        raise RuntimeError(f"Integrity restoration failed: {response}")
                response = CAN.ReloadDefaultPeriodicFrame(channel_name=simulation_channel, frame_name=frame_name)
                if response != f"Default periodic frame '{frame_name}' reloaded successfully.":
                    raise RuntimeError(f"Normal frame restoration failed: {response}")
                response = CAN.PeriodicEnableFrame(channel_name=simulation_channel, frame_name=frame_name)
                if response != f"Simulation Started on {frame_name}":
                    raise RuntimeError(f"Restored frame cannot transmit: {response}")
                RESULT.InsertComment(f"Dequalification wait: {recovery_ms} ms from M314 {fault_mode} recovery count x {periodicity_ms} ms period")
                Wait(recovery_ms)
            elif phase == "historic":
                PS.IGN_OFF()
                Wait(seconds_to_ms(project_config.RESET_WAIT_TIME))
                PS.IGN_ON()
                Wait(settle_ms)
            response = CAN.CheckSingleDTC(channel=diagnostic_channel, code=dtc_code, expectedStatus=DTC_status[status_key])
            expected_record = (hex_to_bytes(dtc_text) + hex_to_bytes(DTC_status[status_key])).hex(" ").upper()
            passed = isinstance(response, (list, tuple)) and len(response) == 2 and response[0] == "0000"
            RESULT.LogCustomAction(f"{frame_name} {phase} DTC", expected_result=expected_record, obtained_result=str(response), res=passed)
            if not passed:
                raise AssertionError(f"{frame_name}: {phase} DTC check failed: {response}")
'''


SIGNAL_BODY = '''        signal_name = definition["signal"]
        byteorder = "little" if dbc_signal.byte_order == "little_endian" else "big"
        lower_ms = periodicity_ms * (1 - tolerance_percent / 100)
        upper_ms = periodicity_ms * (1 + tolerance_percent / 100)
        if case["dynamic_counter"]:
            vectors = [None]
            response = CAN.DynamicEnableSignal(channel=simulation_channel, CAN_FrameName=frame_name, CAN_SignalName=signal_name)
            if response is not None:
                raise RuntimeError(f"Dynamic counter enable failed: {response}")
        else:
            vectors = definition["TestCase_values"]
            observation_ms = canc_config.recovery_ms("message_content", periodicity_ms)
            if not vectors or not observation_ms:
                raise RuntimeError("Configured nominal vectors and observation timing are required")
        for vector_index, raw_value in enumerate(vectors):
            if raw_value is not None:
                reload_frames.add(frame_name)
                response = CAN.ChangeSignalValue(channel_name=simulation_channel, frame_name=frame_name, signal_name=signal_name, value=str(raw_value))
                if response is not None:
                    raise RuntimeError(f"Nominal signal stimulus failed: {response}")
            capture_path = Path(log_path).with_name(f"{Path(log_path).stem}_value_{vector_index}_{signal_name}.txt")
            capture_handle = CAN.StartLoggingToFile(
                TestCase_ID=f"{case['name']}.{vector_index}", filepath=str(capture_path),
                listOption=[definition["frame_ID"]], channel_names=[simulation_channel],
                log_all_available_buses=False,
            )
            if capture_handle is None or isinstance(capture_handle, (str, Exception)):
                raise RuntimeError(f"Capture start failed: {capture_handle}")
            Wait(observation_ms)
            response = CAN.StopLoggingToFile(capture_handle)
            if not isinstance(response, (list, tuple)) or not response or response[0] != "0000":
                raise RuntimeError(f"Capture stop failed: {response}")
            capture_handle = None
            captured = CAN.ReadFromCanLogFile(str(capture_path))
            if not isinstance(captured, (list, tuple)) or len(captured) != 2 or captured[0] != "0000":
                raise RuntimeError(f"Capture read failed: {captured}")
            frames = [frame for frame in captured[1] if getattr(frame, "id", None) == definition["frame_ID"]]
            if len(frames) < 3:
                raise AssertionError("At least three fresh frames are required for nominal reception")
            directions = set()
            decoded = []
            for frame in frames:
                if len(frame.payload) != definition["dlc"]:
                    raise AssertionError(f"{frame_name}: nominal payload length differs from the native DBC")
                if type(getattr(frame, "timestamp", None)) is not int or frame.timestamp < 0:
                    raise RuntimeError("Evidence unavailable. APYM integer microsecond timestamp is required")
                direction = getattr(frame, "direction", None)
                direction_name = getattr(direction, "name", str(direction)).casefold()
                if direction_name not in ("rx", "tx"):
                    raise RuntimeError("Capture direction is not verified")
                directions.add(direction_name)
                decoded.append(decode_can_signal(
                    frame.payload, dbc_signal.start, dbc_signal.length, factor=definition["Factor"],
                    offset=definition["Offset"], signed=definition["Signed"], byteorder=byteorder,
                ))
            if len(directions) != 1:
                raise RuntimeError("Mixed RX/TX copies cannot establish fresh nominal reception")
            intervals_ms = [us_to_ms(current.timestamp - previous.timestamp) for previous, current in zip(frames, frames[1:])]
            timing_passed = all(lower_ms <= value <= upper_ms for value in intervals_ms)
            RESULT.LogCustomAction(f"{frame_name} nominal bus period (ms)", expected_result=f"Every interval {lower_ms:g} to {upper_ms:g} ms", obtained_result=str(intervals_ms), res=timing_passed)
            if not timing_passed:
                raise AssertionError(f"{frame_name}: nominal reception is not within configured periodicity")
            raw_values = [value["raw"] for value in decoded]
            physical_values = [value["physical"] for value in decoded]
            expected_physical = [raw_to_physical(
                raw_value if raw_value is not None else value["raw"],
                scaling=definition["Factor"], offset=definition["Offset"],
                bits=definition["bit_length"], signed=definition["Signed"],
            ) for value in decoded]
            raw_passed = all(value == raw_value for value in raw_values) if raw_value is not None else len(set(raw_values)) >= 3
            physical_passed = physical_values == expected_physical
            RESULT.LogCustomAction(f"{signal_name} captured raw values", expected_result=str(raw_value) if raw_value is not None else "Several distinct values with the valid counter left dynamic", obtained_result=str(raw_values), res=raw_passed)
            RESULT.LogCustomAction(f"{signal_name} captured physical values", expected_result=str(expected_physical), obtained_result=str(physical_values), res=physical_passed)
            if not raw_passed or not physical_passed:
                raise AssertionError(f"{signal_name}: captured raw/physical value mismatch")
        RESULT.InsertComment(case["observation_scope"])
        response = CAN.SendDiagByValuesNoLog(diagnostic_channel, Read_DTC_Req_CANC)
        if isinstance(response, Exception):
            raise response
        obtained = hex_to_bytes(response)
        RESULT.InterpretEqualResult("No communication faults after nominal signal vectors", obtained.hex(" ").upper(), expected.hex(" ").upper())
        if obtained != expected:
            raise AssertionError("Unexpected DTC after nominal signal vectors")
'''


CLEANUP_BODY = '''
    except Exception as error:
        execution_error = error
        if report_ready:
            RESULT.LogCustomAction("HPCAD case failed", expected_result="All implemented observations verified", obtained_result=str(error), res=False)
        raise
    finally:
        cleanup_errors = []
        try:
            if capture_handle is not None:
                try:
                    response = CAN.StopLoggingToFile(capture_handle)
                    if not isinstance(response, (list, tuple)) or not response or response[0] != "0000":
                        cleanup_errors.append(f"Capture stop failed: {response}")
                except Exception as error:
                    cleanup_errors.append(f"Capture stop failed: {error}")
            for frozen_frame, frozen_signal in sorted(frozen_signals):
                try:
                    response = CAN.DynamicEnableSignal(channel=simulation_channel, CAN_FrameName=frozen_frame, CAN_SignalName=frozen_signal)
                    if response is not None:
                        cleanup_errors.append(f"Integrity restore failed: {response}")
                except Exception as error:
                    cleanup_errors.append(f"Integrity restore failed: {error}")
            for reload_frame in sorted(reload_frames):
                try:
                    response = CAN.ReloadDefaultPeriodicFrame(channel_name=simulation_channel, frame_name=reload_frame)
                    if response != f"Default periodic frame '{reload_frame}' reloaded successfully.":
                        cleanup_errors.append(f"Frame reload failed: {response}")
                except Exception as error:
                    cleanup_errors.append(f"Frame reload failed: {error}")
            for touched_frame in sorted(touched_frames):
                try:
                    response = CAN.PeriodicEnableFrame(channel_name=simulation_channel, frame_name=touched_frame)
                    if response != f"Simulation Started on {touched_frame}":
                        cleanup_errors.append(f"Frame restore failed: {response}")
                except Exception as error:
                    cleanup_errors.append(f"Frame restore failed: {error}")
            if preparation_started:
                try:
                    PS.IGN_ON()
                except Exception as error:
                    cleanup_errors.append(f"Ignition restore failed: {error}")
                try:
                    Clear_DTC_Info()
                except Exception as error:
                    cleanup_errors.append(f"DTC cleanup failed: {error}")
            if report_ready and execution_error is None:
                try:
                    if reporter.get_status_now() is not True:
                        cleanup_errors.append("An underlying wrapper or report step recorded failure")
                except Exception as error:
                    cleanup_errors.append(f"Report status check failed: {error}")
            if cleanup_errors:
                if report_ready:
                    RESULT.LogCustomAction("HPCAD cleanup failed", expected_result="All touched resources restored", obtained_result="; ".join(cleanup_errors), res=False)
                raise RuntimeError("Cleanup failed: " + "; ".join(cleanup_errors))
        finally:
            if report_ready:
                reporter.write_to_file()
'''


def render_script(case: dict[str, Any]) -> str:
    source = [
        "# Author: GitHub Copilot", "# GENERATED FILE - do not edit by hand.",
        f"# Rebuild with: {REBUILD_COMMAND}",
        f'"""M314 {case["name"]}; Codebeamer test case {case["id"]}.',
        f'Source: project_testcases/m310_m314_m110/CANC/HPCAD_Node_TestCases.xlsx -> Export -> rows {min(case["rows"])}-{max(case["rows"])}.',
        f'Readiness: {case["readiness"]}. Bench execution has not been performed.',
        '"""', "", "import sys", "from pathlib import Path", "",
        "_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]",
        "if str(_FRAMEWORK_ROOT.parent) not in sys.path:",
        "    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))", "",
        "from Framework_IOEM_Py.shared_libraries.import_list import *",
        "from Framework_IOEM_Py.projects.M310_M314_M110.config import canc_config, project_config",
        "", "", "def run_test():",
        "    case = " + pprint.pformat(case, width=100, sort_dicts=True).replace("\n", "\n    "),
        '    if case["blockers"]:',
        '        raise RuntimeError("Evidence unavailable. Case blocked before bench initialization: " + "; ".join(case["blockers"]))',
    ]
    if case["model"] == "signal":
        source.insert(source.index("import sys"), "import cantools")
    source.append(SETUP_BODY.rstrip())
    body = FAULT_BODY if case["model"] == "fault" else SIGNAL_BODY if case["model"] == "signal" else PERIODICITY_BODY
    source.append(body.rstrip())
    source.append('        if reporter.get_status_now() is not True:\n            raise AssertionError("An underlying wrapper or report step recorded failure")')
    source.append(CLEANUP_BODY.rstrip())
    source.extend(["", "", 'if __name__ == "__main__":', "    run_test()", ""])
    return "\n".join(source).encode("ascii", errors="backslashreplace").decode("ascii")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--validate", action="store_true")
    modes.add_argument("--check", action="store_true")
    parser.add_argument("--case", type=int, nargs="+")
    arguments = parser.parse_args()
    cases, extraction = read_cases(SOURCE_WORKBOOK, case_name_pattern=CASE_NAME_PATTERN)
    if [case["number"] for case in cases] != list(range(1, 73)) or extraction["steps"] != 468:
        raise ValueError("Expected all 72 HPCAD cases and 468 source steps")
    environment = load_environment()
    selected = [case for case in cases if not arguments.case or case["number"] in arguments.case]
    if arguments.case and len(selected) != len(set(arguments.case)):
        raise ValueError("Requested case is absent from the source workbook")
    if not arguments.validate and not arguments.check and not (ARTIFACT_DIRECTORY / "README.md").is_file():
        raise ValueError("The retained artifact folder requires its README before generation")
    plans = [plan_case(case, environment) for case in selected]
    for planned in plans:
        path = SCRIPT_DIRECTORY / f"SUBS_{planned['name']}.py"
        source = render_script(planned)
        validate_rendered(path.name, source)
        if arguments.check:
            if not path.is_file() or path.read_text(encoding="utf-8") != source:
                raise ValueError(f"Generated script differs or is missing: {path}")
        elif not arguments.validate:
            marker = "# Author: GitHub Copilot\n# GENERATED FILE - do not edit by hand.\n# Rebuild with: " + REBUILD_COMMAND
            if path.exists() and not path.read_text(encoding="utf-8").startswith(marker):
                raise ValueError(f"Refusing to replace an unrelated script: {path}")
            path.write_text(source, encoding="utf-8", newline="\n")
    if not arguments.validate and not arguments.check:
        (ARTIFACT_DIRECTORY / "coverage.json").write_text(json.dumps({
            "extraction": extraction, "requirement_source": environment["requirement_evidence"],
            "cases": plans, "bench_executed": False,
        }, indent=2) + "\n", encoding="utf-8")
    print("VALIDATED_SCRIPTS", len(plans), "READINESS", dict(Counter(case["readiness"] for case in plans)))
    print("SOURCE_STEPS_RETAINED", sum(len(case["steps"]) for case in plans), "NO_BENCH_EXECUTION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())