# M314 CAN-C Signal Suite

This utility generates the supported 2C0 test scripts and provides one runner
for the existing 13C cases plus those 2C0 cases. Bench scripts are emitted only
for cases 6, 13, and 14 from the 2C0 workbook. The other source cases and their
blocking reasons are retained in `tests/artifacts/m314-canc-2c0/coverage.json`.

## Inputs And Outputs

- Input: `project_testcases/m310_m314_m110/CANC/M314 CANC 2C0 signal and message spec test cases.xlsx`.
- Evidence: the M314 CAN-C requirement export, M314 project configuration, and native FD/HS-CAN DBCs.
- Generated scripts: `projects/M310_M314_M110/modules/CANC/scripts/SUBS_CANC_2C0_TestCase_<number>.py`.
- Coverage record: `tests/artifacts/m314-canc-2c0/coverage.json`.

All workbook rows are extracted through the repository's UDU-backed workbook
reader. Generated `run_test()` bodies have exactly one entry point and call
bench functionality through `shared_libraries.import_list`; no shared-library
or project-configuration files are changed.

## Commands

Validate extraction, mappings, rendering, and script conventions without
writing scripts or connecting to ARIA:

```powershell
py -3.13 -B tools/m314-canc-signal-suite/generate_m314_canc_2c0_scripts.py --validate
```

Generate the three supported scripts and the coverage record:

```powershell
py -3.13 -B tools/m314-canc-signal-suite/generate_m314_canc_2c0_scripts.py
```

Preflight the combined 13C/2C0 suite without importing or executing bench code:

```powershell
py -3.13 -B tools/m314-canc-signal-suite/run_canc_signal_suite.py --dry-run
```

Normal runner execution is bench-facing and requires an independently prepared
and authorized M314 ARIA bench. It was not run while creating or validating this
utility.

## Retention

Retain the generator, runner, focused offline regression, and case-coverage
manifest so supported and blocked cases can be reproduced from their sources.
The original workbook remains unchanged. Offline validation does not prove live
ECU behavior, capture timing, wiring, or fault reaction.

## HPCAD Per-Case Scripts

The HPCAD generator reads every source worksheet and row from
`project_testcases/m310_m314_m110/CANC/HPCAD_Node_TestCases.xlsx` and emits all 72
per-case files in the user-approved M314 CANC script folder. Every source step
and identifier is retained in `tests/artifacts/m314-canc-hpcad/coverage.json`.

It provides 43 implemented, unexecuted paths and 29 explicitly blocked cases.
Blocked files raise before APYM initialization. The evidence README explains
missing requirement links, CRC/counter oracles, and contradictory priority
sequences. Approved copied-step corrections use the HPCAD objective and existing
M314 configuration, without changing the workbook, shared libraries, project
configuration, or older scripts.

```powershell
py -3.13 -B tools/m314-canc-signal-suite/generate_m314_canc_hpcad_scripts.py --validate
py -3.13 -B tools/m314-canc-signal-suite/generate_m314_canc_hpcad_scripts.py
py -3.13 -B tools/m314-canc-signal-suite/generate_m314_canc_hpcad_scripts.py --check
py -3.13 -B tests/test_m314_canc_hpcad_scripts.py M314HPCADScriptTests -v
```

Fact, High confidence from offline source/runtime checks: scripts reuse existing
capture, decode, time conversion, fault, power, diagnostic, and reporter APIs and
contain only one `run_test` function. Nominal captures establish bus/display
decoding, not ECU-internal acceptance. Fault maturation holds use configured
counts and actual frame periods; they do not measure ECU transition times.

The existing 13C/2C0 runner is unchanged and does not include HPCAD files.
No bench execution was requested or performed for this generation.
The reused fault-free profile includes persistent NVM/coding/VIN operations;
execution requires authorization for those operations as well as CAN stimulus.
Cases 16, 30, and 57 are blocked on an Approved requirement/configuration
contradiction rather than silently substituting timeout counts for node-absence.