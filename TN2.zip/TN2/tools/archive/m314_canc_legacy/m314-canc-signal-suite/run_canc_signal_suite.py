"""Run the supported M314 CANC 13C and 2C0 cases sequentially."""

from __future__ import annotations

import argparse
import ast
import runpy
from pathlib import Path


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIRECTORY = (
    REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "modules" / "CANC" / "scripts"
)
SUITE_SCRIPTS = {
    "13C": (
        "SUBS_CANC_13C_TestCase_51.py",
        "SUBS_CANC_13C_TestCase_52.py",
        "SUBS_CANC_13C_TestCase_58.py",
    ),
    "2C0": (
        "SUBS_CANC_2C0_TestCase_6.py",
        "SUBS_CANC_2C0_TestCase_13.py",
        "SUBS_CANC_2C0_TestCase_14.py",
    ),
}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--family", choices=("both", "13C", "2C0"), default="both")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and list selected scripts without importing or executing bench code.",
    )
    arguments = parser.parse_args(argv)

    families = ("13C", "2C0") if arguments.family == "both" else (arguments.family,)
    selected = [(family, name) for family in families for name in SUITE_SCRIPTS[family]]
    if not selected:
        raise ValueError("No CANC scripts selected; no tests were executed")
    names = [name for _, name in selected]
    if len(names) != len(set(names)):
        raise ValueError("CANC script selection contains duplicate files")

    resolved_script_directory = SCRIPT_DIRECTORY.resolve()
    script_paths = []
    for family, script_name in selected:
        if (
            Path(script_name).name != script_name
            or not script_name.startswith(f"SUBS_CANC_{family}_TestCase_")
            or Path(script_name).suffix != ".py"
        ):
            raise ValueError(f"Selection must contain local {family} CANC Python filenames: {script_name}")
        script_path = SCRIPT_DIRECTORY / script_name
        if script_path.resolve().parent != resolved_script_directory:
            raise ValueError(f"CANC script resolves outside its directory: {script_name}")
        if not script_path.is_file():
            raise FileNotFoundError(f"Missing CANC script: {script_path}")
        script_tree = ast.parse(
            script_path.read_text(encoding="utf-8-sig"), filename=str(script_path)
        )
        compile(script_tree, str(script_path), "exec")
        functions = [
            node.name for node in ast.walk(script_tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        if functions != ["run_test"]:
            raise ValueError(f"{script_name}: expected exactly one run_test() and no helper functions")
        guards = [
            node for node in script_tree.body
            if isinstance(node, ast.If) and ast.unparse(node.test) == "__name__ == '__main__'"
        ]
        if len(guards) != 1 or not guards[0].body or ast.unparse(guards[0].body[0]) != "run_test()":
            raise ValueError(f"{script_name}: missing guarded run_test() entry point")
        script_paths.append((family, script_path))

    if arguments.dry_run:
        print("Dry run only: no bench scripts imported or executed.", flush=True)
        for index, (family, script_path) in enumerate(script_paths, start=1):
            print(f"[{index}/{len(script_paths)}] {family} {script_path.name}", flush=True)
        return 0

    print("M314 CANC 13C/2C0 suite: sequential execution; stop on first error.", flush=True)
    for index, (family, script_path) in enumerate(script_paths, start=1):
        print(f"\n[{index}/{len(script_paths)}] Running {family} {script_path.name}", flush=True)
        try:
            runpy.run_path(str(script_path), run_name="__main__")
        except Exception as error:
            raise RuntimeError(
                f"M314 CANC suite stopped at {script_path.name}; remaining scripts were not run. "
                "Inspect the individual report and restore the bench before further testing."
            ) from error
        print(f"[{index}/{len(script_paths)}] Completed {script_path.name}", flush=True)
    print(f"Completed {len(script_paths)} M314 CANC scripts; see individual reports for verdicts.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())