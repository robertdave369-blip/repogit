"""Generate the M314 CANC 2C0 scripts whose full paths are evidence-backed."""

from __future__ import annotations

import argparse
import json
import pprint
import re
import runpy
import sys
from collections import Counter
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
TOOLS_DIRECTORY = REPOSITORY_ROOT / "tools"
if str(TOOLS_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIRECTORY))

from build_m314_canc_alignment import DBC_FILES, _workbook_rows
from generate_m314_canc_13c_scripts import expected_reference, load_environment
from map_codebeamer_requirement_links import normalized_text


SOURCE_WORKBOOK = (
    REPOSITORY_ROOT / "project_testcases" / "m310_m314_m110" / "CANC"
    / "M314 CANC 2C0 signal and message spec test cases.xlsx"
)
SCRIPT_DIRECTORY = (
    REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "modules" / "CANC" / "scripts"
)
ARTIFACT_DIRECTORY = REPOSITORY_ROOT / "tests" / "artifacts" / "m314-canc-2c0"
REBUILD_COMMAND = "py -3.13 tools/m314-canc-signal-suite/generate_m314_canc_2c0_scripts.py"
SUPPORTED_CASES = (6, 13, 14)
CASE_NAME_PATTERN = re.compile(r"CANC_2C0_TestCase_(\d+)")
SANITIZE_TEXT = runpy.run_path(str(
    REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator"
    / "scripts" / "sanitize.py"
))["sanitize_text"]

CASE_BLOCKERS = {
    1: "Proveout lamp timing (6 s on / 1 s off) has no configured acceptance window; message period and DLC do not verify the complete lamp sequence.",
    2: "Plant-mode activation/security procedure and the 30 s lamp-flashing observation are not mapped to a verified M314 operation and timing window.",
    3: "The composite sequence includes squib, node-absence, message-content, VIN, and voltage faults; the complete stimulus, qualification, and restoration path is not mapped.",
    4: "Proveout lamp timing has no configured acceptance window for the complete 6 s / 1 s behavior.",
    5: "The PAB switch input has no verified stimulus mapping, and the PAB-ON step expects IGN_STS_SRS rather than the PAB lamp signal named by the case.",
    **{number: "Crash/near-crash stimulus, approved M314 curve, T0 alignment, and event cleanup are not verified for this case." for number in (7, 8, 9, 10, 11, 12, 15)},
    **{number: "The requested EOL writes alter persistent coding; D-03 range selection, the current M314 default, and restoration to the original coding are not all defined by this case." for number in (16, 17, 18, 19, 20)},
    21: "The project fault catalogue states that CAN bus-off has no clean wrapper; the physical/error-frame method must be supplied by the user.",
    **{number: "The named seat-belt signals map to SRS1_FD_10 on 0x13C, not to the native SRS1_20 0x2C0 DBC message; these cannot be emitted as 2C0 tests." for number in (22, 23, 24, 25, 26)},
    27: "The SRS_OPERATION_MODE case calls the value a default and expects 1 after IGN ON; requirement 31954882 states initial value 0 while defining 1 as Active. Clarify the intended state before execution.",
    **{number: "The external IEB stimulus or requested HIG/VIN/plant/system-critical fault and its recovery are not fully mapped to existing M314 configuration and wrappers." for number in (28, 29, 30, 31)},
    32: "The DBC locates an 8-bit CRC field, but the case does not provide a verified CRC algorithm/acceptance rule; field layout alone cannot prove message CRC correctness.",
    33: "The reserved-bit expectation conflicts with the DBC: byte 5 is assigned to the 8-bit SRS_OPERATION_MODE signal, not a reserved field.",
    34: "This is a UDS response case rather than a 2C0 signal case; its expected 0x50 0x03 timing bytes do not match the existing M314 0x10 0x03 response catalog.",
}


def read_cases(path: Path = SOURCE_WORKBOOK) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    document, rows, columns = _workbook_rows(
        path,
        "Export",
        (
            "ID", "Priority", "Name", "Description", "Pre-Action", "Post-Action",
            "Test Steps.Action", "Test Steps.Expected result", "Test Steps.Id",
            "Verifies", "Status", "Type",
        ),
    )
    cases: list[dict[str, Any]] = []
    folder_rows: list[int] = []
    current: dict[str, Any] | None = None
    for row_number, row in sorted(rows.items()):
        fields = {
            header: SANITIZE_TEXT(normalized_text(row.get(column, ""))).text
            for header, column in columns.items()
        }
        if fields["ID"]:
            if fields["Type"].casefold() == "folder":
                folder_rows.append(row_number)
                current = None
                continue
            match = CASE_NAME_PATTERN.fullmatch(fields["Name"])
            if match is None:
                raise ValueError(
                    f"{path.name} -> Export -> C{row_number}: unexpected case name {fields['Name']!r}"
                )
            if fields["Status"].casefold() != "approved":
                raise ValueError(f"{fields['Name']}: source status is {fields['Status']!r}")
            current = {
                "number": int(match.group(1)),
                "id": fields["ID"].removesuffix(".0"),
                "name": fields["Name"],
                "description": fields["Description"],
                "priority": fields["Priority"],
                "pre_action": fields["Pre-Action"],
                "post_action": fields["Post-Action"],
                "verifies": fields["Verifies"],
                "status": fields["Status"],
                "row": row_number,
                "rows": [],
                "steps": [],
            }
            cases.append(current)
        if current is None:
            if any(fields.values()):
                raise ValueError(f"{path.name} -> Export -> row {row_number}: orphan data")
            continue
        current["rows"].append(row_number)
        if fields["Test Steps.Action"] or fields["Test Steps.Expected result"]:
            current["steps"].append({
                "row": row_number,
                "id": fields["Test Steps.Id"],
                "action": fields["Test Steps.Action"],
                "expected": fields["Test Steps.Expected result"],
            })

    if [case["number"] for case in cases] != list(range(1, 35)):
        raise ValueError("The source must contain CANC_2C0_TestCase_01 through _34 exactly once")
    if not cases or any(not case["steps"] for case in cases):
        raise ValueError("The source contains no cases or a case without test steps")
    for field in ("number", "id", "name"):
        duplicates = [value for value, count in Counter(case[field] for case in cases).items() if count > 1]
        if duplicates:
            raise ValueError(f"Duplicate {field}: {duplicates}")

    return cases, {
        "source": document.source.to_dict(),
        "export_rows": len(rows),
        "case_rows": sum(len(case["rows"]) for case in cases),
        "folder_rows": folder_rows,
        "steps": sum(len(case["steps"]) for case in cases),
        "successful": document.report.successful,
        "partial": document.report.partial,
        "failed": document.report.failed,
    }


def requirement_evidence(case: dict[str, Any], environment: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    evidence = []
    blockers = []
    identifiers = re.findall(r"\[ISSUE:(\d+)\]", case["verifies"])
    if not identifiers:
        blockers.append(f"Export!L{case['row']}: source Verifies field is empty")
    for identifier in identifiers:
        requirement = environment["requirements"].get(identifier)
        if requirement is None:
            blockers.append(f"Requirement {identifier}: Evidence unavailable in the existing target CAN-C tracker")
            continue
        evidence.append({"id": identifier, **requirement})
        if requirement["status"].casefold() != "approved":
            blockers.append(
                f"Requirement {identifier} is {requirement['status']}, not Approved: {requirement['locator']}"
            )
    return evidence, blockers


def validate_hscan_signal(key: str, environment: dict[str, Any]):
    config = environment["canc_config"]
    definition = config.MAH_CAN_SIGNAL_DEFS.get(f"SRS1_20_{key}")
    if definition is None:
        raise ValueError(f"No existing M314 SRS1_20 signal definition for {key}")
    mapping = config.CAN_HSCAN_SIGNAL_Rx_MAP.get(key)
    if mapping is None:
        raise ValueError(f"No existing M314 HSCAN receive mapping for {key}")
    frame_name, signal_name = mapping
    if frame_name != definition["frame"] or signal_name != definition["signal"]:
        raise ValueError(f"{key}: CAN_HSCAN_SIGNAL_Rx_MAP disagrees with MAH_CAN_SIGNAL_DEFS")
    message = next(
        (message for database in environment["databases"] for message in database.messages
         if message.name == frame_name),
        None,
    )
    if message is None:
        raise ValueError(f"Native M314 DBC has no HSCAN frame {frame_name}")
    if message.frame_id != definition["frame_ID"] or message.length != definition["dlc"]:
        raise ValueError(f"{frame_name}: M314 config frame ID/DLC disagrees with the native DBC")
    if message.cycle_time != definition["periodicity"]:
        raise ValueError(f"{frame_name}: configured periodicity disagrees with the native DBC")
    signal = message.get_signal_by_name(signal_name)
    if (
        signal.length != definition["bit_length"]
        or signal.is_signed != definition["Signed"]
        or signal.byte_order != definition["byte_order"]
        or signal.scale != definition["Factor"]
        or signal.offset != definition["Offset"]
    ):
        raise ValueError(f"{frame_name}.{signal_name}: M314 config encoding disagrees with the native DBC")
    return definition, frame_name, signal_name, message, signal


def plan_case(case: dict[str, Any], environment: dict[str, Any]) -> dict[str, Any]:
    planned = {
        **case,
        "source_step_count": len(case["steps"]),
        "steps": [],
        "blockers": [],
    }
    planned["requirement_evidence"], planned["blockers"] = requirement_evidence(case, environment)
    if case["number"] not in SUPPORTED_CASES:
        planned["blockers"].append(CASE_BLOCKERS[case["number"]])
        planned["readiness"] = "blocked"
        return planned

    if planned["blockers"]:
        planned["readiness"] = "blocked"
        return planned

    for key in ("IGN_STS_SRS", "EVEN_PARITY_BIT"):
        validate_hscan_signal(key, environment)

    for source_step in case["steps"]:
        action = source_step["action"]
        expected = source_step["expected"]
        lower = action.casefold().strip()
        step = {**source_step, "operations": [], "checks": [], "blocked": []}
        if "normal condition" in lower:
            step["operations"].extend(({"kind": "fault_free"}, {"kind": "read_no_dtc"}))
        elif lower == "ign on":
            step["operations"].append({"kind": "ign_on"})
        elif lower.startswith("monitor id 2c0"):
            step["checks"].append({
                "kind": "present", "key": "SRS1_20_IGN_STS_SRS", "signal": "IGN_STS_SRS",
            })
        elif "no fault is detected" in lower:
            step["operations"].append({"kind": "read_no_dtc"})
        elif case["number"] == 6 and lower.startswith("perform ign off"):
            step["operations"].append({"kind": "ign_off"})
            signal_name = "IGN_STS_SRS"
            definition_key = f"SRS1_20_{signal_name}"
            step["checks"].append({
                "kind": "raw", "key": definition_key, "signal": signal_name,
                **expected_reference(definition_key, 0, environment),
            })
        elif case["number"] == 6 and lower.startswith("perform ign on"):
            step["operations"].append({"kind": "ign_on"})
            signal_name = "IGN_STS_SRS"
            definition_key = f"SRS1_20_{signal_name}"
            step["checks"].append({
                "kind": "raw", "key": definition_key, "signal": signal_name,
                **expected_reference(definition_key, 1, environment),
            })
        elif case["number"] == 14 and lower.startswith("create any loop fault"):
            step["operations"].append({"kind": "squib_open"})
        elif "verify the signal even parity bit" in lower:
            match = re.search(r"EVEN_PARITY_BIT\s*=\s*0x([0-9A-Fa-f]+)", expected, re.IGNORECASE)
            if match is None:
                step["blocked"].append("The source expected result has no raw EVEN_PARITY_BIT value")
            else:
                value = int(match.group(1), 16)
                definition_key = f"SRS1_20_EVEN_PARITY_BIT"
                step["checks"].append({
                    "kind": "raw", "key": definition_key, "signal": "EVEN_PARITY_BIT",
                    **expected_reference(definition_key, value, environment),
                })
        else:
            step["blocked"].append("No existing wrapper/config mapping implements this source step")

        planned["blockers"].extend(
            f"Export!G{step['row']}/H{step['row']}: {reason}" for reason in step["blocked"]
        )
        planned["steps"].append(step)

    planned["blockers"] = list(dict.fromkeys(planned["blockers"]))
    planned["readiness"] = "blocked" if planned["blockers"] else "implemented-unexecuted"
    return planned


def render_script(case: dict[str, Any]) -> str:
    kinds = {operation["kind"] for step in case["steps"] for operation in step["operations"]}
    imports = ["import sys", "from pathlib import Path", "import cantools"]
    imports.extend([
        "", "_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]",
        "if str(_FRAMEWORK_ROOT.parent) not in sys.path:",
        "    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))", "",
        "from Framework_IOEM_Py.shared_libraries.import_list import *",
        "from Framework_IOEM_Py.projects.M310_M314_M110.config import canc_config, project_config",
    ])
    if "squib_open" in kinds:
        imports.append("from Framework_IOEM_Py.projects.M310_M314_M110.config import squibs_config")
    hscan_dbc = next(path for path in DBC_FILES if "HSCAN" in path.name)
    source = [
        "# Author: GitHub Copilot",
        "# GENERATED FILE - do not edit by hand.",
        f"# Rebuild with: {REBUILD_COMMAND}",
        f'"""M314 {case["name"]}; Codebeamer test case {case["id"]}.',
        f'Source: {SOURCE_WORKBOOK.relative_to(REPOSITORY_ROOT).as_posix()} -> Export -> rows {case["rows"][0]}-{case["rows"][-1]}.',
        "Readiness: implemented-unexecuted. Bench execution has not been performed.",
        '"""', "", *imports, "", "", "def run_test():",
        f'    tc_id = {case["id"]!r}', f'    tc_name = {case["name"]!r}',
        f'    tc_desc = {case["description"]!r}', f'    tc_priority = {case["priority"]!r}',
        f'    verifies = {case["verifies"]!r}', f'    pre_action = {case["pre_action"]!r}',
        f'    post_action = {case["post_action"]!r}',
        '    blockers = []',
        '    if blockers:',
        '        raise RuntimeError("Evidence unavailable. Case blocked before bench initialization: " + "; ".join(blockers))',
        f'    steps = {pprint.pformat(case["steps"], width=110, sort_dicts=True)}',
        "    ensure_apym_on_path()", "    if not init_aria():",
        '        raise RuntimeError("APYM/ARIA is unavailable; this is not a passing offline simulation")',
        "    aria_reports = get_reporter(strict=True)",
        "    capture_handle = None", "    report_ready = False", "    bench_prepared = False",
        "    touched_squib = None", "    try:",
        "        report_path, log_path = create_report_and_logging(",
        "            Path(__file__).stem, can_ids=resolve_can_log_ids(), tc_desc=tc_desc,",
        "        )", "        report_ready = True",
        '        aria_reports.add_report_info("#Test Case ID:", tc_id)',
        '        aria_reports.add_report_info("#Test Case Name:", tc_name)',
        '        aria_reports.add_report_info("#Test Case Category:", "M314 CAN-C 2C0")',
        '        aria_reports.add_report_info("#Priority:", tc_priority)',
        '        aria_reports.add_report_info("#Verifies:", verifies)',
        '        aria_reports.add_report_info("#Pre-Action:", pre_action)',
        '        aria_reports.add_report_info("#Post-Action:", post_action)',
        '        aria_reports.add_report_info("#Source:", __doc__)',
        '        aria_reports.add_report_info("#Project:", project_config.PROJECT_NAME)',
        '        aria_reports.add_report_info("#Report file:", report_path)',
        '        channel_map = canc_config.CAN_CRASH_FRAME_CHANNEL_MAP[project_config.ACTIVE_CAN_VARIANT]',
        f'        database = cantools.database.load_file(str(_FRAMEWORK_ROOT / {hscan_dbc.relative_to(REPOSITORY_ROOT).as_posix()!r}), strict=False)',
        '        messages = {message.name: message for message in database.messages}',
        "        for step_number, step in enumerate(steps, start=1):",
        '            RESULT.InsertComment(f"Step {step_number} [Export!G{step[\'row\']}/H{step[\'row\']}]: {step[\'action\']}")',
        '            if step["expected"]:', '                RESULT.InsertComment("Expected: " + step["expected"])',
        '            if step["blocked"]:', '                raise RuntimeError("; ".join(step["blocked"]))',
        '            for operation in step["operations"]:', '                kind = operation["kind"]',
        '                if kind == "fault_free":',
        '                    bench_prepared = True', '                    fault_free_profile()',
        '                    read_software_version()', '                    Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)',
        '                elif kind == "ign_on":',
        '                    PS.IGN_ON()', '                    Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)',
        '                elif kind == "ign_off":', '                    PS.IGN_OFF()',
        '                elif kind == "read_no_dtc":',
        '                    response = CAN.SendDiagByValuesNoLog(data=Read_DTC_Req_CANC)',
        '                    if isinstance(response, Exception):', '                        raise response',
        '                    obtained = hex_to_bytes(response)',
        '                    expected = hex_to_bytes(Read_DTC_Resp_CANC)',
        '                    RESULT.InterpretEqualResult("Fault-free CAN-C DTC response", obtained.hex(" "), expected.hex(" "))',
        '                    if obtained != expected:',
        '                        raise AssertionError("Fault-free precondition failed: DTC records or an invalid diagnostic response are present")',
        '                elif kind == "squib_open":',
        '                    squib_name = min(squibs_config.ActiveSquibName, key=squibs_config.SquibNumber.__getitem__)',
        '                    touched_squib = squib_name',
        '                    device = f"LOOP{squibs_config.SquibNumber[squib_name]}"',
        '                    response = SQUIB.SendRequest(device, squibs_config.Squib_Fault_Description["Open"])',
        '                    if not isinstance(response, str) or not response.endswith(" set OK."):',
        '                        raise RuntimeError(f"Open-loop stimulus failed: {response}")',
        '                    Wait(squibs_config.squib_fault_time["Qualification_Time"])',
        '                    dtc_bytes = hex_to_bytes(squibs_config.DTC_Squib_FaultCode[squib_name] + " " + squibs_config.Squib_FaultTypeCode["Open"])',
        '                    dtc_result = CAN.CheckSingleDTC(code=int.from_bytes(dtc_bytes, byteorder="big"), expectedStatus=DTC_status["DTC_active"])',
        '                    if not isinstance(dtc_result, (list, tuple)) or dtc_result[0] != "0000":',
        '                        raise AssertionError(f"Open-loop DTC was not qualified: {dtc_result}")',
        '                    RESULT.InterpretEqualResult("Open-loop active DTC", dtc_result[0], "0000")',
        '                else:', '                    raise RuntimeError(f"Unsupported operation: {kind}")',
        '            for check in step["checks"]:',
        '                definition = canc_config.MAH_CAN_SIGNAL_DEFS[check["key"]]',
        '                mapping = canc_config.CAN_HSCAN_SIGNAL_Rx_MAP.get(check["signal"])',
        '                if mapping is None:', '                    raise RuntimeError("Requested HSCAN signal has no existing M314 mapping")',
        '                frame_name, signal_name = mapping',
        '                message = messages[frame_name]',
        '                if message.frame_id != definition["frame_ID"] or message.length != definition["dlc"]:',
        '                    raise RuntimeError("Existing M314 config frame ID/DLC disagrees with the native HSCAN DBC")',
        '                if message.cycle_time != definition["periodicity"]:',
        '                    raise RuntimeError("Existing M314 config periodicity disagrees with the native HSCAN DBC")',
        '                dbc_signal = message.get_signal_by_name(signal_name)',
        '                if dbc_signal.length != definition["bit_length"] or dbc_signal.is_signed != definition["Signed"]:',
        '                    raise RuntimeError(f"{frame_name}.{signal_name}: config encoding disagrees with the native HSCAN DBC")',
        '                capture_path = Path(log_path).with_name(f"{Path(log_path).stem}_step_{step_number}_{signal_name}_{frame_name}.txt")',
        '                capture_handle = CAN.StartLoggingToFile(',
        '                    TestCase_ID=f"{tc_name}.{step_number}.{signal_name}.{frame_name}",',
        '                    filepath=str(capture_path), listOption=[message.frame_id],',
        '                    channel_names=[channel_map[frame_name]], log_all_available_buses=False,',
        '                )',
        '                if capture_handle is None or isinstance(capture_handle, (str, Exception)):',
        '                    raise RuntimeError(str(capture_handle))',
        '                Wait(definition["periodicity"])',
        '                stopped = CAN.StopLoggingToFile(capture_handle)',
        '                if not isinstance(stopped, (list, tuple)) or not stopped or stopped[0] != "0000":',
        '                    raise RuntimeError(str(stopped))',
        '                capture_handle = None',
        '                captured = CAN.ReadFromCanLogFile(str(capture_path))',
        '                if not isinstance(captured, (list, tuple)) or captured[0] != "0000":',
        '                    raise RuntimeError(str(captured))',
        '                frames = [frame for frame in captured[1] if getattr(frame, "id", None) == message.frame_id]',
        '                if not frames:', '                    raise AssertionError(f"No fresh {frame_name} frame in the isolated capture")',
        '                for frame in frames:',
        '                    direction = getattr(frame, "direction", None)',
        '                    direction_name = getattr(direction, "name", str(direction)).casefold()',
        '                    if direction_name != "rx":',
        '                        raise RuntimeError("Receive direction is unverified; simulated/TX frames cannot pass this check")',
        '                    if len(frame.payload) != message.length:',
        '                        raise AssertionError(f"{frame_name}: captured length differs from the native DBC")',
        '                if check["kind"] == "present":',
        '                    RESULT.InterpretEqualResult(f"{frame_name} fresh RX communication", bool(frames), True)',
        '                else:',
        '                    expected = definition[check["field"]]',
        '                    if check["label"] is not None:', '                        expected = expected[check["label"]]',
        '                    values = [decode_can_signal(',
        '                        frame.payload, dbc_signal.start, dbc_signal.length,',
        '                        factor=dbc_signal.scale, offset=dbc_signal.offset, signed=dbc_signal.is_signed,',
        '                        byteorder="little" if dbc_signal.byte_order == "little_endian" else "big",',
        '                    )["raw"] for frame in frames]',
        '                    RESULT.InterpretEqualResult(f"{frame_name}.{signal_name}", values, [expected] * len(values))',
        '                    if any(value != expected for value in values):',
        '                        raise AssertionError(f"{frame_name}.{signal_name}: expected {expected}, observed {values}")',
        '    except Exception as error:',
        '        if report_ready:',
        '            RESULT.ExpectTestResult("Case execution failed", str(error), "All source steps verified", TestStatus.Failed)',
        '        raise',
        '    finally:',
        '        if report_ready:',
        '            cleanup_errors = []',
        '            try:',
        '                if capture_handle is not None:',
        '                    try:',
        '                        stopped = CAN.StopLoggingToFile(capture_handle)',
        '                        if not isinstance(stopped, (list, tuple)) or not stopped or stopped[0] != "0000":',
        '                            cleanup_errors.append(f"Capture stop failed: {stopped}")',
        '                    except Exception as error:',
        '                        cleanup_errors.append(f"Capture stop failed: {error}")',
        '                if touched_squib is not None:',
        '                    try:',
        '                        response = SQUIB.SendRequest(f"LOOP{squibs_config.SquibNumber[touched_squib]}", squibs_config.Squib_Fault_Description["NoFault"])',
        '                        if not isinstance(response, str) or not response.endswith(" set OK."):',
        '                            cleanup_errors.append(f"Squib restore failed: {response}")',
        '                        Wait(squibs_config.squib_fault_time["Dequalification_Time"])',
        '                    except Exception as error:',
        '                        cleanup_errors.append(f"Squib restore failed: {error}")',
        '                if bench_prepared:',
        '                    try:', '                        Clear_DTC_Info()',
        '                    except Exception as error:', '                        cleanup_errors.append(f"DTC cleanup failed: {error}")',
        '                    try:', '                        PS.IGN_ON()',
        '                    except Exception as error:', '                        cleanup_errors.append(f"Power restore failed: {error}")',
        '                if cleanup_errors:',
        '                    RESULT.ExpectTestResult("Cleanup failed", "; ".join(cleanup_errors), "All touched inputs restored", TestStatus.Failed)',
        '                    raise RuntimeError("Cleanup failed: " + "; ".join(cleanup_errors))',
        '            finally:', '                aria_reports.write_to_file()',
        '', '', 'if __name__ == "__main__":', '    run_test()', '',
    ]
    return "\n".join(source).encode("ascii", errors="backslashreplace").decode("ascii")


def validate_rendered(name: str, source: str) -> None:
    import ast

    tree = ast.parse(source, filename=name)
    functions = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    if functions != ["run_test"]:
        raise ValueError(f"{name}: expected exactly one run_test() and no helper functions, got {functions}")
    compile(tree, name, "exec")
    checker = runpy.run_path(str(REPOSITORY_ROOT / ".github" / "hooks" / "scripts" / "validate_script.py"))
    findings = checker["check_text"](
        f"projects/M310_M314_M110/modules/CANC/scripts/{name}", source,
    )
    if findings:
        raise ValueError(f"{name}: convention findings: {findings}")
    if "Api." in source or "time.sleep" in source:
        raise ValueError(f"{name}: direct bench API or raw sleep is not permitted")


def build_manifest(cases: list[dict[str, Any]], evidence: dict[str, Any], plans: list[dict[str, Any]], environment: dict[str, Any]) -> dict[str, Any]:
    hscan_message = validate_hscan_signal("IGN_STS_SRS", environment)[3]
    return {
        "extraction": evidence,
        "requirement_source": environment["requirement_evidence"],
        "dbc": {
            "file": next(path.relative_to(REPOSITORY_ROOT).as_posix() for path in DBC_FILES if "HSCAN" in path.name),
            "frame": hscan_message.name,
            "frame_id": hscan_message.frame_id,
            "dlc": hscan_message.length,
            "cycle_time_ms": hscan_message.cycle_time,
            "signals": [signal.name for signal in hscan_message.signals],
        },
        "supported_cases": list(SUPPORTED_CASES),
        "cases": [
            {
                "case_number": plan["number"],
                "case_id": plan["id"],
                "name": plan["name"],
                "source_rows": plan["rows"],
                "step_count": plan["source_step_count"],
                "verifies": plan["verifies"],
                "readiness": plan["readiness"],
                "script": (
                    f"projects/M310_M314_M110/modules/CANC/scripts/SUBS_CANC_2C0_TestCase_{plan['number']}.py"
                    if plan["readiness"] == "implemented-unexecuted" else None
                ),
                "blockers": plan["blockers"],
                "requirement_evidence": plan["requirement_evidence"],
            }
            for plan in plans
        ],
        "bench_executed": False,
        "shared_libraries_modified": False,
        "location_exception": "User requested new M314 CANC 2C0 scripts only; existing project/configuration/shared-library files are unchanged.",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--inspect", action="store_true")
    modes.add_argument("--validate", action="store_true")
    modes.add_argument("--check", action="store_true")
    parser.add_argument("--case", type=int, nargs="+")
    arguments = parser.parse_args(argv)

    cases, extraction = read_cases()
    environment = load_environment()
    plans = [plan_case(case, environment) for case in cases]
    ready = [plan for plan in plans if plan["readiness"] == "implemented-unexecuted"]
    if [plan["number"] for plan in ready] != list(SUPPORTED_CASES):
        raise ValueError(
            "The supported 2C0 case set changed or a required evidence/configuration check failed: "
            + "; ".join(f"{plan['number']}: {plan['blockers']}" for plan in plans if plan["blockers"])
        )
    if arguments.inspect:
        print("COMPLETE_WORKBOOK:", extraction)
        print("CASES:", len(cases), "STEPS:", extraction["steps"])
        print("SUPPORTED:", list(SUPPORTED_CASES))
        print("BLOCKED:", {plan["number"]: plan["blockers"] for plan in plans if plan["blockers"]})
        print("OFFLINE_ONLY: no shared-library import and no bench execution")
        return 0

    requested = list(arguments.case) if arguments.case else list(SUPPORTED_CASES)
    if len(requested) != len(set(requested)):
        raise ValueError("Requested case numbers contain duplicates")
    case_numbers = {case["number"] for case in cases}
    missing = [number for number in requested if number not in case_numbers]
    if missing:
        raise ValueError(f"One or more requested 2C0 case numbers do not exist: {missing}")
    blocked = [plan for plan in plans if plan["number"] in requested and plan["readiness"] != "implemented-unexecuted"]
    if blocked:
        raise ValueError("Refusing to generate blocked cases: " + "; ".join(
            f"{plan['number']}: {plan['blockers']}" for plan in blocked
        ))
    selected = [plan for plan in ready if plan["number"] in requested]
    rendered = {}
    for plan in selected:
        name = f"SUBS_CANC_2C0_TestCase_{plan['number']}.py"
        source = render_script(plan)
        validate_rendered(name, source)
        rendered[name] = source

    if arguments.validate:
        print("VALIDATED_IN_MEMORY", len(rendered), "SCRIPTS", "NO_BENCH_EXECUTION")
        return 0

    manifest = build_manifest(cases, extraction, plans, environment)
    manifest_text = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    if arguments.check:
        for name, source in rendered.items():
            path = SCRIPT_DIRECTORY / name
            if not path.is_file() or path.read_text(encoding="utf-8") != source:
                raise ValueError(f"Generated source differs or is missing: {path}")
        manifest_path = ARTIFACT_DIRECTORY / "coverage.json"
        if not manifest_path.is_file() or manifest_path.read_text(encoding="utf-8") != manifest_text:
            raise ValueError(f"Generated coverage manifest differs or is missing: {manifest_path}")
    else:
        if not (ARTIFACT_DIRECTORY / "README.md").is_file():
            raise ValueError("The retained artifact folder requires a README before generating outputs")
        for name, source in rendered.items():
            path = SCRIPT_DIRECTORY / name
            if path.exists() and not path.read_text(encoding="utf-8").startswith(
                f"# Author: GitHub Copilot\n# GENERATED FILE - do not edit by hand.\n# Rebuild with: {REBUILD_COMMAND}"
            ):
                raise ValueError(f"Refusing to overwrite an existing unrelated script: {path}")
            path.write_text(source, encoding="utf-8", newline="\n")
        ARTIFACT_DIRECTORY.mkdir(parents=True, exist_ok=True)
        (ARTIFACT_DIRECTORY / "coverage.json").write_text(manifest_text, encoding="utf-8", newline="\n")

    print(
        "VALIDATED_CASES", len(cases), "SOURCE_STEPS", extraction["steps"],
        "READY", len(ready), "BLOCKED", len(cases) - len(ready), "NO_BENCH_EXECUTION",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())