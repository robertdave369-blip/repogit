"""Run the six M314 Fault List CAN timing scripts sequentially.

Inputs: existing scripts under M310_M314_M110/modules/Fault_List/scripts.
Outputs: console progress and each script's configured reports and CAN logs.
Normal execution injects CAN faults and clears DTCs through those scripts.
Importing this runner or using --dry-run does not execute bench code.
"""

from __future__ import annotations

import argparse
import ast
import runpy
import sys
from contextlib import redirect_stdout
from pathlib import Path


SCRIPT_DIR = (
    Path(__file__).resolve().parents[1]
    / "projects"
    / "M310_M314_M110"
    / "modules"
    / "Fault_List"
    / "scripts"
)
SELECTED_TESTS = (
    "Fault_List_CAN_Node_Absent_Timing.py",
    "Fault_List_CAN_Message_Timeout_Timing.py",
    "Fault_List_CAN_Signal_Content_Failure_Timing.py",
    "Fault_List_CAN_Message_Content_Failure_DLC_Timing.py",
    "Fault_List_CAN_Message_Content_Failure_CRC_Timing.py",
    "Fault_List_CAN_Message_Content_Failure_Alive_Counter_Timing.py",
)
_REPORT_WRAPPER_PATH = Path(__file__).resolve().parents[1] / "shared_libraries" / "jscript_translation.py"


class _ReportingErrorOutput:
    """Make a RESULT wrapper's printed, caught reporting exception fatal."""

    def __init__(self, stream):
        self.stream = stream

    def write(self, text: str) -> int:
        caller = sys._getframe(1)
        error = sys.exc_info()[1]
        if (
            error is not None
            and caller.f_code.co_qualname.startswith("RESULT.")
            and Path(caller.f_code.co_filename).resolve() == _REPORT_WRAPPER_PATH
        ):
            traceback = error.__traceback__
            while traceback is not None:
                if traceback.tb_frame is caller:
                    raise RuntimeError(f"Reporting failed in {caller.f_code.co_qualname}: {error}") from error
                traceback = traceback.tb_next
        return self.stream.write(text)

    def flush(self) -> None:
        self.stream.flush()

    def __getattr__(self, name: str):
        return getattr(self.stream, name)


def run_suite(*, dry_run: bool = False) -> None:
    """Validate all selected files, then run them with their existing cleanup."""
    if not SELECTED_TESTS:
        raise ValueError("No CAN fault scripts selected; no tests were executed")
    if len(SELECTED_TESTS) != len(set(SELECTED_TESTS)):
        raise ValueError("CAN fault selection contains duplicate scripts")
    script_paths = []
    resolved_script_dir = SCRIPT_DIR.resolve()
    for script_name in SELECTED_TESTS:
        if (
            Path(script_name).name != script_name
            or not script_name.startswith("Fault_List_CAN_")
            or Path(script_name).suffix != ".py"
        ):
            raise ValueError(f"Selection must contain local CAN fault Python filenames: {script_name}")
        script_path = SCRIPT_DIR / script_name
        if script_path.resolve().parent != resolved_script_dir:
            raise ValueError(f"CAN fault script resolves outside its directory: {script_name}")
        if not script_path.is_file():
            raise FileNotFoundError(f"Missing CAN fault script: {script_path}")
        script_tree = ast.parse(script_path.read_text(encoding="utf-8-sig"), filename=str(script_path))
        compile(script_tree, str(script_path), "exec")
        if not any(isinstance(node, ast.FunctionDef) and node.name == "run_test" for node in script_tree.body):
            raise ValueError(f"CAN fault script has no run_test entry point: {script_name}")
        script_paths.append(script_path)

    if dry_run:
        print("Dry run only: no bench scripts imported or executed.", flush=True)
        for index, script_path in enumerate(script_paths, start=1):
            print(f"[{index}/{len(script_paths)}] {script_path.name}", flush=True)
        return

    print("M314 Fault List CAN-C suite: sequential execution; continue after reported timing failures.", flush=True)
    failed_scripts = []
    for index, script_path in enumerate(script_paths, start=1):
        print(f"\n[{index}/{len(script_paths)}] Running {script_path.name}", flush=True)
        try:
            with redirect_stdout(_ReportingErrorOutput(sys.stdout)):
                runpy.run_path(str(script_path), run_name="__main__")
        except Exception as error:
            timing_failures = getattr(error, "can_fault_timing_failures", None)
            if (
                isinstance(error, AssertionError)
                and isinstance(timing_failures, tuple)
                and timing_failures
                and all(isinstance(failure, str) and failure for failure in timing_failures)
            ):
                failed_scripts.append(f"{script_path.name}: {error}")
                print(f"[{index}/{len(script_paths)}] FAILED timing; reports saved and cleanup completed: {error}", flush=True)
                continue
            raise RuntimeError(
                f"M314 CAN fault suite stopped at {script_path.name}; remaining scripts were not run. "
                "Inspect the individual report and restore the bench before further testing."
            ) from error
        print(f"[{index}/{len(script_paths)}] Completed {script_path.name}", flush=True)
    print(f"Completed {len(script_paths)} CAN fault scripts; see individual reports for verdicts.", flush=True)
    if failed_scripts:
        summary = (
            f"M314 CAN fault suite completed all {len(script_paths)} scripts with "
            f"{len(failed_scripts)} script(s) reporting timing failures: " + "; ".join(failed_scripts)
        )
        print(f"FAILED: {summary}", flush=True)
        failure = AssertionError(summary)
        setattr(failure, "can_fault_timing_failures", tuple(failed_scripts))
        raise failure


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and list the selected scripts without importing or executing bench code.",
    )
    try:
        run_suite(dry_run=parser.parse_args(argv).dry_run)
    except AssertionError as error:
        if not getattr(error, "can_fault_timing_failures", None):
            raise
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()