"""Generate individual M314 CAN-C 13C or VCU scripts from complete approved exports."""

from __future__ import annotations

import argparse
import ast
import importlib.util
import json
import pprint
import re
import runpy
import sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from typing import Any

import cantools.database

from build_m314_canc_alignment import CAN_C_REQUIREMENTS, DBC_FILES, _workbook_rows
from map_codebeamer_requirement_links import normalized_text


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SOURCE_WORKBOOK = (
    REPOSITORY_ROOT / "project_testcases" / "m310_m314_m110" / "CANC"
    / "M314 CANC 13C signal and message spec test cases.xlsx"
)
SCRIPT_DIRECTORY = (
    REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "modules" / "CANC" / "scripts"
)
ARTIFACT_DIRECTORY = REPOSITORY_ROOT / "tests" / "artifacts" / "m314-canc-13c"
SANITIZE_TEXT = runpy.run_path(str(
    REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator"
    / "scripts" / "sanitize.py"
))["sanitize_text"]


def read_cases(
    path: Path = SOURCE_WORKBOOK,
    *,
    case_name_pattern: str = r"CANC_13C_TestCase_(\d+)",
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    document, rows, columns = _workbook_rows(
        path,
        "Export",
        (
            "ID", "Name", "Description", "Pre-Action", "Post-Action",
            "Test Steps.Action", "Test Steps.Expected result", "Test Steps.Id",
            "Verifies", "Status", "Type",
        ),
    )
    cases: list[dict[str, Any]] = []
    folders: list[int] = []
    current: dict[str, Any] | None = None
    current_is_folder = False
    for number, row in sorted(rows.items()):
        fields = {
            header: SANITIZE_TEXT(normalized_text(row.get(column, ""))).text
            for header, column in columns.items()
        }
        if fields["ID"]:
            current_is_folder = fields["Type"] == "Folder"
            if current_is_folder:
                folders.append(number)
                current = None
                continue
            match = re.fullmatch(case_name_pattern, fields["Name"])
            if match is None:
                raise ValueError(f"{path.name} -> Export -> C{number}: unexpected case name")
            if fields["Status"] != "APPROVED":
                raise ValueError(f"{fields['Name']}: source status is {fields['Status']!r}")
            current = {
                "number": int(match.group(1)),
                "id": fields["ID"].removesuffix(".0"),
                "name": fields["Name"],
                "description": fields["Description"],
                "priority": fields.get("Priority", ""),
                "pre_action": fields["Pre-Action"],
                "post_action": fields["Post-Action"],
                "verifies": fields["Verifies"],
                "status": fields["Status"],
                "row": number,
                "rows": [],
                "steps": [],
                "source_workbook": path.relative_to(REPOSITORY_ROOT).as_posix(),
            }
            cases.append(current)
        if current is None:
            if current_is_folder:
                folders.append(number)
                continue
            if any(fields.values()):
                raise ValueError(f"{path.name} -> Export -> row {number}: orphan data")
            continue
        current["rows"].append(number)
        if fields["Test Steps.Action"] or fields["Test Steps.Expected result"]:
            current["steps"].append({
                "row": number,
                "id": fields["Test Steps.Id"],
                "action": fields["Test Steps.Action"],
                "expected": fields["Test Steps.Expected result"],
            })
    if not cases or any(not case["steps"] for case in cases):
        raise ValueError("The source contains no cases or a case without test steps")
    for field in ("number", "id", "name"):
        duplicates = [value for value, count in Counter(case[field] for case in cases).items() if count > 1]
        if duplicates:
            raise ValueError(f"Duplicate {field}: {duplicates}")
    return sorted(cases, key=lambda case: case["number"]), {
        "source": document.source.to_dict(),
        "export_rows": len(rows),
        "case_rows": sum(len(case["rows"]) for case in cases),
        "folder_rows": folders,
        "steps": sum(len(case["steps"]) for case in cases),
        "missing_requirement_links": [
            {"name": case["name"], "locator": f"{path.name} -> Export -> L{case['row']}"}
            for case in cases if not case["verifies"]
        ],
        "successful": document.report.successful,
        "partial": document.report.partial,
        "failed": document.report.failed,
    }


def load_environment() -> dict[str, Any]:
    configs = {}
    for name in ("project_config", "canc_config", "dcs_config", "eol_config", "squibs_config", "cannm_config", "fault_list_config", "power_config"):
        path = REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "config" / f"{name}.py"
        spec = importlib.util.spec_from_file_location(f"_m314_13c_{name}", path)
        if spec is None or spec.loader is None:
            raise ValueError(f"Cannot load existing project configuration: {path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        configs[name] = module
    sys.path.insert(0, str(
        REPOSITORY_ROOT / ".github" / "skills" / "universal-document-understanding" / "scripts"
    ))
    from udu import adapters

    databases = []
    for path in DBC_FILES:
        document = adapters.build(path, deep=True)
        if document.report.failed:
            raise ValueError(f"{path}: DBC extraction failed: {document.report.failed}")
        databases.append(cantools.database.load_file(str(path), strict=False))
    configs["databases"] = databases
    requirement_document, rows, columns = _workbook_rows(
        CAN_C_REQUIREMENTS, "Export", ("ID", "Summary", "_ReqStatus", "Type", "Description"),
    )
    configs["requirements"] = {
        str(row[columns["ID"]]).removesuffix(".0"): {
            "row": number, "status": str(row.get(columns["_ReqStatus"], "")),
            "type": str(row.get(columns["Type"], "")),
            "summary": normalized_text(row.get(columns["Summary"], "")),
            "description": normalized_text(row.get(columns["Description"], "")),
            "locator": f"{CAN_C_REQUIREMENTS.name} -> Export -> {columns['_ReqStatus']}{number}",
        }
        for number, row in rows.items() if row.get(columns["ID"])
    }
    configs["requirement_evidence"] = {
        "source": requirement_document.source.to_dict(), "export_rows": len(rows),
        "variant_applicability": "Inference: target project folder and matching native M314 DBC; tracker project cells are empty",
    }
    protocol_names = {"ReadDTCInformation", "RDTCI_DTCbyStatusMask", "DTC_StatusMask", "DTC_status", "Over_Voltage", "Under_Voltage"}
    protocol = {}
    protocol_path = REPOSITORY_ROOT / "shared_libraries" / "configuration_control.py"
    for node in ast.parse(protocol_path.read_text(encoding="utf-8")).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in protocol_names:
                    protocol[target.id] = ast.literal_eval(node.value)
    if set(protocol) != protocol_names:
        raise ValueError(f"{protocol_path}: incomplete existing UDS catalog")
    protocol["read_request"] = " ".join((
        protocol["ReadDTCInformation"], protocol["RDTCI_DTCbyStatusMask"],
        protocol["DTC_StatusMask"]["ReadDTCInformation_DTCStatusMask_CANC"],
    ))
    protocol["empty_response"] = " ".join((
        f"0x{int(protocol['ReadDTCInformation'], 16) + 0x40:02X}",
        protocol["RDTCI_DTCbyStatusMask"],
        protocol["DTC_StatusMask"]["ReadDTCInformation_DTCStatusAvailabilityMask"],
    ))
    configs["protocol"] = protocol
    return configs


def signal_key(name: str, environment: dict[str, Any]) -> str | None:
    definitions = environment["canc_config"].MAH_CAN_SIGNAL_DEFS
    matches = [key for key, definition in definitions.items()
               if key.casefold() == name.casefold()
               or definition["signal"].casefold() == name.casefold()]
    return sorted(matches)[0] if matches else None


def expected_reference(key: str, value: int, environment: dict[str, Any]) -> dict[str, Any]:
    definition = environment["canc_config"].MAH_CAN_SIGNAL_DEFS[key]
    if definition.get("Default_Value") == value:
        return {"key": key, "field": "Default_Value", "label": None}
    labels = [label for label, raw in definition.get("State_Values", {}).items() if raw == value]
    if labels:
        return {"key": key, "field": "State_Values", "label": sorted(labels)[0]}
    if definition.get("Invalid_Value") == value:
        return {"key": key, "field": "Invalid_Value", "label": None}
    raise ValueError(f"{key}: expected raw value {value} has no existing config reference")


def plan_case(case: dict[str, Any], environment: dict[str, Any]) -> dict[str, Any]:
    family_match = re.fullmatch(r"CANC_(FR_ZONE|EPS|IEB)_TestCase_?(\d+)", case["name"])
    if family_match:
        family = family_match.group(1)
        is_eps = family == "EPS"
        is_ieb = family == "IEB"
        single_node = is_eps or is_ieb
        planned = {
            **case, "steps": [], "blockers": [], "requirement_evidence": [], "corrections": [],
            "category": f"M314 CAN-C {family}",
            "rebuild_command": f"C:/Python3.13.0/python.exe -B tools/generate_m314_canc_13c_scripts.py --family {family}" if is_ieb else f"py -3.13 -B tools/generate_m314_canc_13c_scripts.py --family {family}",
            "source_workbook": case["source_workbook"],
            "observation_scope": "Fresh simulated input capture/decoding and ECU diagnostic reactions; input TX is not proof of ECU consumption",
        }
        identifiers = re.findall(r"\[ISSUE:(\d+)\]", case["verifies"])
        if not identifiers:
            planned["blockers"].append(f"Export!L{case['row']}: source has no verified requirement link")
        for identifier in identifiers:
            requirement = environment["requirements"].get(identifier)
            if requirement is None:
                planned["blockers"].append(f"Requirement {identifier}: Evidence unavailable in the target CAN-C tracker")
                continue
            planned["requirement_evidence"].append({"id": identifier, **requirement})
            if requirement["status"].casefold() != "approved":
                planned["blockers"].append(f"Requirement {identifier} is {requirement['status']}, not Approved: {requirement['locator']}")
        parameters = {
            label.strip(): value.strip()
            for line in case["pre_action"].splitlines() if ":" in line
            for label, value in [line.split(":", 1)]
        }
        signal_name = parameters.get("Signal", "")
        if is_eps and not signal_name:
            signal_name = parameters.get("Counter Signal", "")
        frame_names = ([environment["canc_config"].CAN_VEHICLE_SPEED["frame"]] if is_ieb
                   else [environment["canc_config"].CAN_ABSOLUTE_ANGLE["frame"]] if is_eps
                   else list(dict.fromkeys(re.findall(r"FR_ZONE[23]_100", case["description"]))))
        if not single_node and case["number"] == 38:
            frame_names = ["FR_ZONE2_100", "FR_ZONE3_100"]
            planned["corrections"].append("Export precondition labels reverse the key/slave roles; this nominal case verifies both frames without injecting a role-dependent fault")
        if not frame_names:
            frame_names = list(dict.fromkeys(re.findall(r"FR_ZONE[23]_100", case["pre_action"])))
        mode = "unsupported"
        mechanism = parameters.get("Mechanism", "")
        voltage_level = None
        voltage_fault = None
        if len(case["steps"]) == 4 and signal_name and "decoded to the correct physical value" in case["description"]:
            mode = "nominal"
        elif is_ieb:
            if case["number"] == 1:
                mode = "node_fault"
            elif case["number"] == 2:
                mode = "dlc"
            elif case["number"] in (3, 4):
                mode = "content"
                candidates = environment["canc_config"].get_message_content_failure_signals(frame_names[0])
                signal_name = next(name for name in candidates if ("CRC" if case["number"] == 3 else "MSG_CNT") in name)
            elif case["number"] in (5, 6):
                mode = "signal_fault"
            elif case["number"] in (7, 8):
                mode = "isolation"
                planned["corrections"].append("Only other application fields are held constant; CRC and message-counter generators remain enabled because freezing protection fields itself causes MCF, as confirmed by the user")
            elif case["number"] in (9, 10):
                mode = "priority"
                signal_name = environment["canc_config"].CAN_VEHICLE_SPEED["signal"]
            elif case["number"] == 13:
                mode = "periodic"
            if case["number"] == 11:
                planned["blockers"].append("Export!G108/H108: IEB sender counter reset/rollover ownership is not defined by the ACU ignition cycle; an approved sender-reset expectation is required")
            if case["number"] == 12:
                planned["blockers"].append("Export!G84/H84: expected CRC transport/integrity pattern and algorithm are unspecified; arithmetic decoding is not proof of integrity handling")
        elif is_eps:
            if case["number"] == 1:
                mode = "node_fault"
            elif case["number"] == 2:
                mode = "dlc"
            elif case["number"] in (3, 4):
                mode = "content"
                signal_name = getattr(environment["canc_config"], "CAN_EPS1_CRC" if case["number"] == 3 else "CAN_EPS1_MSG_COUNT")["signal"]
            elif case["number"] == 5:
                mode = "signal_fault"
                configured_count = environment["canc_config"].SIGNAL_CONTENT_DETECTION_COUNT
                source_count = re.search(r"Qualification Time \((\d+) cycles", case["steps"][3]["action"])
                if source_count is None:
                    planned["blockers"].append("EPS qualification step Export!G42 has no traceable cycle count")
                else:
                    planned["corrections"].append(f"User-selected existing canc_config.SIGNAL_CONTENT_DETECTION_COUNT ({configured_count} cycles) replaces the {source_count.group(1)}-cycle Export!G42 wording; the shared CAN threshold itself is unchanged")
            elif case["number"] in (8, 9):
                mode = "priority"
            elif 10 <= case["number"] <= 19:
                mode = "voltage"
                voltage_level = "over_voltage" if case["number"] <= 14 else "under_voltage"
                voltage_fault = ("node", "dlc", "crc", "counter", "signal")[(case["number"] - 10) % 5]
                if voltage_fault in ("crc", "counter"):
                    signal_name = getattr(environment["canc_config"], "CAN_EPS1_CRC" if voltage_fault == "crc" else "CAN_EPS1_MSG_COUNT")["signal"]
                source_voltage = re.search(r"Voltage Level:\s*([\d.]+)V", case["pre_action"])
                configured_voltage = environment["fault_list_config"].EPS_VOLTAGE_TEST_LEVELS.get(voltage_level)
                if source_voltage is None or configured_voltage != float(source_voltage.group(1)):
                    planned["blockers"].append("EPS voltage stimulus disagrees with the source Voltage Level")
                planned["corrections"].append("Voltage status 08 follows the supplied EPS workbook and fault catalogue section 25.5; conflicting general 8B guidance is not silently substituted")
            elif case["number"] == 22:
                mode = "periodic"
        elif case["number"] in (3, 4, 14, 15):
            mode = "content"
            signal_name = frame_names[0].removesuffix("_100") + ("_CRC" if mechanism == "CRC" else "_COUNTER")
        elif case["number"] in (16, 17, 18, 19):
            mode = "signal_fault"
        elif case["number"] in (9, 26, 38):
            mode = "periodic" if case["number"] != 38 else "both_present"
        if not single_node and case["number"] in (1, 12, 23):
            planned["blockers"].append("Workbook key/slave roles contradict existing KEY_TX_FRAMES: M314 marks FR_ZONE3_100 as key and FR_ZONE2_100 as non-key; do not substitute a different fault objective")
        if "DLC" in case["pre_action"] and not single_node:
            planned["blockers"].append("D-04: existing SetPeriodicFrame changes an existing payload, but transmitted wrong DLC and healthy-length restoration are unverified; an approved length-changing recipe is required")
        elif single_node and mode in ("dlc", "priority", "voltage") and "DLC" in case["pre_action"]:
            planned["corrections"].append("D-04: the existing SetPeriodicFrame recipe requires fresh shortened-length and restored healthy-length captures; offline validation cannot certify native DLC actuation")
        if (is_eps and case["number"] == 20) or (not single_node and case["number"] in (7, 24)):
            planned["blockers"].append("D-03: sender counter rollover/reset ownership, configured modulus and ignition-reset behavior need verification; resetting this ECU does not prove a simulated sender resets")
        if is_eps and case["number"] in (6, 7):
            planned["blockers"].append("Requirement 31858881: literal unchanged companion fields versus live CRC/counter gating, protected-byte exclusion and valid E2E baseline evidence must be resolved; changing a field alone is not proof of CRC exclusion")
        if is_eps and case["number"] == 21:
            planned["blockers"].append("Requirement 31127517 requires E2E profile 5; verified M314 Data ID, protected-byte coverage and E2E reference vectors are unavailable; a CRC field scaling sweep cannot establish integrity conformance")
        if is_eps and case["number"] == 24:
            planned["observation_scope"] += "; case 24 verifies raw counter-field transport/decoding only, not increment, rollover, sender reset or E2E conformance"
        if re.search(r"CRC|COUNTER|TRUNCATED|FRESHNESS", signal_name, re.IGNORECASE) and mode not in ("content", "isolation") and not (is_eps and (mode == "voltage" or case["number"] == 24)):
            planned["blockers"].append("Integrity-field sequence, protected-field exclusion and dynamic update/restoration evidence are unavailable for this objective; a linear decoding sweep is not an integrity test")
        if mode == "unsupported":
            planned["blockers"].append("Evidence unavailable for the complete source fault/priority/voltage/integrity sequence and its restoration; no partial scenario is permitted to pass")
        definitions = environment["canc_config"].MAH_CAN_SIGNAL_DEFS
        keys = []
        for frame_name in frame_names:
            selected_signal = signal_name or (environment["canc_config"].CAN_VEHICLE_SPEED["signal"] if is_ieb else environment["canc_config"].CAN_ABSOLUTE_ANGLE["signal"] if is_eps else frame_name.removesuffix("_100") + "_CRC")
            matches = [key for key, definition in definitions.items()
                       if definition["frame"] == frame_name and definition["signal"] == selected_signal]
            if not matches:
                planned["blockers"].append(f"No existing M314 definition for {frame_name}.{selected_signal}")
                continue
            key = selected_signal if selected_signal in matches else sorted(matches)[0]
            keys.append(key)
            definition = definitions[key]
            messages = [message for database in environment["databases"] for message in database.messages if message.name == frame_name]
            if len(messages) != 1:
                planned["blockers"].append(f"Native M314 DBC does not uniquely define {frame_name}")
                continue
            message = messages[0]
            dbc_signal = message.get_signal_by_name(selected_signal)
            configured = (definition["frame_ID"], definition["dlc"], definition["is_fd"], definition["periodicity"], definition["bit_length"], definition["Signed"], definition["byte_order"], definition["Factor"], definition["Offset"], definition["MIN"], definition["MAX"])
            native = (message.frame_id, message.length, message.is_fd, message.cycle_time, dbc_signal.length, dbc_signal.is_signed, dbc_signal.byte_order, dbc_signal.scale, dbc_signal.offset, dbc_signal.minimum, dbc_signal.maximum)
            if definition.get("ecu_generated") or configured != native:
                planned["blockers"].append(f"Existing config/native DBC disagree or signal is ECU-generated: {frame_name}.{selected_signal}")
            if is_ieb and definition.get("start_bit") != dbc_signal.start:
                planned["blockers"].append(f"{frame_name}.{selected_signal}: required configured start_bit is missing or disagrees with native DBC")
            if mode in ("nominal", "isolation"):
                vectors = definition.get("TestCase_values", [])
                invalid_values = (any(type(value) is not int or not Decimal(str(definition["MIN"])) <= Decimal(value) * Decimal(str(definition["Factor"])) + Decimal(str(definition["Offset"])) <= Decimal(str(definition["MAX"])) for value in vectors) if is_eps
                                  else any(not isinstance(value, int) or not definition["MIN"] <= value * definition["Factor"] + definition["Offset"] <= definition["MAX"] for value in vectors))
                if not vectors or invalid_values:
                    planned["blockers"].append(f"{key}: existing nominal TestCase_values do not cover valid configured values")
            validation_mode = ("content" if voltage_fault in ("crc", "counter", "dlc") else "signal_fault" if voltage_fault == "signal" else mode) if mode == "voltage" else mode
            if validation_mode in ("content", "signal_fault"):
                catalog = "CAN_MESSAGE_CONTENT_FAILURE_DTC" if validation_mode == "content" else "CAN_SIGNAL_CONTENT_FAILURE_DTC"
                if is_eps and voltage_fault == "dlc":
                    candidates = environment["canc_config"].CAN_TX_MESSAGE_CONFIG[frame_name]["message_content_failure_dtcs"]
                    if not candidates or len(set(candidates.values())) != 1:
                        planned["blockers"].append("EPS DLC fault does not resolve one unambiguous existing content DTC")
                elif selected_signal not in getattr(environment["canc_config"], catalog):
                    planned["blockers"].append(f"No existing {catalog} entry for {selected_signal}")
                if validation_mode == "signal_fault" and (definition.get("Invalid_Value") is None or definition.get("SCF_Recovery_Value") is None):
                    planned["blockers"].append(f"{key}: configured invalid/recovery raw value is missing")
        if not keys:
            planned["blockers"].append(f"The source has no complete configured {family} target")
        if case["post_action"]:
            planned["blockers"].append("Source Post-Action requires an approved mapping beyond standard frame/DTC/ignition restoration")
        for index, source_step in enumerate(case["steps"]):
            step = {**source_step, "operations": [], "checks": [], "blocked": []}
            if index == 0:
                step["operations"].extend(({"kind": "fault_free"}, {"kind": "ign_on"}))
                step["operations"].extend({"kind": "healthy_input", "key": key} for key in keys)
                step["operations"].append({"kind": "read_no_dtc"})
                if mode == "isolation" and keys:
                    step["operations"].append({"kind": "isolate_integrity_input", "key": keys[0]})
            elif keys and index == 1:
                for key in keys:
                    step["operations"].append({"kind": "enable_input", "key": key})
                    step["checks"].append({"kind": "input_present", "key": key})
                step["correction"] = f"Start only the configured {family} frame(s) for this objective, not copied IEB/EPS/HPCAd traffic"
            elif keys and mode == "nominal":
                if index in (2, 3):
                    step["checks"].append({"kind": "input_sweep" if index == 2 else "physical_sweep", "key": keys[0]})
                    if index == 3 and not ((is_ieb and case["number"] == 25) or (is_eps and case["number"] == 24)):
                        step["operations"].append({"kind": "read_no_dtc"})
                    if ((is_ieb and case["number"] == 25) or (is_eps and case["number"] == 24)) and index == 2:
                        step["operations"].append({"kind": "protection_fault", "key": keys[0]})
                        planned["corrections"].append("The counter-only decoding sweep temporarily freezes its generator to transmit configured raw values; this can create MCF and does not verify ECU consumption or counter integrity")
                else:
                    step["blocked"].append("Unmapped nominal source step")
            elif keys and mode == "isolation":
                step["checks"].append({"kind": "input_sweep" if index == 2 else "input_present", "key": keys[0]})
                if index == 3:
                    step["operations"].append({"kind": "read_fault_dtc", "key": keys[0], "catalog": "CAN_MESSAGE_CONTENT_FAILURE_DTC", "status": None})
            elif keys and mode in ("periodic", "both_present"):
                step["checks"].extend({"kind": "input_present", "key": key} for key in keys)
                step["operations"].append({"kind": "read_no_dtc"})
            elif keys and mode == "voltage":
                key = keys[0]
                dtc_kind = "node" if voltage_fault == "node" else "signal" if voltage_fault == "signal" else "content"
                count_prefix = "NODE_ABSENT" if voltage_fault == "node" else "SIGNAL_CONTENT" if voltage_fault == "signal" else "MESSAGE_CONTENT"
                if index == 2:
                    step["operations"].append({"kind": "eps_voltage", "level": voltage_level})
                elif index == 3:
                    step["operations"].append({"kind": "eps_dtc_states", "key": key, "states": {voltage_level: "DTC_historic", dtc_kind: None}})
                elif index == 4:
                    fault_operation = "node_fault" if voltage_fault == "node" else "dlc_fault" if voltage_fault == "dlc" else "signal_fault" if voltage_fault == "signal" else "protection_fault"
                    step["operations"].append({"kind": fault_operation, "key": key})
                elif index == 5:
                    step["operations"].extend((
                        {"kind": "wait_fault", "key": key, "count": count_prefix + "_DETECTION_COUNT"},
                        {"kind": "eps_dtc_states", "key": key, "states": {voltage_level: "DTC_historic", dtc_kind: None}},
                    ))
                    if voltage_fault == "dlc":
                        step["checks"].append({"kind": "input_present", "key": key, "expected_length": "short"})
                elif index == 6:
                    step["operations"].extend((
                        {"kind": "eps_voltage", "level": "nominal", "restart_delay": "NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS" if voltage_level == "over_voltage" else "NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS"},
                        {"kind": "wait_fault", "key": key, "count": count_prefix + "_DETECTION_COUNT"},
                    ))
                elif index in (7, 8):
                    if index == 8:
                        step["operations"].extend(({"kind": "ign_cycle"}, {"kind": "wait_fault", "key": key, "count": count_prefix + "_DETECTION_COUNT"}))
                    step["operations"].append({"kind": "eps_dtc_states", "key": key, "states": {voltage_level: "DTC_historic", dtc_kind: "DTC_active_WLOFF"}})
                elif index == 9:
                    restore_operation = "restore_node" if voltage_fault == "node" else "restore_frame" if voltage_fault == "dlc" else "restore_signal" if voltage_fault == "signal" else "restore_protection"
                    step["operations"].append({"kind": restore_operation, "key": key})
                    if voltage_fault == "dlc":
                        step["checks"].append({"kind": "input_present", "key": key})
                elif index == 10:
                    step["operations"].append({"kind": "wait_fault", "key": key, "count": count_prefix + "_RECOVERY_COUNT"})
                elif index in (11, 12):
                    if index == 12:
                        step["operations"].extend(({"kind": "ign_cycle"}, {"kind": "wait_fault", "key": key, "count": count_prefix + "_RECOVERY_COUNT"}))
                    step["operations"].append({"kind": "eps_dtc_states", "key": key, "states": {dtc_kind: "DTC_healed" if index == 11 else "DTC_historic"}, "optional_states": {voltage_level: "DTC_historic"}})
                else:
                    step["blocked"].append("Unmapped EPS voltage-suppression source step")
            elif keys and mode == "priority":
                key = keys[0]
                higher_kind = "content" if case["number"] == (9 if is_ieb else 8) else "node"
                higher_count = "MESSAGE_CONTENT_DETECTION_COUNT" if higher_kind == "content" else "NODE_ABSENT_DETECTION_COUNT"
                if index == 2:
                    step["operations"].extend((
                        {"kind": "signal_fault", "key": key},
                        {"kind": "wait_fault", "key": key, "count": "SIGNAL_CONTENT_DETECTION_COUNT"},
                    ))
                elif index == 3:
                    step["operations"].append({"kind": "eps_dtc_states", "key": key, "states": {"signal": "DTC_active_WLOFF"}})
                elif index == 4:
                    step["operations"].extend((
                        {"kind": "dlc_fault" if higher_kind == "content" else "node_fault", "key": key},
                        {"kind": "wait_fault", "key": key, "count": higher_count},
                    ))
                    if higher_kind == "content":
                        step["checks"].append({"kind": "input_present", "key": key, "expected_length": "short"})
                        if single_node:
                            step["checks"][-1]["preserve_signal_fault"] = True
                elif index == 5:
                    step["operations"].append({"kind": "eps_dtc_states", "key": key, "states": {}, "observe": True})
                elif index in (6, 7):
                    step["operations"].extend((
                        {"kind": "ign_cycle"},
                        {"kind": "eps_dtc_states", "key": key, "states": {
                            higher_kind: "DTC_active_WLOFF",
                            "signal": "DTC_healed" if index == 6 else "DTC_historic",
                        }},
                    ))
                else:
                    step["blocked"].append("Unmapped EPS priority source step")
            elif keys and mode in ("content", "signal_fault", "node_fault", "dlc"):
                key = keys[0]
                catalog = "CAN_MESSAGE_CONTENT_FAILURE_DTC" if mode in ("content", "dlc") else "CAN_NODE_ABSENT_DTC" if mode == "node_fault" else "CAN_SIGNAL_CONTENT_FAILURE_DTC"
                count_prefix = "MESSAGE_CONTENT" if mode in ("content", "dlc") else "NODE_ABSENT" if mode == "node_fault" else "SIGNAL_CONTENT"
                if index == 2:
                    step["operations"].append({"kind": "protection_fault" if mode == "content" else "node_fault" if mode == "node_fault" else "dlc_fault" if mode == "dlc" else "signal_fault", "key": key})
                    step["correction"] = "Inject only the objective's configured CRC/counter or invalid-signal fault using the existing wrapper"
                elif index in (3, 6):
                    step["operations"].append({"kind": "wait_fault", "key": key, "count": count_prefix + ("_DETECTION_COUNT" if index == 3 else "_RECOVERY_COUNT")})
                    if mode == "dlc" and index == 3:
                        step["checks"].append({"kind": "input_present", "key": key, "expected_length": "short"})
                elif index in (4, 7) or ((mode == "content" or single_node) and index == 8):
                    if index == 8:
                        step["operations"].append({"kind": "ign_cycle"})
                    status = "DTC_active_WLOFF" if index == 4 else "DTC_healed" if index == 7 else "DTC_historic"
                    step["operations"].append({"kind": "read_fault_dtc", "key": key, "catalog": catalog, "status": status})
                    step["correction"] = "Expected DTC and status resolve from the selected M314 fault catalog and existing DTC_status, not copied or TBD workbook bytes"
                elif index == 5:
                    step["operations"].append({"kind": "restore_protection" if mode == "content" else "restore_node" if mode == "node_fault" else "restore_frame" if mode == "dlc" else "restore_signal", "key": key})
                    if is_ieb and mode == "signal_fault":
                        step["operations"][-1]["field"] = "Default_Value"
                    if mode == "dlc":
                        step["checks"].append({"kind": "input_present", "key": key})
                    step["correction"] = "Restore the injected protection signal or configured SCF_Recovery_Value before dequalification"
                    if mode == "signal_fault" and not single_node:
                        step["operations"].append({"kind": "read_fault_dtc", "key": key, "catalog": "CAN_MESSAGE_CONTENT_FAILURE_DTC", "status": None, "remaining_statuses": ["DTC_active_WLOFF", "DTC_healed"]})
                elif mode == "signal_fault" and index == 8:
                    step["operations"].append({"kind": "read_fault_dtc", "key": key, "catalog": "CAN_MESSAGE_CONTENT_FAILURE_DTC", "status": None, "remaining_statuses": ["DTC_healed"]})
                    step["correction"] = "A signal-only fault must not create a message-content DTC; copied HPCC content-failure bytes do not belong to this objective"
                else:
                    step["blocked"].append("Unmapped source fault/recovery step")
            else:
                step["blocked"].append("Complete objective is blocked by the recorded evidence gaps")
            if step.get("correction"):
                planned["corrections"].append(f"Export!G{step['row']}/H{step['row']}: {step['correction']}")
            if is_ieb:
                for operation in step["operations"]:
                    if operation["kind"] == "eps_dtc_states":
                        operation["kind"] = "priority_dtc_states"
            planned["blockers"].extend(f"Export!G{step['row']}/H{step['row']}: {reason}" for reason in step["blocked"])
            planned["steps"].append(step)
        planned["blockers"] = list(dict.fromkeys(planned["blockers"]))
        planned["readiness"] = "blocked" if planned["blockers"] else "implemented-unexecuted"
        return planned
    if re.fullmatch(r"CANC_VCU_TestCase_?(\d+)", case["name"], re.IGNORECASE):
        planned = {
            **case, "steps": [], "blockers": [], "requirement_evidence": [],
            "category": "M314 CAN-C VCU",
            "rebuild_command": "C:/Python3.13.0/python.exe -B tools/generate_m314_canc_13c_scripts.py --family VCU",
            "observation_scope": "Simulated VCU input capture and decoding; not evidence of ECU consumption",
        }
        identifiers = re.findall(r"\[ISSUE:(\d+)\]", case["verifies"])
        if not identifiers:
            planned["blockers"].append(f"Export!L{case['row']}: source has no verified requirement link")
        for identifier in identifiers:
            requirement = environment["requirements"].get(identifier)
            if requirement is None:
                planned["blockers"].append(f"Requirement {identifier}: Evidence unavailable in the existing target CAN-C tracker")
                continue
            planned["requirement_evidence"].append({"id": identifier, **requirement})
            if requirement["status"].casefold() != "approved":
                planned["blockers"].append(f"Requirement {identifier} is {requirement['status']}, not Approved: {requirement['locator']}")
        parameters = {
            label.strip(): value.strip()
            for line in case["pre_action"].splitlines() if ":" in line
            for label, value in [line.split(":", 1)]
        }
        signal_name = parameters.get("Signal", "")
        starts = [
            re.fullmatch(r"Start valid transmission of ID (0x[0-9A-Fa-f]+) (\w+) with configured periodicity\.", step["action"])
            for step in case["steps"] if step["action"].startswith("Start valid transmission")
        ]
        start = starts[0] if len(starts) == 1 else None
        periodic_case = not signal_name and "specified periodicity" in case["description"]
        if periodic_case and start is not None:
            frame_definitions = [definition for definition in environment["canc_config"].MAH_CAN_SIGNAL_DEFS.values() if definition["frame"] == start.group(2)]
            if frame_definitions:
                signal_name = frame_definitions[0]["signal"]
        if case["number"] == 45:
            planned["blockers"].append("Export!G5/H7, D-10: stopping parent VCU11_FD_10 selects node absence, while the source expects the VCU4_FD_1500 slave timeout; confirm whether only the slave is to be stopped with the parent kept valid")
        key = None
        definition = None
        if not signal_name or start is None:
            planned["blockers"].append("The source does not identify one signal and one complete frame-start action")
        else:
            frame_name = start.group(2)
            described_frame = re.search(r"received in (\w+)", case["description"])
            if periodic_case:
                described_frame = re.search(r"Verify that (\w+) is received", case["description"])
            if described_frame and described_frame.group(1) != frame_name:
                planned["blockers"].append(f"Export!D{case['row']}: description frame {described_frame.group(1)} contradicts action frame {frame_name}")
            matches = [
                name for name, definition in environment["canc_config"].MAH_CAN_SIGNAL_DEFS.items()
                if definition["frame"] == frame_name and definition["signal"] == signal_name
            ]
            if not matches:
                planned["blockers"].append(f"No existing M314 definition matches {frame_name}.{signal_name}; a signal-only alias cannot resolve this contradiction")
            else:
                key = signal_name if signal_name in matches else sorted(matches)[0]
                definition = environment["canc_config"].MAH_CAN_SIGNAL_DEFS[key]
                fields = ("frame", "signal", "frame_ID", "bus", "periodicity", "Factor", "Offset", "MIN", "MAX", "bit_length", "Signed", "byte_order", "TestCase_values", "ecu_generated")
                if any(any(environment["canc_config"].MAH_CAN_SIGNAL_DEFS[name].get(field) != definition.get(field) for field in fields) for name in matches):
                    planned["blockers"].append(f"Existing aliases disagree for {frame_name}.{signal_name}")
                if definition.get("ecu_generated"):
                    planned["blockers"].append("Refusing to simulate an ECU-generated output")
                messages = [message for database in environment["databases"] for message in database.messages if message.name == frame_name]
                if len(messages) != 1:
                    planned["blockers"].append(f"Native M314 DBC does not uniquely define {frame_name}")
                else:
                    message = messages[0]
                    dbc_signal = message.get_signal_by_name(signal_name)
                    configured = (definition["frame_ID"], definition["dlc"], definition["is_fd"], definition["periodicity"], definition["bit_length"], definition["Signed"], definition["byte_order"], definition["Factor"], definition["Offset"], definition["MIN"], definition["MAX"])
                    native = (message.frame_id, message.length, message.is_fd, message.cycle_time, dbc_signal.length, dbc_signal.is_signed, dbc_signal.byte_order, dbc_signal.scale, dbc_signal.offset, dbc_signal.minimum, dbc_signal.maximum)
                    if configured != native or int(start.group(1), 16) != message.frame_id:
                        planned["blockers"].append(f"Workbook/config/native DBC disagree for {frame_name}.{signal_name}")
                try:
                    periodicity = float(parameters["Periodicity"].removesuffix("ms").strip())
                    tolerance = float(parameters["Tolerance"].removesuffix("%").strip())
                    if periodicity != definition["periodicity"]:
                        planned["blockers"].append(f"Export!E{case['row']}: source periodicity contradicts existing M314 config")
                    if tolerance != environment["canc_config"].CAN_FAULT_TIMING_TOLERANCE_PERCENT:
                        planned["blockers"].append(f"Export!E{case['row']}: source cycle-time tolerance has no matching existing M314 timing configuration")
                    if periodic_case:
                        for requirement in planned["requirement_evidence"]:
                            periods = re.findall(r"\bperiodicity(?:\s+of)?\s*(\d+(?:\.\d+)?)\s*ms\b", requirement["summary"] + " " + requirement["description"], re.IGNORECASE)
                            for source_period in periods:
                                if float(source_period) != periodicity:
                                    planned["blockers"].append(f"Requirement {requirement['id']} at {requirement['locator']} states {source_period} ms, while the workbook and native M314 frame specify {periodicity:g} ms; authoritative timing clarification is required")
                    if not periodic_case:
                        scaling = float(parameters["Scaling"])
                        offset = float(parameters["Offset"])
                        raw_range = tuple(float(value.strip()) for value in parameters["Raw Range"].split(" to "))
                        physical_range = tuple(float(value.strip()) for value in parameters["Physical Range"].split(" to "))
                        if scaling != definition["Factor"] or offset != definition["Offset"] or physical_range != (definition["MIN"], definition["MAX"]):
                            planned["blockers"].append(f"Export!E{case['row']}: source scaling, offset or physical range contradicts existing M314 config")
                        if len(raw_range) != 2 or scaling == 0 or tuple(value * scaling + offset for value in raw_range) != physical_range:
                            planned["blockers"].append(f"Export!E{case['row']}: raw and physical ranges do not agree with source scaling/offset")
                        vectors = definition.get("TestCase_values", [])
                        if not vectors or any(not isinstance(value, int) or not raw_range[0] <= value <= raw_range[-1] for value in vectors):
                            planned["blockers"].append(f"{key}: existing TestCase_values do not provide a complete nominal raw-value vector")
                except (KeyError, TypeError, ValueError) as error:
                    planned["blockers"].append(f"Export!E{case['row']}: incomplete source/config decoding parameters: {error}")
                if planned["requirement_evidence"] and not any(
                    re.search(rf"(?<!\w){re.escape(frame_name if periodic_case else signal_name)}(?!\w)", item["summary"] + " " + item["description"], re.IGNORECASE)
                    for item in planned["requirement_evidence"]
                ):
                    planned["blockers"].append(f"Linked requirements do not establish the {signal_name} signal objective")
        if not periodic_case and re.search(r"CRC|MSG_CNT|TRUNCATED|FRESHNESS|COUNTER", signal_name, re.IGNORECASE):
            planned["blockers"].append("Integrity-field behavior needs the verified CRC/counter/MAC algorithm, update sequence and ECU fault/recovery observable; a linear scaling sweep is not that test")
        if case["post_action"]:
            planned["blockers"].append("The source Post-Action needs a verified mapping beyond the standard frame/DTC/ignition restoration")
        for source_step in case["steps"]:
            step = {**source_step, "operations": [], "checks": [], "blocked": []}
            action = step["action"]
            transmitted = re.fullmatch(r"Transmit representative raw values for signal (\w+) and monitor the dataframe\.", action)
            compared = re.fullmatch(r"Compare the displayed physical value of (\w+) against the configured scaling and offset\.", action)
            if action == "Set test bench to normal condition and enable IGN ON.":
                step["operations"].extend(({"kind": "fault_free"}, {"kind": "ign_on"}, {"kind": "read_no_dtc"}))
            elif start is not None and action == start.group(0):
                if key is not None:
                    step["operations"].append({"kind": "enable_input", "key": key})
                    step["checks"].append({"kind": "input_present", "key": key})
            elif (matched_signal := transmitted if transmitted is not None else compared) is not None:
                mentioned = matched_signal.group(1)
                if mentioned != signal_name:
                    step["blocked"].append(f"Source action signal {mentioned} contradicts precondition signal {signal_name}")
                elif key is not None:
                    step["checks"].append({"kind": "input_sweep" if transmitted else "physical_sweep", "key": key})
                    if compared:
                        step["operations"].append({"kind": "read_no_dtc"})
            elif periodic_case and key is not None and start is not None and definition is not None and (
                action == f"Monitor ID {start.group(1)} {start.group(2)} on the bus."
                or action == "Measure the time difference between consecutive message frames over multiple cycles."
                or action == f"Compare the measured time difference against {definition['periodicity']} ms with tolerance {environment['canc_config'].CAN_FAULT_TIMING_TOLERANCE_PERCENT:g}%."
                or action == "Continue monitoring over additional cycles."
            ):
                step["checks"].append({"kind": "input_present", "key": key})
                step["operations"].append({"kind": "read_no_dtc"})
            else:
                if "0x13A EPS1_FD_10" in action or "0x13B IEB1_FD_10" in action:
                    step["blocked"].append("Source stimulus targets EPS/IEB instead of the VCU objective; an authoritative corrected sequence is required")
                elif "DLC" in action:
                    step["blocked"].append("D-04: an approved wrong-length transmit and healthy-length restoration recipe is not verified by the existing SetPeriodicFrame payload-only update")
                elif "Counter" in action or "MSG_CNT" in action or "CRC" in action or "TRUNCATED" in action:
                    step["blocked"].append("Integrity stimulus, dynamic update ownership and protection restoration are not completely specified for this source sequence")
                else:
                    step["blocked"].append("Implementation unavailable for this source action as part of a complete, contradiction-free stimulus/DTC/recovery sequence; do not execute a partial case")
            planned["blockers"].extend(f"Export!G{step['row']}/H{step['row']}: {reason}" for reason in step["blocked"])
            planned["steps"].append(step)
        if not periodic_case and not planned["blockers"]:
            shape = [(tuple(operation["kind"] for operation in step["operations"]), tuple(check["kind"] for check in step["checks"])) for step in planned["steps"]]
            if shape != [(("fault_free", "ign_on", "read_no_dtc"), ()), (("enable_input",), ("input_present",)), ((), ("input_sweep",)), (("read_no_dtc",), ("physical_sweep",))]:
                planned["blockers"].append("Source step ordering does not match the verified normal/start/raw/physical lifecycle")
        planned["blockers"] = list(dict.fromkeys(planned["blockers"]))
        planned["readiness"] = "blocked" if planned["blockers"] else "implemented-unexecuted"
        return planned
    planned = {**case, "steps": [], "blockers": []}
    if not case["verifies"]:
        planned["blockers"].append(f"Export!L{case['row']}: source requirement link is empty")
    planned["requirement_evidence"] = []
    for identifier in re.findall(r"\[ISSUE:(\d+)\]", case["verifies"]):
        requirement = environment["requirements"].get(identifier)
        if requirement is None:
            planned["blockers"].append(f"Requirement {identifier}: Evidence unavailable in the existing target CAN-C tracker")
            continue
        planned["requirement_evidence"].append({"id": identifier, **requirement})
        if requirement["status"].casefold() != "approved":
            planned["blockers"].append(f"Requirement {identifier} is {requirement['status']}, not Approved: {requirement['locator']}")
    case_text = " ".join((case["description"], case["pre_action"]))
    if "OCS" in case_text.upper() and "OCS" in environment["eol_config"].EOL_NOT_APPLICABLE_FEATURES:
        payload = bytes.fromhex(environment["project_config"].DEFAULT_EOL_CODE.replace("0x", ""))
        byte_index, bit_index = environment["eol_config"].M310_M314_M110_FEATURE_MAP["OCS"]
        encoded_enabled = bool(payload[byte_index] & (1 << bit_index))
        if encoded_enabled:
            planned["blockers"].append("OCS configuration contradiction: selected DEFAULT_EOL_CODE enables OCS, but EOL_NOT_APPLICABLE_FEATURES marks it non-applicable; confirm accepted ECU coding and applicability")
        else:
            planned["blockers"].append("Existing M314 eol_config marks OCS non-applicable and selected default coding disables it; required OCS coding cannot be assumed")
    if case["number"] in (54, 55, 56, 57):
        planned["blockers"].append("D-03: workbook counter rollover requires clarification against the active EOL ALIVE_COUNTER selection")
    if case["number"] == 26:
        planned["blockers"].append("Export!G181/H181: thermal stimulus is -20 degC but the expected result says +20 degC")
    if case["number"] == 135:
        planned["blockers"].append("Export!H760: the source expects 61 for a 31 RoutineControl request; existing UDS routines use positive SID 71")
    context_key = None
    for source_step in case["steps"]:
        action = source_step["action"]
        expected = source_step["expected"]
        lower = action.casefold()
        step = {**source_step, "operations": [], "checks": [], "blocked": []}
        candidates = [key for key, definition in environment["canc_config"].MAH_CAN_SIGNAL_DEFS.items()
                      if re.search(rf"(?<![A-Za-z_0-9]){re.escape(definition['signal'])}(?![A-Za-z_0-9])", action, re.IGNORECASE)]
        if len(set(candidates)) == 1:
            context_key = candidates[0]
        if "normal condition" in lower or "bench to normal" in lower:
            step["operations"].append({"kind": "fault_free"})
            if "ign on" in lower or "ignition on" in lower:
                step["operations"].append({"kind": "ign_on"})
            step["operations"].append({"kind": "read_no_dtc"})
        elif lower in ("ign on", "turn ign on", "switch ign on and wait until srs1_fd_10 starts transmitting."):
            step["operations"].append({"kind": "ign_on"})
        elif lower in ("cycle ign", "perform ign off and on", "repeat the observation after one ign cycle."):
            step["operations"].append({"kind": "ign_cycle"})
        elif lower == "verify no fault is detected":
            step["operations"].append({"kind": "read_no_dtc"})
        elif "create any loop fault" in lower or "create open fault for loop0" in lower:
            step["operations"].append({"kind": "squib_open"})
        elif "make open fault to historic" in lower:
            step["operations"].append({"kind": "squib_heal"})
        elif "set not buckled" in lower or lower == "set buckled" or "set faulty stb" in lower:
            key = context_key
            aliases = environment["dcs_config"].DCSSignal
            configured_aliases = {signal_key(alias, environment): logical for logical, alias in aliases.items()}
            if key in configured_aliases:
                state = "S2B" if "stb" in lower else "unbuckle" if "not buckled" in lower else "buckle"
                step["operations"].append({"kind": "buckle", "logical": configured_aliases[key], "state": state})
            else:
                step["blocked"].append("Existing DCSSignal does not map this transmitted buckle signal to its physical input")
        elif "faulty cc" in lower:
            step["blocked"].append("DCS CrossConnect uses the same BUSS_HI_ON description as S2B; an approved cross-connect pairing is missing")
        elif "move the ecu" in lower or "rotate the ecu" in lower or "shaking ecu" in lower:
            step["blocked"].append("Physical ECU movement requires an approved actuator/operator procedure; output signals must not be simulated")
        elif "thermal chamber" in lower:
            step["blocked"].append("No existing thermal-chamber control, stabilization time or measurement tolerance is configured")
        elif "proveout" in lower or "prove out" in lower or "proving" in lower:
            step["blocked"].append("A timestamped proveout transition check and its timing tolerance are not configured for this case")
        elif "<500ms" in lower or "initialization window" in lower:
            step["blocked"].append("The initial transition needs a configured measurement window and trigger-aligned capture")
        elif "plant mode" in lower or "plantmode" in lower:
            step["blocked"].append("Phase-of-life identifiers in existing plantmode_config are marked tracker-verification pending")
        elif "crash" in lower and any(term in lower for term in ("create", "simulate", "load", "repeat", "reset the event")):
            step["blocked"].append("Approved M314 crash/rollover curves, event sequencing and observation-window evidence must be confirmed")
        elif "wakeup" in lower or "wake up" in lower or "wake up" in expected.casefold():
            step["blocked"].append("This wakeup transition needs case-specific configured stimulus and bus-sleep/observation timing")
        elif "fault" in lower and any(term in lower for term in ("create", "inject", "remove", "make", "clear")):
            step["blocked"].append("The requested fault, qualification and restoration recipe is not fully mapped in the existing case configuration")
        elif any(term in lower for term in ("set ecu", "transition ecu", "set ops", "force low", "calibration", "write routine", "hard reset", "vin mismatch", "variant code error")):
            step["blocked"].append("The requested state/routine needs verified project preconditions and an existing approved operation")
        elif lower.startswith("set ") or lower.startswith("send "):
            assignments = re.findall(r"\b([A-Za-z_][A-Za-z_0-9]*)\s*=\s*(0[xX][0-9A-Fa-f]+|\d+)\b", action)
            for name, raw in assignments:
                key = signal_key(name, environment)
                if key is None:
                    step["blocked"].append(f"No existing CAN signal definition for stimulus {name}")
                    continue
                definition = environment["canc_config"].MAH_CAN_SIGNAL_DEFS[key]
                if definition.get("ecu_generated"):
                    step["blocked"].append(f"{name} is ECU-generated; its physical input recipe is not configured")
                    continue
                try:
                    reference = expected_reference(key, int(raw, 16) if raw.lower().startswith("0x") else int(raw), environment)
                except ValueError as error:
                    step["blocked"].append(str(error))
                else:
                    step["operations"].append({"kind": "can_input", **reference})
            if not assignments:
                step["blocked"].append("This stimulus has no complete value vector and approved physical/input mapping in existing config")
        if "dlc = 64" in expected.casefold():
            step["checks"].append({"kind": "dlc", "key": "IGN_STS_SRS", "both_buses": False})
        elif "message is observed" in expected.casefold() or "message is transmitted" in expected.casefold() or "is transmitted cyclically" in expected.casefold():
            step["checks"].append({"kind": "present", "key": "IGN_STS_SRS", "both_buses": "2c0" in lower or "srs1_20" in lower})
        elif "message is not observed" in expected.casefold() or "no can signal" in expected.casefold():
            step["blocked"].append("Absence checks require state-entry and bounded silence-window configuration; a missing/stale getter is not evidence")
        assignments = re.findall(
            r"\b([A-Za-z_][A-Za-z_0-9]*)\s*(?:=+|(?:Signal\s+)?is Default\s*Value\s*=?)\s*[\"']?(0[xX][0-9A-Fa-f]+|\d+)\b",
            expected, re.IGNORECASE,
        )
        for name, raw in assignments:
            key = signal_key(name, environment)
            if key is None:
                continue
            if not environment["canc_config"].MAH_CAN_SIGNAL_DEFS[key].get("ecu_generated"):
                continue
            try:
                reference = expected_reference(key, int(raw, 16) if raw.lower().startswith("0x") else int(raw), environment)
            except ValueError as error:
                step["blocked"].append(str(error))
            else:
                step["checks"].append({"kind": "raw", "both_buses": "2c0" in lower or "srs1_20" in lower, **reference})
        if re.search(r"lamp (?:off|on)\s*=\s*([01])", expected, re.IGNORECASE):
            match = re.search(r"lamp (?:off|on)\s*=\s*([01])", expected, re.IGNORECASE)
            key = "INDC_PADL" if "PADL" in action.upper() else "INDC_SRS"
            step["checks"].append({"kind": "raw", "both_buses": "2c0" in action.casefold(),
                                   **expected_reference(key, int(match.group(1)), environment)})
        if "800ms" in expected.casefold() or "continuously" in expected.casefold() or "continously" in expected.casefold():
            step["blocked"].append("The required duration/continuity observation has no configured acceptance window and tolerance")
        if " or " in expected.casefold() and assignments:
            step["blocked"].append("Source alternatives require explicit independent vectors; checking only the first alternative would omit coverage")
        observable = expected and not step["checks"] and not step["operations"]
        if observable and not step["blocked"]:
            step["blocked"].append("The source expected observation has no complete measurable criterion in existing configuration")
        if not expected and not step["operations"] and not step["blocked"]:
            if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", action) and not lower.startswith(("verify ", "to check ", "keep ", "all other ")):
                step["blocked"].append("No verified existing operation implements this source action")
        planned["blockers"].extend(f"Export!G{step['row']}/H{step['row']}: {reason}" for reason in step["blocked"])
        planned["steps"].append(step)
    planned["blockers"] = list(dict.fromkeys(planned["blockers"]))
    planned["readiness"] = "blocked" if planned["blockers"] else "implemented-unexecuted"
    return planned


def render_script(case: dict[str, Any]) -> str:
    kinds = {operation["kind"] for step in case["steps"] for operation in step["operations"]}
    has_checks = any(step["checks"] for step in case["steps"])
    has_input_checks = any(check["kind"] in {"input_present", "input_sweep", "physical_sweep"} for step in case["steps"] for check in step["checks"])
    has_faults = bool(kinds & {"protection_fault", "signal_fault"})
    has_restoration = has_faults or "healthy_input" in kinds
    is_vcu = case.get("category") == "M314 CAN-C VCU"
    is_eps = case.get("category") == "M314 CAN-C EPS"
    is_ieb = case.get("category") == "M314 CAN-C IEB"
    single_node = is_eps or is_ieb
    has_isolation = "isolate_integrity_input" in kinds
    imports = ["import sys", "from pathlib import Path"]
    if "eps_voltage" in kinds:
        imports.append("import math")
    if is_vcu or is_eps:
        imports.append("from datetime import datetime")
    if has_checks and not is_ieb:
        imports.append("import cantools.database" if is_eps else "import cantools")
    imports.extend([
        "", "_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]",
        "if str(_FRAMEWORK_ROOT.parent) not in sys.path:",
        "    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))", "",
        "from Framework_IOEM_Py.shared_libraries.import_list import *",
        "from Framework_IOEM_Py.projects.M310_M314_M110.config import canc_config, project_config",
    ])
    if is_eps and ("eps_voltage" in kinds or any(operation.get("count_module") == "fault_list_config" for step in case["steps"] for operation in step["operations"])):
        imports.append("from Framework_IOEM_Py.projects.M310_M314_M110.config import fault_list_config")
    if "eps_voltage" in kinds:
        imports.append("from Framework_IOEM_Py.projects.M310_M314_M110.config import power_config")
    if "buckle" in kinds:
        imports.append("from Framework_IOEM_Py.projects.M310_M314_M110.config import dcs_config")
    if kinds & {"squib_open", "squib_heal"}:
        imports.append("from Framework_IOEM_Py.projects.M310_M314_M110.config import squibs_config")
    source = [
        "# Author: GitHub Copilot",
        "# GENERATED FILE - do not edit by hand.",
        f'# Rebuild with: {case.get("rebuild_command", "C:/Python3.13.0/python.exe -B tools/generate_m314_canc_13c_scripts.py")}',
        f'"""M314 {case["name"]}; Codebeamer test case {case["id"]}.',
        f'Source: {case.get("source_workbook", SOURCE_WORKBOOK.relative_to(REPOSITORY_ROOT).as_posix())} -> Export -> rows {case["rows"][0]}-{case["rows"][-1]}.',
        f'Readiness: {case["readiness"]}. Bench execution has not been performed.',
        *([f'Observation scope: {case["observation_scope"]}.'] if "observation_scope" in case else []),
        '"""', "", *imports, "", "", "def run_test():",
        f'    tc_id = {case["id"]!r}', f'    tc_name = {case["name"]!r}',
        f'    tc_desc = {case["description"]!r}', f'    tc_priority = {case["priority"]!r}',
        f'    verifies = {case["verifies"]!r}', f'    pre_action = {case["pre_action"]!r}',
        f'    post_action = {case["post_action"]!r}',
        f'    blockers = {pprint.pformat(case["blockers"], width=110, sort_dicts=True)}',
        "    if blockers:",
        '        raise RuntimeError("Evidence unavailable. Case blocked before bench initialization: " + "; ".join(blockers))',
        f'    steps = {pprint.pformat(case["steps"], width=110, sort_dicts=True)}',
        *(['    if get_active_project() != project_config.PROJECT_NAME:', '        raise RuntimeError("Active project does not match this M314 script; no bench operation was started")'] if "corrections" in case or is_vcu else []),
        "    ensure_apym_on_path()", "    if not init_aria():",
        '        raise RuntimeError("APYM/ARIA is unavailable; this is not a passing offline simulation")',
        "    aria_reports = get_reporter(strict=True)",
        "    capture_handle = None", "    report_ready = False", "    touched_inputs = set()",
        "    touched_buckles = set()", "    touched_squib = None", "    bench_prepared = False",
        *(["    voltage_restore_required = False"] if "eps_voltage" in kinds else []),
        *(["    suite_capture_handle = None"] if is_vcu or is_eps else []),
        *(["    observed_inputs = {}"] if has_input_checks else []),
        *(["    constant_inputs = {}", "    integrity_reference = {}", "    touched_dynamic = set()"] if has_isolation else []),
        *(["    touched_protection = set()"] if has_faults else []),
        *(["    restoration_counts = {}"] if has_restoration else []),
        "    try:",
        *([
            "        started = datetime.now()",
            '        day_folder = started.strftime("%Y-%m-%d")',
            '        run_stamp = started.strftime("%Y%m%d_%H%M%S_%f")',
            '        results_directory = _FRAMEWORK_ROOT / Path(project_config.TEST_RESULTS_DIR).name / project_config.PROJECT_NAME / day_folder',
            '        logs_directory = _FRAMEWORK_ROOT / Path(project_config.TEST_LOGS_DIR).name / project_config.PROJECT_NAME / day_folder',
            "        results_directory.mkdir(parents=True, exist_ok=True)",
            "        logs_directory.mkdir(parents=True, exist_ok=True)",
            '        report_path = str(results_directory / f"{Path(__file__).stem}_{run_stamp}.html")',
            '        log_path = str(logs_directory / f"{Path(__file__).stem}_{run_stamp}.txt")',
            "        report_options = get_reports_options(strict=True)()",
            "        report_options.direct_write = False",
            "        aria_reports.create(report_path, tc_desc, report_options)",
        ] if is_vcu or is_eps else [
            "        report_path, log_path = create_report_and_logging(",
            ('            Path(__file__).stem, can_ids=resolve_can_log_ids([canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]] for step in steps for operation in step["operations"] if "key" in operation]), tc_desc=tc_desc,' if single_node else "            Path(__file__).stem, can_ids=resolve_can_log_ids(), tc_desc=tc_desc,"),
            "        )",
        ]),
        "        report_ready = True",
        *([
            "        add_standard_report_info()",
            '        suite_channels = list(dict.fromkeys([canc_config.CAN_DIAG_SRS_REQ_DATA["bus"]] + [canc_config.MAH_CAN_SIGNAL_DEFS[check["key"]]["bus"] for step in steps for check in step["checks"]]))',
            ('        started_capture = CAN.StartLoggingToFile(TestCase_ID=tc_name, filepath=log_path, listOption=resolve_can_log_ids([canc_config.MAH_CAN_SIGNAL_DEFS[check["key"]] for step in steps for check in step["checks"]]), channel_names=suite_channels, log_all_available_buses=False)' if is_eps else '        started_capture = CAN.StartLoggingToFile(TestCase_ID=tc_name, filepath=log_path, listOption=resolve_can_log_ids(), channel_names=suite_channels, log_all_available_buses=False)'),
            "        if started_capture is None or isinstance(started_capture, (str, Exception)):",
            '            raise RuntimeError(f"Case-wide capture start failed: {started_capture}")',
            "        suite_capture_handle = started_capture",
        ] if is_vcu or is_eps else []),
        '        aria_reports.add_report_info("#Test Case ID:", tc_id)',
        '        aria_reports.add_report_info("#Test Case Name:", tc_name)',
        f'        aria_reports.add_report_info("#Test Case Category:", {json.dumps(case.get("category", "M314 CAN-C 13C"))})',
        '        aria_reports.add_report_info("#Priority:", tc_priority)',
        '        aria_reports.add_report_info("#Verifies:", verifies)',
        '        aria_reports.add_report_info("#Pre-Action:", pre_action)',
        '        aria_reports.add_report_info("#Post-Action:", post_action)',
        '        aria_reports.add_report_info("#Source:", __doc__)',
        '        aria_reports.add_report_info("#Project:", project_config.PROJECT_NAME)',
        '        aria_reports.add_report_info("#Report file:", report_path)',
        *([f'        aria_reports.add_report_info("#Observation scope:", {case["observation_scope"]!r})'] if "observation_scope" in case else []),
        *([f'        aria_reports.add_report_info("#Approved source corrections:", {chr(10).join(case["corrections"])!r})'] if "corrections" in case else []),
    ]
    if has_checks and not is_ieb:
        paths = [path.relative_to(REPOSITORY_ROOT).as_posix() for path in DBC_FILES]
        source.extend([
            '        channel_map = canc_config.CAN_CRASH_FRAME_CHANNEL_MAP[project_config.ACTIVE_CAN_VARIANT]',
            f"        dbc_paths = {paths!r}",
            "        databases = [cantools.database.load_file(str(_FRAMEWORK_ROOT / path), strict=False) for path in dbc_paths]",
            "        messages = {message.name: message for database in databases for message in database.messages}",
        ])
    source.extend([
        "        for step_number, step in enumerate(steps, start=1):",
        '            RESULT.InsertComment(f"Step {step_number} [Export!G{step[\'row\']}/H{step[\'row\']}]: {step[\'action\']}")',
        '            if step["expected"]:', '                RESULT.InsertComment("Expected: " + step["expected"])',
        *(['            if step.get("correction"):', '                RESULT.InsertComment("Approved source correction: " + step["correction"])'] if "corrections" in case else []),
        '            if step["blocked"]:', '                raise RuntimeError("; ".join(step["blocked"]))',
        '            for operation in step["operations"]:', '                kind = operation["kind"]',
    ])
    branches = []
    if "fault_free" in kinds:
        branches.append(("fault_free", ["bench_prepared = True", *(["voltage_restore_required = True", "PS.SetVoltage(power_config.NOMINAL_VOLTAGE)"] if "eps_voltage" in kinds else []), *(["read_software_version()", "fault_free_profile()"] if is_vcu else ["fault_free_profile()", "read_software_version()"]), "Wait(max(canc_config.NM_IGN_ON_STARTUP_DELAY_MS, PROVEOUT_COMPLETION_TIME))" if is_ieb else "Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)"]))
    if "eps_voltage" in kinds:
        branches.append(("eps_voltage", [
            'voltage_restore_required = True',
            'voltage = power_config.NOMINAL_VOLTAGE if operation["level"] == "nominal" else fault_list_config.EPS_VOLTAGE_TEST_LEVELS[operation["level"]]',
            'PS.SetVoltage(voltage)',
            'RESULT.InsertComment(f"Requested supply voltage: {voltage:g} V")',
            'if operation["level"] == "nominal":',
            '    Wait(getattr(canc_config, operation["restart_delay"]))',
            'else:',
            '    code = Over_Voltage if operation["level"] == "over_voltage" else Under_Voltage',
            '    expected_record = hex_to_bytes(code) + hex_to_bytes(DTC_status["DTC_historic"])',
            '    expected_text = " ".join(f"0x{value:02X}" for value in expected_record)',
            '    observed_ms = faultTimeMeasurement(expected_text)',
            '    if observed_ms is None:',
            '        raise TimeoutError(f"Voltage DTC was not observed: {expected_text}")',
            '    RESULT.LogAction("Observed voltage DTC after (ms)", observed_ms)',
            'feedback = PS.GetVoltageBattery()',
            'if not isinstance(feedback, (list, tuple)) or len(feedback) < 2 or feedback[0] != "0000":',
            '    raise RuntimeError(f"Voltage feedback failed: {feedback}")',
            'measured_voltage = feedback[1]',
            'if type(measured_voltage) not in (int, float) or not math.isfinite(measured_voltage):',
            '    raise RuntimeError(f"Voltage feedback is not a finite number: {feedback}")',
            'voltage_valid = (power_config.UNDERVOLTAGE_THRESHOLD < measured_voltage < power_config.OVERVOLTAGE_THRESHOLD if operation["level"] == "nominal" else measured_voltage < power_config.UNDERVOLTAGE_THRESHOLD if operation["level"] == "under_voltage" else measured_voltage > power_config.OVERVOLTAGE_THRESHOLD)',
            'RESULT.LogCustomAction("Measured supply-voltage state", expected_result=f"{operation[\'level\']} (requested {voltage:g} V)", obtained_result=f"{measured_voltage:g} V", res=voltage_valid)',
            'if not voltage_valid:',
            '    raise RuntimeError(f"Voltage stimulus verification failed: {feedback}")',
        ]))
    if "ign_on" in kinds:
        branches.append(("ign_on", ["PS.IGN_ON()", "Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)"]))
    if "ign_cycle" in kinds:
        branches.append(("ign_cycle", ["PS.IGN_OFF()", "Wait(project_config.RESET_WAIT_TIME * 1000)", "PS.IGN_ON()", "Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)"]))
    if "read_no_dtc" in kinds:
        branches.append(("read_no_dtc", [
            ('response = CAN.SendDiagByValuesNoLog(channel_name=canc_config.CAN_DIAG_SRS_REQ_DATA["bus"], data=Read_DTC_Req_CANC)' if "corrections" in case or is_vcu else "response = CAN.SendDiagByValuesNoLog(data=Read_DTC_Req_CANC)"),
            "if isinstance(response, Exception):", "    raise response",
            "obtained = hex_to_bytes(response)", "expected = hex_to_bytes(Read_DTC_Resp_CANC)",
            'RESULT.InterpretEqualResult("Fault-free CAN-C DTC response", obtained.hex(" "), expected.hex(" "))',
            "if obtained != expected:",
            '    raise AssertionError("Fault-free precondition failed: DTC records or an invalid diagnostic response are present")',
        ]))
    if "can_input" in kinds:
        branches.append(("can_input", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'if definition["ecu_generated"]:', '    raise RuntimeError("Refusing to simulate an ECU-generated output")',
            'value = definition[operation["field"]]', 'if operation["label"] is not None:', '    value = value[operation["label"]]',
            'touched_inputs.add(operation["key"])',
            'response = CAN.ChangeSignalValue(frame_name=definition["frame"], signal_name=definition["signal"], value=str(value))',
            "if response is not None:", "    raise RuntimeError(str(response))",
            'Wait(definition["periodicity"] + canc_config.NM_IGN_ON_STARTUP_DELAY_MS)',
        ]))
    if "enable_input" in kinds:
        branches.append(("enable_input", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'if definition["ecu_generated"]:',
            '    raise RuntimeError("Refusing to simulate an ECU-generated output")',
            'touched_inputs.add(operation["key"])',
            'response = CAN.PeriodicEnableFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Simulation Started on {definition[\'frame\']}":',
            '    raise RuntimeError(f"Input enable failed: {response}")',
        ]))
    if "healthy_input" in kinds:
        branches.append(("healthy_input", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'touched_inputs.add(operation["key"])',
            'for protection_signal in canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["message_content_failure_dtcs"]:',
            '    response = CAN.DynamicEnableSignal(channel=definition["bus"], CAN_FrameName=definition["frame"], CAN_SignalName=protection_signal)',
            '    if response is not None and response is not True:',
            '        raise RuntimeError(f"Healthy protection setup failed: {response}")',
            'response = CAN.ReloadDefaultPeriodicFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Default periodic frame \'{definition[\'frame\']}\' reloaded successfully.":',
            '    raise RuntimeError(f"Healthy frame reload failed: {response}")',
            'response = CAN.PeriodicEnableFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Simulation Started on {definition[\'frame\']}":',
            '    raise RuntimeError(f"Healthy frame enable failed: {response}")',
            'settling_count = max(canc_config.NODE_ABSENT_DETECTION_COUNT, canc_config.MESSAGE_TIMEOUT_DETECTION_COUNT, canc_config.MESSAGE_CONTENT_DETECTION_COUNT, canc_config.SIGNAL_CONTENT_DETECTION_COUNT)',
            'Wait(settling_count * definition["periodicity"] * (1 + canc_config.CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))',
        ]))
    if has_isolation:
        branches.append(("isolate_integrity_input", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'protection_signals = set(canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["message_content_failure_dtcs"])',
            'restoration_counts[operation["key"]] = canc_config.MESSAGE_CONTENT_RECOVERY_COUNT',
            'for other in canc_config.MAH_CAN_SIGNAL_DEFS.values():',
            '    if other["frame"] != definition["frame"] or other["signal"] == definition["signal"] or other["signal"] in protection_signals:',
            '        continue',
            '    target = (other["bus"], other["frame"], other["signal"])',
            '    if target in touched_dynamic:',
            '        continue',
            '    touched_dynamic.add(target)',
            '    response = CAN.DynamicDisableSignal(channel=other["bus"], CAN_FrameName=other["frame"], CAN_SignalName=other["signal"])',
            '    if response is not None and response is not True:',
            '        raise RuntimeError(f"Application-field isolation failed: {response}")',
        ]))
    if "protection_fault" in kinds:
        branches.append(("protection_fault", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'touched_inputs.add(operation["key"])', 'touched_protection.add(operation["key"])',
            'restoration_counts[operation["key"]] = canc_config.MESSAGE_CONTENT_RECOVERY_COUNT',
            'response = CAN.DynamicDisableSignal(channel=definition["bus"], CAN_FrameName=definition["frame"], CAN_SignalName=definition["signal"])',
            'if response is not None and response is not True:',
            '    raise RuntimeError(f"Protection freeze failed: {response}")',
        ]))
    if "node_fault" in kinds:
        branches.append(("node_fault", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'touched_inputs.add(operation["key"])',
            'restoration_counts[operation["key"]] = canc_config.NODE_ABSENT_RECOVERY_COUNT',
            'response = CAN.PeriodicDisableFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Simulation Stopped on {definition[\'frame\']}":',
            '    raise RuntimeError(f"Node-absence stimulus failed: {response}")',
        ]))
    if "restore_node" in kinds:
        branches.append(("restore_node", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'response = CAN.PeriodicEnableFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Simulation Started on {definition[\'frame\']}":',
            '    raise RuntimeError(f"Node-absence recovery failed: {response}")',
        ]))
    if "dlc_fault" in kinds:
        branches.append(("dlc_fault", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'touched_inputs.add(operation["key"])',
            'restoration_counts[operation["key"]] = canc_config.MESSAGE_CONTENT_RECOVERY_COUNT',
            'visible = CAN.ReceiveFrame(channel=definition["bus"], signalName=definition["frame"])',
            'payload = getattr(visible, "payload", None)',
            'if payload is None or len(payload) != definition["dlc"]:',
            '    raise RuntimeError("D-04: a fresh healthy payload is required before shortening the frame")',
            'short_length = canfd_dlc_to_length(canfd_length_to_dlc(definition["dlc"]) - 1)',
            'response = CAN.SetPeriodicFrame(channel_name=definition["bus"], frame_name=definition["frame"], frame_id=definition["frame_ID"], periodicity=definition["periodicity"], payload=bytes(payload[:short_length]), is_fd=definition["is_fd"])',
            'if response is not None:',
            '    raise RuntimeError(f"D-04: wrong-length stimulus failed: {response}")',
        ]))
    if "restore_frame" in kinds:
        branches.append(("restore_frame", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'response = CAN.ReloadDefaultPeriodicFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Default periodic frame \'{definition[\'frame\']}\' reloaded successfully.":',
            '    raise RuntimeError(f"Healthy-length restoration failed: {response}")',
            'response = CAN.PeriodicEnableFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
            'if response != f"Simulation Started on {definition[\'frame\']}":',
            '    raise RuntimeError(f"Restored frame enable failed: {response}")',
        ]))
    if "restore_protection" in kinds:
        branches.append(("restore_protection", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'response = CAN.DynamicEnableSignal(channel=definition["bus"], CAN_FrameName=definition["frame"], CAN_SignalName=definition["signal"])',
            'if response is not None and response is not True:',
            '    raise RuntimeError(f"Protection restore failed: {response}")',
        ]))
    if "signal_fault" in kinds:
        branches.append(("signal_fault", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'touched_inputs.add(operation["key"])',
            'restoration_counts[operation["key"]] = canc_config.SIGNAL_CONTENT_RECOVERY_COUNT',
            'response = CAN.ChangeSignalValue(channel_name=definition["bus"], frame_name=definition["frame"], signal_name=definition["signal"], value=str(definition["Invalid_Value"]))',
            'if response is not None:', '    raise RuntimeError(f"Signal fault injection failed: {response}")',
        ]))
    if "restore_signal" in kinds:
        branches.append(("restore_signal", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            ('response = CAN.ChangeSignalValue(channel_name=definition["bus"], frame_name=definition["frame"], signal_name=definition["signal"], value=str(definition[operation.get("field", "SCF_Recovery_Value")]))' if is_ieb else 'response = CAN.ChangeSignalValue(channel_name=definition["bus"], frame_name=definition["frame"], signal_name=definition["signal"], value=str(definition["SCF_Recovery_Value"]))'),
            'if response is not None:', '    raise RuntimeError(f"Signal recovery stimulus failed: {response}")',
        ]))
    if "wait_fault" in kinds:
        branches.append(("wait_fault", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'duration = getattr(canc_config, operation["count"]) * definition["periodicity"]',
            'Wait(duration * (1 + canc_config.CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))',
        ]))
    if "read_fault_dtc" in kinds:
        branches.append(("read_fault_dtc", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'if operation["catalog"] == "CAN_MESSAGE_CONTENT_FAILURE_DTC":',
            '    candidates = canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["message_content_failure_dtcs"]',
            '    dtc_code = candidates.get(definition["signal"])',
            '    if dtc_code is None:',
            '        unique_codes = set(candidates.values())',
            '        if len(unique_codes) != 1:',
            '            raise RuntimeError("Frame does not resolve one unambiguous content-failure DTC")',
            '        dtc_code = unique_codes.pop()',
                *(['elif operation["catalog"] == "CAN_NODE_ABSENT_DTC":',
                    '    dtc_code = canc_config.CAN_NODE_ABSENT_DTC[canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["key_node"]]'] if single_node else []),
                'else:',
            '    dtc_code = getattr(canc_config, operation["catalog"])[definition["signal"]]',
            'code_bytes = hex_to_bytes(dtc_code)',
            'response = CAN.SendDiagByValuesNoLog(channel_name=canc_config.CAN_DIAG_SRS_REQ_DATA["bus"], data=Read_DTC_Req_CANC)',
            'if isinstance(response, Exception):', '    raise response',
            'obtained = hex_to_bytes(response)',
            'header = hex_to_bytes(Read_DTC_Resp_CANC)',
            'record_size = len(code_bytes) + len(hex_to_bytes(DTC_status["DTC_active_WLOFF"]))',
            'payload = obtained[len(header):]',
            'if obtained[:len(header)] != header or len(payload) % record_size:',
            '    raise RuntimeError(f"Invalid or truncated DTC response: {response}")',
            'records = {payload[offset:offset + len(code_bytes)]: payload[offset + len(code_bytes):offset + record_size] for offset in range(0, len(payload), record_size)}',
            'if len(records) * record_size != len(payload):',
            '    raise RuntimeError("Ambiguous duplicate DTC records")',
            'actual = records.get(code_bytes)',
            'if operation["status"] is None:',
            '    expected = "Absent"',
            '    actual_text = "Absent" if actual is None else (code_bytes + actual).hex(" ").upper()',
            'else:',
            '    expected_bytes = hex_to_bytes(DTC_status[operation["status"]])',
            '    expected = (code_bytes + expected_bytes).hex(" ").upper()',
            '    actual_text = "Not present" if actual is None else (code_bytes + actual).hex(" ").upper()',
            'RESULT.InterpretEqualResult(f"{definition[\'frame\']}.{definition[\'signal\']} {operation[\'status\'] or \'no collateral content fault\'}", actual_text, expected)',
            'if actual_text != expected:',
            '    raise AssertionError(f"DTC state mismatch: expected {expected}, observed {actual_text}")',
            'if operation["status"] is not None and set(records) != {code_bytes}:',
            '    raise AssertionError(f"Unexpected additional DTCs during the isolated fault: {response}")',
            'if operation.get("remaining_statuses"):',
            '    remaining_code = hex_to_bytes(canc_config.CAN_SIGNAL_CONTENT_FAILURE_DTC[definition["signal"]])',
            '    remaining_statuses = {hex_to_bytes(DTC_status[name]) for name in operation["remaining_statuses"]}',
            '    remaining_valid = set(records) == {remaining_code} and records[remaining_code] in remaining_statuses',
            '    RESULT.InterpretEqualResult(f"Complete remaining signal-fault state {operation[\'remaining_statuses\']}; observed {response}", remaining_valid, True)',
            '    if not remaining_valid:',
            '        raise AssertionError(f"Unexpected remaining DTC state after signal recovery: {response}")',
        ]))
    if kinds & {"eps_dtc_states", "priority_dtc_states"}:
        branches.append(("priority_dtc_states" if is_ieb else "eps_dtc_states", [
            'definition = canc_config.MAH_CAN_SIGNAL_DEFS[operation["key"]]',
            'response = CAN.SendDiagByValuesNoLog(channel_name=canc_config.CAN_DIAG_SRS_REQ_DATA["bus"], data=Read_DTC_Req_CANC)',
            'if not isinstance(response, str):',
            ('    raise RuntimeError(f"IEB diagnostic read failed: {response}")' if is_ieb else '    raise RuntimeError(f"EPS diagnostic read failed: {response}")'),
            'obtained = hex_to_bytes(response)',
            'header = hex_to_bytes(Read_DTC_Resp_CANC)',
            'if obtained[:len(header)] != header or (len(obtained) - len(header)) % 4:',
            ('    raise RuntimeError(f"Invalid or truncated IEB DTC response: {response}")' if is_ieb else '    raise RuntimeError(f"Invalid or truncated EPS DTC response: {response}")'),
            'records = [obtained[offset:offset + 4] for offset in range(len(header), len(obtained), 4)]',
            'if len({record[:3] for record in records}) != len(records):',
            '    raise RuntimeError("Ambiguous duplicate EPS DTC records")',
            'if operation.get("observe"):',
            '    RESULT.LogAction("Observed DTCs before the priority IGN cycle", response)',
            '    continue',
            'expected_records = []',
            ('states = {**operation["states"], **operation.get("optional_states", {})}' if is_eps else 'states = operation["states"]'),
            'for fault_kind, status_key in states.items():',
            '    if fault_kind == "node":',
            '        code = canc_config.CAN_NODE_ABSENT_DTC[canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["key_node"]]',
            '    elif fault_kind == "content":',
            '        candidates = set(canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["message_content_failure_dtcs"].values())',
            '        if len(candidates) != 1:',
            ('            raise RuntimeError("IEB content DTC is ambiguous")' if is_ieb else '            raise RuntimeError("EPS content DTC is ambiguous")'),
            '        code = candidates.pop()',
            '    elif fault_kind == "signal":',
            ('        code = canc_config.CAN_SIGNAL_CONTENT_FAILURE_DTC[definition["signal"]]' if is_ieb else '        code = canc_config.CAN_SIGNAL_CONTENT_FAILURE_DTC[canc_config.CAN_ABSOLUTE_ANGLE["signal"]]'),
                *(['    elif fault_kind in ("over_voltage", "under_voltage"):',
                    '        code = Over_Voltage if fault_kind == "over_voltage" else Under_Voltage'] if is_eps else []),
            '    else:',
            ('        raise RuntimeError(f"Unsupported IEB DTC kind: {fault_kind}")' if is_ieb else '        raise RuntimeError(f"Unsupported EPS DTC kind: {fault_kind}")'),
                *(['    if fault_kind in operation.get("optional_states", {}) and not any(record[:3] == hex_to_bytes(code) for record in records):',
                    '        continue'] if is_eps else []),
            '    if status_key is not None:',
            '        expected_records.append(hex_to_bytes(code) + hex_to_bytes(DTC_status[status_key]))',
            'expected = "; ".join(record.hex(" ").upper() for record in sorted(expected_records)) or "No DTC records"',
            'actual = "; ".join(record.hex(" ").upper() for record in sorted(records)) or "No DTC records"',
            ('RESULT.InterpretEqualResult("IEB diagnostic state snapshot", actual, expected)' if is_ieb else 'RESULT.InterpretEqualResult("EPS diagnostic state snapshot", actual, expected)'),
            'if sorted(records) != sorted(expected_records):',
            ('    raise AssertionError(f"IEB DTC state mismatch: expected {expected}, observed {actual}")' if is_ieb else '    raise AssertionError(f"EPS DTC state mismatch: expected {expected}, observed {actual}")'),
        ]))
    if "buckle" in kinds:
        branches.append(("buckle", [
            'logical = operation["logical"]', "touched_buckles.add(logical)",
            'response = SLS.SendRequest(dcs_config.DCSName[logical], dcs_config.DCS_Fault_Description[operation["state"]])',
            'if not isinstance(response, str) or not response.endswith(" set OK."):', "    raise RuntimeError(str(response))",
            'Wait(dcs_config.DCS_fault_time["Qualification"])',
        ]))
    if kinds & {"squib_open", "squib_heal"}:
        branches.append(("squib_open" if "squib_open" in kinds else "squib_heal", [
            'squib_name = min(squibs_config.ActiveSquibName, key=squibs_config.SquibNumber.__getitem__)',
            "touched_squib = squib_name",
            'device = f"LOOP{squibs_config.SquibNumber[squib_name]}"',
            'fault = "Open" if kind == "squib_open" else "NoFault"',
            'response = SQUIB.SetRelay(device, squibs_config.Squib_Fault_Description[fault])',
            'if response != "0000":', "    raise RuntimeError(str(response))",
            'timing = "Qualification_Time" if fault == "Open" else "Dequalification_Time"',
            "Wait(squibs_config.squib_fault_time[timing])",
            'if fault == "Open":',
            '    dtc_bytes = hex_to_bytes(squibs_config.DTC_Squib_FaultCode[squib_name] + " " + squibs_config.Squib_FaultTypeCode["Open"])',
            '    dtc_result = CAN.CheckSingleDTC(code=int.from_bytes(dtc_bytes, byteorder="big"), expectedStatus=DTC_status["DTC_active"])',
            '    if not isinstance(dtc_result, (list, tuple)) or dtc_result[0] != "0000":',
            '        raise AssertionError(f"Open-loop DTC was not qualified: {dtc_result}")',
            '    RESULT.InterpretEqualResult("Open-loop active DTC", dtc_result[0], "0000")',
        ]))
        if kinds >= {"squib_open", "squib_heal"}:
            branches.append(("squib_heal", branches[-1][1]))
    for index, (kind, lines) in enumerate(branches):
        source.append(f'                {"if" if index == 0 else "elif"} kind == {kind!r}:')
        source.extend("                    " + line for line in lines)
    source.extend([
        f'                {"else" if branches else "if True"}:',
        '                    raise RuntimeError(f"Unsupported operation: {kind}")',
    ])
    if has_checks:
        source.extend([
            '            for check in step["checks"]:',
            '                definition = canc_config.MAH_CAN_SIGNAL_DEFS[check["key"]]',
        ])
        if has_input_checks:
            source.extend([
                '                if check["kind"] == "physical_sweep":',
                '                    observations = observed_inputs.get(check["key"], [])',
                '                    if len(observations) != len(definition["TestCase_values"]):',
                '                        raise AssertionError("Physical-value check lacks the complete raw capture vector")',
                '                    for raw_value, decoded_values in observations:',
                '                        expected = raw_to_physical(raw_value, scaling=definition["Factor"], offset=definition["Offset"], bits=definition["bit_length"], signed=definition["Signed"])',
                '                        obtained = [decoded["physical"] for decoded in decoded_values]',
                '                        RESULT.InterpretEqualResult(f"{definition[\'frame\']}.{definition[\'signal\']} physical at raw {raw_value}", obtained, [expected] * len(obtained))',
                '                        if not obtained or any(value != expected for value in obtained):',
                '                            raise AssertionError(f"Physical decoding mismatch: expected {expected}, observed {obtained}")',
                '                    continue',
                '                if check["kind"] in {"input_present", "input_sweep"}:',
                *(['                    message = messages[definition["frame"]]', '                    dbc_signal = message.get_signal_by_name(definition["signal"])'] if not is_ieb else []),
                *(['                    expected_length = canfd_dlc_to_length(canfd_length_to_dlc(definition["dlc"]) - 1) if check.get("expected_length") == "short" else definition["dlc"]'] if is_ieb else ['                    expected_length = canfd_dlc_to_length(canfd_length_to_dlc(definition["dlc"]) - 1) if check.get("expected_length") == "short" else message.length'] if is_eps else []),
                *([
                    '                    if definition["ecu_generated"] or "start_bit" not in definition:',
                    '                        raise RuntimeError("Configured IEB input layout is unavailable or ECU-generated")',
                ] if is_ieb else [
                '                    if definition["ecu_generated"] or message.frame_id != definition["frame_ID"] or message.length != definition["dlc"] or message.cycle_time != definition["periodicity"]:',
                '                        raise RuntimeError("Existing VCU input configuration disagrees with its native M314 DBC")',
                '                    if (dbc_signal.scale, dbc_signal.offset, dbc_signal.length, dbc_signal.is_signed, dbc_signal.byte_order) != (definition["Factor"], definition["Offset"], definition["bit_length"], definition["Signed"], definition["byte_order"]):',
                '                        raise RuntimeError("Existing VCU signal encoding disagrees with its native M314 DBC")',
                ]),
                '                    vectors = definition["TestCase_values"] if check["kind"] == "input_sweep" else [None]',
                '                    if not vectors:',
                '                        raise RuntimeError("No existing configured VCU raw-value vector")',
                '                    for vector_number, raw_value in enumerate(vectors, start=1):',
                '                        if raw_value is not None:',
                '                            touched_inputs.add(check["key"])',
                '                            response = CAN.ChangeSignalValue(channel_name=definition["bus"], frame_name=definition["frame"], signal_name=definition["signal"], value=str(raw_value))',
                '                            if response is not None:',
                '                                raise RuntimeError(f"Raw-value stimulus failed: {response}")',
                '                            Wait(definition["periodicity"])',
                ('                        capture_path = Path(log_path).with_name(f"{Path(log_path).stem}_step_{step_number}_{definition[\'frame\']}_{definition[\'signal\']}_vector_{vector_number}.txt")' if case.get("category") == "M314 CAN-C FR_ZONE" else '                        capture_path = Path(log_path).with_name(f"{Path(log_path).stem}_step_{step_number}_vector_{vector_number}.txt")'),
                ('                        capture_handle = CAN.StartLoggingToFile(TestCase_ID=f"{tc_name}.{step_number}.{vector_number}", filepath=str(capture_path), listOption=[definition["frame_ID"]], channel_names=[definition["bus"]], log_all_available_buses=False)' if is_ieb else '                        capture_handle = CAN.StartLoggingToFile(TestCase_ID=f"{tc_name}.{step_number}.{vector_number}", filepath=str(capture_path), listOption=[message.frame_id], channel_names=[definition["bus"]], log_all_available_buses=False)'),
                '                        if capture_handle is None or isinstance(capture_handle, (str, Exception)):',
                '                            raise RuntimeError(f"Input capture start failed: {capture_handle}")',
                *([
                    '                        capture_window_ms = canc_config.NM_IGN_ON_STARTUP_DELAY_MS + 3 * definition["periodicity"]',
                    '                        Wait(capture_window_ms)',
                ] if is_vcu or single_node else ['                        Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)']),
                '                        stopped = CAN.StopLoggingToFile(capture_handle)',
                '                        if not isinstance(stopped, (list, tuple)) or not stopped or stopped[0] != "0000":',
                '                            raise RuntimeError(f"Input capture stop failed: {stopped}")',
                '                        capture_handle = None',
                '                        captured = CAN.ReadFromCanLogFile(str(capture_path))',
                '                        if not isinstance(captured, (list, tuple)) or len(captured) < 2 or captured[0] != "0000":',
                '                            raise RuntimeError(f"Input capture read failed: {captured}")',
                ('                        frames = [frame for frame in captured[1] if getattr(frame, "id", None) == definition["frame_ID"]]' if is_ieb else '                        frames = [frame for frame in captured[1] if getattr(frame, "id", None) == message.frame_id]'),
                '                        if len(frames) < 2:',
                '                            raise AssertionError("At least two fresh VCU TX frames are required to verify the configured cycle time")',
                '                        for frame in frames:',
                '                            direction = getattr(frame, "direction", None)',
                '                            if getattr(direction, "name", str(direction)).casefold() != "tx":',
                '                                raise AssertionError("VCU input verification requires simulated TX frames, not unrelated RX traffic")',
                ('                            if len(frame.payload) != expected_length:' if single_node else '                            if len(frame.payload) != message.length:'),
                '                                raise AssertionError("VCU captured payload length differs from the native M314 DBC")',
                *([
                    '                        timestamps: list[int] = []',
                    '                        for frame in frames:',
                    '                            timestamp = getattr(frame, "timestamp", None)',
                    '                            if not isinstance(timestamp, int) or isinstance(timestamp, bool) or timestamp < 0:',
                    '                                raise AssertionError("APYM microsecond timestamps are absent, invalid or not strictly increasing")',
                    '                            timestamps.append(timestamp)',
                    '                        if not timestamp_is_monotonic(timestamps, strict=True):',
                    '                            raise AssertionError("APYM microsecond timestamps are absent, invalid or not strictly increasing")',
                ] if single_node else [
                '                        timestamps = [getattr(frame, "timestamp", None) for frame in frames]',
                '                        if any(not isinstance(value, int) or isinstance(value, bool) or value < 0 for value in timestamps) or not timestamp_is_monotonic(timestamps, strict=True):',
                '                            raise AssertionError("APYM microsecond timestamps are absent, invalid or not strictly increasing")',
                ]),
                '                        periods = [us_to_ms(later - earlier) for earlier, later in zip(timestamps, timestamps[1:])]',
                '                        tolerance = canc_config.CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100',
                '                        lower = definition["periodicity"] * (1 - tolerance)',
                '                        upper = definition["periodicity"] * (1 + tolerance)',
                *([
                    '                        minimum_count = max(2, int(capture_window_ms / upper) - 1)',
                    '                        if len(frames) < minimum_count or us_to_ms(timestamps[-1] - timestamps[0]) < capture_window_ms - 2 * upper:',
                    '                            raise AssertionError("Sparse VCU burst does not cover the configured observation window")',
                ] if is_vcu or single_node else []),
                '                        RESULT.InterpretEqualResultRange(f"{definition[\'frame\']} TX cycle time (ms)", periods, lower, upper)',
                '                        if any(not lower <= period <= upper for period in periods):',
                '                            raise AssertionError(f"VCU cycle time outside {lower}..{upper} ms: {periods}")',
                *([
                    '                        observed_span = us_to_ms(timestamps[-1] - timestamps[0])',
                    '                        required_span = max(upper, canc_config.NM_IGN_ON_STARTUP_DELAY_MS - 2 * upper)',
                    '                        RESULT.InterpretEqualResultRange(f"{definition[\'frame\']} capture coverage (ms)", observed_span, required_span, canc_config.NM_IGN_ON_STARTUP_DELAY_MS + 2 * upper)',
                    '                        if not required_span <= observed_span <= canc_config.NM_IGN_ON_STARTUP_DELAY_MS + 2 * upper:',
                    '                            raise AssertionError(f"Insufficient or stale capture coverage: observed {observed_span} ms, required {required_span} ms in the configured window")',
                ] if case.get("category") == "M314 CAN-C FR_ZONE" else []),
                '                        RESULT.InterpretEqualResult(f"{definition[\'frame\']} fresh simulated input communication", bool(frames), True)',
                *([
                    '                        if check.get("preserve_signal_fault"):',
                    ('                            retained = [decode_can_signal(frame.payload, dbc_signal.start, dbc_signal.length, byteorder="little" if dbc_signal.byte_order == "little_endian" else "big")["raw"] for frame in frames]' if is_eps else '                            retained = [decode_can_signal(frame.payload, definition["start_bit"], definition["bit_length"], byteorder="little" if definition["byte_order"] == "little_endian" else "big")["raw"] for frame in frames]'),
                    '                            RESULT.InterpretEqualResult("Lower-priority invalid signal survives wrong DLC", retained, [definition["Invalid_Value"]] * len(retained))',
                    '                            if any(value != definition["Invalid_Value"] for value in retained):',
                    '                                raise AssertionError("DLC priority stimulus removed the lower-priority signal fault")',
                ] if single_node else []),
                *([
                    '                        protection_signals = set(canc_config.CAN_TX_MESSAGE_CONFIG[definition["frame"]]["message_content_failure_dtcs"])',
                    '                        for other in canc_config.MAH_CAN_SIGNAL_DEFS.values():',
                    '                            if other["frame"] != definition["frame"] or other["signal"] == definition["signal"] or other["signal"] in protection_signals:',
                    '                                continue',
                    '                            values = [decode_can_signal(frame.payload, other["start_bit"], other["bit_length"], byteorder="little" if other["byte_order"] == "little_endian" else "big")["raw"] for frame in frames]',
                    '                            constant_inputs.setdefault(other["signal"], values[0])',
                    '                            expected_raw = constant_inputs[other["signal"]]',
                    '                            RESULT.InterpretEqualResult(f"Other application field {other[\'signal\']} remains constant", values, [expected_raw] * len(values))',
                    '                            if any(value != expected_raw for value in values):',
                    '                                raise AssertionError(f"Other application field {other[\'signal\']} changed during isolation")',
                    '                        crc_signal = next(signal for signal in protection_signals if "CRC" in signal)',
                    '                        counter_signal = next(signal for signal in protection_signals if "CRC" not in signal)',
                    '                        crc_definition = next(item for item in canc_config.MAH_CAN_SIGNAL_DEFS.values() if item["frame"] == definition["frame"] and item["signal"] == crc_signal)',
                    '                        counter_definition = next(item for item in canc_config.MAH_CAN_SIGNAL_DEFS.values() if item["frame"] == definition["frame"] and item["signal"] == counter_signal)',
                    '                        counter_values = [extract_counter(frame.payload, counter_definition["start_bit"], counter_definition["bit_length"], byteorder="little" if counter_definition["byte_order"] == "little_endian" else "big") for frame in frames]',
                    '                        if len(set(counter_values)) < 2:',
                    '                            raise AssertionError("Protection counter is not running during integrity isolation")',
                    '                        field_values = [decode_can_signal(frame.payload, definition["start_bit"], definition["bit_length"], byteorder="little" if definition["byte_order"] == "little_endian" else "big")["raw"] for frame in frames]',
                    '                        if raw_value is not None and any(value != raw_value for value in field_values):',
                    '                            raise AssertionError(f"Raw decoding mismatch: expected {raw_value}, observed {field_values}")',
                    '                        matched = 0',
                    '                        for frame, counter, field_raw in zip(frames, counter_values, field_values):',
                    '                            crc = decode_can_signal(frame.payload, crc_definition["start_bit"], crc_definition["bit_length"], byteorder="little" if crc_definition["byte_order"] == "little_endian" else "big")["raw"]',
                    '                            previous = integrity_reference.get(counter)',
                    '                            if previous is None:',
                    '                                integrity_reference[counter] = (field_raw, crc)',
                    '                            elif previous[0] != field_raw:',
                    '                                matched += 1',
                    '                                if previous[1] != crc:',
                    '                                    RESULT.ExpectTestResult("CRC changes with excluded field at a matching counter", crc, previous[1], TestStatus.Failed)',
                    '                                    raise AssertionError("CRC depends on freshness/MAC despite matching counter and other fields")',
                    '                        if raw_value is not None and any(previous[0] != raw_value for previous in integrity_reference.values()) and not matched:',
                    '                            raise AssertionError("Evidence unavailable. No matching counter reference proves CRC exclusion")',
                    '                        RESULT.InterpretEqualResult("Matching-counter CRC exclusion comparisons", matched, matched if raw_value is None else max(1, matched) if any(previous[0] != raw_value for previous in integrity_reference.values()) else matched)',
                    '                        operation = {"key": check["key"], "catalog": "CAN_MESSAGE_CONTENT_FAILURE_DTC", "status": None}',
                    *("                        " + line for line in dict(branches)["read_fault_dtc"]),
                ] if has_isolation else []),
                '                        if raw_value is not None:',
                ('                            decoded_values = [decode_can_signal(frame.payload, definition["start_bit"], definition["bit_length"], factor=definition["Factor"], offset=definition["Offset"], signed=definition["Signed"], byteorder="little" if definition["byte_order"] == "little_endian" else "big") for frame in frames]' if is_ieb else '                            decoded_values = [decode_can_signal(frame.payload, dbc_signal.start, dbc_signal.length, factor=dbc_signal.scale, offset=dbc_signal.offset, signed=dbc_signal.is_signed, byteorder="little" if dbc_signal.byte_order == "little_endian" else "big") for frame in frames]'),
                ('                            obtained = [sign_extend(decoded["raw"], definition["bit_length"]) if definition["Signed"] else decoded["raw"] for decoded in decoded_values]' if is_eps else '                            obtained = [decoded["raw"] for decoded in decoded_values]'),
                '                            RESULT.InterpretEqualResult(f"{definition[\'frame\']}.{definition[\'signal\']} raw", obtained, [raw_value] * len(obtained))',
                '                            if any(value != raw_value for value in obtained):',
                '                                raise AssertionError(f"Raw decoding mismatch: expected {raw_value}, observed {obtained}")',
                '                            observed_inputs.setdefault(check["key"], []).append((raw_value, decoded_values))',
                '                    continue',
            ])
        source.extend([
            '                variants = [(definition["frame"], definition["signal"])]',
            '                if check["both_buses"]:',
            '                    hscan = canc_config.CAN_HSCAN_SIGNAL_Rx_MAP.get(check["key"])',
            "                    if hscan is None:", '                        raise RuntimeError("Requested second-bus signal has no existing mapping")',
            "                    variants.append(hscan)",
            "                for frame_name, signal_name in variants:",
            "                    message = messages[frame_name]",
            "                    dbc_signal = message.get_signal_by_name(signal_name)",
            '                    if frame_name == definition["frame"] and message.frame_id != definition["frame_ID"]:',
            '                        raise RuntimeError("Existing config frame ID disagrees with the native M314 DBC")',
            '                    capture_path = Path(log_path).with_name(f"{Path(log_path).stem}_step_{step_number}_{signal_name}_{frame_name}.txt")',
            "                    capture_handle = CAN.StartLoggingToFile(",
            '                        TestCase_ID=f"{tc_name}.{step_number}.{signal_name}.{frame_name}",',
            "                        filepath=str(capture_path), listOption=[message.frame_id],",
            "                        channel_names=[channel_map[frame_name]], log_all_available_buses=False,",
            "                    )",
            "                    if capture_handle is None or isinstance(capture_handle, (str, Exception)):",
            "                        raise RuntimeError(str(capture_handle))",
            "                    Wait(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)",
            "                    stopped = CAN.StopLoggingToFile(capture_handle)",
            '                    if not isinstance(stopped, (list, tuple)) or stopped[0] != "0000":',
            "                        raise RuntimeError(str(stopped))",
            "                    capture_handle = None",
            "                    captured = CAN.ReadFromCanLogFile(str(capture_path))",
            '                    if not isinstance(captured, (list, tuple)) or captured[0] != "0000":',
            "                        raise RuntimeError(str(captured))",
            '                    frames = [frame for frame in captured[1] if getattr(frame, "id", None) == message.frame_id]',
            "                    if not frames:", '                        raise AssertionError(f"No fresh {frame_name} frame in the isolated capture")',
            "                    for frame in frames:",
            '                        direction = getattr(frame, "direction", None)',
            '                        direction_name = getattr(direction, "name", str(direction)).casefold()',
            '                        if direction_name != "rx":',
            '                            raise RuntimeError("Receive direction is unverified; simulated/TX frames cannot pass this check")',
            '                        if len(frame.payload) != message.length:',
            '                            raise AssertionError(f"{frame_name}: captured length differs from the native DBC")',
            '                    if check["kind"] == "present":',
            '                        RESULT.InterpretEqualResult(f"{frame_name} fresh RX communication", bool(frames), True)',
            '                    elif check["kind"] == "dlc":',
            "                        if len(frames) < 2:", '                            raise AssertionError("Several consecutive frames are required for the DLC check")',
            '                        RESULT.InterpretEqualResult(f"{frame_name} payload length", [len(frame.payload) for frame in frames], [message.length] * len(frames))',
            "                    else:",
            '                        expected = definition[check["field"]]',
            '                        if check["label"] is not None:', '                            expected = expected[check["label"]]',
            "                        values = [decode_can_signal(",
            "                            frame.payload, dbc_signal.start, dbc_signal.length,",
            "                            factor=dbc_signal.scale, offset=dbc_signal.offset, signed=dbc_signal.is_signed,",
            '                            byteorder="little" if dbc_signal.byte_order == "little_endian" else "big",',
            '                        )["raw"] for frame in frames]',
            '                        RESULT.InterpretEqualResult(f"{frame_name}.{signal_name}", values, [expected] * len(values))',
            "                        if any(value != expected for value in values):",
            '                            raise AssertionError(f"{frame_name}.{signal_name}: expected {expected}, observed {values}")',
        ] if not is_ieb else [])
    if (is_vcu or (is_eps and case["number"] in (22, 23))) and "read_no_dtc" in kinds:
        source.append("            if step_number == len(steps):")
        source.append('                RESULT.InsertComment("Verify no DTC qualified during the final observation before cleanup")')
        source.extend("                " + line for line in dict(branches)["read_no_dtc"])
    source.extend([
        "    except Exception as error:", "        if report_ready:",
        '            RESULT.ExpectTestResult("Case execution failed", str(error), "All source steps verified", TestStatus.Failed)',
        "        raise", "    finally:", "        if report_ready:", "            cleanup_errors = []", "            try:",
        "                if capture_handle is not None:", "                    try:",
        "                        stopped = CAN.StopLoggingToFile(capture_handle)",
        '                        if not isinstance(stopped, (list, tuple)) or not stopped or stopped[0] != "0000":',
        '                            cleanup_errors.append(f"Capture stop failed: {stopped}")',
        "                    except Exception as error:", '                        cleanup_errors.append(f"Capture stop failed: {error}")',
    ])
    if "eps_voltage" in kinds:
        source.extend([
            "                if voltage_restore_required:", "                    try:",
            "                        PS.SetVoltage(power_config.NOMINAL_VOLTAGE)",
            "                        Wait(max(canc_config.NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS, canc_config.NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS))",
            "                        feedback = PS.GetVoltageBattery()",
            '                        restored = isinstance(feedback, (list, tuple)) and len(feedback) > 1 and feedback[0] == "0000" and type(feedback[1]) in (int, float) and power_config.UNDERVOLTAGE_THRESHOLD < feedback[1] < power_config.OVERVOLTAGE_THRESHOLD',
            '                        RESULT.LogCustomAction("Supply-voltage restoration", expected_result="Measured healthy voltage range", obtained_result=str(feedback), res=restored)',
            '                        if not restored:',
            '                            cleanup_errors.append(f"Voltage restoration is not confirmed: {feedback}")',
            "                    except Exception as error:",
            '                        cleanup_errors.append(f"Voltage restoration failed: {error}")',
        ])
    if has_faults:
        source.extend([
            "                for key in sorted(touched_protection):", "                    try:",
            "                        definition = canc_config.MAH_CAN_SIGNAL_DEFS[key]",
            '                        response = CAN.DynamicEnableSignal(channel=definition["bus"], CAN_FrameName=definition["frame"], CAN_SignalName=definition["signal"])',
            '                        if response is not None and response is not True:',
            '                            cleanup_errors.append(f"Protection cleanup failed for {key}: {response}")',
            "                    except Exception as error:", '                        cleanup_errors.append(f"Protection cleanup failed for {key}: {error}")',
        ])
    if has_isolation:
        source.extend([
            "                for channel, frame_name, signal_name in sorted(touched_dynamic):",
            "                    try:",
            '                        response = CAN.DynamicEnableSignal(channel=channel, CAN_FrameName=frame_name, CAN_SignalName=signal_name)',
            '                        if response is not None and response is not True:',
            '                            cleanup_errors.append(f"Application-field restore failed for {signal_name}: {response}")',
            "                    except Exception as error:",
            '                        cleanup_errors.append(f"Application-field restore failed for {signal_name}: {error}")',
        ])
    if kinds & {"can_input", "enable_input"}:
        source.extend([
            "                for key in sorted(touched_inputs):", "                    try:",
            "                        definition = canc_config.MAH_CAN_SIGNAL_DEFS[key]",
            ('                        response = CAN.ReloadDefaultPeriodicFrame(channel_name=definition["bus"], frame_name=definition["frame"])' if "enable_input" in kinds else '                        response = CAN.ReloadDefaultPeriodicFrame(frame_name=definition["frame"])'),
            ('                        if response != f"Default periodic frame \'{definition[\'frame\']}\' reloaded successfully.":' if "corrections" in case else '                        if not isinstance(response, str) or response.startswith("Error"):'),
            '                            cleanup_errors.append(f"Input restore failed for {key}: {response}")',
            "                    except Exception as error:", '                        cleanup_errors.append(f"Input restore failed for {key}: {error}")',
        ])
        if has_restoration:
            source.extend([
                "                    try:",
                '                        definition = canc_config.MAH_CAN_SIGNAL_DEFS[key]',
                '                        response = CAN.PeriodicEnableFrame(channel_name=definition["bus"], frame_name=definition["frame"])',
                '                        if response != f"Simulation Started on {definition[\'frame\']}":',
                '                            cleanup_errors.append(f"Frame cleanup failed for {key}: {response}")',
                '                        if key in restoration_counts:',
                '                            Wait(restoration_counts[key] * definition["periodicity"] * (1 + canc_config.CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))',
                '                    except Exception as error:',
                '                        cleanup_errors.append(f"Frame cleanup failed for {key}: {error}")',
            ])
    if "buckle" in kinds:
        source.extend([
            "                for logical in sorted(touched_buckles):", "                    try:",
            '                        response = SLS.SendRequest(dcs_config.DCSName[logical], dcs_config.DCS_Fault_Description["unbuckle"])',
            '                        if not isinstance(response, str) or not response.endswith(" set OK."):',
            '                            cleanup_errors.append(f"Buckle restore failed for {logical}: {response}")',
            "                    except Exception as error:", '                        cleanup_errors.append(f"Buckle restore failed for {logical}: {error}")',
            '                if touched_buckles:', '                    try:',
            '                        Wait(dcs_config.DCS_fault_time["Dequalification"])',
            '                    except Exception as error:', '                        cleanup_errors.append(f"Buckle recovery wait failed: {error}")',
        ])
    if kinds & {"squib_open", "squib_heal"}:
        source.extend([
            "                if touched_squib is not None:", "                    try:",
            '                        response = SQUIB.SetRelay(f"LOOP{squibs_config.SquibNumber[touched_squib]}", squibs_config.Squib_Fault_Description["NoFault"])',
            '                        if response != "0000":', '                            cleanup_errors.append(f"Squib restore failed: {response}")',
            '                        Wait(squibs_config.squib_fault_time["Dequalification_Time"])',
            '                    except Exception as error:', '                        cleanup_errors.append(f"Squib restore failed: {error}")',
        ])
    source.extend([
        "                if bench_prepared:", "                    try:", "                        Clear_DTC_Info()",
        "                    except Exception as error:", '                        cleanup_errors.append(f"DTC cleanup failed: {error}")',
        "                    try:", "                        PS.IGN_ON()",
        "                    except Exception as error:", '                        cleanup_errors.append(f"Power restore failed: {error}")',
        *([
            "                if suite_capture_handle is not None:",
            "                    try:",
            "                        stopped = CAN.StopLoggingToFile(suite_capture_handle)",
            '                        if not isinstance(stopped, (list, tuple)) or not stopped or stopped[0] != "0000":',
            '                            cleanup_errors.append(f"Case-wide capture stop failed: {stopped}")',
            "                    except Exception as error:",
            '                        cleanup_errors.append(f"Case-wide capture stop failed: {error}")',
        ] if is_vcu or is_eps else []),
        "                if cleanup_errors:",
        '                    RESULT.ExpectTestResult("Cleanup failed", "; ".join(cleanup_errors), "All touched inputs restored", TestStatus.Failed)',
        '                    raise RuntimeError("Cleanup failed: " + "; ".join(cleanup_errors))',
        "            finally:", "                aria_reports.write_to_file()", "",
        "", 'if __name__ == "__main__":', "    run_test()", "",
    ])
    return "\n".join(source).encode("ascii", errors="backslashreplace").decode("ascii")


def validate_rendered(name: str, source: str) -> None:
    tree = ast.parse(source, filename=name)
    functions = [node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    if functions != ["run_test"]:
        raise ValueError(f"{name}: expected exactly one run_test() and no helpers, got {functions}")
    compile(source, name, "exec")
    checker = runpy.run_path(str(REPOSITORY_ROOT / ".github" / "hooks" / "scripts" / "validate_script.py"))
    findings = checker["check_text"](
        f"projects/M310_M314_M110/modules/CANC/scripts/{name}", source,
    )
    if findings:
        raise ValueError(f"{name}: convention findings: {findings}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--inspect", action="store_true")
    modes.add_argument("--validate", action="store_true")
    modes.add_argument("--check", action="store_true")
    parser.add_argument("--family", choices=("13C", "VCU", "FR_ZONE", "EPS", "IEB"), default="13C")
    parser.add_argument("--case", type=int, nargs="+")
    arguments = parser.parse_args()
    source_workbook = SOURCE_WORKBOOK if arguments.family == "13C" else SOURCE_WORKBOOK.with_name(f"{arguments.family}_Node_TestCases.xlsx")
    artifact_directory = ARTIFACT_DIRECTORY if arguments.family == "13C" else ARTIFACT_DIRECTORY.with_name(f"m314-canc-{arguments.family.lower().replace('_', '-')}")
    cases, evidence = read_cases(source_workbook, case_name_pattern=rf"CANC_{arguments.family}_TestCase_?(\d+)")
    if arguments.inspect:
        print("COMPLETE_WORKBOOK:", evidence)
        print("CASES:", len(cases), "STEPS:", evidence["steps"])
        print("CASE_NUMBERS:", [case["number"] for case in cases])
        print("OFFLINE_ONLY: no shared-library import and no bench execution")
        return 0
    environment = load_environment()
    selected = [case for case in cases if not arguments.case or case["number"] in arguments.case]
    if arguments.case and len(selected) != len(set(arguments.case)):
        raise ValueError("One or more requested case numbers do not exist in the source workbook")
    if not arguments.validate and not arguments.check and not (artifact_directory / "README.md").is_file():
        raise ValueError("The retained artifact folder requires a README before generating outputs")
    manifest = []
    for case in selected:
        planned = plan_case(case, environment)
        name = f"SUBS_CANC_{arguments.family}_TestCase_{case['number']}.py"
        source = render_script(planned)
        validate_rendered(name, source)
        path = SCRIPT_DIRECTORY / name
        if arguments.check:
            if not path.is_file() or path.read_text(encoding="utf-8") != source:
                raise ValueError(f"Generated source differs or is missing: {path}")
        elif not arguments.validate:
            if path.exists() and path.read_text(encoding="utf-8").splitlines()[:3] != source.splitlines()[:3]:
                raise ValueError(f"Refusing to overwrite an existing unrelated script: {path}")
            path.write_text(source, encoding="utf-8", newline="\n")
        manifest.append({
            "case_number": case["number"], "case_id": case["id"], "name": case["name"],
            "script": path.relative_to(REPOSITORY_ROOT).as_posix(), "source_rows": case["rows"],
            "step_count": len(case["steps"]), "verifies": case["verifies"],
            "readiness": planned["readiness"], "blockers": planned["blockers"],
            "requirement_evidence": planned["requirement_evidence"],
            **({"corrections": planned["corrections"], "observation_scope": planned["observation_scope"]} if "corrections" in planned else {}),
        })
    if not arguments.validate and not arguments.check:
        (artifact_directory / "coverage.json").write_text(
            json.dumps({
                "extraction": evidence, "requirement_source": environment["requirement_evidence"],
                "cases": manifest, "bench_executed": False,
                **({"requirement_coverage_scope": "Supplied case objectives only. Approved source links are retained, but complete linked-requirement verification is not claimed; ECU storage, last-valid and on-fail values require independent ECU-observable evidence."} if arguments.family == "IEB" else {}),
                "location_exception": (
                    "User approved scoped M314 CANC IEB script creation and absolutely required missing "
                    "IEB start-bit metadata through the existing config builder; existing values and shared "
                    "libraries unchanged. Scripts use config only, without parser or Excel/DBC inputs."
                    if arguments.family == "IEB" else
                    "User approved EPS script additions in M314 CANC and only absolutely necessary existing "
                    "configuration/authoring/test changes; shared libraries and source workbooks unchanged; no bench execution."
                    if arguments.family == "EPS" else
                    "User approved only new M314 CANC scripts in this session; existing project/config/shared files unchanged"
                ),
            }, indent=2) + "\n",
            encoding="utf-8",
        )
    print("VALIDATED_SCRIPTS", len(manifest), "READINESS", dict(Counter(item["readiness"] for item in manifest)))
    print("ALL_SELECTED_SOURCE_STEPS_RETAINED", sum(item["step_count"] for item in manifest), "NO_BENCH_EXECUTION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())