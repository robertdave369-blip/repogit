# M314 CAN-C Legacy Tools (archived, do not run)

These tools came from an older copy of the framework (October 2026). They are kept
unchanged for reference only. Current tools replaced them, and those tools write the same
script folders, so running an archived tool would overwrite the current scripts.

| Archived tool | Replaced by |
| --- | --- |
| `generate_m314_canc_13c_scripts.py` (13C, VCU, FR_ZONE, IEB, EPS families) | [`tools/generate_canc_scripts.py`](../../generate_canc_scripts.py), which writes every M310_M314_M110 CANC script from the ten workbooks in `project_testcases/m310_m314_m110/CANC/CANC`, plus `CANC_SCRIPT_GAPS.md` and the two runners |
| `m314-canc-signal-suite/` (2C0 and HPCAD generators, `run_canc_signal_suite.py`) | the same generator, and `run_all_canc_automatic_scripts.py` / `run_all_canc_non_automatic_scripts.py` in the CANC scripts folder |
| `run_m314_fault_list_canc.py` (six Fault_List CAN timing scripts) | [`tools/generate_m310_fault_list_scripts.py`](../../generate_m310_fault_list_scripts.py) and the `run_fault_list_suite.py` it writes |
| `build_m314_canc_alignment.py` (the `--pure` builder, 1040 lines) | [`tools/build_m314_canc_alignment.py`](../../build_m314_canc_alignment.py). Corrections to `canc_config` go in its hand-maintained blocks |

The archived `build_m314_canc_alignment.py` is the `--pure` variant, which the current
alignment builder does not have. It still uses the old `EDR_CANC_TestCase_<element>_values`
keys rather than the common `TestCase_<n>_*` names, so it is not a drop-in replacement.

They cannot reach the project folders from here: each resolves the repository root as
`Path(__file__).parents[1]` (or `[2]` in `m314-canc-signal-suite/`), and from this folder
that is `tools/archive`. They also refer to tests, artifacts and documents under `tests/`
and `docs/improvements/` that are not in this repository. Their history is in
[`tools/logbook/2026-10.md`](../../logbook/2026-10.md).
