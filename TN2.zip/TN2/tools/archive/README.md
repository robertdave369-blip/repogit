# Archived Tools

Tools kept for reference after something else replaced them. Nothing here is part of the
normal tool path, and nothing here should be run. Each subfolder's README says what replaced
it and why it is kept.

| Folder | Contents |
| --- | --- |
| [`m314_canc_legacy/`](m314_canc_legacy/README.md) | M314 CAN-C generators, signal suite, Fault_List CAN runner and `--pure` alignment builder from the older framework copy |
