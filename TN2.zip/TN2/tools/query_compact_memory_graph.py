"""Query the compact architectural memory graph without loading raw source code.

The query result contains matching repository/module/file/symbol nodes, compact
structural relationships, and source references. Callers can then load only the
recommended source files if implementation detail is truly needed.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_GRAPH_PATH = REPO_ROOT / "graphify-out" / "compact-memory" / "memory-graph.json"


def _read_graph(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Memory graph must contain a JSON object.")
    return payload


def _terms(query: str) -> list[str]:
    return [term.lower() for term in re.findall(r"[A-Za-z0-9_]+", query) if len(term) >= 2]


def _file_search_text(file: dict[str, Any]) -> str:
    symbols = " ".join(symbol.get("name", "") for symbol in file.get("symbols", []) if isinstance(symbol, dict))
    relationships = " ".join(relationship.get("target", "") for relationship in file.get("relationships", []) if isinstance(relationship, dict))
    return " ".join(
        [
            str(file.get("path", "")),
            str(file.get("module", "")),
            str(file.get("purpose", "")),
            " ".join(file.get("exports", [])),
            " ".join(file.get("depends_on", [])),
            symbols,
            relationships,
        ]
    ).lower()


def _score(query: str, terms: list[str], haystack: str) -> int:
    score = 0
    lowered_query = query.lower().strip()
    if lowered_query and lowered_query in haystack:
        score += 8
    for term in terms:
        occurrences = haystack.count(term)
        if occurrences:
            score += min(4, occurrences)
    return score


def _file_result(file: dict[str, Any], score: int) -> dict[str, Any]:
    return {
        "type": "file",
        "id": file["id"],
        "path": file["path"],
        "purpose": file["purpose"],
        "module": file["module"],
        "priority": file["priority"],
        "exports": file.get("exports", []),
        "symbols": file.get("symbols", []),
        "source_reference": file["source_reference"],
        "score": score,
    }


def query_memory_graph(graph_path: str | Path, query: str, limit: int = 8, depth: int = 1) -> dict[str, Any]:
    path = Path(graph_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    if limit < 1 or depth < 0:
        raise ValueError("limit must be positive and depth must be zero or greater.")
    graph = _read_graph(path)
    terms = _terms(query)
    file_matches = []
    for file in graph.get("files", []):
        if not isinstance(file, dict):
            continue
        score = _score(query, terms, _file_search_text(file))
        if score:
            file_matches.append(_file_result(file, score))
    file_matches.sort(key=lambda item: (-item["score"], item["path"]))
    matches = file_matches[:limit]

    selected_ids = {item["id"] for item in matches}
    edges = [edge for edge in graph.get("graph", {}).get("edges", []) if isinstance(edge, dict)]
    nodes = {node.get("id"): node for node in graph.get("graph", {}).get("nodes", []) if isinstance(node, dict) and node.get("id")}
    related: dict[str, dict[str, Any]] = {}
    frontier = set(selected_ids)
    for _ in range(depth):
        next_frontier: set[str] = set()
        for edge in edges:
            source = edge.get("source")
            target = edge.get("target")
            if source not in frontier and target not in frontier:
                continue
            neighbor = target if source in frontier else source
            if neighbor not in selected_ids and neighbor in nodes:
                related[neighbor] = {
                    "id": neighbor,
                    "label": nodes[neighbor].get("label"),
                    "type": nodes[neighbor].get("type"),
                    "relation": edge.get("relation"),
                    "confidence": edge.get("confidence"),
                    "source_location": edge.get("source_location"),
                }
                next_frontier.add(neighbor)
        frontier = next_frontier

    source_paths = []
    for match in matches:
        source_paths.append(match["source_reference"])
    module_paths: dict[str, list[str]] = defaultdict(list)
    for module in graph.get("modules", []):
        if isinstance(module, dict):
            module_paths[str(module.get("id"))] = list(module.get("source_paths", []))
    for match in matches:
        for module_path in module_paths.get(match["module"], [])[:3]:
            reference = {"path": module_path, "location": "L1"}
            if reference not in source_paths:
                source_paths.append(reference)

    return {
        "query": query,
        "terms": terms,
        "repository": graph.get("repository", {}),
        "matches": matches,
        "related_nodes": list(related.values())[: max(limit * 3, 12)],
        "recommended_source_references": source_paths[: max(limit * 2, 12)],
        "retrieval_policy": [
            "Use this compact graph result first.",
            "Load only recommended source references when implementation detail is needed.",
            "The graph stores structural evidence, not behavioral proof or raw code.",
        ],
        "raw_code_returned": False,
    }


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Query a compact Graphify AST memory graph.")
    parser.add_argument("query", help="Architecture, module, file, symbol, or dependency terms")
    parser.add_argument("--graph", default=str(DEFAULT_GRAPH_PATH), help="Path to memory-graph.json")
    parser.add_argument("--limit", type=int, default=8, help="Maximum matching file records")
    parser.add_argument("--depth", type=int, default=1, help="Structural neighbor traversal depth")
    return parser


def main() -> int:
    args = build_argument_parser().parse_args()
    result = query_memory_graph(args.graph, args.query, limit=args.limit, depth=args.depth)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())