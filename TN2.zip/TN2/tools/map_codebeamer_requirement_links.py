"""Map offline Codebeamer exports without rewriting unrelated Excel content."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import re
import runpy
import xml.etree.ElementTree as ET
import xml.parsers.expat
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils.cell import coordinate_from_string


REFERENCE_CELL = re.compile(r"\[ISSUE:[1-9]\d*\]-null(?:,\n\[ISSUE:[1-9]\d*\]-null)*\Z")
MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
OFFICE_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"


@dataclass
class XmlSpan:
    name: str
    attributes: dict[str, str]
    start: int
    opening_end: int
    closing_start: int = 0
    end: int = 0
    empty: bool = False


def tag_end(data: bytes, start: int) -> int:
    quote = None
    for offset in range(start, len(data)):
        value = data[offset]
        if quote is not None:
            if value == quote:
                quote = None
        elif value in (34, 39):
            quote = value
        elif value == 62:
            return offset + 1
    raise ValueError("Unterminated XML tag")


def xml_spans(data: bytes, selected: set[str]) -> list[XmlSpan]:
    parser = xml.parsers.expat.ParserCreate()
    stack: list[XmlSpan] = []
    result = []

    def start_element(name: str, attributes: dict[str, str]) -> None:
        offset = parser.CurrentByteIndex
        opening_end = tag_end(data, offset)
        span = XmlSpan(name, attributes, offset, opening_end, empty=data[offset:opening_end].rstrip().endswith(b"/>"))
        stack.append(span)
        if name.rsplit(":", 1)[-1] in selected:
            result.append(span)

    def end_element(name: str) -> None:
        span = stack.pop()
        if name != span.name:
            raise ValueError("XML element stack mismatch")
        span.closing_start = span.opening_end if span.empty else parser.CurrentByteIndex
        span.end = span.opening_end if span.empty else tag_end(data, parser.CurrentByteIndex)

    parser.StartElementHandler = start_element
    parser.EndElementHandler = end_element
    parser.Parse(data, True)
    return result


def replace_spans(data: bytes, changes: list[tuple[int, int, bytes]]) -> bytes:
    ordered = sorted(changes, reverse=True)
    boundary = len(data)
    for start, end, replacement in ordered:
        if end > boundary or start > end:
            raise ValueError("Overlapping XML changes")
        data = data[:start] + replacement + data[end:]
        boundary = start
    return data


def append_xml_child(data: bytes, parent_name: str, child: bytes) -> bytes:
    parents = xml_spans(data, {parent_name})
    if len(parents) != 1 or parents[0].empty:
        raise ValueError(f"Missing or empty XML registration container: {parent_name}")
    offset = parents[0].closing_start
    return data[:offset] + child + data[offset:]


def inline_cell(coordinate: str, value: str, original: XmlSpan | None = None) -> bytes:
    attributes = dict(original.attributes) if original else {"r": coordinate}
    attributes["t"] = "inlineStr"
    name = original.name if original else "c"
    prefix = name.rsplit(":", 1)[0] + ":" if ":" in name else ""
    cell = ET.Element(name, attributes)
    text = ET.SubElement(ET.SubElement(cell, prefix + "is"), prefix + "t", {"{http://www.w3.org/XML/1998/namespace}space": "preserve"})
    text.text = value
    return ET.tostring(cell, encoding="utf-8", short_empty_elements=False)


def column_number(coordinate: str) -> int:
    match = re.match(r"([A-Z]+)\d+\Z", coordinate)
    if not match:
        raise ValueError(f"Invalid cell coordinate: {coordinate}")
    result = 0
    for letter in match.group(1):
        result = result * 26 + ord(letter) - ord("A") + 1
    return result


def patch_verifies(data: bytes, values: dict[str, str]) -> bytes:
    spans = xml_spans(data, {"c", "row"})
    cells = {span.attributes["r"]: span for span in spans if span.name.rsplit(":", 1)[-1] == "c"}
    rows = {int(span.attributes["r"]): span for span in spans if span.name.rsplit(":", 1)[-1] == "row"}
    changes = []
    for coordinate, value in values.items():
        original = cells.get(coordinate)
        if original:
            changes.append((original.start, original.end, inline_cell(coordinate, value, original)))
        else:
            number = coordinate_from_string(coordinate)[1]
            row = rows[number]
            later = [span for reference, span in cells.items() if coordinate_from_string(reference)[1] == number and column_number(reference) > column_number(coordinate)]
            offset = min(span.start for span in later) if later else row.closing_start
            prefix = row.name.rsplit(":", 1)[0] + ":" if ":" in row.name else ""
            empty_original = XmlSpan(prefix + "c", {"r": coordinate}, 0, 0)
            changes.append((offset, offset, inline_cell(coordinate, value, empty_original)))
    return replace_spans(data, changes)


def new_unmapped_sheet(records: list[dict]) -> bytes:
    ET.register_namespace("", MAIN_NS)
    sheet = ET.Element(f"{{{MAIN_NS}}}worksheet")
    last_row = len(records) + 1
    ET.SubElement(sheet, f"{{{MAIN_NS}}}dimension", {"ref": f"A1:D{last_row}"})
    views = ET.SubElement(sheet, f"{{{MAIN_NS}}}sheetViews")
    view = ET.SubElement(views, f"{{{MAIN_NS}}}sheetView", {"workbookViewId": "0"})
    ET.SubElement(view, f"{{{MAIN_NS}}}pane", {"ySplit": "1", "topLeftCell": "A2", "activePane": "bottomLeft", "state": "frozen"})
    ET.SubElement(sheet, f"{{{MAIN_NS}}}sheetFormatPr", {"defaultRowHeight": "15"})
    columns = ET.SubElement(sheet, f"{{{MAIN_NS}}}cols")
    for index, width in enumerate((20, 65, 24, 120), 1):
        ET.SubElement(columns, f"{{{MAIN_NS}}}col", {"min": str(index), "max": str(index), "width": str(width), "customWidth": "1"})
    data = ET.SubElement(sheet, f"{{{MAIN_NS}}}sheetData")
    values = [["Requirement ID", "Requirement Name", "Requirement Tracker", "Reason"]]
    values.extend([[record["id"], record["name"], record["tracker"], record["reason"]] for record in records])
    for number, fields in enumerate(values, 1):
        row = ET.SubElement(data, f"{{{MAIN_NS}}}row", {"r": str(number)})
        for column, value in zip("ABCD", fields):
            cell = ET.SubElement(row, f"{{{MAIN_NS}}}c", {"r": f"{column}{number}", "t": "inlineStr"})
            text = ET.SubElement(ET.SubElement(cell, f"{{{MAIN_NS}}}is"), f"{{{MAIN_NS}}}t", {"{http://www.w3.org/XML/1998/namespace}space": "preserve"})
            text.text = str(value)
    ET.SubElement(sheet, f"{{{MAIN_NS}}}autoFilter", {"ref": f"A1:D{last_row}"})
    return ET.tostring(sheet, encoding="utf-8", xml_declaration=True)


def package_sheet_path(archive: zipfile.ZipFile, name: str) -> str:
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    sheets = workbook.findall(f"{{{MAIN_NS}}}sheets/{{{MAIN_NS}}}sheet")
    sheet = next(element for element in sheets if element.attrib["name"] == name)
    identifier = sheet.attrib[f"{{{OFFICE_REL_NS}}}id"]
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    target = next(element.attrib["Target"] for element in relationships if element.attrib["Id"] == identifier)
    return target.lstrip("/") if target.startswith("/") else "xl/" + target


def write_workbook(original: Path, output: Path, plan: dict) -> dict:
    if output.resolve() == original.resolve():
        raise ValueError("Refusing to overwrite the original workbook")
    with zipfile.ZipFile(original) as source:
        workbook_data = source.read("xl/workbook.xml")
        workbook = ET.fromstring(workbook_data)
        sheets = workbook.findall(f"{{{MAIN_NS}}}sheets/{{{MAIN_NS}}}sheet")
        if any(element.attrib["name"] == plan["unmapped_sheet"] for element in sheets):
            raise ValueError("Original already contains Unmapped_Requirements")
        sheet_numbers = []
        for name in source.namelist():
            match = re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", name)
            if match:
                sheet_numbers.append(int(match.group(1)))
        sheet_number = max(sheet_numbers) + 1
        new_sheet_path = f"xl/worksheets/sheet{sheet_number}.xml"
        new_sheet_id = max(int(element.attrib["sheetId"]) for element in sheets) + 1
        rel_data = source.read("xl/_rels/workbook.xml.rels")
        relationships = ET.fromstring(rel_data)
        used_ids = {element.attrib["Id"] for element in relationships}
        rel_number = 1
        while f"rId{rel_number}" in used_ids:
            rel_number += 1
        new_rel_id = f"rId{rel_number}"
        registration = f'<sheet xmlns="{MAIN_NS}" xmlns:r="{OFFICE_REL_NS}" name="{plan["unmapped_sheet"]}" sheetId="{new_sheet_id}" r:id="{new_rel_id}"/>'.encode()
        relation = f'<Relationship xmlns="{PACKAGE_REL_NS}" Type="{OFFICE_REL_NS}/worksheet" Target="worksheets/sheet{sheet_number}.xml" Id="{new_rel_id}"/>'.encode()
        content = f'<Override xmlns="{CONTENT_NS}" PartName="/{new_sheet_path}" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'.encode()
        export_path = package_sheet_path(source, "Export")
        changes = {
            export_path: patch_verifies(source.read(export_path), {mapping["verifies_cell"]: mapping["value"] for mapping in plan["mappings"]}),
            "xl/workbook.xml": append_xml_child(workbook_data, "sheets", registration),
            "xl/_rels/workbook.xml.rels": append_xml_child(rel_data, "Relationships", relation),
            "[Content_Types].xml": append_xml_child(source.read("[Content_Types].xml"), "Types", content),
        }
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as destination:
            destination.comment = source.comment
            for entry in source.infolist():
                destination.writestr(entry, changes.get(entry.filename, source.read(entry.filename)))
            new_entry = zipfile.ZipInfo(new_sheet_path, date_time=(1980, 1, 1, 0, 0, 0))
            new_entry.compress_type = zipfile.ZIP_DEFLATED
            destination.writestr(new_entry, new_unmapped_sheet(plan["unmapped_requirements"]))
    return {"export_path": export_path, "new_sheet_path": new_sheet_path, "new_rel_id": new_rel_id, "changed_parts": list(changes)}


def validate_workbook(original: Path, output: Path, plan: dict, registration: dict) -> dict:
    allowed_cells = {mapping["verifies_cell"]: mapping for mapping in plan["mappings"]}
    with zipfile.ZipFile(original) as source, zipfile.ZipFile(output) as destination:
        if destination.testzip() is not None:
            raise ValueError("Output ZIP integrity check failed")
        if set(destination.namelist()) != set(source.namelist()) | {registration["new_sheet_path"]}:
            raise ValueError("Unexpected package additions or removals")
        unchanged = []
        for entry in source.infolist():
            original_data = source.read(entry.filename)
            output_data = destination.read(entry.filename)
            if entry.filename not in registration["changed_parts"]:
                if output_data != original_data:
                    raise ValueError(f"Unrelated package part changed: {entry.filename}")
                unchanged.append(entry.filename)
                continue
            if entry.filename == registration["export_path"]:
                original_cells = {span.attributes["r"]: span for span in xml_spans(original_data, {"c"})}
                changes = []
                for span in xml_spans(output_data, {"c"}):
                    coordinate = span.attributes["r"]
                    if coordinate in allowed_cells:
                        old = original_cells.get(coordinate)
                        replacement = original_data[old.start:old.end] if old else b""
                        changes.append((span.start, span.end, replacement))
            else:
                local_name, attribute, expected = {
                    "xl/workbook.xml": ("sheet", "name", plan["unmapped_sheet"]),
                    "xl/_rels/workbook.xml.rels": ("Relationship", "Id", registration["new_rel_id"]),
                    "[Content_Types].xml": ("Override", "PartName", "/" + registration["new_sheet_path"]),
                }[entry.filename]
                matches = [span for span in xml_spans(output_data, {local_name}) if span.attributes.get(attribute) == expected]
                if len(matches) != 1:
                    raise ValueError(f"New sheet registration is ambiguous: {entry.filename}")
                changes = [(matches[0].start, matches[0].end, b"")]
            if replace_spans(output_data, changes) != original_data:
                raise ValueError(f"Change extends outside permitted XML nodes: {entry.filename}")
    source_workbook = load_workbook(original, data_only=False)
    output_workbook = load_workbook(output, data_only=False)
    checked_cells = 0
    non_primary_rows = 0
    formula_count = 0
    actual_ids = set()
    if output_workbook.sheetnames != source_workbook.sheetnames + [plan["unmapped_sheet"]]:
        raise ValueError("Original sheet order or names changed")
    for source_sheet in source_workbook:
        output_sheet = output_workbook[source_sheet.title]
        if source_sheet.sheet_state != output_sheet.sheet_state:
            raise ValueError(f"Sheet visibility changed: {source_sheet.title}")
        if str(source_sheet.merged_cells) != str(output_sheet.merged_cells):
            raise ValueError(f"Merged cells changed: {source_sheet.title}")
        for row in source_sheet.iter_rows():
            for cell in row:
                checked_cells += 1
                counterpart = output_sheet[cell.coordinate]
                if cell.has_style != counterpart.has_style or cell._style != counterpart._style:
                    raise ValueError(f"Cell formatting changed: {source_sheet.title}!{cell.coordinate}")
                if cell.data_type == "f":
                    formula_count += 1
                mapping = allowed_cells.get(cell.coordinate) if source_sheet.title == "Export" else None
                if mapping:
                    if cell.data_type == "f":
                        raise ValueError(f"A mapped Verifies cell contains an original formula: {cell.coordinate}")
                    if source_sheet[f"{plan['name_column']}{cell.row}"].value != mapping["name"] or source_sheet[f"{plan['type_column']}{cell.row}"].value == "Folder":
                        raise ValueError(f"Verifies mapping is not on a primary test case: {cell.coordinate}")
                    if counterpart.value != mapping["value"] or not REFERENCE_CELL.fullmatch(counterpart.value):
                        raise ValueError(f"Wrong or malformed Verifies value: {cell.coordinate}")
                    identifiers = re.findall(r"\[ISSUE:(\d+)\]", counterpart.value)
                    if identifiers != mapping["requirement_ids"] or len(identifiers) != len(set(identifiers)):
                        raise ValueError(f"Reference ordering or duplicates: {cell.coordinate}")
                    actual_ids.update(identifiers)
                elif cell.value != counterpart.value or cell.data_type != counterpart.data_type:
                    raise ValueError(f"Unrelated cell content changed: {source_sheet.title}!{cell.coordinate}")
        if source_sheet.title == "Export":
            for number in range(2, source_sheet.max_row + 1):
                coordinate = f"{plan['verifies_column']}{number}"
                if coordinate not in allowed_cells:
                    non_primary_rows += 1
                    if output_sheet[coordinate].value not in (None, ""):
                        raise ValueError(f"Verifies populated outside mapped primary rows: {coordinate}")
    sheet = output_workbook[plan["unmapped_sheet"]]
    expected_rows = [("Requirement ID", "Requirement Name", "Requirement Tracker", "Reason")]
    expected_rows.extend((record["id"], record["name"], record["tracker"], record["reason"]) for record in plan["unmapped_requirements"])
    actual_rows = [tuple("" if value is None else str(value) for value in row) for row in sheet.iter_rows(values_only=True)]
    if actual_rows != expected_rows:
        raise ValueError("Unmapped_Requirements differs from the validated plan")
    unmapped_ids = {record["id"] for record in plan["unmapped_requirements"]}
    planned_ids = {identifier for mapping in plan["mappings"] for identifier in mapping["requirement_ids"]}
    if actual_ids != planned_ids or actual_ids & unmapped_ids or len(actual_ids | unmapped_ids) != plan["statistics"]["total_requirements"]:
        raise ValueError("Mapped/unmapped partition is incomplete or inconsistent")
    source_workbook.close()
    output_workbook.close()
    return {"passed": True, "original_cells_checked": checked_cells, "blank_non_primary_rows_verified": non_primary_rows, "formulas_preserved": formula_count, "unchanged_package_parts_byte_identical": unchanged, "changed_parts_restorable_to_original_bytes": registration["changed_parts"], "new_package_part": registration["new_sheet_path"], "styles_colors_merged_cells_formulas_sheet_visibility_preserved": True, "reference_format_order_membership_and_deduplication": "passed", "mapped_unmapped_partition": "passed", "live_codebeamer_import": "unverified; no import performed"}


def source_hash(path: Path) -> str:
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def apply_plan(requirement_document: Path, specification_document: Path, requirement_workbook: Path, specification_workbook: Path, output: Path, report_path: Path, plan: dict) -> dict:
    sources = []
    for document_path, workbook_path in ((requirement_document, requirement_workbook), (specification_document, specification_workbook)):
        document = json.loads(document_path.read_text(encoding="utf-8"))
        digest = source_hash(workbook_path)
        if digest != document["source"]["sha256"]:
            raise ValueError(f"Source changed since extraction: {workbook_path}")
        sources.append({"path": str(workbook_path.resolve()), "sha256": digest})
    registration = write_workbook(specification_workbook, output, plan)
    validation = validate_workbook(specification_workbook, output, plan, registration)
    if any(source_hash(Path(source["path"])) != source["sha256"] for source in sources):
        raise ValueError("An original workbook changed during generation")
    report = dict(plan)
    report.update({"sources": sources, "output": str(output.resolve()), "output_sha256": source_hash(output), "validation": validation, "libraries": "Universal Document Understanding/openpyxl for complete evidence extraction; Expat/ElementTree and zipfile for isolated package edits; openpyxl for full cell validation", "residual_risk": "Inferred relationships may differ from intended Codebeamer links. A relationship-bearing tracker export and live importer review would catch this. No requirement is claimed Approved, and no test behavior or execution coverage is certified."})
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    return report


@dataclass
class ExportRow:
    number: int
    values: dict[str, object]
    locators: dict[str, str]

    def text(self, field: str) -> str:
        value = self.values.get(field)
        return "" if value is None else str(value)


def export_rows(path: Path) -> tuple[dict[str, str], list[ExportRow]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    report = document["report"]
    if any(report.get(key) for key in ("partial", "unsupported", "failed")):
        raise ValueError(f"Incomplete document extraction: {path}")
    headers: dict[str, str] = {}
    for element in document["elements"]:
        source = element["source"]
        address = source.get("cell", "")
        if source.get("sheet") != "Export" or not re.fullmatch(r"[A-Z]+1", address):
            continue
        if element["type"] in ("table_header", "cell") and element.get("content"):
            column, _ = coordinate_from_string(address)
            headers[str(element["content"])] = column
    fields_by_column = {column: field for field, column in headers.items()}
    if not headers:
        raise ValueError(f"No main Export header row found: {path}")
    records: dict[int, ExportRow] = {}
    for element in document["elements"]:
        source = element["source"]
        address = source.get("cell", "")
        if source.get("sheet") != "Export" or element["type"] not in ("cell", "note"):
            continue
        if not re.fullmatch(r"[A-Z]+\d+", address):
            continue
        column, number = coordinate_from_string(address)
        if number == 1 or column not in fields_by_column:
            continue
        record = records.setdefault(number, ExportRow(number, {}, {}))
        field = fields_by_column[column]
        value = element.get("value", element.get("content"))
        if field in record.values and record.values[field] != value:
            raise ValueError(f"Conflicting extracted values: {source['locator']}")
        record.values[field] = value
        record.locators[field] = source["locator"]
    return headers, [records[number] for number in sorted(records)]


def issue_id(value: object) -> str:
    number = Decimal(str(value))
    if not number.is_finite() or number != number.to_integral_value() or number <= 0:
        raise ValueError(f"Not an exact positive issue ID: {value!r}")
    return str(int(number))


def normalized_text(value: str) -> str:
    value = html.unescape(value).replace("_x000D_", "")
    value = re.sub(r"~([_,()\[\]{}~*-])", r"\1", value)
    return value


def case_element(record: ExportRow) -> str | None:
    match = re.fullmatch(r"(EDR_Element_ID_.+)_TestCase_.+", record.text("Name"))
    return match.group(1) if match else None


def name_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", normalized_text(value).casefold())


def recording_times(case: ExportRow) -> set[Decimal]:
    text = normalized_text(case.text("Post-Action"))
    if re.search(r"^Recorded at:\s*T0\s*$", text, re.MULTILINE):
        return {Decimal(0)}
    match = re.search(r"^Recording time \[s\][^\n]*?:\s*(\[[^\n]+\])", text, re.MULTILINE)
    if not match:
        return set()
    values = match.group(1).strip("[]").split(",")
    return {Decimal(value.strip()) for value in values}


def requirement_time(record: ExportRow) -> Decimal | None:
    match = re.search(r"\bat\s*([+-]?\d+(?:\.\d+)?)\s*s\b", normalized_text(record.text("Summary")), re.IGNORECASE)
    if match:
        return Decimal(match.group(1))
    interval = normalized_text(record.text("Recording interval / Time (relative to Time zero)")).strip()
    if re.fullmatch(r"0(?:\.0+)?\s*(?:ms|s|sec)", interval, re.IGNORECASE):
        return Decimal(0)
    return None


def case_blocks(rows: list[ExportRow]) -> list[dict]:
    blocks = []
    current = None
    for record in rows:
        if record.text("Name"):
            current = None
            if record.text("Type") != "Folder":
                current = {"primary": record, "steps": []}
                blocks.append(current)
        if current is not None and (record.text("Test Steps.Action") or record.text("Test Steps.Expected result")):
            current["steps"].append(record)
    return blocks


def compile_review(requirement_document: Path, specification_document: Path, output: Path) -> None:
    if not (output / "README.md").exists():
        raise ValueError(f"Retained review folder requires a README: {output}")
    sanitizer_path = Path(__file__).resolve().parents[1] / ".github/skills/veoneer-test-spec-generator/scripts/sanitize.py"
    sanitize = runpy.run_path(str(sanitizer_path))["sanitize_text"]
    _, requirements = export_rows(requirement_document)
    _, specification = export_rows(specification_document)
    blocks = case_blocks(specification)
    case_lines = ["# Complete Case Evidence", "", "GENERATED FILE - do not edit by hand. Rebuild with the mapping utility's --review-output command.", ""]
    for block in blocks:
        primary = block["primary"]
        case_lines.extend([f"## Row {primary.number}: {primary.text('Name')}", ""])
        for field in ("Description", "Pre-Action", "Post-Action", "Verifies"):
            value = sanitize(primary.text(field)).text
            if value:
                case_lines.extend([f"{field} ({primary.locators[field]}):", value, ""])
        for step in block["steps"]:
            case_lines.extend([f"Step row {step.number}", "Action: " + sanitize(step.text("Test Steps.Action")).text, "Expected: " + sanitize(step.text("Test Steps.Expected result")).text, ""])
    (output / "case-evidence.md").write_text("\n".join(case_lines) + "\n", encoding="utf-8")
    requirement_lines = ["# Complete Requirement Index", "", "GENERATED FILE - do not edit by hand. Rebuild with the mapping utility's --review-output command.", ""]
    for requirement in requirements:
        requirement_lines.append(f"Row {requirement.number} | {issue_id(requirement.values['ID'])} | {requirement.text('Type')} | {requirement.text('_ReqStatus')} | {sanitize(requirement.text('Parent')).text} | {sanitize(requirement.text('Summary')).text}")
        if requirement.number < 146 or requirement.number > 1407:
            for field in ("Description", "DID", "Byte_Position", "Recording interval / Time (relative to Time zero)", "_Verification_Criteria"):
                value = sanitize(requirement.text(field)).text
                if value:
                    requirement_lines.extend([f"{field}:", value])
        requirement_lines.append("")
    (output / "requirement-index.md").write_text("\n".join(requirement_lines) + "\n", encoding="utf-8")
    print(json.dumps({"case_blocks": len(blocks), "step_rows": sum(len(block['steps']) for block in blocks), "requirements": len(requirements), "output": str(output)}, indent=2))


def build_reviewed_plan(requirement_document: Path, specification_document: Path, decision_paths: list[Path], previous_plan_path: Path) -> dict:
    _, requirements = export_rows(requirement_document)
    specification_headers, specification = export_rows(specification_document)
    by_id = {issue_id(record.values["ID"]): record for record in requirements}
    if len(by_id) != len(requirements):
        raise ValueError("Duplicate exported requirement IDs")
    blocks = [block for block in case_blocks(specification) if block["steps"]]
    by_case = {block["primary"].number: block["primary"] for block in blocks}
    accepted_by_case: dict[int, set[str]] = defaultdict(set)
    evidence_by_case: dict[int, list[dict]] = defaultdict(list)
    candidates: dict[str, list[dict]] = defaultdict(list)
    gaps: dict[str, list[str]] = defaultdict(list)
    contradictions = []
    review_sources = []
    for path in decision_paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        review_sources.append({"path": str(path), "sha256": source_hash(path), "source_scope": data.get("source_scope", [])})
        for decision in data.get("decisions", []):
            number = int(decision["case_row"])
            if number not in by_case or decision["case_name"] != by_case[number].text("Name"):
                raise ValueError(f"Decision does not identify an actual primary case: {path}, row {number}")
            if decision.get("confidence") != "High" or not decision.get("case_evidence") or not decision.get("requirement_evidence") or not decision.get("rationale"):
                raise ValueError(f"Insufficient reviewed mapping evidence: {path}, row {number}")
            identifiers = decision["requirement_ids"]
            if not identifiers or len(identifiers) != len(set(identifiers)):
                raise ValueError(f"Empty or duplicate decision references: {path}, row {number}")
            for identifier in identifiers:
                if identifier not in by_id:
                    raise ValueError(f"Requirement ID not exported: {identifier}")
                requirement = by_id[identifier]
                if requirement.text("Type") not in ("Functional Requirement", "Information"):
                    raise ValueError(f"Structural item cannot be mapped: {identifier}")
                if requirement.text("_ReqStatus") == "Obsolete":
                    raise ValueError(f"Section 16.2 prohibits Obsolete Verifies references: {identifier}")
            accepted_by_case[number].update(identifiers)
            evidence_by_case[number].append({"review_file": str(path), **decision})
        for candidate in data.get("candidates", []):
            identifier = str(candidate["requirement_id"])
            if identifier not in by_id or any(int(number) not in by_case for number in candidate.get("case_rows", [])):
                raise ValueError(f"Candidate has unknown requirement or non-case row: {path}, {identifier}")
            candidates[identifier].append({"review_file": str(path), **candidate})
        for gap in data.get("unmapped", []):
            identifier = str(gap["requirement_id"])
            if identifier not in by_id:
                raise ValueError(f"Gap references unknown requirement: {path}, {identifier}")
            gaps[identifier].append(gap["reason"])
        contradictions.extend({"review_file": str(path), **finding} for finding in data.get("contradictions", []))
    previous = json.loads(previous_plan_path.read_text(encoding="utf-8"))
    previous_mapped = {identifier for mapping in previous["mappings"] for identifier in mapping["requirement_ids"]}
    previous_unmapped = {record["id"] for record in previous["unmapped_requirements"]}
    if previous_mapped & previous_unmapped or previous_mapped | previous_unmapped != set(by_id):
        raise ValueError("Previous coverage plan does not partition this same requirement export")
    mappings = []
    mapped_ids: set[str] = set()
    for number, identifiers in sorted(accepted_by_case.items()):
        case = by_case[number]
        variant_text = normalized_text(case.text("Pre-Action"))
        marker = "Select one target variant from the approved list:"
        selected_projects: set[str] = set()
        if marker in variant_text:
            selected_text = variant_text.split(marker, 1)[1].split("Write the Default Variant", 1)[0]
            selected_projects = set(re.findall(r"(?<![A-Z0-9])[MUWZ]\d{3}(?!\d)", selected_text.upper()))
        held = []
        for identifier in sorted(identifiers, key=lambda reference: by_id[reference].number):
            requirement_projects = set(re.findall(r"(?<![A-Z0-9])[MUWZ]\d{3}(?!\d)", by_id[identifier].text("_Projects").upper()))
            reason = None
            if selected_projects and not selected_projects.issubset(requirement_projects):
                reason = f"Explicit case targets {', '.join(sorted(selected_projects))} are not corroborated by exported _Projects ({', '.join(sorted(requirement_projects)) or 'missing'}); target eligibility must be resolved before importing this relation"
            if number == 892 and identifier == "36912363":
                reason = "Independent verifier hold: near-crash lock encoding is 0 in requirement Export!AG167, but final case Export!H905 labels Near Event2 with lock 1; resolve the conflicting oracle before linking"
            if reason:
                held.append(identifier)
                candidates[identifier].append({"review_file": "integration-variant-and-oracle-gate", "requirement_id": identifier, "case_rows": [number], "reason": reason})
        for identifier in held:
            identifiers.remove(identifier)
        if not identifiers:
            continue
        existing = list(dict.fromkeys(re.findall(r"\[ISSUE:(\d+)\]", case.text("Verifies"))))
        for identifier in existing:
            if identifier not in by_id or by_id[identifier].text("_ReqStatus") == "Obsolete":
                raise ValueError(f"Existing reference needs explicit review: row {number}, {identifier}")
            identifiers.add(identifier)
        ordered = sorted(identifiers, key=lambda identifier: by_id[identifier].number)
        for evidence in evidence_by_case[number]:
            evidence["accepted_requirement_ids_after_integration"] = [identifier for identifier in evidence["requirement_ids"] if identifier in identifiers]
            evidence["held_requirement_ids_after_integration"] = [identifier for identifier in evidence["requirement_ids"] if identifier not in identifiers]
        value = ",\n".join(f"[ISSUE:{identifier}]-null" for identifier in ordered)
        if len(value) > 32767 or not REFERENCE_CELL.fullmatch(value):
            raise ValueError(f"Invalid or oversized reference cell at row {number}")
        mappings.append({"row": number, "name": case.text("Name"), "verifies_cell": f"{specification_headers['Verifies']}{number}", "requirement_ids": ordered, "value": value, "basis": "INFERRED", "confidence": "High", "method": "reviewed_case_predicate_and_requirement_contract", "semantic_evidence": evidence_by_case[number], "requirement_evidence": [{"id": identifier, "row": by_id[identifier].number, "name": by_id[identifier].text("Summary"), "status": by_id[identifier].text("_ReqStatus"), "locator": by_id[identifier].locators["ID"]} for identifier in ordered]})
        mapped_ids.update(ordered)
    unmapped = []
    for requirement in requirements:
        identifier = issue_id(requirement.values["ID"])
        if identifier in mapped_ids:
            continue
        reasons = []
        if requirement.text("_ReqStatus") == "Obsolete":
            reasons.append("Historical/Obsolete item assessed but prohibited in Verifies by repository section 16.2; see compatibility review")
        if identifier in candidates:
            for candidate in candidates[identifier]:
                rows = candidate.get("case_rows", [])
                reasons.append(f"Potential case rows {', '.join(str(number) for number in rows) or 'none'}: {candidate['reason']}")
        if identifier in gaps:
            reasons.extend(gaps[identifier])
        if not reasons:
            if requirement.text("Type") in ("Heading", "Folder", "Information"):
                reasons.append("Structural, definitional or image-only item without a directly tested normative predicate")
            else:
                reasons.append("No confidently applicable case in this specification; previous mappings, where present, remain in the earlier workbook")
        reason = "\n".join(dict.fromkeys(reasons))
        if len(reason) > 32767:
            raise ValueError(f"Oversized unmapped reason: {identifier}")
        unmapped.append({"id": identifier, "name": requirement.text("Summary"), "tracker": "160307034", "status": requirement.text("_ReqStatus"), "reason": reason, "source_row": requirement.number, "source": requirement.locators["ID"], "previously_unmapped": identifier in previous_unmapped, "candidate_case_rows": sorted({int(number) for candidate in candidates.get(identifier, []) for number in candidate.get("case_rows", [])})})
    potential = [{"id": identifier, "name": by_id[identifier].text("Summary"), "status": by_id[identifier].text("_ReqStatus"), "source_row": by_id[identifier].number, "previously_unmapped": identifier in previous_unmapped, "mapped_in_this_spec": identifier in mapped_ids, "case_rows": sorted({int(number) for candidate in entries for number in candidate.get("case_rows", [])}), "case_names": [by_case[number].text("Name") for number in sorted({int(number) for candidate in entries for number in candidate.get("case_rows", [])})], "reason": "\n".join(dict.fromkeys(candidate["reason"] for candidate in entries))} for identifier, entries in sorted(candidates.items(), key=lambda item: by_id[item[0]].number)]
    historical = []
    for identifier, requirement in by_id.items():
        if requirement.text("_ReqStatus") == "Obsolete":
            if identifier not in candidates:
                raise ValueError(f"Historical ID not independently assessed: {identifier}")
            historical.append(next(record for record in potential if record["id"] == identifier))
    mapped_case_rows = {mapping["row"] for mapping in mappings}
    unresolved = [{"row": number, "name": case.text("Name"), "reason": "No high-confidence compatible requirement relationship after predicate, target-variant and oracle review; potential matches and conflicts remain in the review reports"} for number, case in by_case.items() if number not in mapped_case_rows]
    return {
        "generated_by": "tools/map_codebeamer_requirement_links.py",
        "statistics": {"total_requirements": len(requirements), "functional_requirements": sum(record.text("Type") == "Functional Requirement" for record in requirements), "non_requirement_tracker_items": sum(record.text("Type") != "Functional Requirement" for record in requirements), "mapped_requirements": len(mapped_ids), "mapped_functional_requirements": sum(by_id[identifier].text("Type") == "Functional Requirement" for identifier in mapped_ids), "mapped_normative_information_items": sum(by_id[identifier].text("Type") == "Information" for identifier in mapped_ids), "unmapped_requirements": len(unmapped), "total_test_cases_processed": len(by_case), "total_test_cases_updated": len(mappings), "test_cases_without_confident_mapping": len(unresolved), "previously_unmapped_requirements": len(previous_unmapped), "previously_unmapped_now_mapped": len(mapped_ids & previous_unmapped), "previously_unmapped_still_without_mapping_across_both_specs": len(previous_unmapped - mapped_ids), "combined_unique_mapped_requirements": len(previous_mapped | mapped_ids), "potential_requirement_ids_reviewed": len(potential), "historical_obsolete_ids_assessed": len(historical), "historical_obsolete_ids_imported": 0, "folder_rows_not_mapped": sum(record.text("Type") == "Folder" and bool(record.text("Name")) for record in specification)},
        "verifies_column": specification_headers["Verifies"], "name_column": specification_headers["Name"], "type_column": specification_headers["Type"], "unmapped_sheet": "Unmapped_Requirements",
        "mapping_policy": "High-confidence reviewed predicate/contract links only, source-ordered, primary cases only; candidates and historical/Obsolete IDs are assessed and reported, not forced into import references. No Approved or executed coverage claim.",
        "requirement_statuses": dict(Counter(record.text("_ReqStatus") for record in requirements)), "tracker_provenance": "160307034 is user-provided, not independently identified in the offline export", "relationship_evidence_gap": "Evidence unavailable. No explicit test-case relationships in the requirement export; accepted links are content-based inferences.",
        "mappings": mappings, "unresolved_test_cases": unresolved, "unmapped_requirements": unmapped, "potential_mappings": potential, "historical_compatibility_review": historical, "contradictions": contradictions, "review_sources": review_sources,
        "previous_plan": {"path": str(previous_plan_path), "sha256": source_hash(previous_plan_path)},
        "previously_unmapped_ids_now_mapped": sorted(mapped_ids & previous_unmapped, key=lambda identifier: by_id[identifier].number),
    }


def write_review_csvs(plan: dict, directory: Path) -> None:
    for filename, records in (("potential-mappings.csv", plan.get("potential_mappings", [])), ("historical-compatibility.csv", plan.get("historical_compatibility_review", []))):
        if not records:
            continue
        with (directory / filename).open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["Requirement ID", "Requirement Name", "Status", "Requirement Source Row", "Previously Unmapped", "Mapped In This Specification", "Potential Case Rows", "Potential Case Names", "Reason"])
            for record in records:
                writer.writerow([record["id"], record["name"], record["status"], record["source_row"], record["previously_unmapped"], record["mapped_in_this_spec"], ", ".join(str(number) for number in record["case_rows"]), "\n".join(record["case_names"]), record["reason"]])


def build_plan(requirement_document: Path, specification_document: Path, aliases_path: Path) -> dict:
    requirement_headers, requirements = export_rows(requirement_document)
    specification_headers, specification = export_rows(specification_document)
    for field in ("ID", "Summary", "Type", "Parent", "Description", "_ReqStatus", "DID"):
        if field not in requirement_headers:
            raise ValueError(f"Missing requirement header: {field}")
    for field in ("Name", "Type", "Verifies", "Test Steps.Action", "Post-Action"):
        if field not in specification_headers:
            raise ValueError(f"Missing test specification header: {field}")
    by_id = {issue_id(record.values["ID"]): record for record in requirements}
    if len(by_id) != len(requirements):
        raise ValueError("Duplicate requirement IDs in the supplied export")
    alias_data = json.loads(aliases_path.read_text(encoding="utf-8"))
    aliases = alias_data["element_aliases"]
    scalar_aliases = alias_data["scalar_element_aliases"]
    headings: dict[str, list[ExportRow]] = defaultdict(list)
    for record in requirements:
        if record.text("Type") == "Heading":
            headings[name_key(record.text("Summary"))].append(record)
    for element, title in list(aliases.items()) + list(scalar_aliases.items()):
        targets = [record for record in requirements if name_key(record.text("Summary")) == name_key(title) and record.text("_ReqStatus") != "Obsolete" and record.text("Type") in ("Heading", "Functional Requirement")]
        if len(targets) != 1:
            raise ValueError(f"Alias target is not a unique active exported item: {element} -> {title}")
    mappings = []
    unresolved = []
    mapped_ids: set[str] = set()
    candidates_by_id: dict[str, list[str]] = defaultdict(list)
    cases = [record for record in specification if record.text("Name") and record.text("Type") != "Folder"]
    for case in cases:
        element = case_element(case)
        if not element:
            unresolved.append({"row": case.number, "name": case.text("Name"), "reason": "No confident element identity or explicit requirement relationship"})
            continue
        tag = element.removeprefix("EDR_Element_ID_")
        times = recording_times(case)
        target = scalar_aliases.get(tag, aliases.get(tag, tag)) if times == {Decimal(0)} else aliases.get(tag, tag)
        matched_headings = headings.get(name_key(target), [])
        candidate_requirements = []
        basis = "INFERRED"
        method = "exact_element_title"
        if len(matched_headings) == 1:
            heading = matched_headings[0]
            method = "reviewed_element_alias" if target != tag else "exact_element_title"
            candidate_requirements = [record for record in requirements if name_key(record.text("Parent")) == name_key(heading.text("Summary")) and record.text("Type") == "Functional Requirement" and record.text("_ReqStatus") != "Obsolete"]
            identity_evidence = [heading.locators["Summary"], case.locators["Name"]]
        else:
            candidate_requirements = [record for record in requirements if name_key(record.text("Summary")) == name_key(target) and record.text("Type") == "Functional Requirement" and record.text("_ReqStatus") != "Obsolete"]
            method = "reviewed_scalar_element_alias" if target != tag else "exact_element_title"
            identity_evidence = [case.locators["Name"]]
        behavior_note = tag in ("NOT_CONFIGURED", "RESERVED_BYTES")
        if behavior_note:
            candidate_requirements = [record for record in requirements if record.text("Type") == "Information" and record.text("Parent") == "EDR_0455_045B_Data" and "default/deconfigured value will be 0xFF" in normalized_text(record.text("Description")) and "reserved bits the default/deconfigured value will be 0" in normalized_text(record.text("Description"))]
            if len(candidate_requirements) != 1:
                candidate_requirements = []
            method = "explicit_exported_behavior_note"
        explicit_ids = list(dict.fromkeys(re.findall(r"\[ISSUE:(\d+)\]", case.text("Verifies") + "\n" + case.text("Description"))))
        if any(identifier not in by_id for identifier in explicit_ids):
            raise ValueError(f"Unknown explicit requirement ID in test row {case.number}: {explicit_ids}")
        if explicit_ids:
            candidate_requirements = [by_id[identifier] for identifier in explicit_ids]
            method = "explicit_issue_relationship"
            basis = "EXTRACTED"
        record_header = normalized_text(case.text("Post-Action")).splitlines()
        case_dids = set(re.findall(r"0x[0-9a-fA-F]{4}\b", record_header[0] if record_header else ""))
        case_dids = {identifier.casefold() for identifier in case_dids}
        accepted = []
        for requirement in candidate_requirements:
            identifier = issue_id(requirement.values["ID"])
            candidates_by_id[identifier].append(case.text("Name"))
            requirement_dids = {identifier.casefold() for identifier in re.findall(r"0x[0-9a-fA-F]{4}\b", requirement.text("DID"))}
            if not explicit_ids and (not case_dids or not requirement_dids or not requirement_dids.issubset(case_dids)):
                if not behavior_note or case_dids != {"0x0455", "0x045b"}:
                    continue
            if not explicit_ids and not behavior_note and requirement_time(requirement) not in times:
                continue
            accepted.append(requirement)
        identifiers = [issue_id(record.values["ID"]) for record in accepted]
        if not identifiers:
            unresolved.append({"row": case.number, "name": case.text("Name"), "reason": "No unique active element match with matching recording DID metadata"})
            continue
        mapped_ids.update(identifiers)
        mappings.append({
            "row": case.number,
            "name": case.text("Name"),
            "verifies_cell": f"{specification_headers['Verifies']}{case.number}",
            "requirement_ids": identifiers,
            "value": ",\n".join(f"[ISSUE:{identifier}]-null" for identifier in identifiers),
            "basis": basis,
            "confidence": "Very High" if explicit_ids else "High",
            "method": method,
            "identity_evidence": identity_evidence + [record.locators["Summary"] for record in accepted if record.text("Summary")],
            "recording_times_seconds": sorted(str(time) for time in times),
            "requirement_evidence": [{"id": issue_id(record.values["ID"]), "row": record.number, "name": record.text("Summary"), "status": record.text("_ReqStatus"), "locator": record.locators["ID"]} for record in accepted],
        })
    unmapped = []
    for requirement in requirements:
        identifier = issue_id(requirement.values["ID"])
        if identifier in mapped_ids:
            continue
        if requirement.text("Type") != "Functional Requirement":
            reason = f"Exported item is {requirement.text('Type') or 'missing Type'}, not an identifiable functional requirement; no confident test relationship"
        elif requirement.text("_ReqStatus") == "Obsolete":
            reason = "Obsolete requirement; no explicit test relationship supplied; not inferred as current coverage"
        elif identifier in candidates_by_id:
            reason = "Related element found, but recording DID or sample-time metadata is missing or does not match; relationship cannot be determined with confidence"
        else:
            reason = "No matching test case found with a confident element identity; export does not contain explicit test-case relationships (_TestCoverage is tbd)"
        unmapped.append({"id": identifier, "name": requirement.text("Summary"), "tracker": "160307034", "reason": reason, "source_row": requirement.number, "source": requirement.locators["ID"]})
    return {
        "generated_by": "tools/map_codebeamer_requirement_links.py",
        "statistics": {"total_requirements": len(requirements), "functional_requirements": sum(record.text("Type") == "Functional Requirement" for record in requirements), "non_requirement_tracker_items": sum(record.text("Type") != "Functional Requirement" for record in requirements), "mapped_requirements": len(mapped_ids), "mapped_functional_requirements": sum(by_id[identifier].text("Type") == "Functional Requirement" for identifier in mapped_ids), "mapped_normative_information_items": sum(by_id[identifier].text("Type") == "Information" for identifier in mapped_ids), "unmapped_requirements": len(unmapped), "total_test_cases_processed": len(cases), "total_test_cases_updated": len(mappings), "test_cases_without_confident_mapping": len(unresolved)},
        "verifies_column": specification_headers["Verifies"],
        "name_column": specification_headers["Name"],
        "type_column": specification_headers["Type"],
        "unmapped_sheet": "Unmapped_Requirements",
        "mapping_order": "Requirement export row order; explicit reference order when available",
        "mapping_policy": "Exact element titles or reviewed semantic aliases plus matching recording DIDs and exact sample times; parent heading links identify sample requirements. The explicit default/deconfigured and reserved-bit note supports its two matching behavior cases. Inferred links do not assert approved or executed coverage.",
        "requirement_statuses": dict(Counter(record.text("_ReqStatus") for record in requirements)),
        "relationship_evidence_gap": "Evidence unavailable. The offline requirement export contains no test-case relationship field; _TestCoverage is tbd. Content-based mappings are INFERRED, not retrieved Codebeamer links.",
        "tracker_provenance": "Tracker 160307034 is supplied by the user; the offline workbook does not independently identify its tracker ID.",
        "mappings": mappings,
        "unresolved_test_cases": unresolved,
        "unmapped_requirements": unmapped,
    }


def inspect(requirement_document: Path, specification_document: Path) -> None:
    requirement_headers, requirements = export_rows(requirement_document)
    specification_headers, specification = export_rows(specification_document)
    for field in ("ID", "Summary", "Type", "Parent", "Description"):
        if field not in requirement_headers:
            raise ValueError(f"Missing requirement header: {field}")
    for field in ("Name", "Type", "Verifies", "Test Steps.Action"):
        if field not in specification_headers:
            raise ValueError(f"Missing test specification header: {field}")
    cases = [record for record in specification if record.text("Name") and record.text("Type") != "Folder"]
    ids = [issue_id(record.values["ID"]) for record in requirements]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate requirement IDs in the supplied export")
    families = Counter(case_element(record) for record in cases)
    if None in families:
        raise ValueError("A named test case has no recognized element identifier")
    references: dict[str, list[ExportRow]] = defaultdict(list)
    for record in requirements:
        text = normalized_text(record.text("Summary") + "\n" + record.text("Description"))
        for element in families:
            if element and re.search(r"(?<!\w)" + re.escape(element.removeprefix("EDR_Element_ID_")) + r"(?!\w)", text, re.IGNORECASE):
                references[element].append(record)
    print(json.dumps({
        "requirement_records": len(requirements),
        "functional_requirements": sum(record.text("Type") == "Functional Requirement" for record in requirements),
        "test_cases": len(cases),
        "non_test_named_rows": [(record.number, record.text("Name")) for record in specification if record.text("Name") and record.text("Type") == "Folder"],
        "verifies_column": specification_headers["Verifies"],
        "families": [{
            "element": element,
            "test_cases": count,
            "direct_requirement_references": [{
                "row": record.number,
                "id": issue_id(record.values["ID"]),
                "name": record.text("Summary"),
                "type": record.text("Type"),
                "status": record.text("_ReqStatus"),
                "parent": record.text("Parent"),
                "description": normalized_text(record.text("Description")),
                "fields": {key: value for key, value in record.values.items() if value is not None and str(value).strip()},
            } for record in references[element or ""]],
        } for element, count in families.items()],
        "case_scenarios": [{"row": record.number, "name": record.text("Name"), "description": record.text("Description")} for record in cases if case_element(record) == next(iter(families))],
    }, indent=2, ensure_ascii=True))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requirements-document", type=Path, required=True)
    parser.add_argument("--specification-document", type=Path, required=True)
    parser.add_argument("--inspect", action="store_true")
    parser.add_argument("--aliases", type=Path)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--requirements-workbook", type=Path)
    parser.add_argument("--specification-workbook", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--review-output", type=Path)
    parser.add_argument("--reviewed-mappings", type=Path, action="append")
    parser.add_argument("--previous-plan", type=Path)
    arguments = parser.parse_args()
    if arguments.review_output:
        compile_review(arguments.requirements_document, arguments.specification_document, arguments.review_output)
    elif arguments.inspect:
        inspect(arguments.requirements_document, arguments.specification_document)
    elif (arguments.aliases or arguments.reviewed_mappings) and arguments.plan:
        if arguments.plan.exists() and not arguments.overwrite:
            raise FileExistsError(arguments.plan)
        if arguments.reviewed_mappings:
            if not arguments.previous_plan:
                parser.error("Reviewed mapping requires --previous-plan for complete additional-coverage accounting")
            plan = build_reviewed_plan(arguments.requirements_document, arguments.specification_document, arguments.reviewed_mappings, arguments.previous_plan)
            write_review_csvs(plan, arguments.plan.parent)
        else:
            plan = build_plan(arguments.requirements_document, arguments.specification_document, arguments.aliases)
        arguments.plan.write_text(json.dumps(plan, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
        if arguments.output:
            if not all((arguments.requirements_workbook, arguments.specification_workbook, arguments.report)):
                parser.error("Workbook generation requires --requirements-workbook, --specification-workbook and --report")
            for path in (arguments.output, arguments.report):
                if path.exists() and not arguments.overwrite:
                    raise FileExistsError(path)
            report = apply_plan(arguments.requirements_document, arguments.specification_document, arguments.requirements_workbook, arguments.specification_workbook, arguments.output, arguments.report, plan)
            print(json.dumps({"output": report["output"], "statistics": report["statistics"], "validation": report["validation"]}, indent=2))
        else:
            print(json.dumps(plan["statistics"], indent=2))
    else:
        parser.error("Choose --inspect or supply --aliases and --plan")


if __name__ == "__main__":
    main()