"""Build a low-token architectural memory graph with Graphify AST extraction.

The builder deliberately avoids semantic extraction agents and never writes raw
source code, function bodies, docstrings, or full AST payloads. It stores only
short file/module summaries, symbol names, import/call relationships, hashes,
and source locations. Unchanged selected files are reused from the prior graph.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
from importlib import metadata
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from graphify.extract import extract


SCHEMA_VERSION = 1
DEFAULT_OUTPUT_DIR = "graphify-out/compact-memory"
MAX_EXPORTS_PER_FILE = 12
MAX_DEPENDENCIES_PER_FILE = 12
MAX_SYMBOLS_PER_FILE = 12
PRIORITY_PATHS = (
    "shared_libraries/**/*.py",
    "tools/**/*.py",
    ".github/skills/**/scripts/**/*.py",
    "projects/**/config/**/*.py",
    "projects/__init__.py",
)
IGNORED_PREFIXES = {
    ".git",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "out",
    "bin",
    "obj",
    "coverage",
    "test_results",
    "test_logs",
    "crash_data",
    "test_data",
    "graphify-out",
    "project_reuirements",
    "project_reuirements_cleaned",
    "project_testcases",
    "project_testcases_cleaned",
    "req",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _token_estimate(value: Any) -> int:
    serialized = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return max(1, round(len(serialized.split()) * 1.3))


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def _source_location(line: int | None) -> str | None:
    return f"L{line}" if line else None


def _read_json(path: Path, default: Any) -> Any:
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)


def _path_priority(relative: Path) -> str:
    if relative.parts[0] in {"shared_libraries", "projects"}:
        return "high"
    if relative.parts[0] in {"tools", ".github"}:
        return "medium"
    return "low"


def _module_id(relative: Path) -> str:
    parts = relative.parts
    if parts[0] == "shared_libraries":
        return "module:shared-libraries"
    if parts[0] == "tools":
        return "module:tools"
    if parts[0] == ".github":
        skill_name = parts[2] if len(parts) > 3 and parts[1] == "skills" else "governance"
        return f"module:skill-engine:{skill_name}"
    if parts[0] == "projects" and len(parts) >= 3 and parts[2] == "config":
        return f"module:project-config:{parts[1]}"
    if parts[0] == "projects":
        return "module:projects"
    return f"module:{parts[0]}"


def _module_summary(module_id: str) -> str:
    if module_id == "module:shared-libraries":
        return "Shared runtime wrappers, reporting, configuration, communication, fault, and sensor support for project tests."
    if module_id == "module:tools":
        return "Offline maintenance, conversion, knowledge-building, and review utilities for framework artifacts."
    if module_id == "module:projects":
        return "Project package metadata and shared project namespace."
    if module_id.startswith("module:project-config:"):
        return f"Configuration surface for project variant {module_id.rsplit(':', 1)[1]}; supplies constants and mappings to tests."
    if module_id.startswith("module:skill-engine:"):
        return f"Executable automation engine for Copilot skill {module_id.rsplit(':', 1)[1]}."
    return "Architectural module summarized from selected source paths."


def _file_purpose(relative: Path) -> str:
    stem = relative.stem.replace("_", " ")
    if relative.parts[0] == "shared_libraries":
        return f"Shared framework component for {stem}."
    if relative.parts[0] == "tools":
        return f"Offline framework utility for {stem}."
    if relative.parts[0] == ".github":
        return f"Skill automation engine for {stem}."
    if relative.parts[0] == "projects" and len(relative.parts) >= 3 and relative.parts[2] == "config":
        return f"Project configuration for {relative.parts[1]} {stem}."
    return f"Framework source file for {stem}."


def _selected_files(root: Path) -> list[Path]:
    selected: set[Path] = set()
    for pattern in PRIORITY_PATHS:
        selected.update(path for path in root.glob(pattern) if path.is_file())
    return sorted(path for path in selected if not any(part in IGNORED_PREFIXES for part in path.relative_to(root).parts))


def _extract_public_symbols(path: Path) -> tuple[list[dict[str, Any]], list[str], list[str]]:
    """Extract only names, line references, and imports from AST; never store bodies."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
    except SyntaxError:
        return [], [], []
    explicit_exports: list[str] = []
    imports: list[str] = []
    symbols: list[dict[str, Any]] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            kind = "class" if isinstance(node, ast.ClassDef) else "function"
            symbols.append({"name": node.name, "kind": kind, "location": _source_location(getattr(node, "lineno", None))})
        elif isinstance(node, ast.Import):
            imports.extend(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module.split(".")[0])
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    try:
                        values = ast.literal_eval(node.value)
                    except (ValueError, TypeError):
                        values = []
                    if isinstance(values, (list, tuple)):
                        explicit_exports.extend(str(value) for value in values if isinstance(value, str))
    public_symbols = [symbol for symbol in symbols if not symbol["name"].startswith("_")]
    if explicit_exports:
        symbol_lookup = {symbol["name"]: symbol for symbol in symbols}
        public_symbols = [symbol_lookup.get(name, {"name": name, "kind": "export", "location": None}) for name in explicit_exports]
    return public_symbols[:MAX_SYMBOLS_PER_FILE], sorted(set(explicit_exports))[:MAX_EXPORTS_PER_FILE], sorted(set(imports))[:MAX_DEPENDENCIES_PER_FILE]


def _graphify_relationships(path: Path, relative: Path) -> list[dict[str, Any]]:
    """Use Graphify AST relationships but retain only compact reference metadata."""
    try:
        extracted = extract([path])
    except Exception as error:
        return [{"relation": "analysis_warning", "target": type(error).__name__, "source_location": None, "confidence": "AMBIGUOUS"}]
    relationships: list[dict[str, Any]] = []
    for edge in extracted.get("edges", []):
        relation = edge.get("relation")
        if relation not in {"imports", "imports_from", "calls", "inherits", "implements"}:
            continue
        target = edge.get("target")
        if not isinstance(target, str) or not target:
            continue
        relationships.append(
            {
                "relation": relation,
                "target": target,
                "source_location": edge.get("source_location"),
                "confidence": edge.get("confidence", "EXTRACTED"),
            }
        )
    unique: dict[tuple[str, str, str | None], dict[str, Any]] = {}
    for relationship in relationships:
        key = (relationship["relation"], relationship["target"], relationship["source_location"])
        unique[key] = relationship
    return list(unique.values())[:24]


def _analyze_file(root: Path, path: Path, file_hash: str) -> dict[str, Any]:
    relative = path.relative_to(root)
    symbols, explicit_exports, imports = _extract_public_symbols(path)
    relationships = _graphify_relationships(path, relative)
    exports = explicit_exports or [symbol["name"] for symbol in symbols][:MAX_EXPORTS_PER_FILE]
    return {
        "id": f"file:{relative.as_posix()}",
        "path": relative.as_posix(),
        "hash": file_hash,
        "priority": _path_priority(relative),
        "module": _module_id(relative),
        "purpose": _file_purpose(relative),
        "exports": exports,
        "depends_on": imports,
        "symbols": symbols,
        "relationships": relationships,
        "source_reference": {"path": relative.as_posix(), "location": "L1"},
        "summary_token_estimate": _token_estimate({"purpose": _file_purpose(relative), "exports": exports, "depends_on": imports}),
    }


def _repository_summary(files: list[dict[str, Any]]) -> dict[str, Any]:
    try:
        graphify_version = metadata.version("graphifyy")
    except metadata.PackageNotFoundError:
        graphify_version = "unknown"
    modules = Counter(file["module"] for file in files)
    return {
        "name": "Framework_IOEM_Py",
        "purpose": "Python automation framework for Mahindra SC3 2S airbag ECU validation, ARIA/APYM integration, project configuration, CAN/UDS analysis, and governed engineering tools.",
        "architecture_style": "Configuration-driven modular framework with shared libraries, project-variant configuration, offline tooling, and controlled skill automation.",
        "technology_stack": ["Python", "ARIA/APYM", "CAN/CAN FD", "UDS/ISO-TP", "Excel/PDF tooling", "Graphify AST"],
        "analysis_mode": "Graphify AST-only; no semantic-agent extraction and no raw code storage.",
        "graphify_distribution_version": graphify_version,
        "selected_file_count": len(files),
        "modules": dict(sorted(modules.items())),
    }


def _modules(files: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for file in files:
        grouped[file["module"]].append(file)
    output = []
    for identifier, module_files in sorted(grouped.items()):
        dependencies = Counter(dependency for file in module_files for dependency in file["depends_on"])
        public_interfaces = [symbol["name"] for file in module_files for symbol in file["symbols"]][:24]
        output.append(
            {
                "id": identifier,
                "name": identifier.removeprefix("module:"),
                "purpose": _module_summary(identifier),
                "file_count": len(module_files),
                "depends_on": [name for name, _ in dependencies.most_common(12)],
                "public_interfaces": public_interfaces,
                "source_paths": [file["path"] for file in module_files],
                "summary_token_estimate": _token_estimate({"purpose": _module_summary(identifier), "dependencies": [name for name, _ in dependencies.most_common(12)], "interfaces": public_interfaces}),
            }
        )
    return output


def _graph(files: list[dict[str, Any]], modules: list[dict[str, Any]]) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = [{"id": "repository:Framework_IOEM_Py", "type": "repository", "label": "Framework_IOEM_Py"}]
    edges: list[dict[str, Any]] = []
    for module in modules:
        nodes.append({"id": module["id"], "type": "module", "label": module["name"]})
        edges.append({"source": "repository:Framework_IOEM_Py", "target": module["id"], "relation": "contains", "confidence": "EXTRACTED"})
    for file in files:
        nodes.append({"id": file["id"], "type": "file", "label": file["path"], "priority": file["priority"]})
        edges.append({"source": file["module"], "target": file["id"], "relation": "contains", "confidence": "EXTRACTED"})
        for symbol in file["symbols"]:
            symbol_id = f"symbol:{file['path']}:{symbol['name']}"
            nodes.append({"id": symbol_id, "type": symbol["kind"], "label": symbol["name"], "source_location": symbol["location"]})
            edges.append({"source": file["id"], "target": symbol_id, "relation": "declares", "confidence": "EXTRACTED"})
        for relationship in file["relationships"]:
            target_id = f"external:{relationship['target']}"
            nodes.append({"id": target_id, "type": "external_symbol", "label": relationship["target"]})
            edges.append(
                {
                    "source": file["id"],
                    "target": target_id,
                    "relation": relationship["relation"],
                    "confidence": relationship["confidence"],
                    "source_location": relationship["source_location"],
                }
            )
    deduped_nodes = {node["id"]: node for node in nodes}
    deduped_edges = {(edge["source"], edge["target"], edge["relation"], edge.get("source_location")): edge for edge in edges}
    return {"nodes": list(deduped_nodes.values()), "edges": list(deduped_edges.values())}


def _ignore_summary(root: Path) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for child in root.iterdir():
        if child.name in IGNORED_PREFIXES:
            counts[child.name] = sum(1 for _ in child.rglob("*") if _.is_file()) if child.is_dir() else 1
    return dict(sorted(counts.items()))


def _source_baseline(paths: Iterable[Path]) -> dict[str, int]:
    byte_count = 0
    word_count = 0
    for path in paths:
        byte_count += path.stat().st_size
        word_count += len(path.read_text(encoding="utf-8", errors="ignore").split())
    return {
        "source_bytes": byte_count,
        "source_words": word_count,
        "estimated_raw_tokens": max(1, round(word_count * 1.3)),
    }


def build_memory_graph(root: str | Path = ".", output_dir: str | Path = DEFAULT_OUTPUT_DIR) -> dict[str, Any]:
    root_path = Path(root).expanduser().resolve()
    output_path = Path(output_dir).expanduser()
    if not output_path.is_absolute():
        output_path = root_path / output_path
    output_path.mkdir(parents=True, exist_ok=True)
    graph_path = output_path / "memory-graph.json"
    manifest_path = output_path / "memory-manifest.json"
    previous_graph = _read_json(graph_path, {"files": []})
    previous_manifest = _read_json(manifest_path, {"files": {}})
    previous_files = {file.get("path"): file for file in previous_graph.get("files", []) if isinstance(file, dict) and isinstance(file.get("path"), str)}
    previous_hashes = previous_manifest.get("files", {}) if isinstance(previous_manifest, dict) else {}

    selected = _selected_files(root_path)
    source_baseline = _source_baseline(selected)
    files: list[dict[str, Any]] = []
    changed = 0
    reused = 0
    current_hashes: dict[str, str] = {}
    for path in selected:
        relative = path.relative_to(root_path).as_posix()
        file_hash = _sha256(path)
        current_hashes[relative] = file_hash
        if previous_hashes.get(relative) == file_hash and relative in previous_files:
            files.append(previous_files[relative])
            reused += 1
            continue
        files.append(_analyze_file(root_path, path, file_hash))
        changed += 1

    modules = _modules(files)
    graph = _graph(files, modules)
    repository = _repository_summary(files)
    estimated_memory_tokens = _token_estimate(repository) + sum(file["summary_token_estimate"] for file in files) + sum(module["summary_token_estimate"] for module in modules)
    budget = {
        "estimated_tokens": estimated_memory_tokens,
        **source_baseline,
        "memory_percent_of_raw_token_baseline": round((estimated_memory_tokens / source_baseline["estimated_raw_tokens"]) * 100, 4),
        "selected_files": len(files),
        "stored_symbol_count": sum(len(file["symbols"]) for file in files),
        "stored_relationship_count": len(graph["edges"]),
        "raw_code_stored": False,
        "semantic_agent_tokens": 0,
        "target": "AST-only compact architecture memory",
    }
    payload = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": _utc_now(),
        "repository": repository,
        "scope": {
            "priority_paths": list(PRIORITY_PATHS),
            "ignored_prefixes": sorted(IGNORED_PREFIXES),
            "ignored_file_counts": _ignore_summary(root_path),
            "selection_policy": "High-priority shared libraries, tools, skill engines, and project configuration; no generated tests, exports, logs, crash curves, raw documents, or vendor/build artifacts.",
        },
        "modules": modules,
        "files": files,
        "graph": graph,
        "budget": budget,
        "incremental": {"changed_files": changed, "reused_files": reused, "removed_files": sorted(set(previous_files) - set(current_hashes))},
        "limitations": [
            "AST-only graph; data flow, event flow, and behavioral contracts require targeted source/log/DBC retrieval.",
            "No raw source code, function bodies, docstrings, or semantic-agent summaries are stored.",
            "Generated scripts, tests, logs, documents, and data are excluded from the compact graph by design.",
        ],
    }
    _write_json(graph_path, payload)
    _write_json(
        manifest_path,
        {
            "schema_version": SCHEMA_VERSION,
            "generated_at": _utc_now(),
            "root": str(root_path),
            "files": current_hashes,
            "selection_count": len(current_hashes),
        },
    )
    report = "\n".join(
        [
            "# Compact Graphify Memory Report",
            "",
            f"- Selected architecture files: {budget['selected_files']}",
            f"- Changed files analyzed: {changed}",
            f"- Unchanged files reused: {reused}",
            f"- Stored symbols: {budget['stored_symbol_count']}",
            f"- Stored relationships: {budget['stored_relationship_count']}",
            f"- Estimated memory tokens: {budget['estimated_tokens']}",
            f"- Estimated raw-source token baseline: {budget['estimated_raw_tokens']}",
            f"- Memory percentage of raw baseline: {budget['memory_percent_of_raw_token_baseline']}%",
            "- Raw code stored: no",
            "- Semantic-agent tokens used: 0",
            "",
            "## Retrieval",
            "1. Traverse `graph.nodes` and `graph.edges` to select modules/files/symbols.",
            "2. Load only the referenced source file and source location when implementation detail is needed.",
            "3. Treat AST relationships as structural evidence; use targeted sources for behavioral claims.",
        ]
    )
    (output_path / "MEMORY_REPORT.md").write_text(report + "\n", encoding="utf-8")
    return payload


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build an incremental, low-token Graphify AST memory graph.")
    parser.add_argument("--root", default=".", help="Repository root")
    parser.add_argument("--output", default=DEFAULT_OUTPUT_DIR, help="Output directory relative to root unless absolute")
    return parser


def main() -> int:
    args = build_argument_parser().parse_args()
    payload = build_memory_graph(args.root, args.output)
    print(json.dumps({"output": str(Path(args.output)), "budget": payload["budget"], "incremental": payload["incremental"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())