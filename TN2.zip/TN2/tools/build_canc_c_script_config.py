"""Emit the CAN-C EDR script configuration from the generated specification.

Every case in the common EDR CAN-C specification becomes one entry in
`projects/<project>/config/canc_c_config.py`. Test scripts are generated from that
config rather than from the workbook, so the spec and the scripts cannot drift.

Offline only: reads the DRBFM/DBC/config evidence through the specification generator
and writes one Python config file. No CAN traffic, no ECU access, no bench state.

Usage:
    py -3.14 tools/build_canc_c_script_config.py [--project U171] [--variant U171]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "tests"))
sys.path.insert(0, str(REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "scripts"))

import test_common_edr_canc_specification as spec  # noqa: E402

# Which generated variant supplies the vectors for each project configuration.
PROJECT_VARIANTS = {"U171": "U171", "M310_M314_M110": "M314"}


def _points_for(plan: spec.PlannedCase, variant: str) -> list[dict[str, Any]]:
    """Rebuild the sample array behind a case so scripts drive the same values."""
    route = plan.route_by_variant.get(variant)
    if route is None or route.get("dbc") is None:
        return []
    metadata = route["dbc"]
    if plan.fault_mode:
        decision = spec.onfail_decision(route, plan.fault_mode)
        points = spec.onfail_recording_points(
            plan.element, metadata, variant, plan.timing_scope, decision=decision
        )
    else:
        points = spec.nominal_recording_points(plan.element, metadata, variant, snapshot_sweep=True)
    return [
        {
            "t_s": round(float(point["recording_time_s"]), 4),
            "in_hex": point["input_raw_hex"],
            "in_phys": point["input_physical_value"],
            "exp_hex": point["expected_recorded_raw_hex"],
            "exp_phys": point["expected_recorded_physical_value"],
            "state": point["fault_state"],
        }
        for point in points
    ]


def build_entries(variant: str) -> list[dict[str, Any]]:
    contexts = {name: spec.load_variant_context(name) for name in ("U171", "M314")}
    matrix = spec.build_route_matrix(spec.load_drbfm_analysis(), contexts)
    entries = []
    for plan in spec.build_case_plans(matrix):
        if variant not in plan.variant_keys:
            continue
        route = plan.route_by_variant.get(variant)
        metadata = None if route is None else route.get("dbc")
        entries.append(
            {
                "name": plan.name,
                "applicability": plan.applicability,
                "status": plan.status,
                "category": plan.category,
                "parameter": plan.element.parameter_name,
                "drbfm_row": plan.element.source_row,
                "fault_mode": plan.fault_mode,
                "timing_scope": plan.timing_scope,
                "exception_category": plan.exception_category,
                "can_wakeup": plan.can_wakeup,
                "recording_iterations": len(_points_for(plan, variant)) if spec.recording_model(plan.element) != "interval" else 1,
                "pre_action": plan.pre_action,
                "post_action": plan.post_action,
                "steps": [{"action": step.action, "expected": step.expected_result} for step in plan.steps],
                "frame": None if metadata is None else metadata["message"],
                "signal": None if metadata is None else metadata["signal"],
                "key_frame": None if route is None else route.get("key_frame"),
                "carrying_frame": None if route is None else route.get("carrying_frame"),
                "integrity_signals": list((route or {}).get("integrity_signals") or ()),
                "factor": None if metadata is None else metadata["factor"],
                "offset": None if metadata is None else metadata["offset"],
                "unit": None if metadata is None else metadata["unit"],
                "bit_length": None if metadata is None else metadata["bit_length"],
                "dtc_codes": list(((route or {}).get("faults") or {}).get(plan.fault_mode or "", ())),
                "dtc_status": spec._dtc_status_byte(plan.fault_mode or "", plan.timing_scope),
                "recording_model": spec.recording_model(plan.element),
                "points": _points_for(plan, variant),
            }
        )
    return entries


HEADER = '''"""CAN-C EDR script configuration for {project}.

GENERATED FILE - do not edit by hand.
Rebuild with: py -3.14 tools/build_canc_c_script_config.py --project {project}

Source of truth is the common EDR CAN-C specification generator
(tests/test_common_edr_canc_specification.py), which derives every value from the
DRBFM analysis sheet, the project DBC, canc_config, and the on-fail recording workbook.

Each entry in CANC_C_CASES drives exactly one test script:

  name              Test case name, matching the specification workbook row.
  applicability     ICE, EV, or Both.
  status            IN REVIEW cases are executable; ON HOLD cases await source evidence.
  fault_mode        None for nominal, else node_absent / message_timeout /
                    message_content / signal_content / signal_never_received /
                    variant_code_error.
  timing_scope      full, pre, or post. Pre/post only exist where the parameter has a
                    recording interval and the fault can be applied to one side of T0.
  key_frame         Frame to stop for node absent.
  carrying_frame    Frame carrying the simulated signal.
  non_key_timeout_frame
                    Configured non-key frame to stop for message timeout. It must match
                    carrying_frame for a conventional last-valid scenario. A different
                    same-node frame is retained only as an explicit consumed-value
                    exception and requires source-owned review evidence.
  integrity_signals CRC / alive counter signals to break for message content failure.
  dtc_codes         Configuration-backed CAN DTC bytes; dtc_status is the expected
                    status byte (0B active, 08 for UV/OV and for pre-crash-healed).
  points            Ordered sample array: recording time, input and expected raw hex,
                    physical values, and the fault state at that sample.

Drive the array continuously against the sampling grid with the crash trigger at T0.
Do not insert any wait or sleep between samples, and read DTC only after the recording
interval has completed and the fault qualification time has elapsed.
"""

PROJECT_NAME = "{project}"
MODULE_NAME = "EDR_CANC"
SOURCE_VARIANT = "{variant}"

'''


def render(project: str, variant: str, entries: list[dict[str, Any]]) -> str:
    import pprint

    counts: dict[str, int] = {}
    for entry in entries:
        counts[entry["status"]] = counts.get(entry["status"], 0) + 1
    lines = [HEADER.format(project=project, variant=variant)]
    lines.append(f"CASE_COUNT = {len(entries)}\n")
    lines.append(f"STATUS_COUNTS = {pprint.pformat(dict(sorted(counts.items())))}\n\n")
    lines.append("CANC_C_CASES = ")
    lines.append(pprint.pformat(entries, width=118, sort_dicts=False))
    lines.append("\n\n")
    lines.append(
        "EXECUTABLE_CASES = [case for case in CANC_C_CASES if case['status'] == 'IN REVIEW']\n"
        "CASES_BY_NAME = {case['name']: case for case in CANC_C_CASES}\n"
    )
    return "".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", default="U171", choices=sorted(PROJECT_VARIANTS))
    parser.add_argument("--output", type=Path, default=None)
    arguments = parser.parse_args()

    variant = PROJECT_VARIANTS[arguments.project]
    entries = build_entries(variant)
    output = arguments.output or REPOSITORY_ROOT / "projects" / arguments.project / "config" / "canc_c_config.py"
    output.write_text(render(arguments.project, variant, entries), encoding="utf-8")

    executable = sum(1 for entry in entries if entry["status"] == "IN REVIEW")
    print(f"Wrote {output}")
    print(f"  cases      : {len(entries)} ({executable} executable, {len(entries) - executable} on hold)")
    print(f"  with arrays: {sum(1 for entry in entries if entry['points'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
