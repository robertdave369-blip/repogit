from __future__ import annotations

import argparse
import csv
import importlib.util
import re
import sys
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter


def load_mapping_module(script_path: Path):
    spec = importlib.util.spec_from_file_location("legacy_map", script_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load mapping module from {script_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def build_output_headers(source_headers: list[Any]) -> list[Any]:
    headers = list(source_headers)
    if not headers or headers[0] != "ID":
        headers.insert(0, "ID")
    if "_TestTechnique" not in headers:
        headers.append("_TestTechnique")
    return headers


def should_remove_case(case) -> bool:
    text = f"{case.title or ''} {case.objective or ''}".lower()
    checks_raw_physical = any(marker in text for marker in ["decoding of", "raw to physical", "physical value"])
    checks_crc_mac = any(marker in text for marker in [" crc", "_crc", " truncated_mac", " mac", "freshness"])
    return checks_raw_physical and checks_crc_mac


def renumber_test_case_id(test_case_id: str, serial_number: int) -> str:
    return re.sub(r"TestCase\d+$", f"TestCase{serial_number}", test_case_id)


def build_case_blocks(source_ws, sheet_cases):
    ordered_cases = sorted(sheet_cases, key=lambda case: case.row_start)
    blocks = []
    for index, case in enumerate(ordered_cases):
        end_row = ordered_cases[index + 1].row_start - 1 if index + 1 < len(ordered_cases) else source_ws.max_row
        blocks.append((case, case.row_start, end_row))
    return blocks


def force_score_match(mapping_module, current_case, legacy_case) -> float:
    if current_case.group != legacy_case.group:
        return -1.0

    current_text = mapping_module.normalize_text(current_case.combined_text)
    legacy_text = mapping_module.normalize_text(legacy_case.combined_text)
    current_message = mapping_module.normalize_text(current_case.message)
    legacy_message = mapping_module.normalize_text(legacy_case.message) if legacy_case.message else ""
    current_base_intent = mapping_module.base_intent(current_case.intent)
    legacy_base_intent = mapping_module.base_intent(legacy_case.intent)

    score = 0.0

    if legacy_message == current_message:
        score += 40.0
    elif current_message and current_message in legacy_text:
        score += 32.0

    if current_case.intent and legacy_case.intent and current_case.intent == legacy_case.intent:
        score += 45.0
    elif current_base_intent and legacy_base_intent and current_base_intent == legacy_base_intent:
        score += 35.0

    if current_case.signal_name and legacy_case.signal_name:
        if current_case.signal_name == legacy_case.signal_name:
            score += 45.0
        elif current_base_intent == "scf":
            score -= 20.0

    if current_case.intent in {"priority_scf_mcf", "priority_scf_na"} and "priority" in legacy_text:
        score += 50.0

    if current_case.intent == "normal_reception" and any(marker in legacy_text for marker in ["message is received", "periodicity shall be around", "message_"]):
        score += 48.0

    if current_case.signal_name and current_case.signal_name in legacy_case.combined_text:
        score += 20.0

    if any(marker in current_text for marker in ["alive counter behavior", "integrity field behavior", "truncated_freshness_value", "truncated_mac"]):
        if any(marker in legacy_text for marker in ["alive", "alv", "counter", "message content failure", "crc", "message is received", "periodicity shall be around", "message_"]):
            score += 28.0

    if any(marker in current_text for marker in ["decoding of", "raw to physical", "physical value"]):
        if current_case.signal_name and legacy_case.signal_name == current_case.signal_name:
            score += 34.0
        elif any(marker in legacy_text for marker in ["signal content failure", "message is received", "periodicity shall be around", "message_"]):
            score += 18.0

    current_keywords = current_case.keywords
    legacy_keywords = legacy_case.keywords
    score += 4.0 * len(current_keywords & legacy_keywords)

    token_overlap = mapping_module.tokenize(current_case.combined_text) & mapping_module.tokenize(legacy_case.combined_text)
    score += min(len(token_overlap), 12) * 2.0

    ratio = mapping_module.SequenceMatcher(None, current_text, legacy_text).ratio()
    score += ratio * 26.0

    return score


def force_fill_matches(mapping_module, current_cases, legacy_cases, matches):
    final_matches = dict(matches)
    used_legacy_ids = {legacy_case.artifact_id for legacy_case in final_matches.values()}
    available_current_cases = [case for case in current_cases if (case.sheet, case.row_start) not in final_matches and not should_remove_case(case)]
    remaining_legacy_cases = [case for case in legacy_cases if case.artifact_id not in used_legacy_ids]

    candidates = []
    for current_case in available_current_cases:
        for legacy_case in remaining_legacy_cases:
            score = force_score_match(mapping_module, current_case, legacy_case)
            candidates.append((score, current_case, legacy_case))

    candidates.sort(key=lambda item: item[0], reverse=True)

    for _, current_case, legacy_case in candidates:
        current_key = (current_case.sheet, current_case.row_start)
        if current_key in final_matches or legacy_case.artifact_id in used_legacy_ids:
            continue
        final_matches[current_key] = legacy_case
        used_legacy_ids.add(legacy_case.artifact_id)

    return final_matches, used_legacy_ids


def update_report_rows(report_rows, final_matches):
    updated_rows = []
    for row in report_rows:
        key = (str(row["sheet"]), int(row["row_start"]))
        assigned_legacy = final_matches.get(key)
        if assigned_legacy is not None:
            row["matched_legacy_id"] = assigned_legacy.artifact_id
            row["matched_legacy_name"] = assigned_legacy.name
            row["matched_legacy_description"] = assigned_legacy.description
            row["technique"] = assigned_legacy.technique
            row["accepted"] = "Y"
        else:
            row["accepted"] = ""
        updated_rows.append(row)
    return updated_rows


def write_sheet_workbook(source_ws, output_path: Path, sheet_matches: dict[tuple[str, int], Any], sheet_cases) -> tuple[int, int, int]:
    source_headers = [source_ws.cell(row=1, column=column).value for column in range(1, source_ws.max_column + 1)]
    output_headers = build_output_headers(source_headers)
    header_to_column = {value: index for index, value in enumerate(output_headers)}

    test_case_idx_out = header_to_column["Test Case ID"]
    id_idx_out = header_to_column["ID"]
    technique_idx_out = header_to_column["_TestTechnique"]

    has_source_id = bool(source_headers and source_headers[0] == "ID")
    has_source_technique = "_TestTechnique" in source_headers

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = source_ws.title
    worksheet.freeze_panes = "A2"
    worksheet.append(output_headers)

    accepted = 0
    blank = 0
    removed = 0
    case_serial = 1

    for case, start_row, end_row in build_case_blocks(source_ws, sheet_cases):
        if should_remove_case(case):
            removed += 1
            continue

        match = sheet_matches.get((case.sheet, case.row_start))
        if match is not None:
            accepted += 1
        else:
            blank += 1

        for row_number in range(start_row, end_row + 1):
            row_values = [source_ws.cell(row=row_number, column=column).value for column in range(1, source_ws.max_column + 1)]
            output_values = list(row_values)

            if not has_source_id:
                output_values.insert(0, None)
            if not has_source_technique:
                output_values.append(None)

            if row_number == start_row:
                output_values[test_case_idx_out] = renumber_test_case_id(str(output_values[test_case_idx_out]), case_serial)
                output_values[id_idx_out] = match.artifact_id if match is not None else None
                if match is not None:
                    output_values[technique_idx_out] = match.technique or output_values[technique_idx_out]
            worksheet.append(output_values)

        case_serial += 1

    for column_index in range(1, worksheet.max_column + 1):
        max_length = 0
        for row_index in range(1, worksheet.max_row + 1):
            value = worksheet.cell(row=row_index, column=column_index).value
            if value is None:
                continue
            max_length = max(max_length, len(str(value)))
        worksheet.column_dimensions[get_column_letter(column_index)].width = min(max(max_length + 2, 12), 80)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output_path)
    return accepted, blank, removed


def write_sheet_report(report_rows: list[dict[str, object]], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "sheet",
                "row_start",
                "test_case_id",
                "title",
                "matched_legacy_id",
                "matched_legacy_name",
                "matched_legacy_description",
                "score",
                "second_score",
                "accepted",
                "technique",
            ],
            delimiter="\t",
        )
        writer.writeheader()
        writer.writerows(report_rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Export node-wise workbooks with legacy IDs applied.")
    parser.add_argument("--current", required=True, help="Path to the current multi-sheet workbook.")
    parser.add_argument("--legacy-dir", required=True, help="Folder containing node-wise legacy export workbooks.")
    parser.add_argument("--output-dir", required=True, help="Folder where node-wise workbooks will be written.")
    parser.add_argument("--mapping-script", default=str(Path(__file__).with_name("update_canc_workbook_with_legacy_ids.py")), help="Path to the legacy ID mapping script.")
    args = parser.parse_args()

    current_path = Path(args.current)
    legacy_dir = Path(args.legacy_dir)
    output_dir = Path(args.output_dir)
    report_dir = output_dir / "reports"

    mapping_module = load_mapping_module(Path(args.mapping_script))
    current_cases, known_messages = mapping_module.parse_current_cases(current_path)
    source_workbook = load_workbook(current_path, read_only=False, data_only=False)

    summary_rows: list[dict[str, object]] = []

    legacy_files = sorted(
        path
        for path in legacy_dir.glob("*.xlsx")
        if path.name.lower() != "canc_legacy_testcases_all.xlsx"
    )

    for legacy_file in legacy_files:
        legacy_cases = mapping_module.parse_legacy_cases(legacy_file, known_messages)
        matches, report_rows = mapping_module.compute_matches(current_cases, legacy_cases)
        legacy_groups = {case.group for case in legacy_cases}
        relevant_sheets = [sheet for sheet, group in mapping_module.GROUP_MAP.items() if group in legacy_groups and sheet in source_workbook.sheetnames]
        relevant_current_cases = [case for case in current_cases if case.sheet in relevant_sheets]
        final_matches, used_legacy_ids = force_fill_matches(mapping_module, relevant_current_cases, legacy_cases, matches)
        updated_report_rows = update_report_rows(report_rows, final_matches)
        legacy_unmapped = len({case.artifact_id for case in legacy_cases} - used_legacy_ids)

        for sheet_name in relevant_sheets:
            sheet_matches = {key: value for key, value in final_matches.items() if key[0] == sheet_name}
            sheet_report_rows = [row for row in updated_report_rows if row["sheet"] == sheet_name]
            sheet_cases = [case for case in current_cases if case.sheet == sheet_name]
            accepted, blank, removed = write_sheet_workbook(
                source_workbook[sheet_name],
                output_dir / f"{sheet_name}.xlsx",
                sheet_matches,
                sheet_cases,
            )
            write_sheet_report(sheet_report_rows, report_dir / f"{sheet_name}_mapping.tsv")
            summary_rows.append(
                {
                    "sheet": sheet_name,
                    "legacy_file": legacy_file.name,
                    "accepted": accepted,
                    "blank": blank,
                    "removed": removed,
                    "legacy_unmapped": legacy_unmapped,
                    "output_workbook": f"{sheet_name}.xlsx",
                    "report": f"reports/{sheet_name}_mapping.tsv",
                }
            )

    summary_path = output_dir / "summary.tsv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["sheet", "legacy_file", "accepted", "blank", "removed", "legacy_unmapped", "output_workbook", "report"],
            delimiter="\t",
        )
        writer.writeheader()
        writer.writerows(summary_rows)

    print(f"Created {len(summary_rows)} node-wise workbooks in {output_dir}")
    print(f"Summary: {summary_path}")


if __name__ == "__main__":
    main()
