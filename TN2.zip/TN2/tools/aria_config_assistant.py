from __future__ import annotations

import argparse
import ast
import configparser
import copy
import json
import re
import shutil
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import xml.etree.ElementTree as ET

try:
    import openpyxl  # type: ignore
except ImportError:  # pragma: no cover - dependency is optional at import time
    openpyxl = None  # type: ignore


REPO_ROOT = Path(__file__).resolve().parents[1]
DOCS_ROOT = REPO_ROOT / "docs" / "aria_config_assistant"
KNOWLEDGE_BASE_PATH = DOCS_ROOT / "knowledge-base.json"
TEMPLATES_PATH = DOCS_ROOT / "templates.json"

DEFAULT_PACKAGE_ROOT = Path(r"C:\AriaConfigFiles_Generic\AriaConfigFiles")
DEFAULT_OG_ROOT = Path(r"V:\IN01\DataLake\RCS_IOEM\Christy\Others\OG")
DEFAULT_CORPUS_ROOTS = [
    Path(r"C:\AriaConfigFiles_Generic"),
    Path(r"C:\ARIA5.20"),
    DEFAULT_OG_ROOT,
]

TEXT_SEARCH_EXTENSIONS = {
    ".accf",
    ".cfg",
    ".cs",
    ".json",
    ".ini",
    ".md",
    ".py",
    ".rsu",
    ".rsux",
    ".sym",
    ".txt",
    ".xml",
    ".xaml",
}

PROJECT_REFERENCE_PATTERNS = {
    "rsuWorkbook": ("Config_folder", "RSU", "XLS"),
    "loadboxPackage": ("AriaMain_accdata", "Loadbox"),
    "loadboxProfile": ("AriaMain_accdata", "Loadbox"),
    "dbcFiles": ("DBC",),
}

BUNDLE_FILE_NAMES = (
    "AriaMain.json",
    "ChassisConfig.json",
    "CanConfig.json",
    "LinConfig.json",
    "FlexrayConfig.json",
    "SensorsConfig.json",
)

_UNSUPPORTED = object()


def windows_path(value: Path | str) -> str:
    return str(value).replace("/", "\\")


def is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def coerce_jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return windows_path(value)
    if isinstance(value, dict):
        return {key: coerce_jsonable(item) for key, item in value.items()}
    if isinstance(value, list):
        return [coerce_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [coerce_jsonable(item) for item in value]
    return str(value)


def make_issue(
    severity: str,
    code: str,
    message: str,
    *,
    path: str | None = None,
    evidence: str | None = None,
) -> dict[str, Any]:
    issue: dict[str, Any] = {
        "severity": severity,
        "code": code,
        "message": message,
    }
    if path:
        issue["path"] = path
    if evidence:
        issue["evidence"] = evidence
    return issue


def load_json_file(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def load_knowledge_base() -> dict[str, Any]:
    return load_json_file(KNOWLEDGE_BASE_PATH)


def load_templates() -> dict[str, Any]:
    return load_json_file(TEMPLATES_PATH)


def load_template_files(name: str) -> dict[str, Any]:
    templates = load_templates().get("templates", [])
    for template in templates:
        if template.get("name") == name:
            return copy.deepcopy(template.get("files", {}))
    raise KeyError(f"Template not found: {name}")


def discover_install_roots() -> list[Path]:
    root = Path("C:\\")
    installs = [path for path in root.glob("ARIA*") if path.is_dir()]
    return sorted(installs)


def detect_category(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".json", ".json_old"}:
        return "json"
    if suffix == ".ini":
        return "ini"
    if suffix == ".accf":
        return "accf"
    if suffix == ".xml":
        return "xml"
    if suffix == ".pdf":
        return "pdf"
    if suffix == ".docx":
        return "docx"
    if suffix in {".xls", ".xlsx", ".xlsm"}:
        return "workbook"
    if suffix == ".dbc":
        return "dbc"
    return "other"


def normalize_header(value: Any) -> str:
    text = "" if value is None else str(value).strip().lower()
    text = text.replace("\n", " ").replace("\r", " ")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def ensure_openpyxl() -> None:
    if openpyxl is None:
        raise RuntimeError(
            "openpyxl is required for workbook inspection. Install openpyxl in the active Python environment."
        )


def read_sheet_rows(sheet: Any) -> list[list[Any]]:
    rows: list[list[Any]] = []
    for row in sheet.iter_rows(values_only=True):
        rows.append(list(row))
    return rows


def find_header_row(rows: list[list[Any]], required_headers: set[str]) -> tuple[int | None, list[str]]:
    for index, row in enumerate(rows):
        headers = [normalize_header(item) for item in row]
        if required_headers.issubset(set(headers)):
            return index, headers
    return None, []


def trim_sample_rows(rows: list[list[Any]], limit: int = 8) -> list[list[Any]]:
    samples: list[list[Any]] = []
    for row in rows:
        if any(value not in (None, "") for value in row):
            samples.append(row)
        if len(samples) >= limit:
            break
    return samples


def summarize_sheet(rows: list[list[Any]]) -> dict[str, Any]:
    column_count = max((len(row) for row in rows), default=0)
    return {
        "row_count": len(rows),
        "column_count": column_count,
        "sample_rows": trim_sample_rows(rows),
    }


def inspect_harness_workbook(rows: list[list[Any]]) -> dict[str, Any]:
    header_index, headers = find_header_row(rows, {"slot", "card_type", "ch"})
    if header_index is None:
        return {}

    slot_index = headers.index("slot")
    card_type_index = headers.index("card_type")
    channel_index = headers.index("ch")
    variant_columns = [
        index
        for index, header in enumerate(headers[:slot_index])
        if header.endswith("variant")
    ]

    mapping_rows: list[dict[str, Any]] = []
    previous_slot: Any = None
    previous_card_type: Any = None
    previous_card_type_sc2: Any = None
    previous_channel: Any = None

    for row in rows[header_index + 1 :]:
        if not any(value not in (None, "") for value in row):
            continue

        padded = list(row) + [None] * max(0, len(headers) - len(row))
        slot = padded[slot_index] if padded[slot_index] not in (None, "") else previous_slot
        card_type = padded[card_type_index] if padded[card_type_index] not in (None, "") else previous_card_type
        card_type_sc2 = None
        if "card_type_sc2" in headers:
            sc2_index = headers.index("card_type_sc2")
            card_type_sc2 = padded[sc2_index] if padded[sc2_index] not in (None, "") else previous_card_type_sc2
        channel = padded[channel_index] if padded[channel_index] not in (None, "") else previous_channel

        if slot in (None, "") or channel in (None, ""):
            continue

        row_data = {
            "slot": slot,
            "card_type": card_type,
            "card_type_sc2": card_type_sc2,
            "channel": channel,
            "zif_pin_feed": padded[headers.index("zif_pin_feed")] if "zif_pin_feed" in headers else None,
            "zif_pin_rtrn": padded[headers.index("zif_pin_rtrn")] if "zif_pin_rtrn" in headers else None,
            "master_ecu_pin": padded[headers.index("master_ecu_pin")] if "master_ecu_pin" in headers else None,
        }
        master_pin = "" if row_data["master_ecu_pin"] is None else str(row_data["master_ecu_pin"]).strip().lower()
        if (
            row_data["zif_pin_feed"] in (None, "")
            and row_data["zif_pin_rtrn"] in (None, "")
            and master_pin in {"", "-", "ecu pin"}
        ):
            continue
        if variant_columns:
            row_data["variants"] = {
                str(padded[index]).strip(): padded[index + 1]
                for index in variant_columns
                if index + 1 < len(padded) and padded[index] not in (None, "")
            }

        mapping_rows.append(coerce_jsonable(row_data))
        previous_slot = slot
        previous_card_type = card_type
        previous_card_type_sc2 = card_type_sc2
        previous_channel = channel

    slot_count = len({row["slot"] for row in mapping_rows})
    card_types = sorted({str(row["card_type"]) for row in mapping_rows if row.get("card_type") not in (None, "")})
    return {
        "workbook_type": "harness_mapping",
        "header_row": header_index + 1,
        "mapping_row_count": len(mapping_rows),
        "slot_count": slot_count,
        "card_types": card_types,
        "mapping_rows": mapping_rows[:120],
    }


def inspect_rsu_update_workbook(rows: list[list[Any]]) -> dict[str, Any]:
    if not rows:
        return {}
    first_row = rows[0]
    if not first_row or not all((value is None or "slot" in str(value).lower()) for value in first_row):
        return {}

    slot_labels = [str(value).strip() for value in first_row if value not in (None, "")]
    midpoint = len(slot_labels) // 2 if slot_labels and len(slot_labels) % 2 == 0 else None
    repeated_halves = bool(midpoint and slot_labels[:midpoint] == slot_labels[midpoint:])
    return {
        "workbook_type": "rsu_update",
        "slot_labels": slot_labels,
        "slot_count": midpoint if repeated_halves else len(slot_labels),
        "section_break_column": midpoint + 1 if repeated_halves else None,
        "data_row_count": max(len(rows) - 1, 0),
    }


def inspect_rsu_scenario_workbook(rows: list[list[Any]]) -> dict[str, Any]:
    for index, row in enumerate(rows):
        normalized = [str(value).strip().lower() for value in row if value not in (None, "")]
        if "rsu configuration" in normalized and "rsu startup" in normalized:
            config_index = next(
                idx for idx, value in enumerate(row) if str(value).strip().lower() == "rsu configuration"
            )
            startup_index = next(
                idx for idx, value in enumerate(row) if str(value).strip().lower() == "rsu startup"
            )
            populated = [idx for idx, value in enumerate(row) if value not in (None, "")]
            total_non_empty_columns = len(populated)
            startup_columns = total_non_empty_columns - 1 if startup_index > config_index else total_non_empty_columns
            return {
                "workbook_type": "rsu_scenario",
                "header_row": index + 1,
                "configuration_start_column": config_index + 1,
                "startup_start_column": startup_index + 1,
                "configuration_column_span": startup_index - config_index - 1,
                "total_non_empty_columns": total_non_empty_columns,
                "startup_column_estimate": startup_columns,
            }
    return {}


def inspect_spi_evt_workbook(sheet_rows: dict[str, list[list[Any]]]) -> dict[str, Any]:
    if "Properties" not in sheet_rows:
        return {}

    properties_rows = sheet_rows["Properties"]
    properties: dict[str, Any] = {}
    for row in properties_rows[:40]:
        if len(row) >= 2 and row[0] not in (None, ""):
            properties[str(row[0]).strip()] = row[1]

    register_sheets: list[dict[str, Any]] = []
    for sheet_name, rows in sheet_rows.items():
        header_index, headers = find_header_row(
            rows,
            {"register", "registeraddress"},
        )
        if header_index is None:
            continue
        register_sheets.append(
            {
                "sheet": sheet_name,
                "header_row": header_index + 1,
                "headers": headers,
            }
        )

    if not register_sheets:
        return {}

    return {
        "workbook_type": "spi_evt",
        "properties": coerce_jsonable(properties),
        "register_sheets": register_sheets,
    }


def inspect_loadbox_workbook(sheet_rows: dict[str, list[list[Any]]]) -> dict[str, Any]:
    expected = {"AFT_LOADBOX", "PTF_CONFIG", "TRACE_DATA", "HW_LOAD_TRANSLATION", "LOOK_UP_TABLES"}
    if not expected.intersection(sheet_rows.keys()):
        return {}

    return {
        "workbook_type": "loadbox",
        "sections": sorted(expected.intersection(sheet_rows.keys())),
    }


def inspect_eventmode_workbook(sheet_rows: dict[str, list[list[Any]]]) -> dict[str, Any]:
    expected = {"Instructions", "AVTS Properties", "Event Setup", "BUS Connections", "Results"}
    if not expected.intersection(sheet_rows.keys()):
        return {}

    return {
        "workbook_type": "event_mode",
        "sections": sorted(expected.intersection(sheet_rows.keys())),
    }


def inspect_workbook(path: Path) -> dict[str, Any]:
    ensure_openpyxl()
    workbook = openpyxl.load_workbook(path, data_only=False, read_only=True)  # type: ignore[arg-type]

    sheet_rows: dict[str, list[list[Any]]] = {}
    sheet_summaries: list[dict[str, Any]] = []
    for sheet_name in workbook.sheetnames:
        rows = read_sheet_rows(workbook[sheet_name])
        sheet_rows[sheet_name] = rows
        summary = summarize_sheet(rows)
        summary["name"] = sheet_name
        sheet_summaries.append(coerce_jsonable(summary))

    details = (
        inspect_harness_workbook(sheet_rows[workbook.sheetnames[0]])
        or inspect_rsu_update_workbook(sheet_rows[workbook.sheetnames[0]])
        or inspect_rsu_scenario_workbook(sheet_rows[workbook.sheetnames[0]])
        or inspect_spi_evt_workbook(sheet_rows)
        or inspect_loadbox_workbook(sheet_rows)
        or inspect_eventmode_workbook(sheet_rows)
        or {"workbook_type": "generic"}
    )

    return {
        "kind": "workbook",
        "path": windows_path(path),
        "sheet_count": len(workbook.sheetnames),
        "sheets": sheet_summaries,
        **coerce_jsonable(details),
    }


def extract_python_constant(node: ast.AST, known_values: dict[str, Any]) -> Any:
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.List):
        values = [extract_python_constant(item, known_values) for item in node.elts]
        return values if all(value is not _UNSUPPORTED for value in values) else _UNSUPPORTED
    if isinstance(node, ast.Tuple):
        values = [extract_python_constant(item, known_values) for item in node.elts]
        return tuple(values) if all(value is not _UNSUPPORTED for value in values) else _UNSUPPORTED
    if isinstance(node, ast.Dict):
        keys = [extract_python_constant(item, known_values) for item in node.keys]
        values = [extract_python_constant(item, known_values) for item in node.values]
        if any(item is _UNSUPPORTED for item in keys + values):
            return _UNSUPPORTED
        return dict(zip(keys, values))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        value = extract_python_constant(node.operand, known_values)
        return -value if value is not _UNSUPPORTED else _UNSUPPORTED
    if isinstance(node, ast.Name):
        return known_values.get(node.id, _UNSUPPORTED)
    return _UNSUPPORTED


def extract_python_assignments(path: Path) -> dict[str, Any]:
    module = ast.parse(path.read_text(encoding="utf-8"), filename=windows_path(path))
    values: dict[str, Any] = {}
    for node in module.body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        value = extract_python_constant(node.value, values)
        if value is _UNSUPPORTED:
            continue
        values[target.id] = value
    return values


def format_hex(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        text = value.strip()
        return text if text.lower().startswith("0x") else text
    if isinstance(value, int):
        return f"0x{value:X}"
    return str(value)


def resolve_reference(
    bundle_root: Path,
    value: Any,
    *,
    config_folder: str | None = None,
    rsu_xml_mode: bool = False,
) -> Path | None:
    if value in (None, "", "default"):
        return None

    text = str(value)
    candidate = Path(text)
    if candidate.is_absolute():
        return candidate

    if rsu_xml_mode and config_folder:
        rsu_candidate = bundle_root / config_folder / "RSU" / "XML" / text
        if rsu_candidate.exists():
            return rsu_candidate

    return bundle_root / text


def find_file_references(value: object) -> list[str]:
    references: list[str] = []
    if isinstance(value, dict):
        for nested in value.values():
            references.extend(find_file_references(nested))
        return references
    if isinstance(value, list):
        for nested in value:
            references.extend(find_file_references(nested))
        return references
    if not isinstance(value, str):
        return references

    lowered = value.lower()
    if any(
        token in lowered
        for token in (
            ".accf",
            ".crt",
            ".dbc",
            ".dll",
            ".json",
            ".ldbx",
            ".pdf",
            ".sym",
            ".xaml",
            ".xls",
            ".xlsx",
            ".xlsm",
            ".xml",
        )
    ):
        references.append(value)
    return references


def load_baseline_bundle(source_root: Path | None) -> tuple[dict[str, Any], Path | None]:
    if source_root is None:
        return load_template_files("minimal-json-bundle"), None

    bundle_files: dict[str, Any] = {}
    for file_name in BUNDLE_FILE_NAMES:
        file_path = source_root / file_name
        if file_path.exists():
            bundle_files[file_name] = load_json_file(file_path)
    if not bundle_files:
        return load_template_files("minimal-json-bundle"), None
    return bundle_files, source_root


def infer_known_project_keys(package_root: Path | None, og_root: Path | None) -> set[str]:
    keys: set[str] = set()
    if package_root and package_root.exists():
        for pattern in (
            package_root / "Config_folder" / "RSU" / "XLS",
            package_root / "DBC",
        ):
            if pattern.exists():
                keys.update(path.name.upper() for path in pattern.iterdir() if path.is_dir())
        loadbox_root = package_root / "AriaMain_accdata" / "Loadbox"
        if loadbox_root.exists():
            for path in loadbox_root.iterdir():
                if path.is_dir():
                    keys.add(path.name.upper())
                elif path.suffix.lower() == ".ldbx":
                    keys.add(path.stem.upper())
    if og_root and og_root.exists():
        keys.update({"W616", "Z121", "UPP_EV"})
    return keys


def infer_project_key_from_text(text: str, known_keys: set[str]) -> str | None:
    upper = text.upper()
    for key in sorted(known_keys, key=len, reverse=True):
        if key and key in upper:
            return key
    return None


def score_project_key_in_text(text: str, project_key: str) -> int:
    upper = text.upper()
    key = project_key.upper()
    if not key or key not in upper:
        return 0

    score = upper.count(key)
    emphasized_patterns = (
        f"\\{key}\\",
        f"_{key}_",
        f"-{key}-",
        f"{key}.",
        f"\\{key}.",
        f"ARIACONFIGFILES_{key}",
        f"CONFIG_FOLDER\\RSU\\XLS\\{key}\\",
        f"DBC\\{key}\\",
        f"LOADBOX\\{key}",
    )
    for pattern in emphasized_patterns:
        if pattern in upper:
            score += 4
    if upper.endswith(key) or upper.startswith(key):
        score += 2
    return score


def infer_project_key(
    requested_key: str | None,
    *,
    bundle_root: Path,
    source_values: list[str],
    package_root: Path | None,
    og_root: Path | None,
) -> str | None:
    if requested_key:
        return requested_key.upper()

    known_keys = infer_known_project_keys(package_root, og_root)
    known_keys.update(path.name.upper() for path in (REPO_ROOT / "projects").iterdir() if path.is_dir())

    scores: Counter[str] = Counter()
    for value in source_values:
        for project_key in known_keys:
            weight = score_project_key_in_text(value, project_key)
            if weight:
                scores[project_key] += weight

    if scores:
        best_score = max(scores.values())
        best_keys = [key for key, score in scores.items() if score == best_score]
        return sorted(best_keys, key=len, reverse=True)[0]

    bundle_name = infer_project_key_from_text(bundle_root.name, known_keys)
    return bundle_name


def discover_project_assets(
    package_root: Path,
    project_key: str | None,
    *,
    og_root: Path | None = None,
) -> dict[str, Any]:
    if not project_key:
        return {}

    project_key = project_key.upper()
    assets: dict[str, Any] = {"project_key": project_key}

    rsu_root = package_root / "Config_folder" / "RSU" / "XLS" / project_key
    if rsu_root.exists():
        assets["rsuWorkbook"] = [
            windows_path(path)
            for path in sorted(rsu_root.glob("*.xls*"))
            if path.is_file()
        ]

    loadbox_root = package_root / "AriaMain_accdata" / "Loadbox"
    if loadbox_root.exists():
        loadbox_candidates = [
            path
            for path in loadbox_root.iterdir()
            if path.is_file() and project_key in path.stem.upper()
        ]
        if loadbox_candidates:
            assets["loadboxAssets"] = [windows_path(path) for path in sorted(loadbox_candidates)]

    dbc_root = package_root / "DBC" / project_key
    if dbc_root.exists():
        assets["dbcFiles"] = [
            windows_path(path)
            for path in sorted(dbc_root.glob("*.dbc"))
            if path.is_file()
        ]

    if og_root and og_root.exists():
        harness_candidates = [
            og_root / "ARIA_Harness.xlsx",
            og_root / "Common_Harness.xlsx",
            og_root / "Common_Harness_IOEM.xlsx",
        ]
        assets["harnessWorkbooks"] = [
            windows_path(path) for path in harness_candidates if path.exists()
        ]
        rsu_update = og_root / "EXCEL_Sheet_update_RSU.xlsx"
        if rsu_update.exists():
            assets["rsuUpdateWorkbook"] = windows_path(rsu_update)

    try:
        templates = load_templates().get("templates", [])
    except Exception:
        templates = []
    for template in templates:
        if template.get("name") != "project-root-autoload-pack":
            continue
        project_package = template.get("projectPackage", {}).get(project_key, {})
        asset_set = project_package.get("assetSet", {})
        if asset_set:
            assets["templateAssetSet"] = asset_set
        break

    return assets


def add_artifact(
    artifacts: list[dict[str, Any]],
    *,
    name: str,
    kind: str,
    source_file: str,
    original_value: Any,
    resolved_path: Path | None,
    required: bool,
    bundle_relative_path: str | None = None,
    project_key: str | None = None,
) -> None:
    artifact = {
        "name": name,
        "kind": kind,
        "source_file": source_file,
        "original_value": original_value,
        "required": required,
        "resolved_path": windows_path(resolved_path) if resolved_path else None,
        "exists": resolved_path.exists() if resolved_path else False,
        "bundle_relative_path": bundle_relative_path,
        "project_key": project_key,
    }
    artifacts.append(artifact)


def summarize_ldbx(path: Path) -> dict[str, Any]:
    content = json.loads(path.read_text(encoding="utf-8-sig"))
    if isinstance(content, dict):
        content = content.get("Content", content.get("Cards", content))
    if not isinstance(content, list):
        return {
            "format": type(content).__name__,
            "slot_count": 0,
            "card_types": {},
            "rsu_channel_count": 0,
            "warning": "Unexpected .ldbx payload shape; expected a list of card objects.",
        }

    slot_count = 0
    card_types: Counter[str] = Counter()
    rsu_channel_count = 0
    for card in content:
        if not isinstance(card, dict):
            continue
        slot_count += 1
        card_type = str(card.get("CardType", ""))
        card_types[card_type] += 1
        if card_type.lower().startswith("rsucard"):
            rsu_channel_count += len(card.get("Channels", []))
    return {
        "slot_count": slot_count,
        "card_types": dict(card_types),
        "rsu_channel_count": rsu_channel_count,
    }


def resolve_bundle_manifest(
    bundle_root: Path,
    *,
    project_key: str | None = None,
    package_root: Path | None = None,
    og_root: Path | None = None,
) -> dict[str, Any]:
    effective_package_root = package_root or bundle_root
    entrypoint = bundle_root / "AriaMain.json"
    if not entrypoint.exists():
        raise FileNotFoundError(f"AriaMain.json not found under {bundle_root}")

    root_payload = load_json_file(entrypoint)
    artifacts: list[dict[str, Any]] = []
    bundle_files: dict[str, dict[str, Any]] = {"AriaMain.json": root_payload}
    source_values = [json.dumps(root_payload)]

    config = root_payload.get("Configuration", {})
    config_folder: str | None = None

    for key in ("Chassis", "Can", "Lin", "Flexray", "Sensors", "EventMode"):
        value = config.get(key)
        resolved = resolve_reference(bundle_root, value)
        if key == "EventMode" and value in (None, ""):
            continue
        bundle_relative = None
        if isinstance(value, str) and not Path(value).is_absolute():
            bundle_relative = windows_path(value)
        add_artifact(
            artifacts,
            name=f"AriaMain.Configuration.{key}",
            kind="bundle_file" if key != "EventMode" else "reference_file",
            source_file="AriaMain.json",
            original_value=value,
            resolved_path=resolved,
            required=key != "EventMode",
            bundle_relative_path=bundle_relative,
        )
        if resolved and resolved.exists() and resolved.suffix.lower() == ".json":
            bundle_files[resolved.name] = load_json_file(resolved)
            source_values.append(windows_path(resolved))

    chassis = bundle_files.get("ChassisConfig.json", {}).get("Configuration", {})
    config_folder = chassis.get("ConfigFolder")

    for key in ("ScriptsFolder", "ResultsFolder", "ConfigFolder", "FilterFolder", "CrashFolder"):
        value = chassis.get(key)
        resolved = resolve_reference(bundle_root, value)
        bundle_relative = windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None
        add_artifact(
            artifacts,
            name=f"ChassisConfig.Configuration.{key}",
            kind="reference_dir",
            source_file="ChassisConfig.json",
            original_value=value,
            resolved_path=resolved,
            required=key in {"ConfigFolder", "FilterFolder", "CrashFolder"},
            bundle_relative_path=bundle_relative,
        )

    for key in ("ConfigPath", "ProfilePath"):
        value = chassis.get(key)
        if value in (None, "", "default"):
            continue
        resolved = resolve_reference(bundle_root, value)
        bundle_relative = windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None
        add_artifact(
            artifacts,
            name=f"ChassisConfig.Configuration.{key}",
            kind="reference_file",
            source_file="ChassisConfig.json",
            original_value=value,
            resolved_path=resolved,
            required=False,
            bundle_relative_path=bundle_relative,
        )

    can_config = bundle_files.get("CanConfig.json", {})
    can_global = can_config.get("CanGlobalConfig", {})
    for key in ("SymbolFile", "MnemonicFile"):
        value = can_global.get(key)
        resolved = resolve_reference(bundle_root, value)
        bundle_relative = windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None
        add_artifact(
            artifacts,
            name=f"CanGlobalConfig.{key}",
            kind="reference_file",
            source_file="CanConfig.json",
            original_value=value,
            resolved_path=resolved,
            required=True,
            bundle_relative_path=bundle_relative,
        )

    diagnostic_routes: list[dict[str, Any]] = []
    for index, channel in enumerate(can_config.get("CanChannelConfig", []), start=1):
        product_library = channel.get("ProductLibrary")
        if product_library not in (None, "", "default"):
            add_artifact(
                artifacts,
                name=f"CanChannelConfig[{index}].ProductLibrary",
                kind="reference_file",
                source_file="CanConfig.json",
                original_value=product_library,
                resolved_path=resolve_reference(bundle_root, product_library),
                required=False,
                bundle_relative_path=windows_path(product_library) if isinstance(product_library, str) and not Path(product_library).is_absolute() else None,
            )

        periodic = channel.get("CanPeriodic", {})
        for key in ("Database", "Matrix"):
            value = periodic.get(key)
            if value in (None, "", "default"):
                continue
            add_artifact(
                artifacts,
                name=f"CanChannelConfig[{index}].CanPeriodic.{key}",
                kind="reference_file",
                source_file="CanConfig.json",
                original_value=value,
                resolved_path=resolve_reference(bundle_root, value),
                required=key == "Database",
                bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
            )

        diag = channel.get("DiagProperties", {})
        route = {
            "channel": channel.get("Can"),
            "physical_request_id": diag.get("PhysicalRequestID"),
            "functional_request_id": diag.get("FunctionalRequestID"),
            "response_id": diag.get("ResponseID"),
            "is_can_fd": channel.get("IsCanFd"),
            "services": diag.get("Services"),
            "dtc_general_config": diag.get("ErrorCodesGeneralConfig"),
            "error_codes": diag.get("ErrorCodes"),
        }
        diagnostic_routes.append(route)

        for key in ("ErrorCodes", "ErrorCodesGeneralConfig", "Services"):
            value = diag.get(key)
            if value in (None, "", "default"):
                continue
            add_artifact(
                artifacts,
                name=f"CanChannelConfig[{index}].DiagProperties.{key}",
                kind="reference_file",
                source_file="CanConfig.json",
                original_value=value,
                resolved_path=resolve_reference(bundle_root, value),
                required=False,
                bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
            )

    lin_config = bundle_files.get("LinConfig.json", {})
    for index, channel in enumerate(lin_config.get("LinChannelConfig", []), start=1):
        for key in ("Path", "ProductLibrary"):
            value = channel.get(key)
            if value in (None, "", "default"):
                continue
            add_artifact(
                artifacts,
                name=f"LinChannelConfig[{index}].{key}",
                kind="reference_file",
                source_file="LinConfig.json",
                original_value=value,
                resolved_path=resolve_reference(bundle_root, value),
                required=key == "Path",
                bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
            )
        for key in ("Services", "ErrorCodesGeneralConfig", "ErrorCodes"):
            value = channel.get("LinDiagProperties", {}).get(key)
            if value in (None, "", "default"):
                continue
            add_artifact(
                artifacts,
                name=f"LinChannelConfig[{index}].LinDiagProperties.{key}",
                kind="reference_file",
                source_file="LinConfig.json",
                original_value=value,
                resolved_path=resolve_reference(bundle_root, value),
                required=False,
                bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
            )

    flexray = bundle_files.get("FlexrayConfig.json", {}).get("Configuration", {})
    for key in ("Path", "ProductLibrary", "Services", "Mnemonics", "ErrorCodes", "ErrorCodesGeneralConfig"):
        value = flexray.get(key)
        if value in (None, "", "default"):
            continue
        add_artifact(
            artifacts,
            name=f"FlexrayConfig.Configuration.{key}",
            kind="reference_file",
            source_file="FlexrayConfig.json",
            original_value=value,
            resolved_path=resolve_reference(bundle_root, value),
            required=key == "Path",
            bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
        )

    sensors = bundle_files.get("SensorsConfig.json", {})
    rsu_configuration = sensors.get("RsuConfiguration", {})
    for key, rsu_xml_mode in (("Path", False), ("ConfigPath", True)):
        value = rsu_configuration.get(key)
        if value in (None, "", "default"):
            continue
        add_artifact(
            artifacts,
            name=f"RsuConfiguration.{key}",
            kind="reference_dir" if key == "Path" and str(value).lower().endswith(("xls", "xlsx", "xlsm")) is False else "reference_file",
            source_file="SensorsConfig.json",
            original_value=value,
            resolved_path=resolve_reference(
                bundle_root,
                value,
                config_folder=config_folder,
                rsu_xml_mode=rsu_xml_mode,
            ),
            required=True,
            bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
        )

    for index, sensor in enumerate(rsu_configuration.get("RsuSensors", []), start=1):
        value = sensor.get("Path")
        if value in (None, "", "default"):
            continue
        add_artifact(
            artifacts,
            name=f"RsuConfiguration.RsuSensors[{index}].Path",
            kind="reference_file",
            source_file="SensorsConfig.json",
            original_value=value,
            resolved_path=resolve_reference(
                bundle_root,
                value,
                config_folder=config_folder,
                rsu_xml_mode=True,
            ),
            required=True,
            bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
        )

    spi_configuration = sensors.get("SpiConfiguration", {})
    for key in ("EvtFolder", "WorkflowsFolder"):
        value = spi_configuration.get(key)
        if value in (None, "", "default"):
            continue
        add_artifact(
            artifacts,
            name=f"SpiConfiguration.{key}",
            kind="reference_dir",
            source_file="SensorsConfig.json",
            original_value=value,
            resolved_path=resolve_reference(bundle_root, value),
            required=key == "EvtFolder",
            bundle_relative_path=windows_path(value) if isinstance(value, str) and not Path(value).is_absolute() else None,
        )

    project_key = infer_project_key(
        project_key,
        bundle_root=bundle_root,
        source_values=source_values + [json.dumps(item) for item in artifacts],
        package_root=effective_package_root,
        og_root=og_root,
    )

    discovered_assets = discover_project_assets(effective_package_root, project_key, og_root=og_root)
    for asset_name, value in discovered_assets.items():
        if asset_name == "project_key":
            continue
        if isinstance(value, list):
            for index, item in enumerate(value, start=1):
                path = Path(item)
                bundle_relative = (
                    windows_path(path.relative_to(effective_package_root))
                    if path.exists() and is_relative_to(path, effective_package_root)
                    else None
                )
                add_artifact(
                    artifacts,
                    name=f"projectAsset.{asset_name}[{index}]",
                    kind="project_asset",
                    source_file="asset_discovery",
                    original_value=item,
                    resolved_path=path,
                    required=False,
                    bundle_relative_path=bundle_relative,
                    project_key=project_key,
                )
        elif isinstance(value, str):
            path = Path(value)
            bundle_relative = (
                windows_path(path.relative_to(effective_package_root))
                if path.exists() and is_relative_to(path, effective_package_root)
                else None
            )
            add_artifact(
                artifacts,
                name=f"projectAsset.{asset_name}",
                kind="project_asset",
                source_file="asset_discovery",
                original_value=value,
                resolved_path=path,
                required=False,
                bundle_relative_path=bundle_relative,
                project_key=project_key,
            )

    return {
        "bundle_root": windows_path(bundle_root),
        "entrypoint": windows_path(entrypoint),
        "project_key": project_key,
        "artifacts": artifacts,
        "bundle_files": bundle_files,
        "diagnostic_routes": diagnostic_routes,
        "discovered_assets": discovered_assets,
    }


def validate_bundle(
    bundle_root: Path,
    *,
    project_key: str | None = None,
    package_root: Path | None = None,
    og_root: Path | None = None,
) -> dict[str, Any]:
    manifest = resolve_bundle_manifest(
        bundle_root,
        project_key=project_key,
        package_root=package_root,
        og_root=og_root,
    )
    generated_manifest_path = bundle_root / "artifact-manifest.json"
    generated_manifest = load_json_file(generated_manifest_path) if generated_manifest_path.exists() else {}
    allowed_fallback_project = generated_manifest.get("base_project")

    issues: list[dict[str, Any]] = []
    artifacts = manifest["artifacts"]
    project_key = manifest.get("project_key")

    required_bundle_files = {
        "AriaMain.Configuration.Chassis",
        "AriaMain.Configuration.Can",
        "AriaMain.Configuration.Lin",
        "AriaMain.Configuration.Flexray",
        "AriaMain.Configuration.Sensors",
    }
    present_bundle_files = {artifact["name"] for artifact in artifacts if artifact["kind"] == "bundle_file"}
    for name in sorted(required_bundle_files - present_bundle_files):
        issues.append(
            make_issue(
                "error",
                "missing-root-reference",
                f"Required root reference is missing: {name}",
                path=windows_path(bundle_root / "AriaMain.json"),
            )
        )

    for artifact in artifacts:
        if artifact["required"] and not artifact["exists"]:
            issues.append(
                make_issue(
                    "error",
                    "missing-artifact",
                    f"Required artifact not found for {artifact['name']}",
                    path=artifact.get("resolved_path"),
                    evidence=str(artifact.get("original_value")),
                )
            )
        resolved_path = artifact.get("resolved_path")
        if artifact["kind"] == "project_asset":
            continue
        if resolved_path and Path(resolved_path).is_absolute() and not is_relative_to(Path(resolved_path), bundle_root):
            issues.append(
                make_issue(
                    "warning",
                    "absolute-path-reference",
                    f"{artifact['name']} resolves outside the bundle root; the package is environment-coupled.",
                    path=resolved_path,
                )
            )

    active_routes: set[tuple[str, str]] = set()
    for route in manifest["diagnostic_routes"]:
        physical = str(route.get("physical_request_id") or "")
        response = str(route.get("response_id") or "")
        if not physical or not response:
            continue
        pair = (physical.upper(), response.upper())
        if pair in active_routes:
            issues.append(
                make_issue(
                    "error",
                    "duplicate-diagnostic-route",
                    f"Duplicate active diagnostic route detected for {physical} -> {response}.",
                )
            )
        active_routes.add(pair)

    can_config = manifest["bundle_files"].get("CanConfig.json", {})
    for index, channel in enumerate(can_config.get("CanChannelConfig", []), start=1):
        periodic = channel.get("CanPeriodic", {})
        if str(periodic.get("UseMatrix", "")).lower() == "true" and not periodic.get("Matrix"):
            issues.append(
                make_issue(
                    "error",
                    "matrix-enabled-without-file",
                    f"CanChannelConfig[{index}] enables UseMatrix but has no matrix workbook path.",
                )
            )

    if project_key:
        known_keys = infer_known_project_keys(package_root or Path(manifest["bundle_root"]), og_root)
        for artifact in artifacts:
            resolved_path = artifact.get("resolved_path")
            if not resolved_path:
                continue
            hinted = infer_project_key_from_text(resolved_path, known_keys)
            if hinted and hinted != project_key:
                if allowed_fallback_project and hinted == str(allowed_fallback_project).upper():
                    continue
                issues.append(
                    make_issue(
                        "warning",
                        "project-asset-mismatch",
                        f"{artifact['name']} appears to reference project '{hinted}' while the inferred bundle project is '{project_key}'.",
                        path=resolved_path,
                    )
                )

    for artifact in artifacts:
        if artifact["name"] == "RsuConfiguration.Path" and artifact["exists"]:
            rsu_path = Path(artifact["resolved_path"])
            if rsu_path.is_file() and rsu_path.suffix.lower() in {".xls", ".xlsx", ".xlsm"}:
                workbook_summary = inspect_workbook(rsu_path)
                manifest.setdefault("workbook_inspection", {})["rsu"] = workbook_summary
            break

    for artifact in artifacts:
        if artifact["resolved_path"] and str(artifact["resolved_path"]).lower().endswith(".ldbx") and artifact["exists"]:
            manifest.setdefault("ldbx_inspection", {})[artifact["name"]] = summarize_ldbx(Path(artifact["resolved_path"]))

    manifest["issues"] = issues
    manifest["summary"] = {
        "errors": sum(1 for issue in issues if issue["severity"] == "error"),
        "warnings": sum(1 for issue in issues if issue["severity"] == "warning"),
        "project_key": project_key,
        "base_project": allowed_fallback_project,
        "artifact_count": len(artifacts),
    }
    return manifest


def parse_dbc(path: Path) -> dict[str, Any]:
    messages: dict[str, dict[str, Any]] = {}
    current_message: str | None = None

    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        message_match = re.match(r"^BO_\s+(\d+)\s+([A-Za-z0-9_]+)\s*:\s*(\d+)\s+([A-Za-z0-9_]+)", line)
        if message_match:
            message_id, name, dlc, transmitter = message_match.groups()
            messages[name] = {
                "id": int(message_id),
                "dlc": int(dlc),
                "transmitter": transmitter,
                "signals": set(),
            }
            current_message = name
            continue

        signal_match = re.match(r"^\s*SG_\s+([A-Za-z0-9_]+)", line)
        if signal_match and current_message:
            messages[current_message]["signals"].add(signal_match.group(1))

    return {
        "messages": {
            name: {
                "id": payload["id"],
                "dlc": payload["dlc"],
                "transmitter": payload["transmitter"],
                "signals": sorted(payload["signals"]),
            }
            for name, payload in messages.items()
        },
        "signal_names": sorted({signal for payload in messages.values() for signal in payload["signals"]}),
    }


def collect_impact_matches(search_roots: list[Path], terms: set[str]) -> list[dict[str, Any]]:
    matches: list[dict[str, Any]] = []
    lowered_terms = {term.lower() for term in terms if term}
    for root in search_roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in TEXT_SEARCH_EXTENSIONS:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            lowered = text.lower()
            hit_terms = sorted(term for term in lowered_terms if term in lowered)
            if not hit_terms:
                continue
            matches.append(
                {
                    "path": windows_path(path),
                    "terms": hit_terms[:20],
                }
            )
            if len(matches) >= 200:
                return matches
    return matches


def diff_dbc(
    old_path: Path,
    new_path: Path,
    *,
    search_roots: list[Path] | None = None,
) -> dict[str, Any]:
    old = parse_dbc(old_path)
    new = parse_dbc(new_path)

    old_messages = old["messages"]
    new_messages = new["messages"]
    old_message_names = set(old_messages)
    new_message_names = set(new_messages)

    added_messages = sorted(new_message_names - old_message_names)
    removed_messages = sorted(old_message_names - new_message_names)
    changed_message_ids = []
    for name in sorted(old_message_names & new_message_names):
        if old_messages[name]["id"] != new_messages[name]["id"] or old_messages[name]["dlc"] != new_messages[name]["dlc"]:
            changed_message_ids.append(
                {
                    "message": name,
                    "old_id": old_messages[name]["id"],
                    "new_id": new_messages[name]["id"],
                    "old_dlc": old_messages[name]["dlc"],
                    "new_dlc": new_messages[name]["dlc"],
                }
            )

    old_signals = set(old["signal_names"])
    new_signals = set(new["signal_names"])
    added_signals = sorted(new_signals - old_signals)
    removed_signals = sorted(old_signals - new_signals)

    changed_message_signal_sets = []
    for name in sorted(old_message_names & new_message_names):
        old_set = set(old_messages[name]["signals"])
        new_set = set(new_messages[name]["signals"])
        if old_set != new_set:
            changed_message_signal_sets.append(
                {
                    "message": name,
                    "added_signals": sorted(new_set - old_set),
                    "removed_signals": sorted(old_set - new_set),
                }
            )

    impact_terms = set(added_messages + removed_messages + added_signals + removed_signals)
    impact_terms.update(
        item["message"]
        for item in changed_message_ids + changed_message_signal_sets
        if isinstance(item, dict) and "message" in item
    )
    impact_matches = collect_impact_matches(search_roots or [], impact_terms)

    return {
        "old_dbc": windows_path(old_path),
        "new_dbc": windows_path(new_path),
        "summary": {
            "added_messages": len(added_messages),
            "removed_messages": len(removed_messages),
            "changed_message_ids": len(changed_message_ids),
            "added_signals": len(added_signals),
            "removed_signals": len(removed_signals),
            "changed_message_signal_sets": len(changed_message_signal_sets),
            "impact_matches": len(impact_matches),
        },
        "added_messages": added_messages,
        "removed_messages": removed_messages,
        "changed_message_ids": changed_message_ids,
        "added_signals": added_signals,
        "removed_signals": removed_signals,
        "changed_message_signal_sets": changed_message_signal_sets,
        "impact_matches": impact_matches,
    }


def discover_workspace_project_config(project_key: str) -> Path | None:
    candidate = REPO_ROOT / "projects" / project_key / "config"
    return candidate if candidate.exists() else None


def load_workspace_project_spec(config_dir: Path | None) -> dict[str, Any]:
    if config_dir is None or not config_dir.exists():
        return {}

    spec: dict[str, Any] = {}
    for file_name in ("project_config.py", "rsu_config.py", "canc_config.py"):
        path = config_dir / file_name
        if not path.exists():
            continue
        spec[file_name] = extract_python_assignments(path)
    return spec


def select_primary_can_channel(can_config: dict[str, Any]) -> dict[str, Any] | None:
    channels = can_config.get("CanChannelConfig", [])
    if not channels:
        return None
    for channel in channels:
        diag = channel.get("DiagProperties", {})
        if diag.get("Services") or diag.get("ErrorCodesGeneralConfig") or channel.get("ProductName"):
            return channel
    return channels[0]


def adapt_reference_for_output(
    original_value: Any,
    resolved_path: Path | None,
    *,
    source_root: Path | None,
    copy_files: bool,
    copy_dirs: bool,
    is_directory: bool,
) -> str | None:
    if original_value in (None, "", "default"):
        return None
    if resolved_path is None:
        return str(original_value)

    if source_root and is_relative_to(resolved_path, source_root):
        relative = windows_path(resolved_path.relative_to(source_root))
        if is_directory:
            return relative if copy_dirs else windows_path(resolved_path)
        return relative if copy_files else windows_path(resolved_path)

    return windows_path(resolved_path)


def rebase_source_package_path(resolved_path: Path | None, source_root: Path | None) -> Path | None:
    if resolved_path is None or source_root is None or not resolved_path.is_absolute():
        return resolved_path
    if is_relative_to(resolved_path, source_root):
        return resolved_path

    parts_upper = [part.upper() for part in resolved_path.parts]
    for index, part in enumerate(parts_upper):
        if part == "ARIACONFIGFILES" and index + 1 < len(resolved_path.parts):
            tail = Path(*resolved_path.parts[index + 1 :])
            candidate = source_root / tail
            if candidate.exists():
                return candidate
    return resolved_path


def copy_file_if_needed(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_directory_if_needed(source: Path, destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(source, destination)


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(coerce_jsonable(payload), indent=2), encoding="utf-8")


def generate_project_bundle(
    project_key: str,
    output_dir: Path,
    *,
    source_root: Path | None,
    og_root: Path | None,
    workspace_config_dir: Path | None,
    customer: str | None,
    copy_files: bool,
    copy_support_directories: bool,
    root_alias: str,
    validate_after_write: bool,
    base_project: str | None,
) -> dict[str, Any]:
    bundle_files, baseline_root = load_baseline_bundle(source_root)
    source_root = baseline_root
    workspace_spec = load_workspace_project_spec(workspace_config_dir)

    project_assets = discover_project_assets(
        source_root or DEFAULT_PACKAGE_ROOT,
        base_project or project_key,
        og_root=og_root,
    )

    manifest_before = resolve_bundle_manifest(
        source_root or output_dir,
        project_key=base_project or project_key if source_root else project_key,
        package_root=source_root,
        og_root=og_root,
    ) if source_root else {
        "artifacts": [],
        "bundle_files": bundle_files,
        "discovered_assets": project_assets,
        "project_key": project_key,
        "diagnostic_routes": [],
    }

    root_payload = copy.deepcopy(bundle_files["AriaMain.json"])
    can_payload = copy.deepcopy(bundle_files["CanConfig.json"])
    chassis_payload = copy.deepcopy(bundle_files["ChassisConfig.json"])
    lin_payload = copy.deepcopy(bundle_files["LinConfig.json"])
    flexray_payload = copy.deepcopy(bundle_files["FlexrayConfig.json"])
    sensors_payload = copy.deepcopy(bundle_files["SensorsConfig.json"])

    if customer is not None:
        root_payload.setdefault("Configuration", {})["Customer"] = customer

    for key, portable_default in (("ScriptsFolder", "Scripts"), ("ResultsFolder", "Results")):
        current_value = str(chassis_payload.get("Configuration", {}).get(key, "") or "")
        if not current_value:
            chassis_payload.setdefault("Configuration", {})[key] = portable_default
            continue
        inferred = infer_project_key_from_text(current_value, infer_known_project_keys(source_root, og_root))
        if Path(current_value).is_absolute() or ".." in current_value or (inferred and inferred not in {project_key, base_project}):
            chassis_payload.setdefault("Configuration", {})[key] = portable_default

    project_config = workspace_spec.get("project_config.py", {})
    primary_can_channel = select_primary_can_channel(can_payload)
    if primary_can_channel:
        if "CAN_BAUD_RATE" in project_config:
            primary_can_channel.setdefault("CanProperties", {})["BitRate"] = str(project_config["CAN_BAUD_RATE"])
        if "CAN_FD_ENABLED" in project_config:
            primary_can_channel["IsCanFd"] = "True" if project_config["CAN_FD_ENABLED"] else "False"

        diag = primary_can_channel.setdefault("DiagProperties", {})
        if "DIAG_TX_ID" in project_config:
            diag["PhysicalRequestID"] = format_hex(project_config["DIAG_TX_ID"])
        if "DIAG_FUNCTIONAL_ID" in project_config:
            diag["FunctionalRequestID"] = format_hex(project_config["DIAG_FUNCTIONAL_ID"])
        if "DIAG_RX_ID" in project_config:
            diag["ResponseID"] = format_hex(project_config["DIAG_RX_ID"])

        for route in diag.get("CanIsoTpPropertiesPerCanId", []):
            product_name = str(route.get("ProductName", "")).lower()
            if route.get("Active") == "True" and "DIAG_TX_ID" in project_config:
                route["RequestId"] = format_hex(project_config["DIAG_TX_ID"])
                route["FlowControlRequestId"] = format_hex(project_config["DIAG_TX_ID"])
                if "DIAG_RX_ID" in project_config:
                    route["ResponseId"] = format_hex(project_config["DIAG_RX_ID"])
            elif "functional" in product_name and "DIAG_FUNCTIONAL_ID" in project_config:
                route["RequestId"] = format_hex(project_config["DIAG_FUNCTIONAL_ID"])
                route["FlowControlRequestId"] = format_hex(project_config["DIAG_FUNCTIONAL_ID"])

    if project_assets.get("rsuWorkbook"):
        rsu_workbook = Path(project_assets["rsuWorkbook"][0])
        sensors_payload.setdefault("RsuConfiguration", {})["Path"] = adapt_reference_for_output(
            windows_path(rsu_workbook),
            rsu_workbook,
            source_root=source_root,
            copy_files=copy_files,
            copy_dirs=copy_support_directories,
            is_directory=False,
        )

    source_manifest_artifacts = manifest_before.get("artifacts", [])
    artifact_by_name = {artifact["name"]: artifact for artifact in source_manifest_artifacts}

    def patch_reference(payload: dict[str, Any], path_steps: list[str], artifact_name: str, *, is_directory: bool) -> None:
        artifact = artifact_by_name.get(artifact_name)
        if not artifact:
            return
        resolved_path = Path(artifact["resolved_path"]) if artifact.get("resolved_path") else None
        resolved_path = rebase_source_package_path(resolved_path, source_root)
        new_value = adapt_reference_for_output(
            artifact.get("original_value"),
            resolved_path,
            source_root=source_root,
            copy_files=copy_files,
            copy_dirs=copy_support_directories,
            is_directory=is_directory,
        )
        if new_value is None:
            return
        current = payload
        for key in path_steps[:-1]:
            current = current.setdefault(key, {})
        current[path_steps[-1]] = new_value

    patch_reference(chassis_payload, ["Configuration", "ConfigFolder"], "ChassisConfig.Configuration.ConfigFolder", is_directory=True)
    patch_reference(chassis_payload, ["Configuration", "FilterFolder"], "ChassisConfig.Configuration.FilterFolder", is_directory=True)
    patch_reference(chassis_payload, ["Configuration", "CrashFolder"], "ChassisConfig.Configuration.CrashFolder", is_directory=True)
    patch_reference(can_payload, ["CanGlobalConfig", "SymbolFile"], "CanGlobalConfig.SymbolFile", is_directory=False)
    patch_reference(can_payload, ["CanGlobalConfig", "MnemonicFile"], "CanGlobalConfig.MnemonicFile", is_directory=False)
    patch_reference(sensors_payload, ["RsuConfiguration", "ConfigPath"], "RsuConfiguration.ConfigPath", is_directory=False)
    patch_reference(sensors_payload, ["SpiConfiguration", "EvtFolder"], "SpiConfiguration.EvtFolder", is_directory=True)
    if sensors_payload.get("SpiConfiguration", {}).get("WorkflowsFolder") is not None:
        patch_reference(sensors_payload, ["SpiConfiguration", "WorkflowsFolder"], "SpiConfiguration.WorkflowsFolder", is_directory=True)

    for index, sensor in enumerate(sensors_payload.get("RsuConfiguration", {}).get("RsuSensors", []), start=1):
        artifact = artifact_by_name.get(f"RsuConfiguration.RsuSensors[{index}].Path")
        if artifact and artifact.get("resolved_path"):
            resolved_path = rebase_source_package_path(Path(artifact["resolved_path"]), source_root)
            sensor["Path"] = adapt_reference_for_output(
                artifact.get("original_value"),
                resolved_path,
                source_root=source_root,
                copy_files=copy_files,
                copy_dirs=copy_support_directories,
                is_directory=False,
            )

    for index, channel in enumerate(can_payload.get("CanChannelConfig", []), start=1):
        for ref_key in ("Database", "Matrix"):
            artifact = artifact_by_name.get(f"CanChannelConfig[{index}].CanPeriodic.{ref_key}")
            if artifact and artifact.get("resolved_path"):
                resolved_path = rebase_source_package_path(Path(artifact["resolved_path"]), source_root)
                channel.setdefault("CanPeriodic", {})[ref_key] = adapt_reference_for_output(
                    artifact.get("original_value"),
                    resolved_path,
                    source_root=source_root,
                    copy_files=copy_files,
                    copy_dirs=copy_support_directories,
                    is_directory=False,
                )
        for ref_key in ("ErrorCodes", "ErrorCodesGeneralConfig", "Services"):
            artifact = artifact_by_name.get(f"CanChannelConfig[{index}].DiagProperties.{ref_key}")
            if artifact and artifact.get("resolved_path"):
                resolved_path = rebase_source_package_path(Path(artifact["resolved_path"]), source_root)
                channel.setdefault("DiagProperties", {})[ref_key] = adapt_reference_for_output(
                    artifact.get("original_value"),
                    resolved_path,
                    source_root=source_root,
                    copy_files=copy_files,
                    copy_dirs=copy_support_directories,
                    is_directory=False,
                )

    generated_files = {
        "AriaMain.json": root_payload,
        "ChassisConfig.json": chassis_payload,
        "CanConfig.json": can_payload,
        "LinConfig.json": lin_payload,
        "FlexrayConfig.json": flexray_payload,
        "SensorsConfig.json": sensors_payload,
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    for file_name, payload in generated_files.items():
        write_json(output_dir / file_name, payload)

    alias_name = root_alias.replace("<Project>", project_key)
    if alias_name != "AriaMain.json":
        write_json(output_dir / alias_name, root_payload)

    copied_artifacts: list[str] = []
    if source_root:
        for artifact in source_manifest_artifacts:
            resolved_path_text = artifact.get("resolved_path")
            if not resolved_path_text:
                continue
            resolved_path = Path(resolved_path_text)
            target_relative = artifact.get("bundle_relative_path")
            if not resolved_path.exists():
                continue
            resolved_path = rebase_source_package_path(resolved_path, source_root) or resolved_path
            if not resolved_path.exists():
                continue
            if not target_relative and source_root and is_relative_to(resolved_path, source_root):
                target_relative = windows_path(resolved_path.relative_to(source_root))
            if not target_relative:
                continue
            if target_relative in generated_files or target_relative == alias_name:
                continue
            if artifact["kind"] == "reference_file" and resolved_path.is_file() and copy_files:
                target = output_dir / target_relative
                copy_file_if_needed(resolved_path, target)
                copied_artifacts.append(windows_path(target))
            elif artifact["kind"] == "reference_dir" and resolved_path.is_dir() and copy_support_directories:
                target = output_dir / target_relative
                copy_directory_if_needed(resolved_path, target)
                copied_artifacts.append(windows_path(target))

        for artifact in source_manifest_artifacts:
            if artifact["kind"] != "project_asset":
                continue
            resolved_path_text = artifact.get("resolved_path")
            target_relative = artifact.get("bundle_relative_path")
            if not resolved_path_text or not target_relative:
                continue
            resolved_path = Path(resolved_path_text)
            if not resolved_path.exists():
                continue
            if resolved_path.is_file():
                copy_file_if_needed(resolved_path, output_dir / target_relative)
                copied_artifacts.append(windows_path(output_dir / target_relative))

    manifest_payload = {
        "project_key": project_key,
        "source_root": windows_path(source_root) if source_root else None,
        "base_project": base_project,
        "workspace_config_dir": windows_path(workspace_config_dir) if workspace_config_dir else None,
        "copied_artifacts": copied_artifacts,
        "discovered_assets": project_assets,
        "workspace_spec": workspace_spec,
        "generated_files": sorted(generated_files),
        "root_alias": alias_name,
    }
    write_json(output_dir / "artifact-manifest.json", manifest_payload)

    validation_payload = None
    if validate_after_write:
        validation_payload = validate_bundle(
            output_dir,
            project_key=project_key,
            package_root=output_dir,
            og_root=og_root,
        )
        write_json(output_dir / "validation-report.json", validation_payload)

    return {
        "output_dir": windows_path(output_dir),
        "manifest": manifest_payload,
        "validation": validation_payload,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Executable backend for the ARIA configuration assistant.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate-bundle", help="Validate an ARIA JSON-rooted bundle.")
    validate_parser.add_argument("bundle_root", help="Path to the bundle directory containing AriaMain.json.")
    validate_parser.add_argument("--project-key", help="Override the inferred project key.")
    validate_parser.add_argument("--package-root", help="Package root used for project-asset discovery.")
    validate_parser.add_argument("--og-root", help="OG workbook root.")
    validate_parser.add_argument("--json", action="store_true", help="Emit JSON instead of human-readable text.")

    workbook_parser = subparsers.add_parser("inspect-workbook", help="Extract structured workbook metadata.")
    workbook_parser.add_argument("path", help="Workbook path.")
    workbook_parser.add_argument("--json", action="store_true", help="Emit JSON only.")

    dbc_parser = subparsers.add_parser("diff-dbc", help="Diff two DBC files and search for likely impact.")
    dbc_parser.add_argument("old_dbc", help="Old DBC file path.")
    dbc_parser.add_argument("new_dbc", help="New DBC file path.")
    dbc_parser.add_argument(
        "--search-root",
        action="append",
        dest="search_roots",
        help="Root directory to scan for impacted references. Can be repeated.",
    )
    dbc_parser.add_argument("--json", action="store_true", help="Emit JSON only.")

    generate_parser = subparsers.add_parser("generate-project-bundle", help="Generate a project-scoped ARIA bundle.")
    generate_parser.add_argument("project_key", help="Project key such as M314 or U171.")
    generate_parser.add_argument("output_dir", help="Output directory for the generated bundle.")
    generate_parser.add_argument("--source-root", help="Existing ARIA package root used as the baseline.")
    generate_parser.add_argument("--og-root", help="OG workbook root.")
    generate_parser.add_argument("--workspace-config-dir", help="Workspace project config directory.")
    generate_parser.add_argument("--customer", help="Explicit Customer field override.")
    generate_parser.add_argument(
        "--root-alias",
        default="AriaMain_<Project>.json",
        help="Project root alias file name pattern. Default: AriaMain_<Project>.json",
    )
    generate_parser.add_argument(
        "--no-copy-files",
        action="store_true",
        help="Do not copy referenced files into the output bundle; use absolute paths instead.",
    )
    generate_parser.add_argument(
        "--copy-support-directories",
        action="store_true",
        help="Copy referenced support directories such as SPI folders into the output bundle.",
    )
    generate_parser.add_argument(
        "--skip-validation",
        action="store_true",
        help="Do not run post-generation validation.",
    )
    generate_parser.add_argument(
        "--base-project",
        help="Base project key to use for asset discovery when the target project has no dedicated package assets.",
    )
    generate_parser.add_argument("--json", action="store_true", help="Emit JSON only.")

    return parser.parse_args()


def print_validation_report(result: dict[str, Any]) -> None:
    summary = result["summary"]
    print(f"Bundle: {result['bundle_root']}")
    print(f"Project: {summary.get('project_key') or 'unknown'}")
    print(f"Artifacts: {summary['artifact_count']}")
    print(f"Errors: {summary['errors']}")
    print(f"Warnings: {summary['warnings']}")
    print()
    for issue in result["issues"]:
        location = f" [{issue['path']}]" if issue.get("path") else ""
        print(f"{issue['severity'].upper()}: {issue['code']}: {issue['message']}{location}")


def print_dbc_report(result: dict[str, Any]) -> None:
    summary = result["summary"]
    print(f"Old DBC: {result['old_dbc']}")
    print(f"New DBC: {result['new_dbc']}")
    print(
        "Changes: "
        f"+{summary['added_messages']} messages, "
        f"-{summary['removed_messages']} messages, "
        f"+{summary['added_signals']} signals, "
        f"-{summary['removed_signals']} signals, "
        f"{summary['impact_matches']} likely impacted files"
    )
    if result["changed_message_ids"]:
        print("Changed message ids:")
        for item in result["changed_message_ids"]:
            print(f"  - {item['message']}: {item['old_id']} -> {item['new_id']}")
    if result["impact_matches"]:
        print("Likely impacted files:")
        for match in result["impact_matches"][:20]:
            print(f"  - {match['path']} ({', '.join(match['terms'][:5])})")


def print_generation_report(result: dict[str, Any]) -> None:
    print(f"Generated bundle: {result['output_dir']}")
    print(f"Root alias: {result['manifest']['root_alias']}")
    print(f"Copied artifacts: {len(result['manifest']['copied_artifacts'])}")
    if result.get("validation"):
        summary = result["validation"]["summary"]
        print(f"Validation: {summary['errors']} error(s), {summary['warnings']} warning(s)")


def main() -> int:
    args = parse_args()

    if args.command == "inspect-workbook":
        result = inspect_workbook(Path(args.path))
        print(json.dumps(coerce_jsonable(result), indent=2) if args.json else json.dumps(coerce_jsonable(result), indent=2))
        return 0

    if args.command == "validate-bundle":
        result = validate_bundle(
            Path(args.bundle_root),
            project_key=args.project_key,
            package_root=Path(args.package_root) if args.package_root else None,
            og_root=Path(args.og_root) if args.og_root else (DEFAULT_OG_ROOT if DEFAULT_OG_ROOT.exists() else None),
        )
        if args.json:
            print(json.dumps(coerce_jsonable(result), indent=2))
        else:
            print_validation_report(result)
        return 0 if result["summary"]["errors"] == 0 else 1

    if args.command == "diff-dbc":
        search_roots = [Path(item) for item in args.search_roots] if args.search_roots else []
        result = diff_dbc(Path(args.old_dbc), Path(args.new_dbc), search_roots=search_roots)
        if args.json:
            print(json.dumps(coerce_jsonable(result), indent=2))
        else:
            print_dbc_report(result)
        return 0

    if args.command == "generate-project-bundle":
        project_key = args.project_key.upper()
        workspace_config_dir = (
            Path(args.workspace_config_dir)
            if args.workspace_config_dir
            else discover_workspace_project_config(project_key)
        )
        source_root = Path(args.source_root) if args.source_root else (DEFAULT_PACKAGE_ROOT if DEFAULT_PACKAGE_ROOT.exists() else None)
        og_root = Path(args.og_root) if args.og_root else (DEFAULT_OG_ROOT if DEFAULT_OG_ROOT.exists() else None)
        result = generate_project_bundle(
            project_key,
            Path(args.output_dir),
            source_root=source_root,
            og_root=og_root,
            workspace_config_dir=workspace_config_dir,
            customer=args.customer,
            copy_files=not args.no_copy_files,
            copy_support_directories=args.copy_support_directories,
            root_alias=args.root_alias,
            validate_after_write=not args.skip_validation,
            base_project=args.base_project.upper() if args.base_project else None,
        )
        if args.json:
            print(json.dumps(coerce_jsonable(result), indent=2))
        else:
            print_generation_report(result)
        validation = result.get("validation")
        if validation:
            return 0 if validation["summary"]["errors"] == 0 else 1
        return 0

    raise RuntimeError(f"Unhandled command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
