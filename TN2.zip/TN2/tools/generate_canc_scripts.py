"""Generate the M310_M314_M110 CAN-C communication test scripts.

One flat script per test case in project_testcases/m310_m314_m110/CANC/CANC is
written to projects/M310_M314_M110/modules/CANC/scripts, named after the case.
The workbooks are read here, at generation time, only for each case's name,
Codebeamer ID and objective. A generated script reads nothing but the
M310_M314_M110 configuration modules and the shared library: every frame, signal,
DTC, threshold and timing it uses comes from projects/M310_M314_M110/config, and
every bench action is a shared-library call.

The case steps in the workbooks are heavily copy-pasted, so each script follows
the intent of its case (description, preconditions and the expected results that
are consistent with them). Where a case cannot be followed as written, the script
header and CANC_SCRIPT_GAPS.md say why.

A full run also writes two batch runners next to the scripts:
run_all_canc_automatic_scripts.py (the fully automatic scripts) and
run_all_canc_non_automatic_scripts.py (the rest, grouped by what the bench needs).

Usage:
    py -3.14 tools/generate_canc_scripts.py
"""

from __future__ import annotations

import ast
import builtins
import re
import sys
import textwrap
import warnings
from dataclasses import dataclass, field
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
CASE_DIR = ROOT / "project_testcases" / "m310_m314_m110" / "CANC" / "CANC"
OUT_DIR = ROOT / "projects" / "M310_M314_M110" / "modules" / "CANC" / "scripts"
GAP_REPORT = OUT_DIR / "CANC_SCRIPT_GAPS.md"
AUTO_RUNNER = OUT_DIR / "run_all_canc_automatic_scripts.py"
MANUAL_RUNNER = OUT_DIR / "run_all_canc_non_automatic_scripts.py"
CONFIG_PACKAGE = "Framework_IOEM_Py.projects.M310_M314_M110.config"

sys.path.insert(0, str(ROOT.parent))

from Framework_IOEM_Py.projects.M310_M314_M110.config import canc_config  # noqa: E402

MAH = canc_config.MAH_CAN_SIGNAL_DEFS

# Configuration modules a script may import from, and the names it takes from
# each. A name is imported only when the generated body uses it.
CONFIG_MODULES = ("canc_config", "power_config", "project_config", "cand_config",
                  "dcs_config", "ods_config", "squibs_config", "plantmode_config",
                  "edr_config", "eol_config")


# ---------------------------------------------------------------------------
# Workbooks
# ---------------------------------------------------------------------------

def _clean(value) -> str:
    """Cell text without the Codebeamer wiki markup the export carries."""
    if value is None:
        return ""
    text = str(value).replace("\r\n", "\n")
    while "%%(" in text:
        start = text.index("%%(")
        depth, end = 0, start + 2
        while end < len(text):
            if text[end] == "(":
                depth += 1
            elif text[end] == ")":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        text = text[:start] + text[end + 1:]
    text = re.sub(r";font-style:normal;.*?(?:float|fl0At):none;\)", "", text)
    text = text.replace("~", "").replace("%!", "")
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


@dataclass
class Case:
    name: str
    case_id: str
    description: str
    pre: str
    steps: list
    workbook: str
    suite: str


def load_cases(path: Path, suite: str) -> list[Case]:
    warnings.filterwarnings("ignore")
    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook["Export"] if "Export" in workbook.sheetnames else workbook.worksheets[0]
    header = [_clean(cell.value) for cell in sheet[1]]
    cases, current = [], None
    for row in sheet.iter_rows(min_row=2):
        cells = {header[i]: _clean(cell.value) for i, cell in enumerate(row) if i < len(header)}
        if cells.get("ID"):
            current = {"id": cells["ID"].replace(".0", ""), "name": cells.get("Name", ""),
                       "desc": cells.get("Description", ""), "pre": cells.get("Pre-Action", ""),
                       "type": cells.get("Type", ""), "status": cells.get("Status", ""), "steps": []}
            cases.append(current)
        if current is not None and (cells.get("Test Steps.Action") or cells.get("Test Steps.Expected result")):
            current["steps"].append((cells.get("Test Steps.Action", ""), cells.get("Test Steps.Expected result", "")))
    result = []
    for raw in cases:
        if raw["type"] == "Folder" or (not raw["steps"] and raw["status"] in ("n/a", "")):
            continue
        result.append(Case(raw["name"], raw["id"], raw["desc"], raw["pre"], raw["steps"], path.name, suite))
    return result


# ---------------------------------------------------------------------------
# Code emission
# ---------------------------------------------------------------------------

def py(value) -> str:
    """Python literal for a string, kept on one line."""
    return repr(value)


def mah_key(frame: str, signal: str) -> str:
    """MAH_CAN_SIGNAL_DEFS key of a signal in a frame (keys carry a frame prefix
    when the same signal name is used in two frames)."""
    for key, definition in MAH.items():
        if definition.get("frame") == frame and definition.get("signal") == signal:
            if key == signal or key == f"{frame}_{signal}":
                return key
    for key, definition in MAH.items():
        if definition.get("frame") == frame and definition.get("signal") == signal:
            return key
    raise KeyError(f"{signal} in {frame} is not in MAH_CAN_SIGNAL_DEFS")


def signal_frame(signal: str, frame_hint: str | None = None) -> str:
    if frame_hint:
        return frame_hint
    frames = {d["frame"] for d in MAH.values() if d.get("signal") == signal}
    if len(frames) != 1:
        raise KeyError(f"{signal} is carried by {sorted(frames)}; the case must name the frame")
    return frames.pop()


@dataclass
class Script:
    case: Case
    automation: str = "Automatic"
    notes: list = field(default_factory=list)
    setup: list = field(default_factory=list)
    steps: list = field(default_factory=list)
    cleanup: list = field(default_factory=list)
    log_defs: list = field(default_factory=list)
    log_ids: list = field(default_factory=list)
    required: list = field(default_factory=list)
    step_no: int = 0
    flags: set = field(default_factory=set)
    extra: int = 0

    def _emit(self, target: list, indent: int, text: str, subs: dict):
        text = textwrap.dedent(text).strip("\n")
        for key, value in subs.items():
            text = text.replace(f"@{key}@", str(value))
        if "@" in re.sub(r"(['\"]).*?\1", "", text):
            leftover = re.findall(r"@\w+@", text)
            if leftover:
                raise ValueError(f"{self.case.name}: unreplaced placeholders {leftover}")
        for line in text.split("\n"):
            target.append((" " * indent + line) if line.strip() else "")

    def S(self, text: str, **subs):
        """Lines of run_test before the report is created."""
        self._emit(self.setup, 4, text, subs)

    def T(self, text: str, **subs):
        """Lines of the test body (indented further by `extra` inside a runtime loop)."""
        self._emit(self.steps, 8 + self.extra, text, subs)

    def C(self, text: str, **subs):
        """Lines of the cleanup that always runs."""
        self._emit(self.cleanup, 12, text, subs)

    def step(self, title: str):
        self.step_no += 1
        self.T(f"aria_reports.add_group({py(f'Step {self.step_no}: {title}')})")

    def end(self):
        self.T("aria_reports.close_group()")

    def need(self, label_expr: str, value_expr: str):
        """A configuration item the case cannot run without."""
        self.required.append((label_expr, value_expr))


def read_dtc(sc: Script, label: str, pairs: list, indent_extra: int = 0):
    """Read_DTC against the complete expected list: (dtc expression, DTC_status
    key expression) pairs. An empty list expects no DTC at all."""
    pad = " " * indent_extra
    if not pairs:
        sc.T(f"{pad}Read_DTC({py(label)}, Read_DTC_Resp_CANC, Read_DTC_Req_CANC)")
        return
    lines = [f"{pad}Read_DTC(", f"{pad}    {py(label)},", f"{pad}    \" \".join([Read_DTC_Resp_CANC,"]
    for i, (dtc, status) in enumerate(pairs):
        tail = "])," if i == len(pairs) - 1 else ","
        lines.append(f"{pad}              {dtc}, DTC_status[{status}]{tail}")
    lines.append(f"{pad}    Read_DTC_Req_CANC)")
    sc.T("\n".join(lines))


ACTIVE, HEALED, HISTORIC = "'DTC_active_WLOFF'", "'DTC_healed'", "'DTC_historic'"
V_ACTIVE = "CANC_VOLTAGE_DTC_STATUS_KEYS['active']"
V_HEALED = "CANC_VOLTAGE_DTC_STATUS_KEYS['healed']"
V_HISTORIC = "CANC_VOLTAGE_DTC_STATUS_KEYS['historic']"


def measure(sc: Script, var: str, pairs: list, what: str, expected: str | None = None,
            tolerance: str | None = None):
    """The shared faultTimeMeasurement: it reads the DTCs (19 02 09, nothing written to
    the report) until each (dtc expression, DTC_status key expression) pair is in the
    answer, in turn, and returns the milliseconds since the call (None once canc_config
    FAULT_TIME_MEASUREMENT_TIMEOUT_MS has passed). With expected and tolerance (code of
    ms values) the time is graded; without them it is only recorded, the measurement
    serving as the wait for a settled state. The Read_DTC that follows grades the
    complete DTC list either way.

    what: text of an f-string naming what is timed, e.g. "Qualification time of {fault_dtc}".
    """
    target = ";".join(f"{{{dtc}}} {{DTC_status[{status}]}}" for dtc, status in pairs)
    sc.T(f'{var} = faultTimeMeasurement(f"{target}")')
    if expected is None:
        label = f'f"{what} (ms)"' if "{" in what else py(f"{what} (ms)")
        sc.T(f"RESULT.LogAction({label}, None if {var} is None else round({var}))")
        return
    grade(sc, var, what, expected, tolerance)


def grade(sc: Script, var: str, what: str, expected: str, tolerance: str):
    """fault_time_check over nominal - 10 % ... nominal + 10 % + measurement_lag_ms: the
    shared check takes a centre and a half width, so both are moved up by half the lag."""
    sc.T(f"""
        RESULT.InsertComment(f"{what}: expected {{{expected}}} ms, limits {{{expected} - {tolerance}}} ms "
                             f"(-{{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g}} %) to {{{expected} + {tolerance} + measurement_lag_ms}} ms "
                             f"(+{{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g}} % and the {{measurement_lag_ms}} ms measurement lag)")
        fault_time_check({var}, {expected} + measurement_lag_ms / 2, {tolerance} + measurement_lag_ms / 2)
    """)


def measure_qualify(sc: Script, f: "Fault", pairs: list | None = None, var: str | None = None):
    """Qualification time of a fault, graded against count x period."""
    measure(sc, var or f"{f.prefix}_qualification_time_ms", pairs or [(f.dtc, ACTIVE)],
            f"Qualification time of {{{f.dtc}}} ({{{f.qualify_nominal} // {f.period}}} x {{{f.period}}} ms)",
            f.qualify_nominal, f.qualify_tolerance)


def measure_recover(sc: Script, f: "Fault", pairs: list | None = None, var: str | None = None):
    """Dequalification (heal) time of a fault, graded against count x period.

    A wrong DLC is healed by reloading the default frame (heal() started a CAN log
    first). The ECU can only count valid frames once the first full-length frame is on
    the bus, so the frames and the measurement's first 19 02 read are taken from that
    log: the time from the first read to the first full-length frame (negative when the
    frame was back before the measurement started) moves the expected heal time. The log
    also shows whether the reload left a gap in transmission and where the alive counter
    resumed."""
    var = var or f"{f.prefix}_dequalification_time_ms"
    what = f"Dequalification time of {{{f.dtc}}} ({{{f.recover_nominal} // {f.period}}} x {{{f.period}}} ms)"
    pairs = pairs or [(f.dtc, HEALED)]
    if f.kind != "dlc":
        measure(sc, var, pairs, what, f.recover_nominal, f.recover_tolerance)
        return
    p = f.prefix
    assert f"{p}_restore_started" in sc.flags, f"{sc.case.name}: heal({p}) must start the DLC restore log"
    measure(sc, var, pairs, what)
    capture_stop(sc, f"{p}_restore", None)
    sc.T(f"""
        # The tester's DTC reads: ReadDTCInformation, reportDTCByStatusMask (configuration_control).
        {p}_read_dtc_service = bytes(int(code, 16) for code in (ReadDTCInformation, RDTCI_DTCbyStatusMask))
        {p}_restore_reads = [
            frame_data.timestamp for frame_data in {p}_restore_frames
            if frame_data.id == DIAG_TX_ID and bytes(frame_data.payload[1:3]) == {p}_read_dtc_service]
        {p}_restore_rows = [frame_data for frame_data in {p}_restore_frames if frame_data.id == {p}_def['frame_ID']]
        {p}_restore_short = [
            index for index, frame_data in enumerate({p}_restore_rows) if len(frame_data.payload) != {p}_def['dlc']]
        {p}_restore_full = next((
            index for index in range(({p}_restore_short[-1] + 1) if {p}_restore_short else 0, len({p}_restore_rows))
            if len({p}_restore_rows[index].payload) == {p}_def['dlc']), None)
        if {p}_restore_full is None or not {p}_restore_reads:
            {p}_restart_ms = 0
            RESULT.LogCustomAction(
                "First full-length frame and first DTC read after the reload", "Both in the CAN log",
                "Not found: the heal time is graded from the measurement start", False)
        else:
            {p}_restart_ms = round(({p}_restore_rows[{p}_restore_full].timestamp - {p}_restore_reads[0]) / 1000, 1)
            RESULT.LogAction(
                f"{{{p}_frame}} first full-length frame after the reload (ms after the first DTC read)",
                {p}_restart_ms)
            if {p}_restore_short and {p}_restore_full > 0:
                {p}_restore_gap = round((
                    {p}_restore_rows[{p}_restore_full].timestamp
                    - {p}_restore_rows[{p}_restore_full - 1].timestamp) / 1000, 1)
                RESULT.LogAction(
                    f"{{{p}_frame}} interval across the reload (ms, period {{{p}_def['periodicity']}} ms)",
                    {p}_restore_gap)
            if {p}_counter_key in CAN_SIGNAL_START_BIT:
                {p}_restore_counts = [
                    extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[{p}_counter_key],
                                       MAH_CAN_SIGNAL_DEFS[{p}_counter_key]['bit_length'])
                    for frame_data in {p}_restore_rows[{p}_restore_full:{p}_restore_full + 3]]
                RESULT.LogAction(f"{{{p}_counter_key}} of the first frames after the reload", {p}_restore_counts)
    """)
    grade(sc, var, what, f"{f.recover_nominal} + {p}_restart_ms", f.recover_tolerance)


def dlc_restore_capture(sc: Script, f: "Fault"):
    """Start the CAN log the DLC heal is measured against: the frame and the DTC
    requests on its bus (DIAG_TX_ID, 19 02 of faultTimeMeasurement)."""
    capture(sc, f"{f.prefix}_restore", f"[{f.prefix}_def['frame_ID'], DIAG_TX_ID]",
            f"list(dict.fromkeys([{f.bus}, CAN_FD_CHANNEL_NAME]))", None, f"{f.prefix}_restore", start_only=True)


def measure_read(sc: Script, var: str, label: str, pairs: list, what: str):
    """Wait for a settled DTC state with faultTimeMeasurement (time recorded, not
    graded), then grade the complete list."""
    measure(sc, var, pairs, what)
    read_dtc(sc, label, pairs)


def ign_cycle(sc: Script):
    """Power cycle, then wait for the end of the ECU start-up before anything is read:
    the DTC status and the warning lamp are valid only after the proveout (shared
    PROVEOUT_COMPLETION_TIME, 8 s; on 2026-10-15 the status read 0x48 / 0x49 2 s after
    IGN ON, and a fault lamp came on 7 s after IGN ON)."""
    sc.T("""
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
    """)


def precondition(sc: Script, frames: list[tuple[str, str]] | None = None,
                 title: str = "Bench in normal condition, IGN ON, no DTC present"):
    """Fault-free profile, IGN ON, bench frames in their default state, no DTC.

    frames: (bus expression, frame expression) pairs of the bench frames the
    case drives; each is enabled and reloaded so it starts from its default.
    """
    sc.step(title)
    sc.T("PS.SetVoltage(NOMINAL_VOLTAGE)")
    for bus, frame in frames or []:
        sc.T(f"CAN.PeriodicEnableFrame({bus}, {frame})")
        sc.T(f"CAN.ReloadDefaultPeriodicFrame({bus}, {frame})")
    sc.T("""
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
    """)
    read_dtc(sc, "Bench is fault free with no DTC present", [])
    sc.end()


# ---------------------------------------------------------------------------
# Faults on bench-transmitted frames
# ---------------------------------------------------------------------------

@dataclass
class Fault:
    prefix: str
    kind: str
    dtc: str
    qualify: str
    recover: str
    apply: str
    heal: str
    describe: str
    describe_heal: str
    bus: str
    frame: str

    @property
    def period(self) -> str:
        return f"{self.prefix}_def['periodicity']"

    @property
    def qualify_nominal(self) -> str:
        """Qualification time the configuration gives: detection count x period."""
        return f"{self.prefix}_qualify_nominal_ms"

    @property
    def recover_nominal(self) -> str:
        """Dequalification time the configuration gives: recovery count x period."""
        return f"{self.prefix}_recover_nominal_ms"

    @property
    def qualify_tolerance(self) -> str:
        return f"{self.prefix}_qualify_tolerance_ms"

    @property
    def recover_tolerance(self) -> str:
        return f"{self.prefix}_recover_tolerance_ms"


def frame_def_line(var: str, frame_var: str) -> str:
    return f"{var} = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == {frame_var})"


def fault_timing(sc: Script, p: str, mode_expr: str):
    """Nominal fault times (count x period, canc_config FAULT_THRESHOLDS) and the
    tolerance they are graded with: the timing tolerance of the cases
    (CAN_FAULT_TIMING_TOLERANCE_PERCENT, 10 %) both ways; grade() adds the measured lag
    of faultTimeMeasurement to the upper limit only. <p>_qualify_ms (nominal plus 10 %)
    is the full wait of the checks where a DTC must not qualify."""
    sc.S(f"""
        {p}_qualify_nominal_ms = qualification_ms({mode_expr}, {p}_def['periodicity'])
        {p}_recover_nominal_ms = recovery_ms({mode_expr}, {p}_def['periodicity'])
        {p}_qualify_tolerance_ms = int({p}_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
        {p}_recover_tolerance_ms = int({p}_recover_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
        {p}_qualify_ms = int({p}_qualify_nominal_ms * margin)
    """)


def fault(sc: Script, prefix: str, kind: str, frame: str | None = None, signal_key: str | None = None,
          frame_expr: str | None = None, mode: str | None = None) -> Fault:
    """Declare one fault: setup lines plus the code that applies and heals it.

    kind: loss (stop the frame), dlc, crc, counter (message content failure) or scf
    (signal content failure). For a loss, mode is 'node_absent' or 'message_timeout'
    when the case states which fault stopping the frame creates; without it
    canc_config decides (node absent on a KEY_TX_FRAMES frame, timeout otherwise).
    The DTC always comes from canc_config.
    """
    return _fault(sc, prefix, kind, frame, signal_key, frame_expr, mode)


def _fault(sc: Script, p: str, kind: str, frame: str | None, signal_key: str | None,
           frame_expr: str | None, mode: str | None) -> Fault:
    if kind == "scf":
        assert signal_key, "a signal content failure needs a signal"
        sc.S(f"""
            {p}_key = {py(signal_key)}
            {p}_def = MAH_CAN_SIGNAL_DEFS[{p}_key]
            {p}_frame = {p}_def['frame']
            {p}_bus = {p}_def['bus']
            {p}_dtc = CAN_TX_MESSAGE_CONFIG[{p}_frame]['signal_content_failure_dtcs'].get({p}_def['signal'])
            {p}_invalid = {p}_def.get('Invalid_Value')
            {p}_recovery = {p}_def.get('SCF_Recovery_Value')
            if {p}_recovery is None:
                {p}_recovery = {p}_def.get('Default_Value')
        """)
        fault_timing(sc, p, "'signal_content'")
        sc.need(f"f'signal content failure DTC of {{{p}_key}}'", f"{p}_dtc")
        sc.need(f"f'invalid value of {{{p}_key}}'", f"{p}_invalid")
        sc.need(f"f'recovery value of {{{p}_key}}'", f"{p}_recovery")
        sc.log_defs.append(f"{p}_def")
        return Fault(p, kind, f"{p}_dtc", f"{p}_qualify_ms", f"{p}_recover_nominal_ms",
                     f"CAN.ChangeSignalValue({p}_bus, {p}_frame, {p}_def['signal'], str({p}_invalid))",
                     f"CAN.ChangeSignalValue({p}_bus, {p}_frame, {p}_def['signal'], str({p}_recovery))",
                     (f"inject invalid value {MAH[signal_key].get('Invalid_Value')} for {MAH[signal_key]['signal']}"
                      if MAH[signal_key].get('Invalid_Value') is not None
                      else f"inject the invalid value for {MAH[signal_key]['signal']}"),
                     f"restore valid value for {MAH[signal_key]['signal']}",
                     f"{p}_bus", f"{p}_frame")

    sc.S(f"{p}_frame = {frame_expr or py(frame)}")
    sc.S(frame_def_line(f"{p}_def", f"{p}_frame"))
    sc.S(f"{p}_bus = {p}_def['bus']")
    sc.log_defs.append(f"{p}_def")
    shown = frame or "the key frame"
    if kind == "loss":
        if mode:
            sc.S(f"""
                {p}_mode = {py(mode)}
                {p}_dtc = resolve_dtc_for_event({p}_mode, {p}_frame)
            """)
        else:
            sc.S(f"""
                {p}_mode = 'node_absent' if is_key_message({p}_frame) else 'message_timeout'
                {p}_dtc = resolve_dtc_for_event('frame_disabled', {p}_frame)
            """)
        fault_timing(sc, p, f"{p}_mode")
        sc.need(f"f'frame-loss DTC of {{{p}_frame}}'", f"{p}_dtc")
        return Fault(p, kind, f"{p}_dtc", f"{p}_qualify_ms", f"{p}_recover_nominal_ms",
                     f"CAN.PeriodicDisableFrame({p}_bus, {p}_frame)",
                     f"CAN.PeriodicEnableFrame({p}_bus, {p}_frame)\n"
                     f"CAN.ReloadDefaultPeriodicFrame({p}_bus, {p}_frame)",
                     f"stop transmission of {shown}", f"resume valid transmission of {shown}",
                     f"{p}_bus", f"{p}_frame")
    if kind == "dlc":
        # The frame itself goes out with the shorter payload: a second simulated frame
        # on the same identifier is refused by ARIA ("Frame ID ... already in
        # simulation", 2026-10-15). The bench-computed CRC / alive counter are held
        # while the payload is short and recomputed once the default payload is back.
        sc.S(f"""
            {p}_dtc = get_frame_message_content_failure_dtc({p}_frame)[0]
            if {p}_dtc is None:
                {p}_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get({p}_frame)
            {p}_error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[{p}_def['dlc']])
            {p}_dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals({p}_frame)
                                   if key in MAH_CAN_SIGNAL_DEFS]
            {p}_counter_key = next((
                key for key in get_message_content_failure_signals({p}_frame) if 'CRC' not in key.upper()), None)
        """)
        fault_timing(sc, p, "'message_content'")
        sc.need(f"f'message content failure (DLC) DTC of {{{p}_frame}}'", f"{p}_dtc")
        return Fault(p, kind, f"{p}_dtc", f"{p}_qualify_ms", f"{p}_recover_nominal_ms",
                     f"for {p}_dynamic_signal in {p}_dynamic_signals:\n"
                     f"    CAN.DynamicDisableSignal({p}_bus, {p}_frame, {p}_dynamic_signal)\n"
                     f"CAN.SetPeriodicFrame({p}_bus, {p}_frame, {p}_def['frame_ID'], {p}_def['periodicity'],\n"
                     f"                     {p}_error_payload, {p}_def['is_fd'])\n"
                     f"CAN.PeriodicEnableFrame({p}_bus, {p}_frame)",
                     f"CAN.ReloadDefaultPeriodicFrame({p}_bus, {p}_frame)\n"
                     f"for {p}_dynamic_signal in {p}_dynamic_signals:\n"
                     f"    CAN.DynamicEnableSignal({p}_bus, {p}_frame, {p}_dynamic_signal)\n"
                     f"CAN.PeriodicEnableFrame({p}_bus, {p}_frame)",
                     f"inject incorrect DLC on {shown}", f"restore correct DLC on {shown}",
                     f"{p}_bus", f"{p}_frame")
    if kind in ("crc", "counter"):
        test = "in" if kind == "crc" else "not in"
        what = "CRC" if kind == "crc" else "alive counter"
        sc.S(f"""
            {p}_signal = next((s for s in get_message_content_failure_signals({p}_frame) if 'CRC' {test} s.upper()), None)
            {p}_signal_name = MAH_CAN_SIGNAL_DEFS.get({p}_signal, {{}}).get('signal')
            {p}_dtc = get_message_content_failure_dtcs({p}_frame).get({p}_signal)
        """)
        fault_timing(sc, p, "'message_content'")
        sc.need(f"f'message content failure ({what}) DTC of {{{p}_frame}}'", f"{p}_dtc")
        return Fault(p, kind, f"{p}_dtc", f"{p}_qualify_ms", f"{p}_recover_nominal_ms",
                     f"CAN.DynamicDisableSignal({p}_bus, {p}_frame, {p}_signal_name)",
                     f"CAN.DynamicEnableSignal({p}_bus, {p}_frame, {p}_signal_name)",
                     f"inject {what} error on {shown} ({what} no longer updated)",
                     f"restore correct {what} on {shown}",
                     f"{p}_bus", f"{p}_frame")
    raise ValueError(kind)


def apply(sc: Script, f: Fault):
    sc.T(f.apply)


def heal(sc: Script, f: Fault, measured: bool = True):
    """Remove the fault. measured: measure_recover() times the heal next, which for a
    wrong DLC needs the CAN log started here, before the reload."""
    if f.kind == "dlc" and measured:
        dlc_restore_capture(sc, f)
        sc.flags.add(f"{f.prefix}_restore_started")
    sc.T(f.heal)


def cleanup_heal(sc: Script, f: Fault):
    sc.C(f.heal)


# ---------------------------------------------------------------------------
# Frame capture (dedicated CAN log, read back after it is stopped)
# ---------------------------------------------------------------------------

def capture(sc: Script, var: str, ids_expr: str, buses_expr: str, window_expr: str | None, label: str,
            start_only: bool = False):
    """Log the given frame IDs on the given buses for a window and read the frames
    back. Leaves <var>_frames (objects with .timestamp in microseconds, .id and
    .payload, as apym's CanFrame has)."""
    sc.T(f"""
        {var}_ids = {ids_expr}
        {var}_file = os.path.splitext(log_path)[0] + {py('_' + label + '.txt')}
        {var}_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + {py('_' + label)}, filepath={var}_file,
            listOption={var}_ids, channel_names={buses_expr})
    """)
    if start_only:
        return
    capture_stop(sc, var, window_expr)


def capture_stop(sc: Script, var: str, window_expr: str | None):
    """Stop the dedicated log and read its frames from the file ARIA wrote.

    ARIA writes a log with any extension other than .asc/.blf as text, one frame per
    line: "<time s>\\t<Can|CanFd> <channel>  <RX|TX>  l=<length>, id=<hex>, <payload
    bytes>". The file is parsed directly: on the bench (apym 2.6.4 with ARIA 5.20)
    CAN.ReadFromCanLogFile drops every CAN-FD frame and raises "Failed to decode log
    data", although the file holds them all (2026-10-15 run).
    """
    if window_expr:
        sc.T(f"Wait({window_expr})")
    sc.T(f"""
        CAN.StopLoggingToFile({var}_logger)
        {var}_frames = []
        if os.path.isfile({var}_file):
            with open({var}_file, encoding='utf-8', errors='replace') as {var}_log:
                {var}_fields = [line.split(',', 2) for line in {var}_log if ' id=' in line and line.count(',') >= 2]
            {var}_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in {var}_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {{os.path.basename({var}_file)}} written", "File present",
                                   "File missing: no frames to evaluate", False)
        {var}_frames = [frame_data for frame_data in {var}_frames if frame_data.id in {var}_ids]
    """)


# ---------------------------------------------------------------------------
# Node templates (EPS, IEB, HPCC, HPCAd, FR_ZONE, VCU)
# ---------------------------------------------------------------------------

def common_setup(sc: Script):
    sc.S("""
        margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
        # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
        # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
        measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    """)


def t_fault_cycle(sc: Script, kind: str, frame: str | None, signal_key: str | None = None,
                  mode: str | None = None):
    """Create a fault, see it qualify (0x0B), heal it in the same cycle (0x0A), then
    see it historic after an IGN cycle (0x08)."""
    common_setup(sc)
    f = fault(sc, "fault", kind, frame=frame, signal_key=signal_key, mode=mode)
    precondition(sc, [(f.bus, f.frame)])
    sc.step(f"Create fault - {f.describe}")
    apply(sc, f)
    measure_qualify(sc, f)
    read_dtc(sc, "DTC active after the qualification time", [(f.dtc, ACTIVE)])
    sc.end()
    sc.step(f"Remove fault - {f.describe_heal}")
    heal(sc, f)
    measure_recover(sc, f)
    read_dtc(sc, "DTC healed after the dequalification time", [(f.dtc, HEALED)])
    sc.end()
    sc.step("Cycle IGN and read DTC")
    ign_cycle(sc)
    read_dtc(sc, "DTC historic after the IGN cycle", [(f.dtc, HISTORIC)])
    sc.end()
    cleanup_heal(sc, f)


def t_priority(sc: Script, lower: tuple, higher: tuple):
    """Lower-priority fault qualified first, then the higher-priority one. Each
    fault is (kind, frame[, signal key[, frame expression[, loss mode]]])."""
    common_setup(sc)
    lo_kind, lo_frame, lo_key, lo_expr, lo_mode = (list(lower) + [None, None, None])[:5]
    hi_kind, hi_frame, hi_key, hi_expr, hi_mode = (list(higher) + [None, None, None])[:5]
    lo = fault(sc, "lower", lo_kind, frame=lo_frame, signal_key=lo_key, frame_expr=lo_expr, mode=lo_mode)
    hi = fault(sc, "higher", hi_kind, frame=hi_frame, signal_key=hi_key, frame_expr=hi_expr, mode=hi_mode)
    precondition(sc, [(lo.bus, lo.frame), (hi.bus, hi.frame)])
    sc.step(f"Create and qualify the lower-priority fault - {lo.describe}")
    apply(sc, lo)
    measure_qualify(sc, lo)
    read_dtc(sc, "Lower-priority DTC active", [(lo.dtc, ACTIVE)])
    sc.end()
    sc.step(f"Create the higher-priority fault - {hi.describe}")
    apply(sc, hi)
    measure_qualify(sc, hi)
    sc.T("""
        # Before an IGN cycle the lower-priority DTC may still read active, so the
        # list is recorded rather than graded.
        RESULT.LogAction("DTCs before the IGN cycle", CAN.SendDiagByValues(Read_DTC_Req_CANC))
    """)
    sc.end()
    # Both faults stay applied through the IGN cycles, so the higher-priority DTC
    # qualifies again after each start-up; the measurement waits for it.
    sc.step("Cycle IGN and read DTC")
    ign_cycle(sc)
    measure_read(sc, "settle_time_ms", "Higher-priority DTC active, lower-priority DTC healed",
                 [(hi.dtc, ACTIVE), (lo.dtc, HEALED)], "Time until the DTCs settle after the IGN cycle")
    sc.end()
    sc.step("Cycle IGN and read DTC")
    ign_cycle(sc)
    measure_read(sc, "settle_time_ms", "Higher-priority DTC active, lower-priority DTC historic",
                 [(hi.dtc, ACTIVE), (lo.dtc, HISTORIC)], "Time until the DTCs settle after the IGN cycle")
    sc.end()
    cleanup_heal(sc, hi)
    cleanup_heal(sc, lo)


def voltage_setup(sc: Script, level: str):
    if level == "over":
        sc.S("""
            voltage_level = CANC_OVERVOLTAGE_TEST_VOLTAGE
            voltage_dtc = Over_Voltage
        """)
    else:
        sc.S("""
            voltage_level = CANC_UNDERVOLTAGE_TEST_VOLTAGE
            voltage_dtc = Under_Voltage
        """)
    sc.C("PS.SetVoltage(NOMINAL_VOLTAGE)")


def level_text(level: str) -> str:
    return "over-voltage" if level == "over" else "under-voltage"


def t_voltage(sc: Script, kind: str, frame: str | None, signal_key: str | None, level: str):
    """A CAN fault created during an abnormal supply stays suppressed until the
    supply is back, then qualifies, heals and becomes historic."""
    common_setup(sc)
    f = fault(sc, "fault", kind, frame=frame, signal_key=signal_key)
    voltage_setup(sc, level)
    precondition(sc, [(f.bus, f.frame)])
    sc.step(f"Create {level_text(level)} condition")
    sc.T("PS.SetVoltage(voltage_level)")
    measure_read(sc, "voltage_time_ms", "Voltage DTC active", [("voltage_dtc", V_ACTIVE)], "Time until the voltage DTC is active")
    sc.end()
    sc.step(f"Create CAN fault while the abnormal voltage is present - {f.describe}")
    apply(sc, f)
    # The whole qualification time passes before the read: the CAN DTC must not appear.
    sc.T(f"Wait({f.qualify})")
    read_dtc(sc, "CAN DTC remains suppressed while the abnormal voltage is present", [("voltage_dtc", V_ACTIVE)])
    sc.end()
    # Monitoring restarts with the supply (NM restart delay first), so the CAN DTC's
    # time from the restore is recorded, not graded as a qualification time.
    sc.step("Restore the supply voltage while maintaining the CAN fault")
    sc.T("PS.SetVoltage(NOMINAL_VOLTAGE)")
    measure_read(sc, "settle_time_ms", "Voltage DTC healed, CAN DTC active",
                 [("voltage_dtc", V_HEALED), (f.dtc, ACTIVE)], "Time until the voltage DTC is healed and the CAN DTC active")
    sc.end()
    sc.step("Cycle IGN and read DTC")
    ign_cycle(sc)
    measure_read(sc, "settle_time_ms", "Voltage DTC historic, CAN DTC active",
                 [("voltage_dtc", V_HISTORIC), (f.dtc, ACTIVE)], "Time until the DTCs settle after the IGN cycle")
    sc.end()
    sc.step(f"Remove CAN fault - {f.describe_heal}")
    heal(sc, f)
    measure_recover(sc, f)
    read_dtc(sc, "CAN DTC healed", [("voltage_dtc", V_HISTORIC), (f.dtc, HEALED)])
    sc.end()
    sc.step("Cycle IGN and read DTC")
    ign_cycle(sc)
    read_dtc(sc, "CAN DTC historic", [("voltage_dtc", V_HISTORIC), (f.dtc, HISTORIC)])
    sc.end()
    cleanup_heal(sc, f)


def t_secoc(sc: Script, signal_key: str):
    """Only the freshness value or MAC changes; the CRC stays valid, so no
    message content failure is reported."""
    common_setup(sc)
    d = MAH[signal_key]
    sc.S(f"""
        secoc_key = {py(signal_key)}
        secoc_def = MAH_CAN_SIGNAL_DEFS[secoc_key]
        frame = secoc_def['frame']
        bus = secoc_def['bus']
        period_ms = secoc_def['periodicity']
        secoc_values = list(secoc_def.get('TestCase_values') or [])
        mcf_dtc = get_frame_message_content_failure_dtc(frame)[0]
        # Long enough for a message content failure to qualify if one were detected.
        observe_ms = int(qualification_ms('message_content', period_ms) * margin)
        dwell_ms = max(CANC_SETTLE_FRAMES * period_ms, observe_ms // max(len(secoc_values), 1))
    """)
    sc.need("f'representative values of {secoc_key}'", "secoc_values or None")
    sc.need("f'message content failure DTC of {frame}'", "mcf_dtc")
    sc.log_defs.append("secoc_def")
    precondition(sc, [("bus", "frame")])
    sc.step(f"Change only {d['signal']} through representative values, all other fields unchanged")
    sc.T("""
        CAN.DynamicDisableSignal(bus, frame, secoc_def['signal'])
        elapsed_ms = 0
        while elapsed_ms < observe_ms:
            for value in secoc_values:
                CAN.ChangeSignalValue(bus, frame, secoc_def['signal'], str(value))
                Wait(dwell_ms)
                elapsed_ms += dwell_ms
                read_back = str(CAN.GetSignalFromFrame(bus, frame, secoc_def['signal'])).strip()
                try:
                    read_back = str(int(read_back, 16) if read_back.lower().startswith("0x") else int(float(read_back)))
                except ValueError:
                    pass
                RESULT.InterpretEqualResult(f"{frame} carries {secoc_def['signal']} = {value}", read_back, str(value))
    """)
    sc.end()
    sc.step(f"Check for a CRC-related failure while only {d['signal']} changes")
    sc.T("""
        # CheckSingleDTC takes the three DTC bytes as one number ('0xE7 0x25 0x00' -> 0xE72500).
        mcf_check = CAN.CheckSingleDTC(code=int(str(mcf_dtc).replace('0x', '').replace(' ', ''), 16))
        RESULT.InterpretEqualResult(
            f"No message content failure (CRC) DTC {mcf_dtc} for {frame}",
            str(mcf_check[-1]).endswith("not present"), True)
        RESULT.LogAction("DTCs while only the field changed", CAN.SendDiagByValues(Read_DTC_Req_CANC))
    """)
    sc.end()
    sc.C("""
        CAN.DynamicEnableSignal(bus, frame, secoc_def['signal'])
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
    """)


def t_alive_counter(sc: Script, counter_key: str):
    """The alive counter of a received frame runs, rolls over and restarts
    without a message content failure."""
    common_setup(sc)
    d = MAH[counter_key]
    sc.S(f"""
        counter_key = {py(counter_key)}
        counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
        frame = counter_def['frame']
        bus = counter_def['bus']
        period_ms = counter_def['periodicity']
        counter_bits = counter_def['bit_length']
        counter_start_bit = CAN_SIGNAL_START_BIT[counter_key]
        counter_window_ms = (CANC_COUNTER_SAMPLE_ROLLOVERS * (1 << counter_bits) + CANC_WINDOW_MARGIN_FRAMES) * period_ms
        restart_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + CANC_WINDOW_MARGIN_FRAMES) * period_ms
    """)
    sc.log_defs.append("counter_def")
    precondition(sc, [("bus", "frame")])
    sc.step(f"Observe {d['signal']} over consecutive messages until it rolls over")
    capture(sc, "counter", "[counter_def['frame_ID']]", "[bus]", "counter_window_ms", "alive_counter")
    sc.T("""
        counters = [extract_counter(frame_data.payload, counter_start_bit, counter_bits) for frame_data in counter_frames]
        counter_verdict = validate_counter(counters, counter_bits)
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(counters), (1 << counter_bits) + 1, float('inf'))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} increments by one from frame to frame",
                                    str(counter_verdict['errors'][:10]), "[]")
        RESULT.InterpretEqualResultRange(f"{counter_def['signal']} rollovers", counter_verdict['rollovers'], 1, float('inf'))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} range",
                                    f"{min(counters, default=None)}..{max(counters, default=None)}",
                                    f"{counter_def['MIN']}..{counter_def['MAX']}")
    """)
    read_dtc(sc, "No message content failure while the counter runs and rolls over", [])
    sc.end()
    sc.step(f"Cycle IGN and observe {d['signal']} after transmission restarts")
    ign_cycle(sc)
    capture(sc, "restart", "[counter_def['frame_ID']]", "[bus]", None, "alive_counter_restart", start_only=True)
    sc.T("CAN.ReloadDefaultPeriodicFrame(bus, frame)")
    capture_stop(sc, "restart", "restart_window_ms")
    sc.T("""
        restart_counters = [extract_counter(frame_data.payload, counter_start_bit, counter_bits)
                            for frame_data in restart_frames]
        restart_errors = validate_counter(restart_counters, counter_bits)['errors']
        RESULT.LogAction(f"{counter_def['signal']} after the restart", str(restart_counters[:20]))
        # Either the capture opens on the reset value, or the one break in it is the
        # reset. The bench increments the counter before it sends a reloaded frame, so
        # the first value on the bus is MIN + 1 (2026-10-15 logs: EPS1_FD_10, HPCAd_1_10
        # and FR_ZONE2_100 all restarted at 1).
        counter_restart_values = [counter_def['MIN'], counter_def['MIN'] + 1]
        counter_reset = ((not restart_errors and restart_counters[:1] and restart_counters[0] in counter_restart_values)
                         or (len(restart_errors) == 1 and restart_errors[0][2] in counter_restart_values))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} restarts from {counter_def['MIN']} "
                                    f"(first frame after the reload {counter_def['MIN']} or {counter_def['MIN'] + 1})",
                                    bool(counter_reset), True)
    """)
    read_dtc(sc, "No message content failure after the restart", [])
    sc.end()
    sc.C("CAN.ReloadDefaultPeriodicFrame(bus, frame)")


def t_integrity(sc: Script, crc_key: str):
    """The CRC field follows the frame content; a CRC that does not is detected."""
    common_setup(sc)
    d = MAH[crc_key]
    sc.S(f"""
        crc_key = {py(crc_key)}
        crc_def = MAH_CAN_SIGNAL_DEFS[crc_key]
        frame = crc_def['frame']
        bus = crc_def['bus']
        period_ms = crc_def['periodicity']
        crc_values = list(crc_def.get('TestCase_values') or [])
        mcf_dtc = get_message_content_failure_dtcs(frame).get(crc_key)
        mcf_qualify_ms = int(qualification_ms('message_content', period_ms) * margin)
        mcf_recover_nominal_ms = recovery_ms('message_content', period_ms)
        mcf_recover_tolerance_ms = int(mcf_recover_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
        dwell_ms = max(CANC_SETTLE_FRAMES * period_ms, mcf_qualify_ms // max(len(crc_values), 1))
        monitor_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + CANC_WINDOW_MARGIN_FRAMES) * period_ms
    """)
    sc.need("f'message content failure DTC of {crc_key}'", "mcf_dtc")
    sc.need("f'representative values of {crc_key}'", "crc_values or None")
    sc.log_defs.append("crc_def")
    sc.notes.append("Besides the representative values the case lists, the script checks that a CRC "
                    "held at values that do not match the frame content qualifies the message content "
                    "failure DTC, and that it heals once the computed CRC is restored.")
    precondition(sc, [("bus", "frame")])
    sc.step(f"Monitor {d['signal']} while the bench computes it")
    capture(sc, "crc", "[crc_def['frame_ID']]", "[bus]", "monitor_window_ms", "crc_monitor")
    sc.T("""
        crc_seen = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[crc_key], crc_def['bit_length'])
                    for frame_data in crc_frames]
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(crc_seen), CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResult(f"{crc_def['signal']} follows the changing frame content",
                                    len(set(crc_seen)) > 1, True)
    """)
    read_dtc(sc, "No DTC while the CRC is valid", [])
    sc.end()
    sc.step(f"Transmit representative raw values for {d['signal']}")
    sc.T("""
        CAN.DynamicDisableSignal(bus, frame, crc_def['signal'])
        for value in crc_values:
            CAN.ChangeSignalValue(bus, frame, crc_def['signal'], str(value))
            Wait(dwell_ms)
            read_back = str(CAN.GetSignalFromFrame(bus, frame, crc_def['signal'])).strip()
            try:
                read_back = str(int(read_back, 16) if read_back.lower().startswith("0x") else int(float(read_back)))
            except ValueError:
                pass
            RESULT.InterpretEqualResult(f"{frame} carries {crc_def['signal']} = {value} (physical {value * crc_def['Factor'] + crc_def['Offset']})",
                                        read_back, str(value))
    """)
    # The values were held for about the qualification time already, so the time the
    # DTC still takes is recorded rather than graded as a qualification time.
    measure_read(sc, "mcf_settle_time_ms", "A CRC that does not match the frame content is reported",
                 [("mcf_dtc", ACTIVE)], "Time after the last value until the message content failure is active")
    sc.end()
    sc.step(f"Restore the computed {d['signal']}")
    sc.T("CAN.DynamicEnableSignal(bus, frame, crc_def['signal'])")
    measure(sc, "mcf_dequalification_time_ms", [("mcf_dtc", HEALED)],
            "Dequalification time of {mcf_dtc} ({mcf_recover_nominal_ms // period_ms} x {period_ms} ms)",
            "mcf_recover_nominal_ms", "mcf_recover_tolerance_ms")
    read_dtc(sc, "Message content failure healed", [("mcf_dtc", HEALED)])
    sc.end()
    sc.C("""
        CAN.DynamicEnableSignal(bus, frame, crc_def['signal'])
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
    """)


BENCH_PERIOD_NOTE = ("The frame is sent by the bench (ARIA software simulation), so the script grades its mean period "
                     "against the DBC cycle time and the absence of communication DTCs, and records the spread of "
                     "single intervals: on 2026-10-15 ARIA's simulated frames kept an exact mean (10.00 / 50.0 / "
                     "100.0 ms) but single intervals of a 10 ms frame ran from 1.9 to 24 ms, which is the bench's "
                     "timing, not the ECU's.")


def periodicity_checks(sc: Script, var: str, period_expr: str, frame_name_expr: str, sender: str = "ecu"):
    """sender 'ecu': every interval within the tolerance (the ECU's own TX timing).
    sender 'bench': the mean interval within the tolerance, the spread recorded."""
    sc.T(f"""
        {var}_times = [frame_data.timestamp / 1000 for frame_data in {var}_frames]
        {var}_deltas = [round(later - earlier, 3) for earlier, later in zip({var}_times, {var}_times[1:])]
        RESULT.InterpretEqualResultRange(f"{{{frame_name_expr}}} frames captured", len({var}_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
    """)
    if sender == "bench":
        if BENCH_PERIOD_NOTE not in sc.notes:
            sc.notes.append(BENCH_PERIOD_NOTE)
        sc.T(f"""
            RESULT.InterpretEqualResultRange(f"{{{frame_name_expr}}} mean time between consecutive frames (ms)",
                                             round(sum({var}_deltas) / len({var}_deltas), 3) if {var}_deltas else None,
                                             {period_expr} * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                             {period_expr} * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
            RESULT.InsertComment(f"{{{frame_name_expr}}} single intervals (bench timing): "
                                 f"{{min({var}_deltas, default=None)}} to {{max({var}_deltas, default=None)}} ms")
        """)
        return
    sc.T(f"""
        RESULT.InterpretEqualResultRange(f"{{{frame_name_expr}}} time between consecutive frames (ms)", {var}_deltas,
                                         {period_expr} * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         {period_expr} * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InterpretEqualResult(f"{{{frame_name_expr}}} has no gap outside the tolerance",
                                    str(detect_time_gap({var}_times, {period_expr},
                                                        tolerance=CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)), "[]")
    """)


def t_periodicity(sc: Script, frame: str):
    common_setup(sc)
    sc.S(f"""
        frame = {py(frame)}
        {frame_def_line('frame_def', 'frame')}
        bus = frame_def['bus']
        period_ms = frame_def['periodicity']
        window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + CANC_WINDOW_MARGIN_FRAMES) * period_ms
    """)
    sc.log_defs.append("frame_def")
    precondition(sc, [("bus", "frame")])
    for window, title in ((1, f"Measure the time between consecutive {frame} frames"),
                          (2, "Continue monitoring over additional cycles")):
        sc.step(title)
        capture(sc, f"window{window}", "[frame_def['frame_ID']]", "[bus]", "window_ms", f"periodicity_{window}")
        periodicity_checks(sc, f"window{window}", "period_ms", "frame", sender="bench")
        sc.end()
    sc.step("Read DTC")
    read_dtc(sc, "No communication fault during normal transmission", [])
    sc.end()


def t_decode(sc: Script, signal_key: str):
    """Representative raw values are carried in the frame and decode to the
    physical value the scaling and offset give."""
    common_setup(sc)
    d = MAH[signal_key]
    integrity = signal_key in canc_config.get_message_content_failure_signals(d["frame"])
    sc.S(f"""
        signal_key = {py(signal_key)}
        signal_def = MAH_CAN_SIGNAL_DEFS[signal_key]
        frame = signal_def['frame']
        bus = signal_def['bus']
        signal = signal_def['signal']
        bits = signal_def['bit_length']
        signal_values = list(signal_def.get('TestCase_values') or [])
    """)
    sc.need("f'representative values of {signal_key}'", "signal_values or None")
    sc.log_defs.append("signal_def")
    precondition(sc, [("bus", "frame")])
    sc.step(f"Transmit representative raw values for {d['signal']} and compare the decoded value")
    if integrity:
        sc.T("""
            # The bench normally computes this field itself; hold it while it is driven.
            CAN.DynamicDisableSignal(bus, frame, signal)
        """)
    sc.T("""
        for raw in signal_values:
            CAN.ChangeSignalValue(bus, frame, signal, str(raw))
            Wait(CANC_SETTLE_FRAMES * signal_def['periodicity'])
            read_back = str(CAN.GetSignalFromFrame(bus, frame, signal)).strip()
            try:
                read_raw = int(read_back, 16) if read_back.lower().startswith("0x") else int(float(read_back))
            except ValueError:
                read_raw = None
                # Not a number: ARIA's own answer (e.g. a signal its database lacks) goes to the report.
                RESULT.InsertComment(f"ARIA read-back of {frame}.{signal}: {read_back}")
            raw_unsigned = raw % (1 << bits)
            RESULT.InterpretEqualResult(
                f"{frame} carries {signal} raw {raw} (0x{raw_unsigned:X})",
                str(None if read_raw is None else read_raw % (1 << bits)), str(raw_unsigned))
            physical = round(raw_to_physical(raw_unsigned, scaling=signal_def['Factor'], offset=signal_def['Offset'],
                                             bits=bits, signed=bool(signal_def.get('Signed'))), 6)
            RESULT.InterpretEqualResultRange(
                f"{signal} raw {raw} decodes to {physical:g} (raw x {signal_def['Factor']} + {signal_def['Offset']})",
                physical, signal_def['MIN'], signal_def['MAX'])
    """)
    sc.end()
    sc.step("Restore the default frame content and read DTC")
    if integrity:
        sc.T("CAN.DynamicEnableSignal(bus, frame, signal)")
    sc.T("""
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        Wait(CANC_RESTORE_FRAMES * signal_def['periodicity'])
    """)
    read_dtc(sc, "No DTC after the representative values", [])
    sc.end()
    if integrity:
        sc.C("CAN.DynamicEnableSignal(bus, frame, signal)")
    sc.C("CAN.ReloadDefaultPeriodicFrame(bus, frame)")


def t_vin_decode(sc: Script):
    common_setup(sc)
    sc.S("""
        vin_def = MAH_CAN_SIGNAL_DEFS['VIN_NUMBER']
        vin_bytes = VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY]
    """)
    sc.log_defs.append("vin_def")
    precondition(sc, [("vin_def['bus']", "vin_def['frame']")])
    sc.step("Transmit the project VIN in VIN_NUMBER and compare the decoded value")
    sc.T("""
        simulate_vin_can_signals_fd(vin_bytes)
        Wait(CANC_SETTLE_FRAMES * vin_def['periodicity'])
        compare_vin_can_signals_fd(vin_bytes)
    """)
    sc.end()
    sc.step("Read DTC")
    read_dtc(sc, "No DTC with the project VIN on the bus", [])
    sc.end()


def t_both_frames_normal(sc: Script, frames: list[str]):
    common_setup(sc)
    for i, frame in enumerate(frames, 1):
        sc.S(f"""
            frame_{i} = {py(frame)}
            {frame_def_line(f'frame_{i}_def', f'frame_{i}')}
        """)
        sc.log_defs.append(f"frame_{i}_def")
    sc.S("window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + CANC_WINDOW_MARGIN_FRAMES) * max("
         + ", ".join(f"frame_{i}_def['periodicity']" for i in range(1, len(frames) + 1)) + ")")
    precondition(sc, [(f"frame_{i}_def['bus']", f"frame_{i}") for i in range(1, len(frames) + 1)])
    sc.step(f"Monitor {' and '.join(frames)} for multiple cycles")
    ids = "[" + ", ".join(f"frame_{i}_def['frame_ID']" for i in range(1, len(frames) + 1)) + "]"
    buses = "sorted({" + ", ".join(f"frame_{i}_def['bus']" for i in range(1, len(frames) + 1)) + "})"
    capture(sc, "both", ids, buses, "window_ms", "frames_normal")
    for i in range(1, len(frames) + 1):
        sc.T(f"frame_{i}_frames = [frame_data for frame_data in both_frames if frame_data.id == frame_{i}_def['frame_ID']]")
        periodicity_checks(sc, f"frame_{i}", f"frame_{i}_def['periodicity']", f"frame_{i}", sender="bench")
    sc.end()
    sc.step("Read DTC")
    read_dtc(sc, "No node-absent, message-timeout or message-content DTC", [])
    sc.end()


def t_resume_corrupted(sc: Script, frame: str, mcf_kind: str, mode: str):
    """The frame stops, then comes back with corrupted content: the loss fault
    heals and the message content failure qualifies."""
    common_setup(sc)
    loss = fault(sc, "loss", "loss", frame=frame, mode=mode)
    mcf = fault(sc, "mcf", mcf_kind, frame=frame)
    precondition(sc, [(loss.bus, loss.frame)])
    sc.step(f"Create the primary fault - {loss.describe}")
    apply(sc, loss)
    measure_qualify(sc, loss)
    read_dtc(sc, "Frame-loss DTC active", [(loss.dtc, ACTIVE)])
    sc.end()
    sc.step(f"Resume transmission with corrupted content - {mcf.describe}")
    if mcf_kind != "dlc":
        # The wrong-DLC fault puts the frame back on the bus itself.
        sc.T(loss.heal)
    apply(sc, mcf)
    # With the frame back the frame-loss DTC heals (recovery count) well before the
    # message content failure qualifies (detection count): the measurement waits for
    # both in that order, so its time is the qualification time of the content failure.
    measure_qualify(sc, mcf, [(loss.dtc, HEALED), (mcf.dtc, ACTIVE)])
    read_dtc(sc, "Message content failure active, frame-loss DTC healed", [(mcf.dtc, ACTIVE), (loss.dtc, HEALED)])
    sc.end()
    sc.step("Cycle IGN and read DTC")
    ign_cycle(sc)
    measure_read(sc, "settle_time_ms", "Message content failure active, frame-loss DTC historic",
                 [(mcf.dtc, ACTIVE), (loss.dtc, HISTORIC)], "Time until the DTCs settle after the IGN cycle")
    sc.end()
    cleanup_heal(sc, mcf)
    cleanup_heal(sc, loss)


def t_loss_through_voltage(sc: Script, frame: str, level: str, mode: str):
    """A qualified frame-loss fault stays active through an abnormal supply."""
    common_setup(sc)
    loss = fault(sc, "loss", "loss", frame=frame, mode=mode)
    voltage_setup(sc, level)
    precondition(sc, [(loss.bus, loss.frame)])
    sc.step(f"Create fault - {loss.describe}")
    apply(sc, loss)
    measure_qualify(sc, loss)
    read_dtc(sc, "Frame-loss DTC active", [(loss.dtc, ACTIVE)])
    sc.end()
    sc.step(f"Create {level_text(level)} condition")
    sc.T("PS.SetVoltage(voltage_level)")
    measure_read(sc, "voltage_time_ms", "Voltage DTC active, frame-loss DTC remains active",
                 [(loss.dtc, ACTIVE), ("voltage_dtc", V_ACTIVE)], "Time until the voltage DTC is active")
    sc.end()
    sc.step("Restore the supply voltage")
    sc.T("PS.SetVoltage(NOMINAL_VOLTAGE)")
    measure_read(sc, "voltage_time_ms", "Voltage DTC healed, frame-loss DTC remains active",
                 [(loss.dtc, ACTIVE), ("voltage_dtc", V_HEALED)], "Time until the voltage DTC is healed")
    sc.end()
    sc.step(f"Remove fault - {loss.describe_heal}")
    heal(sc, loss)
    measure_recover(sc, loss)
    read_dtc(sc, "Frame-loss DTC healed", [(loss.dtc, HEALED), ("voltage_dtc", V_HEALED)])
    sc.end()
    cleanup_heal(sc, loss)


def t_mcf_not_qualified_in_voltage(sc: Script, frame: str, mcf_kind: str, level: str):
    """A message content failure is not qualified while the supply is abnormal."""
    common_setup(sc)
    mcf = fault(sc, "mcf", mcf_kind, frame=frame)
    voltage_setup(sc, level)
    precondition(sc, [(mcf.bus, mcf.frame)])
    sc.step(f"Create {level_text(level)} condition")
    sc.T("PS.SetVoltage(voltage_level)")
    measure_read(sc, "voltage_time_ms", "Voltage DTC active", [("voltage_dtc", V_ACTIVE)],
                 "Time until the voltage DTC is active")
    sc.end()
    sc.step(f"Create fault while the abnormal voltage is present - {mcf.describe}")
    apply(sc, mcf)
    # The whole qualification time passes before the read: the DTC must not appear.
    sc.T(f"Wait({mcf.qualify})")
    read_dtc(sc, "Message content failure not qualified while the abnormal voltage is present",
             [("voltage_dtc", V_ACTIVE)])
    sc.end()
    sc.step(f"Restore the supply voltage, then valid message content - {mcf.describe_heal}")
    sc.T("PS.SetVoltage(NOMINAL_VOLTAGE)")
    heal(sc, mcf, measured=False)
    measure_read(sc, "voltage_time_ms", "Voltage DTC healed, message content failure remains not active",
                 [("voltage_dtc", V_HEALED)], "Time until the voltage DTC is healed")
    sc.end()
    cleanup_heal(sc, mcf)


# ---------------------------------------------------------------------------
# Case classification for the node workbooks
# ---------------------------------------------------------------------------

NODE_SUITES = {
    "EPS_Node_TestCases.xlsx": "EPS",
    "IEB_Node_TestCases.xlsx": "IEB",
    "HPCC_Node_TestCases.xlsx": "HPCC",
    "HPCAD_Node_TestCases.xlsx": "HPCAd",
    "FR_ZONE_Node_TestCases.xlsx": "FR_ZONE",
    "VCU_Node_TestCases.xlsx": "VCU",
}

# Key message of a node as its workbook states it ("FR_ZONE2_100 (key message)",
# "Node Absent on key message FR_ZONE2_100", ...), filled by main() before the scripts
# are built. Where a workbook states one it is used, else canc_config KEY_TX_FRAMES.
# They agree since canc_config took FR_ZONE2_100 as FR_ZONE's key frame (2026-10-16):
# on 2026-10-15 stopping FR_ZONE2_100 set the node-absent DTC D10400, while stopping
# FR_ZONE3_100 for 5.5 s set none (its message-timeout DTC D00400 needs 60 x 100 ms).
STATED_KEY_FRAMES: dict[str, str] = {}

KEY_MESSAGE_PATTERNS = (r"\b(\w+_\d+)\s*\(key message\)", r"(?<!non-)key message (?:ID 0x[0-9A-Fa-f]+ )?(\w+_\d+)")


def collect_stated_key_frames(cases: list) -> dict[str, str]:
    stated: dict[str, set] = {}
    for case in cases:
        text = " ".join([case.description, case.pre] + [action + " " + expected for action, expected in case.steps])
        for pattern in KEY_MESSAGE_PATTERNS:
            for match in re.finditer(pattern, text):
                frame = match.group(1)
                node = canc_config.CAN_TX_MESSAGE_CONFIG.get(frame, {}).get("key_node")
                if node:
                    stated.setdefault(node, set()).add(frame)
    conflicting = {node: frames for node, frames in stated.items() if len(frames) > 1}
    assert not conflicting, f"workbooks name more than one key message for a node: {conflicting}"
    return {node: frames.pop() for node, frames in stated.items()}


def node_key_frame(node: str) -> str:
    return STATED_KEY_FRAMES.get(node) or next(
        f for f in canc_config.KEY_TX_FRAMES if canc_config.CAN_TX_MESSAGE_CONFIG.get(f, {}).get("key_node") == node)


FR_ZONE_SPECIAL = {
    "CANC_FR_ZONE_TestCase_38": ("both", ["FR_ZONE2_100", "FR_ZONE3_100"]),
    "CANC_FR_ZONE_TestCase_39": ("resume", "FR_ZONE3_100", "crc"),
    "CANC_FR_ZONE_TestCase_40": ("resume", "FR_ZONE3_100", "counter"),
    "CANC_FR_ZONE_TestCase_41": ("resume", "FR_ZONE2_100", "dlc"),
    "CANC_FR_ZONE_TestCase_42": ("resume", "FR_ZONE2_100", "crc"),
    "CANC_FR_ZONE_TestCase_43": ("resume", "FR_ZONE2_100", "counter"),
    "CANC_FR_ZONE_TestCase_44": ("loss_voltage", "FR_ZONE2_100", "over"),
    "CANC_FR_ZONE_TestCase_45": ("loss_voltage", "FR_ZONE2_100", "under"),
    "CANC_FR_ZONE_TestCase_46": ("loss_voltage", "FR_ZONE3_100", "over"),
    "CANC_FR_ZONE_TestCase_47": ("loss_voltage", "FR_ZONE3_100", "under"),
    "CANC_FR_ZONE_TestCase_48": ("mcf_voltage", "FR_ZONE3_100", "dlc", "over"),
    "CANC_FR_ZONE_TestCase_49": ("mcf_voltage", "FR_ZONE3_100", "dlc", "under"),
    "CANC_FR_ZONE_TestCase_50": ("mcf_voltage", "FR_ZONE3_100", "crc", "over"),
}

FAULT_WORDS = {"Node Absent": "loss", "Message Content Failure (DLC)": "dlc",
               "Message Content Failure (CRC)": "crc", "Message Content Failure (MessageCounter)": "counter"}


def loss_mode_note(frame: str, mode: str) -> str | None:
    """Note for a case whose node-absent / message-timeout reading of a frame differs
    from canc_config KEY_TX_FRAMES."""
    if (mode == "node_absent") == bool(canc_config.is_key_message(frame)):
        return None
    dtc = canc_config.resolve_dtc_for_event(mode, frame)
    said = "node-absent" if mode == "node_absent" else "message-timeout"
    return (f"The case expects a {said} fault when {frame} stops; canc_config KEY_TX_FRAMES "
            f"{'does not name' if mode == 'node_absent' else 'names'} {frame} as the key frame of its node. The "
            f"script follows the case and expects the {said} DTC canc_config gives for {frame} ({dtc}).")


def build_node_case(sc: Script):
    case = sc.case
    desc = case.description
    if case.name in FR_ZONE_SPECIAL:
        spec = FR_ZONE_SPECIAL[case.name]
        if spec[0] == "both":
            t_both_frames_normal(sc, spec[1])
        elif spec[0] == "resume":
            mode = "message_timeout" if "timeout fault" in desc else "node_absent"
            t_resume_corrupted(sc, spec[1], spec[2], mode)
            note = loss_mode_note(spec[1], mode)
            if note:
                sc.notes.append(note)
            sc.notes.append("The case steps are copied from other cases; the script follows the description "
                            "and preconditions (primary frame-loss fault, then the frame resumes with corrupted "
                            "content).")
        elif spec[0] == "loss_voltage":
            mode = "message_timeout" if "message-timeout" in desc else "node_absent"
            t_loss_through_voltage(sc, spec[1], spec[2], mode)
            note = loss_mode_note(spec[1], mode)
            if note:
                sc.notes.append(note)
        elif spec[0] == "mcf_voltage":
            t_mcf_not_qualified_in_voltage(sc, spec[1], spec[2], spec[3])
        return

    m = re.search(r"stopping (\w+) transmission sets the node absent", desc)
    if m:
        t_fault_cycle(sc, "loss", m.group(1), mode="node_absent")
        note = loss_mode_note(m.group(1), "node_absent")
        if note:
            sc.notes.append(note)
        return
    m = re.search(r"loss of (\w+) reception sets the communication fault", desc)
    if m:
        t_fault_cycle(sc, "loss", m.group(1), mode="message_timeout")
        note = loss_mode_note(m.group(1), "message_timeout")
        if note:
            sc.notes.append(note)
        return
    m = re.search(r"invalid DLC on (\w+)", desc)
    if m:
        t_fault_cycle(sc, "dlc", m.group(1))
        sc.notes.append(DLC_NOTE)
        return
    m = re.search(r"CRC error on (\w+)", desc)
    if m:
        t_fault_cycle(sc, "crc", m.group(1))
        return
    m = re.search(r"failure detection and recovery for (\w+) using the MessageCounter", desc)
    if m:
        t_fault_cycle(sc, "counter", m.group(1))
        return
    m = re.search(r"signal content failure detection and recovery for (\w+) in (\w+)", desc)
    if m:
        key = mah_key(m.group(2), m.group(1))
        t_fault_cycle(sc, "scf", None, signal_key=key)
        scf_note(sc, key)
        return
    m = re.search(r"changing only (\w+) while keeping the other fields in (\w+)", desc)
    if m:
        t_secoc(sc, mah_key(m.group(2), m.group(1)))
        return
    m = re.search(r"Message Content Failure \(DLC\) overrides Signal Content Failure \((\w+)\)", desc)
    if m:
        frame = re.search(r"for (\w+)\.?$", desc)
        frame = frame.group(1) if frame and frame.group(1) in canc_config.CAN_TX_MESSAGE_CONFIG else None
        key = mah_key(signal_frame(m.group(1), frame), m.group(1))
        t_priority(sc, ("scf", None, key), ("dlc", MAH[key]["frame"]))
        scf_note(sc, key)
        sc.notes.append(DLC_NOTE)
        return
    m = re.search(r"Node Absent \((\w+)(?: key message)?\) overrides Signal Content Failure \((\w+)", desc)
    if m:
        frame_hint = re.search(r"\((\w+) in (\w+)\)", desc)
        if frame_hint:
            sig_frame = frame_hint.group(2)
        else:
            frames = {d["frame"] for d in MAH.values() if d.get("signal") == m.group(2)}
            sig_frame = frames.pop() if len(frames) == 1 else m.group(1)
        key = mah_key(sig_frame, m.group(2))
        node = canc_config.CAN_TX_MESSAGE_CONFIG[MAH[key]["frame"]]["key_node"]
        key_frame = m.group(1) if m.group(1) in canc_config.CAN_TX_MESSAGE_CONFIG else node_key_frame(node)
        t_priority(sc, ("scf", None, key), ("loss", key_frame, None, None, "node_absent"))
        scf_note(sc, key)
        note = loss_mode_note(key_frame, "node_absent")
        if note:
            sc.notes.append(note)
        return
    m = re.search(r"message content fault is followed by loss of (\w+) reception", desc)
    if m:
        frame = m.group(1)
        t_priority(sc, ("dlc", frame), ("loss", frame))
        sc.notes.append(DLC_NOTE)
        if case.suite == "HPCAd":
            sc.notes.append("The case steps and expected results are copied from other cases and contradict "
                            "each other (lower-priority DTC both historic and healed after the same IGN cycle); "
                            "the script expects the pattern the other priority cases give: after the first IGN "
                            "cycle the higher-priority DTC active and the lower-priority DTC healed, after the "
                            "second the lower-priority DTC historic.")
        return
    if "timeout condition is followed by a node absent condition" in desc:
        lower = (re.search(r"Lower Priority Fault: Message Timeout \((\w+)\)", case.pre)
                 or re.search(r"Message Timeout \((\w+)\)", case.pre + " " + desc))
        assert lower, f"{case.name}: no message-timeout frame in the preconditions"
        frame = lower.group(1)
        node = canc_config.CAN_TX_MESSAGE_CONFIG[frame]["key_node"]
        key_frame = node_key_frame(node)
        assert key_frame != frame, f"{case.name}: the message-timeout frame is the node's key frame"
        t_priority(sc, ("loss", frame, None, None, "message_timeout"), ("loss", key_frame, None, None, "node_absent"))
        return
    m = re.search(r"voltage suppression behavior for (Node Absent|Message Content Failure \((?:DLC|CRC|MessageCounter)\)|"
                  r"Signal Content Failure \((\w+)\)) in (\w+) under (high|low) voltage", desc)
    if m:
        level = "over" if m.group(4) == "high" else "under"
        if m.group(2):
            key = mah_key(m.group(3), m.group(2))
            t_voltage(sc, "scf", None, key, level)
            scf_note(sc, key)
        else:
            kind = FAULT_WORDS[m.group(1)]
            t_voltage(sc, kind, m.group(3), None, level)
            if kind == "dlc":
                sc.notes.append(DLC_NOTE)
        sc.notes.append(VOLTAGE_STATUS_NOTE)
        return
    m = re.search(r"alive counter signal (\w+) in (\w+)", desc)
    if m:
        t_alive_counter(sc, mah_key(m.group(2), m.group(1)))
        sc.notes.append("The alive counter is the one the bench transmits; the script checks that it runs, "
                        "rolls over and restarts in the frames on the bus and that the ECU reports no message "
                        "content failure throughout.")
        return
    if "integrity field behavior" in desc:
        signal_match = re.search(r"Signal: (\w+)", case.pre)
        assert signal_match, f"{case.name}: no signal in the preconditions"
        signal = signal_match.group(1)
        t_integrity(sc, mah_key(signal_frame(signal), signal))
        return
    m = re.search(r"(\w+) is received at the specified periodicity", desc)
    if m:
        t_periodicity(sc, m.group(1))
        return
    m = re.search(r"(\w+) received in (\w+) is decoded to the correct physical value", desc)
    if m:
        if m.group(1) == "VIN_NUMBER":
            t_vin_decode(sc)
        else:
            t_decode(sc, mah_key(m.group(2), m.group(1)))
        return
    raise ValueError(f"{case.name}: no template for '{desc}'")


DLC_NOTE = ("A wrong DLC is produced by giving the simulated frame itself the payload length "
            "CAN_DLC_ERROR_PAYLOAD_LENGTH gives (CAN.SetPeriodicFrame on the frame's own name changes its payload), "
            "with the bench-computed CRC / alive counter held meanwhile; the default payload is reloaded to heal. "
            "A copy on the same identifier is refused by ARIA ('Frame ID ... already in simulation', 2026-10-15). "
            "Confirm on the bench that the frame goes out with the shorter length.")
VOLTAGE_STATUS_NOTE = ("The case gives the battery-voltage DTC status 0x08 for active, healed and historic; the "
                       "customer DTC list (warning lamp 1) and the FR_ZONE / VCU cases give 0x8B / 0x0A / 0x08. "
                       "The script reads the statuses from CANC_VOLTAGE_DTC_STATUS_KEYS in canc_config.")


def scf_note(sc: Script, key: str):
    d = MAH[key]
    dtc = canc_config.CAN_TX_MESSAGE_CONFIG[d["frame"]]["signal_content_failure_dtcs"].get(d["signal"])
    if d.get("Invalid_Value") is None or dtc is None:
        sc.automation = "Not executable (hard constraint)"
        sc.notes.append(f"canc_config has no invalid value and no signal content failure DTC for {d['signal']} "
                        f"(and the customer DTC list defines none), so the fault cannot be created or "
                        f"checked. The script reports this and stops before acting on the bench.")


# ---------------------------------------------------------------------------
# Shared pieces for the bus-off, diagnostic, 2C0 and 13C workbooks
# ---------------------------------------------------------------------------

FD_BUSES = "[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME]"


def ecu_frames(sc: Script):
    """IDs and periods of the two frames the ECU sends (SRS1_FD_10 / SRS1_20)."""
    if "ecu_frames" in sc.flags:
        return
    sc.flags.add("ecu_frames")
    sc.S("""
        fd_frame = CANC_ECU_FD_FRAME
        hs_frame = CANC_ECU_HS_FRAME
        fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
        hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
        fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
        hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
        presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + CANC_WINDOW_MARGIN_FRAMES) * max(fd_period_ms, hs_period_ms)
    """)
    sc.log_ids += ["fd_id", "hs_id"]


def margin_setup(sc: Script):
    if "margin" in sc.flags:
        return
    sc.flags.add("margin")
    common_setup(sc)


def check_signals(sc: Script, pairs: str, label: str = "", settle: str | None = "PROVEOUT_COMPLETION_TIME"):
    """Grade ECU-sent signal values read from the bus. pairs: code of a list of
    (MAH_CAN_SIGNAL_DEFS key, expected raw value). Each signal is read again until it
    shows the expected value or `settle` ms (shared by the list) have passed, then
    graded: an ECU-side update can lag the bench change (the passenger belt status
    followed an OCS change after 1.2 s, a fault lamp came on 1 s after its DTC). The
    waits before a check stay as they are, so a value that must not change is still
    watched for the whole time the case gives."""
    if len(pairs) > 70 and pairs.startswith("[(") and pairs.endswith(")]"):
        items = pairs[1:-1].split("), (")
        items = [("(" if i else "") + item + (")" if i < len(items) - 1 else "") for i, item in enumerate(items)]
        sc.T("\n".join(["check_pairs = ["] + [f"    {item}," for item in items] + ["]"]))
        pairs = "check_pairs"
    if settle:
        sc.T(f"""
            check_started = time.monotonic()
            for check_key, check_expected in {pairs}:
                check_def = MAH_CAN_SIGNAL_DEFS[check_key]
                while True:
                    check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                    try:
                        check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                    except ValueError:
                        check_value = check_text
                    if str(check_value) == str(check_expected) or time.monotonic() - check_started >= ({settle}) / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult({(py(label) + " + ") if label else ""}f"{{check_def['frame']}} {{check_def['signal']}}",
                                            str(check_value), str(check_expected))
        """)
        return
    sc.T(f"""
        for check_key, check_expected in {pairs}:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult({(py(label) + " + ") if label else ""}f"{{check_def['frame']}} {{check_def['signal']}}",
                                        str(check_value), str(check_expected))
    """)


def presence(sc: Script, which: str = "both", expect: str = "present", label: str | None = None):
    """Watch the ECU frames for a window: present (at least CANC_FRAME_PRESENCE_CYCLES
    frames) or absent (none). which: fd, hs or both."""
    ecu_frames(sc)
    var = f"presence{sc.step_no}"
    ids = {"fd": "[fd_id]", "hs": "[hs_id]", "both": "[fd_id, hs_id]"}[which]
    buses = {"fd": "[CAN_FD_CHANNEL_NAME]", "hs": "[CAN_HS_CHANNEL_NAME]", "both": FD_BUSES}[which]
    capture(sc, var, ids, buses, "presence_window_ms", label or var)
    names = {"fd": [("fd_id", "fd_frame")], "hs": [("hs_id", "hs_frame")],
             "both": [("fd_id", "fd_frame"), ("hs_id", "hs_frame")]}[which]
    for frame_id, frame_name in names:
        count = f"{var}_{frame_id.split('_')[0]}_count"
        sc.T(f"{count} = sum(1 for frame_data in {var}_frames if frame_data.id == {frame_id})")
        if expect == "present":
            sc.T(f"RESULT.InterpretEqualResultRange(\n"
                 f"    f\"{{{frame_name}}} is transmitted (frames in the window)\",\n"
                 f"    {count}, CANC_FRAME_PRESENCE_CYCLES, float('inf'))")
        else:
            sc.T(f"RESULT.InterpretEqualResult(\n"
                 f"    f\"{{{frame_name}}} is not transmitted (frames in the window)\",\n"
                 f"    {count}, 0)")


def operator_action(sc: Script, text: str, window: str = "CANC_MANUAL_ACTION_WINDOW_MS"):
    """An action no shared-library call can perform: the instruction goes to the
    report and the console, then the script waits for it before checking. A
    {expression} in the text is filled in when the script runs."""
    message = ("f" if "{" in text else "") + py("OPERATOR ACTION: " + text)
    sc.T(f"""
        RESULT.InsertComment({message})
        print({message})
        Wait({window})
    """)


def wake_setup(sc: Script):
    if "wake" in sc.flags:
        return
    sc.flags.add("wake")
    sc.S("""
        pke_def = MAH_CAN_SIGNAL_DEFS[CAN_PKE_WAKEUP_SIGNAL_KEY]
        nm_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == CAN_NM_WAKEUP_FRAME)
        wake_status_key = next(key for key, d in MAH_CAN_SIGNAL_DEFS.items()
                               if d['frame'] == CAN_WAKEUP_STATUS_FRAME and d['signal'] == CAN_WAKEUP_STATUS_SIGNAL)
    """)
    sc.C("""
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
        PS.IGN_ON()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
    """)


def bus_sleep(sc: Script, verify: bool = True):
    """IGN OFF with no wake request on the bus, until the ECU stops sending."""
    wake_setup(sc)
    ecu_frames(sc)
    sc.T("""
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
    """)
    if verify:
        presence(sc, "both", "absent", "bus_sleep")


def can_wakeup(sc: Script, verify: bool = True):
    """The project's CAN wakeup (user instructions 2026-10-14 / 2026-10-16): IGN OFF,
    then PKE_CLMP_STATE set to a wake value straight away, with no VCU NM wake request
    on the bus, so the PKE clamp state is what keeps the ECU awake. Each value of
    CAN_PKE_WAKEUP_VALUES (1, 2, 3 and 4) wakes the bus, and only with the ignition
    OFF, so each is checked from its own IGN ON -> IGN OFF; the ECU stays awake on the
    last one. It is set before the ECU goes to sleep: the ECU stops sending about 1 s
    after IGN OFF, and on 2026-10-15 the PKE value sent after bus sleep never woke it
    (13C 31, 39-43, 55, 57)."""
    wake_setup(sc)
    ecu_frames(sc)
    sc.T("for pke_value in CAN_PKE_WAKEUP_VALUES:")
    sc.extra += 4
    sc.T("""
        RESULT.InsertComment(f"CAN wakeup with {pke_def['signal']} = {pke_value}")
        PS.IGN_ON()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        PS.IGN_OFF()
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(pke_value))
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
    """)
    if verify:
        check_signals(sc, "[(wake_status_key, CAN_WAKEUP_STATUS_VALUE)]", "ECU awake through CAN: ")
        presence(sc, "both", "present", "can_wake")
    sc.extra -= 4


def nm_wakeup(sc: Script, verify: bool = True):
    """A CAN wakeup from bus sleep, which only the VCU NM frame with the active wakeup
    bit does (13C 48 on 2026-10-15: the ECU restarted with IGN_STS_SRS = 2). The PKE
    clamp state goes to its wake value too, as the project procedure keeps it."""
    wake_setup(sc)
    sc.T("""
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ChangeSignalValue(nm_def['bus'], CAN_NM_WAKEUP_FRAME, CAN_NM_WAKEUP_SIGNAL, str(CAN_NM_WAKEUP_VALUE))
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_WAKEUP_VALUES[0]))
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
    """)
    if verify:
        check_signals(sc, "[(wake_status_key, CAN_WAKEUP_STATUS_VALUE)]", "ECU awake through CAN: ")


def wake_frames(sc: Script) -> list:
    wake_setup(sc)
    return [("pke_def['bus']", "pke_def['frame']"), ("nm_def['bus']", "CAN_NM_WAKEUP_FRAME")]


def lamp_values(sc: Script):
    if "lamp" in sc.flags:
        return
    sc.flags.add("lamp")
    sc.S("""
        lamp_on = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp ON']
        lamp_off = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp OFF/Default']
    """)


def loop_setup(sc: Script):
    if "loop" in sc.flags:
        return
    sc.flags.add("loop")
    sc.S("""
        loop_device = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}"
        loop_dtc = DTC_Squib_FaultCode[CANC_LOOP_FAULT_SQUIB] + " " + Squib_FaultTypeCode['Open']
        loop_qualify_ms = int(squib_fault_time['Qualification_Time'] * (1 + squib_fault_time['Qualification_Tolerance'] / 100))
        loop_recover_ms = int(squib_fault_time['Dequalification_Time'] * (1 + squib_fault_time['Dequalification_Tolerance'] / 100))
    """)
    sc.C("SQUIB.SendRequest(loop_device, Squib_Fault_Description['NoFault'])")


def loop_open(sc: Script, read: bool = True):
    loop_setup(sc)
    sc.T("""
        SQUIB.SendRequest(loop_device, Squib_Fault_Description['Open'])
        Wait(loop_qualify_ms)
    """)
    if read:
        read_dtc(sc, "Loop open DTC active", [("loop_dtc", "'DTC_active'")])


def loop_heal(sc: Script):
    sc.T("""
        SQUIB.SendRequest(loop_device, Squib_Fault_Description['NoFault'])
        Wait(loop_recover_ms)
    """)


def vin_setup(sc: Script):
    if "vin" in sc.flags:
        return
    sc.flags.add("vin")
    sc.S("vin_period_ms = MAH_CAN_SIGNAL_DEFS['VIN_NUMBER']['periodicity']")
    sc.C("simulate_vin_can_signals_fd(VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY])")


def vin_mismatch(sc: Script):
    """Wrong VIN on the bus, then an IGN cycle: the ECU compares the VIN only while it
    starts up (agent_sc3.md section 2.9 - validation during IGN-ON / CAN-wakeup init,
    3 failed sets qualify the DTC), so a VIN changed in a running cycle is never
    compared (2026-10-15: no D30600 10 s after the change). Waits for the DTC."""
    vin_setup(sc)
    sc.notes.append("The ECU compares the received VIN with DID F190 only while it starts up (agent_sc3.md section 2.9), "
                    "so the wrong VIN is put on the bus before an IGN cycle and the project VIN back before the next "
                    "one; the mismatch DTC is then expected historic, not healed in the same cycle. On 2026-10-15 a VIN "
                    "changed in a running cycle gave no D30600 within 10 s.")
    sc.T("""
        simulate_vin_can_signals_fd(VIN_STRATEGY_OPTIONS['wrong_vin_for_comparison'])
        Wait(CANC_VIN_SEND_FRAMES * vin_period_ms)
    """)
    ign_cycle(sc)
    measure(sc, "vin_time_ms", [("Vin_DTC_Code", "'DTC_active'")],
            "Time after the start-up until the VIN mismatch DTC is active")


def vin_restore(sc: Script):
    """The project VIN back on the bus, then an IGN cycle: the start-up comparison
    passes and the VIN mismatch DTC becomes historic."""
    sc.T("""
        simulate_vin_can_signals_fd(VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY])
        Wait(CANC_VIN_SEND_FRAMES * vin_period_ms)
    """)
    ign_cycle(sc)
    measure(sc, "vin_time_ms", [("Vin_DTC_Code", HISTORIC)],
            "Time after the start-up until the VIN mismatch DTC is historic")


def plant_setup(sc: Script):
    if "plant" in sc.flags:
        return
    sc.flags.add("plant")
    margin_setup(sc)
    sc.S("""
        vehicle_assembly = next(phase for phase, name in PHASE_OF_LIFE_STATES.items() if name == 'VehicleAssembly')
        plant_request = format_uds_bytes(build_phase_of_life_start_routine(vehicle_assembly))
        plant_response = format_uds_bytes(build_routine_control_positive_response(vehicle_assembly))
        plant_window_ms = int(PLANT_MODE_OWNER_TRANSITION_DELAY_MS * margin)
    """)
    sc.automation = "Automatic (irreversible: changes the learned phase of life)"
    sc.notes.append("Entering plant mode moves the ECU's learned phase of life to Vehicle Assembly; 30 s "
                    "fault-free it moves on to Owner, from which plantmode_config allows only EndOfLife. The "
                    "case can therefore run once per software flash; the script reads the phase first and "
                    "stops when plant mode cannot be entered.")


def plant_enter(sc: Script, power_cycle: bool = True):
    """Phase check, then the Vehicle Assembly routine (plantmode_config)."""
    plant_setup(sc)
    sc.T("""
        phase_response = str(CAN.SendDiagByValues(format_uds_bytes(build_phase_of_life_status_request())))
        phase_tokens = phase_response.split()
        # A positive response (READ_SID + 0x40, ISO 14229-1) carries the phase in its first data byte.
        phase_positive = f"0x{int(READ_SID, 16) + 0x40:02X}".upper()
        current_phase = int(phase_tokens[3], 16) if len(phase_tokens) > 3 and phase_tokens[0].upper() == phase_positive else None
        RESULT.LogAction("Phase of life before plant mode", phase_response)
        if (current_phase, vehicle_assembly) not in PHASE_OF_LIFE_TRANSITIONS:
            RESULT.LogCustomAction(
                "Plant mode can be entered from the current phase of life",
                f"phase in {sorted(source for source, target in PHASE_OF_LIFE_TRANSITIONS if target == vehicle_assembly)}",
                f"phase {current_phase}", False)
            return
        enter_ext_session()
        Internal_Security_Access(ROUTINE_CONTROL_SECURITY_LEVEL)
        RESULT.InterpretEqualResult("Enter plant mode (phase of life Vehicle Assembly)",
                                    str(CAN.SendDiagByValues(plant_request)), plant_response)
    """)
    if power_cycle:
        ign_cycle(sc)


EVT_LABEL = "Automatic once the EVT sheets and the ARIA SPI sensor card are available (blocked until then)"


def evt_fault(sc: Script):
    sc.automation = EVT_LABEL
    sc.notes.append("The sensor fault is created by loading the corrupted EVT of project_config EOL_EVT_CONFIG "
                    "into the SPI sensor simulation (initSpiFpgaSingleSensor). On 2026-10-15 both EVT sheets were "
                    "missing ('EVT sheet does not exist': EOL_EVT_CONFIG points to evt/z121, which holds no files) "
                    "and the chassis has no SPI sensor card; with both in place, confirm the corruption gives the "
                    "fault the case names.")
    sc.T("""
        initSpiFpgaSingleSensor(EOL_EVT_CONFIG['spi_function'], EOL_EVT_CONFIG['corrupted_evt_path'])
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        RESULT.LogAction("DTCs with the corrupted EVT loaded", CAN.SendDiagByValues(Read_DTC_Req_CANC))
    """)
    sc.C("initSpiFpgaSingleSensor(EOL_EVT_CONFIG['spi_function'], EOL_EVT_CONFIG['normal_evt_path'])")


def evt_restore(sc: Script):
    sc.T("""
        initSpiFpgaSingleSensor(EOL_EVT_CONFIG['spi_function'], EOL_EVT_CONFIG['normal_evt_path'])
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
    """)


def ocs_enable(sc: Script):
    """OCS enabled in the variant code (the project default has the OCS node off;
    the default EOL already has the OCS bit set)."""
    if "ocs" in sc.flags:
        return
    sc.flags.add("ocs")
    sc.S("""
        ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
        ocs_fault_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS_FAULT_STS']
        ocs_subseat_def = MAH_CAN_SIGNAL_DEFS['OCS_SUBSEAT_CLASSIFICATION']
    """)
    sc.T("""
        # The variant-code bit of the node that sends the OCS frame (canc_config key_node).
        ocs_node = CAN_TX_MESSAGE_CONFIG[ocs_class_def['frame']]['key_node']
        manage_variant_code(ocs_node, 'enable', project=PROJECT_NAME, base_from_project_default=True)
    """)
    ign_cycle(sc)
    sc.flags.add("needs_profile")
    sc.C("CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])")


def set_bench_signal(sc: Script, def_var: str, value_expr: str, wait: str | None = None):
    sc.T(f"CAN.ChangeSignalValue({def_var}['bus'], {def_var}['frame'], {def_var}['signal'], str({value_expr}))")
    if wait:
        sc.T(f"Wait({wait})")


def crash_setup(sc: Script, crash: str, var: str = "crash"):
    """Curve availability (paths in the project crash-curve table) and the
    expected crash signal values."""
    sc.S(f"""
        {var}_curve_key = CANC_CRASH_CURVE_KEY[{py(crash)}]
        {var}_curve_set = get_project_crash_curve_config(PROJECT_NAME).get({var}_curve_key) or {{}}
        {var}_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                                 for spec in {var}_curve_set.get('RSU', {{}}).values())
    """)
    sc.need(f"f'crash curves for {{{var}_curve_key}}'", f"{var}_curves_ready or None")
    # The project crash-curve table has no rollover entry; templates that need
    # other undelivered curves (near, PT-only, multi-event) set their own label.
    if crash == "rollover" and sc.automation == "Automatic":
        sc.automation = "Automatic once the rollover crash curves are delivered (blocked until then)"
    elif sc.automation == "Automatic":
        sc.automation = SPI_CARD_LABEL
        if SPI_CARD_NOTE not in sc.notes:
            sc.notes.append(SPI_CARD_NOTE)
    if "crash_values" not in sc.flags:
        sc.flags.add("crash_values")
        sc.S("""
            crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
            crash_clear = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['No Request / Default']
            location_none = MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values']['No Crash/Default']
        """)
        # Right after a crash the ECU refuses the EDR clear of fault_free_profile (31 01 F1 04 ->
        # 7F 31 22, 2026-10-15, 13C 35/37/95/96, ~2.6 s after the crash) and the case failed in its
        # cleanup; an IGN cycle and the start-up wait come first.
        sc.C("""
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
        """)
    sc.flags.add("needs_profile")


SPI_CARD_LABEL = "Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)"
SPI_CARD_NOTE = ("load_crash_curves sends the central-sensor curves of every crash type through the SPI sensor card "
                 "(SPI.SendCrashData). On 2026-10-15 ARIA answered 'Card not present in ARIA Chassis', which fails "
                 "the case even where the satellite curves alone produced the crash (13C 35/37/95/96: STS_CRASH "
                 "held 800 ms with the right CRASH_LOCATION). The case runs as it stands once the card is fitted.")


def crash_location(crash: str) -> str:
    return f"MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE[{py(crash)}]]"


def crash_trigger(sc: Script, var: str = "crash", ids: str = "[fd_id, hs_id]", buses: str = FD_BUSES,
                  window: str = "CANC_CRASH_CAPTURE_HOLDS * CANC_CRASH_SIGNAL_HOLD_MS"):
    ecu_frames(sc)
    capture(sc, var, ids, buses, None, var, start_only=True)
    sc.T("TriggerCrash()")
    capture_stop(sc, var, window)


def crash_rows(sc: Script, var: str, frame_id: str, roles: dict, rows_var: str):
    """Rows (dicts) decoded from captured frames: one key per role plus t (ms)."""
    keys = "{" + ", ".join(f"{py(role)}: {py(key)}" for role, key in roles.items()) + "}"
    sc.T(f"""
        {rows_var}_keys = {keys}
        {rows_var} = [
            dict({{role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in {rows_var}_keys.items()}}, t=frame_data.timestamp / 1000)
            for frame_data in {var}_frames if frame_data.id == {frame_id}]
    """)


def restart_rows(sc: Script, rows_var: str, period: str):
    """Keep only the rows after the last gap in transmission (the capture may span
    a restart)."""
    sc.T(f"""
        {rows_var}_restart = max([index for index in range(1, len({rows_var}))
                                  if {rows_var}[index]['t'] - {rows_var}[index - 1]['t'] > CANC_GAP_FRAMES * {period}] or [0])
        {rows_var} = {rows_var}[{rows_var}_restart:]
    """)


# ---------------------------------------------------------------------------
# Bus-off workbook
# ---------------------------------------------------------------------------

BUS_TEXT = {"CANFD": "the CAN-FD bus", "HSCAN": "the HS-CAN bus", "both": "both the CAN-FD and the HS-CAN bus"}


def busoff_setup(sc: Script):
    margin_setup(sc)
    ecu_frames(sc)
    lamp_values(sc)
    sc.S("""
        busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                                 + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)
        # The warning-indicator bit of a DTC status (ISO 14229-1 bit 7) tells whether
        # the bus-off DTC asks for the lamp.
        fd_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['CANFD']], 16) & 0x80 else lamp_off
        hs_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']], 16) & 0x80 else lamp_off
    """)
    sc.automation = "Semi-automatic (operator creates and removes the bus-off)"
    sc.C(f"""
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
        print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
    """)
    if "busoff_note" not in sc.flags:
        sc.flags.add("busoff_note")
        sc.notes.append("No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so the "
                        "operator applies and removes the bus-off when the script asks (it waits "
                        "CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and the "
                        "DTCs itself.")


def busoff_create(sc: Script, bus: str):
    operator_action(sc, f"Short CAN-H to CAN-L on {BUS_TEXT[bus]} and keep the short.", "CAN_BUS_OFF_OPERATOR_WINDOW_MS")
    if bus == "both":
        presence(sc, "both", "absent", "busoff_both")
    elif bus == "HSCAN":
        presence(sc, "hs", "absent", "busoff_hs")
        presence(sc, "fd", "present", "busoff_fd_alive")
    else:
        presence(sc, "fd", "absent", "busoff_fd")
        presence(sc, "hs", "present", "busoff_hs_alive")


def busoff_remove(sc: Script, bus: str):
    operator_action(sc, f"Remove the CAN-H to CAN-L short on {BUS_TEXT[bus]}.", "CAN_BUS_OFF_OPERATOR_WINDOW_MS")
    sc.T("Wait(busoff_settle_ms)")


def bench_restart(sc: Script):
    sc.T("""
        CAN.PeriodicDisableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicDisableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
    """)


HS_BUSOFF_ACTIVE = ("CAN_BUS_OFF_DTC['HSCAN']", "CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']")


def clear_dtc(sc: Script, expect_pairs: list, wait: str = "NM_IGN_ON_STARTUP_DELAY_MS", label: str = "No DTC"):
    sc.T(f"""
        Clear_DTC_Info()
        Wait({wait})
    """)
    read_dtc(sc, label, expect_pairs)


def tester_present_start(sc: Script):
    sc.T("""
        tester_present(CAN_FD_CHANNEL_NAME, CANC_TESTER_PRESENT_PERIOD_MS, 'start',
                       frame_name='CANC_TESTER_PRESENT', frame_id=DIAG_TX_ID)
        RESULT.InterpretEqualResult("Extended session", str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)),
                                    UDS_RESP_SESSION_EXTENDED)
    """)
    sc.C("""
        tester_present(CAN_FD_CHANNEL_NAME, None, 'stop', frame_name='CANC_TESTER_PRESENT')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
    """)


def t_busoff_both(sc: Script, check_comm: bool):
    busoff_setup(sc)
    precondition(sc, [])
    sc.step("Create bus-off on both buses - no CAN communication")
    busoff_create(sc, "both")
    sc.end()
    sc.step("Stop, then restart, all bench CAN messages")
    bench_restart(sc)
    sc.end()
    sc.step("Remove the bus-off and read DTC")
    busoff_remove(sc, "both")
    read_dtc(sc, "Bus-off DTCs healed", [("CAN_BUS_OFF_DTC['CANFD']", HEALED), ("CAN_BUS_OFF_DTC['HSCAN']", HEALED)])
    sc.end()
    sc.step("Clear DTC")
    clear_dtc(sc, [])
    sc.end()
    if check_comm:
        sc.step("Check communication on both buses")
        presence(sc, "both", "present", "comm_restored")
        sc.end()


def t_busoff_hs(sc: Script):
    busoff_setup(sc)
    precondition(sc, [])
    sc.step("Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues")
    busoff_create(sc, "HSCAN")
    sc.end()
    sc.step("Check the warning lamp in SRS1_FD_10")
    sc.T("# SRS1_20 is not on the bus during the HS-CAN bus-off, so only SRS1_FD_10 can be read.")
    check_signals(sc, "[('INDC_SRS', hs_busoff_lamp)]", "Warning lamp during HS-CAN bus-off: ")
    sc.end()
    sc.step("Restart the bench messages and read DTC while the bus-off is active")
    sc.T("""
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
    """)
    read_dtc(sc, "HS-CAN bus-off DTC active", [HS_BUSOFF_ACTIVE])
    sc.end()
    sc.step("Clear DTC while the bus-off is still active")
    clear_dtc(sc, [HS_BUSOFF_ACTIVE], "busoff_settle_ms", "HS-CAN bus-off DTC active again")
    sc.end()
    sc.step("Remove the bus-off and read DTC")
    busoff_remove(sc, "HSCAN")
    read_dtc(sc, "HS-CAN bus-off DTC healed", [("CAN_BUS_OFF_DTC['HSCAN']", HEALED)])
    sc.end()
    sc.step("Clear DTC")
    clear_dtc(sc, [])
    sc.end()
    sc.notes.append("The case expects the warning lamp ON in SRS1_FD_10; the customer DTC list gives D27100 "
                    "warning lamp 0. The script expects the lamp the configured bus-off status gives "
                    "(CAN_BUS_OFF_ACTIVE_STATUS_KEY).")


def t_busoff_fd(sc: Script):
    busoff_setup(sc)
    precondition(sc, [])
    sc.step("Create bus-off on CAN-FD only - SRS1_FD_10 stops, SRS1_20 continues")
    busoff_create(sc, "CANFD")
    sc.end()
    sc.step("Check the warning lamp in SRS1_20")
    check_signals(sc, "[('SRS1_20_INDC_SRS', fd_busoff_lamp)]", "Warning lamp during CAN-FD bus-off: ")
    sc.end()
    sc.step("Stop, then restart, all bench CAN messages")
    bench_restart(sc)
    sc.end()
    sc.step("Remove the bus-off and read DTC")
    busoff_remove(sc, "CANFD")
    read_dtc(sc, "CAN-FD bus-off DTC healed", [("CAN_BUS_OFF_DTC['CANFD']", HEALED)])
    sc.end()
    sc.step("Clear DTC")
    clear_dtc(sc, [])
    sc.end()


def t_busoff_long(sc: Script, bus: str):
    busoff_setup(sc)
    which = "fd" if bus == "CANFD" else "hs"
    frame_id = "fd_id" if bus == "CANFD" else "hs_id"
    channel = "CAN_FD_CHANNEL_NAME" if bus == "CANFD" else "CAN_HS_CHANNEL_NAME"
    sc.automation = "Semi-automatic (operator holds the bus-off; recovery timing evaluated from the saved log)"
    precondition(sc, [])
    sc.step("Verify the ECU frame is transmitted")
    presence(sc, which, "present", "before_busoff")
    sc.end()
    sc.step("Hold a bus-off with the CAN stress tool and log the recovery attempts")
    capture(sc, "recovery", f"[{frame_id}]", f"[{channel}]", None, "busoff_recovery", start_only=True)
    operator_action(sc, f"Create a bus-off on {BUS_TEXT[bus]} with the CAN stress tool, hold it for "
                        f"{{CAN_BUS_OFF_LONG_HOLD_MS / 1000:.0f}} s, then remove it.",
                    "CAN_BUS_OFF_LONG_HOLD_MS + CAN_BUS_OFF_OPERATOR_WINDOW_MS")
    capture_stop(sc, "recovery", None)
    sc.T("""
        RESULT.LogAction("Recovery log for review", recovery_file)
        RESULT.InsertComment(
            f"Expected in the log: {BUSOFF_FAST_RECOVERY_COUNT} recovery attempts {BUSOFF_FAST_RECOVERY_TIME_MS} ms "
            f"apart, then attempts every {BUSOFF_SLOW_RECOVERY_TIME_MS} ms while the bus-off lasts.")
    """)
    sc.end()
    sc.step("Communication restored after the bus-off")
    sc.T("Wait(busoff_settle_ms)")
    presence(sc, which, "present", "after_busoff")
    sc.end()
    sc.notes.append("The recovery attempts during a bus-off are not decodable frames, so the fast/slow recovery "
                    "timing is evaluated from the saved log; the case's slow recovery time (100 ms) differs "
                    "from canc_config BUSOFF_SLOW_RECOVERY_TIME_MS (500 ms, NM identifier sheet).")


def t_busoff_voltage(sc: Script):
    busoff_setup(sc)
    sc.C("PS.SetVoltage(NOMINAL_VOLTAGE)")
    precondition(sc, [])
    for level, volt, dtc in (("under", "CANC_UNDERVOLTAGE_TEST_VOLTAGE", "Under_Voltage"),
                             ("over", "CANC_OVERVOLTAGE_TEST_VOLTAGE", "Over_Voltage")):
        sc.step(f"Create {level_text(level)} condition")
        sc.T(f"PS.SetVoltage({volt})")
        measure_read(sc, "voltage_time_ms", "Voltage DTC active", [(dtc, V_ACTIVE)], "Time until the voltage DTC is active")
        sc.end()
        sc.step("Create a bus-off longer than the fast recovery time, then remove it")
        sc.T(f"""
            busoff_text = (f"Create a bus-off on both buses with the CAN stress tool for "
                           f"{{BUSOFF_FAST_RECOVERY_TIME_MS + BUSOFF_SLOW_RECOVERY_TIME_MS}} ms, then remove it.")
            RESULT.InsertComment("OPERATOR ACTION: " + busoff_text)
            print("OPERATOR ACTION: " + busoff_text)
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
            Wait(busoff_settle_ms)
        """)
        read_dtc(sc, "No bus-off DTC qualified during the abnormal voltage", [(dtc, V_ACTIVE)])
        sc.end()
        sc.step("Restore the supply voltage")
        sc.T("PS.SetVoltage(NOMINAL_VOLTAGE)")
        measure_read(sc, "voltage_time_ms", "Voltage DTC healed", [(dtc, V_HEALED)], "Time until the voltage DTC is healed")
        sc.end()
        if level == "under":
            sc.step("Clear DTC")
            clear_dtc(sc, [])
            sc.end()
    sc.notes.append("The case lowers the supply to 7 V; the script uses CANC_UNDERVOLTAGE_TEST_VOLTAGE (6.5 V), "
                    "also below the 9 V threshold. The case does not name the bus, so both buses are used.")


def t_busoff_comm_control(sc: Script, request: str, response: str, expect_stop: bool, speed: bool):
    busoff_setup(sc)
    if speed:
        sc.S("""
            speed_def = MAH_CAN_SIGNAL_DEFS['VEHICLE_SPEED']
            speed_raw = int(round((CANC_COMM_CONTROL_REJECT_SPEED_KMH - speed_def['Offset']) / speed_def['Factor']))
        """)
        sc.C("CAN.ReloadDefaultPeriodicFrame(speed_def['bus'], speed_def['frame'])")
    precondition(sc, [])
    sc.step("Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues")
    busoff_create(sc, "HSCAN")
    sc.end()
    if speed:
        sc.step("Send the vehicle speed in IEB1_FD_10")
        set_bench_signal(sc, "speed_def", "speed_raw", "CANC_SETTLE_FRAMES * speed_def['periodicity']")
        sc.end()
    sc.step("Restart the bench messages and read DTC while the bus-off is active")
    sc.T("""
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
    """)
    read_dtc(sc, "HS-CAN bus-off DTC active", [HS_BUSOFF_ACTIVE])
    sc.end()
    sc.step("Send Tester Present periodically and enter the extended session")
    tester_present_start(sc)
    sc.end()
    sc.step("Communication control request")
    sc.T(f"RESULT.InterpretEqualResult('Communication control response', str(CAN.SendDiagByValues({request})), {response})")
    sc.end()
    sc.step("Check SRS1_FD_10")
    presence(sc, "fd", "absent" if expect_stop else "present", "after_comm_control")
    sc.end()


def t_busoff_dtc_setting(sc: Script, request: str, response: str, logged: bool):
    busoff_setup(sc)
    loop_setup(sc)
    precondition(sc, [])
    sc.step("Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues")
    busoff_create(sc, "HSCAN")
    sc.end()
    sc.step("Restart the bench messages and read DTC while the bus-off is active")
    sc.T("""
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
    """)
    read_dtc(sc, "HS-CAN bus-off DTC active", [HS_BUSOFF_ACTIVE])
    sc.end()
    sc.step("Send Tester Present periodically and enter the extended session")
    tester_present_start(sc)
    sc.end()
    sc.step("Control DTC setting")
    sc.T(f"RESULT.InterpretEqualResult('Control DTC setting response', str(CAN.SendDiagByValues({request})), {response})")
    sc.end()
    sc.step("Create a fault on the bench (loop open)")
    loop_open(sc, read=False)
    if logged:
        read_dtc(sc, "The new fault is logged", [HS_BUSOFF_ACTIVE, ("loop_dtc", "'DTC_active'")])
    else:
        read_dtc(sc, "The new fault is not logged while DTC setting is off", [HS_BUSOFF_ACTIVE])
    sc.end()
    sc.notes.append("The case asks for 'any fault'; a loop open is used because CAN faults have 'no bus-off' "
                    "as a precondition in the customer DTC list.")


def t_busoff_vc_lamp(sc: Script):
    busoff_setup(sc)
    sc.flags.add("needs_profile")
    precondition(sc, [])
    sc.step("Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues")
    busoff_create(sc, "HSCAN")
    sc.end()
    sc.step("Create a variant code error and check the warning lamp in SRS1_FD_10")
    sc.T("manage_variant_code('VARIANT_STATUS', 'disable', project=PROJECT_NAME, base_from_project_default=True)")
    ign_cycle(sc)
    sc.T("Wait(busoff_settle_ms)")
    check_signals(sc, "[('INDC_SRS', lamp_on)]", "Warning lamp with the variant code error: ")
    sc.end()
    sc.step("Read DTC while the bus-off is active")
    measure_read(sc, "settle_time_ms", "HS-CAN bus-off and variant code DTCs active",
                 [HS_BUSOFF_ACTIVE, ("Variant_Code_DTC", "'DTC_active'")],
                 "Time until the bus-off and variant code DTCs are active")
    sc.end()
    sc.step("Make the variant code error historic and check the warning lamp")
    sc.T("manage_variant_code('DEFAULT', project=PROJECT_NAME)")
    ign_cycle(sc)
    sc.T("Wait(busoff_settle_ms)")
    check_signals(sc, "[('INDC_SRS', hs_busoff_lamp)]", "Warning lamp with only the HS-CAN bus-off active: ")
    sc.end()
    sc.notes.append("After the variant code error is historic the case still expects the lamp ON; with only "
                    "D27100 active (warning lamp 0 in the customer DTC list) the script expects the lamp the "
                    "configured bus-off status gives.")


def t_busoff_timeouts(sc: Script):
    busoff_setup(sc)
    sc.S("""
        non_key_frames = [frame_name for frame_name, frame_cfg in CAN_TX_MESSAGE_CONFIG.items()
                          if not is_key_message(frame_name) and frame_cfg.get('message_timeout_dtc')
                          and any(d['frame'] == frame_name for d in MAH_CAN_SIGNAL_DEFS.values())]
        non_key_defs = [next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == frame_name)
                        for frame_name in non_key_frames]
        timeout_dtcs = sorted({CAN_TX_MESSAGE_CONFIG[frame_name]['message_timeout_dtc'] for frame_name in non_key_frames})
        timeout_qualify_ms = max(int(qualification_ms('message_timeout', d['periodicity']) * margin) for d in non_key_defs)
    """)
    sc.C("""
        for d in non_key_defs:
            CAN.PeriodicEnableFrame(d['bus'], d['frame'])
            CAN.ReloadDefaultPeriodicFrame(d['bus'], d['frame'])
    """)
    precondition(sc, [])
    sc.step("Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues")
    busoff_create(sc, "HSCAN")
    sc.end()
    sc.step("Stop all non-key messages of every node")
    sc.T("""
        for d in non_key_defs:
            CAN.PeriodicDisableFrame(d['bus'], d['frame'])
        Wait(timeout_qualify_ms)
    """)
    read_dtc(sc, "Only the bus-off DTC while the bus-off is active", [HS_BUSOFF_ACTIVE])
    sc.end()
    sc.step("Remove the bus-off and read DTC")
    busoff_remove(sc, "HSCAN")
    sc.T("""
        Wait(timeout_qualify_ms)
        Read_DTC("Bus-off DTC healed, every message timeout DTC active",
                 " ".join([Read_DTC_Resp_CANC, CAN_BUS_OFF_DTC['HSCAN'], DTC_status['DTC_healed']]
                          + [part for dtc in timeout_dtcs for part in (dtc, DTC_status['DTC_active_WLOFF'])]),
                 Read_DTC_Req_CANC)
    """)
    sc.end()
    sc.notes.append("The case title names the CAN-FD channel but reads D27100 (HS-CAN bus-off) while the "
                    "bus-off is active, which needs the CAN-FD diagnostics alive; the script creates the "
                    "bus-off on HS-CAN.")


BUSOFF_CASES = {
    1: lambda sc: (t_busoff_both(sc, False), sc.notes.append(
        "The case expects only D20600 healed although both buses are bus-off; bus-off cases 6 and 7 expect "
        "D20600 and D27100, and so does this script.")),
    2: t_busoff_hs,
    3: t_busoff_fd,
    4: lambda sc: t_busoff_long(sc, "CANFD"),
    5: t_busoff_voltage,
    6: lambda sc: t_busoff_both(sc, True),
    7: lambda sc: t_busoff_both(sc, True),
    8: lambda sc: t_busoff_comm_control(sc, "UDS_REQ_28_03_03", "UDS_RESP_68_03", True, False),
    9: lambda sc: t_busoff_comm_control(sc, "UDS_REQ_28_01_01", "UDS_RESP_68_01", True, False),
    10: lambda sc: t_busoff_dtc_setting(sc, "UDS_REQ_85_01", "UDS_RESP_C5_01", True),
    11: lambda sc: t_busoff_dtc_setting(sc, "UDS_REQ_85_02", "UDS_RESP_C5_02", False),
    12: lambda sc: t_busoff_long(sc, "HSCAN"),
    13: t_busoff_vc_lamp,
    14: lambda sc: t_busoff_comm_control(sc, "UDS_REQ_28_83_03", "UDS_RESP_7F_28_88", False, True),
    15: lambda sc: t_busoff_comm_control(sc, "UDS_REQ_28_81_01", "UDS_RESP_7F_28_88", False, True),
    16: t_busoff_timeouts,
}


# ---------------------------------------------------------------------------
# Diagnostic workbook
# ---------------------------------------------------------------------------

def t_diag_ids(sc: Script, functional: bool):
    sc.S("""
        variant_code_request = f"{READ_SID} {VARIANT_CODE_DID}"
        variant_code_response = f"0x{int(READ_SID, 16) + 0x40:02X} {VARIANT_CODE_DID} {DEFAULT_VARIANT_CODE}"
    """)
    sc.C("CAN.SetDiagnosticAdressingMode(DIAG_TX_ID, DIAG_RX_ID)")
    precondition(sc, [])
    if functional:
        sc.step("Use functional addressing (request 7DF, response 738)")
        sc.T("RESULT.LogAction('Addressing', CAN.SetDiagnosticAdressingMode(DIAG_FUNCTIONAL_ID, DIAG_RX_ID))")
        sc.end()
    sc.step("Enter the extended session and unlock security level 1")
    sc.T("RESULT.InterpretEqualResult('Extended session', str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)), "
         "UDS_RESP_SESSION_EXTENDED)")
    if functional:
        sc.T("""
            # Security access is a physical request (730), as the case says.
            CAN.SetDiagnosticAdressingMode(DIAG_TX_ID, DIAG_RX_ID)
            Internal_Security_Access(0x01)
            CAN.SetDiagnosticAdressingMode(DIAG_FUNCTIONAL_ID, DIAG_RX_ID)
        """)
    else:
        sc.T("Internal_Security_Access(0x01)")
    sc.end()
    sc.step("Read DID 01 01 (variant code)")
    sc.T("""
        variant_code_read = str(CAN.SendDiagByValues(variant_code_request))
        RESULT.InterpretEqualResult("Response on 738 to 22 01 01", variant_code_read.upper(), variant_code_response.upper())
        RESULT.InterpretEqualResult("Variant code data bytes", len(variant_code_read.split()) - 3,
                                    len(DEFAULT_VARIANT_CODE.split()))
    """)
    sc.end()
    sc.notes.append("The case expects '62 01 02' for a 22 01 01 request; ISO 14229-1 echoes the requested DID, so "
                    "the script expects 62 01 01 followed by the variant code fault_free_profile writes.")
    if functional:
        sc.notes.append("On 2026-10-15 the ECU answered 10 03 on 7DF but nothing at all to 22 01 01 on 7DF (no "
                        "first frame on 738), while 22 01 01 on 730 works: an ECU finding unless the requirement "
                        "excludes DID 01 01 from functional requests.")


DIAG_CASES = {1: lambda sc: t_diag_ids(sc, False), 2: lambda sc: t_diag_ids(sc, True)}


# ---------------------------------------------------------------------------
# ECU-transmitted signal templates (2C0 and 13C workbooks)
# ---------------------------------------------------------------------------

def ecu_precondition(sc: Script, which: str = "both", frames: list | None = None):
    """Fault-free bench, IGN ON, no DTC, and the ECU frames observed."""
    ecu_frames(sc)
    precondition(sc, frames or [])
    sc.step("Monitor the ECU frames")
    presence(sc, which, "present", "monitor")
    sc.end()


def frame_ids_of(keys: list) -> tuple[str, str]:
    """Capture IDs and buses covering the frames carrying the given MAH keys."""
    frames = {MAH[k]["frame"] for k in keys}
    ids = ", ".join("fd_id" if f == canc_config.CANC_ECU_FD_FRAME else "hs_id" for f in sorted(frames))
    buses = ", ".join("CAN_FD_CHANNEL_NAME" if f == canc_config.CANC_ECU_FD_FRAME else "CAN_HS_CHANNEL_NAME"
                      for f in sorted(frames))
    return f"[{ids}]", f"[{buses}]"


def proveout_analysis(sc: Script, var: str, keys: list):
    sc.T(f"""
        for lamp_key in {keys!r}:
            lamp_def = MAH_CAN_SIGNAL_DEFS[lamp_key]
            lamp_id = CAN_RX_MESSAGE_CONFIG[lamp_def['frame']]['frame_ID']
            lamp_on_value = lamp_def['State_Values']['Lamp ON']
            lamp_off_value = lamp_def['State_Values']['Lamp OFF/Default']
            lamp_rows = [(frame_data.timestamp / 1000,
                          extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[lamp_key], lamp_def['bit_length']))
                         for frame_data in {var}_frames if frame_data.id == lamp_id]
            # The capture may span the restart: keep the frames after the last gap.
            lamp_restart = max([index for index in range(1, len(lamp_rows))
                                if lamp_rows[index][0] - lamp_rows[index - 1][0] > CANC_GAP_FRAMES * lamp_def['periodicity']] or [0])
            lamp_rows = lamp_rows[lamp_restart:]
            lamp_on_times = [t for t, value in lamp_rows if value == lamp_on_value]
            lamp_off_at = next((t for t, value in lamp_rows
                                if lamp_on_times and t > lamp_on_times[0] and value != lamp_on_value), None)
            lamp_on_ms = round(lamp_off_at - lamp_on_times[0], 1) if lamp_on_times and lamp_off_at is not None else None
            # The ECU's first frames after IGN ON carry the lamp OFF for about 60 ms before
            # the proveout starts (2026-10-15: 6 frames at 10 ms); the proveout must start
            # within the proveout tolerance of the first frame.
            RESULT.InterpretEqualResultRange(
                f"{{lamp_def['frame']}} {{lamp_def['signal']}} ON from the start of transmission (ms after the first frame)",
                round(lamp_on_times[0] - lamp_rows[0][0], 1) if lamp_on_times else None,
                0, CANC_LAMP_PROVEOUT_ON_MS * CANC_PROVEOUT_TOLERANCE_PERCENT / 100)
            RESULT.InterpretEqualResultRange(
                f"{{lamp_def['frame']}} {{lamp_def['signal']}} ON time in proveout (ms)", lamp_on_ms,
                CANC_LAMP_PROVEOUT_ON_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                CANC_LAMP_PROVEOUT_ON_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
            lamp_after = sorted({{value for t, value in lamp_rows
                                 if lamp_off_at is not None and lamp_off_at <= t <= lamp_off_at + CANC_LAMP_PROVEOUT_OFF_MS}})
            RESULT.InterpretEqualResult(
                f"{{lamp_def['frame']}} {{lamp_def['signal']}} OFF for {{CANC_LAMP_PROVEOUT_OFF_MS}} ms after proveout",
                lamp_after, [lamp_off_value])
    """)


def t_proveout(sc: Script, keys: list, periodicity_dlc: bool = False, wake: bool = False, wake_after: bool = False):
    ids, buses = frame_ids_of(keys)
    frames = wake_frames(sc) if (wake or wake_after) else []
    ecu_precondition(sc, "both", frames)
    proveout_window = "NM_IGN_ON_STARTUP_DELAY_MS + CANC_LAMP_PROVEOUT_ON_MS + CANC_LAMP_PROVEOUT_OFF_MS"
    if wake:
        sc.step("IGN OFF until bus sleep, then CAN wakeup (VCU NM), and record the lamp proveout")
        bus_sleep(sc)
        capture(sc, "proveout", ids, buses, None, "proveout", start_only=True)
        nm_wakeup(sc, verify=False)
        capture_stop(sc, "proveout", proveout_window)
    else:
        sc.step("Cycle IGN and record the lamp proveout")
        capture(sc, "proveout", ids, buses, None, "proveout", start_only=True)
        sc.T("PS.Power_Cycle()")
        capture_stop(sc, "proveout", proveout_window)
    proveout_analysis(sc, "proveout", keys)
    if periodicity_dlc:
        sc.T("""
            hs_rows = [frame_data for frame_data in proveout_frames if frame_data.id == hs_id]
            hs_restart = max([index for index in range(1, len(hs_rows))
                              if (hs_rows[index].timestamp - hs_rows[index - 1].timestamp) / 1000
                              > CANC_GAP_FRAMES * hs_period_ms] or [0])
            proveout_hs_frames = hs_rows[hs_restart:]
            RESULT.InterpretEqualResult(f"{hs_frame} DLC", sorted({len(frame_data.payload) for frame_data in proveout_hs_frames}),
                                        [CAN_RX_MESSAGE_CONFIG[hs_frame]['dlc']])
        """)
        periodicity_checks(sc, "proveout_hs", "hs_period_ms", "hs_frame")
    sc.end()
    if wake_after:
        sc.step("IGN OFF until bus sleep, then CAN wakeup (VCU NM), and record the proveout again")
        bus_sleep(sc)
        capture(sc, "wake_proveout", ids, buses, None, "wake_proveout", start_only=True)
        nm_wakeup(sc, verify=False)
        capture_stop(sc, "wake_proveout", proveout_window)
        proveout_analysis(sc, "wake_proveout", keys)
        sc.end()
    if wake or wake_after:
        sc.notes.append("A proveout needs an ECU start-up, so the ECU first goes to bus sleep and is then woken over "
                        "CAN by the VCU NM frame (active wakeup bit) with PKE_CLMP_STATE at its wake value: on "
                        "2026-10-15 the PKE clamp state sent after bus sleep did not wake the ECU, the VCU NM frame did.")


def t_plant_flash(sc: Script, keys: list):
    ids, buses = frame_ids_of(keys)
    ecu_precondition(sc, "both")
    sc.step("Put the ECU in plant mode and record the warning lamp")
    plant_enter(sc, power_cycle=False)
    capture(sc, "plant", ids, buses, None, "plant_mode", start_only=True)
    sc.T("PS.Power_Cycle()")
    capture_stop(sc, "plant", "plant_window_ms + CANC_PLANT_CAPTURE_STARTUPS * NM_IGN_ON_STARTUP_DELAY_MS")
    sc.T(f"""
        for lamp_key in {keys!r}:
            lamp_def = MAH_CAN_SIGNAL_DEFS[lamp_key]
            lamp_id = CAN_RX_MESSAGE_CONFIG[lamp_def['frame']]['frame_ID']
            flash_value = lamp_def['State_Values']['Flashing 1Hz']
            lamp_rows = [(frame_data.timestamp / 1000,
                          extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[lamp_key], lamp_def['bit_length']))
                         for frame_data in plant_frames if frame_data.id == lamp_id]
            flash_times = [t for t, value in lamp_rows if value == flash_value]
            flash_ms = round(flash_times[-1] - flash_times[0] + lamp_def['periodicity'], 1) if flash_times else None
            RESULT.InterpretEqualResultRange(
                f"{{lamp_def['frame']}} {{lamp_def['signal']}} flashing in plant mode (ms)", flash_ms,
                PLANT_MODE_OWNER_TRANSITION_DELAY_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                PLANT_MODE_OWNER_TRANSITION_DELAY_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
            lamp_after = sorted({{value for t, value in lamp_rows if flash_times and t > flash_times[-1]}})
            RESULT.InterpretEqualResult(f"{{lamp_def['frame']}} {{lamp_def['signal']}} stops flashing after plant mode",
                                        lamp_after, [lamp_def['State_Values']['Lamp OFF/Default']])
    """)
    sc.end()


def lamp_did(sc: Script, value: str):
    sc.T(f"""
        lamp_did_read = str(CAN.SendDiagByValues(f"{{READ_SID}} {{CANC_WARNING_LAMP_DID}}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{{int(READ_SID, 16) + 0x40:02X}} {{CANC_WARNING_LAMP_DID}} 0x{{{value}:02X}}".upper())
    """)


def t_lamp_faults(sc: Script, keys: list, did: bool, last: str):
    """INDC_SRS against the warning-lamp class of each fault: loop open and VIN
    mismatch (lamp DTCs), node absent and message content (no lamp), then a
    supply DTC (2C0) or a variant code error (13C)."""
    margin_setup(sc)
    lamp_values(sc)
    loop_setup(sc)
    vin_setup(sc)
    key_frame = next(iter(canc_config.KEY_TX_FRAMES))
    na = fault(sc, "absent", "loss", frame=key_frame, frame_expr="next(iter(KEY_TX_FRAMES))")
    mcf = fault(sc, "content", "crc", frame=key_frame, frame_expr="next(iter(KEY_TX_FRAMES))")
    ecu_precondition(sc, "both", [(na.bus, na.frame)])
    off_pairs = "[" + ", ".join(f"({k!r}, lamp_off)" for k in keys) + "]"
    on_pairs = "[" + ", ".join(f"({k!r}, lamp_on)" for k in keys) + "]"
    sc.step("Warning lamp OFF with no fault")
    check_signals(sc, off_pairs)
    if did:
        lamp_did(sc, "lamp_off")
    sc.end()
    sc.step("Create an open fault on Loop0")
    loop_open(sc)
    check_signals(sc, on_pairs)
    if did:
        lamp_did(sc, "lamp_on")
    sc.end()
    sc.step("Make the open fault historic")
    loop_heal(sc)
    ign_cycle(sc)
    check_signals(sc, off_pairs)
    if did:
        lamp_did(sc, "lamp_off")
    sc.end()
    sc.step(f"Create a node-absent DTC - {na.describe}")
    apply(sc, na)
    measure(sc, "absent_time_ms", [(na.dtc, ACTIVE)], "Time until the node-absent DTC is active")
    check_signals(sc, off_pairs)
    if did:
        lamp_did(sc, "lamp_off")
    sc.end()
    sc.step("Make the node-absent fault historic")
    heal(sc, na, measured=False)
    measure(sc, "absent_time_ms", [(na.dtc, HEALED)], "Time until the node-absent DTC is healed")
    ign_cycle(sc)
    sc.end()
    sc.step(f"Create a message content failure - {mcf.describe}")
    apply(sc, mcf)
    measure(sc, "content_time_ms", [(mcf.dtc, ACTIVE)], "Time until the message content failure is active")
    check_signals(sc, off_pairs)
    if did:
        lamp_did(sc, "lamp_off")
    heal(sc, mcf, measured=False)
    measure(sc, "content_time_ms", [(mcf.dtc, HEALED)], "Time until the message content failure is healed")
    sc.end()
    sc.step("Create a VIN mismatch (wrong VIN at start-up)")
    vin_mismatch(sc)
    check_signals(sc, on_pairs)
    if did:
        lamp_did(sc, "lamp_on")
    vin_restore(sc)
    sc.end()
    if last == "voltage":
        sc.C("PS.SetVoltage(NOMINAL_VOLTAGE)")
        sc.step("Create a battery-voltage-low DTC")
        sc.T("PS.SetVoltage(CANC_UNDERVOLTAGE_TEST_VOLTAGE)")
        measure(sc, "voltage_time_ms", [("Under_Voltage", V_ACTIVE)], "Time until the under-voltage DTC is active")
        check_signals(sc, on_pairs)
        sc.T("PS.SetVoltage(NOMINAL_VOLTAGE)")
        sc.end()
    else:
        sc.flags.add("needs_profile")
        sc.step("Create a variant code error")
        sc.T("manage_variant_code('VARIANT_STATUS', 'disable', project=PROJECT_NAME, base_from_project_default=True)")
        ign_cycle(sc)
        check_signals(sc, on_pairs)
        if did:
            lamp_did(sc, "lamp_on")
        sc.end()
    cleanup_heal(sc, mcf)
    cleanup_heal(sc, na)
    sc.notes.append("'Any node absent DTC' and 'message content failure' are created on the first key frame of "
                    "KEY_TX_FRAMES (frame stopped / CRC no longer updated). Each lamp check waits for the DTC that "
                    "drives it, and every lamp read after an IGN cycle waits for the end of the start-up: the "
                    "proveout keeps the lamp ON for 6 s and OFF for 1 s whatever the faults (2026-10-15).")


def t_padl_switch(sc: Script, keys: list):
    sc.S("""
        switch_def = MAH_CAN_SIGNAL_DEFS['PSGR_AIRBAG_SW_IC']
        pab_on = switch_def['State_Values']['PAB ON / Default']
        pab_off = switch_def['State_Values']['PAB OFF']
        padl_on = MAH_CAN_SIGNAL_DEFS['INDC_PADL']['State_Values']['Lamp ON']
        padl_off = MAH_CAN_SIGNAL_DEFS['INDC_PADL']['State_Values']['Lamp OFF/Default']
    """)
    sc.C("CAN.ReloadDefaultPeriodicFrame(switch_def['bus'], switch_def['frame'])")
    ecu_precondition(sc, "both", [("switch_def['bus']", "switch_def['frame']")])
    sc.step("PSGR_AIRBAG_SW_IC = PAB ON (default)")
    set_bench_signal(sc, "switch_def", "pab_on", "CANC_DCS_STATE_SETTLE_MS")
    check_signals(sc, "[" + ", ".join(f"({k!r}, padl_off)" for k in keys) + "]")
    sc.end()
    sc.step("PSGR_AIRBAG_SW_IC = PAB OFF")
    set_bench_signal(sc, "switch_def", "pab_off", "CANC_DCS_STATE_SETTLE_MS")
    check_signals(sc, "[" + ", ".join(f"({k!r}, padl_on)" for k in keys) + "]")
    sc.end()


def ign_values(sc: Script):
    if "ign_values" in sc.flags:
        return
    sc.flags.add("ign_values")
    sc.S("""
        ign_states = MAH_CAN_SIGNAL_DEFS['IGN_STS_SRS']['State_Values']
        ign_off = ign_states['IGN OFF/Default']
        ign_hw = ign_states['IGN ON due to HW']
        ign_can = ign_states['IGN ON due to CAN wakeup']
    """)


def ign_off_observed(sc: Script, keys: list, var: str):
    """IGN OFF with no wake request; the last frames before the ECU stops carry
    IGN_STS_SRS = IGN OFF."""
    ids, buses = frame_ids_of(keys)
    capture(sc, var, ids, buses, None, var, start_only=True)
    sc.T("""
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
    """)
    capture_stop(sc, var, "presence_window_ms")
    sc.T(f"""
        for ign_key in {keys!r}:
            ign_def = MAH_CAN_SIGNAL_DEFS[ign_key]
            ign_seen = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[ign_key], ign_def['bit_length'])
                        for frame_data in {var}_frames
                        if frame_data.id == CAN_RX_MESSAGE_CONFIG[ign_def['frame']]['frame_ID']]
            RESULT.InterpretEqualResult(f"{{ign_def['frame']}} IGN_STS_SRS after IGN OFF (last frames sent)",
                                        ign_seen[-1:], [ign_off])
    """)


def t_ign_sts_2c0(sc: Script):
    ign_values(sc)
    ecu_precondition(sc, "hs", wake_frames(sc))
    sc.step("IGN OFF and observe IGN_STS_SRS")
    ign_off_observed(sc, ["SRS1_20_IGN_STS_SRS"], "ign_off")
    sc.end()
    sc.step("IGN ON and observe IGN_STS_SRS")
    sc.T("""
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
        PS.IGN_ON()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
    """)
    check_signals(sc, "[('SRS1_20_IGN_STS_SRS', ign_hw)]")
    sc.end()


def t_crash(sc: Script, crash: str, keys_by_frame: dict, wake: bool = False):
    """A crash through the delivered curves; the crash signals change and hold
    for CANC_CRASH_SIGNAL_HOLD_MS in each frame named."""
    margin_setup(sc)
    crash_setup(sc, crash)
    sc.S(f"location_expected = {crash_location(crash)}")
    if any("door" in roles for roles in keys_by_frame.values()):
        sc.S("door_set = MAH_CAN_SIGNAL_DEFS['DOOR_UNLOCK']['State_Values']['Request to unlock Doors']")
    if any("mode" in roles for roles in keys_by_frame.values()):
        sc.S("mode_active = MAH_CAN_SIGNAL_DEFS['SRS_OPERATION_MODE']['State_Values']['active']")
    frames = wake_frames(sc) if wake else []
    ecu_precondition(sc, "both", frames)
    sc.step(f"Load the {crash} crash curves")
    sc.T("load_crash_curves(crash_curve_key, project=PROJECT_NAME)")
    sc.end()
    if wake:
        sc.step("IGN OFF, then CAN wakeup (PKE_CLMP_STATE at its wake value)")
        can_wakeup(sc)
        sc.end()
    sc.step("Crash signals hold their default values")
    defaults = []
    for roles in keys_by_frame.values():
        defaults.append(f"({roles['sts']!r}, crash_clear)")
        defaults.append(f"({roles['loc']!r}, location_none)")
        if "door" in roles:
            defaults.append(f"({roles['door']!r}, MAH_CAN_SIGNAL_DEFS['DOOR_UNLOCK']['State_Values']['No Request / Default'])")
        if "mode" in roles:
            defaults.append(f"({roles['mode']!r}, mode_active)")
        if "scm" in roles:
            defaults.append(f"({roles['scm']!r}, 0)")
    check_signals(sc, "[" + ", ".join(defaults) + "]")
    sc.end()
    sc.step(f"Create the {crash} crash")
    crash_trigger(sc)
    for frame_id, roles in keys_by_frame.items():
        rows = "hs_rows" if frame_id == "hs_id" else "fd_rows"
        frame_name = "hs_frame" if frame_id == "hs_id" else "fd_frame"
        crash_rows(sc, "crash", frame_id, roles, rows)
        sc.T(f"""
            {rows}_crash = [row for row in {rows} if row['sts'] == crash_set]
            {rows}_hold_ms = (round({rows}_crash[-1]['t'] - {rows}_crash[0]['t'], 1)
                              + CAN_RX_MESSAGE_CONFIG[{frame_name}]['periodicity']) if {rows}_crash else None
            RESULT.InterpretEqualResultRange(f"{{{frame_name}}} STS_CRASH set for (ms)", {rows}_hold_ms,
                                             CANC_CRASH_SIGNAL_HOLD_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                                             CANC_CRASH_SIGNAL_HOLD_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
            RESULT.InterpretEqualResult(f"{{{frame_name}}} CRASH_LOCATION while STS_CRASH is set",
                                        sorted({{row['loc'] for row in {rows}_crash}}), [location_expected])
            {rows}_after = [row for row in {rows} if {rows}_crash and row['t'] > {rows}_crash[-1]['t']]
            RESULT.InterpretEqualResult(f"{{{frame_name}}} STS_CRASH clear after the hold time",
                                        sorted({{row['sts'] for row in {rows}_after}}), [crash_clear])
        """)
        if "door" in roles:
            sc.T(f"""
                RESULT.InterpretEqualResult(f"{{{frame_name}}} DOOR_UNLOCK while STS_CRASH is set",
                                            sorted({{row['door'] for row in {rows}_crash}}), [door_set])
            """)
        if "mode" in roles:
            sc.T(f"""
                RESULT.InterpretEqualResult(f"{{{frame_name}}} SRS_OPERATION_MODE during the crash",
                                            sorted({{row['mode'] for row in {rows}}}), [mode_active])
            """)
        if "scm" in roles:
            sc.T(f"""
                {rows}_scm = [row['scm'] for row in {rows}_crash]
                {rows}_scm_limit = 1 << MAH_CAN_SIGNAL_DEFS[{roles['scm']!r}]['bit_length']
                RESULT.InterpretEqualResult(f"{{{frame_name}}} SCM_CNT counts (1..{{{rows}_scm_limit - 1}}, rolling over) while STS_CRASH is set",
                                            bool({rows}_scm) and len(set({rows}_scm)) > 1
                                            and all(0 < value < {rows}_scm_limit for value in {rows}_scm[1:]), True)
                RESULT.InterpretEqualResult(f"{{{frame_name}}} SCM_CNT back to 0 after the crash",
                                            sorted({{row['scm'] for row in {rows}_after}}), [0])
            """)
    sc.end()
    sc.C("fault_free_profile()")


SRS1_20_CRASH = {"sts": "SRS1_20_STS_CRASH", "loc": "SRS1_20_CRASH_LOCATION", "door": "DOOR_UNLOCK",
                 "mode": "SRS1_20_SRS_OPERATION_MODE", "scm": "SRS1_20_SCM_CNT"}
FD_CRASH = {"sts": "STS_CRASH", "loc": "CRASH_LOCATION"}
HS_CRASH = {"sts": "SRS1_20_STS_CRASH", "loc": "SRS1_20_CRASH_LOCATION"}


def t_crash_sequence(sc: Script, scenarios: list, keys_by_frame: dict, title: str):
    """Multi-event crash sequences: each scenario is (curve key, expected
    CRASH_LOCATION sequence or final value, optional first-crash-rollover value)."""
    margin_setup(sc)
    for index, (curve, _, _) in enumerate(scenarios, 1):
        crash_setup(sc, curve, f"crash{index}")
    ecu_precondition(sc, "both")
    for index, (curve, locations, first_roll) in enumerate(scenarios, 1):
        sc.step(f"{title}: {curve.replace('_', ' ')}")
        sc.T(f"load_crash_curves(crash{index}_curve_key, project=PROJECT_NAME)")
        # The expected CRASH_LOCATION sequence (configuration states); the capture holds
        # CANC_CRASH_SEQUENCE_HOLDS crash signal hold times per crash of it.
        sc.T(f"seq{index}_expected = [" + ", ".join(crash_location(loc) for loc in locations) + "]")
        crash_trigger(sc, f"seq{index}",
                      window=f"CANC_CRASH_SEQUENCE_HOLDS * max(1, len(seq{index}_expected)) * CANC_CRASH_SIGNAL_HOLD_MS")
        expected = f"seq{index}_expected"
        for frame_id, roles in keys_by_frame.items():
            rows = f"seq{index}_{'hs' if frame_id == 'hs_id' else 'fd'}"
            frame_name = "hs_frame" if frame_id == "hs_id" else "fd_frame"
            crash_rows(sc, f"seq{index}", frame_id, roles, rows)
            sc.T(f"""
                {rows}_locations = [row['loc'] for row in {rows} if row['sts'] == crash_set]
                {rows}_sequence = [value for position, value in enumerate({rows}_locations)
                                   if position == 0 or value != {rows}_locations[position - 1]]
            """)
            if len(locations) > 1:
                sc.T(f"RESULT.InterpretEqualResult(f\"{{{frame_name}}} CRASH_LOCATION sequence\", {rows}_sequence, {expected})")
            else:
                sc.T(f"RESULT.InterpretEqualResult(f\"{{{frame_name}}} CRASH_LOCATION after the sequence\", "
                     f"{rows}_sequence[-1:], {expected})")
            if first_roll is not None and "roll" in roles:
                sc.T(f"""
                    RESULT.InterpretEqualResult(f"{{{frame_name}}} STS_FIRST_CRASH_ROLL",
                                                sorted({{row['roll'] for row in {rows} if row['sts'] == crash_set}}),
                                                [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values'][{first_roll!r}]])
                """)
        if index < len(scenarios):
            sc.T("fault_free_profile()")
        sc.end()
    sc.C("fault_free_profile()")
    sc.automation = "Automatic once the multi-event crash curves are delivered (blocked until then)"


def t_no_crash_update(sc: Script, curve: str):
    margin_setup(sc)
    crash_setup(sc, curve)
    ecu_precondition(sc, "both")
    sc.step(f"Load the {curve.replace('_', ' ')} curves and play them")
    sc.T("load_crash_curves(crash_curve_key, project=PROJECT_NAME)")
    crash_trigger(sc)
    for frame_id, roles in (("fd_id", FD_CRASH), ("hs_id", HS_CRASH)):
        rows = "hs_rows" if frame_id == "hs_id" else "fd_rows"
        frame_name = "hs_frame" if frame_id == "hs_id" else "fd_frame"
        crash_rows(sc, "crash", frame_id, roles, rows)
        sc.T(f"""
            RESULT.InterpretEqualResult(f"{{{frame_name}}} STS_CRASH stays clear", sorted({{row['sts'] for row in {rows}}}), [crash_clear])
            RESULT.InterpretEqualResult(f"{{{frame_name}}} CRASH_LOCATION stays at no crash",
                                        sorted({{row['loc'] for row in {rows}}}), [location_none])
        """)
    sc.end()
    sc.C("fault_free_profile()")
    sc.automation = "Automatic once the PT-only crash curves are delivered (blocked until then)"
    sc.notes.append("The case allows near-crash or PT-only curves; the near-crash entry of the project "
                    "crash-curve table has no curve files, so the script needs the PT-only set.")


def t_near_crash(sc: Script, wake: bool = False, hs_checks: bool = False, edr: bool = False):
    margin_setup(sc)
    crash_setup(sc, "near")
    sc.S("""
        near_set = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['Crash']
        near_clear = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['No Near Crash']
    """)
    frames = wake_frames(sc) if wake else []
    ecu_precondition(sc, "both", frames)
    sc.step("Load the near-crash curves")
    sc.T("load_crash_curves(crash_curve_key, project=PROJECT_NAME)")
    sc.end()
    if wake:
        sc.step("IGN OFF, then CAN wakeup (PKE_CLMP_STATE at its wake value)")
        can_wakeup(sc)
        sc.end()
    sc.step("NEAR_CRASH initial value")
    check_signals(sc, "[('NEAR_CRASH', near_clear)]")
    sc.end()
    sc.step("Create the near crash")
    crash_trigger(sc)
    crash_rows(sc, "crash", "fd_id", {"near": "NEAR_CRASH"}, "near_rows")
    sc.T("""
        near_on = [row for row in near_rows if row['near'] == near_set]
        near_hold_ms = round(near_on[-1]['t'] - near_on[0]['t'], 1) + fd_period_ms if near_on else None
        RESULT.InterpretEqualResultRange("SRS1_FD_10 NEAR_CRASH set for (ms)", near_hold_ms,
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
    """)
    if hs_checks:
        sc.T("""
            # A near crash deploys nothing: SRS1_20 keeps the values canc_config gives for it.
            for short_name, expected_text in CAN_SIGNAL_Rx_EXPECTED_VALUES['near'].items():
                near_frame, near_signal = CAN_HSCAN_SIGNAL_Rx_MAP[short_name]
                near_text = str(CAN.GetSignalFromFrame(CAN_HS_CHANNEL_NAME, near_frame, near_signal)).strip()
                try:
                    near_value = int(near_text, 16) if near_text.lower().startswith("0x") else int(float(near_text))
                except ValueError:
                    near_value = near_text
                RESULT.InterpretEqualResult(f"{near_frame} {near_signal} after the near crash", str(near_value),
                                            str(int(expected_text, 16)))
        """)
    sc.end()
    if edr:
        sc.step("Read the longitudinal and lateral delta-V in the EDR")
        sc.T("""
            try:
                near_edr = read_edr_parameters(list(CANC_EDR_MAX_DELTA_V_ELEMENT.values()), crash_type='near',
                                               return_data=True) or {}
            except Exception as edr_error:
                near_edr = {}
                RESULT.LogCustomAction("EDR delta-V of the near crash read", "Decoded by read_edr_parameters",
                                       f"Not possible: {edr_error!r}", False)
            for direction, element in CANC_EDR_MAX_DELTA_V_ELEMENT.items():
                near_delta = (near_edr.get('decoded') or {}).get(element)
                near_delta = near_delta[0] if isinstance(near_delta, (list, tuple)) and near_delta else near_delta
                RESULT.InterpretEqualResultRange(f"EDR {direction} delta-V of the near crash (km/h)",
                                                 abs(near_delta) if isinstance(near_delta, (int, float)) else near_delta,
                                                 CANC_NEAR_CRASH_DELTA_V_MIN_KMH, float('inf'))
        """)
        sc.end()
        sc.notes.append("The case expects STS_CRASH, DOOR_UNLOCK and CRASH_LOCATION to show a left crash for a "
                        "near crash, and NEAR_CRASH in SRS1_20, which does not carry it; the script expects "
                        "canc_config CAN_SIGNAL_Rx_EXPECTED_VALUES['near'] in SRS1_20 and NEAR_CRASH in SRS1_FD_10.")
    sc.C("fault_free_profile()")
    sc.automation = "Automatic once the near-crash curves are delivered (blocked until then)"


def t_near_crash_manual(sc: Script):
    sc.S("""
        near_set = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['Crash']
        near_clear = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['No Near Crash']
    """)
    sc.flags.add("needs_profile")
    ecu_precondition(sc, "both")
    sc.step("NEAR_CRASH initial value")
    check_signals(sc, "[('NEAR_CRASH', near_clear)]")
    sc.end()
    sc.step("Create a near crash by shaking the ECU")
    capture(sc, "shake", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, "near_crash_shake", start_only=True)
    operator_action(sc, "Shake the ECU hard enough to cause a near crash, within the next "
                        "{CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.")
    capture_stop(sc, "shake", None)
    crash_rows(sc, "shake", "fd_id", {"near": "NEAR_CRASH"}, "near_rows")
    sc.T("""
        near_on = [row for row in near_rows if row['near'] == near_set]
        RESULT.InterpretEqualResult("SRS1_FD_10 NEAR_CRASH set during the shaking", bool(near_on), True)
        near_runs = []
        for row in near_rows:
            if row['near'] == near_set and (not near_runs or row['t'] - near_runs[-1][1] > CANC_RUN_BREAK_FRAMES * fd_period_ms):
                near_runs.append([row['t'], row['t']])
            elif row['near'] == near_set:
                near_runs[-1][1] = row['t']
        RESULT.InterpretEqualResultRange("SRS1_FD_10 NEAR_CRASH hold time (ms)",
                                         [round(end - start, 1) + fd_period_ms for start, end in near_runs] or [None],
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
    """)
    sc.end()
    sc.C("fault_free_profile()")
    sc.automation = "Semi-automatic (operator shakes the ECU)"


def t_parity(sc: Script, parity_key: str, trigger: str | None):
    margin_setup(sc)
    sc.S(f"""
        parity_key = {parity_key!r}
        parity_def = MAH_CAN_SIGNAL_DEFS[parity_key]
        parity_id = CAN_RX_MESSAGE_CONFIG[parity_def['frame']]['frame_ID']
        # EVEN_PARITY_BIT makes the count of ones in bits 0 to (its start bit - 1) of byte 0 even.
        parity_mask = (1 << CAN_SIGNAL_START_BIT[parity_key]) - 1
        parity_odd = parity_def['State_Values']['ODD/Default']
        parity_even = parity_def['State_Values']['Even']
    """)
    which = "fd" if MAH[parity_key]["frame"] == canc_config.CANC_ECU_FD_FRAME else "hs"
    ids, buses = frame_ids_of([parity_key])
    if trigger == "loop":
        loop_setup(sc)
    if trigger == "crash":
        crash_setup(sc, "front")
    ecu_precondition(sc, which)
    parity_check = """
        {v}_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in {v}_frames if frame_data.id == parity_id]
        {v}_errors = [row for row in {v}_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{{parity_def['frame']}} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str({v}_errors[:5]), "[]")
    """
    sc.step("Verify EVEN_PARITY_BIT with no fault")
    capture(sc, "idle", ids, buses, "presence_window_ms", "parity_idle")
    sc.T(parity_check.format(v="idle"))
    sc.T("RESULT.InterpretEqualResult(f\"{parity_def['frame']} EVEN_PARITY_BIT\", sorted({row[1] for row in idle_rows}), [parity_odd])")
    sc.end()
    if trigger == "loop":
        sc.step("Create a loop fault and verify EVEN_PARITY_BIT")
        loop_open(sc)
        # The lamp comes on about 1 s after the DTC (2026-10-15) and changes byte 0, and
        # with it the parity bit: the frames are taken once the lamp shows ON.
        lamp_values(sc)
        lamp_key = "INDC_SRS" if MAH[parity_key]["frame"] == canc_config.CANC_ECU_FD_FRAME else "SRS1_20_INDC_SRS"
        check_signals(sc, f"[({lamp_key!r}, lamp_on)]", "Warning lamp ON with the loop fault: ")
        capture(sc, "fault", ids, buses, "presence_window_ms", "parity_fault")
        sc.T(parity_check.format(v="fault"))
        sc.T("RESULT.InterpretEqualResult(f\"{parity_def['frame']} EVEN_PARITY_BIT\", sorted({row[1] for row in fault_rows}), [parity_even])")
        sc.end()
    elif trigger == "crash":
        sc.step("Simulate a front crash and verify EVEN_PARITY_BIT")
        sc.T("load_crash_curves(crash_curve_key, project=PROJECT_NAME)")
        crash_trigger(sc, "fault", ids, buses)
        sc.T(parity_check.format(v="fault"))
        sc.T("RESULT.LogAction(f\"{parity_def['frame']} EVEN_PARITY_BIT values during the crash\", "
             "str(sorted({row[1] for row in fault_rows})))")
        sc.end()
        sc.C("fault_free_profile()")
        sc.notes.append("The case expects EVEN_PARITY_BIT = 1 throughout the crash; the bit follows byte 0 "
                        "(DBC: even parity over bits 0-6), so the script grades every frame against byte 0 and "
                        "records the values seen.")


def counter_check(sc: Script, var: str, key_expr: str, max_expr: str, label: str):
    sc.T(f"""
        {var}_def = MAH_CAN_SIGNAL_DEFS[{key_expr}]
        {var}_values = [extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[{key_expr}], {var}_def['bit_length'])
                        for frame_data in {var}_frames
                        if frame_data.id == CAN_RX_MESSAGE_CONFIG[{var}_def['frame']]['frame_ID']]
        # validate_counter covers power-of-two ranges only; 0..14 needs the modulo check.
        {var}_errors = [(index, earlier, later)
                        for index, (earlier, later) in enumerate(zip({var}_values, {var}_values[1:]), 1)
                        if (later - earlier) % ({max_expr} + 1) != 1]
        RESULT.InterpretEqualResult(f"{{{var}_def['signal']}} counts by one{label}", str({var}_errors[:10]), "[]")
        RESULT.InterpretEqualResult(f"{{{var}_def['signal']}} range{label}",
                                    f"{{min({var}_values, default=None)}}..{{max({var}_values, default=None)}}",
                                    f"0..{{{max_expr}}}")
    """)


def t_hs_alive_eol(sc: Script):
    sc.flags.add("needs_profile")
    ecu_precondition(sc, "hs")
    for action in ("disable", "enable"):
        sc.step(f"Write the EOL code with the alive-counter bit {action}d and cycle IGN")
        sc.T(f"manage_eol_code('ALIVE_COUNTER', {action!r}, project=PROJECT_NAME, base_from_project_default=True)")
        ign_cycle(sc)
        sc.end()
        sc.step("Verify the HS-CAN alive counter")
        var = f"alive_{action}"
        capture(sc, var, "[hs_id]", "[CAN_HS_CHANNEL_NAME]",
                f"(CANC_COUNTER_SAMPLE_ROLLOVERS * (CANC_HS_ALIVE_COUNTER_MAX[{action!r}] + 1) + CANC_WINDOW_MARGIN_FRAMES) * hs_period_ms", var)
        counter_check(sc, var, "'SRSHS_MSG_CNT'", f"CANC_HS_ALIVE_COUNTER_MAX[{action!r}]", "")
        sc.end()
    sc.notes.append(HS_COUNTER_NOTE)


def t_alive_restart(sc: Script, counters: list, trigger: str, eol: str | None):
    """Counters restart from 0 after the trigger. counters: (MAH key, range spec):
    'enable'/'disable' (HS counter for that EOL state), 'default' (HS counter for
    the project default EOL), None (full width)."""
    sc.S("""
        alive_byte, alive_bit = M310_M314_M110_FEATURE_MAP['ALIVE_COUNTER']
        default_alive_action = 'enable' if int(DEFAULT_EOL_CODE.split()[alive_byte], 16) & (1 << alive_bit) else 'disable'
    """)
    specs = []
    for key, spec in counters:
        if spec is None:
            specs.append(f"({key!r}, (1 << MAH_CAN_SIGNAL_DEFS[{key!r}]['bit_length']) - 1)")
        elif spec == "default":
            specs.append(f"({key!r}, CANC_HS_ALIVE_COUNTER_MAX[default_alive_action])")
        else:
            specs.append(f"({key!r}, CANC_HS_ALIVE_COUNTER_MAX[{spec!r}])")
    sc.S(f"""
        counter_specs = [{', '.join(specs)}]
        counter_window_ms = max((CANC_COUNTER_SAMPLE_ROLLOVERS * (counter_max + 1) + CANC_WINDOW_MARGIN_FRAMES)
                                * MAH_CAN_SIGNAL_DEFS[counter_key]['periodicity'] for counter_key, counter_max in counter_specs)
    """)
    keys = [k for k, _ in counters]
    ids, buses = frame_ids_of(keys)
    in_wake = trigger in ("can_wake_cycle", "hard_reset_in_wake")
    frames = wake_frames(sc) if in_wake else []
    if trigger == "busoff":
        busoff_setup(sc)
    ecu_precondition(sc, "both", frames)
    if eol:
        sc.flags.add("needs_profile")
        sc.step(f"Write the EOL code with the alive-counter bit {eol}d and cycle IGN")
        sc.T(f"manage_eol_code('ALIVE_COUNTER', {eol!r}, project=PROJECT_NAME, base_from_project_default=True)")
        ign_cycle(sc)
        sc.end()
    if in_wake:
        sc.step("IGN OFF until bus sleep, then CAN wakeup (VCU NM active wakeup bit = 1)")
        bus_sleep(sc)
        nm_wakeup(sc)
        sc.end()
    sc.step("Verify the alive counters")
    capture(sc, "running", ids, buses, "counter_window_ms", "alive_running")
    sc.T("""
        for counter_key, counter_max in counter_specs:
            counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
            counter_values = [extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key], counter_def['bit_length'])
                              for frame_data in running_frames
                              if frame_data.id == CAN_RX_MESSAGE_CONFIG[counter_def['frame']]['frame_ID']]
            # validate_counter covers power-of-two ranges only; 0..14 needs the modulo check.
            counter_errors = [(index, earlier, later)
                              for index, (earlier, later) in enumerate(zip(counter_values, counter_values[1:]), 1)
                              if (later - earlier) % (counter_max + 1) != 1]
            RESULT.InterpretEqualResult(f"{counter_def['signal']} counts by one", str(counter_errors[:10]), "[]")
            RESULT.InterpretEqualResult(f"{counter_def['signal']} range",
                                        f"{min(counter_values, default=None)}..{max(counter_values, default=None)}",
                                        f"0..{counter_max}")
    """)
    sc.end()
    titles = {"ign": "Cycle IGN", "batt": "Battery off and on", "hard_reset": "Hard reset (11 01)",
              "soft_reset": "Soft reset (11 03)", "busoff": "Bus-off on HS-CAN and back",
              "can_wake_cycle": "CAN wakeup off and on", "hard_reset_in_wake": "Hard reset (11 01) in CAN wakeup"}
    sc.step(f"{titles[trigger]} while the counters run, and observe the restart")
    capture(sc, "restart", ids, buses, None, "alive_restart", start_only=True)
    if trigger == "ign":
        sc.T("PS.Power_Cycle()")
    elif trigger == "batt":
        sc.T("""
            PS.BATT_OFF()
            Wait(CANC_SUPPLY_OFF_MS)
            PS.BATT_ON()
        """)
    elif trigger in ("hard_reset", "hard_reset_in_wake"):
        sc.T("""
            # The ECU answers 11 01 only in the extended session (7F 11 7F in the default
            # session, 2026-10-15).
            enter_ext_session()
            RESULT.InterpretEqualResult('ECU reset (hard)', str(CAN.SendDiagByValues(UDS_REQ_11_01)), UDS_RESP_51_01)
        """)
    elif trigger == "soft_reset":
        sc.T("""
            enter_ext_session()
            RESULT.InterpretEqualResult('ECU reset (soft)', str(CAN.SendDiagByValues(UDS_REQ_11_03)), UDS_RESP_51_03)
        """)
    elif trigger == "busoff":
        busoff_create_short = "Short CAN-H to CAN-L on the HS-CAN bus for a few seconds, then remove the short."
        operator_action(sc, busoff_create_short, "CANC_BUS_OFF_SHORT_WINDOWS * CAN_BUS_OFF_OPERATOR_WINDOW_MS")
    elif trigger == "can_wake_cycle":
        sc.T("""
            # Active wakeup bit off: no VCU NM frame and the PKE clamp state at rest, until
            # the ECU sleeps; then the VCU NM frame with the active wakeup bit wakes it again.
            CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
            Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
            CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ChangeSignalValue(nm_def['bus'], CAN_NM_WAKEUP_FRAME, CAN_NM_WAKEUP_SIGNAL, str(CAN_NM_WAKEUP_VALUE))
            CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_WAKEUP_VALUES[0]))
        """)
    capture_stop(sc, "restart", "NM_IGN_ON_STARTUP_DELAY_MS + counter_window_ms")
    sc.T("""
        for counter_key, counter_max in counter_specs:
            counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
            counter_rows = [(frame_data.timestamp / 1000,
                             extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key], counter_def['bit_length']))
                            for frame_data in restart_frames
                            if frame_data.id == CAN_RX_MESSAGE_CONFIG[counter_def['frame']]['frame_ID']]
            # The restart is the gap in transmission or, failing one, the first break in the count.
            counter_gap = next((index for index in range(1, len(counter_rows))
                                if counter_rows[index][0] - counter_rows[index - 1][0] > CANC_GAP_FRAMES * counter_def['periodicity']), None)
            counter_break = next((index for index in range(1, len(counter_rows))
                                  if (counter_rows[index][1] - counter_rows[index - 1][1]) % (counter_max + 1) != 1), None)
            counter_restart = counter_gap if counter_gap is not None else counter_break
            counter_after = [value for _, value in counter_rows[counter_restart:]] if counter_restart is not None else []
            RESULT.InterpretEqualResult(f"{counter_def['signal']} restarts from 0", counter_after[:1], [0])
            RESULT.InterpretEqualResult(f"{counter_def['signal']} counts by one after the restart",
                                        all((later - earlier) % (counter_max + 1) == 1
                                            for earlier, later in zip(counter_after, counter_after[1:])), True)
            RESULT.InterpretEqualResult(f"{counter_def['signal']} runs up to {counter_max} after the restart",
                                        max(counter_after, default=None), counter_max)
    """)
    sc.end()
    if in_wake:
        sc.notes.append("The case wakes the ECU with the VCU NM active wakeup bit, and so does the script (from bus "
                        "sleep, with PKE_CLMP_STATE at its wake value too): on 2026-10-15 the PKE clamp state alone "
                        "did not wake the sleeping ECU, the VCU NM frame did (13C 48).")
    if trigger == "busoff":
        sc.automation = "Semi-automatic (operator creates and removes the bus-off)"
    if "SRSHS_MSG_CNT" in keys:
        sc.notes.append(HS_COUNTER_NOTE)


HS_COUNTER_NOTE = ("On 2026-10-15 every SRS1_20 frame carried SRSHS_MSG_CNT = 0 (byte 6 = 0x00 in all logged "
                   "frames) with the default EOL code, whose alive-counter bit (byte 6 bit 2) is 0, i.e. 0..15 per "
                   "agent_sc3.md section 2.2: an ECU finding the HS-CAN alive-counter checks report until it is "
                   "fixed.")


def belt_values(sc: Script, key: str, prefix: str = "belt"):
    sc.S(f"""
        {prefix}_key = {key!r}
        {prefix}_states = MAH_CAN_SIGNAL_DEFS[{prefix}_key]['State_Values']
        {prefix}_unbuckled = next(value for label, value in {prefix}_states.items() if label.startswith('Not Buckled'))
        {prefix}_buckled = {prefix}_states['Buckled']
        {prefix}_faulty = {prefix}_states['Buckle Faulty']
        {prefix}_reserved = {prefix}_states['Reserved']
        {prefix}_channel = SLSNumber[CANC_BELT_CHANNEL[{prefix}_key]]
    """)
    sc.C(f"SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], {prefix}_channel)")


def dcs_timing(sc: Script):
    if "dcs_timing" in sc.flags:
        return
    sc.flags.add("dcs_timing")
    sc.S("""
        dcs_fault_ms = int(DCS_fault_time['Qualification'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
        dcs_heal_ms = int(DCS_fault_time['Dequalification'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
        dcs_cc_ms = int(DCS_fault_time['Qualification_CC'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
        dcs_cc_heal_ms = int(DCS_fault_time['Dequalification_CC'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    """)
    sc.C("PS.ClearLeakageVBATBusHigh()")


def ods_prerequisite(sc: Script, belt_key: str):
    ods_key = canc_config.CANC_BELT_ODS.get(belt_key)
    if not ods_key:
        return
    sc.S(f"""
        ods_key = {ods_key!r}
        ods_channel = ODSNumber[CANC_ODS_CHANNEL[ods_key]]
        ods_present = MAH_CAN_SIGNAL_DEFS[ods_key]['State_Values']['PRESENT']
    """)
    sc.C("SET_DCS_LOADS(CANC_ODS_LOADS['NOT_PRESENT'], ods_channel)")
    sc.step("Seat ODS present (prerequisite for the rear belt status)")
    sc.T("""
        SET_DCS_LOADS(CANC_ODS_LOADS['PRESENT'], ods_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
    """)
    check_signals(sc, "[(ods_key, ods_present)]")
    sc.end()


def init_window_check(sc: Script, var: str, key_var: str, reserved: str, actual: str):
    sc.T(f"""
        {var}_rows = [(frame_data.timestamp / 1000,
                       extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[{key_var}], MAH_CAN_SIGNAL_DEFS[{key_var}]['bit_length']))
                      for frame_data in init_frames if frame_data.id == fd_id]
        {var}_restart = max([index for index in range(1, len({var}_rows))
                             if {var}_rows[index][0] - {var}_rows[index - 1][0] > CANC_GAP_FRAMES * fd_period_ms] or [0])
        {var}_rows = {var}_rows[{var}_restart:]
        {var}_reserved = [t for t, value in {var}_rows if value == {reserved}]
        # The ECU's first frames after IGN ON carry the default for about 60 ms before
        # the Reserved state (2026-10-15: 0 for 60 ms, Reserved until 230 ms, then the
        # actual value), so Reserved must show within the init window, not in frame one.
        RESULT.InterpretEqualResultRange(f"{{{key_var}}} reads Reserved at the start of transmission (ms after the first frame)",
                                         round({var}_reserved[0] - {var}_rows[0][0], 1) if {var}_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResultRange(f"{{{key_var}}} Reserved after IGN ON for (ms)",
                                         round({var}_reserved[-1] - {var}_rows[0][0], 1) + fd_period_ms if {var}_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResult(f"{{{key_var}}} then takes the actual value",
                                    {var}_rows[-1][1] if {var}_rows else None, {actual})
    """)


def t_belt_states(sc: Script, key: str, init_check: bool, on_2c0: bool):
    ecu_frames(sc)
    dcs_timing(sc)
    belt_values(sc, key)
    partner = canc_config.CANC_BELT_CROSS_CONNECT_PARTNER[key]
    sc.S(f"partner_channel = SLSNumber[CANC_BELT_CHANNEL[{partner!r}]]")
    sc.C("SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], partner_channel)")
    ecu_precondition(sc, "both")
    ods_prerequisite(sc, key)
    sc.step("Set the belt to unbuckled")
    sc.T("""
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
    """)
    check_signals(sc, "[(belt_key, belt_unbuckled)]")
    sc.end()
    sc.step("Set the belt to buckled")
    sc.T("""
        SET_DCS_LOADS(DCS_Fault_Description['buckle'], belt_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
    """)
    check_signals(sc, "[(belt_key, belt_buckled)]")
    sc.end()
    sc.step("Set the belt to faulty (short to battery)")
    sc.T("""
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, belt_channel)
        PS.SetLeakageVBATBusHigh()
        Wait(dcs_fault_ms)
    """)
    check_signals(sc, "[(belt_key, belt_faulty)]")
    sc.T("""
        PS.ClearLeakageVBATBusHigh()
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        Wait(dcs_heal_ms)
    """)
    sc.end()
    sc.step(f"Set the belt to faulty (cross-connected with {partner})")
    sc.T("""
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, belt_channel)
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, partner_channel)
        Wait(dcs_cc_ms)
    """)
    check_signals(sc, "[(belt_key, belt_faulty)]")
    sc.T("""
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], partner_channel)
        Wait(dcs_cc_heal_ms)
    """)
    sc.end()
    if init_check:
        sc.step("Cycle IGN and observe the belt status in the first frames")
        capture(sc, "init", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, "belt_init", start_only=True)
        sc.T("PS.Power_Cycle()")
        capture_stop(sc, "init", "NM_IGN_ON_STARTUP_DELAY_MS + CANC_SEAT_BELT_INIT_WINDOW_MS")
        init_window_check(sc, "belt_init", "belt_key", "belt_reserved", "belt_unbuckled")
        sc.end()
    sc.notes.append("A faulty belt is load CANC_DCS_FAULT_LOAD with Leakage VBAT Bus High (bench note); the "
                    "cross-connect puts both belt channels on that load without the leakage (assumed wiring).")
    if on_2c0:
        sc.notes.append("SRS1_20 (0x2C0) carries no seat-belt signal; the belt status is read in SRS1_FD_10.")


def t_belt_init(sc: Script, state: str):
    ecu_frames(sc)
    dcs_timing(sc)
    belt_values(sc, "STS_SEAT_BLT_PSGR", "psgr")
    belt_values(sc, "STS_SEAT_BLT_DRV", "drv")
    ecu_precondition(sc, "both")
    load = {"unbuckled": "DCS_Fault_Description['unbuckle']", "buckled": "DCS_Fault_Description['buckle']",
            "faulty": "CANC_DCS_FAULT_LOAD"}[state]
    sc.step(f"Set both front belts to {state}")
    sc.T(f"""
        SET_DCS_LOADS({load}, psgr_channel)
        SET_DCS_LOADS({load}, drv_channel)
    """)
    if state == "faulty":
        sc.T("PS.SetLeakageVBATBusHigh()")
    sc.T("Wait(dcs_fault_ms)" if state == "faulty" else "Wait(CANC_DCS_STATE_SETTLE_MS)")
    sc.end()
    sc.step("Cycle IGN and observe the belt status in the first frames")
    capture(sc, "init", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, "belt_init", start_only=True)
    sc.T("PS.Power_Cycle()")
    window = "NM_IGN_ON_STARTUP_DELAY_MS + dcs_fault_ms" if state == "faulty" else \
        "NM_IGN_ON_STARTUP_DELAY_MS + CANC_SEAT_BELT_INIT_WINDOW_MS"
    capture_stop(sc, "init", window)
    for prefix in ("psgr", "drv"):
        init_window_check(sc, f"{prefix}_init", f"{prefix}_key", f"{prefix}_reserved", f"{prefix}_{state}")
    sc.end()
    sc.notes.append("SRS1_20 (0x2C0) carries no seat-belt signal; the belt status is read in SRS1_FD_10.")


def mode_values(sc: Script):
    if "mode" in sc.flags:
        return
    sc.flags.add("mode")
    sc.S("""
        mode_active = MAH_CAN_SIGNAL_DEFS['SRS_OPERATION_MODE']['State_Values']['active']
        mode_inactive = MAH_CAN_SIGNAL_DEFS['SRS_OPERATION_MODE']['State_Values']['Non active']
    """)


def t_op_mode_default(sc: Script):
    mode_values(sc)
    ecu_precondition(sc, "hs")
    sc.step("Cycle IGN and observe SRS_OPERATION_MODE")
    ign_cycle(sc)
    check_signals(sc, "[('SRS1_20_SRS_OPERATION_MODE', mode_active)]")
    sc.end()


def t_op_mode_fault(sc: Script, kind: str, keys: list):
    margin_setup(sc)
    mode_values(sc)
    active_pairs = "[" + ", ".join(f"({k!r}, mode_active)" for k in keys) + "]"
    inactive_pairs = "[" + ", ".join(f"({k!r}, mode_inactive)" for k in keys) + "]"
    if kind == "vin":
        vin_setup(sc)
    if kind == "plant":
        plant_setup(sc)
    ecu_precondition(sc, "both")
    sc.step("SRS_OPERATION_MODE active with no fault")
    check_signals(sc, active_pairs)
    sc.end()
    titles = {"evt": "Inject the sensor fault", "vin": "Create a VIN mismatch", "plant": "Put the ECU in plant mode",
              "mcal": "Inject the system critical fault"}
    sc.step(titles[kind])
    if kind == "evt":
        evt_fault(sc)
    elif kind == "vin":
        vin_mismatch(sc)
        read_dtc(sc, "VIN mismatch DTC active after the IGN cycle with the wrong VIN", [("Vin_DTC_Code", "'DTC_active'")])
    elif kind == "plant":
        plant_enter(sc)
        sc.T("""
            Read_DTC("Plant mode DTC active",
                     " ".join([Read_DTC_Resp_CANC, PLANT_MODE_DTC['code'], PLANT_MODE_DTC['active_status']]),
                     Read_DTC_Req_CANC)
        """)
    else:
        operator_action(sc, "Inject the system critical fault (MCAL SPI TRANSMIT BUSY) in the ECU and keep it active.")
    check_signals(sc, inactive_pairs)
    sc.end()
    sc.step("Remove the fault")
    if kind == "evt":
        evt_restore(sc)
    elif kind == "vin":
        vin_restore(sc)
        read_dtc(sc, "VIN mismatch DTC historic after the IGN cycle with the project VIN", [("Vin_DTC_Code", HISTORIC)])
    elif kind == "plant":
        sc.T("""
            Wait(plant_window_ms)
            Read_DTC("Plant mode DTC healed",
                     " ".join([Read_DTC_Resp_CANC, PLANT_MODE_DTC['code'], PLANT_MODE_DTC['healed_status']]),
                     Read_DTC_Req_CANC)
        """)
    else:
        operator_action(sc, "Remove the system critical fault from the ECU.")
    check_signals(sc, active_pairs)
    sc.end()
    if kind == "mcal":
        sc.automation = "Semi-automatic (no shared-library call injects an internal MCAL fault)"
    sc.flags.add("needs_profile")


def t_crc_2c0(sc: Script):
    ecu_precondition(sc, "hs")
    sc.step("Cycle IGN and verify the CRC of every SRS1_20 frame")
    ign_cycle(sc)
    capture(sc, "crc", "[hs_id]", "[CAN_HS_CHANNEL_NAME]", "presence_window_ms", "srs1_20_crc")
    sc.T("""
        crc_bad = [frame_data.payload.hex(' ') for frame_data in crc_frames
                   if not validate_crc(bytes(frame_data.payload[SRS1_20_CRC_DATA_BYTES[0]:SRS1_20_CRC_DATA_BYTES[1]]),
                                       extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['SRSHS_CRC'],
                                                          MAH_CAN_SIGNAL_DEFS['SRSHS_CRC']['bit_length']),
                                       SRS1_20_CRC_ALGORITHM)]
        RESULT.InterpretEqualResultRange(f"{hs_frame} frames captured", len(crc_frames), CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        RESULT.InterpretEqualResult(f"{hs_frame} SRSHS_CRC is the CRC of bytes 0-6 in every frame", crc_bad[:5], [])
    """)
    sc.end()
    sc.notes.append("CRC-8/SAE-J1850 over bytes 0-6 (agent_sc3.md section 2.2, canc_config SRS1_20_CRC_*); confirm "
                    "no data ID or start value is folded in.")


def t_reserved_2c0(sc: Script):
    ecu_precondition(sc, "hs")
    sc.step("Cycle IGN and verify the reserved bits of every SRS1_20 frame")
    ign_cycle(sc)
    capture(sc, "reserved", "[hs_id]", "[CAN_HS_CHANNEL_NAME]", "presence_window_ms", "srs1_20_reserved")
    sc.T("""
        reserved_set = [(byte_index, f"0x{frame_data.payload[byte_index] & mask:02X}")
                        for frame_data in reserved_frames for byte_index, mask in SRS1_20_RESERVED_BIT_MASKS.items()
                        if frame_data.payload[byte_index] & mask]
        RESULT.InterpretEqualResultRange(f"{hs_frame} frames captured", len(reserved_frames), CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        RESULT.InterpretEqualResult(f"{hs_frame} reserved bits are 0 in every frame", reserved_set[:5], [])
    """)
    sc.end()


def t_diag_response(sc: Script):
    ecu_precondition(sc, "hs")
    sc.step("Cycle IGN and send 10 03 on 730")
    ign_cycle(sc)
    sc.T("RESULT.InterpretEqualResult('Response on 738', str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)), "
         "UDS_RESP_SESSION_EXTENDED)")
    sc.end()


IMU_KEYS = list(canc_config.CANC_IMU_SIGNALS)   # the IMU signals the ECU sends (canc_config)
IMU_MOVES = {
    "LATTERAL_ACCEL": "Move the ECU to and fro in the lateral direction",
    "LONG_ACCEL": "Move the ECU to and fro in the longitudinal direction",
    "YAW_RATE": "Rotate the ECU in the yaw direction (arc-shaped movement)",
    "X_AXIS_ANGULAR": "Tilt the ECU right and left about the X axis",
    "Y_AXIS_ANGULAR": "Tilt the ECU nose up and nose down about the Y axis",
    "Z_AXIS_ACCEL": "Move the ECU up and down",
}


def imu_physical(var: str, key_expr: str, rows_source: str) -> str:
    return f"""
        {var}_def = MAH_CAN_SIGNAL_DEFS[{key_expr}]
        {var}_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[{key_expr}],
                                                                 {var}_def['bit_length']),
                                              scaling={var}_def['Factor'], offset={var}_def['Offset'],
                                              bits={var}_def['bit_length'], signed=bool({var}_def.get('Signed'))), 4)
                        for frame_data in {rows_source} if frame_data.id == fd_id]
    """


def imu_static_check(sc: Script, key: str, var: str, label: str):
    capture(sc, var, "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", var)
    sc.T(imu_physical(var, py(key), f"{var}_frames"))
    sc.T(f"""
        RESULT.InterpretEqualResultRange(f"{{{var}_def['signal']}} {label} ({{{var}_def.get('UNIT') or 'physical'}})",
                                         {var}_values or [None],
                                         CANC_IMU_STATIC_EXPECTED[{key!r}] - CANC_IMU_STATIC_TOLERANCE[{key!r}],
                                         CANC_IMU_STATIC_EXPECTED[{key!r}] + CANC_IMU_STATIC_TOLERANCE[{key!r}])
    """)


def imu_motion_check(sc: Script, key: str, var: str):
    capture(sc, var, "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, var, start_only=True)
    operator_action(sc, f"{IMU_MOVES[key]} during the next {{CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f}} s.")
    capture_stop(sc, var, None)
    sc.T(imu_physical(var, py(key), f"{var}_frames"))
    sc.T(f"""
        RESULT.InterpretEqualResultRange(f"{{{var}_def['signal']}} follows the movement (swing, physical)",
                                         round(max({var}_values) - min({var}_values), 4) if {var}_values else None,
                                         CANC_IMU_MOTION_MIN_SWING[{key!r}], float('inf'))
    """)


def imu_note(sc: Script):
    sc.notes.append("The stationary value is graded against CANC_IMU_STATIC_EXPECTED +/- CANC_IMU_STATIC_TOLERANCE "
                    "and the movement against CANC_IMU_MOTION_MIN_SWING; the case gives no band, so these "
                    "canc_config values are assumptions to confirm.")


def t_imu(sc: Script, key: str, wake: bool):
    ecu_frames(sc)
    frames = wake_frames(sc) if wake else []
    ecu_precondition(sc, "fd", frames)
    sc.step(f"Verify {key} on a stationary ECU")
    imu_static_check(sc, key, "static", "on a stationary ECU")
    sc.end()
    if wake:
        sc.step("IGN OFF, then CAN wakeup (PKE_CLMP_STATE at its wake value)")
        can_wakeup(sc)
    else:
        sc.step("Cycle IGN")
        ign_cycle(sc)
    sc.end()
    sc.step(IMU_MOVES[key])
    imu_motion_check(sc, key, "motion")
    sc.end()
    sc.automation = "Semi-automatic (operator moves the ECU)"
    imu_note(sc)


def t_imu_temp(sc: Script):
    """The chamber setpoint of the case is canc_config CANC_IMU_TEMP_SETPOINTS_DEGC[<case name>]."""
    setpoint = canc_config.CANC_IMU_TEMP_SETPOINTS_DEGC[sc.case.name]
    ecu_frames(sc)
    ecu_precondition(sc, "fd")
    sc.step(f"Soak the ECU in the thermal chamber at {setpoint} degC and read IMU_TEMP")
    sc.S("chamber_setpoint_degc = CANC_IMU_TEMP_SETPOINTS_DEGC[tc_name]")
    operator_action(sc, f"Put the ECU in the thermal chamber at {setpoint} degC and let it soak.",
                    "CANC_THERMAL_SOAK_WINDOW_MS")
    capture(sc, "temperature", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_temp")
    sc.T(imu_physical("temperature", "'IMU_TEMP'", "temperature_frames"))
    sc.T("""
        RESULT.InterpretEqualResultRange("IMU_TEMP in the thermal chamber (degC)", temperature_values or [None],
                                         chamber_setpoint_degc - CANC_IMU_TEMP_TOLERANCE_DEGC,
                                         chamber_setpoint_degc + CANC_IMU_TEMP_TOLERANCE_DEGC)
    """)
    sc.end()
    sc.automation = "Manual environment (thermal chamber), automatic check"


def t_ign_sts_wake(sc: Script, sources: list):
    """IGN_STS_SRS in both frames for each wake source in turn: hw (IGN ON),
    nm (VCU NM active wakeup), pke (PKE clamp state), off (IGN OFF / NM stop)."""
    ign_values(sc)
    ecu_precondition(sc, "both", wake_frames(sc))
    sc.step("IGN OFF and no VCU NM / PKE wake request - the ECU frames stop")
    bus_sleep(sc)
    sc.end()
    keys = ["IGN_STS_SRS", "SRS1_20_IGN_STS_SRS"]
    # The ignition has priority over a CAN wake source (user instruction 2026-10-16): once
    # IGN is ON, adding the VCU NM or PKE source leaves "IGN ON due to HW".
    can_expected = "ign_can"
    for source in sources:
        if source == "hw":
            sc.step("Turn IGN ON")
            sc.T("""
                PS.IGN_ON()
                Wait(NM_IGN_ON_STARTUP_DELAY_MS)
            """)
            check_signals(sc, "[" + ", ".join(f"({k!r}, ign_hw)" for k in keys) + "]")
            presence(sc, "both", "present", "after_ign_on")
            can_expected = "ign_hw"
        elif source == "nm":
            sc.step("Start sending the VCU NM message")
            sc.T("""
                CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
                CAN.ChangeSignalValue(nm_def['bus'], CAN_NM_WAKEUP_FRAME, CAN_NM_WAKEUP_SIGNAL, str(CAN_NM_WAKEUP_VALUE))
                Wait(NM_IGN_ON_STARTUP_DELAY_MS)
            """)
            check_signals(sc, "[" + ", ".join(f"({k!r}, {can_expected})" for k in keys) + "]")
            presence(sc, "both", "present", "after_nm")
        elif source == "pke":
            sc.step("Send each PKE clamp state wake value (FR_ZONE2_100)")
            sc.T("for pke_value in CAN_PKE_WAKEUP_VALUES:")
            sc.extra += 4
            sc.T("""
                RESULT.InsertComment(f"{pke_def['signal']} = {pke_value}")
                CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(pke_value))
                Wait(NM_IGN_ON_STARTUP_DELAY_MS)
            """)
            check_signals(sc, "[" + ", ".join(f"({k!r}, {can_expected})" for k in keys) + "]")
            presence(sc, "both", "present", "after_pke")
            sc.extra -= 4
        elif source == "off":
            sc.step("Remove the wake source and observe IGN_STS_SRS")
            ign_off_observed(sc, keys, "ign_off")
            sc.T("Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)")
            presence(sc, "both", "absent", "after_off")
        sc.end()
    if "hw" in sources and ("nm" in sources or "pke" in sources):
        sc.notes.append("The case expects IGN_STS_SRS = 2 (IGN ON due to CAN wakeup) once the CAN wake source is "
                        "added with the hardware IGN already ON. The ignition has priority over a CAN wake source "
                        "(user instruction, 2026-10-16), so the script expects 1 (IGN ON due to HW), which is what "
                        "the ECU sent on 2026-10-15; the case text needs the same correction.")
    if "pke" in sources:
        sc.notes.append("Each PKE_CLMP_STATE wake value of CAN_PKE_WAKEUP_VALUES (1, 2, 3 and 4) is sent in turn.")


def t_dlc_13c(sc: Script):
    ecu_precondition(sc, "fd")
    for round_no in (1, 2):
        if round_no == 2:
            sc.step("Repeat after an IGN cycle")
            ign_cycle(sc)
        else:
            sc.step("Monitor consecutive SRS1_FD_10 frames")
        capture(sc, f"dlc{round_no}", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", f"srs1_fd_10_dlc_{round_no}")
        sc.T(f"""
            RESULT.InterpretEqualResultRange(f"{{fd_frame}} frames captured", len(dlc{round_no}_frames),
                                             CANC_FRAME_PRESENCE_CYCLES, float('inf'))
            RESULT.InterpretEqualResult(f"{{fd_frame}} DLC", sorted({{len(frame_data.payload) for frame_data in dlc{round_no}_frames}}),
                                        [CAN_RX_MESSAGE_CONFIG[fd_frame]['dlc']])
        """)
        sc.end()


REAR_ODS = ["STS_SEAT_ODS_SEC_ROW_LEFT", "STS_SEAT_ODS_SEC_ROW_MIDDLE", "STS_SEAT_ODS_SEC_ROW_RIGHT",
            "STS_SEAT_ODS_TRD_ROW_LEFT", "STS_SEAT_ODS_TRD_ROW_RIGHT"]
REAR_BELTS = ["STS_SEC_ROW_LEFT_BLT", "STS_SEC_ROW_MIDDLE_BLT", "STS_SEC_ROW_RIGHT_BLT",
              "STS_TRD_ROW_LEFT_BLT", "STS_TRD_ROW_RIGHT_BLT"]


def occupancy_setup(sc: Script):
    if "occupancy" in sc.flags:
        return
    sc.flags.add("occupancy")
    dcs_timing(sc)
    sc.S("""
        ods_loads = {'PRESENT': CANC_ODS_LOADS['PRESENT'], 'PRESENT_ADULT': CANC_ODS_LOADS['PRESENT_ADULT'],
                     'PRESENT_CHILD': CANC_ODS_LOADS['PRESENT_CHILD'], 'NOT_PRESENT': CANC_ODS_LOADS['NOT_PRESENT'],
                     'FAULTY': CANC_DCS_FAULT_LOAD}
        belt_loads = {'UNBUCKLED': DCS_Fault_Description['unbuckle'], 'BUCKLED': DCS_Fault_Description['buckle'],
                      'FAULTY': CANC_DCS_FAULT_LOAD}
    """)
    sc.C("""
        for ods_key in CANC_ODS_CHANNEL:
            SET_DCS_LOADS(CANC_ODS_LOADS['NOT_PRESENT'], ODSNumber[CANC_ODS_CHANNEL[ods_key]])
        for seat_belt_key in CANC_BELT_CHANNEL:
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], SLSNumber[CANC_BELT_CHANNEL[seat_belt_key]])
    """)


PSGR_UNOCCUPIED_NOTE = ("With the passenger seat unoccupied for the OCS (OCS_PASS_CLASS = EMPTY, no OCS fault), the "
                        "system requirement (Mahindra System Requirements M112/M312/Z121 V1.8, tables 1.7 and 1.9) "
                        "has STS_SEAT_BLT_PSGR sent as 1 (Buckled) whatever the buckle switch, and the ECU does so "
                        "(2026-10-15); the script expects that where the case gives 0x0.")


def psgr_belt_expected(state: str, ocs: dict) -> str:
    """STS_SEAT_BLT_PSGR label for a buckle state and the OCS input (requirement tables
    1.7 / 1.9: 'Don't care + Not Occupied -> Buckled'; an OCS fault reads as occupied,
    the on-fail value)."""
    if ocs.get("empty") and not ocs.get("fault"):
        return "Buckled"
    return {"UNBUCKLED": "UNBUCKLED", "BUCKLED": "Buckled", "FAULTY": "Buckle Faulty"}[state]


def occupancy_ocs_after(ocs: dict, settings: list) -> dict:
    """The OCS input once the settings are applied: empty seat and OCS fault flags."""
    ocs = dict(ocs)
    for kind, _, value in settings:
        if kind == "ocs_class":
            ocs["empty"] = value == 1 or "'EMPTY'" in str(value)
        elif kind == "ocs_fault":
            ocs["fault"] = value == 1 or "'Faulty'" in str(value)
    return ocs


OCS_SIGNALS = {"ocs_class": ("ocs_class_def", "OCS_PASS_CLASS"),
               "ocs_fault": ("ocs_fault_def", "OCS_PASS_CLASS_FAULT_STS"),
               "ocs_subseat": ("ocs_subseat_def", "OCS_SUBSEAT_CLASSIFICATION")}


def ocs_state(kind: str, raw: int) -> str:
    """An OCS raw value of the case table as its configuration state:
    <def>['State_Values'][<label>] (MAH_CAN_SIGNAL_DEFS)."""
    def_var, key = OCS_SIGNALS[kind]
    labels = [label for label, value in MAH[key]["State_Values"].items() if value == raw]
    if len(labels) != 1:
        raise ValueError(f"{key}: raw value {raw} has {len(labels)} State_Values labels")
    return f"{def_var}['State_Values'][{labels[0]!r}]"


def occupancy_apply(sc: Script, settings: list, label: str, ocs: dict | None = None, counts: bool = False):
    """settings: (kind, key, state): ods/belt with load states, ocs_class /
    ocs_fault / ocs_subseat with raw values. ocs: the OCS input before the settings
    (for the passenger belt status). counts: wait for the occupant counts to settle
    (CANC_OCCUPANT_COUNT_SETTLE_MS) rather than for the seat statuses alone."""
    ocs = occupancy_ocs_after(ocs or {}, settings)
    ods = [(k, s) for kind, k, s in settings if kind == "ods"]
    belts = [(k, s) for kind, k, s in settings if kind == "belt"]
    faulty = any(s == "FAULTY" for kind, _, s in settings if kind in ("ods", "belt"))
    lines = []
    if ods:
        lines.append("for ods_key, ods_state in [")
        lines += [f"    {item!r}," for item in ods]
        lines.append("]:")
        lines.append("    SET_DCS_LOADS(ods_loads[ods_state], ODSNumber[CANC_ODS_CHANNEL[ods_key]])")
    if belts:
        lines.append("for seat_belt_key, seat_belt_state in [")
        lines += [f"    {item!r}," for item in belts]
        lines.append("]:")
        lines.append("    SET_DCS_LOADS(belt_loads[seat_belt_state], SLSNumber[CANC_BELT_CHANNEL[seat_belt_key]])")
    if faulty:
        lines.append("PS.SetLeakageVBATBusHigh()")
    for kind, key, value in settings:
        if kind in ("ocs_class", "ocs_fault", "ocs_subseat"):
            def_var = {"ocs_class": "ocs_class_def", "ocs_fault": "ocs_fault_def", "ocs_subseat": "ocs_subseat_def"}[kind]
            if isinstance(value, int):
                value = ocs_state(kind, value)
            lines.append(f"CAN.ChangeSignalValue({def_var}['bus'], {def_var}['frame'],")
            lines.append(f"                      {def_var}['signal'], str({value}))")
    settle = "CANC_OCCUPANT_COUNT_SETTLE_MS" if counts else "max(CANC_DCS_STATE_SETTLE_MS, CANC_OCS_UPDATE_MS)"
    lines.append(f"Wait({settle}" + (" + dcs_fault_ms)" if faulty else ")"))
    sc.T("\n".join(lines))
    checks = []
    for kind, key, state in settings:
        if kind == "ods":
            label_ = {"PRESENT": "PRESENT", "PRESENT_ADULT": "PRESENT", "PRESENT_CHILD": "PRESENT",
                      "NOT_PRESENT": "NOT_PRESENT_DEFAULT", "FAULTY": "FAULTY"}[state]
            checks.append(f"({key!r}, MAH_CAN_SIGNAL_DEFS[{key!r}]['State_Values'][{label_!r}])")
        elif kind == "belt":
            expected = psgr_belt_expected(state, ocs) if key == PSGR_BELT else \
                {"UNBUCKLED": "UNBUCKLED", "BUCKLED": "Buckled", "FAULTY": "Buckle Faulty"}[state]
            if key == PSGR_BELT and expected == "Buckled" and state != "BUCKLED" and PSGR_UNOCCUPIED_NOTE not in sc.notes:
                sc.notes.append(PSGR_UNOCCUPIED_NOTE)
            if expected == "UNBUCKLED":
                checks.append(f"({key!r}, next(value for label, value in MAH_CAN_SIGNAL_DEFS[{key!r}]['State_Values'].items() "
                              f"if label.startswith('Not Buckled')))")
            else:
                checks.append(f"({key!r}, MAH_CAN_SIGNAL_DEFS[{key!r}]['State_Values'][{expected!r}])")
    if checks:
        check_signals(sc, "[" + ", ".join(checks) + "]", label)
    return ocs


def occupancy_baseline(sc: Script) -> dict:
    """Every rear seat not present, every belt unbuckled, no OCS fault, passenger empty.
    Returns the OCS input it leaves."""
    settings = [("ods", k, "NOT_PRESENT") for k in REAR_ODS] + \
               [("belt", k, "UNBUCKLED") for k in REAR_BELTS + ["STS_SEAT_BLT_PSGR", "STS_SEAT_BLT_DRV"]] + \
               [("ocs_fault", None, "ocs_fault_def['State_Values']['No_Fault']"),
                ("ocs_class", None, "ocs_class_def['State_Values']['EMPTY']")]
    sc.T("PS.ClearLeakageVBATBusHigh()")
    return occupancy_apply(sc, settings, "Baseline: ", counts=True)


def read_ecu_value(sc: Script, var: str, key: str):
    sc.T(f"""
        {var}_def = MAH_CAN_SIGNAL_DEFS[{key!r}]
        {var}_text = str(CAN.GetSignalFromFrame({var}_def['bus'], {var}_def['frame'], {var}_def['signal'])).strip()
        try:
            {var} = int({var}_text, 16) if {var}_text.lower().startswith("0x") else int(float({var}_text))
        except ValueError:
            {var} = None
    """)


def t_occupancy(sc: Script, variants: list, checks: list, note: str | None = None):
    """Occupant counts. variants: list of settings lists (one run each, from the
    baseline); checks: (signal key, ('abs', value) | ('delta', value))."""
    ecu_frames(sc)
    occupancy_setup(sc)
    ecu_precondition(sc, "fd")
    sc.step("Enable OCS in the variant code")
    ocs_enable(sc)
    sc.end()
    for index, settings in enumerate(variants, 1):
        sc.step("Set the baseline (rear seats not present, belts unbuckled, passenger empty)")
        ocs = occupancy_baseline(sc)
        for number, (key, (mode, _)) in enumerate(checks, 1):
            if mode == "delta":
                read_ecu_value(sc, f"baseline_{number}", key)
        sc.end()
        sc.step(f"Set the combination{f' {index}' if len(variants) > 1 else ''} and observe the counts")
        occupancy_apply(sc, settings, "Combination: ", ocs, counts=True)
        for number, (key, (mode, value)) in enumerate(checks, 1):
            read_ecu_value(sc, f"count_{number}", key)
            if mode == "abs":
                sc.T(f"RESULT.InterpretEqualResult({key!r}, str(count_{number}), str({value}))")
            else:
                sc.T("\n".join([
                    "RESULT.InterpretEqualResult(",
                    f"    '{key} change from the baseline',",
                    f"    str(None if count_{number} is None or baseline_{number} is None "
                    f"else count_{number} - baseline_{number}), str({value}))"]))
        sc.end()
    if note:
        sc.notes.append(note)
    sc.notes.append("OCS is enabled in the variant code for the case (the project default has the OCS node off); "
                    "fault_free_profile restores the default codes afterwards.")
    sc.notes.append("The seat statuses and counts are read CANC_OCCUPANT_COUNT_SETTLE_MS after the last seat change: on "
                    "2026-10-15 a rear seat (ODS present, belt buckled) showed in SRS_BKL_CNT 7.5 s after the change "
                    "and the counts the earlier scripts read after 1 s were still the old ones.")


def t_ods_states(sc: Script, key: str):
    ecu_frames(sc)
    occupancy_setup(sc)
    ecu_precondition(sc, "fd")
    for state, title in (("NOT_PRESENT", "Not present (above 400 ohm)"), ("PRESENT_ADULT", "Present (below 120 ohm)"),
                         ("FAULTY", "Faulty (short to battery)")):
        sc.step(f"{key}: {title}")
        if state == "FAULTY":
            occupancy_apply(sc, [("ods", key, "FAULTY")], "")
        else:
            sc.T("PS.ClearLeakageVBATBusHigh()")
            occupancy_apply(sc, [("ods", key, state)], "")
        sc.end()
    sc.notes.append("ODS loads from CANC_ODS_LOADS: 800R not present, 100R present (the case's 0-120 ohm band); a "
                    "faulty ODS is load CANC_DCS_FAULT_LOAD with Leakage VBAT Bus High.")


def t_ocs_psgr(sc: Script, variant: str):
    ecu_frames(sc)
    sc.S("""
        ocs_states = MAH_CAN_SIGNAL_DEFS['STS_SEAT_OCS_PSGR']['State_Values']
    """)
    ecu_precondition(sc, "fd")
    sc.step("Enable OCS in the variant code")
    ocs_enable(sc)
    sc.end()
    if variant == "present":
        sc.step("OCS_PASS_CLASS through every occupied class")
        sc.T("""
            for ocs_value in [value for label, value in ocs_class_def['State_Values'].items() if label != 'EMPTY']:
                CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'], ocs_class_def['signal'], str(ocs_value))
                Wait(CANC_OCS_UPDATE_MS)
                # OCS1_500 goes out every 500 ms and the ECU takes about 1 s more: read again
                # until the status follows or the start-up time has passed.
                ocs_started = time.monotonic()
                while True:
                    ocs_text = str(CAN.GetSignalFromFrame(MAH_CAN_SIGNAL_DEFS['STS_SEAT_OCS_PSGR']['bus'],
                                                          MAH_CAN_SIGNAL_DEFS['STS_SEAT_OCS_PSGR']['frame'],
                                                          MAH_CAN_SIGNAL_DEFS['STS_SEAT_OCS_PSGR']['signal'])).strip()
                    try:
                        ocs_seen = int(ocs_text, 16) if ocs_text.lower().startswith("0x") else int(float(ocs_text))
                    except ValueError:
                        ocs_seen = ocs_text
                    if str(ocs_seen) == str(ocs_states['PRESENT']) or time.monotonic() - ocs_started >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(f"STS_SEAT_OCS_PSGR with OCS_PASS_CLASS {ocs_value}", str(ocs_seen),
                                            str(ocs_states['PRESENT']))
        """)
        sc.end()
        sc.step("OCS_PASS_CLASS back to empty")
        set_bench_signal(sc, "ocs_class_def", "ocs_class_def['State_Values']['EMPTY']", "CANC_OCS_UPDATE_MS")
        check_signals(sc, "[('STS_SEAT_OCS_PSGR', ocs_states['NOT_PRESENT_DEFAULT'])]")
        sc.end()
    elif variant == "not_present":
        for title in ("OCS_PASS_CLASS = empty", "OCS_PASS_CLASS back to empty"):
            sc.step(title)
            set_bench_signal(sc, "ocs_class_def", "ocs_class_def['State_Values']['EMPTY']", "CANC_OCS_UPDATE_MS")
            check_signals(sc, "[('STS_SEAT_OCS_PSGR', ocs_states['NOT_PRESENT_DEFAULT'])]")
            sc.end()
    else:
        sc.step("Passenger empty, then OCS_PASS_CLASS_FAULT_STS = faulty")
        set_bench_signal(sc, "ocs_class_def", "ocs_class_def['State_Values']['EMPTY']", "CANC_OCS_UPDATE_MS")
        set_bench_signal(sc, "ocs_fault_def", "ocs_fault_def['State_Values']['Faulty']", "CANC_OCS_UPDATE_MS")
        check_signals(sc, "[('STS_SEAT_OCS_PSGR', ocs_states['FAULTY'])]")
        sc.end()
        sc.step("OCS_PASS_CLASS_FAULT_STS back to no fault")
        set_bench_signal(sc, "ocs_fault_def", "ocs_fault_def['State_Values']['No_Fault']", "CANC_OCS_UPDATE_MS")
        check_signals(sc, "[('STS_SEAT_OCS_PSGR', ocs_states['NOT_PRESENT_DEFAULT'])]")
        sc.end()
    sc.notes.append("The case calls 0x1 (EMPTY) the OCS_PASS_CLASS default; the DBC default is 0x0 "
                    "(PERCENTILE_50TH_ADULT_DEFAULT). The script uses EMPTY where the case means 'default'.")


def t_stps(sc: Script, key: str):
    ecu_frames(sc)
    dcs_timing(sc)
    sc.S(f"""
        stps_key = {key!r}
        stps_states = MAH_CAN_SIGNAL_DEFS[stps_key]['State_Values']
        stps_channels = [STPSNumber[name] for name in CANC_STPS_CHANNEL[stps_key]]
    """)
    sc.C("""
        for stps_channel in stps_channels:
            SET_DCS_LOADS(CANC_STPS_LOADS['ZONE_1'], stps_channel)
    """)
    ecu_precondition(sc, "fd")
    for zone, label in (("ZONE_2", "ZONE_2"), ("ZONE_1", "ZONE_1_DEFAULT")):
        sc.step(f"Set {key} to {zone.replace('_', ' ').lower()}")
        sc.T(f"""
            for stps_channel in stps_channels:
                SET_DCS_LOADS(CANC_STPS_LOADS[{zone!r}], stps_channel)
            Wait(CANC_DCS_STATE_SETTLE_MS)
        """)
        check_signals(sc, f"[(stps_key, stps_states[{label!r}])]")
        sc.end()
    sc.step(f"Set {key} to zone 3")
    sc.T("""
        RESULT.LogCustomAction("Zone 3 current for the seat track sensor", "A zone 3 load preset in CANC_STPS_LOADS",
                               "None available on the bench (bench note gives 6 mA and 14 mA only)", False)
    """)
    sc.end()
    sc.step(f"Make {key} faulty (short to battery)")
    sc.T("""
        for stps_channel in stps_channels:
            SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, stps_channel)
        PS.SetLeakageVBATBusHigh()
        Wait(dcs_fault_ms)
    """)
    check_signals(sc, "[(stps_key, stps_states['FAULTY'])]")
    sc.end()
    sc.automation = "Partly automatic (zone 3 current not available)"
    sc.notes.append("The case gives zone 2 = 12-17 mA and zone 1 = 5-6.9 mA; the bench note and the DCS seat-system "
                    "check give 6 mA -> zone 2 (0x0) and 14 mA -> zone 1 (0x1). The script uses CANC_STPS_LOADS "
                    "(bench) and the case's expected signal values.")


def t_deploy_status(sc: Script, crash: str):
    margin_setup(sc)
    crash_setup(sc, crash)
    direction = "lateral" if crash in ("left", "right") else "longitudinal"
    sc.S(f"""
        deployment_expected = CANC_DEPLOYMENT_STATUS_EXPECTED[{crash!r}]
        delta_v_element = CANC_EDR_MAX_DELTA_V_ELEMENT[{direction!r}]
        delta_v_def = MAH_CAN_SIGNAL_DEFS['SRS_DELTA_V']
    """)
    ecu_precondition(sc, "fd")
    sc.step(f"Create the {crash} crash")
    sc.T("load_crash_curves(crash_curve_key, project=PROJECT_NAME)")
    crash_trigger(sc, "crash", "[fd_id]", "[CAN_FD_CHANNEL_NAME]")
    crash_rows(sc, "crash", "fd_id", {"deploy": "SRS_DEPLOYEMENT_STS", "delta": "SRS_DELTA_V"}, "deploy_rows")
    sc.end()
    sc.step("Observe SRS_DEPLOYEMENT_STS")
    sc.T("""
        RESULT.InterpretEqualResult("SRS_DEPLOYEMENT_STS after the crash",
                                    f"0x{deploy_rows[-1]['deploy']:02X}" if deploy_rows else None,
                                    f"0x{deployment_expected:02X}")
    """)
    sc.end()
    sc.step("Observe and decode SRS_DELTA_V")
    sc.T("""
        delta_v_values = [round(raw_to_physical(row['delta'], scaling=delta_v_def['Factor'], offset=delta_v_def['Offset'],
                                                bits=delta_v_def['bit_length'], signed=bool(delta_v_def.get('Signed'))), 3)
                          for row in deploy_rows]
        delta_v_peak = max(delta_v_values, key=abs) if delta_v_values else None
        RESULT.InterpretEqualResultRange("SRS_DELTA_V within the database range (km/h)", delta_v_values or [None],
                                         delta_v_def['MIN'], delta_v_def['MAX'])
        # The shared EDR decoder needs EDR_DECODER_CONFIG in the project's edr_config;
        # without it the comparison is reported as not possible and the case goes on.
        try:
            crash_edr = read_edr_parameters([delta_v_element], return_data=True) or {}
        except Exception as edr_error:
            crash_edr = {}
            RESULT.LogCustomAction("EDR delta-V of the event read", "Decoded by read_edr_parameters",
                                   f"Not possible: {edr_error!r}", False)
        edr_delta_v = (crash_edr.get('decoded') or {}).get(delta_v_element)
        edr_delta_v = edr_delta_v[0] if isinstance(edr_delta_v, (list, tuple)) and edr_delta_v else edr_delta_v
        RESULT.InterpretEqualResultRange(
            f"SRS_DELTA_V peak {delta_v_peak} matches the recorded {delta_v_element} {edr_delta_v} (km/h difference)",
            abs(abs(delta_v_peak) - abs(edr_delta_v)) if isinstance(delta_v_peak, (int, float))
            and isinstance(edr_delta_v, (int, float)) else None, 0, CANC_DELTA_V_TOLERANCE_KMH)
    """)
    sc.end()
    sc.C("fault_free_profile()")
    sc.notes.append("'Matches the measured crash delta-V' is graded against the EDR maximum delta-V of the event "
                    "(CANC_EDR_MAX_DELTA_V_ELEMENT) within CANC_DELTA_V_TOLERANCE_KMH, an assumed band.")
    sc.notes.append("read_edr_parameters needs EDR_DECODER_CONFIG in the project's edr_config, which M310_M314_M110 does "
                    "not have (2026-10-15: AttributeError); until it is added the delta-V comparison step reports "
                    "'not possible' and the case fails on it, while the deployment status and range checks run.")


def t_ocs_mirror(sc: Script, source: str, target: str):
    ecu_frames(sc)
    ecu_precondition(sc, "fd")
    sc.step("Enable OCS in the variant code")
    ocs_enable(sc)
    sc.end()
    def_var = "ocs_class_def" if source == "OCS_PASS_CLASS" else "ocs_subseat_def"
    sc.step(f"Set {source} through every class and observe {target}")
    sc.T(f"""
        ocs_labels = {{value: label for label, value in {def_var}['State_Values'].items()}}
        for ocs_value in sorted(ocs_labels):
            ocs_label = ocs_labels[ocs_value]
            CAN.ChangeSignalValue({def_var}['bus'], {def_var}['frame'], {def_var}['signal'], str(ocs_value))
            Wait(CANC_OCS_UPDATE_MS)
            # Read again until the mirror follows or the start-up time has passed (OCS1_500
            # goes out every 500 ms and the ECU takes about 1 s more).
            mirror_started = time.monotonic()
            while True:
                mirror_text = str(CAN.GetSignalFromFrame(MAH_CAN_SIGNAL_DEFS[{target!r}]['bus'],
                                                         MAH_CAN_SIGNAL_DEFS[{target!r}]['frame'],
                                                         MAH_CAN_SIGNAL_DEFS[{target!r}]['signal'])).strip()
                try:
                    mirror_value = int(mirror_text, 16) if mirror_text.lower().startswith("0x") else int(float(mirror_text))
                except ValueError:
                    mirror_value = mirror_text
                if str(mirror_value) == str(ocs_value) or time.monotonic() - mirror_started >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{target} with {source} = {{ocs_label}}", str(mirror_value), str(ocs_value))
    """)
    sc.end()


def t_pab(sc: Script, mode: str, actions: list):
    """Automatic / semi-automatic PAB control. actions: ('switch', value label),
    ('ocs', class value, subseat value), ('padl', expected label),
    ('warn', expected label)."""
    ecu_frames(sc)
    sc.S("""
        switch_def = MAH_CAN_SIGNAL_DEFS['PSGR_AIRBAG_SW_IC']
        padl_states = MAH_CAN_SIGNAL_DEFS['INDC_PADL']['State_Values']
        warn_states = MAH_CAN_SIGNAL_DEFS['SRS_PAB_WARN_STS']['State_Values']
    """)
    sc.C("CAN.ReloadDefaultPeriodicFrame(switch_def['bus'], switch_def['frame'])")
    ecu_precondition(sc, "fd", [("switch_def['bus']", "switch_def['frame']")])
    pab_action = "enable" if mode == "automatic" else "disable"
    sc.step(f"Configure PAB control {mode} (EOL PAB_MODE) and enable OCS")
    sc.T(f"manage_eol_code('PAB_MODE', {pab_action!r}, project=PROJECT_NAME, base_from_project_default=True)")
    ocs_enable(sc)
    sc.end()
    for action in actions:
        if action[0] == "switch":
            sc.step(f"Set PSGR_AIRBAG_SW_IC = {action[1]}")
            set_bench_signal(sc, "switch_def", f"switch_def['State_Values'][{action[1]!r}]", "CANC_DCS_STATE_SETTLE_MS")
        elif action[0] == "ocs":
            sc.step(f"Set OCS_PASS_CLASS = {action[1]}, OCS_SUBSEAT_CLASSIFICATION = {action[2]}")
            set_bench_signal(sc, "ocs_class_def", ocs_state("ocs_class", action[1]))
            set_bench_signal(sc, "ocs_subseat_def", ocs_state("ocs_subseat", action[2]), "CANC_OCS_UPDATE_MS")
        elif action[0] == "padl":
            sc.step(f"Observe INDC_PADL ({action[1]})")
            check_signals(sc, f"[('INDC_PADL', padl_states[{action[1]!r}])]")
        elif action[0] == "warn":
            sc.step(f"Observe SRS_PAB_WARN_STS ({action[1]})")
            check_signals(sc, f"[('SRS_PAB_WARN_STS', warn_states[{action[1]!r}])]")
        sc.end()
    sc.notes.append("PAB control type is EOL byte 5 bit 5 (agent_sc3.md: 0 semi-automatic, 1 automatic), set with "
                    "manage_eol_code('PAB_MODE'); fault_free_profile restores the default EOL afterwards.")


def imu_valid_check(sc: Script, var: str, expect_invalid: bool, label: str):
    test = "==" if expect_invalid else "!="
    sc.T(f"""
        for imu_key in CANC_IMU_SIGNALS:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in {var}_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{{imu_key}} {label}",
                                        bool(imu_raw) and all(value {test} imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
    """)


def t_imu_fault(sc: Script):
    ecu_precondition(sc, "fd")
    sc.step("Inject the IMU sensor fault")
    operator_action(sc, "Inject the IMU sensor fault on the bench and keep it active.")
    capture(sc, "fault", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_fault")
    imu_valid_check(sc, "fault", True, "transmitted as the invalid value under the IMU fault")
    sc.end()
    sc.step("Remove the IMU fault and allow recovery")
    operator_action(sc, "Remove the IMU sensor fault.")
    ign_cycle(sc)
    capture(sc, "recovered", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_recovered")
    imu_valid_check(sc, "recovered", False, "no longer the invalid value after recovery")
    sc.end()
    sc.automation = "Semi-automatic (no IMU fault-injection method or EVT exists for the Panasonic IMU)"
    sc.flags.add("needs_profile")


def t_imu_states(sc: Script, ops: bool):
    ecu_precondition(sc, "fd", wake_frames(sc))
    sc.step("ECU off / idle - no IMU signal")
    sc.T("""
        PS.BATT_OFF()
        PS.IGN_OFF()
    """)
    presence(sc, "fd", "absent", "ecu_off")
    sc.end()
    sc.step("Power up: initialisation, proveout and run - IMU values valid")
    capture(sc, "startup", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, "imu_startup", start_only=True)
    sc.T("""
        PS.BATT_ON()
        PS.IGN_ON()
    """)
    capture_stop(sc, "startup", "NM_IGN_ON_STARTUP_DELAY_MS + CANC_LAMP_PROVEOUT_ON_MS + CANC_LAMP_PROVEOUT_OFF_MS")
    imu_valid_check(sc, "startup", False, "valid (not the invalid value) from start-up through proveout and run")
    sc.end()
    if ops:
        sc.step("Housekeeping (IGN OFF while SRS1_FD_10 is still sent) - IMU values valid")
        capture(sc, "housekeeping", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, "imu_housekeeping", start_only=True)
        sc.T("""
            PS.IGN_OFF()
            CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
            CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        """)
        capture_stop(sc, "housekeeping", "presence_window_ms")
        imu_valid_check(sc, "housekeeping", False, "valid while SRS1_FD_10 is sent after IGN OFF")
        sc.end()
    sc.step("IGN OFF until power down - no IMU signal")
    bus_sleep(sc)
    sc.end()
    sc.automation = "Automatic (ECU/OPS states approximated by supply transitions)"
    sc.notes.append("Standby, INIT and the OPS states cannot be commanded individually; the script steps the "
                    "supply (off, power-up with proveout and run, IGN OFF housekeeping, power down) and checks "
                    "the IMU values wherever SRS1_FD_10 is sent.")


def t_imu_low_power(sc: Script):
    dcs_timing(sc)
    belt_values(sc, "STS_SEAT_BLT_DRV", "drv")
    ecu_precondition(sc, "fd")
    sc.step("Normal mode - IMU values valid")
    capture(sc, "normal", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_normal")
    imu_valid_check(sc, "normal", False, "valid in normal mode")
    sc.end()
    sc.step("Force low-power mode")
    operator_action(sc, "Force the ECU into low-power mode (while SRS1_FD_10 is still transmitted).")
    capture(sc, "low_power", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_low_power")
    imu_valid_check(sc, "low_power", False, "valid in low-power mode")
    operator_action(sc, "Return the ECU to normal mode.")
    sc.end()
    sc.step("Create a short-to-battery fault on the driver belt (system critical fault)")
    sc.T("""
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, drv_channel)
        PS.SetLeakageVBATBusHigh()
        Wait(dcs_fault_ms)
        RESULT.LogAction("DTCs with the belt short to battery", CAN.SendDiagByValues(Read_DTC_Req_CANC))
    """)
    capture(sc, "critical", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_critical")
    imu_valid_check(sc, "critical", True, "transmitted as the invalid value under the system critical fault")
    sc.end()
    sc.step("Clear the fault and return to normal mode")
    sc.T("""
        PS.ClearLeakageVBATBusHigh()
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], drv_channel)
        Wait(dcs_heal_ms)
    """)
    ign_cycle(sc)
    capture(sc, "cleared", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", "presence_window_ms", "imu_cleared")
    imu_valid_check(sc, "cleared", False, "valid again after the fault is cleared")
    sc.end()
    sc.automation = "Semi-automatic (operator forces low-power mode)"
    sc.flags.add("needs_profile")


def t_imu_calibration(sc: Script):
    sc.S("""
        imu_routine = format_uds_bytes((ROUTINE_CONTROL_SID, START_ROUTINE_SUBFUNCTION,
                                        CANC_IMU_CALIBRATION_ROUTINE_ID >> 8, CANC_IMU_CALIBRATION_ROUTINE_ID & 0xFF))
        imu_routine_response = format_uds_bytes((ROUTINE_CONTROL_POSITIVE_SID, START_ROUTINE_SUBFUNCTION,
                                                 CANC_IMU_CALIBRATION_ROUTINE_ID >> 8, CANC_IMU_CALIBRATION_ROUTINE_ID & 0xFF))
    """)
    ecu_precondition(sc, "fd")
    for round_no in (1, 2):
        sc.step("Cycle IGN and record the IMU values in the initialisation window" + (" again" if round_no == 2 else ""))
        capture(sc, f"init{round_no}", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, f"imu_init_{round_no}", start_only=True)
        sc.T("PS.Power_Cycle()")
        capture_stop(sc, f"init{round_no}", "NM_IGN_ON_STARTUP_DELAY_MS")
        sc.T(f"""
            for imu_key in CANC_IMU_SIGNALS:
                imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
                imu_rows = [(frame_data.timestamp / 1000,
                             round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key],
                                                                      imu_def['bit_length']),
                                                   scaling=imu_def['Factor'], offset=imu_def['Offset'],
                                                   bits=imu_def['bit_length'], signed=bool(imu_def.get('Signed'))), 4))
                            for frame_data in init{round_no}_frames if frame_data.id == fd_id]
                imu_restart = max([index for index in range(1, len(imu_rows))
                                   if imu_rows[index][0] - imu_rows[index - 1][0] > CANC_GAP_FRAMES * fd_period_ms] or [0])
                RESULT.InterpretEqualResultRange(f"{{imu_key}} 0 or about 0 during the IMU initialisation",
                                                 [value for _, value in imu_rows[imu_restart:imu_restart + CANC_FRAME_PRESENCE_CYCLES]] or [None],
                                                 -CANC_IMU_STATIC_TOLERANCE[imu_key], CANC_IMU_STATIC_TOLERANCE[imu_key])
        """)
        sc.end()
        if round_no == 1:
            sc.step("Move the ECU mildly on each axis before the calibration routine")
            capture(sc, "motion", "[fd_id]", "[CAN_FD_CHANNEL_NAME]", None, "imu_motion", start_only=True)
            operator_action(sc, "Move the ECU mildly on each axis during the next "
                                "{CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.")
            capture_stop(sc, "motion", None)
            sc.T(f"""
                for imu_key in CANC_IMU_SIGNALS:
                    imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
                    imu_values = [raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key],
                                                                     imu_def['bit_length']),
                                                  scaling=imu_def['Factor'], offset=imu_def['Offset'],
                                                  bits=imu_def['bit_length'], signed=bool(imu_def.get('Signed')))
                                  for frame_data in motion_frames if frame_data.id == fd_id]
                    RESULT.InterpretEqualResultRange(f"{{imu_key}} follows the movement (swing, physical)",
                                                     round(max(imu_values) - min(imu_values), 4) if imu_values else None,
                                                     CANC_IMU_MOTION_MIN_SWING[imu_key], float('inf'))
            """)
            sc.end()
            sc.step("Start the IMU calibration routine with security level 1")
            sc.T("""
                enter_ext_session()
                Internal_Security_Access(0x01)
                RESULT.InterpretEqualResult("IMU calibration routine response", str(CAN.SendDiagByValues(imu_routine)),
                                            imu_routine_response)
            """)
            sc.end()
        sc.step("IMU values offset-corrected on a stationary ECU" + (" after the IGN cycle" if round_no == 2 else ""))
        for key in IMU_KEYS:
            imu_static_check(sc, key, f"corrected_{round_no}_{key.lower()}", "offset-corrected on a stationary ECU")
        sc.end()
    sc.automation = "Semi-automatic (operator moves the ECU)"
    sc.notes.append("The case expects '61 01 02 33'; the ISO 14229-1 positive response to 31 01 02 33 is "
                    "71 01 02 33, which the script expects.")
    imu_note(sc)
    sc.flags.add("needs_profile")


# ---------------------------------------------------------------------------
# Case tables for the 2C0 and 13C workbooks
# ---------------------------------------------------------------------------

def occ(kind, key, state):
    return (kind, key, state)


def rear(count: int, ods_state: str = "PRESENT") -> list:
    """The first `count` rear seats occupied and buckled (case order: SEC left,
    middle, right, TRD left, right)."""
    out = []
    for ods_key, belt_key in list(zip(REAR_ODS, REAR_BELTS))[:count]:
        out += [occ("ods", ods_key, ods_state), occ("belt", belt_key, "BUCKLED")]
    return out


def rear_order(keys: list, ods_state: str = "PRESENT_ADULT") -> list:
    out = []
    for name in keys:
        index = {"SEC_LEFT": 0, "SEC_MIDDLE": 1, "SEC_RIGHT": 2, "TRD_LEFT": 3, "TRD_RIGHT": 4}[name]
        out += [occ("ods", REAR_ODS[index], ods_state), occ("belt", REAR_BELTS[index], "BUCKLED")]
    return out


SEC_LEFT_ODS, SEC_LEFT_BELT = REAR_ODS[0], REAR_BELTS[0]
ECALL = "SRS_ECALL_OCC_BKL_CNT"


def ecall_delta(settings_variants, delta):
    return lambda sc: t_occupancy(sc, settings_variants, [(ECALL, ("delta", delta))])


def ecall_abs(settings, value, note=None):
    return lambda sc: t_occupancy(sc, [settings], [(ECALL, ("abs", value))], note)


def adult_bkl(settings, adult, bkl):
    return lambda sc: t_occupancy(sc, [settings], [("SRS_OCC_ODS_ADULT", ("abs", adult)), ("SRS_BKL_CNT", ("abs", bkl))])


def occ_cnt(settings, value):
    return lambda sc: t_occupancy(sc, [settings], [("SRS_OCC_CNT", ("abs", value))])


PSGR_BELT = "STS_SEAT_BLT_PSGR"
DRV_BELT = "STS_SEAT_BLT_DRV"
ADULT_CLASSES, CHILD_CLASSES = [0, 2, 3], [4, 5, 6, 7]

C2C0 = {
    1: lambda sc: t_proveout(sc, ["SRS1_20_INDC_SRS"], periodicity_dlc=True),
    2: lambda sc: t_plant_flash(sc, ["SRS1_20_INDC_SRS"]),
    3: lambda sc: t_lamp_faults(sc, ["SRS1_20_INDC_SRS"], did=False, last="voltage"),
    4: lambda sc: t_proveout(sc, ["SRS1_20_INDC_PADL"]),
    5: lambda sc: t_padl_switch(sc, ["SRS1_20_INDC_PADL"]),
    6: t_ign_sts_2c0,
    7: lambda sc: t_crash(sc, "front", {"hs_id": SRS1_20_CRASH}),
    8: lambda sc: t_crash(sc, "right", {"hs_id": SRS1_20_CRASH}),
    9: lambda sc: t_crash(sc, "left", {"hs_id": SRS1_20_CRASH}),
    10: lambda sc: t_crash(sc, "rear", {"hs_id": SRS1_20_CRASH}),
    11: lambda sc: t_crash_sequence(sc, [("front_left_right_rear", ["front", "left", "right", "rear"], None)],
                                    {"hs_id": SRS1_20_CRASH}, "Crashes within 800 ms"),
    12: lambda sc: t_near_crash(sc, hs_checks=True, edr=True),
    13: lambda sc: t_parity(sc, "SRS1_20_EVEN_PARITY_BIT", None),
    14: lambda sc: t_parity(sc, "SRS1_20_EVEN_PARITY_BIT", "loop"),
    15: lambda sc: t_parity(sc, "SRS1_20_EVEN_PARITY_BIT", "crash"),
    16: t_hs_alive_eol,
    17: lambda sc: t_alive_restart(sc, [("SRSHS_MSG_CNT", "enable")], "ign", "enable"),
    18: lambda sc: t_alive_restart(sc, [("SRSHS_MSG_CNT", "enable")], "batt", "enable"),
    19: lambda sc: t_alive_restart(sc, [("SRSHS_MSG_CNT", "enable")], "hard_reset", "enable"),
    20: lambda sc: t_alive_restart(sc, [("SRSHS_MSG_CNT", "enable")], "soft_reset", "enable"),
    21: lambda sc: t_alive_restart(sc, [("SRSHS_MSG_CNT", "enable")], "busoff", "enable"),
    22: lambda sc: t_belt_states(sc, PSGR_BELT, init_check=False, on_2c0=True),
    23: lambda sc: t_belt_states(sc, DRV_BELT, init_check=False, on_2c0=True),
    24: lambda sc: t_belt_init(sc, "unbuckled"),
    25: lambda sc: t_belt_init(sc, "buckled"),
    26: lambda sc: t_belt_init(sc, "faulty"),
    27: t_op_mode_default,
    28: lambda sc: t_op_mode_fault(sc, "evt", ["SRS1_20_SRS_OPERATION_MODE"]),
    29: lambda sc: t_op_mode_fault(sc, "vin", ["SRS1_20_SRS_OPERATION_MODE"]),
    30: lambda sc: t_op_mode_fault(sc, "plant", ["SRS1_20_SRS_OPERATION_MODE"]),
    31: lambda sc: t_op_mode_fault(sc, "mcal", ["SRS1_20_SRS_OPERATION_MODE"]),
    32: t_crc_2c0,
    33: t_reserved_2c0,
    34: t_diag_response,
}

BOTH_CRASH = {"fd_id": FD_CRASH, "hs_id": HS_CRASH}
ROLL_CRASH = {"fd_id": dict(FD_CRASH, roll="STS_FIRST_CRASH_ROLL")}

C13C = {
    23: t_imu_temp, 24: t_imu_temp, 25: t_imu_temp,
    26: lambda sc: (t_imu_temp(sc), sc.notes.append(
        "The case sets the chamber to -20 degC and expects 20 degC; the script expects the setpoint.")),
    27: t_imu_temp,
    13: lambda sc: t_belt_states(sc, PSGR_BELT, True, False),
    14: lambda sc: t_belt_states(sc, DRV_BELT, True, False),
    15: lambda sc: t_belt_states(sc, "STS_SEC_ROW_RIGHT_BLT", True, False),
    16: lambda sc: t_belt_states(sc, "STS_SEC_ROW_MIDDLE_BLT", True, False),
    17: lambda sc: t_belt_states(sc, "STS_SEC_ROW_LEFT_BLT", True, False),
    18: lambda sc: t_belt_states(sc, "STS_TRD_ROW_RIGHT_BLT", True, False),
    19: lambda sc: t_belt_states(sc, "STS_TRD_ROW_LEFT_BLT", True, False),
    20: lambda sc: t_near_crash(sc),
    21: t_near_crash_manual,
    22: lambda sc: t_near_crash(sc, wake=True),
    28: lambda sc: t_proveout(sc, ["INDC_SRS", "SRS1_20_INDC_SRS"]),
    29: lambda sc: t_plant_flash(sc, ["INDC_SRS", "SRS1_20_INDC_SRS"]),
    30: lambda sc: t_lamp_faults(sc, ["INDC_SRS", "SRS1_20_INDC_SRS"], did=True, last="vc"),
    31: lambda sc: t_proveout(sc, ["INDC_SRS", "SRS1_20_INDC_SRS"], wake=True),
    32: lambda sc: t_proveout(sc, ["INDC_PADL", "SRS1_20_INDC_PADL"], wake_after=True),
    33: lambda sc: t_padl_switch(sc, ["INDC_PADL", "SRS1_20_INDC_PADL"]),
    34: lambda sc: t_crash(sc, "front", BOTH_CRASH),
    35: lambda sc: t_crash(sc, "right", BOTH_CRASH),
    36: lambda sc: t_crash(sc, "rear", BOTH_CRASH),
    37: lambda sc: t_crash(sc, "left", BOTH_CRASH),
    38: lambda sc: t_crash(sc, "underbody", BOTH_CRASH),
    39: lambda sc: t_crash(sc, "front", BOTH_CRASH, wake=True),
    40: lambda sc: t_crash(sc, "right", BOTH_CRASH, wake=True),
    41: lambda sc: t_crash(sc, "rear", BOTH_CRASH, wake=True),
    42: lambda sc: t_crash(sc, "left", BOTH_CRASH, wake=True),
    43: lambda sc: t_crash(sc, "underbody", BOTH_CRASH, wake=True),
    44: lambda sc: t_op_mode_fault(sc, "vin", ["SRS_OPERATION_MODE", "SRS1_20_SRS_OPERATION_MODE"]),
    45: lambda sc: t_op_mode_fault(sc, "plant", ["SRS_OPERATION_MODE", "SRS1_20_SRS_OPERATION_MODE"]),
    46: lambda sc: t_op_mode_fault(sc, "evt", ["SRS_OPERATION_MODE", "SRS1_20_SRS_OPERATION_MODE"]),
    47: lambda sc: t_ign_sts_wake(sc, ["hw", "off"]),
    48: lambda sc: t_ign_sts_wake(sc, ["nm", "off"]),
    49: lambda sc: t_ign_sts_wake(sc, ["hw", "nm"]),
    50: lambda sc: t_ign_sts_wake(sc, ["hw", "pke"]),
    51: lambda sc: t_parity(sc, "EVEN_PARITY_BIT", None),
    52: lambda sc: t_parity(sc, "EVEN_PARITY_BIT", "loop"),
    53: lambda sc: t_parity(sc, "EVEN_PARITY_BIT", "crash"),
    54: lambda sc: t_alive_restart(sc, [("SRS_MSG_CNT", None), ("SRSHS_MSG_CNT", "default")], "ign", None),
    55: lambda sc: t_alive_restart(sc, [("SRS_MSG_CNT", None), ("SRSHS_MSG_CNT", "default")], "can_wake_cycle", None),
    56: lambda sc: t_alive_restart(sc, [("SRS_MSG_CNT", None), ("SRSHS_MSG_CNT", "default")], "hard_reset", None),
    57: lambda sc: t_alive_restart(sc, [("SRS_MSG_CNT", None), ("SRSHS_MSG_CNT", "default")], "hard_reset_in_wake", None),
    58: t_dlc_13c,
    59: lambda sc: t_crash(sc, "rollover", BOTH_CRASH),
    60: lambda sc: t_no_crash_update(sc, "pt_only"),
    61: lambda sc: t_crash_sequence(sc, [("rear_then_front", ["front"], None), ("underbody_then_left", ["left"], None),
                                         ("rollover_then_right", ["right"], None)], BOTH_CRASH, "Multi-event"),
    62: ecall_delta([[occ("ods", SEC_LEFT_ODS, "PRESENT"), occ("belt", SEC_LEFT_BELT, "BUCKLED")]], 1),
    63: ecall_delta([[occ("ods", SEC_LEFT_ODS, "PRESENT"), occ("belt", SEC_LEFT_BELT, "UNBUCKLED")]], 1),
    64: ecall_delta([[occ("ods", SEC_LEFT_ODS, "PRESENT"), occ("belt", SEC_LEFT_BELT, "FAULTY")]], 1),
    65: ecall_delta([[occ("ods", SEC_LEFT_ODS, "NOT_PRESENT"), occ("belt", SEC_LEFT_BELT, "BUCKLED")]], 1),
    66: ecall_delta([[occ("ods", SEC_LEFT_ODS, "NOT_PRESENT"), occ("belt", SEC_LEFT_BELT, "UNBUCKLED")]], 0),
    67: ecall_delta([[occ("ods", SEC_LEFT_ODS, "FAULTY"), occ("belt", SEC_LEFT_BELT, "UNBUCKLED")]], 1),
    68: ecall_delta([[occ("belt", PSGR_BELT, "BUCKLED"), occ("ocs_class", None, c)] for c in ADULT_CLASSES], 1),
    69: ecall_delta([[occ("belt", PSGR_BELT, "UNBUCKLED"), occ("ocs_class", None, c)] for c in CHILD_CLASSES], 1),
    70: ecall_delta([[occ("belt", PSGR_BELT, "FAULTY"), occ("ocs_class", None, c)] for c in ADULT_CLASSES + CHILD_CLASSES], 1),
    71: ecall_delta([[occ("belt", PSGR_BELT, "BUCKLED"), occ("ocs_class", None, 1)]], 1),
    72: ecall_delta([[occ("belt", PSGR_BELT, "UNBUCKLED"), occ("ocs_class", None, 1)]], 0),
    73: ecall_delta([[occ("belt", PSGR_BELT, "BUCKLED"), occ("ocs_fault", None, 1)]], 1),
    74: ecall_delta([[occ("belt", PSGR_BELT, state), occ("ocs_fault", None, 1)] for state in ("UNBUCKLED", "FAULTY")], 0),
    75: ecall_abs([], 0),
    76: ecall_abs(rear(1), 1),
    77: ecall_abs(rear(2), 2),
    78: ecall_abs(rear(3), 3),
    79: ecall_abs(rear(4), 4),
    80: ecall_abs(rear(5), 5),
    81: ecall_abs(rear(5) + [occ("ocs_class", None, 0), occ("belt", PSGR_BELT, "BUCKLED")], 6),
    82: ecall_abs(rear(5) + [occ("ocs_class", None, 0), occ("belt", PSGR_BELT, "BUCKLED")], 7,
                  "Case 82 repeats case 81's seat combination but expects 0x7, which the DBC defines as RESERVED "
                  "(0x6 = seven occupants); the script follows the case as written - confirm the intended combination."),
    83: lambda sc: t_ods_states(sc, "STS_SEAT_ODS_TRD_ROW_RIGHT"),
    84: lambda sc: t_ods_states(sc, "STS_SEAT_ODS_SEC_ROW_LEFT"),
    85: lambda sc: t_ods_states(sc, "STS_SEAT_ODS_SEC_ROW_RIGHT"),
    86: lambda sc: t_ods_states(sc, "STS_SEAT_ODS_SEC_ROW_MIDDLE"),
    87: lambda sc: t_ods_states(sc, "STS_SEAT_ODS_TRD_ROW_LEFT"),
    88: lambda sc: t_ocs_psgr(sc, "present"),
    89: lambda sc: t_ocs_psgr(sc, "not_present"),
    90: lambda sc: t_ocs_psgr(sc, "faulty"),
    91: lambda sc: t_stps(sc, "SRS_STPS_ZONE_FR"),
    92: lambda sc: t_stps(sc, "SRS_STPS_ZONE_FL"),
    93: lambda sc: t_crash_sequence(sc, [
        ("front_then_rollover", ["front"], "ROLLOVER_NOT_FIRST_CRASH_DEFAULT"), ("rollover", ["rollover"], "ROLLOVER_IS_FIRST_CRASH"),
        ("left_then_rollover", ["left"], "ROLLOVER_NOT_FIRST_CRASH_DEFAULT"), ("rollover", ["rollover"], "ROLLOVER_IS_FIRST_CRASH"),
        ("right_then_rollover", ["right"], "ROLLOVER_NOT_FIRST_CRASH_DEFAULT"), ("rollover", ["rollover"], "ROLLOVER_IS_FIRST_CRASH"),
        ("rear_then_rollover", ["rear"], "ROLLOVER_NOT_FIRST_CRASH_DEFAULT"), ("rollover", ["rollover"], "ROLLOVER_IS_FIRST_CRASH"),
        ("underbody_then_rollover", ["underbody"], "ROLLOVER_NOT_FIRST_CRASH_DEFAULT"), ("rollover", ["rollover"], "ROLLOVER_IS_FIRST_CRASH"),
    ], ROLL_CRASH, "First crash rollover"),
    100: lambda sc: t_ocs_mirror(sc, "OCS_PASS_CLASS", "SRS_OCS_PER_CLASSIFICATION"),
    101: lambda sc: t_ocs_mirror(sc, "OCS_SUBSEAT_CLASSIFICATION", "SRS_OCS_SUBSEAT_CLASSIFICATION"),
    102: adult_bkl([], 0, 0),
    103: adult_bkl(rear_order(["SEC_LEFT"]), 0, 1),
    104: adult_bkl(rear_order(["SEC_LEFT", "SEC_RIGHT"]), 1, 2),
    105: adult_bkl(rear_order(["SEC_LEFT", "SEC_RIGHT", "SEC_MIDDLE"]), 2, 3),
    106: adult_bkl(rear_order(["SEC_LEFT", "SEC_RIGHT", "SEC_MIDDLE", "TRD_LEFT"]), 3, 4),
    107: adult_bkl(rear_order(["SEC_LEFT", "SEC_RIGHT", "SEC_MIDDLE", "TRD_LEFT", "TRD_RIGHT"]), 4, 5),
    108: adult_bkl(rear_order(["SEC_LEFT", "SEC_RIGHT", "SEC_MIDDLE", "TRD_LEFT", "TRD_RIGHT"])
                   + [occ("belt", PSGR_BELT, "BUCKLED"), occ("ocs_class", None, 0)], 5, 6),
    109: adult_bkl(rear_order(["SEC_LEFT", "SEC_RIGHT", "SEC_MIDDLE", "TRD_LEFT", "TRD_RIGHT"])
                   + [occ("belt", PSGR_BELT, "BUCKLED"), occ("belt", DRV_BELT, "BUCKLED"), occ("ocs_class", None, 0)], 6, 7),
    110: adult_bkl([occ("ods", SEC_LEFT_ODS, "NOT_PRESENT"), occ("belt", SEC_LEFT_BELT, "BUCKLED")], 0, 0),
    111: adult_bkl([occ("ods", SEC_LEFT_ODS, "FAULTY"), occ("belt", SEC_LEFT_BELT, "BUCKLED")], 0, 0),
    112: adult_bkl([occ("belt", PSGR_BELT, "BUCKLED"), occ("ocs_class", None, 4)], 0, 0),
    113: occ_cnt([occ("ods", SEC_LEFT_ODS, "PRESENT")], 1),
    114: occ_cnt([occ("ods", SEC_LEFT_ODS, "PRESENT_CHILD")], 1),
    115: occ_cnt([occ("ods", SEC_LEFT_ODS, "FAULTY")], 1),
    116: occ_cnt([occ("ods", SEC_LEFT_ODS, "NOT_PRESENT")], 0),
    117: occ_cnt([occ("ocs_class", None, 0)], 1),
    118: occ_cnt([occ("ocs_class", None, 2)], 1),
    119: occ_cnt([occ("ocs_class", None, 3)], 1),
    120: occ_cnt([occ("ocs_class", None, 1)], 0),
    121: occ_cnt([occ("ocs_class", None, 4)], 1),
    122: occ_cnt([occ("ocs_class", None, 5)], 1),
    123: occ_cnt([occ("ocs_class", None, 6)], 1),
    124: occ_cnt([occ("ocs_class", None, 7)], 1),
    125: lambda sc: t_pab(sc, "automatic", [("switch", "PAB OFF"), ("padl", "Lamp ON"), ("ocs", 0, 0), ("padl", "Lamp OFF/Default")]),
    126: lambda sc: t_pab(sc, "automatic", [("switch", "PAB ON / Default"), ("padl", "Lamp OFF/Default"), ("ocs", 4, 2),
                                            ("padl", "Lamp ON")]),
    127: lambda sc: t_pab(sc, "automatic", [("switch", "PAB OFF"), ("padl", "Lamp ON"), ("ocs", 7, 0), ("padl", "Lamp OFF/Default")]),
    128: lambda sc: t_pab(sc, "automatic", [("switch", "PAB OFF"), ("padl", "Lamp ON"), ("ocs", 1, 0), ("padl", "Lamp ON")]),
    129: lambda sc: t_pab(sc, "semi-automatic", [("switch", "PAB OFF"), ("padl", "Lamp ON"), ("ocs", 0, 0),
                                                 ("warn", "PAB_ON_WARNING"), ("switch", "PAB ON / Default"),
                                                 ("padl", "Lamp OFF/Default"), ("ocs", 0, 0), ("warn", "DEFAULT"),
                                                 ("padl", "Lamp OFF/Default")]),
    130: lambda sc: t_pab(sc, "semi-automatic", [("switch", "PAB ON / Default"), ("padl", "Lamp OFF/Default"), ("ocs", 4, 0),
                                                 ("warn", "PAB_OFF_WARNING"), ("padl", "Lamp OFF/Default")]),
    131: t_imu_fault,
    132: lambda sc: t_imu_states(sc, False),
    133: lambda sc: t_imu_states(sc, True),
    134: t_imu_low_power,
    135: t_imu_calibration,
}

for _number, _key in enumerate(IMU_KEYS, 1):
    C13C[_number] = (lambda key: lambda sc: t_imu(sc, key, False))(_key)
    C13C[_number + 6] = (lambda key: lambda sc: t_imu(sc, key, True))(_key)
for _number, _crash in zip(range(94, 100), ("front", "left", "right", "rear", "underbody", "rollover")):
    C13C[_number] = (lambda crash: lambda sc: t_deploy_status(sc, crash))(_crash)

OTHER_TABLES = {
    "BussOff_TestCases.xlsx": (r"CAN_BUSOFF_(\d+)$", BUSOFF_CASES),
    "Diagnostic_ID_TestCases.xlsx": (r"Testcase(\d+)$", DIAG_CASES),
    "M314 CANC 2C0 signal and message spec test cases.xlsx": (r"TestCase_(\d+)$", C2C0),
    "M314 CANC 13C signal and message spec test cases.xlsx": (r"TestCase_(\d+)$", C13C),
}


def build_other_case(sc: Script):
    pattern, table = OTHER_TABLES[sc.case.workbook]
    match = re.search(pattern, sc.case.name)
    assert match, f"{sc.case.name}: no case number"
    number = int(match.group(1))
    table[number](sc)
    if "needs_profile" in sc.flags and "fault_free_profile()" not in "\n".join(sc.cleanup):
        sc.C("fault_free_profile()")


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

# No generated-file marker or rebuild line in the scripts (user request, 2026-10-16).
HEADER = '''\
# Author: Kris
#
'''

PRELUDE = '''\
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
'''


def wrap_comment(label: str, text: str) -> list[str]:
    prefix = f"# {label:<11}: "
    lines = textwrap.wrap(text, width=96 - len(prefix)) or [""]
    out = [prefix + lines[0]]
    out += ["# " + " " * 13 + line for line in lines[1:]]
    return out


_CONFIG_NAMES: dict[str, set] = {}


def config_names(module: str) -> set:
    if module not in _CONFIG_NAMES:
        import importlib
        mod = importlib.import_module(f"{CONFIG_PACKAGE}.{module}")
        _CONFIG_NAMES[module] = {n for n in dir(mod) if not n.startswith("_")}
    return _CONFIG_NAMES[module]


def prune_setup(sc: Script, body_text: str) -> bool:
    """Drop the setup assignments run_test never reads, with the comment lines right
    above them: the shared setup blocks (common_setup, fault_timing, ...) give every
    name a template might need. Returns whether anything was dropped."""
    tree = ast.parse(body_text)
    loaded = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
    setup_tree = ast.parse(textwrap.dedent("\n".join(sc.setup)))
    drop = set()
    for stmt in setup_tree.body:
        if (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name)
                and stmt.targets[0].id not in loaded):
            first = stmt.lineno - 1
            while first > 0 and sc.setup[first - 1].strip().startswith("#"):
                first -= 1
            drop.update(range(first, stmt.end_lineno or stmt.lineno))
    sc.setup = [line for index, line in enumerate(sc.setup) if index not in drop]
    return bool(drop)


def render(sc: Script) -> str:
    while True:
        text, body_text = _render(sc)
        if not prune_setup(sc, body_text):
            return text


def _render(sc: Script) -> tuple[str, str]:
    case = sc.case
    body: list[str] = []
    body.append("def run_test():")
    body.append(f"    tc_id = {py(case.case_id)}")
    body.append(f"    tc_name = {py(case.name)}")
    desc_lines = textwrap.wrap(case.description, width=84) or [""]
    body.append("    tc_desc = (")
    for i, line in enumerate(desc_lines):
        tail = " " if i < len(desc_lines) - 1 else ""
        body.append(f"        {py(line + tail)}")
    body.append("    )")
    body.append(f"    automation = {py(sc.automation)}")
    body.append("")
    body.extend(sc.setup)
    body.append("")
    defs = ", ".join(dict.fromkeys(sc.log_defs))
    ids = ", ".join(dict.fromkeys(sc.log_ids))
    log_call = f"resolve_can_log_ids([{defs}]" + (f", [{ids}])" if ids else ")")
    body.append("    test_case_file = os.path.splitext(os.path.basename(__file__))[0]")
    body.append("    report_path, log_path = create_report_and_logging(")
    body.append(f"        test_case_file, can_ids={log_call}, tc_desc=tc_desc)")
    body.append('    aria_reports.add_report_info("#Test Case ID:", tc_id)')
    body.append('    aria_reports.add_report_info("#Test Case Name:", tc_name)')
    body.append('    aria_reports.add_report_info("#Automation:", automation)')
    body.append("")
    body.append("    try:")
    if sc.required:
        body.append("        missing = [label for label, value in (")
        for label, value in sc.required:
            body.append(f"            ({label}, {value}),")
        body.append("        ) if value is None]")
        body.append("        if missing:")
        body.append("            RESULT.LogCustomAction(")
        body.append('                "Configuration the case needs", "Present in the M310_M314_M110 configuration",')
        body.append('                "Missing: " + ", ".join(missing), False)')
        body.append("            return")
        body.append("")
    body.extend(sc.steps)
    body.append("    except Exception as raised:")
    body.append('        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)')
    body.append("    finally:")
    body.append("        try:")
    if sc.cleanup:
        body.extend(sc.cleanup)
    else:
        body.append("            pass")
    body.append("        finally:")
    body.append("            aria_reports.write_to_file()")
    body.append("")
    body.append("")
    body.append('if __name__ == "__main__":')
    body.append("    run_test()")
    body_text = "\n".join(body) + "\n"

    # Imports: each configuration name the body uses, from the module defining it.
    # The few framework constants in SHARED_PREFERRED come from the shared library
    # even where a configuration module repeats them.
    tree = ast.parse(body_text)
    loaded = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
    stored = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and not isinstance(n.ctx, ast.Load)}
    used = loaded - stored - SHARED_PREFERRED
    imports = []
    taken = set()
    for module in CONFIG_MODULES:
        names = sorted((used & config_names(module)) - taken - {"MODULE_NAME", "ENABLED"})
        if names:
            taken |= set(names)
            imports.append(f"from {CONFIG_PACKAGE}.{module} import (")
            imports += [f"    {name}," for name in names]
            imports.append(")")

    header = HEADER.splitlines()
    header += wrap_comment("Test case", f"{case.name} (Codebeamer ID {case.case_id})" if case.case_id
                           else f"{case.name} (additional check, not a workbook case)")
    if case.workbook:
        header += wrap_comment("Workbook", case.workbook)
    header += wrap_comment("Objective", case.description)
    header += wrap_comment("Automation", sc.automation)
    for note in sc.notes:
        header += wrap_comment("Note", note)
    return "\n".join(header) + "\n\n" + PRELUDE + "\n".join(imports) + "\n\n\n" + body_text, body_text


# ---------------------------------------------------------------------------
# Static check of a generated script
# ---------------------------------------------------------------------------

_SHARED_NAMES: set | None = None

# Framework constants a script takes from the shared library even where a
# configuration module repeats the name.
SHARED_PREFERRED = {"DTC_status", "Read_DTC_Req_CANC", "Read_DTC_Resp_CANC", "Over_Voltage", "Under_Voltage",
                    "VIN_STRATEGY_OPTIONS", "VIN_STRATEGY_KEY", "VARIANT_CODE_DID", "READ_SID", "WRITE_SID",
                    "Variant_Code_DTC", "Vin_DTC_Code", "Crash_DTC", "PT_Crash_DTC", "EOL_DID"}


def shared_names() -> set:
    """Every name `from shared_libraries.import_list import *` gives a script."""
    global _SHARED_NAMES
    if _SHARED_NAMES is None:
        import os
        os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "M310_M314_M110")
        namespace: dict = {}
        exec("from Framework_IOEM_Py.shared_libraries.import_list import *", namespace)
        _SHARED_NAMES = {n for n in namespace if not n.startswith("__")}
    return _SHARED_NAMES


def check_script(name: str, source: str) -> list[str]:
    """Problems found in a generated script: syntax, helper functions, names that
    resolve to nothing."""
    problems = []
    tree = ast.parse(source, filename=name)
    functions = [n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    if functions != ["run_test"] or any(isinstance(n, ast.Lambda) for n in ast.walk(tree)):
        problems.append(f"functions defined: {functions}")
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and not any(a.name == "*" for a in node.names):
            imported |= {a.asname or a.name for a in node.names}
        elif isinstance(node, ast.Import):
            imported |= {(a.asname or a.name).split(".")[0] for a in node.names}
    assigned = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            assigned.add(node.id)
        elif isinstance(node, ast.arg):
            assigned.add(node.arg)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            assigned.add(node.name)
        elif isinstance(node, (ast.FunctionDef,)):
            assigned.add(node.name)
    known = imported | assigned | set(dir(builtins)) | shared_names() | {"__file__", "__name__"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load) and node.id not in known:
            problems.append(f"unresolved name {node.id} (line {node.lineno})")
    return sorted(set(problems))


# ---------------------------------------------------------------------------
# Additional check: the CRC of every frame with a CRC signal
# ---------------------------------------------------------------------------

CRC_CHECK_CASE = Case(
    name="CANC_CRC_Check_All_Messages", case_id="",
    description="Verify that the CRC signal of every CAN-C frame that carries one, sent by the ECU or simulated "
                "by the bench, is the CRC in use computed over the bytes canc_config gives for that frame.",
    pre="", steps=[], workbook="", suite="CRC")


def build_crc_check() -> Script:
    """The CRC of every frame with a CRC signal against the CRC in use: a name
    from CANC_CRC_CATALOGUE given on the command line, else CANC_CRC_IN_USE."""
    sc = Script(CRC_CHECK_CASE)
    common_setup(sc)
    sc.S("""
        crc_in_use = {}
        crc_unknown = []
        for crc_request in list(CANC_CRC_IN_USE.values()) + sys.argv[1:]:
            crc_request_key = str(crc_request).strip().upper().replace('_', '-').replace(' ', '-')
            crc_name = next((name for name, spec in CANC_CRC_CATALOGUE.items()
                             if crc_request_key in [label.upper().replace('_', '-').replace(' ', '-')
                                                    for label in (name,) + tuple(spec['aliases'])]), None)
            if crc_name is None:
                crc_unknown.append(str(crc_request))
            else:
                crc_in_use[CANC_CRC_CATALOGUE[crc_name]['width']] = crc_name
        if crc_unknown:
            print('Known CRC names: ' + ', '.join(CANC_CRC_CATALOGUE))
        crc_keys = sorted(key for key in MAH_CAN_SIGNAL_DEFS if key.upper().endswith('_CRC'))
        crc_frame_ids = sorted({MAH_CAN_SIGNAL_DEFS[key]['frame_ID'] for key in crc_keys})
        crc_widths_missing = sorted({MAH_CAN_SIGNAL_DEFS[key]['bit_length'] for key in crc_keys} - set(crc_in_use))
        crc_capture_ms = int(CANC_PERIODICITY_SAMPLE_FRAMES
                             * max((MAH_CAN_SIGNAL_DEFS[key]['periodicity'] for key in crc_keys), default=0) * margin)
        crc_outcome = {}
    """)
    sc.need("'signals named *_CRC in MAH_CAN_SIGNAL_DEFS'", "crc_keys or None")
    sc.need("'a CANC_CRC_CATALOGUE entry for ' + ', '.join(crc_unknown)", "None if crc_unknown else True")
    sc.need("'a CRC in use for the ' + ', '.join(f'{width}-bit' for width in crc_widths_missing) + ' CRC signals'",
            "None if crc_widths_missing else True")
    sc.log_ids.append("*crc_frame_ids")

    sc.step("Bench in normal condition, IGN ON, no DTC present")
    sc.T("""
        PS.SetVoltage(NOMINAL_VOLTAGE)
        for crc_key in crc_keys:
            crc_def = MAH_CAN_SIGNAL_DEFS[crc_key]
            if not crc_def.get('ecu_generated'):
                CAN.PeriodicEnableFrame(crc_def['bus'], crc_def['frame'])
                CAN.ReloadDefaultPeriodicFrame(crc_def['bus'], crc_def['frame'])
                CAN.DynamicEnableSignal(crc_def['bus'], crc_def['frame'], crc_def['signal'])
        fault_free_profile()
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
    """)
    read_dtc(sc, "Bench is fault free with no DTC present", [])
    sc.end()

    sc.step("Known-answer check of the CRC in use")
    sc.T("""
        for crc_width, crc_name in sorted(crc_in_use.items()):
            crc_spec = CANC_CRC_CATALOGUE[crc_name]
            crc_check = calculate_crc(b'123456789', f"crc{crc_width}", polynomial=crc_spec['poly'],
                                      initial=crc_spec['init'], final_xor=crc_spec['xorout'],
                                      reflect_in=crc_spec['refin'], reflect_out=crc_spec['refout'])
            RESULT.InterpretEqualResult(f"{crc_name} ({crc_width}-bit) of the ASCII bytes 123456789",
                                        f"0x{crc_check:0{crc_width // 4}X}", f"0x{crc_spec['check']:0{crc_width // 4}X}")
    """)
    sc.end()

    sc.step("Log every frame with a CRC signal on both buses")
    capture(sc, "crc", "crc_frame_ids", FD_BUSES, "crc_capture_ms", "crc_frames")
    sc.T('RESULT.InsertComment(f"{len(crc_frames)} frames logged in {crc_capture_ms} ms")')
    sc.end()

    sc.step("Check the CRC of every frame against the CRC in use")
    sc.T("""
        for crc_key in crc_keys:
            crc_def = MAH_CAN_SIGNAL_DEFS[crc_key]
            crc_frame = crc_def['frame']
            crc_width = crc_def['bit_length']
            crc_digits = crc_width // 4
            crc_name = crc_in_use[crc_width]
            crc_spec = CANC_CRC_CATALOGUE[crc_name]
            crc_layout = CANC_CRC_FRAMES.get(crc_frame)
            crc_source = 'sent by the ECU' if crc_def.get('ecu_generated') else 'simulated by the bench'
            aria_reports.add_group(f"{crc_frame} (0x{crc_def['frame_ID']:X}, {crc_source}): "
                                   f"{crc_def['signal']} against {crc_name}")
            if crc_layout is None or crc_key not in CAN_SIGNAL_START_BIT:
                RESULT.LogCustomAction(f"{crc_frame} CRC layout", "In CANC_CRC_FRAMES and CAN_SIGNAL_START_BIT",
                                       "Missing: the frame is not checked", False)
                crc_outcome[crc_frame] = 'not checked (no CRC layout in the configuration)'
                aria_reports.close_group()
                continue
            crc_start = CAN_SIGNAL_START_BIT[crc_key]
            crc_byteorder = 'big' if crc_def.get('byte_order') == 'big_endian' else 'little'
            crc_data_id = crc_layout.get('data_id')
            crc_data_id_bytes = b'' if crc_data_id is None else bytes([crc_data_id & 0xFF, (crc_data_id >> 8) & 0xFF])
            crc_rows = [(bytes(frame_data.payload),
                         b''.join(bytes(frame_data.payload[start:end]) for start, end in crc_layout['data_bytes'])
                         + crc_data_id_bytes,
                         extract_can_signal(frame_data.payload, crc_start, crc_width, byteorder=crc_byteorder))
                        for frame_data in crc_frames if frame_data.id == crc_def['frame_ID']]
            crc_checked = [row + (calculate_crc(row[1], f"crc{crc_width}", polynomial=crc_spec['poly'],
                                                initial=crc_spec['init'], final_xor=crc_spec['xorout'],
                                                reflect_in=crc_spec['refin'], reflect_out=crc_spec['refout']),)
                           for row in crc_rows]
            crc_bad = [row for row in crc_checked if row[3] != row[2]]
            RESULT.InsertComment(f"CRC over bytes {crc_layout['data_bytes']} (end exclusive)"
                                 + ("" if crc_data_id is None else f", then Data ID 0x{crc_data_id:04X} low byte first"))
            RESULT.InterpretEqualResultRange(f"{crc_frame} frames logged", len(crc_rows),
                                             CANC_FRAME_PRESENCE_CYCLES, float('inf'))
            RESULT.InterpretEqualResult(
                f"{crc_frame} frames whose {crc_def['signal']} is not the {crc_name} of the covered bytes "
                f"({len(crc_bad)} of {len(crc_rows)})",
                [f"received 0x{row[2]:0{crc_digits}X}, computed 0x{row[3]:0{crc_digits}X}" for row in crc_bad[:3]], [])
            crc_outcome[crc_frame] = ('not logged' if not crc_rows else 'conforms' if not crc_bad
                                      else f"differs in {len(crc_bad)} of {len(crc_rows)} frames")
            if crc_bad:
                RESULT.InsertComment(f"First frame that differs: {crc_bad[0][0].hex(' ').upper()}")
                crc_first = crc_start // 8
                crc_last = (crc_start + crc_width - 1) // 8
                crc_sample = crc_rows[:CANC_FRAME_PRESENCE_CYCLES]
                crc_coverages = {}
                for crc_label, crc_blocks in (
                        ('the configured bytes', [row[1] for row in crc_sample]),
                        (f"bytes 0-{crc_first - 1}", [row[0][:crc_first] for row in crc_sample]),
                        ('every byte but the CRC', [row[0][:crc_first] + row[0][crc_last + 1:] for row in crc_sample])):
                    if crc_blocks not in crc_coverages.values():
                        crc_coverages[crc_label] = crc_blocks
                crc_matches = [f"{name} over {label}" for label, blocks in crc_coverages.items()
                               for name, spec in CANC_CRC_CATALOGUE.items()
                               if spec['width'] == crc_width and all(
                                   calculate_crc(block, f"crc{crc_width}", polynomial=spec['poly'], initial=spec['init'],
                                                 final_xor=spec['xorout'], reflect_in=spec['refin'],
                                                 reflect_out=spec['refout']) == row[2]
                                   for block, row in zip(blocks, crc_sample))]
                RESULT.InsertComment(
                    f"Catalogued CRCs that match the first {len(crc_sample)} frames: " + "; ".join(crc_matches)
                    if crc_matches else
                    f"No catalogued {crc_width}-bit CRC matches the first {len(crc_sample)} frames over "
                    + ", ".join(crc_coverages) + ": the CRC may fold in an E2E Data ID (data_id in "
                    "CANC_CRC_FRAMES) or cover other bytes.")
            aria_reports.close_group()
    """)
    sc.end()

    sc.step("Summary")
    sc.T("""
        RESULT.InsertComment("CRC in use: " + ", ".join(f"{width}-bit {name}" for width, name in sorted(crc_in_use.items())))
        RESULT.InterpretEqualResult(
            f"Frames whose CRC is not the CRC in use (of {len(crc_outcome)} frames with a CRC signal)",
            sorted(f"{frame}: {outcome}" for frame, outcome in crc_outcome.items() if outcome != 'conforms'), [])
    """)
    sc.end()

    sc.notes += [
        "Input: the CRC in use, as a CANC_CRC_CATALOGUE name or alias on the command line, e.g. "
        "'py -3.14 CANC_CRC_Check_All_Messages.py CRC-16/ARC'; each name replaces the CANC_CRC_IN_USE entry of "
        "its width (16-bit: the CAN-FD frames, 8-bit: SRS1_20). Run without one, the script checks "
        "CANC_CRC_IN_USE.",
        "The frames come from the configuration: every MAH_CAN_SIGNAL_DEFS signal named *_CRC (13 CAN-FD frames "
        "and SRS1_20 on HS-CAN, as in the DBCs). CANC_CRC_FRAMES gives the bytes each CRC covers and the frame's "
        "E2E Data ID; the CRC must equal the selected CRC of those bytes in every logged frame.",
        "CAN-FD frames carry the CRC in bytes 58-59, the alive counter in 60, the SecOC freshness value in 61 and "
        "the truncated MAC in 62-63. The CRC is E2E Profile 5: CRC-16/CCITT-FALSE over bytes 0-57 and 60, then the "
        "Data ID low byte first, and the Data ID is the frame's CAN identifier - every frame of the 2026-10-15 "
        "bench logs matches (674,172 SRS1_FD_10 frames from the ECU, all bench-simulated frames outside the "
        "CRC-error cases). CANC_CRC_FRAMES holds the covered bytes and Data ID of each frame.",
        "Where a frame's CRC differs, the script lists the catalogued CRCs of the same width that do match its "
        "first frames over the configured bytes, the bytes before the CRC and every byte but the CRC, which shows "
        "the CRC the frame actually uses.",
        "Bench-simulated frames carry the CRC the bench computes (customer DLL); the ECU accepting it shows in the "
        "no-DTC precondition. The SecOC MAC and freshness value are not checked.",
    ]
    return sc


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build(case: Case) -> Script:
    sc = Script(case)
    if case.workbook in NODE_SUITES:
        build_node_case(sc)
    else:
        build_other_case(sc)
    return sc


BUSOFF_RECOVERY_CASE = Case(
    name="CANC_BUSOFF_Fast_Slow_Recovery", case_id="",
    description="Verify the ECU's recovery from a bus-off: it retries BUSOFF_FAST_RECOVERY_COUNT times after the "
                "fast recovery time, then after the slow recovery time for as long as the bus-off lasts (bus-off "
                "case 4), the bus-off being put on the bus by the bench relay.",
    pre="", steps=[], workbook="", suite="BUSOFF_RECOVERY")


def build_busoff_recovery() -> Script:
    """Fast and slow bus-off recovery measured with release probes. A bus-off cannot be
    seen on a shorted bus, but its end can: released after a known hold, the bus stays
    silent until the ECU's next retry, so the time from the release to the first ECU
    frame tells where the retries fall. One probe sits in the middle of each fast
    interval (the next retry half a fast interval later) and five spread over the first
    slow interval (the next retry 450, 350, 250, 150 and 50 ms later with the 500 ms of
    canc_config). Too few or too many fast retries, or a wrong slow time, puts probes
    outside their windows."""
    sc = Script(BUSOFF_RECOVERY_CASE)
    common_setup(sc)
    ecu_frames(sc)
    sc.S("""
        fast_holds_ms = [round((index + 0.5) * BUSOFF_FAST_RECOVERY_TIME_MS) for index in range(BUSOFF_FAST_RECOVERY_COUNT)]
        slow_start_ms = BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
        slow_holds_ms = [round(slow_start_ms + (index + 0.5) * BUSOFF_SLOW_RECOVERY_TIME_MS / 5) for index in range(5)]
        # (phase, hold, retry interval, expected time from the release to the next retry)
        probes = ([('fast', hold, BUSOFF_FAST_RECOVERY_TIME_MS, BUSOFF_FAST_RECOVERY_TIME_MS / 2) for hold in fast_holds_ms]
                  + [('slow', hold, BUSOFF_SLOW_RECOVERY_TIME_MS, slow_start_ms + BUSOFF_SLOW_RECOVERY_TIME_MS - hold)
                     for hold in slow_holds_ms])
        identify_hold_ms = slow_start_ms + BUSOFF_SLOW_RECOVERY_TIME_MS
        bus_off_lead_ms = CANC_BUS_OFF_LEAD_FRAMES * max(fd_period_ms, hs_period_ms)
        recovery_wait_ms = int(BUSOFF_SLOW_RECOVERY_TIME_MS * margin) + bus_off_lead_ms
    """)
    sc.C("ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_RESTORE_LOAD)")
    ecu_precondition(sc, "both")

    sc.step("Find the bus behind the bus-off relay")
    capture(sc, "identify", "[fd_id, hs_id]", FD_BUSES, None, "busoff_identify", start_only=True)
    sc.T("""
        Wait(bus_off_lead_ms)
        ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_LOAD)
        Wait(identify_hold_ms)
        ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_RESTORE_LOAD)
        Wait(recovery_wait_ms)
    """)
    capture_stop(sc, "identify", None)
    sc.T("""
        identify_silence = {}
        for identify_id in (fd_id, hs_id):
            identify_times = [frame_data.timestamp for frame_data in identify_frames if frame_data.id == identify_id]
            identify_silence[identify_id] = max([(later - earlier) / 1000 for earlier, later
                                                 in zip(identify_times, identify_times[1:])] or [0])
        RESULT.LogAction(f"Longest gap of {fd_frame} on {CAN_FD_CHANNEL_NAME} (ms)", round(identify_silence[fd_id], 1))
        RESULT.LogAction(f"Longest gap of {hs_frame} on {CAN_HS_CHANNEL_NAME} (ms)", round(identify_silence[hs_id], 1))
        busoff_ids = [frame_id for frame_id, silence in identify_silence.items() if silence >= identify_hold_ms / 2]
        RESULT.InterpretEqualResult(
            f"ECU frames stopped by {CAN_BUS_OFF_RELAY_FUNCTION} = {CAN_BUS_OFF_RELAY_LOAD} for {identify_hold_ms} ms",
            len(busoff_ids), 1)
        if len(busoff_ids) != 1:
            aria_reports.close_group()
            return
        watch_id = busoff_ids[0]
        watch_frame = fd_frame if watch_id == fd_id else hs_frame
        watch_bus = CAN_FD_CHANNEL_NAME if watch_id == fd_id else CAN_HS_CHANNEL_NAME
        watch_period_ms = fd_period_ms if watch_id == fd_id else hs_period_ms
        bus_off_dtc = CAN_BUS_OFF_DTC[watch_bus]
        RESULT.InsertComment(f"{CAN_BUS_OFF_RELAY_FUNCTION} carries {watch_bus}: the recovery is timed on {watch_frame}")
    """)
    sc.end()

    sc.step("Release the bus-off at set times in the fast and the slow recovery")
    sc.T("""
        probe_results = []
        for probe_index, (probe_phase, probe_hold_ms, probe_interval_ms, probe_expected_ms) in enumerate(probes, start=1):
            probe_label = f"_busoff_probe_{probe_index:02d}"
            probe_file = os.path.splitext(log_path)[0] + probe_label + '.txt'
            probe_logger = CAN.StartLoggingToFile(TestCase_ID=tc_name + probe_label, filepath=probe_file,
                                                  listOption=[watch_id], channel_names=[watch_bus])
            Wait(bus_off_lead_ms)
            probe_set = time.monotonic()
            ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_LOAD)
            Wait(probe_hold_ms)
            probe_clear = time.monotonic()
            ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_RESTORE_LOAD)
            Wait(recovery_wait_ms)
            CAN.StopLoggingToFile(probe_logger)
            probe_times = []
            if os.path.isfile(probe_file):
                with open(probe_file, encoding='utf-8', errors='replace') as probe_log:
                    probe_fields = [line.split(',', 2) for line in probe_log if ' id=' in line and line.count(',') >= 2]
                probe_times = [round(float(fields[0].split()[0]) * 1e6) for fields in probe_fields
                               if int(fields[1].split('=')[1], 16) == watch_id]
            probe_silence_ms = max([(later - earlier) / 1000 for earlier, later in zip(probe_times, probe_times[1:])] or [0])
            probe_held_ms = (probe_clear - probe_set) * 1000
            # No gap longer than the hold means the frame did not come back within the log (or
            # never stopped): no time to grade.
            probe_recovery_ms = round(probe_silence_ms - probe_held_ms, 1) if probe_silence_ms > probe_held_ms else None
            RESULT.InsertComment(f"Probe {probe_index}: longest gap of {watch_frame} {round(probe_silence_ms, 1)} ms, "
                                 f"bus-off held {round(probe_held_ms, 1)} ms")
            # Window: the expected time to the next retry, -/+ 10 % of the retry interval and the
            # relay switching; the upper limit also allows the bus-off starting at the ECU's next
            # transmission and the first frame after the retry (one frame period each).
            probe_tolerance_ms = probe_interval_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100 + CAN_BUS_OFF_RELAY_SWITCH_MS
            RESULT.InterpretEqualResultRange(
                f"Probe {probe_index}, {probe_phase} recovery, bus-off held {round(probe_held_ms)} ms: "
                f"release to the first {watch_frame} (ms)",
                probe_recovery_ms, round(probe_expected_ms - probe_tolerance_ms, 1),
                round(probe_expected_ms + probe_tolerance_ms + 2 * watch_period_ms, 1))
            probe_results.append((probe_index, probe_phase, round(probe_held_ms), probe_recovery_ms))
            Wait(CAN_BUS_OFF_PROBE_SETTLE_MS)
        RESULT.InsertComment("Probes (index, phase, held ms, release to first frame ms): " + str(probe_results))
    """)
    sc.end()

    sc.step("Read DTC: the bus-off DTC healed in this cycle, the ECU frames back")
    read_dtc(sc, "Bus-off DTC raised and healed", [("bus_off_dtc", "'DTC_healed'")])
    presence(sc, "both", "present", "after_recovery")
    sc.end()

    sc.notes += [
        "The bench loadbox puts the bus-off on: CAN_BUS_OFF_RELAY_FUNCTION (CAN1) set to CAN_BUS_OFF_RELAY_LOAD "
        "(CAN_BUSS_OFF) with the shared ARIA.AFT_iLoadBoxWrapper, back to CAN_BUS_OFF_RELAY_RESTORE_LOAD "
        "(INHERENT) to end it (M314 ARIA relay map, .github/agents/aria_agent.md section 5.1). Which bus CAN1 "
        "carries is not recorded anywhere, so the script finds it first from the ECU frame that stops.",
        "Retries cannot be seen while the bus is shorted, so the script releases the bus-off at set hold times and "
        "times the release to the first ECU frame: that is the time to the ECU's next retry. Expected with "
        "canc_config: 50 ms for each of the BUSOFF_FAST_RECOVERY_COUNT probes inside the fast recovery, then "
        "450, 350, 250, 150 and 50 ms across the first slow interval; each within 10 % of the retry interval and "
        "CAN_BUS_OFF_RELAY_SWITCH_MS, the upper limit plus two frame periods. CAN_BUS_OFF_RELAY_SWITCH_MS (10 ms) "
        "is an assumed relay switching allowance to confirm on the bench.",
        "Bus-off case 4 asks for a CAN stress tool and a bus-off held for 2000 s, with the retries read from the "
        "CAN log; this script checks the same retry pattern (count, fast and slow time) in about a minute, and "
        "stays an additional check next to that case.",
    ]
    return sc


DTC_TIMING_CASE = Case(
    name="CANC_DTC_Read_Timing", case_id="",
    description="Measure how long one DTC read of the shared faultTimeMeasurement takes on this bench (request out "
                "through ARIA, the ECU's answer, the answer back in python) and check that the measurement lag the "
                "CAN-C timing checks allow (FAULT_TIME_MEASUREMENT_LAG_MS) covers it.",
    pre="", steps=[], workbook="", suite="DTC_TIMING")


def build_dtc_read_timing() -> Script:
    """Read timing of faultTimeMeasurement on the bench. Its target here is the 19 02
    positive-response header, which every answer carries, so each call returns after
    exactly one read: the time of a read as the CAN-C scripts' measurements see it.
    A DTC change right after a read is seen by the next one, so the lag is at most a
    read, the poll pause and a read."""
    sc = Script(DTC_TIMING_CASE)
    sc.S("""
        timing_target = " ".join(Read_DTC_Resp.split()[:2])
    """)
    precondition(sc)
    sc.step("Time single DTC reads of faultTimeMeasurement")
    sc.T("""
        timing_reads_ms = [faultTimeMeasurement(timing_target) for _ in range(CANC_DTC_READ_TIMING_SAMPLES)]
        timing_valid = sorted(value for value in timing_reads_ms if value is not None)
        RESULT.InterpretEqualResult(f"Reads without the 19 02 answer (of {CANC_DTC_READ_TIMING_SAMPLES})",
                                    len(timing_reads_ms) - len(timing_valid), 0)
        timing_sleeps_ms = []
        for _ in range(CANC_DTC_READ_TIMING_SAMPLES):
            timing_started = time.monotonic()
            time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            timing_sleeps_ms.append((time.monotonic() - timing_started) * 1000)
        timing_sleeps_ms.sort()
        if timing_valid:
            RESULT.LogAction("One DTC read (ms): min / median / 95th percentile / max",
                             [round(timing_valid[0], 1), round(timing_valid[len(timing_valid) // 2], 1),
                              round(timing_valid[min(len(timing_valid) - 1, int(0.95 * len(timing_valid)))], 1),
                              round(timing_valid[-1], 1)])
            RESULT.LogAction(f"Poll pause of {CAN_FAULT_POLL_INTERVAL_MS:g} ms (ms): median / max",
                             [round(timing_sleeps_ms[len(timing_sleeps_ms) // 2], 1), round(timing_sleeps_ms[-1], 1)])
            timing_lag_ms = round(2 * timing_valid[-1] + timing_sleeps_ms[-1], 1)
            RESULT.InterpretEqualResultRange("Measurement lag on this bench: 2 x longest read + longest pause (ms)",
                                             timing_lag_ms, 0, FAULT_TIME_MEASUREMENT_LAG_MS)
    """)
    sc.end()
    read_dtc(sc, "No DTC after the timing reads", [])
    sc.notes += [
        "faultTimeMeasurement is given the 19 02 positive-response header (the first two bytes of Read_DTC_Resp) "
        "as its target, which every answer carries, so each of the CANC_DTC_READ_TIMING_SAMPLES calls times one "
        "read: one ARIA call resolving the UDS channel, the 19 02 09 request, the ECU's answer and the return.",
        "The CAN-C timing checks allow FAULT_TIME_MEASUREMENT_LAG_MS (60 ms, derived from the 2026-10-15 bench "
        "logs) above nominal + 10 %. If this script measures more, raise that value to the measured lag.",
    ]
    return sc


def main(argv: list[str]) -> int:
    only = set(argv[1:])
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    scripts: list[Script] = []
    problems = {}
    node_cases = [case for path in sorted(CASE_DIR.glob("*.xlsx")) if path.name in NODE_SUITES
                  for case in load_cases(path, NODE_SUITES[path.name])]
    STATED_KEY_FRAMES.update(collect_stated_key_frames(node_cases))
    print("key messages the workbooks state:", STATED_KEY_FRAMES)
    for path in sorted(CASE_DIR.glob("*.xlsx")):
        suite = NODE_SUITES.get(path.name, path.stem)
        if only and path.name not in only and suite not in only:
            continue
        for case in load_cases(path, suite):
            sc = build(case)
            source = render(sc)
            issues = check_script(case.name, source)
            if issues:
                problems[case.name] = issues
            (OUT_DIR / f"{case.name}.py").write_text(source, encoding="utf-8")
            scripts.append(sc)
    print(f"{len(scripts)} scripts written to {OUT_DIR}")
    extras: list[Script] = []
    for extra_case, extra_builder in ((CRC_CHECK_CASE, build_crc_check), (BUSOFF_RECOVERY_CASE, build_busoff_recovery),
                                      (DTC_TIMING_CASE, build_dtc_read_timing)):
        if only and extra_case.suite not in only:
            continue
        sc = extra_builder()
        source = render(sc)
        issues = check_script(sc.case.name, source)
        if issues:
            problems[sc.case.name] = issues
        (OUT_DIR / f"{sc.case.name}.py").write_text(source, encoding="utf-8")
        extras.append(sc)
        print(f"additional check written: {sc.case.name}.py")
    for name, issues in problems.items():
        print(f"  {name}: {issues}")
    if not only:
        write_gap_report(scripts)
        print(f"gap report written to {GAP_REPORT}")
        write_runners(scripts, extras)
        print(f"runners written to {AUTO_RUNNER.name} and {MANUAL_RUNNER.name}")
    return 1 if problems else 0


# ---------------------------------------------------------------------------
# Gap report
# ---------------------------------------------------------------------------

GAP_REPORT_HEAD = """\
# CAN-C test scripts - gaps and hard constraints

Author: Kris. Generated by `tools/generate_canc_scripts.py` from the ten workbooks in
`project_testcases/m310_m314_m110/CANC/CANC`: {total} cases, one script each, named after the case.
Edit the generator, not the scripts. `run_all_canc_automatic_scripts.py` runs the fully automatic scripts
and `run_all_canc_non_automatic_scripts.py` the rest, grouped by what the bench needs.

Additional checks (not workbook cases, all in the automatic runner):
- `CANC_CRC_Check_All_Messages.py` logs every frame with a CRC signal (13 CAN-FD frames and SRS1_20 on
  HS-CAN, ECU-sent and bench-simulated) and checks each frame's CRC against the CRC in use, given as a name
  on its command line - any catalogued CRC-8/CRC-16, including the preset names of the online calculator
  sunshine2k.de (`CRC16_CCITT_FALSE`, `CRC16_CCIT_ZERO`, `CRC8_SAE_J1850`, ...) - or by `CANC_CRC_IN_USE`.
- `CANC_BUSOFF_Fast_Slow_Recovery.py` puts a bus-off on the bus with the bench relay and measures the
  ECU's fast and slow recovery (see "Bus-off recovery" below).
- `CANC_DTC_Read_Timing.py` times single DTC reads of `faultTimeMeasurement` on the bench and checks that
  the measurement lag the timing checks allow covers them.

Every script reads only `projects/M310_M314_M110/config/*` and the `shared_libraries` functions; no DBC,
JSON or workbook is a script input; each has a single `run_test()` and no helper functions.

**Verification done:** every script compiles and passes a static check (only `run_test` defined, every
name resolves to the shared library or an explicit config import) and runs end to end offline against
stubbed bench calls. The frame analysis was also replayed on the real CAN logs of the 2026-10-15 bench
run: every frame check the ECU behaved right for passes. The DTC timing path was run against the real
shared `faultTimeMeasurement` / `fault_time_check` with a simulated ECU: a DTC set inside its window
passes, an early, late or missing one fails, and the 90 s VCU4_FD_1500 timeout is measured. The bus-off
recovery script was run against a simulated ECU: the correct retry pattern passes on either bus, and
3 or 7 fast retries, a 50 / 150 ms fast time, a 300 / 1000 ms slow time or no slow phase each fail.
**The corrected scripts have not run on the bench yet.**

## What the 2026-10-15 bench run showed, and what changed

297 reports (231 failed) and their CAN logs were analysed. The causes, and the fix in these scripts:

1. **Frames never read back** (every 13C/2C0 frame check, the node counter / CRC / periodicity cases, the
   CRC check): `CAN.ReadFromCanLogFile` (apym 2.6.4 with ARIA 5.20) drops every CAN-FD frame and raises
   "Failed to decode log data" or "A positive number is required", although the log files hold all
   frames. The scripts now read the text log ARIA writes (1,184,934 logged lines parse without error).
2. **DTC read too soon after an IGN cycle**: 2 s after IGN ON the statuses read 0x48 / 0x49 (test not
   completed this cycle). Every read after an IGN cycle, and the precondition's no-DTC check, now waits
   the shared `PROVEOUT_COMPLETION_TIME` (8 s; the lamp proveout ends about 7 s after IGN ON).
3. **Qualification / heal read once at the bare count x period**: the DTCs showed a little later (the
   EPS CRC DTC was not yet set 653 ms after the CRC froze, against 60 x 10 ms = 600 ms; a CRC heal on a
   100 ms frame took over 1.02 s against 1.0 s; a node-absent heal on a 10 ms frame over 101 ms against
   100 ms). The times are now **measured and graded with the shared `faultTimeMeasurement` and
   `fault_time_check`**, as the W610 Fault_List scripts do: right after the fault is applied (or removed)
   faultTimeMeasurement reads the DTCs (19 02 09, nothing written to the report) until the expected DTC
   and status are in the answer, and fault_time_check grades that time against count x period from
   canc_config `FAULT_THRESHOLDS` (node absent 50, message timeout / content / signal content 60,
   recovery 10 cycles). **The window is strict: -10 % to +10 %, the upper limit extended only by the
   measurement lag** (`FAULT_TIME_MEASUREMENT_LAG_MS`, 60 ms): the measurement can only see a DTC change
   after it happened, never before. The lag was measured from the 2026-10-15 reports and CAN logs (6,200
   diagnostic calls) rather than assumed: a read of faultTimeMeasurement is one ARIA call resolving the
   UDS channel plus the `19 02 09` request (apym sends each call as JSON over a localhost TCP socket and
   ARIA answers when the ECU has); the request reaches the bus within 17.3 ms (p99, measured on the logged
   SendDiagByValues, which makes 7 ARIA calls before it, so a bound for these 2); the ECU answers 19 02
   within 12.4 ms (p99 of 618 single-frame answers, 13.9 ms max); the answer is back in python within
   8 ms; the 10 ms pause between reads overruns by up to 4 ms (p99). A change just after a read is seen
   by the next: 8 + 14 + 17.3 + 12.4 + 8 = 59.7 ms. The ~90 ms each logged SendDiagByValues takes is its
   bus capture read-back (75 ms, the same read-back that fails in ReadFromCanLogFile), which
   faultTimeMeasurement does not do. `CANC_DTC_Read_Timing.py` measures the lag on the bench. Examples:
   node absent on a 10 ms frame 450 to 610 ms, its heal 90 to 170 ms; CRC on a 10 ms frame 540 to 720 ms;
   message timeout of VCU4_FD_1500 81 to 99.06 s. An ECU earlier than -10 % is caught when it is early by
   more than the lag happened to be at that read. The full DTC list is then graded with Read_DTC. Expected
   statuses are unchanged: active 0x0B and healed 0x0A in the same cycle, historic 0x08 only after an
   IGN cycle. Where the timing does not start at the fault itself (a CAN fault qualifying once the supply
   is back, DTCs after an IGN cycle, the lamp cases, the VIN start-up check) the measurement only waits
   for the state and records how long it took. Checks that a DTC must *not* appear still wait the whole
   qualification time (+10 %) first. The shared function gives up after 7.5 s unless canc_config sets
   `FAULT_TIME_MEASUREMENT_TIMEOUT_MS`; it is set to 101 s, past the end of the VCU4_FD_1500 window
   (99.06 s), so a DTC that never comes holds the script 101 s per measurement before the step fails.
4. **Wrong DLC**: a second simulated frame on the identifier is refused by ARIA ("Frame ID ... already in
   simulation"). The frame itself now gets the shorter payload (bench CRC / counter held), and the
   default frame is reloaded to heal (`CAN.ReloadDefaultPeriodicFrame`, then the CRC / counter
   re-enabled). The reload's own timing is not taken on trust: a CAN log runs across the heal, and the
   time from the measurement's first 19 02 read to the first full-length frame moves the expected heal
   time (the ECU can only count valid frames from then on); the report also shows the frame interval
   across the reload (a transmission gap) and the alive counter the reloaded frame resumes with.
5. **FR_ZONE key message**: the bench sides with the workbook - stopping FR_ZONE2_100 sets the
   node-absent DTC D10400, stopping FR_ZONE3_100 for 5.5 s set none (its message-timeout DTC D00400 needs
   60 x 100 ms). The scripts take the fault from the case wording and the key message the FR_ZONE
   workbook states (FR_ZONE2_100), which canc_config `KEY_TX_FRAMES` also names since 2026-10-16 (the
   customer DTC list, S.No 274, still says FR_ZONE3_100); every DTC comes from canc_config.
6. **CAN wakeup**: the PKE clamp state sent after bus sleep never woke the ECU (13C 31, 39-43, 55, 57); the
   VCU NM frame did (13C 48). The CAN wakeup is now IGN OFF and PKE_CLMP_STATE set straight away (the
   ECU stops sending about 1 s after IGN OFF), as you described, and each wake value 1, 2, 3 and 4
   (`CAN_PKE_WAKEUP_VALUES`) is checked from its own IGN ON -> IGN OFF; the PKE wakes the bus only with
   the ignition OFF - with the ignition ON the ignition has priority (13C 49/50 now expect IGN ON due to
   HW). Cases that need a start-up from sleep (proveout on CAN wakeup 13C 31/32, alive-counter restart
   13C 55/57, which name the active wakeup bit) wake the ECU from bus sleep with the VCU NM frame.
7. **VIN mismatch**: the ECU compares the VIN only at start-up (agent_sc3.md 2.9), so the wrong VIN is now
   put on the bus before an IGN cycle; the DTC is expected historic after the cycle with the project VIN.
8. **Lamp checks**: read during the 6 s proveout, and the fault lamp comes on about 1 s after its DTC. Lamp
   reads now wait for the end of the start-up and for the DTC, then poll for the lamp. The proveout check
   allows the ~60 ms of lamp-OFF frames the ECU sends before the proveout starts (ON time measured
   5951 ms); the belt init check allows the same before the Reserved state.
9. **Occupancy**: the counts settle about 7.5 s after a seat change (new `CANC_OCCUPANT_COUNT_SETTLE_MS`,
   10 s), and with the passenger seat unoccupied for the OCS the ECU sends STS_SEAT_BLT_PSGR = Buckled, as
   the system requirement (tables 1.7 / 1.9) says.
10. **Hard / soft reset**: 11 01 is answered only in the extended session (7F 11 7F in default); the
   scripts enter it first.
11. **CheckSingleDTC** was given '0xE7 0x25 0x00'; it takes the number (0xE72500).
12. **Bench-sent frame periodicity**: ARIA's simulated frames keep an exact mean period but single
   intervals of a 10 ms frame run from 1.9 to 24 ms (bench timing); those cases now grade the mean period
   and record the spread. ECU-sent frames keep the per-interval check.
13. **Bench-side counter restart**: a reloaded simulated frame restarts its alive counter at 1 (all
   simulated frames in the logs); 0 or 1 is accepted as the restart.
14. **Not script issues**: ARIA lost its connection during 13C 122 ("Power line BATT not found", "Diagnostic
   channel ... not found"), so 13C 122/123 and 2C0 16-19 must be re-run; a 6 s host stall inside
   fault_free_profile let the extended session expire in 13C 83 (7F 27 7F); fault_free_profile once got
   7F 31 31 for F105 (HPCC 5, IEB 10) and 7F 31 22 for F104 right after a side crash.

## ECU findings from the 2026-10-15 run (the scripts report them; nothing to change in the scripts)

- SRS1_20 SRSHS_MSG_CNT stays 0 in every frame (byte 6 = 0x00) with the default EOL code, whose
  alive-counter bit is 0 (0..15 expected, agent_sc3.md 2.2): 2C0 16-21, 13C 54-57 fail on it.
- No D05A00 after HPCC_24_500 was stopped for 33.5 s (HPCC 22); the measurement now waits up to 101 s
  and grades the time within 27 to 33.06 s.
- 22 01 01 on the functional address 7DF gets no answer at all (Diagnostics 2); 10 03 on 7DF and 22 01 01
  on 730 work.
- After an IGN cycle with a CRC error held, the CRC DTC read 0x08 (monitor passed) 2.3 s after IGN ON
  (EPS 12); the script now waits for it to qualify again after the start-up.
- CTRL_BRAKE_LIGHT and PIB_ACTIVE could not be read back from the ARIA simulation (IEB 23/24); the script
  now writes ARIA's answer to the report - most likely the bench's ARIA database lacks the two signals.

## Cases that cannot be executed as written (hard constraints)

1. **No invalid value / SCF DTC** - VCU 55, 58, 59: `VCU_MCU_MOTOR_SPEED` has no invalid value and no
   signal-content DTC in canc_config, and the customer DTC list defines none. The scripts report the
   missing configuration and stop before acting on the bench.
2. **Crash curves not delivered** - the project crash-curve table has front, left, right, rear and
   understrike curves; `near` exists with no curve files, and rollover, PT-only and every multi-event
   sequence are absent. 2C0 11 and 12, 13C 20, 22, 59, 60, 61, 93 and 99 report "crash curves missing"
   and stop; they run unchanged once the curves are added under the `CANC_CRASH_CURVE_KEY` names.
3. **Operator action needed** (no shared-library call can do it): creating and removing a bus-off on the
   bus a case names (all 16 bus-off cases and 2C0 21: the bench relay reaches only the bus behind CAN1,
   see below), moving or shaking the ECU (13C 1-12, 21, 135), the thermal chamber
   (13C 23-27), injecting an IMU sensor fault (13C 131, no method or EVT exists for the Panasonic IMU),
   forcing low-power mode (13C 134) and an internal MCAL SPI fault (2C0 31). The script prints and
   reports each instruction, waits a configured window, then checks the result itself. The fast/slow
   bus-off recovery timing (bus-off 4 and 12) is evaluated from the saved CAN log, and checked without an
   operator by the additional `CANC_BUSOFF_Fast_Slow_Recovery.py`.
4. **Partly automatic** - 13C 91/92: no zone-3 current preset exists for the seat track sensors;
   13C 132/133: standby, INIT and the OPS states cannot be commanded, so they are approximated by supply
   transitions.
5. **One run per flash** - 2C0 2 and 30, 13C 29 and 45 enter plant mode; the learned phase of life then
   moves to Owner, from which plantmode_config allows only EndOfLife. The scripts read the phase first
   and stop if plant mode cannot be entered.
6. **SPI sensor card missing on the bench** - every crash case (13C 34-43, 53, 94-98; 2C0 7-10, 15):
   load_crash_curves sends the central-sensor curves through the SPI card and ARIA answered "Card not
   present in ARIA Chassis", which fails the case even where the satellite curves alone produced the
   crash (13C 35/37/95/96 held STS_CRASH 800 ms with the right CRASH_LOCATION). They run as they stand
   once the card is fitted. 13C 94-98 also need `EDR_DECODER_CONFIG` in the project's edr_config for the
   delta-V comparison (read_edr_parameters raises without it; the step now reports it and the case goes on).
7. **EVT sheets missing** - 2C0 28 and 13C 46 load the corrupted EVT of project_config `EOL_EVT_CONFIG`,
   which points to evt/z121; that folder holds no files ("EVT sheet does not exist"), and the SPI card
   is needed as well.

## Test-case defects (each script header says what the script does instead)

- 13C 72, 75, 102-122 (baselines): the cases expect STS_SEAT_BLT_PSGR = 0x0 with OCS_PASS_CLASS = EMPTY;
  the system requirement (tables 1.7 / 1.9) and the ECU give 1 (Buckled) for an unoccupied passenger
  seat; the scripts expect the requirement.
- HPCAd 22/36/63 expected statuses contradict each other; the common priority pattern is used.
- EPS voltage cases give status 0x08 for active, healed and historic; the DTC list (warning lamp 1) and
  the FR_ZONE / VCU cases give 0x8B / 0x0A / 0x08 (configurable: `CANC_VOLTAGE_DTC_STATUS_KEYS`).
- SCF cases quote a 10-cycle qualification; config and the NM sheet give 60 (the longer wait is used).
- FR_ZONE 39-50 and HPCAd 22 steps are copied from other cases; the scripts follow description and
  preconditions.
- Diagnostic cases expect `62 01 02` for `22 01 01`; ISO 14229-1 echoes the DID (`62 01 01`).
- 13C 135 expects `61 01 02 33`; the ISO 14229-1 positive response to `31 01 02 33` is `71 01 02 33`.
- 13C 82 repeats case 81's seat combination but expects 0x7 (RESERVED in the DBC); kept as written.
- 13C 88/90 call OCS_PASS_CLASS default 0x1; the DBC default is 0x0.
- 13C 26 sets -20 degC and expects 20 degC; bus-off 4/12 give a 100 ms slow recovery (config: 500 ms).
- 13C 91/92 currents are swapped against the bench note (6 mA zone 2, 14 mA zone 1).
- Bus-off 1 expects only D20600 although both buses are bus-off (cases 6/7 expect both); bus-off 2 and
  13 expect the lamp ON for D27100, which has warning lamp 0; bus-off 16 names the CAN-FD channel but
  reads D27100 while the bus-off is active (the script uses HS-CAN).
- 2C0 12 expects a left-crash signature for a near crash and NEAR_CRASH in SRS1_20, which does not
  carry it; 2C0 22-26 name belt signals only SRS1_FD_10 carries; 2C0 15 / 13C 53 expect parity 1
  throughout a crash (graded against byte 0 instead).
- 13C 49/50 expect IGN_STS_SRS = 2 with the hardware IGN ON and a CAN wake source added; the ignition has
  priority (your instruction, 2026-10-16), so the scripts expect 1 (IGN ON due to HW), which the ECU sent
  on 2026-10-15. The case text needs the correction.

## Bus-off recovery (additional check)

The M314 ARIA relay map gives the loadbox function CAN1 the presets OPEN, CAN_BUSS_OFF, CAN_BUSS_HI_ON,
CAN_BUSS_Lo_ON and INHERENT (CAN2 only OPEN / INHERENT; `.github/agents/aria_agent.md` 5.1), set with the
shared `ARIA.AFT_iLoadBoxWrapper`. `CANC_BUSOFF_Fast_Slow_Recovery.py` first finds which bus CAN1 carries
(the ECU frame that stops), then releases the bus-off at set hold times: one in the middle of each of the
`BUSOFF_FAST_RECOVERY_COUNT` (5) fast intervals of `BUSOFF_FAST_RECOVERY_TIME_MS` (100 ms), and five across
the first slow interval of `BUSOFF_SLOW_RECOVERY_TIME_MS` (500 ms). Retries cannot be seen while the bus is
shorted, but the bus stays silent after the release until the ECU's next retry, so the release-to-first-
frame time shows where the retries fall: 50 ms in each fast probe, then 450, 350, 250, 150 and 50 ms. Each
probe is graded within 10 % of its retry interval and `CAN_BUS_OFF_RELAY_SWITCH_MS` (10 ms, assumed), the
upper limit plus two frame periods (the bus-off starts at the ECU's next transmission; the first frame
after a retry). The bus-off DTC of that bus is then expected healed (it sets immediately, per the fault
list) and both ECU frames back.

## Assumptions to confirm on the bench

- Wrong DLC = the simulated frame itself given the shorter payload with `CAN.SetPeriodicFrame` on its own
  name (ARIA's change-payload); confirm the frame goes out with the shorter length. The reload that heals
  it is timed on the bus (see item 4).
- PKE wake values 1, 2, 3 and 4 (your instruction, 2026-10-16): the CAN wakeup cases check each.
- Measurement lag 60 ms (`FAULT_TIME_MEASUREMENT_LAG_MS`, derived from the 2026-10-15 logs): run
  `CANC_DTC_Read_Timing.py` once on the bench; raise the value if it measures more.
- Bus-off relay: CAN1 = CAN_BUSS_OFF puts a bus-off on one bus (the script finds which); the relay
  switching allowance of 10 ms.
- Occupant counts settle within `CANC_OCCUPANT_COUNT_SETTLE_MS` (10 s; 7.5 s seen).
- IMU static bands, motion swings, IMU_TEMP tolerance and the SRS_DELTA_V / EDR delta-V band.
- ODS adult load `100R`; belt cross-connect = both belt channels on load `BUS` without the leakage.
- OCS enabled through the variant code for the occupancy cases (default variant code has it off);
  E-Call enabling (13C 102-112 preconditions) is not in `manage_variant_code` and is taken as default.
- CRC (confirmed on the 2026-10-15 logs): SRS1_20 = CRC8_SAE_J1850 (poly 0x1D, init 0xFF, final XOR
  0xFF) over bytes 0-6, no Data ID - all SRS1_20 frames; CAN-FD frames = E2E Profile 5, CRC16_CCITT_FALSE
  (poly 0x1021, init 0xFFFF) over bytes 0-57 and 60 then the Data ID = the frame's CAN identifier (low
  byte first) - all 623,598 distinct SRS1_FD_10 frames the ECU sent. CRC16_CCIT_ZERO (same polynomial,
  init 0x0000) matches none of them, with or without the Data ID; the script still takes it as an input
  (`py -3.14 CANC_CRC_Check_All_Messages.py CRC16_CCIT_ZERO`). The VCU frames were not on the bus that day
  and are taken to follow the same rule.

## canc_config additions (block `CANC COMMUNICATION TEST SETTINGS`, appended after the EDR block)

HPCC_24_500 supervision (node HPCC, D16000 / D05A00); DLC-only content DTC (VCU4_FD_1500 -> E72700) and
wrong-DLC lengths; PKE wake values (1, 2, 3, 4) and sleep value; bus-off DTCs, status keys, operator
windows, the bus-off relay (function CAN1, loads CAN_BUSS_OFF / INHERENT), the probe settle time and the
relay switching allowance; voltage levels and status keys; the measurement lag of faultTimeMeasurement
(`FAULT_TIME_MEASUREMENT_LAG_MS`, 60 ms) and the samples `CANC_DTC_Read_Timing` takes; the longest
faultTimeMeasurement poll (`FAULT_TIME_MEASUREMENT_TIMEOUT_MS`, 101 s - a name the shared function itself
reads from canc_config); timing-check counts; lamp proveout and crash hold
times; belt init window; settle times (DCS, OCS and, since the bench run, the occupant counts:
`CANC_OCCUPANT_COUNT_SETTLE_MS`); signal start bits for decoding logged frames; SRS1_20 CRC and
reserved-bit masks; ODS/STPS loads, channel maps and the DCS fault load `BUS`; crash curve keys,
crash-location labels and deployment-status expectations; IMU expectations; warning-lamp DID; HS alive
counter range per EOL bit; supply-off time; comm-control speed; tester-present period; loop squib.
A second block, `CANC CRC CHECK SETTINGS`, holds the CRC catalogue (every CRC RevEng CRC-8/CRC-16 with its
check value and its other names, the calculator presets among them), the CRC in use per width and the
covered bytes / Data ID of each frame with a CRC (the Data IDs, the frames' CAN identifiers, were set
after the bench logs confirmed them).
Only these two blocks were added or changed; nothing that existed before was edited and
`shared_libraries` is untouched.

## Other observations (not changed)

`wake_ecu_over_can*` are back in `shared_libraries/core_functions.py` as at HEAD, kept as legacy
next to the shared `CAN_Wakeup()` / `CAN_Wakeup_Restore()` the EDR_CANC scripts now call
(2026-10-22); the `power_config` voltage constants are back for reference. `vin_config` does not import
(NameError READ_SID).
"""


def _natural(name: str) -> list:
    return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", name)]


def write_gap_report(scripts: list[Script]):
    from collections import Counter
    counts = Counter(sc.automation for sc in scripts)
    by_note: dict[str, list[str]] = {}
    for sc in scripts:
        for note in sc.notes:
            by_note.setdefault(note, []).append(sc.case.name)
    lines = [GAP_REPORT_HEAD.format(total=len(scripts)), "## Automation summary", "",
             "| Automation | Scripts |", "|---|---|"]
    lines += [f"| {label} | {count} |" for label, count in counts.most_common()]
    lines += ["", "## Cases that are not fully automatic", "", "| Case | Codebeamer ID | Automation |", "|---|---|---|"]
    for sc in sorted(scripts, key=lambda item: (item.case.workbook, _natural(item.case.name))):
        if sc.automation != "Automatic":
            lines.append(f"| {sc.case.name} | {sc.case.case_id} | {sc.automation} |")
    lines += ["", "## Script notes by topic", "",
              "Each note is also in the header of the scripts it applies to.", ""]
    for note, names in sorted(by_note.items(), key=lambda item: (-len(item[1]), item[0])):
        lines.append(f"- {note}")
        lines.append(f"  - Applies to ({len(names)}): {', '.join(sorted(names, key=_natural))}")
    GAP_REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Batch runners
# ---------------------------------------------------------------------------

# The scripts that are not fully automatic, by what the bench needs, in the order
# the non-automatic runner takes them: (group, prompt, title, automation labels).
# Prompt "operator" waits for Enter before each script, "confirm" wants "yes" and
# "none" runs straight on. Plant mode goes last because it changes the ECU for good.
RUNNER_GROUPS = [
    ("bus-off", "operator",
     "Bus-off: short CAN-H to CAN-L, or hold a bus-off with the CAN stress tool, when the script says",
     ["Semi-automatic (operator creates and removes the bus-off)",
      "Semi-automatic (operator holds the bus-off; recovery timing evaluated from the saved log)"]),
    ("ecu-motion", "operator", "ECU motion: move, tilt or shake the ECU when the script says",
     ["Semi-automatic (operator moves the ECU)", "Semi-automatic (operator shakes the ECU)"]),
    ("ecu-fault", "operator", "ECU faults no shared-library call creates: inject and remove them when the script says",
     ["Semi-automatic (no IMU fault-injection method or EVT exists for the Panasonic IMU)",
      "Semi-automatic (operator forces low-power mode)",
      "Semi-automatic (no shared-library call injects an internal MCAL fault)"]),
    ("thermal", "operator", "Thermal chamber: set the chamber when the script says and let the ECU soak",
     ["Manual environment (thermal chamber), automatic check"]),
    ("partial", "none", "Partly automatic: no zone 3 current preset, the rest of the case runs",
     ["Partly automatic (zone 3 current not available)"]),
    ("approximated", "none", "Automatic, with the ECU/OPS states approximated by supply transitions",
     ["Automatic (ECU/OPS states approximated by supply transitions)"]),
    ("bench-hardware", "none",
     "Need the ARIA SPI sensor card (crash curves) or the EVT sheets, both missing on the 2026-10-15 bench",
     [SPI_CARD_LABEL, EVT_LABEL]),
    ("crash-curves", "none", "Blocked until the crash curves are delivered: each reports the missing curves and stops",
     ["Automatic once the near-crash curves are delivered (blocked until then)",
      "Automatic once the rollover crash curves are delivered (blocked until then)",
      "Automatic once the PT-only crash curves are delivered (blocked until then)",
      "Automatic once the multi-event crash curves are delivered (blocked until then)"]),
    ("not-executable", "none", "Not executable (hard constraint): each reports what is missing and stops",
     ["Not executable (hard constraint)"]),
    ("plant-mode", "confirm", "Plant mode, one run per software flash: the learned phase of life changes for good",
     ["Automatic (irreversible: changes the learned phase of life)"]),
]

RUNNER_HEAD = r'''"""@TITLE@

Author: Kris

@INTRO@

@USAGE@

Each script runs in its own Python process and writes its own ARIA report under
test_results/M310_M314_M110/<date>/. The status shown for a script is the verdict apym
writes on the last line of that report (<!--PASSED--> or <!--FAILED-->); ERROR means the
script crashed or left no verdict. Results go to @RESULTS@, rewritten
after every script so an interrupted run keeps what finished. Ctrl+C stops the run once
the current script has finished its own cleanup.

These scripts drive a bench. Run them only against a rig you are authorized to use.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
FRAMEWORK_ROOT = SCRIPT_DIR.parents[4]
REPORT_DIR = FRAMEWORK_ROOT / "test_results" / SCRIPT_DIR.parents[2].name
RESULTS_FILE = SCRIPT_DIR / "@RESULTS@"
'''

RUNNER_COMMON = r'''

def finish_selection(arguments, selected, missing):
    if missing:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for name in missing:
            print("- " + name)
        print()
    if arguments.start_from:
        names = [path.stem for path in selected]
        start = arguments.start_from.removesuffix(".py")
        if start not in names:
            print("--start-from " + arguments.start_from + " is not one of the selected scripts.")
            return None
        selected = selected[names.index(start):]
    return selected


def build_environment():
    env = os.environ.copy()
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(FRAMEWORK_ROOT.parent) + (os.pathsep + existing if existing else "")
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def read_report(path, started):
    """The report this run of the script wrote, the verdict apym put on its last
    line and the passed/total step count beside it."""
    report_name = re.compile(re.escape(path.stem) + r"_\d{8}_\d{6}\.html")
    reports = [report for report in REPORT_DIR.glob("*/" + path.stem + "_*.html")
               if report_name.fullmatch(report.name) and report.stat().st_mtime >= started - 2]
    if not reports:
        return None, None, None
    report = max(reports, key=os.path.getmtime)
    with open(report, "rb") as handle:
        handle.seek(0, os.SEEK_END)
        handle.seek(max(0, handle.tell() - 512))
        tail = handle.read().decode("utf-8", "replace")
    verdict = re.search(r"<!--(PASSED|FAILED)-->\s*$", tail)
    steps = re.search(r'id="successStepsCount">(\d+/\d+)<', tail)
    return report, verdict.group(1) if verdict else None, steps.group(1) if steps else None


def run_script(path, env):
    """Run one script in its own Python process and show its output as it comes,
    so an operator instruction appears the moment the script prints it."""
    started = time.time()
    process = subprocess.Popen([sys.executable, "-u", str(path)], cwd=str(SCRIPT_DIR), env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               encoding="utf-8", errors="replace")
    output, interrupted = [], False
    while True:
        try:
            for line in process.stdout:
                print(line, end="", flush=True)
                output.append(line)
            exit_code = process.wait()
            break
        except KeyboardInterrupt:
            # The script gets the same Ctrl+C and runs its own cleanup; keep reading
            # until it ends so that cleanup is not cut off.
            interrupted = True
            print("\nCtrl+C: stopping once " + path.name + " has cleaned up.", flush=True)
    report, verdict, steps = read_report(path, started)
    if interrupted:
        status = "INTERRUPTED"
    elif verdict and exit_code == 0:
        status = verdict
    else:
        status = "ERROR"
    result = {"status": status, "exit_code": exit_code, "steps_passed": steps,
              "minutes": round((time.time() - started) / 60, 1), "report": str(report) if report else None}
    if status != "PASSED":
        result["output_tail"] = [line.rstrip("\n") for line in output[-40:]]
    print(status + ": " + path.name + " (" + (steps + " steps passed" if steps else "no verdict") + ", "
          + str(result["minutes"]) + " min)")
    if report:
        print("Report: " + str(report))
    return result


def save_results(run):
    run["finished"] = datetime.now().isoformat(timespec="seconds")
    RESULTS_FILE.write_text(json.dumps(run, indent=2), encoding="utf-8")


def print_summary(run):
    results = run["results"]
    counts = {}
    for result in results.values():
        counts[result["status"]] = counts.get(result["status"], 0) + 1
    print("=" * 100)
    print("Ran " + str(len(results)) + " script(s): "
          + (", ".join(str(count) + " " + status for status, count in sorted(counts.items())) or "none"))
    for name, result in results.items():
        if result["status"] != "PASSED":
            print("  " + result["status"].ljust(11) + " " + name
                  + ("  " + result["report"] if result.get("report") else ""))
    print("Results written to " + str(RESULTS_FILE))
'''

RUNNER_AUTO_MAIN = r'''

def select_scripts(arguments):
    selected, missing = [], []
    for name in SCRIPT_FILES:
        if arguments.only and arguments.only.lower() not in name.lower():
            continue
        path = SCRIPT_DIR / name
        if path.is_file():
            selected.append(path)
        else:
            missing.append(name)
    return finish_selection(arguments, selected, missing)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--only", help="run the scripts whose name contains this text")
    parser.add_argument("--start-from", help="skip the selected scripts before this one, to resume a run")
    parser.add_argument("--stop-on-fail", action="store_true", help="stop at the first script that does not pass")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    scripts = select_scripts(arguments)
    if scripts is None:
        return 2
    if arguments.list:
        for path in scripts:
            print(path.name)
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    env = build_environment()
    run = {"runner": Path(__file__).name, "started": datetime.now().isoformat(timespec="seconds"), "results": {}}
    try:
        for index, path in enumerate(scripts, 1):
            print("=" * 100)
            print("[" + str(index) + "/" + str(len(scripts)) + "] " + path.name)
            print("=" * 100)
            result = run_script(path, env)
            run["results"][path.name] = result
            save_results(run)
            if result["status"] == "INTERRUPTED" or (arguments.stop_on_fail and result["status"] != "PASSED"):
                break
    except KeyboardInterrupt:
        print("\nStopped.")
    save_results(run)
    print_summary(run)
    results = run["results"].values()
    return 0 if results and all(result["status"] == "PASSED" for result in results) else 1


if __name__ == "__main__":
    sys.exit(main())
'''

RUNNER_MANUAL_MAIN = r'''

def select_scripts(arguments):
    selected, missing = [], []
    for name in SCRIPT_FILES:
        if arguments.only and arguments.only.lower() not in name.lower():
            continue
        if arguments.group and SCRIPT_INFO[name][0] != arguments.group:
            continue
        path = SCRIPT_DIR / name
        if path.is_file():
            selected.append(path)
        else:
            missing.append(name)
    return finish_selection(arguments, selected, missing)


def ask(prompt):
    """Wait for the operator before a script that needs one: run, skip or stop."""
    if prompt == "operator":
        question = "Bench ready for this script? Enter = run, s = skip, q = stop: "
    elif prompt == "confirm":
        question = "This cannot be undone on this software flash. Type yes to run, s = skip, q = stop: "
    else:
        return "run"
    while True:
        try:
            answer = input(question).strip().lower()
        except EOFError:
            return "stop"
        if answer in ("s", "skip"):
            return "skip"
        if answer in ("q", "quit", "stop"):
            return "stop"
        if (prompt == "operator" and answer == "") or (prompt == "confirm" and answer == "yes"):
            return "run"


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--group", choices=list(GROUPS), help="run one group only")
    parser.add_argument("--only", help="run the scripts whose name contains this text")
    parser.add_argument("--start-from", help="skip the selected scripts before this one")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    scripts = select_scripts(arguments)
    if scripts is None:
        return 2
    if arguments.list:
        for path in scripts:
            group, automation, objective = SCRIPT_INFO[path.name]
            print(path.name.ljust(30) + " [" + group + "] " + automation)
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    env = build_environment()
    run = {"runner": Path(__file__).name, "started": datetime.now().isoformat(timespec="seconds"), "results": {}}
    current_group = None
    try:
        for index, path in enumerate(scripts, 1):
            group, automation, objective = SCRIPT_INFO[path.name]
            prompt, title = GROUPS[group]
            if group != current_group:
                current_group = group
                members = [item for item in scripts if SCRIPT_INFO[item.name][0] == group]
                print()
                print("#" * 100)
                print("# " + title + " (" + str(len(members)) + " script(s))")
                print("#" * 100)
            print("=" * 100)
            print("[" + str(index) + "/" + str(len(scripts)) + "] " + path.name)
            print("Objective : " + objective)
            print("Automation: " + automation)
            print("=" * 100)
            choice = ask(prompt)
            if choice == "stop":
                break
            if choice == "skip":
                run["results"][path.name] = {"status": "SKIPPED", "group": group}
                print("SKIPPED: " + path.name)
            else:
                run["results"][path.name] = dict(run_script(path, env), group=group)
            save_results(run)
            if run["results"][path.name]["status"] == "INTERRUPTED":
                break
    except KeyboardInterrupt:
        print("\nStopped.")
    save_results(run)
    print_summary(run)
    results = run["results"].values()
    return 0 if results and all(result["status"] == "PASSED" for result in results) else 1


if __name__ == "__main__":
    sys.exit(main())
'''


def _runner_source(title: str, intro: str, usage: str, results: str, tables: list[str], main: str) -> str:
    head = RUNNER_HEAD
    for key, value in (("TITLE", title), ("INTRO", intro), ("USAGE", usage), ("RESULTS", results)):
        head = head.replace(f"@{key}@", value)
    return head + "\n" + "\n\n".join(tables) + "\n" + RUNNER_COMMON + main


def _script_files(sections: list[tuple[str, list[Script]]]) -> str:
    lines = ["# Comment out a line to skip that script.", "SCRIPT_FILES = ["]
    for title, members in sections:
        lines.append(f"    # {title} ({len(members)})")
        lines += [f'    "{sc.case.name}.py",' for sc in members]
    lines.append("]")
    return "\n".join(lines)


def write_runners(scripts: list[Script], extras: list[Script]):
    """The fully automatic scripts in one runner, the rest in another grouped by
    what the bench needs; every case script is in exactly one of them. The
    additional checks (extras), all automatic, close the automatic runner."""
    group_of = {label: group for group, _, _, labels in RUNNER_GROUPS for label in labels}
    unknown = sorted({sc.automation for sc in scripts} - set(group_of) - {"Automatic"})
    if unknown:
        raise ValueError(f"automation labels with no runner group: {unknown}")
    if any(sc.automation != "Automatic" for sc in extras):
        raise ValueError("an additional check that is not automatic has no runner")
    ordered = sorted(scripts, key=lambda item: (item.case.workbook, _natural(item.case.name)))
    automatic = [sc for sc in ordered if sc.automation == "Automatic"]
    by_workbook: dict[str, list[Script]] = {}
    for sc in automatic:
        by_workbook.setdefault(sc.case.workbook, []).append(sc)
    groups = [(group, prompt, title, [sc for sc in ordered if group_of.get(sc.automation) == group])
              for group, prompt, title, _ in RUNNER_GROUPS]
    groups = [entry for entry in groups if entry[3]]
    manual = [sc for entry in groups for sc in entry[3]]
    if len(automatic) + len(manual) != len(scripts):
        raise ValueError("the runners do not cover every script exactly once")

    auto_name, manual_name = AUTO_RUNNER.name, MANUAL_RUNNER.name
    extra_names = ", ".join(sc.case.name for sc in extras)
    auto_source = _runner_source(
        "Run the fully automatic M310_M314_M110 CAN-C scripts.",
        textwrap.fill(
            f"{len(automatic)} of the {len(scripts)} CAN-C case scripts need nobody at the bench; this runner runs "
            f"them one after another without stopping"
            + (f", then the additional check{'s' if len(extras) > 1 else ''} {extra_names}" if extras else "")
            + f". The other {len(manual)} case scripts (operator actions, missing crash curves, plant mode, not "
            f"executable) are in {manual_name}.", width=92),
        "\n".join([
            f"    py -3.14 {auto_name}                                  # everything uncommented",
            f"    py -3.14 {auto_name} --only CANC_VCU                  # name contains CANC_VCU",
            f"    py -3.14 {auto_name} --start-from CANC_VCU_TestCase10 # resume a run there",
            f"    py -3.14 {auto_name} --stop-on-fail                   # stop at the first non-pass",
            f"    py -3.14 {auto_name} --list                           # show what would run",
        ]),
        "canc_automatic_results.json",
        [_script_files([(workbook, members) for workbook, members in by_workbook.items()]
                       + ([("Additional checks", extras)] if extras else []))],
        RUNNER_AUTO_MAIN)

    group_lines = [f"    {group:<15} {len(members):>3}  {title}" for group, _, title, members in groups]
    groups_table = ["# Group: (prompt before each script, what the bench needs). Prompt \"operator\" waits",
                    "# for Enter, \"confirm\" wants \"yes\", \"none\" runs straight on.", "GROUPS = {"]
    groups_table += [f"    {py(group)}: ({py(prompt)}, {py(title)})," for group, prompt, title, _ in groups]
    groups_table.append("}")
    info_table = ["# Group, automation and objective of each script.", "SCRIPT_INFO = {"]
    for group, _, _, members in groups:
        for sc in members:
            objective = " ".join(sc.case.description.split())
            if len(objective) > 150:
                objective = objective[:147].rstrip() + "..."
            info_table.append(f'    "{sc.case.name}.py": (')
            info_table.append(f"        {py(group)}, {py(sc.automation)},")
            info_table.append(f"        {py(objective)}),")
    info_table.append("}")
    manual_source = _runner_source(
        "Run the M310_M314_M110 CAN-C scripts that are not fully automatic.",
        f"The {len(manual)} CAN-C scripts that are not fully automatic, grouped by what the bench needs.\n"
        "Before each script that needs an operator the runner waits for Enter (s skips, q stops);\n"
        "the scripts print each operator instruction while they run and wait a set time for it.\n"
        "The plant-mode scripts change the ECU for good and run only after \"yes\". The blocked and\n"
        "not-executable scripts run without a prompt: each reports what is missing and stops\n"
        f"before acting on the bench. The fully automatic scripts are in {auto_name}.\n\n"
        "Groups, in the order they run:\n" + "\n".join(group_lines),
        "\n".join([
            f"    py -3.14 {manual_name}                            # every group, in order",
            f"    py -3.14 {manual_name} --group bus-off            # one group",
            f"    py -3.14 {manual_name} --only 13C                 # name contains 13C",
            f"    py -3.14 {manual_name} --start-from CAN_BUSOFF_5  # skip the ones before",
            f"    py -3.14 {manual_name} --list                     # show what would run",
        ]),
        "canc_non_automatic_results.json",
        ["\n".join(groups_table), _script_files([(f"{group}: {title}", members) for group, _, title, members in groups]),
         "\n".join(info_table)],
        RUNNER_MANUAL_MAIN)

    for path, source in ((AUTO_RUNNER, auto_source), (MANUAL_RUNNER, manual_source)):
        compile(source, str(path), "exec")
        path.write_text(source, encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main(sys.argv))
