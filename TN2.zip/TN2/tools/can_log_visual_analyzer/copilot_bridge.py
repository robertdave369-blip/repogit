"""Opt-in, sanitized bridge to an authenticated local GitHub Copilot CLI.

The bridge deliberately gives Copilot no source capture, payload, DBC,
configuration, local path, or credential data. It provides an aggregate
analysis summary only after the user reviews and confirms the exact prompt.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from collections import Counter
from pathlib import Path
from typing import Any


class CopilotBridgeError(RuntimeError):
    """A user-visible Copilot bridge error that must not be hidden by the UI."""


def build_sanitized_prompt(
    question: str,
    overview: dict[str, Any],
    findings: list[dict[str, Any]],
    fault_event_count: int,
    dtc_record_count: int,
    configuration_summary: dict[str, Any],
) -> str:
    """Build an aggregate-only prompt that excludes all raw engineering source data."""

    normalized_question = question.strip()
    if not normalized_question:
        raise ValueError("Enter a Copilot analysis question.")
    if len(normalized_question) > 4_000:
        raise ValueError("Copilot analysis questions are limited to 4,000 characters.")
    category_counts = Counter(
        str(finding.get("category", "Unclassified finding"))
        for finding in findings
    )
    selected_overview = {
        key: overview.get(key, 0)
        for key in (
            "total_parsed_frames",
            "capture_duration_ms",
            "active_channels",
            "unique_observed_ids",
            "dbc_matched_ids",
            "unknown_ids",
            "timing_anomalies",
            "potential_stopped_gaps",
            "potential_timeout_qualifications",
            "potential_node_absence_events",
            "recorded_dtc_status_records",
        )
    }
    lines = [
        "You are assisting an engineer who is using a local, analysis-only CAN/ECU evidence workspace.",
        "The original capture, payload bytes, CAN IDs, timestamps, source lines, DBC data, configuration files,",
        "local file paths, and credentials are not available to you and must not be requested or inferred.",
        "Do not recommend live CAN transmission, ECU configuration, diagnostics, DTC clearing, flashing,",
        "or vehicle safety changes. Distinguish observed evidence, configured-model results, and unknowns.",
        "",
        "The user explicitly opted in to send this aggregate-only question:",
        normalized_question,
        "",
        "Aggregate local analysis summary (no raw source data):",
        *[f"- {key}: {value}" for key, value in selected_overview.items()],
        f"- configured fault-event candidates: {fault_event_count}",
        f"- recorded UDS DTC-status records: {dtc_record_count}",
        f"- configuration audit checks: {configuration_summary.get('check_count', 0)}",
        f"- configuration audit warnings: {configuration_summary.get('warning_count', 0)}",
        f"- configuration audit review items: {configuration_summary.get('review_count', 0)}",
        "- finding categories: "
        + (", ".join(f"{category} ({count})" for category, count in sorted(category_counts.items()))
           if category_counts else "none"),
        "",
        "Provide a concise, evidence-aware analysis approach. State what additional local evidence the engineer",
        "should inspect in the workspace when aggregate data cannot support a conclusion.",
    ]
    return "\n".join(lines)


def _copilot_command() -> list[str]:
    """Resolve a user-installed CLI without downloading, installing, or embedding credentials."""

    configured_path = os.environ.get("CAN_ANALYZER_COPILOT_CLI")
    candidate = configured_path or shutil.which("copilot")
    if not candidate:
        raise CopilotBridgeError(
            "GitHub Copilot CLI was not found. Install and authenticate it, or set CAN_ANALYZER_COPILOT_CLI."
        )
    executable = Path(candidate)
    if not executable.is_file():
        raise CopilotBridgeError(f"Configured Copilot CLI path was not found: {executable}")
    if executable.suffix.casefold() == ".ps1":
        powershell = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
        if not powershell.is_file():
            raise CopilotBridgeError("PowerShell is required to invoke the installed Copilot CLI wrapper.")
        return [str(powershell), "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(executable)]
    return [str(executable)]


def run_copilot_prompt(
    prompt: str,
    runtime_directory: Path,
    *,
    timeout_seconds: int = 180,
) -> str:
    """Run one reviewed prompt in an empty isolated directory and return only CLI response text."""

    if timeout_seconds <= 0:
        raise ValueError("Copilot timeout must be positive.")
    context_directory = runtime_directory / "copilot-empty-context"
    log_directory = runtime_directory / "copilot-logs"
    context_directory.mkdir(parents=True, exist_ok=True)
    log_directory.mkdir(parents=True, exist_ok=True)
    command = _copilot_command() + [
        "--prompt",
        prompt,
        "--silent",
        "--allow-all-tools",
        "--disallow-temp-dir",
        "--disable-builtin-mcps",
        "--output-format",
        "text",
        "--log-dir",
        str(log_directory),
        "-C",
        str(context_directory),
    ]
    try:
        completed = subprocess.run(
            command,
            cwd=context_directory,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
    except OSError as error:
        raise CopilotBridgeError(f"Could not start GitHub Copilot CLI: {error}") from error
    except subprocess.TimeoutExpired as error:
        raise CopilotBridgeError(
            f"GitHub Copilot CLI did not finish within {timeout_seconds} seconds."
        ) from error
    response = completed.stdout.strip()
    if completed.returncode != 0:
        detail = completed.stderr.strip() or response or f"Exit code {completed.returncode}."
        raise CopilotBridgeError(f"GitHub Copilot CLI did not complete: {detail}")
    if not response:
        raise CopilotBridgeError("GitHub Copilot CLI completed without an analysis response.")
    return response
