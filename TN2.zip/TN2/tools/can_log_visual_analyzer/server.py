"""Localhost-only HTTP API and static-file server for offline CAN analysis."""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import tempfile
import threading
import uuid
from collections import Counter, defaultdict
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from io import StringIO
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, unquote, urlparse

from .analysis import AnalysisResult, StreamAnalysis, analyze, decode_frame
from .configuration_audit import (
    CancConfiguration,
    CancCaseConfiguration,
    ConfigurationAudit,
    EdrConfiguration,
    audit_configuration,
    import_canc_configuration,
    import_canc_case_configuration,
    import_edr_configuration,
)
from .copilot_bridge import (
    CopilotBridgeError,
    build_sanitized_prompt,
    run_copilot_prompt,
)
from .dbc import DbcDatabase, dbc_message_to_dict, import_dbc_json
from .faults import FAULT_OPTIONS
from .guidance import GuidanceError, build_message_guidance
from .models import AnalysisSettings, CanFrame, IdentifierType, ParseResult
from .onfail_policy import OnFailPolicy, import_onfail_policy
from .parser import parse_aria_text


_SAFE_FILENAME = re.compile(r"[^A-Za-z0-9._-]+")
_MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024


@dataclass(slots=True)
class ImportJob:
    """Background import state reported to the UI while workers remain responsive."""

    job_id: str
    kind: str
    source_name: str
    state: str = "queued"
    progress: int = 0
    message: str = "Queued"
    error: str | None = None
    result: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Workspace:
    """Thread-safe in-memory state backed by isolated temporary input copies."""

    runtime_directory: Path
    settings: AnalysisSettings = field(default_factory=AnalysisSettings)
    target_ecu: str = ""
    parse_results: list[ParseResult] = field(default_factory=list)
    dbc_imports: list[Any] = field(default_factory=list)
    onfail_policy: OnFailPolicy | None = None
    canc_configuration: CancConfiguration | None = None
    edr_configuration: EdrConfiguration | None = None
    canc_case_configuration: CancCaseConfiguration | None = None
    configuration_audit: ConfigurationAudit = field(default_factory=ConfigurationAudit)
    result: AnalysisResult | None = None
    jobs: dict[str, ImportJob] = field(default_factory=dict)
    identifier_overrides: dict[str, IdentifierType] = field(default_factory=dict)
    revision: int = 0
    lock: threading.RLock = field(default_factory=threading.RLock)
    workers: ThreadPoolExecutor = field(
        default_factory=lambda: ThreadPoolExecutor(max_workers=2, thread_name_prefix="can-analysis")
    )

    def close(self) -> None:
        self.workers.shutdown(wait=False, cancel_futures=True)

    def _all_frames(self) -> list[CanFrame]:
        return [frame for result in self.parse_results for frame in result.frames]

    def _database(self) -> DbcDatabase:
        return DbcDatabase(self.dbc_imports)

    def reanalyse(self) -> None:
        """Analyse a consistent snapshot without holding the API-state lock.

        A concurrent import or setup change advances ``revision``. In that
        case, repeat with the new snapshot so an older result is never exposed.
        """

        while True:
            with self.lock:
                revision = self.revision
                frames = list(self._all_frames())
                database = self._database()
                target_ecu = self.target_ecu
                settings = self.settings
                overrides = dict(self.identifier_overrides)
                policy = self.onfail_policy
                canc_configuration = self.canc_configuration
                edr_configuration = self.edr_configuration
                canc_case_configuration = self.canc_case_configuration
            result = analyze(frames, database, target_ecu, settings, overrides, policy)
            configuration_audit = audit_configuration(
                canc_configuration,
                edr_configuration,
                database,
                canc_case_configuration,
            )
            with self.lock:
                if revision == self.revision:
                    self.result = result
                    self.configuration_audit = configuration_audit
                    return

    def queue_import(self, kind: str, uploaded_file: Path, source_name: str) -> ImportJob:
        """Schedule parsing/normalization outside the request-processing thread."""

        job = ImportJob(uuid.uuid4().hex, kind, source_name)
        with self.lock:
            self.jobs[job.job_id] = job
        worker: Callable[[], None]
        if kind == "log":
            worker = lambda: self._import_log(job, uploaded_file)
        elif kind == "dbc":
            worker = lambda: self._import_dbc(job, uploaded_file)
        elif kind == "onfail-policy":
            worker = lambda: self._import_onfail_policy(job, uploaded_file)
        elif kind == "canc-config":
            worker = lambda: self._import_canc_configuration(job, uploaded_file)
        elif kind == "edr-config":
            worker = lambda: self._import_edr_configuration(job, uploaded_file)
        elif kind == "canc-case-config":
            worker = lambda: self._import_canc_case_configuration(job, uploaded_file)
        else:
            raise ValueError(f"Unsupported import type '{kind}'.")
        self.workers.submit(worker)
        return job

    def _import_log(self, job: ImportJob, uploaded_file: Path) -> None:
        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 5, "Parsing ARIA/CAN text"
            parsed = parse_aria_text(uploaded_file, job.source_name)
            with self.lock:
                job.progress, job.message = 60, "Normalizing frames"
                self.parse_results.append(parsed)
                self.revision += 1
            with self.lock:
                job.progress, job.message = 75, "Analysing recorded frames"
            self.reanalyse()
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "Log import completed"
                job.result = parsed.to_dict()
        except (OSError, UnicodeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "Log import failed"

    def _import_dbc(self, job: ImportJob, uploaded_file: Path) -> None:
        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 5, "Validating DBC JSON"
            imported = import_dbc_json(uploaded_file, job.source_name)
            with self.lock:
                job.progress, job.message = 65, "Indexing DBC definitions"
                self.dbc_imports.append(imported)
                self.revision += 1
            with self.lock:
                job.progress, job.message = 75, "Analysing recorded frames"
            self.reanalyse()
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "DBC import completed"
                job.result = {
                    "source_name": imported.source_name,
                    "message_count": len(imported.messages),
                    "warning_count": len(imported.warnings),
                    "warnings": imported.warnings,
                }
        except (OSError, UnicodeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "DBC import failed"

    def _import_onfail_policy(self, job: ImportJob, uploaded_file: Path) -> None:
        """Import source-owned on-fail expectations; it never changes frame-derived evidence."""

        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 5, "Validating on-fail policy JSON"
            policy = import_onfail_policy(uploaded_file, job.source_name)
            with self.lock:
                job.progress, job.message = 65, "Linking source policy context"
                self.onfail_policy = policy
                self.revision += 1
            with self.lock:
                job.progress, job.message = 75, "Analysing recorded frames"
            self.reanalyse()
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "On-fail policy import completed"
                job.result = policy.to_dict()
        except (OSError, UnicodeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "On-fail policy import failed"

    def _import_canc_configuration(self, job: ImportJob, uploaded_file: Path) -> None:
        """Safely import declarative CAN-C source without executing it."""

        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 5, "Reading static CAN-C configuration"
            configuration = import_canc_configuration(uploaded_file, job.source_name)
            with self.lock:
                job.progress, job.message = 65, "Auditing CAN-C routes against DBC data"
                self.canc_configuration = configuration
                self.revision += 1
            self.reanalyse()
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "CAN-C configuration import completed"
                job.result = configuration.to_dict()
        except (OSError, UnicodeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "CAN-C configuration import failed"

    def _import_edr_configuration(self, job: ImportJob, uploaded_file: Path) -> None:
        """Safely import declarative EDR record metadata without executing it."""

        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 5, "Reading static EDR configuration"
            configuration = import_edr_configuration(uploaded_file, job.source_name)
            with self.lock:
                job.progress, job.message = 65, "Auditing interval and snapshot metadata"
                self.edr_configuration = configuration
                self.revision += 1
            self.reanalyse()
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "EDR configuration import completed"
                job.result = configuration.to_dict()
        except (OSError, UnicodeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "EDR configuration import failed"

    def _import_canc_case_configuration(self, job: ImportJob, uploaded_file: Path) -> None:
        """Safely import generated case-plan data for static schedule and DTC expectation checks."""

        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 5, "Reading generated CAN-C case configuration"
            configuration = import_canc_case_configuration(uploaded_file, job.source_name)
            with self.lock:
                job.progress, job.message = 65, "Auditing generated simulation cases"
                self.canc_case_configuration = configuration
                self.revision += 1
            self.reanalyse()
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "Generated case configuration import completed"
                job.result = configuration.to_dict()
        except (OSError, UnicodeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "Generated case configuration import failed"

    def update_configuration(self, payload: dict[str, Any]) -> None:
        """Apply explicit setup choices then reanalyse without altering source data."""

        with self.lock:
            if "target_ecu" in payload:
                target = payload["target_ecu"]
                if not isinstance(target, str):
                    raise ValueError("target_ecu must be a string.")
                self.target_ecu = target.strip()
            if "settings" in payload:
                raw_settings = payload["settings"]
                if not isinstance(raw_settings, dict):
                    raise ValueError("settings must be an object.")
                allowed = set(AnalysisSettings.__dataclass_fields__)
                unknown = set(raw_settings) - allowed
                if unknown:
                    raise ValueError(f"Unsupported settings: {', '.join(sorted(unknown))}.")
                values = {
                    name: float(value)
                    for name, value in raw_settings.items()
                }
                self.settings = AnalysisSettings(**{**asdict(self.settings), **values})
            if "identifier_overrides" in payload:
                overrides = payload["identifier_overrides"]
                if not isinstance(overrides, dict):
                    raise ValueError("identifier_overrides must be an object.")
                parsed: dict[str, IdentifierType] = {}
                for source_name, identifier_type in overrides.items():
                    if not isinstance(source_name, str) or not isinstance(identifier_type, str):
                        raise ValueError("Identifier overrides must map source names to identifier types.")
                    parsed[source_name] = IdentifierType(identifier_type)
                self.identifier_overrides = parsed
            self.revision += 1
        self.reanalyse()

    def status(self) -> dict[str, Any]:
        with self.lock:
            frames = self._all_frames()
            overview = self.result.overview() if self.result else {
                "total_parsed_frames": len(frames),
                "capture_duration_ms": 0,
            }
            return {
                "overview": overview,
                "settings": self.settings.to_dict(),
                "target_ecu": self.target_ecu,
                "sources": [result.to_dict() for result in self.parse_results],
                "dbc_sources": [
                    {
                        "source_name": imported.source_name,
                        "message_count": len(imported.messages),
                        "warning_count": len(imported.warnings),
                    }
                    for imported in self.dbc_imports
                ],
                "onfail_policy": self.onfail_policy.to_dict() if self.onfail_policy else None,
                "configuration_sources": {
                    "canc": self.canc_configuration.to_dict() if self.canc_configuration else None,
                    "edr": self.edr_configuration.to_dict() if self.edr_configuration else None,
                    "canc_case": self.canc_case_configuration.to_dict() if self.canc_case_configuration else None,
                },
                "configuration_audit": self.configuration_audit.to_dict()["summary"],
                "limitations": [
                    "TX and RX are capture-interface directions, not confirmed target-ECU directions.",
                    "DBC metadata may be incomplete, outdated, or for a different vehicle configuration.",
                    "No live CAN, ECU configuration, diagnostic, DTC, or vehicle-control capability is present.",
                    "Missing capture frames do not prove an ECU failed.",
                    "Qualification and recovery timestamps are configured monitor-model candidates, not proof of ECU-internal state transitions.",
                    "DTC status is available only when recorded ISO-TP UDS 0x59 diagnostic responses are present.",
                ],
            }

    def streams(self, query: dict[str, list[str]]) -> list[dict[str, Any]]:
        with self.lock:
            if not self.result:
                return []
            channel = _first(query, "channel")
            direction = _first(query, "direction")
            attribution = _first(query, "attribution")
            return [
                stream.to_dict()
                for stream in self.result.streams
                if (not channel or stream.frames[0].channel == channel)
                and (not direction or stream.frames[0].capture_direction.value == direction)
                and (not attribution or stream.attribution.classification.value == attribution)
            ]

    def stream_detail(self, stream_id: str) -> dict[str, Any] | None:
        with self.lock:
            stream = self._stream(stream_id)
            if stream is None:
                return None
            message = stream.message
            decoded_rows = [
                {
                    "timestamp": frame.timestamp,
                    "source_line": frame.source_line,
                    "payload_hex": frame.payload_hex,
                    "signals": [asdict(signal) for signal in decode_frame(frame, message)],
                }
                for frame in stream.frames[:5000]
            ]
            payload_counts = Counter(frame.payload_hex for frame in stream.frames)
            lengths = Counter((frame.declared_length, len(frame.payload)) for frame in stream.frames)
            return {
                **stream.to_dict(),
                "dbc_definition": dbc_message_to_dict(message) if message else None,
                "representative_frames": [frame.to_dict() for frame in stream.frames[:20]],
                "timing_intervals_ms": [
                    (after.timestamp - before.timestamp) * 1000
                    for before, after in zip(stream.frames, stream.frames[1:])
                ],
                "payload_distribution": [
                    {"payload_hex": payload, "count": count}
                    for payload, count in payload_counts.most_common(25)
                ],
                "length_distribution": [
                    {"declared_length": declared, "parsed_byte_count": parsed, "count": count}
                    for (declared, parsed), count in sorted(lengths.items())
                ],
                "decoded_samples": decoded_rows[:5000],
                "decoded_sample_limit": 5000,
                "decoded_source_frame_count": len(stream.frames),
                "decoding_limitations": [
                    "Signals are decoded only for one unambiguous, valid DBC match.",
                    "Missing payload bytes are not padded.",
                    "No CRC, counter, checksum, reserved-value, E2E, or invalid-value inference is performed.",
                ],
            }

    def frames(self, query: dict[str, list[str]]) -> dict[str, Any]:
        with self.lock:
            frames = self._all_frames()
            channel, direction, stream_id = (
                _first(query, "channel"),
                _first(query, "direction"),
                _first(query, "stream_id"),
            )
            start, end = _float_query(query, "start"), _float_query(query, "end")
            if stream_id:
                stream = self._stream(stream_id)
                frames = stream.frames if stream else []
            frames = [
                frame
                for frame in frames
                if (not channel or frame.channel == channel)
                and (not direction or frame.capture_direction.value == direction)
                and (start is None or frame.timestamp >= start)
                and (end is None or frame.timestamp <= end)
            ]
            frames.sort(key=lambda frame: (frame.timestamp, frame.source_order))
            offset = max(0, int(_first(query, "offset") or "0"))
            limit = min(10_000, max(1, int(_first(query, "limit") or "250")))
            return {
                "total": len(frames),
                "offset": offset,
                "limit": limit,
                "frames": [frame.to_dict() for frame in frames[offset : offset + limit]],
            }

    def timeline(self, query: dict[str, list[str]]) -> dict[str, Any]:
        """Return exact markers for focused traffic or explicit density bins for large ranges."""

        with self.lock:
            if not self.result:
                return {"mode": "exact", "frame_count": 0, "lanes": []}
            channel, direction = _first(query, "channel"), _first(query, "direction")
            start, end = _float_query(query, "start"), _float_query(query, "end")
            selected = [
                stream
                for stream in self.result.streams
                if (not channel or stream.frames[0].channel == channel)
                and (not direction or stream.frames[0].capture_direction.value == direction)
            ]
            frames = [
                (stream, frame)
                for stream in selected
                for frame in stream.frames
                if (start is None or frame.timestamp >= start) and (end is None or frame.timestamp <= end)
            ]
            if not frames:
                return {"mode": "exact", "frame_count": 0, "lanes": []}
            min_time = min(frame.timestamp for _, frame in frames)
            max_time = max(frame.timestamp for _, frame in frames)
            if len(frames) <= 10_000:
                lanes: dict[str, list[dict[str, Any]]] = defaultdict(list)
                for stream, frame in frames:
                    lanes[stream.stream_id].append(
                        {
                            "timestamp": frame.timestamp,
                            "can_id_hex": frame.can_id_hex,
                            "capture_direction": frame.capture_direction.value,
                            "payload_hex": frame.payload_hex,
                            "message_name": stream.message.name if stream.message else None,
                            "attribution": stream.attribution.classification.value,
                        }
                    )
                return {
                    "mode": "exact",
                    "frame_count": len(frames),
                    "start": min_time,
                    "end": max_time,
                    "lanes": [
                        {"stream_id": stream.stream_id, "label": _stream_label(stream), "frames": lanes[stream.stream_id]}
                        for stream in selected
                        if stream.stream_id in lanes
                    ],
                }
            resolution = min(1_000, max(50, int(_first(query, "bins") or "200")))
            span = max(max_time - min_time, 1e-9)
            bins: dict[str, list[int]] = {
                stream.stream_id: [0] * resolution for stream in selected
            }
            for stream, frame in frames:
                bucket = min(resolution - 1, int((frame.timestamp - min_time) / span * resolution))
                bins[stream.stream_id][bucket] += 1
            return {
                "mode": "binned",
                "frame_count": len(frames),
                "start": min_time,
                "end": max_time,
                "bin_count": resolution,
                "lanes": [
                    {"stream_id": stream.stream_id, "label": _stream_label(stream), "bins": bins[stream.stream_id]}
                    for stream in selected
                    if any(bins[stream.stream_id])
                ],
                "notice": "Density bins summarize every source frame in this view; raw frames remain available through the frame table and exports.",
            }

    def findings(self, query: dict[str, list[str]]) -> list[dict[str, Any]]:
        with self.lock:
            if not self.result:
                return []
            category = _first(query, "category")
            severity = _first(query, "severity")
            return [
                finding.to_dict()
                for finding in self.result.findings
                if (not category or finding.category == category)
                and (not severity or finding.severity == severity)
            ]

    def fault_events(self) -> list[dict[str, Any]]:
        """Expose configured monitor transitions separately from generic anomaly findings."""

        with self.lock:
            return [event.to_dict() for event in self.result.fault_events] if self.result else []

    def dtc_records(self) -> list[dict[str, Any]]:
        """Expose only DTC/status records decoded from passive, recorded UDS responses."""

        with self.lock:
            return [record.to_dict() for record in self.result.dtc_records] if self.result else []

    def fault_options(self) -> dict[str, Any]:
        """Describe every supported fault family and its evidentiary boundary."""

        with self.lock:
            return {
                "options": [option.to_dict() for option in FAULT_OPTIONS],
                "policy": self.onfail_policy.to_dict() if self.onfail_policy else None,
            }

    def configuration_checks(self) -> dict[str, Any]:
        """Expose static source/DBC consistency results separately from capture findings."""

        with self.lock:
            return self.configuration_audit.to_dict()

    def message_guidance(
        self,
        can_id: str,
        fault_family: str,
        signal_name: str | None,
    ) -> dict[str, Any]:
        """Build a focused local guidance report without sending a prompt or changing source data."""

        with self.lock:
            frames = list(self._all_frames())
            database = self._database()
            canc = self.canc_configuration
            policy = self.onfail_policy
            settings = self.settings
        return build_message_guidance(
            can_id,
            fault_family,
            signal_name,
            frames,
            database,
            canc,
            policy,
            settings,
        )

    def copilot_preview(self, question: str) -> dict[str, Any]:
        """Build the exact reviewed Copilot prompt without contacting GitHub Copilot."""

        with self.lock:
            overview = self.result.overview() if self.result else {}
            findings = self.findings({})
            prompt = build_sanitized_prompt(
                question,
                overview,
                findings,
                len(self.result.fault_events) if self.result else 0,
                len(self.result.dtc_records) if self.result else 0,
                self.configuration_audit.to_dict()["summary"],
            )
        return {
            "prompt": prompt,
            "disclosure": [
                "Only your question and the displayed aggregate counts/categories will be sent to authenticated GitHub Copilot.",
                "No raw capture lines, payload bytes, CAN IDs, timestamps, DBC/configuration contents, local paths, or credentials are included.",
                "Copilot runs in an empty, temporary local working directory with built-in MCP disabled.",
                "Copilot inference requires GitHub/Copilot network access; this request is independent from offline parsing and decoding.",
            ],
        }

    def queue_copilot_query(self, question: str, confirmed: bool) -> ImportJob:
        """Queue one explicit, reviewed Copilot request without passing raw engineering artifacts."""

        if confirmed is not True:
            raise ValueError("Confirm the displayed Copilot data-sharing disclosure before sending a request.")
        preview = self.copilot_preview(question)
        job = ImportJob(uuid.uuid4().hex, "copilot-analysis", "Sanitized Copilot analysis")
        with self.lock:
            self.jobs[job.job_id] = job
        self.workers.submit(self._run_copilot_query, job, preview["prompt"])
        return job

    def _run_copilot_query(self, job: ImportJob, prompt: str) -> None:
        """Invoke the installed CLI asynchronously after the user confirms the exact prompt."""

        try:
            with self.lock:
                job.state, job.progress, job.message = "running", 10, "Starting authenticated Copilot CLI"
            response = run_copilot_prompt(prompt, self.runtime_directory)
            with self.lock:
                job.state, job.progress, job.message = "completed", 100, "Copilot analysis completed"
                job.result = {"response": response}
        except (CopilotBridgeError, ValueError) as error:
            with self.lock:
                job.state, job.error, job.message = "failed", str(error), "Copilot analysis failed"

    def explorer(self) -> list[dict[str, Any]]:
        """Summarise unknown, non-associated, and ambiguous streams without guessing purpose."""

        with self.lock:
            if not self.result:
                return []
            selected = {
                "Unknown CAN ID",
                "DBC-known, not associated with selected ECU",
                "Ambiguous DBC match",
            }
            rows: list[dict[str, Any]] = []
            for stream in self.result.streams:
                if stream.attribution.classification.value not in selected:
                    continue
                payloads = [frame.payload_hex for frame in stream.frames]
                changes = sum(left != right for left, right in zip(payloads, payloads[1:]))
                rows.append(
                    {
                        "stream_id": stream.stream_id,
                        "can_id_hex": stream.frames[0].can_id_hex,
                        "channel": stream.frames[0].channel,
                        "capture_direction": stream.frames[0].capture_direction.value,
                        "count": len(stream.frames),
                        "first_timestamp": stream.frames[0].timestamp,
                        "last_timestamp": stream.frames[-1].timestamp,
                        "observed_lengths": sorted({len(frame.payload) for frame in stream.frames}),
                        "payload_examples": list(dict.fromkeys(payloads))[:5],
                        "candidate_messages": [candidate.name for candidate in stream.attribution.candidates],
                        "reason": stream.attribution.rationale,
                        "unique_payload_count": len(set(payloads)),
                        "payload_change_rate": changes / max(1, len(payloads) - 1),
                    }
                )
            return rows

    def inventory(self) -> list[dict[str, Any]]:
        with self.lock:
            return self._database().inventory(self._all_frames(), self.target_ecu)

    def exports(self, kind: str) -> tuple[str, str, str]:
        """Build browser-downloadable CSV/JSON exports with analysis context."""

        with self.lock:
            context = {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "selected_settings": self.settings.to_dict(),
                "selected_target_ecu": self.target_ecu,
                "dbc_sources": [imported.source_name for imported in self.dbc_imports],
                "onfail_policy_source": self.onfail_policy.source_name if self.onfail_policy else None,
                "selected_time_range": _time_range(self._all_frames()),
            }
            if kind == "frames":
                payload: Any = {"context": context, "frames": [frame.to_dict() for frame in self._all_frames()]}
            elif kind == "signals":
                rows: list[dict[str, Any]] = []
                if self.result:
                    for stream in self.result.streams:
                        for frame in stream.frames:
                            for signal in decode_frame(frame, stream.message):
                                rows.append(
                                    {
                                        "stream_id": stream.stream_id,
                                        "timestamp": frame.timestamp,
                                        "can_id_hex": frame.can_id_hex,
                                        "message_name": stream.message.name if stream.message else None,
                                        **asdict(signal),
                                    }
                                )
                payload = {"context": context, "decoded_signals": rows}
            elif kind == "timing":
                payload = {
                    "context": context,
                    "timing_metrics": [stream.to_dict() for stream in self.result.streams] if self.result else [],
                }
            elif kind == "findings":
                payload = {"context": context, "findings": self.findings({})}
            elif kind == "dbc-validation":
                payload = {"context": context, "dbc_inventory": self.inventory()}
            elif kind == "summary":
                payload = {"context": context, "analysis_summary": self.status()}
            elif kind == "fault-events":
                payload = {
                    "context": context,
                    "fault_events": self.fault_events(),
                    "fault_options": [option.to_dict() for option in FAULT_OPTIONS],
                }
            elif kind == "dtcs":
                payload = {"context": context, "recorded_dtc_status": self.dtc_records()}
            elif kind == "onfail-policy":
                payload = {
                    "context": context,
                    "onfail_policy": self.onfail_policy.to_dict() if self.onfail_policy else None,
                }
            elif kind == "configuration-audit":
                payload = {"context": context, "configuration_audit": self.configuration_checks()}
            else:
                raise ValueError(f"Unsupported export kind '{kind}'.")
            if kind == "frames-csv":
                output = StringIO()
                rows = [frame.to_dict() for frame in self._all_frames()]
                fields = list(rows[0]) if rows else ["source_name", "source_line", "timestamp", "can_id_hex"]
                writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(rows)
                return "text/csv; charset=utf-8", "can-analysis-frames.csv", output.getvalue()
            return "application/json; charset=utf-8", f"can-analysis-{kind}.json", json.dumps(payload, indent=2)

    def _stream(self, stream_id: str) -> StreamAnalysis | None:
        if not self.result:
            return None
        return next((stream for stream in self.result.streams if stream.stream_id == stream_id), None)


def _first(query: dict[str, list[str]], name: str) -> str | None:
    values = query.get(name)
    return values[0] if values else None


def _float_query(query: dict[str, list[str]], name: str) -> float | None:
    value = _first(query, name)
    if value is None:
        return None
    try:
        return float(value)
    except ValueError as error:
        raise ValueError(f"Query parameter '{name}' must be numeric.") from error


def _time_range(frames: list[CanFrame]) -> dict[str, float | None]:
    if not frames:
        return {"start": None, "end": None}
    return {"start": min(frame.timestamp for frame in frames), "end": max(frame.timestamp for frame in frames)}


def _stream_label(stream: StreamAnalysis) -> str:
    """Keep timeline labels concise while preserving the message identity in the detail view."""

    name = stream.message.name if stream.message else stream.frames[0].can_id_hex
    frame = stream.frames[0]
    return f"{name} | {frame.bus} {frame.channel} | {frame.capture_direction.value}"


class CanAnalysisHandler(SimpleHTTPRequestHandler):
    """HTTP transport for static workspace assets and scoped localhost APIs."""

    workspace: Workspace

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(Path(__file__).with_name("web")), **kwargs)

    def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        try:
            if parsed.path == "/api/status":
                return self._json(self.workspace.status())
            if parsed.path == "/api/streams":
                return self._json(self.workspace.streams(query))
            if parsed.path == "/api/frames":
                return self._json(self.workspace.frames(query))
            if parsed.path == "/api/timeline":
                return self._json(self.workspace.timeline(query))
            if parsed.path == "/api/findings":
                return self._json(self.workspace.findings(query))
            if parsed.path == "/api/fault-events":
                return self._json(self.workspace.fault_events())
            if parsed.path == "/api/dtcs":
                return self._json(self.workspace.dtc_records())
            if parsed.path == "/api/fault-options":
                return self._json(self.workspace.fault_options())
            if parsed.path == "/api/configuration-audit":
                return self._json(self.workspace.configuration_checks())
            if parsed.path == "/api/guidance":
                can_id = _first(query, "can_id")
                if not can_id:
                    return self._json({"error": "Query parameter 'can_id' is required."}, HTTPStatus.BAD_REQUEST)
                return self._json(
                    self.workspace.message_guidance(
                        can_id,
                        _first(query, "fault") or "message_content",
                        _first(query, "signal"),
                    )
                )
            if parsed.path == "/api/copilot/preview":
                return self._json({"error": "Use POST to create a reviewed Copilot prompt."}, HTTPStatus.METHOD_NOT_ALLOWED)
            if parsed.path == "/api/inventory":
                return self._json(self.workspace.inventory())
            if parsed.path == "/api/explorer":
                return self._json(self.workspace.explorer())
            if parsed.path.startswith("/api/jobs/"):
                job = self.workspace.jobs.get(parsed.path.rsplit("/", 1)[-1])
                return self._json(job.to_dict() if job else {"error": "Job not found."}, HTTPStatus.OK if job else HTTPStatus.NOT_FOUND)
            if parsed.path.startswith("/api/streams/"):
                detail = self.workspace.stream_detail(parsed.path.rsplit("/", 1)[-1])
                return self._json(detail if detail else {"error": "Stream not found."}, HTTPStatus.OK if detail else HTTPStatus.NOT_FOUND)
            if parsed.path.startswith("/api/export/"):
                content_type, filename, content = self.workspace.exports(parsed.path.rsplit("/", 1)[-1])
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                self.send_header("Content-Length", str(len(content.encode("utf-8"))))
                self.end_headers()
                self.wfile.write(content.encode("utf-8"))
                return
            super().do_GET()
        except (GuidanceError, ValueError) as error:
            self._json({"error": str(error)}, HTTPStatus.BAD_REQUEST)

    def do_POST(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        parsed = urlparse(self.path)
        try:
            import_types = {
                "/api/import/log": "log",
                "/api/import/dbc": "dbc",
                "/api/import/onfail-policy": "onfail-policy",
                "/api/import/canc-config": "canc-config",
                "/api/import/edr-config": "edr-config",
                "/api/import/canc-case-config": "canc-case-config",
            }
            if parsed.path in import_types:
                kind = import_types[parsed.path]
                source_name = unquote(self.headers.get("X-File-Name", "capture.txt"))
                uploaded_file = self._save_upload(source_name)
                job = self.workspace.queue_import(kind, uploaded_file, source_name)
                return self._json(job.to_dict(), HTTPStatus.ACCEPTED)
            if parsed.path == "/api/configuration":
                payload = self._request_json()
                self.workspace.update_configuration(payload)
                return self._json(self.workspace.status())
            if parsed.path == "/api/copilot/preview":
                payload = self._request_json()
                question = payload.get("question")
                if not isinstance(question, str):
                    raise ValueError("Copilot question must be a string.")
                return self._json(self.workspace.copilot_preview(question))
            if parsed.path == "/api/copilot/query":
                payload = self._request_json()
                question = payload.get("question")
                if not isinstance(question, str):
                    raise ValueError("Copilot question must be a string.")
                job = self.workspace.queue_copilot_query(question, payload.get("confirmed") is True)
                return self._json(job.to_dict(), HTTPStatus.ACCEPTED)
            self._json({"error": "Unknown API path."}, HTTPStatus.NOT_FOUND)
        except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as error:
            self._json({"error": str(error)}, HTTPStatus.BAD_REQUEST)

    def _save_upload(self, source_name: str) -> Path:
        try:
            length = int(self.headers.get("Content-Length", ""))
        except ValueError as error:
            raise ValueError("A valid Content-Length header is required.") from error
        if not 0 <= length <= _MAX_UPLOAD_BYTES:
            raise ValueError(f"Upload size must be between 0 and {_MAX_UPLOAD_BYTES} bytes.")
        safe_name = _SAFE_FILENAME.sub("_", Path(source_name).name) or "upload"
        destination = self.workspace.runtime_directory / f"{uuid.uuid4().hex}_{safe_name}"
        remaining = length
        with destination.open("wb") as target:
            while remaining:
                chunk = self.rfile.read(min(1024 * 1024, remaining))
                if not chunk:
                    raise ValueError("Upload ended before the declared Content-Length.")
                target.write(chunk)
                remaining -= len(chunk)
        return destination

    def _request_json(self) -> dict[str, Any]:
        content_length = int(self.headers.get("Content-Length", "0"))
        if content_length > 1024 * 1024:
            raise ValueError("Configuration payload is too large.")
        value = json.loads(self.rfile.read(content_length).decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON request body must be an object.")
        return value

    def _json(self, value: Any, status: HTTPStatus = HTTPStatus.OK) -> None:
        body = json.dumps(value, indent=2, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        """Keep local request logging useful without echoing potentially huge payloads."""

        print(f"[{self.log_date_time_string()}] {format % args}")


def run_server(port: int) -> None:
    """Start an explicitly loopback-bound visual analysis workspace."""

    runtime_directory = Path(tempfile.mkdtemp(prefix="can-log-visual-analyzer-"))
    workspace = Workspace(runtime_directory)
    CanAnalysisHandler.workspace = workspace
    server = ThreadingHTTPServer(("127.0.0.1", port), CanAnalysisHandler)
    print(f"Offline CAN Log Visual Analyzer: http://127.0.0.1:{port}")
    print("The server is loopback-only. It reads uploaded files and never transmits CAN traffic.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping offline analysis workspace.")
    finally:
        server.server_close()
        workspace.close()
        try:
            shutil.rmtree(runtime_directory)
        except OSError as error:
            print(f"Could not remove temporary analysis files at {runtime_directory}: {error}")


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for launching the localhost-only engineering workspace."""

    parser = argparse.ArgumentParser(description="Run the offline ARIA/CAN visual log analyzer.")
    parser.add_argument("--port", type=int, default=8765, help="Loopback TCP port (default: 8765).")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535.")
    run_server(args.port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
