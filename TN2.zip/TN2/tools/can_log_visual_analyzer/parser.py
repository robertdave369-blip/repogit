"""Robust, source-preserving parser for ARIA/CAN text capture records."""

from __future__ import annotations

import re
from pathlib import Path

from .models import (
    CanFrame,
    CaptureDirection,
    IdentifierType,
    ParseResult,
    ParseWarning,
    RejectedLine,
)


_ARIA_RECORD = re.compile(
    r"^\s*(?P<timestamp>\S+)\s+(?P<bus>\S+)\s+(?P<channel>\S+)\s+"
    r"(?P<direction>\S+)\s+l\s*=\s*(?P<length>[^,]+)\s*,\s*"
    r"id\s*=\s*(?P<can_id>[^,\s]+)\s*,?\s*(?P<payload>.*?)\s*$",
    re.IGNORECASE,
)
_HEX_BYTE = re.compile(r"^[0-9A-Fa-f]{2}$")
_HEX_ID = re.compile(r"^(?:0[xX])?([0-9A-Fa-f]+)$")


def _warning(
    code: str, message: str, source_name: str, line_number: int, raw_line: str
) -> ParseWarning:
    return ParseWarning(code, message, source_name, line_number, raw_line)


def _normalized_identifier(value: str) -> tuple[int, str, IdentifierType] | None:
    match = _HEX_ID.fullmatch(value.strip())
    if match is None:
        return None
    numeric = int(match.group(1), 16)
    if numeric > 0x1FFFFFFF:
        return None
    # ARIA text records do not carry an explicit identifier-format bit. Values
    # above the 11-bit range are necessarily extended; all others remain unknown.
    identifier_type = IdentifierType.EXTENDED if numeric > 0x7FF else IdentifierType.UNKNOWN
    width = 8 if identifier_type is IdentifierType.EXTENDED else 3
    return numeric, f"0x{numeric:0{width}X}", identifier_type


def _parse_payload(
    payload_text: str,
    source_name: str,
    line_number: int,
    raw_line: str,
) -> tuple[tuple[int, ...], list[ParseWarning]]:
    warnings: list[ParseWarning] = []
    payload: list[int] = []
    tokens = [token for token in re.split(r"[\s,]+", payload_text.strip()) if token]
    for token in tokens:
        if _HEX_BYTE.fullmatch(token):
            payload.append(int(token, 16))
            continue
        warnings.append(
            _warning(
                "invalid-payload-byte",
                f"Invalid payload byte token '{token}'.",
                source_name,
                line_number,
                raw_line,
            )
        )
        warnings.append(
            _warning(
                "unexpected-trailing-content",
                f"Unexpected trailing content '{token}' after the payload.",
                source_name,
                line_number,
                raw_line,
            )
        )
    if len(payload) > 64:
        warnings.append(
            _warning(
                "payload-too-long",
                f"Parsed {len(payload)} payload bytes; CAN and CAN-FD payloads support at most 64.",
                source_name,
                line_number,
                raw_line,
            )
        )
    return tuple(payload[:64]), warnings


def parse_aria_text(source: Path, source_name: str | None = None) -> ParseResult:
    """Parse ARIA ``Can`` records without discarding malformed-line evidence.

    Frames retain source order. Consumers requiring chronological calculations
    must use :attr:`ParseResult.sorted_frames` rather than mutating this result.
    """

    display_name = source_name or source.name
    result = ParseResult(source_name=display_name)
    previous_timestamp: float | None = None
    source_order = 0
    with source.open("r", encoding="utf-8-sig", errors="replace") as input_file:
        for line_number, source_line in enumerate(input_file, 1):
            raw_line = source_line.rstrip("\r\n")
            if not raw_line.strip():
                continue
            match = _ARIA_RECORD.match(raw_line)
            if match is None:
                first_token = raw_line.split(maxsplit=1)[0] if raw_line.split() else ""
                reason = (
                    f"Malformed timestamp '{first_token}'."
                    if first_token and not _is_float(first_token)
                    else "Line does not match the supported ARIA/CAN record layout."
                )
                result.rejected_lines.append(
                    RejectedLine(display_name, line_number, raw_line, reason)
                )
                continue

            source_order += 1
            warnings: list[ParseWarning] = []
            timestamp_text = match.group("timestamp")
            try:
                timestamp = float(timestamp_text)
            except ValueError:
                result.rejected_lines.append(
                    RejectedLine(
                        display_name,
                        line_number,
                        raw_line,
                        f"Malformed timestamp '{timestamp_text}'.",
                    )
                )
                continue
            if timestamp != timestamp or timestamp in (float("inf"), float("-inf")):
                result.rejected_lines.append(
                    RejectedLine(
                        display_name,
                        line_number,
                        raw_line,
                        f"Malformed timestamp '{timestamp_text}'.",
                    )
                )
                continue

            normalized_id = _normalized_identifier(match.group("can_id"))
            if normalized_id is None:
                result.rejected_lines.append(
                    RejectedLine(
                        display_name,
                        line_number,
                        raw_line,
                        f"Malformed CAN identifier '{match.group('can_id')}'.",
                    )
                )
                continue
            can_id, can_id_hex, identifier_type = normalized_id

            length_text = match.group("length").strip()
            try:
                declared_length = int(length_text, 10)
            except ValueError:
                result.rejected_lines.append(
                    RejectedLine(
                        display_name,
                        line_number,
                        raw_line,
                        f"Malformed declared length '{length_text}'.",
                    )
                )
                continue
            if not 0 <= declared_length <= 64:
                warnings.append(
                    _warning(
                        "declared-length-out-of-range",
                        f"Declared length {declared_length} is outside the 0-64 CAN/CAN-FD range.",
                        display_name,
                        line_number,
                        raw_line,
                    )
                )

            direction_text = match.group("direction").upper()
            if direction_text == "TX":
                direction = CaptureDirection.TX
            elif direction_text == "RX":
                direction = CaptureDirection.RX
            else:
                direction = CaptureDirection.UNKNOWN
                warnings.append(
                    _warning(
                        "malformed-direction",
                        f"Unsupported capture direction '{match.group('direction')}'.",
                        display_name,
                        line_number,
                        raw_line,
                    )
                )

            payload, payload_warnings = _parse_payload(
                match.group("payload"), display_name, line_number, raw_line
            )
            warnings.extend(payload_warnings)
            if declared_length != len(payload):
                warnings.append(
                    _warning(
                        "declared-length-mismatch",
                        f"Declared length {declared_length} differs from {len(payload)} parsed payload byte(s).",
                        display_name,
                        line_number,
                        raw_line,
                    )
                )
            if previous_timestamp is not None and timestamp < previous_timestamp:
                warnings.append(
                    _warning(
                        "non-monotonic-timestamp",
                        f"Timestamp {timestamp:.9f} is earlier than preceding parsed timestamp "
                        f"{previous_timestamp:.9f} in source order.",
                        display_name,
                        line_number,
                        raw_line,
                    )
                )
            previous_timestamp = timestamp
            frame = CanFrame(
                source_name=display_name,
                source_line=line_number,
                source_order=source_order,
                raw_line=raw_line,
                timestamp=timestamp,
                bus=match.group("bus"),
                channel=match.group("channel"),
                capture_direction=direction,
                can_id=can_id,
                can_id_hex=can_id_hex,
                identifier_type=identifier_type,
                declared_length=declared_length,
                payload=payload,
                parse_warnings=tuple(warnings),
            )
            result.frames.append(frame)
            result.warnings.extend(warnings)
    return result


def _is_float(value: str) -> bool:
    try:
        float(value)
    except ValueError:
        return False
    return True
