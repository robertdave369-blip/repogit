"""Passive configured-monitor evidence and recorded UDS DTC-status reconstruction."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from hashlib import sha1
from typing import Any, Iterable, Protocol

from .models import AnalysisSettings, CanFrame, DtcStatusRecord, FaultEvent, FaultOption
from .onfail_policy import OnFailPolicy


class _TimingStream(Protocol):
    """Structural type accepted from the timing-analysis layer without a circular import."""

    stream_id: str
    frames: list[CanFrame]
    message: Any
    metrics: Any


FAULT_OPTIONS: tuple[FaultOption, ...] = (
    FaultOption(
        "message_timeout",
        "derived",
        "Uses a valid DBC cycle time and the configured no-frame qualification delay to model an internal capture gap.",
        "This is a configured monitor model, not proof that an ECU timeout monitor or DTC actually qualified.",
    ),
    FaultOption(
        "node_absent",
        "derived",
        "Finds overlapping configured timeout windows across at least two observed periodic messages declared with the same DBC sender.",
        "DBC sender metadata does not identify the configured node key message, so this is a node-wide communication-absence candidate only.",
    ),
    FaultOption(
        "signal_never_received",
        "profile-required",
        "Can be correlated with an imported policy profile, but needs a monitor definition and pre-capture initialization evidence.",
        "A capture beginning without a frame does not prove the signal was never received.",
    ),
    FaultOption(
        "signal_invalid",
        "profile-required",
        "Requires an explicit application monitor, invalid-value encoding, or source-owned diagnostic rule.",
        "DBC min/max and enumerations alone do not define an invalid-value rule.",
    ),
    FaultOption(
        "reserved_or_out_of_range",
        "profile-required",
        "Can display Potential DBC-range deviation, while a reserved-value fault needs explicit source metadata.",
        "No reserved values are inferred from signal names or unused enum codes.",
    ),
    FaultOption(
        "message_content_failure",
        "profile-required",
        "Requires source-owned integrity, checksum, counter, or content-monitor rules.",
        "The analyzer never infers CRC, alive counter, checksum, E2E, or content validity from payload names.",
    ),
    FaultOption(
        "variant_code_error",
        "not-observable",
        "Can be documented through an imported on-fail policy.",
        "Variant coding and ignition-cycle state are not observable from this passive CAN text capture.",
    ),
    FaultOption(
        "uv_ov",
        "profile-required",
        "Can be correlated with a source-owned monitor or DTC policy.",
        "Supply-voltage monitor state cannot be inferred from generic CAN payloads.",
    ),
    FaultOption(
        "bus_off",
        "not-observable",
        "A controller-level bus-off event requires recorded controller/error-frame or diagnostic evidence.",
        "A frame gap alone is not evidence of bus-off.",
    ),
    FaultOption(
        "network_security_failure",
        "profile-required",
        "Can be correlated with a source-owned security-monitor policy.",
        "Network-security failure is not inferred from unknown IDs or payload contents.",
    ),
    FaultOption(
        "recorded_dtc_status",
        "diagnostic-only",
        "Reconstructs DTC status only from recorded ISO-TP UDS positive ReadDTCInformation responses (0x59).",
        "The analyzer never sends a diagnostic request; no recorded 0x59 response means DTC availability is unknown.",
    ),
)

_DTC_STATUS_BITS: tuple[tuple[int, str], ...] = (
    (0, "testFailed"),
    (1, "testFailedThisOperationCycle"),
    (2, "pendingDTC"),
    (3, "confirmedDTC"),
    (4, "testNotCompletedSinceLastClear"),
    (5, "testFailedSinceLastClear"),
    (6, "testNotCompletedThisOperationCycle"),
    (7, "warningIndicatorRequested"),
)
_DTC_RECORD_SUBFUNCTIONS = frozenset({0x02, 0x0A, 0x0F})


@dataclass(frozen=True, slots=True)
class _TimeoutWindow:
    """A single stream's configured no-frame interval used for node-overlap analysis."""

    stream: _TimingStream
    event: FaultEvent
    start: float
    end: float


def _event_id(category: str, identity: str) -> str:
    return sha1(f"{category}|{identity}".encode("utf-8")).hexdigest()[:16]


def _frame_evidence(frame: CanFrame) -> dict[str, Any]:
    return {
        "source_name": frame.source_name,
        "source_line": frame.source_line,
        "raw_line": frame.raw_line,
        "timestamp": frame.timestamp,
        "bus": frame.bus,
        "channel": frame.channel,
        "capture_direction": frame.capture_direction.value,
        "can_id_hex": frame.can_id_hex,
        "payload_hex": frame.payload_hex,
    }


def _qualification_delay_ms(stream: _TimingStream, settings: AnalysisSettings) -> float:
    """Resolve an explicit override or the established periodic-gap rule."""

    if settings.timeout_qualification_ms > 0:
        return settings.timeout_qualification_ms
    return max(
        stream.metrics.expected_cycle_ms * settings.stopped_multiplier,
        settings.minimum_gap_ms,
    )


def _recovery_time(
    frames: list[CanFrame],
    recovered_index: int,
    delay_ms: float,
    qualification_delay_ms: float,
) -> float | None:
    """Require recorded continuity through non-zero recovery delay before declaring it evidenced."""

    first_recovered = frames[recovered_index]
    if delay_ms == 0:
        return first_recovered.timestamp
    target = first_recovered.timestamp + delay_ms / 1000
    for previous, current in zip(frames[recovered_index:], frames[recovered_index + 1:]):
        if (current.timestamp - previous.timestamp) * 1000 > qualification_delay_ms:
            return None
        if current.timestamp >= target:
            return target
    return None


def message_timeout_events(
    streams: Iterable[_TimingStream],
    settings: AnalysisSettings,
    policy: OnFailPolicy | None,
) -> list[FaultEvent]:
    """Model internal message-timeout transitions only for internal observed gaps."""

    events: list[FaultEvent] = []
    for stream in streams:
        message = stream.message
        expected = stream.metrics.expected_cycle_ms
        if message is None or expected is None or expected <= 0:
            continue
        qualification_delay = _qualification_delay_ms(stream, settings)
        ordered = stream.frames
        policy_context = policy.contexts_for_message(message.name, "message_timeout") if policy else ()
        for index, (before, after) in enumerate(zip(ordered, ordered[1:]), 1):
            gap_ms = (after.timestamp - before.timestamp) * 1000
            if gap_ms <= qualification_delay:
                continue
            qualification = before.timestamp + qualification_delay / 1000
            recovery = _recovery_time(
                ordered,
                index,
                settings.timeout_recovery_ms,
                qualification_delay,
            )
            event = FaultEvent(
                event_id=_event_id("message-timeout", f"{stream.stream_id}|{before.source_line}|{after.source_line}"),
                category="Potential message-timeout qualification",
                monitor_scope="message",
                message_name=message.name,
                sender_node=None,
                qualification_timestamp=qualification,
                recovery_observed_timestamp=after.timestamp,
                dequalification_timestamp=recovery,
                confidence="medium",
                summary=(
                    f"Configured monitor model reaches its {qualification_delay:.3f} ms no-frame "
                    f"qualification delay at {qualification:.6f} s."
                ),
                evidence={
                    "expected_cycle_ms": expected,
                    "actual_gap_ms": gap_ms,
                    "qualification_delay_ms": qualification_delay,
                    "recovery_delay_ms": settings.timeout_recovery_ms,
                    "frame_before_gap": _frame_evidence(before),
                    "first_frame_after_gap": _frame_evidence(after),
                },
                rule=(
                    "Configured no-frame monitor: qualification is last observed frame + "
                    f"{qualification_delay:.3f} ms; recovery requires {settings.timeout_recovery_ms:.3f} ms of recorded continuity."
                ),
                policy_context=policy_context,
                stream_id=stream.stream_id,
            )
            events.append(event)
    return events


def node_absence_events(
    streams: Iterable[_TimingStream],
    message_events: Iterable[FaultEvent],
    policy: OnFailPolicy | None,
) -> list[FaultEvent]:
    """Find overlaps only when all observed periodic streams of a sender are timed out."""

    stream_by_id = {stream.stream_id: stream for stream in streams}
    by_sender: dict[str, list[_TimingStream]] = defaultdict(list)
    for stream in stream_by_id.values():
        message = stream.message
        if message is None or stream.metrics.expected_cycle_ms is None:
            continue
        for sender in message.senders:
            by_sender[sender].append(stream)
    windows_by_stream: dict[str, list[_TimeoutWindow]] = defaultdict(list)
    for event in message_events:
        if event.stream_id is None or event.recovery_observed_timestamp is None:
            continue
        stream = stream_by_id.get(event.stream_id)
        if stream:
            windows_by_stream[event.stream_id].append(
                _TimeoutWindow(stream, event, event.qualification_timestamp, event.recovery_observed_timestamp)
            )
    events: list[FaultEvent] = []
    for sender, sender_streams in by_sender.items():
        unique_streams = {stream.stream_id: stream for stream in sender_streams}
        if len(unique_streams) < 2 or any(not windows_by_stream[stream_id] for stream_id in unique_streams):
            continue
        ordered_windows = [
            sorted(windows_by_stream[stream_id], key=lambda window: window.start)
            for stream_id in unique_streams
        ]
        positions = [0] * len(ordered_windows)
        while all(position < len(windows) for position, windows in zip(positions, ordered_windows)):
            current = [windows[position] for position, windows in zip(positions, ordered_windows)]
            start = max(window.start for window in current)
            end = min(window.end for window in current)
            if start < end:
                messages = [window.stream.message.name for window in current]
                policy_context = tuple(
                    context
                    for message_name in messages
                    for context in (policy.contexts_for_message(message_name, "node_absent") if policy else ())
                )
                events.append(
                    FaultEvent(
                        event_id=_event_id("node-absence", f"{sender}|{start:.9f}|{end:.9f}"),
                        category="Potential sender-node communication absence",
                        monitor_scope="sender-node",
                        message_name=None,
                        sender_node=sender,
                        qualification_timestamp=start,
                        recovery_observed_timestamp=end,
                        dequalification_timestamp=end,
                        confidence="low",
                        summary=(
                            f"All {len(current)} observed periodic streams declared with DBC sender '{sender}' "
                            f"overlap in configured timeout windows from {start:.6f} s to {end:.6f} s."
                        ),
                        evidence={
                            "sender": sender,
                            "monitored_messages": messages,
                            "overlap_start_timestamp": start,
                            "first_recovery_timestamp": end,
                            "stream_timeout_events": [window.event.to_dict() for window in current],
                        },
                        rule=(
                            "Derived node-wide candidate: overlap of configured timeout windows across every "
                            "observed periodic stream that declares this DBC sender. This does not identify a configured node key message."
                        ),
                        policy_context=policy_context,
                        stream_id=None,
                    )
                )
            earliest_end = min(range(len(current)), key=lambda index: current[index].end)
            positions[earliest_end] += 1
    return events


def _dtc_flags(status_byte: int) -> tuple[str, ...]:
    return tuple(name for bit, name in _DTC_STATUS_BITS if status_byte & (1 << bit))


def _dtc_records_from_payload(
    payload: tuple[int, ...],
    timestamp: float,
    source_frames: tuple[CanFrame, ...],
) -> list[DtcStatusRecord]:
    if len(payload) < 3 or payload[0] != 0x59 or payload[1] not in _DTC_RECORD_SUBFUNCTIONS:
        return []
    subfunction = payload[1]
    records = payload[3:]
    if len(records) % 4:
        return []
    result: list[DtcStatusRecord] = []
    for offset in range(0, len(records), 4):
        dtc_bytes = records[offset : offset + 3]
        status = records[offset + 3]
        if dtc_bytes == (0, 0, 0):
            continue
        result.append(
            DtcStatusRecord(
                dtc="".join(f"{byte:02X}" for byte in dtc_bytes),
                status_byte=status,
                status_flags=_dtc_flags(status),
                subfunction=subfunction,
                timestamp=timestamp,
                source_frames=source_frames,
            )
        )
    return result


def recorded_dtc_status(frames: Iterable[CanFrame]) -> list[DtcStatusRecord]:
    """Reassemble recorded ISO-TP positive DTC responses without transmitting UDS."""

    reassemblies: dict[tuple[str, str, int, object, object], tuple[int, list[int], list[CanFrame], int]] = {}
    records: list[DtcStatusRecord] = []
    for frame in sorted(frames, key=lambda item: (item.timestamp, item.source_order)):
        if not frame.payload:
            continue
        key = (
            frame.bus,
            frame.channel,
            frame.can_id,
            frame.identifier_type,
            frame.capture_direction,
        )
        pci_type = frame.payload[0] >> 4
        if pci_type == 0:
            length = frame.payload[0] & 0x0F
            if 0 < length <= len(frame.payload) - 1:
                records.extend(
                    _dtc_records_from_payload(
                        frame.payload[1 : length + 1],
                        frame.timestamp,
                        (frame,),
                    )
                )
            reassemblies.pop(key, None)
        elif pci_type == 1 and len(frame.payload) >= 2:
            length = ((frame.payload[0] & 0x0F) << 8) | frame.payload[1]
            data = list(frame.payload[2:])
            if len(data) >= length:
                records.extend(_dtc_records_from_payload(tuple(data[:length]), frame.timestamp, (frame,)))
                reassemblies.pop(key, None)
            else:
                reassemblies[key] = (length, data, [frame], 1)
        elif pci_type == 2 and key in reassemblies:
            length, data, source_frames, expected_sequence = reassemblies[key]
            sequence = frame.payload[0] & 0x0F
            if sequence != expected_sequence:
                reassemblies.pop(key, None)
                continue
            data.extend(frame.payload[1:])
            source_frames.append(frame)
            if len(data) >= length:
                records.extend(
                    _dtc_records_from_payload(tuple(data[:length]), source_frames[0].timestamp, tuple(source_frames))
                )
                reassemblies.pop(key, None)
            else:
                reassemblies[key] = (length, data, source_frames, (expected_sequence + 1) & 0x0F)
    return records


def analyse_fault_evidence(
    streams: Iterable[_TimingStream],
    frames: Iterable[CanFrame],
    settings: AnalysisSettings,
    policy: OnFailPolicy | None,
) -> tuple[list[FaultEvent], list[DtcStatusRecord]]:
    """Return only raw-evidence fault-state candidates and recorded diagnostic responses."""

    materialized_streams = list(streams)
    message_events = message_timeout_events(materialized_streams, settings, policy)
    node_events = node_absence_events(materialized_streams, message_events, policy)
    return message_events + node_events, recorded_dtc_status(frames)
