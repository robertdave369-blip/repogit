"""Validate optional on-fail policy JSON without treating it as observed ECU state."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class OnFailRecord:
    """One source-owned on-fail policy record correlated only by exact message name."""

    system: str
    message: str
    signal: str
    source_row: int | None
    applicable: bool
    faults: dict[str, dict[str, Any]]
    special: dict[str, Any]

    def context_for(self, fault_name: str) -> dict[str, Any] | None:
        """Return source policy context for display, never as a detected fault."""

        entry = self.faults.get(fault_name)
        if entry is None:
            return None
        return {
            "system": self.system,
            "message": self.message,
            "signal": self.signal,
            "source_row": self.source_row,
            "fault": fault_name,
            "expected_reaction": entry.get("reaction"),
            "expected_value": entry.get("value"),
            "source_text": entry.get("source_text"),
            "special": self.special or None,
        }


@dataclass(slots=True)
class OnFailPolicy:
    """An imported policy profile and its validation notes."""

    source_name: str
    generic: dict[str, dict[str, Any]]
    records: list[OnFailRecord] = field(default_factory=list)
    validation_warnings: list[str] = field(default_factory=list)

    def contexts_for_message(self, message_name: str, fault_name: str) -> tuple[dict[str, Any], ...]:
        """Find source-policy entries; an absent entry means policy availability is unknown."""

        return tuple(
            context
            for record in self.records
            if record.applicable and record.message == message_name
            if (context := record.context_for(fault_name)) is not None
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_name": self.source_name,
            "record_count": len(self.records),
            "validation_warnings": list(self.validation_warnings),
            "generic_faults": sorted(self.generic),
        }


def import_onfail_policy(source: Path, source_name: str | None = None) -> OnFailPolicy:
    """Read the repository's normalized on-fail policy shape with validation warnings."""

    display_name = source_name or source.name
    try:
        document = json.loads(source.read_text(encoding="utf-8-sig"))
    except UnicodeDecodeError as error:
        raise ValueError(f"On-fail policy '{display_name}' is not UTF-8: {error}") from error
    except json.JSONDecodeError as error:
        raise ValueError(f"On-fail policy '{display_name}' is invalid JSON: {error}") from error
    if not isinstance(document, dict):
        raise ValueError("On-fail policy JSON must be an object.")
    generic = document.get("generic", {})
    records = document.get("records", [])
    if not isinstance(generic, dict):
        raise ValueError("On-fail policy 'generic' must be an object.")
    if not isinstance(records, list):
        raise ValueError("On-fail policy 'records' must be an array.")
    policy = OnFailPolicy(display_name, {
        str(name): value for name, value in generic.items() if isinstance(value, dict)
    })
    for index, raw_record in enumerate(records):
        if not isinstance(raw_record, dict):
            policy.validation_warnings.append(f"Record {index}: expected an object.")
            continue
        message = raw_record.get("message")
        signal = raw_record.get("signal")
        system = raw_record.get("system")
        faults = raw_record.get("faults", {})
        if not all(isinstance(value, str) and value.strip() for value in (message, signal, system)):
            policy.validation_warnings.append(f"Record {index}: system, message, and signal must be non-empty strings.")
            continue
        if not isinstance(faults, dict) or any(not isinstance(value, dict) for value in faults.values()):
            policy.validation_warnings.append(f"Record {index}: faults must map names to objects.")
            continue
        source_row = raw_record.get("source_row")
        if source_row is not None and (isinstance(source_row, bool) or not isinstance(source_row, int)):
            policy.validation_warnings.append(f"Record {index}: source_row must be an integer when present.")
            source_row = None
        special = raw_record.get("special", {})
        if not isinstance(special, dict):
            policy.validation_warnings.append(f"Record {index}: special metadata must be an object.")
            special = {}
        policy.records.append(
            OnFailRecord(
                system.strip(),
                message.strip(),
                signal.strip(),
                source_row,
                bool(raw_record.get("on_fail_applicable", True)),
                {str(name): value for name, value in faults.items()},
                special,
            )
        )
    return policy
