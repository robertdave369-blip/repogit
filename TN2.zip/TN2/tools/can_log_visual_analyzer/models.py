"""Typed domain models shared by the offline CAN log analysis layers."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from math import isfinite
from typing import Any, Literal


class IdentifierType(str, Enum):
    """CAN identifier format, including captures that do not state it."""

    STANDARD = "standard"
    EXTENDED = "extended"
    UNKNOWN = "unknown"


class CaptureDirection(str, Enum):
    """Direction reported by the capture interface, not an ECU role."""

    TX = "TX"
    RX = "RX"
    UNKNOWN = "UNKNOWN"


class Attribution(str, Enum):
    """Exclusive target-ECU classifications based solely on imported DBC data."""

    ECU_TX_CANDIDATE = "ECU-associated transmit candidate"
    ECU_RX_CANDIDATE = "ECU-associated receive candidate"
    ECU_AMBIGUOUS_ROLE = "ECU-associated bidirectional or ambiguous role"
    DBC_KNOWN_NON_ASSOCIATED = "DBC-known, not associated with selected ECU"
    UNKNOWN_ID = "Unknown CAN ID"
    AMBIGUOUS_DBC = "Ambiguous DBC match"


@dataclass(frozen=True, slots=True)
class ParseWarning:
    """A source-local parser warning retaining its exact line evidence."""

    code: str
    message: str
    source_name: str
    source_line: int
    raw_line: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class RejectedLine:
    """A line that could not yield a normalized frame."""

    source_name: str
    source_line: int
    raw_line: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CanFrame:
    """One normalized capture record with source-order and raw-line evidence."""

    source_name: str
    source_line: int
    source_order: int
    raw_line: str
    timestamp: float
    bus: str
    channel: str
    capture_direction: CaptureDirection
    can_id: int
    can_id_hex: str
    identifier_type: IdentifierType
    declared_length: int
    payload: tuple[int, ...]
    parse_warnings: tuple[ParseWarning, ...] = ()

    @property
    def payload_hex(self) -> str:
        return " ".join(f"{byte:02X}" for byte in self.payload)

    @property
    def stream_key(self) -> tuple[str, str, int, IdentifierType, CaptureDirection]:
        return (
            self.bus,
            self.channel,
            self.can_id,
            self.identifier_type,
            self.capture_direction,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_name": self.source_name,
            "source_line": self.source_line,
            "source_order": self.source_order,
            "raw_line": self.raw_line,
            "timestamp": self.timestamp,
            "bus": self.bus,
            "channel": self.channel,
            "capture_direction": self.capture_direction.value,
            "can_id": self.can_id,
            "can_id_hex": self.can_id_hex,
            "identifier_type": self.identifier_type.value,
            "declared_length": self.declared_length,
            "parsed_byte_count": len(self.payload),
            "payload": list(self.payload),
            "payload_hex": self.payload_hex,
            "parse_warnings": [warning.to_dict() for warning in self.parse_warnings],
        }


@dataclass(slots=True)
class ParseResult:
    """A complete source import; source-order frames stay separate from analysis order."""

    source_name: str
    frames: list[CanFrame] = field(default_factory=list)
    rejected_lines: list[RejectedLine] = field(default_factory=list)
    warnings: list[ParseWarning] = field(default_factory=list)

    @property
    def sorted_frames(self) -> list[CanFrame]:
        return sorted(self.frames, key=lambda frame: (frame.timestamp, frame.source_order))

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_name": self.source_name,
            "parsed_frame_count": len(self.frames),
            "rejected_line_count": len(self.rejected_lines),
            "warning_count": len(self.warnings),
            "rejected_lines": [line.to_dict() for line in self.rejected_lines],
        }


@dataclass(frozen=True, slots=True)
class DbcSignal:
    """A normalized signal definition from a JSON-exported DBC."""

    name: str
    start_bit: int
    length: int
    byte_order: Literal["little_endian", "big_endian"]
    is_signed: bool
    factor: float
    offset: float
    minimum: float | None
    maximum: float | None
    unit: str
    value_descriptions: dict[int, str]
    multiplexer_signal: str | None = None
    multiplexer_values: tuple[int, ...] = ()
    is_multiplexer: bool = False
    valid: bool = True
    validation_warnings: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DbcMessage:
    """A normalized DBC message definition, including validation state."""

    source_name: str
    name: str
    frame_id: int | None
    identifier_type: IdentifierType
    length: int | None
    senders: tuple[str, ...]
    receivers: tuple[str, ...]
    cycle_time_ms: float | None
    signals: tuple[DbcSignal, ...]
    valid: bool
    validation_warnings: tuple[str, ...] = ()

    @property
    def can_id_hex(self) -> str:
        if self.frame_id is None:
            return "Unavailable"
        width = 8 if self.identifier_type is IdentifierType.EXTENDED else 3
        return f"0x{self.frame_id:0{width}X}"


@dataclass(slots=True)
class DbcImportResult:
    """A DBC import and its source-specific validation report."""

    source_name: str
    messages: list[DbcMessage] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class DbcMatch:
    """DBC candidates and a conclusion for a source frame."""

    candidates: tuple[DbcMessage, ...]
    ambiguous_identifier_type: bool = False

    @property
    def unambiguous_message(self) -> DbcMessage | None:
        return self.candidates[0] if len(self.candidates) == 1 else None


@dataclass(frozen=True, slots=True)
class AttributionResult:
    """A classification with DBC sender/receiver evidence and cautious rationale."""

    classification: Attribution
    candidates: tuple[DbcMessage, ...]
    rationale: str
    confidence: Literal["high", "medium", "low"]


@dataclass(frozen=True, slots=True)
class AnalysisSettings:
    """Configurable timing rules; all values are milliseconds unless stated otherwise."""

    minimum_gap_ms: float = 10.0
    absolute_tolerance_ms: float = 0.5
    stopped_multiplier: float = 3.0
    jitter_fraction: float = 0.10
    burst_fraction: float = 0.50
    percentile: float = 95.0
    timeout_qualification_ms: float = 0.0
    timeout_recovery_ms: float = 0.0

    def __post_init__(self) -> None:
        for value in (
            self.minimum_gap_ms,
            self.absolute_tolerance_ms,
            self.stopped_multiplier,
            self.jitter_fraction,
            self.burst_fraction,
            self.percentile,
            self.timeout_qualification_ms,
            self.timeout_recovery_ms,
        ):
            if not isfinite(value) or value < 0:
                raise ValueError("Analysis settings must be finite, non-negative values.")

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class TimingGap:
    """One interval with before/after frame evidence."""

    before: CanFrame
    after: CanFrame
    interval_ms: float
    estimated_missed_cycles: int


@dataclass(frozen=True, slots=True)
class TimingMetrics:
    """Descriptive statistics for one non-combined CAN timing stream."""

    stream_id: str
    frame_count: int
    first_timestamp: float
    last_timestamp: float
    capture_duration_ms: float
    mean_interval_ms: float | None
    median_interval_ms: float | None
    min_interval_ms: float | None
    max_interval_ms: float | None
    standard_deviation_ms: float | None
    percentile_interval_ms: float | None
    expected_cycle_ms: float | None
    mean_difference_from_expected_ms: float | None
    median_difference_from_expected_ms: float | None
    jitter_ms: float | None
    long_gap_count: int
    burst_count: int
    estimated_missed_cycles: int
    within_tolerance_percent: float | None
    long_gaps: tuple[TimingGap, ...] = ()


@dataclass(frozen=True, slots=True)
class DecodedSignal:
    """A per-frame signal value or an explicit reason it is unavailable."""

    name: str
    raw_value: int | None
    physical_value: float | None
    unit: str
    enum_label: str | None
    status: str
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class Finding:
    """Traceable analysis finding with evidence rather than a vehicle diagnosis."""

    finding_id: str
    category: str
    severity: Literal["info", "warning", "review"]
    confidence: Literal["high", "medium", "low"]
    summary: str
    evidence: dict[str, Any]
    rule: str
    affected_message: str | None
    affected_signal: str | None
    next_step: str
    stream_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class FaultEvent:
    """A configured-monitor state transition supported by captured frame evidence."""

    event_id: str
    category: str
    monitor_scope: str
    message_name: str | None
    sender_node: str | None
    qualification_timestamp: float
    recovery_observed_timestamp: float | None
    dequalification_timestamp: float | None
    confidence: Literal["high", "medium", "low"]
    summary: str
    evidence: dict[str, Any]
    rule: str
    policy_context: tuple[dict[str, Any], ...] = ()
    stream_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class DtcStatusRecord:
    """A DTC/status record reconstructed from a recorded ISO-TP UDS response."""

    dtc: str
    status_byte: int
    status_flags: tuple[str, ...]
    subfunction: int
    timestamp: float
    source_frames: tuple[CanFrame, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "dtc": self.dtc,
            "status_byte": self.status_byte,
            "status_hex": f"0x{self.status_byte:02X}",
            "status_flags": list(self.status_flags),
            "subfunction": self.subfunction,
            "timestamp": self.timestamp,
            "source_frames": [frame.to_dict() for frame in self.source_frames],
        }


@dataclass(frozen=True, slots=True)
class FaultOption:
    """A fault family and the evidence required before it can be interpreted."""

    name: str
    capture_support: Literal["derived", "profile-required", "not-observable", "diagnostic-only"]
    description: str
    limitation: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)
