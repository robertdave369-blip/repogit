"""Safely import static CAN-C/EDR Python configuration and audit it against DBC metadata.

The importer evaluates only literals, references to earlier literals, and
dictionary ``.get`` calls. It never imports or executes a user-selected file.
"""

from __future__ import annotations

import ast
import math
import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .dbc import DbcDatabase
from .models import DbcMessage, DbcSignal


@dataclass(frozen=True, slots=True)
class ConfigurationCheck:
    """A static configuration/DBC consistency result with source evidence."""

    category: str
    severity: str
    summary: str
    evidence: dict[str, Any]
    rule: str
    next_step: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class StaticConfiguration:
    """A safely evaluated subset of a Python configuration module."""

    source_name: str
    constants: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    call_names: tuple[str, ...] = ()


@dataclass(slots=True)
class CancConfiguration:
    """The static CAN-C data needed for configuration and route verification."""

    source_name: str
    messages: dict[str, dict[str, Any]]
    key_frames: dict[str, bool]
    routes: dict[str, dict[str, Any]]
    qualification_profile: dict[str, Any]
    call_names: tuple[str, ...]
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_name": self.source_name,
            "message_configuration_count": len(self.messages),
            "key_frame_count": sum(self.key_frames.values()),
            "route_count": len(self.routes),
            "qualification_profile_available": bool(self.qualification_profile),
            "static_call_names": list(self.call_names),
            "warnings": self.warnings,
        }


@dataclass(slots=True)
class EdrConfiguration:
    """The static EDR parameter data needed to distinguish interval and snapshot fields."""

    source_name: str
    parameters: list[dict[str, Any]]
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        counts = Counter(str(parameter.get("recording_model", "unspecified")) for parameter in self.parameters)
        return {
            "source_name": self.source_name,
            "parameter_count": len(self.parameters),
            "recording_models": dict(counts),
            "warnings": self.warnings,
        }


@dataclass(slots=True)
class CancCaseConfiguration:
    """Generated CAN-C case definitions used for static simulation-plan verification."""

    source_name: str
    cases: list[dict[str, Any]]
    call_names: tuple[str, ...]
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_name": self.source_name,
            "case_count": len(self.cases),
            "static_call_names": list(self.call_names),
            "warnings": self.warnings,
        }


@dataclass(slots=True)
class ConfigurationAudit:
    """All source/DBC consistency checks exposed by the passive analyzer."""

    checks: list[ConfigurationCheck] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        counts = Counter(check.severity for check in self.checks)
        return {
            "summary": {
                "check_count": len(self.checks),
                "info_count": counts["info"],
                "warning_count": counts["warning"],
                "review_count": counts["review"],
            },
            "checks": [check.to_dict() for check in self.checks],
        }


class _StaticEvaluator:
    """Constrained evaluator for declarative Python configuration assignments."""

    def __init__(self, constants: dict[str, Any]) -> None:
        self.constants = constants

    def evaluate(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            if node.id not in self.constants:
                raise ValueError(f"Reference to unsupported or later symbol '{node.id}'.")
            return self.constants[node.id]
        if isinstance(node, ast.List):
            return [self.evaluate(element) for element in node.elts]
        if isinstance(node, ast.Tuple):
            return tuple(self.evaluate(element) for element in node.elts)
        if isinstance(node, ast.Set):
            return {self.evaluate(element) for element in node.elts}
        if isinstance(node, ast.Dict):
            return {
                self.evaluate(key): self.evaluate(value)
                for key, value in zip(node.keys, node.values)
                if key is not None
            }
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            value = self.evaluate(node.operand)
            if not isinstance(value, (int, float)):
                raise ValueError("Unary arithmetic operand is not numeric.")
            return -value if isinstance(node.op, ast.USub) else value
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.BitOr)):
            left, right = self.evaluate(node.left), self.evaluate(node.right)
            if isinstance(node.op, ast.Add) and isinstance(left, (int, float, str, tuple, list)):
                return left + right
            if isinstance(node.op, ast.BitOr) and isinstance(left, dict) and isinstance(right, dict):
                return left | right
            raise ValueError("Unsupported binary operation in static configuration.")
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "get"
            and isinstance(self.evaluate(node.func.value), dict)
        ):
            source = self.evaluate(node.func.value)
            arguments = [self.evaluate(argument) for argument in node.args]
            if not 1 <= len(arguments) <= 2 or node.keywords:
                raise ValueError("Only dictionary .get(key[, default]) is allowed.")
            return source.get(*arguments)
        raise ValueError(f"Unsupported expression '{type(node).__name__}' in static configuration.")


def read_static_configuration(source: Path, source_name: str | None = None) -> StaticConfiguration:
    """Parse a configuration without importing it or executing application code."""

    display_name = source_name or source.name
    try:
        tree = ast.parse(source.read_text(encoding="utf-8-sig"), filename=display_name)
    except UnicodeDecodeError as error:
        raise ValueError(f"Configuration '{display_name}' is not UTF-8: {error}") from error
    except SyntaxError as error:
        raise ValueError(f"Configuration '{display_name}' has invalid Python syntax: {error}") from error
    result = StaticConfiguration(display_name)
    evaluator = _StaticEvaluator(result.constants)
    calls: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                calls.append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                calls.append(node.func.attr)
    for statement in tree.body:
        target: ast.Name | None = None
        value: ast.AST | None = None
        if isinstance(statement, ast.Assign) and len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name):
            target, value = statement.targets[0], statement.value
        elif isinstance(statement, ast.AnnAssign) and isinstance(statement.target, ast.Name) and statement.value:
            target, value = statement.target, statement.value
        if target is None or value is None:
            continue
        try:
            result.constants[target.id] = evaluator.evaluate(value)
        except ValueError as error:
            result.warnings.append(f"{target.id}: {error}")
    result.call_names = tuple(calls)
    return result


def import_canc_configuration(source: Path, source_name: str | None = None) -> CancConfiguration:
    """Extract CAN-C route/key-frame data from a declarative configuration source."""

    static = read_static_configuration(source, source_name)
    raw_messages = static.constants.get("CAN_TX_MESSAGE_CONFIG", {})
    messages = {
        name: definition
        for name, definition in raw_messages.items()
        if isinstance(name, str) and isinstance(definition, dict)
    } if isinstance(raw_messages, dict) else {}
    if not messages:
        static.warnings.append("CAN_TX_MESSAGE_CONFIG was not found or could not be evaluated.")
    raw_keys = static.constants.get("KEY_TX_FRAMES", {})
    key_frames = {
        name: value
        for name, value in raw_keys.items()
        if isinstance(name, str) and isinstance(value, bool)
    } if isinstance(raw_keys, dict) else {}
    if not key_frames:
        static.warnings.append("KEY_TX_FRAMES was not found or could not be evaluated.")
    routes = {
        name: definition
        for name, definition in static.constants.items()
        if name.startswith("CAN_")
        and isinstance(definition, dict)
        and isinstance(definition.get("fault_logic"), dict)
        and isinstance(definition.get("frame"), str)
        and isinstance(definition.get("signal"), str)
    }
    qualification = static.constants.get("U171_CAN_FAULT_QUALI_DEQUALI_CONFIG", {})
    if not isinstance(qualification, dict):
        qualification = {}
    return CancConfiguration(
        static.source_name,
        messages,
        key_frames,
        routes,
        qualification,
        static.call_names,
        static.warnings,
    )


def import_edr_configuration(source: Path, source_name: str | None = None) -> EdrConfiguration:
    """Extract static EDR parameter metadata without evaluating application code."""

    static = read_static_configuration(source, source_name)
    raw_parameters = static.constants.get("EDR_PARAMETERS", [])
    parameters = [parameter for parameter in raw_parameters if isinstance(parameter, dict)] if isinstance(raw_parameters, list) else []
    if not parameters:
        static.warnings.append("EDR_PARAMETERS was not found or could not be evaluated.")
    return EdrConfiguration(static.source_name, parameters, static.warnings)


def import_canc_case_configuration(
    source: Path, source_name: str | None = None
) -> CancCaseConfiguration:
    """Read generated ``CANC_C_CASES`` data without importing or executing it."""

    static = read_static_configuration(source, source_name)
    raw_cases = static.constants.get("CANC_C_CASES", [])
    cases = [case for case in raw_cases if isinstance(case, dict)] if isinstance(raw_cases, list) else []
    if not cases:
        static.warnings.append("CANC_C_CASES was not found or could not be evaluated.")
    return CancCaseConfiguration(static.source_name, cases, static.call_names, static.warnings)


def _check(
    category: str,
    severity: str,
    summary: str,
    evidence: dict[str, Any],
    rule: str,
    next_step: str,
) -> ConfigurationCheck:
    return ConfigurationCheck(category, severity, summary, evidence, rule, next_step)


def _messages_by_name(database: DbcDatabase) -> dict[str, list[DbcMessage]]:
    result: dict[str, list[DbcMessage]] = defaultdict(list)
    for message in database.messages:
        result[message.name.casefold()].append(message)
    return result


def _raw_to_physical(raw: int, signal: DbcSignal) -> float:
    signed = raw
    if signal.is_signed and raw & (1 << (signal.length - 1)):
        signed -= 1 << signal.length
    return signed * signal.factor + signal.offset


def _valid_raw_value(raw: Any, signal: DbcSignal) -> bool:
    return isinstance(raw, int) and not isinstance(raw, bool) and 0 <= raw < 1 << signal.length


def _outside_physical_range(value: float, signal: DbcSignal) -> bool:
    """Compare rounded engineering values without turning an exact DBC endpoint into a warning."""

    tolerance = 1e-9 * max(
        1.0,
        abs(value),
        abs(signal.minimum) if signal.minimum is not None else 0.0,
        abs(signal.maximum) if signal.maximum is not None else 0.0,
    )
    return (
        signal.minimum is not None
        and value < signal.minimum - tolerance
        or signal.maximum is not None
        and value > signal.maximum + tolerance
    )


def _normal_raw_vectors(route: dict[str, Any]) -> list[int]:
    values: list[int] = []
    for name, candidate in route.items():
        if (
            isinstance(name, str)
            and name.endswith("_Values")
            and "Invalid" not in name
            and "OutofRange" not in name
            and isinstance(candidate, list)
        ):
            values.extend(value for value in candidate if isinstance(value, int) and not isinstance(value, bool))
    return values


def _has_description(signal: DbcSignal, token: str) -> bool:
    return any(token in label.casefold() for label in signal.value_descriptions.values())


def _unique_message(candidates: list[DbcMessage]) -> DbcMessage | None:
    return candidates[0] if len(candidates) == 1 else None


def _parse_raw_hex(value: object) -> int | None:
    """Read the generated case-config raw hexadecimal representation without coercing errors."""

    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if not isinstance(value, str):
        return None
    try:
        return int(value.strip(), 16)
    except ValueError:
        return None


def _key_frame_check(
    key_frame: str,
    carrying_frame: str,
    key_frames: dict[str, bool],
    messages_by_name: dict[str, list[DbcMessage]],
) -> tuple[bool, str]:
    if key_frames.get(key_frame) is not True:
        return False, f"Configured key frame '{key_frame}' is not marked true in KEY_TX_FRAMES."
    key_message = _unique_message(messages_by_name.get(key_frame.casefold(), []))
    carrying_message = _unique_message(messages_by_name.get(carrying_frame.casefold(), []))
    if key_message is None:
        return False, f"Configured key frame '{key_frame}' is missing or ambiguous in the imported DBC."
    if carrying_message is None:
        return False, f"Carrying frame '{carrying_frame}' is missing or ambiguous in the imported DBC."
    if not key_message.senders or not carrying_message.senders:
        return False, (
            f"Configured key frame '{key_frame}' is marked, but DBC sender metadata is unavailable "
            "for the key or carrying frame; arbitration cannot be verified."
        )
    shared_senders = set(key_message.senders).intersection(carrying_message.senders)
    if not shared_senders:
        return False, f"Key frame '{key_frame}' and carrying frame '{carrying_frame}' have no shared DBC sender."
    peers = [
        candidate
        for definitions in messages_by_name.values()
        for candidate in definitions
        if candidate.frame_id is not None
        and set(candidate.senders).intersection(key_message.senders)
    ]
    if peers and min(peers, key=lambda candidate: candidate.frame_id or 0).name != key_frame:
        return False, (
            f"DBC arbitration selects '{min(peers, key=lambda candidate: candidate.frame_id or 0).name}' "
            f"rather than configured key frame '{key_frame}'."
        )
    return True, f"Configured key frame '{key_frame}' is marked and DBC-aligned."


def audit_configuration(
    canc: CancConfiguration | None,
    edr: EdrConfiguration | None,
    database: DbcDatabase,
    case_configuration: CancCaseConfiguration | None = None,
) -> ConfigurationAudit:
    """Compare static source declarations with imported DBC metadata; never modify either."""

    audit = ConfigurationAudit()
    messages_by_name = _messages_by_name(database)
    if canc is None:
        audit.checks.append(
            _check(
                "CAN-C configuration source",
                "review",
                "No CAN-C configuration source is imported; key-frame and fault-route eligibility cannot be verified.",
                {},
                "Static CAN-C configuration is required for source-backed on-fail eligibility.",
                "Import the project canc_config.py through the configuration-evidence panel.",
            )
        )
    else:
        for warning in canc.warnings:
            audit.checks.append(
                _check(
                    "CAN-C configuration import",
                    "review",
                    warning,
                    {"source_name": canc.source_name},
                    "Only declarative literals and dictionary lookups are evaluated; source code is never executed.",
                    "Resolve the named expression or export a declarative configuration profile.",
                )
            )
        for frame_name, definition in canc.messages.items():
            message = _unique_message(messages_by_name.get(frame_name.casefold(), []))
            if message is None:
                audit.checks.append(
                    _check(
                        "CAN-C to DBC mapping",
                        "review",
                        f"CAN-C frame '{frame_name}' is missing or ambiguous in the imported DBC.",
                        {"frame": frame_name, "source_name": canc.source_name},
                        "Every configured signal route must resolve to one DBC message before validation.",
                        "Import the matching DBC revision or resolve the configuration frame name.",
                    )
                )
                continue
            for signal_name in definition.get("signals", []):
                if not isinstance(signal_name, str):
                    continue
                if not any(signal.name == signal_name for signal in message.signals):
                    audit.checks.append(
                        _check(
                            "CAN-C signal mapping",
                            "review",
                            f"Configured signal '{signal_name}' on '{frame_name}' is not present in the imported DBC.",
                            {"frame": frame_name, "signal": signal_name, "dbc_message": message.name},
                            "Normal and fault simulation values must reference a defined DBC signal.",
                            "Confirm the configuration/DBC revision pair and correct the source-owned mapping if needed.",
                        )
                    )
        for route_name, route in canc.routes.items():
            frame_name, signal_name = route["frame"], route["signal"]
            message = _unique_message(messages_by_name.get(frame_name.casefold(), []))
            signal = (
                next((candidate for candidate in message.signals if candidate.name == signal_name), None)
                if message
                else None
            )
            evidence = {"route": route_name, "frame": frame_name, "signal": signal_name}
            if message is None or signal is None:
                audit.checks.append(
                    _check(
                        "DBC route verification",
                        "review",
                        f"Route '{route_name}' cannot be compared because its frame/signal is absent or ambiguous in the imported DBC.",
                        evidence,
                        "Raw/physical values and fault eligibility are checked only on an unambiguous DBC route.",
                        "Import the matching DBC revision or correct the source route.",
                    )
                )
                continue
            factor = route.get("Factor")
            offset = route.get("Offset")
            if isinstance(factor, (int, float)) and isinstance(offset, (int, float)):
                if not math.isclose(float(factor), signal.factor) or not math.isclose(float(offset), signal.offset):
                    audit.checks.append(
                        _check(
                            "DBC scaling and offset",
                            "warning",
                            f"Route '{route_name}' declares factor/offset {factor}/{offset}, but DBC '{message.name}.{signal.name}' declares {signal.factor}/{signal.offset}.",
                            {**evidence, "config_factor": factor, "config_offset": offset, "dbc_factor": signal.factor, "dbc_offset": signal.offset},
                            "Physical comparison must use the imported DBC formula: signed raw × factor + offset.",
                            "Correct the source-owned config vector or use the matching DBC revision before comparing EDR results.",
                        )
                    )
            normal_values = _normal_raw_vectors(route)
            invalid_normal = [
                raw for raw in normal_values
                if not _valid_raw_value(raw, signal)
                or _outside_physical_range(_raw_to_physical(raw, signal), signal)
            ]
            if invalid_normal:
                audit.checks.append(
                    _check(
                        "Normal simulation values",
                        "warning",
                        f"Route '{route_name}' has {len(invalid_normal)} normal-simulation raw value(s) that do not fit or are outside the DBC physical range.",
                        {**evidence, "invalid_raw_samples": invalid_normal[:20], "dbc_minimum": signal.minimum, "dbc_maximum": signal.maximum},
                        "Normal simulation samples must fit the DBC signal width and decode inside its physical range.",
                        "Correct the source-owned vector or explicitly mark it as a fault vector.",
                    )
                )
            elif normal_values:
                audit.checks.append(
                    _check(
                        "Normal simulation values",
                        "info",
                        f"Route '{route_name}' has {len(normal_values)} normal-simulation raw value(s) that fit the signal and DBC physical range.",
                        {**evidence, "sample_count": len(normal_values), "dbc_factor": signal.factor, "dbc_offset": signal.offset},
                        "Physical comparison used signed raw × DBC factor + DBC offset.",
                        "Compare the matching recorded EDR samples using the EDR field-packing definition.",
                    )
                )
            invalid_vectors = [
                raw for name, values in route.items()
                if isinstance(name, str) and "Invalid_Values" in name and isinstance(values, list)
                for raw in values if isinstance(raw, int) and not isinstance(raw, bool)
            ]
            if invalid_vectors and not _has_description(signal, "invalid"):
                audit.checks.append(
                    _check(
                        "Signal-content eligibility",
                        "review",
                        f"Route '{route_name}' provides invalid-value vectors, but DBC '{message.name}.{signal.name}' has no explicitly labelled invalid enum value.",
                        {**evidence, "invalid_samples": invalid_vectors[:20]},
                        "Signal-content failure requires an explicit DBC invalid encoding and a configured signal-content DTC.",
                        "Confirm the released DBC invalid encoding and configuration DTC mapping before treating the case as applicable.",
                    )
                )
            out_of_range_vectors = [
                raw for name, values in route.items()
                if isinstance(name, str) and "OutofRange_Values" in name and isinstance(values, list)
                for raw in values if isinstance(raw, int) and not isinstance(raw, bool)
            ]
            if out_of_range_vectors:
                reserved = _has_description(signal, "reserved")
                valid_out_of_range = [
                    raw for raw in out_of_range_vectors
                    if _valid_raw_value(raw, signal)
                    and _outside_physical_range(_raw_to_physical(raw, signal), signal)
                ]
                severity = "review" if reserved or len(valid_out_of_range) != len(out_of_range_vectors) else "info"
                audit.checks.append(
                    _check(
                        "Reserved versus out-of-range eligibility",
                        severity,
                        (
                            f"Route '{route_name}' uses out-of-range vectors while the DBC has reserved encodings."
                            if reserved
                            else f"Route '{route_name}' has {len(valid_out_of_range)} encodable DBC-range-exceeding vector(s)."
                        ),
                        {**evidence, "vector_count": len(out_of_range_vectors), "valid_out_of_range_count": len(valid_out_of_range), "dbc_has_reserved_value": reserved},
                        "Out-of-range vectors are allowed only when no reserved encoding applies, the raw value fits the signal width, and its physical value exceeds the DBC range.",
                        "Classify the released DBC codes once as reserved or out-of-range, then correct the source vector accordingly.",
                    )
                )
            logic = route.get("fault_logic", {})
            if not isinstance(logic, dict):
                continue
            key_frame = logic.get("key_message")
            if isinstance(key_frame, str):
                key_ok, key_reason = _key_frame_check(key_frame, frame_name, canc.key_frames, messages_by_name)
                audit.checks.append(
                    _check(
                        "Node-absent key-frame eligibility",
                        "info" if key_ok and logic.get("node_absent_dtc") else "review",
                        key_reason if key_ok else f"{key_reason} Node-absent case is not source-verified.",
                        {**evidence, "key_frame": key_frame, "node_absent_dtc": logic.get("node_absent_dtc")},
                        "Node-absent simulation is eligible only through a configured, DBC-verified key frame with a configured DTC.",
                        "Correct the key-frame declaration, DBC grouping, or DTC mapping before authoring a node-absent case.",
                    )
                )
            timeout_frame = logic.get("non_key_timeout_frame")
            if timeout_frame is None:
                audit.checks.append(
                    _check(
                        "Message-timeout eligibility",
                        "info",
                        f"Route '{route_name}' has no configured non-key timeout frame; no separate message-timeout case is assumed.",
                        evidence,
                        "A separate message-timeout case exists only when a non-key target frame is explicitly configured.",
                        "No action is required unless a released configuration adds a valid slave timeout frame.",
                    )
                )
            elif not isinstance(timeout_frame, str) or canc.key_frames.get(timeout_frame) is True:
                audit.checks.append(
                    _check(
                        "Message-timeout eligibility",
                        "review",
                        f"Route '{route_name}' timeout target '{timeout_frame}' is missing or marked as a key frame.",
                        {**evidence, "key_frame": key_frame, "timeout_frame": timeout_frame},
                        "Message-timeout simulation must target a configured non-key frame.",
                        "Correct the timeout target or do not create a separate message-timeout case.",
                    )
                )
            elif timeout_frame != frame_name:
                audit.checks.append(
                    _check(
                        "Message-timeout recorded-value behavior",
                        "review",
                        f"Route '{route_name}' timeout target '{timeout_frame}' differs from signal-carrying frame '{frame_name}'.",
                        {**evidence, "timeout_frame": timeout_frame, "expected_effect": "May consume the live carrying-frame value rather than preserve last valid."},
                        "For a last-valid message-timeout scenario, stop the configured non-key signal-carrying frame. Unrelated-frame exceptions must be explicit.",
                        "Mark this route as a consumed-value exception or align the target with the carrying frame.",
                    )
                )
            else:
                audit.checks.append(
                    _check(
                        "Message-timeout recorded-value behavior",
                        "info",
                        f"Route '{route_name}' targets its non-key signal-carrying frame '{frame_name}'.",
                        {**evidence, "timeout_frame": timeout_frame},
                        "The message-timeout target is the configured signal-carrying non-key frame.",
                        "Verify qualification/recovery calibration and EDR output against recorded test evidence.",
                    )
                )
            content_dtc = logic.get("message_content_failure_dtcs", {})
            if isinstance(content_dtc, dict):
                for integrity_signal, dtc in content_dtc.items():
                    present = any(candidate.name == integrity_signal for candidate in message.signals)
                    audit.checks.append(
                        _check(
                            "Message-content eligibility",
                            "info" if present and dtc else "review",
                            (
                                f"Configured integrity signal '{integrity_signal}' is present in DBC message '{message.name}'."
                                if present and dtc
                                else f"Configured integrity signal '{integrity_signal}' or its DTC mapping is absent from DBC/configuration."
                            ),
                            {**evidence, "integrity_signal": integrity_signal, "dtc": dtc},
                            "Message-content failure applies only to a source-configured CRC/alive counter signal and DTC mapping.",
                            "Confirm CRC/alive semantics and protection algorithm separately; they are never inferred by this analyzer.",
                        )
                    )
        sleep_or_wait = [
            call for call in canc.call_names if call.casefold() in {"sleep", "wait"}
        ]
        audit.checks.append(
            _check(
                "Continuous simulation scheduling",
                "warning" if sleep_or_wait else "review",
                (
                    f"Static CAN-C source contains potential scheduling calls: {', '.join(sleep_or_wait)}."
                    if sleep_or_wait
                    else "Static CAN-C data contains no direct Sleep/Wait call, but it does not provide an execution trace proving the T0 sequence."
                ),
                {"source_name": canc.source_name, "static_call_names": sleep_or_wait},
                "No-sleep and DTC-after-interval rules must be verified against a generated case plan or execution trace, not inferred from a mapping dictionary.",
                "Import a generated CAN-C case configuration or timestamped simulation trace with T0, interval start/end, and DTC read events.",
            )
        )
    if edr is None:
        audit.checks.append(
            _check(
                "EDR recording configuration",
                "review",
                "No EDR configuration source is imported; interval versus snapshot treatment cannot be verified.",
                {},
                "EDR recording model and sample range determine whether pre/post crash cases are meaningful.",
                "Import the project edr_config.py through the configuration-evidence panel.",
            )
        )
    else:
        for warning in edr.warnings:
            audit.checks.append(
                _check(
                    "EDR configuration import",
                    "review",
                    warning,
                    {"source_name": edr.source_name},
                    "Only declarative literals are imported from source configuration.",
                    "Export a declarative EDR configuration subset if the source uses unsupported expressions.",
                )
            )
        for parameter in edr.parameters:
            name = parameter.get("name", "<unnamed>")
            model = parameter.get("recording_model")
            sample_range = parameter.get("sample_range")
            factor, offset = parameter.get("scaling_factor"), parameter.get("offset")
            if model == "snapshot" and sample_range is None:
                audit.checks.append(
                    _check(
                        "Snapshot parameter handling",
                        "info",
                        f"EDR parameter '{name}' is a snapshot with no recording range; it must not receive pre/post interval simulation cases.",
                        {"parameter": name, "recording_model": model},
                        "Snapshot/no-range parameters are scalar at T0, not interval arrays.",
                        "Keep EDR verification scalar and use the field packing from the EDR configuration.",
                    )
                )
            elif model == "interval" and not sample_range:
                audit.checks.append(
                    _check(
                        "EDR recording interval",
                        "warning",
                        f"EDR parameter '{name}' is declared as interval but has no sample range.",
                        {"parameter": name, "recording_model": model, "sample_range": sample_range},
                        "Interval simulation must have a source-defined T0-relative sample range.",
                        "Correct the source recording configuration before comparing normal or on-fail arrays.",
                    )
                )
            if not all(isinstance(value, (int, float)) and math.isfinite(value) for value in (factor, offset)):
                audit.checks.append(
                    _check(
                        "EDR conversion",
                        "warning",
                        f"EDR parameter '{name}' has non-finite or missing scaling/offset metadata.",
                        {"parameter": name, "scaling_factor": factor, "offset": offset},
                        "EDR raw/physical comparison requires an explicit finite factor and offset.",
                        "Resolve the EDR conversion source before comparing values.",
                    )
                )
    _audit_generated_case_configuration(audit, case_configuration, messages_by_name)
    return audit


def _audit_generated_case_configuration(
    audit: ConfigurationAudit,
    case_configuration: CancCaseConfiguration | None,
    messages_by_name: dict[str, list[DbcMessage]],
) -> None:
    """Check generated-plan timing, conversion, fault scope, and DTC ordering declarations."""

    if case_configuration is None:
        audit.checks.append(
            _check(
                "Generated CAN-C case plan",
                "review",
                "No generated CANC_C_CASES source is imported; no-sleep, T0 ordering, interval completion, and DTC-read-order declarations cannot be checked statically.",
                {},
                "Execution-order assertions require the generated CAN-C case plan or a timestamped simulation trace.",
                "Import the generated canc_c_config.py when it is source-complete, or attach a timestamped execution trace.",
            )
        )
        return
    for warning in case_configuration.warnings:
        audit.checks.append(
            _check(
                "Generated CAN-C case import",
                "review",
                warning,
                {"source_name": case_configuration.source_name},
                "Only declarative CANC_C_CASES data is parsed; selected Python is never executed.",
                "Regenerate a declarative case configuration or resolve the named unsupported expression.",
            )
        )
    scheduling_calls = [
        call for call in case_configuration.call_names if call.casefold() in {"sleep", "wait"}
    ]
    audit.checks.append(
        _check(
            "Continuous simulation scheduling",
            "warning" if scheduling_calls else "review",
            (
                f"Generated case source contains potential scheduling calls: {', '.join(scheduling_calls)}."
                if scheduling_calls
                else "Generated case data contains no direct Sleep/Wait call, but a configuration file cannot prove runtime scheduling."
            ),
            {"source_name": case_configuration.source_name, "static_call_names": scheduling_calls},
            "Drive simulation continuously on the source-defined sampling grid with trigger at T0; do not insert sleeps.",
            "Use a timestamped simulation trace to verify actual schedule and T0 order.",
        )
    )
    for case in case_configuration.cases:
        name = str(case.get("name") or "<unnamed case>")
        fault_mode = case.get("fault_mode")
        timing_scope = case.get("timing_scope")
        evidence = {
            "case": name,
            "fault_mode": fault_mode,
            "timing_scope": timing_scope,
            "recording_model": case.get("recording_model"),
        }
        if fault_mode in {"signal_never_received", "variant_code_error"} and timing_scope != "full":
            audit.checks.append(
                _check(
                    "Full-only fault scope",
                    "warning",
                    f"Case '{name}' uses {fault_mode} with scope '{timing_scope}', not the required full-only scope.",
                    evidence,
                    "Signal-never-received and variant-code cases require variant/ignition behavior and cannot be split into pre/post recording windows.",
                    "Correct the generated case scope to full-only.",
                )
            )
        signal_name, frame_name = case.get("signal"), case.get("frame")
        message = _unique_message(messages_by_name.get(frame_name.casefold(), [])) if isinstance(frame_name, str) else None
        signal = (
            next((candidate for candidate in message.signals if candidate.name == signal_name), None)
            if message and isinstance(signal_name, str)
            else None
        )
        if signal:
            factor, offset = case.get("factor"), case.get("offset")
            if isinstance(factor, (int, float)) and isinstance(offset, (int, float)):
                if not math.isclose(float(factor), signal.factor) or not math.isclose(float(offset), signal.offset):
                    audit.checks.append(
                        _check(
                            "Generated-case DBC conversion",
                            "warning",
                            f"Case '{name}' factor/offset {factor}/{offset} differs from DBC {signal.factor}/{signal.offset}.",
                            {**evidence, "dbc_message": message.name, "dbc_factor": signal.factor, "dbc_offset": signal.offset},
                            "Both input and expected values must be compared using signed raw × DBC factor + DBC offset.",
                            "Regenerate the case from the matching DBC source or correct the source case configuration.",
                        )
                    )
            points = case.get("points", [])
            if isinstance(points, list):
                mismatches: list[dict[str, Any]] = []
                invalid_normal: list[dict[str, Any]] = []
                for point in points:
                    if not isinstance(point, dict):
                        continue
                    raw = _parse_raw_hex(point.get("in_hex"))
                    physical = point.get("in_phys")
                    if raw is None or not isinstance(physical, (int, float)):
                        continue
                    decoded = _raw_to_physical(raw, signal)
                    if not math.isclose(decoded, float(physical), abs_tol=1e-6):
                        mismatches.append({"t_s": point.get("t_s"), "raw": point.get("in_hex"), "config_physical": physical, "dbc_physical": decoded})
                    if fault_mode is None and (
                        not _valid_raw_value(raw, signal)
                        or _outside_physical_range(decoded, signal)
                    ):
                        invalid_normal.append({"t_s": point.get("t_s"), "raw": point.get("in_hex"), "physical": decoded})
                if mismatches:
                    audit.checks.append(
                        _check(
                            "Generated normal/on-fail value comparison",
                            "warning",
                            f"Case '{name}' has {len(mismatches)} input raw/physical point(s) that disagree with DBC decoding.",
                            {**evidence, "mismatch_samples": mismatches[:20]},
                            "Compare generated values with DBC physical = signed raw × factor + offset.",
                            "Correct source-owned vectors or the DBC/configuration revision pair before use.",
                        )
                    )
                if invalid_normal:
                    audit.checks.append(
                        _check(
                            "Generated normal simulation",
                            "warning",
                            f"Normal case '{name}' has {len(invalid_normal)} point(s) outside the DBC width or physical range.",
                            {**evidence, "invalid_samples": invalid_normal[:20]},
                            "Normal simulation points must be DBC-valid and encodable.",
                            "Correct the normal vector or label the points as an approved fault scenario.",
                        )
                    )
        dtc_codes, dtc_status = case.get("dtc_codes"), case.get("dtc_status")
        if fault_mode is None and dtc_codes:
            audit.checks.append(
                _check(
                    "Normal-simulation DTC expectation",
                    "warning",
                    f"Normal case '{name}' contains CAN fault DTC code(s).",
                    {**evidence, "dtc_codes": dtc_codes, "dtc_status": dtc_status},
                    "Normal simulation carries no on-fail CAN DTC; project crash-lock DTCs are a separate diagnostic expectation.",
                    "Remove unsupported on-fail DTC expectations or classify the case as an on-fail case.",
                )
            )
        elif fault_mode in {"uv_ov", "uv", "ov"} and dtc_status not in {8, "08", "0x08"}:
            audit.checks.append(
                _check(
                    "UV/OV DTC status",
                    "warning",
                    f"UV/OV case '{name}' does not declare status 08.",
                    {**evidence, "dtc_status": dtc_status},
                    "Source policy requires UV/OV DTC status 08.",
                    "Confirm the DTC status source and correct the generated expectation.",
                )
            )
        elif fault_mode and timing_scope != "pre" and dtc_status not in {11, "0B", "0x0B"}:
            audit.checks.append(
                _check(
                    "Active CAN-fault DTC status",
                    "review",
                    f"Active fault case '{name}' has status '{dtc_status}', not source-expected 0B.",
                    {**evidence, "dtc_status": dtc_status},
                    "Configuration-backed active CAN fault DTCs use 0B; exceptions require source-owned evidence.",
                    "Confirm whether the fault remains active at Read DTC and correct the case expectation if necessary.",
                )
            )
        elif fault_mode and timing_scope == "pre" and dtc_status in {8, "08", "0x08"}:
            audit.checks.append(
                _check(
                    "Post-crash-healed DTC status",
                    "review",
                    f"Pre-crash case '{name}' declares historic status 08; ignition-cycle evidence before Read DTC is required.",
                    {**evidence, "dtc_status": dtc_status},
                    "A healed pre-crash fault is historic 08 only with a documented ignition cycle before Read DTC; otherwise report healed state.",
                    "Attach ignition-cycle and Read-DTC timing evidence, or mark the healed status rather than historic.",
                )
            )
        steps = case.get("steps", [])
        actions = [
            step.get("action", "").casefold()
            for step in steps
            if isinstance(step, dict) and isinstance(step.get("action"), str)
        ] if isinstance(steps, list) else []
        read_positions = [index for index, action in enumerate(actions) if "read dtc" in action]
        simulation_positions = [index for index, action in enumerate(actions) if "simulate" in action or "drive" in action]
        if read_positions and simulation_positions and min(read_positions) < max(simulation_positions):
            audit.checks.append(
                _check(
                    "Read-DTC ordering",
                    "warning",
                    f"Case '{name}' places a Read DTC action before its final simulation/drive action.",
                    {**evidence, "actions": actions},
                    "Read DTC only after recording-interval simulation and required qualification time.",
                    "Reorder the generated case steps and record the qualification delay.",
                )
            )
