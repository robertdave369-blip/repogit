"""DBC decoding, independent timing analysis, and evidence-based findings."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from hashlib import sha1
from statistics import fmean, median, pstdev
from typing import Any, Iterable

from .dbc import DbcDatabase, attribute_frame, motorola_bit_positions
from .faults import FAULT_OPTIONS, analyse_fault_evidence
from .models import (
    AnalysisSettings,
    Attribution,
    AttributionResult,
    CanFrame,
    DecodedSignal,
    DbcMessage,
    DbcSignal,
    DtcStatusRecord,
    FaultEvent,
    Finding,
    IdentifierType,
    TimingGap,
    TimingMetrics,
)
from .onfail_policy import OnFailPolicy


def _stream_id(frame: CanFrame) -> str:
    raw = "|".join(
        (
            frame.bus,
            frame.channel,
            str(frame.can_id),
            frame.identifier_type.value,
            frame.capture_direction.value,
        )
    )
    return sha1(raw.encode("utf-8")).hexdigest()[:16]


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * percentile / 100
    lower, upper = int(rank), min(int(rank) + 1, len(ordered) - 1)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (rank - lower)


def _frame_evidence(frame: CanFrame) -> dict[str, Any]:
    return {
        "source_name": frame.source_name,
        "source_line": frame.source_line,
        "raw_line": frame.raw_line,
        "timestamp": frame.timestamp,
        "bus": frame.bus,
        "channel": frame.channel,
        "capture_direction": frame.capture_direction.value,
        "can_id": frame.can_id,
        "can_id_hex": frame.can_id_hex,
        "identifier_type": frame.identifier_type.value,
        "declared_length": frame.declared_length,
        "parsed_byte_count": len(frame.payload),
        "payload_hex": frame.payload_hex,
    }


def _finding_id(category: str, stream_id: str | None, evidence: dict[str, Any]) -> str:
    identity = f"{category}|{stream_id or ''}|{evidence}"
    return sha1(identity.encode("utf-8")).hexdigest()[:16]


def _finding(
    *,
    category: str,
    severity: str,
    confidence: str,
    summary: str,
    evidence: dict[str, Any],
    rule: str,
    message: str | None,
    signal: str | None,
    next_step: str,
    stream_id: str | None,
) -> Finding:
    return Finding(
        finding_id=_finding_id(category, stream_id, evidence),
        category=category,
        severity=severity,  # type: ignore[arg-type]
        confidence=confidence,  # type: ignore[arg-type]
        summary=summary,
        evidence=evidence,
        rule=rule,
        affected_message=message,
        affected_signal=signal,
        next_step=next_step,
        stream_id=stream_id,
    )


def _extract_raw(payload: tuple[int, ...], signal: DbcSignal) -> int | None:
    if signal.length <= 0:
        return None
    positions = (
        tuple(range(signal.start_bit, signal.start_bit + signal.length))
        if signal.byte_order == "little_endian"
        else motorola_bit_positions(signal.start_bit, signal.length)
    )
    if any(position < 0 or position // 8 >= len(payload) for position in positions):
        return None
    if signal.byte_order == "little_endian":
        raw_data = int.from_bytes(payload, byteorder="little", signed=False)
        return (raw_data >> signal.start_bit) & ((1 << signal.length) - 1)
    raw = 0
    for position in positions:
        raw = (raw << 1) | ((payload[position // 8] >> (position % 8)) & 1)
    return raw


def decode_frame(frame: CanFrame, message: DbcMessage | None) -> list[DecodedSignal]:
    """Decode only one unambiguous, valid DBC definition without padding payloads."""

    if message is None:
        return []
    if not message.valid:
        return [
            DecodedSignal(
                signal.name,
                None,
                None,
                signal.unit,
                None,
                "Unavailable",
                "DBC data for this message is invalid; decoding was not attempted.",
            )
            for signal in message.signals
        ]
    selected_mux_values: dict[str, int] = {}
    for signal in message.signals:
        if signal.is_multiplexer and signal.valid:
            raw = _extract_raw(frame.payload, signal)
            if raw is not None:
                selected_mux_values[signal.name] = raw
    decoded: list[DecodedSignal] = []
    for signal in message.signals:
        if not signal.valid:
            decoded.append(
                DecodedSignal(
                    signal.name,
                    None,
                    None,
                    signal.unit,
                    None,
                    "Unavailable",
                    "DBC signal data is invalid.",
                )
            )
            continue
        if signal.multiplexer_signal:
            selector = selected_mux_values.get(signal.multiplexer_signal)
            if selector is None:
                decoded.append(
                    DecodedSignal(
                        signal.name,
                        None,
                        None,
                        signal.unit,
                        None,
                        "Unavailable",
                        "Multiplex selector metadata or payload data is insufficient.",
                    )
                )
                continue
            if signal.multiplexer_values and selector not in signal.multiplexer_values:
                decoded.append(
                    DecodedSignal(
                        signal.name,
                        None,
                        None,
                        signal.unit,
                        None,
                        "Unavailable",
                        f"Signal is inactive for multiplex selector value {selector}.",
                    )
                )
                continue
        raw = _extract_raw(frame.payload, signal)
        if raw is None:
            decoded.append(
                DecodedSignal(
                    signal.name,
                    None,
                    None,
                    signal.unit,
                    None,
                    "Unavailable",
                    "Payload data is insufficient for this signal; missing bytes were not padded.",
                )
            )
            continue
        signed_raw = raw
        if signal.is_signed and raw & (1 << (signal.length - 1)):
            signed_raw -= 1 << signal.length
        physical = signed_raw * signal.factor + signal.offset
        enum_label = signal.value_descriptions.get(raw)
        status = "Decoded"
        if signal.value_descriptions and enum_label is None:
            status = "Unmapped enumeration value"
        elif (
            signal.minimum is not None
            and physical < signal.minimum
            or signal.maximum is not None
            and physical > signal.maximum
        ):
            status = "Potential DBC-range deviation"
        decoded.append(
            DecodedSignal(
                signal.name,
                signed_raw,
                physical,
                signal.unit,
                enum_label,
                status,
            )
        )
    return decoded


def _expected_cycle(message: DbcMessage | None) -> float | None:
    if message is None or message.cycle_time_ms is None or message.cycle_time_ms <= 0:
        return None
    return message.cycle_time_ms


def calculate_timing(
    stream_id: str,
    frames: list[CanFrame],
    expected_cycle_ms: float | None,
    settings: AnalysisSettings,
) -> TimingMetrics:
    """Calculate timing independently for one bus/channel/ID/type/direction stream."""

    ordered = sorted(frames, key=lambda frame: (frame.timestamp, frame.source_order))
    first, last = ordered[0].timestamp, ordered[-1].timestamp
    intervals = [
        (current.timestamp - previous.timestamp) * 1000
        for previous, current in zip(ordered, ordered[1:])
    ]
    interval_values = [interval for interval in intervals if interval >= 0]
    mean_interval = fmean(interval_values) if interval_values else None
    median_interval = median(interval_values) if interval_values else None
    tolerance = (
        max(expected_cycle_ms * settings.jitter_fraction, settings.absolute_tolerance_ms)
        if expected_cycle_ms is not None
        else None
    )
    stop_threshold = (
        max(expected_cycle_ms * settings.stopped_multiplier, settings.minimum_gap_ms)
        if expected_cycle_ms is not None
        else None
    )
    gaps: list[TimingGap] = []
    burst_count = 0
    within_tolerance = 0
    if expected_cycle_ms is not None:
        for previous, current, interval in zip(ordered, ordered[1:], intervals):
            if interval > stop_threshold:  # type: ignore[operator]
                gaps.append(
                    TimingGap(
                        previous,
                        current,
                        interval,
                        max(0, int(interval // expected_cycle_ms) - 1),
                    )
                )
            if interval < expected_cycle_ms * settings.burst_fraction:
                burst_count += 1
            if abs(interval - expected_cycle_ms) <= tolerance:  # type: ignore[operator]
                within_tolerance += 1
    return TimingMetrics(
        stream_id=stream_id,
        frame_count=len(ordered),
        first_timestamp=first,
        last_timestamp=last,
        capture_duration_ms=(last - first) * 1000,
        mean_interval_ms=mean_interval,
        median_interval_ms=median_interval,
        min_interval_ms=min(interval_values) if interval_values else None,
        max_interval_ms=max(interval_values) if interval_values else None,
        standard_deviation_ms=pstdev(interval_values) if len(interval_values) > 1 else 0.0 if interval_values else None,
        percentile_interval_ms=_percentile(interval_values, settings.percentile),
        expected_cycle_ms=expected_cycle_ms,
        mean_difference_from_expected_ms=(
            mean_interval - expected_cycle_ms
            if mean_interval is not None and expected_cycle_ms is not None
            else None
        ),
        median_difference_from_expected_ms=(
            median_interval - expected_cycle_ms
            if median_interval is not None and expected_cycle_ms is not None
            else None
        ),
        jitter_ms=(
            max(abs(value - expected_cycle_ms) for value in interval_values)
            if expected_cycle_ms is not None and interval_values
            else None
        ),
        long_gap_count=len(gaps),
        burst_count=burst_count,
        estimated_missed_cycles=sum(gap.estimated_missed_cycles for gap in gaps),
        within_tolerance_percent=(
            100 * within_tolerance / len(interval_values)
            if expected_cycle_ms is not None and interval_values
            else None
        ),
        long_gaps=tuple(gaps),
    )


@dataclass(slots=True)
class StreamAnalysis:
    """Results and raw frames for a separately analysed timing stream."""

    stream_id: str
    frames: list[CanFrame]
    attribution: AttributionResult
    metrics: TimingMetrics

    @property
    def message(self) -> DbcMessage | None:
        return self.attribution.candidates[0] if len(self.attribution.candidates) == 1 else None

    def to_dict(self) -> dict[str, Any]:
        message = self.message
        first = self.frames[0]
        return {
            "stream_id": self.stream_id,
            "bus": first.bus,
            "channel": first.channel,
            "capture_direction": first.capture_direction.value,
            "can_id": first.can_id,
            "can_id_hex": first.can_id_hex,
            "identifier_type": first.identifier_type.value,
            "message_name": message.name if message else None,
            "candidate_messages": [candidate.name for candidate in self.attribution.candidates],
            "expected_dlc": message.length if message else None,
            "attribution": self.attribution.classification.value,
            "attribution_rationale": self.attribution.rationale,
            "attribution_confidence": self.attribution.confidence,
            "sender_evidence": list(message.senders) if message else [],
            "receiver_evidence": list(message.receivers) if message else [],
            "metrics": timing_to_dict(self.metrics),
            "status": (
                "Potential timing anomaly requiring engineer review."
                if self.metrics.long_gap_count or self.metrics.burst_count
                else "No configured timing anomaly observed."
            ),
        }


def timing_to_dict(metrics: TimingMetrics) -> dict[str, Any]:
    """Serialize timing metrics and retain exact before/after evidence for each gap."""

    return {
        "frame_count": metrics.frame_count,
        "first_timestamp": metrics.first_timestamp,
        "last_timestamp": metrics.last_timestamp,
        "capture_duration_ms": metrics.capture_duration_ms,
        "mean_interval_ms": metrics.mean_interval_ms,
        "median_interval_ms": metrics.median_interval_ms,
        "min_interval_ms": metrics.min_interval_ms,
        "max_interval_ms": metrics.max_interval_ms,
        "standard_deviation_ms": metrics.standard_deviation_ms,
        "percentile_interval_ms": metrics.percentile_interval_ms,
        "expected_cycle_ms": metrics.expected_cycle_ms,
        "mean_difference_from_expected_ms": metrics.mean_difference_from_expected_ms,
        "median_difference_from_expected_ms": metrics.median_difference_from_expected_ms,
        "jitter_ms": metrics.jitter_ms,
        "long_gap_count": metrics.long_gap_count,
        "burst_count": metrics.burst_count,
        "estimated_missed_cycles": metrics.estimated_missed_cycles,
        "within_tolerance_percent": metrics.within_tolerance_percent,
        "long_gaps": [
            {
                "interval_ms": gap.interval_ms,
                "estimated_missed_cycles": gap.estimated_missed_cycles,
                "before": _frame_evidence(gap.before),
                "after": _frame_evidence(gap.after),
            }
            for gap in metrics.long_gaps
        ],
    }


def _mapping_finding(
    stream: StreamAnalysis,
) -> Finding | None:
    classification = stream.attribution.classification
    if classification not in {
        Attribution.UNKNOWN_ID,
        Attribution.DBC_KNOWN_NON_ASSOCIATED,
        Attribution.AMBIGUOUS_DBC,
    }:
        return None
    frame = stream.frames[0]
    message = stream.message
    return _finding(
        category="Unknown, non-associated, or ambiguous DBC mapping",
        severity="review",
        confidence=stream.attribution.confidence,
        summary=stream.attribution.rationale,
        evidence={
            "representative_frame": _frame_evidence(frame),
            "candidate_messages": [candidate.name for candidate in stream.attribution.candidates],
        },
        rule="Numeric CAN ID and identifier type were matched only against imported DBC definitions.",
        message=message.name if message else None,
        signal=None,
        next_step="Check the DBC revision, active vehicle configuration, and capture identifier-type information.",
        stream_id=stream.stream_id,
    )


def _timing_findings(stream: StreamAnalysis, settings: AnalysisSettings) -> list[Finding]:
    findings: list[Finding] = []
    message = stream.message
    expected = stream.metrics.expected_cycle_ms
    if message is None or expected is None:
        return findings
    stopped_threshold = max(expected * settings.stopped_multiplier, settings.minimum_gap_ms)
    tolerance = max(expected * settings.jitter_fraction, settings.absolute_tolerance_ms)
    ordered = sorted(stream.frames, key=lambda frame: (frame.timestamp, frame.source_order))
    for gap in stream.metrics.long_gaps:
        findings.append(
            _finding(
                category="Potential stopped or missing periodic message",
                severity="review",
                confidence="medium",
                summary=(
                    f"A {gap.interval_ms:.3f} ms gap exceeds the configured "
                    f"{stopped_threshold:.3f} ms threshold."
                ),
                evidence={
                    "expected_cycle_ms": expected,
                    "actual_gap_ms": gap.interval_ms,
                    "applied_threshold_ms": stopped_threshold,
                    "estimated_missed_cycles": gap.estimated_missed_cycles,
                    "frame_before_gap": _frame_evidence(gap.before),
                    "frame_after_gap": _frame_evidence(gap.after),
                },
                rule=(
                    "Potential stop detection applies only to a valid positive DBC cycle time: "
                    f"gap > max({settings.stopped_multiplier:g} x expected cycle, configured minimum gap)."
                ),
                message=message.name,
                signal=None,
                next_step="Review the matching source lines and confirm the DBC cycle time and capture continuity.",
                stream_id=stream.stream_id,
            )
        )
    for previous, current in zip(ordered, ordered[1:]):
        interval = (current.timestamp - previous.timestamp) * 1000
        if expected + tolerance < interval <= stopped_threshold:
            findings.append(
                _finding(
                    category="Timing deviation / late frame",
                    severity="warning",
                    confidence="medium",
                    summary=(
                        f"A {interval:.3f} ms interval exceeds the {expected:.3f} ms expected period "
                        f"by more than the {tolerance:.3f} ms tolerance."
                    ),
                    evidence={"before": _frame_evidence(previous), "after": _frame_evidence(current), "interval_ms": interval},
                    rule=f"expected cycle + max(10% expected cycle, configured absolute tolerance) = {expected + tolerance:.3f} ms.",
                    message=message.name,
                    signal=None,
                    next_step="Review timing against the capture setup and the DBC cycle-time revision.",
                    stream_id=stream.stream_id,
                )
            )
        if interval < expected * settings.burst_fraction:
            findings.append(
                _finding(
                    category="Burst / early frame",
                    severity="warning",
                    confidence="medium",
                    summary=(
                        f"A {interval:.3f} ms interval is below 50% of the "
                        f"{expected:.3f} ms expected period."
                    ),
                    evidence={"before": _frame_evidence(previous), "after": _frame_evidence(current), "interval_ms": interval},
                    rule=f"interval < {settings.burst_fraction * 100:g}% of expected cycle time.",
                    message=message.name,
                    signal=None,
                    next_step="Inspect surrounding recorded traffic and verify whether this DBC message is periodic.",
                    stream_id=stream.stream_id,
                )
            )
            if previous.payload == current.payload:
                findings.append(
                    _finding(
                        category="Repeated frame burst",
                        severity="warning",
                        confidence="high",
                        summary="Identical payload frames occurred unusually close together.",
                        evidence={"before": _frame_evidence(previous), "after": _frame_evidence(current), "interval_ms": interval},
                        rule=f"Identical consecutive payloads with interval < {settings.burst_fraction * 100:g}% of expected cycle time.",
                        message=message.name,
                        signal=None,
                        next_step="Compare raw source lines and review the capture configuration before interpreting the repetition.",
                        stream_id=stream.stream_id,
                    )
                )
    return findings


def _frame_findings(
    stream: StreamAnalysis,
    database: DbcDatabase,
) -> list[Finding]:
    findings: list[Finding] = []
    message = stream.message
    for frame in stream.frames:
        for warning in frame.parse_warnings:
            findings.append(
                _finding(
                    category="Log or data-quality issue",
                    severity="warning",
                    confidence="high",
                    summary=warning.message,
                    evidence=_frame_evidence(frame),
                    rule=f"Parser warning: {warning.code}.",
                    message=message.name if message else None,
                    signal=None,
                    next_step="Inspect the original raw line and capture/export configuration.",
                    stream_id=stream.stream_id,
                )
            )
        match = database.match(frame)
        current_message = match.unambiguous_message
        if current_message and current_message.length is not None and frame.declared_length != current_message.length:
            findings.append(
                _finding(
                    category="DLC or payload-length discrepancy",
                    severity="warning",
                    confidence="high",
                    summary=(
                        f"Observed declared length {frame.declared_length} differs from DBC length "
                        f"{current_message.length}."
                    ),
                    evidence={"frame": _frame_evidence(frame), "dbc_expected_length": current_message.length},
                    rule="Observed declared length was compared with the unambiguous imported DBC message length.",
                    message=current_message.name,
                    signal=None,
                    next_step="Check the DBC revision and whether the capture used CAN FD or a different message variant.",
                    stream_id=stream.stream_id,
                )
            )
        for signal in decode_frame(frame, current_message):
            if signal.status == "Unavailable":
                findings.append(
                    _finding(
                        category="DLC or payload-length discrepancy",
                        severity="warning",
                        confidence="high",
                        summary=f"Signal '{signal.name}' is unavailable: {signal.reason}",
                        evidence=_frame_evidence(frame),
                        rule="Signals are not decoded when the recorded payload lacks required bits or the DBC mapping is invalid.",
                        message=current_message.name if current_message else None,
                        signal=signal.name,
                        next_step="Inspect declared and parsed payload lengths together with the matching DBC definition.",
                        stream_id=stream.stream_id,
                    )
                )
            elif signal.status == "Potential DBC-range deviation":
                findings.append(
                    _finding(
                        category="Potential DBC-range deviation",
                        severity="review",
                        confidence="medium",
                        summary=(
                            f"Decoded physical value {signal.physical_value:g} {signal.unit} for '{signal.name}' "
                            "is outside the imported DBC minimum/maximum range."
                        ),
                        evidence={**_frame_evidence(frame), "raw_value": signal.raw_value, "physical_value": signal.physical_value},
                        rule="Decoded physical value was compared with the imported DBC min/max metadata; this is not a confirmed ECU failure.",
                        message=current_message.name if current_message else None,
                        signal=signal.name,
                        next_step="Check the DBC signal limits and vehicle/configuration context for this recorded value.",
                        stream_id=stream.stream_id,
                    )
                )
            elif signal.status == "Unmapped enumeration value":
                findings.append(
                    _finding(
                        category="Unmapped enumeration value",
                        severity="review",
                        confidence="high",
                        summary=f"Raw value {signal.raw_value} for '{signal.name}' has no imported DBC enumeration label.",
                        evidence={**_frame_evidence(frame), "raw_value": signal.raw_value},
                        rule="Decoded raw value was not present in the imported DBC value descriptions.",
                        message=current_message.name if current_message else None,
                        signal=signal.name,
                        next_step="Check the DBC revision or identify whether this capture uses another message variant.",
                        stream_id=stream.stream_id,
                    )
                )
    return findings


def _fault_evidence_findings(
    events: Iterable[FaultEvent],
    dtc_records: Iterable[DtcStatusRecord],
) -> list[Finding]:
    """Turn configured fault-state candidates and recorded diagnostics into traceable findings."""

    findings: list[Finding] = []
    for event in events:
        findings.append(
            _finding(
                category=event.category,
                severity="review",
                confidence=event.confidence,
                summary=event.summary,
                evidence=event.evidence,
                rule=event.rule,
                message=event.message_name,
                signal=None,
                next_step=(
                    "Compare the configured monitor delay with source-owned qualification/recovery "
                    "requirements and recorded DTC evidence."
                ),
                stream_id=event.stream_id,
            )
        )
    for record in dtc_records:
        findings.append(
            _finding(
                category="Recorded UDS DTC status",
                severity="info",
                confidence="high",
                summary=(
                    f"Recorded UDS response reports DTC {record.dtc} with status "
                    f"0x{record.status_byte:02X} ({', '.join(record.status_flags) or 'no set status bits'})."
                ),
                evidence=record.to_dict(),
                rule="ISO-TP UDS positive ReadDTCInformation response (0x59) was reconstructed from recorded source frames.",
                message=None,
                signal=None,
                next_step="Compare the recorded DTC/status with the project diagnostic specification and the exact capture phase.",
                stream_id=None,
            )
        )
    return findings


def _condense_repetitive_findings(findings: Iterable[Finding]) -> list[Finding]:
    """Group per-frame decode discrepancies while retaining representative source evidence."""

    condense_categories = {
        "DLC or payload-length discrepancy",
        "Potential DBC-range deviation",
        "Unmapped enumeration value",
        "Timing deviation / late frame",
        "Burst / early frame",
        "Repeated frame burst",
    }
    condensed: list[Finding] = []
    groups: dict[tuple[str, str | None, str | None, str | None], list[Finding]] = defaultdict(list)
    for finding in findings:
        if finding.category not in condense_categories:
            condensed.append(finding)
            continue
        groups[
            (
                finding.category,
                finding.stream_id,
                finding.affected_message,
                finding.affected_signal,
            )
        ].append(finding)
    for group in groups.values():
        first = group[0]
        if len(group) == 1:
            condensed.append(first)
            continue
        condensed.append(
            Finding(
                finding_id=first.finding_id,
                category=first.category,
                severity=first.severity,
                confidence=first.confidence,
                summary=f"{len(group)} occurrences. First observed: {first.summary}",
                evidence={
                    "occurrence_count": len(group),
                    "representative_evidence": [finding.evidence for finding in group[:20]],
                    "evidence_note": "Exports retain full frame and decoded-signal data; this finding panel retains 20 representative source records.",
                },
                rule=first.rule,
                affected_message=first.affected_message,
                affected_signal=first.affected_signal,
                next_step=first.next_step,
                stream_id=first.stream_id,
            )
        )
    return condensed


@dataclass(slots=True)
class AnalysisResult:
    """Complete offline analysis result consumable by the local API and exports."""

    streams: list[StreamAnalysis]
    findings: list[Finding]
    settings: AnalysisSettings
    target_ecu: str
    fault_events: list[Any]
    dtc_records: list[Any]
    policy_source: str | None

    def overview(self) -> dict[str, Any]:
        def occurrence_count(category: str) -> int:
            return sum(
                int(finding.evidence.get("occurrence_count", 1))
                for finding in self.findings
                if finding.category == category
            )

        all_frames = [frame for stream in self.streams for frame in stream.frames]
        counts = Counter(stream.attribution.classification.value for stream in self.streams)
        timestamps = [frame.timestamp for frame in all_frames]
        return {
            "total_parsed_frames": len(all_frames),
            "capture_duration_ms": (max(timestamps) - min(timestamps)) * 1000 if timestamps else 0,
            "active_channels": len({(frame.bus, frame.channel) for frame in all_frames}),
            "unique_observed_ids": len({frame.can_id for frame in all_frames}),
            "dbc_matched_ids": sum(
                1
                for stream in self.streams
                if stream.attribution.classification
                not in {Attribution.UNKNOWN_ID, Attribution.AMBIGUOUS_DBC}
            ),
            "unknown_ids": counts[Attribution.UNKNOWN_ID.value],
            "dbc_known_non_associated_ids": counts[Attribution.DBC_KNOWN_NON_ASSOCIATED.value],
            "ecu_transmit_candidates": counts[Attribution.ECU_TX_CANDIDATE.value],
            "ecu_receive_candidates": counts[Attribution.ECU_RX_CANDIDATE.value],
            "timing_anomalies": sum(
                occurrence_count(category)
                for category in {"Timing deviation / late frame", "Burst / early frame", "Repeated frame burst"}
            ),
            "potential_stopped_gaps": occurrence_count("Potential stopped or missing periodic message"),
            "dlc_mismatches": occurrence_count("DLC or payload-length discrepancy"),
            "signal_range_and_enum_findings": (
                occurrence_count("Potential DBC-range deviation")
                + occurrence_count("Unmapped enumeration value")
            ),
            "potential_timeout_qualifications": sum(
                event.monitor_scope == "message" for event in self.fault_events
            ),
            "potential_node_absence_events": sum(
                event.monitor_scope == "sender-node" for event in self.fault_events
            ),
            "recorded_dtc_status_records": len(self.dtc_records),
        }


def analyze(
    frames: Iterable[CanFrame],
    database: DbcDatabase,
    target_ecu: str,
    settings: AnalysisSettings | None = None,
    identifier_overrides: dict[str, IdentifierType] | None = None,
    onfail_policy: OnFailPolicy | None = None,
) -> AnalysisResult:
    """Analyse a capture without combining channel or interface-direction streams."""

    active_settings = settings or AnalysisSettings()
    materialized_frames = list(frames)
    grouped: dict[tuple[str, str, int, IdentifierType, object], list[CanFrame]] = defaultdict(list)
    for frame in materialized_frames:
        grouped[frame.stream_key].append(frame)
    streams: list[StreamAnalysis] = []
    findings: list[Finding] = []
    for grouped_frames in grouped.values():
        first = grouped_frames[0]
        override = (identifier_overrides or {}).get(first.source_name)
        attribution = attribute_frame(first, database, target_ecu, override)
        message = attribution.candidates[0] if len(attribution.candidates) == 1 else None
        stream = StreamAnalysis(
            _stream_id(first),
            sorted(grouped_frames, key=lambda frame: (frame.timestamp, frame.source_order)),
            attribution,
            calculate_timing(
                _stream_id(first),
                grouped_frames,
                _expected_cycle(message),
                active_settings,
            ),
        )
        streams.append(stream)
        mapping = _mapping_finding(stream)
        if mapping:
            findings.append(mapping)
        findings.extend(_timing_findings(stream, active_settings))
        findings.extend(_frame_findings(stream, database))
    streams.sort(key=lambda stream: (stream.frames[0].can_id, stream.frames[0].channel, stream.frames[0].capture_direction.value))
    fault_events, dtc_records = analyse_fault_evidence(
        streams,
        materialized_frames,
        active_settings,
        onfail_policy,
    )
    findings.extend(_fault_evidence_findings(fault_events, dtc_records))
    findings = _condense_repetitive_findings(findings)
    return AnalysisResult(
        streams,
        findings,
        active_settings,
        target_ecu,
        fault_events,
        dtc_records,
        onfail_policy.source_name if onfail_policy else None,
    )
