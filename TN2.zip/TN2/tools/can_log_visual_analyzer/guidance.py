"""Focused, evidence-led offline guidance for a selected CAN message and fault family."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Iterable

from .configuration_audit import CancConfiguration
from .dbc import DbcDatabase, motorola_bit_positions
from .models import AnalysisSettings, CanFrame, DbcMessage, DbcSignal
from .onfail_policy import OnFailPolicy


class GuidanceError(ValueError):
    """Raised when a requested message focus cannot be resolved safely."""


def _can_id(value: str) -> int:
    normalized = value.strip().casefold()
    if normalized.startswith("0x"):
        normalized = normalized[2:]
    if not normalized or any(character not in "0123456789abcdef" for character in normalized):
        raise GuidanceError(f"Invalid CAN identifier '{value}'. Use hexadecimal, for example 0x127.")
    return int(normalized, 16)


def _format_id(can_id: int) -> str:
    return f"0x{can_id:08X}" if can_id > 0x7FF else f"0x{can_id:03X}"


def _raw_signal(frame: CanFrame, signal: DbcSignal) -> int | None:
    positions = (
        tuple(range(signal.start_bit, signal.start_bit + signal.length))
        if signal.byte_order == "little_endian"
        else motorola_bit_positions(signal.start_bit, signal.length)
    )
    if signal.length <= 0 or any(position < 0 or position // 8 >= len(frame.payload) for position in positions):
        return None
    if signal.byte_order == "little_endian":
        packed = int.from_bytes(frame.payload, byteorder="little", signed=False)
        return (packed >> signal.start_bit) & ((1 << signal.length) - 1)
    raw = 0
    for position in positions:
        raw = (raw << 1) | ((frame.payload[position // 8] >> (position % 8)) & 1)
    return raw


def _frame_filter(frame: CanFrame) -> dict[str, Any]:
    return {
        "source_name": frame.source_name,
        "source_line": frame.source_line,
        "timestamp": frame.timestamp,
        "bus": frame.bus,
        "channel": frame.channel,
        "capture_direction": frame.capture_direction.value,
        "can_id_hex": frame.can_id_hex,
        "declared_length": frame.declared_length,
        "parsed_byte_count": len(frame.payload),
    }


def _unique_message(messages: Iterable[DbcMessage]) -> DbcMessage | None:
    definitions = list(messages)
    return definitions[0] if len(definitions) == 1 else None


def _route_candidates(canc: CancConfiguration | None, message_names: set[str]) -> list[tuple[str, dict[str, Any]]]:
    if canc is None:
        return []
    return [
        (name, route)
        for name, route in canc.routes.items()
        if str(route.get("frame", "")).casefold() in message_names
    ]


def _counter_summary(
    streams: dict[tuple[str, str, str], list[CanFrame]],
    signal: DbcSignal | None,
    detection_count: int | None,
    recovery_count: int | None,
) -> dict[str, Any]:
    if signal is None:
        return {
            "status": "Unavailable",
            "reason": "The selected integrity signal is absent or ambiguous in the imported DBC definition.",
        }
    modulo = 1 << signal.length
    stream_results: list[dict[str, Any]] = []
    total_transitions = 0
    total_mismatches = 0
    qualifying_events: list[dict[str, Any]] = []
    for (bus, channel, direction), frames in streams.items():
        values = [(frame, _raw_signal(frame, signal)) for frame in frames]
        available = [(frame, value) for frame, value in values if value is not None]
        mismatch_run = 0
        valid_run = 0
        qualified = False
        max_mismatch_run = 0
        stream_mismatch_count = 0
        mismatches: list[dict[str, Any]] = []
        transition_count = 0
        for (previous_frame, previous), (current_frame, current) in zip(available, available[1:]):
            transition_count += 1
            expected = (previous + 1) % modulo
            if current == expected:
                mismatch_run = 0
                if qualified:
                    valid_run += 1
                    if recovery_count and valid_run >= recovery_count:
                        qualifying_events.append(
                            {
                                "kind": "configured-recovery candidate",
                                "timestamp": current_frame.timestamp,
                                "required_good_receptions": recovery_count,
                                "source_line": current_frame.source_line,
                                "stream": {"bus": bus, "channel": channel, "capture_direction": direction},
                            }
                        )
                        qualified = False
                        valid_run = 0
                continue
            valid_run = 0
            mismatch_run += 1
            stream_mismatch_count += 1
            max_mismatch_run = max(max_mismatch_run, mismatch_run)
            total_mismatches += 1
            if len(mismatches) < 20:
                mismatches.append(
                    {
                        "previous": _frame_filter(previous_frame),
                        "current": _frame_filter(current_frame),
                        "expected_raw": expected,
                        "observed_raw": current,
                    }
                )
            if detection_count and mismatch_run == detection_count:
                qualifying_events.append(
                    {
                        "kind": "configured-qualification candidate",
                        "timestamp": current_frame.timestamp,
                        "required_bad_receptions": detection_count,
                        "source_line": current_frame.source_line,
                        "stream": {"bus": bus, "channel": channel, "capture_direction": direction},
                    }
                )
                qualified = True
        total_transitions += transition_count
        stream_results.append(
            {
                "bus": bus,
                "channel": channel,
                "capture_direction": direction,
                "frame_count": len(frames),
                "decoded_frame_count": len(available),
                "transition_count": transition_count,
                "mismatch_count": stream_mismatch_count,
                "max_consecutive_mismatch_count": max_mismatch_run,
                "first_value": available[0][1] if available else None,
                "last_value": available[-1][1] if available else None,
                "observed_values": sorted({value for _, value in available}),
                "mismatch_examples": mismatches,
            }
        )
    return {
        "status": "No counter sequence mismatch observed" if total_mismatches == 0 else "Counter sequence mismatch observed",
        "signal": signal.name,
        "bit_length": signal.length,
        "modulo": modulo,
        "expected_transition": f"increment by one with {modulo - 1}->0 rollover",
        "transition_count": total_transitions,
        "mismatch_count": total_mismatches,
        "configured_events": qualifying_events,
        "streams": stream_results,
    }


def _frame_timing_summary(
    streams: dict[tuple[str, str, str], list[CanFrame]],
    expected_cycle_ms: float | None,
    settings: AnalysisSettings,
) -> dict[str, Any]:
    threshold = (
        max(expected_cycle_ms * settings.stopped_multiplier, settings.minimum_gap_ms)
        if expected_cycle_ms is not None
        else None
    )
    all_intervals: list[float] = []
    gaps: list[dict[str, Any]] = []
    for (bus, channel, direction), frames in streams.items():
        for before, after in zip(frames, frames[1:]):
            interval = (after.timestamp - before.timestamp) * 1000
            all_intervals.append(interval)
            if threshold is not None and interval > threshold:
                gaps.append(
                    {
                        "interval_ms": interval,
                        "threshold_ms": threshold,
                        "before": _frame_filter(before),
                        "after": _frame_filter(after),
                        "stream": {"bus": bus, "channel": channel, "capture_direction": direction},
                    }
                )
    return {
        "expected_cycle_ms": expected_cycle_ms,
        "stopped_gap_threshold_ms": threshold,
        "minimum_interval_ms": min(all_intervals) if all_intervals else None,
        "mean_interval_ms": sum(all_intervals) / len(all_intervals) if all_intervals else None,
        "maximum_interval_ms": max(all_intervals) if all_intervals else None,
        "stopped_gap_count": len(gaps),
        "stopped_gap_examples": gaps[:20],
        "status": (
            "No internal frame gap exceeded the configured stopped threshold."
            if threshold is not None and not gaps
            else "Internal frame gap(s) exceeded the configured stopped threshold."
            if gaps
            else "No valid expected cycle is available for stop detection."
        ),
    }


def build_message_guidance(
    can_id_text: str,
    fault_family: str,
    signal_name: str | None,
    frames: Iterable[CanFrame],
    database: DbcDatabase,
    canc: CancConfiguration | None,
    policy: OnFailPolicy | None,
    settings: AnalysisSettings,
) -> dict[str, Any]:
    """Build one local evidence plan for a selected message without performing any simulation."""

    can_id = _can_id(can_id_text)
    selected_frames = sorted(
        (frame for frame in frames if frame.can_id == can_id),
        key=lambda frame: (frame.timestamp, frame.source_order),
    )
    if not selected_frames:
        raise GuidanceError(f"No captured frames match {_format_id(can_id)}.")
    candidates = [message for message in database.messages if message.frame_id == can_id]
    candidate_names = {message.name.casefold() for message in candidates}
    routes = _route_candidates(canc, candidate_names)
    selected_message: DbcMessage | None = None
    selected_route: tuple[str, dict[str, Any]] | None = None
    for route in routes:
        route_messages = [
            message for message in candidates if message.name.casefold() == str(route[1]["frame"]).casefold()
        ]
        resolved = _unique_message(route_messages)
        if resolved is not None:
            selected_message, selected_route = resolved, route
            break
    if selected_message is None:
        selected_message = _unique_message(candidates)
    selected_signal: DbcSignal | None = None
    integrity_dtcs: dict[str, Any] = {}
    if selected_route:
        logic = selected_route[1].get("fault_logic", {})
        if isinstance(logic, dict) and isinstance(logic.get("message_content_failure_dtcs"), dict):
            integrity_dtcs = logic["message_content_failure_dtcs"]
    configured_integrity_signals = list(integrity_dtcs)
    preferred_signal = signal_name.strip() if signal_name and signal_name.strip() else next(
        (name for name in configured_integrity_signals if "MSG_CNT" in name.upper()),
        configured_integrity_signals[0] if configured_integrity_signals else "",
    )
    if selected_message and preferred_signal:
        selected_signal = next(
            (signal for signal in selected_message.signals if signal.name == preferred_signal),
            None,
        )
    grouped: dict[tuple[str, str, str], list[CanFrame]] = defaultdict(list)
    for frame in selected_frames:
        grouped[(frame.bus, frame.channel, frame.capture_direction.value)].append(frame)
    expected_cycle = None
    if selected_route and isinstance(selected_route[1].get("periodicity"), (int, float)):
        expected_cycle = float(selected_route[1]["periodicity"])
    elif selected_message and selected_message.cycle_time_ms:
        expected_cycle = selected_message.cycle_time_ms
    timing = _frame_timing_summary(grouped, expected_cycle, settings)
    qualification: dict[str, Any] = {
        "status": "Unavailable",
        "reason": "No imported CAN-C qualification/dequalification profile is available.",
    }
    if canc:
        timing_profile = canc.qualification_profile.get("timing", {})
        default_counts = timing_profile.get("default_counts", {}) if isinstance(timing_profile, dict) else {}
        counts = default_counts.get("message_content") if isinstance(default_counts, dict) else None
        if isinstance(counts, (list, tuple)) and len(counts) == 2 and all(isinstance(value, int) for value in counts):
            detection_count, recovery_count = counts
            qualification = {
                "status": "Configuration default; production calibration remains unconfirmed when mapping_state is REVIEW_REQUIRED.",
                "detection_count": detection_count,
                "recovery_count": recovery_count,
                "nominal_cycle_ms": expected_cycle,
                "derived_qualification_ms": detection_count * expected_cycle if expected_cycle else None,
                "derived_recovery_ms": recovery_count * expected_cycle if expected_cycle else None,
                "startup_delay_ms": timing_profile.get("startup_delay_ms"),
                "mapping_state": canc.qualification_profile.get("mapping_state"),
                "source_name": canc.source_name,
                "tuple_interpretation": "The source stores an unnamed pair; detection/recovery ordering is shown as a configuration-model interpretation.",
            }
        else:
            detection_count = recovery_count = None
    else:
        detection_count = recovery_count = None
    counter = _counter_summary(grouped, selected_signal, detection_count, recovery_count)
    crc_signal = (
        next((signal for signal in selected_message.signals if signal.name in integrity_dtcs and "CRC" in signal.name.upper()), None)
        if selected_message
        else None
    )
    crc_summary = {
        "signal": crc_signal.name if crc_signal else None,
        "status": (
            "CRC field is present, but its correctness is unavailable because no source CRC algorithm, protected-byte coverage, or Data ID is imported."
            if crc_signal
            else "No explicitly configured CRC field is available for this message."
        ),
        "distinct_observed_values": len(
            {
                _raw_signal(frame, crc_signal)
                for frame in selected_frames
                if crc_signal and _raw_signal(frame, crc_signal) is not None
            }
        ) if crc_signal else 0,
    }
    policy_context = (
        policy.contexts_for_message(selected_message.name, "message_content_failure")
        if policy and selected_message
        else ()
    )
    return {
        "focus": {
            "can_id_hex": _format_id(can_id),
            "fault_family": fault_family,
            "selected_message": selected_message.name if selected_message else None,
            "dbc_candidates": [message.name for message in candidates],
            "mapping_status": (
                "Resolved through matching CAN-C route and one DBC definition."
                if selected_message
                else "DBC message mapping remains unknown or ambiguous; no signal decoding was assumed."
            ),
            "filter_hint": [
                {
                    "bus": bus,
                    "channel": channel,
                    "capture_direction": direction,
                    "can_id_hex": _format_id(can_id),
                    "frame_count": len(stream_frames),
                    "first_timestamp": stream_frames[0].timestamp,
                    "last_timestamp": stream_frames[-1].timestamp,
                }
                for (bus, channel, direction), stream_frames in grouped.items()
            ],
        },
        "configured_message_content": {
            "route_name": selected_route[0] if selected_route else None,
            "integrity_signals": [
                {"signal": name, "dtc": value}
                for name, value in integrity_dtcs.items()
            ],
            "selected_integrity_signal": preferred_signal or None,
            "policy_context": list(policy_context),
        },
        "qualification": qualification,
        "frame_stop_check": timing,
        "alive_counter_check": counter,
        "crc_check": crc_summary,
        "what_to_check": [
            "Use the listed bus, channel, direction, and CAN-ID filter so independent capture streams are not combined.",
            "For alive-counter qualification, confirm the released U171 detection/recovery calibration and verify consecutive counter mismatches against the explicit 0..15 to 0 rollover.",
            "For CRC qualification, obtain the source CRC algorithm, protected-byte coverage, Data ID, initialization, and final-XOR details; a changing CRC byte does not prove validity.",
            "For a wrong-DLC message-content case, compare observed declared length with the DBC DLC and preserve the raw source frames.",
            "To assert an ECU DTC state, capture the ECU-originated ISO-TP UDS 0x59 response after the configured interval and qualification; compare the configured DTC mapping and status with that response.",
            "To assert healing, capture the required consecutive valid receptions after a known qualified fault, then a subsequent UDS DTC response. Do not infer healing from a normal-looking frame alone.",
        ],
        "copilot_question": (
            "Using only the aggregate local analysis summary, what additional local evidence is required "
            "to confirm an EMS21_10 message-content alive-counter qualification and recovery?"
        ),
    }
