"""JSON DBC import, validation, indexed lookup, and ECU attribution."""

from __future__ import annotations

import json
import math
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

from .models import (
    Attribution,
    AttributionResult,
    CanFrame,
    DbcImportResult,
    DbcMatch,
    DbcMessage,
    DbcSignal,
    IdentifierType,
)


def _number(value: object, label: str, warnings: list[str]) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        warnings.append(f"Invalid {label} '{value}'.")
        return None
    if not math.isfinite(number):
        warnings.append(f"Invalid {label} '{value}'; a finite number is required.")
        return None
    return number


def _integer(value: object, label: str, warnings: list[str]) -> int | None:
    if isinstance(value, bool):
        warnings.append(f"Invalid {label} '{value}'.")
        return None
    try:
        if isinstance(value, str):
            normalized = value.strip()
            number = int(normalized, 16) if normalized.lower().startswith("0x") else int(normalized, 10)
        else:
            number = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        warnings.append(f"Invalid {label} '{value}'.")
        return None
    return number


def _identifier_type(record: dict[str, Any]) -> IdentifierType:
    for key in ("is_extended_frame", "is_extended_id", "extended"):
        if key in record:
            return IdentifierType.EXTENDED if bool(record[key]) else IdentifierType.STANDARD
    return IdentifierType.STANDARD


def _string_list(value: object, label: str, warnings: list[str]) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        warnings.append(f"Malformed {label} list; expected an array of non-empty strings.")
        return ()
    return tuple(item.strip() for item in value)


def _normalize_byte_order(value: object) -> str | None:
    normalized = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    if normalized in {"little_endian", "intel", "1", "little"}:
        return "little_endian"
    if normalized in {"big_endian", "motorola", "0", "big"}:
        return "big_endian"
    return None


def motorola_bit_positions(start_bit: int, length: int) -> tuple[int, ...]:
    """Return DBC Motorola bit positions from the MSB start-bit convention."""

    positions: list[int] = []
    position = start_bit
    for _ in range(length):
        positions.append(position)
        position = position + 15 if position % 8 == 0 else position - 1
    return tuple(positions)


def _multiplex_metadata(record: dict[str, Any]) -> tuple[str | None, tuple[int, ...], bool, list[str]]:
    warnings: list[str] = []
    metadata = record.get("multiplexing")
    if not isinstance(metadata, dict):
        metadata = {}
    is_multiplexer = bool(
        record.get("is_multiplexer", metadata.get("is_multiplexer", False))
    ) or str(record.get("multiplexer_indicator", "")).lower() in {
        "multiplexor",
        "multiplexer",
        "m",
    }
    mux_signal = record.get(
        "multiplexer_signal",
        metadata.get("multiplexer_signal", metadata.get("signal")),
    )
    if mux_signal is not None and not isinstance(mux_signal, str):
        warnings.append("Incomplete multiplexing metadata: multiplexer signal must be a string.")
        mux_signal = None
    values_raw = record.get(
        "multiplexer_ids",
        record.get("multiplexer_values", metadata.get("values", metadata.get("ids"))),
    )
    values: list[int] = []
    if values_raw is not None:
        if not isinstance(values_raw, list):
            warnings.append("Incomplete multiplexing metadata: selector values must be an array.")
        else:
            for value in values_raw:
                parsed = _integer(value, "multiplex selector value", warnings)
                if parsed is not None:
                    values.append(parsed)
    if values and not mux_signal:
        warnings.append("Incomplete multiplexing metadata: selector values have no multiplexer signal.")
    if mux_signal and not values and not is_multiplexer:
        warnings.append("Incomplete multiplexing metadata: a multiplexed signal has no selector value.")
    return mux_signal, tuple(values), is_multiplexer, warnings


def _normalize_signal(record: object, message_length: int | None) -> DbcSignal:
    warnings: list[str] = []
    if not isinstance(record, dict):
        return DbcSignal(
            name="<invalid signal>",
            start_bit=0,
            length=0,
            byte_order="little_endian",
            is_signed=False,
            factor=1.0,
            offset=0.0,
            minimum=None,
            maximum=None,
            unit="",
            value_descriptions={},
            valid=False,
            validation_warnings=("Signal record must be an object.",),
        )
    name = record.get("name")
    if not isinstance(name, str) or not name.strip():
        warnings.append("Signal has an invalid name.")
        name = "<invalid signal>"
    start_bit = _integer(record.get("start_bit"), "signal start bit", warnings)
    length = _integer(record.get("length"), "signal length", warnings)
    if start_bit is None or start_bit < 0:
        warnings.append("Signal start bit must be zero or greater.")
        start_bit = 0
    if length is None or length <= 0:
        warnings.append("Signal length must be positive.")
        length = 0
    byte_order = _normalize_byte_order(record.get("byte_order"))
    if byte_order is None:
        warnings.append(f"Unsupported byte order '{record.get('byte_order')}'.")
        byte_order = "little_endian"
    factor = _number(record.get("factor", 1), "signal factor", warnings)
    offset = _number(record.get("offset", 0), "signal offset", warnings)
    factor = 1.0 if factor is None else factor
    offset = 0.0 if offset is None else offset
    minimum = None if record.get("min") is None else _number(record.get("min"), "signal minimum", warnings)
    maximum = None if record.get("max") is None else _number(record.get("max"), "signal maximum", warnings)
    if minimum is not None and maximum is not None and minimum > maximum:
        warnings.append("Signal minimum is greater than maximum.")
    values: dict[int, str] = {}
    raw_descriptions = record.get("value_descriptions", {})
    if raw_descriptions is not None:
        if not isinstance(raw_descriptions, dict):
            warnings.append("Signal value descriptions must be an object.")
        else:
            for raw_value, label in raw_descriptions.items():
                parsed_value = _integer(raw_value, "enumeration value", warnings)
                if parsed_value is not None and isinstance(label, str):
                    values[parsed_value] = label
                elif parsed_value is not None:
                    warnings.append(f"Enumeration label for value {raw_value!r} must be a string.")
    mux_signal, mux_values, is_multiplexer, mux_warnings = _multiplex_metadata(record)
    warnings.extend(mux_warnings)
    if message_length is not None and length:
        positions = (
            tuple(range(start_bit, start_bit + length))
            if byte_order == "little_endian"
            else motorola_bit_positions(start_bit, length)
        )
        if any(position < 0 or position >= message_length * 8 for position in positions):
            warnings.append(
                f"Signal bit range extends beyond the {message_length}-byte message length."
            )
    return DbcSignal(
        name=name.strip(),
        start_bit=start_bit,
        length=length,
        byte_order=byte_order,  # type: ignore[arg-type]
        is_signed=bool(record.get("is_signed", False)),
        factor=factor,
        offset=offset,
        minimum=minimum,
        maximum=maximum,
        unit=str(record.get("unit") or ""),
        value_descriptions=values,
        multiplexer_signal=mux_signal.strip() if isinstance(mux_signal, str) else None,
        multiplexer_values=mux_values,
        is_multiplexer=is_multiplexer,
        valid=not warnings,
        validation_warnings=tuple(warnings),
    )


def _message_record(record: object, source_name: str) -> DbcMessage:
    warnings: list[str] = []
    if not isinstance(record, dict):
        return DbcMessage(
            source_name,
            "<invalid message>",
            None,
            IdentifierType.STANDARD,
            None,
            (),
            (),
            None,
            (),
            False,
            ("DBC message record must be an object.",),
        )
    name = record.get("name")
    if not isinstance(name, str) or not name.strip():
        warnings.append("Message has an invalid name.")
        name = "<invalid message>"
    frame_id = _integer(record.get("frame_id", record.get("id")), "frame ID", warnings)
    if frame_id is None or frame_id < 0 or frame_id > 0x1FFFFFFF:
        warnings.append("Frame ID must be within the 29-bit CAN identifier range.")
        frame_id = None
    identifier_type = _identifier_type(record)
    if frame_id is not None and identifier_type is IdentifierType.STANDARD and frame_id > 0x7FF:
        warnings.append("A standard DBC frame ID cannot exceed 0x7FF.")
    length = _integer(record.get("length", record.get("dlc")), "message length", warnings)
    if length is None or not 0 <= length <= 64:
        warnings.append("Message length must be within the 0-64 CAN/CAN-FD range.")
        length = None
    cycle_time = record.get("cycle_time")
    cycle_time_ms = None if cycle_time is None else _number(cycle_time, "cycle time", warnings)
    if cycle_time_ms is not None and cycle_time_ms <= 0:
        warnings.append("Cycle time must be positive when specified.")
        cycle_time_ms = None
    senders = _string_list(record.get("senders", []), "senders", warnings)
    receivers = _string_list(record.get("receivers", []), "receivers", warnings)
    raw_signals = record.get("signals", [])
    if not isinstance(raw_signals, list):
        warnings.append("Message signals must be an array.")
        raw_signals = []
    signals = tuple(_normalize_signal(signal, length) for signal in raw_signals)
    seen_names: set[str] = set()
    for signal in signals:
        if signal.name in seen_names:
            warnings.append(f"Duplicate signal name '{signal.name}' within this message.")
        seen_names.add(signal.name)
        warnings.extend(f"{signal.name}: {warning}" for warning in signal.validation_warnings)
    return DbcMessage(
        source_name=source_name,
        name=name.strip(),
        frame_id=frame_id,
        identifier_type=identifier_type,
        length=length,
        senders=senders,
        receivers=receivers,
        cycle_time_ms=cycle_time_ms,
        signals=signals,
        valid=not warnings,
        validation_warnings=tuple(warnings),
    )


def import_dbc_json(source: Path, source_name: str | None = None) -> DbcImportResult:
    """Read one JSON-exported DBC and retain invalid definitions for review."""

    display_name = source_name or source.name
    try:
        content = json.loads(source.read_text(encoding="utf-8-sig"))
    except UnicodeDecodeError as error:
        raise ValueError(f"DBC JSON '{display_name}' is not UTF-8: {error}") from error
    except json.JSONDecodeError as error:
        raise ValueError(f"DBC JSON '{display_name}' is invalid: {error}") from error
    records = content.get("messages") if isinstance(content, dict) else content
    if not isinstance(records, list):
        raise ValueError("DBC JSON must be a message array or an object with a 'messages' array.")
    result = DbcImportResult(display_name)
    result.messages = [_message_record(record, display_name) for record in records]
    for message in result.messages:
        result.warnings.extend(f"{message.name}: {warning}" for warning in message.validation_warnings)
    return result


class DbcDatabase:
    """Combined DBC definitions with explicit collision-preserving indexes."""

    def __init__(self, imports: Iterable[DbcImportResult] = ()) -> None:
        self.imports = list(imports)
        self.messages = [message for imported in self.imports for message in imported.messages]
        self.by_identity: dict[tuple[int, IdentifierType], tuple[DbcMessage, ...]] = {}
        buckets: dict[tuple[int, IdentifierType], list[DbcMessage]] = defaultdict(list)
        for message in self.messages:
            if message.frame_id is not None:
                buckets[(message.frame_id, message.identifier_type)].append(message)
        self.by_identity = {key: tuple(value) for key, value in buckets.items()}
        self.collisions = {
            key: definitions for key, definitions in self.by_identity.items() if len(definitions) > 1
        }

    def match(self, frame: CanFrame, identifier_override: IdentifierType | None = None) -> DbcMatch:
        """Match numeric ID and type without guessing standard/extended ambiguity."""

        identifier_type = identifier_override or frame.identifier_type
        if identifier_type is not IdentifierType.UNKNOWN:
            return DbcMatch(self.by_identity.get((frame.can_id, identifier_type), ()))
        candidates = (
            self.by_identity.get((frame.can_id, IdentifierType.STANDARD), ())
            + self.by_identity.get((frame.can_id, IdentifierType.EXTENDED), ())
        )
        return DbcMatch(candidates, ambiguous_identifier_type=len(candidates) > 1)

    def associated_messages(self, target_ecu: str) -> tuple[DbcMessage, ...]:
        target = target_ecu.strip().casefold()
        return tuple(
            message
            for message in self.messages
            if target
            and (
                target in {node.casefold() for node in message.senders}
                or target in {node.casefold() for node in message.receivers}
            )
        )

    def inventory(self, observed: Iterable[CanFrame], target_ecu: str) -> list[dict[str, Any]]:
        observed_keys = {(frame.can_id, frame.identifier_type) for frame in observed}
        target = target_ecu.strip().casefold()
        rows: list[dict[str, Any]] = []
        for message in self.messages:
            observed_state = False
            if message.frame_id is not None:
                observed_state = (
                    (message.frame_id, message.identifier_type) in observed_keys
                    or (message.frame_id, IdentifierType.UNKNOWN) in observed_keys
                )
            sender_match = target in {sender.casefold() for sender in message.senders}
            receiver_match = target in {receiver.casefold() for receiver in message.receivers}
            association = (
                "ECU-associated bidirectional or ambiguous role"
                if sender_match and receiver_match
                else "ECU-associated transmit candidate"
                if sender_match
                else "ECU-associated receive candidate"
                if receiver_match
                else "No association was found for this message in the imported DBC data for the selected ECU."
            )
            rows.append(
                {
                    "source_name": message.source_name,
                    "message_name": message.name,
                    "can_id": message.frame_id,
                    "can_id_hex": message.can_id_hex,
                    "identifier_type": message.identifier_type.value,
                    "expected_dlc": message.length,
                    "cycle_time_ms": message.cycle_time_ms,
                    "senders": list(message.senders),
                    "receivers": list(message.receivers),
                    "signal_count": len(message.signals),
                    "observed_status": "Observed" if observed_state else "Not observed during this capture",
                    "selected_ecu_association": association,
                    "validation_warnings": list(message.validation_warnings),
                    "ambiguous_mapping": (
                        message.frame_id is not None
                        and len(self.by_identity.get((message.frame_id, message.identifier_type), ())) > 1
                    ),
                }
            )
        return rows


def attribute_frame(
    frame: CanFrame,
    database: DbcDatabase,
    target_ecu: str,
    identifier_override: IdentifierType | None = None,
) -> AttributionResult:
    """Classify a frame exclusively from DBC sender/receiver evidence."""

    match = database.match(frame, identifier_override)
    if not match.candidates:
        return AttributionResult(
            Attribution.UNKNOWN_ID,
            (),
            "No matching DBC definition was found.",
            "high",
        )
    if len(match.candidates) > 1:
        reason = (
            "The capture does not state identifier type and both standard and extended DBC definitions apply."
            if match.ambiguous_identifier_type
            else "Multiple DBC message definitions apply; no definition was selected."
        )
        return AttributionResult(Attribution.AMBIGUOUS_DBC, match.candidates, reason, "low")
    message = match.candidates[0]
    target = target_ecu.strip().casefold()
    senders = {sender.casefold() for sender in message.senders}
    receivers = {receiver.casefold() for receiver in message.receivers}
    sender_match = bool(target) and target in senders
    receiver_match = bool(target) and target in receivers
    if sender_match and receiver_match:
        return AttributionResult(
            Attribution.ECU_AMBIGUOUS_ROLE,
            (message,),
            "The selected ECU appears in both DBC senders and receivers; capture direction does not establish ECU transmission direction.",
            "medium",
        )
    if sender_match:
        return AttributionResult(
            Attribution.ECU_TX_CANDIDATE,
            (message,),
            "The selected ECU appears in the imported DBC sender list. Capture direction does not establish ECU transmission direction.",
            "medium",
        )
    if receiver_match:
        return AttributionResult(
            Attribution.ECU_RX_CANDIDATE,
            (message,),
            "The selected ECU appears in the imported DBC receiver list. Capture direction does not establish ECU transmission direction.",
            "medium",
        )
    return AttributionResult(
        Attribution.DBC_KNOWN_NON_ASSOCIATED,
        (message,),
        "No association was found for this message in the imported DBC data for the selected ECU.",
        "high",
    )


def dbc_message_to_dict(message: DbcMessage) -> dict[str, Any]:
    """Serialize a normalized DBC record for the local API without losing metadata."""

    data = asdict(message)
    data["identifier_type"] = message.identifier_type.value
    data["can_id_hex"] = message.can_id_hex
    return data
