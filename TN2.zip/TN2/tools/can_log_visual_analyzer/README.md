# Offline CAN Log Visual Analyzer

A localhost-only engineering workspace for analysing recorded ARIA/CAN text
logs and JSON-exported DBC metadata. It is an **analysis-only** tool: it has
no live CAN interface, does not connect to hardware, and cannot configure,
flash, diagnose, clear DTCs on, or otherwise control an ECU or vehicle.

## Run

From the repository root, use the project Python interpreter:

```powershell
py -3.13 -m tools.can_log_visual_analyzer.server
```

Open `http://127.0.0.1:8765`. The server is deliberately bound only to the
loopback interface. Upload a recorded log and then one or more DBC JSON
exports. All temporary uploaded copies are isolated under the operating
system's temporary directory; source captures are never modified.

Use a different loopback port if required:

```powershell
py -3.13 -m tools.can_log_visual_analyzer.server --port 8877
```

## Supported ARIA text format

One record is expected per line:

```text
<timestamp> <bus> <channel> <TX|RX> l=<length>, id=<hex-id>, <payload bytes>
45.662322 Can 2 RX l=8, id=000002C0, 81 00 00 00 01 00 80 5F
```

Whitespace and hexadecimal case are flexible. IDs accept leading zeroes and an
optional `0x` prefix. Zero-length records and payloads up to 64 bytes are
accepted. The displayed `declared_length` and `parsed_byte_count` are always
separate. Malformed lines are retained in the import summary with the original
line and source location rather than aborting an import.

ARIA records do not explicitly declare standard versus extended identifier
type. Values above `0x7FF` are necessarily extended; otherwise the type is
recorded as `unknown`. If both standard and extended DBC records can match,
the result remains ambiguous unless the user applies a source-level override.

## DBC JSON schema

Import either a message array or an object containing `messages`. Each message
may contain:

```json
{
  "name": "Vehicle_Status",
  "frame_id": "0x2C0",
  "is_extended_frame": false,
  "length": 8,
  "senders": ["SRS"],
  "receivers": ["BCM"],
  "cycle_time": 10,
  "signals": [{
    "name": "Counter",
    "start_bit": 52,
    "length": 4,
    "byte_order": "little_endian",
    "is_signed": false,
    "factor": 1,
    "offset": 0,
    "min": 0,
    "max": 15,
    "unit": "",
    "value_descriptions": {"10": "Valid"}
  }]
}
```

The import report visibly retains invalid frame IDs, invalid bit ranges,
unsupported byte orders, malformed ECU lists, incomplete multiplex metadata,
and collisions. Conflicting definitions are never selected silently.

## Attribution and analysis rules

CAN matching uses numeric ID plus standard/extended type; channel and
capture-direction remain part of the timing stream but not of DBC identity.
With a selected target ECU, a frame is classified exactly as one of:

1. ECU-associated transmit candidate — target appears in DBC `senders`.
2. ECU-associated receive candidate — target appears in DBC `receivers`.
3. ECU-associated bidirectional or ambiguous role — target is both, or the
   imported metadata cannot establish a unique role.
4. DBC-known, not associated with selected ECU.
5. Unknown CAN ID.
6. Ambiguous DBC match.

`TX` and `RX` describe the capture interface only. They do not prove which ECU
transmitted a message. DBC-associated messages not present in the recording
are labelled **Not observed during this capture**, never “stopped.”

Timing is calculated separately by `bus + channel + CAN ID + identifier type +
capture direction`. Periodic-message gap detection only applies when a valid,
positive DBC cycle time exists:

- stopped/missing review threshold: `max(3 × expected cycle, minimum gap)`;
- warning timing tolerance: `max(10% × expected cycle, absolute tolerance)`;
- burst threshold: less than `50%` of the expected cycle.

Findings contain source frames, timestamps, raw payload, applied rule, and a
safe next analytical step. They are potential observations requiring engineer
review, not ECU or vehicle diagnoses. Range checks are labelled **Potential
DBC-range deviation** and unknown enum values **Unmapped enumeration value**.

Little-endian/Intel and DBC Motorola bit numbering, signed values, scale,
offset, units, enumerations, and sufficient multiplex metadata are supported.
Missing data is never zero-padded. The tool does not infer CRCs, alive
counters, checksums, E2E protection, reserved values, invalid-value rules, or
message function from a CAN ID or payload.

## Performance and export

Imports and analysis use background workers, keeping the UI request thread
responsive. The API paginates raw frames and uses exact timeline markers for
focused views (up to 10,000 frames) or explicit density bins that account for
every source frame in larger views. Long tables are server-paginated; exports
preserve complete source data.

The dashboard exports frames, decoded signals, timing metrics, findings, DBC
validation, and the analysis summary in CSV or JSON. JSON exports include
selected analysis settings, imported DBC sources, target ECU, and capture time
range.

## On-fail, qualification, recovery, and DTC evidence

The **On-fail & DTC evidence** workspace is passive. It models what the
recording supports and never creates, clears, heals, qualifies, or
dequalifies a fault in a vehicle.

| Fault family | What the workspace can show | Boundary |
| --- | --- | --- |
| Message timeout | A configured no-frame qualification timestamp and a recovery/dequalification candidate for an internal gap in a valid DBC-periodic stream. | This is a configurable monitor model, not evidence that an ECU monitor or DTC actually changed state. |
| Node absent | An overlap where all observed periodic streams declaring the same DBC sender were in configured timeout windows. | DBC sender metadata does not identify the configured key message; a result is a node-wide communication-absence candidate, not a confirmed node-absent fault. |
| Signal never received | An imported on-fail policy can provide expected reaction context. | Capture-start absence does not prove the signal was never received. It needs initialization and monitor evidence. |
| Signal invalid / reserved / out of range | Potential DBC-range and unmapped-enum evidence. | A confirmed invalid/reserved fault requires source-owned monitor rules; the tool never infers them from signal names. |
| Message content failure | Policy context only. | CRC, checksum, alive counter, E2E, and content rules are never inferred. |
| Variant code error / UV/OV / network security | Policy context only. | These need the relevant configuration or monitor evidence. |
| Bus-off | No frame-gap conclusion. | Bus-off is controller-level and needs recorded controller/error-frame or diagnostic evidence. |
| DTC status | Every reconstructed recorded ISO-TP positive `0x59` UDS ReadDTCInformation response, with raw status byte and standard set-bit names. | The tool never sends a diagnostic request. No recorded `0x59` response means DTC availability is unknown. |

For each internal message gap, the tool reports:

- **Configured qualification timestamp**: last recorded frame plus either the
  explicit *Timeout qualification override* or
  `max(3 × expected DBC cycle, minimum gap)`.
- **First recovery frame**: the first frame after that internal gap.
- **Configured dequalification timestamp**: first recovery frame plus
  *Timeout recovery evidence*. A non-zero recovery delay is shown only when
  the capture contains continuous recorded traffic through the configured
  duration. No boundary absence is treated as a transition.

The optional on-fail-policy importer accepts the normalised project policy
shape produced by `tools/build_edr_onfail_policy.py`, for example
`tests/artifacts/edr-onfail-policy/edr_onfail_policy.json`. It adds expected
reaction/source-row context beside a matching DBC message; it never converts
policy expectation into observed fault or DTC state.

Project evidence distinguishes node-absent (configured key-message loss) from
message-timeout (the signal-carrying frame): where the carrier is itself the
key message, a separate timeout case may not exist. The analyzer preserves
that distinction and marks the unavailable configuration detail rather than
guessing.

## Static CAN-C / EDR configuration audit

The **Configuration audit** panel accepts the project `canc_config.py` and
`edr_config.py` as optional source evidence. These files are parsed with a
restricted AST reader that accepts only literals, references to earlier
literals, and dictionary `.get()` calls. The tool **never imports or executes**
the selected source file.

For CAN-C configuration, the audit checks:

- configured frame/signal routes exist in the selected DBC;
- source factor and offset agree with the DBC, and normal-simulation raw
  vectors both fit the signal width and decode inside the DBC physical range;
- invalid-value, reserved-value, and out-of-range vectors are kept distinct;
- node-absent routes use a configured `KEY_TX_FRAMES` member, resolve in DBC,
  share the appropriate sender evidence, and win the available arbitration
  comparison;
- message-timeout targets are configured non-key messages. If a target differs
  from the signal-carrying frame, the tool flags the possible
  **consumed-value** exception instead of claiming a last-valid result;
- a configured message-content DTC references a present integrity signal. The
  source must explicitly supply CRC/alive semantics; no algorithm is inferred.

For EDR configuration, the audit checks interval versus snapshot metadata,
T0-range availability, and finite conversion metadata. A parameter with
`recording_model: "snapshot"` and no `sample_range` (such as odometer/event
date/event time) is explicitly kept out of pre/post interval logic.

A static configuration cannot prove runtime behavior. The audit marks the
following as **review required** until a generated case plan or timestamped
execution trace supplies the evidence: continuous no-sleep scheduling, T0
trigger order, fault injection/heal timing, ignition-cycle state, and Read DTC
ordering after recording interval plus qualification time. Normal simulations
also require a complete recorded `0x59` DTC response before “no CAN fault DTC”
can be concluded.

The workspace preserves the documented special `STS_ENG` condition as
source-policy context: raw `0x1`/`0x5`, 10,000 ms qualification, roughly
500 ms dequalification, and full-only scope. It does not infer that special
case from a general engine-state signal or create a pre/post test case.

## Optional Copilot-assisted analysis

The **Copilot-assisted analysis** panel can send one user-requested question
to an installed and authenticated GitHub Copilot CLI. It is **off by default**.
The browser first shows the exact prompt and data-sharing disclosure; the
request cannot run until the user checks the confirmation box.

Only these items are sent:

- the typed user question;
- aggregate frame/timing/fault/DTC counts;
- aggregate configuration-audit counts; and
- counts by finding category.

The bridge deliberately excludes raw capture lines, payload bytes, CAN IDs,
timestamps, DBC data, CAN-C/EDR configuration contents, local paths, and
credentials. Copilot runs with built-in MCP disabled in an empty temporary
working directory and receives no file attachment. Its inference uses
authenticated GitHub/Copilot network access; the parser, decoder, timing, and
configuration audit remain local and can be used without it.

The bridge invokes the documented `copilot --prompt` non-interactive CLI mode
only after confirmation. Do not enter sensitive, personal, customer, or
export-controlled material in the question. The request result is displayed
in the workspace; each request is independent so prior questions are not
silently shared.

## Guided message-content investigation

The **Guided message check** panel turns a selected CAN ID and fault family
into a local investigation plan. Its default focus is U171 `EMS21_10`
(`0x127`) with `EMS21_MSG_CNT`.

For an explicitly configured alive-counter fault, it:

1. Filters the recorded stream by **bus + channel + capture direction + CAN
   ID** so unrelated traffic is not combined.
2. Displays the CANC-configured integrity-signal/DTC map and only decodes the
   selected counter when the matching DBC definition is unique.
3. Checks consecutive transitions using the DBC bit length and modulo rollover,
   then identifies a qualification candidate only when the imported
   configuration count is reached. A recovery candidate likewise needs the
   configured number of successive good receptions.
4. Separately reports frame-stop gaps using the periodic timing threshold.
   A frame stop is not treated as a CRC/alive-counter failure.
5. Lists the missing evidence needed for a conclusion: released
   detection/recovery calibration, CRC profile, internal monitor state, and a
   recorded ECU `0x59` DTC response.

For the currently available U171 source, the guide shows the configuration
default `message_content: (60, 10)` and a 10 ms nominal cycle as a
**configuration-model interpretation** of 600 ms qualification and 100 ms
recovery. The source marks this DTC mapping `REVIEW_REQUIRED`; do not report
those derived times as released ECU calibration until the CANC calibration or
ECU diagnostic evidence confirms them.

## Validate

```powershell
py -3.13 -m pytest tests\test_can_log_visual_analyzer.py
py -3.13 -m compileall -q tools\can_log_visual_analyzer
```

The static browser API contract is TypeScript with strict compiler settings.
When a TypeScript compiler is installed, validate it without generating output:

```powershell
tsc --project tools\can_log_visual_analyzer\tsconfig.json
```
