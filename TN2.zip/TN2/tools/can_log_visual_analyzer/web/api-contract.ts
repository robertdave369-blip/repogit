/** Typed API contract for the bundled browser workspace.
 *
 * The distributable uses app.js so it can run with only Python. This source
 * contract is checked by `tsc --noEmit` when TypeScript is available.
 */
export type IdentifierType = "standard" | "extended" | "unknown";
export type CaptureDirection = "TX" | "RX" | "UNKNOWN";
export type FindingSeverity = "info" | "warning" | "review";

export interface Frame {
  source_name: string;
  source_line: number;
  timestamp: number;
  bus: string;
  channel: string;
  capture_direction: CaptureDirection;
  can_id: number;
  can_id_hex: string;
  identifier_type: IdentifierType;
  declared_length: number;
  parsed_byte_count: number;
  payload_hex: string;
}

export interface TimingMetrics {
  frame_count: number;
  expected_cycle_ms: number | null;
  mean_interval_ms: number | null;
  median_interval_ms: number | null;
  min_interval_ms: number | null;
  max_interval_ms: number | null;
  jitter_ms: number | null;
  long_gap_count: number;
  burst_count: number;
}

export interface Stream {
  stream_id: string;
  channel: string;
  capture_direction: CaptureDirection;
  can_id_hex: string;
  identifier_type: IdentifierType;
  message_name: string | null;
  attribution: string;
  attribution_rationale: string;
  metrics: TimingMetrics;
}

export interface Finding {
  finding_id: string;
  category: string;
  severity: FindingSeverity;
  confidence: "high" | "medium" | "low";
  summary: string;
  stream_id: string | null;
  evidence: Record<string, unknown>;
}

export interface AnalysisSettings {
  minimum_gap_ms: number;
  absolute_tolerance_ms: number;
  stopped_multiplier: number;
  jitter_fraction: number;
  burst_fraction: number;
  percentile: number;
  timeout_qualification_ms: number;
  timeout_recovery_ms: number;
}

export interface WorkspaceStatus {
  overview: Record<string, number>;
  settings: AnalysisSettings;
  target_ecu: string;
  limitations: string[];
}

export interface FaultEvent {
  event_id: string;
  category: string;
  monitor_scope: "message" | "sender-node";
  message_name: string | null;
  sender_node: string | null;
  qualification_timestamp: number;
  recovery_observed_timestamp: number | null;
  dequalification_timestamp: number | null;
  confidence: "high" | "medium" | "low";
  rule: string;
  evidence: Record<string, unknown>;
}

export interface DtcStatusRecord {
  dtc: string;
  status_byte: number;
  status_hex: string;
  status_flags: string[];
  subfunction: number;
  timestamp: number;
  source_frames: Frame[];
}

export interface ConfigurationCheck {
  category: string;
  severity: FindingSeverity;
  summary: string;
  evidence: Record<string, unknown>;
  rule: string;
  next_step: string;
}

export interface ConfigurationAudit {
  summary: {
    check_count: number;
    info_count: number;
    warning_count: number;
    review_count: number;
  };
  checks: ConfigurationCheck[];
}

export interface ConfigurationSources {
  canc: { source_name: string; route_count: number } | null;
  edr: { source_name: string; parameter_count: number } | null;
  canc_case: { source_name: string; case_count: number } | null;
}

export interface CopilotPromptPreview {
  prompt: string;
  disclosure: string[];
}

export interface CopilotAnalysisResult {
  response: string;
}

export interface MessageGuidance {
  focus: {
    can_id_hex: string;
    fault_family: string;
    selected_message: string | null;
    mapping_status: string;
  };
  qualification: Record<string, unknown>;
  frame_stop_check: Record<string, unknown>;
  alive_counter_check: Record<string, unknown>;
  crc_check: Record<string, unknown>;
  what_to_check: string[];
  copilot_question: string;
}
