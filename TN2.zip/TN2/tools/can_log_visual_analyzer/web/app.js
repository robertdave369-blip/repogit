/* Offline CAN Evidence Workspace - API client and accessible visual drill-down. */
const state = { status: null, streams: [], findings: [], faultEvents: [], dtcs: [], faultOptions: [], configurationAudit: null, guidance: null, filters: {} };
const $ = (id) => document.getElementById(id);
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
})[character]);
const number = (value, digits = 2) => value === null || value === undefined ? "—" : Number(value).toFixed(digits);
const api = async (path, options) => {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
};
const query = () => new URLSearchParams(Object.entries(state.filters).filter(([, value]) => value !== "" && value !== undefined && value !== null));

function setJobStatus(message, isError = false) {
  const output = $("job-status");
  output.textContent = message;
  output.style.color = isError ? "var(--red)" : "var(--cyan)";
}

async function upload(kind, file) {
  if (!file) return;
  setJobStatus(`Uploading ${file.name}…`);
  try {
    const job = await api(`/api/import/${kind}`, {
      method: "POST",
      headers: { "X-File-Name": encodeURIComponent(file.name), "Content-Type": "application/octet-stream" },
      body: file
    });
    await monitorJob(job.job_id);
    await refresh();
  } catch (error) {
    setJobStatus(error.message, true);
  }
}

async function monitorJob(jobId) {
  while (true) {
    const job = await api(`/api/jobs/${jobId}`);
    setJobStatus(`${job.source_name}: ${job.message} (${job.progress}%)`, Boolean(job.error));
    if (job.state === "failed") throw new Error(job.error || job.message);
    if (job.state === "completed") return job;
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
}

function configureDropZone(zoneId, inputId, kind) {
  const zone = $(zoneId);
  const input = $(inputId);
  ["dragenter", "dragover"].forEach((event) => zone.addEventListener(event, (item) => {
    item.preventDefault(); zone.classList.add("drag-over");
  }));
  ["dragleave", "drop"].forEach((event) => zone.addEventListener(event, (item) => {
    item.preventDefault(); zone.classList.remove("drag-over");
  }));
  zone.addEventListener("drop", (event) => [...event.dataTransfer.files].forEach((file) => upload(kind, file)));
  input.addEventListener("change", () => [...input.files].forEach((file) => upload(kind, file)));
}

function renderStatus() {
  const { status } = state;
  if (!status) return;
  const summary = [
    ...status.sources.map((source) => `${escapeHtml(source.source_name)}: ${source.parsed_frame_count.toLocaleString()} frames, ${source.rejected_line_count} rejected lines, ${source.warning_count} warnings`),
    ...status.dbc_sources.map((source) => `${escapeHtml(source.source_name)}: ${source.message_count} DBC messages, ${source.warning_count} validation warnings`),
    ...(status.onfail_policy ? [`${escapeHtml(status.onfail_policy.source_name)}: ${status.onfail_policy.record_count} source-owned on-fail records`] : []),
    ...(status.configuration_sources?.canc ? [`${escapeHtml(status.configuration_sources.canc.source_name)}: ${status.configuration_sources.canc.route_count} CAN-C routes`] : []),
    ...(status.configuration_sources?.edr ? [`${escapeHtml(status.configuration_sources.edr.source_name)}: ${status.configuration_sources.edr.parameter_count} EDR parameters`] : []),
    ...(status.configuration_sources?.canc_case ? [`${escapeHtml(status.configuration_sources.canc_case.source_name)}: ${status.configuration_sources.canc_case.case_count} generated CAN-C cases`] : [])
  ];
  $("import-summary").innerHTML = summary.length ? summary.join(" &nbsp; | &nbsp; ") : "No recorded sources imported.";
  $("limitations").innerHTML = status.limitations.map((item) => `<li>${escapeHtml(item)}</li>`).join("");
  $("target-ecu").value = status.target_ecu || "";
  for (const [key, value] of Object.entries(status.settings)) {
    const element = $(key.replaceAll("_", "-"));
    if (element) element.value = value;
  }
}

const cards = [
  ["total_parsed_frames", "Parsed frames"], ["rejected_malformed_lines", "Rejected / malformed lines"],
  ["capture_duration_ms", "Capture duration (ms)"], ["active_channels", "Active channels"],
  ["unique_observed_ids", "Observed IDs"], ["dbc_matched_ids", "DBC-matched streams"],
  ["unknown_ids", "Unknown ID streams"], ["dbc_known_non_associated_ids", "DBC-known, non-associated"],
  ["ecu_transmit_candidates", "ECU TX candidates"], ["ecu_receive_candidates", "ECU RX candidates"],
  ["timing_anomalies", "Timing anomalies"], ["potential_stopped_gaps", "Potential stopped-message gaps"],
  ["dlc_mismatches", "DLC / payload discrepancies"], ["signal_range_and_enum_findings", "Signal range / enum findings"],
  ["potential_timeout_qualifications", "Timeout qualification candidates"], ["potential_node_absence_events", "Node-absence candidates"],
  ["recorded_dtc_status_records", "Recorded UDS DTC records"]
];

function renderCards() {
  const overview = state.status?.overview || {};
  const rejected = state.status?.sources?.reduce((count, source) => count + source.rejected_line_count, 0) || 0;
  const values = { ...overview, rejected_malformed_lines: rejected };
  $("summary-cards").innerHTML = cards.map(([key, label]) => `<button class="summary-card" data-card="${key}" type="button"><strong>${key === "capture_duration_ms" ? number(values[key], 1) : Number(values[key] || 0).toLocaleString()}</strong><span>${label}</span></button>`).join("");
  $("summary-cards").querySelectorAll("[data-card]").forEach((card) => card.addEventListener("click", () => {
    const cardKey = card.dataset.card;
    if (cardKey === "unknown_ids") state.filters.attribution = "Unknown CAN ID";
    if (cardKey === "dbc_known_non_associated_ids") state.filters.attribution = "DBC-known, not associated with selected ECU";
    if (cardKey === "ecu_transmit_candidates") state.filters.attribution = "ECU-associated transmit candidate";
    if (cardKey === "ecu_receive_candidates") state.filters.attribution = "ECU-associated receive candidate";
    refreshStreams();
  }));
}

function updateFilterOptions() {
  const channels = [...new Set(state.streams.map((stream) => stream.channel))].sort();
  $("channel-filter").innerHTML = `<option value="">All channels</option>${channels.map((channel) => `<option value="${escapeHtml(channel)}">${escapeHtml(channel)}</option>`).join("")}`;
  $("channel-filter").value = state.filters.channel || "";
}

function renderTimeline(timeline) {
  const height = Math.max(90, 36 * timeline.lanes.length + 34);
  const width = 1100, left = 250, chartWidth = width - left - 20;
  const span = Math.max(1e-9, (timeline.end || 0) - (timeline.start || 0));
  const classFor = (attribution, hasAnomaly) => hasAnomaly ? "anomaly" : attribution?.includes("Unknown") || attribution?.includes("ambiguous") ? "unknown" : "known";
  let markup = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Communication timeline of ${timeline.frame_count || 0} frames"><text x="${left}" y="18" class="timeline-axis">${number(timeline.start, 6)} s</text><text x="${width - 86}" y="18" class="timeline-axis">${number(timeline.end, 6)} s</text>`;
  timeline.lanes.forEach((lane, laneIndex) => {
    const y = 34 + laneIndex * 36;
    const stream = state.streams.find((item) => item.stream_id === lane.stream_id);
    const markerClass = classFor(stream?.attribution, stream?.metrics.long_gap_count || stream?.metrics.burst_count);
    markup += `<g class="timeline-lane" data-stream-id="${lane.stream_id}" tabindex="0" role="button" aria-label="Open ${escapeHtml(lane.label)}"><rect x="0" y="${y - 15}" width="${width}" height="31" fill="transparent"></rect><text x="8" y="${y + 4}" class="timeline-label">${escapeHtml(lane.label).slice(0, 34)}</text><line x1="${left}" y1="${y}" x2="${width - 20}" y2="${y}" stroke="#2a4054"/>`;
    if (timeline.mode === "exact") {
      lane.frames.forEach((frame) => {
        const x = left + ((frame.timestamp - timeline.start) / span) * chartWidth;
        const tooltip = `${number(frame.timestamp, 6)} s | ${frame.can_id_hex} | ${frame.capture_direction} | ${frame.payload_hex} | ${frame.message_name || "No DBC message"} | ${frame.attribution}`;
        markup += `<circle class="timeline-marker ${markerClass}" cx="${x}" cy="${y}" r="3"><title>${escapeHtml(tooltip)}</title></circle>`;
      });
    } else {
      lane.bins.forEach((count, index) => {
        if (!count) return;
        const x = left + index / lane.bins.length * chartWidth;
        const opacity = Math.min(.95, .2 + Math.log10(count + 1) / 2);
        markup += `<rect class="timeline-marker ${markerClass}" x="${x}" y="${y - 7}" width="${Math.max(1, chartWidth / lane.bins.length)}" height="14" opacity="${opacity}"><title>Density bin: ${count} recorded frame(s)</title></rect>`;
      });
    }
    markup += "</g>";
  });
  markup += "</svg>";
  $("timeline").innerHTML = markup;
  $("timeline-mode").textContent = timeline.notice || (timeline.mode === "exact" ? "Exact frame markers" : "Density bins");
  $("timeline").querySelectorAll("[data-stream-id]").forEach((lane) => {
    const open = () => openDetail(lane.dataset.streamId);
    lane.addEventListener("click", open);
    lane.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); open(); } });
  });
}

function streamSearch() {
  const term = $("stream-search").value.trim().toLowerCase();
  return state.streams.filter((stream) => !term || [stream.message_name, stream.can_id_hex, stream.channel, stream.attribution].join(" ").toLowerCase().includes(term));
}

function renderStreams() {
  const rows = streamSearch();
  $("streams-table").querySelector("tbody").innerHTML = rows.map((stream) => {
    const metrics = stream.metrics;
    return `<tr tabindex="0" data-stream-id="${stream.stream_id}"><td><strong>${escapeHtml(stream.message_name || stream.can_id_hex)}</strong><br><span class="meta">${escapeHtml(stream.can_id_hex)} / ${escapeHtml(stream.identifier_type)}</span></td><td>${escapeHtml(stream.channel)}<br><span class="badge">${escapeHtml(stream.capture_direction)}</span></td><td>${escapeHtml(stream.attribution)}</td><td>${number(metrics.expected_cycle_ms)} ms</td><td>${number(metrics.mean_interval_ms)} / ${number(metrics.median_interval_ms)} ms</td><td>${number(metrics.min_interval_ms)} / ${number(metrics.max_interval_ms)} ms</td><td>${number(metrics.jitter_ms)} ms</td><td>${metrics.frame_count.toLocaleString()}</td><td>${metrics.long_gap_count} / ${metrics.burst_count}</td><td>${escapeHtml(stream.status)}</td></tr>`;
  }).join("") || `<tr><td colspan="10" class="empty-state">No timing streams match the selected filters.</td></tr>`;
  $("streams-table").querySelectorAll("[data-stream-id]").forEach((row) => {
    const open = () => openDetail(row.dataset.streamId);
    row.addEventListener("click", open);
    row.addEventListener("keydown", (event) => { if (event.key === "Enter") open(); });
  });
}

function renderFindings() {
  const severity = $("severity-filter").value;
  const findings = state.findings.filter((finding) => !severity || finding.severity === severity);
  const visibleFindings = findings.slice(0, 500);
  const overflow = findings.length > visibleFindings.length ? `<p class="empty-state">Showing the first ${visibleFindings.length.toLocaleString()} of ${findings.length.toLocaleString()} findings. Use severity filters and exports for the full evidence set.</p>` : "";
  $("findings").innerHTML = visibleFindings.map((finding) => `<article class="finding ${escapeHtml(finding.severity)}" tabindex="0" data-stream-id="${escapeHtml(finding.stream_id || "")}"><h3>${escapeHtml(finding.category)}</h3><p>${escapeHtml(finding.summary)}</p><p class="meta"><span class="badge">${escapeHtml(finding.severity)}</span><span class="badge">${escapeHtml(finding.confidence)} confidence</span>${escapeHtml(finding.affected_message || "No unambiguous DBC message")}</p><p class="meta"><strong>Rule:</strong> ${escapeHtml(finding.rule)}</p></article>`).join("") + overflow || `<p class="empty-state">No findings under the selected filter.</p>`;
  $("findings").querySelectorAll("[data-stream-id]").forEach((item) => {
    if (!item.dataset.streamId) return;
    item.addEventListener("click", () => openDetail(item.dataset.streamId));
    item.addEventListener("keydown", (event) => { if (event.key === "Enter") openDetail(item.dataset.streamId); });
  });
}

function renderExplorer(rows) {
  $("explorer").innerHTML = rows.map((row) => `<article class="explorer-item" tabindex="0" data-stream-id="${row.stream_id}"><strong>${escapeHtml(row.can_id_hex)} / channel ${escapeHtml(row.channel)} / ${escapeHtml(row.capture_direction)}</strong><p>${escapeHtml(row.reason)}</p><p class="meta">${row.count.toLocaleString()} frames · ${row.unique_payload_count} payloads · ${(row.payload_change_rate * 100).toFixed(1)}% payload change rate</p><p class="meta">Examples: ${row.payload_examples.map(escapeHtml).join(" | ")}</p></article>`).join("") || `<p class="empty-state">No unknown, non-associated, or ambiguous streams under the selected setup.</p>`;
  $("explorer").querySelectorAll("[data-stream-id]").forEach((item) => item.addEventListener("click", () => openDetail(item.dataset.streamId)));
}

function renderFaultAnalysis() {
  $("fault-options").innerHTML = state.faultOptions.map((option) => `<article class="fault-option"><h3>${escapeHtml(option.name)}</h3><p><span class="badge">${escapeHtml(option.capture_support)}</span></p><p>${escapeHtml(option.description)}</p><p class="meta">${escapeHtml(option.limitation)}</p></article>`).join("") || `<p class="empty-state">Fault-option definitions are unavailable.</p>`;
  const visibleEvents = [...state.faultEvents].sort((left, right) => left.qualification_timestamp - right.qualification_timestamp).slice(0, 500);
  const eventOverflow = state.faultEvents.length > visibleEvents.length ? `<p class="empty-state">Showing the first ${visibleEvents.length.toLocaleString()} of ${state.faultEvents.length.toLocaleString()} transitions. Download the fault-transition export for the complete timeline.</p>` : "";
  $("fault-events").innerHTML = visibleEvents.map((event) => {
    const qualification = number(event.qualification_timestamp, 6);
    const recovered = event.recovery_observed_timestamp === null ? "Not observed" : `${number(event.recovery_observed_timestamp, 6)} s`;
    const dequalification = event.dequalification_timestamp === null ? "Not evidenced in capture" : `${number(event.dequalification_timestamp, 6)} s`;
    const policy = event.policy_context?.length ? ` · ${event.policy_context.length} matching policy record(s)` : "";
    return `<article class="finding review" tabindex="0" data-stream-id="${escapeHtml(event.stream_id || "")}"><h3>${escapeHtml(event.category)}</h3><p>${escapeHtml(event.summary)}</p><p class="meta"><strong>Configured qualification:</strong> ${qualification} s · <strong>First recovery frame:</strong> ${recovered} · <strong>Configured dequalification:</strong> ${dequalification}${policy}</p><p class="meta"><strong>Rule:</strong> ${escapeHtml(event.rule)}</p></article>`;
  }).join("") + eventOverflow || `<p class="empty-state">No configured message-timeout or node-wide communication-absence candidate was found. A capture boundary is never treated as a qualified fault.</p>`;
  $("fault-events").querySelectorAll("[data-stream-id]").forEach((item) => {
    if (item.dataset.streamId) item.addEventListener("click", () => openDetail(item.dataset.streamId));
  });
  $("dtc-records").innerHTML = state.dtcs.map((record) => `<article class="finding info"><h3>DTC ${escapeHtml(record.dtc)} · ${escapeHtml(record.status_hex)}</h3><p>${escapeHtml(record.status_flags.join(", ") || "No status bits set")}</p><p class="meta">Recorded UDS 0x59/${record.subfunction.toString(16).padStart(2, "0").toUpperCase()} response at ${number(record.timestamp, 6)} s · ${record.source_frames.length} source frame(s)</p></article>`).join("") || `<p class="empty-state">No recorded ISO-TP UDS 0x59 DTC response was found. DTC availability is unknown; the tool did not send a diagnostic request.</p>`;
}

function renderConfigurationAudit() {
  const audit = state.configurationAudit;
  if (!audit) return;
  const summary = audit.summary;
  const checks = audit.checks.slice(0, 500);
  const overflow = audit.checks.length > checks.length ? `<p class="empty-state">Showing the first ${checks.length.toLocaleString()} of ${audit.checks.length.toLocaleString()} checks. Export the full audit for every source record.</p>` : "";
  $("configuration-audit").innerHTML = `<p class="meta">${summary.check_count.toLocaleString()} checks · <span class="badge">${summary.info_count} info</span><span class="badge">${summary.warning_count} warning</span><span class="badge">${summary.review_count} review</span></p>${checks.map((check) => `<article class="configuration-check ${escapeHtml(check.severity)}"><h3>${escapeHtml(check.category)}</h3><p>${escapeHtml(check.summary)}</p><p class="meta"><strong>Rule:</strong> ${escapeHtml(check.rule)}</p><p class="meta"><strong>Next:</strong> ${escapeHtml(check.next_step)}</p></article>`).join("")}${overflow}`;
}

function renderGuidance() {
  const guidance = state.guidance;
  if (!guidance) return;
  const focus = guidance.focus;
  const qualification = guidance.qualification;
  const timing = guidance.frame_stop_check;
  const counter = guidance.alive_counter_check;
  const configured = guidance.configured_message_content;
  $("message-guidance").classList.remove("empty-state");
  $("message-guidance").innerHTML = `
    <article class="guidance-card"><h3>Focused filter</h3><p><strong>${escapeHtml(focus.can_id_hex)}</strong> · ${escapeHtml(focus.selected_message || "Unresolved DBC message")}</p><p>${escapeHtml(focus.mapping_status)}</p><pre>${escapeHtml(JSON.stringify(focus.filter_hint, null, 2))}</pre></article>
    <article class="guidance-card"><h3>Qualification / recovery model</h3><p>${escapeHtml(qualification.status)}</p><p><strong>Detection:</strong> ${escapeHtml(qualification.detection_count ?? "Unavailable")} receptions / ${number(qualification.derived_qualification_ms)} ms</p><p><strong>Recovery:</strong> ${escapeHtml(qualification.recovery_count ?? "Unavailable")} receptions / ${number(qualification.derived_recovery_ms)} ms</p><p class="meta">${escapeHtml(qualification.tuple_interpretation || qualification.reason || "")}</p></article>
    <article class="guidance-card"><h3>Stopped-frame check</h3><p>${escapeHtml(timing.status)}</p><p><strong>Cycle:</strong> ${number(timing.expected_cycle_ms)} ms · <strong>Stopped threshold:</strong> ${number(timing.stopped_gap_threshold_ms)} ms</p><p><strong>Observed min / mean / max:</strong> ${number(timing.minimum_interval_ms)} / ${number(timing.mean_interval_ms)} / ${number(timing.maximum_interval_ms)} ms</p><p><strong>Internal stopped gaps:</strong> ${timing.stopped_gap_count}</p></article>
    <article class="guidance-card"><h3>Alive-counter check</h3><p>${escapeHtml(counter.status)}</p><p><strong>Signal:</strong> ${escapeHtml(counter.signal || "Unavailable")} · <strong>Rule:</strong> ${escapeHtml(counter.expected_transition || "Unavailable")}</p><p><strong>Transitions / mismatches:</strong> ${counter.transition_count ?? 0} / ${counter.mismatch_count ?? 0}</p><p><strong>Configured transition candidates:</strong> ${counter.configured_events?.length ?? 0}</p></article>
    <article class="guidance-card"><h3>CRC and configured DTC</h3><p>${escapeHtml(guidance.crc_check.status)}</p><p><strong>Observed CRC values:</strong> ${guidance.crc_check.distinct_observed_values}</p><pre>${escapeHtml(JSON.stringify(configured.integrity_signals, null, 2))}</pre><p class="meta">Policy records: ${configured.policy_context.length}</p></article>
    <article class="guidance-card"><h3>What to check next</h3><ul>${guidance.what_to_check.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul></article>`;
}

async function buildGuidance() {
  try {
    const params = new URLSearchParams({
      can_id: $("guidance-can-id").value,
      fault: $("guidance-fault-family").value,
      signal: $("guidance-signal").value
    });
    state.guidance = await api(`/api/guidance?${params}`);
    renderGuidance();
  } catch (error) {
    $("message-guidance").textContent = `Could not build the offline guide: ${error.message}`;
  }
}

function filterGuidanceMessage() {
  $("stream-search").value = $("guidance-can-id").value.trim().toLowerCase();
  renderStreams();
  $("timing-heading").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function prepareGuidanceCopilotQuestion() {
  if (!state.guidance) await buildGuidance();
  if (!state.guidance) return;
  $("copilot-question").value = state.guidance.copilot_question;
  clearCopilotConsent();
  $("copilot-heading").scrollIntoView({ behavior: "smooth", block: "start" });
}

function clearCopilotConsent() {
  $("copilot-consent").checked = false;
  $("copilot-consent").disabled = true;
  $("copilot-send").disabled = true;
  $("copilot-prompt").textContent = "";
  $("copilot-disclosure").textContent = "";
}

async function previewCopilotPrompt() {
  try {
    const preview = await api("/api/copilot/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: $("copilot-question").value })
    });
    $("copilot-prompt").textContent = preview.prompt;
    $("copilot-disclosure").innerHTML = `<strong>Data-sharing disclosure</strong><ul>${preview.disclosure.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`;
    $("copilot-consent").disabled = false;
    $("copilot-send").disabled = true;
    $("copilot-response").textContent = "Review the exact prompt and disclosure, then explicitly confirm before sending.";
  } catch (error) {
    $("copilot-response").textContent = `Could not prepare Copilot prompt: ${error.message}`;
  }
}

async function sendCopilotPrompt() {
  if (!$("copilot-consent").checked) return;
  try {
    $("copilot-send").disabled = true;
    $("copilot-response").textContent = "Copilot is analysing the reviewed aggregate-only prompt…";
    const job = await api("/api/copilot/query", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: $("copilot-question").value, confirmed: true })
    });
    const completed = await monitorJob(job.job_id);
    $("copilot-response").textContent = completed.result.response;
  } catch (error) {
    $("copilot-response").textContent = `Copilot analysis was not completed: ${error.message}`;
  }
}

function histogram(values) {
  if (!values.length) return `<p class="empty-state">No intervals available.</p>`;
  const bins = Array(20).fill(0), maximum = Math.max(...values), minimum = Math.min(...values), span = Math.max(1e-9, maximum - minimum);
  values.forEach((value) => bins[Math.min(19, Math.floor((value - minimum) / span * 20))]++);
  const top = Math.max(...bins);
  return `<div class="histogram" role="img" aria-label="Inter-arrival histogram from ${number(minimum)} to ${number(maximum)} milliseconds">${bins.map((count) => `<span title="${count} interval(s)" style="height:${Math.max(3, count / top * 100)}%"></span>`).join("")}</div>`;
}

async function openDetail(streamId) {
  try {
    const detail = await api(`/api/streams/${streamId}`);
    const signals = detail.decoded_samples.slice(0, 50).flatMap((sample) => sample.signals.map((signal) => ({ ...signal, timestamp: sample.timestamp })));
    $("detail").classList.remove("empty-state");
    $("detail").innerHTML = `<div class="detail-grid"><div><h3>${escapeHtml(detail.message_name || detail.can_id_hex)}</h3><p><span class="badge">${escapeHtml(detail.attribution)}</span><span class="badge">${escapeHtml(detail.capture_direction)}</span></p><p>${escapeHtml(detail.attribution_rationale)}</p><h3>Timing evidence</h3>${histogram(detail.timing_intervals_ms)}<p class="meta">Mean ${number(detail.metrics.mean_interval_ms)} ms · median ${number(detail.metrics.median_interval_ms)} ms · ${detail.metrics.long_gap_count} long gaps · ${detail.metrics.burst_count} bursts</p><h3>Payload length distribution</h3><pre>${escapeHtml(JSON.stringify(detail.length_distribution, null, 2))}</pre><h3>Decoding limitations</h3><ul>${detail.decoding_limitations.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul></div><div><h3>Raw metadata and DBC definition</h3><pre>${escapeHtml(JSON.stringify(detail.dbc_definition, null, 2))}</pre><h3>Representative source frames</h3><pre>${escapeHtml(JSON.stringify(detail.representative_frames, null, 2))}</pre><h3>Decoded signal samples</h3><div class="table-scroll"><table><thead><tr><th>Time</th><th>Signal</th><th>Raw</th><th>Physical</th><th>Unit</th><th>Enum</th><th>Status</th></tr></thead><tbody>${signals.map((signal) => `<tr><td>${number(signal.timestamp, 6)}</td><td>${escapeHtml(signal.name)}</td><td>${escapeHtml(signal.raw_value)}</td><td>${number(signal.physical_value, 4)}</td><td>${escapeHtml(signal.unit)}</td><td>${escapeHtml(signal.enum_label)}</td><td>${escapeHtml(signal.status)}</td></tr>`).join("") || `<tr><td colspan="7">No decodable signals.</td></tr>`}</tbody></table></div></div></div>`;
    $("detail").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    $("detail").textContent = `Could not open stream detail: ${error.message}`;
  }
}

function renderInventory(rows) {
  const ecus = new Set();
  $("inventory-table").querySelector("tbody").innerHTML = rows.map((row) => {
    row.senders.forEach((node) => ecus.add(node)); row.receivers.forEach((node) => ecus.add(node));
    return `<tr><td>${escapeHtml(row.message_name)}</td><td>${escapeHtml(row.can_id_hex)}<br><span class="meta">${escapeHtml(row.source_name)}</span></td><td>${escapeHtml(row.identifier_type)}</td><td>${escapeHtml(row.expected_dlc)} / ${number(row.cycle_time_ms)} ms</td><td>${escapeHtml(row.senders.join(", ") || "—")}<br>${escapeHtml(row.receivers.join(", ") || "—")}</td><td>${row.signal_count}</td><td>${escapeHtml(row.observed_status)}</td><td>${escapeHtml(row.selected_ecu_association)}</td><td>${escapeHtml(row.validation_warnings.join(" | ") || "None")}</td></tr>`;
  }).join("") || `<tr><td colspan="9" class="empty-state">Import DBC JSON to review its validated inventory.</td></tr>`;
  $("ecu-nodes").innerHTML = [...ecus].sort().map((node) => `<option value="${escapeHtml(node)}"></option>`).join("");
}

async function refreshStreams() {
  const parameters = query().toString();
  state.streams = await api(`/api/streams${parameters ? `?${parameters}` : ""}`);
  updateFilterOptions(); renderStreams();
  const timeline = await api(`/api/timeline${parameters ? `?${parameters}` : ""}`);
  renderTimeline(timeline);
}

async function refresh() {
  try {
    state.status = await api("/api/status");
    state.findings = await api("/api/findings");
    state.faultEvents = await api("/api/fault-events");
    state.dtcs = await api("/api/dtcs");
    state.faultOptions = (await api("/api/fault-options")).options;
    state.configurationAudit = await api("/api/configuration-audit");
    renderStatus(); renderCards(); await refreshStreams();
    renderFindings(); renderFaultAnalysis(); renderConfigurationAudit(); renderExplorer(await api("/api/explorer")); renderInventory(await api("/api/inventory"));
    setJobStatus(state.status.sources.length ? "Offline analysis ready." : "Ready for offline imports.");
  } catch (error) {
    setJobStatus(error.message, true);
  }
}

function readFilters() {
  state.filters = {
    channel: $("channel-filter").value,
    direction: $("direction-filter").value,
    start: $("start-time").value,
    end: $("end-time").value
  };
}

$("apply-filters").addEventListener("click", () => { readFilters(); refreshStreams(); });
$("timeline-reset").addEventListener("click", () => { state.filters = {}; $("channel-filter").value = ""; $("direction-filter").value = ""; $("start-time").value = ""; $("end-time").value = ""; refreshStreams(); });
$("stream-search").addEventListener("input", renderStreams);
$("severity-filter").addEventListener("change", renderFindings);
$("build-guidance").addEventListener("click", buildGuidance);
$("filter-guidance-message").addEventListener("click", filterGuidanceMessage);
$("guidance-to-copilot").addEventListener("click", prepareGuidanceCopilotQuestion);
$("copilot-question").addEventListener("input", clearCopilotConsent);
$("copilot-preview").addEventListener("click", previewCopilotPrompt);
$("copilot-consent").addEventListener("change", () => { $("copilot-send").disabled = !$("copilot-consent").checked; });
$("copilot-send").addEventListener("click", sendCopilotPrompt);
$("apply-settings").addEventListener("click", async () => {
  try {
    await api("/api/configuration", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target_ecu: $("target-ecu").value,
        settings: {
          minimum_gap_ms: Number($("minimum-gap-ms").value),
          absolute_tolerance_ms: Number($("absolute-tolerance-ms").value),
          stopped_multiplier: Number($("stopped-multiplier").value),
          jitter_fraction: Number($("jitter-fraction").value),
          burst_fraction: Number($("burst-fraction").value),
          timeout_qualification_ms: Number($("timeout-qualification-ms").value),
          timeout_recovery_ms: Number($("timeout-recovery-ms").value)
        }
      })
    });
    await refresh();
  } catch (error) { setJobStatus(error.message, true); }
});
configureDropZone("log-drop-zone", "log-file", "log");
configureDropZone("dbc-drop-zone", "dbc-file", "dbc");
configureDropZone("onfail-drop-zone", "onfail-file", "onfail-policy");
configureDropZone("canc-config-drop-zone", "canc-config-file", "canc-config");
configureDropZone("edr-config-drop-zone", "edr-config-file", "edr-config");
configureDropZone("canc-case-config-drop-zone", "canc-case-config-file", "canc-case-config");
refresh();
