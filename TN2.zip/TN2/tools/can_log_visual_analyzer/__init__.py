"""Offline-first ARIA/CAN log analysis workspace.

This package only reads imported recordings and DBC JSON metadata. It contains
no CAN transport, diagnostic-session, ECU configuration, or vehicle-control
capability.
"""

