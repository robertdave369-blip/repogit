Attribute VB_Name = "CodebeamerCleaner"
Option Explicit

'==============================================================================
'  CodebeamerCleaner  v4   -   COMPLETE, SELF-CONTAINED MODULE
'
'  Delete any earlier version of this module first, then import this one file.
'  Save the workbook as .xlsm (not .xlsx) or install into PERSONAL.XLSB.
'
'  Handles both kinds of junk in a Codebeamer Excel export:
'    1. HTML / CSS      <span style="...">, &nbsp;, <br>, <style> blocks
'    2. Wiki markup     [{Table style='...'}]  table macro
'                       |(text-align:center;...)CELL TEXT
'                       |^                      merged-with-above cell
'                       %%(text-decoration:line-through;)TEXT%!
'                       \\                      hard line break
'                       ~-  ~_  ~'  ~,          tilde escapes
'                       //italic//  **bold**  __bold__  ''italic''  {{mono}}
'
'  MACROS (Alt+F8)
'    DiagnoseSheet            read-only health check - RUN THIS FIRST
'    PreviewActiveCell        before/after for ONE cell, changes nothing
'    CleanCodebeamerExport    clean every used cell on the active sheet
'    CleanAllSheets           clean every sheet in the workbook
'    CleanSelectionOnly       clean the selected cells only
'    ExplodeCodebeamerTable   active cell's wiki table -> real grid, new sheet
'    TidyLayout               wrap text, sane column widths and row heights
'
'  Macros are NOT undoable. OPT_BACKUP_COPY snapshots the sheet first.
'==============================================================================

'------------------------------- OPTIONS --------------------------------------
Private Const OPT_BACKUP_COPY      As Boolean = True    ' hidden snapshot first
Private Const OPT_WIKI_MARKUP      As Boolean = True    ' handle Codebeamer wiki
Private Const OPT_WIKI_INLINE      As Boolean = True    ' //it// __bold__ {{mono}}
Private Const OPT_STRIP_LOOSE_SLASH As Boolean = True   ' remove orphaned //
Private Const OPT_UNESCAPE_TILDE   As Boolean = True    ' 1~-ENABLE -> 1-ENABLE
Private Const OPT_JOIN_ROWS        As Boolean = True    ' one table row per line
Private Const OPT_ROW_SEP          As String = " | "    ' between cells of a row
Private Const OPT_INCELL_JOIN      As String = " / "    ' between a cell's lines
Private Const OPT_MARK_STRIKE      As Boolean = True    ' keep strikethrough info
Private Const OPT_STRIKE_OPEN      As String = "[STRUCK]"
Private Const OPT_STRIKE_CLOSE     As String = "[/STRUCK]"

Private Const OPT_LINE_BREAKS      As Boolean = True    ' <br>,</p> -> newline
Private Const OPT_BULLET           As String = "- "     ' <li> prefix ("" = none)
Private Const OPT_CELL_SEP         As String = " | "    ' between </td> cells
Private Const OPT_STRIP_CSS_RULE   As Boolean = True    ' leftover  sel{a:b;}
Private Const OPT_COLLAPSE_BLANK   As Boolean = True    ' max one empty line
Private Const OPT_FILL_MERGED      As Boolean = True    ' |^ fills down on explode
Private Const OPT_CHUNK_ROWS       As Long = 2000
Private Const MAX_CELL_CHARS       As Long = 32767
'------------------------------------------------------------------------------

Private mRx As Object       ' compiled RegExp cache
Private mEnt As Object      ' named-entity lookup


'==============================================================================
'  ENTRY POINTS
'==============================================================================

Public Sub CleanCodebeamerExport()
    If ActiveSheet Is Nothing Then Exit Sub
    CleanRange ActiveSheet.UsedRange, True
End Sub

Public Sub CleanAllSheets()
    Dim ws As Worksheet, i As Long, total As Long
    Dim t0 As Single, msg As String

    If MsgBox("Clean ALL sheets in '" & ActiveWorkbook.Name & "'?" & vbCrLf & _
              "This cannot be undone with Ctrl+Z.", _
              vbOKCancel + vbQuestion, "Codebeamer Cleaner") <> vbOK Then Exit Sub

    t0 = Timer
    For i = 1 To ActiveWorkbook.Worksheets.Count
        Set ws = ActiveWorkbook.Worksheets(i)
        If ws.Visible = xlSheetVisible Then
            If InStr(1, ws.Name, "_orig", vbTextCompare) = 0 Then
                ws.Activate
                CleanRange ws.UsedRange, False
            End If
        End If
    Next i

    msg = "All visible sheets cleaned in " & Format$(Timer - t0, "0.0") & " s."
    MsgBox msg, vbInformation, "Codebeamer Cleaner"
End Sub

Public Sub CleanSelectionOnly()
    If TypeName(Selection) <> "Range" Then
        MsgBox "Select some cells first.", vbInformation
        Exit Sub
    End If
    CleanRange Selection, True
End Sub

Public Sub PreviewActiveCell()
    Dim src As String, res As String
    If TypeName(Selection) <> "Range" Then Exit Sub
    src = CStr(ActiveCell.Formula)
    res = CleanCell(src)
    MsgBox "BEFORE (" & Len(src) & " chars):" & vbCrLf & _
           Left$(src, 800) & IIf(Len(src) > 800, " ...", "") & vbCrLf & vbCrLf & _
           String(50, "-") & vbCrLf & vbCrLf & _
           "AFTER (" & Len(res) & " chars):" & vbCrLf & _
           Left$(res, 1200) & IIf(Len(res) > 1200, " ...", ""), _
           vbInformation, "Preview - " & ActiveCell.Address(False, False)
End Sub


'==============================================================================
'  DIAGNOSTIC - read only, changes nothing
'==============================================================================

Public Sub DiagnoseSheet()
    Dim ws As Worksheet, ur As Range
    Dim msg As String, arr As Variant
    Dim r As Long, cc As Long, sLen As Long
    Dim longest As Long, longAddr As String
    Dim nDirty As Long, nText As Long, nMerged As Long
    Dim v As Variant, mc As Variant, rngVal As Range

    Set ws = ActiveSheet
    Set ur = ws.UsedRange

    msg = "WORKBOOK: " & ws.Parent.Name & vbCrLf
    If LCase$(Right$(ws.Parent.Name, 5)) = ".xlsx" Then
        msg = msg & "   !! .xlsx cannot store macros - save as .xlsm" & vbCrLf
    End If
    msg = msg & "SHEET:    " & ws.Name & vbCrLf & _
          "Used range: " & ur.Address(False, False) & _
          "  (" & ur.Rows.Count & " rows x " & ur.Columns.Count & " cols)" & vbCrLf & vbCrLf

    msg = msg & "Sheet protected:      " & ws.ProtectContents
    If ws.ProtectContents Then msg = msg & "   <== blocks all cell writes"
    msg = msg & vbCrLf
    msg = msg & "Workbook structure:   " & ws.Parent.ProtectStructure & vbCrLf
    msg = msg & "Workbook read-only:   " & ws.Parent.ReadOnly & vbCrLf

    On Error Resume Next
    mc = ur.MergeCells
    If Err.Number <> 0 Then
        msg = msg & "Merged cells:         (unknown - mixed)" & vbCrLf
        Err.Clear
    ElseIf IsNull(mc) Then
        msg = msg & "Merged cells:         yes, some" & vbCrLf
    Else
        msg = msg & "Merged cells:         " & CBool(mc) & vbCrLf
    End If

    msg = msg & "Excel Tables here:    " & ws.ListObjects.Count
    If ws.ListObjects.Count > 0 Then msg = msg & "   (calculated columns can block writes)"
    msg = msg & vbCrLf

    Set rngVal = Nothing
    Set rngVal = ur.SpecialCells(xlCellTypeAllValidation)
    Err.Clear
    msg = msg & "Data validation:      " & (Not rngVal Is Nothing) & vbCrLf

    arr = ur.Formula
    If Err.Number <> 0 Then
        msg = msg & vbCrLf & "!! Could not READ .Formula from the used range." & vbCrLf & _
              "   Error " & Err.Number & ": " & Err.Description & vbCrLf & _
              "   This often means merged cells are present."
        Err.Clear
        On Error GoTo 0
        MsgBox msg, vbExclamation, "Diagnose"
        Exit Sub
    End If
    On Error GoTo 0

    If Not IsArray(arr) Then
        nText = 1
    Else
        For r = 1 To UBound(arr, 1)
            For cc = 1 To UBound(arr, 2)
                v = arr(r, cc)
                If VarType(v) = vbString Then
                    sLen = Len(v)
                    If sLen > 0 Then
                        nText = nText + 1
                        If NeedsCleaning(CStr(v)) Then nDirty = nDirty + 1
                        If sLen > longest Then
                            longest = sLen
                            longAddr = ur.Cells(r, cc).Address(False, False)
                        End If
                    End If
                End If
            Next cc
        Next r
    End If

    ' Count merged areas
    On Error Resume Next
    Dim ma As Range
    For Each ma In ur.Cells
        If ma.MergeCells Then
            If ma.Address = ma.MergeArea.Cells(1, 1).Address Then nMerged = nMerged + 1
        End If
        If nMerged > 50 Then Exit For   ' enough to know, don't scan 10K cells
    Next ma
    Err.Clear
    On Error GoTo 0

    msg = msg & vbCrLf & _
          "Text cells:           " & nText & vbCrLf & _
          "Cells needing clean:  " & nDirty & vbCrLf & _
          "Merged areas:         " & IIf(nMerged > 50, ">50", CStr(nMerged)) & vbCrLf & _
          "Longest cell:         " & longest & " chars at " & longAddr & vbCrLf
    If longest > MAX_CELL_CHARS Then msg = msg & "   (over 32,767 limit - will be truncated)" & vbCrLf

    MsgBox msg, vbInformation, "Diagnose - nothing was changed"
End Sub


'==============================================================================
'  DRIVER
'==============================================================================

Private Sub CleanRange(ByVal target As Range, ByVal showPrompt As Boolean)
    Dim ws As Worksheet, ar As Range
    Dim calcMode As XlCalculation
    Dim nChanged As Long, nTrunc As Long
    Dim t0 As Single, msg As String
    Dim failures As Collection, i As Long
    Dim reProtect As Boolean

    If target Is Nothing Then Exit Sub
    Set ws = target.Worksheet
    Set failures = New Collection

    If showPrompt Then
        If MsgBox("Clean " & target.Cells.CountLarge & " cells in " & _
                  target.Address(False, False) & " on sheet '" & ws.Name & "'?" & _
                  vbCrLf & vbCrLf & "This cannot be undone with Ctrl+Z.", _
                  vbOKCancel + vbQuestion, "Codebeamer Cleaner") <> vbOK Then Exit Sub
    End If

    ' Handle protection
    If ws.ProtectContents Then
        If showPrompt Then
            If MsgBox("Sheet '" & ws.Name & "' is protected, which blocks cell writes." & _
                      vbCrLf & vbCrLf & "Unprotect now and re-protect when finished?" & vbCrLf & _
                      "(Cancel if it needs a password - remove that manually first.)", _
                      vbOKCancel + vbQuestion, "Sheet is protected") <> vbOK Then Exit Sub
        End If
        On Error Resume Next
        ws.Unprotect
        If Err.Number <> 0 Then
            Err.Clear
            On Error GoTo 0
            If showPrompt Then
                MsgBox "Could not unprotect '" & ws.Name & "' - it probably has a password." & vbCrLf & _
                       "Review > Unprotect Sheet, then run this again.", vbExclamation
            End If
            Exit Sub
        End If
        On Error GoTo 0
        reProtect = True
    End If

    t0 = Timer

    If OPT_BACKUP_COPY Then
        On Error Resume Next
        MakeBackup ws
        If Err.Number <> 0 Then
            Dim backupErr As String
            backupErr = Err.Description
            Err.Clear
            On Error GoTo 0
            If showPrompt Then
                If MsgBox("Could not create backup sheet (" & backupErr & ")." & _
                          vbCrLf & vbCrLf & "Carry on without a backup?", _
                          vbYesNo + vbExclamation) <> vbYes Then
                    If reProtect Then ws.Protect
                    Exit Sub
                End If
            End If
        End If
        On Error GoTo 0
    End If

    With Application
        .ScreenUpdating = False
        .EnableEvents = False
        calcMode = .Calculation
        .Calculation = xlCalculationManual
    End With

    For Each ar In target.Areas
        ProcessArea ar, nChanged, nTrunc, failures
    Next ar

    With Application
        .Calculation = calcMode
        .EnableEvents = True
        .ScreenUpdating = True
        .StatusBar = False
    End With

    If reProtect Then
        On Error Resume Next
        ws.Protect
        On Error GoTo 0
    End If

    ' Report
    msg = ws.Name & ":  " & nChanged & " cell(s) cleaned in " & Format$(Timer - t0, "0.0") & " s."
    If nTrunc > 0 Then _
        msg = msg & vbCrLf & nTrunc & " cell(s) exceeded 32,767 characters and were truncated."

    If failures.Count > 0 Then
        msg = msg & vbCrLf & vbCrLf & failures.Count & " cell(s) could not be processed:" & vbCrLf
        For i = 1 To failures.Count
            If i > 12 Then
                msg = msg & "   ... and " & (failures.Count - 12) & " more"
                Exit For
            End If
            msg = msg & "   " & failures(i) & vbCrLf
        Next i
    End If

    If showPrompt Then
        MsgBox msg, IIf(failures.Count > 0, vbExclamation, vbInformation), "Codebeamer Cleaner"
    Else
        Debug.Print msg
    End If
End Sub


'==============================================================================
'  WORKER
'==============================================================================

Private Sub ProcessArea(ByVal ar As Range, ByRef nChanged As Long, _
                        ByRef nTrunc As Long, ByRef failures As Collection)
    Dim nRows As Long, nCols As Long
    Dim startR As Long, blockRows As Long
    Dim blk As Range, arr As Variant, scalar(1 To 1, 1 To 1) As Variant
    Dim r As Long, c As Long, readErr As Long
    Dim src As String, res As String
    Dim eNo As Long, eTx As String
    Dim cell As Range

    nRows = ar.Rows.Count
    nCols = ar.Columns.Count
    startR = 1

    Do While startR <= nRows
        blockRows = OPT_CHUNK_ROWS
        If startR + blockRows - 1 > nRows Then blockRows = nRows - startR + 1
        Set blk = ar.Cells(1, 1).Offset(startR - 1, 0).Resize(blockRows, nCols)

        ' --- bulk read attempt -----------------------------------------------
        readErr = 0
        On Error Resume Next
        arr = blk.Formula
        readErr = Err.Number
        Err.Clear
        On Error GoTo 0

        If readErr <> 0 Then
            ' Bulk read failed (usually merged cells) - read cell by cell
            ReDim arr(1 To blockRows, 1 To nCols)
            For r = 1 To blockRows
                For c = 1 To nCols
                    Set cell = blk.Cells(r, c)
                    On Error Resume Next
                    ' Skip non-anchor cells in merged regions
                    If cell.MergeCells Then
                        If cell.Address <> cell.MergeArea.Cells(1, 1).Address Then
                            arr(r, c) = Empty
                            Err.Clear
                            On Error GoTo 0
                            GoTo NextCellRead
                        End If
                    End If
                    arr(r, c) = cell.Formula
                    If Err.Number <> 0 Then
                        arr(r, c) = Empty
                        failures.Add cell.Address(False, False) & _
                                     "  read error " & Err.Number
                        Err.Clear
                    End If
                    On Error GoTo 0
NextCellRead:
                Next c
            Next r
        ElseIf Not IsArray(arr) Then
            scalar(1, 1) = arr
            arr = scalar
        End If

        ' --- clean and write -------------------------------------------------
        For r = 1 To UBound(arr, 1)
            For c = 1 To UBound(arr, 2)
                If VarType(arr(r, c)) = vbString Then
                    src = arr(r, c)
                    If Len(src) > 0 Then
                        If Left$(src, 1) <> "=" Then
                            If NeedsCleaning(src) Then

                                res = ""
                                On Error Resume Next
                                res = CleanCell(src)
                                If Err.Number <> 0 Then
                                    failures.Add blk.Cells(r, c).Address(False, False) & _
                                                 "  parse error " & Err.Number & ": " & Err.Description
                                    Err.Clear
                                    res = src
                                End If
                                On Error GoTo 0

                                If Len(res) > MAX_CELL_CHARS Then
                                    res = Left$(res, MAX_CELL_CHARS - 3) & "..."
                                    nTrunc = nTrunc + 1
                                End If

                                If StrComp(res, src, vbBinaryCompare) <> 0 Then
                                    If WriteCellSafe(blk.Cells(r, c), res, eNo, eTx) Then
                                        nChanged = nChanged + 1
                                    Else
                                        failures.Add blk.Cells(r, c).Address(False, False) & _
                                                     "  write error " & eNo & ": " & eTx
                                    End If
                                End If

                            End If
                        End If
                    End If
                End If
            Next c
        Next r

        Application.StatusBar = "Cleaning... row " & (blk.Row + blockRows - 1) & _
                                "   |   " & nChanged & " changed, " & failures.Count & " failed"
        startR = startR + blockRows
    Loop
End Sub


' Writes one cell, retrying with fallback strategies.
Private Function WriteCellSafe(ByVal c As Range, ByVal s As String, _
                               ByRef eNo As Long, ByRef eTx As String) As Boolean
    Dim tgt As Range

    Set tgt = c
    On Error Resume Next

    ' Redirect to merge anchor if needed
    If c.MergeCells Then
        Set tgt = c.MergeArea.Cells(1, 1)
    End If
    Err.Clear

    ' Attempt 1: plain value
    If Left$(s, 1) = "=" Then tgt.NumberFormat = "@"
    Err.Clear
    tgt.Value = s
    If Err.Number = 0 Then
        On Error GoTo 0
        WriteCellSafe = True
        Exit Function
    End If
    eNo = Err.Number: eTx = Err.Description
    Err.Clear

    ' Attempt 2: force Text format
    tgt.NumberFormat = "@"
    Err.Clear
    tgt.Value2 = s
    If Err.Number = 0 Then
        On Error GoTo 0
        WriteCellSafe = True
        Exit Function
    End If
    eNo = Err.Number: eTx = Err.Description
    Err.Clear

    ' Attempt 3: unlock and retry
    tgt.Locked = False
    Err.Clear
    tgt.Value = s
    If Err.Number = 0 Then
        On Error GoTo 0
        WriteCellSafe = True
        Exit Function
    End If
    eNo = Err.Number: eTx = Err.Description
    Err.Clear

    On Error GoTo 0
    WriteCellSafe = False
End Function


' Fast pre-filter: untouched cells cost almost nothing.
Private Function NeedsCleaning(ByVal s As String) As Boolean
    NeedsCleaning = True
    If InStr(1, s, "<") > 0 Then Exit Function
    If InStr(1, s, "&") > 0 Then Exit Function
    If InStr(1, s, "%%") > 0 Then Exit Function
    If InStr(1, s, "%!") > 0 Then Exit Function
    If InStr(1, s, "[{") > 0 Then Exit Function
    If InStr(1, s, "\\") > 0 Then Exit Function
    If InStr(1, s, "//") > 0 Then Exit Function
    If InStr(1, s, "~") > 0 Then Exit Function
    If InStr(1, s, "|") > 0 Then Exit Function
    If InStr(1, s, ChrW(160)) > 0 Then Exit Function
    If InStr(1, s, vbCr) > 0 Then Exit Function
    If InStr(1, s, "  ") > 0 Then Exit Function
    If InStr(1, s, vbTab) > 0 Then Exit Function
    If s <> Trim$(s) Then Exit Function
    NeedsCleaning = False
End Function


'==============================================================================
'  MASTER CLEANER   (also usable as a worksheet function: =CleanCell(A2) )
'==============================================================================

Public Function CleanCell(ByVal s As String) As String
    Dim t As String
    t = s
    t = Replace(t, vbCrLf, vbLf)
    t = Replace(t, vbCr, vbLf)

    If OPT_WIKI_MARKUP Then t = CleanWikiMarkup(t)
    t = StripHtml(t)
    t = FinalTidy(t)

    CleanCell = t
End Function


'==============================================================================
'  CODEBEAMER WIKI MARKUP
'==============================================================================

Private Function CleanWikiMarkup(ByVal t As String) As String
    ' Remove [{...}] macro wrappers
    t = Rx("^[ \t]*\[\{[^\r\n]*$").Replace(t, "")
    t = Rx("^[ \t]*\}\][ \t]*$").Replace(t, "")
    t = Rx("\[\{[^\[\]{}\r\n]*\}\]").Replace(t, "")
    Do While Right$(RTrim$(t), 2) = "}]"
        t = RTrim$(t)
        t = Left$(t, Len(t) - 2)
    Loop

    ' %%(css)text%!  spans
    t = StripPercentStyles(t)

    ' Wiki hard line break  \\
    t = Rx("\\\\[ \t]*\n?").Replace(t, vbLf)

    ' Table rows / cells
    t = AssembleTable(t)

    ' Inline wiki formatting
    t = StripWikiInline(t)

    ' Tilde escapes
    t = UnescapeTilde(t)

    CleanWikiMarkup = t
End Function


Private Function StripWikiInline(ByVal t As String) As String
    Dim urlMark As String
    urlMark = ChrW(57345)                   ' private-use sentinel

    If Not OPT_WIKI_INLINE Then StripWikiInline = t: Exit Function

    ' [label|target]  ->  label
    t = Rx("\[([^\[\]\|\r\n]+)\|[^\[\]\r\n]*\]").Replace(t, "$1")

    ' Shield URLs before touching //
    t = Replace(t, "://", urlMark)

    ' //italic//  **bold**  __bold__  ''italic''  {{mono}}
    t = Rx("//([^/\r\n]{1,400}?)//").Replace(t, "$1")
    t = Rx("\*\*([^\*\r\n]{1,400}?)\*\*").Replace(t, "$1")
    t = Rx("__([^_\r\n]+)__").Replace(t, "$1")
    t = Rx("''([^'\r\n]+)''").Replace(t, "$1")
    t = Rx("\{\{([^{}\r\n]*)\}\}").Replace(t, "$1")

    ' !!!Heading  ->  Heading
    t = Rx("^!{1,3}[ \t]*").Replace(t, "")

    ' Orphaned // that are not part of a URL
    If OPT_STRIP_LOOSE_SLASH Then
        t = Rx("(^|[^:/])//(?!/)").Replace(t, "$1")
    End If

    ' Restore URLs
    t = Replace(t, urlMark, "://")

    StripWikiInline = t
End Function


Private Function UnescapeTilde(ByVal t As String) As String
    If Not OPT_UNESCAPE_TILDE Then UnescapeTilde = t: Exit Function
    ' Tilde before any punctuation including , _ - ' etc.
    UnescapeTilde = Rx("~([\-_\*#\|\\\[\]\{\}\(\)!'""~%\^/\+=\.,:; ])").Replace(t, "$1")
End Function


' Removes %%(css) and %! tokens. Paren matching is depth-aware so that
' rgb(202, 237, 251) inside a style does not terminate the token early.
' Also handles  %%(text-decoration:line-through)  (without trailing semicolon).
Private Function StripPercentStyles(ByVal s As String) As String
    Dim out As String, p As Long, q As Long, n As Long
    Dim closePos As Long, inner As String
    Dim stack As Collection, isStrike As Boolean

    If InStr(1, s, "%") = 0 Then StripPercentStyles = s: Exit Function

    Set stack = New Collection
    n = Len(s)
    p = 1

    Do While p <= n
        q = InStr(p, s, "%")
        If q = 0 Then
            out = out & Mid$(s, p)
            Exit Do
        End If
        If q > p Then out = out & Mid$(s, p, q - p)

        If Mid$(s, q, 3) = "%%(" Then
            ' Depth-aware paren match
            If FindMatchingParen(s, q + 2, closePos, inner) Then
                isStrike = (InStr(1, inner, "line-through", vbTextCompare) > 0)
                stack.Add isStrike
                If isStrike And OPT_MARK_STRIKE Then out = out & OPT_STRIKE_OPEN
                p = closePos + 1
            Else
                ' Paren never closed on this line - try to find )  on next lines
                ' This handles  %%(text-decoration:line-through) \\\n%!
                Dim altClose As Long
                altClose = FindParenAcrossLines(s, q + 2)
                If altClose > 0 Then
                    inner = Mid$(s, q + 3, altClose - q - 3)
                    isStrike = (InStr(1, inner, "line-through", vbTextCompare) > 0)
                    stack.Add isStrike
                    If isStrike And OPT_MARK_STRIKE Then out = out & OPT_STRIKE_OPEN
                    p = altClose + 1
                Else
                    out = out & "%"
                    p = q + 1
                End If
            End If
        ElseIf Mid$(s, q, 2) = "%!" Then
            If stack.Count > 0 Then
                isStrike = stack(stack.Count)
                stack.Remove stack.Count
                If isStrike And OPT_MARK_STRIKE Then out = out & OPT_STRIKE_CLOSE
            End If
            p = q + 2
        Else
            out = out & "%"
            p = q + 1
        End If
    Loop

    ' Close any unclosed strikethrough markers
    Do While stack.Count > 0
        If stack(stack.Count) And OPT_MARK_STRIKE Then out = out & OPT_STRIKE_CLOSE
        stack.Remove stack.Count
    Loop

    StripPercentStyles = out
End Function


' Same-line paren matching with depth tracking.
Private Function FindMatchingParen(ByVal s As String, ByVal openPos As Long, _
                                   ByRef closePos As Long, ByRef inner As String) As Boolean
    Dim i As Long, depth As Long, ch As String
    If Mid$(s, openPos, 1) <> "(" Then Exit Function
    For i = openPos To Len(s)
        ch = Mid$(s, i, 1)
        Select Case ch
            Case "("
                depth = depth + 1
            Case ")"
                depth = depth - 1
                If depth = 0 Then
                    closePos = i
                    inner = Mid$(s, openPos + 1, i - openPos - 1)
                    FindMatchingParen = True
                    Exit Function
                End If
            Case vbLf, vbCr
                Exit Function          ' same-line only
        End Select
    Next i
End Function


' Cross-line paren match for edge cases like:
'   %%(text-decoration:line-through) \\
'   %!
Private Function FindParenAcrossLines(ByVal s As String, ByVal openPos As Long) As Long
    Dim i As Long, depth As Long, ch As String
    If Mid$(s, openPos, 1) <> "(" Then Exit Function
    For i = openPos To Len(s)
        ch = Mid$(s, i, 1)
        Select Case ch
            Case "("
                depth = depth + 1
            Case ")"
                depth = depth - 1
                If depth = 0 Then
                    FindParenAcrossLines = i
                    Exit Function
                End If
        End Select
        ' Safety: don't scan more than 500 chars for a closing paren
        If (i - openPos) > 500 Then Exit Function
    Next i
End Function


' Walks text line by line, turning  |(css)text  cells into rows.
' Lines that are not cells pass through untouched (prose above the table).
Private Function AssembleTable(ByVal s As String) As String
    Dim lines() As String, i As Long
    Dim outp As Collection, cells As Collection
    Dim curCell As String, hasCell As Boolean
    Dim isCell As Boolean, isMerge As Boolean
    Dim txt As String, ln As String

    If InStr(1, s, "|") = 0 Then AssembleTable = s: Exit Function

    Set outp = New Collection
    Set cells = New Collection
    lines = Split(s, vbLf)

    For i = LBound(lines) To UBound(lines)
        ln = lines(i)
        txt = StripCellPrefix(ln, isCell, isMerge)

        If isCell Then
            If hasCell Then cells.Add curCell
            curCell = txt
            hasCell = True
        ElseIf Len(Trim$(ln)) = 0 Then
            If hasCell Then cells.Add curCell
            hasCell = False: curCell = ""
            FlushRow outp, cells
        Else
            If hasCell Then
                If Len(Trim$(txt)) > 0 Then
                    If Len(curCell) = 0 Then
                        curCell = Trim$(txt)
                    Else
                        curCell = curCell & OPT_INCELL_JOIN & Trim$(txt)
                    End If
                End If
            Else
                outp.Add ln
            End If
        End If
    Next i

    If hasCell Then cells.Add curCell
    FlushRow outp, cells

    AssembleTable = JoinCollection(outp, vbLf)
End Function


Private Sub FlushRow(ByRef outp As Collection, ByRef cells As Collection)
    Dim i As Long, row As String, nonEmpty As Boolean

    If cells.Count = 0 Then Exit Sub

    For i = 1 To cells.Count
        If Len(Trim$(CStr(cells(i)))) > 0 Then nonEmpty = True
    Next i

    If nonEmpty Then
        If OPT_JOIN_ROWS Then
            For i = 1 To cells.Count
                If i > 1 Then row = row & OPT_ROW_SEP
                row = row & Trim$(CStr(cells(i)))
            Next i
            outp.Add row
        Else
            For i = 1 To cells.Count
                If Len(Trim$(CStr(cells(i)))) > 0 Then outp.Add Trim$(CStr(cells(i)))
            Next i
            outp.Add ""
        End If
    End If

    Set cells = New Collection
End Sub


' "|(text-align:center;...)BYTE"  ->  "BYTE"      isCell = True
' "|^"                            ->  ""           isMerge = True
Private Function StripCellPrefix(ByVal ln As String, ByRef isCell As Boolean, _
                                 ByRef isMerge As Boolean) As String
    Dim t As String, closePos As Long, inner As String

    isCell = False
    isMerge = False
    t = LTrim$(ln)

    If Left$(t, 1) <> "|" Then
        StripCellPrefix = ln
        Exit Function
    End If

    isCell = True
    Do While Left$(t, 1) = "|"
        t = Mid$(t, 2)
    Loop

    If Left$(t, 1) = "(" Then
        If FindMatchingParen(t, 1, closePos, inner) Then
            If InStr(1, inner, ":") > 0 Then t = Mid$(t, closePos + 1)
        End If
    End If

    If Trim$(t) = "^" Then
        isMerge = True
        t = ""
    End If

    StripCellPrefix = t
End Function


Private Function JoinCollection(ByVal col As Collection, ByVal sep As String) As String
    Dim arr() As String, i As Long
    If col.Count = 0 Then Exit Function
    ReDim arr(0 To col.Count - 1)
    For i = 1 To col.Count
        arr(i - 1) = CStr(col(i))
    Next i
    JoinCollection = Join(arr, sep)
End Function


'==============================================================================
'  HTML STRIPPING
'==============================================================================

Private Function StripHtml(ByVal t As String) As String
    ' Remove whole blocks, contents included
    t = Rx("<!--[\s\S]*?-->").Replace(t, "")
    t = Rx("<script[^>]*>[\s\S]*?</script\s*>").Replace(t, "")
    t = Rx("<style[^>]*>[\s\S]*?</style\s*>").Replace(t, "")
    t = Rx("<head[^>]*>[\s\S]*?</head\s*>").Replace(t, "")
    t = Rx("<!\[if[\s\S]*?<!\[endif\]>").Replace(t, "")
    t = Rx("<\?xml[\s\S]*?\?>").Replace(t, "")
    t = Rx("<!DOCTYPE[^>]*>").Replace(t, "")

    ' Structural tags become separators
    If OPT_LINE_BREAKS Then
        t = Rx("<br\s*/?\s*>").Replace(t, vbLf)
        t = Rx("<hr\s*/?\s*>").Replace(t, vbLf & "----------" & vbLf)
        t = Rx("</(td|th)\s*>").Replace(t, OPT_CELL_SEP)
        If Len(OPT_BULLET) > 0 Then
            t = Rx("<li(\s[^<>]*)?>").Replace(t, vbLf & OPT_BULLET)
        Else
            t = Rx("<li(\s[^<>]*)?>").Replace(t, vbLf)
        End If
        t = Rx("</(p|div|li|ul|ol|tr|table|h[1-6]|blockquote|pre|section|article)\s*>").Replace(t, vbLf)
        t = Rx("<(p|div|tr|h[1-6]|blockquote|pre|section|article)(\s[^<>]*)?>").Replace(t, vbLf)
    Else
        t = Rx("<br\s*/?\s*>").Replace(t, " ")
        t = Rx("</(td|th)\s*>").Replace(t, OPT_CELL_SEP)
    End If

    ' Strip all remaining tags. Requires letter/"/"/"!" after "<"
    ' so maths like "a < b and c > d" survives.
    t = Rx("</?[A-Za-z!][^<>]*>").Replace(t, "")

    ' Orphaned CSS rules - LINE-BOUNDED to avoid eating wiki table macros
    If OPT_STRIP_CSS_RULE Then
        t = Rx("^[^{}\r\n]*\{[^{}\r\n]*:[^{}\r\n]*;[^{}\r\n]*\}[ \t]*$").Replace(t, "")
        t = Rx("@(media|import|font-face|charset)[^;{\r\n]*(\{[^{}\r\n]*\}|;)").Replace(t, "")
    End If

    ' HTML entities
    t = DecodeNumericEntities(t)
    t = DecodeNamedEntities(t)
    t = Replace(t, "&amp;", "&")          ' always last

    StripHtml = t
End Function


'==============================================================================
'  WHITESPACE CLEANUP
'==============================================================================

Private Function FinalTidy(ByVal t As String) As String
    ' Exotic whitespace
    t = Replace(t, ChrW(160), " ")        ' non-breaking space
    t = Replace(t, ChrW(8203), "")        ' zero-width space
    t = Replace(t, ChrW(8232), vbLf)      ' line separator
    t = Replace(t, ChrW(8233), vbLf)      ' paragraph separator
    t = Replace(t, ChrW(65279), "")       ' BOM
    t = Replace(t, vbTab, " ")

    ' Trailing table separators
    t = Rx("(\s*\|)+[ \t]*(\n|$)").Replace(t, vbLf)

    ' Collapse whitespace
    t = Rx("[ ]{2,}").Replace(t, " ")
    t = Rx("[ ]+\n").Replace(t, vbLf)
    t = Rx("\n[ ]+").Replace(t, vbLf)
    If OPT_COLLAPSE_BLANK Then t = Rx("\n{3,}").Replace(t, vbLf & vbLf)

    ' Trim leading and trailing whitespace
    Do While Len(t) > 0
        If Left$(t, 1) = vbLf Or Left$(t, 1) = " " Then t = Mid$(t, 2) Else Exit Do
    Loop
    Do While Len(t) > 0
        If Right$(t, 1) = vbLf Or Right$(t, 1) = " " Then t = Left$(t, Len(t) - 1) Else Exit Do
    Loop

    FinalTidy = t
End Function


'==============================================================================
'  HTML ENTITIES
'==============================================================================

Private Function DecodeNumericEntities(ByVal t As String) As String
    Dim mc As Object, m As Object, d As Object, k As Variant, code As Long
    If InStr(1, t, "&#") = 0 Then DecodeNumericEntities = t: Exit Function

    Set d = CreateObject("Scripting.Dictionary")

    ' Decimal: &#160;
    Set mc = Rx("&#(\d{1,7});").Execute(t)
    For Each m In mc
        If Not d.Exists(m.Value) Then
            code = CLng(m.SubMatches(0))
            If code > 0 And code < 1114112 Then d.Add m.Value, SafeChrW(code)
        End If
    Next m

    ' Hexadecimal: &#xA0;
    Set mc = Rx("&#[xX]([0-9A-Fa-f]{1,6});").Execute(t)
    For Each m In mc
        If Not d.Exists(m.Value) Then
            code = CLng("&H" & m.SubMatches(0))
            If code > 0 And code < 1114112 Then d.Add m.Value, SafeChrW(code)
        End If
    Next m

    For Each k In d.Keys
        t = Replace(t, CStr(k), d(k))
    Next k

    DecodeNumericEntities = t
End Function


Private Function SafeChrW(ByVal code As Long) As String
    If code > 65535 Then
        SafeChrW = "?"
    ElseIf code > 32767 Then
        SafeChrW = ChrW(code - 65536)
    Else
        SafeChrW = ChrW(code)
    End If
End Function


Private Function DecodeNamedEntities(ByVal t As String) As String
    Dim mc As Object, m As Object, d As Object, k As Variant, map As Object
    If InStr(1, t, "&") = 0 Then DecodeNamedEntities = t: Exit Function

    Set map = EntityMap()
    Set d = CreateObject("Scripting.Dictionary")
    d.CompareMode = vbBinaryCompare

    Set mc = Rx("&[A-Za-z][A-Za-z0-9]{1,12};").Execute(t)
    For Each m In mc
        If Not d.Exists(m.Value) Then
            If map.Exists(m.Value) Then d.Add m.Value, map(m.Value)
        End If
    Next m

    For Each k In d.Keys
        If StrComp(CStr(k), "&amp;", vbTextCompare) <> 0 Then
            t = Replace(t, CStr(k), d(k))
        End If
    Next k

    DecodeNamedEntities = t
End Function


Private Function EntityMap() As Object
    If Not mEnt Is Nothing Then Set EntityMap = mEnt: Exit Function

    Set mEnt = CreateObject("Scripting.Dictionary")
    mEnt.CompareMode = vbTextCompare

    AddEnt "nbsp", " ": AddEnt "lt", "<": AddEnt "gt", ">"
    AddEnt "quot", """": AddEnt "apos", "'": AddEnt "shy", ""
    AddEnt "ensp", " ": AddEnt "emsp", " ": AddEnt "thinsp", " "
    AddEnt "zwnj", "": AddEnt "zwj", ""
    AddEnt "bull", ChrW(8226): AddEnt "middot", ChrW(183)
    AddEnt "hellip", "...": AddEnt "ndash", "-": AddEnt "mdash", "-"
    AddEnt "minus", "-": AddEnt "lsquo", "'": AddEnt "rsquo", "'"
    AddEnt "sbquo", "'": AddEnt "ldquo", """": AddEnt "rdquo", """"
    AddEnt "bdquo", """": AddEnt "laquo", ChrW(171): AddEnt "raquo", ChrW(187)
    AddEnt "copy", ChrW(169): AddEnt "reg", ChrW(174): AddEnt "trade", ChrW(8482)
    AddEnt "deg", ChrW(176): AddEnt "plusmn", ChrW(177): AddEnt "times", ChrW(215)
    AddEnt "divide", ChrW(247): AddEnt "micro", ChrW(181): AddEnt "para", ChrW(182)
    AddEnt "sect", ChrW(167): AddEnt "dagger", ChrW(8224): AddEnt "permil", ChrW(8240)
    AddEnt "euro", ChrW(8364): AddEnt "pound", ChrW(163): AddEnt "yen", ChrW(165)
    AddEnt "cent", ChrW(162): AddEnt "curren", ChrW(164)
    AddEnt "frac12", "1/2": AddEnt "frac14", "1/4": AddEnt "frac34", "3/4"
    AddEnt "sup1", "1": AddEnt "sup2", "2": AddEnt "sup3", "3"
    AddEnt "larr", "<-": AddEnt "rarr", "->": AddEnt "harr", "<->"
    AddEnt "uarr", ChrW(8593): AddEnt "darr", ChrW(8595)
    AddEnt "le", "<=": AddEnt "ge", ">=": AddEnt "ne", "<>": AddEnt "asymp", "~"
    AddEnt "alpha", ChrW(945): AddEnt "beta", ChrW(946): AddEnt "gamma", ChrW(947)
    AddEnt "delta", ChrW(948): AddEnt "mu", ChrW(956)
    AddEnt "omega", ChrW(969): AddEnt "Omega", ChrW(937)
    AddEnt "amp", "&"

    Set EntityMap = mEnt
End Function


Private Sub AddEnt(ByVal nm As String, ByVal val As String)
    If Not mEnt.Exists("&" & nm & ";") Then mEnt.Add "&" & nm & ";", val
End Sub


'==============================================================================
'  EXPLODE ONE TABLE CELL INTO A REAL GRID
'==============================================================================

Public Sub ExplodeCodebeamerTable()
    Dim src As String, t As String
    Dim lines() As String, i As Long, j As Long
    Dim rows As Collection, cells As Collection
    Dim isCell As Boolean, isMerge As Boolean
    Dim curCell As String, hasCell As Boolean, txt As String, ln As String
    Dim maxCols As Long, ws As Worksheet, nm As String, prev As String

    If TypeName(Selection) <> "Range" Then Exit Sub
    src = CStr(ActiveCell.Formula)
    If Len(src) = 0 Then MsgBox "The active cell is empty.", vbInformation: Exit Sub

    nm = "Tbl_" & ActiveCell.Parent.Name & "_" & ActiveCell.Address(False, False)
    nm = Left$(Rx("[\\/\?\*\[\]:]").Replace(nm, "_"), 31)

    t = Replace(Replace(src, vbCrLf, vbLf), vbCr, vbLf)
    t = Rx("^[ \t]*\[\{[^\r\n]*$").Replace(t, "")
    t = Rx("^[ \t]*\}\][ \t]*$").Replace(t, "")
    t = StripPercentStyles(t)
    t = Rx("\\\\[ \t]*\n?").Replace(t, vbLf)

    Set rows = New Collection
    Set cells = New Collection
    lines = Split(t, vbLf)

    For i = LBound(lines) To UBound(lines)
        ln = lines(i)
        txt = StripCellPrefix(ln, isCell, isMerge)
        If isCell Then
            If hasCell Then cells.Add curCell
            curCell = txt
            hasCell = True
        ElseIf Len(Trim$(ln)) = 0 Then
            If hasCell Then cells.Add curCell
            hasCell = False: curCell = ""
            If cells.Count > 0 Then
                rows.Add cells
                Set cells = New Collection
            End If
        Else
            If hasCell Then
                If Len(Trim$(txt)) > 0 Then
                    If Len(curCell) = 0 Then curCell = Trim$(txt) Else curCell = curCell & vbLf & Trim$(txt)
                End If
            End If
        End If
    Next i
    If hasCell Then cells.Add curCell
    If cells.Count > 0 Then rows.Add cells

    If rows.Count = 0 Then
        MsgBox "No wiki table rows found in " & ActiveCell.Address(False, False) & ".", vbInformation
        Exit Sub
    End If

    For i = 1 To rows.Count
        If rows(i).Count > maxCols Then maxCols = rows(i).Count
    Next i

    Application.ScreenUpdating = False
    Set ws = ActiveWorkbook.Worksheets.Add(After:=ActiveWorkbook.Sheets(ActiveWorkbook.Sheets.Count))
    On Error Resume Next
    ws.Name = nm
    On Error GoTo 0

    For i = 1 To rows.Count
        Set cells = rows(i)
        For j = 1 To cells.Count
            txt = CleanFragment(CStr(cells(j)))
            If Len(txt) = 0 And OPT_FILL_MERGED And i > 1 Then
                prev = CStr(ws.Cells(i - 1, j).Value)
                If Len(prev) > 0 Then txt = prev
            End If
            If Left$(txt, 1) = "=" Then ws.Cells(i, j).NumberFormat = "@"
            ws.Cells(i, j).Value = txt
        Next j
    Next i

    With ws.Range(ws.Cells(1, 1), ws.Cells(rows.Count, maxCols))
        .WrapText = True
        .VerticalAlignment = xlTop
        .Rows(1).Font.Bold = True
        .Rows(1).Interior.Color = RGB(202, 237, 251)
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(180, 180, 180)
        .EntireColumn.AutoFit
    End With
    For j = 1 To maxCols
        If ws.Columns(j).ColumnWidth > 45 Then ws.Columns(j).ColumnWidth = 45
    Next j
    ws.Rows(1).AutoFit
    ws.Activate
    ws.Range("A2").Select
    ActiveWindow.FreezePanes = True

    Application.ScreenUpdating = True
    MsgBox rows.Count & " row(s) x " & maxCols & " column(s) written to '" & ws.Name & "'.", _
           vbInformation, "Explode table"
End Sub


' Clean an already-extracted cell fragment (no table re-assembly needed).
Private Function CleanFragment(ByVal s As String) As String
    Dim t As String
    t = StripWikiInline(s)
    t = UnescapeTilde(t)
    t = StripHtml(t)
    t = FinalTidy(t)
    CleanFragment = t
End Function


'==============================================================================
'  HELPERS
'==============================================================================

Private Function Rx(ByVal pat As String, _
                    Optional ByVal ignoreCase As Boolean = True, _
                    Optional ByVal multiLine As Boolean = True) As Object
    Dim key As String, re As Object
    If mRx Is Nothing Then Set mRx = CreateObject("Scripting.Dictionary")
    key = pat & Chr(1) & CStr(ignoreCase) & Chr(1) & CStr(multiLine)
    If Not mRx.Exists(key) Then
        Set re = CreateObject("VBScript.RegExp")
        re.Global = True
        re.IgnoreCase = ignoreCase
        re.multiLine = multiLine
        re.pattern = pat
        mRx.Add key, re
    End If
    Set Rx = mRx(key)
End Function


Private Sub MakeBackup(ByVal ws As Worksheet)
    Dim wb As Workbook, nm As String, base As String, i As Long, bak As Worksheet
    Set wb = ws.Parent
    base = Left$(ws.Name, 22) & "_orig"
    nm = base
    i = 1
    Do While SheetExists(wb, nm)
        i = i + 1
        nm = Left$(base, 27) & "_" & i
    Loop
    Application.DisplayAlerts = False
    ws.Copy After:=wb.Sheets(wb.Sheets.Count)
    Set bak = wb.Sheets(wb.Sheets.Count)
    bak.Name = nm
    bak.Visible = xlSheetHidden
    Application.DisplayAlerts = True
    ws.Activate
End Sub


Private Function SheetExists(ByVal wb As Workbook, ByVal nm As String) As Boolean
    Dim sh As Object
    For Each sh In wb.Sheets
        If StrComp(sh.Name, nm, vbTextCompare) = 0 Then SheetExists = True: Exit Function
    Next sh
End Function


Public Sub TidyLayout()
    Const MAX_COL_WIDTH As Double = 60
    Const MAX_ROW_HEIGHT As Double = 150
    Dim ws As Worksheet, col As Range, rw As Range

    Set ws = ActiveSheet
    Application.ScreenUpdating = False

    With ws.UsedRange
        .WrapText = True
        .VerticalAlignment = xlTop
        .HorizontalAlignment = xlLeft
        .EntireColumn.AutoFit
    End With

    For Each col In ws.UsedRange.Columns
        If col.ColumnWidth > MAX_COL_WIDTH Then col.ColumnWidth = MAX_COL_WIDTH
    Next col

    ws.UsedRange.EntireRow.AutoFit
    For Each rw In ws.UsedRange.Rows
        If rw.RowHeight > MAX_ROW_HEIGHT Then rw.RowHeight = MAX_ROW_HEIGHT
    Next rw

    ws.Activate
    ActiveWindow.FreezePanes = False
    ws.Cells(ws.UsedRange.Row + 1, 1).Select
    ActiveWindow.FreezePanes = True
    ws.Cells(1, 1).Select
    Application.ScreenUpdating = True
End Sub
