"""Build a project's canc_config.py from its CAN database(s).

A project has a CAN-FD bus, a high-speed CAN bus, a normal (classic) CAN bus, or a mix,
one DBC each. Each DBC is written from the SRS side: its node list (BU_) names the SRS,
the frames the SRS transmits carry it as sender, and every other frame is one the bench
must transmit (the restbus). The config uses the variables every project's config uses
(tools/canc_common_names.py): the SRS outputs of the main bus in CAN_SIGNAL_Rx_MAP, of a
second bus in CAN_HSCAN_SIGNAL_Rx_MAP, every signal with its ARIA channel ("bus") and
"is_fd" - so it reads like every other project's. EDR parameter names are the common
ones (U171's). tools/canc_config_gui.py asks for all of this in a window and runs this
builder.

What the DBC gives, and this tool fills in directly
    frames, CAN IDs, DLC, cycle times, CAN-FD or classic CAN, every signal's width,
    sign, factor, offset, range, unit and value table; which frames carry a CRC or an
    alive counter (by signal name); which frames are diagnostic or network management;
    per signal the invalid, reserved and out-of-range raw codes and the default raw;
    the SRS output frames read at crash time; the CAN wakeup status signal and the NM
    wakeup signal (by their value-table labels).

What a DBC does not give, read from the project's inputs file
    DTC codes, the key frame of each node, which node sends each frame, EDR parameter
    names, crash-output expectations and the network-management counts and delays.
    `--init-inputs` writes a starter inputs file with every DBC-derived guess filled
    in and marked, and every unknown left None. Anything still missing when the config
    is built is left None in it and listed in CANC_DBC_OPEN_ITEMS at its end.

Rules (same as the EV/U171 EDR CAN-C work, .github/agents/canc_onfail.md)
    Node absent stops the node's key frame. Message timeout stops the frame carrying the
    signal; where that frame IS the key frame there is no timeout case
    (non_key_timeout_frame None). Message content failure needs a CRC or alive counter
    in the frame; SecOC MAC / freshness signals are listed separately and are never
    treated as message-content (E2E) signals. Invalid codes are the value-table entries
    labelled invalid, reserved codes those labelled reserved, and the out-of-range raw
    is the highest raw the width carries above the DBC maximum that the value table does
    not name and that is not the default (tools/edr_canc_review_model.dbc_codes).

Offline only: reads DBCs and the inputs file, writes one config file. It never
overwrites an existing file without --force, and never writes the hand-maintained
U171, Z121 or M310_M314_M110 configs.

Usage:
    py -3.14 tools/build_canc_config_from_dbc.py --project M210 \\
        --dbc project_dbc/m210_dbc/SRS_FD_SVNID_41243.dbc \\
        --dbc project_dbc/m210_dbc/SRS_HSCAN_SVNID_41243.dbc --init-inputs
    (edit projects/M210/config/canc_dbc_inputs.py)
    py -3.14 tools/build_canc_config_from_dbc.py --project M210 \\
        --dbc project_dbc/m210_dbc/SRS_FD_SVNID_41243.dbc \\
        --dbc project_dbc/m210_dbc/SRS_HSCAN_SVNID_41243.dbc

    --dbc detects the bus type of each file (CAN-FD frames -> CANFD, else HSCAN);
    --fd / --hs / --can name it explicitly (--can: normal, classic CAN).
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import pprint
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import cantools

sys.path.insert(0, str(Path(__file__).resolve().parent))
import canc_common_names as common  # noqa: E402
import build_edr_config_from_diag as edr_names  # noqa: E402  (COMMON_ELEMENT_NAMES)

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]

# Hand-maintained configs this tool must never write (user decision 2026-10-08: the
# generator is for new projects).
HAND_MAINTAINED_PROJECTS = {"U171", "Z121", "M310_M314_M110"}

BUS_TYPES = common.BUS_TYPES
OPTION_OF_BUS = {"CANFD": "fd", "HSCAN": "hs", "CAN": "can"}
INPUTS_FILE_NAME = "canc_dbc_inputs.py"

DIAG_ATTRIBUTES = ("DiagRequest", "DiagResponse", "DiagState")
NM_ATTRIBUTES = ("NmMessage", "NmAsrMessage")
DIAG_NAME = re.compile(r"DIAG|TESTER", re.IGNORECASE)
NM_NAME = re.compile(r"CANNM|(^|_)NM(_|$)", re.IGNORECASE)
PSEUDO_FRAMES = {"VECTOR__INDEPENDENT_SIG_MSG"}

# End-to-end protection signals (accidental corruption). SecOC signals (deliberate
# attacker) are matched first and kept apart: a MAC is not a message-content check.
SECOC_SIGNAL = re.compile(r"TRUNCATED_MAC|FRESHNESS|(^|_)MAC($|_)", re.IGNORECASE)
CRC_SIGNAL = re.compile(r"CRC|CHECKSUM|CHKSUM", re.IGNORECASE)
COUNTER_SIGNAL = re.compile(r"MSG_?CNT|MSG_?COUNT|COUNTER|ALIVE|ROLLING", re.IGNORECASE)

NETWORK_MANAGEMENT_NAMES = (
    "NODE_ABSENT_DETECTION_COUNT", "NODE_ABSENT_RECOVERY_COUNT",
    "MESSAGE_TIMEOUT_DETECTION_COUNT", "MESSAGE_TIMEOUT_RECOVERY_COUNT",
    "MESSAGE_CONTENT_DETECTION_COUNT", "MESSAGE_CONTENT_RECOVERY_COUNT",
    "SIGNAL_CONTENT_DETECTION_COUNT", "SIGNAL_CONTENT_RECOVERY_COUNT",
    "NM_DRIVE_COUNT_TO_CLEAR_DTC",
    "BUSOFF_FAST_RECOVERY_TIME_MS", "BUSOFF_FAST_RECOVERY_COUNT", "BUSOFF_SLOW_RECOVERY_TIME_MS",
    "NM_IGN_ON_STARTUP_DELAY_MS",
    "NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS", "NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS",
    "NM_RESTART_DELAY_AFTER_BUS_OFF_MS", "NM_RESTART_DELAY_AFTER_CRANKING_MS",
    "CAN_WAKEUP_FEATURE_ENABLE", "CAN_WAKEUP_MSG_COUNT",
    "WAKEUP_QUICK_RECOVERY_TIMEOUT_MS", "WAKEUP_QUICK_RECOVERY_RETRY_LIMIT",
    "WAKEUP_SLOW_RECOVERY_TIMEOUT_MS", "WAKEUP_SLOW_RECOVERY_RETRY_LIMIT",
)
WAKEUP_NAMES = (
    "CAN_WAKEUP_STATUS_FRAME", "CAN_WAKEUP_STATUS_SIGNAL", "CAN_WAKEUP_STATUS_VALUE",
    "CAN_WAKEUP_BUS_SLEEP_WAIT_MS",
    "CAN_NM_WAKEUP_FRAME", "CAN_NM_WAKEUP_SIGNAL", "CAN_NM_WAKEUP_VALUE", "CAN_NM_SRS_FRAME",
)
CRASH_TYPES = ("front", "left", "right", "rear", "near")


# --------------------------------------------------------------------------------------
# Reading the DBCs
# --------------------------------------------------------------------------------------


@dataclass
class Signal:
    name: str
    frame: str
    bit_length: int
    signed: bool
    factor: float
    offset: float
    minimum: float | None
    maximum: float | None
    unit: str | None
    values: dict[int, str]
    initial: int | None
    received: bool          # the SRS is a receiver of this signal


@dataclass
class Frame:
    name: str
    frame_id: int
    dlc: int
    cycle_ms: int
    bus: str
    is_fd: bool
    kind: str               # "restbus", "ecu_tx", "diag"
    is_nm: bool
    signals: list[Signal] = field(default_factory=list)

    @property
    def ecu_signals(self) -> list[Signal]:
        """The signals the SRS consumes; all of them if the DBC names no receivers."""
        if self.kind == "ecu_tx":
            return list(self.signals)
        received = [signal for signal in self.signals if signal.received]
        return received or list(self.signals)


@dataclass
class Bus:
    bus: str
    path: Path
    ecu_node: str
    frames: list[Frame]


def _attribute(obj: Any, name: str) -> Any:
    dbc = getattr(obj, "dbc", None)
    attribute = dbc.attributes.get(name) if dbc is not None else None
    return None if attribute is None else attribute.value


def _number(value: Any) -> Any:
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


def _ecu_node(database: Any, path: Path, requested: str | None) -> str:
    nodes = [node.name for node in database.nodes]
    if requested:
        if requested not in nodes:
            raise SystemExit(f"{path.name}: node {requested!r} is not in the DBC node list {nodes}")
        return requested
    if len(nodes) == 1:
        return nodes[0]
    srs = [name for name in nodes if name.upper().startswith("SRS")]
    if len(srs) == 1:
        return srs[0]
    raise SystemExit(f"{path.name}: cannot tell which node is the SRS among {nodes}; "
                     "pass --ecu-node")


def read_bus(path: Path, bus: str | None, ecu_node: str | None) -> Bus:
    database = cantools.database.load_file(str(path), strict=False)
    node = _ecu_node(database, path, ecu_node)
    frames: list[Frame] = []
    for message in database.messages:
        if message.name in PSEUDO_FRAMES:
            continue
        is_diag = (any(_attribute(message, name) == 1 for name in DIAG_ATTRIBUTES)
                   or bool(DIAG_NAME.search(message.name)))
        is_nm = (any(_attribute(message, name) == 1 for name in NM_ATTRIBUTES)
                 or bool(NM_NAME.search(message.name)))
        sent_by_ecu = node in (message.senders or [])
        kind = "diag" if is_diag else "ecu_tx" if sent_by_ecu else "restbus"
        frame = Frame(
            name=message.name, frame_id=int(message.frame_id), dlc=int(message.length),
            cycle_ms=int(message.cycle_time or 0), bus="", is_fd=bool(message.is_fd),
            kind=kind, is_nm=is_nm and not is_diag,
        )
        for signal in message.signals:
            frame.signals.append(Signal(
                name=signal.name, frame=message.name, bit_length=int(signal.length),
                signed=bool(signal.is_signed), factor=_number(signal.scale),
                offset=_number(signal.offset), minimum=_number(signal.minimum),
                maximum=_number(signal.maximum), unit=signal.unit or None,
                values={int(raw): str(label) for raw, label in (signal.choices or {}).items()},
                initial=None if signal.raw_initial is None else int(signal.raw_initial),
                received=node in (signal.receivers or []),
            ))
        frames.append(frame)

    detected = "CANFD" if any(frame.is_fd for frame in frames) else "HSCAN"
    if bus is None:
        bus = detected
    elif bus not in BUS_TYPES:
        raise SystemExit(f"{path.name}: bus type {bus!r} is not one of {BUS_TYPES}")
    elif (bus == "CANFD") != (detected == "CANFD"):
        # HS-CAN and normal CAN both carry classic frames, so only CAN-FD is detectable.
        print(f"WARNING: {path.name} is named {bus} but its frames look "
              f"{'CAN-FD' if detected == 'CANFD' else 'classic'}; using {bus} as named.")
    for frame in frames:
        frame.bus = bus
    return Bus(bus=bus, path=path, ecu_node=node, frames=frames)


# --------------------------------------------------------------------------------------
# What the DBC says about one signal
# --------------------------------------------------------------------------------------


def node_from_frame_name(frame: str) -> str:
    """VCU11_FD_10 -> VCU, HPCAd_1_10 -> HPCAD, FR_ZONE2_100 -> FR_ZONE (a guess)."""
    base = re.sub(r"_\d+$", "", frame)            # cycle-time suffix
    base = re.sub(r"_FD$", "", base, flags=re.IGNORECASE)
    base = re.sub(r"_?\d+$", "", base)            # frame index
    return base.upper()


def default_raw(signal: Signal) -> tuple[int, str]:
    """The raw the DBC calls the default, and where that came from."""
    named = sorted(raw for raw, label in signal.values.items() if "default" in label.lower())
    if named:
        return named[0], "value table"
    if signal.initial is not None:
        return signal.initial, "GenSigStartValue"
    return 0, "none in the DBC; 0 assumed"


def code_sets(signal: Signal, default: int) -> dict[str, list[int]]:
    """Invalid, reserved and out-of-range raws - the rule of edr_canc_review_model.dbc_codes."""
    named = set(signal.values)
    invalid = sorted(raw for raw, label in signal.values.items() if "invalid" in label.lower())
    reserved = sorted(raw for raw, label in signal.values.items() if "reserved" in label.lower())
    bits = signal.bit_length
    top = (1 << (bits - 1)) - 1 if signal.signed else (1 << bits) - 1
    if signal.maximum is None or not signal.factor or signal.minimum == signal.maximum:
        raw_max = top                             # no physical range: nothing above it
    else:
        raw_max = int(round((signal.maximum - signal.offset) / signal.factor))
    oor = next((raw for raw in range(top, raw_max, -1)
                if raw not in named and raw != default), None)
    return {"Invalid_Values": invalid, "Reserved_Values": reserved,
            "OutofRange_Values": [] if oor is None else [oor]}


def _raw(signal: Signal, physical: float | None) -> int | None:
    """The raw a physical DBC limit encodes (MIN / MAX are physical, as in the DBC)."""
    if physical is None or not signal.factor:
        return None
    return int(round((physical - signal.offset) / signal.factor))


def state_values(signal: Signal) -> dict[str, int]:
    """label -> raw; a label the table repeats gets its raw appended (Reserved_9)."""
    labels = [label for _, label in sorted(signal.values.items())]
    states: dict[str, int] = {}
    for raw, label in sorted(signal.values.items()):
        key = f"{label}_{raw}" if labels.count(label) > 1 else label
        states[key] = raw
    return states


def integrity_role(signal_name: str) -> str | None:
    if SECOC_SIGNAL.search(signal_name):
        return "secoc"
    if CRC_SIGNAL.search(signal_name):
        return "crc"
    if COUNTER_SIGNAL.search(signal_name):
        return "counter"
    return None


# --------------------------------------------------------------------------------------
# Inputs file
# --------------------------------------------------------------------------------------


class Inputs:
    """The project facts a DBC does not carry. Absent names read as empty / None."""

    def __init__(self, path: Path | None):
        self.path = path
        self.module = None
        if path is not None and path.is_file():
            spec = importlib.util.spec_from_file_location("canc_dbc_inputs", path)
            if spec is None or spec.loader is None:
                raise SystemExit(f"Cannot load {path}")
            self.module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.module)

    def get(self, name: str, default: Any = None) -> Any:
        if self.module is None:
            return default
        value = getattr(self.module, name, default)
        return default if value is None else value

    def has(self, name: str) -> bool:
        return self.module is not None and hasattr(self.module, name)


DTC_FORMAT = re.compile(r"^0x[0-9A-F]{2} 0x[0-9A-F]{2} 0x[0-9A-F]{2}$", re.IGNORECASE)


def checked_dtc(value: Any, where: str, warnings: list[str]) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not DTC_FORMAT.match(text):
        warnings.append(f"{where}: DTC {text!r} is not in the '0xD1 0x54 0x00' form")
    return text


# --------------------------------------------------------------------------------------
# Model
# --------------------------------------------------------------------------------------


class Expr(str):
    """Python source emitted as-is inside a pretty-printed value."""

    def __repr__(self) -> str:
        return str(self)


class Hex(int):
    def __repr__(self) -> str:
        return f"0x{int(self):X}"


def _symbol(text: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", text.upper()).strip("_")


@dataclass
class Block:
    symbol: str
    signal: Signal
    frame: Frame
    preferred: bool
    value: dict[str, Any] = field(default_factory=dict)


class Model:
    def __init__(self, project: str, buses: list[Bus], inputs: Inputs, variant: str):
        self.project = project
        self.buses = buses
        self.inputs = inputs
        self.variant = variant
        self.open_items: list[str] = []
        self.warnings: list[str] = []
        present = {bus.bus for bus in buses}
        self.primary = next(bus_type for bus_type in BUS_TYPES if bus_type in present)

        self.frames: dict[str, Frame] = {}
        for bus in buses:
            for frame in bus.frames:
                if frame.name in self.frames:
                    self.warnings.append(f"frame {frame.name} is in more than one DBC; "
                                         f"kept the {self.frames[frame.name].bus} one")
                    continue
                self.frames[frame.name] = frame
        self.ordered = sorted(self.frames.values(),
                              key=lambda f: (f.bus != self.primary, f.frame_id))
        channel_names = inputs.get("BUS_CHANNELS", {})
        ch_numbers = inputs.get("BUS_CH", {})
        bus_types = [bus.bus for bus in buses]
        # The ARIA channel each bus is on: what the bench calls take as "bus".
        self.channel = {b: channel_names.get(b) or common.DEFAULT_ARIA_CHANNEL[b]
                        for b in bus_types}
        self.ch = {b: ch_numbers.get(b, 2 if b == self.primary else 3) for b in bus_types}
        for bus_type, channel in self.channel.items():
            if channel not in common.ARIA_CHANNELS:
                self.warnings.append(f"BUS_CHANNELS[{bus_type!r}] = {channel!r} is not an ARIA "
                                     f"channel name the shared library resolves "
                                     f"{common.ARIA_CHANNELS}")
        if len(set(self.channel.values())) != len(self.channel):
            raise SystemExit(f"two buses on one ARIA channel: {self.channel} - give each its "
                             "own channel in BUS_CHANNELS")

        self._nodes()
        self._dtcs()
        self._blocks()

    # -- nodes and key frames -------------------------------------------------------

    def _nodes(self) -> None:
        overrides = self.inputs.get("NODE_BY_FRAME", {})
        self.frame_node: dict[str, str | None] = {}
        for frame in self.ordered:
            if frame.kind != "restbus" or frame.is_nm:
                self.frame_node[frame.name] = None
            elif frame.name in overrides:
                self.frame_node[frame.name] = overrides[frame.name]
            else:
                self.frame_node[frame.name] = node_from_frame_name(frame.name)
        unknown = sorted(set(overrides) - set(self.frames))
        if unknown:
            self.warnings.append(f"NODE_BY_FRAME names frames not in the DBCs: {unknown}")

        self.frames_by_node: dict[str, list[str]] = {}
        for frame in self.ordered:
            node = self.frame_node[frame.name]
            if node:
                self.frames_by_node.setdefault(node, []).append(frame.name)
        for node in self.frames_by_node:
            self.frames_by_node[node].sort(key=lambda name: self.frames[name].frame_id)
        if not self.inputs.has("NODE_BY_FRAME"):
            self.open_items.append(
                "Node of each restbus frame guessed from its name (no NODE_BY_FRAME in the "
                "inputs): " + ", ".join(f"{f}->{n}" for f, n in self.frame_node.items() if n))

        configured = self.inputs.get("KEY_FRAMES", {})
        self.key_frame: dict[str, str] = {}
        assumed = []
        for node, frames in self.frames_by_node.items():
            chosen = configured.get(node)
            if chosen and chosen not in frames:
                self.warnings.append(f"KEY_FRAMES[{node!r}] = {chosen!r} is not a frame of "
                                     f"{node} {frames}; using the lowest CAN ID instead")
                chosen = None
            if not chosen:
                chosen = frames[0]
                assumed.append(f"{node}->{chosen}")
            self.key_frame[node] = chosen
        if assumed:
            self.open_items.append(
                "Key frame assumed to be the lowest CAN ID the node sends (confirm against "
                "the Node Absent DTC set conditions; add to KEY_FRAMES): " + ", ".join(assumed))

    # -- DTCs ----------------------------------------------------------------------

    def _dtcs(self) -> None:
        warn = self.warnings
        node_absent = self.inputs.get("NODE_ABSENT_DTC", {})
        timeout = self.inputs.get("MESSAGE_TIMEOUT_DTC", {})
        content = self.inputs.get("MESSAGE_CONTENT_FAILURE_DTC", {})
        signal_content = self.inputs.get("SIGNAL_CONTENT_FAILURE_DTC", {})

        self.node_absent_dtc = {node: checked_dtc(node_absent.get(node), f"NODE_ABSENT_DTC[{node}]", warn)
                                for node in self.frames_by_node}
        missing = [node for node, dtc in self.node_absent_dtc.items() if dtc is None]
        if missing:
            self.open_items.append("No node absent DTC for: " + ", ".join(missing))

        # A message timeout case needs a frame besides the key frame, so only such nodes
        # are asked for a DTC; a node the inputs give one for anyway keeps it.
        self.timeout_nodes = [node for node, frames in self.frames_by_node.items()
                              if any(frame != self.key_frame[node] for frame in frames)]
        nodes = self.timeout_nodes + [node for node in self.frames_by_node
                                      if node in timeout and node not in self.timeout_nodes]
        self.message_timeout_dtc = {node: checked_dtc(timeout.get(node), f"MESSAGE_TIMEOUT_DTC[{node}]", warn)
                                    for node in nodes}
        missing = [node for node in self.timeout_nodes if self.message_timeout_dtc[node] is None]
        if missing:
            self.open_items.append("No message timeout DTC for (node sends non-key frames): "
                                   + ", ".join(missing))

        # Integrity signals per frame, and the DTC each one raises.
        self.integrity: dict[str, dict[str, list[str]]] = {}
        self.content_dtc: dict[str, str] = {}
        uncovered = []
        for frame in self.ordered:
            roles: dict[str, list[str]] = {"crc": [], "counter": [], "secoc": []}
            for signal in frame.signals:
                role = integrity_role(signal.name)
                if role:
                    roles[role].append(signal.name)
            self.integrity[frame.name] = roles
            if frame.kind != "restbus":
                continue
            for name in roles["crc"] + roles["counter"]:
                dtc = (content.get(f"{frame.name}.{name}") or content.get(name)
                       or content.get(frame.name))
                dtc = checked_dtc(dtc, f"MESSAGE_CONTENT_FAILURE_DTC[{name}]", warn)
                if dtc:
                    self.content_dtc[name] = dtc
            if (roles["crc"] or roles["counter"]) and not any(
                    name in self.content_dtc for name in roles["crc"] + roles["counter"]):
                uncovered.append(frame.name)
        if uncovered:
            self.open_items.append(
                "Frames with a CRC / alive counter but no message content failure DTC (add "
                "one if the SRS monitors it, else the frame has no MCF case): " + ", ".join(uncovered))

        self.signal_content_dtc: dict[str, str] = {}
        for key, value in signal_content.items():
            dtc = checked_dtc(value, f"SIGNAL_CONTENT_FAILURE_DTC[{key}]", warn)
            if dtc:
                self.signal_content_dtc[key] = dtc

    # -- signal blocks --------------------------------------------------------------

    def _blocks(self) -> None:
        candidates: dict[str, list[tuple[Frame, Signal]]] = {}
        for frame in self.ordered:
            if frame.kind == "diag" or frame.is_nm:
                continue
            for signal in frame.ecu_signals:
                candidates.setdefault(signal.name, []).append((frame, signal))

        preferred_frames = self.inputs.get("PREFERRED_FRAME", {})
        chosen_by_rule = []

        def rank(item: tuple[Frame, Signal]) -> tuple:
            frame = item[0]
            return (frame.kind != "restbus", frame.bus != self.primary,
                    frame.cycle_ms == 0, frame.cycle_ms, frame.frame_id)

        self.blocks: list[Block] = []
        used: set[str] = set()
        for name, items in candidates.items():
            items = sorted(items, key=rank)
            wanted = preferred_frames.get(name)
            if wanted and any(frame.name == wanted for frame, _ in items):
                items.sort(key=lambda item: item[0].name != wanted)
            elif len(items) > 1:
                chosen_by_rule.append(f"{name}->{items[0][0].name} (also on "
                                      + ", ".join(frame.name for frame, _ in items[1:]) + ")")
            for index, (frame, signal) in enumerate(items):
                symbol = "CAN_" + _symbol(name)
                if index or symbol in used:
                    symbol = f"CAN_{_symbol(name)}__{_symbol(frame.name)}"
                used.add(symbol)
                self.blocks.append(Block(symbol, signal, frame, preferred=index == 0))
        if chosen_by_rule:
            self.open_items.append(
                "Signal on several frames; its plain name points at the restbus, primary-bus, "
                "fastest frame (set PREFERRED_FRAME to change): " + "; ".join(chosen_by_rule))

        edr = self.inputs.get("EDR_PARAMETERS", {})
        for block in self.blocks:
            block.value = self._block_value(block, edr)

    def _block_value(self, block: Block, edr: dict[str, str]) -> dict[str, Any]:
        frame, signal = block.frame, block.signal
        default, source = default_raw(signal)
        value: dict[str, Any] = {
            "frame": frame.name, "signal": signal.name, "frame_ID": Hex(frame.frame_id),
            "bus": self.channel[frame.bus], "is_fd": frame.is_fd,
            "ch": self.ch[frame.bus], "periodicity": frame.cycle_ms,
            "direction": "rx" if frame.kind == "restbus" else "tx",
            "bit_length": signal.bit_length, "Signed": signal.signed,
            "Factor": signal.factor, "Offset": signal.offset, "UNIT": signal.unit,
            "MIN": signal.minimum, "MID": None, "MAX": signal.maximum,
            "RAW_MIN": _raw(signal, signal.minimum), "RAW_MAX": _raw(signal, signal.maximum),
            "Default_Value": default, "Default_Source": source,
            "State_Values": state_values(signal),
        }
        value.update(code_sets(signal, default))
        qualified = f"{frame.name}.{signal.name}"
        value["EDR_Parameter"] = edr.get(qualified) or (edr.get(signal.name) if block.preferred else None)

        node = self.frame_node.get(frame.name)
        if frame.kind != "restbus" or not node:
            value["fault_logic"] = {
                "key_message": None, "non_key_timeout_frame": None, "fault_type": None,
                "node_absent_dtc": None, "message_timeout_dtc": None,
                "signal_content_failure_dtc": None, "message_content_failure_dtcs": {},
            }
            return value
        key = self.key_frame[node]
        timeout_frame = None if frame.name == key else frame.name
        scf = qualified if qualified in self.signal_content_dtc else (
            signal.name if signal.name in self.signal_content_dtc else None)
        value["fault_logic"] = {
            "key_message": key,
            "non_key_timeout_frame": timeout_frame,
            "fault_type": "message_timeout" if timeout_frame else "node_absent",
            "node_absent_dtc": Expr(f'CAN_NODE_ABSENT_DTC.get("{node}")'),
            "message_timeout_dtc": Expr(f'CAN_MESSAGE_TIMEOUT_DTC.get("{node}")') if timeout_frame else None,
            "signal_content_failure_dtc": Expr(f'CAN_SIGNAL_CONTENT_FAILURE_DTC.get("{scf}")') if scf else None,
            "message_content_failure_dtcs": self._frame_content_dtcs(frame),
        }
        return value

    def _frame_content_dtcs(self, frame: Frame) -> dict[str, Expr]:
        roles = self.integrity[frame.name]
        return {name: Expr(f'CAN_MESSAGE_CONTENT_FAILURE_DTC.get("{name}")')
                for name in roles["crc"] + roles["counter"] if name in self.content_dtc}

    # -- crash outputs and wakeup ---------------------------------------------------

    def crash_output_frames(self) -> dict[str, str]:
        """SRS frame read at crash time per bus: CRASH_OUTPUT_FRAMES, else its fastest
        cyclic frame (SRS1_FD_10 / SRS1_20 on M314, SRS1_20 on U171)."""
        if hasattr(self, "_crash_frames"):
            return self._crash_frames
        configured = self.inputs.get("CRASH_OUTPUT_FRAMES")
        frames: dict[str, str] = {}
        if configured is not None:
            for name in configured:
                if name in self.frames and self.frames[name].kind == "ecu_tx":
                    frames[name] = self.frames[name].bus
                else:
                    self.warnings.append(f"CRASH_OUTPUT_FRAMES names {name!r}, not an SRS frame")
        else:
            fastest: dict[str, Frame] = {}
            for frame in self.ordered:
                if frame.kind != "ecu_tx" or frame.is_nm or not frame.cycle_ms:
                    continue
                best = fastest.get(frame.bus)
                if best is None or (frame.cycle_ms, frame.frame_id) < (best.cycle_ms, best.frame_id):
                    fastest[frame.bus] = frame
            frames = {frame.name: bus for bus, frame in fastest.items()}
        self._crash_frames = frames
        return frames

    def crash_maps(self) -> tuple[dict[str, tuple[str, str]], dict[str, tuple[str, str]], dict[str, str]]:
        """Signals the SRS transmits, read at crash time: per bus key -> (frame, signal)."""
        maps: dict[str, dict[str, tuple[str, str]]] = {}
        channels: dict[str, str] = {}
        outputs = self.crash_output_frames()
        for frame in self.ordered:
            if frame.name not in outputs:
                continue
            bus_map = maps.setdefault(frame.bus, {})
            channels[frame.name] = self.channel[frame.bus]
            for signal in frame.signals:
                key = signal.name if signal.name not in bus_map else f"{frame.name}_{signal.name}"
                bus_map[key] = (frame.name, signal.name)
        primary = maps.get(self.primary, {})
        # CAN_HSCAN_SIGNAL_Rx_MAP (the shared library's name) holds the second bus's
        # outputs: HS-CAN beside CAN-FD, or a normal-CAN bus beside either.
        others = [bus_type for bus_type in BUS_TYPES if bus_type != self.primary and bus_type in maps]
        secondary = maps.get(others[0], {}) if others else {}
        return primary, secondary, channels

    def lamp_values(self) -> dict[str, dict[str, str]]:
        """Signal_Value_<ID>: the warning-lamp ON / OFF raws, per SRS output frame."""
        result = {}
        for frame in self.ordered:
            if frame.kind != "ecu_tx" or frame.is_nm:
                continue
            for signal in frame.signals:
                on = [raw for raw, label in signal.values.items() if re.search(r"LAMP.?ON", label, re.I)]
                off = [raw for raw, label in signal.values.items() if re.search(r"LAMP.?OFF", label, re.I)]
                if on and off:
                    result[f"Signal_Value_{frame.frame_id:X}"] = {"ON": f"0x{on[0]:02X}", "OFF": f"0x{off[0]:02X}"}
                    break
        return result

    def derived_wakeup(self) -> dict[str, Any]:
        """CAN wakeup and NM wakeup settings the DBC value tables identify."""
        derived: dict[str, Any] = {name: None for name in WAKEUP_NAMES}
        for frame in self.ordered:
            if frame.kind == "ecu_tx" and not frame.is_nm and derived["CAN_WAKEUP_STATUS_FRAME"] is None:
                for signal in frame.signals:
                    raw = next((raw for raw, label in signal.values.items()
                                if re.search(r"CAN.?WAKE", label, re.I)), None)
                    if raw is not None:
                        derived.update(CAN_WAKEUP_STATUS_FRAME=frame.name,
                                       CAN_WAKEUP_STATUS_SIGNAL=signal.name,
                                       CAN_WAKEUP_STATUS_VALUE=raw)
                        break
            if frame.is_nm and frame.kind == "restbus" and derived["CAN_NM_WAKEUP_FRAME"] is None:
                for signal in frame.signals:
                    raw = next((raw for raw, label in signal.values.items()
                                if label.strip().lower() == "active"), None)
                    if "WAKEUP" in signal.name.upper() and raw is not None:
                        derived.update(CAN_NM_WAKEUP_FRAME=frame.name,
                                       CAN_NM_WAKEUP_SIGNAL=signal.name, CAN_NM_WAKEUP_VALUE=raw)
                        break
            if frame.is_nm and frame.kind == "ecu_tx" and derived["CAN_NM_SRS_FRAME"] is None:
                derived["CAN_NM_SRS_FRAME"] = frame.name
        return derived

    def derived_crash_expectations(self) -> dict[str, dict[str, str]]:
        """Candidate crash-output values from value-table labels - to confirm, never final."""
        primary, secondary, _ = self.crash_maps()
        signals = {}
        for mapping in (secondary, primary):        # primary last, so it wins
            for key, (frame, name) in mapping.items():
                signal = next(s for s in self.frames[frame].signals if s.name == name)
                signals[key] = signal

        def pick(key: str, pattern: str) -> str | None:
            signal = signals.get(key)
            if signal is None:
                return None
            raw = next((raw for raw, label in sorted(signal.values.items())
                        if re.search(pattern, label, re.I) and "default" not in label.lower()), None)
            return None if raw is None else f"0x{raw:X}"

        result: dict[str, dict[str, str]] = {}
        for crash in CRASH_TYPES:
            entry: dict[str, str | None] = {}
            if crash == "near":
                for key in ("STS_CRASH", "INDC_SRS", "CRASH_LOCATION", "DOOR_UNLOCK"):
                    if key in signals:
                        entry[key] = f"0x{default_raw(signals[key])[0]:X}"
            else:
                entry["STS_CRASH"] = pick("STS_CRASH", r"CRASH")
                entry["INDC_SRS"] = pick("INDC_SRS", r"LAMP.?ON")
                entry["CRASH_LOCATION"] = pick("CRASH_LOCATION", rf"^{crash}")
                entry["DOOR_UNLOCK"] = pick("DOOR_UNLOCK", r"UNLOCK")
            result[crash] = {key: value for key, value in entry.items() if value is not None}
        return result


# --------------------------------------------------------------------------------------
# Writing canc_config.py
# --------------------------------------------------------------------------------------

HELPERS = '''

def is_key_message(frame_name: str) -> bool:
    """True when stopping this frame raises Node Absent rather than Message Timeout."""
    return bool(KEY_TX_FRAMES.get(frame_name, False))


def get_message_timeout_dtc(frame_name: str) -> str | None:
    return (CAN_TX_MESSAGE_CONFIG.get(frame_name) or {}).get("message_timeout_dtc")


def get_node_absent_dtc(frame_name: str) -> str | None:
    return (CAN_TX_MESSAGE_CONFIG.get(frame_name) or {}).get("node_absent_dtc")


def get_signal_content_failure_dtc(signal_name: str) -> str | None:
    """Return the signal-content failure DTC based on signal name."""
    return CAN_SIGNAL_CONTENT_FAILURE_DTC.get(signal_name)


def get_message_content_failure_dtcs(frame_name: str) -> dict:
    """Return the message-content failure DTCs defined for a frame."""
    return (CAN_TX_MESSAGE_CONFIG.get(frame_name) or {}).get("message_content_failure_dtcs", {}) or {}


def get_message_content_failure_signals(frame_name: str) -> list:
    """Return message-content-failure signal names for a frame."""
    return list(get_message_content_failure_dtcs(frame_name))


def choose_message_content_failure_signal(frame_name: str) -> str | None:
    """Select message counter first, CRC second, then the first available signal."""
    signals = get_message_content_failure_signals(frame_name)
    if not signals:
        return None
    upper = [signal.upper() for signal in signals]
    for index, signal_name in enumerate(upper):
        if "MSG_CNT" in signal_name:
            return signals[index]
    for index, signal_name in enumerate(upper):
        if "CRC" in signal_name:
            return signals[index]
    return signals[0]


def get_frame_message_content_failure_dtc(frame_name: str) -> tuple[str | None, str | None]:
    """Return the selected message-content DTC and its signal name."""
    dtc_map = get_message_content_failure_dtcs(frame_name)
    signal_name = choose_message_content_failure_signal(frame_name)
    if not signal_name:
        return None, None
    return dtc_map.get(signal_name), signal_name


def resolve_dtc_for_event(event_type: str, frame_name: str | None, signal_name: str | None = None):
    """Resolve the DTC mapped to the requested CANC fault event."""
    if event_type == "message_timeout":
        return get_message_timeout_dtc(frame_name) if frame_name else None
    if event_type == "node_absent":
        return get_node_absent_dtc(frame_name) if frame_name else None
    if event_type == "frame_disabled":
        if not frame_name:
            return None
        return get_node_absent_dtc(frame_name) if is_key_message(frame_name) else get_message_timeout_dtc(frame_name)
    if event_type == "signal_invalid" and signal_name:
        return get_signal_content_failure_dtc(signal_name)
    if event_type == "message_content_failure":
        return get_message_content_failure_dtcs(frame_name) if frame_name else None
    return None


def timeout_frame_for(signal_name: str) -> str | None:
    """Frame to stop for a message-timeout test, or None when no such case exists."""
    definition = MAH_CAN_SIGNAL_DEFS.get(signal_name)
    return None if definition is None else definition["fault_logic"].get("non_key_timeout_frame")


def key_frame_for(signal_name: str) -> str | None:
    """Frame to stop for a node-absent test."""
    definition = MAH_CAN_SIGNAL_DEFS.get(signal_name)
    return None if definition is None else definition["fault_logic"].get("key_message")
'''

QUALIFICATION = '''
# Detection / recovery threshold per CAN fault family.
FAULT_THRESHOLDS = {
    "node_absent": (NODE_ABSENT_DETECTION_COUNT, NODE_ABSENT_RECOVERY_COUNT),
    "message_timeout": (MESSAGE_TIMEOUT_DETECTION_COUNT, MESSAGE_TIMEOUT_RECOVERY_COUNT),
    "message_content": (MESSAGE_CONTENT_DETECTION_COUNT, MESSAGE_CONTENT_RECOVERY_COUNT),
    "signal_content": (SIGNAL_CONTENT_DETECTION_COUNT, SIGNAL_CONTENT_RECOVERY_COUNT),
}

# Variant-code faults are evaluated at startup, so they need an ignition cycle
# rather than a count of message periods.
IGNITION_CYCLE_QUALIFIED_FAULTS = ("variant_code_error", "signal_never_received")


def qualification_ms(fault_mode: str, frame_cycle_time_ms: int) -> int | None:
    """Time a fault must persist before its DTC matures, for this cycle time.

    None for faults that qualify on an ignition cycle, for anything without a threshold
    of its own, and while the project's count is not configured yet (CANC_DBC_OPEN_ITEMS).
    """
    thresholds = FAULT_THRESHOLDS.get(fault_mode)
    if thresholds is None or thresholds[0] is None or not frame_cycle_time_ms:
        return None
    return thresholds[0] * int(frame_cycle_time_ms)


def recovery_ms(fault_mode: str, frame_cycle_time_ms: int) -> int | None:
    """Time a healed fault must stay healed before its DTC dematures."""
    thresholds = FAULT_THRESHOLDS.get(fault_mode)
    if thresholds is None or thresholds[1] is None or not frame_cycle_time_ms:
        return None
    return thresholds[1] * int(frame_cycle_time_ms)
'''


def _fmt(value: Any, width: int = 100) -> str:
    return pprint.pformat(value, width=width, sort_dicts=False)


def _dbc_line(bus: Bus) -> str:
    digest = hashlib.sha256(bus.path.read_bytes()).hexdigest()[:12]
    try:
        shown = bus.path.resolve().relative_to(REPOSITORY_ROOT).as_posix()
    except ValueError:
        shown = bus.path.name
    return f"    {bus.bus:<6} {shown}  (SRS node {bus.ecu_node}, sha256 {digest})"


def late_open_items(model: Model) -> None:
    """Open items found while resolving crash outputs, EDR names, NM and wakeup settings."""
    inputs = model.inputs
    if inputs.get("CRASH_EXPECTED_VALUES") is None:
        model.open_items.append("No CRASH_EXPECTED_VALUES: crash-output signals are read but "
                                "not checked (--init-inputs proposes values from the DBC labels)")
    # EDR parameter names are common to every project (U171's): an element's specification
    # name is not used where the common name differs.
    for signal, name in sorted((inputs.get("EDR_PARAMETERS", {}) or {}).items()):
        common_name = edr_names.COMMON_ELEMENT_NAMES.get(name)
        if common_name and common_name != name:
            model.open_items.append(f"EDR_PARAMETERS[{signal!r}] = {name!r} is the specification "
                                    f"name; use the common name {common_name!r}")
    nm = inputs.get("NETWORK_MANAGEMENT", {})
    missing = [name for name in NETWORK_MANAGEMENT_NAMES if nm.get(name) is None]
    if missing:
        model.open_items.append("Network-management values not configured (diag spec, "
                                "NetworkMgmtIdentifiers): " + ", ".join(missing))
    configured = inputs.get("CAN_WAKEUP", {})
    wakeup = model.derived_wakeup()
    if configured.get("CAN_WAKEUP_BUS_SLEEP_WAIT_MS") is None:
        model.open_items.append("CAN_WAKEUP_BUS_SLEEP_WAIT_MS not configured (the shared CAN_Wakeup "
                                "falls back to 10000 ms)")
    for name in ("CAN_WAKEUP_STATUS_SIGNAL", "CAN_NM_WAKEUP_SIGNAL", "CAN_NM_SRS_FRAME"):
        if configured.get(name, wakeup.get(name)) is None:
            model.open_items.append(f"{name}: none found in the DBCs")
    model.crash_output_frames()                 # resolves CRASH_OUTPUT_FRAMES, may warn
    model.open_items.extend("Inputs check: " + warning for warning in model.warnings)


def _render_signal(symbol: str, value: dict[str, Any]) -> str:
    """One signal definition: keys in the common order, grouped, aligned, one per line."""
    placed: list[tuple[str, list[str]]] = []
    for title, keys in common.SIGNAL_KEY_GROUPS:
        present = [key for key in keys if key in value]
        if present:
            placed.append((title, present))
    known = {key for _, keys in placed for key in keys}
    rest = [key for key in value if key not in known]
    if rest:
        placed.append(("other", rest))
    width = max(len(repr(key)) for key in value) + 1
    lines = [f"{symbol} = {{"]
    for title, keys in placed:
        lines.append(f"    # {title}")
        for key in keys:
            prefix = f"    {(repr(key) + ':').ljust(width)} "
            body = _fmt(value[key], width=100 - len(prefix)).split("\n")
            lines.append(prefix + body[0])
            lines.extend(" " * len(prefix) + row for row in body[1:])
            lines[-1] += ","
    lines.append("}")
    return "\n".join(lines) + "\n\n"


def render_signal_blocks(model: Model) -> list[str]:
    """Every signal block, under a banner per bus and a heading per frame."""
    out: list[str] = []
    by_frame: dict[str, list[Block]] = {}
    for block in model.blocks:
        by_frame.setdefault(block.frame.name, []).append(block)
    for bus in model.buses:
        frames = [frame for frame in model.ordered if frame.bus == bus.bus and frame.name in by_frame]
        if not frames:
            continue
        channel = model.channel[bus.bus]
        out.append("# " + "=" * 86 + "\n")
        out.append(f"# {channel} bus - {common.BUS_TYPE_LABELS[bus.bus]} ({bus.path.name}), "
                   f"{len(frames)} frames\n")
        out.append("# " + "=" * 86 + "\n\n")
        for frame in frames:
            node = model.frame_node.get(frame.name)
            role = ("SRS output" if frame.kind == "ecu_tx"
                    else f"node {node}" + (", key frame" if node and model.key_frame.get(node) == frame.name else "")
                    if node else "no node")
            heading = (f"# -- {frame.name}   0x{frame.frame_id:X}   "
                       f"{frame.cycle_ms or 'event'}{' ms' if frame.cycle_ms else ''}   {role} ")
            out.append(heading + "-" * max(4, 88 - len(heading)) + "\n\n")
            for block in by_frame[frame.name]:
                out.append(_render_signal(block.symbol, block.value))
    return out


def render_config(model: Model, command: str) -> str:
    inputs = model.inputs
    late_open_items(model)
    out: list[str] = []
    add = out.append
    inputs_shown = "none" if inputs.module is None else _relative(inputs.path)

    add('"""\nModule Configuration: CANC\n')
    add(f"Project: {model.project}\n")
    add("============================================================\n\n")
    add(f"Location: projects/{model.project}/config/canc_config.py\n\n")
    add("Built from the inputs file below. Change the inputs (tools/canc_config_gui.py\n"
        "opens them in a window) and rebuild with:\n")
    add(f"    {command}\n\n")
    add("CAN databases:\n")
    for bus in model.buses:
        add(_dbc_line(bus) + "\n")
    add(f"Inputs: {inputs_shown}\n\n")
    add("Everything about frames and signals comes from the DBCs. DTCs, key frames, the node\n"
        "of each frame, EDR parameter names, crash-output expectations and the network-\n"
        "management counts come from the inputs file. Whatever is still unknown is None\n"
        f"here and listed in CANC_DBC_OPEN_ITEMS at the end ({len(model.open_items)} items).\n"
        '"""\n\n')

    add(f'PROJECT_NAME = "{model.project}"\nMODULE_NAME = "CANC"\n')
    add(f'# Key of CAN_SIGNAL_Rx_MAP; must equal project_config.ACTIVE_CAN_VARIANT.\n')
    add(f'CAN_VARIANT = "{model.variant}"\n\n')

    # Crash outputs -------------------------------------------------------------
    primary, secondary, channels = model.crash_maps()
    add(f"# Signals the SRS transmits, read at crash time ({model.primary}).\n")
    add("CAN_SIGNAL_Rx_MAP = " + _fmt({model.variant: primary}) + "\n\n")
    add("# Signals the SRS transmits on HS-CAN when the project also has a CAN-FD bus.\n")
    add("CAN_HSCAN_SIGNAL_Rx_MAP = " + _fmt(secondary) + "\n\n")
    add("CAN_CRASH_FRAME_CHANNEL_MAP = " + _fmt({model.variant: channels}) + "\n\n")
    lamps = model.lamp_values()
    if lamps:
        add("# Warning-lamp ON / OFF raws per SRS output frame, from the DBC value table.\n")
        for name, value in lamps.items():
            add(f"{name} = {_fmt(value)}\n")
        add("\n")
    expected = inputs.get("CRASH_EXPECTED_VALUES", {})
    add("# Expected crash-output values per crash type (from the inputs file).\n")
    add("CAN_SIGNAL_Rx_EXPECTED_VALUES = " + _fmt(expected) + "\n\n")

    # DTCs -----------------------------------------------------------------------
    add("# DTC codes (from the inputs file; None = not known yet).\n")
    add("CAN_NODE_ABSENT_DTC = " + _fmt(model.node_absent_dtc) + "\n\n")
    add("CAN_MESSAGE_TIMEOUT_DTC = " + _fmt(model.message_timeout_dtc) + "\n\n")
    add("# Message content failure DTC per CRC / alive-counter signal.\n")
    add("CAN_MESSAGE_CONTENT_FAILURE_DTC = " + _fmt(model.content_dtc) + "\n\n")
    add("CAN_SIGNAL_CONTENT_FAILURE_DTC = " + _fmt(model.signal_content_dtc) + "\n\n")

    # Nodes and frames ---------------------------------------------------------------
    add("# Frames each node sends, lowest CAN ID first.\n")
    add("FRAMES_BY_NODE = " + _fmt(model.frames_by_node) + "\n\n")
    add("# Key frame per node: stopping it raises Node Absent.\n")
    add("NODE_KEY_FRAMES = " + _fmt(model.key_frame) + "\n\n")
    add("KEY_TX_FRAMES = " + _fmt({frame: True for frame in model.key_frame.values()}) + "\n\n")

    tx_config: dict[str, Any] = {}
    rx_config: dict[str, Any] = {}
    for frame in model.ordered:
        node = model.frame_node.get(frame.name)
        roles = model.integrity[frame.name]
        # The node's timeout DTC on every one of its frames, key frame included, as in the
        # hand-made configs; whether a timeout case exists is the signal's fault_logic.
        timeout = node in model.message_timeout_dtc
        scf = {}
        for signal in frame.signals:
            for key in (f"{frame.name}.{signal.name}", signal.name):
                if key in model.signal_content_dtc:
                    scf[signal.name] = Expr(f'CAN_SIGNAL_CONTENT_FAILURE_DTC.get("{key}")')
                    break
        tx_config[frame.name] = {
            "signals": [signal.name for signal in frame.signals],
            "frame_ID": Hex(frame.frame_id), "bus": model.channel[frame.bus],
            "periodicity": frame.cycle_ms,
            "kind": "nm" if frame.is_nm else frame.kind,
            "key_node": node,
            "is_key_frame": bool(node) and model.key_frame.get(node) == frame.name,
            "node_absent_dtc": Expr(f'CAN_NODE_ABSENT_DTC.get("{node}")') if node else None,
            "message_timeout_dtc": Expr(f'CAN_MESSAGE_TIMEOUT_DTC.get("{node}")') if timeout else None,
            "signal_content_failure_dtcs": scf if node else {},
            "message_content_failure_dtcs": model._frame_content_dtcs(frame) if node else {},
            "integrity_signals": roles["crc"] + roles["counter"],
            "secoc_signals": roles["secoc"],
        }
        if frame.kind == "ecu_tx":
            bus = next(b for b in model.buses if b.bus == frame.bus)
            rx_config[frame.name] = {
                "signals": [signal.name for signal in frame.signals],
                "frame_ID": Hex(frame.frame_id), "dlc": frame.dlc,
                "periodicity": frame.cycle_ms, "sender": bus.ecu_node,
                "bus": model.channel[frame.bus],
            }
    add("# Every frame on the bus(es), with its node, key-frame flag and fault DTCs.\n")
    add("CAN_TX_MESSAGE_CONFIG = " + _fmt(tx_config) + "\n\n")
    add("# Frames the SRS transmits.\n")
    add("CAN_RX_MESSAGE_CONFIG = " + _fmt(rx_config) + "\n\n")

    # Signal blocks ----------------------------------------------------------------
    add("# " + "-" * 30 + " Signal definitions " + "-" * 30 + "\n#\n")
    add("# Invalid_Values / Reserved_Values / OutofRange_Values are DBC facts. The EDR CAN-C\n"
        "# series arrays (TestCase_<n>_..., in each signal's own dict) are added by the EDR\n"
        "# tooling, not here.\n"
        "#\n"
        "# Grouped by bus, then frame; every signal lists its keys in the same order and\n"
        "# groups (where it is / encoding / scaling and range / values / EDR and fault\n"
        "# handling), so any two read alike.\n\n")
    out.extend(render_signal_blocks(model))

    add("# Signal name -> definition. A signal on several frames: its plain name points at the\n"
        "# preferred frame, and every block is also reachable as \"FRAME.SIGNAL\".\n")
    entries: dict[str, str] = {}
    for block in model.blocks:
        if block.preferred:
            entries[block.signal.name] = block.symbol
    for block in model.blocks:
        entries[f"{block.frame.name}.{block.signal.name}"] = block.symbol
    add("MAH_CAN_SIGNAL_DEFS = {\n")
    for key, symbol in entries.items():
        add(f'    "{key}": {symbol},\n')
    add("}\n")
    add(HELPERS)

    # Network management -------------------------------------------------------------
    nm = inputs.get("NETWORK_MANAGEMENT", {})
    add("\n\n# -- Network management (from the inputs file) " + "-" * 34 + "\n#\n")
    add("# A CAN fault's DTC matures on a count of message periods, not a fixed delay:\n"
        "#     qualification_ms = detection_count x frame_cycle_time_ms\n\n")
    for name in NETWORK_MANAGEMENT_NAMES:
        add(f"{name} = {nm.get(name)!r}\n")

    wakeup = model.derived_wakeup()
    configured = inputs.get("CAN_WAKEUP", {})
    add("\n# -- CAN wakeup and CAN NM wakeup (shared CAN_Wakeup / CAN_Wakeup_Restore) --\n")
    add("# Legacy: wake_ecu_over_can / wake_ecu_over_can_nm read the same settings.\n")
    add("# Status and NM signals from the DBC value tables unless the inputs file names them.\n")
    for name in WAKEUP_NAMES:
        value = configured.get(name, wakeup.get(name))
        add(f"{name} = {value!r}\n")
    add(QUALIFICATION)

    # Open items and exports ---------------------------------------------------------
    add("\n# What this config does not know yet. Rebuild after filling the inputs file.\n")
    add("CANC_DBC_OPEN_ITEMS = " + _fmt(model.open_items, width=110) + "\n\n")

    exported = (
        ["PROJECT_NAME", "MODULE_NAME", "CAN_VARIANT",
         "CAN_SIGNAL_Rx_MAP", "CAN_HSCAN_SIGNAL_Rx_MAP", "CAN_CRASH_FRAME_CHANNEL_MAP"]
        + list(lamps)
        + ["CAN_SIGNAL_Rx_EXPECTED_VALUES", "CAN_NODE_ABSENT_DTC", "CAN_MESSAGE_TIMEOUT_DTC",
           "CAN_MESSAGE_CONTENT_FAILURE_DTC", "CAN_SIGNAL_CONTENT_FAILURE_DTC",
           "FRAMES_BY_NODE", "NODE_KEY_FRAMES", "KEY_TX_FRAMES",
           "CAN_TX_MESSAGE_CONFIG", "CAN_RX_MESSAGE_CONFIG"]
        + [block.symbol for block in model.blocks]
        + ["MAH_CAN_SIGNAL_DEFS", "is_key_message", "get_message_timeout_dtc",
           "get_node_absent_dtc", "get_signal_content_failure_dtc",
           "get_message_content_failure_dtcs", "get_message_content_failure_signals",
           "choose_message_content_failure_signal", "get_frame_message_content_failure_dtc",
           "resolve_dtc_for_event", "timeout_frame_for", "key_frame_for"]
        + list(NETWORK_MANAGEMENT_NAMES) + list(WAKEUP_NAMES)
        + ["FAULT_THRESHOLDS", "IGNITION_CYCLE_QUALIFIED_FAULTS", "qualification_ms",
           "recovery_ms", "CANC_DBC_OPEN_ITEMS"]
    )
    add("__all__ = " + _fmt(exported) + "\n")
    return "".join(out)


# --------------------------------------------------------------------------------------
# Writing the starter inputs file
# --------------------------------------------------------------------------------------


def derived_inputs(model: Model) -> dict[str, Any]:
    """Every inputs-file value as the DBCs suggest it: guesses filled in, unknowns None."""
    restbus = [frame for frame in model.ordered if frame.kind == "restbus" and not frame.is_nm]
    uncovered_content = {frame.name: None for frame in restbus
                         if model.integrity[frame.name]["crc"] or model.integrity[frame.name]["counter"]}
    scf_candidates = {}
    for block in model.blocks:
        if block.value["direction"] == "rx" and block.value["Invalid_Values"]:
            key = block.signal.name if block.preferred else f"{block.frame.name}.{block.signal.name}"
            scf_candidates[key] = None
    duplicates = {}
    for block in model.blocks:
        if block.preferred and sum(b.signal.name == block.signal.name for b in model.blocks) > 1:
            duplicates[block.signal.name] = block.frame.name
    return {
        "CAN_VARIANT": model.variant,
        "DBC_FILES": {bus.bus: _relative(bus.path) for bus in model.buses},
        "SRS_NODES": {bus.bus: bus.ecu_node for bus in model.buses},
        "BUS_CHANNELS": dict(model.channel),
        "BUS_CH": dict(model.ch),
        "NODE_BY_FRAME": {f.name: model.frame_node[f.name] for f in restbus},
        "KEY_FRAMES": dict(model.key_frame),
        "NODE_ABSENT_DTC": {node: None for node in model.frames_by_node},
        "MESSAGE_TIMEOUT_DTC": {node: None for node in model.timeout_nodes},
        "MESSAGE_CONTENT_FAILURE_DTC": uncovered_content,
        "SIGNAL_CONTENT_FAILURE_DTC": scf_candidates,
        "EDR_PARAMETERS": {},
        "PREFERRED_FRAME": duplicates,
        "CRASH_OUTPUT_FRAMES": list(model.crash_output_frames()),
        "CRASH_EXPECTED_VALUES": model.derived_crash_expectations(),
        "NETWORK_MANAGEMENT": {name: None for name in NETWORK_MANAGEMENT_NAMES},
        "CAN_WAKEUP": model.derived_wakeup(),
    }


INPUT_NAMES = ("CAN_VARIANT", "DBC_FILES", "SRS_NODES", "BUS_CHANNELS", "BUS_CH", "NODE_BY_FRAME", "KEY_FRAMES",
               "NODE_ABSENT_DTC", "MESSAGE_TIMEOUT_DTC", "MESSAGE_CONTENT_FAILURE_DTC",
               "SIGNAL_CONTENT_FAILURE_DTC", "EDR_PARAMETERS",
               "PREFERRED_FRAME", "CRASH_OUTPUT_FRAMES", "CRASH_EXPECTED_VALUES",
               "NETWORK_MANAGEMENT", "CAN_WAKEUP")


def render_inputs(model: Model, command: str, values: dict[str, Any] | None = None,
                  origin: str | None = None) -> str:
    """The inputs file: DBC-derived guesses, overridden by `values` where given."""
    v = derived_inputs(model)
    v.update({name: value for name, value in (values or {}).items() if name in INPUT_NAMES})
    written_by = origin or f"Starter written by:\n    {command} --init-inputs"
    rebuild = ("Change it in tools/canc_config_gui.py (or by hand), then rebuild canc_config.py\n"
               f"there or with:\n    {command}\n" if origin else
               "Edit by hand, then rebuild canc_config.py (same command without --init-inputs).\n")
    sections = [
        f'"""CAN-C generator inputs for {model.project}: the facts a DBC does not carry.\n\n'
        f"{written_by}\n\n"
        + rebuild +
        "Values marked DERIVED are guesses from the DBC - confirm them. None = not known yet;\n"
        "the generated config keeps it None and lists it in CANC_DBC_OPEN_ITEMS.\n"
        'DTC format: "0xD1 0x54 0x00" (three bytes, as in the other projects).\n"""\n',

        "# Key of CAN_SIGNAL_Rx_MAP; must equal project_config.ACTIVE_CAN_VARIANT.\n"
        f"CAN_VARIANT = {v['CAN_VARIANT']!r}\n",

        "# The DBC of each bus (CANFD, HSCAN or CAN - normal CAN) and the SRS node in it.\n"
        "# Recorded so tools/canc_config_gui.py can reopen the project; the command line\n"
        "# names its DBCs itself.\n"
        f"DBC_FILES = {_fmt(v['DBC_FILES'])}\n"
        f"SRS_NODES = {_fmt(v['SRS_NODES'])}\n\n"
        "# ARIA channel name and legacy channel number per bus.\n"
        f"BUS_CHANNELS = {_fmt(v['BUS_CHANNELS'])}\n"
        f"BUS_CH = {_fmt(v['BUS_CH'])}\n",

        "# DERIVED from the frame names. Node that sends each restbus frame; None = no node\n"
        "# (the frame is never stopped for a node-absent or timeout case).\n"
        f"NODE_BY_FRAME = {_fmt(v['NODE_BY_FRAME'])}\n",

        "# DERIVED: the lowest CAN ID each node sends. Confirm every one against the Node\n"
        "# Absent DTC set conditions in the diag spec - it is not always the lowest ID.\n"
        f"KEY_FRAMES = {_fmt(v['KEY_FRAMES'])}\n",

        "# Diag spec, DTC List sheet.\n"
        f"NODE_ABSENT_DTC = {_fmt(v['NODE_ABSENT_DTC'])}\n\n"
        "# Only nodes that send a frame besides their key frame need one.\n"
        f"MESSAGE_TIMEOUT_DTC = {_fmt(v['MESSAGE_TIMEOUT_DTC'])}\n\n"
        "# Frames carrying a CRC / alive counter. Key by frame (both signals share the DTC),\n"
        "# or by signal name. Leave None if the SRS does not monitor the frame.\n"
        f"MESSAGE_CONTENT_FAILURE_DTC = {_fmt(v['MESSAGE_CONTENT_FAILURE_DTC'])}\n\n"
        "# Signals the DBC names an invalid code for. Key by signal, or \"FRAME.SIGNAL\".\n"
        "# Leave None where the DTC list has no signal content DTC for it.\n"
        f"SIGNAL_CONTENT_FAILURE_DTC = {_fmt(v['SIGNAL_CONTENT_FAILURE_DTC'])}\n",

        "# \"SIGNAL\" or \"FRAME.SIGNAL\" -> EDR parameter name: the common name every project\n"
        "# gives the element (U171's: VehSpdLgt, ACC_PED, GEAR_ACTUAL, ...), whatever frame\n"
        "# and signal carry it in this project.\n"
        f"EDR_PARAMETERS = {_fmt(v['EDR_PARAMETERS'])}\n",

        "# DERIVED: frame a plain signal name points at when the signal is on several frames.\n"
        f"PREFERRED_FRAME = {_fmt(v['PREFERRED_FRAME'])}\n",

        "# DERIVED: the SRS frame read at crash time on each bus (its fastest cyclic frame).\n"
        f"CRASH_OUTPUT_FRAMES = {_fmt(v['CRASH_OUTPUT_FRAMES'])}\n\n"
        "# DERIVED from the DBC value-table labels. Confirm against the crash-output\n"
        "# requirement; compared as hex strings against the values read at crash time.\n"
        f"CRASH_EXPECTED_VALUES = {_fmt(v['CRASH_EXPECTED_VALUES'])}\n",

        "# Diag spec, sheet NetworkMgmtIdentifiers (DID 0x0103 / 0x0104).\n"
        f"NETWORK_MANAGEMENT = {_fmt(v['NETWORK_MANAGEMENT'])}\n",

        "# DERIVED from the DBC value tables, except the bus-sleep wait (NM timeout +\n"
        "# wait-bus-sleep time from the NM spec, plus margin).\n"
        f"CAN_WAKEUP = {_fmt(v['CAN_WAKEUP'])}\n",
    ]
    return "\n\n".join(sections)

# --------------------------------------------------------------------------------------
# Checking the result
# --------------------------------------------------------------------------------------


def self_check(path: Path) -> list[str]:
    """Import the written config and check what the scripts rely on."""
    spec = importlib.util.spec_from_file_location("generated_canc_config", path)
    if spec is None or spec.loader is None:
        return [f"cannot load {path}"]
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as error:                  # a generated file must at least import
        return [f"the written file does not import: {error!r}"]
    problems = []
    required = ("frame", "signal", "bit_length", "Signed", "Factor", "Offset", "UNIT",
                "MIN", "MAX", "periodicity", "Default_Value", "fault_logic")
    for key, definition in module.MAH_CAN_SIGNAL_DEFS.items():
        missing = [name for name in required if name not in definition]
        if missing:
            problems.append(f"{key}: missing {missing}")
        logic = definition["fault_logic"]
        for frame in (logic.get("key_message"), logic.get("non_key_timeout_frame")):
            if frame and frame not in module.CAN_TX_MESSAGE_CONFIG:
                problems.append(f"{key}: fault frame {frame} not in CAN_TX_MESSAGE_CONFIG")
    for name in module.__all__:
        if not hasattr(module, name):
            problems.append(f"__all__ names {name}, which is not defined")
    return problems


def _relative(path: Path | None) -> str:
    if path is None:
        return "none"
    try:
        return path.resolve().relative_to(REPOSITORY_ROOT).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def _active_can_variant(project: str) -> str | None:
    path = REPOSITORY_ROOT / "projects" / project / "config" / "project_config.py"
    if not path.is_file():
        return None
    match = re.search(r'^ACTIVE_CAN_VARIANT\s*=\s*["\']([^"\']+)["\']',
                      path.read_text(encoding="utf-8", errors="replace"), re.MULTILINE)
    return match.group(1) if match else None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--project", required=True)
    parser.add_argument("--dbc", action="append", default=[], type=Path,
                        help="a DBC whose bus type is detected (CAN-FD frames -> CANFD)")
    parser.add_argument("--fd", type=Path, help="the CAN-FD DBC")
    parser.add_argument("--hs", type=Path, help="the HS-CAN DBC")
    parser.add_argument("--can", type=Path, help="the normal (classic) CAN DBC")
    parser.add_argument("--ecu-node", help="the SRS node name, when a DBC lists several nodes")
    parser.add_argument("--inputs", type=Path,
                        help=f"inputs file (default projects/<project>/config/{INPUTS_FILE_NAME})")
    parser.add_argument("--output", type=Path,
                        help="output file (default projects/<project>/config/canc_config.py)")
    parser.add_argument("--init-inputs", action="store_true",
                        help="write the starter inputs file and stop")
    parser.add_argument("--force", action="store_true", help="overwrite an existing output file")
    arguments = parser.parse_args()

    config_dir = REPOSITORY_ROOT / "projects" / arguments.project / "config"
    inputs_path = arguments.inputs or config_dir / INPUTS_FILE_NAME
    output = arguments.output or config_dir / "canc_config.py"

    requested: list[tuple[Path, str | None]] = [(path, None) for path in arguments.dbc]
    if arguments.fd:
        requested.append((arguments.fd, "CANFD"))
    if arguments.hs:
        requested.append((arguments.hs, "HSCAN"))
    if arguments.can:
        requested.append((arguments.can, "CAN"))
    if not 1 <= len(requested) <= len(BUS_TYPES):
        parser.error("give one DBC per bus, at most one each of --fd, --hs and --can")
    for path, _ in requested:
        if not path.is_file():
            parser.error(f"DBC not found: {path}")
    buses = [read_bus(path, bus, arguments.ecu_node) for path, bus in requested]
    if len({bus.bus for bus in buses}) != len(buses):
        parser.error("two DBCs have the same bus type; name them with --fd, --hs and --can")

    command = ("py -3.14 tools/build_canc_config_from_dbc.py --project " + arguments.project
               + "".join(f" --{OPTION_OF_BUS[bus.bus]} {_relative(bus.path)}"
                         for bus in buses))

    inputs = Inputs(None if arguments.init_inputs else inputs_path)
    variant = inputs.get("CAN_VARIANT") or _active_can_variant(arguments.project) or arguments.project
    model = Model(arguments.project, buses, inputs, variant)

    target = inputs_path if arguments.init_inputs else output
    try:
        default_target = target.resolve().parent == config_dir.resolve()
    except OSError:
        default_target = False
    if (not arguments.init_inputs and arguments.project in HAND_MAINTAINED_PROJECTS
            and default_target):
        print(f"Refusing: projects/{arguments.project}/config/canc_config.py is hand-maintained. "
              "Use --output to write somewhere else.")
        return 2
    if target.exists() and not arguments.force:
        print(f"Refusing to overwrite {_relative(target)} (use --force).")
        return 2
    target.parent.mkdir(parents=True, exist_ok=True)

    if arguments.init_inputs:
        target.write_text(render_inputs(model, command), encoding="utf-8")
        print(f"Wrote {_relative(target)}. Fill it in, then run:\n    {command}")
        return 0

    if inputs.module is None:
        print(f"No inputs file at {_relative(inputs_path)}; DTCs and key frames stay open. "
              "Create one with --init-inputs.")
    target.write_text(render_config(model, command), encoding="utf-8")
    problems = self_check(target)

    print(f"Wrote {_relative(target)}")
    for bus in model.buses:
        kinds = [frame.kind for frame in bus.frames]
        print(f"  {bus.bus:<6} {bus.path.name}: {len(bus.frames)} frames "
              f"({kinds.count('restbus')} restbus, {kinds.count('ecu_tx')} SRS, "
              f"{kinds.count('diag')} diag)")
    print(f"  nodes          : {len(model.frames_by_node)}")
    print(f"  signal blocks  : {len(model.blocks)}")
    print(f"  open items     : {len(model.open_items)} (CANC_DBC_OPEN_ITEMS)")
    for problem in problems:
        print(f"  CHECK FAILED   : {problem}")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
