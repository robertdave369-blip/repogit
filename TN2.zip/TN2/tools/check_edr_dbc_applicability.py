"""Compare complete EDR requirement records with native DBC metadata offline."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from map_codebeamer_requirement_links import export_rows, issue_id, name_key, normalized_text, source_hash


ROOT = Path(__file__).resolve().parents[1]
ECU_NODES = {"SRS_FD", "SRS_HSCAN"}
REVIEW_ALIASES = {
    "Vehicle Speed Longitudinal": ["VEHICLE_SPEED"],
    "VehicleSpeed Longitudinal At Time Zero": ["VEHICLE_SPEED"],
    "Vehicle State": ["VEHICLE_STATE"],
    "BRAKE SWITCH STATUS": ["BRK_SWITCH"],
    "Accelerator pedal": ["RAW_ACC_PEDAL_VALUE"],
    "Vcu Motor Speed": ["VCU_MCU_MOTOR_SPEED"],
    "ABS_ACTIVE_IEB": ["ABS_ACTIVE_IEB"],
    "STEERING_ABSOLUTE_ANGLE": ["STEERING_ABSOLUTE_ANGLE"],
    "ESC_ACTIVE_IEB": ["ESC_ACTIVE_IEB"],
    "Tyre_Pressure_FL": ["FL_TYRE_PRESSURE"],
    "Door Lock Status": ["STS_DRIVER_DOOR_LATCH"],
    "TCS_ACTIVE_IEB": ["TCS_ACTIVE_IEB"],
    "Front Head Lamp Status": ["STS_HIGH_BEAM"],
    "ZONAL_BATT_VOLT": ["ZONAL_BATT_VOLT"],
    "AEB_WARNING_MSG": ["AEB_WARNING_MSG"],
    "AEB_FCTA_WARN": ["AEB_FCTA_WARN"],
    "AES_Warning": ["AES_WARNING"],
    "AES_SYS_STS": ["AES_SYS_STS"],
    "ESA_SYS_STS": ["ESA_SYS_STS"],
    "LDW_LKA_WARNING": ["LDW_LKA_WARNING"],
    "ADAS_Des_StrWhl_Angle_Cmd": ["ADAS_DES_STRWHL_ANGLE_CMD"],
    "LDW_LKA_SYS_STATE": ["LDW_LKA_SYS_STATE"],
    "LKA_HANDSOFF_DISPLAY_WARNING": ["LKA_HANDSOFF_DISPLAY_WARNING"],
    "SPA_SYS_STATE": ["SPA_SYS_STATE"],
    "SPA_LCF_HANDSOFF_ WARNING": ["SPA_LCF_HANDS_OFF_WARNING"],
    "NP_SYS_STS": ["NP_SYS_STS"],
    "RMS_MODE_STATE": ["RMS_MODE_STATE"],
    "LC_PATH_STATE": ["LC_PATH_STATE"],
    "ELK_Oncoming_Warning": ["ELK_ONCOMING_WARNING"],
    "ELK_SIDE_WARNING": ["ELK_SIDE_WARNING"],
    "ELK_Overtaking_Warning": ["ELK_OVERTAKING_WARNING"],
    "Gear": ["GEAR_ACTUAL"],
    "Passenger air bag suppression switch status, front passenger": ["PSGR_AIRBAG_SW_IC"],
    "OCS Passenger Type Classification": ["OCS_PASS_CLASS"],
    "DOMS Seat Belt Identification Status": ["DOMS_FL_SEATBELT"],
    "ECALL_PWM_ACK_CRASH": ["E_CALL_PWM_SIGNAL_ACK"],
}


def source_tokens(value: str) -> list[str]:
    return [token.strip() for token in normalized_text(value).split(",") if token.strip()]


def parameter_label(record) -> str:
    summary = normalized_text(record.text("Summary")).strip()
    parent = normalized_text(record.text("Parent")).strip()
    match = re.search(r"\s*at\s+(?:T0|[+-]?\d+(?:\.\d+)?\s*(?:s|sec))\s*$", summary, re.IGNORECASE)
    if match:
        base = summary[:match.start()].strip()
        if re.search(r"\bat\s+T0\s*$", summary, re.IGNORECASE):
            return base
        return parent or base
    return summary or parent or "Unlabelled exported item"


def load_networks(folder: Path) -> list[dict]:
    messages = []
    for bus, filename in (("CAN FD", "can-fd-signals.json"), ("HSCAN", "hscan-signals.json")):
        for message in json.loads((folder / filename).read_text(encoding="utf-8")):
            message = dict(message, bus=bus)
            messages.append(message)
    return messages


def build_report(requirement_document: Path, folder: Path) -> dict:
    _, requirements = export_rows(requirement_document)
    messages = load_networks(folder)
    signals = []
    for message in messages:
        for signal in message["signals"]:
            receivers = set(signal.get("receivers", []))
            senders = set(message.get("senders", []))
            direction = "ECU_RX" if receivers & ECU_NODES else "ECU_TX" if senders & ECU_NODES else "DIRECTION_UNANNOTATED"
            signals.append({"bus": message["bus"], "message": message["name"], "signal": signal["name"], "frame_id": message["frame_id"], "direction": direction, "senders": sorted(senders), "receivers": sorted(receivers), "factor": signal["factor"], "offset": signal["offset"], "length": signal["length"], "locator": f"{message['bus']} DBC -> {message['name']} -> {signal['name']}"})
    aliases = {name_key(label): values for label, values in REVIEW_ALIASES.items()}
    sources = []
    for project in ("m210_dbc", "m314_dbc"):
        for filename in ("SRS_FD_SVNID_41243.dbc", "SRS_HSCAN_SVNID_41243.dbc"):
            path = ROOT / "project_dbc" / project / filename
            sources.append({"path": str(path.relative_to(ROOT)), "sha256": source_hash(path)})
    if sources[0]["sha256"] != sources[2]["sha256"] or sources[1]["sha256"] != sources[3]["sha256"]:
        raise ValueError("Project DBC copies differ; independent project-specific extraction is required")
    records = []
    for record in requirements:
        label = parameter_label(record)
        declared_messages = source_tokens(record.text("Source_Message_Name"))
        declared_signals = source_tokens(record.text("Source_Signal_Name"))
        message_matches = [message["name"] for message in messages if any(message["name"].casefold() == value.casefold() for value in declared_messages)]
        declared_matches = [signal for signal in signals if any(signal["signal"].casefold() == value.casefold() for value in declared_signals)]
        pair_matches = [signal for signal in declared_matches if any(signal["message"].casefold() == value.casefold() for value in declared_messages)]
        identity_matches = [signal for signal in signals if name_key(signal["signal"]) == name_key(label)]
        proposed_names = aliases.get(name_key(label), [])
        alias_matches = [signal for signal in signals if signal["signal"] in proposed_names]
        combined = list({(signal["bus"], signal["message"], signal["signal"]): signal for signal in declared_matches + identity_matches + alias_matches}.values())
        received = [signal for signal in combined if signal["direction"] == "ECU_RX"]
        transmitted = [signal for signal in combined if signal["direction"] == "ECU_TX"]
        exact_received = [signal for signal in declared_matches if signal["direction"] == "ECU_RX"]
        identity_received = [signal for signal in identity_matches if signal["direction"] == "ECU_RX"]
        if record.text("Type") in ("Heading", "Folder"):
            classification = "STRUCTURAL_ITEM"
            reason = "Heading/folder is not an EDR behavior or input signal requirement"
        elif record.text("Type") != "Functional Requirement":
            classification = "NON_FUNCTIONAL_ITEM_REVIEW"
            reason = "Information, incomplete metadata or other item type; assess normative predicate separately from CAN presence"
        elif any(signal["direction"] == "ECU_RX" for signal in pair_matches):
            classification = "EXACT_CAN_INPUT_PAIR_PRESENT"
            reason = "Declared message and signal pair is present and annotated as received by SRS; full EDR/configuration applicability still requires its own evidence"
        elif exact_received:
            classification = "CAN_INPUT_SIGNAL_PRESENT_SOURCE_CHANGED"
            reason = "Declared signal exists as an SRS input, but its declared source message is missing or different; update/confirm the EV source route"
        elif identity_received:
            classification = "CAN_INPUT_PARAMETER_NAME_PRESENT"
            reason = "Parameter identity matches an SRS-received signal; requirement source metadata is missing or different, so actual EDR routing is not proved"
        elif received and name_key(label) == name_key("ECALL_PWM_ACK_CRASH"):
            classification = "CAN_INPUT_CONVERSION_REQUIRED_REVIEW"
            reason = "E_CALL_PWM_SIGNAL_ACK is an SRS input, but DBC 0=Default/1=No_Error/2=Error differs from EDR 0=OK/1=Not OK; conversion and default/reserved handling require confirmation, not a direct alias"
        elif received:
            classification = "CANDIDATE_EV_CAN_INPUT_REVIEW"
            reason = "A proposed semantic/legacy-name replacement exists as an SRS input; the equivalence and EDR route are INFERRED and need owner confirmation"
        elif transmitted:
            classification = "ECU_TX_ONLY_NOT_EXTERNAL_CAN_INPUT"
            reason = "Matching signal is transmitted by SRS, not received as the declared external input; internal/sensor-derived EDR applicability is not decided by DBC input presence"
        elif combined:
            classification = "SIGNAL_PRESENT_DIRECTION_UNANNOTATED"
            reason = "Matching signal exists but its SRS receive direction is not annotated; do not assume an active ECU input"
        elif declared_messages or declared_signals:
            classification = "DECLARED_CAN_SOURCE_NOT_PRESENT"
            reason = "No declared source signal or reviewed replacement found in either supplied DBC; this proves only absent external CAN evidence, not that the EDR field must be removed"
        else:
            classification = "DBC_NOT_DECIDABLE_NO_CAN_SOURCE"
            reason = "No declared CAN source or matching network parameter; internal ECU, sensor, NVM/diagnostic, hardware or incomplete source evidence requires non-DBC assessment"
        exact_pair_all = bool(declared_signals) and all(any(signal["signal"].casefold() == value.casefold() for signal in pair_matches) for value in declared_signals)
        actual_signal_names = sorted({signal["signal"] for signal in combined})
        candidate_class = classification in ("CANDIDATE_EV_CAN_INPUT_REVIEW", "CAN_INPUT_CONVERSION_REQUIRED_REVIEW")
        records.append({"requirement_id": issue_id(record.values["ID"]), "requirement_name": record.text("Summary"), "parameter": label, "parent": record.text("Parent"), "type": record.text("Type"), "status": record.text("_ReqStatus"), "requirement_row": record.number, "requirement_locator": record.locators["ID"], "declared_messages": declared_messages, "declared_signals": declared_signals, "declared_message_present": bool(message_matches), "all_declared_pairs_present": exact_pair_all, "any_signal_or_candidate_present": bool(combined), "external_srs_input_present": bool(received), "m210_classification": classification, "m314_classification": classification, "classification": classification, "matched_signals": combined, "matched_signal_names": actual_signal_names, "reason": reason, "basis": "INFERRED" if candidate_class else "EXTRACTED signal presence; INFERRED applicability limits", "confidence": "High for candidate identity; unverified routing" if candidate_class else "Very High for DBC membership only"})
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for record in records:
        if record["type"] == "Functional Requirement":
            groups[(record["parameter"], record["classification"], record["status"])].append(record)
    parameters = []
    for (label, classification, status), members in groups.items():
        matches = list({(signal["bus"], signal["message"], signal["signal"]): signal for record in members for signal in record["matched_signals"]}.values())
        parameters.append({"parameter": label, "classification": classification, "status": status, "requirement_ids": [record["requirement_id"] for record in members], "requirement_rows": [record["requirement_row"] for record in members], "matched_signals": matches, "declared_messages": sorted({value for record in members for value in record["declared_messages"]}), "declared_signals": sorted({value for record in members for value in record["declared_signals"]}), "reason": members[0]["reason"]})
    return {"generated_by": "tools/check_edr_dbc_applicability.py", "sources": sources, "project_dbc_snapshots_identical": True, "statistics": {"total_requirement_items": len(records), "functional_requirement_items": sum(record["type"] == "Functional Requirement" for record in records), "parsed_messages": len(messages), "parsed_signals": len(signals), "all_record_classifications": dict(Counter(record["classification"] for record in records)), "current_functional_classifications": dict(Counter(record["classification"] for record in records if record["type"] == "Functional Requirement" and record["status"] != "Obsolete")), "current_parameter_groups": sum(record["status"] != "Obsolete" for record in parameters)}, "requirements": records, "parameters": parameters, "dbc_signals": signals, "method": "All requirement IDs retained; exact source-message/signal membership, normalized parameter identity and explicitly labelled semantic aliases compared with complete native DBC extraction. SRS reception/transmission distinguished. Non-CAN behavior is not rejected by absence from DBC.", "limitations": ["DBC presence proves signal availability, not enabled variant, EDR allocation, firmware implementation or executed recording.", "Semantic aliases and changed source messages require source-owner review; no requirement or DBC was rewritten.", "Obsolete requirements retained for review, not treated as active approved requirements."]}


def table_rows(records: list[dict]) -> list[list]:
    rows = []
    for record in records:
        rows.append([record["requirement_id"], record["requirement_name"], record["parameter"], record["type"], record["status"], record["requirement_row"], ", ".join(record["declared_messages"]), ", ".join(record["declared_signals"]), record["m210_classification"], record["m314_classification"], "\n".join(f"{signal['bus']}: {signal['message']}.{signal['signal']} ({signal['direction']})" for signal in record["matched_signals"]), record["reason"], record["requirement_locator"]])
    return rows


def write_outputs(report: dict, folder: Path) -> None:
    headers = ["Requirement ID", "Requirement Name", "EDR Parameter", "Type", "Status", "Source Row", "Declared Message", "Declared Signal", "M210 DBC Classification", "M314 DBC Classification", "Actual DBC Evidence", "Reason / Applicability Limit", "Requirement Provenance"]
    with (folder / "requirement-applicability.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(headers)
        writer.writerows(table_rows(report["requirements"]))
    workbook = Workbook()
    workbook.remove(workbook.active)
    groups = [("All_Requirements", report["requirements"]), ("CAN_Input_Present", [record for record in report["requirements"] if record["classification"] in ("EXACT_CAN_INPUT_PAIR_PRESENT", "CAN_INPUT_SIGNAL_PRESENT_SOURCE_CHANGED", "CAN_INPUT_PARAMETER_NAME_PRESENT")]), ("Candidate_Renames", [record for record in report["requirements"] if record["classification"] in ("CANDIDATE_EV_CAN_INPUT_REVIEW", "CAN_INPUT_CONVERSION_REQUIRED_REVIEW")]), ("No_External_CAN", [record for record in report["requirements"] if record["classification"] in ("DECLARED_CAN_SOURCE_NOT_PRESENT", "ECU_TX_ONLY_NOT_EXTERNAL_CAN_INPUT", "SIGNAL_PRESENT_DIRECTION_UNANNOTATED")]), ("Non_CAN_Review", [record for record in report["requirements"] if record["classification"] in ("DBC_NOT_DECIDABLE_NO_CAN_SOURCE", "NON_FUNCTIONAL_ITEM_REVIEW", "STRUCTURAL_ITEM")])]
    for name, records in groups:
        sheet = workbook.create_sheet(name)
        sheet.append(headers)
        for row in table_rows(records):
            sheet.append(row)
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="275D57")
        for index, width in enumerate((18, 45, 38, 25, 16, 14, 30, 32, 42, 42, 65, 95, 65), 1):
            sheet.column_dimensions[get_column_letter(index)].width = width
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
    sheet = workbook.create_sheet("Parameter_Summary", 0)
    sheet.append(["EDR Parameter", "Classification M210 and M314", "Status", "Requirement IDs", "Requirement Rows", "Declared Messages", "Declared Signals", "DBC Matches / Direction", "Reason"])
    for parameter in report["parameters"]:
        sheet.append([parameter["parameter"], parameter["classification"], parameter["status"], ", ".join(parameter["requirement_ids"]), ", ".join(str(value) for value in parameter["requirement_rows"]), ", ".join(parameter["declared_messages"]), ", ".join(parameter["declared_signals"]), "\n".join(f"{signal['message']}.{signal['signal']} ({signal['direction']})" for signal in parameter["matched_signals"]), parameter["reason"]])
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for index, width in enumerate((42, 46, 16, 85, 65, 35, 40, 75, 100), 1):
        sheet.column_dimensions[get_column_letter(index)].width = width
    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9E5E2")
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    output = folder / "EV_EDR_M210_M314_DBC_Applicability.xlsx"
    workbook.save(output)
    workbook.close()
    check = load_workbook(output, read_only=True, data_only=False)
    actual = list(check["All_Requirements"].iter_rows(min_row=2, values_only=True))
    if [row[0] for row in actual] != [record["requirement_id"] for record in report["requirements"]]:
        raise ValueError("Applicability workbook does not preserve complete requirement ID order")
    check.close()
    report["validation"] = {"passed": True, "all_requirement_ids_written_once": len(actual), "source_order_retained": True, "project_dbc_hash_equality_verified": True, "original_sources_changed": False}
    (folder / "applicability-report.json").write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requirements-document", type=Path, required=True)
    parser.add_argument("--output-folder", type=Path, required=True)
    arguments = parser.parse_args()
    if not (arguments.output_folder / "README.md").exists():
        parser.error("Retained output folder must have a README")
    report = build_report(arguments.requirements_document, arguments.output_folder)
    write_outputs(report, arguments.output_folder)
    print(json.dumps(report["statistics"], indent=2))


if __name__ == "__main__":
    main()