"""Check that every project's canc_config.py uses the common CAN-C names.

What "common" means is defined once, in tools/canc_common_names.py:

  1. the shared top-level names (MAH_CAN_SIGNAL_DEFS, CAN_TX_MESSAGE_CONFIG,
     CAN_SIGNAL_Rx_MAP, ...) - each holding the project's own frames, whatever its buses;
  2. EDR parameter names: no EDR_Parameter is spelled as an element's specification name
     where the common name (U171's) differs;
  3. the element names themselves: an edr_config entry that decodes one element of the
     common record (it carries the element's 'spec_name') has U171's name for it.

An EDR_Parameter that is neither an element of the project's edr_config nor a label U171
uses is listed as a note: that is right for a signal the record does not store (an
EV-only SRS output, say), and worth a look in case it is a misspelt element name. The
frame and signal that carry a parameter are each project's own and are not compared.

Offline only: imports each config and reports what it lacks. Exit code 1 when anything
is missing.

Usage:
    py -3.14 tools/check_canc_config_common.py                 # every project with signals
    py -3.14 tools/check_canc_config_common.py --project W610
    py -3.14 tools/check_canc_config_common.py --file path/to/canc_config.py
"""

from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import canc_common_names as common  # noqa: E402

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def load(path: Path, kind: str):
    spec = importlib.util.spec_from_file_location(f"_common_{kind}_{path.parent.parent.name}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def edr_entries(canc_path: Path) -> list[dict[str, Any]] | None:
    path = canc_path.with_name("edr_config.py")
    if not path.is_file():
        return None
    return list(getattr(load(path, "edr"), "EDR_PARAMETERS", []) or [])


def single_spec(entry: dict[str, Any]) -> str | None:
    spec = entry.get("spec_name")
    return spec if isinstance(spec, str) else None


def reference() -> tuple[set[str], dict[str, str]]:
    """U171's EDR_Parameter labels and element names, and spec name -> U171 name."""
    path = REPOSITORY_ROOT / "projects" / common.REFERENCE_PROJECT / "config" / "canc_config.py"
    signals = getattr(load(path, "canc"), "MAH_CAN_SIGNAL_DEFS", {}) or {}
    entries = edr_entries(path) or []
    labels = {d.get("EDR_Parameter") for d in signals.values() if isinstance(d, dict)}
    labels |= {entry.get("name") for entry in entries}
    specs: dict[str, list[str]] = {}
    for entry in entries:
        spec = single_spec(entry)
        if spec:
            specs.setdefault(spec, []).append(entry["name"])
    names = {spec: found[0] for spec, found in specs.items() if len(found) == 1}
    return {label for label in labels if label}, names


def check(label: str, path: Path, labels: set[str], names: dict[str, str]) -> int:
    module = load(path, "canc")
    signals = getattr(module, "MAH_CAN_SIGNAL_DEFS", None)
    if not signals:
        print(f"== {label}: no signal definitions (MAH_CAN_SIGNAL_DEFS) - nothing to check")
        return 0
    entries = edr_entries(path)
    edr_names = None if entries is None else [entry.get("name") for entry in entries]
    problems = common.check_config(module, names)
    notes = [f"EDR_Parameter {name!r} ({', '.join(keys)}) is not an element of this "
             f"project's edr_config nor a label {common.REFERENCE_PROJECT} uses"
             for name, keys in sorted(common.edr_parameters(module).items())
             if edr_names is not None and name not in edr_names and name not in labels]
    for entry in entries or []:
        expected = names.get(single_spec(entry) or "")
        if expected and entry.get("name") != expected:
            problems.append(f"edr_config element {entry.get('name')!r} (spec "
                            f"{single_spec(entry)!r}) is {expected!r} in "
                            f"{common.REFERENCE_PROJECT}")
    feeding = [d for d in signals.values() if isinstance(d, dict) and d.get("EDR_Parameter")]
    resolved = sum(1 for d in feeding if edr_names is not None and d["EDR_Parameter"] in edr_names)
    print(f"== {label}: {len(feeding)} signal key(s) name an EDR parameter, {resolved} of them "
          f"an element of its edr_config"
          + ("" if entries is not None else " (no edr_config next to it)"))
    for problem in problems:
        print(f"   PROBLEM {problem}")
    for note in notes:
        print(f"   note    {note}")
    print(f"   {len(problems)} problem(s)")
    return len(problems)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--project")
    parser.add_argument("--file", type=Path)
    arguments = parser.parse_args()
    sys.path.insert(0, str(REPOSITORY_ROOT.parent))
    labels, names = reference()
    if arguments.file:
        targets = [(str(arguments.file), arguments.file)]
    else:
        projects = [arguments.project] if arguments.project else sorted(
            p.name for p in (REPOSITORY_ROOT / "projects").iterdir()
            if (p / "config" / "canc_config.py").is_file())
        targets = [(name, REPOSITORY_ROOT / "projects" / name / "config" / "canc_config.py")
                   for name in projects]
    total = sum(check(label, path, labels, names) for label, path in targets)
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
