"""Build tests/edr_onfail_policy.json from the source on-fail recording workbook.

The workbook `docs/project_documents/onfail_documents/onfail_edr_recording.xlsx`
(sheet `SRS`) is the source of truth for what the SRS/EDR logic records when a CAN
signal or network fault is active. This script normalizes it into the policy JSON
the specification generator consumes, and records the source SHA-256 so the
generated specification can cite verifiable provenance.

Offline only: reads two files and writes one JSON. No CAN traffic, no ECU access.

Usage:
    py -3.14 tools/build_edr_onfail_policy.py [--check]

`--check` verifies the committed JSON still matches the workbook and exits
non-zero on drift, without rewriting anything.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SOURCE_WORKBOOK = REPOSITORY_ROOT / "docs" / "project_documents" / "onfail_documents" / "onfail_edr_recording.xlsx"
SOURCE_SHEET = "SRS"
OUTPUT_PATH = REPOSITORY_ROOT / "tests" / "edr_onfail_policy.json"

HEADER_ROW = 4
FIRST_DATA_ROW = 6

# Fault condition -> column holding its `Value`; the `Reaction` is the next column.
FAULT_COLUMNS: tuple[tuple[str, int], ...] = (
    ("signal_never_received", 6),
    ("signal_invalid", 8),
    ("reserved_or_out_of_range", 10),
    ("message_timeout", 12),
    ("node_absent", 14),
    ("variant_code_error", 16),
    ("message_content_failure", 18),
    ("uv_ov", 20),
    ("bus_off", 22),
    ("network_security_failure", 24),
)

SYSTEM_COLUMN = 1
MESSAGE_COLUMN = 2
SIGNAL_COLUMN = 3
FEATURES_COLUMN = 4
INITIALIZATION_COLUMN = 5
REMARKS_COLUMN = 26

# Generic behavior used when no exact system+message+signal record matches.
# Mirrors section 5 of onfail_edr_recording_context.md.
GENERIC_BEHAVIOR = {
    "initialization": {"reaction": "consume"},
    "signal_never_received": {"reaction": "default"},
    "signal_invalid": {"reaction": "consume"},
    "reserved_or_out_of_range": {"reaction": "consume"},
    "message_timeout": {"reaction": "last_valid"},
    "node_absent": {"reaction": "last_valid"},
    "variant_code_error": {"reaction": "default"},
    "message_content_failure": {"reaction": "last_valid"},
    "uv_ov": {"reaction": "last_valid"},
    "bus_off": {"reaction": "last_valid"},
    "network_security_failure": {"reaction": "last_valid"},
}

# Signal-specific behavior that the flat matrix cannot express. Each entry cites
# the rule that justifies it so the generated specification stays traceable.
SPECIAL_BEHAVIOR: dict[tuple[str, str, str], dict[str, Any]] = {
    ("EMS", "EMS1_10", "STS_ENG"): {
        "message_timeout_values": ["0x1", "0x5"],
        "qualification_seconds": 10,
        "full_only": True,
        "reason": (
            "Message timeout qualifies only while STS_ENG is simulated as 0x1 or 0x5 and needs "
            "10 s to mature, which exceeds the recording window, so pre/post-crash split cases "
            "are not constructible (canc_onfail.md)."
        ),
    },
    ("EMS", "EMS3_10", "CLUTCH_STS"): {
        "carried_on_key_frame": True,
        "reason": (
            "CLUTCH_STS is carried on EMS3_10, which is the EMS key frame (lowest CAN ID, 0x108). "
            "Stopping it raises Node Absent, so no separate message-timeout case exists. Injecting "
            "the timeout on another EMS frame would leave CLUTCH_STS live and record a consumed "
            "value rather than the last valid one, which is not a timeout test (canc_onfail.md)."
        ),
    },
}

# Section 3 of the context document: SRS never uses gateway signal values.
GATEWAY_MESSAGE = "GW_HEARTBEAT"
GATEWAY_OVERRIDE = {
    "reaction": "default",
    "value": "0x0",
    "note": (
        "SRS does not use gateway signal values as functional inputs. GW_HEARTBEAT is considered "
        "only for node-absent detection and all gateway signal values are treated as 0x0 for any "
        "condition (onfail_edr_recording.xlsx remark, source row 28)."
    ),
}

REACTION_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"^last\s*valid\s*value$", "last_valid"),
    (r"^con[us]{2}me\s+the\s*value$", "consume"),
    (r"^default\s+value\.?$", "default"),
)

# The source records the reserved/out-of-range reaction for vehicle speed as a
# clamp instruction rather than a raw code. The approved reference specification
# (canc_m314.xlsx, VehSpdLgt reserved/out-of-range case) confirms the DBC maximum
# is what gets recorded, so this is encoded rather than left unresolved.
CLAMP_MAX_PATTERN = re.compile(r"^max\s+value\s+as\s+per\s+dbc\b", flags=re.IGNORECASE)

# `signal_never_received` rows always carry a concrete raw value. Some rows name
# that value semantically ("No warning", "System OFF") instead of repeating
# "Default value". Section 5 of the context document already fixes the generic
# signal-never-received reaction as `default`, and section 7 directs that stated
# semantic meanings be retained rather than dropped, so the label is preserved
# alongside the canonical reaction instead of being treated as a new behavior.
SEMANTIC_DEFAULT_LABELS = frozenset(
    {
        "no warning",
        "no warning\\default",
        "no warning/default",
        "no display",
        "warning off",
        "system off",
        "off",
        "reserved",
    }
)

HEX_PREFIX_PATTERN = re.compile(r"0X(?=[0-9A-Fa-f])")


def normalize_cell(value: object) -> str | None:
    """Collapse whitespace/newlines; return None for blank cells."""
    if value is None:
        return None
    text = re.sub(r"\s+", " ", str(value)).strip()
    return text or None


def normalize_raw_value(value: str | None) -> tuple[str | None, bool]:
    """Normalize the hex prefix casing only; ranges and digits are preserved verbatim.

    Returns (value, not_specified). `NA` means the source carries no explicit
    special value (rule 4) and must not be turned into a number.
    """
    if value is None:
        return None, False
    if value.strip().upper() == "NA":
        return None, True
    return HEX_PREFIX_PATTERN.sub("0x", value), False


def classify_reaction(raw: str | None, *, fault: str) -> tuple[str, str | None, str | None]:
    """Map a source reaction phrase onto a canonical reaction token.

    Returns (reaction, unresolved_source_text, semantic_label). Anything that is
    not an unambiguous match stays `unresolved` with its original text preserved,
    per rule 11 of the context document: never silently correct the source.
    """
    if raw is None:
        return "unspecified", None, None
    collapsed = re.sub(r"\s+", " ", raw).strip()
    lowered = collapsed.lower()
    for pattern, reaction in REACTION_PATTERNS:
        if re.match(pattern, lowered):
            return reaction, None, None
    if lowered == "na":
        return "not_applicable", None, None
    if CLAMP_MAX_PATTERN.match(collapsed):
        return "clamp_dbc_max", None, collapsed
    if fault == "signal_never_received":
        # A bare raw code in the reaction column restates the paired value.
        if re.fullmatch(r"0x[0-9A-Fa-f]+", collapsed, flags=re.IGNORECASE):
            return "default", None, None
        if lowered in SEMANTIC_DEFAULT_LABELS:
            return "default", None, collapsed
    # Conflicting entries such as "Default value Last valid value" stay unresolved.
    return "unresolved", collapsed, None


def expand_merged_cells(worksheet: Worksheet) -> None:
    """Fill every merged region with its anchor value so row reads are complete."""
    for merged_range in list(worksheet.merged_cells.ranges):
        anchor = worksheet.cell(row=merged_range.min_row, column=merged_range.min_col).value
        worksheet.unmerge_cells(str(merged_range))
        for row in range(merged_range.min_row, merged_range.max_row + 1):
            for column in range(merged_range.min_col, merged_range.max_col + 1):
                worksheet.cell(row=row, column=column).value = anchor  # type: ignore[assignment]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(131072), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_header(worksheet: Worksheet) -> None:
    """Fail loudly if the workbook layout moved instead of silently misreading it."""
    expected = {
        SYSTEM_COLUMN: "System",
        MESSAGE_COLUMN: "Message",
        SIGNAL_COLUMN: "Signal Name",
    }
    for column, label in expected.items():
        actual = normalize_cell(worksheet.cell(row=HEADER_ROW, column=column).value)
        if actual != label:
            raise SystemExit(
                f"Unexpected header at row {HEADER_ROW} column {column}: "
                f"expected {label!r}, found {actual!r}. Re-check the workbook layout."
            )
    for fault, column in FAULT_COLUMNS:
        header = normalize_cell(worksheet.cell(row=HEADER_ROW, column=column).value)
        if header is None:
            raise SystemExit(f"Missing fault header for {fault} at column {column}.")


def build_records(worksheet: Worksheet) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    # System and Message are stated once and left blank for continuation rows.
    # Carry the last stated value forward, matching the normalization already
    # published in onfail_edr_recording_context.md.
    system = ""
    message = ""
    for row in range(FIRST_DATA_ROW, worksheet.max_row + 1):
        stated_system = normalize_cell(worksheet.cell(row=row, column=SYSTEM_COLUMN).value)
        stated_message = normalize_cell(worksheet.cell(row=row, column=MESSAGE_COLUMN).value)
        if stated_system:
            system = stated_system
        if stated_message:
            message = stated_message
        signal = normalize_cell(worksheet.cell(row=row, column=SIGNAL_COLUMN).value)
        if not signal:
            continue

        record: dict[str, Any] = {
            "system": system,
            "message": message,
            "signal": signal,
            "source_row": row,
            "on_fail_applicable": True,
            "features_affected": normalize_cell(worksheet.cell(row=row, column=FEATURES_COLUMN).value),
            "initialization": normalize_cell(worksheet.cell(row=row, column=INITIALIZATION_COLUMN).value),
            "faults": {},
        }

        remarks = normalize_cell(worksheet.cell(row=row, column=REMARKS_COLUMN).value)
        if remarks:
            record["source_comments"] = remarks

        special = SPECIAL_BEHAVIOR.get((record["system"], record["message"], signal))
        if special:
            record["special"] = dict(special)

        if message == GATEWAY_MESSAGE:
            # SRS treats every gateway signal value as 0x0 for any condition and uses the
            # frame only for node-absent detection, so no functional on-fail case applies.
            record["gateway_override"] = dict(GATEWAY_OVERRIDE)
            record["on_fail_applicable"] = False

        for fault, column in FAULT_COLUMNS:
            raw_value = normalize_cell(worksheet.cell(row=row, column=column).value)
            reaction_text = normalize_cell(worksheet.cell(row=row, column=column + 1).value)
            value, value_not_specified = normalize_raw_value(raw_value)
            reaction, unresolved_text, semantic_label = classify_reaction(reaction_text, fault=fault)
            if reaction == "unspecified" and raw_value is None:
                # Blank value and blank reaction: intentionally unresolved (rule 9).
                continue
            entry: dict[str, Any] = {"reaction": reaction}
            if value is not None:
                entry["value"] = value
            if value_not_specified:
                # Source said `NA`: no explicit special value exists (rule 4).
                entry["value_not_specified"] = True
            if semantic_label is not None:
                entry["semantic_label"] = semantic_label
            if unresolved_text is not None:
                entry["source_text"] = unresolved_text
            record["faults"][fault] = entry

        records.append(record)
    return records


def build_policy() -> dict[str, Any]:
    if not SOURCE_WORKBOOK.exists():
        raise SystemExit(f"Source workbook not found: {SOURCE_WORKBOOK}")
    workbook = openpyxl.load_workbook(SOURCE_WORKBOOK, data_only=True)
    if SOURCE_SHEET not in workbook.sheetnames:
        raise SystemExit(f"Sheet {SOURCE_SHEET!r} missing from {SOURCE_WORKBOOK.name}.")
    worksheet = workbook[SOURCE_SHEET]
    expand_merged_cells(worksheet)
    verify_header(worksheet)
    records = build_records(worksheet)

    unresolved = [
        {"system": r["system"], "message": r["message"], "signal": r["signal"],
         "source_row": r["source_row"], "fault": fault, "source_text": entry.get("source_text")}
        for r in records
        for fault, entry in r["faults"].items()
        if entry["reaction"] == "unresolved"
    ]

    return {
        "source": {
            "name": SOURCE_WORKBOOK.name,
            "path": str(SOURCE_WORKBOOK),
            "sheet": SOURCE_SHEET,
            "sha256": sha256_file(SOURCE_WORKBOOK),
            "parser": f"openpyxl {openpyxl.__version__}",
            "generated_by": "tools/build_edr_onfail_policy.py",
            "matching_key": "system + message + signal",
            "record_count": len(records),
            "status": "Evidence-backed: read directly from the source workbook.",
        },
        "generic": GENERIC_BEHAVIOR,
        "unresolved": unresolved,
        "records": records,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="verify the committed JSON matches the workbook")
    arguments = parser.parse_args()

    policy = build_policy()
    rendered = json.dumps(policy, indent=2, ensure_ascii=False) + "\n"

    if arguments.check:
        if not OUTPUT_PATH.exists():
            print(f"MISSING: {OUTPUT_PATH}")
            return 1
        if OUTPUT_PATH.read_text(encoding="utf-8") != rendered:
            print(f"DRIFT: {OUTPUT_PATH} does not match {SOURCE_WORKBOOK.name}.")
            return 1
        print(f"OK: {OUTPUT_PATH.name} matches {SOURCE_WORKBOOK.name}.")
        return 0

    OUTPUT_PATH.write_text(rendered, encoding="utf-8")
    print(f"Wrote {OUTPUT_PATH}")
    print(f"  source sha256 : {policy['source']['sha256']}")
    print(f"  records       : {policy['source']['record_count']}")
    print(f"  unresolved    : {len(policy['unresolved'])} fault entries need owner clarification")
    return 0


if __name__ == "__main__":
    sys.exit(main())
