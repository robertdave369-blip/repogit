# Mahindra SC3 2S Airbag ECU (SRS / ACU) — AI Agent Knowledge Base

> **Purpose of this file**: This is the definitive engineering knowledge base for the Mahindra SC3 2S
> family Airbag Control Unit (ACU / AECU / SRS ECU) covering platform variants **M310 / M314 / M110,
> U171, W616, Z121, M112, M312, W610-BEV**. It is written for use by AI coding assistants
> (GitHub Copilot / Claude / VS Code agents) so they can reason like a senior airbag-ECU engineer when
> writing code, reviewing implementations, generating unit/integration tests, creating diagnostic test
> scripts, or answering technical questions.
>
> **Ground rules baked into this document**:
> - Excel requirement exports (Codebeamer trackers `84222_Mahindra_SC3 2S - DES_SW_*`) are **one input,
>   not the truth**. Every requirement is cross-checked here against ISO 14229 (UDS), ISO 11898 /
>   CAN FD, ISO 26262, AUTOSAR CanNm/Dem/Dcm, SAE J1850 CRC-8, PSI5 v2.1, and common Tier-1
>   production practice (Veoneer/Autoliv-style SC3 platform, Bosch/Continental/ZF equivalents).
> - Where the requirement text contradicts a standard or itself, the discrepancy is called out as:
>   **Requirement says… / Industry standard says… / Recommended implementation…**
> - Requirement IDs cited (e.g. `31300826`) are Codebeamer artifact IDs from the source exports.

---

# 1. Module Overview

## 1.1 System context

The SC3 2S is a 2nd-generation safety controller ACU for Mahindra passenger vehicles. It:

- Detects frontal / side / rear / rollover / underbody crash events using internal IMU
  (accelerometers + angular-rate sensors) fused with remote PSI5 satellite sensors (RSU).
- Fires squib loops (airbags, pretensioners, load limiters) via SB3/EX3-class firing ASICs.
- Publishes crash and occupant status on **CAN FD (vehicle bus)** and **HS-CAN (diagnostic bus)**.
- Drives discrete outputs (GPO): crash output / ENS PWM line (eCall trigger), PAB ON/OFF indicator
  lamps (PADI).
- Records EDR (Event Data Recorder) data per crash event, readable via UDS.
- Supports UDS diagnostics (ISO 14229) on request `0x730` / response `0x738` / functional `0x7DF`
  (some variants additionally respond on `0x7F9` TesterPhysicalResPCU).
- Is configured at End-of-Line via **Feature Code (DID $0102)**, **Variant Code (DID $0101)** and
  **VIN (DID $F190)** stored in EEPROM/NVM.

## 1.2 Software AAU (Atomic Architecture Unit) decomposition

| AAU / Module | Responsibility | ASIL (from req. exports) |
|---|---|---|
| `CanMgr` / CAN-C | CAN FD + HS-CAN com stack, RX/TX message processing, node monitoring, bus-off handling, CRC/alive-counter checks, on-fail signal substitution | ASIL B |
| `CanNm` (Network Management) | AUTOSAR-style NM state machine, wakeup/sleep coordination, `SRS_CANNM` (0x36D) PDU | ASIL B |
| `DiagMgr` (DCM) + `DiagMgr_SecurityAccess`, `DiagMgr_RoutineServices`, `DiagMgr_ExternalProcessdServices`, `DiagMgrDataService` | UDS services, sessions, security, DIDs, IO control, routines | QM…ASIL B |
| `FltMonr` + `FltMonrCallback` (DEM-equivalent) | Fault event debouncing, DTC qualification/dequalification, enable conditions, suspend-diagnostics groups, freeze frames, NVM fault memory | ASIL B |
| `RstEdr` (EDR) | Event Data Recorder: T0 detection, pre/post-crash data collection, EEPROM records, record locking | ASIL B |
| `EnsMgr` / GPO driver (`Sb3Ex3GpoDrvr`) | Crash-output/ENS PWM, GPO channel diagnostics (open/STB/STG/config) | ASIL B |
| `Padi` / `WLMgr` | PAB disable/enable indicator lamps, warning lamp management, `INDC_PADL` CAN signal | ASIL B |
| `RsuMgr` | PSI5 v2.1 satellite management: channel + satellite state machines, phase 1–4 startup, diagnostics | ASIL B(D) |
| `ImuMgr` | Internal inertial measurement (X/Y/Z accel, roll/yaw rates), plausibility, CAN reporting | ASIL B |
| `DeviceCfgMgr` | EOL feature code, variant code, VIN, NVM configuration, virgin-ECU defaults | ASIL B |
| `OpsModMgr` / `OpsCrashMgr` | ECU operating states (Init → Proveout → Run → Powerdown/Postrun), crash decision orchestration | ASIL B/D elements |
| Bootloader (FBL) | UDS-based reprogramming (SID $34/$36/$37, RIDs), S-Record (.s37) images, app-validity management | QM/ASIL-decomposed |

> ASIL note: requirement exports tag most functional requirements **ASIL_B** or **ASIL_B(D)**
> (i.e., ASIL B requirement inherited from an ASIL D goal after decomposition). Treat the deployment
> path (crash decision → firing loop control) as **ASIL D at system level with decomposition**;
> everything that can cause *unwanted deployment* or *failure to deploy* inherits the highest rigor.

## 1.3 Safety goals (typical for this class of ECU — inferred, aligned with ISO 26262)

1. **SG1 – No inadvertent deployment** (ASIL D): no squib fires without a valid crash decision.
2. **SG2 – Deploy when required** (ASIL C/D): correct restraint deployment for in-scope crash types.
3. **SG3 – Correct occupant-dependent suppression** (ASIL B/C): PAB suppressed when switch/OCS says so.
4. **SG4 – Warn the driver** (ASIL B): warning lamp ON for any fault degrading SG1–SG3.
5. **SG5 – Post-crash safety functions** (ASIL B): crash output/ENS signal, door unlock request,
   fuel/HV cutoff request (`STS_CRASH`) transmitted after deployment.

## 1.4 External interfaces

**Inputs (CAN FD RX — per CAN-C tracker, M314 set)**: `EPS1_FD_10` (0x13A, steering angle),
`IEB1_FD_10` (0x13B), `HPCAd_1_10/2_50/3_50/4_10` (0x13E/0x2AF/0x2B1/0x13F, ADAS),
`HPCC_1_100` (0x318, incl. `PSGR_AIRBAG_SW_IC`), `FR_ZONE2_100` (0x319, `PKE_CLMP_STATE`),
`FR_ZONE3_100` (0x31A, doors/beams/TPMS/zonal battery), `VCU1/2/4/11` (0x207/0x30E/0x3F0/0x16E),
`VCU_CANNM` (0x38F), `GLOBAL_DIAG_REQ` (0x7DF), `SRS_DIAG_REQ` (0x730), `E_CALL1_100` (0x34A).
W616/U171 classic-CAN variant instead uses `EMS1_10/EMS3_10/EMS21_10/EMS36_10/EMS5_500/EMS6_500`,
`ESC2/5/10/12`, `EPS_SAS1_10` (0x114), `IC1_100/IC2_100` (0x340), `IS1_100` (0x220), `IS3_500`,
`MBFM1/5/6/7_100` (0x348…), `TCU5_10` (0x136), `FRM2_20` (0x24C), `FCM1_20` (0x24D),
`HPCAd_31_10` (0x14C), `HPCAd_33_50`, `GW_HEARTBEAT` (0x283).

**Outputs (TX)**: `SRS1_FD_10` (0x13C, DLC 64), `SRS1_20` (0x2C0, DLC 8, HS variant),
`SRS_CANNM` (0x36D), `SRS_DIAG_RES` (0x738), `TesterPhysicalResPCU` (0x7F9, variant-specific).
Discrete: GPO0 = crash output/ENS PWM, GPO1 = PADI lamp-ON (low-side), GPO2 = PADI lamp-OFF
(low-side). Squib loop channels, DCS (buckle/STPS) inputs, PSI5 channels CH0–CH7.

**Key TX signals in SRS1**: `STS_CRASH` (crash / request engine stop), `CRASH_LOCATION`
(0=none, 1=front, 2=right, 3=left, 4=rollover…, priority: Front > Left > Right > Rollover > Rear >
Understrike), `INDC_SRS` (warning lamp: 0 off / 1 on / 3 blink; $2 invalid unsupported),
`INDC_PADL`, `IGN_STS_SRS` (0 off / 1 HW ign / 2 CAN wakeup), seat-belt status per position
(0 unbuckled/default, 1 buckled, 2 faulty, 3 reserved), ODS/OCS occupancy, `SRS_STPS_ZONE_FR/FL`,
IMU values (lat/long accel g, yaw & angular rates deg/s), `SRS_DELTA_V` (−100…+200 km/h),
even-parity bit over Byte0 bits0–6, plus CRC + alive counter (`MSG_CNT`).

## 1.5 Interaction between modules (data flow)

```
IMU + RSU (PSI5) ──► OpsCrashMgr (crash algorithms, T0) ──► Loop firing ASIC
        │                    │                                   │
        │                    ├──► RstEdr (EDR record @ T0)       ├──► FltMonr (deployment DTCs, ECU lock)
        │                    ├──► EnsMgr (ENS PWM invert 800ms)
        │                    └──► CanMgr (STS_CRASH, CRASH_LOCATION, door unlock)
CAN RX (CanMgr) ──► on-fail substitution ──► EDR pre-crash buffer, PADI, VIN check, algorithms
CanNm ──► enables/disables CanMgr TX/RX + network diagnostics
DiagMgr ◄──► FltMonr (19/14/85), DeviceCfgMgr (0101/0102/F190), RstEdr (0455/0456…), IO control (2F)
DeviceCfgMgr ──► RsuMgr / Loop / GPO / DCS enable masks (effective next ignition cycle)
```

---

# 2. Functional Behaviour

## 2.1 ECU operating states

`Initialization → Proveout → Run (Normal / Degraded) → Powerdown / Post-run (housekeeping)`

- **Initialization** (target 350–400 ms for crash output readiness; CAN TX inhibited ≥ 150 ms
  `T[CANInit]`, all cyclic TX started by `T[MessageStart]`, plausible values by `T[SignalValue]`,
  diagnostics available within 500 ms of IGN ON):
  - NVM reads: feature code (EOL), variant code, VIN, fault memory.
  - PDC (Power-up Device Check): loop measurements, GPO configuration detection, RSU phase startup.
  - PABON and PABOFF lamps driven ON (bulb check); `INDC_PADL = 0x1` after CAN init (~1 s).
  - Crash algorithms are **not armed during init** (crash triggered < 450 ms after IGN ON must not
    deploy — verified by ENS test scenarios).
- **Proveout**: lamp proveout — PABON/PABOFF/`INDC_PADL` ON for 6 s then OFF for 1 s
  (CAN signal effectively ~5.91 s due to 70–80 ms CAN init delay), RSU full diagnostic suite
  (configuration, factory data, serial number if cybersecurity enabled, open/STG/STB/internal/comm
  tests, ASIC self-test, PRSU plausibility for door-pressure pairs).
- **Run**: cyclic acquisition (RSU fast runnable 500 µs, slow/report runnable 25 ms; PADI state
  update ≤ 25 ms of PAB state change), continuous diagnostics per DTC-list periodicity, crash
  algorithms armed, EDR pre-crash ring buffers running (−5.0 s window).
- **Degraded operation**: UV/OV (outside ~7–19 V) → CAN network diagnostics stopped, RX signals
  switch to on-fail values, most DTC qualification suppressed (UV/OV DTC itself active, status
  stays `0x08`-style historic behavior per project rule); bus-off → fast then slow recovery; single
  faulted device → function-level degradation + warning lamp, never whole-ECU shutdown.
- **Powerdown / Post-run**: triggered by IGN OFF + NM release; stop RSU acquisition, suspend
  failure detection, write NVM (fault memory, counters, EDR if pending), interrupted post-run
  restarts cleanly. VIN comparison disabled during post-run. Energy reserve (ER) keeps crash
  output/ENS alive and allows **EDR write within 150 ms after power cut during a crash**.

## 2.2 CAN communication behaviour (CAN-C)

- **Media**: CAN FD (DLC 64, E2E Profile 5 CRC on FD frames) + HS-CAN (DLC 8, SAE J1850 CRC-8:
  poly 0x1D, init 0xFF, XOR-out 0xFF, check 0x4B, magic check 0xC4, data bytes 0…63).
- **TX timing tolerance**: < 10 % for periods < 100 ms; < 3 % for ≥ 100 ms. Bus load capped at 80 %.
- **Alive counter (`MSG_CNT`)**: 4-bit, increments from 0 each IGN ON / reset. Rollover at **15→0 or
  14→0 selected by EOL Byte6 Bit2** (0 → 0…15, 1 → 0…14). See discrepancy D-03.
- **RX monitoring per message** (uniform pattern across all RX messages):
  - *Node absent*: no message for `u8NodeAbsentDetection × cycle_time` while network diagnostics
    enabled → `<NODE>_NODE_ABSENT` DTC; heal after ≥ 80 % of `u8NodeAbsentRecovery` expected
    messages within `u8NodeAbsentRecovery × cycle_time`.
  - *Message content failure* (one DTC, three causes): wrong DLC (frame ignored, debounced),
    CRC error (checked only when DLC OK), alive-counter error (checked only when DLC + CRC OK) —
    `u8MsgContentErrorDetection` consecutive bad → qualify; `u8MsgContentErrorRecovery` consecutive
    good → heal. Evaluation order **DLC → CRC → alive counter** is mandatory.
  - *Signal content failure*: signal-level invalid value (per DBC "invalid" encoding) — only
    applicable if the DBC defines an invalid/reserved code for that signal.
  - Until a fault **matures**, last valid value is retained; **after** qualification the received
    signals switch to **on-fail values** per the On-fail Specification matrix (§ 2.8).
  - When a node-timeout DTC is entered, further monitoring of that node's messages stops until heal.
- **Missing-ACK strategy**: transmitter keeps retransmitting (hardware automatic retransmission)
  until `TTimeout`; then CAN controller re-init and wait `TRecovery`; RX stays alive; ECU must not
  treat missing ACK as bus-off; timeout monitoring unaffected. (Consistent with ISO 11898-1: ACK
  errors drive the node only to error-passive, not bus-off.)
- **Bus-off recovery**: fast recovery strategy × `Fast Bus off Recovery Count`, then slow recovery;
  each = re-init controller immediately, pause TX until fast/slow recovery time expires, RX active,
  then resume. Both CAN channels handled; application records the bus-off DTC.
- **Voltage-gated network diagnostics**: diagnostics start after `u8NmIgnStrtupDel` ("NM IGN On
  Startup Delay", default 2000 ms, includes `TOSinitial`, configurable via **DID $0103**) with
  supply within `VNW_Diag_Low_OFF…VNW_Diag_High_OFF`. Out-of-window for `u8AbnormalVolPresentTime`
  → stop diagnostics + switch RX to on-fail values. Recovery restarts after
  `u8NmIgnStartupDelAftrUndrVolRec` / `…OvrVolRec` ("NM Restart Delay"). If T15 outside
  `VComm_Lower…VComm_High` for `TCommPresent` → stop CAN communication entirely; restart after
  `TCommAbsent` in-window.

## 2.3 Network Management (AUTOSAR CanNm profile)

States: `BUS_SLEEP → REPEAT_MESSAGE → NORMAL_OPERATION ⇄ READY_SLEEP → PREPARE_BUS_SLEEP → BUS_SLEEP`.

- Network **requested** when `Ignition_Signal == ON`; kept awake by `ACTIVE_WAKEUP_BIT` in received
  `CANNM_PDU` or `PKE_CLMP_State ∈ {0x2,0x3,0x4}` (FR_ZONE2 / PKE clamp state).
- Timers: `CANNM_RepeatMsgTimer` (expiry `P_NmAsrRepeatMessageTime`), `CANNM_Timeout_Timer`
  (`P_NmAsrTimeoutTime`), `CANNM_BusSleepTimer` (`P_NmAsrWaitBusSleepTime`),
  `CANNM_FrZone2_Timer` (`P_CanNmMsgTimeoutTime`). `SRS_CANNM` TX period `P_NmAsrCanMsgCycleTime`.
- Communication gating: BUS_SLEEP → all TX/RX disabled; REPEAT_MESSAGE → RX + app TX enabled, NM TX
  enabled only for active wakeup (passive wakeup on first ECU wake keeps NM TX off);
  NORMAL_OPERATION → app TX enabled **with ~350 ms delay**, NM TX disabled; READY_SLEEP → NM TX
  disabled, app com enabled; PREPARE_BUS_SLEEP → only NM RX enabled. On PREPARE_BUS_SLEEP entry
  with AWB cleared, `IGN_STS_SRS` switches to IGN_OFF after `P_IGN_STS_AWB_Clear_Delay`.
- On transition PREPARE_BUS_SLEEP → REPEAT_MESSAGE, re-enable diagnosis of message/signal content
  failures. **VC error, node absent, DLC, message/signal content failures must never affect NM
  state transitions** — NM robustness is independent of application-level CAN faults.
- CAN wakeup (IGN OFF) is a first-class operating mode: deployment determination, diagnostics,
  fault management and GPO management all run on valid CAN wakeup, and every ENS/EDR/VIN behavior
  must be tested both for HW IGN ON and CAN-wakeup.

## 2.4 Crash detection, deployment and post-crash behaviour

- Crash algorithms: Front, Side (L/R), Rear, Rollover, Underbody, Near-crash (non-deploy).
  Algorithm wake-up with no algorithm running defines **T0 (Time Zero)** = EDR Event Start.
- Deployment inhibits: init time (< 450 ms), VIN mismatch active (see D-01), loop de-configured via
  EOL (only that loop inhibited), `PSGR_AIRBAG_SW_IC = PAB OFF` + PABD-via-CAN feature → passenger
  airbag suppressed.
- Post-deployment: `STS_CRASH = 0x1` on `SRS1_FD_10`/`SRS1_20`, `CRASH_LOCATION` set with the
  multi-event priority order, door-unlock request, ENS PWM inversion for 800 ms, EDR record +
  lock, crash DTCs (e.g. `906196` ECU LOCKED DUE TO FRONT CRASH, `921A00` ECU LOCKED DUE TO
  PRETENSIONER DEPLOYMENT, side `920100`, rear `921E00`; status byte `0x8B` = testFailed +
  confirmed + pending + warningIndicatorRequested pattern used by this project). After a
  deployment-lock DTC the ECU is **crash-locked**: DTC clear ($14) will not remove lock DTCs
  (positive response but crash DTCs and EDR persist) — replacement of ECU is the service action.

## 2.5 GPO functional behaviour

**GPO0 — Crash output / ENS (Event Notification Signal), eCall trigger line**
- PWM, fixed 40 ms period. Normal: 25 ms high / 15 ms low (**62.5 % duty**). During deployment:
  inverted — 15 ms high / 25 ms low (**37.5 % duty**) for **20 cycles = 800 ms**, then back to
  normal. Near-crash: duty unchanged (no inversion), no crash DTC.
- Init: constant high 350–400 ms (must be < 450 ms) then PWM starts. If crash occurs at the PWM
  low phase, first inverted pulse starts on the low side, still 37.5 % for 800 ms.
- Feature disabled via EOL (crash-output bit): init pulse until PDC completes, then **constant
  high** (one variant documents constant low — see D-06); de-configured DTC `923456`.
- Fault signatures: **STB → PWM stuck low** (DTC `921812`), **STG → stuck high** (`921811`),
  **OPEN → pulse amplitude drops ~50 %** (`921813`). During an ENS fault, a crash must **not**
  invert the PWM — it stays in the fault signature.
- Power robustness: if IGN or BATT is cut ≥ 50 ms after crash, PWM holds 37.5 % duty for the
  remaining 800 ms from the **energy reserve (ER)**; in normal drive the 62.5 % PWM likewise
  persists through IGN/BATT cut while ER charge lasts.

**GPO1 / GPO2 — PADI lamps (low-side drivers)**
- GPO1 = PAB-ON lamp, GPO2 = PAB-OFF lamp. Low-side: output constant **low = lamp ON**,
  constant **high = lamp OFF**.
- `PSGR_AIRBAG_SW_IC` (in `HPCC_1_100` FD / `IC2_100` classic) = 0x0 → PAB enabled: PABON lamp ON,
  PABOFF lamp OFF, `INDC_PADL = 0` (lamp off). = 0x1 → PAB disabled: PABOFF ON, PABON OFF,
  `INDC_PADL = 1`. `IC2_100` node absent → PADI-lamp-ON output low (lamp ON), PADI-lamp-OFF high;
  `INDC_PADL` behaves as Lamp OFF for PAB-ON-side conditions (project-specific fail-safe: show
  "passenger airbag enabled" indication as default). IO-control override via SID $2F also forces
  `INDC_PADL` Lamp OFF.
- Electrical behavior: STB → pin constant high; STG → pin constant low; OPEN DTC → GPO1 high /
  GPO2 high; EOL configuration error → PADI-lamp-OFF constant high.
- Lamp DTCs (M314 numbering): PABOFF `921013/921011/921012/921064` (open/STB/STG/config),
  PABON `902413/902412/902411/902464`; **mature 2 s / de-mature 4 s**. During UV/OV all GPO DTCs
  are suppressed and report only after return to 7–19 V.

## 2.6 RSU (PSI5 satellite) behaviour

- PSI5 v2.1, up to 8 logical channels (`DEVICECFGMGR_ASIC_CH0…CH7`), acceleration satellites
  (120g/240g, alpha/gamma) and door-pressure satellites (15 %), single/dual/quad time slots
  (high-speed slots: 44–144/144–244/244–344/344–450 µs; low-speed: 44–184/184–340/340–480 µs);
  internal/external busing pairs (e.g. A-pillar FRSU + C-pillar SRSU share a channel).
- Satellite startup phases: **Ph1** (sync detect) → **Ph2** (factory data: manufacturer, date,
  serial; serial-number check when cybersecurity enabled) → **Ph3** (self-test status) → **Ph4**
  (cyclic sensor data, `u8SS_PDC_OK`). Support states: `WATCH, IGNORE, QUIET, DEPOP→NOPOP, STOP→OFF,
  REBOOT→OFF, FAULT→ERROR (terminal, do-nothing)`.
- Retry management: `RSU_Fault_Counter` / `RSU_Retry_Counter` vs `RSU_Retry_Goal` (satellite) and
  `Channel_Fault_Counter` / `Channel_Retry_Goal` (channel); REBOOT on fault-counter ≥ goal, FAULT
  on retry-counter ≥ goal. `Immediate_fault_report` cal bits choose report-on-detection vs
  report-on-confirmation separately for startup and drive.
- Error classes: OPEN (≥ 180 ms NODATA), COMM/INVALID (non-PSI5-2.1 device), STG, STB, INTERNAL
  (bad Ph2/Ph3/Ph4 sequencing, too many self-test messages, out-of-range data), CFG (satellite in
  wrong slot: accel `7193`, pressure `719B` families). Full DTC map per position:
  FRSU `8090xx/8095xx`, B-pillar SRSU `920Axx/920Bxx`, pressure `9212xx/9216xx`, C-pillar
  `921Bxx/921Cxx`, A-pillar `9236xx/9237xx`, rear `9238xx` (suffix xx: 13 open, 11 STG, 12 STB,
  81 comm, 96 internal, 64 config).
- **Qualification/dequalification is immediate**, but dequalification (heal to historic) only takes
  effect at the **next ignition cycle**; on active RSU DTC, warning-lamp status must be asserted.

## 2.7 EDR behaviour

- Enabled only when `EDR_CONFIG` (EOL) set. Managed cyclically; records to **two EEPROM areas**.
- **Event definitions**: T0 = first algorithm wakeup with none running; Event End = all algorithms
  reset. Event number increments per trigger (near-crash and deployable). **Single event**: ΔT0 to
  previous > 5 s (or additional triggers between Start and End). **Multi-event**: 800 ms < ΔT0 ≤ 5 s
  (EDR1 `TimeBetweenEvents = 0xFFFF`, EDR2 < 5 s, event number n+1).
- **Record triggers**: any squib deploys; confirmed crash with ΔV > 8 km/h within 150 ms;
  underbody-strike crash. Near-crash records but does **not lock**; a later real crash overwrites.
  Deployment locks the record (lock status flag; record 0x1 deploy / 0x0 near-crash).
- Data content: pre-crash window −5.0 s…T0 (CAN signals sampled per edr_config interval, e.g. 16
  samples at 500 ms for `VehSpdLgt`), at-T0 snapshot (battery voltage, odometer, clock, belt/ODS/
  OCS states, lamp status, tyre pressures, gear, ABS/ESC/TCS flags, ADAS states), post-crash /
  deployment data (ΔV, deployment times, loop status), sensor traces (IMU + RSU + SCS
  longitudinal/vertical for underbody). Odometer/event date/time have **no recording range** (single
  values, not arrays) — comparison logic must treat them as scalars.
- On-fail substitution during recording follows the **On-fail Spec** (§ 2.8): during an active CAN
  fault, affected pre/post-crash samples show last-valid or default per the matrix; samples before
  fault-start and after heal show simulated/live values. `STS_ENG` special case: message-timeout
  qualification takes ~10 s when signal is 0x1/0x5 (cranking), dequalifies ~500 ms after value 0 —
  pre/post-crash fault scenarios are not practical for it.
- Reads: Mahindra records DID `$0455/$045B/$045D` (records 1–3), supplier records
  `$0456/$045C/$045E`, additional-info DIDs `$045F…$049C`, crash counter `$0458`; roll-over sensor
  arrays `$0477/$0478`. Reading is allowed only after recording completes; **CAN-fault DTC status
  `0x0B`** when active; UV/OV DTC status stays `0x08`; post-crash-healed CAN DTCs read **historic
  (`…08`) if an ignition cycle occurred before Read-DTC**, else healed.

## 2.8 On-fail signal substitution matrix (U171 On-fail Spec V1.1/V2.0 — normative)

Reaction vocabulary: **Consume the value** (use as received), **Last valid value** (hold),
**Default value** (substitute signal default, usually 0x0). Failure columns: Signal never received
(node disabled in VC), Signal invalid, Reserved/Out-of-range, Message timeout, Node absent,
**Variant-code error → Default value**, Message content failure, UV/OV, Bus-off, Network security
failure.

General pattern for EDR-feeding signals (`ABSOLUTE_ANGLE`, gear, `BRK_PEDAL1`, `CLUTCH_STS`,
`ACC_PED1`, `ENG_SPD1`, speeds, `MASTER_CYL_PRESSURE`, TCS/ABS/ESC flags, accel/yaw, odometer,
clock, tyre pressures, ADAS warnings…): timeout/node-absent/MCF/UV-OV/bus-off → **last valid
value**; VC error → **default**; invalid/reserved codes → consume (they are recorded as-is).
Notable exceptions:
- `VIN_DATA_x` / `VIN_INDEX` (EMS5_500): affects deployment (see D-01); invalid/out-of-range →
  last valid value.
- `PSGR_AIRBAG_SW_IC` (IC2_100): **all failure modes → default (0x0 = PAB ON)** — fail-safe toward
  deployment-enabled with PAB lamps signalling.
- `VEHICLE_SPEED_ESC12` reserved/out-of-range → clamp to DBC max 300 km/h.
- `GW_HEARTBEAT` signals: used **only** for node-absent detection; all signal values treated as 0.
- Signals whose "default" is a reserved code (e.g. `STS_DOOR_LATCH` 0x2, `AEB_WARNING_MSG1` 0x5,
  `NP_SYS_STS1` 0x3–0xF): never-received uses that reserved encoding; MCF consumes.
- Reserved/out-of-range fault injection is only valid when the DBC leaves numeric headroom
  (raw max > physical max); if the DBC has no invalid value, **signal-content-failure does not
  apply** to that signal.
- Key-message list (W616): `EMS3_10` 0x108, `ESC5_10` 0x10D, `IC2_100` 0x340, `IS1_100` 0x220,
  `MBFM1_100` 0x348, `TCU5_10` 0x136, `EPS_SAS1_10` 0x114, `FCM1_20` 0x24D, `FRM2_20` 0x24C,
  `GW_HEARTBEAT` 0x283, `HPCAd_31_10` 0x14C. **Node absent** = key message stopped;
  **message timeout** = a slave (non-key) message of that node stopped; if a node has no slave
  message, the timeout case does not exist for it. If the timeout is created on a message other
  than the one carrying the signal under test, the signal keeps being consumed (not last-valid) —
  test design must stop the exact message that carries the signal.

## 2.9 EOL / Variant Code / VIN behaviour

**Feature code (EOL, DID $0102, 20+ bytes bitmap)** — physical equipment of THIS ECU:
loops byte0 (PAB, DAB, side L/R, curtain L/R, knee, far-side) + byte1 (PT L/R, lap PT L/R, load
limiter L/R, row-2 PTs), RSU byte1 bit7–byte3 bit2, PABD switch b3.3, buckles b3/b4/b5,
ODS b4/b5, STPS b7 (driver zone-1 b7.2, co-driver b7.4), DOMS b6.3, OCS b6.4, PAB lamps b5.3/b5.4,
PAB mode b5.5 (0 semiauto / 1 automatic), crash-output / eCall line b6.0, alive-counter-range b6.2,
NM-test-message b6.1 (obsolete). Virgin default per variant (e.g. M314
`2E 01 02 FF BF FF AF FE 0F 3D 14 03 00…`; W616 `7F 0F 0F AB 2A 18 01 00…` — variant-specific).
Write gates: extended session + security L1, speed < 5 km/h (or default 0xFFFE), no
`SRS_ECU_INTERNAL_ERROR`, valid vs fixed-EEPROM capability, min 1 loop + 1 RSU, PAB-consistency
rules (PAB configured ⇔ PABD lamps + switch source configured), no reserved bits. NRCs: 31
(reserved bit / internal error / invalid combination / all-RSU-void), 13 (unintended config),
88 (speed), 33 (security). Effective **next ignition cycle**; survives CAN flashing.
Mismatch physical-vs-EOL: enabled-but-absent → device **open fault**; disabled-but-present →
device **unexpected-load / configuration error** + `ECU_CONFIGURATION_ERROR` (`9202-00` /
0xB120200) — electrical faults take priority over unexpected-squib/config faults; warning lamp
(`INDC_SRS`) stays ON while config error active. De-configured loops must still be diagnosable for
open/unexpected-squib/electrical; de-configured loops are **inhibited from deployment**.

**Variant code (DID $0101, 20 bytes)** — presence of OTHER nodes on CAN: EMS, ABS, ESC/IEB, EPS,
SAS, PKE/SKM, ICU, SRS (byte0 bit0 = self; 0 → variant-code DTC), PODS, EPB, ESCL, TCU, AMT, ITM,
TC, CNG, DCT, E-braking, IC, MBFM/BCM, HVAC/FATC, ETC, EVDC, ACC, PTC, HLCU, WLC, SCM…
Write gates: extended + L1, speed < 5 km/h (NRC 88), allowed even with internal DTC active.
Effective after IGN toggle / ACU sleep; VC error **not recoverable within the ignition cycle**;
survives flashing. Mutual-exclusion pairs → SRS-variant-code error if **both** set: ABS+ESC,
AMT+TCU, PKE+ICU, FATC+ETC, TC+ITM. Gear-source arbitration: EMS+TCU → TCU (`CURRENT_GEAR_MT`
ignored); EMS only → EMS; TCU only → TCU. Node enabled → process its messages + monitor DTCs +
record EDR on-fail per spec; ABS enabled (ESC absent) → `LATTERAL_ACCEL/LONG_ACCEL/YAW_RATE`
recorded as 0 in EDR. Disabled node → treated as not installed (no monitoring, "signal never
received" reactions); partner-ACU functionality disabled for the cycle when partner not configured
or SRS-VC error.

**VIN (DID $F190, 17 bytes, EMS5_500 3-frame multiplex `VIN_INDEX` 0/1/2, 500 ms each → 1.5 s/set)**
Virgin default: all bytes 0x39 ('9'). Write: L1 unlocked, any hex accepted, NRC 88 above 5 km/h;
survives flashing. Validation only during IGN-ON/CAN-wakeup init, starting after NM startup delay
(default 2 s; +NM-restart delay after UV/OV/bus-off/cranking recovery); paused/skipped while
bus-off, UV/OV, VC error active, VIN-master node-absent, VIN-master key MCF, or cranking
(`STS_ENG` 0x1 T50 / 0x5 ESS; if cranking persists > 10 s, validate anyway per DID $0103
parameters). First matching full set stops further comparison; mismatch increments comparison
counter — **3 consecutive failed sets → `VIN_MISMATCH_ERROR`**; incomplete index set at check time
also qualifies; qualification window bounded by VIN-DTC qualification time; `EMS5_500` never
received → VIN-mismatch DTC qualifies. All-zero received & stored, or zeros-vs-nonzero → mismatch.
Both-default-0x39 → contradictory requirements (D-02). After validation passes, DLC-error
monitoring for the VIN message is suppressed. **Deployment inhibited while VIN mismatch active**
(D-01 — verify!). Comparison disabled during post-run.

## 2.10 DCS / occupant sensing behaviour (bench-relevant physics)

- Buckle switches are resistance-coded: **200 Ω = unbuckled, 800 Ω = buckled**; valid only when the
  seat's ODS reports Present. ODS: **200 Ω = present, 800 Ω = not present**; fault = bus + VBAT
  leakage (reads "Faulty"). Reserved buckle status exists only < 300 ms at IGN ON.
- STPS (seat-track position, Hall current): **Zone 2 (far) = 5.0–6.9 mA** (≈1739–2400 Ω @12 V,
  bench: 6 mA relay RL2), **Zone 1 (close) = 12–17 mA** (≈706–1000 Ω, bench: 15 mA RL1 or 800R);
  7–11.9 mA is an undefined intermediate band → report Faulty/last-zone per cal. Only driver +
  passenger STPS enabled on this project. OCS arrives via PODS CAN (0x5FF), ~1 s update latency.
- DCS fault families (FltMonr event groups): unexpected-load, cross-connect, too-low, bad-sensor,
  too-high, open, short-GND, short-plus, internal, SPI (22 channels each).

## 2.11 Fault management behaviour (FltMonr / DEM)

- Counter-based debouncing per event (AUTOSAR DEM style): `DebounceCounterIncrement/DecrementStepSize`,
  `FailedThreshold` (max 127), `PassedThreshold` (min −128), optional jump-up/jump-down; or
  "Monitor Internal" (module-managed) debounce. ~1590 configured fault events.
- **Enable conditions** (max 8; includes UNDER_VOLTAGE / OVER_VOLTAGE) inhibit qualification;
  **SuspendDiagnostics groups** (GPO group, DCS group, LOOPS group) allow bulk suspend/resume, e.g.
  during IO control or deployment. UV/OV: suppress dependent DTCs, report after voltage normal.
- Status bytes follow ISO 14229 DTC status semantics; project shorthand: active = `0x0B`
  (testFailed+testFailedThisCycle+pending... project-observed), crash-lock DTCs read `0x8B`
  (confirmed+…+warningIndicator), historic = `0x08` (confirmed only), UV/OV remains `0x08` even
  when the condition is present. Extended data: `$01` frequency counter, `$02` operation cycles,
  `$FF` both. Snapshots: Record 1 = oldest/original, Record 2 = most recent, with freeze-frame
  DIDs (Table-39 set) captured at set **and** at heal.
- Aging/dequalification policy is per-fault (e.g. GPO 2 s/4 s; RSU immediate-qualify,
  next-ignition heal; CAN faults per Table-2 counts).

## 2.12 UDS behaviour summary

See § 4.3 / § 10 for the service catalogue; behavioural highlights:

- After IGN ON: default session; diag available < 500 ms; DLC 8 (HS) / 64 (FD), shorter frames
  ignored; physical `$730`→`$738`, functional `$7DF`→`$738`; unsupported SID on physical → NRC;
  unsupported SID/SF on functional → **no response** (per ISO 14229-1 functional-addressing rule).
- P2server = 50 ms, P2*server = 5000 ms (session-control response `50 03 00 32 13 88`); NRC $78
  when exceeding P2; S3 timeout returns to default session; `suppressPosRspMsgIndicationBit`
  honored everywhere it is legal; where SPR is not supported ($10 default/programming, $11, $14)
  the project returns **NRC 12** on SPR bit — see D-07. Flow control TX: BS=0, STmin=0; received
  BS/STmin accepted without validation as zero.
- Sessions: default $01, programming $02 (entry only from extended + security **L3**, speed
  < 5 km/h else NRC 88), extended $03 (SPR allowed). Security: L1 (seed $01/key $02) for extended;
  L3 (seed $05/key $06, 8-byte seed/key; variant also documents $05/$06 as seed/key SF pair) for
  programming. Anti-brute-force: NVM attempt counter; NRC 36 from 11th attempt (carried across
  ignition cycles; special 2nd-attempt rule after a carried-over lockout), NRC 37 for violated
  3 s inter-attempt delay (from 3rd attempt) and 5 s post-reset delay; max 5 successful L1 unlocks
  per cycle; seed re-request while unlocked returns all-zero seed; key-for-zero-seed → NRC 24;
  invalid key → NRC 35.
- $14 clearDTC only with `groupOfDTC = $FFFFFF`; positive response even when memory empty;
  crash-locked DTCs and EDR survive; NRC 22 in plant mode. $19 SFs: 01/81, 02/82, 04/84 (snapshot),
  06/86 (extended data), 0A/8A; supported status-mask bits 0,1,3,6,7. $22/$2E per DID table
  (§ 10.2), multi-DID rules (§ 10.2). $28 communicationControl: SF 00–03, com types 01/02/03 —
  only app messages (13C/2C0) actually gated; NM type answers positively with no action. $2F IO
  control: extended session only, SFs returnControlToECU/resetToDefault/freezeState/
  shortTermAdjust(states 00/01, else NRC 31). $31 routines (start only), $3E testerPresent,
  $85 controlDTCSetting ON/OFF (OFF also stops CAN-C diagnosis), $83 accessTimingParameter SF $04.
  $34/$36/$37 programming-session only (bootloader § 2.13).

## 2.13 Bootloader / reprogramming behaviour

Standard two-stage UDS flash sequence (ISO 14229-1 + ISO 15765-2), tested against S-Record (.s37)
images (S0 header / S3 data, 4-byte address / S7 terminator; per-record checksum = one's complement
of length+address+data LSB):

1. App: `10 03` → `85 02` (DTC off) → `28 03 03` (com off) → `27 05/06` (L3) → `10 02` → ECU
   reboots into boot (response `50 02` from boot; app→boot transition preserves programming
   session).
2. Boot: security re-auth, erase (RID via `31 01 FF00`-class), `34` requestDownload (addr+size),
   `36` transferData with block-sequence counter (wrong BSC → NRC 73; repeated block → tolerated
   once per ISO), `37` transferExit, checksum/signature verify RID, app-validity flag write,
   `11 01` reset.
3. Robustness: programming-session S3 timeout in boot without valid app → stay in boot;
   with valid app → jump to app. NRCs per ISO: 13/22/24/31/33/35/36/37/70/71/72/73/7E/7F.
   Feature code, variant code, VIN, EDR, fault memory **must survive flashing**.
   Boot version DIDs: `$F180` boot SW id, boot flag `$200`, history zone `$201`, `$F1B7` EEPROM
   layout version.

---

# 3. Requirement Analysis

> The source trackers contain ~6,000 requirement rows. This section does not restate them; it
> analyses each requirement **cluster** with interpretation, rationale, standards validation, and
> known defects. Requirement IDs cited are representative anchors from the exports.
> **Discrepancy register D-xx is the most important part of this section — treat every D-xx as a
> "do not blindly implement/trust" flag.**

## 3.1 Discrepancy / ambiguity register (validated findings)

**D-01 — VIN mismatch inhibits deployment (VIN tracker, "The software shall inhibit the deployment
when the VIN mismatch DTC is active").**
*Requirement says*: active `VIN_MISMATCH_ERROR` → inhibit deployment.
*Industry standard says*: restraint deployment availability must not depend on vehicle-pairing
plausibility data. ISO 26262 hazard analysis ranks "failure to deploy in a crash" as a
safety-goal violation (typically ASIL C/D); VIN mismatch is a theft/part-swap indicator (QM/anti-
tamper), and no mainstream OEM/Tier-1 blocks deployment on it — the common reaction is warning
lamp + DTC + optionally blocking *configuration writes*.
*Recommended implementation*: escalate to OEM safety team with an ISO 26262 impact analysis before
implementing. If contractually forced, gate the inhibit behind an unambiguous, EOL-controlled
feature bit, ensure the warning lamp is ON whenever deployment is inhibited (SG4), and record the
inhibit state in EDR. Never let a transient VIN-comparison state (e.g. during the 2 s NM delay)
inhibit deployment — only a *qualified, matured* DTC may.

**D-02 — Contradictory VIN default-value requirements.** Two approved requirements state for
"received = stored = all 0x39": one says *VIN_MISMATCH_ERROR will NOT be set*, the other *will be
set*, for the identical condition.
*Interpretation*: factory state (both default) must not raise the DTC — otherwise every virgin
vehicle leaves the plant with an airbag warning (and, with D-01, no deployment).
*Recommended*: treat both-default as **no mismatch** (matches "failure case" wording of the first
requirement and plant logistics); raise a requirements-clarification issue to obsolete the second.

**D-03 — Alive-counter rollover 15→0 vs 14→0 stated simultaneously.** CAN-C TX requirement lists
"Once it reaches 15 it would roll back to 0. Once it reaches 14 it would roll back to 0." with no
condition.
*Resolution*: the EOL tracker resolves it — **Byte 6 Bit 2 of the feature code selects the range**
(0 → 0…15, 1 → 0…14). AUTOSAR E2E Profile 5 uses 0…14 (0xF excluded); plain 4-bit counters use
0…15. *Recommended*: implement both ranges behind the EOL bit; never hard-code; the receiver check
must use the same range as the transmitter or MCF false-positives will occur exactly at rollover.

**D-04 — DLC acceptance: "smaller than 64" vs "not equal to 64".** The generic CAN-C rule says
ignore RX if DLC < 64; the per-message RX requirements say ignore if DLC ≠ 64.
*Industry standard*: CAN FD DLC codes are discrete (…, 32, 48, 64); a frame larger than expected
usually indicates DBC mismatch. Receivers commonly accept ≥ expected length (tolerant receiver,
AUTOSAR `ComIPduRxLengthCheck` semantics) or exact-match per OEM rule.
*Recommended*: exact-match (≠ 64 → ignore + debounce MCF) since the per-message requirements and
the tests (`u8MsgContentErrorDetection`) assume it; align the generic requirement text.

**D-05 — PABON/PABOFF wording swaps.** GPO reqs `31300826/31300827` swap "Enable"/"Disable"
between title, description and verification criteria (e.g. summary "Set …Disable_Indicator…
LAMP_ON" describing PABON). Similarly DID $044A description says byte0 bit1 for PAB-OFF while the
verification text says bit3, and `31300840/41` mix DID 0448/044A.
*Recommended*: trust the *behavioral* invariants: at init both lamps ON (bulb check); runtime
PABON = NOT(PSGR_AIRBAG_SW_IC), PABOFF = PSGR_AIRBAG_SW_IC; $044A byte0 bit0 = PAB-enable lamp
state, bit1 = PAB-disable state. Verify against the released DID decoder table (ECU Identifiers
tracker), not the prose.

**D-06 — Crash-output-disabled level: constant high vs constant low.** Two adjacent approved
requirements in Process-GPO differ (maintain high vs maintain low after PDC identifies disabled
feature).
*Recommended*: constant **high** matches the ENS test prompts ("pulse stays always high" when ENS
de-configured via EOL) and the fail-safe convention (receiver treats sustained low as crash-
asserted on some eCall lines). Confirm with the eCall-module ICD; the receiving TCU defines which
idle level is "no crash".

**D-07 — NRC for suppressPosRspBit on services where SPR is "not supported".** Project returns
NRC $12 when the SPR bit is set on $10-default/programming, $11, $14.
*Industry standard says*: ISO 14229-1 treats the SPR bit as part of the sub-function byte; a server
that does not support suppression for a sub-function should still execute and respond positively
(bit is informative), or reject with $12 only if the resulting sub-function value is genuinely
unsupported. Many OEMs, however, specify exactly this NRC-12 behavior.
*Recommended*: implement per requirement (NRC 12) — it is testable and deterministic — but document
the deviation from strict ISO reading in the DCM configuration notes.

**D-08 — "Bit8 of Byte0/Byte1" in EOL loop map** (row-2 pretensioners). Bytes have bits 0–7.
*Interpretation*: 1-based carry-over into the next byte (bit8 of byte0 ≈ bit0 of byte1) or a
copy-paste from a 16-bit word layout. *Recommended*: resolve against `DeviceCfgMgr_NvmConfig`
fixed-EEPROM layout before coding; never guess bit positions for anything that gates a squib.

**D-09 — RSU channel table duplicates** (`DEVICECFGMGR_ASIC_CH6 ((uint8)5)`, `CH7 ((uint8)6)` in
`31332342`). Obvious enumeration typo (should be 6 and 7). All the CH0/CH1 dual-mapping rows
(A-FRSU + C-SRSU internal busing) are intentional (two satellites bused on one channel with
different time slots), not typos.

**D-10 — Message-timeout vs consumed-value test-design trap** (canc_onfail notes): if the timeout
DTC is provoked by stopping a *different* message of the node than the one carrying the signal
under test, the signal under test keeps updating (consumed), so "last valid value" expectations
fail. This is a *test-design* constraint, but the implementation must also ensure per-message (not
per-node) on-fail switching. Verify `canc_config` maps each fault case to the message that
actually carries the parameter.

**D-11 — EOL default feature code: three different "approved" defaults** (M314 vs two W616 rows).
These are per-variant plant defaults. *Recommended*: key the default block by variant/part number
in fixed calibration; never merge trackers across variants without filtering the `_Projects`/
Release column.

**D-12 — `INDC_PADL` "Lamp OFF" when IC2_100 node absent vs PADI HW lamp ON.** Process-GPO says
node-absent → PADI-lamp-ON output low (HW lamp ON) but `INDC_PADL` sent as Lamp OFF. This is
intentionally asymmetric (cluster cannot show a lamp for a bus that is dead anyway), but easy to
"fix" wrongly during maintenance. Keep the asymmetry; document it in code.

## 3.2 Cluster-by-cluster analysis (why the requirements exist, edge cases)

**CAN init timing (`T[CANInit] ≥ 150 ms` no-TX, ready < 500 ms, cyclic start < T[MessageStart])**
— *Why*: bus-wide start-up choreography; transmitting before other nodes ack causes error frames
and false bus-off at network level; 150 ms floor prevents ACU flooding a waking bus. *Edge cases*:
reset via $11 (must re-honor timing), CAN wakeup vs HW ignition (both must meet it), UV during
init (diagnostics gated separately).

**Node monitoring family** — *Why*: distinguish "node dead" (key message, whole-node reaction,
affects all its signals) from "single PDU lost" (timeout) from "data corrupted" (MCF) from
"data implausible" (SCF). This 4-level model mirrors AUTOSAR ComM/E2E practice and drives
different EDR substitutions. *Edge cases*: heal criterion is statistical (≥ 80 % of expected
messages within recovery window) — a marginal 79 % reception must not heal; monitoring pause after
bus-off recovery; monitoring disabled below NM-startup delay and in UV/OV; per-node suspension
when node-timeout DTC entered (avoid DTC storms).

**CRC/alive-counter checks ordered DLC→CRC→AC** — *Why*: each check is only meaningful when the
prior layer is intact (CRC over garbage length is undefined; AC of a corrupt frame is noise).
Prevents double-counting one physical corruption into multiple debounce counters.

**NM state machine** — matches AUTOSAR CanNm (BusSleep/PrepareBusSleep/RepeatMessage/ReadySleep/
NormalOperation); passive-wakeup NM-TX suppression on first wake implements "passive startup"
(NmPassiveModeEnabled semantics) so a diagnostic wake doesn't keep the whole network up. The 350 ms
app-TX delay in NormalOperation gives partner ECUs time to enter RX-ready. The "faults never move
NM states" rule prevents a babbling application error from deadlocking network sleep (availability
requirement). *Edge case*: AWB clear during PREPARE_BUS_SLEEP → delayed `IGN_STS_SRS = OFF`
(`P_IGN_STS_AWB_Clear_Delay`) so receivers see a clean ignition-status transition.

**Security-access counters in NVM** — *Why*: ISO 14229 $27 anti-brute-force must survive battery
pulls; the "NRC 36 from 11th attempt carried across cycles" and "3 s / 5 s delays" implement
exponential-cost attack throttling. *Edge cases*: counter reset rules (successful unlock), NVM
write failure while counting (fail closed — keep lockout), seed re-request while unlocked returns
zero-seed (ISO-conformant "alreadyUnlocked" signalling), key-for-zero-seed → NRC 24.

**EOL/VC/VIN write-gates (speed < 5 km/h, NRC 88)** — NRC 0x88 (`vehicleSpeedTooHigh`) *is* an ISO
14229-1 defined NRC; using it for config writes is standard practice. Speed source default 0xFFFE
(signal not available) counts as "allowed" for EOL — *edge case*: a broken speed source must not
brick plant EOL flashing, but this also means a moving car with failed speed signal could accept a
write; acceptable because security + session gates remain.

**Loop/RSU/GPO mismatch faults (open vs unexpected-load vs config-error)** — *Why*: separates
harness faults (open on an enabled device) from configuration faults (device present but
de-configured), which have different service actions (repair vs re-EOL). Electrical faults
outprioritize unexpected-load because a short is both more dangerous and masks classification.
De-configured loops staying diagnosable (open/unexpected-squib/electrical) is a Veoneer-platform
behavior enabling plant detection of mis-wired variants. *Edge*: "void config" (all loops or all
RSUs disabled) rejected with NRC 31 at write time AND `ECU_CONFIGURATION_ERROR` if found at init.

**EDR single/multi-event windows (800 ms / 5 s)** — aligned with Part 563 / GB 39732-style EDR
regulations (multi-event = second impact within 5 s; separate records; lock on deployment).
*Edge cases*: T0 during another algorithm's run is NOT a new event; near-crash never locks;
power-loss write path must complete in 150 ms from ER — this drives EEPROM page-write budgeting
and is why EDR data is staged in RAM in write-ready format during the event.

**ENS PWM parameters (40 ms/62.5 %/37.5 %/800 ms/450 ms init)** — the inverted-duty scheme lets the
eCall TCU distinguish: normal (62.5), crash (37.5 for 800 ms), STG (100 % high), STB (0 %),
open (half amplitude), dead ECU (no pulse) — every failure is distinguishable from "crash".
That is the engineering rationale; preserve *distinguishability* in any change.

**PSGR_AIRBAG_SW_IC all-faults→default-0 (PAB enabled)** — fail-operational choice: losing the
switch keeps the passenger airbag ACTIVE (deploy for a belted adult) while both PADI lamps signal
state; suppression only on explicit command. Matches FMVSS-era PADI practice.

---

# 4. Protocol Knowledge

## 4.1 CAN / CAN FD (ISO 11898-1/-2)

- Bit timing (TSEG1/TSEG2/SJW) derived from quartz per CAN spec; FD data-phase BRS per DBC.
- Frames per DBC exports: `SRS_FD_40250…signals.json` / `SRS_HSCAN_40250…` (M310) and
  `U171_SRS_39588…` (U171) are the machine-readable signal DBs the framework uses — **DBC beats
  spec prose** for scaling/offset/invalid values (per canc_onfail guidance).
- Error handling: TEC/REC, error-passive on missing ACK (no bus-off from ACK-only errors),
  bus-off → fast×N then slow recovery (§ 2.2).
- E2E: FD messages Profile-5 (CRC-16 over data+DataID, 8-bit counter 0–14); HS messages SAE J1850
  CRC-8 + 4-bit counter. Even-parity bit on `SRS1` Byte0 is a legacy supplementary check.

## 4.2 PSI5 v2.1 (RSU)

Two-wire current-modulated sensor interface; sync pulses per time slot; Manchester data; phases
1–4 startup (§ 2.6); 125/189 µs slot classes per speed; blank/NODATA detection 180 ms → OPEN;
INVALID → non-2.1 device. SPI bridge ASIC (SB3) between µC and PSI5 front-end; CRC[2:0] over
bits[16:0] and LCID[3:0] on the SPI read path.

## 4.3 UDS ISO 14229 service map (project profile)

| SID | Service | Sessions | Security | Addressing | Notes |
|---|---|---|---|---|---|
| $10 | SessionControl | all | — | phys (03 also func) | resp `50 xx 00 32 13 88`; NRC 88 for $02 if v>5 km/h; $02 only from extended+L3 |
| $11 | ECUReset | ext (L1), prog (L3) | L1/L3 | phys | SF 01 hard, 03 soft; +$80 suppressed forms; NRC 88 rule |
| $14 | ClearDiagInfo | def, ext | — | phys+func | only $FFFFFF; crash-lock survives; plant mode → NRC 22 |
| $19 | ReadDTCInfo | def, ext | — | phys only | SF 01/81,02/82,04/84,06/86,0A/8A; mask bits 0,1,3,6,7 |
| $22 | ReadDataByIdent | def, ext, prog | per-DID | phys | multi-DID rules; NRC 13/31/33/7F priority |
| $27 | SecurityAccess | ext (L1), ext+prog (L3) | — | phys | seed/key SFs 01/02 (L1), 05/06 (L3); lockout counters in NVM |
| $28 | CommunicationControl | ext | L1 | phys+func | SF 00–03 × types 01/02/03; only 13C/2C0 gated |
| $2E | WriteDataByIdent | ext | L1 | phys | NRC flow per NRC_CheckFlow sheet |
| $2F | IOControlByIdent | ext only | L1 | phys | SF 00/01/02/03; DIDs F010–F022 |
| $31 | RoutineControl | prog, ext, safety | per-RID | phys | start ($01) only |
| $34/$36/$37 | Download/Transfer/Exit | prog | L3 | phys | BSC checks; NRC 24/31/71/72/73 |
| $3E | TesterPresent | all | — | phys+func | 00/80 |
| $83 | AccessTimingParameter | — | — | phys | SF $04 only |
| $85 | ControlDTCSetting | ext | — | phys+func | OFF also halts CAN-C diagnosis |

**NRC priority** (per project NRC_CheckFlow, matches ISO general server behavior):
$13 length → $7F/$7E service/SF-in-session → $31 range → $33 security → $22 conditions →
$88 speed → service-specifics ($24/$35/$36/$37/$72/$73). NRC 78 for long-running ops.

## 4.4 Transport & timing (ISO 15765-2)

Normal addressing; SF/FF/CF/FC; server FC = BS 0, STmin 0; network-layer timeouts table (N_As/
N_Bs/N_Cr…) with defined reactions; P2 = 50 ms, P2* = 5 s; S3server timeout (5 s typ.) →
default session + security relock.

## 4.5 DEM / DCM / NVM (AUTOSAR-equivalents)

FltMonr = Dem (counter debounce, enable/storage conditions, freeze frames, extended data,
`ClearEventAllowed` callbacks, event→DTC mapping in `Dem` sheet, UDS status byte);
DiagMgr = Dcm (session/security state machine, DID dispatch, NRC arbitration);
NVM: EEPROM-backed blocks — `DiagMgr_DID_NvmData.u8Variant_Code[0..19]`,
`.u8Feature_Code[0..19]`, `DeviceCfgMgr_NvmConfig.RsuConfig/DcsMapping/OpsActConfig/LampsConfig/
CrashOutputConfig`, security attempt counters, fault memory (30-entry × 8-byte NVM buffer),
EDR areas, life timer, ignition/reset counters, reset reasons.

## 4.6 Other interfaces

SPI (firing ASIC, PSI5 bridge, watchdog companion per SB3 platform), ADC (loop resistance
measurement — DID $0434 ≈ 0x0B40-order raw values, DCS current sensing, T15/T30 voltage),
PWM (ENS output; Saleae-captured in test), GPIO (lamps low-side), OS: 500 µs fast task (RSU/loop
diagnostics), 25 ms slow task (fault reporting, PADI), com task, background NVM. External + window
watchdog per platform (see § 5).

---

# 5. Safety Analysis

## 5.1 Hazards and failure modes → mitigations

| Failure mode | Effect | Detection / mitigation |
|---|---|---|
| Inadvertent squib current | unwanted deployment (SG1) | dual-channel arm+fire (safing: separate sensor/µC path), HS+LS transistor independence, loop diagnostics (LOOP_F_* families: short GND/BATT, low/high res, open, cross-connect, unexpected load, dwell, deploy-command/compare CMT), VRCM/locking/config ASIC checks |
| Missed crash / no deploy | SG2 | RSU redundancy + IMU safing, PRSU pair plausibility, algorithm ASIL decomposition, ER for power-loss ride-through, ENS holds crash signature on ER |
| CAN input corruption | wrong algorithm inputs / EDR garbage | DLC→CRC→AC→range checks, on-fail matrix, VC/node gating, GW signals forced 0 |
| UV/OV | brownout misbehavior | 7–19 V window: suspend diagnostics + on-fail values + DTC suppression; ER completes deployment + EDR |
| EEPROM corruption | wrong config → wrong deployment map | EOL/VC/VIN checksums + virgin defaults + `ECU_CONFIGURATION_ERROR` + config-vs-physical cross-check at every init |
| Stuck lamp driver | driver unaware of fault state (SG4) | GPO open/STB/STG/config detection (2 s/4 s), suppressed in UV/OV, `INDC_SRS` CAN redundancy to HW lamp |
| SW crash / runaway | loss of all functions | external watchdog + reset-reason DID $F1B4, reset counter $F1B5; crash algorithms idempotent from NVM state; post-reset re-init < 500 ms diag |
| RSU wrong-slot swap | wrong crash localization | Ph2 factory-data + config test → `…64` config DTC (7193/719B), sensor not used |
| Diagnostic misuse (IO control while driving) | actuator hazard | $2F only in extended + L1 + (per-DID) speed gates; returnControlToECU on session drop; SuspendDiagnostics groups during control |
| Flash interruption | brick / invalid app | boot-managed validity flag, stay-in-boot rule, NVM (config/EDR) segregation from app image |

## 5.2 Safe states

- **Com loss / bus-off**: keep restraint function on internal sensors, on-fail CAN values; never
  drop deployment capability for bus faults alone.
- **Config error**: warning lamp ON; affected device excluded; rest functional.
- **UV/OV**: diagnostics quiesced; deployment capability from ER as long as physics allow.
- **Post-deployment**: crash-locked (no re-arm), EDR locked, DTC clear blocked for lock DTCs.
- Watchdog reset → full re-init; repeated resets → reset counter escalation (read $F1B5/$F1B4).

## 5.3 Diagnostic coverage notes

FltMonr event families cover: 32-channel loop faults × 14 types + PDC-abort + ASIC (VRCM/locking/
config) + deployment-path (DEP_COMMAND/DEP_CMP/CMT/DWELL), 48-satellite × 7 RSU types + 12-channel
ASIC (SPI/config/CRC-checker), 22 DCS × 10 types, 5 GPO × 8 types, IMU log/range 10 axes.
This maps to high (>90 %) diagnostic coverage on the firing path consistent with ASIL-D single-
point-fault-metric targets; keep the event-ID consecutiveness constraints (Guidelines sheet) —
several AAUs index DTCs arithmetically off the first event ID.

---

# 6. Software Design Guidance

- **Layering** (AUTOSAR-ish, matches AAU list): MCAL/drivers (CAN, SPI, ADC, PWM, EEPROM) →
  ECU-abstraction (Sb3Ex3GpoDrvr, PSI5 bridge, loop ASIC) → services (FltMonr, DiagMgr, NvM, CanNm)
  → application (OpsCrashMgr, RsuMgr, EnsMgr, Padi, RstEdr, DeviceCfgMgr). Config-by-generation:
  FltMonr tables come from the **Configurator workbook** (edit the workbook + regenerate; never
  hand-edit generated `*_Lcfg` files — mirrors this repo's "edit the generator" rule).
- **Tasking**: 500 µs safety-fast task (sensor acquisition, loop/RSU diagnostics, deployment
  window); 5/10 ms com task; 25 ms slow task (fault report, lamps, PADI, NM); background/idle
  (NVM, EDR write staging). Crash decision and firing must not depend on any lower-priority task
  completing.
- **Interrupts**: CAN RX to ring buffer only (no processing in ISR); PSI5/SPI DMA where possible;
  deployment command is *not* issued from ISR context — it is issued from the protected fast task
  with dual-condition (algo + safing) interlock.
- **Reentrancy**: FltMonr `ReportErrorStatus` is called from multiple tasks → its counter update
  must be atomic (disable-IRQ window or CAS). DID read handlers must be side-effect-free.
- **Memory**: EDR staging buffers in retained RAM sized for 150 ms power-loss write; NVM writes
  through a journal/2-copy scheme (2 EDR areas, config blocks with CRC); no dynamic allocation
  (MISRA dir 4.12); const-qualified generated tables in flash.
- **State machines**: implement NM/RSU/session state machines as table-driven explicit-state
  (enum state + transition table), never as nested flags; every state handles every event
  (default = stay + log).
- **MISRA C:2012** mandatory/required compliance with documented deviations; ISO 26262-6 coding
  guidelines (single exit discouraged exceptions, no recursion, bounded loops).

# 7. Coding Guidelines (C / Embedded / AUTOSAR-style)

- Naming (observed platform convention): `u8/u16/s16…` prefixes for storage class
  (`u8NodeAbsentDetection`), `P_` for calibration parameters (`P_NmAsrTimeoutTime`), module prefix
  for APIs (`RsuMgr_Initialization`, `FltMonr_ReportErrorStatus`), `*_Lcfg` generated config,
  UPPER_SNAKE for events/DTC macros (`GPO_F_SHORT_GND_0`).
- Error handling: every HW/driver call returns status; check and route to FltMonr; no silent
  defaults on the firing path. Defensive: range-check every CAN-sourced value against DBC min/max
  *before* use; treat out-of-range per on-fail matrix, not by clamping silently (except documented
  clamps like speed→300 km/h).
- Assertions: DET-style in debug; in production convert to FltMonr internal-error events —
  never `while(1)` traps in ASIL code paths.
- Config/compile-time: feature bits (EDR_CONFIG, crash-output, alive-range) are **runtime NVM**,
  not `#ifdef` — same binary serves variants; `#if` only for platform HW differences.
  Keep FLTMONR_* General-tab switches (`FLTMONR_CONFIGURABLE_JUMP_ENABLE`, callbacks,
  `FLTMONR_ALLOW_DISABLED_MASK` = dangerous, keep OFF) under configuration control.
- State/counter variables that gate deployment: duplicate-store with inverse copy or CRC where
  RAM-corruption is in scope (ASIL D memory-safety measures).

# 8. Unit Testing Guidance

- **Positive**: each state transition of NM/RSU/session machines with exact trigger vectors;
  CRC-8 known-answer (0x4B check, 0xC4 magic); E2E P5 vectors; alive-counter both ranges (0–14 &
  0–15) across rollover; debounce counters hitting thresholds exactly.
- **Negative**: unsupported SID/SF/session/security combinations → exact NRC + priority order;
  key-without-seed (NRC 24); 11th attempt (NRC 36 with NVM persistence mocked); SPR-bit on
  unsupported services (NRC 12 per D-07).
- **Boundary**: DLC 63/64/65; debounce N−1/N/N+1 consecutive errors; 79 %/80 % heal reception;
  VIN comparison at 2/3 mismatching sets; speed 4.9/5.0/5.1 km/h on NRC-88 gates; voltage at
  VNW_Diag_* edges; alive counter at 14/15; multi-event at ΔT0 = 800 ms and 5.0 s exactly.
- **Timing**: init-pulse 350–400 ms window; 800 ms inversion = 20 × 40 ms cycles (count cycles,
  don't sleep — the framework rule "no sleeps during EDR simulation, trigger at T0" applies to
  unit level too: drive time via tick injection); P2/P2* via mocked timer.
- **Fault injection**: mock CAN driver to inject DLC/CRC/AC corruption sequences interleaved
  (ensure order-of-checks DLC→CRC→AC and single-counter increment per frame); EEPROM write-fail
  during security-counter update (must fail closed); power-fail flag mid-EDR-write (second area
  intact).
- **Mocks needed**: CAN driver (frame-level), NvM (with fail modes), FltMonr (capture
  report calls), timer/tick, PSI5 bridge (phase-data scripting), ADC (loop resistances).
- **Coverage**: MC/DC on ASIL-B+ decision points (deployment gates, NM transitions, NRC
  arbitration); 100 % statement on generated-table access wrappers.

# 9. Integration Testing

Reflect the SwQTS suites (`CANC/EDR/IOControl/UDS/Bootloader_SwQTS`):

- **Signal/CAN interaction**: for every RX signal — normal consume, each on-fail column of the
  matrix, heal, and EDR content check (pre/post-crash split around fault activation; values with
  offsets converted per DBC; odometer/date/time scalars).
- **Fault injection recipes** (bench API): node absent = `CAN.PeriodicDisableFrame(ch, keyFrame)`;
  message timeout = disable the slave frame carrying the signal (never a different one — D-10);
  wrong-DLC = `CAN.SetPeriodicFrame(ch, id, cycle, wrongDlc, bytes)` then
  `ReloadDefaultPeriodicFrame`; CRC/AC = `CAN.DisableDynamicSignal(ch, frame, crcOrAliveSignal)`;
  SCF = `CAN.PeriodicChangeSignal(ch, frame, signal, invalidPerDbc)` (skip if DBC has no invalid);
  VC error = write VC with node bit 0 + IGN cycle; UV/OV via programmable supply.
  DTC read only **after** quali time (and after recording interval for EDR cases); active status
  `0x0B` for CAN DTCs, `0x8B` for crash locks, UV/OV stays `08`.
- **UDS interaction**: session×security×service matrix; S3 timeout relock; multi-DID mixes
  (L1 + non-L1 + unsupported in default/extended/unlocked — NRC 31/response filtering per § 10.2);
  $28 gating verified by observing 13C/2C0 stop while NM keeps running; $85 OFF halts CAN-C
  diagnosis (no new CAN DTCs while faults injected).
- **Power cycles/resets**: EOL/VC effective only next cycle; RSU heal next cycle; security
  counters persist; $11 hard/soft reset → diag < 500 ms, no TX < 150 ms; interrupted post-run.
- **Crash scenarios**: front/left/right/rear/near × {all-bus-active, bus-silent} × {HW IGN, CAN
  wakeup} × {normal, UV, OV}; IGN-cut and BATT-cut 50 ms post-T0 (ER hold); crash at PWM low
  phase; crash during init < 450 ms (no deploy); ENS faulty (STB/STG/OPEN/de-config) + crash → PWM
  keeps fault signature, crash DTCs still recorded; healed-ENS + crash → normal inversion.
  Crash DTC sets: front `926196 8B` + `921A00 8B`; side `920100 8B`/`921A00 8B`; rear `921E00 8B`;
  near-crash none.
- **Sensor failures**: each RSU position × open/STG/STB/comm/internal/config; ODS/buckle/STPS
  resistance and Hall-current matrices incl. undefined 7–11.9 mA band; OCS via 0x5FF with ~1 s
  settle.
- **Bootloader**: full flash, corrupted S3 payload/address/checksum, truncated file, missing S7,
  wrong BSC, session timeout in boot with/without valid app, flash-then-verify NVM survival
  (VIN/EOL/VC/EDR/DTCs).

# 10. Diagnostics Reference

## 10.1 DTC map (key entries; 3-byte DTC + status byte on wire)

Crash locks: `906196` front-lock, `921A00` PT-deployment-lock, `920100` side-lock, `921E00`
rear-lock (status `8B`). ENS/GPO0: `921811` STG, `921812` STB, `921813` OPEN, `923456` de-config.
PADI: PABOFF `921013/11/12/64`, PABON `902413/12/11/64`. Config: `9202-00` (0xB120200)
ECU_CONFIGURATION_ERROR, `990E64` eCall config. RSU per § 2.6. CAN: per-message NODE_ABSENT /
MESSAGE_CONTENT_FAILURE / signal DTCs + BUS_OFF + VIN_MISMATCH_ERROR + variant-code DTC.
Suffix convention: `…11` STG, `…12` STB, `…13` open, `…64` config, `…81` comm, `…96` internal.

## 10.2 DID catalogue (read $22 unless noted)

Project DIDs: `0434` deploy-loop resistances, `04A2` buckle resistances, `0444` life timer,
`0446` squib status, `0448` sensor/belt status, `0449` doors, `044A` PADI+PAB fault, `044B`
warning-lamp, `0455/045B/045D` Mahindra EDR rec1–3, `0456/045C/045E` supplier EDR, `0457` sensor
faults, `0458` crash counter, `0459` brake switch, `045A` accel pedal, `045F–049C` EDR additional,
`0477/0478` rollover arrays, `047E` internal-DTC reason, `0100` (r/w), `0101` VC (r/w L1),
`0102` EOL (r/w L1), `0103` NM params (r/w), `0110` NM read, `F100` mode config (r/w),
`F1B0…F1B9` odo/batt/speed/engine-speed/reset-reasons/reset-ctr/ign-ctr/eeprom-layout/vehicle-status,
`F1C0` speed-for-NRC88 (r/w). Standard: `F180/F181/F182` (boot/app/cal versions, naming per
Table 84), `F186` active session, `F187` MVPN, `F18A` supplier ID, `F18B` mfg date (write only in
phase-of-life 01, else NRC 22), `F18C` serial (first 9 bytes locked non-zero rule; last 4
writable), `F190` VIN (write L1 + NRC 88), `F191` HW version, `F193/F194/F195/F197/F198/F199/F19D`,
`F1F0` supplier part no (`0x44 0x56…`), `200` boot flag, `201` history zone. Plant DIDs:
`FF80/FF8C/FF8D/FFAA` (plant phase only). IO-control DIDs ($2F): `F010–F014, F017–F021, 0F22`
(0F22 = PAB-enable lamp — check HW lamp state, not INDC_PADL), `F012`.
Multi-DID: unsupported DID in request → NRC 31; > max DIDs or < min length → NRC 13; mixed-security
sets answered with only the permitted DIDs per session/lock state.

## 10.3 Sessions/security/NRC — see § 2.12 & § 4.3. Freeze frames

Snapshot records 1 (oldest) & 2 (latest); Table-39 freeze-frame DID set captured at set & heal;
extended data $01 frequency counter / $02 op-cycles / $FF both.

# 11. Calibration

| Parameter | Default / range | Owner |
|---|---|---|
| `u8NmIgnStrtupDel` (NM IGN-on startup delay) | 2000 ms (UV-reset path 1500 ms note) | DID $0103 |
| `u8NmIgnStartupDelAftrUndrVolRec/OvrVolRec` | project cal | DID $0103 |
| `u8NodeAbsentDetection/Recovery`, `u8MsgContentErrorDetection/Recovery` | per-message Table 1/2 | CanMgr cal |
| `u8AbnormalVolPresentTime`, `VNW_Diag_Low/High_OFF/ON`, `VComm_Lower/High`, `TCommPresent/Absent` | volt gates | CanMgr |
| `P_NmAsrRepeatMessageTime / WaitBusSleepTime / TimeoutTime / CanMsgCycleTime`, `P_CanNmMsgTimeoutTime`, `P_IGN_STS_AWB_Clear_Delay` | NM cal | CanNm |
| GPO mature/de-mature | 2 s / 4 s | FltMonr row |
| ENS: period 40 ms, duty 62.5/37.5 %, inversion 800 ms, init 350–400 ms (<450) | fixed | EnsMgr |
| Proveout 6 s ON / 1 s OFF; PADI update ≤ 25 ms | fixed | Padi |
| EDR: multi-event 0.8–5 s, ΔV>8 km/h/150 ms trigger, 150 ms power-loss write, sample ranges per `edr_config` | RstEdr |
| Debounce per event: inc/dec step, thresholds (−128…127), jumps | FltMonr DATA sheet |
| `Min_Configuration_Speed` 5 km/h; security delays 3 s/5 s; attempt limits 10/5 | DiagMgr |
| RSU: `RSU_Retry_Goal`, `Channel_Retry_Goal`, `Immediate_fault_report` bits, 180 ms NODATA | RSU fixed cal |
| STPS zone currents 5–6.9 / 12–17 mA; DCS 200R/800R codings | DCS cal |
| P2 50 ms / P2* 5000 ms / S3 5 s; T[CANInit] 150 ms; diag-ready 500 ms | DCM |

Scaling/units always per DBC (speed km/h, accel g, rates deg/s, ΔV −100…+200 km/h, temp °C);
apply offset before compare (framework rule).

# 12. Known Industry Practices

- **Veoneer/Autoliv (this platform's lineage)**: generated FltMonr/Dem config from workbook,
  SB3/EX3 firing-ASIC pairs, PSI5 satellites, EDR dual-area EEPROM, crash-lock DTC concept —
  exactly what SC3 shows.
- **Bosch/Continental/ZF**: same 4-level CAN monitoring (node/timeout/content/signal), CanNm
  passive startup, energy-reserve deployment ride-through, PADI dual-lamp with proveout,
  seed/key with NVM attempt counters. Bosch tends to E2E P1/P2 on classic CAN; this project's
  J1850-CRC8+parity is Mahindra-legacy — don't "modernize" without OEM signoff.
- **Denso/Mobis/Joyson**: resistance-coded buckle/ODS ladders (200/800 Ω) and Hall-zone STPS are
  common across Asian OEM programs; the 2-zone STPS (no mid band) matches Mobis-style suppression
  maps.
- Regulatory: EDR content/locking aligned with NHTSA Part 563 / AIS-140-era Indian requirements /
  GB 39732 style; UDS profile is plain ISO 14229 with OEM NRC-priority sheet.

# 13. Common Design Mistakes (watch for these in review)

1. Sleeping in simulations/tests around T0 instead of counting cycles (breaks EDR interval
   alignment). 2. Creating message-timeout on the wrong frame → consumed-vs-last-valid confusion
   (D-10). 3. Hard-coding alive-counter range instead of EOL bit (D-03). 4. Checking CRC before
   DLC or counting one corrupt frame in several debounce counters. 5. Letting CAN faults drive NM
   transitions. 6. Treating UV/OV DTC status like normal active (it stays `08`). 7. Reading DTCs
   before quali time / before EDR recording interval ends. 8. Clearing crash-lock DTCs in $14
   implementation. 9. Applying EOL/VC immediately instead of next ignition. 10. PADI asymmetry
   "fixes" (D-12). 11. Forgetting the 350 ms app-TX delay entering NORMAL_OPERATION. 12. Security
   counter kept in RAM (must be NVM, fail-closed). 13. IO-control left latched after session drop
   (must returnControlToECU). 14. Testing SCF on signals with no DBC invalid value. 15. Using
   INDC_PADL to verify PAB-lamp IO control (use HW lamp state, DID 0F22 note). 16. Race between
   25 ms fault report and 500 µs detection (report task reading half-updated status — atomicity).
   17. EDR write path exceeding the 150 ms ER budget after adding data. 18. Assuming bit8 exists
   (D-08) or trusting swapped PABON/PABOFF prose (D-05).

# 14. Implementation Checklist (before code review)

- [ ] Requirement cluster identified; all D-xx discrepancies affecting it resolved/escalated.
- [ ] DBC checked for scaling/offset/invalid/reserved values of every touched signal.
- [ ] On-fail matrix behavior implemented per signal (not per node).
- [ ] Timing constants from calibration, not literals; both alive-counter ranges handled.
- [ ] State machines table-driven; all events handled in all states.
- [ ] FltMonr event IDs keep consecutive-group ordering; workbook regenerated, not hand-edited.
- [ ] NVM writes journaled; power-fail mid-write handled; EOL/VC/VIN survive flash.
- [ ] Next-ignition-cycle semantics respected for config changes.
- [ ] NRC priority order per NRC_CheckFlow; SPR handling per D-07 decision.
- [ ] No deployment-path dependency on QM data (VIN inhibit D-01 escalated if touched).
- [ ] Unit tests: boundaries (N−1/N/N+1), both IGN-ON and CAN-wakeup variants, UV/OV gates.
- [ ] MISRA clean or deviations documented; no dynamic memory; bounded loops.

# 15. Review Checklist (for the reviewer)

- [ ] Does the change alter anything on the firing path? If yes: safety analysis updated? dual-
      channel interlocks intact? ASIL rigor (MC/DC tests) present?
- [ ] Are CAN fault reactions still per on-fail matrix (spot-check 3 signals incl. one exception
      like PSGR_AIRBAG_SW_IC)?
- [ ] Any new literal that should be calibration? Any `#ifdef` that should be an NVM feature bit?
- [ ] DTC additions: status-byte semantics, quali/dequali times, UV/OV suppression, snapshot DIDs,
      event-ID group placement all specified?
- [ ] Session/security gates on any new DID/RID; NRC order; multi-DID interaction.
- [ ] Concurrency: which task writes / which reads each new shared variable; atomicity ensured?
- [ ] Tests read DTCs only after maturation; no sleeps in T0-relative simulations; ignition-cycle
      steps present where heal-next-cycle applies.
- [ ] Test cases follow § 16: Veoneer Excel format, `Verifies` requirement IDs actually exist in
      the correct variant's tracker and are Approved (spot-check 2–3 IDs against the export),
      DTC status bytes per § 16.3 (CAN faults `0B`), NRC expectations explicit per § 16.4.
- [ ] Requirement text vs implemented behavior: if prose is self-contradictory, is the resolution
      documented with a D-xx-style note rather than silently chosen?

# 16. Test Case Authoring Rules (Veoneer Excel format — MANDATORY)

All generated test cases must follow the format produced by
`C:\Python 3.14.0\Scripts\scripts\excel_testcase_veoneer_format_v2_tweak.py` (openpyxl writer).
When asked to "write test cases", produce either that Python structure (a `test_cases` list of
dicts) or the equivalent Excel rows — never a free-form table.

## 16.1 File / sheet structure

- Workbook with one sheet per module/spec (e.g. `"EDR Test Spec"`).
- Header row: `["Test Case Name", "Step No", "Test Step", "Expected Observation"]`
  (written from column A; content starts in column B).
- Per test case: one title row — **column B = Test Case Name, column C = Test Case Description**
  — followed by one row per step: **B = step number, C = action, D = expected observation**.
  Then the next test case starts on the following row. Column widths auto-fit (`max_length + 2`).
- Python dict shape per test case:

```python
{
    "Sno": <int>,
    "Test Case Name": "<Module>_<Feature>_<Scenario>_<n>",   # e.g. EDR_Element_IDs_Gear_1
    "Test Case Description": "Verify that … <behavior + where it is observed>",
    "Verifies": ["31300826", "31307791"],                    # REQUIREMENT IDs — see 16.2
    "Steps": [
        ["1", "<action>", "<expected observation>"],
        ...
    ],
}
```

- Canonical step skeleton (adapt, don't skip):
  1. `Set bench to normal condition` → `System is in normal state, no faults present`
  2. Simulation / precondition setup (signal values with timing grid, fault creation, EOL/VC
     writes + IGN cycle where config is involved)
  3. Trigger (crash / fault maturation / diagnostic request) **+ Read DTC** with full expected
     DTC text and coded bytes (see 16.3)
  4. Verification read (EDR DID / status DID / lamp / PWM) with exact bytes and byte-index ranges
     (e.g. `Read EDR with DID 730: 22 04 55 and observe bytes 328 to 332`)
  5. `Clear NVM and Clear DTC` → `All DTCs and NVM data are cleared; system returns to normal state`
     (omit/replace for crash-locked cases — lock DTCs and EDR must be stated as NOT clearable).

- Request/response steps spell out raw frames when relevant, in the project style:
  `730 : 08 02 10 03 00 00 00 00 00` / `738 : 08 06 50 03 00 32 13 88 00`.
- Simulation steps must respect the framework rules: values per **DBC** (apply offset/scaling
  before compare), sample grids relative to T0 (e.g. `every 500ms from -3s to 0s`), **no sleeps**
  in T0-relative sequences, Saleae capture started ≥ 5 s early, DTC read only **after** the
  recording interval / qualification time.

## 16.2 Requirement mapping (traceability) — the most important rule

Every test case MUST carry the correct requirement ID(s) from the requirement Excel exports
(Codebeamer artifact IDs — first column `ID` of the `DES_SW_Mahindra_*` trackers, e.g. `31300826`).

Mapping procedure (do this, in order — never guess):

1. **Pick the right tracker for the module under test** (GPO/Padi → `…Mahindra_GPO.xlsx` or
   `…Process_GPO`; CAN faults → `…Mahindra_CAN_C`; EDR → `…Mahindra_EDR`; UDS/DID → `…Mahindra_UDS`
   + `Customer_DIDList`; NM → `…Network_Management`; EOL → `…EOL` / `EOL_Additional`; VC →
   `Variant code_Additional`; VIN → `…VIN`; RSU → `…Mahindra_RSU`; DTC lists → `…FaultList`) —
   and the right **variant** (M314 vs W616/U171/Z121 trackers; check the `_Projects`/Release
   column, D-11).
2. **Search the `Description` and `Summary` columns** for the distinctive tokens of the behavior
   under test: signal name (`PSGR_AIRBAG_SW_IC`), message (`IC2_100`), DID (`044A`, `0455`),
   DTC number (`921013`), parameter (`u8NodeAbsentDetection`), timing value (`800ms`, `6s`).
   The row whose Description states the behavior the test's *Expected Observation* checks is the
   requirement to cite. Use the `Parent`/heading hierarchy to disambiguate (e.g. the same lamp
   behavior appears under Initialization vs Proveout vs Run Time — pick the phase your test runs).
3. **Prefer rows with `_ReqStatus = Approved`** (or `In_Review` where nothing approved exists).
   **Never map to `Obsolete` rows.** If both an old and a reworded requirement match, cite the
   current one.
4. One test may verify several requirements (list all); one requirement may need several tests
   (positive + each fault mode + heal). Coverage goal: every Approved functional requirement of
   the module has ≥ 1 test citing it.
5. If no requirement row matches, **do not invent an ID**: set `"Verifies": ["TBD"]`, state the
   gap explicitly, and flag it as a requirement-coverage hole (possible missing requirement).
6. Output format: the `Verifies` list carries bare IDs; when the SwQTS/Codebeamer import format is
   requested instead, render as `[ISSUE:<id>]` references in the `Verifies` column of the export.
7. Cross-check trap list before finalizing: D-05 (PABON/PABOFF prose swaps — map by behavior, not
   by summary text), D-02 (contradictory VIN rows — cite the recommended one and note the
   conflict), D-11 (variant-specific defaults — cite the row for the tested variant only).

## 16.3 DTC and status-byte rules (exact bytes in Expected Observation)

- Always write DTC name **and** 4-byte coded form `<DTC-high> <DTC-mid> <DTC-low> <status>`:
  e.g. `DTC: ECU Locked Due to Front Crash / DTC Code: 90 61 96 8B`.
- Status bytes (project-normative — get these wrong and the test is invalid):
  - **CAN-fault DTCs (node absent, message timeout, message/signal content failure, bus-off,
    VIN mismatch, VC error) active = `0B`** — per requirement; e.g. `92 xx xx 0B`.
  - **Crash-lock / deployment DTCs = `8B`** (front `90 61 96 8B`, PT `92 1A 00 8B`,
    side `92 01 00 8B`, rear `92 1E 00 8B`; near-crash → NO DTC).
  - **UV/OV DTCs stay `08`** even while the voltage condition is present.
  - **Historic/healed = `08`.** Post-crash-healed CAN DTC: if quali time elapsed and an ignition
    cycle occurred before Read-DTC → expect **historic `08`**; without the ignition cycle →
    expect healed state. State the ignition-cycle step explicitly in the test.
  - Internal/GPO/RSU/loop DTC statuses follow the same active/historic convention; respect
    mature/de-mature times (GPO 2 s/4 s, RSU immediate-qualify + next-ignition heal) before the
    read step.
- Normal-simulation EDR cases have **no on-fail CAN DTC** — only the crash DTCs appear.
- DTC numbers must come from the FaultList/ENS/RSU tables in this document (§ 2.5, § 2.6, § 10.1)
  or the FaultList tracker — never from memory. If a needed DTC is not in either, ask.

## 16.4 Negative-response (NRC / "nack") handling rules

- Every diagnostic-request step must state the exact expected response: positive
  (`738 : … 50/62/6E/71 …`) or negative `7F <SID> <NRC>` — never "request fails".
- Apply the NRC **priority chain** (§ 4.3): length `13` → session/SID-SF `7F/7E` → range `31` →
  security `33` → conditions `22` → speed `88` → service-specific (`24/35/36/37/72/73`).
  Tests for gated writes (EOL/VC/VIN/session/reset) must include the NRC-88 speed case
  (> 5 km/h), NRC-33 locked case, and the wrong-session `7F` case as separate test cases.
- SPR-bit on services where suppression is unsupported ($10 def/prog, $11, $14) → expect
  **NRC 12** (documented deviation D-07).
- Security lockouts: 11th attempt → `36`; delay violations → `37`; key-without-seed → `24`;
  wrong key → `35`; plant-mode $14 → `22`; NRC 78 allowed as intermediate for long operations —
  final response must still be asserted.
- For requests expected to be ignored (functional address + unsupported SID/SF): expected
  observation = **no response within P2**, stated explicitly.

## 16.5 Reading the Excel sources without losing content (mandatory extraction procedure)

Requirement mapping, DTC lookup and config auditing are only as good as the Excel extraction.
Never work from a screenshot, a partial preview, a "first 50 rows", or memory of a file — extract
programmatically, completely, and verify the extraction before using it.

**Extraction procedure (do all of it, in order):**

1. **Dump the whole workbook with a script, not by eyeballing.** Use `openpyxl` with
   `load_workbook(path, data_only=True, read_only=True)`; iterate **every sheet** (list them
   first — trackers hide data in `ChoiceValues`, `Dem`, decoder and `DATA` sheets, not just the
   first one) and **every row** to a plain-text/TSV scratch file, one dump file per workbook.
   Analyze the dump, not the workbook. Note: on this machine `openpyxl` lives under
   `C:\Python 3.14.0\python.exe`; the bare `python` on PATH is a different install without it.
2. **Locate columns by header name, never by fixed index.** The same tracker family ships with
   different column layouts per variant (M314 exports put `Description` at a different position
   than W616 exports; SwQTS test exports use `Name/Description/Test Steps.*` instead of
   `ID/Parent/Summary`). Read the header row of *each* sheet and resolve `Description`,
   `_ReqStatus`, `_Projects`, `ID`, `Verifies` etc. by name. A fixed index silently reads the
   wrong column and produces plausible-looking garbage.
3. **Preserve cell content losslessly.** In-cell newlines → replace with a visible separator
   (` | `), never delete. Do not truncate cells; if a tooling limit forces truncation, mark it
   explicitly (`…[TRUNCATED]`) and re-read that cell in full before relying on it. Trim only
   *trailing* empty columns — a row whose first columns are empty may still carry data further
   right.
4. **Decode the Codebeamer export conventions instead of discarding them:**
   - Escapes: `~_` = `_`, `~-` = `-`, `~,` = `,`, `~'` = `'`, `~>` `~<` `~[` `~]` similarly.
   - Style noise `%%(color:… )text%!` wraps REAL text — strip the style, keep the text.
   - `%%(text-decoration:line-through;)…%!` is **struck-through (deleted) text** — treat it as
     obsolete content, never as an active requirement, even when `_ReqStatus` still says
     Approved/In_Review.
   - `[{Table …}] |(…)cell | |(…)cell …` wiki markup contains the actual data tables (EOL byte
     maps, DID byte tables, DTC lists) — parse the cell values out of it; skipping "markup"
     loses the normative content.
   - `[!image.png!]` / `[CB:/displayDocument/…]` are embedded images — content NOT in the export;
     record them as "figure — content not extractable" gaps, don't pretend the row is empty.
   - `[ISSUE:nnn]` / `[TRACKER:nnn]` are cross-references to other Codebeamer items — keep the
     numbers, they are traceability links.
5. **Handle structure quirks:** merged cells return their value only in the anchor cell (other
   cells read `None`) — if a table looks sparsely filled, carry the last non-empty value forward
   where the layout implies it (e.g. the System/Message columns of the On-fail spec). Multi-row
   headers exist (On-fail spec has a two-tier header: failure-mode columns each split into
   Value/Reaction) — combine both header rows before naming columns. `.xlsm` files are read the
   same way (macros ignored); openpyxl warnings about styles/data-validation are harmless.
6. **Verify the extraction before using it:** compare per-sheet extracted row counts against the
   sheet dimension (`ws.calculate_dimension()`), spot-check 2–3 known rows (a requirement ID you
   can see, a DTC you know) against the dump, and confirm the `Description` column really
   contains prose (if it contains `tbd` everywhere or looks like status values, the column
   resolution is wrong — fix and re-extract, do not proceed).
7. **Filter with, not before, understanding:** keep Obsolete/strikethrough rows in the dump
   (marked) so contradictions are visible; apply `_ReqStatus`/`_Projects` filters only at the
   analysis step (§ 16.2 mapping uses Approved rows of the correct variant, but knowing an
   Obsolete twin exists is what catches D-02-style contradictions).
8. **Cache and reuse:** write dumps to a scratch/working folder once per task and let every
   worker (§ 17) read the same dump — re-extracting per worker invites inconsistent parsing.

**Anti-patterns (all observed to cause silent content loss):** reading only the first N rows and
assuming the rest is similar; using a fixed column letter across variants; dropping cells that
contain markup; treating struck-through text as live requirements; ignoring non-first sheets;
skipping rows with empty leading columns; trusting a screenshot or a previous conversation's
recollection of a value instead of the fresh dump.

## 16.6 Reading PDFs, Word documents and other sources without losing content

Basic text extraction is NOT sufficient for the project's PDFs (ARIA User Functions, OEM specs,
on-fail specs) — they carry their meaning in tables, prototypes, multi-column layouts, figures
and page structure. Extract with purpose-built libraries, completely, and verify before use.

**Library selection (install on demand with `pip` into the interpreter that will run the
extraction — on this machine `C:\Python 3.14.0\python.exe`; pick the best tool per document, and
switch tools when the first choice loses content):**

| Content type | Tool |
|---|---|
| Native (text-layer) PDFs — structure, headings, reading order, images, metadata | `pymupdf` (fitz) |
| Tables in native PDFs (row/column integrity) | `pdfplumber`; ruled/gridded tables → `camelot`; Java available → `tabula-py` |
| Scanned/image-only PDFs (little or no extractable text per page) | `ocrmypdf` (adds text layer) or `pytesseract` + `opencv` preprocessing (deskew, binarize) |
| Complex layouts (multi-column, forms, mixed) | `layoutparser` / `unstructured` |
| Table post-processing, reshaping, export | `pandas` |
| Word documents | `.docx` → `python-docx` (paragraphs + tables + styles); legacy `.doc` → convert first (Word COM / LibreOffice headless); note some sources ship pre-extracted as `*_extracted.txt` in `req\` — prefer the original when fidelity matters |

**Extraction requirements (all mandatory):**

1. **Page-by-page, full-document dump to a scratch file** — same two-pass discipline as § 16.5:
   dump first, analyze the dump. Preserve headings, section numbering, lists, notes, references,
   headers/footers (they carry document IDs and revisions), and document metadata
   (title/version/date — needed to cite the right revision).
2. **Tables with complete row/column integrity.** Extract tables as tables (pdfplumber/camelot),
   not as flowed text; verify each row has the expected column count; multi-page tables must be
   stitched with the header carried over; merged/spanning cells resolved like § 16.5 rule 5.
   Prototype tables (e.g. ARIA function definitions) must keep parameter order and types exact.
3. **Detect scanned pages automatically** — if a page yields no/garbage text but contains a large
   image, switch that page to OCR. **Validate OCR quality**: check per-word confidence
   (pytesseract data output); mark low-confidence text inline as `[OCR-UNCERTAIN: …]` and never
   base a requirement/DTC/byte value on uncertain OCR — re-read, zoom/preprocess, or report it.
4. **Figures and diagrams**: extract the images, associate each with its caption and section;
   where the meaning is in the drawing (state machines, timing diagrams, PWM waveforms), record a
   `figure — content requires visual review` gap with its page number instead of pretending the
   section is complete. If an image-capable reader is available, view the figure; otherwise flag.
5. **Keep page references for every extracted fact** (`<doc> p.<n>`), so reviews and requirement
   citations are traceable back to the source page.
6. **Completeness cross-check before use**: extracted page count vs document page count; table of
   contents entries vs headings actually found; numbered sections/functions contiguous (a jump
   from 14.31 to 14.33 is either a source quirk or a lost page — check which); spot-check 2–3
   known values. Produce a short extraction-quality report (pages OK / OCR pages / uncertain
   regions / unextractable figures / suspected gaps).
7. **Never assume missing content.** If extraction quality is poor or a section is unreadable,
   say so explicitly and treat it as an open question — a guessed byte table in this domain is a
   safety defect, not a convenience.

# 17. Multi-Agent Task Orchestration (how to execute big tasks without mistakes)

For any non-trivial task (a batch of test cases, a module's scripts, a requirement-coverage sweep),
do **not** attempt it as one monolithic pass. Decompose into specialized sub-agents that run in
parallel, then integrate and gate. This mirrors established patterns (GitHub Copilot coding
agent / multi-agent "planner–worker–integrator" repos, Claude Code subagents & Agent-tool fan-out,
CrewAI/AutoGen plan-execute-integrate): parallel narrow-scope workers + a single integrator +
a mandatory verification gate. The goal is **zero mistakes** in requirement mapping, DTC/status
bytes, and script correctness — each of these gets its own dedicated agent pass.

## 17.1 Standard agent roles (spawn one per role; scale workers by module/test-case batch)

1. **Planner** — splits the task into work packages (per module / per signal / per DID / per fault
   type), assigns source-of-truth files to each package (which requirement tracker + which DBC
   JSON + which project config), and defines the integration contract (file names, dict shapes,
   `Verifies` format).
2. **Requirement-Mapper agent(s)** — input: behavior list; output: Codebeamer ID(s) per behavior
   using § 16.2 procedure ONLY (search the correct variant tracker's Description/Summary columns;
   Approved rows; no invented IDs; TBD + flag for gaps), working exclusively on full workbook
   dumps produced per § 16.5 (never on partial reads). Produces a traceability table
   `behavior → requirement ID(s) → tracker file → row status`.
3. **Test-Case Author agent(s)** — writes the Veoneer-format test cases (§ 16.1) consuming the
   mapper's table; never does its own mapping from memory.
4. **Script-Writer agent(s)** — converts test cases to framework Python scripts per § 18; consumes
   the function inventory produced by the Library-Auditor, never invents API calls.
5. **Library-Auditor agent** — greps `shared_libraries\` for the exact functions/signatures the
   scripts will need; outputs the allowed-function list + any **missing-wrapper report** (see
   § 18.4 — missing functions go to the user, they are never improvised inline).
6. **Config-Auditor agent** — verifies every message/signal/DTC/timing constant the scripts use
   exists in the target project's `projects\<project>\config\*_config.py` (and matches the DBC);
   reports config gaps instead of hard-coding values.
7. **Integrator** — merges all worker outputs into the final deliverable set at once; resolves
   naming collisions; ensures consistent step numbering, imports, and file placement
   (`projects\<project>\modules\<MODULE>\scripts\`).
8. **Verifier / Reviewer agent (mandatory final gate)** — independent pass over the integrated
   result checking: (a) every `Verifies` ID exists in the correct tracker and is Approved,
   (b) DTC codes + status bytes per § 16.3 (CAN faults `0B`, crash locks `8B`, UV/OV `08`),
   (c) NRC expectations per § 16.4, (d) every called function exists in `shared_libraries` with
   matching arity, (e) all constants come from config, (f) timing/ignition-cycle rules of § 18.5
   respected, (g) D-xx register consulted for every touched area. **Nothing ships until this gate
   passes**; failures go back to the owning worker agent, not patched ad-hoc by the integrator.

## 17.2 Orchestration rules

- Workers get **narrow, non-overlapping scopes** and the *specific* source files — never "the
  whole req folder". Two workers must not edit the same script file.
- All facts flow through artifacts (tables/lists), not through worker memory: the mapper's
  traceability table and the auditor's function inventory are the only allowed sources for IDs
  and API names downstream.
- Integrate **once, at the end** — partial merges create the inconsistencies this process exists
  to prevent.
- If any worker is uncertain (ambiguous requirement, missing function, missing config key), it
  must emit a question/flag artifact, not a guess. The orchestrator batches these to the user.
- Keep a per-task ledger: work package → worker → output artifact → verifier verdict. This is the
  audit trail proving traceability.

# 18. Script Authoring Rules (framework Python scripts — MANDATORY)

Target layout: scripts live in `projects\<project>\modules\<MODULE>\scripts\`
(e.g. `projects\M310_M314_M110\modules\EDR\scripts\SUBS_EDR_Element_ID_<X>_TestCase_<N>_<M>.py`);
per-project configuration in `projects\<project>\config\` (`project_config`, `cand_config`,
`canc_config`, `edr_config`, `dcs_config`, `rsu_config`, …); shared wrappers in
`C:\Framework_IOEM_Py\shared_libraries\`.

## 18.1 Use ONLY existing shared-library wrapper functions

Scripts are thin sequences of **wrapper calls + ResultStep verifications** — no raw logic.
The wrapper inventory (verify signatures by reading the module before use — names below are the
real exports):

- `core_functions.py`: power/ignition (`POWER_ON`, `POWER_OFF`, `POWER_CYCLE`,
  `POWER_OFF_WAIT_POWER_ON_WAIT`, `Set_ECU_PowerVoltage`, `CAN_Wakep_UPP`,
  `CAN_Wakeup_Disable_UPP`, `CAN_Wakeup_Cycle_UPP`); diagnostics (`Send_UDSFrame`,
  `send_uds_frame`, `SecurityAccess`, `Internal_Security_Access`, `enter_ext_session`,
  `Read_DTC`, `Read_customer_DTC`, `ClearDTC`, `Clear_DTC_Info`, `NVM_Clear_L61`,
  `DataIdentifier_Read_Write`, `diag_read_byte_after_did`, `decode_DID_0446`,
  `vehicle_speed_did_F1B2`); crash (`TriggerCrash`, `perform_crash`, `load_crash_curves`,
  `load_crash_curves_can_wakeup_condition`, `LoadCrashCurve`, `Load_RSU_CrashData`,
  `Front_2sec_Left`, `Near_2sec_Front`, … multi-event helpers, `load_front/left/right_crash_curves_ens`);
  EDR (`ReadEdrDataStructure`, `EDR_DECODER`, `CAN_Signal_Info_during_crash`); faults
  (`SetGpoFaultCondition`, `SetRsuFaultCondition`, `RemoveRsuFaultCondition`,
  `FaultFreeCalibration`, `Fault_Free_sequence`, `FaultMaturationDematurationLogic`,
  `faultTimeMeasurement`, `fault_free_profile_classic_can`, `fault_free_profile_can_fd`,
  `disable/enable_all_node_absent_frames`, `disable/enable_all_message_timeout_frames`,
  `induce_signal_never_received`, `Create_Variant_code_error`, `clear_Variant_code_error`);
  config ops (`manage_eol_code`, `manage_variant_code`, `SET_LOOPS_LOADS`, `SET_DCS_LOADS`,
  `SET_LAMP_LOADS`, `SET_RSU_LOADS`, `SteeringWheelPosition_Config`); VIN
  (`simulate_vin_can_signals[_fd]`, `compare_vin_can_signals_classic/_fd`,
  `format_expected_vin_response`, `vin_strategy_test`); misc (`Sleep`, `Wait`, `ResultStep`,
  `create_report_and_logging`, `RunSaleaeCapture`, `physical_to_raw`, `raw_to_physical`,
  `GetSWInfo`, `read_software_version`).
- `jscript_translation.py`: bench object classes — `CAN` (PeriodicDisableFrame,
  PeriodicEnableFrame, PeriodicChangeSignal, DisableDynamicSignal, EnableDynamicSignal,
  SetPeriodicFrame, ReloadDefaultPeriodicFrame, GetSignalFromFrame…), `LAMPS`, `PS` (power
  supply / leakage buses), `SQUIB`, `RSU`, `SPI`, `SLS`, `ARIA`, `PowerCard`, plus `RESULT`,
  `Sleep`, `Wait`, channel resolution (`_resolve_simulation_channel_id`,
  `_resolve_diag_channel_id` — bus/channel is **config-resolved, never a literal**).
- `fault_monitor.py`: `ExpectInternalErrors`, `AddOptionalError`, `DisplayInternalErrors`.
- `edr_decoding_functions.py` / `edr_did_library.py` / `data_conversions.py`:
  `read_edr_parameters`, `decodeParameterValues`, `decode_crash_location`, `read_rsu_did`,
  `get_sample_interval_ms`, `build_time_axis_and_t0`, `get_sample_range`,
  `ExtractBytesFromStringOfBytes`, `CovertBetweenIntelAndMotorola`, `int_to_hex`…
- `check_sequence.py` (`CheckSequence_Begin/End`, `Verify_CheckSequence_for_SpecificEvent`),
  `dcs_library.py`, `crash_configuration.py` (`get_project_crash_curve_config`,
  `build_rsu_config`), `project_config_loader.py`, `framework_registry.py`
  (`locate_framework_root`, `infer_project_name`, `list_available_projects`),
  `configuration_control.py` (`TestStatus`, `G_Var`), `ascent_batch_lib.py` (flashing),
  `infineon_memtool.py` (calibration), `excel_handler.py`, `apym_imports.py`.

**Before calling any function: confirm it exists and check its actual signature/return contract
in the source file** (most bench calls return `["0000", value]`-style arrays — check index [0]
for success, [1] for payload). Never call a function that is not in `shared_libraries`.

## 18.2 Configuration-driven scripting (no hard-coding)

- Every message name/ID, signal name, key-node designation, invalid/on-fail value, DTC code,
  sample range/interval, qualification/maturation time, bus/channel number, and EOL/VC byte comes
  from the **target project's config** (`cand_config`, `canc_config`, `edr_config`, `dcs_config`,
  `rsu_config`, `project_config`) or the DBC JSON — never a literal in the script.
- If a needed constant is missing from config: **add it to the config file** (or flag it),
  don't inline it. If config disagrees with the DBC, the DBC wins — fix the config (per the
  canc_onfail rule) and note it.
- Scripts must select classic-CAN vs CAN-FD paths via config/project detection
  (`fault_free_profile_classic_can` vs `fault_free_profile_can_fd`,
  `simulate_vin_can_signals` vs `…_fd`), never via copy-pasted per-project forks of the
  same script.

## 18.3 Timing, waits and ignition-cycle discipline

Every `Sleep`/`Wait` must be **traceable to a spec time** — comment which one:

- Fault maturation before Read-DTC: GPO/lamp 2 s (heal 4 s), CAN faults per
  `u8MsgContentErrorDetection/u8NodeAbsentDetection × cycle time`, RSU immediate, plus margin.
  Use `FaultMaturationDematurationLogic`/`faultTimeMeasurement` where available instead of raw
  sleeps.
- NM/network-diag start: 2000 ms (`u8NmIgnStrtupDel`) after IGN ON before CAN-fault
  injection/VIN checks; NM restart delay after UV/OV recovery.
- Lamp settle after `SetGpoFaultCondition`: the wrapper already sleeps 4–5 s — do not add more.
- Proveout observations: 6 s ON + 1 s OFF window; PADI runtime update ≤ 25 ms (poll, don't sleep
  long); OCS via 0x5FF ~1 s settle; buckle "Reserved" only < 300 ms after IGN ON; VIN set = 1.5 s,
  3 sets for mismatch; STS_ENG timeout quali ~10 s / dequali ~500 ms; security delays 3 s / 5 s.
- **T0-relative EDR simulation: NO sleeps at all** — simulation values are laid out on the
  recording-interval grid (`get_sample_interval_ms`, `build_time_axis_and_t0`,
  `get_sample_range`) and the crash triggers at T0; read DTC/EDR only after the recording
  interval completes.
- Ignition cycling: use `POWER_CYCLE` (or `CAN_Wakeup_Cycle_UPP` for wakeup variants) wherever the
  spec says next-ignition-cycle (EOL/VC effectivity, RSU heal, VC error recovery, historic-DTC
  status `08` after post-crash heal). If the test intent is "healed without ignition cycle", the
  script must explicitly NOT power-cycle — state it in a comment.
- Saleae/PWM capture: `RunSaleaeCapture` started ≥ 5 s before the event window.

## 18.4 Missing functions → ask, don't improvise; new-wrapper policy

- If a step needs an operation with **no existing wrapper**: STOP, report it to the user as a
  missing-wrapper request with a proposed spec — name (matching existing naming style), module it
  belongs in, parameters, return contract (`["0000", value]` style), and which projects/buses it
  must support. **Never** write the raw bench/diag logic inline in a test script, and never
  half-duplicate an existing function. If the operation exists in the legacy ARIA JS API, the
  proposal MUST follow § 18.6 (same ARIA name/prototype, PDF section cited, channel-resolution
  pattern from `CAN.SendDiagByValues`).
- New wrappers (once approved) must be: **project-agnostic** (all constants via parameters or
  `project_config_loader`), **bus-configurable** (channel resolved through the
  `jscript_translation` channel resolvers; works for classic CAN and CAN FD where applicable),
  placed in the correct shared module (bench objects → `jscript_translation`, sequences →
  `core_functions`, decode → `data_conversions`/`edr_decoding_functions`), and reusable —
  one generic function, not N variants.
- **Do not add or modify existing shared-library functions unless strictly necessary** — 900+
  generated scripts depend on current signatures. If a change is unavoidable, keep the signature
  backward-compatible (new optional kwargs only) and state the impact analysis.
- **No throwaway helpers**: no per-script `def` helpers duplicating library behavior, no unused
  imports, no debug prints. If the same 3+ lines appear in several scripts, that is a wrapper
  candidate (→ missing-wrapper request), not a copy-paste.

## 18.5 Script structure & hygiene

- Follow the existing module's script pattern (open a neighbouring script in the same
  `modules\<MODULE>\scripts\` folder and mirror its skeleton): imports via the framework import
  mechanism (`import_list`/`apym_imports`), `create_report_and_logging` at start, precondition
  block (`Set bench to normal condition` = fault-free profile + `FaultFreeCalibration`/
  `Fault_Free_sequence`), numbered steps matching the Excel test case 1:1, `ResultStep`/
  `RESULT.InterpretEqualResult` for **every** expected observation (never a bare comment),
  cleanup block (heal faults, `ReloadDefaultPeriodicFrame`, `Clear_DTC_Info`/`NVM_Clear_L61`,
  restore power) that runs even on failure paths.
- File naming: `SUBS_<Module>_<Feature>_TestCase_<N>_<M>.py` matching the Excel test-case name;
  one test case per file; scenario suffixes as used in the module (`_MCF_PreCrash`, …).
- Expected values computed via `physical_to_raw`/`raw_to_physical` with DBC scaling/offset —
  never pre-baked magic numbers without the conversion shown in config.
- Remember the generator rule: modules with generators (IO control ← `IO_Full.csv`, UDS ←
  `ServiceID.xlsx`) are changed by **editing the generator**, not the emitted scripts.

## 18.6 Legacy ARIA JS API porting layer (`jscript_translation.py`) — how wrappers come to exist

**Background.** The old test environment ran JavaScript (ScriptStudio) test scripts against the
Veoneer **ARIA** bench API — built-in objects (`CAN`, `PS`, `LAMPS`, `SQUIB`, `RSU`, `SPI`,
`RESULT`, …) callable as-is. `shared_libraries\jscript_translation.py` re-implements those APIs
**1:1 in Python** so legacy JS scripts port with minimal edits and new Python scripts keep the
familiar call style. Only a subset is ported so far; the rest are created on demand following the
rules below. The authoritative prototype source is the **"ARIA User Functions" document (Veoneer,
ARIA 4.x, 266 pages)** — every legacy function's exact name, parameter list, return contract and
usage example lives there; always match the wrapper against it.

**ARIA namespace catalog (per the User Functions doc):**

| §  | Namespace | Scope (representative functions) |
|----|-----------|----------------------------------|
| 2  | `LAMPS` | ConfigureLamp, StartLampMonitoring (durations = multiples of 500 ms, ≤ 60000 ms; stop-mode not for scripts), GetLampRecordedSamples/InstantStatus/FilteredStatus (ON/OFF/Dimming/Flashing/Indeterminate + freq/duty), GetLampFDStatus, GetLampENSFrequency/ENSDutyCycle, Set/GetLampLsHs, Set/GetLampDimmingFrequency, Set/GetLampFlashingOffTime |
| 3  | `SPI` (+`ARIA.iUpdate_EVTWrapper`) | SendEvt, UpdateProtocolInfo (GEN6 CRC/counter options), TriggerEvtErrors, SimulateSensor, CrashTriggerSingle/Continuos, SendCrashData (1–5 curves, ± inverted), SendDeflectionCurves (1–5), ResetSpiCard, GetVersion, ReadCardInfo, ChangeState (loadbox GPIO states) |
| 4  | `RSU` | SetStartUpFile/SetConfigFile (all-sensors or per-slot; sensorStatus −1…0x3FF, repetitionFactor), SelectCrashFile, StartCrash, ResetRSU, LoadCurve, SendAcceleration (± inverted), SetIdFault, SetFault (fault names: Clear, OPEN-NC, OPEN-ND, STB, STG, Manchester, Parity, I-Modulation, I-Ide, Polarity, Lkg-To-Batt, Lkg-To-Gnd, ID-Fault), SetFaultOpen/NoData/ShortGround/ShortBattery/Mancester/Parity, ClearFault, iUpdateDriveDataWrapper, SendPlayback, SendBlendedSamples (fault active from StartTime to StopTime ms), GetFeedVoltage |
| 5  | `ARIA.ODS_*` / `ODS` (K-line) | ODS_Parameters (T2/T3/default/trigger), ODS_InitializationData, ODS_DataOnKline (error bit-field: bits0–2 enable B1–B3, bits4–6 parity faults; normal = 0x07; repetition 255 = indefinite), ODS_ChangeData, ODS_Configure (Mazda/Nissan), ODS_UpdateData(OTG), ODS_ClearSaveRead, Start/StopLoggingToFile |
| 6–7| `SQUIB` | SendRequest (loadbox action names: OPEN, INHERENT, CLOCKSPRING…), GetTTFandFDandFAResults, GetDeployAmplitudeSamples (+RESULT.PlotChart), ConfigureMicroUCut/StartMicroUCut |
| 8  | `SLS` | SendRequest by loop name or ID (loadbox actions: NotSuppressing, OutOfRange, Opencircuit…) |
| 9  | `PS` (~109 fns) | PowerOn/Off(±name/±delay), ResetCard, Set/ClearPushPull/PPVBAT/PPIGN, Get voltage/current, SetVoltage/ClearVoltage/ReadVoltage/StatusVoltage, Set/Clear/Status4Q (±slot, ±amplifier), SetCurrent(Limit) (0.5–10 A), Set/Clear VBAT/IGN/VBATIGN, Start/Stop/StatusDiagFrame, **leakage relays** SetLeakageGNDBusHigh/Low & SetLeakageVBATBusHigh/Low (each Set auto-clears its opposite to avoid shorts), Set/ClearModulePower, external VBAT/IGN relays, StatusRelay, RemotePowerDown/Up (CAN blocks after powerdown until PowerUp), LoadCurve/LoadUCutCurve/LoadWaveFormCurve (waveform samples 5–30 V @10–65530 µs; ucut samples 0/1 @1–8191 µs; plain .txt one sample/line), Start/Stop Curve/UCut/WaveForm, SendCurve (load+start), ReadStatus/Write/Read (external supplies), SetMultipleSequence |
| 10 | `DMM` | Open/CloseSession (VISA address), Read(cnt), SendSingleRequest (step 0–8), Write, scanner fns, SingleRead Voltage/Current AC-DC, Period, Resistor, FResistor, Frequency, Diode |
| 11 | `ACL` | Start/Stop, Get/Change Period (2020–1250000, multiple of 20) / DutyCycle / Frequency (0.8–495) |
| 12 | `RD` | SetResistance/ReadResistance, Set/ReadConnectionPoints (Ch1: No_connection/Ch1_Feed/Ch2_Feed/Bus_L/Bus_H/Batt/User_Plus; Ch2: …/Dut_Gnd/User_Minus), ReadUniqueId/ReadStatus/Calibrate |
| 13 | `ARIA` | AFT_GetTTFAndFDResults/GetTTFResults/FDResults, GetTestEnvironment (AriaSWVersion, CANcaseSerialNumber, Cards list), CheckTimeAfterCanCardGetsReadyToListen, AriaOnEventOnRxFrame (RTSE: RX-signal trigger → TX-signal action; 3 overloads incl. raw startbit/bitlength/byte-order; StartDelay/ActionDuration always 0), LoadProfile (loadbox init profile JSON) |
| 14 | `CAN` (~150 fns) | Periodic frame control (Enable/Disable/Start/Stop/Reload/Remove/ChangeID/ChangePeriodicity/ChangeSignal/GetFrameValue, Hw-simulated variants), dynamic signals (Enable/DisableDynamicSignal = CRC/alive-counter control), DTC set (CheckDTC/CheckSingleDTC/CheckOneDTC/CheckMultipleDTC/CheckAllDTCExceptIgnored, ReadAllDTC Codes/Names/WithStatus, internal DTCs, Get/Parse DTC codes/names, ClearDtcs), diagnostics (SendDiagByValues/ByMnemonic, VerifyDiagByValues/ByMnemonic, ServiceSend, SecurityAccess(OnChannel), OpenSession, GetSecurityAccessKey, SetDiagnosticAdressingMode, SetFlowControlRequestId), frames (SendFrame/FD/List/Sw/Remote/SwEmulated, Receive(MostRecent)Frame(WithTimestamp), LastReceivedFrame, VerifyFrame, SendAndWaitForResponseOrTimeout, CreateFramePayloadObject + GetSignalObjectByFrameIdAndContainingPatternName + GetSignalValueFromPayload), config loading (LoadMain/Periodic/Services/DTC/Mnemonic/Symbol/ProductDll/MatrixFile, ChangeErrorCodes, ChangePaddingByte), logging (StartLoggingToFile/ToMemory/FromScriptStudio + filters, StopLogging*, ReadFromCanLogFile/MemoryLog, LoadAndPlayCanLog, SortLogByTimestamp, ExtractSignalsValuesToCsv, InsertLogMessage), memory/flash (Read/WriteMemoryParameters, ReadRamErrors/ReadEEPErrors, GetSymbolAddress/Size, Upload/DownloadSRECFiles, RequestDownloadToECU, TransferDataBlockFromODXFile, FilterFlashingFile), events (CreateOnChangeSignalEventChangeSignalAction, ClearOnEventList), PDU/update-bit fns, interface (Open/Close/Reset CAN, ResetClock, SetInterfaceCANToChannel, CheckMsgCycleTime/CheckMsgDLC, GetAllPeriodics, WaitTimer) |
| 15 | CAN FD | SendFrameFD overloads (byte[]/string payload, ± channel) |
| 16 | `FR` (FlexRay) | SetDiagnostic(Slot)AddressingMode, ChangeTimeout, WriteDefaultApplication (JLR flash), update-bit/PDU fns |
| 17 | `Lin` | SendMasterId, ChangeEventResponse |
| 18 | `RESULT` | InsertTestCaseStart/End, InsertFile/Picture/Comment, InterpretEqualResult(±expected,±log/picture)/Range/WithoutCheck, KInterpretEqualResult, LogAction, LogCustomAction, PlotConfigProp, PlotChart |
| 19 | `MessageBox` | Show(text, ±timeout) — **avoid in unattended scripts unless timeout given** |
| 20 | `LOG` | LoadCanLog (LogCanFrame collection: Filter/Sort/GetStatistics/AppendStatistics/Save), CreateCanLogForPlayBack (AddFrameToLog/Save) |
| 21 | `BOOTHOST` | GetCardFirmwareInfo/GetFileFirmwareInfo/UpdateFirmware (FirmwareInfo object, Outcomes enum) |
| 22 | `HarnessSwitch` | ResetHS, ChangeRelaysStatus, GetRelayStatus, GetErrorStatus |
| 23 | `AES` | GenerateM1…M5, GenerateM1M2M3, GenerateAesSelfTestResponse (product library, e.g. "FordRCM9") |

**Porting status** (verify in source before use — this list moves): classes already present in
`jscript_translation.py`: `CAN`, `LAMPS`, `PS`, `SQUIB`, `RSU`, `SPI`, `SLS`, `ARIA`, `PowerCard`,
`RESULT` (+ module-level `Sleep`/`Wait`/`CommentStep`) — but **each class implements only a subset
of the PDF's methods**. Not yet ported at all: `ODS`, `DMM`, `ACL`, `RD`, `FR`, `Lin`, `LOG`,
`MessageBox`, `BOOTHOST`, `HarnessSwitch`, `AES`.

**Rules for creating a new ARIA-compatible wrapper** (reference implementation:
`CAN.SendDiagByValues` in `jscript_translation.py` — copy its shape):

1. **Same namespace, same method name, same call style** as the ARIA User Functions doc — a
   `@staticmethod` on the matching class — so ported JS scripts and the 900+ existing Python
   scripts keep one familiar API. Fidelity check the prototype (parameters, order, defaults,
   return) against the PDF section before writing code; where the PDF itself has typos (e.g.
   FR pdu functions all titled `SetUpdateBitOnSignal` in the prototype row), name the wrapper
   after the **section heading**, not the typo.
2. **Channel arguments become optional and name-based, resolved through config** — this is the
   "works on any channel, any project" requirement. Pattern from `SendDiagByValues`:
   the legacy `byte channel` first parameter becomes `channel_name: str | None = None`; if the
   caller passes only the remaining args, shift them (`if data is None: data = channel_name;
   channel_name = None`) and resolve the default channel from the loaded project profile
   (`_resolve_simulation_channel_id` / `_resolve_diag_channel_id` over `vehcSimulationChannels` /
   `diagChannels`). Named channels are matched via `_find_matching_channel_name`. **Never
   hard-code a channel/simulation id in a wrapper**; a wrapper is correct only when the same code
   drives CAN-FD on M314 and classic CAN on U171/W616 purely from the project profile.
3. **`require_runtime()` first**, then implement against the new APYM/ARIA Python API (`Api.*`)
   using the existing private helpers (`_prepare_diag_payload`, `_format_diag_response`,
   channel resolvers) instead of duplicating parsing logic.
4. **Return contract exactly as the PDF documents it**: `[0]` = `"0000"` on success, the
   namespace's documented NOK code otherwise (`"1000"` bench cards, `"1111"` newer PS/LAMPS/DMM
   APIs, `"1020"` external supplies), `[1]` = payload/message. Scripts already branch on
   `result[0] == "0000"` and read `result[1]` — breaking this contract breaks every consumer.
5. **try/except inside the wrapper** — return the error in the contract, never raise into a test
   script; log actions through `RESULT`.
6. **Encapsulate the documented device behaviors and constraints in the wrapper**, not in
   scripts: PS leakage-relay mutual exclusion, LAMPS 500 ms monitoring granularity, PS curve
   sample ranges/units, ODS error bit-field semantics, RemotePowerDown CAN-block, RSU fault-name
   enumeration. A script must be able to call the wrapper naively and get spec-conformant bench
   behavior.
7. New wrappers land in `jscript_translation.py` under the correct class (create the class if the
   namespace is unported), are proposed to the user first per § 18.4 (missing-wrapper report now
   cites the **ARIA PDF section + prototype**), and never modify existing method signatures.

# 19. Test-Case Review & Cross-Document Validation Protocol

Reviewing existing test cases (or implementations) is an expert peer review, not a formatting
pass. It runs in four phases: ingest everything → understand the module → review against the
checklists → deliver an evidence-based report. No implementation or review conclusion may be
produced before phase 1 and 2 are complete.

## 19.1 Phase 1 — Full ingestion and cross-document correlation

Before reviewing anything, ingest ALL relevant sources per § 16.5 (Excel) and § 16.6 (PDF/Word):
the module's requirement tracker(s) for the **correct variant**, the DBC JSONs, the on-fail spec,
the FltMonr configurator, the project's `config\` files, the existing scripts and SwQTS test
exports for the module, applicable standards clauses (ISO 14229/11898/26262, AUTOSAR SWS), and
this document (especially the D-register § 3.1 and the module section §§ 1–12).

Then run an explicit **correlation pass** across the sources and record, before judging any
single test case:

- **Contradictions** between documents (requirement vs DBC, requirement vs on-fail spec, two
  requirement rows, spec vs existing implementation) — log them D-register-style
  (*Source A says / Source B says / recommended resolution*), and check § 3.1 first: many are
  already catalogued (D-01…D-12).
- **Duplicates** (the same requirement/test expressed twice, possibly with drift between copies).
- **Inconsistencies** (same signal/DTC/timing named differently or valued differently across
  documents; variant content mixed into the wrong project).
- **Missing information** (requirement referenced but absent, figure-only content, DIDs/DTCs in
  tests with no requirement row, config keys used but undefined).

Implementation and review decisions are made only after this pass; where a conflict is
unresolved, the review flags it as an open question instead of silently picking a side.

## 19.2 Phase 2 — Module-aware context (no generic reviews)

Identify, for the specific module under review, before evaluating a single step — using §§ 1–2
of this document plus the module's tracker and code:

responsibilities and safety goals it serves; interfaces (CAN messages/signals, DIDs/RIDs, HW
pins, PSI5/SPI channels); dependencies (which AAUs feed it, which config blocks gate it);
inputs/outputs with valid ranges per DBC; internal state machines and their transition triggers;
safety mechanisms (interlocks, on-fail substitutions, suppression conditions); diagnostic
interactions (DTCs owned, quali/dequali times, enable/suspend conditions, snapshot content);
communication behavior (periodicity, CRC/alive-counter, NM gating); timing constraints (init
budgets, maturation, recording windows); and hardware dependencies (loadbox cards, energy
reserve, resistance codings).

Every finding and recommendation must be phrased in the module's own terms (its signals, DTCs,
timings, states) — a recommendation that could apply to any module unchanged is not finished.

## 19.3 Phase 3 — Per-test-case review checklist

Verify each test case, as applicable, for:

- **Traceability & coverage**: `Verifies` IDs exist, are Approved, belong to the right variant
  (§ 16.2); the test actually exercises what the requirement states; requirement coverage across
  the suite (every Approved functional requirement of the module has ≥ 1 test).
- **Functional correctness & logic**: expected behavior matches requirement + DBC + on-fail spec;
  logical flow of steps is executable in order; test sequence has no hidden dependency on a
  previous test's state.
- **Pre/postconditions**: environment setup present (fault-free profile, config/EOL state, bus
  state, wake source); cleanup restores bench (heal faults, reload frames, clear DTC/NVM unless
  crash-locked, restore power) even on failure paths.
- **Boundaries & negatives**: boundary values (N−1/N/N+1, threshold edges per § 8), invalid
  inputs, negative scenarios and NRC cases (§ 16.4), corner cases (wake source × voltage ×
  bus-state combinations per § 9).
- **Timing**: waits traceable to spec times (§ 18.3); quali/maturation respected before reads; no
  sleeps in T0-relative sequences; timing tolerances stated where the spec gives them.
- **State & modes**: state-transition coverage (NM states, RSU phases, sessions); behavior in
  degraded modes (UV/OV, bus-off) where the requirement distinguishes them.
- **Safety, diagnostics, recovery**: crash-lock and deployment-inhibit behavior correct; DTC
  codes AND status bytes per § 16.3; heal/recovery paths tested (incl. next-ignition-cycle
  semantics); failure handling (what the test expects when the ECU is already faulted).
- **Regression impact**: whether the change/test invalidates or duplicates existing suite
  content.

## 19.4 Phase 3 — Defect detection list (report every instance found)

Missing test cases and uncovered requirements; incorrect expected results; incorrect/impossible
test steps; wrong diagnostic data (DTC number, **status byte** — CAN faults `0B`, crash locks
`8B`, UV/OV `08`, historic `08`); wrong CAN messages or IDs for the variant (M314 FD set vs
U171/W616 classic set); wrong UDS requests/responses (frame bytes, session/security gates, NRC
and NRC priority); wrong signal values vs DBC (scaling/offset/invalid codes); invalid timing
values (maturation, NM startup, proveout, recording windows); incorrect configuration assumptions
(EOL/VC bits, key-message list, channel); duplicate and redundant tests; ambiguous wording a
tester could execute two ways; incomplete validation (action without an asserted expected
observation); missing cleanup or environmental setup; incorrect assumptions (e.g. healing without
the required ignition cycle, SCF on a signal with no DBC invalid value — D-10-class errors);
requirement conflicts surfaced by 19.1; invalid acceptance criteria (untestable, or contradicting
the standard per § 3.1).

## 19.5 Issue handling — mandatory five steps per finding

For every issue: **(1) Why it is incorrect** — the technical reason, not just "mismatch";
**(2) Evidence** — the requirement ID / DBC signal / spec section+page / standard clause /
agent.md § that contradicts it; **(3) Impact** — what fails, is masked, or falsely passes (and
whether safety-relevant); **(4) Corrected version** — the fixed step/expected result/ID, in the
§ 16 format; **(5) Additional validation** — extra cases the defect reveals as missing, where
appropriate.

## 19.6 Evidence-based analysis (applies to ALL work, not only reviews)

Never invent, assume, or extrapolate a fact. Every conclusion, correction, defect, byte value,
timing, DTC, or ID must be supported by at least one of: a requirement row (tracker + ID), source
code (file:line), a design/interface document (doc + section/page), an industry standard clause
(ISO/AUTOSAR/ASPICE, with number), the DBC, the diagnostic/on-fail specification, or the existing
implementation. When evidence cannot be found: state explicitly *"information unavailable in the
provided sources"*, list it under Open Questions, and do not proceed on a guess — in this domain
an invented value is a safety defect. Recalled/derived values (e.g. computed from DBC scaling)
must show the derivation.

## 19.7 Review deliverables

Every review report contains, in order: **Executive Summary** (verdict + top findings in plain
prose); **Files Reviewed** (with versions/paths); **Requirements Covered** and **Missing
Requirements**; **Requirement Traceability Matrix** (requirement ID → test case(s) → status);
**Test Coverage Matrix** (module behaviors/fault modes → tests); **Identified Issues** each with
**Severity** (Safety-critical / Major / Minor / Cosmetic), **Root Cause**, and **Recommended
Fix** (per 19.5); **Suggested Additional Test Cases** (in § 16 format); **Risk Assessment** (what
ships broken if findings are ignored); **Assumptions** (each one justified — ideally none);
**Open Questions**; **Confidence Level** (High/Medium/Low per area, with the reason — e.g.
"Low: figure-only spec content not extractable"); **References** (every document, tracker, DBC,
standard cited, with revision and page/row).

# 20. Copilot Instructions

When assisting on this codebase/ECU:

1. **Answering questions**: cite the module (§ above) and, where relevant, the discrepancy
   register. Distinguish explicitly: *Requirement says… / Standard says… / Recommended…*. If the
   answer touches deployment, security, or crash-lock behavior, flag safety impact first.
2. **Generating code**: follow § 6–7 (naming, layering, calibration-not-literals, table-driven
   state machines, FltMonr reporting on every error path). Never generate code that: fires or
   arms squibs outside the documented interlocks, clears crash-lock DTCs, bypasses security
   counters, or hard-codes variant behavior that is EOL/VC-controlled.
3. **Reviewing code**: apply § 13/§ 15. Prioritize: firing path > fault reaction correctness >
   diagnostics conformance > style.
4. **Generating tests**: follow § 8–9 for content and **§ 16 for format — mandatory**: Veoneer
   Excel structure (Test Case Name / Step No / Test Step / Expected Observation via the
   `excel_testcase_veoneer_format_v2_tweak.py` pattern), a `Verifies` list with **correct
   Codebeamer requirement IDs mapped per § 16.2** (search the module's tracker Description column
   for the tested behavior; Approved rows only; never invent IDs — use TBD + flag), DTC codes
   with correct status bytes per § 16.3 (**CAN faults active = `0B`**, crash locks `8B`, UV/OV
   stays `08`, historic `08`), and exact NRC expectations per § 16.4. Always create both
   HW-IGN-ON and CAN-wakeup variants when the behavior depends on wake source; respect quali
   times before DTC reads; no sleeps in T0-relative sequences; use bench APIs
   (`CAN.PeriodicDisableFrame`, `CAN.DisableDynamicSignal`, `CAN.PeriodicChangeSignal`,
   `LAMPS.ConfigureLamp`, `Read_DTC`, `RunSaleaeCapture` — start Saleae ≥ 5 s early) as
   documented in § 9. Verify signal values against the **DBC JSONs**, not spec prose.
5. **Suggesting diagnostics**: use the DID/DTC catalogues (§ 10); propose NRCs per the priority
   chain; remember NRC 88 speed gates and plant-mode NRC 22 behaviors.
6. **Safety**: never assume undefined behavior — if a state/event combination is unspecified,
   propose the fail-safe (warning lamp + no actuation + FltMonr event) and ask. Prefer the
   standard (ISO 14229 / 11898 / 26262 / AUTOSAR) over ambiguous requirement text, but implement
   OEM-specific documented deviations (e.g. D-07 NRC 12) as specified.
7. **Identifying inconsistencies**: when two requirements conflict (see D-01, D-02, D-06),
   do not silently pick one — surface both, recommend one with rationale, and mark the code with
   a traceable comment referencing the clarification issue.
8. **When to ask for clarification**: anything touching D-01 (VIN-deployment inhibit), bit-layout
   ambiguities (D-08), undocumented DTC numbers, new EOL/VC bits, or timing changes to the ENS/
   EDR/initialization budgets.
9. **Variant awareness**: check which platform (M314 FD-CAN vs U171/W616/Z121 classic-CAN) a file
   serves before reusing message IDs, DLCs, CRC schemes, or default feature codes (D-11).
10. **Never restate requirements as answers** — explain the engineering *why*, cross-reference the
    standard, and state the production-grade implementation.
11. **Writing framework scripts**: follow § 18 strictly — only existing `shared_libraries`
    wrappers (verify name + signature in the source first), all constants from the project's
    `config\` files / DBC, every Sleep/Wait traceable to a spec time, ignition cycles where
    next-cycle semantics apply, no sleeps in T0-relative EDR sequences, no inline helpers or raw
    bench logic. If a wrapper is missing, stop and ask the user with a § 18.4 missing-wrapper
    proposal (project-agnostic, bus-configurable); never modify existing library functions unless
    strictly necessary and backward-compatible. For legacy ARIA JS functions not yet ported to
    `jscript_translation.py`, design the wrapper per § 18.6: identical ARIA namespace/method
    name and prototype (validated against the ARIA User Functions PDF), optional config-resolved
    channel argument (the `CAN.SendDiagByValues` pattern), the documented `["0000", …]` return
    contract, and device constraints encapsulated inside the wrapper so it works unchanged on
    every project and bus.
12. **Large/batch tasks (test-case sets, module script suites, coverage sweeps)**: orchestrate per
    § 17 — plan, fan out specialized sub-agents (requirement-mapper, test author, script writer,
    library auditor, config auditor), integrate once at the end, and run the mandatory § 17.1
    verifier gate (requirement IDs exist & Approved, DTC status bytes correct — CAN faults `0B`,
    functions exist, config-driven, timing rules) before delivering anything. Workers flag
    uncertainties to the user instead of guessing.
13. **Reading Excel/requirement sources**: always follow § 16.5 — dump the entire workbook
    programmatically (openpyxl, every sheet, every row), resolve columns by header name never by
    index, preserve cell content losslessly (decode Codebeamer escapes/markup, treat
    strikethrough as deleted, parse wiki-tables instead of skipping them, flag embedded images as
    unextractable gaps), verify the extraction (row counts + spot-checks) before using it, and
    never answer from a partial read, a screenshot, or memory of the file.
14. **Reading PDFs/Word documents**: always follow § 16.6 — select the right library per document
    (pymupdf/pdfplumber/camelot for native PDFs, ocrmypdf/pytesseract+opencv for scanned pages,
    layoutparser/unstructured for complex layouts, python-docx for Word; install on demand),
    extract page-by-page with tables kept intact and page references retained, auto-detect
    scanned pages and validate OCR confidence (`[OCR-UNCERTAIN]` markers), associate figures with
    captions and flag diagram-only content, cross-check completeness, and report extraction
    quality instead of guessing missing content.
15. **Reviewing test cases or implementations**: run the full § 19 protocol — ingest and
    correlate ALL sources first (contradictions/duplicates/gaps logged before judging anything),
    build module-aware context (§ 19.2) so findings are specific to the module's signals, DTCs
    and timings, review against the § 19.3/19.4 checklists, handle every finding with the § 19.5
    five steps (why wrong → evidence → impact → corrected version → added validation), obey the
    § 19.6 evidence rule (no unsupported claims; "information unavailable" instead of guesses),
    and deliver the § 19.7 report structure including severity, traceability matrix, risk
    assessment, open questions and confidence level.
16. **Environment & lookups**: use the § 21 repository map and interpreter facts instead of
    rediscovering them; take constants from the § 21.3 quick-reference card (verify against the
    source on first use in a task); follow the § 22 playbook matching the task type.
17. **Hardware & repository safety**: obey § 23 without exception — never execute anything that
    actuates the bench/ECU (power, crash, flashing, EOL/VC/VIN/NVM writes) unless the user
    explicitly asked to RUN it in this conversation; writing a script is not permission to run
    it; never hand-edit generated artifacts or commit dumps/caches.
18. **Keeping this document alive**: when work reveals that agent.md is wrong or incomplete
    (a D-item resolved, a wrapper ported, a tracker revised), update it per § 25 in the same
    change-set — a stale knowledge base is worse than none.

# 21. Environment, Tooling & Repository Map

## 21.1 Interpreters and tooling facts (verified on this machine)

- **Extraction/analysis Python**: `C:\Python 3.14.0\python.exe` — has `openpyxl` (and is where
  new extraction libraries should be installed:
  `& "C:\Python 3.14.0\python.exe" -m pip install <lib>`). The bare `python` on PATH is a
  **different** install (3.10-era, used by the legacy tooling under `C:\Python3.10.4\Scripts`)
  and lacks these packages — using it silently fails.
- Test-case Excel writer pattern: `C:\Python 3.10.4? / C:\Python 3.14.0\Scripts\scripts\`
  `excel_testcase_veoneer_format_v2_tweak.py` (§ 16.1 defines the format it produces).
- ARIA User Functions PDF (authoritative for § 18.6):
  `C:\Users\cpchr\Downloads\Phone_dump-18-01-25\Download\Bluetooth\ARIA User Functions.pdf` —
  **outside the repo and liable to move**; recommended action: copy it into `req\` and update
  this line.
- Shell is Windows/PowerShell 5.1: no `&&`/`||` chaining, quote paths with spaces, prefer
  absolute paths.

## 21.2 Repository map (where every kind of truth lives)

| Path | Contents / role |
|---|---|
| `agent.md`, `AGENTS.md`, `.github\copilot-instructions.md` | This knowledge base + the two auto-loaded pointers (keep all three in sync, § 25) |
| `shared_libraries\` | The ONLY place for reusable test logic (§ 18.1); `jscript_translation.py` = ARIA porting layer (§ 18.6); `project_config_loader.py` / `framework_registry.py` = project/profile resolution |
| `projects\<PLATFORM>\config\` | Per-platform configs (`project_config`, `cand_config`, `canc_config`, `edr_config`, `dcs_config`, `rsu_config`) — the source for every constant a script uses (§ 18.2). Folder naming: one platform folder can serve several variants (e.g. `M310_M314_M110`) |
| `projects\<PLATFORM>\modules\<MODULE>\scripts\` | Test scripts (CANC, CAND, CANNM, DCS, EDR, EOL, E_CALL, Fault_List, GPO, IMU, OCS, ODS, PlantMode, POWER, …); `test_data\` holds curves/inputs |
| `req\m314\` | M314 requirement trackers (CAN_C, EDR, EOL, FaultList, GPO, NM, RSU, UDS) + `tc_edr\` SwQTS test exports (Bootloader/CANC/EDR/IOControl/UDS) |
| `req\u171_616_z121\` | W616/U171/Z121 trackers (CAN_C, Customer DID/IOControl/Routine lists, EDR, EOL/VC/VIN additionals, FaultList, Process GPO) |
| `req\EDR_info\` | On-fail specification (§ 2.8) + canc_onfail.md test-design notes |
| `req\fault_monitor\` | FltMonr Configurator workbook (§ 2.11 — DTC/debounce/event-ID source) |
| `req\io_testcases\` | `IO_Full.csv` (IO-script generator input) + `M310_DBC\*_signals.json` |
| `req\u171_dbc\` | U171 DBC JSON |
| `req\module info prompt\` | `ServiceID.xlsx` (UDS generator input), `M314_ECU_IDentifiers.xlsx`, bootloader spec, system requirements extract, bench-physics notes (DCS/STPS/ENS prompts) |
| Generators | IO-control scripts ← `IO_Full.csv`; UDS scripts ← `ServiceID.xlsx` via `generate_uds_scripts.py`; FltMonr `*_Lcfg` ← Configurator workbook. **Always edit the generator/input, never the emitted files** |

Scratch outputs (workbook dumps per § 16.5/16.6, intermediate CSVs) go to the session scratchpad
or a git-ignored working folder — never into `req\` or the module folders, never committed.

## 21.3 Quick-reference card (verify against source on first use; § 3.1 D-items marked)

| Fact | Value |
|---|---|
| Diag CAN IDs | request `0x730` phys / `0x7DF` func → response `0x738` (variant extra: `0x7F9`) |
| P2 / P2* / S3 | 50 ms / 5000 ms / 5 s (session resp `50 03 00 32 13 88`) |
| Security | L1 seed/key SF `01/02` (extended); L3 `05/06` (ext+programming); lockout: 3 s delay, 5 s post-reset, NRC 36 from 11th attempt (NVM-persistent), max 5 L1 unlocks/cycle |
| Config write gates | ext session + L1 + speed < 5 km/h (NRC 88); effective **next ignition cycle**; survive flashing |
| CAN init | no TX < 150 ms (`T[CANInit]`); diag ready < 500 ms; network diagnostics from `u8NmIgnStrtupDel` = 2000 ms |
| CRC / alive counter | HS: SAE J1850 CRC-8 (poly 0x1D, init 0xFF, xor 0xFF, check 0x4B); FD: E2E Profile 5; counter range 0–15 or 0–14 per EOL Byte6 Bit2 (**D-03**) |
| DTC status bytes | CAN faults active `0B`; crash locks `8B`; UV/OV stays `08`; historic `08`; post-crash heal → historic only after ignition cycle (§ 16.3) |
| Crash-lock DTCs | front `90 61 96`, PT `92 1A 00`, side `92 01 00`, rear `92 1E 00`; near-crash = no DTC |
| ENS/GPO0 | 40 ms period; normal 62.5 % duty; crash 37.5 % for 800 ms (20 cycles); init high 350–400 ms (< 450 ms); STG high / STB low / OPEN −50 % ampl.; deconfig DTC `923456` (**D-06** on idle level) |
| PADI/lamps | proveout 6 s ON + 1 s OFF; runtime update ≤ 25 ms; GPO faults mature 2 s / de-mature 4 s; suppressed in UV/OV |
| EDR | multi-event 0.8–5 s between T0s; trigger ΔV > 8 km/h in 150 ms or any deploy; power-loss write budget 150 ms; near-crash records but never locks |
| Voltage window | network diagnostics ~7–19 V; outside → on-fail values + DTC suppression |
| VIN | EMS5_500, 3 frames × 500 ms; mismatch after 3 failed sets; **D-01** (deployment inhibit) unresolved |
| Bench return contract | `[0]=="0000"` OK; NOK `"1000"`/`"1111"`/`"1020"` per namespace (§ 18.6 rule 4) |

# 22. Task Playbooks (route the task, then follow the sections)

1. **Answer an ECU-behavior question** → find the module in §§ 1–12; check § 3.1 D-register for
   known contradictions; if the answer needs a source fact not in this doc, extract it per
   § 16.5/16.6; answer with evidence per § 19.6 (requirement ID / DBC / page).
2. **Write test cases for a module** → dump the correct variant tracker (§ 16.5) → map behaviors
   to requirement IDs (§ 16.2) → author in the Veoneer format (§ 16.1) with DTC bytes (§ 16.3)
   and NRCs (§ 16.4) → self-review against § 19.3/19.4 → deliver with the traceability table.
3. **Write or modify a framework script** → open a neighbouring script in the same module folder
   and mirror it (§ 18.5) → confirm every constant exists in `projects\<P>\config\` (§ 18.2) →
   confirm every wrapper exists with the right signature (§ 18.1) → apply timing/ignition rules
   (§ 18.3) → syntax-verify (`py_compile`) and state plainly that it has NOT been run on the
   bench (§ 23).
4. **Port a legacy JS script** → list its ARIA calls → check each against `jscript_translation.py`
   → ported: convert 1:1 (channel arg may drop, § 18.6 rule 2) → unported: missing-wrapper
   proposal citing the ARIA PDF section (§ 18.4/18.6) → convert `Thread.Sleep`/`RESULT.*` to the
   Python equivalents; re-justify every sleep per § 18.3.
5. **Review existing test cases/scripts** → full § 19 protocol; deliver § 19.7 report.
6. **Batch work (suites, sweeps, migrations)** → § 17 orchestration with the § 17.1 verifier gate.
7. **New variant/project support** → new `projects\<P>\config\` set from the variant's own
   trackers (D-11: never merge variants), DBC JSON in `req\`, key-message list from the on-fail
   spec, defaults per that variant's EOL tracker.
8. **A source document changed/arrived** → re-extract per § 16.5/16.6, diff against what this doc
   states, update the affected sections + D-register per § 25.

# 23. Agent Safety & Permission Boundaries (non-negotiable)

This repository's scripts **actuate real hardware**: power cards, squib firing loops
(deployment = pyrotechnic event on a real ECU), ECU flashing, and NVM writes that are
irreversible (crash-lock DTCs) or change device identity (EOL/VC/VIN).

1. **Writing code ≠ running code.** Never execute a script, wrapper call, or command that drives
   the bench or ECU — `PS.*` power actions, crash/`TriggerCrash`/curve loading, `SQUIB.*`,
   flashing (`BOOTHOST`, `ascent_batch_lib`, `infineon_memtool`, SID $34/$36/$37), `manage_eol_code`
   / `manage_variant_code` / VIN writes, `Clear_DTC_Info` / `NVM_Clear_L61` — unless the user
   explicitly asked to RUN it in the current conversation. Deliver scripts as files and say they
   are unexecuted. Syntax checks (`py_compile`, imports) are always allowed; anything touching
   the ARIA runtime is not.
2. **Irreversibility awareness**: deployment crash-locks the ECU (DTCs + EDR survive $14 —
   service action is ECU replacement); a wrong EOL/VC/VIN write can strand a unit until
   re-configured; RemotePowerDown blocks CAN until PowerUp. Call these out whenever a script
   contains them.
3. **Protected artifacts — never hand-edit**: generated scripts (IO-control ← `IO_Full.csv`,
   UDS ← `ServiceID.xlsx`), FltMonr `*_Lcfg`/generated config, fixed-calibration data, and
   existing shared-library signatures (§ 18.4). Change the generator/input instead.
4. **Repository hygiene**: never commit workbook dumps, extraction scratch files, logs,
   `__pycache__`/`.pyc` (note: stale `.pyc` deletions are already pending in git status — that
   cleanup is correct), or large binaries outside `req\`. Never commit or push at all unless the
   user asks (repo-wide rule).
5. **Requirement sources are read-only**: the files under `req\` are OEM/customer deliverables —
   analysis writes summaries elsewhere; it never modifies the sources.
6. **When unsure whether an action reaches hardware or persists state — stop and ask.** The cost
   asymmetry in this domain is extreme.

# 24. Glossary (project vocabulary — resolve ambiguity here first)

| Term | Meaning here |
|---|---|
| ACU / AECU / SRS ECU | The airbag control unit under test (same device, three names across docs) |
| AAU | Atomic Architecture Unit — one software module (CanMgr, RstEdr, …) |
| ARIA / NEEVA | Veoneer bench automation environment (HW cards + API); NEEVA is its host application |
| Loadbox / card / slot | The bench chassis, its plug-in HW cards (power, squib, lamp, RSU, SPI, CAN), and their addresses |
| APYM | The Python API bridge to ARIA used by `jscript_translation.py` (`Api.*`) |
| Key message vs slave message | Node-presence message (stop = Node Absent) vs any other message of that node (stop = Message Timeout) — § 2.8, D-10 |
| NA / MTO / MCF / SCF / VC error | Node Absent, Message TimeOut, Message Content Failure (DLC/CRC/alive), Signal Content Failure, Variant-Code error — the five CAN fault classes |
| On-fail value | Value a received signal switches to after its fault matures (last-valid / default / consume) per the On-fail Spec |
| Quali / de-quali (mature / de-mature) | DTC qualification and healing debounce times |
| Crash lock | Post-deployment state: lock DTCs (`…8B`) + EDR record survive ClearDTC |
| T0 | Time Zero — first crash-algorithm wakeup; all EDR timing is relative to it |
| PDC | Power-up Device Check (init-time HW discovery: loops, GPO, RSU) |
| ER | Energy Reserve — capacitor bank powering deployment/ENS/EDR after supply loss |
| TTF / FD / FA | Time To Fire / Firing Duration / Firing Amplitude (squib measurements) |
| RTSE | Real-Time Scripted Event — ARIA on-event trigger→action (`AriaOnEventOnRxFrame`) |
| Proveout | Post-init lamp/self-test phase (6 s ON + 1 s OFF) |
| WL | Warning Lamp (`INDC_SRS`); "QUALIFIED WITH WL" is a DTC status string in `CAN.CheckDTC` |
| EOL / feature code | DID $0102 — what is physically fitted to THIS ECU |
| Variant code (VC) | DID $0101 — which OTHER nodes exist on the vehicle CAN |
| Virgin ECU / plant mode | Factory-fresh NVM defaults / manufacturing phase-of-life with special diag behavior (NRC 22 on $14, plant DIDs) |
| DCS / ODS / OCS / STPS / DOMS / PADI | Buckle switches / occupant detection / occupant classification / seat-track position / driver monitoring / passenger-airbag disable indication |
| FRSU / SRSU / PRSU / SCS | Front / side (B-, A-, C-pillar, rear) / pressure satellites / underbody strike sensor |
| SwQTS | Software Qualification Test Specification (the Codebeamer test-case exports) |
| Codebeamer | The requirements/test management tool the `req\` Excel exports come from |
| D-xx | An entry in the § 3.1 discrepancy register |

# 25. Maintaining This Document

`agent.md` is a living knowledge base — it is only as safe as it is current.

- **Update triggers** (do it in the same change-set as the work that revealed it): a tracker
  revision arrives in `req\` → re-extract and diff §§ 1–12 + D-register; a D-item is resolved by
  the OEM → record the resolution, keep the item marked *resolved* (history matters); a wrapper
  is ported/added → update § 18.6 porting status; a new variant/project → §§ 1, 21.2 tables;
  a source file moves (e.g. the ARIA PDF) → § 21.1; a new recurring mistake is caught → § 13.
- **Keep the three files consistent**: any new/renumbered section here must be reflected in
  `AGENTS.md` and `.github\copilot-instructions.md` in the same commit. Grep for `§ <n>` after
  renumbering — stale cross-references misroute every future agent.
- **Never fork the content**: the pointers stay slim; full knowledge lives only here.
- **Changelog**: append one line per substantive change at the bottom of this file
  (`YYYY-MM-DD — what changed — trigger`), so reviewers can see drift at a glance.

---

**Changelog**
- 2026-07-11 — Initial version: §§ 1–20 built from full extraction of `req\` trackers, on-fail
  spec, FltMonr configurator, DBC JSONs and framework sources; §§ 21–25 (environment map,
  playbooks, safety boundaries, glossary, maintenance) added — session with Claude.
