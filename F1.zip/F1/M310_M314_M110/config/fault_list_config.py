"""
Module Configuration: Fault_List
Project: M310_M314_M110
============================================================

"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "Fault_List"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── Fault_List Settings ──


