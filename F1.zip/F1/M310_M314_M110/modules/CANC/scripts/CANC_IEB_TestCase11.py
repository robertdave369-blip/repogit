# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_IEB_TestCase11 (Codebeamer ID 35654970)
# Workbook   : IEB_Node_TestCases.xlsx
# Objective  : Verify increment, rollover, and reset behavior of alive counter signal
#              IEB1_MSG_CNT in IEB1_FD_10.
# Automation : Automatic
# Note       : The alive counter is the one the bench transmits; the script checks that it runs,
#              rolls over and restarts in the frames on the bus and that the ECU reports no
#              message content failure throughout.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_COUNTER_SAMPLE_ROLLOVERS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35654970'
    tc_name = 'CANC_IEB_TestCase11'
    tc_desc = (
        'Verify increment, rollover, and reset behavior of alive counter signal IEB1_MSG_CNT '
        'in IEB1_FD_10.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    counter_key = 'IEB1_MSG_CNT'
    counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
    frame = counter_def['frame']
    bus = counter_def['bus']
    period_ms = counter_def['periodicity']
    counter_bits = counter_def['bit_length']
    counter_start_bit = CAN_SIGNAL_START_BIT[counter_key]
    counter_window_ms = (CANC_COUNTER_SAMPLE_ROLLOVERS * (1 << counter_bits) + 4) * period_ms
    restart_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * period_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([counter_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Observe IEB1_MSG_CNT over consecutive messages until it rolls over')
        counter_ids = [counter_def['frame_ID']]
        counter_file = os.path.splitext(log_path)[0] + '_alive_counter.txt'
        counter_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_counter', filepath=counter_file,
            listOption=counter_ids, channel_names=[bus])
        Wait(counter_window_ms)
        CAN.StopLoggingToFile(counter_logger)
        counter_read = CAN.ReadFromCanLogFile(counter_file)
        counter_frames = [
            frame for frame in (counter_read[1] if counter_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in counter_ids]
        counters = [extract_counter(frame_data.payload, counter_start_bit, counter_bits) for frame_data in counter_frames]
        counter_verdict = validate_counter(counters, counter_bits)
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(counters), (1 << counter_bits) + 1, float('inf'))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} increments by one from frame to frame",
                                    str(counter_verdict['errors'][:10]), "[]")
        RESULT.InterpretEqualResultRange(f"{counter_def['signal']} rollovers", counter_verdict['rollovers'], 1, float('inf'))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} range",
                                    f"{min(counters, default=None)}..{max(counters, default=None)}",
                                    f"{counter_def['MIN']}..{counter_def['MAX']}")
        Read_DTC('No message content failure while the counter runs and rolls over', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Cycle IGN and observe IEB1_MSG_CNT after transmission restarts')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        restart_ids = [counter_def['frame_ID']]
        restart_file = os.path.splitext(log_path)[0] + '_alive_counter_restart.txt'
        restart_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_counter_restart', filepath=restart_file,
            listOption=restart_ids, channel_names=[bus])
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        Wait(restart_window_ms)
        CAN.StopLoggingToFile(restart_logger)
        restart_read = CAN.ReadFromCanLogFile(restart_file)
        restart_frames = [
            frame for frame in (restart_read[1] if restart_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in restart_ids]
        restart_counters = [extract_counter(frame_data.payload, counter_start_bit, counter_bits)
                            for frame_data in restart_frames]
        restart_errors = validate_counter(restart_counters, counter_bits)['errors']
        RESULT.LogAction(f"{counter_def['signal']} after the restart", str(restart_counters[:20]))
        # Either the capture opens on the reset value, or the one break in it is the
        # reset to the minimum.
        counter_reset = ((not restart_errors and restart_counters[:1] == [counter_def['MIN']])
                         or (len(restart_errors) == 1 and restart_errors[0][2] == counter_def['MIN']))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} restarts from {counter_def['MIN']}", counter_reset, True)
        Read_DTC('No message content failure after the restart', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame(bus, frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
