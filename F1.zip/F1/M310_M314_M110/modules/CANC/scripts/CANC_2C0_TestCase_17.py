# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_2C0_TestCase_17 (Codebeamer ID 35736864)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Verify Alive counter starts from 0 when Ign cycle is performed.
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_COUNTER_SAMPLE_ROLLOVERS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_HS_ALIVE_COUNTER_MAX,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
    DEFAULT_EOL_CODE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.eol_config import (
    M310_M314_M110_FEATURE_MAP,
)


def run_test():
    tc_id = '35736864'
    tc_name = 'CANC_2C0_TestCase_17'
    tc_desc = (
        'To Verify Alive counter starts from 0 when Ign cycle is performed.'
    )
    automation = 'Automatic'

    alive_byte, alive_bit = M310_M314_M110_FEATURE_MAP['ALIVE_COUNTER']
    default_alive_action = 'enable' if int(DEFAULT_EOL_CODE.split()[alive_byte], 16) & (1 << alive_bit) else 'disable'
    counter_specs = [('SRSHS_MSG_CNT', CANC_HS_ALIVE_COUNTER_MAX['enable'])]
    counter_window_ms = max((CANC_COUNTER_SAMPLE_ROLLOVERS * (counter_max + 1) + 4)
                            * MAH_CAN_SIGNAL_DEFS[counter_key]['periodicity'] for counter_key, counter_max in counter_specs)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Write the EOL code with the alive-counter bit enabled and cycle IGN')
        manage_eol_code('ALIVE_COUNTER', 'enable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Verify the alive counters')
        running_ids = [hs_id]
        running_file = os.path.splitext(log_path)[0] + '_alive_running.txt'
        running_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_running', filepath=running_file,
            listOption=running_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(counter_window_ms)
        CAN.StopLoggingToFile(running_logger)
        running_read = CAN.ReadFromCanLogFile(running_file)
        running_frames = [
            frame for frame in (running_read[1] if running_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in running_ids]
        for counter_key, counter_max in counter_specs:
            counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
            counter_values = [extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key], counter_def['bit_length'])
                              for frame_data in running_frames
                              if frame_data.id == CAN_RX_MESSAGE_CONFIG[counter_def['frame']]['frame_ID']]
            # validate_counter covers power-of-two ranges only; 0..14 needs the modulo check.
            counter_errors = [(index, earlier, later)
                              for index, (earlier, later) in enumerate(zip(counter_values, counter_values[1:]), 1)
                              if (later - earlier) % (counter_max + 1) != 1]
            RESULT.InterpretEqualResult(f"{counter_def['signal']} counts by one", str(counter_errors[:10]), "[]")
            RESULT.InterpretEqualResult(f"{counter_def['signal']} range",
                                        f"{min(counter_values, default=None)}..{max(counter_values, default=None)}",
                                        f"0..{counter_max}")
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN while the counters run, and observe the restart')
        restart_ids = [hs_id]
        restart_file = os.path.splitext(log_path)[0] + '_alive_restart.txt'
        restart_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_restart', filepath=restart_file,
            listOption=restart_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS + counter_window_ms)
        CAN.StopLoggingToFile(restart_logger)
        restart_read = CAN.ReadFromCanLogFile(restart_file)
        restart_frames = [
            frame for frame in (restart_read[1] if restart_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in restart_ids]
        for counter_key, counter_max in counter_specs:
            counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
            counter_rows = [(frame_data.timestamp / 1000,
                             extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key], counter_def['bit_length']))
                            for frame_data in restart_frames
                            if frame_data.id == CAN_RX_MESSAGE_CONFIG[counter_def['frame']]['frame_ID']]
            # The restart is the gap in transmission or, failing one, the first break in the count.
            counter_gap = next((index for index in range(1, len(counter_rows))
                                if counter_rows[index][0] - counter_rows[index - 1][0] > 5 * counter_def['periodicity']), None)
            counter_break = next((index for index in range(1, len(counter_rows))
                                  if (counter_rows[index][1] - counter_rows[index - 1][1]) % (counter_max + 1) != 1), None)
            counter_restart = counter_gap if counter_gap is not None else counter_break
            counter_after = [value for _, value in counter_rows[counter_restart:]] if counter_restart is not None else []
            RESULT.InterpretEqualResult(f"{counter_def['signal']} restarts from 0", counter_after[:1], [0])
            RESULT.InterpretEqualResult(f"{counter_def['signal']} counts by one after the restart",
                                        all((later - earlier) % (counter_max + 1) == 1
                                            for earlier, later in zip(counter_after, counter_after[1:])), True)
            RESULT.InterpretEqualResult(f"{counter_def['signal']} runs up to {counter_max} after the restart",
                                        max(counter_after, default=None), counter_max)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
