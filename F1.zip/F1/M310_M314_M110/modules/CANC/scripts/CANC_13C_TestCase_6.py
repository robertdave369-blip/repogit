# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_6 (Codebeamer ID 35739850)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check Signal Value of Z_AXIS_ACCEL Signal In ID 13C
# Automation : Semi-automatic (operator moves the ECU)
# Note       : The stationary value is graded against CANC_IMU_STATIC_EXPECTED +/-
#              CANC_IMU_STATIC_TOLERANCE and the movement against CANC_IMU_MOTION_MIN_SWING; the
#              case gives no band, so these canc_config values are assumptions to confirm.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_IMU_MOTION_MIN_SWING,
    CANC_IMU_STATIC_EXPECTED,
    CANC_IMU_STATIC_TOLERANCE,
    CANC_MANUAL_ACTION_WINDOW_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '35739850'
    tc_name = 'CANC_13C_TestCase_6'
    tc_desc = (
        'To Check Signal Value of Z_AXIS_ACCEL Signal In ID 13C'
    )
    automation = 'Semi-automatic (operator moves the ECU)'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Verify Z_AXIS_ACCEL on a stationary ECU')
        static_ids = [fd_id]
        static_file = os.path.splitext(log_path)[0] + '_static.txt'
        static_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_static', filepath=static_file,
            listOption=static_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(static_logger)
        static_read = CAN.ReadFromCanLogFile(static_file)
        static_frames = [
            frame for frame in (static_read[1] if static_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in static_ids]
        static_def = MAH_CAN_SIGNAL_DEFS['Z_AXIS_ACCEL']
        static_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['Z_AXIS_ACCEL'],
                                                                 static_def['bit_length']),
                                              scaling=static_def['Factor'], offset=static_def['Offset'],
                                              bits=static_def['bit_length'], signed=bool(static_def.get('Signed'))), 4)
                        for frame_data in static_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{static_def['signal']} on a stationary ECU ({static_def.get('UNIT') or 'physical'})",
                                         static_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['Z_AXIS_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['Z_AXIS_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['Z_AXIS_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['Z_AXIS_ACCEL'])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Move the ECU up and down')
        motion_ids = [fd_id]
        motion_file = os.path.splitext(log_path)[0] + '_motion.txt'
        motion_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_motion', filepath=motion_file,
            listOption=motion_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        RESULT.InsertComment(f'OPERATOR ACTION: Move the ECU up and down during the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        print(f'OPERATOR ACTION: Move the ECU up and down during the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        CAN.StopLoggingToFile(motion_logger)
        motion_read = CAN.ReadFromCanLogFile(motion_file)
        motion_frames = [
            frame for frame in (motion_read[1] if motion_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in motion_ids]
        motion_def = MAH_CAN_SIGNAL_DEFS['Z_AXIS_ACCEL']
        motion_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['Z_AXIS_ACCEL'],
                                                                 motion_def['bit_length']),
                                              scaling=motion_def['Factor'], offset=motion_def['Offset'],
                                              bits=motion_def['bit_length'], signed=bool(motion_def.get('Signed'))), 4)
                        for frame_data in motion_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{motion_def['signal']} follows the movement (swing, physical)",
                                         round(max(motion_values) - min(motion_values), 4) if motion_values else None,
                                         CANC_IMU_MOTION_MIN_SWING['Z_AXIS_ACCEL'], float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
