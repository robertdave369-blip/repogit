# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_2C0_TestCase_33 (Codebeamer ID 35736880)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Verify Reserved bits in 2C0 message
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    NM_IGN_ON_STARTUP_DELAY_MS,
    SRS1_20_RESERVED_BIT_MASKS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736880'
    tc_name = 'CANC_2C0_TestCase_33'
    tc_desc = (
        'To Verify Reserved bits in 2C0 message'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Cycle IGN and verify the reserved bits of every SRS1_20 frame')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        reserved_ids = [hs_id]
        reserved_file = os.path.splitext(log_path)[0] + '_srs1_20_reserved.txt'
        reserved_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_srs1_20_reserved', filepath=reserved_file,
            listOption=reserved_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(reserved_logger)
        reserved_read = CAN.ReadFromCanLogFile(reserved_file)
        reserved_frames = [
            frame for frame in (reserved_read[1] if reserved_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in reserved_ids]
        reserved_set = [(byte_index, f"0x{frame_data.payload[byte_index] & mask:02X}")
                        for frame_data in reserved_frames for byte_index, mask in SRS1_20_RESERVED_BIT_MASKS.items()
                        if frame_data.payload[byte_index] & mask]
        RESULT.InterpretEqualResultRange(f"{hs_frame} frames captured", len(reserved_frames), CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        RESULT.InterpretEqualResult(f"{hs_frame} reserved bits are 0 in every frame", reserved_set[:5], [])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
