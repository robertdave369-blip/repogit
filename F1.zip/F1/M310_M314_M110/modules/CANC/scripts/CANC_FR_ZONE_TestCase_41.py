# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_FR_ZONE_TestCase_41 (Codebeamer ID 35660012)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that FR_ZONE2_100 node-absent fault is healed and message-content failure
#              (DLC) becomes active when corrupted key-message frames resume.
# Automation : Automatic
# Note       : The case expects a node-absent fault on FR_ZONE2_100, but canc_config
#              (KEY_TX_FRAMES, from the customer DTC list) treats FR_ZONE2_100 as a non-key
#              frame, so stopping it reports the message timeout DTC 0xD0 0x04 0x00. The script
#              expects what canc_config gives.
# Note       : The case steps are copied from other cases; the script follows the description
#              and preconditions (primary frame-loss fault, then the frame resumes with
#              corrupted content).

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    get_frame_message_content_failure_dtc,
    is_key_message,
    qualification_ms,
    recovery_ms,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35660012'
    tc_name = 'CANC_FR_ZONE_TestCase_41'
    tc_desc = (
        'Verify that FR_ZONE2_100 node-absent fault is healed and message-content failure '
        '(DLC) becomes active when corrupted key-message frames resume.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    loss_frame = 'FR_ZONE2_100'
    loss_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == loss_frame)
    loss_bus = loss_def['bus']
    loss_mode = 'node_absent' if is_key_message(loss_frame) else 'message_timeout'
    loss_dtc = resolve_dtc_for_event('frame_disabled', loss_frame)
    loss_qualify_ms = int(qualification_ms(loss_mode, loss_def['periodicity']) * margin)
    loss_recover_ms = int(recovery_ms(loss_mode, loss_def['periodicity']) * margin)
    mcf_frame = 'FR_ZONE2_100'
    mcf_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == mcf_frame)
    mcf_bus = mcf_def['bus']
    mcf_dtc = get_frame_message_content_failure_dtc(mcf_frame)[0]
    if mcf_dtc is None:
        mcf_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(mcf_frame)
    mcf_error_frame = mcf_frame + '_DLC_ERROR'
    mcf_error_payload = [0] * CAN_DLC_ERROR_PAYLOAD_LENGTH[mcf_def['dlc']]
    mcf_qualify_ms = int(qualification_ms('message_content', mcf_def['periodicity']) * margin)
    mcf_recover_ms = int(recovery_ms('message_content', mcf_def['periodicity']) * margin)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([loss_def, mcf_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'frame-loss DTC of {loss_frame}', loss_dtc),
            (f'message content failure (DLC) DTC of {mcf_frame}', mcf_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create the primary fault - stop transmission of FR_ZONE2_100')
        CAN.PeriodicDisableFrame(loss_bus, loss_frame)
        Wait(loss_qualify_ms)
        Read_DTC(
            'Frame-loss DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Resume transmission with corrupted content - inject incorrect DLC on FR_ZONE2_100')
        CAN.SetPeriodicFrame(mcf_bus, mcf_error_frame, mcf_def['frame_ID'], mcf_def['periodicity'],
                             mcf_error_payload, mcf_def['is_fd'])
        Wait(max(loss_recover_ms, mcf_qualify_ms))
        Read_DTC(
            'Message content failure active, frame-loss DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      mcf_dtc, DTC_status['DTC_active_WLOFF'],
                      loss_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Wait(mcf_qualify_ms)
        Read_DTC(
            'Message content failure active, frame-loss DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      mcf_dtc, DTC_status['DTC_active_WLOFF'],
                      loss_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.RemovePeriodicFrame(mcf_bus, mcf_error_frame)
            CAN.PeriodicEnableFrame(mcf_bus, mcf_frame)
            CAN.ReloadDefaultPeriodicFrame(mcf_bus, mcf_frame)
            CAN.PeriodicEnableFrame(loss_bus, loss_frame)
            CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
