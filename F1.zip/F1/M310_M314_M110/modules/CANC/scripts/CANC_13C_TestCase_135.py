# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_135 (Codebeamer ID 36767369)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify IMU initialization and calibration behavior
# Automation : Semi-automatic (operator moves the ECU)
# Note       : The case expects '61 01 02 33'; the ISO 14229-1 positive response to 31 01 02 33
#              is 71 01 02 33, which the script expects.
# Note       : The stationary value is graded against CANC_IMU_STATIC_EXPECTED +/-
#              CANC_IMU_STATIC_TOLERANCE and the movement against CANC_IMU_MOTION_MIN_SWING; the
#              case gives no band, so these canc_config values are assumptions to confirm.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_IMU_CALIBRATION_ROUTINE_ID,
    CANC_IMU_MOTION_MIN_SWING,
    CANC_IMU_STATIC_EXPECTED,
    CANC_IMU_STATIC_TOLERANCE,
    CANC_MANUAL_ACTION_WINDOW_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.plantmode_config import (
    ROUTINE_CONTROL_POSITIVE_SID,
    ROUTINE_CONTROL_SID,
    START_ROUTINE_SUBFUNCTION,
    format_uds_bytes,
)


def run_test():
    tc_id = '36767369'
    tc_name = 'CANC_13C_TestCase_135'
    tc_desc = (
        'Verify IMU initialization and calibration behavior'
    )
    automation = 'Semi-automatic (operator moves the ECU)'

    imu_routine = format_uds_bytes((ROUTINE_CONTROL_SID, START_ROUTINE_SUBFUNCTION,
                                    CANC_IMU_CALIBRATION_ROUTINE_ID >> 8, CANC_IMU_CALIBRATION_ROUTINE_ID & 0xFF))
    imu_routine_response = format_uds_bytes((ROUTINE_CONTROL_POSITIVE_SID, START_ROUTINE_SUBFUNCTION,
                                             CANC_IMU_CALIBRATION_ROUTINE_ID >> 8, CANC_IMU_CALIBRATION_ROUTINE_ID & 0xFF))
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Cycle IGN and record the IMU values in the initialisation window')
        init1_ids = [fd_id]
        init1_file = os.path.splitext(log_path)[0] + '_imu_init_1.txt'
        init1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_init_1', filepath=init1_file,
            listOption=init1_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        CAN.StopLoggingToFile(init1_logger)
        init1_read = CAN.ReadFromCanLogFile(init1_file)
        init1_frames = [
            frame for frame in (init1_read[1] if init1_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in init1_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_rows = [(frame_data.timestamp / 1000,
                         round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key],
                                                                  imu_def['bit_length']),
                                               scaling=imu_def['Factor'], offset=imu_def['Offset'],
                                               bits=imu_def['bit_length'], signed=bool(imu_def.get('Signed'))), 4))
                        for frame_data in init1_frames if frame_data.id == fd_id]
            imu_restart = max([index for index in range(1, len(imu_rows))
                               if imu_rows[index][0] - imu_rows[index - 1][0] > 5 * fd_period_ms] or [0])
            RESULT.InterpretEqualResultRange(f"{imu_key} 0 or about 0 during the IMU initialisation",
                                             [value for _, value in imu_rows[imu_restart:imu_restart + CANC_FRAME_PRESENCE_CYCLES]] or [None],
                                             -CANC_IMU_STATIC_TOLERANCE[imu_key], CANC_IMU_STATIC_TOLERANCE[imu_key])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Move the ECU mildly on each axis before the calibration routine')
        motion_ids = [fd_id]
        motion_file = os.path.splitext(log_path)[0] + '_imu_motion.txt'
        motion_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_motion', filepath=motion_file,
            listOption=motion_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        RESULT.InsertComment(f'OPERATOR ACTION: Move the ECU mildly on each axis during the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        print(f'OPERATOR ACTION: Move the ECU mildly on each axis during the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        CAN.StopLoggingToFile(motion_logger)
        motion_read = CAN.ReadFromCanLogFile(motion_file)
        motion_frames = [
            frame for frame in (motion_read[1] if motion_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in motion_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_values = [raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key],
                                                             imu_def['bit_length']),
                                          scaling=imu_def['Factor'], offset=imu_def['Offset'],
                                          bits=imu_def['bit_length'], signed=bool(imu_def.get('Signed')))
                          for frame_data in motion_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResultRange(f"{imu_key} follows the movement (swing, physical)",
                                             round(max(imu_values) - min(imu_values), 4) if imu_values else None,
                                             CANC_IMU_MOTION_MIN_SWING[imu_key], float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Start the IMU calibration routine with security level 1')
        enter_ext_session()
        Internal_Security_Access(0x01)
        RESULT.InterpretEqualResult("IMU calibration routine response", str(CAN.SendDiagByValues(imu_routine)),
                                    imu_routine_response)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: IMU values offset-corrected on a stationary ECU')
        corrected_1_latteral_accel_ids = [fd_id]
        corrected_1_latteral_accel_file = os.path.splitext(log_path)[0] + '_corrected_1_latteral_accel.txt'
        corrected_1_latteral_accel_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_1_latteral_accel', filepath=corrected_1_latteral_accel_file,
            listOption=corrected_1_latteral_accel_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_1_latteral_accel_logger)
        corrected_1_latteral_accel_read = CAN.ReadFromCanLogFile(corrected_1_latteral_accel_file)
        corrected_1_latteral_accel_frames = [
            frame for frame in (corrected_1_latteral_accel_read[1] if corrected_1_latteral_accel_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_1_latteral_accel_ids]
        corrected_1_latteral_accel_def = MAH_CAN_SIGNAL_DEFS['LATTERAL_ACCEL']
        corrected_1_latteral_accel_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['LATTERAL_ACCEL'],
                                                                 corrected_1_latteral_accel_def['bit_length']),
                                              scaling=corrected_1_latteral_accel_def['Factor'], offset=corrected_1_latteral_accel_def['Offset'],
                                              bits=corrected_1_latteral_accel_def['bit_length'], signed=bool(corrected_1_latteral_accel_def.get('Signed'))), 4)
                        for frame_data in corrected_1_latteral_accel_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_1_latteral_accel_def['signal']} offset-corrected on a stationary ECU ({corrected_1_latteral_accel_def.get('UNIT') or 'physical'})",
                                         corrected_1_latteral_accel_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['LATTERAL_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['LATTERAL_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['LATTERAL_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['LATTERAL_ACCEL'])
        corrected_1_long_accel_ids = [fd_id]
        corrected_1_long_accel_file = os.path.splitext(log_path)[0] + '_corrected_1_long_accel.txt'
        corrected_1_long_accel_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_1_long_accel', filepath=corrected_1_long_accel_file,
            listOption=corrected_1_long_accel_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_1_long_accel_logger)
        corrected_1_long_accel_read = CAN.ReadFromCanLogFile(corrected_1_long_accel_file)
        corrected_1_long_accel_frames = [
            frame for frame in (corrected_1_long_accel_read[1] if corrected_1_long_accel_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_1_long_accel_ids]
        corrected_1_long_accel_def = MAH_CAN_SIGNAL_DEFS['LONG_ACCEL']
        corrected_1_long_accel_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['LONG_ACCEL'],
                                                                 corrected_1_long_accel_def['bit_length']),
                                              scaling=corrected_1_long_accel_def['Factor'], offset=corrected_1_long_accel_def['Offset'],
                                              bits=corrected_1_long_accel_def['bit_length'], signed=bool(corrected_1_long_accel_def.get('Signed'))), 4)
                        for frame_data in corrected_1_long_accel_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_1_long_accel_def['signal']} offset-corrected on a stationary ECU ({corrected_1_long_accel_def.get('UNIT') or 'physical'})",
                                         corrected_1_long_accel_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['LONG_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['LONG_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['LONG_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['LONG_ACCEL'])
        corrected_1_yaw_rate_ids = [fd_id]
        corrected_1_yaw_rate_file = os.path.splitext(log_path)[0] + '_corrected_1_yaw_rate.txt'
        corrected_1_yaw_rate_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_1_yaw_rate', filepath=corrected_1_yaw_rate_file,
            listOption=corrected_1_yaw_rate_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_1_yaw_rate_logger)
        corrected_1_yaw_rate_read = CAN.ReadFromCanLogFile(corrected_1_yaw_rate_file)
        corrected_1_yaw_rate_frames = [
            frame for frame in (corrected_1_yaw_rate_read[1] if corrected_1_yaw_rate_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_1_yaw_rate_ids]
        corrected_1_yaw_rate_def = MAH_CAN_SIGNAL_DEFS['YAW_RATE']
        corrected_1_yaw_rate_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['YAW_RATE'],
                                                                 corrected_1_yaw_rate_def['bit_length']),
                                              scaling=corrected_1_yaw_rate_def['Factor'], offset=corrected_1_yaw_rate_def['Offset'],
                                              bits=corrected_1_yaw_rate_def['bit_length'], signed=bool(corrected_1_yaw_rate_def.get('Signed'))), 4)
                        for frame_data in corrected_1_yaw_rate_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_1_yaw_rate_def['signal']} offset-corrected on a stationary ECU ({corrected_1_yaw_rate_def.get('UNIT') or 'physical'})",
                                         corrected_1_yaw_rate_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['YAW_RATE'] - CANC_IMU_STATIC_TOLERANCE['YAW_RATE'],
                                         CANC_IMU_STATIC_EXPECTED['YAW_RATE'] + CANC_IMU_STATIC_TOLERANCE['YAW_RATE'])
        corrected_1_x_axis_angular_ids = [fd_id]
        corrected_1_x_axis_angular_file = os.path.splitext(log_path)[0] + '_corrected_1_x_axis_angular.txt'
        corrected_1_x_axis_angular_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_1_x_axis_angular', filepath=corrected_1_x_axis_angular_file,
            listOption=corrected_1_x_axis_angular_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_1_x_axis_angular_logger)
        corrected_1_x_axis_angular_read = CAN.ReadFromCanLogFile(corrected_1_x_axis_angular_file)
        corrected_1_x_axis_angular_frames = [
            frame for frame in (corrected_1_x_axis_angular_read[1] if corrected_1_x_axis_angular_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_1_x_axis_angular_ids]
        corrected_1_x_axis_angular_def = MAH_CAN_SIGNAL_DEFS['X_AXIS_ANGULAR']
        corrected_1_x_axis_angular_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['X_AXIS_ANGULAR'],
                                                                 corrected_1_x_axis_angular_def['bit_length']),
                                              scaling=corrected_1_x_axis_angular_def['Factor'], offset=corrected_1_x_axis_angular_def['Offset'],
                                              bits=corrected_1_x_axis_angular_def['bit_length'], signed=bool(corrected_1_x_axis_angular_def.get('Signed'))), 4)
                        for frame_data in corrected_1_x_axis_angular_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_1_x_axis_angular_def['signal']} offset-corrected on a stationary ECU ({corrected_1_x_axis_angular_def.get('UNIT') or 'physical'})",
                                         corrected_1_x_axis_angular_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['X_AXIS_ANGULAR'] - CANC_IMU_STATIC_TOLERANCE['X_AXIS_ANGULAR'],
                                         CANC_IMU_STATIC_EXPECTED['X_AXIS_ANGULAR'] + CANC_IMU_STATIC_TOLERANCE['X_AXIS_ANGULAR'])
        corrected_1_y_axis_angular_ids = [fd_id]
        corrected_1_y_axis_angular_file = os.path.splitext(log_path)[0] + '_corrected_1_y_axis_angular.txt'
        corrected_1_y_axis_angular_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_1_y_axis_angular', filepath=corrected_1_y_axis_angular_file,
            listOption=corrected_1_y_axis_angular_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_1_y_axis_angular_logger)
        corrected_1_y_axis_angular_read = CAN.ReadFromCanLogFile(corrected_1_y_axis_angular_file)
        corrected_1_y_axis_angular_frames = [
            frame for frame in (corrected_1_y_axis_angular_read[1] if corrected_1_y_axis_angular_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_1_y_axis_angular_ids]
        corrected_1_y_axis_angular_def = MAH_CAN_SIGNAL_DEFS['Y_AXIS_ANGULAR']
        corrected_1_y_axis_angular_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['Y_AXIS_ANGULAR'],
                                                                 corrected_1_y_axis_angular_def['bit_length']),
                                              scaling=corrected_1_y_axis_angular_def['Factor'], offset=corrected_1_y_axis_angular_def['Offset'],
                                              bits=corrected_1_y_axis_angular_def['bit_length'], signed=bool(corrected_1_y_axis_angular_def.get('Signed'))), 4)
                        for frame_data in corrected_1_y_axis_angular_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_1_y_axis_angular_def['signal']} offset-corrected on a stationary ECU ({corrected_1_y_axis_angular_def.get('UNIT') or 'physical'})",
                                         corrected_1_y_axis_angular_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['Y_AXIS_ANGULAR'] - CANC_IMU_STATIC_TOLERANCE['Y_AXIS_ANGULAR'],
                                         CANC_IMU_STATIC_EXPECTED['Y_AXIS_ANGULAR'] + CANC_IMU_STATIC_TOLERANCE['Y_AXIS_ANGULAR'])
        corrected_1_z_axis_accel_ids = [fd_id]
        corrected_1_z_axis_accel_file = os.path.splitext(log_path)[0] + '_corrected_1_z_axis_accel.txt'
        corrected_1_z_axis_accel_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_1_z_axis_accel', filepath=corrected_1_z_axis_accel_file,
            listOption=corrected_1_z_axis_accel_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_1_z_axis_accel_logger)
        corrected_1_z_axis_accel_read = CAN.ReadFromCanLogFile(corrected_1_z_axis_accel_file)
        corrected_1_z_axis_accel_frames = [
            frame for frame in (corrected_1_z_axis_accel_read[1] if corrected_1_z_axis_accel_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_1_z_axis_accel_ids]
        corrected_1_z_axis_accel_def = MAH_CAN_SIGNAL_DEFS['Z_AXIS_ACCEL']
        corrected_1_z_axis_accel_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['Z_AXIS_ACCEL'],
                                                                 corrected_1_z_axis_accel_def['bit_length']),
                                              scaling=corrected_1_z_axis_accel_def['Factor'], offset=corrected_1_z_axis_accel_def['Offset'],
                                              bits=corrected_1_z_axis_accel_def['bit_length'], signed=bool(corrected_1_z_axis_accel_def.get('Signed'))), 4)
                        for frame_data in corrected_1_z_axis_accel_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_1_z_axis_accel_def['signal']} offset-corrected on a stationary ECU ({corrected_1_z_axis_accel_def.get('UNIT') or 'physical'})",
                                         corrected_1_z_axis_accel_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['Z_AXIS_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['Z_AXIS_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['Z_AXIS_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['Z_AXIS_ACCEL'])
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Cycle IGN and record the IMU values in the initialisation window again')
        init2_ids = [fd_id]
        init2_file = os.path.splitext(log_path)[0] + '_imu_init_2.txt'
        init2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_init_2', filepath=init2_file,
            listOption=init2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        CAN.StopLoggingToFile(init2_logger)
        init2_read = CAN.ReadFromCanLogFile(init2_file)
        init2_frames = [
            frame for frame in (init2_read[1] if init2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in init2_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_rows = [(frame_data.timestamp / 1000,
                         round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key],
                                                                  imu_def['bit_length']),
                                               scaling=imu_def['Factor'], offset=imu_def['Offset'],
                                               bits=imu_def['bit_length'], signed=bool(imu_def.get('Signed'))), 4))
                        for frame_data in init2_frames if frame_data.id == fd_id]
            imu_restart = max([index for index in range(1, len(imu_rows))
                               if imu_rows[index][0] - imu_rows[index - 1][0] > 5 * fd_period_ms] or [0])
            RESULT.InterpretEqualResultRange(f"{imu_key} 0 or about 0 during the IMU initialisation",
                                             [value for _, value in imu_rows[imu_restart:imu_restart + CANC_FRAME_PRESENCE_CYCLES]] or [None],
                                             -CANC_IMU_STATIC_TOLERANCE[imu_key], CANC_IMU_STATIC_TOLERANCE[imu_key])
        aria_reports.close_group()
        aria_reports.add_group('Step 8: IMU values offset-corrected on a stationary ECU after the IGN cycle')
        corrected_2_latteral_accel_ids = [fd_id]
        corrected_2_latteral_accel_file = os.path.splitext(log_path)[0] + '_corrected_2_latteral_accel.txt'
        corrected_2_latteral_accel_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_2_latteral_accel', filepath=corrected_2_latteral_accel_file,
            listOption=corrected_2_latteral_accel_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_2_latteral_accel_logger)
        corrected_2_latteral_accel_read = CAN.ReadFromCanLogFile(corrected_2_latteral_accel_file)
        corrected_2_latteral_accel_frames = [
            frame for frame in (corrected_2_latteral_accel_read[1] if corrected_2_latteral_accel_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_2_latteral_accel_ids]
        corrected_2_latteral_accel_def = MAH_CAN_SIGNAL_DEFS['LATTERAL_ACCEL']
        corrected_2_latteral_accel_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['LATTERAL_ACCEL'],
                                                                 corrected_2_latteral_accel_def['bit_length']),
                                              scaling=corrected_2_latteral_accel_def['Factor'], offset=corrected_2_latteral_accel_def['Offset'],
                                              bits=corrected_2_latteral_accel_def['bit_length'], signed=bool(corrected_2_latteral_accel_def.get('Signed'))), 4)
                        for frame_data in corrected_2_latteral_accel_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_2_latteral_accel_def['signal']} offset-corrected on a stationary ECU ({corrected_2_latteral_accel_def.get('UNIT') or 'physical'})",
                                         corrected_2_latteral_accel_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['LATTERAL_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['LATTERAL_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['LATTERAL_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['LATTERAL_ACCEL'])
        corrected_2_long_accel_ids = [fd_id]
        corrected_2_long_accel_file = os.path.splitext(log_path)[0] + '_corrected_2_long_accel.txt'
        corrected_2_long_accel_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_2_long_accel', filepath=corrected_2_long_accel_file,
            listOption=corrected_2_long_accel_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_2_long_accel_logger)
        corrected_2_long_accel_read = CAN.ReadFromCanLogFile(corrected_2_long_accel_file)
        corrected_2_long_accel_frames = [
            frame for frame in (corrected_2_long_accel_read[1] if corrected_2_long_accel_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_2_long_accel_ids]
        corrected_2_long_accel_def = MAH_CAN_SIGNAL_DEFS['LONG_ACCEL']
        corrected_2_long_accel_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['LONG_ACCEL'],
                                                                 corrected_2_long_accel_def['bit_length']),
                                              scaling=corrected_2_long_accel_def['Factor'], offset=corrected_2_long_accel_def['Offset'],
                                              bits=corrected_2_long_accel_def['bit_length'], signed=bool(corrected_2_long_accel_def.get('Signed'))), 4)
                        for frame_data in corrected_2_long_accel_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_2_long_accel_def['signal']} offset-corrected on a stationary ECU ({corrected_2_long_accel_def.get('UNIT') or 'physical'})",
                                         corrected_2_long_accel_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['LONG_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['LONG_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['LONG_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['LONG_ACCEL'])
        corrected_2_yaw_rate_ids = [fd_id]
        corrected_2_yaw_rate_file = os.path.splitext(log_path)[0] + '_corrected_2_yaw_rate.txt'
        corrected_2_yaw_rate_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_2_yaw_rate', filepath=corrected_2_yaw_rate_file,
            listOption=corrected_2_yaw_rate_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_2_yaw_rate_logger)
        corrected_2_yaw_rate_read = CAN.ReadFromCanLogFile(corrected_2_yaw_rate_file)
        corrected_2_yaw_rate_frames = [
            frame for frame in (corrected_2_yaw_rate_read[1] if corrected_2_yaw_rate_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_2_yaw_rate_ids]
        corrected_2_yaw_rate_def = MAH_CAN_SIGNAL_DEFS['YAW_RATE']
        corrected_2_yaw_rate_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['YAW_RATE'],
                                                                 corrected_2_yaw_rate_def['bit_length']),
                                              scaling=corrected_2_yaw_rate_def['Factor'], offset=corrected_2_yaw_rate_def['Offset'],
                                              bits=corrected_2_yaw_rate_def['bit_length'], signed=bool(corrected_2_yaw_rate_def.get('Signed'))), 4)
                        for frame_data in corrected_2_yaw_rate_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_2_yaw_rate_def['signal']} offset-corrected on a stationary ECU ({corrected_2_yaw_rate_def.get('UNIT') or 'physical'})",
                                         corrected_2_yaw_rate_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['YAW_RATE'] - CANC_IMU_STATIC_TOLERANCE['YAW_RATE'],
                                         CANC_IMU_STATIC_EXPECTED['YAW_RATE'] + CANC_IMU_STATIC_TOLERANCE['YAW_RATE'])
        corrected_2_x_axis_angular_ids = [fd_id]
        corrected_2_x_axis_angular_file = os.path.splitext(log_path)[0] + '_corrected_2_x_axis_angular.txt'
        corrected_2_x_axis_angular_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_2_x_axis_angular', filepath=corrected_2_x_axis_angular_file,
            listOption=corrected_2_x_axis_angular_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_2_x_axis_angular_logger)
        corrected_2_x_axis_angular_read = CAN.ReadFromCanLogFile(corrected_2_x_axis_angular_file)
        corrected_2_x_axis_angular_frames = [
            frame for frame in (corrected_2_x_axis_angular_read[1] if corrected_2_x_axis_angular_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_2_x_axis_angular_ids]
        corrected_2_x_axis_angular_def = MAH_CAN_SIGNAL_DEFS['X_AXIS_ANGULAR']
        corrected_2_x_axis_angular_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['X_AXIS_ANGULAR'],
                                                                 corrected_2_x_axis_angular_def['bit_length']),
                                              scaling=corrected_2_x_axis_angular_def['Factor'], offset=corrected_2_x_axis_angular_def['Offset'],
                                              bits=corrected_2_x_axis_angular_def['bit_length'], signed=bool(corrected_2_x_axis_angular_def.get('Signed'))), 4)
                        for frame_data in corrected_2_x_axis_angular_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_2_x_axis_angular_def['signal']} offset-corrected on a stationary ECU ({corrected_2_x_axis_angular_def.get('UNIT') or 'physical'})",
                                         corrected_2_x_axis_angular_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['X_AXIS_ANGULAR'] - CANC_IMU_STATIC_TOLERANCE['X_AXIS_ANGULAR'],
                                         CANC_IMU_STATIC_EXPECTED['X_AXIS_ANGULAR'] + CANC_IMU_STATIC_TOLERANCE['X_AXIS_ANGULAR'])
        corrected_2_y_axis_angular_ids = [fd_id]
        corrected_2_y_axis_angular_file = os.path.splitext(log_path)[0] + '_corrected_2_y_axis_angular.txt'
        corrected_2_y_axis_angular_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_2_y_axis_angular', filepath=corrected_2_y_axis_angular_file,
            listOption=corrected_2_y_axis_angular_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_2_y_axis_angular_logger)
        corrected_2_y_axis_angular_read = CAN.ReadFromCanLogFile(corrected_2_y_axis_angular_file)
        corrected_2_y_axis_angular_frames = [
            frame for frame in (corrected_2_y_axis_angular_read[1] if corrected_2_y_axis_angular_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_2_y_axis_angular_ids]
        corrected_2_y_axis_angular_def = MAH_CAN_SIGNAL_DEFS['Y_AXIS_ANGULAR']
        corrected_2_y_axis_angular_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['Y_AXIS_ANGULAR'],
                                                                 corrected_2_y_axis_angular_def['bit_length']),
                                              scaling=corrected_2_y_axis_angular_def['Factor'], offset=corrected_2_y_axis_angular_def['Offset'],
                                              bits=corrected_2_y_axis_angular_def['bit_length'], signed=bool(corrected_2_y_axis_angular_def.get('Signed'))), 4)
                        for frame_data in corrected_2_y_axis_angular_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_2_y_axis_angular_def['signal']} offset-corrected on a stationary ECU ({corrected_2_y_axis_angular_def.get('UNIT') or 'physical'})",
                                         corrected_2_y_axis_angular_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['Y_AXIS_ANGULAR'] - CANC_IMU_STATIC_TOLERANCE['Y_AXIS_ANGULAR'],
                                         CANC_IMU_STATIC_EXPECTED['Y_AXIS_ANGULAR'] + CANC_IMU_STATIC_TOLERANCE['Y_AXIS_ANGULAR'])
        corrected_2_z_axis_accel_ids = [fd_id]
        corrected_2_z_axis_accel_file = os.path.splitext(log_path)[0] + '_corrected_2_z_axis_accel.txt'
        corrected_2_z_axis_accel_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_corrected_2_z_axis_accel', filepath=corrected_2_z_axis_accel_file,
            listOption=corrected_2_z_axis_accel_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(corrected_2_z_axis_accel_logger)
        corrected_2_z_axis_accel_read = CAN.ReadFromCanLogFile(corrected_2_z_axis_accel_file)
        corrected_2_z_axis_accel_frames = [
            frame for frame in (corrected_2_z_axis_accel_read[1] if corrected_2_z_axis_accel_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in corrected_2_z_axis_accel_ids]
        corrected_2_z_axis_accel_def = MAH_CAN_SIGNAL_DEFS['Z_AXIS_ACCEL']
        corrected_2_z_axis_accel_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['Z_AXIS_ACCEL'],
                                                                 corrected_2_z_axis_accel_def['bit_length']),
                                              scaling=corrected_2_z_axis_accel_def['Factor'], offset=corrected_2_z_axis_accel_def['Offset'],
                                              bits=corrected_2_z_axis_accel_def['bit_length'], signed=bool(corrected_2_z_axis_accel_def.get('Signed'))), 4)
                        for frame_data in corrected_2_z_axis_accel_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{corrected_2_z_axis_accel_def['signal']} offset-corrected on a stationary ECU ({corrected_2_z_axis_accel_def.get('UNIT') or 'physical'})",
                                         corrected_2_z_axis_accel_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['Z_AXIS_ACCEL'] - CANC_IMU_STATIC_TOLERANCE['Z_AXIS_ACCEL'],
                                         CANC_IMU_STATIC_EXPECTED['Z_AXIS_ACCEL'] + CANC_IMU_STATIC_TOLERANCE['Z_AXIS_ACCEL'])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
