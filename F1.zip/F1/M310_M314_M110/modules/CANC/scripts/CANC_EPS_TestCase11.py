# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_EPS_TestCase11 (Codebeamer ID 35654988)
# Workbook   : EPS_Node_TestCases.xlsx
# Objective  : Verify voltage suppression behavior for Message Content Failure (DLC) in
#              EPS1_FD_10 under high voltage condition.
# Automation : Automatic
# Note       : A wrong DLC is produced by stopping the frame and sending a copy on the same
#              identifier with the payload length CAN_DLC_ERROR_PAYLOAD_LENGTH gives (no shared-
#              library call changes the DLC of a simulated frame); confirm on the bench that the
#              copy goes out on the identifier.
# Note       : The case gives the battery-voltage DTC status 0x08 for active, healed and
#              historic; the customer DTC list (warning lamp 1) and the FR_ZONE / VCU cases give
#              0x8B / 0x0A / 0x08. The script reads the statuses from
#              CANC_VOLTAGE_DTC_STATUS_KEYS in canc_config.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_OVERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_DEMATURE_MS,
    CANC_VOLTAGE_DTC_MATURE_MS,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS,
    get_frame_message_content_failure_dtc,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35654988'
    tc_name = 'CANC_EPS_TestCase11'
    tc_desc = (
        'Verify voltage suppression behavior for Message Content Failure (DLC) in EPS1_FD_10 '
        'under high voltage condition.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fault_frame = 'EPS1_FD_10'
    fault_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame)
    fault_bus = fault_def['bus']
    fault_dtc = get_frame_message_content_failure_dtc(fault_frame)[0]
    if fault_dtc is None:
        fault_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(fault_frame)
    fault_error_frame = fault_frame + '_DLC_ERROR'
    fault_error_payload = [0] * CAN_DLC_ERROR_PAYLOAD_LENGTH[fault_def['dlc']]
    fault_qualify_ms = int(qualification_ms('message_content', fault_def['periodicity']) * margin)
    fault_recover_ms = int(recovery_ms('message_content', fault_def['periodicity']) * margin)
    voltage_level = CANC_OVERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Over_Voltage
    voltage_restart_ms = NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS
    voltage_mature_ms = int(CANC_VOLTAGE_DTC_MATURE_MS * margin)
    voltage_demature_ms = int(CANC_VOLTAGE_DTC_DEMATURE_MS * margin) + voltage_restart_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([fault_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure (DLC) DTC of {fault_frame}', fault_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create over-voltage condition')
        PS.SetVoltage(voltage_level)
        Wait(voltage_mature_ms)
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create CAN fault while the abnormal voltage is present - inject incorrect DLC on EPS1_FD_10')
        CAN.PeriodicDisableFrame(fault_bus, fault_frame)
        CAN.SetPeriodicFrame(fault_bus, fault_error_frame, fault_def['frame_ID'], fault_def['periodicity'],
                             fault_error_payload, fault_def['is_fd'])
        Wait(fault_qualify_ms)
        Read_DTC(
            'CAN DTC remains suppressed while the abnormal voltage is present',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage while maintaining the CAN fault')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        Wait(voltage_demature_ms + fault_qualify_ms)
        Read_DTC(
            'Voltage DTC healed, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Wait(fault_qualify_ms)
        Read_DTC(
            'Voltage DTC historic, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Remove CAN fault - restore correct DLC on EPS1_FD_10')
        CAN.RemovePeriodicFrame(fault_bus, fault_error_frame)
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        Wait(fault_recover_ms)
        Read_DTC(
            'CAN DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Read_DTC(
            'CAN DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.RemovePeriodicFrame(fault_bus, fault_error_frame)
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
            CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
