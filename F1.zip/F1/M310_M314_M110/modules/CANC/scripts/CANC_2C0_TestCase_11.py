# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_2C0_TestCase_11 (Codebeamer ID 35736858)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signals
#              shall transmit the data for the newly detected crash event in the next available
#              SRS1_20 message.
# Automation : Automatic once the multi-event crash curves are delivered (blocked until then)

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_LOCATION_STATE,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736858'
    tc_name = 'CANC_2C0_TestCase_11'
    tc_desc = (
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signals shall '
        'transmit the data for the newly detected crash event in the next available SRS1_20 '
        'message.'
    )
    automation = 'Automatic once the multi-event crash curves are delivered (blocked until then)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    crash1_curve_key = CANC_CRASH_CURVE_KEY['front_left_right_rear']
    crash1_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash1_curve_key) or {}
    crash1_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash1_curve_set.get('RSU', {}).values())
    crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
    crash_clear = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['No Request / Default']
    location_none = MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values']['No Crash/Default']
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash1_curve_key}', crash1_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Crashes within 800 ms: front left right rear')
        load_crash_curves(crash1_curve_key, project=PROJECT_NAME)
        seq1_ids = [fd_id, hs_id]
        seq1_file = os.path.splitext(log_path)[0] + '_seq1.txt'
        seq1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq1', filepath=seq1_file,
            listOption=seq1_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(16 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq1_logger)
        seq1_read = CAN.ReadFromCanLogFile(seq1_file)
        seq1_frames = [
            frame for frame in (seq1_read[1] if seq1_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in seq1_ids]
        seq1_hs_keys = {'sts': 'SRS1_20_STS_CRASH', 'loc': 'SRS1_20_CRASH_LOCATION', 'door': 'DOOR_UNLOCK', 'mode': 'SRS1_20_SRS_OPERATION_MODE', 'scm': 'SRS1_20_SCM_CNT'}
        seq1_hs = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq1_hs_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq1_frames if frame_data.id == hs_id]
        seq1_hs_locations = [row['loc'] for row in seq1_hs if row['sts'] == crash_set]
        seq1_hs_sequence = [value for position, value in enumerate(seq1_hs_locations)
                           if position == 0 or value != seq1_hs_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{hs_frame} CRASH_LOCATION sequence", seq1_hs_sequence, [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['front']], MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['left']], MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['right']], MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rear']]])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
