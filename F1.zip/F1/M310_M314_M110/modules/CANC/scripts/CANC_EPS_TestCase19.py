# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_EPS_TestCase19 (Codebeamer ID 35654995)
# Workbook   : EPS_Node_TestCases.xlsx
# Objective  : Verify voltage suppression behavior for Signal Content Failure
#              (STEERING_ABSOLUTE_ANGLE) in EPS1_FD_10 under low voltage condition.
# Automation : Automatic
# Note       : The case gives the battery-voltage DTC status 0x08 for active, healed and
#              historic; the customer DTC list (warning lamp 1) and the FR_ZONE / VCU cases give
#              0x8B / 0x0A / 0x08. The script reads the statuses from
#              CANC_VOLTAGE_DTC_STATUS_KEYS in canc_config.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_UNDERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_DEMATURE_MS,
    CANC_VOLTAGE_DTC_MATURE_MS,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_TX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35654995'
    tc_name = 'CANC_EPS_TestCase19'
    tc_desc = (
        'Verify voltage suppression behavior for Signal Content Failure '
        '(STEERING_ABSOLUTE_ANGLE) in EPS1_FD_10 under low voltage condition.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fault_key = 'STEERING_ABSOLUTE_ANGLE'
    fault_def = MAH_CAN_SIGNAL_DEFS[fault_key]
    fault_frame = fault_def['frame']
    fault_bus = fault_def['bus']
    fault_dtc = CAN_TX_MESSAGE_CONFIG[fault_frame]['signal_content_failure_dtcs'].get(fault_def['signal'])
    fault_invalid = fault_def.get('Invalid_Value')
    fault_recovery = fault_def.get('SCF_Recovery_Value')
    if fault_recovery is None:
        fault_recovery = fault_def.get('Default_Value')
    fault_qualify_ms = int(qualification_ms('signal_content', fault_def['periodicity']) * margin)
    fault_recover_ms = int(recovery_ms('signal_content', fault_def['periodicity']) * margin)
    voltage_level = CANC_UNDERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Under_Voltage
    voltage_restart_ms = NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS
    voltage_mature_ms = int(CANC_VOLTAGE_DTC_MATURE_MS * margin)
    voltage_demature_ms = int(CANC_VOLTAGE_DTC_DEMATURE_MS * margin) + voltage_restart_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([fault_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'signal content failure DTC of {fault_key}', fault_dtc),
            (f'invalid value of {fault_key}', fault_invalid),
            (f'recovery value of {fault_key}', fault_recovery),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create under-voltage condition')
        PS.SetVoltage(voltage_level)
        Wait(voltage_mature_ms)
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create CAN fault while the abnormal voltage is present - inject invalid value 32767 for STEERING_ABSOLUTE_ANGLE')
        CAN.ChangeSignalValue(fault_bus, fault_frame, fault_def['signal'], str(fault_invalid))
        Wait(fault_qualify_ms)
        Read_DTC(
            'CAN DTC remains suppressed while the abnormal voltage is present',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage while maintaining the CAN fault')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        Wait(voltage_demature_ms + fault_qualify_ms)
        Read_DTC(
            'Voltage DTC healed, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Wait(fault_qualify_ms)
        Read_DTC(
            'Voltage DTC historic, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Remove CAN fault - restore valid value for STEERING_ABSOLUTE_ANGLE')
        CAN.ChangeSignalValue(fault_bus, fault_frame, fault_def['signal'], str(fault_recovery))
        Wait(fault_recover_ms)
        Read_DTC(
            'CAN DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Read_DTC(
            'CAN DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.ChangeSignalValue(fault_bus, fault_frame, fault_def['signal'], str(fault_recovery))
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
