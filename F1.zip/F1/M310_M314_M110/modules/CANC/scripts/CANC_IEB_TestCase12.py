# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_IEB_TestCase12 (Codebeamer ID 35654961)
# Workbook   : IEB_Node_TestCases.xlsx
# Objective  : Verify integrity field behavior for the signal in this message (field update
#              pattern and transport integrity behavior).
# Automation : Automatic
# Note       : Besides the representative values the case lists, the script checks that a CRC
#              held at values that do not match the frame content qualifies the message content
#              failure DTC, and that it heals once the computed CRC is restored.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    get_message_content_failure_dtcs,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35654961'
    tc_name = 'CANC_IEB_TestCase12'
    tc_desc = (
        'Verify integrity field behavior for the signal in this message (field update pattern '
        'and transport integrity behavior).'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    crc_key = 'IEB1_CRC'
    crc_def = MAH_CAN_SIGNAL_DEFS[crc_key]
    frame = crc_def['frame']
    bus = crc_def['bus']
    period_ms = crc_def['periodicity']
    crc_values = list(crc_def.get('TestCase_values') or [])
    mcf_dtc = get_message_content_failure_dtcs(frame).get(crc_key)
    mcf_qualify_ms = int(qualification_ms('message_content', period_ms) * margin)
    mcf_recover_ms = int(recovery_ms('message_content', period_ms) * margin)
    dwell_ms = max(3 * period_ms, mcf_qualify_ms // max(len(crc_values), 1))
    monitor_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * period_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([crc_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure DTC of {crc_key}', mcf_dtc),
            (f'representative values of {crc_key}', crc_values or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor IEB1_CRC while the bench computes it')
        crc_ids = [crc_def['frame_ID']]
        crc_file = os.path.splitext(log_path)[0] + '_crc_monitor.txt'
        crc_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_crc_monitor', filepath=crc_file,
            listOption=crc_ids, channel_names=[bus])
        Wait(monitor_window_ms)
        CAN.StopLoggingToFile(crc_logger)
        crc_read = CAN.ReadFromCanLogFile(crc_file)
        crc_frames = [
            frame for frame in (crc_read[1] if crc_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in crc_ids]
        crc_seen = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[crc_key], crc_def['bit_length'])
                    for frame_data in crc_frames]
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(crc_seen), CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResult(f"{crc_def['signal']} follows the changing frame content",
                                    len(set(crc_seen)) > 1, True)
        Read_DTC('No DTC while the CRC is valid', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Transmit representative raw values for IEB1_CRC')
        CAN.DynamicDisableSignal(bus, frame, crc_def['signal'])
        for value in crc_values:
            CAN.ChangeSignalValue(bus, frame, crc_def['signal'], str(value))
            Wait(dwell_ms)
            read_back = str(CAN.GetSignalFromFrame(bus, frame, crc_def['signal'])).strip()
            try:
                read_back = str(int(read_back, 16) if read_back.lower().startswith("0x") else int(float(read_back)))
            except ValueError:
                pass
            RESULT.InterpretEqualResult(f"{frame} carries {crc_def['signal']} = {value} (physical {value * crc_def['Factor'] + crc_def['Offset']})",
                                        read_back, str(value))
        Read_DTC(
            'A CRC that does not match the frame content is reported',
            " ".join([Read_DTC_Resp_CANC,
                      mcf_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the computed IEB1_CRC')
        CAN.DynamicEnableSignal(bus, frame, crc_def['signal'])
        Wait(mcf_recover_ms)
        Read_DTC(
            'Message content failure healed',
            " ".join([Read_DTC_Resp_CANC,
                      mcf_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.DynamicEnableSignal(bus, frame, crc_def['signal'])
            CAN.ReloadDefaultPeriodicFrame(bus, frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
