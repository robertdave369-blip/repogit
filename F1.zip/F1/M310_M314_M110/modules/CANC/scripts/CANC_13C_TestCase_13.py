# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_13 (Codebeamer ID 35739857)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify Passenger seat belt status
# Automation : Automatic
# Note       : A faulty belt is load CANC_DCS_FAULT_LOAD with Leakage VBAT Bus High (bench
#              note); the cross-connect puts both belt channels on that load without the leakage
#              (assumed wiring).

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_BELT_CHANNEL,
    CANC_DCS_FAULT_LOAD,
    CANC_DCS_STATE_SETTLE_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_SEAT_BELT_INIT_WINDOW_MS,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    DCS_fault_time,
    SLSNumber,
)


def run_test():
    tc_id = '35739857'
    tc_name = 'CANC_13C_TestCase_13'
    tc_desc = (
        'Verify Passenger seat belt status'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    dcs_fault_ms = int(DCS_fault_time['Qualification'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
    dcs_heal_ms = int(DCS_fault_time['Dequalification'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    dcs_cc_ms = int(DCS_fault_time['Qualification_CC'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
    dcs_cc_heal_ms = int(DCS_fault_time['Dequalification_CC'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    belt_key = 'STS_SEAT_BLT_PSGR'
    belt_states = MAH_CAN_SIGNAL_DEFS[belt_key]['State_Values']
    belt_unbuckled = next(value for label, value in belt_states.items() if label.startswith('Not Buckled'))
    belt_buckled = belt_states['Buckled']
    belt_faulty = belt_states['Buckle Faulty']
    belt_reserved = belt_states['Reserved']
    belt_channel = SLSNumber[CANC_BELT_CHANNEL[belt_key]]
    partner_channel = SLSNumber[CANC_BELT_CHANNEL['STS_SEAT_BLT_DRV']]

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Set the belt to unbuckled')
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
        for check_key, check_expected in [(belt_key, belt_unbuckled)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Set the belt to buckled')
        SET_DCS_LOADS(DCS_Fault_Description['buckle'], belt_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
        for check_key, check_expected in [(belt_key, belt_buckled)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Set the belt to faulty (short to battery)')
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, belt_channel)
        PS.SetLeakageVBATBusHigh()
        Wait(dcs_fault_ms)
        for check_key, check_expected in [(belt_key, belt_faulty)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        PS.ClearLeakageVBATBusHigh()
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        Wait(dcs_heal_ms)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Set the belt to faulty (cross-connected with STS_SEAT_BLT_DRV)')
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, belt_channel)
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, partner_channel)
        Wait(dcs_cc_ms)
        for check_key, check_expected in [(belt_key, belt_faulty)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], partner_channel)
        Wait(dcs_cc_heal_ms)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Cycle IGN and observe the belt status in the first frames')
        init_ids = [fd_id]
        init_file = os.path.splitext(log_path)[0] + '_belt_init.txt'
        init_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_belt_init', filepath=init_file,
            listOption=init_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS + CANC_SEAT_BELT_INIT_WINDOW_MS)
        CAN.StopLoggingToFile(init_logger)
        init_read = CAN.ReadFromCanLogFile(init_file)
        init_frames = [
            frame for frame in (init_read[1] if init_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in init_ids]
        belt_init_rows = [(frame_data.timestamp / 1000,
                       extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[belt_key], MAH_CAN_SIGNAL_DEFS[belt_key]['bit_length']))
                      for frame_data in init_frames if frame_data.id == fd_id]
        belt_init_restart = max([index for index in range(1, len(belt_init_rows))
                             if belt_init_rows[index][0] - belt_init_rows[index - 1][0] > 5 * fd_period_ms] or [0])
        belt_init_rows = belt_init_rows[belt_init_restart:]
        belt_init_reserved = [t for t, value in belt_init_rows if value == belt_reserved]
        RESULT.InterpretEqualResult(f"{belt_key} reads Reserved when transmission starts",
                                    belt_init_rows[0][1] if belt_init_rows else None, belt_reserved)
        RESULT.InterpretEqualResultRange(f"{belt_key} Reserved after IGN ON for (ms)",
                                         round(belt_init_reserved[-1] - belt_init_rows[0][0], 1) + fd_period_ms if belt_init_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResult(f"{belt_key} then takes the actual value",
                                    belt_init_rows[-1][1] if belt_init_rows else None, belt_unbuckled)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.ClearLeakageVBATBusHigh()
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], partner_channel)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
