# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_FR_ZONE_TestCase_46 (Codebeamer ID 35660023)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that FR_ZONE3_100 message-timeout fault remains active when Over-Voltage
#              is induced, and voltage DTC behavior follows expected active/healed transitions.
# Automation : Automatic
# Note       : The case expects a message-timeout fault on FR_ZONE3_100, but canc_config
#              (KEY_TX_FRAMES, from the customer DTC list) treats FR_ZONE3_100 as the key frame
#              of its node, so stopping it reports the node-absent DTC 0xD1 0x04 0x00. The
#              script expects what canc_config gives.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_OVERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_DEMATURE_MS,
    CANC_VOLTAGE_DTC_MATURE_MS,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS,
    is_key_message,
    qualification_ms,
    recovery_ms,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35660023'
    tc_name = 'CANC_FR_ZONE_TestCase_46'
    tc_desc = (
        'Verify that FR_ZONE3_100 message-timeout fault remains active when Over-Voltage is '
        'induced, and voltage DTC behavior follows expected active/healed transitions.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    loss_frame = 'FR_ZONE3_100'
    loss_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == loss_frame)
    loss_bus = loss_def['bus']
    loss_mode = 'node_absent' if is_key_message(loss_frame) else 'message_timeout'
    loss_dtc = resolve_dtc_for_event('frame_disabled', loss_frame)
    loss_qualify_ms = int(qualification_ms(loss_mode, loss_def['periodicity']) * margin)
    loss_recover_ms = int(recovery_ms(loss_mode, loss_def['periodicity']) * margin)
    voltage_level = CANC_OVERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Over_Voltage
    voltage_restart_ms = NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS
    voltage_mature_ms = int(CANC_VOLTAGE_DTC_MATURE_MS * margin)
    voltage_demature_ms = int(CANC_VOLTAGE_DTC_DEMATURE_MS * margin) + voltage_restart_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([loss_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'frame-loss DTC of {loss_frame}', loss_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create fault - stop transmission of FR_ZONE3_100')
        CAN.PeriodicDisableFrame(loss_bus, loss_frame)
        Wait(loss_qualify_ms)
        Read_DTC(
            'Frame-loss DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create over-voltage condition')
        PS.SetVoltage(voltage_level)
        Wait(voltage_mature_ms)
        Read_DTC(
            'Voltage DTC active, frame-loss DTC remains active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF'],
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        Wait(voltage_demature_ms)
        Read_DTC(
            'Voltage DTC healed, frame-loss DTC remains active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF'],
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Remove fault - resume valid transmission of FR_ZONE3_100')
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        Wait(loss_recover_ms)
        Read_DTC(
            'Frame-loss DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_healed'],
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.PeriodicEnableFrame(loss_bus, loss_frame)
            CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
