# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_94 (Codebeamer ID 36753998)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during FRONT crash
# Automation : Automatic
# Note       : 'Matches the measured crash delta-V' is graded against the EDR maximum delta-V of
#              the event (CANC_EDR_MAX_DELTA_V_ELEMENT) within CANC_DELTA_V_TOLERANCE_KMH, an
#              assumed band.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_DELTA_V_TOLERANCE_KMH,
    CANC_DEPLOYMENT_STATUS_EXPECTED,
    CANC_EDR_MAX_DELTA_V_ELEMENT,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '36753998'
    tc_name = 'CANC_13C_TestCase_94'
    tc_desc = (
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during FRONT crash'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    crash_curve_key = CANC_CRASH_CURVE_KEY['front']
    crash_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash_curve_key) or {}
    crash_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash_curve_set.get('RSU', {}).values())
    crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
    crash_clear = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['No Request / Default']
    location_none = MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values']['No Crash/Default']
    deployment_expected = CANC_DEPLOYMENT_STATUS_EXPECTED['front']
    delta_v_element = CANC_EDR_MAX_DELTA_V_ELEMENT['longitudinal']
    delta_v_def = MAH_CAN_SIGNAL_DEFS['SRS_DELTA_V']
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash_curve_key}', crash_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create the front crash')
        load_crash_curves(crash_curve_key, project=PROJECT_NAME)
        crash_ids = [fd_id]
        crash_file = os.path.splitext(log_path)[0] + '_crash.txt'
        crash_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_crash', filepath=crash_file,
            listOption=crash_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        TriggerCrash()
        Wait(3 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(crash_logger)
        crash_read = CAN.ReadFromCanLogFile(crash_file)
        crash_frames = [
            frame for frame in (crash_read[1] if crash_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in crash_ids]
        deploy_rows_keys = {'deploy': 'SRS_DEPLOYEMENT_STS', 'delta': 'SRS_DELTA_V'}
        deploy_rows = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in deploy_rows_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in crash_frames if frame_data.id == fd_id]
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Observe SRS_DEPLOYEMENT_STS')
        RESULT.InterpretEqualResult("SRS_DEPLOYEMENT_STS after the crash",
                                    f"0x{deploy_rows[-1]['deploy']:02X}" if deploy_rows else None,
                                    f"0x{deployment_expected:02X}")
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Observe and decode SRS_DELTA_V')
        delta_v_values = [round(raw_to_physical(row['delta'], scaling=delta_v_def['Factor'], offset=delta_v_def['Offset'],
                                                bits=delta_v_def['bit_length'], signed=bool(delta_v_def.get('Signed'))), 3)
                          for row in deploy_rows]
        delta_v_peak = max(delta_v_values, key=abs) if delta_v_values else None
        RESULT.InterpretEqualResultRange("SRS_DELTA_V within the database range (km/h)", delta_v_values or [None],
                                         delta_v_def['MIN'], delta_v_def['MAX'])
        crash_edr = read_edr_parameters([delta_v_element], return_data=True) or {}
        edr_delta_v = (crash_edr.get('decoded') or {}).get(delta_v_element)
        edr_delta_v = edr_delta_v[0] if isinstance(edr_delta_v, (list, tuple)) and edr_delta_v else edr_delta_v
        RESULT.InterpretEqualResultRange(
            f"SRS_DELTA_V peak {delta_v_peak} matches the recorded {delta_v_element} {edr_delta_v} (km/h difference)",
            abs(abs(delta_v_peak) - abs(edr_delta_v)) if isinstance(delta_v_peak, (int, float))
            and isinstance(edr_delta_v, (int, float)) else None, 0, CANC_DELTA_V_TOLERANCE_KMH)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
