# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CAN_BUSOFF_16 (Codebeamer ID 35729176)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : To check the Timeout DTC when CANFD channel is in Bus Off DTC is active.
# Automation : Semi-automatic (operator creates and removes the bus-off)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.
# Note       : The case title names the CAN-FD channel but reads D27100 (HS-CAN bus-off) while
#              the bus-off is active, which needs the CAN-FD diagnostics alive; the script
#              creates the bus-off on HS-CAN.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_BUS_OFF_ACTIVE_STATUS_KEY,
    CAN_BUS_OFF_DTC,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_TX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
    is_key_message,
    qualification_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35729176'
    tc_name = 'CAN_BUSOFF_16'
    tc_desc = (
        'To check the Timeout DTC when CANFD channel is in Bus Off DTC is active.'
    )
    automation = 'Semi-automatic (operator creates and removes the bus-off)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    lamp_on = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp ON']
    lamp_off = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp OFF/Default']
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)
    # The warning-indicator bit of a DTC status (ISO 14229-1 bit 7) tells whether
    # the bus-off DTC asks for the lamp.
    fd_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['CANFD']], 16) & 0x80 else lamp_off
    hs_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']], 16) & 0x80 else lamp_off
    non_key_frames = [frame_name for frame_name, frame_cfg in CAN_TX_MESSAGE_CONFIG.items()
                      if not is_key_message(frame_name) and frame_cfg.get('message_timeout_dtc')
                      and any(d['frame'] == frame_name for d in MAH_CAN_SIGNAL_DEFS.values())]
    non_key_defs = [next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == frame_name)
                    for frame_name in non_key_frames]
    timeout_dtcs = sorted({CAN_TX_MESSAGE_CONFIG[frame_name]['message_timeout_dtc'] for frame_name in non_key_frames})
    timeout_qualify_ms = max(int(qualification_ms('message_timeout', d['periodicity']) * margin) for d in non_key_defs)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues')
        RESULT.InsertComment('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        print('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_hs.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_hs', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence2_hs_count, 0)
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_fd_alive.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_fd_alive', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Stop all non-key messages of every node')
        for d in non_key_defs:
            CAN.PeriodicDisableFrame(d['bus'], d['frame'])
        Wait(timeout_qualify_ms)
        Read_DTC(
            'Only the bus-off DTC while the bus-off is active',
            " ".join([Read_DTC_Resp_CANC,
                      CAN_BUS_OFF_DTC['HSCAN'], DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Remove the bus-off and read DTC')
        RESULT.InsertComment('OPERATOR ACTION: Remove the CAN-H to CAN-L short on the HS-CAN bus.')
        print('OPERATOR ACTION: Remove the CAN-H to CAN-L short on the HS-CAN bus.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        Wait(busoff_settle_ms)
        Wait(timeout_qualify_ms)
        Read_DTC("Bus-off DTC healed, every message timeout DTC active",
                 " ".join([Read_DTC_Resp_CANC, CAN_BUS_OFF_DTC['HSCAN'], DTC_status['DTC_healed']]
                          + [part for dtc in timeout_dtcs for part in (dtc, DTC_status['DTC_active_WLOFF'])]),
                 Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
            for d in non_key_defs:
                CAN.PeriodicEnableFrame(d['bus'], d['frame'])
                CAN.ReloadDefaultPeriodicFrame(d['bus'], d['frame'])
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
