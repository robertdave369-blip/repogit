# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_2C0_TestCase_06 (Codebeamer ID 35736853)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check Signal Value of IGN_STS_SRS Signal in 2C0 Msg
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_NM_WAKEUP_FRAME,
    CAN_PKE_SLEEP_VALUE,
    CAN_PKE_WAKEUP_SIGNAL_KEY,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    CAN_WAKEUP_BUS_SLEEP_WAIT_MS,
    CAN_WAKEUP_STATUS_FRAME,
    CAN_WAKEUP_STATUS_SIGNAL,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736853'
    tc_name = 'CANC_2C0_TestCase_06'
    tc_desc = (
        'To Check Signal Value of IGN_STS_SRS Signal in 2C0 Msg'
    )
    automation = 'Automatic'

    ign_states = MAH_CAN_SIGNAL_DEFS['IGN_STS_SRS']['State_Values']
    ign_off = ign_states['IGN OFF/Default']
    ign_hw = ign_states['IGN ON due to HW']
    ign_can = ign_states['IGN ON due to CAN wakeup']
    pke_def = MAH_CAN_SIGNAL_DEFS[CAN_PKE_WAKEUP_SIGNAL_KEY]
    nm_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == CAN_NM_WAKEUP_FRAME)
    wake_status_key = next(key for key, d in MAH_CAN_SIGNAL_DEFS.items()
                           if d['frame'] == CAN_WAKEUP_STATUS_FRAME and d['signal'] == CAN_WAKEUP_STATUS_SIGNAL)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(pke_def['bus'], pke_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: IGN OFF and observe IGN_STS_SRS')
        ign_off_ids = [hs_id]
        ign_off_file = os.path.splitext(log_path)[0] + '_ign_off.txt'
        ign_off_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_ign_off', filepath=ign_off_file,
            listOption=ign_off_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(ign_off_logger)
        ign_off_read = CAN.ReadFromCanLogFile(ign_off_file)
        ign_off_frames = [
            frame for frame in (ign_off_read[1] if ign_off_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in ign_off_ids]
        for ign_key in ['SRS1_20_IGN_STS_SRS']:
            ign_def = MAH_CAN_SIGNAL_DEFS[ign_key]
            ign_seen = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[ign_key], ign_def['bit_length'])
                        for frame_data in ign_off_frames
                        if frame_data.id == CAN_RX_MESSAGE_CONFIG[ign_def['frame']]['frame_ID']]
            RESULT.InterpretEqualResult(f"{ign_def['frame']} IGN_STS_SRS after IGN OFF (last frames sent)",
                                        ign_seen[-1:], [ign_off])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: IGN ON and observe IGN_STS_SRS')
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
        PS.IGN_ON()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        for check_key, check_expected in [('SRS1_20_IGN_STS_SRS', ign_hw)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
            PS.IGN_ON()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
