# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_VCU_TestCase47 (Codebeamer ID 35662129)
# Workbook   : VCU_Node_TestCases.xlsx
# Objective  : Verify that when a message content fault is followed by loss of VCU4_FD_1500
#              reception, the reported communication fault changes according to the specified
#              priority.
# Automation : Automatic
# Note       : A wrong DLC is produced by stopping the frame and sending a copy on the same
#              identifier with the payload length CAN_DLC_ERROR_PAYLOAD_LENGTH gives (no shared-
#              library call changes the DLC of a simulated frame); confirm on the bench that the
#              copy goes out on the identifier.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    get_frame_message_content_failure_dtc,
    is_key_message,
    qualification_ms,
    recovery_ms,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35662129'
    tc_name = 'CANC_VCU_TestCase47'
    tc_desc = (
        'Verify that when a message content fault is followed by loss of VCU4_FD_1500 '
        'reception, the reported communication fault changes according to the specified '
        'priority.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    lower_frame = 'VCU4_FD_1500'
    lower_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == lower_frame)
    lower_bus = lower_def['bus']
    lower_dtc = get_frame_message_content_failure_dtc(lower_frame)[0]
    if lower_dtc is None:
        lower_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(lower_frame)
    lower_error_frame = lower_frame + '_DLC_ERROR'
    lower_error_payload = [0] * CAN_DLC_ERROR_PAYLOAD_LENGTH[lower_def['dlc']]
    lower_qualify_ms = int(qualification_ms('message_content', lower_def['periodicity']) * margin)
    lower_recover_ms = int(recovery_ms('message_content', lower_def['periodicity']) * margin)
    higher_frame = 'VCU4_FD_1500'
    higher_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == higher_frame)
    higher_bus = higher_def['bus']
    higher_mode = 'node_absent' if is_key_message(higher_frame) else 'message_timeout'
    higher_dtc = resolve_dtc_for_event('frame_disabled', higher_frame)
    higher_qualify_ms = int(qualification_ms(higher_mode, higher_def['periodicity']) * margin)
    higher_recover_ms = int(recovery_ms(higher_mode, higher_def['periodicity']) * margin)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([lower_def, higher_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure (DLC) DTC of {lower_frame}', lower_dtc),
            (f'frame-loss DTC of {higher_frame}', higher_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(lower_bus, lower_frame)
        CAN.ReloadDefaultPeriodicFrame(lower_bus, lower_frame)
        CAN.PeriodicEnableFrame(higher_bus, higher_frame)
        CAN.ReloadDefaultPeriodicFrame(higher_bus, higher_frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create and qualify the lower-priority fault - inject incorrect DLC on VCU4_FD_1500')
        CAN.PeriodicDisableFrame(lower_bus, lower_frame)
        CAN.SetPeriodicFrame(lower_bus, lower_error_frame, lower_def['frame_ID'], lower_def['periodicity'],
                             lower_error_payload, lower_def['is_fd'])
        Wait(lower_qualify_ms)
        Read_DTC(
            'Lower-priority DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      lower_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create the higher-priority fault - stop transmission of VCU4_FD_1500')
        CAN.RemovePeriodicFrame(lower_bus, lower_error_frame)
        Wait(higher_qualify_ms)
        # Before an IGN cycle the lower-priority DTC may still read active, so the
        # list is recorded rather than graded.
        RESULT.LogAction("DTCs before the IGN cycle", CAN.SendDiagByValues(Read_DTC_Req_CANC))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Wait(higher_qualify_ms)
        Read_DTC(
            'Higher-priority DTC active, lower-priority DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      higher_dtc, DTC_status['DTC_active_WLOFF'],
                      lower_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Wait(higher_qualify_ms)
        Read_DTC(
            'Higher-priority DTC active, lower-priority DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      higher_dtc, DTC_status['DTC_active_WLOFF'],
                      lower_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(higher_bus, higher_frame)
            CAN.ReloadDefaultPeriodicFrame(higher_bus, higher_frame)
            CAN.RemovePeriodicFrame(lower_bus, lower_error_frame)
            CAN.PeriodicEnableFrame(lower_bus, lower_frame)
            CAN.ReloadDefaultPeriodicFrame(lower_bus, lower_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
