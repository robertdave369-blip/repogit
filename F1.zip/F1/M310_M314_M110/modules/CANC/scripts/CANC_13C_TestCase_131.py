# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_131 (Codebeamer ID 36767370)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify IMU faulty condition output value
# Automation : Semi-automatic (no IMU fault-injection method or EVT exists for the Panasonic
#              IMU)

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_MANUAL_ACTION_WINDOW_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '36767370'
    tc_name = 'CANC_13C_TestCase_131'
    tc_desc = (
        'Verify IMU faulty condition output value'
    )
    automation = 'Semi-automatic (no IMU fault-injection method or EVT exists for the Panasonic IMU)'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Inject the IMU sensor fault')
        RESULT.InsertComment('OPERATOR ACTION: Inject the IMU sensor fault on the bench and keep it active.')
        print('OPERATOR ACTION: Inject the IMU sensor fault on the bench and keep it active.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        fault_ids = [fd_id]
        fault_file = os.path.splitext(log_path)[0] + '_imu_fault.txt'
        fault_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_fault', filepath=fault_file,
            listOption=fault_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(fault_logger)
        fault_read = CAN.ReadFromCanLogFile(fault_file)
        fault_frames = [
            frame for frame in (fault_read[1] if fault_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in fault_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in fault_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} transmitted as the invalid value under the IMU fault",
                                        bool(imu_raw) and all(value == imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Remove the IMU fault and allow recovery')
        RESULT.InsertComment('OPERATOR ACTION: Remove the IMU sensor fault.')
        print('OPERATOR ACTION: Remove the IMU sensor fault.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        recovered_ids = [fd_id]
        recovered_file = os.path.splitext(log_path)[0] + '_imu_recovered.txt'
        recovered_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_recovered', filepath=recovered_file,
            listOption=recovered_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(recovered_logger)
        recovered_read = CAN.ReadFromCanLogFile(recovered_file)
        recovered_frames = [
            frame for frame in (recovered_read[1] if recovered_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in recovered_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in recovered_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} no longer the invalid value after recovery",
                                        bool(imu_raw) and all(value != imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
