# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_VCU_TestCase13 (Codebeamer ID 35715449)
# Workbook   : VCU_Node_TestCases.xlsx
# Objective  : Verify that VCU1_FD_20 is received at the specified periodicity without
#              communication faults during normal transmission.
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35715449'
    tc_name = 'CANC_VCU_TestCase13'
    tc_desc = (
        'Verify that VCU1_FD_20 is received at the specified periodicity without '
        'communication faults during normal transmission.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    frame = 'VCU1_FD_20'
    frame_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == frame)
    bus = frame_def['bus']
    period_ms = frame_def['periodicity']
    window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * period_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([frame_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Measure the time between consecutive VCU1_FD_20 frames')
        window1_ids = [frame_def['frame_ID']]
        window1_file = os.path.splitext(log_path)[0] + '_periodicity_1.txt'
        window1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_periodicity_1', filepath=window1_file,
            listOption=window1_ids, channel_names=[bus])
        Wait(window_ms)
        CAN.StopLoggingToFile(window1_logger)
        window1_read = CAN.ReadFromCanLogFile(window1_file)
        window1_frames = [
            frame for frame in (window1_read[1] if window1_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in window1_ids]
        window1_times = [frame_data.timestamp / 1000 for frame_data in window1_frames]
        window1_deltas = [round(later - earlier, 3) for earlier, later in zip(window1_times, window1_times[1:])]
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(window1_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResultRange(f"{frame} time between consecutive frames (ms)", window1_deltas,
                                         period_ms * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         period_ms * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InterpretEqualResult(f"{frame} has no gap outside the tolerance",
                                    str(detect_time_gap(window1_times, period_ms,
                                                        tolerance=CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)), "[]")
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Continue monitoring over additional cycles')
        window2_ids = [frame_def['frame_ID']]
        window2_file = os.path.splitext(log_path)[0] + '_periodicity_2.txt'
        window2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_periodicity_2', filepath=window2_file,
            listOption=window2_ids, channel_names=[bus])
        Wait(window_ms)
        CAN.StopLoggingToFile(window2_logger)
        window2_read = CAN.ReadFromCanLogFile(window2_file)
        window2_frames = [
            frame for frame in (window2_read[1] if window2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in window2_ids]
        window2_times = [frame_data.timestamp / 1000 for frame_data in window2_frames]
        window2_deltas = [round(later - earlier, 3) for earlier, later in zip(window2_times, window2_times[1:])]
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(window2_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResultRange(f"{frame} time between consecutive frames (ms)", window2_deltas,
                                         period_ms * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         period_ms * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InterpretEqualResult(f"{frame} has no gap outside the tolerance",
                                    str(detect_time_gap(window2_times, period_ms,
                                                        tolerance=CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)), "[]")
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Read DTC')
        Read_DTC('No communication fault during normal transmission', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
