# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_21 (Codebeamer ID 35739874)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check Signal Values of Near_Crash Signal in ID 13C in IGN On condition
# Automation : Semi-automatic (operator shakes the ECU)

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_MANUAL_ACTION_WINDOW_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_PROVEOUT_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35739874'
    tc_name = 'CANC_13C_TestCase_21'
    tc_desc = (
        'To Check Signal Values of Near_Crash Signal in ID 13C in IGN On condition'
    )
    automation = 'Semi-automatic (operator shakes the ECU)'

    near_set = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['Crash']
    near_clear = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['No Near Crash']
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: NEAR_CRASH initial value')
        for check_key, check_expected in [('NEAR_CRASH', near_clear)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Create a near crash by shaking the ECU')
        shake_ids = [fd_id]
        shake_file = os.path.splitext(log_path)[0] + '_near_crash_shake.txt'
        shake_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_near_crash_shake', filepath=shake_file,
            listOption=shake_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        RESULT.InsertComment(f'OPERATOR ACTION: Shake the ECU hard enough to cause a near crash, within the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        print(f'OPERATOR ACTION: Shake the ECU hard enough to cause a near crash, within the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        CAN.StopLoggingToFile(shake_logger)
        shake_read = CAN.ReadFromCanLogFile(shake_file)
        shake_frames = [
            frame for frame in (shake_read[1] if shake_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in shake_ids]
        near_rows_keys = {'near': 'NEAR_CRASH'}
        near_rows = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in near_rows_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in shake_frames if frame_data.id == fd_id]
        near_on = [row for row in near_rows if row['near'] == near_set]
        RESULT.InterpretEqualResult("SRS1_FD_10 NEAR_CRASH set during the shaking", bool(near_on), True)
        near_runs = []
        for row in near_rows:
            if row['near'] == near_set and (not near_runs or row['t'] - near_runs[-1][1] > 2 * fd_period_ms):
                near_runs.append([row['t'], row['t']])
            elif row['near'] == near_set:
                near_runs[-1][1] = row['t']
        RESULT.InterpretEqualResultRange("SRS1_FD_10 NEAR_CRASH hold time (ms)",
                                         [round(end - start, 1) + fd_period_ms for start, end in near_runs] or [None],
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
