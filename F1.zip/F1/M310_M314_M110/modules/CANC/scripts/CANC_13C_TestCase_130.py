# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_130 (Codebeamer ID 36754034)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify SRS_PAB_WARN_STS requests PAB OFF warning in semi-automatic mode when PAB
#              is ON and passenger OCS classification is child with CRS seat type.
# Automation : Automatic
# Note       : PAB control type is EOL byte 5 bit 5 (agent_sc3.md: 0 semi-automatic, 1
#              automatic), set with manage_eol_code('PAB_MODE'); fault_free_profile restores the
#              default EOL afterwards.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_DCS_STATE_SETTLE_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_OCS_UPDATE_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '36754034'
    tc_name = 'CANC_13C_TestCase_130'
    tc_desc = (
        'Verify SRS_PAB_WARN_STS requests PAB OFF warning in semi-automatic mode when PAB is '
        'ON and passenger OCS classification is child with CRS seat type.'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    switch_def = MAH_CAN_SIGNAL_DEFS['PSGR_AIRBAG_SW_IC']
    padl_states = MAH_CAN_SIGNAL_DEFS['INDC_PADL']['State_Values']
    warn_states = MAH_CAN_SIGNAL_DEFS['SRS_PAB_WARN_STS']['State_Values']
    ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
    ocs_fault_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS_FAULT_STS']
    ocs_subseat_def = MAH_CAN_SIGNAL_DEFS['OCS_SUBSEAT_CLASSIFICATION']

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(switch_def['bus'], switch_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(switch_def['bus'], switch_def['frame'])
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Configure PAB control semi-automatic (EOL PAB_MODE) and enable OCS')
        manage_eol_code('PAB_MODE', 'disable', project=PROJECT_NAME, base_from_project_default=True)
        manage_variant_code('OCS', 'enable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Set PSGR_AIRBAG_SW_IC = PAB ON / Default')
        CAN.ChangeSignalValue(switch_def['bus'], switch_def['frame'], switch_def['signal'], str(switch_def['State_Values']['PAB ON / Default']))
        Wait(CANC_DCS_STATE_SETTLE_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Observe INDC_PADL (Lamp OFF/Default)')
        for check_key, check_expected in [('INDC_PADL', padl_states['Lamp OFF/Default'])]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Set OCS_PASS_CLASS = 4, OCS_SUBSEAT_CLASSIFICATION = 0')
        CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'], ocs_class_def['signal'], str(4))
        CAN.ChangeSignalValue(ocs_subseat_def['bus'], ocs_subseat_def['frame'], ocs_subseat_def['signal'], str(0))
        Wait(CANC_OCS_UPDATE_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Observe SRS_PAB_WARN_STS (PAB_OFF_WARNING)')
        for check_key, check_expected in [('SRS_PAB_WARN_STS', warn_states['PAB_OFF_WARNING'])]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 8: Observe INDC_PADL (Lamp OFF/Default)')
        for check_key, check_expected in [('INDC_PADL', padl_states['Lamp OFF/Default'])]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame(switch_def['bus'], switch_def['frame'])
            CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
