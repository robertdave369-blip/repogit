# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_53 (Codebeamer ID 35773103)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check value of Even parity signal when Crash occurs
# Automation : Automatic
# Note       : The case expects EVEN_PARITY_BIT = 1 throughout the crash; the bit follows byte 0
#              (DBC: even parity over bits 0-6), so the script grades every frame against byte 0
#              and records the values seen.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '35773103'
    tc_name = 'CANC_13C_TestCase_53'
    tc_desc = (
        'To Check value of Even parity signal when Crash occurs'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    parity_key = 'EVEN_PARITY_BIT'
    parity_def = MAH_CAN_SIGNAL_DEFS[parity_key]
    parity_id = CAN_RX_MESSAGE_CONFIG[parity_def['frame']]['frame_ID']
    # EVEN_PARITY_BIT makes the count of ones in bits 0 to (its start bit - 1) of byte 0 even.
    parity_mask = (1 << CAN_SIGNAL_START_BIT[parity_key]) - 1
    parity_odd = parity_def['State_Values']['ODD/Default']
    parity_even = parity_def['State_Values']['Even']
    crash_curve_key = CANC_CRASH_CURVE_KEY['front']
    crash_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash_curve_key) or {}
    crash_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash_curve_set.get('RSU', {}).values())
    crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
    crash_clear = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['No Request / Default']
    location_none = MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values']['No Crash/Default']
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash_curve_key}', crash_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Verify EVEN_PARITY_BIT with no fault')
        idle_ids = [fd_id]
        idle_file = os.path.splitext(log_path)[0] + '_parity_idle.txt'
        idle_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_parity_idle', filepath=idle_file,
            listOption=idle_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(idle_logger)
        idle_read = CAN.ReadFromCanLogFile(idle_file)
        idle_frames = [
            frame for frame in (idle_read[1] if idle_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in idle_ids]
        idle_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in idle_frames if frame_data.id == parity_id]
        idle_errors = [row for row in idle_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str(idle_errors[:5]), "[]")
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT", sorted({row[1] for row in idle_rows}), [parity_odd])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Simulate a front crash and verify EVEN_PARITY_BIT')
        load_crash_curves(crash_curve_key, project=PROJECT_NAME)
        fault_ids = [fd_id]
        fault_file = os.path.splitext(log_path)[0] + '_fault.txt'
        fault_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_fault', filepath=fault_file,
            listOption=fault_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        TriggerCrash()
        Wait(3 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(fault_logger)
        fault_read = CAN.ReadFromCanLogFile(fault_file)
        fault_frames = [
            frame for frame in (fault_read[1] if fault_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in fault_ids]
        fault_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in fault_frames if frame_data.id == parity_id]
        fault_errors = [row for row in fault_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str(fault_errors[:5]), "[]")
        RESULT.LogAction(f"{parity_def['frame']} EVEN_PARITY_BIT values during the crash", str(sorted({row[1] for row in fault_rows})))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
