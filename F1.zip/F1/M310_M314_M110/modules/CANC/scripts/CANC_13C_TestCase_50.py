# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_50 (Codebeamer ID 35739904)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check Signal Values of IGN_STS_SRS when wakeup through Hardware Ign and
#              PKE_CLAMP message also sent
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_NM_WAKEUP_FRAME,
    CAN_PKE_SLEEP_VALUE,
    CAN_PKE_WAKEUP_SIGNAL_KEY,
    CAN_PKE_WAKEUP_VALUE,
    CAN_RX_MESSAGE_CONFIG,
    CAN_WAKEUP_BUS_SLEEP_WAIT_MS,
    CAN_WAKEUP_STATUS_FRAME,
    CAN_WAKEUP_STATUS_SIGNAL,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35739904'
    tc_name = 'CANC_13C_TestCase_50'
    tc_desc = (
        'To Check Signal Values of IGN_STS_SRS when wakeup through Hardware Ign and PKE_CLAMP '
        'message also sent'
    )
    automation = 'Automatic'

    ign_states = MAH_CAN_SIGNAL_DEFS['IGN_STS_SRS']['State_Values']
    ign_off = ign_states['IGN OFF/Default']
    ign_hw = ign_states['IGN ON due to HW']
    ign_can = ign_states['IGN ON due to CAN wakeup']
    pke_def = MAH_CAN_SIGNAL_DEFS[CAN_PKE_WAKEUP_SIGNAL_KEY]
    nm_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == CAN_NM_WAKEUP_FRAME)
    wake_status_key = next(key for key, d in MAH_CAN_SIGNAL_DEFS.items()
                           if d['frame'] == CAN_WAKEUP_STATUS_FRAME and d['signal'] == CAN_WAKEUP_STATUS_SIGNAL)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(pke_def['bus'], pke_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: IGN OFF and no VCU NM / PKE wake request - the ECU frames stop')
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
        presence3_ids = [fd_id, hs_id]
        presence3_file = os.path.splitext(log_path)[0] + '_bus_sleep.txt'
        presence3_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_bus_sleep', filepath=presence3_file,
            listOption=presence3_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence3_logger)
        presence3_read = CAN.ReadFromCanLogFile(presence3_file)
        presence3_frames = [
            frame for frame in (presence3_read[1] if presence3_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence3_ids]
        presence3_fd_count = sum(1 for frame_data in presence3_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResult(
            f"{fd_frame} is not transmitted (frames in the window)",
            presence3_fd_count, 0)
        presence3_hs_count = sum(1 for frame_data in presence3_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence3_hs_count, 0)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Turn IGN ON')
        PS.IGN_ON()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        for check_key, check_expected in [('IGN_STS_SRS', ign_hw), ('SRS1_20_IGN_STS_SRS', ign_hw)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        presence4_ids = [fd_id, hs_id]
        presence4_file = os.path.splitext(log_path)[0] + '_after_ign_on.txt'
        presence4_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_after_ign_on', filepath=presence4_file,
            listOption=presence4_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence4_logger)
        presence4_read = CAN.ReadFromCanLogFile(presence4_file)
        presence4_frames = [
            frame for frame in (presence4_read[1] if presence4_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence4_ids]
        presence4_fd_count = sum(1 for frame_data in presence4_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence4_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence4_hs_count = sum(1 for frame_data in presence4_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence4_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Start sending the PKE clamp state (FR_ZONE2_100)')
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_WAKEUP_VALUE))
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        for check_key, check_expected in [('IGN_STS_SRS', ign_can), ('SRS1_20_IGN_STS_SRS', ign_can)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        presence5_ids = [fd_id, hs_id]
        presence5_file = os.path.splitext(log_path)[0] + '_after_pke.txt'
        presence5_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_after_pke', filepath=presence5_file,
            listOption=presence5_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence5_logger)
        presence5_read = CAN.ReadFromCanLogFile(presence5_file)
        presence5_frames = [
            frame for frame in (presence5_read[1] if presence5_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence5_ids]
        presence5_fd_count = sum(1 for frame_data in presence5_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence5_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence5_hs_count = sum(1 for frame_data in presence5_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence5_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
            PS.IGN_ON()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
