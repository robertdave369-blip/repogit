# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_2C0_TestCase_07 (Codebeamer ID 35736854)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for
#              front crash
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_LOCATION_STATE,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_PROVEOUT_TOLERANCE_PERCENT,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736854'
    tc_name = 'CANC_2C0_TestCase_07'
    tc_desc = (
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for '
        'front crash'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    crash_curve_key = CANC_CRASH_CURVE_KEY['front']
    crash_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash_curve_key) or {}
    crash_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash_curve_set.get('RSU', {}).values())
    crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
    crash_clear = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['No Request / Default']
    location_none = MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values']['No Crash/Default']
    location_expected = MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['front']]
    door_set = MAH_CAN_SIGNAL_DEFS['DOOR_UNLOCK']['State_Values']['Request to unlock Doors']
    mode_active = MAH_CAN_SIGNAL_DEFS['SRS_OPERATION_MODE']['State_Values']['active']
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash_curve_key}', crash_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Load the front crash curves')
        load_crash_curves(crash_curve_key, project=PROJECT_NAME)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Crash signals hold their default values')
        check_pairs = [
            ('SRS1_20_STS_CRASH', crash_clear),
            ('SRS1_20_CRASH_LOCATION', location_none),
            ('DOOR_UNLOCK', MAH_CAN_SIGNAL_DEFS['DOOR_UNLOCK']['State_Values']['No Request / Default']),
            ('SRS1_20_SRS_OPERATION_MODE', mode_active),
            ('SRS1_20_SCM_CNT', 0),
        ]
        for check_key, check_expected in check_pairs:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
            try:
                check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
            except ValueError:
                check_value = check_text
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Create the front crash')
        crash_ids = [fd_id, hs_id]
        crash_file = os.path.splitext(log_path)[0] + '_crash.txt'
        crash_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_crash', filepath=crash_file,
            listOption=crash_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(3 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(crash_logger)
        crash_read = CAN.ReadFromCanLogFile(crash_file)
        crash_frames = [
            frame for frame in (crash_read[1] if crash_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in crash_ids]
        hs_rows_keys = {'sts': 'SRS1_20_STS_CRASH', 'loc': 'SRS1_20_CRASH_LOCATION', 'door': 'DOOR_UNLOCK', 'mode': 'SRS1_20_SRS_OPERATION_MODE', 'scm': 'SRS1_20_SCM_CNT'}
        hs_rows = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in hs_rows_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in crash_frames if frame_data.id == hs_id]
        hs_rows_crash = [row for row in hs_rows if row['sts'] == crash_set]
        hs_rows_hold_ms = (round(hs_rows_crash[-1]['t'] - hs_rows_crash[0]['t'], 1)
                          + CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']) if hs_rows_crash else None
        RESULT.InterpretEqualResultRange(f"{hs_frame} STS_CRASH set for (ms)", hs_rows_hold_ms,
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
        RESULT.InterpretEqualResult(f"{hs_frame} CRASH_LOCATION while STS_CRASH is set",
                                    sorted({row['loc'] for row in hs_rows_crash}), [location_expected])
        hs_rows_after = [row for row in hs_rows if hs_rows_crash and row['t'] > hs_rows_crash[-1]['t']]
        RESULT.InterpretEqualResult(f"{hs_frame} STS_CRASH clear after the hold time",
                                    sorted({row['sts'] for row in hs_rows_after}), [crash_clear])
        RESULT.InterpretEqualResult(f"{hs_frame} DOOR_UNLOCK while STS_CRASH is set",
                                    sorted({row['door'] for row in hs_rows_crash}), [door_set])
        RESULT.InterpretEqualResult(f"{hs_frame} SRS_OPERATION_MODE during the crash",
                                    sorted({row['mode'] for row in hs_rows}), [mode_active])
        hs_rows_scm = [row['scm'] for row in hs_rows_crash]
        RESULT.InterpretEqualResult(f"{hs_frame} SCM_CNT counts (1..15, rolling over) while STS_CRASH is set",
                                    bool(hs_rows_scm) and len(set(hs_rows_scm)) > 1
                                    and all(0 < value <= 15 for value in hs_rows_scm[1:]), True)
        RESULT.InterpretEqualResult(f"{hs_frame} SCM_CNT back to 0 after the crash",
                                    sorted({row['scm'] for row in hs_rows_after}), [0])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
