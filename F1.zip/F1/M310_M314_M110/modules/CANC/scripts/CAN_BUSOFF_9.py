# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CAN_BUSOFF_9 (Codebeamer ID 35721115)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : 1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages
#              diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is not BUS OFF)
# Automation : Semi-automatic (operator creates and removes the bus-off)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_TESTER_PRESENT_PERIOD_MS,
    CAN_BUS_OFF_ACTIVE_STATUS_KEY,
    CAN_BUS_OFF_DTC,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
    DIAG_TX_ID,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_REQ_28_01_01,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_68_01,
    UDS_RESP_SESSION_EXTENDED,
)


def run_test():
    tc_id = '35721115'
    tc_name = 'CAN_BUSOFF_9'
    tc_desc = (
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages '
        'diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is not BUS OFF)'
    )
    automation = 'Semi-automatic (operator creates and removes the bus-off)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    lamp_on = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp ON']
    lamp_off = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp OFF/Default']
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)
    # The warning-indicator bit of a DTC status (ISO 14229-1 bit 7) tells whether
    # the bus-off DTC asks for the lamp.
    fd_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['CANFD']], 16) & 0x80 else lamp_off
    hs_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']], 16) & 0x80 else lamp_off

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues')
        RESULT.InsertComment('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        print('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_hs.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_hs', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence2_hs_count, 0)
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_fd_alive.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_fd_alive', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Restart the bench messages and read DTC while the bus-off is active')
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
        Read_DTC(
            'HS-CAN bus-off DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      CAN_BUS_OFF_DTC['HSCAN'], DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Send Tester Present periodically and enter the extended session')
        tester_present(CAN_FD_CHANNEL_NAME, CANC_TESTER_PRESENT_PERIOD_MS, 'start',
                       frame_name='CANC_TESTER_PRESENT', frame_id=DIAG_TX_ID)
        RESULT.InterpretEqualResult("Extended session", str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)),
                                    UDS_RESP_SESSION_EXTENDED)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Communication control request')
        RESULT.InterpretEqualResult('Communication control response', str(CAN.SendDiagByValues(UDS_REQ_28_01_01)), UDS_RESP_68_01)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Check SRS1_FD_10')
        presence6_ids = [fd_id]
        presence6_file = os.path.splitext(log_path)[0] + '_after_comm_control.txt'
        presence6_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_after_comm_control', filepath=presence6_file,
            listOption=presence6_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence6_logger)
        presence6_read = CAN.ReadFromCanLogFile(presence6_file)
        presence6_frames = [
            frame for frame in (presence6_read[1] if presence6_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence6_ids]
        presence6_fd_count = sum(1 for frame_data in presence6_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResult(
            f"{fd_frame} is not transmitted (frames in the window)",
            presence6_fd_count, 0)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
            tester_present(CAN_FD_CHANNEL_NAME, None, 'stop', frame_name='CANC_TESTER_PRESENT')
            PS.Power_Cycle()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
