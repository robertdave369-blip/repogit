# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_VCU_TestCase26 (Codebeamer ID 35662157)
# Workbook   : VCU_Node_TestCases.xlsx
# Objective  : Verify that changing only VCU2_TRUNCATED_MAC while keeping the other fields in
#              VCU2_FD_100 unchanged does not cause a CRC-related failure.
# Automation : Automatic

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
    get_frame_message_content_failure_dtc,
    qualification_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35662157'
    tc_name = 'CANC_VCU_TestCase26'
    tc_desc = (
        'Verify that changing only VCU2_TRUNCATED_MAC while keeping the other fields in '
        'VCU2_FD_100 unchanged does not cause a CRC-related failure.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    secoc_key = 'VCU2_TRUNCATED_MAC'
    secoc_def = MAH_CAN_SIGNAL_DEFS[secoc_key]
    frame = secoc_def['frame']
    bus = secoc_def['bus']
    period_ms = secoc_def['periodicity']
    secoc_values = list(secoc_def.get('TestCase_values') or [])
    mcf_dtc = get_frame_message_content_failure_dtc(frame)[0]
    # Long enough for a message content failure to qualify if one were detected.
    observe_ms = int(qualification_ms('message_content', period_ms) * margin)
    dwell_ms = max(3 * period_ms, observe_ms // max(len(secoc_values), 1))

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([secoc_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'representative values of {secoc_key}', secoc_values or None),
            (f'message content failure DTC of {frame}', mcf_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Change only VCU2_TRUNCATED_MAC through representative values, all other fields unchanged')
        CAN.DynamicDisableSignal(bus, frame, secoc_def['signal'])
        elapsed_ms = 0
        while elapsed_ms < observe_ms:
            for value in secoc_values:
                CAN.ChangeSignalValue(bus, frame, secoc_def['signal'], str(value))
                Wait(dwell_ms)
                elapsed_ms += dwell_ms
                read_back = str(CAN.GetSignalFromFrame(bus, frame, secoc_def['signal'])).strip()
                try:
                    read_back = str(int(read_back, 16) if read_back.lower().startswith("0x") else int(float(read_back)))
                except ValueError:
                    pass
                RESULT.InterpretEqualResult(f"{frame} carries {secoc_def['signal']} = {value}", read_back, str(value))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Check for a CRC-related failure while only VCU2_TRUNCATED_MAC changes')
        mcf_check = CAN.CheckSingleDTC(None, mcf_dtc)
        RESULT.InterpretEqualResult(
            f"No message content failure (CRC) DTC {mcf_dtc} for {frame}",
            str(mcf_check[-1]).endswith("not present"), True)
        RESULT.LogAction("DTCs while only the field changed", CAN.SendDiagByValues(Read_DTC_Req_CANC))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.DynamicEnableSignal(bus, frame, secoc_def['signal'])
            CAN.ReloadDefaultPeriodicFrame(bus, frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
