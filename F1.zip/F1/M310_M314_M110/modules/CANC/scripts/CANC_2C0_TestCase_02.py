# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_2C0_TestCase_02 (Codebeamer ID 35736849)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check signal Values of INDC_SRS(Warning lamp in plantmode) Signal 2C0 Msg
# Automation : Automatic (irreversible: changes the learned phase of life)
# Note       : Entering plant mode moves the ECU's learned phase of life to Vehicle Assembly; 30
#              s fault-free it moves on to Owner, from which plantmode_config allows only
#              EndOfLife. The case can therefore run once per software flash; the script reads
#              the phase first and stops when plant mode cannot be entered.

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_PROVEOUT_TOLERANCE_PERCENT,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.plantmode_config import (
    PHASE_OF_LIFE_STATES,
    PHASE_OF_LIFE_TRANSITIONS,
    PLANT_MODE_OWNER_TRANSITION_DELAY_MS,
    ROUTINE_CONTROL_SECURITY_LEVEL,
    build_phase_of_life_start_routine,
    build_phase_of_life_status_request,
    build_routine_control_positive_response,
    format_uds_bytes,
)


def run_test():
    tc_id = '35736849'
    tc_name = 'CANC_2C0_TestCase_02'
    tc_desc = (
        'To Check signal Values of INDC_SRS(Warning lamp in plantmode) Signal 2C0 Msg'
    )
    automation = 'Automatic (irreversible: changes the learned phase of life)'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    vehicle_assembly = next(phase for phase, name in PHASE_OF_LIFE_STATES.items() if name == 'VehicleAssembly')
    plant_request = format_uds_bytes(build_phase_of_life_start_routine(vehicle_assembly))
    plant_response = format_uds_bytes(build_routine_control_positive_response(vehicle_assembly))
    plant_window_ms = int(PLANT_MODE_OWNER_TRANSITION_DELAY_MS * margin)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Put the ECU in plant mode and record the warning lamp')
        phase_response = str(CAN.SendDiagByValues(format_uds_bytes(build_phase_of_life_status_request())))
        phase_tokens = phase_response.split()
        current_phase = int(phase_tokens[3], 16) if len(phase_tokens) > 3 and phase_tokens[0].upper() == "0X62" else None
        RESULT.LogAction("Phase of life before plant mode", phase_response)
        if (current_phase, vehicle_assembly) not in PHASE_OF_LIFE_TRANSITIONS:
            RESULT.LogCustomAction(
                "Plant mode can be entered from the current phase of life",
                f"phase in {sorted(source for source, target in PHASE_OF_LIFE_TRANSITIONS if target == vehicle_assembly)}",
                f"phase {current_phase}", False)
            return
        enter_ext_session()
        Internal_Security_Access(ROUTINE_CONTROL_SECURITY_LEVEL)
        RESULT.InterpretEqualResult("Enter plant mode (phase of life Vehicle Assembly)",
                                    str(CAN.SendDiagByValues(plant_request)), plant_response)
        plant_ids = [hs_id]
        plant_file = os.path.splitext(log_path)[0] + '_plant_mode.txt'
        plant_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_plant_mode', filepath=plant_file,
            listOption=plant_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(plant_window_ms + 2 * NM_IGN_ON_STARTUP_DELAY_MS)
        CAN.StopLoggingToFile(plant_logger)
        plant_read = CAN.ReadFromCanLogFile(plant_file)
        plant_frames = [
            frame for frame in (plant_read[1] if plant_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in plant_ids]
        for lamp_key in ['SRS1_20_INDC_SRS']:
            lamp_def = MAH_CAN_SIGNAL_DEFS[lamp_key]
            lamp_id = CAN_RX_MESSAGE_CONFIG[lamp_def['frame']]['frame_ID']
            flash_value = lamp_def['State_Values']['Flashing 1Hz']
            lamp_rows = [(frame_data.timestamp / 1000,
                          extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[lamp_key], lamp_def['bit_length']))
                         for frame_data in plant_frames if frame_data.id == lamp_id]
            flash_times = [t for t, value in lamp_rows if value == flash_value]
            flash_ms = round(flash_times[-1] - flash_times[0] + lamp_def['periodicity'], 1) if flash_times else None
            RESULT.InterpretEqualResultRange(
                f"{lamp_def['frame']} {lamp_def['signal']} flashing in plant mode (ms)", flash_ms,
                PLANT_MODE_OWNER_TRANSITION_DELAY_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                PLANT_MODE_OWNER_TRANSITION_DELAY_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
            lamp_after = sorted({value for t, value in lamp_rows if flash_times and t > flash_times[-1]})
            RESULT.InterpretEqualResult(f"{lamp_def['frame']} {lamp_def['signal']} stops flashing after plant mode",
                                        lamp_after, [lamp_def['State_Values']['Lamp OFF/Default']])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
