"""Run the fully automatic M310_M314_M110 CAN-C scripts.

Author: Kris

GENERATED FILE - regenerate with:
    py -3.14 tools/generate_canc_scripts.py

394 of the 453 CAN-C scripts need nobody at the bench; this runner runs them
one after another without stopping. The other 59 (operator actions, missing crash curves,
plant mode, not executable) are in run_all_canc_non_automatic_scripts.py.

    py -3.14 run_all_canc_automatic_scripts.py                                  # everything uncommented
    py -3.14 run_all_canc_automatic_scripts.py --only CANC_VCU                  # name contains CANC_VCU
    py -3.14 run_all_canc_automatic_scripts.py --start-from CANC_VCU_TestCase10 # resume a run there
    py -3.14 run_all_canc_automatic_scripts.py --stop-on-fail                   # stop at the first non-pass
    py -3.14 run_all_canc_automatic_scripts.py --list                           # show what would run

Each script runs in its own Python process and writes its own ARIA report under
test_results/M310_M314_M110/<date>/. The status shown for a script is the verdict apym
writes on the last line of that report (<!--PASSED--> or <!--FAILED-->); ERROR means the
script crashed or left no verdict. Results go to canc_automatic_results.json, rewritten
after every script so an interrupted run keeps what finished. Ctrl+C stops the run once
the current script has finished its own cleanup.

These scripts drive a bench. Run them only against a rig you are authorized to use.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
FRAMEWORK_ROOT = SCRIPT_DIR.parents[4]
REPORT_DIR = FRAMEWORK_ROOT / "test_results" / SCRIPT_DIR.parents[2].name
RESULTS_FILE = SCRIPT_DIR / "canc_automatic_results.json"

# Comment out a line to skip that script.
SCRIPT_FILES = [
    # Diagnostic_ID_TestCases.xlsx (2)
    "CANC_DIAGNOSTICS_Testcase1.py",
    "CANC_DIAGNOSTICS_Testcase2.py",
    # EPS_Node_TestCases.xlsx (24)
    "CANC_EPS_TestCase1.py",
    "CANC_EPS_TestCase2.py",
    "CANC_EPS_TestCase3.py",
    "CANC_EPS_TestCase4.py",
    "CANC_EPS_TestCase5.py",
    "CANC_EPS_TestCase6.py",
    "CANC_EPS_TestCase7.py",
    "CANC_EPS_TestCase8.py",
    "CANC_EPS_TestCase9.py",
    "CANC_EPS_TestCase10.py",
    "CANC_EPS_TestCase11.py",
    "CANC_EPS_TestCase12.py",
    "CANC_EPS_TestCase13.py",
    "CANC_EPS_TestCase14.py",
    "CANC_EPS_TestCase15.py",
    "CANC_EPS_TestCase16.py",
    "CANC_EPS_TestCase17.py",
    "CANC_EPS_TestCase18.py",
    "CANC_EPS_TestCase19.py",
    "CANC_EPS_TestCase20.py",
    "CANC_EPS_TestCase21.py",
    "CANC_EPS_TestCase22.py",
    "CANC_EPS_TestCase23.py",
    "CANC_EPS_TestCase24.py",
    # FR_ZONE_Node_TestCases.xlsx (50)
    "CANC_FR_ZONE_TestCase_1.py",
    "CANC_FR_ZONE_TestCase_2.py",
    "CANC_FR_ZONE_TestCase_3.py",
    "CANC_FR_ZONE_TestCase_4.py",
    "CANC_FR_ZONE_TestCase_5.py",
    "CANC_FR_ZONE_TestCase_6.py",
    "CANC_FR_ZONE_TestCase_7.py",
    "CANC_FR_ZONE_TestCase_8.py",
    "CANC_FR_ZONE_TestCase_9.py",
    "CANC_FR_ZONE_TestCase_10.py",
    "CANC_FR_ZONE_TestCase_11.py",
    "CANC_FR_ZONE_TestCase_12.py",
    "CANC_FR_ZONE_TestCase_13.py",
    "CANC_FR_ZONE_TestCase_14.py",
    "CANC_FR_ZONE_TestCase_15.py",
    "CANC_FR_ZONE_TestCase_16.py",
    "CANC_FR_ZONE_TestCase_17.py",
    "CANC_FR_ZONE_TestCase_18.py",
    "CANC_FR_ZONE_TestCase_19.py",
    "CANC_FR_ZONE_TestCase_20.py",
    "CANC_FR_ZONE_TestCase_21.py",
    "CANC_FR_ZONE_TestCase_22.py",
    "CANC_FR_ZONE_TestCase_23.py",
    "CANC_FR_ZONE_TestCase_24.py",
    "CANC_FR_ZONE_TestCase_25.py",
    "CANC_FR_ZONE_TestCase_26.py",
    "CANC_FR_ZONE_TestCase_27.py",
    "CANC_FR_ZONE_TestCase_28.py",
    "CANC_FR_ZONE_TestCase_29.py",
    "CANC_FR_ZONE_TestCase_30.py",
    "CANC_FR_ZONE_TestCase_31.py",
    "CANC_FR_ZONE_TestCase_32.py",
    "CANC_FR_ZONE_TestCase_33.py",
    "CANC_FR_ZONE_TestCase_34.py",
    "CANC_FR_ZONE_TestCase_35.py",
    "CANC_FR_ZONE_TestCase_36.py",
    "CANC_FR_ZONE_TestCase_37.py",
    "CANC_FR_ZONE_TestCase_38.py",
    "CANC_FR_ZONE_TestCase_39.py",
    "CANC_FR_ZONE_TestCase_40.py",
    "CANC_FR_ZONE_TestCase_41.py",
    "CANC_FR_ZONE_TestCase_42.py",
    "CANC_FR_ZONE_TestCase_43.py",
    "CANC_FR_ZONE_TestCase_44.py",
    "CANC_FR_ZONE_TestCase_45.py",
    "CANC_FR_ZONE_TestCase_46.py",
    "CANC_FR_ZONE_TestCase_47.py",
    "CANC_FR_ZONE_TestCase_48.py",
    "CANC_FR_ZONE_TestCase_49.py",
    "CANC_FR_ZONE_TestCase_50.py",
    # HPCAD_Node_TestCases.xlsx (72)
    "CANC_HPCAd_TestCase_1.py",
    "CANC_HPCAd_TestCase_2.py",
    "CANC_HPCAd_TestCase_3.py",
    "CANC_HPCAd_TestCase_4.py",
    "CANC_HPCAd_TestCase_5.py",
    "CANC_HPCAd_TestCase_6.py",
    "CANC_HPCAd_TestCase_7.py",
    "CANC_HPCAd_TestCase_8.py",
    "CANC_HPCAd_TestCase_9.py",
    "CANC_HPCAd_TestCase_10.py",
    "CANC_HPCAd_TestCase_11.py",
    "CANC_HPCAd_TestCase_12.py",
    "CANC_HPCAd_TestCase_13.py",
    "CANC_HPCAd_TestCase_14.py",
    "CANC_HPCAd_TestCase_15.py",
    "CANC_HPCAd_TestCase_16.py",
    "CANC_HPCAd_TestCase_17.py",
    "CANC_HPCAd_TestCase_18.py",
    "CANC_HPCAd_TestCase_19.py",
    "CANC_HPCAd_TestCase_20.py",
    "CANC_HPCAd_TestCase_21.py",
    "CANC_HPCAd_TestCase_22.py",
    "CANC_HPCAd_TestCase_23.py",
    "CANC_HPCAd_TestCase_24.py",
    "CANC_HPCAd_TestCase_25.py",
    "CANC_HPCAd_TestCase_26.py",
    "CANC_HPCAd_TestCase_27.py",
    "CANC_HPCAd_TestCase_28.py",
    "CANC_HPCAd_TestCase_29.py",
    "CANC_HPCAd_TestCase_30.py",
    "CANC_HPCAd_TestCase_31.py",
    "CANC_HPCAd_TestCase_32.py",
    "CANC_HPCAd_TestCase_33.py",
    "CANC_HPCAd_TestCase_34.py",
    "CANC_HPCAd_TestCase_35.py",
    "CANC_HPCAd_TestCase_36.py",
    "CANC_HPCAd_TestCase_37.py",
    "CANC_HPCAd_TestCase_38.py",
    "CANC_HPCAd_TestCase_39.py",
    "CANC_HPCAd_TestCase_40.py",
    "CANC_HPCAd_TestCase_41.py",
    "CANC_HPCAd_TestCase_42.py",
    "CANC_HPCAd_TestCase_43.py",
    "CANC_HPCAd_TestCase_44.py",
    "CANC_HPCAd_TestCase_45.py",
    "CANC_HPCAd_TestCase_46.py",
    "CANC_HPCAd_TestCase_47.py",
    "CANC_HPCAd_TestCase_48.py",
    "CANC_HPCAd_TestCase_49.py",
    "CANC_HPCAd_TestCase_50.py",
    "CANC_HPCAd_TestCase_51.py",
    "CANC_HPCAd_TestCase_52.py",
    "CANC_HPCAd_TestCase_53.py",
    "CANC_HPCAd_TestCase_54.py",
    "CANC_HPCAd_TestCase_55.py",
    "CANC_HPCAd_TestCase_56.py",
    "CANC_HPCAd_TestCase_57.py",
    "CANC_HPCAd_TestCase_58.py",
    "CANC_HPCAd_TestCase_59.py",
    "CANC_HPCAd_TestCase_60.py",
    "CANC_HPCAd_TestCase_61.py",
    "CANC_HPCAd_TestCase_62.py",
    "CANC_HPCAd_TestCase_63.py",
    "CANC_HPCAd_TestCase_64.py",
    "CANC_HPCAd_TestCase_65.py",
    "CANC_HPCAd_TestCase_66.py",
    "CANC_HPCAd_TestCase_67.py",
    "CANC_HPCAd_TestCase_68.py",
    "CANC_HPCAd_TestCase_69.py",
    "CANC_HPCAd_TestCase_70.py",
    "CANC_HPCAd_TestCase_71.py",
    "CANC_HPCAd_TestCase_72.py",
    # HPCC_Node_TestCases.xlsx (24)
    "CANC_HPCC_TestCase_1.py",
    "CANC_HPCC_TestCase_2.py",
    "CANC_HPCC_TestCase_3.py",
    "CANC_HPCC_TestCase_4.py",
    "CANC_HPCC_TestCase_5.py",
    "CANC_HPCC_TestCase_6.py",
    "CANC_HPCC_TestCase_7.py",
    "CANC_HPCC_TestCase_8.py",
    "CANC_HPCC_TestCase_9.py",
    "CANC_HPCC_TestCase_10.py",
    "CANC_HPCC_TestCase_11.py",
    "CANC_HPCC_TestCase_12.py",
    "CANC_HPCC_TestCase_13.py",
    "CANC_HPCC_TestCase_14.py",
    "CANC_HPCC_TestCase_15.py",
    "CANC_HPCC_TestCase_16.py",
    "CANC_HPCC_TestCase_17.py",
    "CANC_HPCC_TestCase_18.py",
    "CANC_HPCC_TestCase_19.py",
    "CANC_HPCC_TestCase_20.py",
    "CANC_HPCC_TestCase_21.py",
    "CANC_HPCC_TestCase_22.py",
    "CANC_HPCC_TestCase_23.py",
    "CANC_HPCC_TestCase_24.py",
    # IEB_Node_TestCases.xlsx (25)
    "CANC_IEB_TestCase1.py",
    "CANC_IEB_TestCase2.py",
    "CANC_IEB_TestCase3.py",
    "CANC_IEB_TestCase4.py",
    "CANC_IEB_TestCase5.py",
    "CANC_IEB_TestCase6.py",
    "CANC_IEB_TestCase7.py",
    "CANC_IEB_TestCase8.py",
    "CANC_IEB_TestCase9.py",
    "CANC_IEB_TestCase10.py",
    "CANC_IEB_TestCase11.py",
    "CANC_IEB_TestCase12.py",
    "CANC_IEB_TestCase13.py",
    "CANC_IEB_TestCase14.py",
    "CANC_IEB_TestCase15.py",
    "CANC_IEB_TestCase16.py",
    "CANC_IEB_TestCase17.py",
    "CANC_IEB_TestCase18.py",
    "CANC_IEB_TestCase19.py",
    "CANC_IEB_TestCase20.py",
    "CANC_IEB_TestCase21.py",
    "CANC_IEB_TestCase22.py",
    "CANC_IEB_TestCase23.py",
    "CANC_IEB_TestCase24.py",
    "CANC_IEB_TestCase25.py",
    # M314 CANC 13C signal and message spec test cases.xlsx (101)
    "CANC_13C_TestCase_13.py",
    "CANC_13C_TestCase_14.py",
    "CANC_13C_TestCase_15.py",
    "CANC_13C_TestCase_16.py",
    "CANC_13C_TestCase_17.py",
    "CANC_13C_TestCase_18.py",
    "CANC_13C_TestCase_19.py",
    "CANC_13C_TestCase_28.py",
    "CANC_13C_TestCase_30.py",
    "CANC_13C_TestCase_31.py",
    "CANC_13C_TestCase_32.py",
    "CANC_13C_TestCase_33.py",
    "CANC_13C_TestCase_34.py",
    "CANC_13C_TestCase_35.py",
    "CANC_13C_TestCase_36.py",
    "CANC_13C_TestCase_37.py",
    "CANC_13C_TestCase_38.py",
    "CANC_13C_TestCase_39.py",
    "CANC_13C_TestCase_40.py",
    "CANC_13C_TestCase_41.py",
    "CANC_13C_TestCase_42.py",
    "CANC_13C_TestCase_43.py",
    "CANC_13C_TestCase_44.py",
    "CANC_13C_TestCase_46.py",
    "CANC_13C_TestCase_47.py",
    "CANC_13C_TestCase_48.py",
    "CANC_13C_TestCase_49.py",
    "CANC_13C_TestCase_50.py",
    "CANC_13C_TestCase_51.py",
    "CANC_13C_TestCase_52.py",
    "CANC_13C_TestCase_53.py",
    "CANC_13C_TestCase_54.py",
    "CANC_13C_TestCase_55.py",
    "CANC_13C_TestCase_56.py",
    "CANC_13C_TestCase_57.py",
    "CANC_13C_TestCase_58.py",
    "CANC_13C_TestCase_62.py",
    "CANC_13C_TestCase_63.py",
    "CANC_13C_TestCase_64.py",
    "CANC_13C_TestCase_65.py",
    "CANC_13C_TestCase_66.py",
    "CANC_13C_TestCase_67.py",
    "CANC_13C_TestCase_68.py",
    "CANC_13C_TestCase_69.py",
    "CANC_13C_TestCase_70.py",
    "CANC_13C_TestCase_71.py",
    "CANC_13C_TestCase_72.py",
    "CANC_13C_TestCase_73.py",
    "CANC_13C_TestCase_74.py",
    "CANC_13C_TestCase_75.py",
    "CANC_13C_TestCase_76.py",
    "CANC_13C_TestCase_77.py",
    "CANC_13C_TestCase_78.py",
    "CANC_13C_TestCase_79.py",
    "CANC_13C_TestCase_80.py",
    "CANC_13C_TestCase_81.py",
    "CANC_13C_TestCase_82.py",
    "CANC_13C_TestCase_83.py",
    "CANC_13C_TestCase_84.py",
    "CANC_13C_TestCase_85.py",
    "CANC_13C_TestCase_86.py",
    "CANC_13C_TestCase_87.py",
    "CANC_13C_TestCase_88.py",
    "CANC_13C_TestCase_89.py",
    "CANC_13C_TestCase_90.py",
    "CANC_13C_TestCase_94.py",
    "CANC_13C_TestCase_95.py",
    "CANC_13C_TestCase_96.py",
    "CANC_13C_TestCase_97.py",
    "CANC_13C_TestCase_98.py",
    "CANC_13C_TestCase_100.py",
    "CANC_13C_TestCase_101.py",
    "CANC_13C_TestCase_102.py",
    "CANC_13C_TestCase_103.py",
    "CANC_13C_TestCase_104.py",
    "CANC_13C_TestCase_105.py",
    "CANC_13C_TestCase_106.py",
    "CANC_13C_TestCase_107.py",
    "CANC_13C_TestCase_108.py",
    "CANC_13C_TestCase_109.py",
    "CANC_13C_TestCase_110.py",
    "CANC_13C_TestCase_111.py",
    "CANC_13C_TestCase_112.py",
    "CANC_13C_TestCase_113.py",
    "CANC_13C_TestCase_114.py",
    "CANC_13C_TestCase_115.py",
    "CANC_13C_TestCase_116.py",
    "CANC_13C_TestCase_117.py",
    "CANC_13C_TestCase_118.py",
    "CANC_13C_TestCase_119.py",
    "CANC_13C_TestCase_120.py",
    "CANC_13C_TestCase_121.py",
    "CANC_13C_TestCase_122.py",
    "CANC_13C_TestCase_123.py",
    "CANC_13C_TestCase_124.py",
    "CANC_13C_TestCase_125.py",
    "CANC_13C_TestCase_126.py",
    "CANC_13C_TestCase_127.py",
    "CANC_13C_TestCase_128.py",
    "CANC_13C_TestCase_129.py",
    "CANC_13C_TestCase_130.py",
    # M314 CANC 2C0 signal and message spec test cases.xlsx (28)
    "CANC_2C0_TestCase_01.py",
    "CANC_2C0_TestCase_03.py",
    "CANC_2C0_TestCase_04.py",
    "CANC_2C0_TestCase_05.py",
    "CANC_2C0_TestCase_06.py",
    "CANC_2C0_TestCase_07.py",
    "CANC_2C0_TestCase_08.py",
    "CANC_2C0_TestCase_09.py",
    "CANC_2C0_TestCase_10.py",
    "CANC_2C0_TestCase_13.py",
    "CANC_2C0_TestCase_14.py",
    "CANC_2C0_TestCase_15.py",
    "CANC_2C0_TestCase_16.py",
    "CANC_2C0_TestCase_17.py",
    "CANC_2C0_TestCase_18.py",
    "CANC_2C0_TestCase_19.py",
    "CANC_2C0_TestCase_20.py",
    "CANC_2C0_TestCase_22.py",
    "CANC_2C0_TestCase_23.py",
    "CANC_2C0_TestCase_24.py",
    "CANC_2C0_TestCase_25.py",
    "CANC_2C0_TestCase_26.py",
    "CANC_2C0_TestCase_27.py",
    "CANC_2C0_TestCase_28.py",
    "CANC_2C0_TestCase_29.py",
    "CANC_2C0_TestCase_32.py",
    "CANC_2C0_TestCase_33.py",
    "CANC_2C0_TestCase_34.py",
    # VCU_Node_TestCases.xlsx (68)
    "CANC_VCU_TestCase1.py",
    "CANC_VCU_TestCase2.py",
    "CANC_VCU_TestCase3.py",
    "CANC_VCU_TestCase4.py",
    "CANC_VCU_TestCase5.py",
    "CANC_VCU_TestCase6.py",
    "CANC_VCU_TestCase7.py",
    "CANC_VCU_TestCase8.py",
    "CANC_VCU_TestCase9.py",
    "CANC_VCU_TestCase10.py",
    "CANC_VCU_TestCase11.py",
    "CANC_VCU_TestCase12.py",
    "CANC_VCU_TestCase13.py",
    "CANC_VCU_TestCase14.py",
    "CANC_VCU_TestCase15.py",
    "CANC_VCU_TestCase16.py",
    "CANC_VCU_TestCase17.py",
    "CANC_VCU_TestCase18.py",
    "CANC_VCU_TestCase19.py",
    "CANC_VCU_TestCase20.py",
    "CANC_VCU_TestCase21.py",
    "CANC_VCU_TestCase22.py",
    "CANC_VCU_TestCase23.py",
    "CANC_VCU_TestCase24.py",
    "CANC_VCU_TestCase25.py",
    "CANC_VCU_TestCase26.py",
    "CANC_VCU_TestCase27.py",
    "CANC_VCU_TestCase28.py",
    "CANC_VCU_TestCase29.py",
    "CANC_VCU_TestCase30.py",
    "CANC_VCU_TestCase31.py",
    "CANC_VCU_TestCase32.py",
    "CANC_VCU_TestCase33.py",
    "CANC_VCU_TestCase34.py",
    "CANC_VCU_TestCase35.py",
    "CANC_VCU_TestCase36.py",
    "CANC_VCU_TestCase37.py",
    "CANC_VCU_TestCase38.py",
    "CANC_VCU_TestCase39.py",
    "CANC_VCU_TestCase40.py",
    "CANC_VCU_TestCase41.py",
    "CANC_VCU_TestCase42.py",
    "CANC_VCU_TestCase43.py",
    "CANC_VCU_TestCase44.py",
    "CANC_VCU_TestCase45.py",
    "CANC_VCU_TestCase46.py",
    "CANC_VCU_TestCase47.py",
    "CANC_VCU_TestCase48.py",
    "CANC_VCU_TestCase49.py",
    "CANC_VCU_TestCase50.py",
    "CANC_VCU_TestCase51.py",
    "CANC_VCU_TestCase52.py",
    "CANC_VCU_TestCase53.py",
    "CANC_VCU_TestCase54.py",
    "CANC_VCU_TestCase56.py",
    "CANC_VCU_TestCase57.py",
    "CANC_VCU_TestCase60.py",
    "CANC_VCU_TestCase61.py",
    "CANC_VCU_TestCase62.py",
    "CANC_VCU_TestCase63.py",
    "CANC_VCU_TestCase64.py",
    "CANC_VCU_TestCase65.py",
    "CANC_VCU_TestCase66.py",
    "CANC_VCU_TestCase67.py",
    "CANC_VCU_TestCase68.py",
    "CANC_VCU_TestCase69.py",
    "CANC_VCU_TestCase70.py",
    "CANC_VCU_TestCase71.py",
]


def finish_selection(arguments, selected, missing):
    if missing:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for name in missing:
            print("- " + name)
        print()
    if arguments.start_from:
        names = [path.stem for path in selected]
        start = arguments.start_from.removesuffix(".py")
        if start not in names:
            print("--start-from " + arguments.start_from + " is not one of the selected scripts.")
            return None
        selected = selected[names.index(start):]
    return selected


def build_environment():
    env = os.environ.copy()
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(FRAMEWORK_ROOT.parent) + (os.pathsep + existing if existing else "")
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def read_report(path, started):
    """The report this run of the script wrote, the verdict apym put on its last
    line and the passed/total step count beside it."""
    report_name = re.compile(re.escape(path.stem) + r"_\d{8}_\d{6}\.html")
    reports = [report for report in REPORT_DIR.glob("*/" + path.stem + "_*.html")
               if report_name.fullmatch(report.name) and report.stat().st_mtime >= started - 2]
    if not reports:
        return None, None, None
    report = max(reports, key=os.path.getmtime)
    with open(report, "rb") as handle:
        handle.seek(0, os.SEEK_END)
        handle.seek(max(0, handle.tell() - 512))
        tail = handle.read().decode("utf-8", "replace")
    verdict = re.search(r"<!--(PASSED|FAILED)-->\s*$", tail)
    steps = re.search(r'id="successStepsCount">(\d+/\d+)<', tail)
    return report, verdict.group(1) if verdict else None, steps.group(1) if steps else None


def run_script(path, env):
    """Run one script in its own Python process and show its output as it comes,
    so an operator instruction appears the moment the script prints it."""
    started = time.time()
    process = subprocess.Popen([sys.executable, "-u", str(path)], cwd=str(SCRIPT_DIR), env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               encoding="utf-8", errors="replace")
    output, interrupted = [], False
    while True:
        try:
            for line in process.stdout:
                print(line, end="", flush=True)
                output.append(line)
            exit_code = process.wait()
            break
        except KeyboardInterrupt:
            # The script gets the same Ctrl+C and runs its own cleanup; keep reading
            # until it ends so that cleanup is not cut off.
            interrupted = True
            print("\nCtrl+C: stopping once " + path.name + " has cleaned up.", flush=True)
    report, verdict, steps = read_report(path, started)
    if interrupted:
        status = "INTERRUPTED"
    elif verdict and exit_code == 0:
        status = verdict
    else:
        status = "ERROR"
    result = {"status": status, "exit_code": exit_code, "steps_passed": steps,
              "minutes": round((time.time() - started) / 60, 1), "report": str(report) if report else None}
    if status != "PASSED":
        result["output_tail"] = [line.rstrip("\n") for line in output[-40:]]
    print(status + ": " + path.name + " (" + (steps + " steps passed" if steps else "no verdict") + ", "
          + str(result["minutes"]) + " min)")
    if report:
        print("Report: " + str(report))
    return result


def save_results(run):
    run["finished"] = datetime.now().isoformat(timespec="seconds")
    RESULTS_FILE.write_text(json.dumps(run, indent=2), encoding="utf-8")


def print_summary(run):
    results = run["results"]
    counts = {}
    for result in results.values():
        counts[result["status"]] = counts.get(result["status"], 0) + 1
    print("=" * 100)
    print("Ran " + str(len(results)) + " script(s): "
          + (", ".join(str(count) + " " + status for status, count in sorted(counts.items())) or "none"))
    for name, result in results.items():
        if result["status"] != "PASSED":
            print("  " + result["status"].ljust(11) + " " + name
                  + ("  " + result["report"] if result.get("report") else ""))
    print("Results written to " + str(RESULTS_FILE))


def select_scripts(arguments):
    selected, missing = [], []
    for name in SCRIPT_FILES:
        if arguments.only and arguments.only.lower() not in name.lower():
            continue
        path = SCRIPT_DIR / name
        if path.is_file():
            selected.append(path)
        else:
            missing.append(name)
    return finish_selection(arguments, selected, missing)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--only", help="run the scripts whose name contains this text")
    parser.add_argument("--start-from", help="skip the selected scripts before this one, to resume a run")
    parser.add_argument("--stop-on-fail", action="store_true", help="stop at the first script that does not pass")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    scripts = select_scripts(arguments)
    if scripts is None:
        return 2
    if arguments.list:
        for path in scripts:
            print(path.name)
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    env = build_environment()
    run = {"runner": Path(__file__).name, "started": datetime.now().isoformat(timespec="seconds"), "results": {}}
    try:
        for index, path in enumerate(scripts, 1):
            print("=" * 100)
            print("[" + str(index) + "/" + str(len(scripts)) + "] " + path.name)
            print("=" * 100)
            result = run_script(path, env)
            run["results"][path.name] = result
            save_results(run)
            if result["status"] == "INTERRUPTED" or (arguments.stop_on_fail and result["status"] != "PASSED"):
                break
    except KeyboardInterrupt:
        print("\nStopped.")
    save_results(run)
    print_summary(run)
    results = run["results"].values()
    return 0 if results and all(result["status"] == "PASSED" for result in results) else 1


if __name__ == "__main__":
    sys.exit(main())
