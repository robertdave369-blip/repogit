# Author: Kris
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_canc_scripts.py
#
# Test case  : CANC_13C_TestCase_134 (Codebeamer ID 36767373)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify IMU signal behavior in other scenarios
# Automation : Semi-automatic (operator forces low-power mode)

import os
import sys
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_BELT_CHANNEL,
    CANC_DCS_FAULT_LOAD,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_MANUAL_ACTION_WINDOW_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    DCS_fault_time,
    SLSNumber,
)


def run_test():
    tc_id = '36767373'
    tc_name = 'CANC_13C_TestCase_134'
    tc_desc = (
        'Verify IMU signal behavior in other scenarios'
    )
    automation = 'Semi-automatic (operator forces low-power mode)'

    dcs_fault_ms = int(DCS_fault_time['Qualification'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
    dcs_heal_ms = int(DCS_fault_time['Dequalification'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    dcs_cc_ms = int(DCS_fault_time['Qualification_CC'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
    dcs_cc_heal_ms = int(DCS_fault_time['Dequalification_CC'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    drv_key = 'STS_SEAT_BLT_DRV'
    drv_states = MAH_CAN_SIGNAL_DEFS[drv_key]['State_Values']
    drv_unbuckled = next(value for label, value in drv_states.items() if label.startswith('Not Buckled'))
    drv_buckled = drv_states['Buckled']
    drv_faulty = drv_states['Buckle Faulty']
    drv_reserved = drv_states['Reserved']
    drv_channel = SLSNumber[CANC_BELT_CHANNEL[drv_key]]
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_read = CAN.ReadFromCanLogFile(presence2_file)
        presence2_frames = [
            frame for frame in (presence2_read[1] if presence2_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Normal mode - IMU values valid')
        normal_ids = [fd_id]
        normal_file = os.path.splitext(log_path)[0] + '_imu_normal.txt'
        normal_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_normal', filepath=normal_file,
            listOption=normal_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(normal_logger)
        normal_read = CAN.ReadFromCanLogFile(normal_file)
        normal_frames = [
            frame for frame in (normal_read[1] if normal_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in normal_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in normal_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} valid in normal mode",
                                        bool(imu_raw) and all(value != imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Force low-power mode')
        RESULT.InsertComment('OPERATOR ACTION: Force the ECU into low-power mode (while SRS1_FD_10 is still transmitted).')
        print('OPERATOR ACTION: Force the ECU into low-power mode (while SRS1_FD_10 is still transmitted).')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        low_power_ids = [fd_id]
        low_power_file = os.path.splitext(log_path)[0] + '_imu_low_power.txt'
        low_power_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_low_power', filepath=low_power_file,
            listOption=low_power_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(low_power_logger)
        low_power_read = CAN.ReadFromCanLogFile(low_power_file)
        low_power_frames = [
            frame for frame in (low_power_read[1] if low_power_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in low_power_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in low_power_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} valid in low-power mode",
                                        bool(imu_raw) and all(value != imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        RESULT.InsertComment('OPERATOR ACTION: Return the ECU to normal mode.')
        print('OPERATOR ACTION: Return the ECU to normal mode.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Create a short-to-battery fault on the driver belt (system critical fault)')
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, drv_channel)
        PS.SetLeakageVBATBusHigh()
        Wait(dcs_fault_ms)
        RESULT.LogAction("DTCs with the belt short to battery", CAN.SendDiagByValues(Read_DTC_Req_CANC))
        critical_ids = [fd_id]
        critical_file = os.path.splitext(log_path)[0] + '_imu_critical.txt'
        critical_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_critical', filepath=critical_file,
            listOption=critical_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(critical_logger)
        critical_read = CAN.ReadFromCanLogFile(critical_file)
        critical_frames = [
            frame for frame in (critical_read[1] if critical_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in critical_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in critical_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} transmitted as the invalid value under the system critical fault",
                                        bool(imu_raw) and all(value == imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Clear the fault and return to normal mode')
        PS.ClearLeakageVBATBusHigh()
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], drv_channel)
        Wait(dcs_heal_ms)
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        cleared_ids = [fd_id]
        cleared_file = os.path.splitext(log_path)[0] + '_imu_cleared.txt'
        cleared_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_cleared', filepath=cleared_file,
            listOption=cleared_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(cleared_logger)
        cleared_read = CAN.ReadFromCanLogFile(cleared_file)
        cleared_frames = [
            frame for frame in (cleared_read[1] if cleared_read[0] == "0000" else [])
            if getattr(frame, 'id', None) in cleared_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in cleared_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} valid again after the fault is cleared",
                                        bool(imu_raw) and all(value != imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.ClearLeakageVBATBusHigh()
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], drv_channel)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
