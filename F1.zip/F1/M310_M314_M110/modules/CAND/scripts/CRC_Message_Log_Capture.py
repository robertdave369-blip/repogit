# Author: Christy

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()


LOG_DURATION_SECONDS = 10
PROJECT_NAME = "M310_M314_M110"
CRC_LOG_TARGETS = [
    ("IEB1_FD_10", "IEB1_CRC", 0x13B),
    ("HPCA4_d_10", "HPCA_4_CRC", 0x14C),
    ("HPCAd_1_10", "HPCA_1_CRC", 0x13E),
    ("EPS1_FD_10", "EPS1_CRC", 0x13A),
    ("VCU11_FD_10", "VCU11FD_CRC", 0x16E),
    ("SRS1_FD_10", "SRS_CRC", 0x13C),
    ("VCU1_FD_20", "VCU1FD_CRC", 0x207),
    ("HPCAd_3_50", "HPCA_3_CRC", 0x2B1),
    ("HPCAd_2_50", "HPCA_2_CRC", 0x2AF),
    ("SRS1_20", "SRSHS_CRC", 0x2C0),
    ("FR_ZONE2_100", "FR_ZONE2_CRC", 0x319),
    ("FR_ZONE3_100", "FR_ZONE3_CRC", 0x31A),
    ("HPCC_1_100", "HPCC_1_CRC", 0x318),
    ("VCU2_FD_100", "VCU2FD_CRC", 0x30E),
]


def run_test():
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    results_dir = _FRAMEWORK_ROOT / "test_results" / PROJECT_NAME
    logs_dir = results_dir / "Log"
    results_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)

    options_class = get_reports_options(strict=False)
    if options_class is not None:
        options = options_class()
        options.direct_write = False
        aria_reports.create(str(results_dir / f"{test_case_file}.html"), test_case_file, options)
        try:
            aria_reports.add_report_info("#Log Duration (seconds):", str(LOG_DURATION_SECONDS))
        except Exception:
            pass

    for message_name, crc_signal_name, can_id in CRC_LOG_TARGETS:
        log_path = logs_dir / f"{crc_signal_name}.txt"
        RESULT.InsertComment(f"Start logging {message_name} ({hex(can_id)}) into {log_path.name}")
        log_handle = StartLoggingToFile(crc_signal_name, str(log_path), [can_id])
        Sleep(LOG_DURATION_SECONDS)
        if isinstance(log_handle, str):
            RESULT.LogAction(
                f"Start logging {crc_signal_name}",
                f"message={message_name}, can_id=0x{can_id:03X}, handle={log_handle}",
            )
        else:
            try:
                stop_result = log_handle.stop()
                RESULT.LogAction(
                    f"Stop logging {crc_signal_name}",
                    f"message={message_name}, can_id=0x{can_id:03X}, result={stop_result}",
                )
            except Exception as ex:
                RESULT.LogAction(
                    f"Stop logging {crc_signal_name}",
                    f"message={message_name}, can_id=0x{can_id:03X}, error={ex}",
                )

    if options_class is not None:
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()