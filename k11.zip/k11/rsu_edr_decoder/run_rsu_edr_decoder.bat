@echo off
py -3 "%~dp0rsu_edr_decoder.py" %*
if errorlevel 1 pause
