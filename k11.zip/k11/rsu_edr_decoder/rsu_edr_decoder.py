# Author: Kris
#
# RSU / central sensor EDR decoder (standalone: needs numpy and xlsxwriter only).
# Decodes the EDR sensor DIDs and the two event records from any log (CAN trace, txt, ARIA log,
# html, xml), identifies the LSB curve of every sensor in the input-curve folder, and checks the
# recording against the curve: magnitude, polarity and the central delta-V of each record.
# Writes an Excel workbook (summary, data, graphs) and a folder of decoded LSB curves.
#
#   py -3 rsu_edr_decoder.py                      window (asks for the log and the curve folder)
#   py -3 rsu_edr_decoder.py --log run.txt --curves <folder> --crash front
#   py -3 rsu_edr_decoder.py --self-test
#
# Everything project specific (sampling rate, applicable sensors, DIDs, conversion, record layout)
# is in projects/<project>/profile.json; the polarity expectation is AUTOSAR unless a polarity
# JSON is loaded. See README.md.

import argparse
import html
import json
import os
import re
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
PROJECTS_DIR = HERE / "projects"
DEFAULT_PROJECT = "m210"
RULES = ("+", "-", "curve", "inverted", "any")
# AUTOSAR vehicle axis (+X forward, +Y left) at the ECU input: the sign of the main pulse per crash
# type. An axis the crash type does not govern is "any": recorded and reported, not judged.
AUTOSAR = {"front": {"X": "-"}, "rear": {"X": "+"}, "left": {"Y": "-"}, "right": {"Y": "+"}}
# Delta-V is REPORTED in the NHTSA 49 CFR Part 563 (SAE J211) convention, not in the AUTOSAR sensor
# axis: longitudinal positive forward (a frontal crash gives a negative delta-V), lateral positive
# from left to right (a crash into the left side pushes the vehicle to the right: positive).
NHTSA_DELTA_V = {"front": {"Longitudinal": "-"}, "rear": {"Longitudinal": "+"},
                 "left": {"Lateral": "+"}, "right": {"Lateral": "-"}}
KMH_PER_G_MS = 9.80665 * 3.6 / 1000.0
HEXB = r"[0-9A-Fa-f]{2}"
GAP = r"[ \t]+"


def load_profile(project=None):
    """project: a folder name under projects/ (m210, u171, ..) or the path of a profile JSON."""
    path = Path(project or DEFAULT_PROJECT)
    if path.suffix.lower() != ".json":
        path = PROJECTS_DIR / str(path).lower() / "profile.json"
    if not path.is_file():
        raise ValueError(f"No profile {path}. Projects: {', '.join(project_names())}")
    profile = json.loads(path.read_text(encoding="utf-8"))
    if profile.get("blocked"):
        raise ValueError(f"{path}: {profile['blocked']}")
    if abs(stride(profile) * curve_ms(profile) - profile["sample_ms"]) > 1e-9:
        raise ValueError(f"{path}: sample_ms must be a whole multiple of curve_ms")
    return profile, path


def project_names():
    return sorted(d.name for d in PROJECTS_DIR.iterdir() if (d / "profile.json").is_file())


def curve_ms(P):
    """Time step of the input curves (2k files: 0.5 ms); every curve is brought onto this grid."""
    return P.get("curve_ms", P["sample_ms"])


def stride(P):
    """Curve samples per EDR sample: 1 for a 0.5 ms project, 4 for a 2 ms project."""
    return max(1, round(P["sample_ms"] / curve_ms(P)))


# ----------------------------------------------------------------------------------------------
# 1. Log decoding: DID responses out of any log
# ----------------------------------------------------------------------------------------------
def read_text(path):
    raw = Path(path).read_bytes()
    return raw.decode("utf-16" if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else "utf-8", "ignore")


def isotp_responses(text, dids):
    """CAN trace, one frame per line: reassemble the ISO 15765-2 multi-frame responses 62 <DID>.
    The frame's CAN id is 'id=<hex>' (ARIA) or the last 3-8 digit hex field before the data
    (Vector asc, PCAN trc)."""
    did_alt = "|".join(f"{d[:2]}{GAP}{d[2:]}" for d in dids)
    first = re.compile(rf"(?<![\w=.])(?:1([0-9A-Fa-f]){GAP}({HEXB})|10{GAP}00((?:{GAP}{HEXB}){{4}}))"
                       rf"{GAP}62{GAP}(?:{did_alt})(?!\w)", re.I)
    frame = re.compile(rf"{HEXB}(?:{GAP}{HEXB}(?![\w.]))*")
    found = []
    for m in first.finditer(text):
        line_start = text.rfind("\n", 0, m.start()) + 1
        line_end = text.find("\n", m.end())
        line_end = len(text) if line_end < 0 else line_end
        prefix = text[line_start:m.start()]
        if m.group(3):    # 32-bit length (messages over 4095 bytes)
            total, header = int(re.sub(r"\s", "", m.group(3)), 16), 6
        else:
            total, header = int(m.group(1) + m.group(2), 16), 2
        payload = bytearray(bytes.fromhex(re.sub(r"\s", "", frame.match(text, m.start(), line_end).group(0)))[header:])
        can_id = re.search(r"id\s*[=:]\s*(?:0x)?([0-9A-Fa-f]+)", prefix, re.I)
        if can_id:
            key = re.compile(r"id\s*[=:]\s*(?:0x)?" + can_id.group(1) + r"(?![0-9A-Fa-f])", re.I)
        else:
            fields = re.findall(r"(?<![\w.:])[0-9A-Fa-f]{3,8}x?(?![\w.:])", prefix)
            if not fields:
                continue
            key = re.compile(r"(?<![\w.:])" + fields[-1] + r"(?![\w.:])")
        position, number, lines = line_end + 1, 1, 0
        # shortcut: a response is given up 5000 lines after its first frame, raise it for a busier bus
        while len(payload) < total and position < len(text) and lines < 5000:
            end = text.find("\n", position)
            end = len(text) if end < 0 else end
            line, position, lines = text[position:end], end + 1, lines + 1
            same = key.search(line)
            if not same:
                continue
            # shortcut: an asc CAN FD frame of length 20 or 24 could be read as sequence number 0 / 4
            consecutive = re.search(rf"(?<![\w=.])2{number:X}((?:{GAP}{HEXB}(?![\w.]))+)", line[same.end():], re.I)
            if consecutive:
                payload += bytes.fromhex(re.sub(r"\s", "", consecutive.group(1)))
                number = (number + 1) & 0xF
        if len(payload) >= total and payload[0] == 0x62:
            found.append((payload[1:3].hex().upper(), bytes(payload[3:total])))
    return found


def text_responses(text, lengths):
    """Responses printed as text: '62 04 60 7F ..', '0x62, 0x04, ..' or '6204607F..'.
    lengths: DID -> data bytes of the response (None = to the end of the run of bytes)."""
    runs = re.compile(rf"(?<![0-9A-Za-z])(?:0x)?{HEXB}(?:[\s,;:|\-]+(?:0x)?{HEXB}){{15,}}(?![0-9A-Za-z])"
                      rf"|(?<![0-9A-Za-z])(?:0x)?(?:{HEXB}){{16,}}(?![0-9A-Za-z])")
    heads = re.compile(b"\x62(?:" + b"|".join(re.escape(bytes.fromhex(d)) for d in lengths) + b")")
    found = []
    for run in runs.finditer(text):
        data = bytes.fromhex(re.sub(r"0[xX]|[^0-9A-Fa-f]", "", run.group(0)))
        position = 0
        while True:
            m = heads.search(data, position)
            if not m:
                break
            did = data[m.start() + 1:m.end()].hex().upper()
            body = data[m.end():m.end() + lengths[did]] if lengths[did] else data[m.end():]
            found.append((did, body))
            position = m.end() + len(body)    # the bytes of a response are never searched for a header
    return found


def decode_logs(paths, wanted, pick="last"):
    """wanted: DID -> (label, exact data bytes or None, least data bytes). Returns the chosen
    response per DID and one report row per wanted DID."""
    lengths = {did: exact for did, (label, exact, least) in wanted.items()}
    seen = {did: [] for did in wanted}
    for path in paths:
        text = read_text(path)
        items, how = isotp_responses(text, list(wanted)), "CAN trace (ISO-TP)"
        if not items:
            how = "text"
            items = text_responses(text, lengths)
            if "<" in text:    # html / xml: bytes split over tags (cells), entities
                items += text_responses(html.unescape(re.sub(r"<[^>]*>", " ", text)), lengths)
        for did, body in items:
            if did in seen:
                seen[did].append((body, f"{os.path.basename(path)}: {how}"))
    chosen, rows = {}, []
    for did, (label, exact, least) in wanted.items():
        good = [c for c in seen[did] if (len(c[0]) == exact if exact else len(c[0]) >= least)]
        if good:
            body, source = good[-1] if pick == "last" else good[0]
            chosen[did] = body
            used = f"{pick} of {len(good)}" if len({g[0] for g in good}) > 1 else "only one"
            rows.append((did, label, len(seen[did]), len(body), source, f"decoded ({used})"))
        elif seen[did]:
            sizes = sorted({len(c[0]) for c in seen[did]})
            rows.append((did, label, len(seen[did]), "", seen[did][-1][1],
                         f"NOT USED: {sizes} data bytes, {exact or f'at least {least}'} needed"))
        else:
            rows.append((did, label, 0, "", "", "not in the log"))
    return chosen, rows


# ----------------------------------------------------------------------------------------------
# 2. Input curves: which file belongs to which sensor
# ----------------------------------------------------------------------------------------------
def norm(name):
    return re.sub(r"[^a-z0-9]+", " ", name.lower()).strip()


def read_curve(path):
    """One LSB value per line. A line '<value>#SPI_..' is a sample the sensor answers faulty."""
    text = Path(path).read_text(errors="ignore")
    if "#" not in text:
        values = np.array(text.split(), dtype=float)
        return values, np.zeros(len(values), bool)
    lines = [line for line in text.splitlines() if line.strip()]
    return np.array([float(line.split("#")[0]) for line in lines]), np.array(["#" in line for line in lines])


def identify_curves(folder, profile, overrides=None):
    """A file belongs to a sensor only when the sensor part of its name (between '_LSB_' and the
    rate, or the whole name) EQUALS one of the sensor's curve names: 'Central_AccLG_X' (Panasonic
    low-g) is never 'Central_Acc_X'. Two files for one sensor stop the run."""
    sample_ms = curve_ms(profile)
    # High-g sensors and the IMU elements of the record are separate targets with their own curve
    # names; a curve is stored in physical units (g, deg/s), an IMU curve with its mounting sign.
    targets = profile["sensors"] + [dict(e, lsb_per_g=e["lsb_per_unit"] * e["sign"])
                                    for e in (profile.get("imu") or {}).get("elements", [])]
    alias = {norm(a): s["name"] for s in targets for a in s["curve"]}
    by_name = {s["name"]: s for s in targets}
    overrides = {name: Path(p).resolve() for name, p in (overrides or {}).items()}
    for name in overrides:
        if name not in by_name:
            raise ValueError(f"--curve: no sensor '{name}' in the profile ({', '.join(by_name)})")
    forced = {p: name for name, p in overrides.items()}
    files = sorted(p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() == ".txt")
    files += [p for p in forced if p not in [f.resolve() for f in files]]
    chosen, rows = {}, []
    for path in files:
        m = re.search(r"_LSB_(.+?)_(\d+(?:\.\d+)?)k(?=_|$)", path.stem, re.I)
        token, rate = (m.group(1), float(m.group(2))) if m else (path.stem, None)
        sensor = forced.get(path.resolve()) or (None if alias.get(norm(token)) in overrides else alias.get(norm(token)))
        if sensor is None:
            if re.search(r"acc ?lg|low ?g|panasonic|imu|rate", norm(token)):
                why = "ignored: low-g / IMU (Panasonic) curve that no IMU element of the profile names; never a high-g sensor"
            elif alias.get(norm(token)) in overrides:
                why = "ignored: another file was given for this sensor (--curve)"
            else:
                why = "ignored: no sensor of the profile has this curve name"
            rows.append((path.name, token, "", why))
            continue
        if sensor in chosen:
            raise ValueError(f"Two curve files for {sensor}: '{chosen[sensor]['path'].name}' and '{path.name}'. "
                             f"Remove one or name the right one with --curve \"{sensor}=<file>\".")
        values, faulty = read_curve(path)
        file_ms = 1.0 / rate if rate else sample_ms
        note = "by name" if path.resolve() not in forced else "given by the user"
        if abs(file_ms - sample_ms) > 1e-9:    # another rate than the profile's curve grid
            x = np.arange(len(values)) * file_ms
            grid = np.arange(0.0, x[-1] + 1e-9, sample_ms)
            values, faulty = np.interp(grid, x, values), np.interp(grid, x, faulty) > 0
            note += f"; resampled {file_ms:g} -> {sample_ms:g} ms"
        s = by_name[sensor]
        peak = float(np.abs(values).max()) / abs(s["lsb_per_g"]) if len(values) else 0.0
        if "range_g" not in s:
            note += f"; IMU element of the event record ({s['lsb_per_unit']} LSB per {s['unit']})"
        elif peak > 1.5 * s["range_g"]:
            note += f"; WARNING peak {peak:.0f} g is far over the +/-{s['range_g']} g range - right file?"
        chosen[sensor] = {"path": path, "g": values / s["lsb_per_g"], "faulty": faulty}
        rows.append((path.name, token, sensor, note))
    for s in targets:
        if s["name"] not in chosen:
            rows.append(("(no file)", "", s["name"], "no curve in the folder: " +
                         ("0 g expected" if "range_g" in s else "decoded only, not compared")))
    return chosen, rows


# ----------------------------------------------------------------------------------------------
# 3. Polarity expectation
# ----------------------------------------------------------------------------------------------
def load_polarity(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    for crash, table in data.get("expect", {}).items():
        for sensor, rule in table.items():
            if rule not in RULES:
                raise ValueError(f"{path}: {crash} / {sensor}: '{rule}' is not one of {RULES}")
    return data


def rule_for(polarity, crash, sensor):
    """'+' / '-': sign of the main pulse at the ECU; 'curve': as the file; 'inverted': the file
    negated; 'any': not judged. Not in the polarity file -> AUTOSAR; no crash type -> 'any'.
    crash may name several types that happened in the record ('front+left+rollover'): the sensor
    is judged when the types that have a rule for it agree, and not judged when they contradict
    (front+rear on X). 'mixed' (every side at once, all loops fired), 'rollover' or any other name
    without rules judges nothing; 'mixed' overrides the other types named with it."""
    def one(part):
        table = (polarity or {}).get("expect", {}).get(part, {})
        return table.get(sensor["name"]) or table.get("default") or AUTOSAR.get(part, {}).get(sensor["axis"], "any")
    return combined(crash, one)


def combined(crash, rule_of):
    """The one rule the crashes named in 'a+b+c' agree on, else 'any'."""
    parts = [p.strip() for p in (crash or "").split("+") if p.strip()]
    rules = {rule_of(part) for part in (["mixed"] if "mixed" in parts else parts)} - {"any"}
    return rules.pop() if len(rules) == 1 else "any"


# ----------------------------------------------------------------------------------------------
# 4. Comparison
# ----------------------------------------------------------------------------------------------
def window(values, first, count, fill=0.0):
    out = np.full(count, fill, dtype=values.dtype if fill is False else float)
    low, high = max(first, 0), min(first + count, len(values))
    if high > low:
        out[low - first:high - first] = values[low:high]
    return out


def quantise(g, sensor, max_counts):
    """The input clipped to the range and as the ECU stores it (cut toward zero to the resolution)."""
    step = sensor["g_per_count"]
    limit = min(sensor["range_g"] // step, max_counts) * step
    given = np.clip(g, -limit, limit)
    return given, np.trunc(given / step) * step


def sign_text(value):
    return "+" if value > 0 else "-" if value < 0 else "0"


def r1_edges(g, window_samples, kmh_per_sample, threshold):
    """Samples where the delta-V over the window first reaches the threshold (49 CFR 563.5 T0)."""
    total = np.concatenate([[0.0], np.cumsum(g)])
    index = np.arange(1, len(g) + 1)
    hit = np.abs(total[index] - total[np.maximum(index - window_samples, 0)]) * kmh_per_sample >= threshold
    return np.flatnonzero(hit & ~np.concatenate([[False], hit[:-1]]))


def compare_sensor(sensor, raw, curve, first, rule, P):
    step, n, shift = sensor["g_per_count"], P["samples"], P["shift_samples"]
    time_ms = (np.arange(n) - P["pre_t0_samples"]) * P["sample_ms"]
    edr = np.where(raw == P["invalid_code"], np.nan, (raw.astype(float) - P["zero_code"]) * step)
    g = window(curve["g"], first, n) if curve else np.zeros(n)
    fault = window(curve["faulty"], first, n, False) if curve else np.zeros(n, bool)
    valid = ~fault
    k_in = int(np.argmax(np.where(valid, np.abs(g), -1.0)))
    in_peak = float(g[k_in]) if valid.any() else 0.0
    # Orientation the rule expects at the ECU (None: not judged) and the one the record shows.
    wanted = {"+": 1.0 if in_peak >= 0 else -1.0, "-": -1.0 if in_peak > 0 else 1.0,
              "curve": 1.0, "inverted": -1.0, "any": None}[rule]
    shown = 1.0 if np.nansum(np.where(valid, edr * g, 0.0)) >= 0 else -1.0
    judged = wanted is not None and abs(in_peak) >= P["min_counts_for_sign"] * step and valid.any()
    polarity_ok = (shown == wanted) if judged else True
    # Magnitude against the input in the orientation the record shows, so that a polarity fault
    # and a magnitude fault are reported separately.
    given, stored = quantise(shown * g, sensor, P["max_counts"])
    low, high, near = np.where(fault, np.inf, stored), np.where(fault, -np.inf, stored), fault.copy()
    low_band, high_band = low.copy(), high.copy()
    for d in range(1, shift + 1):
        for a, b in ((slice(d, None), slice(None, -d)), (slice(None, -d), slice(d, None))):
            low_band[a], high_band[a] = np.minimum(low_band[a], low[b]), np.maximum(high_band[a], high[b])
            near[a] |= fault[b]
    with np.errstate(invalid="ignore"):
        in_band = np.where(np.isnan(edr), near, (edr >= low_band - step) & (edr <= high_band + step))
    outside = np.flatnonzero(~in_band)
    k_edr = int(np.argmax(np.where(valid, np.abs(np.nan_to_num(edr)), -1.0)))
    edr_peak = float(np.nan_to_num(edr[k_edr])) if valid.any() else 0.0
    peak_ok = abs(edr_peak - float(given[k_in])) <= step if valid.any() else True
    display = (wanted if wanted is not None else shown)
    return {
        "name": sensor["name"], "raw": raw, "edr": edr, "time": time_ms,
        "input": display * g, "stored": quantise(display * g, sensor, P["max_counts"])[1],
        "rule": rule, "sigma": display,
        "expected_polarity": sign_text(wanted * in_peak) if judged else "not judged",
        "recorded_polarity": sign_text(edr_peak),
        "polarity": "PASS" if judged and polarity_ok else "FAIL" if judged else "not judged",
        "input_peak": display * in_peak, "input_peak_ms": float(time_ms[k_in]),
        "edr_peak": edr_peak, "edr_peak_ms": float(time_ms[k_edr]),
        "peak": "PASS" if peak_ok else "FAIL",
        "outside": len(outside), "first_outside_ms": float(time_ms[outside[0]]) if len(outside) else None,
        "invalid": int(np.isnan(edr).sum()),
        "verdict": "PASS" if polarity_ok and peak_ok and not len(outside) else "FAIL",
    }


def compare_delta_v(axis, payload, curve, sigma, t0, P, crash=""):
    """sigma: orientation of the central curve at the ECU, used only when the crash type gives no
    NHTSA sign for this axis; with one, the expected delta-V has that sign whatever the sensor
    polarity expectation is."""
    D, dt, shift = P["delta_v"], curve_ms(P), P["shift_samples"] * stride(P)
    out = {"name": axis["name"], "sensor": axis["sensor"], "times": [], "expected": [], "edr": [], "ok": [],
           "verdict": "", "note": ""}
    if payload is None or len(payload) < axis["max_byte"] - 3:
        out["verdict"], out["note"] = "NOT IN LOG", "the event record is not in the log"
        return out
    at = lambda position: position - 4    # 1-based position including the 3 header bytes -> payload index
    series = [None if b == P["invalid_code"] else b + D["offset"]
              for b in payload[at(axis["series_start"]):at(axis["series_start"]) + D["samples"]]]
    raw_max = payload[at(axis["max_byte"])]
    out["max_edr"] = None if raw_max == P["invalid_code"] else raw_max + D["offset"]
    out["time_edr"] = int.from_bytes(payload[at(axis["time_max_start"]):at(axis["time_max_start"]) + 2], "big") * D["time_scale_ms"]
    out["times"], out["edr"] = [i * D["step_ms"] for i in range(D["samples"])], series
    if curve is None:
        out["verdict"], out["note"] = "INFO", f"no {axis['sensor']} curve in the folder or no T0: reported only"
        out["expected"], out["ok"] = [None] * D["samples"], [""] * D["samples"]
        return out
    g = sigma * curve["g"]
    total = np.concatenate([[0.0], np.cumsum(g)]) * KMH_PER_G_MS * dt
    length, step_samples, span = len(g), round(D["step_ms"] / dt), round(D["time_max_window_ms"] / dt)
    report = axis["report_sign"]
    nhtsa = combined(crash, lambda part: NHTSA_DELTA_V.get(part, {}).get(axis["name"], "any"))
    if nhtsa != "any":
        window = total[min(max(t0, 0), length):min(max(t0, 0) + span, length) + 1] - total[min(max(t0, 0), length)]
        largest_input = float(window[np.argmax(np.abs(window))]) if len(window) else 0.0
        report = (1.0 if nhtsa == "+" else -1.0) * (-1.0 if largest_input < 0 else 1.0)

    def delta_v(samples_after, start):
        a, b = min(max(start, 0), length), min(max(start + samples_after, 0), length)
        return np.clip(report * (total[b] - total[a]), D["min"], D["max"])

    starts = range(t0 - shift, t0 + shift + 1)    # T0 one sample either side, like the sensor samples
    tolerance = D["tolerance_kmh"]
    within = lambda value, band: value is not None and min(band) - tolerance <= value <= max(band) + tolerance
    largest = lambda start: max((float(delta_v(k, start)) for k in range(span + 1)), key=abs)
    for i in range(D["samples"]):
        out["expected"].append(float(delta_v(i * step_samples, t0)))
        out["ok"].append("PASS" if within(series[i] if i < len(series) else None,
                                          [delta_v(i * step_samples, s) for s in starts]) else "FAIL")
    k_max = max(range(span + 1), key=lambda k: abs(delta_v(k, t0)))
    out["max_expected"], out["time_expected"] = float(delta_v(k_max, t0)), k_max * dt
    out["max_ok"] = "PASS" if within(out["max_edr"], [largest(s) for s in starts]) else "FAIL"
    judged = abs(out["max_expected"]) >= 2 * tolerance
    out["expected_polarity"] = (sign_text(out["max_expected"]) + (" (NHTSA)" if nhtsa != "any" else " (from the sensor)")) if judged else "not judged"
    out["recorded_polarity"] = sign_text(out["max_edr"] or 0)
    out["polarity"] = ("PASS" if sign_text(out["max_edr"] or 0) == sign_text(out["max_expected"]) else "FAIL") if judged else "not judged"
    if curve["faulty"][max(t0 - shift, 0):t0 + span + shift].any():
        out["verdict"], out["note"] = "INFO", f"{axis['sensor']} is faulty in the record: reported only"
    else:
        out["verdict"] = "PASS" if out["max_ok"] == "PASS" and "FAIL" not in out["ok"] else "FAIL"
    return out


def compare_imu(payload, curves, t0, P):
    """The IMU elements of the event record (angular rate X / Y / Z, longitudinal / lateral /
    vertical acceleration), decoded and, where a curve and a T0 exist, checked. The ECU takes each
    sample on a free-running 500 ms tick, so a sample may be taken anywhere in an interval: it
    passes when it lies between the lowest and the highest input of that interval."""
    I, dt = P["imu"], curve_ms(P)
    labels = [I["start_ms"] + k * I["step_ms"] for k in range(I["samples"])]
    out = []
    for element in I["elements"]:
        row = {"name": element["name"], "unit": element["unit"], "times": [label / 1000 for label in labels],
               "edr": [], "low": [], "high": [], "ok": [], "verdict": "INFO", "note": ""}
        out.append(row)
        data = payload[element["start"] - 4:element["start"] - 4 + 2 * I["samples"]]
        if len(data) < 2 * I["samples"]:
            row["verdict"], row["note"], row["times"] = "NOT IN LOG", "the event record in the log is too short", []
            continue
        curve = curves.get(element["name"])
        tolerance = I["tolerance_counts"] * element["scale"]
        for k, label in enumerate(labels):
            word = int.from_bytes(data[2 * k:2 * k + 2], "big")
            value = None if word in I["invalid_words"] else (word - 0x10000 if word >= 0x8000 else word) * element["scale"]
            start = label - I["t0_sample_after_ms"] if label <= 0 else label
            end = label + I["tick_ms"] - I["t0_sample_after_ms"] if label < 0 else label + I["tick_ms"]
            first = last = -1
            if curve is not None and t0 is not None:
                first = t0 + int(np.floor((start + I["t0_margin_ms"]) / dt)) + 1
                last = t0 + int(np.floor((end - I["t0_margin_ms"]) / dt))
            if first < 0 or last >= len(curve["g"]):    # no curve, no T0, or the curve does not cover the interval
                low = high = None
                ok = ""
            else:
                low, high = float(curve["g"][first:last + 1].min()), float(curve["g"][first:last + 1].max())
                ok = "PASS" if value is not None and low - tolerance <= value <= high + tolerance else "FAIL"
            row["edr"].append(value if value is not None else f"0x{word:04X}")
            row["low"].append(low)
            row["high"].append(high)
            row["ok"].append(ok)
        judged = [ok for ok in row["ok"] if ok]
        if judged:
            row["verdict"] = "FAIL" if "FAIL" in judged else "PASS"
            row["note"] = f"{judged.count('PASS')} of {len(judged)} compared samples within the input"
        else:
            row["note"] = ("decoded only: " + ("no curve in the folder" if curve is None else "no T0" if t0 is None
                                               else "the curve does not cover the samples"))
    return out


def imu_fit_t0(payload, curves, P):
    """T0 from the IMU elements alone (a rollover without a high-g pulse): the curve sample at which
    most IMU samples lie within their input. None when the recorded IMU data do not vary."""
    I = P["imu"]
    names = [e["name"] for e in I["elements"] if e["name"] in curves]
    flat = compare_imu(payload, {}, None, P)
    varies = any(np.ptp([v for v in row["edr"] if not isinstance(v, str)] or [0.0]) > 2 * I["tolerance_counts"] * e["scale"]
                 for row, e in zip(flat, I["elements"]))
    if not names or not varies:
        return None
    best = None
    # shortcut: 4 ms grid (inside the 5 ms interval margin), a finer T0 needs a second pass
    for t0 in range(0, max(len(curves[name]["g"]) for name in names), max(1, round(4 / curve_ms(P)))):
        oks = [ok for row in compare_imu(payload, curves, t0, P) for ok in row["ok"] if ok]
        score = (oks.count("FAIL"), -len(oks))
        if oks and (best is None or score < best[0]):
            best = (score, t0)
    return best[1] if best else None


def analyse(profile, curves, found, crashes, polarity):
    P = profile
    by_name = {s["name"]: s for s in P["sensors"]}
    results, previous_t0 = [], None
    for column, record_did in enumerate(P["records"]):
        crash = crashes[column] if column < len(crashes) else ""
        record = {"record": column + 1, "did": record_did, "crash": crash, "sensors": [], "missing": [],
                  "delta_v": [], "imu": [], "t0": None, "status": "", "t0_note": ""}
        results.append(record)
        payload = found.get(record_did)
        raws = {s["name"]: np.frombuffer(found[s["did"][column]], np.uint8)
                for s in P["sensors"] if s["did"][column] in found}
        record["missing"] = [(s["name"], s["did"][column]) for s in P["sensors"] if s["name"] not in raws]
        if not raws and payload is None:
            record["status"] = "NOT IN LOG"
            continue
        if raws and all((raw == P["invalid_code"]).all() for raw in raws.values()):
            record["status"] = "EMPTY (every sensor sample 0xFF: no event stored)"
            continue
        t0 = None
        if raws:
            t0 = previous_t0 = analyse_sensors(record, raws, curves, crash, polarity, previous_t0, P)
        if payload is not None and P.get("imu"):
            # A rollover has no high-g pulse to place T0 with: place it with the IMU elements.
            if t0 is None or record["status"].startswith("NO SIGNAL"):
                fitted = imu_fit_t0(payload, curves, P)
                if fitted is not None:
                    t0 = previous_t0 = record["t0"] = fitted
                    record["status"] = ""
                    record["t0_note"] = "placed with the IMU elements of the record (no high-g pulse), 4 ms grid"
            record["imu"] = compare_imu(payload, curves, t0, P)
        sigma = {r["name"]: r["sigma"] for r in record["sensors"]}
        for axis in (P.get("delta_v") or {}).get("axes", []):
            rule = rule_for(polarity, crash, by_name[axis["sensor"]])
            record["delta_v"].append(compare_delta_v(
                axis, payload, curves.get(axis["sensor"]) if t0 is not None else None,
                sigma.get(axis["sensor"], -1.0 if rule == "inverted" else 1.0), t0, P, crash))
    return results


def analyse_sensors(record, raws, curves, crash, polarity, previous_t0, P):
    """Finds the ECU's T0 of the record in the curves and compares every sensor DID; returns the
    T0 as a sample of the curve grid."""
    n, pre, dt, k = P["samples"], P["pre_t0_samples"], curve_ms(P), stride(P)
    by_name = {s["name"]: s for s in P["sensors"]}
    length = max([len(c["g"]) for name, c in curves.items() if name in by_name] + [1])
    edr = {}
    for name, raw in raws.items():
        mask = raw != P["invalid_code"]
        edr[name] = (np.where(mask, (raw.astype(float) - P["zero_code"]) * by_name[name]["g_per_count"], 0.0), mask.astype(float))
    # T0: the curve sample at which all sensor DIDs together fit their curves best, either sign per
    # sensor so that a polarity fault does not move it. An EDR slower than the curves (2 ms against
    # 0.5 ms) keeps every k-th curve sample, starting anywhere: every starting phase is tried.
    best = None
    for phase in range(k):
        size = max(1, -(-(length - phase) // k))
        cost = np.zeros(size + n + 1)
        for name, (values, mask) in edr.items():
            cost += float((values * values).sum())
            if name in curves:
                part = quantise(curves[name]["g"][phase::k], by_name[name], P["max_counts"])[1]
                stored = np.zeros(size + 2 * n)
                stored[n:n + len(part)] = part
                cost += np.correlate(stored * stored, mask, "valid") - 2 * np.abs(np.correlate(stored, values, "valid"))
        if best is None or cost.min() < best[0] - 1e-6 * max(1.0, abs(cost.min())):
            best = (cost.min(), phase, cost)
    low, phase, cost = best
    fits = np.flatnonzero(cost <= low + 1e-6 * max(1.0, abs(low)))
    later = fits[(fits - n + pre) * k + phase > previous_t0] if previous_t0 is not None else fits[:0]
    first = int(later[0] if len(later) else fits[0]) - n    # an equal fit: the event after the previous record's
    t0 = record["t0"] = (first + pre) * k + phase
    edges = np.unique(np.concatenate([
        r1_edges(curves[name]["g"], round(window_ms / dt), KMH_PER_G_MS * dt, P["t0_rule"]["threshold_kmh"])
        for name, window_ms in P["t0_rule"]["window_ms"].items() if name in curves] or [np.array([], int)]))
    if len(edges):
        nearest = int(edges[np.argmin(np.abs(edges - t0))])
        record["t0_note"] = f"{(t0 - nearest) * dt:+g} ms from the 0.8 km/h rule T0 of the curves (sample {nearest})"
        if abs(t0 - nearest) * dt > P["t0_rule"]["warn_ms"]:
            record["t0_note"] += " - WARNING: far from any event start, check the curve folder"
    for sensor in P["sensors"]:
        if sensor["name"] in raws:
            curve = curves.get(sensor["name"])
            on_grid = curve and {"g": curve["g"][phase::k], "faulty": curve["faulty"][phase::k]}
            record["sensors"].append(compare_sensor(sensor, raws[sensor["name"]], on_grid, first,
                                                    rule_for(polarity, crash, sensor), P))
    floor = lambda r: P["min_counts_for_sign"] * by_name[r["name"]]["g_per_count"]
    if all(abs(r["input_peak"]) < floor(r) and abs(r["edr_peak"]) < floor(r) for r in record["sensors"]):
        record["status"] = "NO SIGNAL: neither the record nor the curves hold a crash pulse - nothing was proven"
    return t0


def overall_verdict(results):
    present = [r for r in results if r["sensors"] or r["imu"]]
    if not present:
        return "NOTHING CHECKED"
    if any(r["status"].startswith("NO SIGNAL") or any(s["verdict"] == "FAIL" for s in r["sensors"])
           or any(d["verdict"] == "FAIL" for d in r["delta_v"] + r["imu"]) for r in present):
        return "FAIL"
    if any(r["missing"] or any(d["verdict"] == "NOT IN LOG" for d in r["delta_v"]) for r in present):
        return "INCOMPLETE (PASS for what the log holds)"
    return "PASS"


# ----------------------------------------------------------------------------------------------
# 5. Outputs: workbook and decoded LSB curves
# ----------------------------------------------------------------------------------------------
def cells(values):
    return [None if v is None or v != v else v for v in (values.tolist() if hasattr(values, "tolist") else values)]


def write_excel(path, meta, results, curve_rows, did_rows, profile):
    import xlsxwriter
    book = xlsxwriter.Workbook(str(path))
    bold, head = book.add_format({"bold": True}), book.add_format({"bold": True, "bg_color": "#D9E1F2", "border": 1})
    good, bad = book.add_format({"bg_color": "#C6EFCE"}), book.add_format({"bg_color": "#FFC7CE"})

    def colour(sheet, rows):
        for text, fmt in (("FAIL", bad), ("NOT IN", bad), ("NOT USED", bad), ("WARNING", bad), ("PASS", good)):
            sheet.conditional_format(0, 0, rows, 30, {"type": "text", "criteria": "containing", "value": text, "format": fmt})

    summary = book.add_worksheet("Summary")
    row = 0
    for label, value in meta:
        summary.write(row, 0, label, bold)
        summary.write(row, 1, value)
        row += 1
    columns = ["Record", "Sensor", "DID", "Polarity rule", "Expected polarity", "Recorded polarity", "Polarity",
               "Input peak (g)", "at (ms)", "EDR peak (g)", "at (ms)", "Peak", "Samples out of tolerance",
               "First at (ms)", "Samples 0xFF", "Verdict"]
    for record in results:
        row += 1
        t0 = "" if record["t0"] is None else (f"; ECU T0 = curve sample {record['t0']} "
                                              f"({record['t0'] * curve_ms(profile):g} ms). {record['t0_note']}")
        summary.write(row, 0, f"Record {record['record']} ({record['did']}); crash type: {record['crash'] or 'not given'}"
                              f"{t0} {record['status']}", bold)
        row += 1
        if not (record["sensors"] or record["delta_v"] or record["imu"]):
            continue
        summary.write_row(row, 0, columns, head)
        for s in record["sensors"]:
            row += 1
            did = next(x["did"][record["record"] - 1] for x in profile["sensors"] if x["name"] == s["name"])
            summary.write_row(row, 0, [record["record"], s["name"], did, s["rule"], s["expected_polarity"],
                                       s["recorded_polarity"], s["polarity"], round(s["input_peak"], 3),
                                       s["input_peak_ms"], s["edr_peak"], s["edr_peak_ms"], s["peak"], s["outside"],
                                       s["first_outside_ms"], s["invalid"], s["verdict"]])
        for name, did in record["missing"]:
            row += 1
            summary.write_row(row, 0, [record["record"], name, did] + [""] * 12 + ["NOT IN LOG"])
        for d in record["delta_v"]:
            row += 1
            summary.write_row(row, 0, [record["record"], f"Delta-V {d['name']} ({d['sensor']})", record["did"], "NHTSA Part 563",
                                       d.get("expected_polarity", ""), d.get("recorded_polarity", ""), d.get("polarity", ""),
                                       d.get("max_expected"), d.get("time_expected"), d.get("max_edr"), d.get("time_edr"),
                                       d.get("max_ok", ""), d["ok"].count("FAIL"), "", "", d["verdict"], d["note"]])
        for e in record["imu"]:
            row += 1
            summary.write_row(row, 0, [record["record"], f"IMU {e['name']} ({e['unit']})", record["did"]] + [""] * 9
                              + [e["ok"].count("FAIL"), "", sum(isinstance(v, str) for v in e["edr"]), e["verdict"], e["note"]])
        row += 1
    summary.set_column(0, 0, 9)
    summary.set_column(1, 1, 34)
    summary.set_column(2, 15, 14)
    colour(summary, row)

    graphs = book.add_worksheet("Graphs")
    delta = book.add_worksheet("DeltaV")
    imu = book.add_worksheet("IMU")
    graph_row = delta_row = imu_row = 0
    for record in results:
        # IMU elements of the record: decoded values, and the input band where a curve exists
        for i, e in enumerate(x for x in record["imu"] if x["times"]):
            c = 1 + 4 * i
            if i == 0:
                imu.write(imu_row, 0, f"Record {record['record']} ({record['did']}): IMU elements, sample must lie "
                                      f"between the lowest and highest input of its sampling interval", bold)
                imu.write(imu_row + 1, 0, "Time (s)", head)
                imu.write_column(imu_row + 2, 0, e["times"])
            imu.write_row(imu_row + 1, c, [f"{e['name']} input min ({e['unit']})", f"{e['name']} input max",
                                           f"{e['name']} EDR", f"{e['name']} verdict"], head)
            for offset, values in enumerate((e["low"], e["high"], e["edr"], e["ok"])):
                imu.write_column(imu_row + 2, c + offset, cells(values))
            last = imu_row + 1 + len(e["times"])
            imu.write(last + 1, c, f"{e['verdict']} {e['note']}")
            chart = book.add_chart({"type": "scatter", "subtype": "straight_with_markers"})
            for label, offset in (("Input min", 0), ("Input max", 1), ("EDR", 2)):
                chart.add_series({"name": label, "categories": ["IMU", imu_row + 2, 0, last, 0],
                                  "values": ["IMU", imu_row + 2, c + offset, last, c + offset]})
            chart.set_title({"name": f"R{record['record']} {e['name']} - {e['verdict']}", "name_font": {"size": 10}})
            chart.set_x_axis({"name": "s from T0"})
            chart.set_y_axis({"name": e["unit"]})
            chart.set_size({"width": 500, "height": 280})
            imu.insert_chart(imu_row + len(e["times"]) + 5 + (i // 3) * 15, (i % 3) * 8, chart)
        if any(x["times"] for x in record["imu"]):
            imu_row += profile["imu"]["samples"] + 5 + 2 * 15 + 2
        tag = f"R{record['record']}"
        if record["sensors"]:
            data = book.add_worksheet(f"{tag} data")
            data.write(0, 0, "Time (ms)", head)
            data.write_column(1, 0, cells(record["sensors"][0]["time"]))
            data.freeze_panes(1, 1)
            graphs.write(graph_row, 0, f"Record {record['record']} ({record['did']}): input at the ECU against the EDR recording (g)", bold)
            samples = profile["samples"]
            for i, s in enumerate(record["sensors"]):
                c = 1 + 4 * i
                data.write_row(0, c, [f"{s['name']} input (g)", f"{s['name']} input as stored (g)", f"{s['name']} EDR (g)",
                                      f"{s['name']} raw byte"], head)
                for offset, values in enumerate((s["input"], s["stored"], s["edr"], s["raw"])):
                    data.write_column(1, c + offset, cells(values))
                chart = book.add_chart({"type": "scatter", "subtype": "straight"})
                for label, offset, colour_hex in (("Input", 0, "#1F77B4"), ("EDR", 2, "#D62728")):
                    chart.add_series({"name": label, "categories": [data.name, 1, 0, samples, 0],
                                      "values": [data.name, 1, c + offset, samples, c + offset],
                                      "line": {"color": colour_hex, "width": 1.25}})
                chart.set_title({"name": f"{tag} {s['name']} - {s['verdict']}", "name_font": {"size": 10}})
                chart.set_x_axis({"name": "ms from T0"})
                chart.set_y_axis({"name": "g"})
                chart.set_size({"width": 500, "height": 280})
                graphs.insert_chart(graph_row + 1 + (i // 3) * 15, (i % 3) * 8, chart)
            graph_row += 2 + ((len(record["sensors"]) + 2) // 3) * 15

        if not record["delta_v"]:
            continue
        delta.write(delta_row, 0, f"Record {record['record']} ({record['did']}): delta-V of the curve from T0 against the record (km/h)", bold)
        delta.write(delta_row + 1, 0, "Time (ms)", head)
        for i, d in enumerate(record["delta_v"]):
            c = 1 + 3 * i
            delta.write_row(delta_row + 1, c, [f"{d['name']} expected", f"{d['name']} EDR", f"{d['name']} verdict"], head)
            if not d["times"]:
                delta.write(delta_row + 2, c, f"{d['verdict']}: {d['note']}")
                continue
            delta.write_column(delta_row + 2, 0, d["times"])
            delta.write_column(delta_row + 2, c, cells(d["expected"]))
            delta.write_column(delta_row + 2, c + 1, cells(d["edr"]))
            delta.write_column(delta_row + 2, c + 2, d["ok"])
            last = delta_row + 2 + len(d["times"])
            delta.write_row(last, c, cells([d.get("max_expected"), d.get("max_edr"), d.get("max_ok", "")]))
            delta.write(last, 0, "Maximum", bold)
            delta.write_row(last + 1, c, cells([d.get("time_expected"), d.get("time_edr"), "reported only"]))
            delta.write(last + 1, 0, "Time of max (ms)", bold)
            delta.write(last + 2, c, f"{d['verdict']} {d['note']}")
            chart = book.add_chart({"type": "scatter", "subtype": "straight_with_markers"})
            for label, offset in (("Expected (curve)", 0), ("EDR", 1)):
                chart.add_series({"name": label, "categories": ["DeltaV", delta_row + 2, 0, last - 1, 0],
                                  "values": ["DeltaV", delta_row + 2, c + offset, last - 1, c + offset]})
            chart.set_title({"name": f"{tag} delta-V {d['name']} - {d['verdict']}", "name_font": {"size": 10}})
            chart.set_x_axis({"name": "ms from T0"})
            chart.set_y_axis({"name": "km/h"})
            chart.set_size({"width": 500, "height": 280})
            delta.insert_chart(delta_row + 1, 9 + i * 8, chart)
        delta_row += profile["delta_v"]["samples"] + 8
    delta.set_column(0, 8, 20)
    colour(delta, delta_row)
    imu.set_column(0, 24, 18)
    colour(imu, imu_row)

    files = book.add_worksheet("Files")
    files.write_row(0, 0, ["Curve file", "Sensor part of the name", "Sensor", "Note"], head)
    for i, r in enumerate(curve_rows):
        files.write_row(1 + i, 0, r)
    base = len(curve_rows) + 3
    files.write_row(base, 0, ["DID", "Content", "Responses in the log", "Data bytes", "Source", "Status"], head)
    for i, r in enumerate(did_rows):
        files.write_row(base + 1 + i, 0, r)
    files.set_column(0, 0, 70)
    files.set_column(1, 5, 32)
    colour(files, base + len(did_rows) + 1)
    book.close()


def write_decoded_lsb(folder, results, profile):
    """The recording of every sensor as an LSB curve (one value per line, the input-curve format),
    to replay or inspect in simulation. A 0xFF sample is written as 0."""
    folder.mkdir(parents=True, exist_ok=True)
    rate = f"{1.0 / profile['sample_ms']:g}k"
    by_name = {s["name"]: s for s in profile["sensors"]}
    for record in results:
        for s in record["sensors"]:
            sensor = by_name[s["name"]]
            label = (sensor["curve"] or [sensor["name"]])[0]
            name = f"EDR_R{record['record']}_{sensor['did'][record['record'] - 1]}_LSB_{label}_{rate}_decoded.txt"
            np.savetxt(folder / name, np.rint(np.nan_to_num(s["edr"]) * sensor["lsb_per_g"]).astype(int), fmt="%d")


def run(logs, curves_dir, out_dir=None, project=None, polarity=None, crashes=(), pick="last", overrides=None):
    """project: folder name under projects/ or a profile path. polarity: a loaded polarity dict, a
    path, or None (AUTOSAR). Returns (verdict, text, out dir)."""
    profile, profile_path = load_profile(project)
    if isinstance(polarity, (str, Path)):
        polarity_name, polarity = str(polarity), load_polarity(polarity)
    else:
        polarity_name = (polarity or {}).get("name", "AUTOSAR (built in)")
    logs = [Path(p) for p in logs]
    wanted = {}
    least = max([a["max_byte"] for a in (profile.get("delta_v") or {}).get("axes", [])] + [4]) - 3
    for column, did in enumerate(profile["records"]):
        wanted[did] = (f"Event record {column + 1}", profile.get("record_payload_bytes"), least)
        for s in profile["sensors"]:
            wanted[s["did"][column]] = (f"{s['name']}, record {column + 1}", profile["samples"], profile["samples"])
    curves, curve_rows = identify_curves(curves_dir, profile, overrides)
    found, did_rows = decode_logs(logs, wanted, pick)
    if not found:
        raise ValueError("No sensor DID or event record response was found in the log(s). "
                         "See README.md for the log forms the tool reads.")
    results = analyse(profile, curves, found, list(crashes), polarity)
    verdict = overall_verdict(results)
    out_dir = Path(out_dir) if out_dir else logs[0].parent / f"{logs[0].stem}_edr_check"
    out_dir.mkdir(parents=True, exist_ok=True)
    meta = [("Result", verdict), ("Log file(s)", "; ".join(str(p) for p in logs)), ("Input curves", str(curves_dir)),
            ("Profile", f"{profile.get('project', '')}: {profile_path}; EDR sample {profile['sample_ms']:g} ms, "
                        f"{profile['samples']} samples, {len(profile['sensors'])} sensors"), ("Polarity expectation", polarity_name),
            ("Tolerance", f"each sample within one EDR count of the input, {profile['shift_samples']} sample either "
                          f"side" + (f"; delta-V within {profile['delta_v']['tolerance_kmh']:g} km/h" if profile.get("delta_v") else
                                      "; delta-V not checked (not in the profile)"))]
    workbook = out_dir / "EDR_sensor_comparison.xlsx"
    write_excel(workbook, meta, results, curve_rows, did_rows, profile)
    write_decoded_lsb(out_dir / "decoded_lsb", results, profile)

    lines = [f"RESULT: {verdict}",
             f"Project {profile.get('project', '')}: EDR sample {profile['sample_ms']:g} ms, {profile['samples']} samples",
             f"Curves identified: {len(curves)} (of {len(profile['sensors'])} sensors and "
                                           f"{len((profile.get('imu') or {}).get('elements', []))} IMU elements)"]
    lines += [f"  {r[0]}: {r[3]}" for r in curve_rows if r[3].startswith("ignored") or "WARNING" in r[3]]
    for record in results:
        lines.append(f"Record {record['record']} ({record['did']}), crash '{record['crash'] or 'not given'}': "
                     + (f"T0 = curve sample {record['t0']}; {record['t0_note']} " if record["t0"] is not None else "")
                     + record["status"])
        for s in record["sensors"]:
            lines.append(f"  {s['verdict']:4}  {s['name']:17} polarity {s['recorded_polarity']} (expected "
                         f"{s['expected_polarity']}), peak {s['edr_peak']:+g} g vs input {s['input_peak']:+.2f} g, "
                         f"{s['outside']} samples out of tolerance")
        lines += [f"  NOT IN LOG  {name} (DID {did})" for name, did in record["missing"]] if record["status"] != "NOT IN LOG" else []
        for d in record["delta_v"]:
            numbers = (f"polarity {d['recorded_polarity']} (expected {d['expected_polarity']}), "
                       f"max {d.get('max_edr')} km/h vs input {d['max_expected']:+.1f} km/h, "
                       f"{d['ok'].count('FAIL')} of {len(d['ok'])} samples out") if "max_expected" in d else ""
            lines.append(f"  {d['verdict']:4}  Delta-V {d['name']}: {numbers} {d['note']}")
        for e in record["imu"]:
            lines.append(f"  {e['verdict']:4}  IMU {e['name']}: {e['note']}")
    lines += [f"Workbook: {workbook}", f"Decoded LSB curves: {out_dir / 'decoded_lsb'}"]
    return verdict, "\n".join(lines), out_dir


# ----------------------------------------------------------------------------------------------
# 6. Window
# ----------------------------------------------------------------------------------------------
def gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog, ttk

    profile = load_profile()[0]    # kept as one dict, refilled when another project is chosen
    root = tk.Tk()
    root.title("RSU / central EDR decoder")
    logs, curves, polarity_text = tk.StringVar(), tk.StringVar(), tk.StringVar(value="AUTOSAR (built in)")
    project, project_text = tk.StringVar(value=DEFAULT_PROJECT), tk.StringVar()
    state = {"polarity": None, "out": None, "project": DEFAULT_PROJECT}

    def choose_project(*_):
        try:
            chosen = load_profile(project.get())[0]
        except (ValueError, OSError) as error:
            messagebox.showerror("Project", str(error))
            project.set(state["project"])
            return
        profile.clear()
        profile.update(chosen)
        state["project"] = project.get()
        refresh()
    crash_ticks = [{} for _ in profile["records"]]    # per record: crash type -> ticked
    crash_frames = []

    def crash_types():
        base = list(AUTOSAR) + ["rollover", "mixed"]
        return base + [c for c in (state["polarity"] or {}).get("expect", {}) if c not in base]

    def crash_of(ticks):
        return "+".join(name for name, var in ticks.items() if var.get())

    def refresh():
        polarity_text.set((state["polarity"] or {}).get("name", "AUTOSAR (built in)"))
        project_text.set(f"EDR sample {profile['sample_ms']:g} ms, {profile['samples']} samples, {len(profile['sensors'])} sensors"
                         + ("" if profile.get("delta_v") else ", no delta-V") + ("" if profile.get("imu") else ", no IMU"))
        for frame, ticks in zip(crash_frames, crash_ticks):
            for child in frame.winfo_children():
                child.destroy()
            for name in crash_types():
                ttk.Checkbutton(frame, text=name, variable=ticks.setdefault(name, tk.BooleanVar())).pack(side="left", padx=3)

    def pick_logs():
        chosen = filedialog.askopenfilenames(title="Log file(s) with the DID responses", filetypes=[
            ("Logs", "*.txt *.log *.asc *.trc *.xml *.html *.htm *.csv"), ("All files", "*.*")])
        if chosen:
            logs.set(";".join(chosen))

    def pick_curves():
        chosen = filedialog.askdirectory(title="Folder with the input LSB curves fed to the sensors")
        if chosen:
            curves.set(chosen)

    def load():
        chosen = filedialog.askopenfilename(title="Polarity expectation", initialdir=PROJECTS_DIR / state["project"], filetypes=[("JSON", "*.json")])
        if chosen:
            try:
                state["polarity"] = load_polarity(chosen)
            except (ValueError, OSError) as error:
                messagebox.showerror("Polarity file", str(error))
            refresh()

    def autosar():
        state["polarity"] = None
        refresh()

    def edit():
        top = tk.Toplevel(root)
        top.title("Expected polarity at the ECU, per crash type")
        grid = ttk.Frame(top, padding=8)
        grid.pack()
        table = {}

        def build(types):
            for child in grid.winfo_children():
                child.destroy()
            ttk.Label(grid, text="+ / - : sign of the main pulse   curve: as the file   inverted: file negated   "
                                 "any: not judged").grid(row=0, column=0, columnspan=len(types) + 1, sticky="w")
            for c, crash in enumerate(types):
                ttk.Label(grid, text=crash).grid(row=1, column=c + 1)
            for r, sensor in enumerate(profile["sensors"]):
                ttk.Label(grid, text=sensor["name"]).grid(row=r + 2, column=0, sticky="w")
                for c, crash in enumerate(types):
                    var = table.setdefault((crash, sensor["name"]),
                                           tk.StringVar(value=rule_for(state["polarity"], crash, sensor)))
                    ttk.Combobox(grid, textvariable=var, values=RULES, width=9, state="readonly").grid(row=r + 2, column=c + 1)

        types = crash_types()
        build(types)

        def add():
            name = simpledialog.askstring("Crash type", "Name of the crash type (for example near, understrike):", parent=top)
            if name and name.strip() and name.strip() not in types:
                types.append(name.strip())
                build(types)

        def collect():
            return {"name": polarity_text.get(), "expect": {
                crash: {s["name"]: table[(crash, s["name"])].get() for s in profile["sensors"]} for crash in types}}

        def save():
            chosen = filedialog.asksaveasfilename(parent=top, initialdir=PROJECTS_DIR / state["project"], defaultextension=".json",
                                                  filetypes=[("JSON", "*.json")], initialfile="polarity_expectation.json")
            if chosen:
                data = collect()
                data["name"] = Path(chosen).stem
                Path(chosen).write_text(json.dumps(data, indent=2), encoding="utf-8")
                state["polarity"] = data
                refresh()
                top.destroy()

        def use():
            state["polarity"] = dict(collect(), name="edited, not saved")
            refresh()
            top.destroy()

        bar = ttk.Frame(top, padding=8)
        bar.pack()
        for text, command in (("Add crash type", add), ("Save as JSON and use", save), ("Use without saving", use)):
            ttk.Button(bar, text=text, command=command).pack(side="left", padx=4)

    def start():
        if not logs.get() or not curves.get():
            messagebox.showerror("Missing input", "Choose the log file(s) and the input-curve folder.")
            return
        output.delete("1.0", "end")
        try:
            verdict, text, state["out"] = run(logs.get().split(";"), curves.get(), project=state["project"], polarity=state["polarity"],
                                              crashes=[crash_of(ticks) for ticks in crash_ticks])
        except (ValueError, OSError) as error:
            text = f"STOPPED: {error}"
        output.insert("end", text)

    form = ttk.Frame(root, padding=10)
    form.pack(fill="both", expand=True)
    ttk.Label(form, text="Project").grid(row=0, column=0, sticky="w")
    box = ttk.Combobox(form, textvariable=project, values=project_names(), width=12, state="readonly")
    box.grid(row=0, column=1, sticky="w", padx=4, pady=2)
    box.bind("<<ComboboxSelected>>", choose_project)
    ttk.Label(form, textvariable=project_text).grid(row=0, column=2, columnspan=4, sticky="w")
    for r, (label, var, command) in enumerate((("Log file(s)", logs, pick_logs), ("Input curves folder", curves, pick_curves)), 1):
        ttk.Label(form, text=label).grid(row=r, column=0, sticky="w")
        ttk.Entry(form, textvariable=var, width=90).grid(row=r, column=1, columnspan=4, sticky="we", padx=4, pady=2)
        ttk.Button(form, text="Browse", command=command).grid(row=r, column=5)
    for i in range(len(crash_ticks)):
        ttk.Label(form, text=f"Crashes in record {i + 1} ({profile['records'][i]})").grid(row=3 + i, column=0, sticky="w")
        crash_frames.append(ttk.Frame(form))
        crash_frames[-1].grid(row=3 + i, column=1, columnspan=5, sticky="w", padx=4, pady=2)
    r = 3 + len(crash_ticks)
    ttk.Label(form, text="Polarity expectation").grid(row=r, column=0, sticky="w")
    ttk.Label(form, textvariable=polarity_text).grid(row=r, column=1, sticky="w", padx=4)
    for c, (text, command) in enumerate((("AUTOSAR", autosar), ("Load JSON", load), ("Edit / save", edit))):
        ttk.Button(form, text=text, command=command).grid(row=r, column=2 + c, padx=2)
    ttk.Button(form, text="Decode and check", command=start).grid(row=r + 1, column=1, sticky="w", pady=8, padx=4)
    ttk.Button(form, text="Open output folder", command=lambda: state["out"] and os.startfile(state["out"])).grid(
        row=r + 1, column=2, columnspan=2, sticky="w")
    output = tk.Text(form, width=130, height=30, font=("Consolas", 9))
    output.grid(row=r + 2, column=0, columnspan=6, sticky="nsew")
    form.rowconfigure(r + 2, weight=1)
    form.columnconfigure(1, weight=1)
    refresh()
    root.mainloop()


# ----------------------------------------------------------------------------------------------
# 7. Self-test: a simulated ECU recording in every log form, and planted faults
# ----------------------------------------------------------------------------------------------
def self_test():
    import tempfile
    profile = load_profile()[0]
    n, pre, dt = profile["samples"], profile["pre_t0_samples"], profile["sample_ms"]
    pulse = np.zeros(19000)    # the crash 5.6 s into the curves, so that the IMU samples from -5 s are covered
    pulse[11200:11280] = np.sin(np.linspace(0, np.pi, 80))
    imu = profile["imu"]
    peaks = {"Central X": 30.0, "Central Y": 3.0, "Front Left X": 40.0, "Front Right X": 36.0, "A-Pillar Left Y": 12.0}
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        curve_dir = tmp / "curves"
        curve_dir.mkdir()
        lsb = {}
        for s in profile["sensors"]:
            if s["curve"]:
                lsb[s["name"]] = np.rint(pulse * peaks.get(s["name"], 0.0) * s["lsb_per_g"])
                np.savetxt(curve_dir / f"SET_LSB_{s['curve'][0]}_2k_01-Jan-2026.txt", lsb[s["name"]], fmt="%d")
        # IMU curves under their Central_AccLG_X / RollRate_X .. names: a slow wave per element. They
        # must drive the IMU elements only; Central_AccLG_X taken for Central X would fail every check.
        imu_dir = tmp / "imu_only"
        imu_dir.mkdir()
        imu_lsb = {}
        for k, e in enumerate(imu["elements"]):
            imu_lsb[e["name"]] = np.rint(4000 * np.sin(2 * np.pi * np.arange(len(pulse)) * dt / (3000 + 1000 * k)))
            for folder in (curve_dir, imu_dir):
                np.savetxt(folder / f"SET_LSB_{e['curve'][1]}_2k_01-Jan-2026.txt", imu_lsb[e["name"]], fmt="%d")
        (curve_dir / "set_summary.txt").write_text("front crash set\n")

        def ecu(flip=(), scale=None, imu_flip=()):
            """Record 1 of a front crash on an AUTOSAR ECU: X negative, T0 by the 0.8 km/h rule."""
            g = {name: values / next(s for s in profile["sensors"] if s["name"] == name)["lsb_per_g"] for name, values in lsb.items()}
            t0 = int(r1_edges(g["Central X"], 40, KMH_PER_G_MS * dt, 0.8)[0])
            responses, seen = {}, {}
            for s in profile["sensors"]:
                at_ecu = g.get(s["name"], np.zeros(len(pulse))) * (-1.0 if s["axis"] == "X" else 1.0)
                at_ecu = seen[s["name"]] = at_ecu * (-1.0 if s["name"] in flip else 1.0) * ((scale or {}).get(s["name"], 1.0))
                stored = quantise(window(at_ecu, t0 - pre, n), s, profile["max_counts"])[1]
                responses[s["did"][0]] = bytes((stored / s["g_per_count"] + profile["zero_code"]).astype(int).tolist())
            record = bytearray(600)
            for e in imu["elements"]:
                for k in range(imu["samples"]):    # one sample inside each sampling interval
                    label = imu["start_ms"] + k * imu["step_ms"]
                    value = imu_lsb[e["name"]][t0 + round((label + (100 if label <= 0 else 250)) / dt)] * e["sign"] / e["lsb_per_unit"]
                    counts = round(value / e["scale"]) * (-1 if e["name"] in imu_flip else 1)
                    record[e["start"] - 4 + 2 * k:e["start"] - 2 + 2 * k] = (counts & 0xFFFF).to_bytes(2, "big")
            for axis in profile["delta_v"]["axes"]:
                dv = np.concatenate([[0.0], np.cumsum(seen[axis["sensor"]])]) * KMH_PER_G_MS * dt * axis["report_sign"]
                series = [dv[min(t0 + i * 20, len(pulse))] - dv[t0] for i in range(26)]
                record[axis["series_start"] - 4:axis["series_start"] + 22] = [int(round(v)) + 100 for v in series]
                span = dv[t0:t0 + 601] - dv[t0]
                record[axis["max_byte"] - 4] = int(round(span[np.argmax(np.abs(span))])) + 100
            responses["0455"] = bytes(record)
            return responses

        def can_trace(responses):
            lines, t = [], 10.0
            for did, body in responses.items():
                message = bytes([0x62]) + bytes.fromhex(did) + body
                frames = [bytes([0x10 | len(message) >> 8, len(message) & 0xFF]) + message[:6]]
                frames += [bytes([0x20 | (i + 1) & 0xF]) + message[6 + 7 * i:13 + 7 * i] for i in range((len(message) - 6 + 6) // 7)]
                lines.append(f"{t:.6f}\tCanFd 2  TX  l=8,  id=00000730, 03 22 {did[:2]} {did[2:]} AA AA AA AA")
                for i, frame in enumerate(frames):
                    t += 0.001
                    lines.append(f"{t:.6f}\tCanFd 2  RX  l=8,  id=00000738, " + frame.ljust(8, b"\xaa").hex(" ").upper())
                    lines.append(f"{t:.6f}\tCan   3  RX  l=8,  id=000002C0, 21 00 00 00 01 01 00 C9")
                    if i == 0:
                        lines.append(f"{t:.6f}\tCanFd 2  TX  l=8,  id=00000730, 30 00 00 AA AA AA AA AA")
            return "\n".join(lines)

        spaced = lambda body, did: f"62 {did[:2]} {did[2:]} " + body.hex(" ").upper()
        forms = {
            "trace.txt": can_trace,
            "report.txt": lambda r: "\n".join(f"Read DID {d}\nRequest: 22 {d[:2]} {d[2:]}\nResponse: {spaced(b, d)}\nDecoded ok" for d, b in r.items()),
            "report.html": lambda r: "<html><table>" + "".join(
                f"<tr><td>{d}</td>" + "".join(f"<td>{x:02X}</td>" for x in bytes([0x62]) + bytes.fromhex(d) + b) + "</tr>" for d, b in r.items()) + "</table></html>",
            "report.xml": lambda r: "<log>" + "".join(
                f'<resp did="{d}" data="{",".join(f"0x{x:02X}" for x in bytes([0x62]) + bytes.fromhex(d) + b)}"/>' for d, b in r.items()) + "</log>",
            "raw.log": lambda r: "\n".join((bytes([0x62]) + bytes.fromhex(d) + b).hex() for d, b in r.items()),
        }
        for name, build in forms.items():
            (tmp / name).write_text(build(ecu()))
            verdict, text, out = run([tmp / name], curve_dir, crashes=["front"])
            assert verdict == "PASS", f"{name}: {verdict}\n{text}"
            assert text.count("PASS  IMU ") == len(imu["elements"]) and "ignored: low-g" not in text, text
            assert (out / "EDR_sensor_comparison.xlsx").stat().st_size > 20000
            decoded = np.loadtxt(next((out / "decoded_lsb").glob("EDR_R1_0460_*")))
            assert decoded.min() == -480 and decoded.max() == 0, (decoded.min(), decoded.max())

        def lines_of(text, word):
            return [line for line in text.splitlines() if word in line]

        (tmp / "flip.txt").write_text(forms["report.txt"](ecu(flip={"Central X"})))
        verdict, text, _ = run([tmp / "flip.txt"], curve_dir, crashes=["front"])
        assert verdict == "FAIL" and "FAIL" in lines_of(text, "Central X")[0] and "0 samples out" in lines_of(text, "Central X ")[0], text
        assert "FAIL" in lines_of(text, "Delta-V Longitudinal")[0] and "PASS" in lines_of(text, "Front Left X")[0], text
        (tmp / "gain.txt").write_text(forms["report.txt"](ecu(scale={"Front Left X": 0.5})))
        verdict, text, _ = run([tmp / "gain.txt"], curve_dir, crashes=["front"])
        row = lines_of(text, "Front Left X")[0]
        assert verdict == "FAIL" and "FAIL" in row and "polarity - (expected -)" in row and "PASS" in lines_of(text, "Central X ")[0], text
        # Placement expectation from a JSON file: Front Left X mounted the other way round.
        (tmp / "pol.json").write_text(json.dumps({"name": "test", "expect": {"front": {"Front Left X": "+"}}}))
        (tmp / "placed.txt").write_text(forms["report.txt"](ecu(flip={"Front Left X"})))
        assert run([tmp / "placed.txt"], curve_dir, crashes=["front"])[0] == "FAIL"
        assert run([tmp / "placed.txt"], curve_dir, crashes=["front"], polarity=tmp / "pol.json")[0] == "PASS"
        # Several crashes in one record: front+left also expects Y negative (the simulated ECU has Y as
        # the file), front+rear contradicts on X so X is not judged, mixed judges no polarity at all.
        verdict, text, _ = run([tmp / "report.txt"], curve_dir, crashes=["front+left"])
        assert verdict == "FAIL" and "FAIL" in lines_of(text, "Central Y")[0] and "PASS" in lines_of(text, "Central X ")[0], text
        assert run([tmp / "flip.txt"], curve_dir, crashes=["front+rear+rollover"])[0] == "PASS"
        assert run([tmp / "flip.txt"], curve_dir, crashes=["front+mixed"])[0] == "PASS"
        # Delta-V is judged in the NHTSA sign of the crash, apart from the sensor polarity: the
        # simulated record holds a negative lateral delta-V, a left-side crash must give a positive one.
        verdict, text, _ = run([tmp / "report.txt"], curve_dir, crashes=["left"])
        row = lines_of(text, "Delta-V Lateral")[0]
        assert "FAIL" in row and "polarity - (expected + (NHTSA))" in row, text
        assert "polarity - (expected - (NHTSA))" in lines_of(run([tmp / "report.txt"], curve_dir, crashes=["front"])[1], "Delta-V Longitudinal")[0]
        # IMU element recorded with the wrong sign.
        (tmp / "imu.txt").write_text(forms["report.txt"](ecu(imu_flip={"YAW_RATE"})))
        verdict, text, _ = run([tmp / "imu.txt"], curve_dir, crashes=["front"])
        assert verdict == "FAIL" and "FAIL" in lines_of(text, "IMU YAW_RATE")[0] and text.count("PASS  IMU ") == 5, text
        # Rollover: only the event record in the log, no high-g pulse; T0 is placed with the IMU elements.
        (tmp / "roll.txt").write_text(forms["report.txt"]({"0455": ecu()["0455"]}))
        verdict, text, _ = run([tmp / "roll.txt"], imu_dir, crashes=["rollover"])
        assert verdict.startswith("INCOMPLETE") and "placed with the IMU" in text and text.count("PASS  IMU ") == 6, text
        # Every project folder: loadable (or blocked with a reason), DIDs used once.
        for name in project_names():
            try:
                other = load_profile(name)[0]
            except ValueError as error:
                assert "not known" in str(error), error
                continue
            dids = [d for s in other["sensors"] for d in s["did"]] + other["records"]
            assert other["sensors"] and len(dids) == len(set(dids)), name
        # A 2 ms project (M110) on the 0.5 ms curves: the ECU keeps every 4th curve sample, here from
        # an odd one, so the T0 must be found on the curve grid and not on the 2 ms grid.
        slow = load_profile("m110")[0]
        k, t0 = stride(slow), 11211
        lines = []
        for s in slow["sensors"]:
            at_ecu = lsb.get(s["name"], np.zeros(len(pulse))) / s["lsb_per_g"] * (-1.0 if s["axis"] == "X" else 1.0)
            stored = quantise(at_ecu[t0 - slow["pre_t0_samples"] * k + k * np.arange(slow["samples"])], s, slow["max_counts"])[1]
            lines.append(spaced(bytes((stored / s["g_per_count"] + slow["zero_code"]).astype(int).tolist()), s["did"][0]))
        (tmp / "slow.txt").write_text("\n".join(lines))
        verdict, text, _ = run([tmp / "slow.txt"], curve_dir, project="m110", crashes=["front"])
        assert k == 4 and verdict.startswith("INCOMPLETE") and "T0 = curve sample 11211;" in text and "FAIL" not in text, text
        # Two files for one sensor must stop the run.
        np.savetxt(curve_dir / "OTHER_LSB_Central_Acc_X_2k_02-Jan-2026.txt", pulse, fmt="%d")
        try:
            run([tmp / "report.txt"], curve_dir, crashes=["front"])
            raise AssertionError("two Central X files were accepted")
        except ValueError as error:
            assert "Two curve files for Central X" in str(error)
    print("self-test passed: 5 log forms, polarity / magnitude / placement faults, combined and mixed crash types, "
          "IMU elements (low-g curves, wrong sign, rollover T0), duplicate curve")


def main():
    parser = argparse.ArgumentParser(description="Decode the EDR sensor DIDs from a log and check them against the input LSB curves.")
    parser.add_argument("--log", nargs="+", help="log file(s): CAN trace, txt, ARIA log, html, xml")
    parser.add_argument("--curves", help="folder with the input LSB curves")
    parser.add_argument("--crash", default="", help="crashes in each record: records separated by ',', several crashes in one record joined "
                                                       "with '+', e.g. front  |  front,left  |  front+left+rollover,mixed  "
                                                       "(front rear left right rollover mixed, or a type of the polarity file)")
    parser.add_argument("--polarity", help="polarity expectation JSON (default: AUTOSAR)")
    parser.add_argument("--project", default=DEFAULT_PROJECT, help=f"project folder under projects/: {', '.join(project_names())} "
                                                                   f"(default {DEFAULT_PROJECT}), or the path of a profile JSON")
    parser.add_argument("--out", help="output folder (default: <log name>_edr_check beside the log)")
    parser.add_argument("--pick", choices=("last", "first"), default="last", help="which response of a DID read several times")
    parser.add_argument("--curve", action="append", default=[], metavar="SENSOR=FILE", help="name the curve file of a sensor yourself")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if not args.log and not args.curves:
        return gui()
    if not args.log or not args.curves:
        parser.error("--log and --curves are both needed")
    try:
        verdict, text, _ = run(args.log, args.curves, args.out, args.project, args.polarity,
                               [c.strip() for c in args.crash.split(",")] if args.crash else [], args.pick,
                               dict(item.split("=", 1) for item in args.curve))
    except (ValueError, OSError) as error:
        sys.exit(f"STOPPED: {error}")
    print(text)
    sys.exit(0 if verdict == "PASS" else 1)


if __name__ == "__main__":
    main()
