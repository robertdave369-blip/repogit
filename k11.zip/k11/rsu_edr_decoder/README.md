# RSU / central sensor EDR decoder

Standalone tool: checks that the EDR recorded every sensor as the input LSB curve fed to it.
Needs Python 3 with `numpy` and `xlsxwriter` (`py -3 -m pip install numpy xlsxwriter`); nothing
from the framework is imported.

## Run

- Double click `run_rsu_edr_decoder.bat` (or `py -3 rsu_edr_decoder.py`): a window asks for the
  project, the log file(s), the input-curve folder, the crashes in each record (tick-boxes) and the polarity
  expectation.
- Command line:
  `py -3 rsu_edr_decoder.py --log run.txt --curves <curve folder> --project m210 --crash front,left --polarity projects/m210/polarity_bench.json`
  (`--crash`: records separated by `,`, several crashes in one record joined with `+`:
  `front+left+rollover,mixed`)
- `py -3 rsu_edr_decoder.py --self-test` proves the tool on a simulated recording (5 log forms,
  planted polarity / magnitude faults, combined and mixed crash types, IMU elements, a rollover
  record, a duplicate curve).

Exit code 0 = PASS, 1 = anything else.

## What it does

1. **Decodes the log.** Any text log: a CAN trace (ARIA `id=..` lines, Vector asc, PCAN trc; the
   ISO-TP multi-frame responses are reassembled, CAN and CAN FD), or a txt / ARIA / html / xml
   log that prints the response as `62 04 60 7F ..`, `0x62,0x04,..` or `6204607F..` (also one
   byte per html cell). Several logs can be given (record 1 and record 2 read separately). A DID
   read more than once: the last response is used (`--pick first` for the first). A response of
   the wrong length is never used; the `Files` sheet says so.
2. **Identifies the curves.** A file belongs to a sensor only when the sensor part of its name
   (between `_LSB_` and `_2k_`) *equals* a curve name of the profile. `Central_AccLG_X/Y/Z`,
   `Central_RollRate_X` / `PitchRate_Y` / `YawRate_Z` and `Panasonic_imu_axis1..6` (the Panasonic
   IMU) belong to the IMU elements of the record only and can never be taken for the high-g
   `Central_Acc_X/Y`. Two files for one sensor stop the run. `--curve "Central X=<file>"`
   names a file by hand. A sensor without a file is expected at 0 g.
3. **Finds the ECU's T0** in the curve: the sample at which all sensor DIDs of the record fit
   best (whole curve searched, so record 2 finds its own event). It is reported against the
   0.8 km/h rule T0 of the central curves.
4. **Checks each sensor**: polarity (against the expectation), peak within one EDR count, every
   sample within one count of the input one sample either side, `0xFF` where the curve marks the
   sensor faulty. Polarity and magnitude are judged separately: a sensor recorded mirrored shows
   `polarity FAIL` with 0 samples out of tolerance.
5. **Checks delta-V** of records `0455` / `045B` (series, maximum; time of maximum reported)
   against the central X / Y curve summed from T0, within 1 km/h.
6. **Decodes the IMU elements** of each record (angular rate X / Y / yaw, longitudinal / lateral /
   vertical acceleration, 17 samples from -5 s to +3 s) whenever the record is in the log, and
   checks them where an IMU curve is in the folder: a sample passes when it lies between the
   lowest and highest input of the interval in which the ECU can take it (500 ms tick). A
   rollover has no high-g pulse: T0 is then placed with the IMU elements (4 ms grid), also when
   the log holds the record but no sensor DID.

## Polarity expectation

Two conventions apply, and the tool keeps them apart:

- **Sensor recording (the sensor DIDs): AUTOSAR** vehicle axis, or your polarity JSON.
- **Delta-V of the event record: NHTSA 49 CFR Part 563** (SAE J211), fixed, never taken from the
  polarity JSON: front crash longitudinal `-`, rear `+`, left-side crash lateral `+` (the
  vehicle is pushed to the right), right-side crash lateral `-`. With several crashes ticked the
  sign is judged when they agree; with `mixed`, `rollover` or no crash type the expected sign
  follows the central sensor as recorded (longitudinal as measured, lateral negated).

Per crash type and sensor, one of: `+` / `-` (sign of the main pulse at the ECU), `curve` (as
the file), `inverted` (file negated), `any` (recorded, not judged).

- Built in: **AUTOSAR** vehicle axis: front X `-`, rear X `+`, left Y `-`, right Y `+`, for every
  sensor of that axis; other axes `any`. No crash type given: nothing is judged.
- **Several crashes in one record** (tick more than one, `front+left`): a sensor is judged when
  the ticked crashes that have a rule for it agree, and not judged when they contradict
  (`front+rear` on X).
- **`mixed`**: a custom curve that fires every loop from all sides. No polarity is judged
  (magnitude, delta-V and IMU still are); the recorded polarity is still shown. It overrides the
  other ticks. A polarity JSON may define its own `mixed` rules.
- **`rollover`**: has no high-g polarity rule; tick it together with the others as information.
  The IMU elements are checked for every record regardless of the tick.
- A sensor mounted differently: window button **Edit / save** (table of sensor x crash type,
  **Save as JSON**), load it again with **Load JSON** or `--polarity file.json`. A file only
  needs the sensors that differ; the rest stays AUTOSAR.
- `projects/m210/polarity_bench.json`: the M210 bench as wired (ARIA inversion flags of
  `M210_RSU_CHANNEL_SPECS`). With it, use the crash type of the *first* event for both records
  of a merged multi-event set.

## Output (`<log name>_edr_check` beside the log, or `--out`)

- `EDR_sensor_comparison.xlsx`: `Summary` (verdict per sensor, delta-V and IMU element), `IMU` (table and charts), `Graphs` (input
  against EDR, one chart per sensor and record), `DeltaV` (table and charts), `R1 data` /
  `R2 data` (time, input g, input as stored, EDR g, raw byte), `Files` (which file was taken for
  which sensor and why the others were ignored; which DID was decoded from where).
- `decoded_lsb/`: the recording of every sensor as an LSB curve in the input format
  (`EDR_R1_0460_LSB_Central_Acc_X_2k_decoded.txt`), signed as the ECU saw it; `0xFF` samples are
  written 0.

## Projects

One folder per project under `projects/`, each with its `profile.json` (and any polarity JSON
you save for that project). Choose it in the window or with `--project`.

| Folder | EDR sensor sampling | Samples per DID | Sensors | Delta-V | IMU elements |
|---|---|---|---|---|---|
| `m210` | 0.5 ms | 521 | 21 | yes | yes |
| `m314` | 0.5 ms | 521 | 23 | yes | yes |
| `u171` | 0.5 ms | 521 | 12 | yes | yes |
| `z121` | 0.5 ms | 521 | 14 | yes | yes |
| `upp_ev` | 0.5 ms | 521 | 13 | no | no |
| `m110` | 2 ms | 131 (assumed) | 21 | yes | yes |
| `w616` | 2 ms | 131 (assumed) | 14 | yes | yes |
| `w610` | 2 ms | 131 (assumed) | 21 | no | no |
| `d101` | not known | - | - | - | - |

- Sampling rate, applicable sensors, DIDs, range and resolution: sheet `EDR Sensor Data` of
  `M312_M112_M210_SRS_V3.4_DIAG_RE.xlsx` (row "Followed Sampling Rate" and the Yes / NA column
  of the project). Delta-V and IMU byte positions: the project's `edr_config.py`.
- **2 ms projects.** The curves stay at 0.5 ms; the ECU is taken to keep every 4th curve sample
  starting from any of them, and T0 is found on the 0.5 ms grid. The sheet gives the byte layout
  only for 0.5 ms, so 131 samples (-10 ms to +250 ms) is an assumption: a DID of another length
  is reported in the `Files` sheet as `NOT USED` with its real length, then correct `samples` /
  `pre_t0_samples` in the profile.
- `upp_ev` and `w610`: their `edr_config.py` has no usable delta-V / IMU entries, so only the
  sensor DIDs are checked.
- `d101` is not in the sheet: its profile only says so and the tool stops with that message.
  Copy another project's `profile.json` there and correct it from the D101 specification.
- `m314` and `z121` also record the door pressure sensors (0466 / 0465); they have no g
  conversion and are listed in the profile under `not_decoded`. The M314 10 ms DIDs (04AB..04B2,
  -1 s to 9 s) have no range or resolution in the sheet and are not decoded either.
- A new project: a new folder with a `profile.json`.

## Not verified

- IMU: the curve scaling (50 LSB per deg/s, 2000 LSB per g), the 1:1 axis map with sign +1, and
  that the `Central_AccLG_*` / `*Rate_*` files use the same counts as `Panasonic_imu_axis*` are
  assumptions carried in each `profile.json` (`imu`); confirm them on the bench. No IMU polarity
  expectation per crash type exists: the sign is the profile's.

- Proven only against simulated recordings (self-test and the project curve sets); no bench log
  with sensor DIDs was available. The asc / trc readers were tried on hand-made lines.
- Only the M210 conversion (curve LSB per g) is taken from ECU source; for the other projects it
  is inferred from the sensor range (480 / range for an RSU, 2048 / range for the central
  sensors). Whether a 2 ms ECU stores every 4th sample or an average is not known.
- A log that wraps one response over several lines with an address or timestamp at each line
  start is not reassembled (reported as wrong length).
