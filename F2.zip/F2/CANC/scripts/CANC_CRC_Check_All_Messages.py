# Author: Kris
#


#
# Test case  : CANC_CRC_Check_All_Messages (additional check, not a workbook case)
# Objective  : Verify that the CRC signal of every CAN-C frame that carries one, sent by the ECU
#              or simulated by the bench, is the CRC in use computed over the bytes canc_config
#              gives for that frame.
# Automation : Automatic
# Note       : Input: the CRC in use, as a CANC_CRC_CATALOGUE name or alias on the command line,
#              e.g. 'py -3.14 CANC_CRC_Check_All_Messages.py CRC-16/ARC'; each name replaces the
#              CANC_CRC_IN_USE entry of its width (16-bit: the CAN-FD frames, 8-bit: SRS1_20).
#              Run without one, the script checks CANC_CRC_IN_USE.
# Note       : The frames come from the configuration: every MAH_CAN_SIGNAL_DEFS signal named
#              *_CRC (13 CAN-FD frames and SRS1_20 on HS-CAN, as in the DBCs). CANC_CRC_FRAMES
#              gives the bytes each CRC covers and the frame's E2E Data ID; the CRC must equal
#              the selected CRC of those bytes in every logged frame.
# Note       : CAN-FD frames carry the CRC in bytes 58-59, the alive counter in 60, the SecOC
#              freshness value in 61 and the truncated MAC in 62-63. The CRC is E2E Profile 5:
#              CRC-16/CCITT-FALSE over bytes 0-57 and 60, then the Data ID low byte first, and
#              the Data ID is the frame's CAN identifier - every frame of the 2026-10-15 bench
#              logs matches (674,172 SRS1_FD_10 frames from the ECU, all bench-simulated frames
#              outside the CRC-error cases). CANC_CRC_FRAMES holds the covered bytes and Data ID
#              of each frame.
# Note       : Where a frame's CRC differs, the script lists the catalogued CRCs of the same
#              width that do match its first frames over the configured bytes, the bytes before
#              the CRC and every byte but the CRC, which shows the CRC the frame actually uses.
# Note       : Bench-simulated frames carry the CRC the bench computes (customer DLL); the ECU
#              accepting it shows in the no-DTC precondition. The SecOC MAC and freshness value
#              are not checked.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRC_CATALOGUE,
    CANC_CRC_FRAMES,
    CANC_CRC_IN_USE,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = ''
    tc_name = 'CANC_CRC_Check_All_Messages'
    tc_desc = (
        'Verify that the CRC signal of every CAN-C frame that carries one, sent by the ECU or '
        'simulated by the bench, is the CRC in use computed over the bytes canc_config gives '
        'for that frame.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    crc_in_use = {}
    crc_unknown = []
    for crc_request in list(CANC_CRC_IN_USE.values()) + sys.argv[1:]:
        crc_request_key = str(crc_request).strip().upper().replace('_', '-').replace(' ', '-')
        crc_name = next((name for name, spec in CANC_CRC_CATALOGUE.items()
                         if crc_request_key in [label.upper().replace('_', '-').replace(' ', '-')
                                                for label in (name,) + tuple(spec['aliases'])]), None)
        if crc_name is None:
            crc_unknown.append(str(crc_request))
        else:
            crc_in_use[CANC_CRC_CATALOGUE[crc_name]['width']] = crc_name
    if crc_unknown:
        print('Known CRC names: ' + ', '.join(CANC_CRC_CATALOGUE))
    crc_keys = sorted(key for key in MAH_CAN_SIGNAL_DEFS if key.upper().endswith('_CRC'))
    crc_frame_ids = sorted({MAH_CAN_SIGNAL_DEFS[key]['frame_ID'] for key in crc_keys})
    crc_widths_missing = sorted({MAH_CAN_SIGNAL_DEFS[key]['bit_length'] for key in crc_keys} - set(crc_in_use))
    crc_capture_ms = int(CANC_PERIODICITY_SAMPLE_FRAMES
                         * max((MAH_CAN_SIGNAL_DEFS[key]['periodicity'] for key in crc_keys), default=0) * margin)
    crc_outcome = {}

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [*crc_frame_ids]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            ('signals named *_CRC in MAH_CAN_SIGNAL_DEFS', crc_keys or None),
            ('a CANC_CRC_CATALOGUE entry for ' + ', '.join(crc_unknown), None if crc_unknown else True),
            ('a CRC in use for the ' + ', '.join(f'{width}-bit' for width in crc_widths_missing) + ' CRC signals', None if crc_widths_missing else True),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        for crc_key in crc_keys:
            crc_def = MAH_CAN_SIGNAL_DEFS[crc_key]
            if not crc_def.get('ecu_generated'):
                CAN.PeriodicEnableFrame(crc_def['bus'], crc_def['frame'])
                CAN.ReloadDefaultPeriodicFrame(crc_def['bus'], crc_def['frame'])
                CAN.DynamicEnableSignal(crc_def['bus'], crc_def['frame'], crc_def['signal'])
        fault_free_profile()
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Known-answer check of the CRC in use')
        for crc_width, crc_name in sorted(crc_in_use.items()):
            crc_spec = CANC_CRC_CATALOGUE[crc_name]
            crc_check = calculate_crc(b'123456789', f"crc{crc_width}", polynomial=crc_spec['poly'],
                                      initial=crc_spec['init'], final_xor=crc_spec['xorout'],
                                      reflect_in=crc_spec['refin'], reflect_out=crc_spec['refout'])
            RESULT.InterpretEqualResult(f"{crc_name} ({crc_width}-bit) of the ASCII bytes 123456789",
                                        f"0x{crc_check:0{crc_width // 4}X}", f"0x{crc_spec['check']:0{crc_width // 4}X}")
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Log every frame with a CRC signal on both buses')
        crc_ids = crc_frame_ids
        crc_file = os.path.splitext(log_path)[0] + '_crc_frames.txt'
        crc_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_crc_frames', filepath=crc_file,
            listOption=crc_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(crc_capture_ms)
        CAN.StopLoggingToFile(crc_logger)
        crc_frames = []
        if os.path.isfile(crc_file):
            with open(crc_file, encoding='utf-8', errors='replace') as crc_log:
                crc_fields = [line.split(',', 2) for line in crc_log if ' id=' in line and line.count(',') >= 2]
            crc_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in crc_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(crc_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        crc_frames = [frame_data for frame_data in crc_frames if frame_data.id in crc_ids]
        RESULT.InsertComment(f"{len(crc_frames)} frames logged in {crc_capture_ms} ms")
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Check the CRC of every frame against the CRC in use')
        for crc_key in crc_keys:
            crc_def = MAH_CAN_SIGNAL_DEFS[crc_key]
            crc_frame = crc_def['frame']
            crc_width = crc_def['bit_length']
            crc_digits = crc_width // 4
            crc_name = crc_in_use[crc_width]
            crc_spec = CANC_CRC_CATALOGUE[crc_name]
            crc_layout = CANC_CRC_FRAMES.get(crc_frame)
            crc_source = 'sent by the ECU' if crc_def.get('ecu_generated') else 'simulated by the bench'
            aria_reports.add_group(f"{crc_frame} (0x{crc_def['frame_ID']:X}, {crc_source}): "
                                   f"{crc_def['signal']} against {crc_name}")
            if crc_layout is None or crc_key not in CAN_SIGNAL_START_BIT:
                RESULT.LogCustomAction(f"{crc_frame} CRC layout", "In CANC_CRC_FRAMES and CAN_SIGNAL_START_BIT",
                                       "Missing: the frame is not checked", False)
                crc_outcome[crc_frame] = 'not checked (no CRC layout in the configuration)'
                aria_reports.close_group()
                continue
            crc_start = CAN_SIGNAL_START_BIT[crc_key]
            crc_byteorder = 'big' if crc_def.get('byte_order') == 'big_endian' else 'little'
            crc_data_id = crc_layout.get('data_id')
            crc_data_id_bytes = b'' if crc_data_id is None else bytes([crc_data_id & 0xFF, (crc_data_id >> 8) & 0xFF])
            crc_rows = [(bytes(frame_data.payload),
                         b''.join(bytes(frame_data.payload[start:end]) for start, end in crc_layout['data_bytes'])
                         + crc_data_id_bytes,
                         extract_can_signal(frame_data.payload, crc_start, crc_width, byteorder=crc_byteorder))
                        for frame_data in crc_frames if frame_data.id == crc_def['frame_ID']]
            crc_checked = [row + (calculate_crc(row[1], f"crc{crc_width}", polynomial=crc_spec['poly'],
                                                initial=crc_spec['init'], final_xor=crc_spec['xorout'],
                                                reflect_in=crc_spec['refin'], reflect_out=crc_spec['refout']),)
                           for row in crc_rows]
            crc_bad = [row for row in crc_checked if row[3] != row[2]]
            RESULT.InsertComment(f"CRC over bytes {crc_layout['data_bytes']} (end exclusive)"
                                 + ("" if crc_data_id is None else f", then Data ID 0x{crc_data_id:04X} low byte first"))
            RESULT.InterpretEqualResultRange(f"{crc_frame} frames logged", len(crc_rows),
                                             CANC_FRAME_PRESENCE_CYCLES, float('inf'))
            RESULT.InterpretEqualResult(
                f"{crc_frame} frames whose {crc_def['signal']} is not the {crc_name} of the covered bytes "
                f"({len(crc_bad)} of {len(crc_rows)})",
                [f"received 0x{row[2]:0{crc_digits}X}, computed 0x{row[3]:0{crc_digits}X}" for row in crc_bad[:3]], [])
            crc_outcome[crc_frame] = ('not logged' if not crc_rows else 'conforms' if not crc_bad
                                      else f"differs in {len(crc_bad)} of {len(crc_rows)} frames")
            if crc_bad:
                RESULT.InsertComment(f"First frame that differs: {crc_bad[0][0].hex(' ').upper()}")
                crc_first = crc_start // 8
                crc_last = (crc_start + crc_width - 1) // 8
                crc_sample = crc_rows[:CANC_FRAME_PRESENCE_CYCLES]
                crc_coverages = {}
                for crc_label, crc_blocks in (
                        ('the configured bytes', [row[1] for row in crc_sample]),
                        (f"bytes 0-{crc_first - 1}", [row[0][:crc_first] for row in crc_sample]),
                        ('every byte but the CRC', [row[0][:crc_first] + row[0][crc_last + 1:] for row in crc_sample])):
                    if crc_blocks not in crc_coverages.values():
                        crc_coverages[crc_label] = crc_blocks
                crc_matches = [f"{name} over {label}" for label, blocks in crc_coverages.items()
                               for name, spec in CANC_CRC_CATALOGUE.items()
                               if spec['width'] == crc_width and all(
                                   calculate_crc(block, f"crc{crc_width}", polynomial=spec['poly'], initial=spec['init'],
                                                 final_xor=spec['xorout'], reflect_in=spec['refin'],
                                                 reflect_out=spec['refout']) == row[2]
                                   for block, row in zip(blocks, crc_sample))]
                RESULT.InsertComment(
                    f"Catalogued CRCs that match the first {len(crc_sample)} frames: " + "; ".join(crc_matches)
                    if crc_matches else
                    f"No catalogued {crc_width}-bit CRC matches the first {len(crc_sample)} frames over "
                    + ", ".join(crc_coverages) + ": the CRC may fold in an E2E Data ID (data_id in "
                    "CANC_CRC_FRAMES) or cover other bytes.")
            aria_reports.close_group()
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Summary')
        RESULT.InsertComment("CRC in use: " + ", ".join(f"{width}-bit {name}" for width, name in sorted(crc_in_use.items())))
        RESULT.InterpretEqualResult(
            f"Frames whose CRC is not the CRC in use (of {len(crc_outcome)} frames with a CRC signal)",
            sorted(f"{frame}: {outcome}" for frame, outcome in crc_outcome.items() if outcome != 'conforms'), [])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
