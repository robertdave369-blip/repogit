# Author: Kris
#


#
# Test case  : CAN_BUSOFF_6 (Codebeamer ID 35721112)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : 1. To check the behaviour of ACU during busoff condition. 2. To test no CAN
#              messages diagnosis when Bus OFF is present.(HS CAN & FD CAN BOTH ARE BUS OFF)
# Automation : Semi-automatic (operator creates and removes the bus-off)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_BUS_OFF_DTC,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35721112'
    tc_name = 'CAN_BUSOFF_6'
    tc_desc = (
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages '
        'diagnosis when Bus OFF is present.(HS CAN & FD CAN BOTH ARE BUS OFF)'
    )
    automation = 'Semi-automatic (operator creates and removes the bus-off)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create bus-off on both buses - no CAN communication')
        RESULT.InsertComment('OPERATOR ACTION: Short CAN-H to CAN-L on both the CAN-FD and the HS-CAN bus and keep the short.')
        print('OPERATOR ACTION: Short CAN-H to CAN-L on both the CAN-FD and the HS-CAN bus and keep the short.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_both.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_both', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResult(
            f"{fd_frame} is not transmitted (frames in the window)",
            presence2_fd_count, 0)
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence2_hs_count, 0)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Stop, then restart, all bench CAN messages')
        CAN.PeriodicDisableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicDisableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Remove the bus-off and read DTC')
        RESULT.InsertComment('OPERATOR ACTION: Remove the CAN-H to CAN-L short on both the CAN-FD and the HS-CAN bus.')
        print('OPERATOR ACTION: Remove the CAN-H to CAN-L short on both the CAN-FD and the HS-CAN bus.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        Wait(busoff_settle_ms)
        Read_DTC(
            'Bus-off DTCs healed',
            " ".join([Read_DTC_Resp_CANC,
                      CAN_BUS_OFF_DTC['CANFD'], DTC_status['DTC_healed'],
                      CAN_BUS_OFF_DTC['HSCAN'], DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Clear DTC')
        Clear_DTC_Info()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Read_DTC('No DTC', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Check communication on both buses')
        presence6_ids = [fd_id, hs_id]
        presence6_file = os.path.splitext(log_path)[0] + '_comm_restored.txt'
        presence6_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_comm_restored', filepath=presence6_file,
            listOption=presence6_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence6_logger)
        presence6_frames = []
        if os.path.isfile(presence6_file):
            with open(presence6_file, encoding='utf-8', errors='replace') as presence6_log:
                presence6_fields = [line.split(',', 2) for line in presence6_log if ' id=' in line and line.count(',') >= 2]
            presence6_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence6_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence6_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence6_frames = [frame_data for frame_data in presence6_frames if frame_data.id in presence6_ids]
        presence6_fd_count = sum(1 for frame_data in presence6_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence6_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence6_hs_count = sum(1 for frame_data in presence6_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence6_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
