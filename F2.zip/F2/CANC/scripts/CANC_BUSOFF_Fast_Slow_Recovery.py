# Author: Kris
#


#
# Test case  : CANC_BUSOFF_Fast_Slow_Recovery (additional check, not a workbook case)
# Objective  : Verify the ECU's recovery from a bus-off: it retries BUSOFF_FAST_RECOVERY_COUNT
#              times after the fast recovery time, then after the slow recovery time for as long
#              as the bus-off lasts (bus-off case 4), the bus-off being put on the bus by the
#              bench relay.
# Automation : Automatic
# Note       : The bench loadbox puts the bus-off on: CAN_BUS_OFF_RELAY_FUNCTION (CAN1) set to
#              CAN_BUS_OFF_RELAY_LOAD (CAN_BUSS_OFF) with the shared ARIA.AFT_iLoadBoxWrapper,
#              back to CAN_BUS_OFF_RELAY_RESTORE_LOAD (INHERENT) to end it (M314 ARIA relay map,
#              .github/agents/aria_agent.md section 5.1). Which bus CAN1 carries is not recorded
#              anywhere, so the script finds it first from the ECU frame that stops.
# Note       : Retries cannot be seen while the bus is shorted, so the script releases the bus-
#              off at set hold times and times the release to the first ECU frame: that is the
#              time to the ECU's next retry. Expected with canc_config: 50 ms for each of the
#              BUSOFF_FAST_RECOVERY_COUNT probes inside the fast recovery, then 450, 350, 250,
#              150 and 50 ms across the first slow interval; each within 10 % of the retry
#              interval and CAN_BUS_OFF_RELAY_SWITCH_MS, the upper limit plus two frame periods.
#              CAN_BUS_OFF_RELAY_SWITCH_MS (10 ms) is an assumed relay switching allowance to
#              confirm on the bench.
# Note       : Bus-off case 4 asks for a CAN stress tool and a bus-off held for 2000 s, with the
#              retries read from the CAN log; this script checks the same retry pattern (count,
#              fast and slow time) in about a minute, and stays an additional check next to that
#              case.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_BUS_OFF_DTC,
    CAN_BUS_OFF_PROBE_SETTLE_MS,
    CAN_BUS_OFF_RELAY_FUNCTION,
    CAN_BUS_OFF_RELAY_LOAD,
    CAN_BUS_OFF_RELAY_RESTORE_LOAD,
    CAN_BUS_OFF_RELAY_SWITCH_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = ''
    tc_name = 'CANC_BUSOFF_Fast_Slow_Recovery'
    tc_desc = (
        "Verify the ECU's recovery from a bus-off: it retries BUSOFF_FAST_RECOVERY_COUNT "
        'times after the fast recovery time, then after the slow recovery time for as long as '
        'the bus-off lasts (bus-off case 4), the bus-off being put on the bus by the bench '
        'relay.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    fast_holds_ms = [round((index + 0.5) * BUSOFF_FAST_RECOVERY_TIME_MS) for index in range(BUSOFF_FAST_RECOVERY_COUNT)]
    slow_start_ms = BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
    slow_holds_ms = [round(slow_start_ms + (index + 0.5) * BUSOFF_SLOW_RECOVERY_TIME_MS / 5) for index in range(5)]
    # (phase, hold, retry interval, expected time from the release to the next retry)
    probes = ([('fast', hold, BUSOFF_FAST_RECOVERY_TIME_MS, BUSOFF_FAST_RECOVERY_TIME_MS / 2) for hold in fast_holds_ms]
              + [('slow', hold, BUSOFF_SLOW_RECOVERY_TIME_MS, slow_start_ms + BUSOFF_SLOW_RECOVERY_TIME_MS - hold)
                 for hold in slow_holds_ms])
    identify_hold_ms = slow_start_ms + BUSOFF_SLOW_RECOVERY_TIME_MS
    bus_off_lead_ms = 5 * max(fd_period_ms, hs_period_ms)
    recovery_wait_ms = int(BUSOFF_SLOW_RECOVERY_TIME_MS * margin) + bus_off_lead_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Find the bus behind the bus-off relay')
        identify_ids = [fd_id, hs_id]
        identify_file = os.path.splitext(log_path)[0] + '_busoff_identify.txt'
        identify_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_identify', filepath=identify_file,
            listOption=identify_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(bus_off_lead_ms)
        ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_LOAD)
        Wait(identify_hold_ms)
        ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_RESTORE_LOAD)
        Wait(recovery_wait_ms)
        CAN.StopLoggingToFile(identify_logger)
        identify_frames = []
        if os.path.isfile(identify_file):
            with open(identify_file, encoding='utf-8', errors='replace') as identify_log:
                identify_fields = [line.split(',', 2) for line in identify_log if ' id=' in line and line.count(',') >= 2]
            identify_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in identify_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(identify_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        identify_frames = [frame_data for frame_data in identify_frames if frame_data.id in identify_ids]
        identify_silence = {}
        for identify_id in (fd_id, hs_id):
            identify_times = [frame_data.timestamp for frame_data in identify_frames if frame_data.id == identify_id]
            identify_silence[identify_id] = max([(later - earlier) / 1000 for earlier, later
                                                 in zip(identify_times, identify_times[1:])] or [0])
        RESULT.LogAction(f"Longest gap of {fd_frame} on {CAN_FD_CHANNEL_NAME} (ms)", round(identify_silence[fd_id], 1))
        RESULT.LogAction(f"Longest gap of {hs_frame} on {CAN_HS_CHANNEL_NAME} (ms)", round(identify_silence[hs_id], 1))
        busoff_ids = [frame_id for frame_id, silence in identify_silence.items() if silence >= identify_hold_ms / 2]
        RESULT.InterpretEqualResult(
            f"ECU frames stopped by {CAN_BUS_OFF_RELAY_FUNCTION} = {CAN_BUS_OFF_RELAY_LOAD} for {identify_hold_ms} ms",
            len(busoff_ids), 1)
        if len(busoff_ids) != 1:
            aria_reports.close_group()
            return
        watch_id = busoff_ids[0]
        watch_frame = fd_frame if watch_id == fd_id else hs_frame
        watch_bus = CAN_FD_CHANNEL_NAME if watch_id == fd_id else CAN_HS_CHANNEL_NAME
        watch_period_ms = fd_period_ms if watch_id == fd_id else hs_period_ms
        bus_off_dtc = CAN_BUS_OFF_DTC[watch_bus]
        RESULT.InsertComment(f"{CAN_BUS_OFF_RELAY_FUNCTION} carries {watch_bus}: the recovery is timed on {watch_frame}")
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Release the bus-off at set times in the fast and the slow recovery')
        probe_results = []
        for probe_index, (probe_phase, probe_hold_ms, probe_interval_ms, probe_expected_ms) in enumerate(probes, start=1):
            probe_label = f"_busoff_probe_{probe_index:02d}"
            probe_file = os.path.splitext(log_path)[0] + probe_label + '.txt'
            probe_logger = CAN.StartLoggingToFile(TestCase_ID=tc_name + probe_label, filepath=probe_file,
                                                  listOption=[watch_id], channel_names=[watch_bus])
            Wait(bus_off_lead_ms)
            probe_set = time.monotonic()
            ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_LOAD)
            Wait(probe_hold_ms)
            probe_clear = time.monotonic()
            ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_RESTORE_LOAD)
            Wait(recovery_wait_ms)
            CAN.StopLoggingToFile(probe_logger)
            probe_times = []
            if os.path.isfile(probe_file):
                with open(probe_file, encoding='utf-8', errors='replace') as probe_log:
                    probe_fields = [line.split(',', 2) for line in probe_log if ' id=' in line and line.count(',') >= 2]
                probe_times = [round(float(fields[0].split()[0]) * 1e6) for fields in probe_fields
                               if int(fields[1].split('=')[1], 16) == watch_id]
            probe_silence_ms = max([(later - earlier) / 1000 for earlier, later in zip(probe_times, probe_times[1:])] or [0])
            probe_held_ms = (probe_clear - probe_set) * 1000
            # No gap longer than the hold means the frame did not come back within the log (or
            # never stopped): no time to grade.
            probe_recovery_ms = round(probe_silence_ms - probe_held_ms, 1) if probe_silence_ms > probe_held_ms else None
            RESULT.InsertComment(f"Probe {probe_index}: longest gap of {watch_frame} {round(probe_silence_ms, 1)} ms, "
                                 f"bus-off held {round(probe_held_ms, 1)} ms")
            # Window: the expected time to the next retry, -/+ 10 % of the retry interval and the
            # relay switching; the upper limit also allows the bus-off starting at the ECU's next
            # transmission and the first frame after the retry (one frame period each).
            probe_tolerance_ms = probe_interval_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100 + CAN_BUS_OFF_RELAY_SWITCH_MS
            RESULT.InterpretEqualResultRange(
                f"Probe {probe_index}, {probe_phase} recovery, bus-off held {round(probe_held_ms)} ms: "
                f"release to the first {watch_frame} (ms)",
                probe_recovery_ms, round(probe_expected_ms - probe_tolerance_ms, 1),
                round(probe_expected_ms + probe_tolerance_ms + 2 * watch_period_ms, 1))
            probe_results.append((probe_index, probe_phase, round(probe_held_ms), probe_recovery_ms))
            Wait(CAN_BUS_OFF_PROBE_SETTLE_MS)
        RESULT.InsertComment("Probes (index, phase, held ms, release to first frame ms): " + str(probe_results))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Read DTC: the bus-off DTC healed in this cycle, the ECU frames back')
        Read_DTC(
            'Bus-off DTC raised and healed',
            " ".join([Read_DTC_Resp_CANC,
                      bus_off_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        presence5_ids = [fd_id, hs_id]
        presence5_file = os.path.splitext(log_path)[0] + '_after_recovery.txt'
        presence5_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_after_recovery', filepath=presence5_file,
            listOption=presence5_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence5_logger)
        presence5_frames = []
        if os.path.isfile(presence5_file):
            with open(presence5_file, encoding='utf-8', errors='replace') as presence5_log:
                presence5_fields = [line.split(',', 2) for line in presence5_log if ' id=' in line and line.count(',') >= 2]
            presence5_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence5_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence5_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence5_frames = [frame_data for frame_data in presence5_frames if frame_data.id in presence5_ids]
        presence5_fd_count = sum(1 for frame_data in presence5_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence5_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence5_hs_count = sum(1 for frame_data in presence5_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence5_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            ARIA.AFT_iLoadBoxWrapper(CAN_BUS_OFF_RELAY_FUNCTION, CAN_BUS_OFF_RELAY_RESTORE_LOAD)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
