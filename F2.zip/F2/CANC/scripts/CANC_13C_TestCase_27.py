# Author: Kris
#


#
# Test case  : CANC_13C_TestCase_27 (Codebeamer ID 35739880)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check Signal values of IMU TEMP Signal in 13C
# Automation : Manual environment (thermal chamber), automatic check

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_IMU_TEMP_TOLERANCE_DEGC,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_THERMAL_SOAK_WINDOW_MS,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '35739880'
    tc_name = 'CANC_13C_TestCase_27'
    tc_desc = (
        'To Check Signal values of IMU TEMP Signal in 13C'
    )
    automation = 'Manual environment (thermal chamber), automatic check'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    chamber_setpoint_degc = 25

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Soak the ECU in the thermal chamber at 25 degC and read IMU_TEMP')
        RESULT.InsertComment('OPERATOR ACTION: Put the ECU in the thermal chamber at 25 degC and let it soak.')
        print('OPERATOR ACTION: Put the ECU in the thermal chamber at 25 degC and let it soak.')
        Wait(CANC_THERMAL_SOAK_WINDOW_MS)
        temperature_ids = [fd_id]
        temperature_file = os.path.splitext(log_path)[0] + '_imu_temp.txt'
        temperature_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_temp', filepath=temperature_file,
            listOption=temperature_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(temperature_logger)
        temperature_frames = []
        if os.path.isfile(temperature_file):
            with open(temperature_file, encoding='utf-8', errors='replace') as temperature_log:
                temperature_fields = [line.split(',', 2) for line in temperature_log if ' id=' in line and line.count(',') >= 2]
            temperature_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in temperature_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(temperature_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        temperature_frames = [frame_data for frame_data in temperature_frames if frame_data.id in temperature_ids]
        temperature_def = MAH_CAN_SIGNAL_DEFS['IMU_TEMP']
        temperature_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['IMU_TEMP'],
                                                                 temperature_def['bit_length']),
                                              scaling=temperature_def['Factor'], offset=temperature_def['Offset'],
                                              bits=temperature_def['bit_length'], signed=bool(temperature_def.get('Signed'))), 4)
                        for frame_data in temperature_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange("IMU_TEMP in the thermal chamber (degC)", temperature_values or [None],
                                         chamber_setpoint_degc - CANC_IMU_TEMP_TOLERANCE_DEGC,
                                         chamber_setpoint_degc + CANC_IMU_TEMP_TOLERANCE_DEGC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
