# Author: Kris
#


#
# Test case  : CANC_FR_ZONE_TestCase_9 (Codebeamer ID 36766230)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that FR_ZONE2_100 is received at the specified periodicity without
#              communication faults during normal transmission.
# Automation : Automatic
# Note       : The frame is sent by the bench (ARIA software simulation), so the script grades
#              its mean period against the DBC cycle time and the absence of communication DTCs,
#              and records the spread of single intervals: on 2026-10-15 ARIA's simulated frames
#              kept an exact mean (10.00 / 50.0 / 100.0 ms) but single intervals of a 10 ms
#              frame ran from 1.9 to 24 ms, which is the bench's timing, not the ECU's.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '36766230'
    tc_name = 'CANC_FR_ZONE_TestCase_9'
    tc_desc = (
        'Verify that FR_ZONE2_100 is received at the specified periodicity without '
        'communication faults during normal transmission.'
    )
    automation = 'Automatic'

    frame = 'FR_ZONE2_100'
    frame_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == frame)
    bus = frame_def['bus']
    period_ms = frame_def['periodicity']
    window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * period_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([frame_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Measure the time between consecutive FR_ZONE2_100 frames')
        window1_ids = [frame_def['frame_ID']]
        window1_file = os.path.splitext(log_path)[0] + '_periodicity_1.txt'
        window1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_periodicity_1', filepath=window1_file,
            listOption=window1_ids, channel_names=[bus])
        Wait(window_ms)
        CAN.StopLoggingToFile(window1_logger)
        window1_frames = []
        if os.path.isfile(window1_file):
            with open(window1_file, encoding='utf-8', errors='replace') as window1_log:
                window1_fields = [line.split(',', 2) for line in window1_log if ' id=' in line and line.count(',') >= 2]
            window1_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in window1_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(window1_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        window1_frames = [frame_data for frame_data in window1_frames if frame_data.id in window1_ids]
        window1_times = [frame_data.timestamp / 1000 for frame_data in window1_frames]
        window1_deltas = [round(later - earlier, 3) for earlier, later in zip(window1_times, window1_times[1:])]
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(window1_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResultRange(f"{frame} mean time between consecutive frames (ms)",
                                         round(sum(window1_deltas) / len(window1_deltas), 3) if window1_deltas else None,
                                         period_ms * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         period_ms * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InsertComment(f"{frame} single intervals (bench timing): "
                             f"{min(window1_deltas, default=None)} to {max(window1_deltas, default=None)} ms")
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Continue monitoring over additional cycles')
        window2_ids = [frame_def['frame_ID']]
        window2_file = os.path.splitext(log_path)[0] + '_periodicity_2.txt'
        window2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_periodicity_2', filepath=window2_file,
            listOption=window2_ids, channel_names=[bus])
        Wait(window_ms)
        CAN.StopLoggingToFile(window2_logger)
        window2_frames = []
        if os.path.isfile(window2_file):
            with open(window2_file, encoding='utf-8', errors='replace') as window2_log:
                window2_fields = [line.split(',', 2) for line in window2_log if ' id=' in line and line.count(',') >= 2]
            window2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in window2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(window2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        window2_frames = [frame_data for frame_data in window2_frames if frame_data.id in window2_ids]
        window2_times = [frame_data.timestamp / 1000 for frame_data in window2_frames]
        window2_deltas = [round(later - earlier, 3) for earlier, later in zip(window2_times, window2_times[1:])]
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(window2_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResultRange(f"{frame} mean time between consecutive frames (ms)",
                                         round(sum(window2_deltas) / len(window2_deltas), 3) if window2_deltas else None,
                                         period_ms * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         period_ms * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InsertComment(f"{frame} single intervals (bench timing): "
                             f"{min(window2_deltas, default=None)} to {max(window2_deltas, default=None)} ms")
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Read DTC')
        Read_DTC('No communication fault during normal transmission', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
