# Author: Kris
#


#
# Test case  : CAN_BUSOFF_4 (Codebeamer ID 35721110)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : To check the behaviour of ACU during busoff condition
# Automation : Semi-automatic (operator holds the bus-off; recovery timing evaluated from the
#              saved log)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.
# Note       : The recovery attempts during a bus-off are not decodable frames, so the fast/slow
#              recovery timing is evaluated from the saved log; the case's slow recovery time
#              (100 ms) differs from canc_config BUSOFF_SLOW_RECOVERY_TIME_MS (500 ms, NM
#              identifier sheet).

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_BUS_OFF_LONG_HOLD_MS,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35721110'
    tc_name = 'CAN_BUSOFF_4'
    tc_desc = (
        'To check the behaviour of ACU during busoff condition'
    )
    automation = 'Semi-automatic (operator holds the bus-off; recovery timing evaluated from the saved log)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Verify the ECU frame is transmitted')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_before_busoff.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_before_busoff', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Hold a bus-off with the CAN stress tool and log the recovery attempts')
        recovery_ids = [fd_id]
        recovery_file = os.path.splitext(log_path)[0] + '_busoff_recovery.txt'
        recovery_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_recovery', filepath=recovery_file,
            listOption=recovery_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        RESULT.InsertComment(f'OPERATOR ACTION: Create a bus-off on the CAN-FD bus with the CAN stress tool, hold it for {CAN_BUS_OFF_LONG_HOLD_MS / 1000:.0f} s, then remove it.')
        print(f'OPERATOR ACTION: Create a bus-off on the CAN-FD bus with the CAN stress tool, hold it for {CAN_BUS_OFF_LONG_HOLD_MS / 1000:.0f} s, then remove it.')
        Wait(CAN_BUS_OFF_LONG_HOLD_MS + CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        CAN.StopLoggingToFile(recovery_logger)
        recovery_frames = []
        if os.path.isfile(recovery_file):
            with open(recovery_file, encoding='utf-8', errors='replace') as recovery_log:
                recovery_fields = [line.split(',', 2) for line in recovery_log if ' id=' in line and line.count(',') >= 2]
            recovery_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in recovery_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(recovery_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        recovery_frames = [frame_data for frame_data in recovery_frames if frame_data.id in recovery_ids]
        RESULT.LogAction("Recovery log for review", recovery_file)
        RESULT.InsertComment(
            f"Expected in the log: {BUSOFF_FAST_RECOVERY_COUNT} recovery attempts {BUSOFF_FAST_RECOVERY_TIME_MS} ms "
            f"apart, then attempts every {BUSOFF_SLOW_RECOVERY_TIME_MS} ms while the bus-off lasts.")
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Communication restored after the bus-off')
        Wait(busoff_settle_ms)
        presence4_ids = [fd_id]
        presence4_file = os.path.splitext(log_path)[0] + '_after_busoff.txt'
        presence4_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_after_busoff', filepath=presence4_file,
            listOption=presence4_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence4_logger)
        presence4_frames = []
        if os.path.isfile(presence4_file):
            with open(presence4_file, encoding='utf-8', errors='replace') as presence4_log:
                presence4_fields = [line.split(',', 2) for line in presence4_log if ' id=' in line and line.count(',') >= 2]
            presence4_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence4_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence4_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence4_frames = [frame_data for frame_data in presence4_frames if frame_data.id in presence4_ids]
        presence4_fd_count = sum(1 for frame_data in presence4_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence4_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
