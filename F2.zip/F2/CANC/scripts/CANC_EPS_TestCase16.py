# Author: Kris
#


#
# Test case  : CANC_EPS_TestCase16 (Codebeamer ID 35654989)
# Workbook   : EPS_Node_TestCases.xlsx
# Objective  : Verify voltage suppression behavior for Message Content Failure (DLC) in
#              EPS1_FD_10 under low voltage condition.
# Automation : Automatic
# Note       : A wrong DLC is produced by giving the simulated frame itself the payload length
#              CAN_DLC_ERROR_PAYLOAD_LENGTH gives (CAN.SetPeriodicFrame on the frame's own name
#              changes its payload), with the bench-computed CRC / alive counter held meanwhile;
#              the default payload is reloaded to heal. A copy on the same identifier is refused
#              by ARIA ('Frame ID ... already in simulation', 2026-10-15). Confirm on the bench
#              that the frame goes out with the shorter length.
# Note       : The case gives the battery-voltage DTC status 0x08 for active, healed and
#              historic; the customer DTC list (warning lamp 1) and the FR_ZONE / VCU cases give
#              0x8B / 0x0A / 0x08. The script reads the statuses from
#              CANC_VOLTAGE_DTC_STATUS_KEYS in canc_config.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_UNDERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_SIGNAL_START_BIT,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
    get_frame_message_content_failure_dtc,
    get_message_content_failure_signals,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    DIAG_TX_ID,
)


def run_test():
    tc_id = '35654989'
    tc_name = 'CANC_EPS_TestCase16'
    tc_desc = (
        'Verify voltage suppression behavior for Message Content Failure (DLC) in EPS1_FD_10 '
        'under low voltage condition.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    fault_frame = 'EPS1_FD_10'
    fault_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame)
    fault_bus = fault_def['bus']
    fault_dtc = get_frame_message_content_failure_dtc(fault_frame)[0]
    if fault_dtc is None:
        fault_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(fault_frame)
    fault_error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[fault_def['dlc']])
    fault_dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals(fault_frame)
                           if key in MAH_CAN_SIGNAL_DEFS]
    fault_counter_key = next((
        key for key in get_message_content_failure_signals(fault_frame) if 'CRC' not in key.upper()), None)
    fault_qualify_nominal_ms = qualification_ms('message_content', fault_def['periodicity'])
    fault_recover_nominal_ms = recovery_ms('message_content', fault_def['periodicity'])
    fault_recover_tolerance_ms = int(fault_recover_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    fault_qualify_ms = int(fault_qualify_nominal_ms * margin)
    voltage_level = CANC_UNDERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Under_Voltage

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([fault_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure (DLC) DTC of {fault_frame}', fault_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create under-voltage condition')
        PS.SetVoltage(voltage_level)
        voltage_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]}")
        RESULT.LogAction('Time until the voltage DTC is active (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create CAN fault while the abnormal voltage is present - inject incorrect DLC on EPS1_FD_10')
        for fault_dynamic_signal in fault_dynamic_signals:
            CAN.DynamicDisableSignal(fault_bus, fault_frame, fault_dynamic_signal)
        CAN.SetPeriodicFrame(fault_bus, fault_frame, fault_def['frame_ID'], fault_def['periodicity'],
                             fault_error_payload, fault_def['is_fd'])
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        Wait(fault_qualify_ms)
        Read_DTC(
            'CAN DTC remains suppressed while the abnormal voltage is present',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage while maintaining the CAN fault')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        settle_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]};{fault_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.LogAction('Time until the voltage DTC is healed and the CAN DTC active (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Voltage DTC healed, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']]};{fault_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Voltage DTC historic, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Remove CAN fault - restore correct DLC on EPS1_FD_10')
        fault_restore_ids = [fault_def['frame_ID'], DIAG_TX_ID]
        fault_restore_file = os.path.splitext(log_path)[0] + '_fault_restore.txt'
        fault_restore_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_fault_restore', filepath=fault_restore_file,
            listOption=fault_restore_ids, channel_names=list(dict.fromkeys([fault_bus, CAN_FD_CHANNEL_NAME])))
        CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        for fault_dynamic_signal in fault_dynamic_signals:
            CAN.DynamicEnableSignal(fault_bus, fault_frame, fault_dynamic_signal)
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        fault_dequalification_time_ms = faultTimeMeasurement(f"{fault_dtc} {DTC_status['DTC_healed']}")
        RESULT.LogAction(f"Dequalification time of {fault_dtc} ({fault_recover_nominal_ms // fault_def['periodicity']} x {fault_def['periodicity']} ms) (ms)", None if fault_dequalification_time_ms is None else round(fault_dequalification_time_ms))
        CAN.StopLoggingToFile(fault_restore_logger)
        fault_restore_frames = []
        if os.path.isfile(fault_restore_file):
            with open(fault_restore_file, encoding='utf-8', errors='replace') as fault_restore_log:
                fault_restore_fields = [line.split(',', 2) for line in fault_restore_log if ' id=' in line and line.count(',') >= 2]
            fault_restore_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in fault_restore_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(fault_restore_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        fault_restore_frames = [frame_data for frame_data in fault_restore_frames if frame_data.id in fault_restore_ids]
        fault_restore_reads = [
            frame_data.timestamp for frame_data in fault_restore_frames
            if frame_data.id == DIAG_TX_ID and bytes(frame_data.payload[1:3]) == bytes([0x19, 0x02])]
        fault_restore_rows = [frame_data for frame_data in fault_restore_frames if frame_data.id == fault_def['frame_ID']]
        fault_restore_short = [
            index for index, frame_data in enumerate(fault_restore_rows) if len(frame_data.payload) != fault_def['dlc']]
        fault_restore_full = next((
            index for index in range((fault_restore_short[-1] + 1) if fault_restore_short else 0, len(fault_restore_rows))
            if len(fault_restore_rows[index].payload) == fault_def['dlc']), None)
        if fault_restore_full is None or not fault_restore_reads:
            fault_restart_ms = 0
            RESULT.LogCustomAction(
                "First full-length frame and first DTC read after the reload", "Both in the CAN log",
                "Not found: the heal time is graded from the measurement start", False)
        else:
            fault_restart_ms = round((fault_restore_rows[fault_restore_full].timestamp - fault_restore_reads[0]) / 1000, 1)
            RESULT.LogAction(
                f"{fault_frame} first full-length frame after the reload (ms after the first DTC read)",
                fault_restart_ms)
            if fault_restore_short and fault_restore_full > 0:
                fault_restore_gap = round((
                    fault_restore_rows[fault_restore_full].timestamp
                    - fault_restore_rows[fault_restore_full - 1].timestamp) / 1000, 1)
                RESULT.LogAction(
                    f"{fault_frame} interval across the reload (ms, period {fault_def['periodicity']} ms)",
                    fault_restore_gap)
            if fault_counter_key in CAN_SIGNAL_START_BIT:
                fault_restore_counts = [
                    extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[fault_counter_key],
                                       MAH_CAN_SIGNAL_DEFS[fault_counter_key]['bit_length'])
                    for frame_data in fault_restore_rows[fault_restore_full:fault_restore_full + 3]]
                RESULT.LogAction(f"{fault_counter_key} of the first frames after the reload", fault_restore_counts)
        RESULT.InsertComment(f"Dequalification time of {fault_dtc} ({fault_recover_nominal_ms // fault_def['periodicity']} x {fault_def['periodicity']} ms): expected {fault_recover_nominal_ms + fault_restart_ms} ms, limits {fault_recover_nominal_ms + fault_restart_ms - fault_recover_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {fault_recover_nominal_ms + fault_restart_ms + fault_recover_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(fault_dequalification_time_ms, fault_recover_nominal_ms + fault_restart_ms + measurement_lag_ms / 2, fault_recover_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'CAN DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        Read_DTC(
            'CAN DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
            for fault_dynamic_signal in fault_dynamic_signals:
                CAN.DynamicEnableSignal(fault_bus, fault_frame, fault_dynamic_signal)
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
