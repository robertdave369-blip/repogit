# Author: Kris
#


#
# Test case  : CANC_FR_ZONE_TestCase_40 (Codebeamer ID 35660010)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that FR_ZONE3_100 timeout fault is healed and message-content failure
#              (alive counter) becomes active when counter corruption is applied.
# Automation : Automatic
# Note       : The case expects a message-timeout fault when FR_ZONE3_100 stops; canc_config
#              KEY_TX_FRAMES names FR_ZONE3_100 as the key frame of its node. The script follows
#              the case and expects the message-timeout DTC canc_config gives for FR_ZONE3_100
#              (0xD0 0x04 0x00): on the bench (2026-10-15) stopping FR_ZONE2_100 set the node-
#              absent DTC D10400 and stopping FR_ZONE3_100 for 5.5 s set none (its message-
#              timeout DTC needs 60 x 100 ms).
# Note       : The case steps are copied from other cases; the script follows the description
#              and preconditions (primary frame-loss fault, then the frame resumes with
#              corrupted content).

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
    get_message_content_failure_dtcs,
    get_message_content_failure_signals,
    qualification_ms,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35660010'
    tc_name = 'CANC_FR_ZONE_TestCase_40'
    tc_desc = (
        'Verify that FR_ZONE3_100 timeout fault is healed and message-content failure (alive '
        'counter) becomes active when counter corruption is applied.'
    )
    automation = 'Automatic'

    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    loss_frame = 'FR_ZONE3_100'
    loss_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == loss_frame)
    loss_bus = loss_def['bus']
    loss_mode = 'message_timeout'
    loss_dtc = resolve_dtc_for_event(loss_mode, loss_frame)
    loss_qualify_nominal_ms = qualification_ms(loss_mode, loss_def['periodicity'])
    loss_qualify_tolerance_ms = int(loss_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    mcf_frame = 'FR_ZONE3_100'
    mcf_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == mcf_frame)
    mcf_bus = mcf_def['bus']
    mcf_signal = next((s for s in get_message_content_failure_signals(mcf_frame) if 'CRC' not in s.upper()), None)
    mcf_signal_name = MAH_CAN_SIGNAL_DEFS.get(mcf_signal, {}).get('signal')
    mcf_dtc = get_message_content_failure_dtcs(mcf_frame).get(mcf_signal)
    mcf_qualify_nominal_ms = qualification_ms('message_content', mcf_def['periodicity'])
    mcf_qualify_tolerance_ms = int(mcf_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([loss_def, mcf_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'frame-loss DTC of {loss_frame}', loss_dtc),
            (f'message content failure (alive counter) DTC of {mcf_frame}', mcf_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create the primary fault - stop transmission of FR_ZONE3_100')
        CAN.PeriodicDisableFrame(loss_bus, loss_frame)
        loss_qualification_time_ms = faultTimeMeasurement(f"{loss_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {loss_dtc} ({loss_qualify_nominal_ms // loss_def['periodicity']} x {loss_def['periodicity']} ms): expected {loss_qualify_nominal_ms} ms, limits {loss_qualify_nominal_ms - loss_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {loss_qualify_nominal_ms + loss_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(loss_qualification_time_ms, loss_qualify_nominal_ms + measurement_lag_ms / 2, loss_qualify_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'Frame-loss DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Resume transmission with corrupted content - inject alive counter error on FR_ZONE3_100 (alive counter no longer updated)')
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        CAN.DynamicDisableSignal(mcf_bus, mcf_frame, mcf_signal_name)
        mcf_qualification_time_ms = faultTimeMeasurement(f"{loss_dtc} {DTC_status['DTC_healed']};{mcf_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {mcf_dtc} ({mcf_qualify_nominal_ms // mcf_def['periodicity']} x {mcf_def['periodicity']} ms): expected {mcf_qualify_nominal_ms} ms, limits {mcf_qualify_nominal_ms - mcf_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {mcf_qualify_nominal_ms + mcf_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(mcf_qualification_time_ms, mcf_qualify_nominal_ms + measurement_lag_ms / 2, mcf_qualify_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'Message content failure active, frame-loss DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      mcf_dtc, DTC_status['DTC_active_WLOFF'],
                      loss_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{mcf_dtc} {DTC_status['DTC_active_WLOFF']};{loss_dtc} {DTC_status['DTC_historic']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Message content failure active, frame-loss DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      mcf_dtc, DTC_status['DTC_active_WLOFF'],
                      loss_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.DynamicEnableSignal(mcf_bus, mcf_frame, mcf_signal_name)
            CAN.PeriodicEnableFrame(loss_bus, loss_frame)
            CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
