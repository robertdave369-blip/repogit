# Author: Kris
#


#
# Test case  : CANC_13C_TestCase_101 (Codebeamer ID 36754005)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify_SRS_OCS_SUBSEAT_CLASSIFICATION
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_OCS_UPDATE_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '36754005'
    tc_name = 'CANC_13C_TestCase_101'
    tc_desc = (
        'Verify_SRS_OCS_SUBSEAT_CLASSIFICATION'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
    ocs_subseat_def = MAH_CAN_SIGNAL_DEFS['OCS_SUBSEAT_CLASSIFICATION']

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Enable OCS in the variant code')
        manage_variant_code('OCS', 'enable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Set OCS_SUBSEAT_CLASSIFICATION through every class and observe SRS_OCS_SUBSEAT_CLASSIFICATION')
        ocs_labels = {value: label for label, value in ocs_subseat_def['State_Values'].items()}
        for ocs_value in sorted(ocs_labels):
            ocs_label = ocs_labels[ocs_value]
            CAN.ChangeSignalValue(ocs_subseat_def['bus'], ocs_subseat_def['frame'], ocs_subseat_def['signal'], str(ocs_value))
            Wait(CANC_OCS_UPDATE_MS)
            # Read again until the mirror follows or the start-up time has passed (OCS1_500
            # goes out every 500 ms and the ECU takes about 1 s more).
            mirror_started = time.monotonic()
            while True:
                mirror_text = str(CAN.GetSignalFromFrame(MAH_CAN_SIGNAL_DEFS['SRS_OCS_SUBSEAT_CLASSIFICATION']['bus'], 'SRS1_FD_10', 'SRS_OCS_SUBSEAT_CLASSIFICATION')).strip()
                try:
                    mirror_value = int(mirror_text, 16) if mirror_text.lower().startswith("0x") else int(float(mirror_text))
                except ValueError:
                    mirror_value = mirror_text
                if str(mirror_value) == str(ocs_value) or time.monotonic() - mirror_started >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"SRS_OCS_SUBSEAT_CLASSIFICATION with OCS_SUBSEAT_CLASSIFICATION = {ocs_label}", str(mirror_value), str(ocs_value))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
