# Author: Kris
#


#
# Test case  : CANC_FR_ZONE_TestCase_36 (Codebeamer ID 36766247)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that ZONAL_BATT_VOLT received in FR_ZONE3_100 is decoded to the correct
#              physical value.
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '36766247'
    tc_name = 'CANC_FR_ZONE_TestCase_36'
    tc_desc = (
        'Verify that ZONAL_BATT_VOLT received in FR_ZONE3_100 is decoded to the correct '
        'physical value.'
    )
    automation = 'Automatic'

    signal_key = 'ZONAL_BATT_VOLT'
    signal_def = MAH_CAN_SIGNAL_DEFS[signal_key]
    frame = signal_def['frame']
    bus = signal_def['bus']
    signal = signal_def['signal']
    bits = signal_def['bit_length']
    signal_values = list(signal_def.get('TestCase_values') or [])

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'representative values of {signal_key}', signal_values or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Transmit representative raw values for ZONAL_BATT_VOLT and compare the decoded value')
        for raw in signal_values:
            CAN.ChangeSignalValue(bus, frame, signal, str(raw))
            Wait(3 * signal_def['periodicity'])
            read_back = str(CAN.GetSignalFromFrame(bus, frame, signal)).strip()
            try:
                read_raw = int(read_back, 16) if read_back.lower().startswith("0x") else int(float(read_back))
            except ValueError:
                read_raw = None
                # Not a number: ARIA's own answer (e.g. a signal its database lacks) goes to the report.
                RESULT.InsertComment(f"ARIA read-back of {frame}.{signal}: {read_back}")
            raw_unsigned = raw % (1 << bits)
            RESULT.InterpretEqualResult(
                f"{frame} carries {signal} raw {raw} (0x{raw_unsigned:X})",
                str(None if read_raw is None else read_raw % (1 << bits)), str(raw_unsigned))
            physical = round(raw_to_physical(raw_unsigned, scaling=signal_def['Factor'], offset=signal_def['Offset'],
                                             bits=bits, signed=bool(signal_def.get('Signed'))), 6)
            RESULT.InterpretEqualResultRange(
                f"{signal} raw {raw} decodes to {physical:g} (raw x {signal_def['Factor']} + {signal_def['Offset']})",
                physical, signal_def['MIN'], signal_def['MAX'])
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Restore the default frame content and read DTC')
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        Wait(10 * signal_def['periodicity'])
        Read_DTC('No DTC after the representative values', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame(bus, frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
