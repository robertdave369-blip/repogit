# Author: Kris
#


#
# Test case  : CANC_DTC_Read_Timing (additional check, not a workbook case)
# Objective  : Measure how long one DTC read of the shared faultTimeMeasurement takes on this
#              bench (request out through ARIA, the ECU's answer, the answer back in python) and
#              check that the measurement lag the CAN-C timing checks allow
#              (FAULT_TIME_MEASUREMENT_LAG_MS) covers it.
# Automation : Automatic
# Note       : faultTimeMeasurement is given the 19 02 positive-response header (the first two
#              bytes of Read_DTC_Resp) as its target, which every answer carries, so each of the
#              CANC_DTC_READ_TIMING_SAMPLES calls times one read: one ARIA call resolving the
#              UDS channel, the 19 02 09 request, the ECU's answer and the return.
# Note       : The CAN-C timing checks allow FAULT_TIME_MEASUREMENT_LAG_MS (60 ms, derived from
#              the 2026-10-15 bench logs) above nominal + 10 %. If this script measures more,
#              raise that value to the measured lag.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_DTC_READ_TIMING_SAMPLES,
    CAN_FAULT_POLL_INTERVAL_MS,
    FAULT_TIME_MEASUREMENT_LAG_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = ''
    tc_name = 'CANC_DTC_Read_Timing'
    tc_desc = (
        'Measure how long one DTC read of the shared faultTimeMeasurement takes on this bench '
        "(request out through ARIA, the ECU's answer, the answer back in python) and check "
        'that the measurement lag the CAN-C timing checks allow '
        '(FAULT_TIME_MEASUREMENT_LAG_MS) covers it.'
    )
    automation = 'Automatic'

    timing_target = " ".join(Read_DTC_Resp.split()[:2])

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Time single DTC reads of faultTimeMeasurement')
        timing_reads_ms = [faultTimeMeasurement(timing_target) for _ in range(CANC_DTC_READ_TIMING_SAMPLES)]
        timing_valid = sorted(value for value in timing_reads_ms if value is not None)
        RESULT.InterpretEqualResult(f"Reads without the 19 02 answer (of {CANC_DTC_READ_TIMING_SAMPLES})",
                                    len(timing_reads_ms) - len(timing_valid), 0)
        timing_sleeps_ms = []
        for _ in range(CANC_DTC_READ_TIMING_SAMPLES):
            timing_started = time.monotonic()
            time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            timing_sleeps_ms.append((time.monotonic() - timing_started) * 1000)
        timing_sleeps_ms.sort()
        if timing_valid:
            RESULT.LogAction("One DTC read (ms): min / median / 95th percentile / max",
                             [round(timing_valid[0], 1), round(timing_valid[len(timing_valid) // 2], 1),
                              round(timing_valid[min(len(timing_valid) - 1, int(0.95 * len(timing_valid)))], 1),
                              round(timing_valid[-1], 1)])
            RESULT.LogAction(f"Poll pause of {CAN_FAULT_POLL_INTERVAL_MS:g} ms (ms): median / max",
                             [round(timing_sleeps_ms[len(timing_sleeps_ms) // 2], 1), round(timing_sleeps_ms[-1], 1)])
            timing_lag_ms = round(2 * timing_valid[-1] + timing_sleeps_ms[-1], 1)
            RESULT.InterpretEqualResultRange("Measurement lag on this bench: 2 x longest read + longest pause (ms)",
                                             timing_lag_ms, 0, FAULT_TIME_MEASUREMENT_LAG_MS)
        aria_reports.close_group()
        Read_DTC('No DTC after the timing reads', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
