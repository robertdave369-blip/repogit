# Author: Kris
#


#
# Test case  : CANC_EPS_TestCase13 (Codebeamer ID 35654992)
# Workbook   : EPS_Node_TestCases.xlsx
# Objective  : Verify voltage suppression behavior for Message Content Failure (MessageCounter)
#              in EPS1_FD_10 under high voltage condition.
# Automation : Automatic
# Note       : The case gives the battery-voltage DTC status 0x08 for active, healed and
#              historic; the customer DTC list (warning lamp 1) and the FR_ZONE / VCU cases give
#              0x8B / 0x0A / 0x08. The script reads the statuses from
#              CANC_VOLTAGE_DTC_STATUS_KEYS in canc_config.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_OVERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
    get_message_content_failure_dtcs,
    get_message_content_failure_signals,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35654992'
    tc_name = 'CANC_EPS_TestCase13'
    tc_desc = (
        'Verify voltage suppression behavior for Message Content Failure (MessageCounter) in '
        'EPS1_FD_10 under high voltage condition.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    fault_frame = 'EPS1_FD_10'
    fault_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame)
    fault_bus = fault_def['bus']
    fault_signal = next((s for s in get_message_content_failure_signals(fault_frame) if 'CRC' not in s.upper()), None)
    fault_signal_name = MAH_CAN_SIGNAL_DEFS.get(fault_signal, {}).get('signal')
    fault_dtc = get_message_content_failure_dtcs(fault_frame).get(fault_signal)
    fault_qualify_nominal_ms = qualification_ms('message_content', fault_def['periodicity'])
    fault_recover_nominal_ms = recovery_ms('message_content', fault_def['periodicity'])
    fault_recover_tolerance_ms = int(fault_recover_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    fault_qualify_ms = int(fault_qualify_nominal_ms * margin)
    voltage_level = CANC_OVERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Over_Voltage

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([fault_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure (alive counter) DTC of {fault_frame}', fault_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(fault_bus, fault_frame)
        CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create over-voltage condition')
        PS.SetVoltage(voltage_level)
        voltage_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]}")
        RESULT.LogAction('Time until the voltage DTC is active (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create CAN fault while the abnormal voltage is present - inject alive counter error on EPS1_FD_10 (alive counter no longer updated)')
        CAN.DynamicDisableSignal(fault_bus, fault_frame, fault_signal_name)
        Wait(fault_qualify_ms)
        Read_DTC(
            'CAN DTC remains suppressed while the abnormal voltage is present',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage while maintaining the CAN fault')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        settle_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]};{fault_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.LogAction('Time until the voltage DTC is healed and the CAN DTC active (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Voltage DTC healed, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']]};{fault_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Voltage DTC historic, CAN DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Remove CAN fault - restore correct alive counter on EPS1_FD_10')
        CAN.DynamicEnableSignal(fault_bus, fault_frame, fault_signal_name)
        fault_dequalification_time_ms = faultTimeMeasurement(f"{fault_dtc} {DTC_status['DTC_healed']}")
        RESULT.InsertComment(f"Dequalification time of {fault_dtc} ({fault_recover_nominal_ms // fault_def['periodicity']} x {fault_def['periodicity']} ms): expected {fault_recover_nominal_ms} ms, limits {fault_recover_nominal_ms - fault_recover_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {fault_recover_nominal_ms + fault_recover_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(fault_dequalification_time_ms, fault_recover_nominal_ms + measurement_lag_ms / 2, fault_recover_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'CAN DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        Read_DTC(
            'CAN DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['historic']],
                      fault_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.DynamicEnableSignal(fault_bus, fault_frame, fault_signal_name)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
