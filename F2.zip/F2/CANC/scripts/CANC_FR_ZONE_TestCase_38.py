# Author: Kris
#


#
# Test case  : CANC_FR_ZONE_TestCase_38 (Codebeamer ID 36766339)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that FR_ZONE2_100 (key message) and FR_ZONE3_100 (non-key message) are
#              both received normally before fault injection scenarios.
# Automation : Automatic
# Note       : The frame is sent by the bench (ARIA software simulation), so the script grades
#              its mean period against the DBC cycle time and the absence of communication DTCs,
#              and records the spread of single intervals: on 2026-10-15 ARIA's simulated frames
#              kept an exact mean (10.00 / 50.0 / 100.0 ms) but single intervals of a 10 ms
#              frame ran from 1.9 to 24 ms, which is the bench's timing, not the ECU's.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '36766339'
    tc_name = 'CANC_FR_ZONE_TestCase_38'
    tc_desc = (
        'Verify that FR_ZONE2_100 (key message) and FR_ZONE3_100 (non-key message) are both '
        'received normally before fault injection scenarios.'
    )
    automation = 'Automatic'

    frame_1 = 'FR_ZONE2_100'
    frame_1_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == frame_1)
    frame_2 = 'FR_ZONE3_100'
    frame_2_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == frame_2)
    window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(frame_1_def['periodicity'], frame_2_def['periodicity'])

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([frame_1_def, frame_2_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(frame_1_def['bus'], frame_1)
        CAN.ReloadDefaultPeriodicFrame(frame_1_def['bus'], frame_1)
        CAN.PeriodicEnableFrame(frame_2_def['bus'], frame_2)
        CAN.ReloadDefaultPeriodicFrame(frame_2_def['bus'], frame_2)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor FR_ZONE2_100 and FR_ZONE3_100 for multiple cycles')
        both_ids = [frame_1_def['frame_ID'], frame_2_def['frame_ID']]
        both_file = os.path.splitext(log_path)[0] + '_frames_normal.txt'
        both_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_frames_normal', filepath=both_file,
            listOption=both_ids, channel_names=sorted({frame_1_def['bus'], frame_2_def['bus']}))
        Wait(window_ms)
        CAN.StopLoggingToFile(both_logger)
        both_frames = []
        if os.path.isfile(both_file):
            with open(both_file, encoding='utf-8', errors='replace') as both_log:
                both_fields = [line.split(',', 2) for line in both_log if ' id=' in line and line.count(',') >= 2]
            both_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in both_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(both_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        both_frames = [frame_data for frame_data in both_frames if frame_data.id in both_ids]
        frame_1_frames = [frame_data for frame_data in both_frames if frame_data.id == frame_1_def['frame_ID']]
        frame_1_times = [frame_data.timestamp / 1000 for frame_data in frame_1_frames]
        frame_1_deltas = [round(later - earlier, 3) for earlier, later in zip(frame_1_times, frame_1_times[1:])]
        RESULT.InterpretEqualResultRange(f"{frame_1} frames captured", len(frame_1_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResultRange(f"{frame_1} mean time between consecutive frames (ms)",
                                         round(sum(frame_1_deltas) / len(frame_1_deltas), 3) if frame_1_deltas else None,
                                         frame_1_def['periodicity'] * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         frame_1_def['periodicity'] * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InsertComment(f"{frame_1} single intervals (bench timing): "
                             f"{min(frame_1_deltas, default=None)} to {max(frame_1_deltas, default=None)} ms")
        frame_2_frames = [frame_data for frame_data in both_frames if frame_data.id == frame_2_def['frame_ID']]
        frame_2_times = [frame_data.timestamp / 1000 for frame_data in frame_2_frames]
        frame_2_deltas = [round(later - earlier, 3) for earlier, later in zip(frame_2_times, frame_2_times[1:])]
        RESULT.InterpretEqualResultRange(f"{frame_2} frames captured", len(frame_2_frames),
                                         CANC_PERIODICITY_SAMPLE_FRAMES, float('inf'))
        RESULT.InterpretEqualResultRange(f"{frame_2} mean time between consecutive frames (ms)",
                                         round(sum(frame_2_deltas) / len(frame_2_deltas), 3) if frame_2_deltas else None,
                                         frame_2_def['periodicity'] * (1 - CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100),
                                         frame_2_def['periodicity'] * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100))
        RESULT.InsertComment(f"{frame_2} single intervals (bench timing): "
                             f"{min(frame_2_deltas, default=None)} to {max(frame_2_deltas, default=None)} ms")
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Read DTC')
        Read_DTC('No node-absent, message-timeout or message-content DTC', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
