"""
Module Configuration: IMU
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/imu_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is IMU
    ctx.get_module_config("IMU").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "IMU"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── IMU Settings ──
ACCELEROMETER_RANGE = 200
GYROSCOPE_RANGE = 300
SAMPLE_RATE = 1000

ACCEL_OFFSET = {"x": 0.0, "y": 0.0, "z": 0.0}
GYRO_OFFSET = {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}
