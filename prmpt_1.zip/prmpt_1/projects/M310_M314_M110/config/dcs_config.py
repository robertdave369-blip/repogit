"""
Module Configuration: DCS
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/dcs_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is DCS
    ctx.get_module_config("DCS").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "DCS"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── DCS Settings ──
DIAGNOSTIC_DIDS = {
    "ECU_SERIAL":     0xF18C,
    "ECU_HW_VERSION": 0xF191,
    "ECU_SW_VERSION": 0xF195,
    "SUPPLIER_ID":    0xF18A,
    "CRASH_STATUS":   0x0400,
    "SYSTEM_STATUS":  0x0410,
}

DEFAULT_SESSION = 0x01
EXTENDED_SESSION = 0x03
PROGRAMMING_SESSION = 0x02
