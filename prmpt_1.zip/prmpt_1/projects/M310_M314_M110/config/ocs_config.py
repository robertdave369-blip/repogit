"""
Module Configuration: OCS
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/ocs_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is OCS
    ctx.get_module_config("OCS").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "OCS"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── OCS Settings ──
OCS_STATUS_DID = 0x0460
OCS_SEATBELT_DID = 0x0461

SEATBELT_STATUS = {
    0x00: "Unbuckled",
    0x01: "Buckled",
    0x02: "Error",
}
