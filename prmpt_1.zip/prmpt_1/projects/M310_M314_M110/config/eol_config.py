"""
Module Configuration: EOL
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/eol_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is EOL
    ctx.get_module_config("EOL").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "EOL"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── EOL Settings ──
EOL_STEPS = [
    "voltage_check",
    "can_communication",
    "sensor_calibration",
    "squib_resistance",
    "vin_write",
    "variant_coding",
    "final_check",
]

EOL_STATUS_DID = 0xF1F0
EOL_COUNTER_DID = 0xF1F1
EOL_RESULT_DID = 0xF1F2

ALL_DTCS_MUST_CLEAR = True
MIN_VOLTAGE = 11.5
MAX_VOLTAGE = 14.5
