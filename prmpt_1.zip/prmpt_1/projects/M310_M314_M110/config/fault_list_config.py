"""
Module Configuration: Fault_List
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/fault_list_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is Fault_List
    ctx.get_module_config("Fault_List").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "Fault_List"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── Fault_List Settings ──
FAULT_LIST = {
    "C0001": {"name": "Sensor Open Circuit",  "severity": "HIGH"},
    "C0002": {"name": "Sensor Short Circuit", "severity": "HIGH"},
    "C0010": {"name": "CAN Bus Off",          "severity": "MEDIUM"},
    "C0020": {"name": "Voltage Out of Range", "severity": "LOW"},
}

MONITOR_INTERVAL = 0.5
AUTO_CLEAR_ON_START = True
