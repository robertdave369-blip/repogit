"""
Module Configuration: ODS
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/ods_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is ODS
    ctx.get_module_config("ODS").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "ODS"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── ODS Settings ──
ODS_STATUS_DID = 0x0450
ODS_WEIGHT_DID = 0x0451
ODS_CLASSIFICATION_DID = 0x0452

CLASSIFICATION_MAP = {
    0x00: "Empty",
    0x01: "Child Seat (RF)",
    0x02: "Child Seat (FF)",
    0x03: "Adult Small",
    0x04: "Adult Average",
    0x05: "Adult Large",
}

WEIGHT_THRESHOLD_KG = 15.0
