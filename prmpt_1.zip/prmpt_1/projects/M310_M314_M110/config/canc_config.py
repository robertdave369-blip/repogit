"""
Module Configuration: CANC
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/canc_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is CANC
    ctx.get_module_config("CANC").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "CANC"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CANC Settings ──
TEST_CAN_MESSAGES = [
    {"id": 0x100, "data": [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]},
    {"id": 0x200, "data": [0xFF, 0xFE, 0xFD, 0xFC, 0x00, 0x00, 0x00, 0x00]},
    {"id": 0x300, "data": [0x00] * 8},
]

BUS_OFF_RECOVERY_TIME = 2.0
MESSAGE_CYCLE_TIME = 0.01
TIMEOUT_MONITORING = 1.0
