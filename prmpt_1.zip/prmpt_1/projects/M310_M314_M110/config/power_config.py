"""
Module Configuration: POWER
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/power_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is POWER
    ctx.get_module_config("POWER").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "POWER"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── POWER Settings ──
NOMINAL_VOLTAGE = 12.0
UNDERVOLTAGE_THRESHOLD = 9.0
OVERVOLTAGE_THRESHOLD = 16.0

POWER_MODES = {
    "RUN":   0x01,
    "ACC":   0x02,
    "OFF":   0x03,
    "CRANK": 0x04,
}

POWER_ON_DELAY = 0.5
POWER_OFF_DELAY = 5.0
CRANK_DURATION = 2.0
