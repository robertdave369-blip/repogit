"""
Module Configuration: SQUIBS
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/squibs_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is SQUIBS
    ctx.get_module_config("SQUIBS").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "SQUIBS"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── SQUIBS Settings ──
SQUIB_CHANNELS = {
    "DRIVER_FRONT":              1,
    "PASSENGER_FRONT":           2,
    "DRIVER_SIDE":               3,
    "PASSENGER_SIDE":            4,
    "DRIVER_CURTAIN":            5,
    "PASSENGER_CURTAIN":         6,
    "DRIVER_KNEE":               7,
    "SEATBELT_PRETENSIONER_DRV": 8,
    "SEATBELT_PRETENSIONER_PSG": 9,
}

SQUIB_DID_MAP = {
    0x0446: "Squib_Resistance_All",
    0x0447: "Squib_Status",
    0x0448: "Squib_Deployment_Count",
}

SQUIB_DID_0446_CODEMAP = {
    0x00: "Normal",
    0x01: "Short to GND",
    0x02: "Short to VBAT",
    0x03: "Open Circuit",
    0x04: "Resistance High",
    0x05: "Resistance Low",
}

RESISTANCE_MIN_OHM = 1.8
RESISTANCE_MAX_OHM = 2.8
DEPLOYMENT_CURRENT_A = 1.5
