"""
Project Configuration: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/project_config.py

All module configs are also in this same config/ folder:
    m310_m314_m110/config/gpo_config.py
    m310_m314_m110/config/edr_config.py
    ... etc.

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="GPO")
    ctx.config.CAN_CHANNEL            # project config
    ctx.mod_config.TEST_SIGNALS       # current module config
    ctx.get_module_config("EDR").EDR_DIDS  # another module config
"""

from pathlib import Path

PROJECT_NAME = "M310_M314_M110"
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ── Tool Paths ──
WINIDEA_WORKSPACE = r"C:\iSYSTEM\M310_M314_M110\workspace.xjrf"
CAN_DB_PATH = r"C:\CAN_DB\M310_M314_M110\M310_M314_M110.dbc"
FLASH_FILE_PATH = r"C:\Builds\M310_M314_M110\latest.hex"

# ── Output ──
TEST_RESULTS_DIR = str(PROJECT_ROOT / "test_results")
TEST_LOGS_DIR = str(PROJECT_ROOT / "test_logs")

# ── CAN ──
CAN_CHANNEL = 0
CAN_BAUD_RATE = 500000
CAN_FD_ENABLED = False

# ── Diagnostics ──
DIAG_RX_ID = 0x641
DIAG_TX_ID = 0x642
DIAG_FUNCTIONAL_ID = 0x7DF

DEFAULT_CAN_LOG_IDS = [0x100, 0x200, 0x300, 0x400, 0x641, 0x642]

# ── ECU ──
ECU_VARIANT = "DEFAULT"
SOFTWARE_VERSION = "1.0.0"
HARDWARE_VERSION = "1.0"

# ── Timing ──
DEFAULT_TIMEOUT = 30
FLASH_TIMEOUT = 120
RESET_WAIT_TIME = 5

# ── WinIDEA ──
TARGET_CPU = "TC397"
