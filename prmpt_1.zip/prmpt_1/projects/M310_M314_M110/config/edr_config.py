"""
Module Configuration: EDR
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/edr_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is EDR
    ctx.get_module_config("EDR").<SETTING>  # from any other module
"""

# PROJECT_NAME = "M310_M314_M110"
# MODULE_NAME = "EDR"

from shared_libraries.jscript_translation import CAN, RESULT
from shared_libraries.core_functions import enter_ext_session, Internal_Security_Access
from shared_libraries.configuration_control import (
    EXPECTED_SQUIB_DEPLOYMENT,
    SQUIB_DEPLOYMENT_LABELS,
    TIMETO_DEPLOY_LABELS,
    TestStatus,
)

Crash_Parameters = [
    ["Life_Time_Event_Number", 4, 7],
    ["Multi_Event_Number", 25, 25],
    ["Squib_Deployment_Status", 358, 359],
    ["TimetoDeploy", 201, 226],
    ["Completion_Status", 227, 227],
    ["200msCompletion_Status", 227, 227],
    ["Crash_Location", 26, 26],
    ["Crash_Record_Lock_Status",26,26],
    ["Time_Btw_Events",228,229],
    ["SRS_ECU_Status",227,227]
]

EDR_UPP_PARAMETERS = [
    # --- Basic Event Info ---
    # 1. Life_Time_Event_Number: Byte 4 to byte 7
    {"name": "Life_Time_Event_Number", "range": "4-7", "type": "int"},
    # 2. VehSpdLgtAtTimeZero: Byte 8 to Byte 9
    {"name": "VehSpdLgtAtTimeZero", "range": "8-9", "type": "int", "scaling_factor": 0.015625, "unit": "kmPh", "signed": False},
    # 3. BattVolt: Byte 10
    {"name": "BattVolt", "range": 10, "type": "int", "scaling_factor": 0.1, "unit": "V", "signed": False},
    # 4. Odometer: Byte 11 to byte 13
    {"name": "Odometer", "range": "11-13", "type": "int", "signed": False},
    # 5. VEHICLE_STATE: Byte 14, Bit 0 to 2
    {"name": "VEHICLE_STATE", "range": "14.0-14.2", "type": "bits"},

    # --- SRS/Multi-Event Info ---
    # 6. (missing)
    # 7. SRSMalLampOnIGCycle: Byte 16 to byte 17
    {"name": "SRSMalLampOnIGCycle", "range": "16-17", "type": "int"},
    # 8. SRSMalLampOnTime: Byte 18, byte 19
    {"name": "SRSMalLampOnTime", "range": "18-19", "type": "int"},
    # 9-14. (missing)
    # 15. Multi_Event_Number: byte 25
    {"name": "Multi_Event_Number", "range": 25, "type": "int"},
    # 16. Crash_Location: byte 26
    {"name": "Crash_Location", "range": 26, "type": "int"},
    # 17. Crash_Record_Lock_Status: byte 26 bit 7
    {"name": "Crash_Record_Lock_Status", "range": "26.7", "type": "bit"},
    # 18. IgnCycleCrash: Byte 27-30
    {"name": "IgnCycleCrash", "range": "27-30", "type": "int"},
    # 19. (missing)
    # 20. SRSMalFunIndicator: byte 31 bit 5
    {"name": "SRSMalFunIndicator", "range": "31.5", "type": "bit"},
    # 21. BltLockStateFPsngr: byte 31 bit 4, bit 3 (read as bit4,bit3)
    {"name": "BltLockStateFPsngr", "range": "31.4,31.3", "type": "custom_bits"},
    # 22. BltLockStateDriver: byte 31 bit 2, bit 1 (read as bit2,bit1)
    {"name": "BltLockStateDriver", "range": "31.2,31.1", "type": "custom_bits"},

    # --- Multi-sample Data ---
    # 23-26. (missing)
    # 27. VehSpdLgt: Data Start Byte = 33, Data Byte Length = 34, Data Bytes per Sample = 2, Data Samples Number = 17
    {
        "name": "VehSpdLgt",
        "data_start_byte": 33,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.015625,
        "offset": 0,
        "signed": False,
        "unit": "kmph",
        "type": "multi_sample_bytes",
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    # 28. Brake_Switch: Data Start Byte = 67, Data Byte Length = 5, Data Bytes per Sample = 1, Data Samples Number = 17
    {
        "name": "Brake_Switch",
        "data_start_byte": 67,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "type": "multi_sample_bits",
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    # 29. ACC_PED: Data Start Byte = 72, Data Byte Length = 17, Data Bytes per Sample = 1, Data Samples Number = 17
    {
        "name": "ACC_PED",
        "data_start_byte": 72,
        "data_byte_length": 17,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.4,
        "offset": 0,
        "unit": "%",
        "type": "multi_sample_bytes",
        "sample_range": {"start": -5, "end": 3, "step": 0.5},
        "signed": False
    },
    # 30. MOTOR_SPD: Data Start Byte = 89, Data Byte Length = 34, Data Bytes per Sample = 2, Data Samples Number = 17
    {
        "name": "MOTOR_SPD",
        "data_start_byte": 89,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 1,
        "offset": 0,
        "unit": "rpm",
        "type": "multi_sample_bytes",
        "sample_range": {"start": -5, "end": 3, "step": 0.5},
        "signed": False
    },

    # 31-34. (missing)
    # 35. Absolute_Angle: Data Start Byte = 162, Data Byte Length = 34, Data Bytes per Sample = 2, Data Samples Number = 17
    {
        "name": "Absolute_Angle",
        "data_start_byte": 162,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.1,
        "offset": 0,
        "unit": "deg",
        "type": "multi_sample_bytes",
        "signed": True,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },

    # 36. (missing)
    # 37-48. TimetoDeploy: Data Start Byte = 201, Data Byte Length = 26, Data Bytes per Sample = 2, Data Samples Number = 13
    {
        "name": "TimetoDeploy",
        "data_start_byte": 201,
        "data_byte_length": 26,
        "data_bytes_per_sample": 2,
        "data_samples_number": 13,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "type": "multi_sample_bytes",
        "signed": False
    },

    # --- Status Bits ---
    # 49. Completion_Status: byte 227 bit 7
    {
        "name": "Completion_Status",
        "range": "227.7",
        "type": "bit"
    },
    # 50. 200msCompletion_Status: byte 227 bit 6
    {
        "name": "200msCompletion_Status",
        "range": "227.6",
        "type": "bit"
    },
    # 51. SRS_ECU_Status: byte 227 bit 5
    {
        "name": "SRS_ECU_Status",
        "range": "227.5",
        "type": "bit"
    },
    # 52. Time_Btw_Events: byte 228-229
    {
        "name": "Time_Btw_Events",
        "range": "228-229",
        "type": "int",
        "scaling_factor": 0.5
    },

    # --- Delta V Data ---
    # 53. DeltaVLgt: byte 230, byte length 26
    {
        "name": "DeltaVLgt",
        "data_start_byte": 230,
        "data_byte_length": 26,
        "data_bytes_per_sample": 1,
        "data_samples_number": 26,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "scaling_factor": 1,
        "offset": -100,
        "signed": False
    },
    # 54. DeltaVLat: byte 256, byte length 26
    {
        "name": "DeltaVLat",
        "data_start_byte": 256,
        "data_byte_length": 26,
        "data_bytes_per_sample": 1,
        "data_samples_number": 26,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "scaling_factor": 1,
        "offset": -100,
        "signed": False
    },
    # 55. TimeMaxDeltaVLgt: byte 282, byte length 2
    {
        "name": "TimeMaxDeltaVLgt",
        "data_start_byte": 282,
        "data_byte_length": 2,
        "data_bytes_per_sample": 2,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "type": "multi_sample_bytes",
        "scaling_factor": 0.5,  
        "unit": "ms",
        "signed": False
    },
    # 56. TimeMaxDeltaVLat: byte 284, byte length 2
    {
        "name": "TimeMaxDeltaVLat",
        "data_start_byte": 284,
        "data_byte_length": 2,
        "data_bytes_per_sample": 2,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "type": "multi_sample_bytes",
        "scaling_factor": 0.5,
        "unit": "ms",
        "signed": False
    },
    # 57. MaxDeltaVLgt: byte 286, byte length 1
    {
        "name": "MaxDeltaVLgt",
        "data_start_byte": 286,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "scaling_factor": 1,
        "offset": -100,
        "signed": False
    },
    # 58. MaxDeltaVLat: byte 287, byte length 1
    {
        "name": "MaxDeltaVLat",
        "data_start_byte": 287,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "scaling_factor": 1,
        "offset": -100,
        "signed": False
    },

    # --- Squib Deployment ---
    # 59-62. (missing)
    # 63-75. Squib_Deployment_Status
    {
        "name": "Squib_Deployment_Status",
        "range": [
            "358.3", "358.2", "358.1", "358.0", "359.4"
        ],
        "type": "custom_bits"
    },

    # --- Gear Info ---
    # 76-87. (missing)
    # 88. Gear_Actual: Data Start Byte = 360, Data Byte Length = 5, Data Bytes per Sample = 1, Data Samples Number = 10
    {
        "name": "Gear_Actual",
        "data_start_byte": 360,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_start_bit": 0,
        "signed": False,
        "data_bit_length": 4,
        "data_samples_number": 10,
        "type": "multi_sample_bits",
        "sample_range": {"start": -5.5, "end": 3, "step": 1.0}, 
    },

    # 89. Reset_Cycle_Counter: Byte 365 to byte 368 (DID 0x0455, SecLevel1)
    {
        "name": "Reset_Cycle_Counter",
        "range": "365-368",
        "type": "int",
        "unit": "count",
        "signed": False
    }
]

# Crash location bit mapping for byte 26 (LSB = bit 0).
# Define here to keep decoding consistent across variants.
CRASH_LOCATION_BITS = [
    (0, "Front Crash"),
    (1, "Left Side Crash"),
    (2, "Right Side Crash"),
    (3, "Rear Crash"),
    (4, "Understrike Crash"),
    (5, "Roll Over"),
    (6, "Near Crash"),
]

# Helper functions to be kept here for extraction and other data analysis

def get_sample_interval_ms(param_name, default_ms=500):
    """Return sampling interval in ms derived from the EDR definition."""
    param = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == param_name), None)
    if not param:
        return default_ms

    # Explicit override takes precedence if present.
    if "sample_interval_ms" in param:
        try:
            return int(round(float(param["sample_interval_ms"])))
        except Exception:
            return default_ms

    sr = param.get("sample_range")
    if sr and "step" in sr:
        try:
            step_seconds = float(sr.get("step"))
            return int(round(abs(step_seconds) * 1000.0))
        except Exception:
            return default_ms

    return default_ms


def build_time_axis_and_t0(param_name, crash_type, rsu_t0_offsets=None, default_len=None, default_t0_index=None):
    """Return (time_axis, T0_INDEX) using EDR definition and RSU offsets."""
    # Baseline fallback from requested parameter definition (if present)
    param = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == param_name), None)
    param_default_len = None
    if param and param.get("data_samples_number") is not None:
        try:
            param_default_len = int(param.get("data_samples_number"))
        except Exception:
            param_default_len = None

    if param_default_len is None and param and "sample_range" in param:
        try:
            sr = param["sample_range"]
            start = float(sr.get("start"))
            end = float(sr.get("end"))
            step = float(sr.get("step"))
            param_default_len = int(round(((end - start) / step) + 1))
        except Exception:
            param_default_len = None

    if param_default_len is None:
        param_default_len = default_len if default_len is not None else 1

    param_default_t0_index = 10
    if param and "sample_range" in param:
        try:
            sr = param["sample_range"]
            start = float(sr.get("start"))
            step = float(sr.get("step"))
            param_default_t0_index = int(round((0.0 - start) / step))
        except Exception:
            param_default_t0_index = 10

    default_len = param_default_len if default_len is None else default_len
    default_t0_index = param_default_t0_index if default_t0_index is None else default_t0_index

    time_axis = []

    if param and "sample_range" in param:
        sr = param["sample_range"]
        try:
            start = float(sr.get("start"))
            end = float(sr.get("end"))
            step = float(sr.get("step"))
        except Exception:
            return [i for i in range(0, default_len)], max(0, min(default_t0_index, default_len - 1))

        total = int(param.get("data_samples_number", 0) or int(((end - start) / step) + 1))
        t = start
        for _ in range(total):
            time_axis.append(round(t, 6))
            t = t + step

        offsets = rsu_t0_offsets or {}
        t0_index_raw = offsets.get(crash_type, offsets.get("default", None))
        if t0_index_raw is None:
            t0_index = default_t0_index
        else:
            try:
                t0_index = int(round(float(t0_index_raw)))
            except Exception:
                t0_index = default_t0_index

        if t0_index < 0:
            t0_index = 0
        if t0_index >= len(time_axis):
            t0_index = len(time_axis) - 1
        return time_axis, t0_index

    # Fallback when definition is missing
    time_axis = [i for i in range(0, default_len)]
    t0_index = max(0, min(default_t0_index, len(time_axis) - 1))
    return time_axis, t0_index

def get_sample_range(edr_param, edr_parameters=None):
    """
    Returns the sample intervals for the given EDR parameter name.
    Optionally accepts a custom EDR parameter list (default: EDR_UPP_PARAMETERS).
    """
    params = edr_parameters if edr_parameters is not None else EDR_UPP_PARAMETERS
    param_def = next((p for p in params if p.get("name") == edr_param), None)
    if param_def and "sample_range" in param_def:
        sr = param_def["sample_range"]
        start, end, step = sr["start"], sr["end"], sr["step"]
        samples = []
        val = start
        while val <= end + 1e-9:
            samples.append(round(val, 3))
            val += step
        return samples
    return []

def _to_signed(val, bits):
    if bits <= 0:
        return val
    threshold = 1 << (bits - 1)
    mask = 1 << bits
    return val - mask if val >= threshold else val

def read_edr_parameters_UPP(param_names=None, did: str = "220455", crash_type=None, can_wakeup=False, return_data: bool = False):
    print("crash_type",crash_type)
    enter_ext_session()
    Internal_Security_Access(0x01)
    # Sanitize DID (accept "0455", "220455", "22 04 55", "0x0455", etc.)
    did_clean = str(did).replace(" ", "").lower().replace("0x", "")
    if not all(c in "0123456789abcdef" for c in did_clean):
        raise ValueError(f"Invalid DID format (non-hex): {did}")

    if len(did_clean) == 4:
        did_request = f"22{did_clean}"
    elif len(did_clean) == 6 and did_clean.startswith("22"):
        did_request = did_clean
    else:
        raise ValueError(f"Invalid DID format: {did}. Use 4-hex DID (e.g., 0455) or full request (e.g., 220455).")

    response = CAN.SendDiagByValues(did_request.upper())
    print(f"EDR Response ({did_request.upper()})", response)
    RESULT.LogAction(f"EDR Response DID {did_request.upper()}", response)
    data = response.split(" ")
    print("data",data)
    # Generic squib bit logging based on configuration
    squib_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == "Squib_Deployment_Status"), None)
    if squib_def:
        ranges = squib_def.get("range", [])
        if isinstance(ranges, str):
            ranges = [x.strip() for x in ranges.split(',')]
        labels_map = {f"{b}.{bit}": label for label, b, bit in SQUIB_DEPLOYMENT_LABELS}
        for rng in ranges:
            try:
                byte_str, bit_str = rng.split('.')
                byte_idx = int(byte_str)
                bit_idx = int(bit_str)
            except Exception:
                continue
            data_idx = byte_idx - 1
            if data_idx < 0 or data_idx >= len(data):
                continue
            raw_byte = data[data_idx]
            try:
                val_int = int(raw_byte, 16) if isinstance(raw_byte, str) else int(raw_byte)
            except Exception:
                continue
            bit_val = (val_int >> bit_idx) & 0x1
            label = labels_map.get(f"{byte_idx}.{bit_idx}", f"Squib {byte_idx}.{bit_idx}")
            RESULT.LogAction(f"{label} Value", bit_val)
    '''response = CAN.SendDiagByValues("220455")
    print("EDR Response",response)
    RESULT.LogAction("EDR Resposne:  ", response)
    data = response.split(" ")
    data = response.split(" ")'''
    if param_names is None:
        param_names = [p["name"] for p in EDR_UPP_PARAMETERS]
    elif isinstance(param_names, str):
        param_names = [param_names]
    # For collecting date/time fields
    event_fields = {}
    results_map = {}
    raw_values_map = {}
    for param in param_names:
        if (isinstance(param, (list, tuple)) and len(param) == 3):
            paramName, start, end = param
            paramValues = [data[j-1] if 0 <= (j-1) < len(data) else None for j in range(start, end+1)]
        else:
            paramName = param
            param_def = next((p for p in EDR_UPP_PARAMETERS if p["name"] == paramName), None)
            paramValues = []
            if param_def:
                if "range" in param_def:
                    rng = param_def["range"]
                    if isinstance(rng, int):
                        paramValues = [data[rng-1] if 0 <= (rng-1) < len(data) else None]
                    elif isinstance(rng, list):
                        unique_bytes = sorted(set(int(idx.split('.')[0]) for idx in rng))
                        paramValues = [data[byte_idx-1] if 0 <= (byte_idx-1) < len(data) else None for byte_idx in unique_bytes]
                    elif isinstance(rng, str) and "-" in rng:
                        start_str, end_str = rng.split("-")
                        if "." not in start_str and "." not in end_str:
                            start, end = int(start_str), int(end_str)
                            paramValues = [data[j-1] if 0 <= (j-1) < len(data) else None for j in range(start, end+1)]
                        else:
                            start_byte, start_bit = map(int, start_str.split("."))
                            end_byte, end_bit = map(int, end_str.split("."))
                            paramValues = [data[start_byte-1] if 0 <= (start_byte-1) < len(data) else None]
                    elif isinstance(rng, str) and "," in rng:
                        indices = [x for x in rng.split(",")]
                        for idx in indices:
                            if '.' in idx:
                                byte_idx = int(idx.split('.')[0])
                                paramValues.append(data[byte_idx-1] if 0 <= (byte_idx-1) < len(data) else None)
                            else:
                                byte_idx = int(idx)
                                paramValues.append(data[byte_idx-1] if 0 <= (byte_idx-1) < len(data) else None)
                    elif isinstance(rng, str) and '.' in rng:
                        byte_idx = int(rng.split('.')[0])
                        paramValues = [data[byte_idx-1] if 0 <= (byte_idx-1) < len(data) else None]
                    else:
                        paramValues = [data[int(rng)-1] if 0 <= (int(rng)-1) < len(data) else None]
                elif "data_start_byte" in param_def and "data_byte_length" in param_def:
                    start = param_def["data_start_byte"]
                    end = start + param_def["data_byte_length"] - 1
                    paramValues = [data[j-1] if 0 <= (j-1) < len(data) else None for j in range(start, end+1)]
                else:
                    paramValues = []
            else:
                paramValues = []

        print("paramName", paramName)
        print("paramValues", paramValues)
        decodedValues = decodeParameterValues(paramName, paramValues)
        results_map[paramName] = decodedValues
        raw_values_map[paramName] = paramValues
        # Pass context to printParameterValues for special comparisons
        if paramName == "Crash_Location":
            printParameterValues.crash_type = crash_type
        # Provide IGN OFF context for SRS_ECU_Status expectation
        printParameterValues.can_wakeup = can_wakeup
        printParameterValues(paramName, decodedValues, paramValues)

        if paramName in [
            "EventDtYear", "EventDt_Month", "EventDt_Day",
            "EventTime_Hour", "EventTime_Min", "EventTime_Sec"
        ] and decodedValues:
            if paramName == "EventDtYear":
                year_val = decodedValues[0]
                if year_val < 100:
                    year_val += 2020
                event_fields[paramName] = year_val
            else:
                event_fields[paramName] = decodedValues[0]

    # Print summary only once per call
    if all(k in event_fields for k in [
        "EventDtYear", "EventDt_Month", "EventDt_Day",
        "EventTime_Hour", "EventTime_Min", "EventTime_Sec"
    ]):
        date_str = f"DATE: {event_fields['EventDt_Day']:02}/{event_fields['EventDt_Month']:02}/{event_fields['EventDtYear']}"
        time_str = f"TIME: {event_fields['EventTime_Hour']:02}:{event_fields['EventTime_Min']:02}:{event_fields['EventTime_Sec']:02}"
        print(date_str)
        print(time_str)
        RESULT.LogAction("Event Date", date_str)
        RESULT.LogAction("Event Time", time_str)

    for crash in ["front", "left", "right", "rear", "near"]:
        if crash_type == crash and (
            any(
                (isinstance(p, (list, tuple)) and p[0] == "Squib_Deployment_Status") or
                (isinstance(p, str) and p == "Squib_Deployment_Status")
                for p in param_names
            ) or param_names is None
        ):
            # Decode bytes for squib deployment using SQUIB_DEPLOYMENT_LABELS
            # Build byte value array for all unique bytes in SQUIB_DEPLOYMENT_LABELS
            unique_bytes = sorted(set(byte for _, byte, _ in SQUIB_DEPLOYMENT_LABELS))
            byte_vals = []
            for b in unique_bytes:
                idx = b - 1
                val = int(data[idx], 16) if len(data) > idx else 0
                byte_vals.append(val)
            byte_index_map = {b: i for i, b in enumerate(unique_bytes)}
            #from Test_Enviornment.Library.ConfigurationControl import EXPECTED_SQUIB_DEPLOYMENT
            expected = EXPECTED_SQUIB_DEPLOYMENT.get(crash, {})
            all_match = True
            result_lines = []
            decoded_samples_lines = []
            for label, byte, bit in SQUIB_DEPLOYMENT_LABELS:
                idx = byte_index_map.get(byte, 0)
                act_val = (byte_vals[idx] >> bit) & 0x1
                exp_val = expected.get(label, 0)
                match = (act_val == exp_val)
                print(f"DEBUG: label={label}, byte={byte}, bit={bit}, act_val={act_val}, exp_val={exp_val}, match={match}")
                all_match = all_match and match
                result_lines.append(f"{label}: Expected={exp_val}, Actual={act_val} => {'Passed' if match else 'Failed'}")
                decoded_samples_lines.append(f"{label} {byte} bit {bit} Value: {act_val}")
            summary = "<br>".join(result_lines)
            decoded_samples_str = "<br>".join(decoded_samples_lines)
            print("summary", summary)
            # Log decoded samples step
            #RESULT.LogCustomAction("Squib_Deployment_Status Decoded Samples", decoded_samples_str, decoded_samples_str, True)
            # If any part of the summary contains 'Failed', use TestStatus.Failed, else TestStatus.Passed
            result_status = TestStatus.Failed if "Failed" in summary else TestStatus.Passed
            print("result_status",result_status)
            is_passed = (result_status == TestStatus.Passed)
            RESULT.LogCustomAction(f"Squib Deployment Comparison ({crash})", summary, summary, is_passed)
            print(f"Squib Deployment Comparison ({crash}):\n{summary}")
    if return_data:
        return {"data": data, "decoded": results_map, "raw": raw_values_map}
def decodeParameterValues(paramName, values):
    param_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == paramName), None)
    if not param_def:
        return values

    typ = param_def.get("type")
    scaling = param_def.get("scaling_factor", 1)
    offset = param_def.get("offset", 0)

    if typ == "int":
        hex_str = ''.join([v.replace('0x', '').zfill(2) for v in values if v is not None])
        if hex_str:
            raw_val = int(hex_str, 16)
            signed = param_def.get("signed", False)
            if signed:
                byte_len = len(hex_str) // 2
                bits = byte_len * 8
                raw_val = _to_signed(raw_val, bits)
            physical_val = raw_val * scaling + offset
            return [physical_val]
        else:
            return []
    elif typ == "bit":
        if values and values[0] is not None:
            byte_idx, bit_idx = map(int, param_def["range"].split('.'))
            v = values[0]
            val = int(v, 16) if isinstance(v, str) and v.startswith("0x") else int(v)
            return [(val >> bit_idx) & 1]
        return []
    elif typ == "bits":
        if values and values[0] is not None:
            start_bit = int(param_def["range"].split('-')[0].split('.')[-1])
            end_bit = int(param_def["range"].split('-')[1].split('.')[-1])
            v = values[0]
            val = int(v, 16) if isinstance(v, str) and v.startswith("0x") else int(v)
            mask = (1 << (end_bit - start_bit + 1)) - 1
            return [(val >> start_bit) & mask]
        return []
    elif typ == "custom_bits":
        # FIX: read each bit from its correct byte; preserve given order
        rng = param_def["range"]
        if isinstance(rng, str):
            indices = [x.strip() for x in rng.split(',')]
        elif isinstance(rng, list):
            indices = rng
        else:
            indices = [rng]

        # Build mapping byte_index -> raw byte value (first occurrence)
        byte_values = {}
        # Collect raw bytes from 'values' in the same order they were added
        # When paramValues were built, each index contributed one byte (duplicates included)
        # Zip indices with values to capture correct raw per index
        for idx, raw in zip(indices, values):
            if raw is None:
                continue
            byte_part = idx.split('.')[0]
            try:
                b_idx = int(byte_part)
            except ValueError:
                continue
            # Keep first occurrence (or overwrite – both give same raw since duplicates are same byte)
            if b_idx not in byte_values:
                byte_values[b_idx] = raw

        bits_ordered = []
        for idx in indices:
            parts = idx.split('.')
            if len(parts) != 2:
                continue
            b_idx = int(parts[0])
            bit_idx = int(parts[1])
            raw = byte_values.get(b_idx)
            if raw is None:
                bits_ordered.append(0)
                continue
            val_int = int(raw, 16) if isinstance(raw, str) and raw.startswith("0x") else int(raw)
            bit_val = (val_int >> bit_idx) & 1
            bits_ordered.append(bit_val)

        # Combine bits: first in list is MSB
        result = 0
        for b in bits_ordered:
            result = (result << 1) | b
        return [result]
    elif typ == "multi_sample_bytes":
        samples = []
        bytes_per_sample = param_def.get("data_bytes_per_sample", 1)
        num_samples = param_def.get("data_samples_number", 1)
        scaling = param_def.get("scaling_factor", 1)
        offset = param_def.get("offset", 0)
        for i in range(num_samples):
            idx = i * bytes_per_sample
            if idx + bytes_per_sample > len(values):
                break
            sample_bytes = values[idx:idx+bytes_per_sample]
            if any(v is None for v in sample_bytes):
                continue
            raw_val = 0
            for b in sample_bytes:
                raw_val = (raw_val << 8) | (int(b, 16) if isinstance(b, str) and b.startswith("0x") else int(b))
            signed = param_def.get("signed", False)
            if signed:
                bits = bytes_per_sample * 8
                raw_val = _to_signed(raw_val, bits)
            physical_val = raw_val * scaling + offset
            samples.append(physical_val)
        return samples
    elif typ == "multi_sample_bits":
        data_bit_length = param_def.get("data_bit_length", 1)
        num_samples = param_def.get("data_samples_number", 1)
        bits = ""
        for v in values:
            if v is None:
                continue
            bits += f"{int(v,16):08b}" if isinstance(v, str) and v.startswith("0x") else f"{int(v):08b}"
        decoded = []
        for i in range(num_samples):
            start = i * data_bit_length
            end = start + data_bit_length
            if end > len(bits):
                break
            sample_bits = bits[start:end]
            decoded.append(int(sample_bits, 2))
        return decoded
    else:
        return values
def printParameterValues(paramName, values, paramValues=None):
    # Time_Btw_Events decoding and comparison
    if paramName == "Time_Btw_Events" and paramValues:
        # paramValues should be two bytes
        b1 = paramValues[0] if len(paramValues) > 0 else None
        b2 = paramValues[1] if len(paramValues) > 1 else None
        # Accept both '0xff' and 'ff' as FF
        is_ff = (str(b1).lower() in ["0xff", "ff"]) and (str(b2).lower() in ["0xff", "ff"])
        if is_ff:
            summary = "Expected: FF FF, Actual: FF FF => Passed"
            print(summary)
            RESULT.LogCustomAction("Time_Btw_Events Comparison", summary, summary, True)
        else:
            try:
                v1 = int(b1, 16) if b1 is not None else 0
                v2 = int(b2, 16) if b2 is not None else 0
                combined = (v1 << 8) | v2
                summary = f"Expected: FF FF, Actual: {combined} => Failed"
                print(summary)
                RESULT.LogCustomAction("Time_Btw_Events Comparison", summary, summary, False)
            except Exception:
                summary = f"Expected: FF FF, Actual: {b1} {b2} => Failed"
                print(summary)
                RESULT.LogCustomAction("Time_Btw_Events Comparison", summary, summary, False)
        return

    # Crash_Record_Lock_Status decoding and comparison
    if paramName == "Crash_Record_Lock_Status" and values:
        # Decoded value is expected to be [0] or [1]
        decoded_val = values[0] if values else None
        lock_status_str = "Locked" if decoded_val == 1 else "Unlocked"
        crash_type = getattr(printParameterValues, "crash_type", None)
        # For Near Crash, expected is 0 (Unlocked), else 1 (Locked)
        expected_val = 0 if crash_type == "near" else 1
        expected_str = "Unlocked" if expected_val == 0 else "Locked"
        is_passed = (decoded_val == expected_val)
        status = TestStatus.Passed if is_passed else TestStatus.Failed
        summary = f"Expected: {expected_val}({expected_str}), Actual: {decoded_val}({lock_status_str}) => {'Passed' if is_passed else 'Failed'}"
        print(summary)
        RESULT.LogCustomAction(f"Crash Record Lock Status Comparison ({crash_type})", summary, summary, is_passed)
        return
    if paramName == "Squib_Deployment_Status":
        return
    # SRS_ECU_Status decoding and comparison (based on can_wakeup context)
    if paramName == "SRS_ECU_Status" and values:
        decoded_val = values[0] if isinstance(values, list) else values
        ign_ctx = getattr(printParameterValues, "can_wakeup", False)
        expected_val = 1 if ign_ctx else 0
        is_passed = (decoded_val == expected_val)
        summary = f"Expected: {expected_val}, Actual: {decoded_val} => {'Passed' if is_passed else 'Failed'}"
        print(summary)
        RESULT.LogCustomAction("SRS_ECU_Status Comparison", summary, summary, is_passed)
        return
    raw_bytes = paramValues if paramValues is not None else values
    raw_str = " ".join(
        f"0x{int(v,16):02X}" if isinstance(v, str) and v.startswith("0x")
        else f"0x{int(v):02X}" for v in raw_bytes if v is not None
    )
    print(f"{paramName} Raw EDR Bytes: {raw_str}")
    RESULT.LogCustomAction(f"{paramName} Raw EDR Bytes", raw_str, raw_str, TestStatus.Passed)
 
    param_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == paramName), None)
    typ = param_def.get("type") if param_def else None
    decoded_lines = []
    
    if paramName == "Crash_Location" and values:
        # values[0] is the decoded int, but we want the original hex string
        if paramValues and paramValues[0] is not None:
            hex_str = paramValues[0].replace("0x", "") if isinstance(paramValues[0], str) else f"{int(paramValues[0]):02X}"
            crash_location_str = decode_crash_location(hex_str)
            print(crash_location_str)
            # Determine expected crash location from crash_type
            crash_type = getattr(printParameterValues, "crash_type", None)
            crash_type_map = {
                "front": "Front Crash",
                "left": "Left Side Crash",
                "right": "Right Side Crash",
                "rear": "Rear Crash",
                "near": "Near Crash"
            }
            expected_location = crash_type_map.get(crash_type, None)
            # Parse obtained crash locations
            obtained_locations = crash_location_str.replace("Crash Location: ", "").split(", ") if crash_location_str.startswith("Crash Location: ") else []
            # Only pass if obtained is exactly the expected location (no extras)
            if expected_location:
                is_passed = (len(obtained_locations) == 1 and obtained_locations[0] == expected_location)
                status = TestStatus.Passed if is_passed else TestStatus.Failed
                summary = f"Expected: {expected_location}, Actual: {crash_location_str} => {'Passed' if is_passed else 'Failed'}"
                RESULT.LogCustomAction(f"Crash Location Comparison ({crash_type})", summary, summary, is_passed)
            else:
                RESULT.LogCustomAction("Crash Location", crash_location_str, crash_location_str, TestStatus.Passed)
        else:
            print("Crash Location: Unknown")
            RESULT.LogCustomAction("Crash Location", "Unknown", "Unknown", TestStatus.Failed)
        return
        # --- Date/Time collection logic (modified) ---
    if not hasattr(printParameterValues, "event_fields"):
        printParameterValues.event_fields = {}
    event_fields = printParameterValues.event_fields
 
    if paramName in [
        "EventDtYear", "EventDt_Month", "EventDt_Day",
        "EventTime_Hour", "EventTime_Min", "EventTime_Sec"
    ] and values:
        # Apply year offset rule
        if paramName == "EventDtYear":
            year_val = values[0]
            if year_val < 100:
                year_val += 2020
            event_fields[paramName] = year_val
            print(f"{paramName} Decoded Value(s): [{year_val}]")
            RESULT.LogCustomAction(f"{paramName} Decoded Samples", str([year_val]), str([year_val]), TestStatus.Passed)
        else:
            event_fields[paramName] = values[0]
            print(f"{paramName} Decoded Value(s): {values}")
            RESULT.LogCustomAction(f"{paramName} Decoded Samples", str(values), str(values), TestStatus.Passed)
 
        # When all six fields collected, print & log the two summary lines, then reset for next set
        if all(k in event_fields for k in [
            "EventDtYear", "EventDt_Month", "EventDt_Day",
            "EventTime_Hour", "EventTime_Min", "EventTime_Sec"
        ]):
            # Do NOT clamp/month fix per request (leave original decoded values)
            date_summary = f"Event Date: {event_fields['EventDt_Day']:02}/{event_fields['EventDt_Month']:02}/{event_fields['EventDtYear']}"
            time_summary = f"Event Time: {event_fields['EventTime_Hour']:02}:{event_fields['EventTime_Min']:02}:00"
            print(date_summary)
            print(time_summary)
            RESULT.LogCustomAction("Event Date", date_summary, date_summary, TestStatus.Passed)
            RESULT.LogCustomAction("Event Time", time_summary, time_summary, TestStatus.Passed)
            # Reset for next multi-event set inside same DID
            printParameterValues.event_fields = {}
        return
    # --- Existing logic for other parameters ---
    # Exclude Squib_Deployment_Status from generic decoded samples logging
    if paramName == "Squib_Deployment_Status":
        return
    if paramName == "TimetoDeploy":
        # ...existing code unchanged...
        for idx, (label, start_byte, byte_len) in enumerate(TIMETO_DEPLOY_LABELS):
            b1 = paramValues[idx*2] if idx*2 < len(paramValues) else None
            b2 = paramValues[idx*2+1] if idx*2+1 < len(paramValues) else None
            if b1 is None or b2 is None:
                val_str = "--"
            else:
                if (str(b1).lower() in ["0xff", "ff"]) and (str(b2).lower() in ["0xff", "ff"]):
                    val_str = "FF FF"
                else:
                    try:
                        v1 = int(b1, 16) if isinstance(b1, str) and b1.startswith("0x") else int(b1)
                        v2 = int(b2, 16) if isinstance(b2, str) and b2.startswith("0x") else int(b2)
                        combined = (v1 << 8) | v2
                        val_str = str(combined)
                    except Exception:
                        val_str = f"{b1} {b2}"
            line = f"{label} {start_byte} {byte_len} Value: {val_str}"
            print(line)
            decoded_lines.append(line)
        #RESULT.LogCustomAction(f"{paramName} Decoded Samples", "<br>".join(decoded_lines), "<br>".join(decoded_lines), TestStatus.Passed)
        return
 
    # Default handling for other parameters
    if typ == "multi_sample_bytes":
        unit = param_def.get("unit", "")
        sample_range = param_def.get("sample_range")
        if sample_range:
            start = sample_range.get("start", 0)
            end = sample_range.get("end", 0)
            step = sample_range.get("step", 1)
            # Build timing labels
            labels = []
            val = start
            for _ in range(len(values)):
                if val == 0:
                    labels.append("0ms")
                else:
                    labels.append(f"{val:+g}ms")
                val += step
            for idx, v in enumerate(values):
                label = labels[idx] if idx < len(labels) else f"Sample {idx+1}"
                if unit:
                    line = f"{paramName} {label}:{v:.3f} {unit}"
                else:
                    line = f"{paramName} {label}:{v:.3f}"
                print(line)
                decoded_lines.append(line)
        else:
            for idx, v in enumerate(values):
                if unit:
                    line = f"{paramName} Sample {idx+1}: {v:.3f} {unit}"
                else:
                    line = f"{paramName} Sample {idx+1}: {v:.3f}"
                print(line)
                decoded_lines.append(line)
        #RESULT.LogCustomAction(f"{paramName} Decoded Samples", "<br>".join(decoded_lines), "<br>".join(decoded_lines), TestStatus.Passed)
    elif typ == "multi_sample_bits":
        sample_range = param_def.get("sample_range")
        if sample_range:
            start = sample_range.get("start", 0)
            end = sample_range.get("end", 0)
            step = sample_range.get("step", 1)
            labels = []
            val = start
            for _ in range(len(values)):
                if val == 0:
                    labels.append("0ms")
                else:
                    labels.append(f"{val:+g}ms")
                val += step
            for idx, v in enumerate(values):
                label = labels[idx] if idx < len(labels) else f"Sample {idx+1}"
                line = f"{paramName} {label}: {v}"
                print(line)
                decoded_lines.append(line)
        else:
            for idx, v in enumerate(values):
                line = f"{paramName} Sample {idx+1}: {v}"
                print(line)
                decoded_lines.append(line)
        #RESULT.LogCustomAction(f"{paramName} Decoded Samples", "<br>".join(decoded_lines), "<br>".join(decoded_lines), TestStatus.Passed)
    elif typ in ["int", "bit", "bits", "custom_bits"]:
        print(f"{paramName} Decoded Value(s): {values}")
        #RESULT.LogCustomAction(f"{paramName} Decoded Samples", str(values), str(values), TestStatus.Passed)
    else:
        print(f"{paramName} Decoded Value(s): {values}")
        #RESULT.LogCustomAction(f"{paramName} Decoded Samples", str(values), str(values), TestStatus.Passed)
def decode_crash_location(hex_str):
    """
    Decodes the Crash_Location byte and returns a human-readable string.
    """
    location_str = []
    crashlocation = int(hex_str, 16)
    # Ignore reserved MSB (bit 7) to keep variant mapping consistent.
    crashlocation &= 0x7F
    bit_map = globals().get("CRASH_LOCATION_BITS")
    if not bit_map:
        bit_map = [
            (0, "Front Crash"),
            (1, "Left Side Crash"),
            (2, "Right Side Crash"),
            (3, "Rear Crash"),
            (4, "Understrike Crash"),
            (5, "Roll Over"),
            (6, "Near Crash"),
        ]
    for bit_idx, label in bit_map:
        if crashlocation & (1 << bit_idx):
            location_str.append(label)
    concatenated_string = f"Crash Location: {', '.join(location_str) if location_str else 'None'}"
    return concatenated_string


def _decode_rsu_did_bytes(data_bytes, sensor_type: str):
    """Decode RSU/Hi-G DID payload bytes to physical values.

    data_bytes: list of hex strings (payload only, after 62 DID1 DID2)
    sensor_type: "rsu", "hig_x", "hig_y"
    """
    decoded = []
    for b in data_bytes:
        if b is None:
            continue
        try:
            raw = str(b).strip()
            raw = raw[2:] if raw.lower().startswith("0x") else raw
            val = int(raw, 16) & 0xFF
        except Exception:
            continue

        if val == 0x7F:
            decoded_val = 0
        elif sensor_type == "rsu":
            decoded_val = (val - 127) * 2
        else:
            decoded_val = (val - 127)
        decoded.append(decoded_val)
    return decoded


def read_rsu_did(did: str, sensor_type: str, return_data: bool = False, rsu_name: str = None):
    """Read RSU/Hi-G DID using 0x22 service and decode payload."""
    PS.Power_Cycle()
    enter_ext_session()
    Internal_Security_Access(0x01)

    did_clean = did.replace(" ", "").lower()
    if len(did_clean) != 4:
        raise ValueError(f"Invalid DID format: {did}")
    response = CAN.SendDiagByValues(f"22{did_clean}")
    if rsu_name:
        RESULT.LogAction(f"RSU {rsu_name} DID {did_clean.upper()} Response", response)
    else:
        RESULT.LogAction(f"RSU DID {did_clean.upper()} Response", response)
    data = response.split(" ")

    # Expect: 62 DID1 DID2 <payload...>
    payload = data[3:] if len(data) > 3 else []
    decoded = _decode_rsu_did_bytes(payload, sensor_type)

    if return_data:
        return {"raw": payload, "decoded": decoded, "response": response}


def read_all_rsu_dids(edr: str = "EDR1", return_data: bool = False):
    """Read all RSU/Hi-G DIDs for EDR1 or EDR2 using RSU_DID_MAP."""
   

    edr_key = "edr1" if str(edr).upper() == "EDR1" else "edr2"
    results = {}
    for name, spec in RSU_DID_MAP.items():
        did = spec.get(edr_key)
        sensor_type = spec.get("sensor_type", "rsu")
        if not did:
            continue
        results[name] = read_rsu_did(did, sensor_type, return_data=True, rsu_name=name)

    if return_data:
        return results
