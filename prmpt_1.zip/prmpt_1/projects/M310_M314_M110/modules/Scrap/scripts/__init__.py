"""Scripts for Scrap."""
