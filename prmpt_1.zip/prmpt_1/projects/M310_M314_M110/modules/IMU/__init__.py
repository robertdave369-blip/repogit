"""Module: IMU (M310_M314_M110)"""
