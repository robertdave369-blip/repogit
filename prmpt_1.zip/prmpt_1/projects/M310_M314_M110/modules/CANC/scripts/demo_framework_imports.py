"""
Demo script showing how to load shared libraries and project config
through FrameworkContext for project M310_M314_M110 and module CANC.
"""

from __future__ import annotations

import sys
from pathlib import Path


PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "CANC"


_FRAMEWORK_PARENT = str(Path(__file__).resolve().parents[5].parent)
if _FRAMEWORK_PARENT not in sys.path:
    sys.path.insert(0, _FRAMEWORK_PARENT)

from Framework_IOEM_Py.path_manager import FrameworkContext, bootstrap_framework_import

_FW_ROOT = bootstrap_framework_import(__file__)


def build_context() -> FrameworkContext:
    """
    Shortest full-load pattern:
    - one call
    - one context object
    - all shared libraries loaded
    - all config files for the selected project loaded
    """
    return FrameworkContext.preload_all(
        project=PROJECT_NAME,
        module=MODULE_NAME,
    )


def main() -> None:
    ctx = build_context()

    can_library = ctx.shared.can_library
    project_config = ctx.project_configs.project_config
    canc_config = ctx.project_configs.canc_config

    print("=" * 72)
    print("FRAMEWORK IMPORT DEMO")
    print("=" * 72)
    print(f"Framework root : {_FW_ROOT}")
    print(f"Project        : {PROJECT_NAME}")
    print(f"Module         : {MODULE_NAME}")
    print()
    print("Loaded files")
    print(f"  Project config : {project_config.__file__}")
    print(f"  Module config  : {canc_config.__file__}")
    print(f"  Shared library : {can_library.__file__}")
    print(f"  Shared count   : {len(ctx.shared.list_modules())}")
    print(f"  Config count   : {len(ctx.project_configs.list_modules())}")
    print()
    print("Example values")
    print(f"  ctx.config.PROJECT_NAME        = {ctx.config.PROJECT_NAME}")
    print(f"  ctx.config.CAN_CHANNEL         = {ctx.config.CAN_CHANNEL}")
    print(f"  ctx.mod_config.TIMEOUT_SECONDS = {ctx.mod_config.TIMEOUT_SECONDS}")
    print(f"  canc_config.TIMEOUT_SECONDS    = {canc_config.TIMEOUT_SECONDS}")
    print(
        f"  canc_config.MESSAGE_CYCLE_TIME = {canc_config.MESSAGE_CYCLE_TIME}"
    )
    print(
        "  can_library.CAN_MESSAGES keys = "
        f"{list(can_library.CAN_MESSAGES.keys())[:5]}"
    )
    print()
    print("Note")
    print(
        "  This demo uses one short configurable call:"
    )
    print(
        "  FrameworkContext.preload_all(project=PROJECT_NAME, module=MODULE_NAME)"
    )


if __name__ == "__main__":
    main()
