"""Module: VIN (M310_M314_M110)"""
