"""Scripts for VIN."""
