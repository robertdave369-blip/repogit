"""Module: POWER (M310_M314_M110)"""
