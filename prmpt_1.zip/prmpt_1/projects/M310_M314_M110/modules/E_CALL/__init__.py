"""Module: E_CALL (M310_M314_M110)"""
