"""Scripts for VARIANTCODE."""
