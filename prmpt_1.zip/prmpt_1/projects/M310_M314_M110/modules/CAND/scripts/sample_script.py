"""
Sample script demonstrating the usage of the shared_libraries facade.
By importing `import_list` from `shared_libraries` as `shared`, we can easily
access functions from *any* library file using dot notation, avoiding circular
imports and function name collisions.
"""

from shared_libraries import import_list as shared

def main():
    print("--- Starting Sample Script using Shared Libraries Facade ---")
    
    # 1. framework_registry.py
    try:
        projects = shared.fw_reg.list_available_projects()
        print(f"Available Projects: {projects}")
    except Exception as e:
        print(f"fw_reg error: {e}")
        
    # 2. project_config_loader.py
    try:
        project_name = shared.proj_cfg.get_active_project()
        print(f"Current Active Project: {project_name}")
    except Exception as e:
        print(f"proj_cfg error: {e}")

    # 3. data_conversions.py
    try:
        hex_val = shared.data_conv.int_to_hex(255, width=2)
        print(f"data_conv: 255 to hex -> {hex_val}")
    except Exception as e:
        print(f"data_conv error: {e}")

    # 4. can_library.py
    try:
        is_key = shared.can.is_key_message("VehSpd_CAN")
        print(f"can_library: Is VehSpd_CAN a key message? {is_key}")
    except Exception as e:
        print(f"can_library error: {e}")

    # 5. edr_decoding_functions.py
    print("edr_decoding_functions: Available to call e.g., shared.edr_dec.read_edr_parameters()")
    
    # 6. winidea.py
    print("winidea: Available to call e.g., shared.winidea.CheckForDebugger()")
    
    # 7. excel_handler.py
    print("excel_handler: Available to call e.g., shared.excel.ForceCloseAllExcel()")
    
    # 8. fault_monitor.py
    print("fault_monitor: Available to call e.g., shared.fault.printErrorNames('Error1')")
    
    # 9. apym_imports.py
    print("apym_imports: Available to call e.g., shared.apym.ensure_apym_on_path()")
    
    # 10. ascent_batch_lib.py
    print("ascent_batch_lib: Available to call e.g., shared.ascent.countFiles()")
    
    # 11. check_sequence.py
    print("check_sequence: Available to call e.g., shared.chk_seq.checkSequence([])")

    # 12. core_functions.py
    print("core_functions: Available to call e.g., shared.core._require_numpy()")

    # 13. crash_configuration.py
    print("crash_configuration: Available to call e.g., shared.crash_config.get_project_crash_curve_config()")

    # 14. infineon_memtool.py
    print("infineon_memtool: Available to call e.g., shared.memtool.mtoolExecuteMemtool()")
    
    # 15. jscript_translation.py
    print("jscript_translation: Available to call e.g., shared.js_trans._normalize_channel_name('ch1')")

    print("--- Script Completed Successfully ---")

if __name__ == "__main__":
    main()
