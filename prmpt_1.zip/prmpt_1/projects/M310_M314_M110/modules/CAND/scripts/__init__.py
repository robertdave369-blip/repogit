"""Scripts for CAND."""
