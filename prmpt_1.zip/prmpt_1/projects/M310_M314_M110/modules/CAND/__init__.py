"""Module: CAND (M310_M314_M110)"""
