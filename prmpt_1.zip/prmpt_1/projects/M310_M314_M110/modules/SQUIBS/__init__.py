"""Module: SQUIBS (M310_M314_M110)"""
