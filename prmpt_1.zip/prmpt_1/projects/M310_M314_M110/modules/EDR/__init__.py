"""Module: EDR (M310_M314_M110)"""
