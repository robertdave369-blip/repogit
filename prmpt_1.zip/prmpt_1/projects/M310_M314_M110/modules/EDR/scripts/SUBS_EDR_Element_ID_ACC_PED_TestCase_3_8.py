import time
from apym.connection import Instance as aria_instance

aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import *

from Test_Enviornment.Library.EDR_Parameters_UPP import get_sample_range


def run_test():
    tc_id = "3.8"
    tc_desc = (
        "ACC_PED signal-invalid scenario (post-crash only): send values for all pre-crash and T0, then half post-crash, "
        "inject invalid raw values in post-crash, continue simulation till end, "
        "verify EDR captures invalid values after fault, and DTCs are set."
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_3_values"]
    invalid_values = signal_def["TestCase_3_Invalid_Values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)

    # Sampling configuration for ACC_PED
    # Recording interval: -5.0s to 3.0s
    # Sample interval: 500ms
    # Total samples: 16
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)

    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]
    if not isinstance(invalid_values, list):
        invalid_values = [invalid_values]

    can_dtc_code = resolve_dtc_for_event("signal_invalid", msg, sig)
    
    print("can_dtc_code =", can_dtc_code, type(can_dtc_code))
    print("DTC_status[DTC_active_WLOFF] =", DTC_status.get("DTC_active_WLOFF"), type(DTC_status.get("DTC_active_WLOFF")))

    combined_can_dtc_final = can_dtc_code + " " + DTC_status["DTC_active_WLOFF"]
    print(f"Resolved CAN DTC for signal invalid: {can_dtc_code}, combined with WLOFF status: {combined_can_dtc_final}")

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file,
        can_ids=can_ids,
        direct_write=False,
        tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)
        # Ensure the periodic frame is enabled for each EDR read cycle
        CAN.ReloadDefaultPeriodicFrame(msg)

        # Build time axis based on recording interval configuration
        recording_start = -5.0
        recording_end = 3.0
        sample_interval_s = sample_interval_ms / 1000.0

        # Generate time axis from recording start to end
        time_axis = []
        t = recording_start
        while t <= recording_end + 0.001:
            time_axis.append(round(t, 3))
            t += sample_interval_s

        # Determine T0 index (where time = 0)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), len(time_axis) // 2)
        trigger_idx = t0_sample_idx - 1

        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Correct sample identification
        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        t0_index = next((i for i, s in enumerate(sample_range) if abs(s) < 1e-9), len(pre_crash_samples))
        post_crash_samples = [s for s in sample_range if s > 0]
        num_post_crash = len(post_crash_samples)

        # Calculate disable index as T0 + half of post-crash samples
        disable_index = t0_index + (num_post_crash // 2)

        if disable_index >= len(values):
            disable_index = len(values) - 1
        if disable_index <= t0_index:
            disable_index = t0_index + 1

        def resolve_invalid_value(idx: int) -> int:
            invalid_idx = idx - disable_index
            if invalid_idx < len(invalid_values):
                return invalid_values[invalid_idx]
            return invalid_values[-1]

        # Debug/verification prints
        print(f"EDR Parameter: ACC_PED")
        print(f"Recording interval: -5.0s to 3.0s")
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Post-crash samples (positive time): {post_crash_samples}")
        print(f"Number of post-crash samples: {num_post_crash}")
        print(f"T0 index: {t0_index}")
        print(f"Disable index (fault induced at, in post-crash): {disable_index}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(f"Time at disable_index: {time_axis[disable_index] if disable_index < len(time_axis) else 'N/A'}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"ACC_PED {tc_id}: Send values for all samples, "
            f"inject invalid values at post-crash index {disable_index}, verify EDR captures invalid values after fault."
        )
        invalid_done = False

        for idx, val in enumerate(values):
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            value_to_send = resolve_invalid_value(idx) if idx >= disable_index else val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)

            if idx < disable_index:
                fault_status = ""
            else:
                fault_status = " [Invalid Value Injected]"

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s){fault_status}",
                str(received_val_int),
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s){fault_status}",
                str(received_phys),
                str(expected_phys))

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                continue

            # Inject invalid values at disable index in post-crash
            if not invalid_done and idx == disable_index:
                RESULT.InsertComment(
                    f"Injecting invalid values starting at index {disable_index} "
                    f"(simulated from {simulation_start_time}s to {recording_time}s) to simulate signal invalid fault in post-crash samples."
                )
                invalid_done = True


        if invalid_done:
            combined_can_dtc_wloff = can_dtc_code + " " + DTC_status["DTC_active_WLOFF"]
            combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
            final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_wloff
            Sleep(3)
            Read_DTC("Signal Invalid (after fault induced in post-front crash) ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req_CANC)
        aria_reports.close_group()

        # Restore frame for the next DID iteration
        CAN.ReloadDefaultPeriodicFrame(msg)

        Sleep(5)
        edr_read = read_edr_parameters_UPP([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        raw_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []
            raw_samples = edr_read.get("raw", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        aria_reports.add_group("EDR Output Verification - Signal Invalid (Post-Crash Only)")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("ACC_PED Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)

            if i < disable_index:
                expected_phys = values[i] * scaling + offset_edr
                expected_raw = values[i]
                description = "actual value (before fault)"
            else:
                invalid_val = resolve_invalid_value(i)
                expected_phys = invalid_val * scaling + offset_edr
                expected_raw = invalid_val
                description = "invalid value (fault active)"

            RESULT.InterpretEqualResult(
                f"ACC_PED phyiscial value recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys)
            )
            if i >= len(raw_samples):
                RESULT.LogCustomAction(
                    "ACC_PED Raw",
                    f"Missing raw sample {i}",
                    f"Missing raw sample {i}",
                    TestStatus.Failed,
                )
                continue
            raw_observed = raw_samples[i]
            raw_observed_str = str(raw_observed).strip()
            if raw_observed_str.lower().startswith("0x"):
                raw_observed_str = raw_observed_str[2:]
            raw_observed_norm = f"0x{raw_observed_str.upper()}"
            expected_raw_norm = f"0x{expected_raw:02X}"
            RESULT.InterpretEqualResult(
                f"ACC_PED raw recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                raw_observed_norm,
                expected_raw_norm
            )
        aria_reports.close_group()

        CAN.ChangeSignalValue(msg, sig, "0")
        CAN.ReloadDefaultPeriodicFrame(msg)
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()

# # display_Tracability(34628290,34628690,34857066,34984478)
