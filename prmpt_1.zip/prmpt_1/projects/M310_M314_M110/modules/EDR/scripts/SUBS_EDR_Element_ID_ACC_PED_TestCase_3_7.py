import time
from apym.connection import Instance as aria_instance

aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import *


def run_test():
    tc_id = "3.7"
    tc_desc = (
        "ACC_PED invalid-value injection (pre-crash only): send normal values up to disable index "
        "(half pre-crash samples), inject invalid values until T0, clear fault at T0, trigger crash, "
        "verify EDR captures invalid values during fault and normal values after fault is cleared."
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    normal_values = signal_def["TestCase_3_values"]
    invalid_values = signal_def["TestCase_3_Invalid_Values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)

    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(normal_values, list):
        normal_values = [normal_values]
    if not isinstance(invalid_values, list):
        invalid_values = [invalid_values]

    from Test_Enviornment.Library.CANLibrary import resolve_dtc_for_event

    can_dtc_code = resolve_dtc_for_event("signal_invalid", msg, sig)
    combined_can_dtc_final = can_dtc_code + " " + DTC_status["DTC_healed"]
    print(
        f"Resolved CAN DTC for signal invalid: {can_dtc_code}, combined with WLOFF status: {combined_can_dtc_final}"
    )

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file,
        can_ids=can_ids,
        direct_write=False,
        tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        recording_start = -5.0
        recording_end = 3.0
        sample_interval_s = sample_interval_ms / 1000.0

        time_axis = []
        t = recording_start
        while t <= recording_end + 0.001:
            time_axis.append(round(t, 3))
            t += sample_interval_s

        t0_sample_idx = next(
            (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9),
            len(time_axis) // 2,
        )
        trigger_idx = t0_sample_idx - 1

        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        num_pre_crash = len(pre_crash_samples)

        disable_index = num_pre_crash // 2
        if disable_index >= num_pre_crash:
            disable_index = num_pre_crash - 1
        if disable_index < 0:
            disable_index = 0

        # Build send list: normal values up to disable_index, invalid values until T0, normal after T0.
        values_to_send = []
        for i in range(len(normal_values)):
            if i <= disable_index or i > t0_sample_idx:
                values_to_send.append(normal_values[i])
            else:
                invalid_idx = i - (disable_index + 1)
                if invalid_idx < len(invalid_values):
                    values_to_send.append(invalid_values[invalid_idx])
                else:
                    values_to_send.append(invalid_values[-1])

        # Debug prints
        print(f"EDR Parameter: ACC_PED")
        print(f"Recording interval: -5.0s to 3.0s")
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Number of pre-crash samples: {num_pre_crash}")
        print(f"Disable index (invalid injection starts after): {disable_index}")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(
            f"Time at disable_index: "
            f"{time_axis[disable_index] if disable_index < len(time_axis) else 'N/A'}"
        )
        print(f"Total values to simulate: {len(values_to_send)}")

        aria_reports.add_group(
            f"ACC_PED {tc_id}: Send normal values up to index {disable_index}, "
            "inject invalid values until T0, clear fault at T0, trigger crash, "
            "verify EDR output and signal-content-failure DTC."
        )

        fault_active = False
        fault_removed = False

        for idx, val in enumerate(values_to_send):
            simulation_start_time = (
                simulation_time_axis[idx]
                if idx < len(simulation_time_axis)
                else ((idx * sample_interval_s) - sample_interval_s)
            )
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            value_to_send = val
            value_to_send_hex = f"0x{int(value_to_send):02X}"

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = (
                    int(received_val, 16)
                    if isinstance(received_val, str) and received_val.startswith("0x")
                    else int(received_val)
                )
            except Exception:
                received_val_int = int(received_val)

            if not fault_active:
                fault_status = ""
            elif fault_active and not fault_removed:
                fault_status = " [Invalid Value Injected]"
            else:
                fault_status = " [Fault Cleared - Normal Values]"

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} ({value_to_send_hex}) (index {idx}, "
                f"simulated from {simulation_start_time}s to {recording_time}s, "
                f"recorded at {recording_time}s){fault_status}",
                str(received_val_int),
                str(value_to_send),
            )

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value "
                f"(simulated from {simulation_start_time}s to {recording_time}s)"
                f"{fault_status}",
                str(received_phys),
                str(expected_phys),
            )

            if not fault_active and idx == disable_index:
                fault_active = True

            if idx == trigger_idx:
                fault_removed = True
                fault_active = False
                TriggerCrash()
                continue

        combined_crash_dtc = (
            Crash_DTC
            + " "
            + DTC_status["DTC_active"]
            + " "
            + PT_Crash_DTC
            + " "
            + DTC_status["DTC_active"]
        )
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Sleep(5)
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters_UPP(
            [edr_param], did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        decoded_samples = []
        raw_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []
            raw_samples = edr_read.get("raw", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        aria_reports.add_group("EDR Output Verification - Invalid Injection (Pre-Crash Only)")
        for i in range(len(values_to_send)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction(
                    "ACC_PED Decode",
                    f"Missing decoded sample {i}",
                    f"Missing decoded sample {i}",
                    TestStatus.Failed,
                )
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = (
                simulation_time_axis[i]
                if i < len(simulation_time_axis)
                else ((i * sample_interval_s) - sample_interval_s)
            )

            if i <= disable_index:
                expected_phys = normal_values[i] * scaling + offset_edr
                expected_raw_int = int(normal_values[i])
                description = "actual value (before/at fault)"
            elif i <= t0_sample_idx:
                invalid_idx = i - (disable_index + 1)
                if invalid_idx < len(invalid_values):
                    invalid_val = invalid_values[invalid_idx]
                else:
                    invalid_val = invalid_values[-1]
                expected_phys = invalid_val * scaling + offset_edr
                expected_raw_int = int(invalid_val)
                description = "invalid value (fault active)"
            else:
                expected_phys = normal_values[i] * scaling + offset_edr
                expected_raw_int = int(normal_values[i])
                description = "actual value (fault cleared)"

            RESULT.InterpretEqualResult(
                f"ACC_PED physical value recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys),
            )
            if i >= len(raw_samples):
                RESULT.LogCustomAction(
                    "ACC_PED Raw",
                    f"Missing raw sample {i}",
                    f"Missing raw sample {i}",
                    TestStatus.Failed,
                )
                continue
            raw_observed = raw_samples[i]
            raw_observed_str = str(raw_observed).strip()
            if raw_observed_str.lower().startswith("0x"):
                raw_observed_int = int(raw_observed_str, 16)
            else:
                raw_observed_int = int(raw_observed_str)
            raw_observed_norm = f"0x{raw_observed_int:02X}"

            expected_raw_norm = f"0x{expected_raw_int:02X}"
            RESULT.InterpretEqualResult(
                f"ACC_PED raw recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                raw_observed_norm,
                expected_raw_norm,
            )
        aria_reports.close_group()

    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)
    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
