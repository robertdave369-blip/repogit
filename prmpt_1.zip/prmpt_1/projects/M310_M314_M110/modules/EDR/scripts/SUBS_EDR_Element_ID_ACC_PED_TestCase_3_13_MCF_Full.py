import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import (
    EDR_UPP_PARAMETERS,
    build_time_axis_and_t0,
    get_sample_interval_ms,
)


def run_test():
    tc_id = "3.13"
    tc_desc = (
        "ACC_PED Message Content Failure (full duration): send first non-zero value, "
        "disable MSG_CNT of the associated message (simulate message content failure), "
        "continue CAN simulation with actual values, trigger crash at T0, "
        "verify EDR latches non-zero value in all samples after fault, and DTCs are set."
    )

    # ── Signal definition ──────────────────────────────────────────────
    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_3_values"]
    edr_param = signal_def["EDR_Parameter"]
    veh_edr_def = next(
        (p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None
    )
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # ── MSG_CNT / Message-content-failure specifics (from CANLibrary) ─
    fault_logic = signal_def["fault_logic"]
    key_message = fault_logic.get("key_message")
    mcf_dtcs = get_message_content_failure_dtcs(msg) or {}

    mcf_frame = signal_def["frame"]
    mcf_ch = signal_def["ch"]

    mcf_signal_name = choose_message_content_failure_signal(msg)
    mcf_dtc_value = mcf_dtcs.get(mcf_signal_name) if mcf_signal_name else None

    if not mcf_signal_name or not mcf_dtc_value:
        raise ValueError(
            f"No MSG_CNT entry in message_content_failure_dtcs for '{sig}'. "
            f"Available: {list(mcf_dtcs.keys())}"
        )

    combined_can_dtc_final = mcf_dtc_value + " " + DTC_status["DTC_active_WLOFF"]

    print(f"Key message: {key_message}")
    print(f"MSG_CNT signal to disable: {mcf_signal_name} on frame {mcf_frame} ch {mcf_ch}")
    print(f"Message content failure DTC: {mcf_dtc_value}")
    print(f"Combined DTC (with WLOFF): {combined_can_dtc_final}")

    # ── Report / logging setup ─────────────────────────────────────────
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file,
        can_ids=can_ids,
        direct_write=False,
        tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # ── Time axis ──────────────────────────────────────────────────
        time_axis, T0_INDEX = build_time_axis_and_t0(
            edr_param, crash_type, RSU_T0_OFFSETS
        )
        t0_sample_idx = next(
            (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX
        )
        trigger_idx = t0_sample_idx - 1

        sample_interval_s = sample_interval_ms / 1000.0
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Fault induced after first non-zero value
        first_nonzero_index = next(
            (i for i, v in enumerate(values) if int(v) != 0), 0
        )
        disable_index = first_nonzero_index
        latched_raw = (
            values[disable_index] if disable_index < len(values) else values[-1]
        )

        # Debug prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(f"Disable index: {disable_index}")
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"{sig} {tc_id}: Send first non-zero value, disable MSG_CNT '{mcf_signal_name}' "
            f"on frame '{mcf_frame}' (simulate message content failure), "
            "continue CAN simulation with actual values, trigger crash at T0, "
            "verify EDR latches non-zero value in all samples after fault."
        )
        disabled_done = False

        # ── Simulation loop ────────────────────────────────────────────
        for idx, val in enumerate(values):
            simulation_start_time = (
                simulation_time_axis[idx]
                if idx < len(simulation_time_axis)
                else ((idx * sample_interval_s) - sample_interval_s)
            )
            recording_time = (
                time_axis[idx]
                if idx < len(time_axis)
                else (idx * sample_interval_s)
            )

            value_to_send = val
            value_to_send_hex = f"0x{int(value_to_send):02X}"

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                if isinstance(received_val, str) and received_val.startswith("0x"):
                    received_val_int = int(received_val, 16)
                else:
                    received_val_int = int(received_val)
            except Exception:
                received_val_int = int(received_val)

            if not disabled_done:
                fault_status = ""
            else:
                fault_status = " [Message Content Failure Active - ECU latching]"

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} ({value_to_send_hex}) (index {idx}, "
                f"simulated from {simulation_start_time}s to {recording_time}s, "
                f"recorded at {recording_time}s){fault_status}",
                str(received_val_int),
                str(value_to_send),
            )

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value "
                f"(simulated from {simulation_start_time}s to {recording_time}s)"
                f"{fault_status}",
                str(received_phys),
                str(expected_phys),
            )

            # ── Induce fault: disable CRC after first non-zero sample ──
            if not disabled_done and idx == disable_index:
                RESULT.InsertComment(
                    f"Disabling MSG_CNT signal '{mcf_signal_name}' on frame "
                    f"'{mcf_frame}' ch {mcf_ch} at index {disable_index} "
                    f"(simulated from {simulation_start_time}s to "
                    f"{recording_time}s) to simulate message content failure."
                )
                RESULT.InsertComment(
                    f"ECU will latch value {latched_raw} "
                    f"(physical: {latched_raw * factor + offset}) "
                    f"for all subsequent samples."
                )
                RESULT.InsertComment(
                    "CAN simulation continues with actual values from list, "
                    "but ECU will reject frames due to CRC failure."
                )
                CAN.DynamicDisableSignal(mcf_frame, mcf_signal_name)
                disabled_done = True

            # ── Trigger crash one sample before T0 ─────────────────────
            if idx == trigger_idx:
                TriggerCrash()
                continue

        # ── Post-simulation DTC verification ───────────────────────────
        Sleep(1)
        combined_crash_dtc = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC(
            "Front Crash ",Read_DTC_Resp + " " + final_combined_dtc,Read_DTC_Req)
        aria_reports.close_group()

        # ── EDR readout ────────────────────────────────────────────────
        Sleep(5)
        edr_read = read_edr_parameters_UPP(
            [edr_param], did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        decoded_samples = []
        raw_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = (
                edr_read.get("decoded", {}).get(edr_param, []) or []
            )
            raw_samples = edr_read.get("raw", {}).get(edr_param, []) or []

        scaling = veh_edr_def.get("scaling_factor", 1) if veh_edr_def else 1
        offset_edr = veh_edr_def.get("offset", 0) if veh_edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        # ── EDR verification ───────────────────────────────────────────
        aria_reports.add_group(
            "EDR Output Verification - Message Content Failure "
            "(Full Duration - Latched Value)"
        )
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction(
                    f"{sig} Decode",
                    f"Missing decoded sample {i}",
                    f"Missing decoded sample {i}",
                    TestStatus.Failed,
                )
                continue

            observed = decoded_samples[i]
            recording_time = (
                time_axis[i]
                if i < len(time_axis)
                else (i * sample_interval_s)
            )
            simulation_start_time = (
                simulation_time_axis[i]
                if i < len(simulation_time_axis)
                else ((i * sample_interval_s) - sample_interval_s)
            )

            if i <= disable_index:
                expected_phys = values[i] * scaling + offset_edr
                expected_raw = values[i]
                description = "actual value (before/at fault)"
            else:
                expected_phys = expected_phys_latched
                expected_raw = latched_raw
                description = "latched value (message content failure active)"

            RESULT.InterpretEqualResult(
                f"{edr_param} recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to "
                f"{recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys),
            )
            if i >= len(raw_samples):
                RESULT.LogCustomAction(
                    "ACC_PED Raw",
                    f"Missing raw sample {i}",
                    f"Missing raw sample {i}",
                    TestStatus.Failed,
                )
                continue
            raw_observed = raw_samples[i]
            raw_observed_str = str(raw_observed).strip()
            if raw_observed_str.lower().startswith("0x"):
                raw_observed_int = int(raw_observed_str, 16)
            else:
                raw_observed_int = int(raw_observed_str)
            raw_observed_norm = f"0x{raw_observed_int:02X}"

            expected_raw_int = int(expected_raw)
            expected_raw_norm = f"0x{expected_raw_int:02X}"
            RESULT.InterpretEqualResult(
                f"{edr_param} raw recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to "
                f"{recording_time:g}s) - {description}",
                raw_observed_norm,
                expected_raw_norm,
            )
        CAN.ChangeSignalValue(msg, sig, "0")
        CAN.DynamicEnableSignal(mcf_frame, mcf_signal_name)
        aria_reports.close_group()

    # ── Cleanup ────────────────────────────────────────────────────────
   
    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
