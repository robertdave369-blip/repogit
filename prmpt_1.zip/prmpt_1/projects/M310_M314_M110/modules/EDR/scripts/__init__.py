"""Scripts for EDR."""
