import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import *

from Test_Enviornment.Library.EDR_Parameters_UPP import get_sample_range

def run_test():
    tc_id = "3.4"
    tc_desc = (
        "ACC_PED message-timeout scenario (post-crash only): send values for all pre-crash and T0, then half post-crash, "
        "disable non-key frame (simulate message timeout) in post-crash, continue simulation till end, "
        "verify EDR latches values as expected after fault, and DTCs are set."
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_3_values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)

    # Sampling configuration for ACC_PED
    # Recording interval: -5.0s to 3.0s
    # Sample interval: 500ms
    # Total samples: 16
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)#500

    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    fault_logic = signal_def["fault_logic"]
    non_key_frame = fault_logic.get("non_key_timeout_frame") or msg
    fault_type = fault_logic.get("fault_type", "frame_disabled")
   
    
    can_dtc_code = resolve_dtc_for_event(fault_type, non_key_frame, sig)
    combined_can_dtc_final = can_dtc_code + " " + DTC_status["DTC_active_WLOFF"]
    print(f"Resolved CAN DTC for frame timeout: {can_dtc_code}, combined with WLOFF status: {combined_can_dtc_final}")


    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file,
        can_ids=can_ids,
        direct_write=False,
        tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)
        # Ensure the periodic frame is enabled for each EDR read cycle
        CAN.ReloadDefaultPeriodicFrame(non_key_frame)

        # Build time axis based on recording interval configuration
        recording_start = -5.0
        recording_end = 3.0
        sample_interval_s = sample_interval_ms / 1000.0

        # Generate time axis from recording start to end
        time_axis = []
        t = recording_start
        while t <= recording_end + 0.001:
            time_axis.append(round(t, 3))
            t += sample_interval_s

        # Determine T0 index (where time = 0)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), len(time_axis) // 2)
        trigger_idx = t0_sample_idx - 1

        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Correct sample identification
        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        t0_index = next((i for i, s in enumerate(sample_range) if abs(s) < 1e-9), len(pre_crash_samples))
        post_crash_samples = [s for s in sample_range if s > 0]
        num_post_crash = len(post_crash_samples)

        # Calculate disable index as T0 + half of post-crash samples
        disable_index = t0_index + (num_post_crash // 2)

        if disable_index >= len(values):
            disable_index = len(values) - 1
        if disable_index <= t0_index:
            disable_index = t0_index + 1

        latched_raw = values[disable_index] if disable_index < len(values) else values[-1]

        # Debug/verification prints
        print(f"EDR Parameter: ACC_PED")
        print(f"Recording interval: -5.0s to 3.0s")
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Post-crash samples (positive time): {post_crash_samples}")
        print(f"Number of post-crash samples: {num_post_crash}")
        print(f"T0 index: {t0_index}")
        print(f"Disable index (fault induced at, in post-crash): {disable_index}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(f"Time at disable_index: {time_axis[disable_index] if disable_index < len(time_axis) else 'N/A'}")
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"ACC_PED 3.4: Send values for all samples, "
            f"disable non-key frame '{non_key_frame}' at post-crash index {disable_index}, verify EDR latches values after fault."
        )
        disabled_done = False

        for idx, val in enumerate(values):
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)

            if not disabled_done:
                fault_status = ""
            else:
                fault_status = " [Message Timeout Active - ECU latching]"

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s){fault_status}",
                str(received_val_int),
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s){fault_status}",
                str(received_phys),
                str(expected_phys))

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                continue

            # Disable non-key frame (simulate message timeout) at disable index in post-crash
            if not disabled_done and idx == disable_index:
                RESULT.InsertComment(f"Disabling non-key CAN frame '{non_key_frame}' at index {disable_index} (simulated from {simulation_start_time}s to {recording_time}s) to simulate message timeout fault in post-crash samples.")
                RESULT.InsertComment(f"ECU will latch value {latched_raw} (physical: {latched_raw * factor + offset}) for remaining samples.")
                RESULT.InsertComment(f"CAN simulation continues with actual values till end, but ECU will latch due to message timeout.")
                CAN.PeriodicDisableFrame(non_key_frame)
                disabled_done = True

        Sleep(1)

        if disabled_done:
            combined_can_dtc_wloff = can_dtc_code + " " + DTC_status["DTC_active_WLOFF"]
            Sleep(1)
            combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
            final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_wloff
            Read_DTC("Message Timeout (after fault induced in post-front crash) ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
        aria_reports.close_group()

        # Restore frame for the next DID iteration
        CAN.ReloadDefaultPeriodicFrame(non_key_frame)

        Sleep(5)
        edr_read = read_edr_parameters_UPP([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        raw_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []
            raw_samples = edr_read.get("raw", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        aria_reports.add_group("EDR Output Verification - Message Timeout (Post-Crash Only)")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("ACC_PED Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)

            if i <= disable_index:
                expected_phys = values[i] * scaling + offset_edr
                expected_raw = values[i]
                description = "actual value (before/at fault)"
            else:
                expected_phys = expected_phys_latched
                expected_raw = latched_raw
                description = "latched value (message timeout active)"

            RESULT.InterpretEqualResult(
                f"ACC_PED phyiscial value recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys)
            )
            if i >= len(raw_samples):
                RESULT.LogCustomAction(
                    "ACC_PED Raw",
                    f"Missing raw sample {i}",
                    f"Missing raw sample {i}",
                    TestStatus.Failed,
                )
                continue
            raw_observed = raw_samples[i]
            raw_observed_str = str(raw_observed)
            raw_observed_norm = raw_observed_str.strip().upper()
            if not raw_observed_norm.startswith("0x"):
                raw_observed_norm = f"0x{raw_observed_norm}"
            expected_raw_norm = f"0x{expected_raw:02x}"
            RESULT.InterpretEqualResult(
                f"ACC_PED raw recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                raw_observed_norm,
                expected_raw_norm
            )
        aria_reports.close_group()

    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(non_key_frame)
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()

# # display_Tracability(34628290,34628690,34857066,34984478)
