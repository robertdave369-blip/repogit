"""Module: OCS (M310_M314_M110)"""
