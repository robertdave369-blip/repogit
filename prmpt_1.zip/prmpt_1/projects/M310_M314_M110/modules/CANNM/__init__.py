"""Module: CANNM (M310_M314_M110)"""
