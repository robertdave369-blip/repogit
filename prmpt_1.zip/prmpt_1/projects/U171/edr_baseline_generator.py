"""edr_baseline_generator.py — generate the missing _1 (valid-baseline)
test case for every EDR parameter.

The _1 TC is the "normal simulation" baseline: simulate the valid sweep on
CAN, trigger crash, read EDR, compare. ACC_PED 3_1 is the reference:
    C:\\Framework_IOEM_Py\\projects\\U171\\modules\\EDR\\scripts\\SUBS_EDR_Element_ID_ACC_PED_TestCase_3_1.py

For every (param, N) discovered from existing scripts, if no _1.py exists,
this writes one obtained from the template by substituting:
    - ACC_PED → <param>     (whole-word, every occurrence)
    - "TestCase_3_values" → "TestCase_<N>_values"
    - tc_id = "3.1"      → tc_id = "<N>.1"

Default is dry-run. Re-run with --apply to actually write files.
"""

from __future__ import annotations
import argparse
import re
import sys
from collections import defaultdict
from pathlib import Path

SCRIPTS_DIR_DEFAULT = Path(r"C:\Framework_IOEM_Py\projects\U171\modules\EDR\scripts")
TEMPLATE_NAME = "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_1.py"

REF_PARAM = "ACC_PED"
REF_N = 3

FILENAME_RE = re.compile(
    r"^SUBS_EDR_Element_ID_(?P<param>.+?)_TestCase_(?P<n>\d+)_(?P<m>\d+)(?:_.+)?\.py$"
)


def discover_pairs(scripts_dir: Path) -> dict[tuple[str, int], set[int]]:
    """Map every (param, N) seen in <scripts_dir> to the set of sub-indices M
    that already exist for it. Used to know which parameters still need a _1.
    """
    by_pair: dict[tuple[str, int], set[int]] = defaultdict(set)
    for p in scripts_dir.glob("SUBS_EDR_Element_ID_*.py"):
        m = FILENAME_RE.match(p.name)
        if not m:
            continue
        param = m.group("param")
        n = int(m.group("n"))
        mm = int(m.group("m"))
        by_pair[(param, n)].add(mm)
    return by_pair


def substitute_template(template_text: str, new_param: str, new_n: int) -> str:
    """Adapt ACC_PED 3_1 template to use new_param and TestCase_<new_n>_values."""
    out = template_text
    # 1. Whole-word ACC_PED → new_param. Catches:
    #      - MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    #      - tc_desc strings
    #      - RESULT.LogCustomAction labels and f-string EDR verification labels
    #    \b prevents matching e.g. "ACC_PED1" (the signal name).
    out = re.sub(r"\b" + re.escape(REF_PARAM) + r"\b", new_param, out)
    # 2. The TestCase_<N>_values key the baseline reads.
    out = out.replace(
        f'"TestCase_{REF_N}_values"',
        f'"TestCase_{new_n}_values"',
    )
    # 3. tc_id string.
    out = out.replace(
        f'tc_id = "{REF_N}.1"',
        f'tc_id = "{new_n}.1"',
    )
    # 4. Strip the trailing `# # display_Tracability(...)` comment that carries
    #    ACC_PED-specific IDs irrelevant to other parameters.
    out = re.sub(r"^# *# *display_Tracability\([^)]*\)\s*$\n?", "", out, flags=re.M)
    return out


def plan_generation(
    pairs: dict[tuple[str, int], set[int]],
    scripts_dir: Path,
) -> tuple[list[tuple[str, int, Path]], list[tuple[str, int]]]:
    """Return (to_create, already_present)."""
    to_create: list[tuple[str, int, Path]] = []
    already_present: list[tuple[str, int]] = []
    for (param, n), m_set in sorted(pairs.items()):
        target = scripts_dir / f"SUBS_EDR_Element_ID_{param}_TestCase_{n}_1.py"
        if target.exists() or 1 in m_set:
            already_present.append((param, n))
            continue
        to_create.append((param, n, target))
    return to_create, already_present


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--scripts", default=str(SCRIPTS_DIR_DEFAULT),
                    help="EDR scripts folder")
    ap.add_argument("--apply", action="store_true",
                    help="Actually write new files (otherwise dry-run).")
    args = ap.parse_args()
    scripts_dir = Path(args.scripts)
    if not scripts_dir.is_dir():
        print(f"ERROR: scripts dir not found: {scripts_dir}", file=sys.stderr)
        return 2
    template = scripts_dir / TEMPLATE_NAME
    if not template.exists():
        print(f"ERROR: template not found: {template}", file=sys.stderr)
        return 2

    template_text = template.read_text(encoding="utf-8")
    pairs = discover_pairs(scripts_dir)
    print(f"Scripts dir : {scripts_dir}")
    print(f"Template    : {template.name}")
    print(f"Mode        : {'APPLY' if args.apply else 'dry-run'}")
    print(f"Discovered {len(pairs)} unique (param, N) pair(s).")

    to_create, already_present = plan_generation(pairs, scripts_dir)
    print(f"  already have _1 : {len(already_present)}")
    print(f"  will generate _1: {len(to_create)}")
    print()

    if to_create:
        print("Will create:")
        for entry in to_create:
            print(f"  + {entry[2].name}")
    if already_present:
        print()
        print("Already present (skipped):")
        for (param, n) in already_present:
            print(f"  - SUBS_EDR_Element_ID_{param}_TestCase_{n}_1.py")

    if not args.apply:
        print("\nDry-run only. Re-run with --apply to write the files.")
        return 0

    n_written = 0
    for (param, n, target) in to_create:
        target.write_text(
            substitute_template(template_text, param, n), encoding="utf-8"
        )
        n_written += 1
    print(f"\nWrote {n_written} new file(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
