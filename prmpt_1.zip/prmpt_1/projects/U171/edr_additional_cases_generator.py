"""edr_additional_cases_generator.py — emit the remaining EDR test scripts
described in C:\\project_req\\m314\\tc_edr\\edr_additional_sesnor_cases.csv.

Families produced:
  A. DeltaV longitudinal/lateral  (EDR_Element_IDs_Deltav*)            14
  B. RSU fault injection          (TC_EDR_*_Negative/Positive_OtherRSU) 16
  C. Individual EDR parameters    (SUBS_EDR_Element_ID_*_TestCase_N)     8
  D. Multi-event near-crash       (SUBS_EDR_MultiEvent_NearCrash_*)      2
  E. Parameters folder stub       (SUBS_EDR_PARAMETERS)                  1

All scripts use ONLY existing framework helpers (core_functions,
jscript_translation, ascent_batch_lib, edr_decoding_functions, apym.reports)
and read every project value from projects/U171/config/rsu_config.py. Steps
that need bench hardware actions with no framework API (inject an OPEN/S2B/S2G
fault, set battery voltage, toggle the PADI lamp, change seat-belt status,
shape an onboard DeltaV curve) are emitted as clearly-marked RESULT.InsertComment
placeholders carrying the exact CSV step text, so the engineer knows precisely
what to wire up. No CSV is read at run time.

Default: dry-run. Re-run with --apply to write files.
"""

from __future__ import annotations
import argparse
import sys
from pathlib import Path

OUT_DIR_DEFAULT = Path(r"C:\Framework_IOEM_Py\projects\U171\modules\EDR\scripts")


COMMON_HEADER = '''# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import (
    U171_CRASH_CURVE_CONFIG,
    CRASH_TYPES,
)
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
    enter_ext_session,
    Internal_Security_Access,
    NVM_Clear_L61,
    ClearDTC,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.rsu_config import (
    SENSOR_TO_RSU_CHANNEL, SENSOR_SENSITIVITY, SENSOR_PORT_RES,
    SENSOR_DID_EDR1, SENSOR_DID_EDR2,
    CRASH_SENSOR_GROUPS, RSU_DECODE_TOLERANCE_G,
    EDR_EMPTY_BYTE, EDR_FORCED_ZERO_BYTE,
    DELTAV_EDR1_DID, DELTAV_EDR2_DID, DELTAV_PARAMETERS,
    DELTAV_SAMPLE_INTERVAL_MS, DELTAV_THRESHOLD_KMPH,
    RSU_FAULT_TYPES, RSU_FAULT_DTC,
    EDR_FULL_READ_DID, EDR_L1_SECURITY_LEVEL,
    build_read_did_request, lsb_curve_from_file,
    input_g_from_lsb, expand_decoded_to_input_rate, output_duplication_factor,
    decode_uds_response_to_g, curve_path_for_channel, did_response_payload_tokens,
)


def _read_crash_dtc(label):
    """Verify the standard crash + pretensioner DTCs are active."""
    combined = (Crash_DTC + " " + DTC_status["DTC_active"]
                + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"])
    Read_DTC(label, Read_DTC_Resp + " " + combined, Read_DTC_Req)


def _verify_did_payload_is_byte(sensor, did_label, did_str, target_byte):
    """Read a DID and assert every payload byte equals target_byte."""
    aria_reports.add_group(sensor + " " + did_label + " expected all-" + target_byte)
    request = build_read_did_request(did_str)
    response = CAN.SendDiagByValues(request)
    RESULT.InsertComment("UDS REQ " + request + "    RESP " + str(response))
    payload = did_response_payload_tokens(response)
    norm = lambda t: t.lower().replace("0x", "").zfill(2)
    target = norm(target_byte)
    all_ok = bool(payload) and all(norm(t) == target for t in payload)
    RESULT.InterpretEqualResult(
        sensor + " " + did_label + " payload all " + target_byte,
        ("all-" + target_byte) if all_ok else " ".join(payload),
        "all-" + target_byte,
    )
    aria_reports.close_group()


def _verify_sensor_did_against_curve(sensor, did_label, did_str, crash_type, polarity):
    """Read a sensor's DID and compare the (output-duplicated) decoded G stream
    against the full-resolution input curve Aria played for `crash_type`."""
    aria_reports.add_group(
        "RSU Decode :: " + sensor + " (" + did_label + " " + did_str + ") vs " + crash_type + " curve"
    )
    rsu_channel = SENSOR_TO_RSU_CHANNEL.get(sensor)
    sensitivity = SENSOR_SENSITIVITY.get(sensor)
    port_res = SENSOR_PORT_RES.get(sensor)
    if not (rsu_channel and sensitivity and port_res):
        RESULT.LogCustomAction(sensor + " metadata", "missing from rsu_config",
                               "channel/sensitivity/port_res required", TestStatus.Failed)
        aria_reports.close_group()
        return
    request = build_read_did_request(did_str)
    response = CAN.SendDiagByValues(request)
    RESULT.InsertComment("UDS REQ " + request + "    RESP " + str(response))
    factor = output_duplication_factor(sensor)
    decoded = decode_uds_response_to_g(response, port_res)
    decoded_expanded = expand_decoded_to_input_rate(decoded, factor=factor)
    curve = curve_path_for_channel(U171_CRASH_CURVE_CONFIG, crash_type, rsu_channel)
    if curve:
        lsb = lsb_curve_from_file(curve)
        input_g = input_g_from_lsb(lsb, sensitivity)
        n = min(len(decoded_expanded), len(input_g))
        for i in range(n):
            diff = abs(decoded_expanded[i] - input_g[i])
            ok = diff <= RSU_DECODE_TOLERANCE_G
            RESULT.LogCustomAction(
                sensor + " sample " + str(i),
                "output=%.4fG input=%.4fG diff=%.4f" % (decoded_expanded[i], input_g[i], diff),
                "within +/- %.4fG" % RSU_DECODE_TOLERANCE_G,
                TestStatus.Passed if ok else TestStatus.Failed,
            )
    else:
        for i, g in enumerate(decoded_expanded):
            RESULT.InsertComment("  " + sensor + " output[" + str(i) + "] = %.4fG" % g)
    first_nz = next((g for g in decoded if abs(g) > 1e-6), 0.0)
    polarity_ok = ((polarity == "negative" and first_nz < 0)
                   or (polarity == "positive" and first_nz > 0))
    RESULT.LogCustomAction(sensor + " polarity", "first non-zero G = %.4f" % first_nz,
                           polarity, TestStatus.Passed if polarity_ok else TestStatus.Failed)
    aria_reports.close_group()


'''


# ── Family A: DeltaV ────────────────────────────────────────────────────────
DELTAV_BODY = '''
def run_test():
    tc_id = "@@NAME@@"
    tc_desc = "@@DESC@@"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    enter_ext_session()
    Internal_Security_Access(EDR_L1_SECURITY_LEVEL)

    axis = "@@AXIS@@"            # "Lgt" or "Lat"
    crash_a, crash_b = "@@CRASH_A@@", "@@CRASH_B@@"

    # ── 1st crash ───────────────────────────────────────────────────────────
    aria_reports.add_group("Crash 1 :: " + crash_a.upper() + " (DeltaV" + axis + ")")
    RESULT.InsertComment(
        "SPEC STEP (project-specific stimulus): @@STEP1@@ "
        "Shape the onboard CT" + ("x" if axis == "Lgt" else "y") + " curve to the target |DeltaV| "
        "relative to the " + str(DELTAV_THRESHOLD_KMPH) + " km/h threshold, and set the RSU input as the "
        "test calls for. load_crash_curves() plays the configured crash curve below."
    )
    load_crash_curves(crash_a)
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc(crash_a.title() + " Crash DTC (1st)")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 (" + DELTAV_EDR1_DID + ") DeltaV params after 1st crash")
    edr1 = read_edr_parameters(DELTAV_PARAMETERS, did=DELTAV_EDR1_DID.replace("0x", ""),
                               crash_type=crash_a, return_data=True)
    RESULT.InsertComment("EDR1 read (" + DELTAV_EDR1_DID + "): " + str(edr1))
    RESULT.InsertComment("DeltaV" + axis + " records every " + str(DELTAV_SAMPLE_INTERVAL_MS) + " ms/sample.")
    aria_reports.close_group()

    aria_reports.add_group("EDR2 (" + DELTAV_EDR2_DID + ") should be empty (all-0xFF) after 1st crash")
    _verify_did_payload_is_byte("DeltaV" + axis, "EDR2", DELTAV_EDR2_DID, EDR_EMPTY_BYTE)
    aria_reports.close_group()

    # ── IGN cycle, then 2nd crash ───────────────────────────────────────────
    aria_reports.add_group("IGN cycle (proveout)")
    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)
    aria_reports.close_group()

    aria_reports.add_group("Crash 2 :: " + crash_b.upper() + " (DeltaV" + axis + ")")
    RESULT.InsertComment("SPEC STEP (project-specific stimulus): @@STEP2@@")
    load_crash_curves(crash_b)
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc(crash_b.title() + " Crash DTC (2nd)")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 retention after 2nd crash (should still hold 1st-crash DeltaV)")
    edr1_again = read_edr_parameters(DELTAV_PARAMETERS, did=DELTAV_EDR1_DID.replace("0x", ""),
                                     crash_type=crash_a, return_data=True)
    RESULT.InsertComment("EDR1 re-read (" + DELTAV_EDR1_DID + "): " + str(edr1_again))
    aria_reports.close_group()

    aria_reports.add_group("EDR2 (" + DELTAV_EDR2_DID + ") DeltaV params after 2nd crash")
    edr2 = read_edr_parameters(DELTAV_PARAMETERS, did=DELTAV_EDR2_DID.replace("0x", ""),
                               crash_type=crash_b, return_data=True)
    RESULT.InsertComment("EDR2 read (" + DELTAV_EDR2_DID + "): " + str(edr2))
    RESULT.InsertComment("Expected polarity note from spec: @@POLARITY_NOTE@@")
    aria_reports.close_group()

    aria_reports.add_group("IGN cycle retention check (both EDRs unchanged)")
    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)
    RESULT.InsertComment("Re-read EDR1/EDR2 and confirm values match the previous ignition cycle.")
    aria_reports.close_group()

    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
'''


# ── Family B: RSU fault injection ───────────────────────────────────────────
FAULT_BODY = '''
def run_test():
    tc_id = "@@NAME@@"
    tc_desc = "@@DESC@@"
    fault_type = "@@FAULT@@"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    enter_ext_session()

    group_a = CRASH_SENSOR_GROUPS["@@CRASH_A@@"]
    group_b = CRASH_SENSOR_GROUPS["@@CRASH_B@@"]
    other_a = [s for s in group_b["sensors"] if s not in group_a["sensors"]]
    other_b = [s for s in group_a["sensors"] if s not in group_b["sensors"]]
    fault_desc = RSU_FAULT_TYPES.get(fault_type, fault_type)

    def _inject_fault(sensors):
        for s in sensors:
            RESULT.InsertComment(
                "SPEC STEP (project-specific hardware action): create " + fault_type
                + " (" + fault_desc + ") on RSU sensor '" + s + "' (channel "
                + str(SENSOR_TO_RSU_CHANNEL.get(s)) + "). Wire the bench fault here."
            )

    def _read_fault_dtc():
        dtc = RSU_FAULT_DTC.get(fault_type)
        if dtc:
            Read_DTC(fault_type + " RSU fault DTC",
                     Read_DTC_Resp + " " + dtc + " " + DTC_status["DTC_active"], Read_DTC_Req)
        else:
            RESULT.InsertComment(
                "Read fault DTC for " + fault_type + " on faulted RSUs. "
                "Exact DTC not in rsu_config.RSU_FAULT_DTC — confirm from ECU spec."
            )

    # ── 1st crash phase ─────────────────────────────────────────────────────
    aria_reports.add_group("Crash 1 :: @@CRASH_A_UPPER@@  (" + fault_type + " on other RSUs)")
    load_crash_curves("@@CRASH_A@@")
    _inject_fault(other_a)
    _read_fault_dtc()
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc("@@CRASH_A_LABEL@@ DTC (1st)")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 vs INPUT after @@CRASH_A_UPPER@@ crash")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR1.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR1", did, "@@CRASH_A@@", group_a["polarity"])
    aria_reports.close_group()

    aria_reports.add_group("EDR2 all-0xFF (empty) after 1st trigger")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR2.get(sensor)
        if did:
            _verify_did_payload_is_byte(sensor, "EDR2", did, EDR_EMPTY_BYTE)
    aria_reports.close_group()

    aria_reports.add_group("Faulted RSUs read all-0xFF (EDR1/EDR2) after 1st crash")
    for sensor in other_a:
        for slot, dmap in (("EDR1", SENSOR_DID_EDR1), ("EDR2", SENSOR_DID_EDR2)):
            did = dmap.get(sensor)
            if did:
                _verify_did_payload_is_byte(sensor, slot, did, EDR_EMPTY_BYTE)
    aria_reports.close_group()

    # ── IGN cycle, 2nd crash phase ──────────────────────────────────────────
    aria_reports.add_group("IGN cycle")
    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)
    aria_reports.close_group()

    aria_reports.add_group("Crash 2 :: @@CRASH_B_UPPER@@  (" + fault_type + " on other RSUs)")
    load_crash_curves("@@CRASH_B@@")
    _inject_fault(other_b)
    _read_fault_dtc()
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc("@@CRASH_B_LABEL@@ DTC (2nd)")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 retention after @@CRASH_B_UPPER@@ (still 1st/@@CRASH_A_UPPER@@ values)")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR1.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR1", did, "@@CRASH_A@@", group_a["polarity"])
    aria_reports.close_group()

    aria_reports.add_group("EDR2 vs INPUT after @@CRASH_B_UPPER@@ crash (2nd trigger)")
    for sensor in group_b["sensors"]:
        did = SENSOR_DID_EDR2.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR2", did, "@@CRASH_B@@", group_b["polarity"])
    aria_reports.close_group()

    aria_reports.add_group("Faulted RSUs read all-0xFF after 2nd crash")
    for sensor in other_b:
        for slot, dmap in (("EDR1", SENSOR_DID_EDR1), ("EDR2", SENSOR_DID_EDR2)):
            did = dmap.get(sensor)
            if did:
                _verify_did_payload_is_byte(sensor, slot, did, EDR_EMPTY_BYTE)
    aria_reports.close_group()

    aria_reports.add_group("IGN cycle retention check")
    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)
    RESULT.InsertComment("Re-read EDR1/EDR2; values must match the previous ignition cycle.")
    aria_reports.close_group()

    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
'''


# ── Family C: individual EDR parameter ──────────────────────────────────────
PARAM_BODY = '''
def run_test():
    tc_id = "@@NAME@@"
    tc_desc = "@@DESC@@"
    edr_param = "@@PARAM@@"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc,
    )

    # Step 1-2: normal bench, no DTC
    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    aria_reports.add_group("Pre-check: no DTC on a fault-free bench")
    Read_DTC("No DTC (normal condition)", Read_DTC_Resp, Read_DTC_Req)
    aria_reports.close_group()

    # Param-specific setup (project hardware/CAN action — see step text)
    aria_reports.add_group("Parameter setup :: " + edr_param)
@@SETUP_BLOCK@@
    aria_reports.close_group()

    # Simulate + trigger crash
    crash_type = "front"
    aria_reports.add_group("Simulate + trigger " + crash_type + " crash")
    load_crash_curves(crash_type)
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc(crash_type.title() + " Crash DTC")
    aria_reports.close_group()

    # Read EDR 0x0455 with L1 security and verify the parameter
    Sleep(5)
    aria_reports.add_group("Read EDR (220455, L1 security) and verify " + edr_param)
    enter_ext_session()
    Internal_Security_Access(EDR_L1_SECURITY_LEVEL)
    edr = read_edr_parameters([edr_param], did=EDR_FULL_READ_DID, crash_type=crash_type, return_data=True)
    RESULT.InsertComment("EDR read (220455) for " + edr_param + ": " + str(edr))
    RESULT.InsertComment("Verification note from spec: @@VERIFY_NOTE@@")
    aria_reports.close_group()

    # Clear NVM and DTC
    aria_reports.add_group("Clear NVM and DTC")
    NVM_Clear_L61()
    ClearDTC()
    aria_reports.close_group()

    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
'''


# ── Family D: multi-event near-crash ────────────────────────────────────────
MULTIEVENT_BODY = '''
def run_test():
    tc_id = "@@NAME@@"
    tc_desc = "@@DESC@@"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()

    # events: list of (label, crash_type, expect_deployment)
    events = @@EVENTS@@

    aria_reports.add_group("IGN ON + proveout")
    RESULT.InsertComment("Wait for proveout to complete after IGN ON.")
    aria_reports.close_group()

    for idx, (label, crash_type, expect_deploy) in enumerate(events, start=1):
        aria_reports.add_group("Event " + str(idx) + " :: " + label)
        load_crash_curves(crash_type)
        TriggerCrash()
        Sleep(2)
        if expect_deploy:
            _read_crash_dtc(label + " Crash DTC (deployment)")
        else:
            RESULT.InsertComment(
                "Near crash: confirm NO squibs deployed and crash signals "
                "DOOR_UNLOCK=0, STS_CRASH=0, CRASH_LOCATION=0 (Near), SCM_CNT=0, NEAR_CRASH=1."
            )
            Read_DTC("No new DTC after near crash (Event " + str(idx) + ")",
                     Read_DTC_Resp, Read_DTC_Req)
        # Read EDR1/EDR2 multi-event view after the 2nd event onward
        if idx >= 2:
            Sleep(3)
            RESULT.InsertComment(
                "Read EDR1 (0x0455) and EDR2 (0x045B): verify MultiEvent# counters, "
                "TimeB/W (<5s between events), and that EDR1/EDR2 hold the expected events "
                "per the spec table for Event " + str(idx) + "."
            )
            edr1 = read_edr_parameters(None, did="0455", return_data=True)
            edr2 = read_edr_parameters(None, did="045B", return_data=True)
            RESULT.InsertComment("EDR1 (0x0455): " + str(edr1))
            RESULT.InsertComment("EDR2 (0x045B): " + str(edr2))
        aria_reports.close_group()
        Sleep(1)  # events are <5 s apart

    aria_reports.add_group("Sensor data cross-check (EDR vs EEPROM) after final event")
    RESULT.InsertComment("Compare EEPROM sensor data against the EDR sensor recording values.")
    aria_reports.close_group()

    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
'''


# ── Family E: parameters folder stub ────────────────────────────────────────
PARAMETERS_STUB_BODY = '''
def run_test():
    """SUBS_EDR_PARAMETERS is a folder/grouping node in the test spec — it has
    no standalone test steps. This stub exists so the name resolves in the
    runner; the actual parameter checks live in the
    SUBS_EDR_Element_ID_*_TestCase_* scripts."""
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False,
        tc_desc="SUBS_EDR_PARAMETERS — grouping node (no standalone steps).",
    )
    aria_reports.add_group("SUBS_EDR_PARAMETERS")
    RESULT.InsertComment(
        "Folder/grouping node — see SUBS_EDR_Element_ID_*_TestCase_* for the "
        "individual EDR parameter verifications."
    )
    aria_reports.close_group()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
'''


# ── Test-case registry ──────────────────────────────────────────────────────
def _deltav(name, desc, axis, ca, cb, step1, step2, pol):
    return {"family": "deltav", "name": name, "desc": desc, "axis": axis,
            "crash_a": ca, "crash_b": cb, "step1": step1, "step2": step2,
            "polarity_note": pol}


DELTAV_CASES = [
    _deltav("EDR_Element_IDs_DeltavLongitudinal_01",
            "DeltaVLgt: onboard |DeltaVx| < 8 km/h in any 150 ms window with RSU input 0G.",
            "Lgt", "front", "rear",
            "Load 0 to applicable RSU; load CTx so |DeltaVx| < 8 km/h within 150 ms.",
            "Load 0 to applicable RSU; load CTx so |DeltaVx| < 8 km/h within 150 ms.",
            "below-threshold case; record per spec"),
    _deltav("EDR_Element_IDs_DeltavLongitudinal_02",
            "DeltaVLgt: |DeltaVx| < 8 km/h with RSU input at threshold.",
            "Lgt", "front", "rear",
            "Load threshold to RSU; load CTx so |DeltaVx| < 8 km/h across any 150 ms.",
            "Load 0 to RSU; load CTx so |DeltaVx| < 8 km/h within 150 ms.",
            "below-threshold case"),
    _deltav("EDR_Element_IDs_DeltavLongitudinal_03",
            "DeltaVLgt: |DeltaVx| >= 8 km/h with RSU set to 0.",
            "Lgt", "front", "rear",
            "Load 0 to RSU; load CTx so |DeltaVx| >= 8 km/h across any 150 ms.",
            "Load 0 to RSU; load CTx so |DeltaVx| < 8 km/h within 150 ms.",
            "at/above-threshold case"),
    _deltav("EDR_Element_IDs_DeltavLongitudinal_04",
            "DeltaVLgt: |DeltaVx| >= 8 km/h with RSU input at threshold; front then rear.",
            "Lgt", "front", "rear",
            "Load threshold to Front RSU; load CTx so |DeltaVx| >= 8 km/h across any 150 ms.",
            "Load threshold to Rear RSU; load CTx so |DeltaVx| >= 8 km/h across any 150 ms.",
            "front=negative polarity, rear=positive polarity"),
    _deltav("EDR_Element_IDs_DeltavLongitudinal_05",
            "DeltaVLgt: onboard values incremental; check polarity.",
            "Lgt", "front", "rear",
            "Load threshold to Front RSU; load CTx incremental across any 150 ms.",
            "Load threshold to Rear RSU; load CTx incremental across any 150 ms.",
            "front=negative polarity, rear=positive polarity"),
    _deltav("EDR_Element_IDs_DeltavLongitudinal_06",
            "DeltaVLgt: incremental crossing boundary; values recorded irrespective of polarity.",
            "Lgt", "front", "rear",
            "Load threshold to Front RSU; load CTx incremental crossing boundary across 150 ms.",
            "Load threshold to Rear RSU; load CTx incremental crossing boundary across 150 ms.",
            "recorded irrespective of polarity; MaxDeltaVLgt = last max, TimeMaxDeltaVLgt = time of max"),
    _deltav("EDR_Element_IDs_DeltavLongitudinal_07",
            "DeltaVLgt: onboard CTx DeltaVLgt swept -100..+100 km/h in any 150 ms; RSU at threshold.",
            "Lgt", "front", "rear",
            "Load threshold to Front RSU; load CTx so -100 <= |DeltaVx| >= +100 across 150 ms.",
            "Load threshold to Front RSU; load CTx so -100 <= |DeltaVx| >= +100 across 150 ms.",
            "front=negative polarity, rear=positive polarity"),
    _deltav("EDR_Element_IDs_DeltavLatteral_08",
            "DeltaVLat: lateral |DeltaVx| < 8 km/h with RSU input 0G.",
            "Lat", "left", "right",
            "Load 0 to RSU; load CTy so |DeltaVx| < 8 km/h within 150 ms.",
            "Load 0 to RSU; load CTy so |DeltaVx| < 8 km/h within 150 ms.",
            "below-threshold case"),
    _deltav("EDR_Element_IDs_DeltavLatteral_09",
            "DeltaVLat: lateral |DeltaVx| < 8 km/h with RSU input at threshold.",
            "Lat", "left", "right",
            "Load threshold to RSU; load CTy so |DeltaVx| < 8 km/h across any 150 ms.",
            "Load 0 to RSU; load CTy so |DeltaVx| < 8 km/h within 150 ms.",
            "below-threshold case"),
    _deltav("EDR_Element_IDs_DeltavLatteral_10",
            "DeltaVLat: lateral |DeltaVx| >= 8 km/h with RSU set to 0.",
            "Lat", "left", "right",
            "Load 0 to RSU; load CTy so |DeltaVx| >= 8 km/h across any 150 ms.",
            "Load 0 to RSU; load CTy so |DeltaVx| < 8 km/h within 150 ms.",
            "at/above-threshold case"),
    _deltav("EDR_Element_IDs_DeltavLatteral_11",
            "DeltaVLat: lateral |DeltaVx| >= 8 km/h with RSU input at threshold.",
            "Lat", "left", "right",
            "Load threshold to RSU; load CTy so |DeltaVx| >= 8 km/h across any 150 ms.",
            "Load threshold to RSU; load CTy so |DeltaVx| >= 8 km/h across any 150 ms.",
            "at/above-threshold case"),
    _deltav("EDR_Element_IDs_DeltavLatteral_12",
            "DeltaVLat: lateral sweep 5,7,7,8,>8 within 150 ms; RSU 0; verify threshold recording.",
            "Lat", "left", "right",
            "Load threshold to RSU; load CTy incremental sweep across any 150 ms.",
            "Load threshold to RSU; load CTy incremental sweep across any 150 ms.",
            "records once threshold exceeded"),
    _deltav("EDR_Element_IDs_DeltavLateral_13",
            "DeltaVLat: incremental crossing boundary; values recorded irrespective of polarity.",
            "Lat", "left", "right",
            "Load threshold to Left side RSUs (B/C/A pillar); load CTy incremental crossing boundary.",
            "Load threshold to Right side RSUs (B/C/A pillar); load CTy incremental crossing boundary.",
            "recorded irrespective of polarity; MaxDeltaVLat = last max"),
    _deltav("EDR_Element_IDs_DeltavLateral_14",
            "DeltaVLat: onboard CTy DeltaVLat swept -100..+100 km/h; RSU at threshold.",
            "Lat", "left", "right",
            "Load threshold to Left side RSUs; load CTy so -100 <= |DeltaVx| >= +100 across 150 ms.",
            "Load threshold to Right side RSUs; load CTy so -100 <= |DeltaVx| >= +100 across 150 ms.",
            "left=positive polarity, right=negative polarity"),
]


def _fault(name, desc, fault, ca, cb):
    return {"family": "fault", "name": name, "desc": desc, "fault": fault,
            "crash_a": ca, "crash_b": cb}


FAULT_TYPES = ["OpenFault", "S2B", "S2G", "InternalFault", "CommFault", "ConfigFault", "OutOfRange"]
FAULT_CASES = []
for ft in FAULT_TYPES:
    FAULT_CASES.append(_fault(
        "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_" + ft,
        "Front then rear crash with other RSUs in " + ft + " fault; faulted RSU EDR reads FF.",
        ft, "front", "rear"))
for ft in FAULT_TYPES:
    FAULT_CASES.append(_fault(
        "TC_EDR_Left_Crash_Side_Negative_OtherRSU_" + ft,
        "Left then right crash with other RSUs in " + ft + " fault; faulted RSU EDR reads FF.",
        ft, "left", "right"))
# Positive-polarity OutOfRange variants
FAULT_CASES.append(_fault(
    "TC_EDR_Rear_Crash_RSU_CTx_Positive_OtherRSU_OutOfRange",
    "Rear then front crash with other RSUs OutOfRange; faulted RSU EDR reads FF.",
    "OutOfRange", "rear", "front"))
FAULT_CASES.append(_fault(
    "TC_EDR_Right_Crash_Side_Positive_OtherRSU_OutOfRange",
    "Right then left crash with other RSUs OutOfRange; faulted RSU EDR reads FF.",
    "OutOfRange", "right", "left"))


def _param(name, desc, param, setup_lines, verify):
    return {"family": "param", "name": name, "desc": desc, "param": param,
            "setup_lines": setup_lines, "verify": verify}


PARAM_CASES = [
    _param("SUBS_EDR_Element_ID_LifeTimeEventNb_TestCase_1",
           "Lifetime event number: trigger near crash 50 times, verify count in EDR.",
           "LifeTimeEventNb",
           ['    RESULT.InsertComment("Load Near Crash curves.")',
            '    load_crash_curves("near")',
            '    RESULT.InsertComment("Trigger Near Crash 50 times (loop).")',
            '    for _n in range(50):',
            '        TriggerCrash()',
            '        Sleep(1)'],
           "LifeTimeEventNb counts the lifetime crash events (expect 50)."),
    _param("SUBS_EDR_Element_ID_Crash_Parameters_TestCase_2",
           "Crash parameters: simulate respective crash curves, verify crash parameters in EDR.",
           "Crash_Parameters",
           ['    RESULT.InsertComment("Simulate respective crash curves (handled by load_crash_curves at crash step).")'],
           "Verify CrashLocation, CrashRecordLockStatus, IgnCycleCrash, etc."),
    _param("SUBS_EDR_Element_ID_Batt_Volt_TestCase_3",
           "Battery voltage: set 6.5V/12V/19V, trigger crash, verify BATTVOLT in EDR.",
           "BATTVOLT",
           ['    RESULT.InsertComment("SPEC STEP (project hardware): set battery to 6.5V (UV), 12V (normal), 19V (OV) via PS before crash.")'],
           "BATTVOLT records the battery voltage at crash (UV/normal/OV)."),
    _param("SUBS_EDR_Element_ID_MalFuntion_TestCase_4",
           "Malfunction lamp time: create electrical fault, cycle IGN, verify lamp-on time in EDR.",
           "MalFunction",
           ['    RESULT.InsertComment("SPEC STEP (project hardware): create an electrical fault on the bench.")',
            '    RESULT.InsertComment("Cycle IGN n times and wait while the fault is active.")',
            '    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)'],
           "Malfunction time updates every 10 s; 60 s lamp-on -> records accordingly."),
    _param("SUBS_EDR_Element_ID_IGNCycle_TestCase_5",
           "IGN cycle count: cycle IGN n times, trigger crash, verify IGN-cycle count in EDR.",
           "IGNCycle",
           ['    RESULT.InsertComment("Cycle IGN n times.")',
            '    for _n in range(3):',
            '        PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)'],
           "IGNCycle records the number of ignition cycles at crash."),
    _param("SUBS_EDR_Element_ID_PADILamp_TestCase_6",
           "PADI lamp status: change PADI lamp via switch, trigger crash, verify status (0/1) in EDR.",
           "PADILamp",
           ['    RESULT.InsertComment("SPEC STEP (project CAN/hardware): change PADI lamp status via switch (CAN or hardware).")'],
           "PADILamp value is 0 or 1."),
    _param("SUBS_EDR_Element_ID_DCS_TestCase_7",
           "Seat-belt (DCS) status: set Buckled/Unbuckled/Faulty, trigger crash, verify in EDR.",
           "DCS",
           ['    RESULT.InsertComment("SPEC STEP (project CAN): set seat-belt status to Buckled / Unbuckled / Faulty.")'],
           "EDR DCS encoding: Buckled=0, Unbuckled=1, Faulty=2."),
    _param("SUBS_EDR_Element_ID_Velocity_TestCase_8",
           "Velocity: simulate + trigger crash, verify velocity parameters in EDR.",
           "Velocity",
           ['    RESULT.InsertComment("Velocity comes from the simulated crash; no extra setup before crash.")'],
           "Verify the velocity parameter recorded in EDR."),
]


MULTIEVENT_CASES = [
    {"family": "multievent",
     "name": "SUBS_EDR_MultiEvent_NearCrash_NearCrash_NearCrash",
     "desc": "Three events <5s apart: Near, Near, Near. Verify EDR multi-event behavior.",
     "events": '[("Near Crash", "near", False), ("Near Crash", "near", False), ("Near Crash", "near", False)]'},
    {"family": "multievent",
     "name": "SUBS_EDR_MultiEvent_NearCrash_NearCrash_Deployment",
     "desc": "Three events <5s apart: Near, Near, Front deployment. Verify EDR + squib deployment.",
     "events": '[("Near Crash", "near", False), ("Near Crash", "near", False), ("Front Deployment", "front", True)]'},
]

PARAMETERS_STUB = {"family": "parameters_stub", "name": "SUBS_EDR_PARAMETERS",
                   "desc": "SUBS_EDR_PARAMETERS grouping node."}


def render(case):
    fam = case["family"]
    if fam == "deltav":
        body = (DELTAV_BODY
                .replace("@@NAME@@", case["name"])
                .replace("@@DESC@@", case["desc"])
                .replace("@@AXIS@@", case["axis"])
                .replace("@@CRASH_A@@", case["crash_a"])
                .replace("@@CRASH_B@@", case["crash_b"])
                .replace("@@STEP1@@", case["step1"])
                .replace("@@STEP2@@", case["step2"])
                .replace("@@POLARITY_NOTE@@", case["polarity_note"]))
    elif fam == "fault":
        ca, cb = case["crash_a"], case["crash_b"]
        body = (FAULT_BODY
                .replace("@@NAME@@", case["name"])
                .replace("@@DESC@@", case["desc"])
                .replace("@@FAULT@@", case["fault"])
                .replace("@@CRASH_A_UPPER@@", ca.upper())
                .replace("@@CRASH_B_UPPER@@", cb.upper())
                .replace("@@CRASH_A_LABEL@@", ca.title() + " Crash")
                .replace("@@CRASH_B_LABEL@@", cb.title() + " Crash")
                .replace("@@CRASH_A@@", ca)
                .replace("@@CRASH_B@@", cb))
    elif fam == "param":
        body = (PARAM_BODY
                .replace("@@NAME@@", case["name"])
                .replace("@@DESC@@", case["desc"])
                .replace("@@PARAM@@", case["param"])
                .replace("@@VERIFY_NOTE@@", case["verify"])
                .replace("@@SETUP_BLOCK@@", "\n".join(case["setup_lines"])))
    elif fam == "multievent":
        body = (MULTIEVENT_BODY
                .replace("@@NAME@@", case["name"])
                .replace("@@DESC@@", case["desc"])
                .replace("@@EVENTS@@", case["events"]))
    elif fam == "parameters_stub":
        body = PARAMETERS_STUB_BODY
    else:
        raise ValueError("unknown family: " + fam)
    return COMMON_HEADER + body


ALL_CASES = DELTAV_CASES + FAULT_CASES + PARAM_CASES + MULTIEVENT_CASES + [PARAMETERS_STUB]


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--out-dir", default=str(OUT_DIR_DEFAULT))
    ap.add_argument("--apply", action="store_true", help="Write files (default: dry-run).")
    args = ap.parse_args()
    out_dir = Path(args.out_dir)
    if not out_dir.is_dir():
        print("ERROR: out dir not found: " + str(out_dir), file=sys.stderr)
        return 2

    print("Output dir: " + str(out_dir))
    print("Mode      : " + ("APPLY" if args.apply else "dry-run"))
    by_fam = {}
    for c in ALL_CASES:
        by_fam.setdefault(c["family"], []).append(c)
    for fam, cs in by_fam.items():
        print("  " + fam + ": " + str(len(cs)) + " case(s)")
    print()
    for c in ALL_CASES:
        print("  + " + c["name"] + ".py   [" + c["family"] + "]")

    if not args.apply:
        print("\nDry-run only. Re-run with --apply to write the files.")
        return 0

    for c in ALL_CASES:
        (out_dir / (c["name"] + ".py")).write_text(render(c), encoding="utf-8")
    print("\nWrote " + str(len(ALL_CASES)) + " file(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
