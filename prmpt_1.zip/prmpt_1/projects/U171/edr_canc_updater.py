"""edr_canc_updater.py — keep EDR scripts and canc_config.py in lockstep with
the M314 EDR test-case CSV.

Default = dry-run. Re-run with --apply to write changes.

It does TWO things, in this exact order:

1. EDR scripts under <SCRIPTS>:
   For every SUBS_EDR_Element_ID_<Param>_TestCase_<N>_<M>(_suffix).py file:
     - Parameter index N is the number after _TestCase_ in the filename.
     - Find every ["TestCase_X(_Invalid|_OutofRange)?_values"] lookup.
     - If X != N, rewrite the key so the index matches N.
     - The KIND (values / Invalid_Values / OutofRange_Values) is preserved —
       scripts that already read both valid + invalid keys keep both lines
       and both get their N corrected independently.
     - Nothing else in the file is changed. Whitespace, blank lines and
       comments are byte-identical outside the patched substring.

2. canc_config.py:
   For each CAN_<PARAM> = {...} block, work out the parameter index N (from
   the CSV signal_name → script-filename param) and ensure these keys exist
   and are populated from the CSV:
       TestCase_N_values             → valid sweep, physical→raw via Factor/Offset.
       TestCase_N_Invalid_Values     → scalar, AS-IS from CSV (no conversion).
       TestCase_N_OutofRange_Values  → scalar (or short list), AS-IS from CSV.
   Existing keys are left untouched unless --overwrite-config is passed.

Backups: every file modified gets a sibling .bak (overwritten each --apply run).
"""

from __future__ import annotations
import argparse
import csv
import json
import re
import shutil
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# ──────────────────────────────────────────────────────────────────────────────
# Defaults
# ──────────────────────────────────────────────────────────────────────────────
DEFAULT_CSV = r"C:\project_req\m314\tc_edr\test_case_array\edr_testcase_arrays.csv"
DEFAULT_SCRIPTS = r"C:\Framework_IOEM_Py\projects\U171\modules\EDR\scripts"
DEFAULT_CONFIG = r"C:\Framework_IOEM_Py\projects\U171\config\canc_config.py"

SCRIPT_FNAME_RE = re.compile(
    r"^SUBS_EDR_Element_ID_(?P<param>.+?)_TestCase_(?P<n>\d+)_(?P<m>\d+)(?:_.+)?\.py$"
)
# CSV's test_case_name (no .py, may have _in_CANWAKEUP between param and TestCase).
CSV_NAME_RE = re.compile(
    r"^SUBS_EDR_Element_ID_(?P<param>.+?)(?:_in_CANWAKEUP)?_TestCase_(?P<n>\d+)_(?P<m>\d+)$"
)
KEY_RE = re.compile(r'"(TestCase_(\d+)(?:_(Invalid|OutofRange))?_[vV]alues)"')

# Map CSV scenario → key kind. Anything else → "values" (valid sweep).
KIND_BY_SCENARIO = {
    "signal_invalid": "Invalid_Values",
    "reserved_or_out_of_range": "OutofRange_Values",
}


# ──────────────────────────────────────────────────────────────────────────────
# Models
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class TCInfo:
    """One CSV row, parsed."""
    test_case_name: str
    param: str
    n: int
    m: int
    scenario: str
    time_window: str
    array_values: Optional[list]    # only ever list-or-None (markers filtered out at load time)
    values_during_fault: object     # str marker OR list of strings
    after_fault: Optional[list]     # only ever list-or-None


@dataclass
class ParamSummary:
    """What we know about one EDR parameter (one index N) after digesting CSV."""
    param: str
    n: int
    valid_sweep_physical: list = field(default_factory=list)
    invalid_scalar: object = None      # raw, AS-IS from CSV (scalar or short list)
    outofrange_scalar: object = None   # raw, AS-IS from CSV (scalar or short list)
    scenarios_seen: set = field(default_factory=set)


@dataclass
class ConfigBlock:
    """One CAN_<PARAM> = { ... } block in canc_config.py."""
    name: str                  # e.g. "CAN_ACC_PED"
    edr_parameter: str         # value of "EDR_Parameter"
    factor: float
    offset: float
    bit_width: int             # inferred from MAX value, used for hex padding only
    start_line: int            # 1-indexed line where `CAN_<X> = {` lives
    end_line: int              # 1-indexed line of the closing `}`
    existing_keys: dict        # {key_name -> line_number}
    indent: str = "    "       # whitespace prefix used for inner items


# ──────────────────────────────────────────────────────────────────────────────
# CSV loading
# ──────────────────────────────────────────────────────────────────────────────
def _parse_array_cell(cell: str):
    if not cell:
        return None
    cell = cell.strip()
    if cell.startswith("["):
        try:
            return [x.strip() for x in json.loads(cell)]
        except Exception:
            return None
    return cell  # leave marker strings alone


def load_csv(path: Path) -> list[TCInfo]:
    out: list[TCInfo] = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            name = (row.get("test_case_name") or "").strip()
            m = CSV_NAME_RE.match(name)
            if not m:
                continue
            av = _parse_array_cell(row.get("array_values") or "")
            af = _parse_array_cell(
                row.get("values_after_fault_cleared_or_non_fault_interval") or ""
            )
            out.append(
                TCInfo(
                    test_case_name=name,
                    param=m.group("param"),
                    n=int(m.group("n")),
                    m=int(m.group("m")),
                    scenario=(row.get("scenario") or "").strip(),
                    time_window=(row.get("time_window") or "").strip(),
                    array_values=av if isinstance(av, list) else None,
                    values_during_fault=_parse_array_cell(
                        row.get("values_during_fault") or ""
                    ),
                    after_fault=af if isinstance(af, list) else None,
                )
            )
    return out


def summarize_per_param(rows: list[TCInfo]) -> dict[int, ParamSummary]:
    """Collapse all CSV rows into one ParamSummary per parameter index N.
    The 'param' field uses the first non-CANWAKEUP variant we see for that N.
    """
    by_n: dict[int, ParamSummary] = {}
    for r in rows:
        s = by_n.setdefault(r.n, ParamSummary(param=r.param, n=r.n))
        s.scenarios_seen.add(r.scenario)

        # valid sweep: prefer the full_interval row of the 'valid' scenario.
        if (
            r.scenario == "valid"
            and r.time_window in ("full_interval", "unspecified", "")
            and r.array_values
            and len(r.array_values) > len(s.valid_sweep_physical)
        ):
            s.valid_sweep_physical = list(r.array_values)

        # invalid scalar: scenario=signal_invalid, full_interval, scalar form.
        if r.scenario == "signal_invalid" and isinstance(r.values_during_fault, list):
            uniq = sorted(set(r.values_during_fault), key=lambda v: str(v))
            if s.invalid_scalar is None:
                s.invalid_scalar = uniq[0] if len(uniq) == 1 else uniq

        # out-of-range: scenario=reserved_or_out_of_range, scalar form.
        if r.scenario == "reserved_or_out_of_range" and isinstance(
            r.values_during_fault, list
        ):
            uniq = sorted(set(r.values_during_fault), key=lambda v: str(v))
            if s.outofrange_scalar is None:
                s.outofrange_scalar = uniq[0] if len(uniq) == 1 else uniq

    return by_n


# ──────────────────────────────────────────────────────────────────────────────
# Script-side updater
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class ScriptEdit:
    path: Path
    line_no: int          # 1-indexed line where the key sits
    old_key: str
    new_key: str


def plan_script_edits(scripts_dir: Path) -> tuple[list[ScriptEdit], list[str]]:
    """Return (planned edits, warnings)."""
    edits: list[ScriptEdit] = []
    warnings: list[str] = []
    for p in sorted(scripts_dir.glob("SUBS_EDR_Element_ID_*.py")):
        m = SCRIPT_FNAME_RE.match(p.name)
        if not m:
            warnings.append(f"  skipped (filename unparseable): {p.name}")
            continue
        n_correct = int(m.group("n"))
        lines = p.read_text(encoding="utf-8").splitlines()
        for i, line in enumerate(lines, start=1):
            for match in KEY_RE.finditer(line):
                full_key = match.group(1)
                n_found = int(match.group(2))
                kind = match.group(3)  # None | "Invalid" | "OutofRange"
                if n_found == n_correct:
                    continue
                # Build the corrected key, preserving the kind suffix and the
                # lowercase/uppercase style of "values"/"Values" in the source.
                suffix_kind = f"_{kind}" if kind else ""
                values_word = full_key.rsplit("_", 1)[-1]  # "values" or "Values"
                new_key = f"TestCase_{n_correct}{suffix_kind}_{values_word}"
                edits.append(
                    ScriptEdit(path=p, line_no=i, old_key=full_key, new_key=new_key)
                )
    return edits, warnings


def apply_script_edits(edits: list[ScriptEdit]) -> int:
    """Group edits by path and patch each file once. Writes .bak alongside."""
    by_path: dict[Path, list[ScriptEdit]] = defaultdict(list)
    for e in edits:
        by_path[e.path].append(e)

    files_changed = 0
    for path, file_edits in by_path.items():
        original = path.read_text(encoding="utf-8")
        patched = original
        # Apply in order; each edit replaces "<old_key>" → "<new_key>" exactly
        # within the line at edit.line_no. Doing a global replace would risk
        # changing comments or strings on unrelated lines, so we patch per line.
        lines = patched.splitlines(keepends=True)
        for e in file_edits:
            idx = e.line_no - 1
            if 0 <= idx < len(lines):
                lines[idx] = lines[idx].replace(f'"{e.old_key}"', f'"{e.new_key}"', 1)
        new_text = "".join(lines)
        if new_text != original:
            shutil.copyfile(path, path.with_suffix(path.suffix + ".bak"))
            path.write_text(new_text, encoding="utf-8")
            files_changed += 1
    return files_changed


# ──────────────────────────────────────────────────────────────────────────────
# Config-side parser
# ──────────────────────────────────────────────────────────────────────────────
CAN_DICT_START_RE = re.compile(r"^(?P<name>CAN_\w+)\s*=\s*\{\s*$")
FIELD_RE = re.compile(
    r'^(?P<indent>\s+)"(?P<key>[\w]+)"\s*:\s*(?P<value>.+?),?\s*$'
)


def _parse_simple_number(text: str) -> Optional[float]:
    """Parse 0x1A, 0xFF, 250, 0.4 → float. Returns None if not a simple literal."""
    t = text.strip().rstrip(",")
    try:
        if t.lower().startswith("0x"):
            return float(int(t, 16))
        return float(t)
    except Exception:
        return None


def parse_config(path: Path) -> tuple[list[str], list[ConfigBlock]]:
    """Return (lines_with_newlines, blocks)."""
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    blocks: list[ConfigBlock] = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        m = CAN_DICT_START_RE.match(line.rstrip("\n"))
        if not m:
            i += 1
            continue
        # only blocks that look like per-signal dicts (skip CAN_SIGNAL_Rx_MAP etc.)
        name = m.group("name")
        start_line = i + 1
        # Find this block's closing brace, which is `}` AT COLUMN 0. Nested dicts
        # inside the block (e.g. "fault_logic": {...}) always have an INDENTED
        # closing brace, so checking that the line starts with `}` at column 0
        # cleanly skips them.
        end_line = None
        for j in range(i + 1, n):
            line_raw = lines[j].rstrip("\n")
            if line_raw and line_raw[0] == "}":
                end_line = j + 1
                break
        if end_line is None:
            i += 1
            continue

        edr_param = ""
        factor = 1.0
        offset = 0.0
        max_value = 0xFF
        indent = "    "                       # default — overridden by shortest match
        shortest_indent_len = None            # tracks the SHORTEST indent seen (= top-level)
        existing_keys: dict[str, int] = {}
        for j in range(i + 1, end_line - 1):
            fm = FIELD_RE.match(lines[j].rstrip("\n"))
            if not fm:
                continue
            this_indent = fm.group("indent")
            # Only top-level keys count for indent and for `existing_keys`. Nested-dict
            # fields (e.g. inside "fault_logic": {...}) have a strictly deeper indent;
            # we must not record them as block-level keys, otherwise inserts go in the
            # wrong place.
            if shortest_indent_len is None or len(this_indent) < shortest_indent_len:
                shortest_indent_len = len(this_indent)
                indent = this_indent
                # We just found a shallower indent → previously-recorded "keys" were
                # actually nested keys; throw them away and start fresh.
                existing_keys = {}
            if len(this_indent) > shortest_indent_len:
                # Nested key — ignore for block-level bookkeeping.
                continue
            key = fm.group("key")
            val = fm.group("value")
            existing_keys[key] = j + 1
            if key == "EDR_Parameter":
                vv = val.strip().rstrip(",")
                if vv.startswith('"') and vv.endswith('"'):
                    edr_param = vv[1:-1]
            elif key == "Factor":
                v = _parse_simple_number(val)
                if v is not None:
                    factor = v
            elif key == "Offset":
                v = _parse_simple_number(val)
                if v is not None:
                    offset = v
            elif key == "MAX":
                v = _parse_simple_number(val)
                if v is not None and v > 0:
                    max_value = int(v)

        # Only treat blocks that have an EDR_Parameter as candidates.
        if edr_param:
            bit_width = max(8, max_value.bit_length())
            # Round up to a nybble so hex padding is consistent: 8/12/16/24/32 bits.
            for cap in (8, 12, 16, 24, 32):
                if max_value <= (1 << cap) - 1:
                    bit_width = cap
                    break
            blocks.append(
                ConfigBlock(
                    name=name,
                    edr_parameter=edr_param,
                    factor=factor,
                    offset=offset,
                    bit_width=bit_width,
                    start_line=start_line,
                    end_line=end_line,
                    existing_keys=existing_keys,
                    indent=indent,
                )
            )
        i = end_line
    return lines, blocks


# ──────────────────────────────────────────────────────────────────────────────
# Config-side updater
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class ConfigInsertion:
    block: ConfigBlock
    key: str
    value_literal: str       # the Python source for the value (e.g. "[0x00, 0x19, ...]")
    insert_before_line: int  # 1-indexed line (the closing `}` line)


def _physical_to_raw(physical_value: str, factor: float, offset: float) -> int:
    """Convert a physical-units string from the CSV to a raw integer."""
    s = physical_value.strip()
    try:
        v = float(s)
    except Exception:
        # spec sometimes has things like "0.0" or "-10.0" — both float-parseable
        v = float(s.replace(",", "."))
    raw = (v - offset) / factor if factor else v
    return int(round(raw))


def _fmt_hex(value: int, bit_width: int) -> str:
    pad = max(2, (bit_width + 3) // 4)
    # signed values get cast into the field; clamp negatives via two's complement.
    if value < 0:
        value &= (1 << bit_width) - 1
    return f"0x{value:0{pad}X}"


def _fmt_value_list(physical_values: list, factor: float, offset: float,
                    bit_width: int) -> str:
    raws = [_physical_to_raw(v, factor, offset) for v in physical_values]
    return "[" + ", ".join(_fmt_hex(v, bit_width) for v in raws) + "]"


def _fmt_scalar_as_raw(value, bit_width: int) -> str:
    """Render a CSV-supplied raw value as a Python literal, AS-IS (no Factor/Offset)."""
    # value can be a scalar (str or number) or a short list
    if isinstance(value, list):
        items = []
        for v in value:
            try:
                iv = int(float(v))
                items.append(_fmt_hex(iv, bit_width))
            except Exception:
                items.append(repr(v))
        return "[" + ", ".join(items) + "]"
    try:
        iv = int(float(value))
        return _fmt_hex(iv, bit_width)
    except Exception:
        return repr(value)


def _normalize(s: str) -> str:
    """Lowercase + strip whitespace + collapse separators. So 'Door Lock Status',
    'door_lock_status' and 'DOOR-LOCK-STATUS' all reduce to 'doorlockstatus'."""
    return re.sub(r"[\s_\-]+", "", s).lower()


# Hand-coded aliases for the few CSV param names whose canc_config block lives
# under a different name (different physical signal naming or a "snapshot at T0"
# variant of an existing signal). Maps CSV signal_name → CAN_<X> block name.
PARAM_ALIASES = {
    "BRK_SWITCH":          "CAN_BRK_PDL",        # EDR_Parameter is BRAKE_PEDAL_VALUE
    "DoorOpenStatus":      "CAN_STS_DOOR",       # EDR_Parameter is "DoorsOpenStatus" (plural)
    "VehSpdLgtAtTimeZero": "CAN_VEHICLE_SPEED",  # same VehSpdLgt signal, sampled at T0
    "VehSpdLgtAtTimeZero_in_CANWAKEUP": "CAN_VEHICLE_SPEED",
}


def map_csv_param_to_block(
    blocks: list[ConfigBlock], csv_param: str
) -> Optional[ConfigBlock]:
    """Match a CSV signal_name (e.g. 'ACC_PED') to a CAN_<X> block via, in order:
        1. exact EDR_Parameter match
        2. normalized EDR_Parameter match (case- and separator-insensitive)
        3. hand-coded alias
        4. dict name CAN_<csv_param>
        5. normalized dict-name suffix match
    """
    # 1. exact
    for b in blocks:
        if b.edr_parameter == csv_param:
            return b
    # 2. normalized EDR_Parameter
    target = _normalize(csv_param)
    for b in blocks:
        if _normalize(b.edr_parameter) == target:
            return b
    # 3. hand-coded alias
    if csv_param in PARAM_ALIASES:
        target_name = PARAM_ALIASES[csv_param]
        for b in blocks:
            if b.name == target_name:
                return b
    # 4. dict name CAN_<csv_param>
    cand = f"CAN_{csv_param}"
    for b in blocks:
        if b.name == cand:
            return b
    # 5. normalized dict name (strip CAN_ prefix)
    for b in blocks:
        if _normalize(b.name.removeprefix("CAN_")) == target:
            return b
    return None


def plan_config_insertions(
    blocks: list[ConfigBlock],
    summaries: dict[int, ParamSummary],
    overwrite: bool,
) -> tuple[list[ConfigInsertion], list[str]]:
    """For each parameter summary that maps to a block, plan key insertions."""
    insertions: list[ConfigInsertion] = []
    warnings: list[str] = []

    # Group: which N's map to which block? (some blocks back multiple N's, e.g.
    # CAN_ABSOLUTE_ANGLE backs both ABSOLUTE_ANGLE N=5 and STEERING_ABSOLUTE_ANGLE N=41.)
    block_to_ns: dict[str, list[ParamSummary]] = defaultdict(list)
    for s in summaries.values():
        b = map_csv_param_to_block(blocks, s.param)
        if b is None:
            warnings.append(
                f"  no canc_config block matches CSV param {s.param!r} (index {s.n}) — skipped"
            )
            continue
        block_to_ns[b.name].append(s)

    by_name = {b.name: b for b in blocks}
    for block_name, params in block_to_ns.items():
        block = by_name[block_name]
        for s in params:
            n = s.n
            # 1) valid sweep
            key_valid = f"TestCase_{n}_values"
            if s.valid_sweep_physical and (
                key_valid not in block.existing_keys or overwrite
            ):
                literal = _fmt_value_list(
                    s.valid_sweep_physical, block.factor, block.offset, block.bit_width
                )
                insertions.append(
                    ConfigInsertion(
                        block=block,
                        key=key_valid,
                        value_literal=literal,
                        insert_before_line=block.end_line,
                    )
                )
            # 2) invalid scalar
            key_inv = f"TestCase_{n}_Invalid_Values"
            if s.invalid_scalar is not None and (
                key_inv not in block.existing_keys or overwrite
            ):
                literal = _fmt_scalar_as_raw(s.invalid_scalar, block.bit_width)
                insertions.append(
                    ConfigInsertion(
                        block=block,
                        key=key_inv,
                        value_literal=literal,
                        insert_before_line=block.end_line,
                    )
                )
            # 3) out-of-range scalar
            key_oor = f"TestCase_{n}_OutofRange_Values"
            if s.outofrange_scalar is not None and (
                key_oor not in block.existing_keys or overwrite
            ):
                literal = _fmt_scalar_as_raw(s.outofrange_scalar, block.bit_width)
                insertions.append(
                    ConfigInsertion(
                        block=block,
                        key=key_oor,
                        value_literal=literal,
                        insert_before_line=block.end_line,
                    )
                )
    return insertions, warnings


def _ensure_trailing_comma(lines: list[str], before_idx: int) -> None:
    """Walk backwards from `before_idx` (exclusive) to find the last non-blank,
    non-comment-only line. Append `,` to it if it doesn't already end with one.
    Preserves any trailing inline comment.

    Without this, inserting new keys after a block's previously-last item
    breaks the syntax when that last item is e.g. `"fault_logic": {...}` whose
    closing `}` lacks a trailing comma (legal as the last entry, illegal once
    a new entry follows).
    """
    j = before_idx - 1
    while j >= 0:
        raw = lines[j]
        stripped = raw.rstrip("\n").rstrip()
        # Skip blank lines and comment-only lines.
        if not stripped or stripped.lstrip().startswith("#"):
            j -= 1
            continue
        # Split off any inline comment so we test the actual code part.
        m = re.match(r"^(?P<code>.*?)(?P<comment>\s*#.*)?$", raw.rstrip("\n"))
        code = m.group("code").rstrip() if m else stripped
        if code.endswith(","):
            return
        comment = (m.group("comment") or "") if m else ""
        lines[j] = code + "," + comment + "\n"
        return


def apply_config_insertions(
    config_path: Path, insertions: list[ConfigInsertion], overwrite: bool
) -> int:
    """Insert keys before the closing `}` of each affected block.

    Insertions for the same block are grouped and processed in one pass so
    that line numbers stay valid as text is appended.
    """
    if not insertions:
        return 0
    lines = config_path.read_text(encoding="utf-8").splitlines(keepends=True)
    # Group insertions by block end line; sort descending so prior insertions
    # don't shift later indices.
    by_block: dict[int, list[ConfigInsertion]] = defaultdict(list)
    for ins in insertions:
        by_block[ins.insert_before_line].append(ins)
    edits_done = 0
    for end_line in sorted(by_block.keys(), reverse=True):
        block_insertions = by_block[end_line]
        block = block_insertions[0].block
        indent = block.indent
        # Build the text to insert just before the closing `}` line (1-indexed).
        new_chunk_lines = []
        for ins in block_insertions:
            if overwrite and ins.key in block.existing_keys:
                # Find the existing key's line and rewrite it in place.
                # (Handled in a separate pass below for clarity.)
                continue
            new_chunk_lines.append(
                f'{indent}"{ins.key}": {ins.value_literal},\n'
            )
        if new_chunk_lines:
            # end_line is 1-indexed; insert before that position (0-indexed end_line-1).
            insert_at = end_line - 1
            # CRITICAL: make sure the previously-last entry in the block ends
            # with a comma. Without this, blocks whose last item was e.g.
            # `"fault_logic": {...}` (no trailing comma) become syntax-invalid.
            _ensure_trailing_comma(lines, insert_at)
            lines[insert_at:insert_at] = new_chunk_lines
            edits_done += len(new_chunk_lines)
    # Now handle in-place overwrites (only when --overwrite-config).
    if overwrite:
        # Re-read line positions because we may have shifted them.
        text = "".join(lines)
        # Rather than re-parse the whole config, do a string-level safe rewrite
        # for each (block name, key) using a regex anchored to the block body.
        for ins in insertions:
            if ins.key not in ins.block.existing_keys:
                continue
            pattern = re.compile(
                rf'(\n[ \t]+"{re.escape(ins.key)}"\s*:\s*)[^\n]*?(,?\s*\n)'
            )
            replacement = rf"\g<1>{ins.value_literal},\n"
            # Replace only within the block — scope by name to be safe.
            block_open_idx = text.find(f"{ins.block.name} = {{")
            if block_open_idx < 0:
                continue
            # Find the closing brace at column 0 after block_open_idx.
            close_idx = text.find("\n}", block_open_idx)
            if close_idx < 0:
                continue
            head = text[:block_open_idx]
            body = text[block_open_idx:close_idx]
            tail = text[close_idx:]
            new_body, did = pattern.subn(replacement, body, count=1)
            if did:
                text = head + new_body + tail
                edits_done += 1
        lines = text.splitlines(keepends=True)

    backup_path = config_path.with_suffix(config_path.suffix + ".bak")
    shutil.copyfile(config_path, backup_path)
    new_text = "".join(lines)
    config_path.write_text(new_text, encoding="utf-8")
    # Safety net: confirm the result is still valid Python. If not, roll back.
    try:
        import ast
        ast.parse(new_text)
    except SyntaxError as e:
        # Restore from backup so the user is never left with a broken config.
        shutil.copyfile(backup_path, config_path)
        raise RuntimeError(
            f"config insertions produced invalid Python at line {e.lineno}: {e.msg}. "
            f"Reverted from backup; no changes written."
        ) from e
    return edits_done


# ──────────────────────────────────────────────────────────────────────────────
# Reporting
# ──────────────────────────────────────────────────────────────────────────────
def print_script_report(edits: list[ScriptEdit], warnings: list[str]) -> None:
    print(f"\n── Script edits planned: {len(edits)} change(s) across {len({e.path for e in edits})} file(s) ──")
    by_file: dict[Path, list[ScriptEdit]] = defaultdict(list)
    for e in edits:
        by_file[e.path].append(e)
    for path in sorted(by_file.keys()):
        print(f"  {path.name}")
        for e in by_file[path]:
            print(f"    line {e.line_no:4d}: {e.old_key}  ->  {e.new_key}")
    if warnings:
        print("\nWarnings:")
        for w in warnings:
            print(w)


def verify_alignment(
    scripts_dir: Path,
    blocks: list[ConfigBlock],
    script_edits: list[ScriptEdit],
    insertions: list[ConfigInsertion],
) -> tuple[list[str], int, int]:
    """Simulate the post-state and confirm every key each script will read
    actually exists in some canc_config block.
    Returns (misalignment_report_lines, n_ok_references, n_missing_references).
    """
    # Future-state key set per block name (existing ∪ planned-inserted).
    future_keys: dict[str, set[str]] = {b.name: set(b.existing_keys.keys()) for b in blocks}
    for ins in insertions:
        future_keys.setdefault(ins.block.name, set()).add(ins.key)

    # Index script edits by path for fast lookup.
    edits_by_path: dict[Path, list[ScriptEdit]] = defaultdict(list)
    for e in script_edits:
        edits_by_path[e.path].append(e)

    missing: list[tuple[str, str, str, Optional[str]]] = []
    ok_count = 0
    for p in sorted(scripts_dir.glob("SUBS_EDR_Element_ID_*.py")):
        m = SCRIPT_FNAME_RE.match(p.name)
        if not m:
            continue
        param_from_file = m.group("param")
        # Read source, apply planned edits in-memory to get post-state.
        lines = p.read_text(encoding="utf-8").splitlines()
        for e in edits_by_path.get(p, []):
            idx = e.line_no - 1
            if 0 <= idx < len(lines):
                lines[idx] = lines[idx].replace(f'"{e.old_key}"', f'"{e.new_key}"', 1)
        # Collect every TestCase_*_..._values key referenced post-edit.
        keys_seen: set[str] = set()
        for line in lines:
            for match in KEY_RE.finditer(line):
                keys_seen.add(match.group(1))
        target_block = map_csv_param_to_block(blocks, param_from_file)
        for k in keys_seen:
            if target_block is None:
                missing.append((p.name, k, param_from_file, None))
            elif k not in future_keys.get(target_block.name, set()):
                missing.append((p.name, k, param_from_file, target_block.name))
            else:
                ok_count += 1
    # Format as report lines.
    out: list[str] = []
    by_block_or_none: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    for fname, key, param, target in missing:
        by_block_or_none[target or f"NO_BLOCK_FOR_{param}"].append((fname, key, param))
    for block_or_tag, items in sorted(by_block_or_none.items()):
        out.append(f"  {block_or_tag}: {len(items)} unresolved reference(s)")
        # Show distinct keys with one example script each.
        by_key: dict[str, str] = {}
        for fname, key, _ in items:
            by_key.setdefault(key, fname)
        for key, fname in sorted(by_key.items()):
            out.append(f"      key {key!r:38s} — example: {fname}")
    return out, ok_count, len(missing)


def print_config_report(
    insertions: list[ConfigInsertion], warnings: list[str], overwrite: bool
) -> None:
    inserts = [i for i in insertions if i.key not in i.block.existing_keys]
    over = [i for i in insertions if i.key in i.block.existing_keys]
    print(f"\n── canc_config.py changes planned ──")
    print(f"  inserts : {len(inserts)} new key(s) across {len({i.block.name for i in inserts})} block(s)")
    if overwrite:
        print(f"  overwrite: {len(over)} existing key(s)")
    else:
        print(f"  existing keys skipped (use --overwrite-config to update): {len(over)}")
    by_block: dict[str, list[ConfigInsertion]] = defaultdict(list)
    for i in insertions:
        by_block[i.block.name].append(i)
    for name in sorted(by_block.keys()):
        bins = by_block[name]
        block = bins[0].block
        print(f"\n  {name}  (EDR_Parameter={block.edr_parameter!r}, "
              f"Factor={block.factor}, Offset={block.offset}, bit_width={block.bit_width})")
        for i in bins:
            kind = "OVERWRITE" if i.key in block.existing_keys else "INSERT   "
            shown = i.value_literal
            if len(shown) > 110:
                shown = shown[:107] + "..."
            print(f"    {kind} {i.key:32s} = {shown}")
    if warnings:
        print("\nWarnings:")
        for w in warnings:
            print(w)


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", default=DEFAULT_CSV, help="Path to edr_testcase_arrays.csv")
    ap.add_argument("--scripts", default=DEFAULT_SCRIPTS, help="Path to EDR scripts folder")
    ap.add_argument("--config", default=DEFAULT_CONFIG, help="Path to canc_config.py")
    ap.add_argument("--apply", action="store_true",
                    help="Actually write changes (otherwise dry-run only).")
    ap.add_argument("--overwrite-config", action="store_true",
                    help="Also update existing TestCase_* keys in canc_config.py "
                         "(default: only insert missing keys).")
    ap.add_argument("--only-scripts", action="store_true",
                    help="Skip the canc_config pass entirely.")
    ap.add_argument("--only-config", action="store_true",
                    help="Skip the scripts pass entirely.")
    args = ap.parse_args()

    csv_path = Path(args.csv)
    scripts_dir = Path(args.scripts)
    config_path = Path(args.config)

    for label, p in [("CSV", csv_path), ("scripts dir", scripts_dir), ("config", config_path)]:
        if not p.exists():
            print(f"ERROR: {label} not found: {p}", file=sys.stderr)
            return 2

    print(f"CSV    : {csv_path}")
    print(f"Scripts: {scripts_dir}")
    print(f"Config : {config_path}")
    print(f"Mode   : {'APPLY' if args.apply else 'dry-run'}"
          f"{'  (overwrite-config ON)' if args.overwrite_config else ''}")

    rows = load_csv(csv_path)
    summaries = summarize_per_param(rows)
    print(f"\nLoaded {len(rows)} CSV rows covering {len(summaries)} parameter indices.")

    # Pass 1: scripts
    script_edits: list[ScriptEdit] = []
    script_warnings: list[str] = []
    if not args.only_config:
        script_edits, script_warnings = plan_script_edits(scripts_dir)
        print_script_report(script_edits, script_warnings)

    # Pass 2: config
    config_insertions: list[ConfigInsertion] = []
    config_warnings: list[str] = []
    blocks: list[ConfigBlock] = []
    if not args.only_scripts:
        _, blocks = parse_config(config_path)
        print(f"\nParsed {len(blocks)} CAN_<PARAM> blocks from canc_config.py.")
        config_insertions, config_warnings = plan_config_insertions(
            blocks, summaries, args.overwrite_config
        )
        print_config_report(config_insertions, config_warnings, args.overwrite_config)

    # Pass 3: post-state naming-alignment check.
    if blocks and not args.only_config:
        misalign_lines, ok_count, miss_count = verify_alignment(
            scripts_dir, blocks, script_edits, config_insertions
        )
        print(f"\n── Naming alignment check (post-state) ──")
        print(f"  Script-side key references that WILL resolve in canc_config: {ok_count}")
        print(f"  Script-side key references that will NOT resolve            : {miss_count}"
              + ("  — fully aligned." if miss_count == 0 else ""))
        if misalign_lines:
            print()
            print("  Unresolved references:")
            for line in misalign_lines:
                print(line)

    if not args.apply:
        print("\nDry-run only. Re-run with --apply to write changes.")
        return 0

    # Apply
    n_scripts_changed = 0
    n_config_changes = 0
    if script_edits:
        n_scripts_changed = apply_script_edits(script_edits)
        print(f"\nApplied script edits → {n_scripts_changed} file(s) updated "
              f"(backups: *.py.bak).")
    if config_insertions:
        n_config_changes = apply_config_insertions(
            config_path, config_insertions, args.overwrite_config
        )
        print(f"Applied config changes → {n_config_changes} key(s) "
              f"(backup: {config_path.name}.bak).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
