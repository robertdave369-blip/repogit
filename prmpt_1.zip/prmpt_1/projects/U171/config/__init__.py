"""Configuration package for U171.

Contains project_config.py and ALL module configs.
"""
