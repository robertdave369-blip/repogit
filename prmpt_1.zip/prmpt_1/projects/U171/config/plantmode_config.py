"""
Module Configuration: PlantMode
Project: U171
============================================================

Location: projects/U171/config/plantmode_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is PlantMode
    ctx.get_module_config("PlantMode").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "PlantMode"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── PlantMode Settings ──
PLANT_MODE_DID = 0xF1E0
PLANT_MODE_STATUS_DID = 0xF1E1

PLANT_MODE_STATES = {
    0x00: "Normal",
    0x01: "PlantMode_Active",
    0x02: "PlantMode_Locked",
}

ENTRY_CONDITIONS = {
    "ignition": "ON",
    "vehicle_speed_kmh": 0,
    "engine_running": False,
}

EXIT_CONDITIONS = {
    "security_access": True,
    "correct_sequence": True,
}

DISABLED_FEATURES_IN_PLANT_MODE = [
    "airbag_deployment",
    "seatbelt_pretensioner",
    "ecall_automatic",
]

PLANT_MODE_TIMEOUT = 120
