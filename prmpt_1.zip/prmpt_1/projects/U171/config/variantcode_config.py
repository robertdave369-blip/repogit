"""
Module Configuration: VARIANTCODE
Project: U171
============================================================

Location: projects/U171/config/variantcode_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is VARIANTCODE
    ctx.get_module_config("VARIANTCODE").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "VARIANTCODE"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── VARIANTCODE Settings ──
VARIANT_DID = 0xF1A0

VARIANT_CODES = {
    0x01: "Base",
    0x02: "Mid",
    0x03: "High",
    0x04: "Premium",
}

REGION_CODES = {
    0x01: "NAR",
    0x02: "EUR",
    0x03: "CHN",
    0x04: "KOR",
    0x05: "JPN",
}
