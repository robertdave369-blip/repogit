"""
Module Configuration: GPO
Project: U171
============================================================

Location: projects/U171/config/gpo_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is GPO
    ctx.get_module_config("GPO").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "GPO"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── GPO Settings ──
TEST_SIGNALS = [
    "GPO_OutputChannel_1",
    "GPO_OutputChannel_2",
    "GPO_OutputChannel_3",
    "GPO_OutputChannel_4",
]

EXPECTED_OUTPUT_VOLTAGE = 12.0
VOLTAGE_TOLERANCE = 0.5
OUTPUT_HIGH_THRESHOLD = 10.0
OUTPUT_LOW_THRESHOLD = 2.0

ACTIVATION_DELAY = 0.1
DEACTIVATION_DELAY = 0.05

GPO_STATUS_DID = 0x0500
GPO_CONFIG_DID = 0x0501

FAULT_CODES = {
    "GPO_SHORT_TO_GROUND":  "C1001",
    "GPO_SHORT_TO_BATTERY": "C1002",
    "GPO_OPEN_LOAD":        "C1003",
}
