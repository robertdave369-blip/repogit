"""
Module Configuration: CAND
Project: U171
============================================================

Location: projects/U171/config/cand_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is CAND
    ctx.get_module_config("CAND").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "CAND"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CAND Settings ──
DIAG_REQUEST_IDS = [0x641, 0x7DF]
DIAG_RESPONSE_IDS = [0x642]
SUPPORTED_SERVICES = [0x10, 0x11, 0x14, 0x19, 0x22, 0x2E, 0x31, 0x3E]
