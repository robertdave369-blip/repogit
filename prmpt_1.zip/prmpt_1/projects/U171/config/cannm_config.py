"""
Module Configuration: CANNM
Project: U171
============================================================

Location: projects/U171/config/cannm_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is CANNM
    ctx.get_module_config("CANNM").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "CANNM"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CANNM Settings ──
NM_CHANNEL = 0
NM_BASE_ID = 0x500
NM_REPEAT_MESSAGE_TIME = 1.5
NM_WAIT_BUS_SLEEP_TIME = 5.0
NM_TIMEOUT_TIME = 6.0
