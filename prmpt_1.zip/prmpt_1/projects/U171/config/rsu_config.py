"""
Module Configuration: RSU
Project: U171
============================================================

Location: projects/U171/config/rsu_config.py

All RSU sensor metadata (channel mapping, sensitivity, ECU port resolution,
UDS DID) and the helpers needed for the Sensor_Recording test cases live in
this file. The SUBS_EDR_Sensor_Recording_TestCase_*.py scripts read from
here. No external library dependency: pure stdlib only.

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is RSU
    ctx.get_module_config("RSU").<SETTING>    # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "RSU"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1


# ── Sensor → RSU channel mapping ────────────────────────────────────────────
# Names on the right MUST match keys used by crash_configuration.U171_CRASH_CURVE_CONFIG
# (so that curve_path_for_channel() can find the .txt curve Aria played).
# Channels not yet wired on U171 can be commented out; the test scripts skip
# any sensor with missing metadata.
SENSOR_TO_RSU_CHANNEL = {
    "CTx":              "CTx",              # SPI (central X)
    "CTy":              "CTy",              # SPI (central Y)
    "FRSU_Left_X":      "RSU_CH9",
    "FRSU_Right_X":     "RSU_CH11",
    "Rear_RSU_X":       "RSU_CH13",
    "B_Pillar_Left_X":  "RSU_CH2",
    "B_Pillar_Left_Y":  "RSU_CH1",
    "B_Pillar_Right_X": "RSU_CH4",
    "B_Pillar_Right_Y": "RSU_CH3",
    "C_Pillar_Left_X":  "RSU_CH6",
    "C_Pillar_Left_Y":  "RSU_CH5",
    "C_Pillar_Right_X": "RSU_CH8",
    "C_Pillar_Right_Y": "RSU_CH7",
}


# ── Sensitivity (LSB → G for the Aria input curve) ─────────────────────────
SENSOR_SENSITIVITY = {
    "CTx":              0.06253,
    "CTy":              0.03127,
    "FRSU_Left_X":      0.5000,
    "FRSU_Right_X":     0.5000,
    "Rear_RSU_X":       0.5000,
    "B_Pillar_Left_X":  0.2500,
    "B_Pillar_Left_Y":  0.5000,
    "B_Pillar_Right_X": 0.2500,
    "B_Pillar_Right_Y": 0.5000,
    "C_Pillar_Left_X":  0.2500,
    "C_Pillar_Left_Y":  0.5000,
    "C_Pillar_Right_X": 0.2500,
    "C_Pillar_Right_Y": 0.5000,
}


# ── Port resolution (LSB → G for the ECU DID response) ─────────────────────
SENSOR_PORT_RES = {
    "CTx":              0.015633,
    "CTy":              0.015633,
    "FRSU_Left_X":      0.0078125,
    "FRSU_Right_X":     0.0078125,
    "Rear_RSU_X":       0.0078125,
    "B_Pillar_Left_X":  0.00390625,
    "B_Pillar_Left_Y":  0.0078125,
    "B_Pillar_Right_X": 0.00390625,
    "B_Pillar_Right_Y": 0.0078125,
    "C_Pillar_Left_X":  0.00390625,
    "C_Pillar_Left_Y":  0.0078125,
    "C_Pillar_Right_X": 0.00390625,
    "C_Pillar_Right_Y": 0.0078125,
}


# ── UDS Data Identifiers per sensor: EDR1 / EDR2 ───────────────────────────
# Values taken from the Sensor_Recording test specification. Update these
# if the ECU DID assignment changes.
SENSOR_DID_EDR1 = {
    "CTx":              "0x0460",
    "CTy":              "0x045F",
    "FRSU_Left_X":      "0x0463",
    "FRSU_Right_X":     "0x0464",
    "Rear_RSU_X":       "0x0481",
    "B_Pillar_Left_X":  "0x049F",
    "B_Pillar_Left_Y":  "0x0461",
    "B_Pillar_Right_X": "0x04A0",
    "B_Pillar_Right_Y": "0x0462",
    "C_Pillar_Left_X":  "0x0488",
    "C_Pillar_Left_Y":  "0x047B",
    "C_Pillar_Right_X": "0x0487",
    "C_Pillar_Right_Y": "0x047A",
}
SENSOR_DID_EDR2 = {
    "CTx":              "0x0468",
    "CTy":              "0x0467",
    "FRSU_Left_X":      "0x046B",
    "FRSU_Right_X":     "0x046C",
    "Rear_RSU_X":       "0x0484",
    "B_Pillar_Left_X":  "0x04A1",
    "B_Pillar_Left_Y":  "0x0469",
    "B_Pillar_Right_X": "0x04A2",
    "B_Pillar_Right_Y": "0x046A",
    "C_Pillar_Left_X":  "0x0492",
    "C_Pillar_Left_Y":  "0x047D",
    "C_Pillar_Right_X": "0x0491",
    "C_Pillar_Right_Y": "0x047C",
}


# ── Per-crash-type sensor group + expected polarity ────────────────────────
# polarity:
#   "negative" → first non-zero decoded G must be < 0
#   "positive" → first non-zero decoded G must be > 0
CRASH_SENSOR_GROUPS = {
    "front": {
        "sensors":   ["CTx", "FRSU_Left_X", "FRSU_Right_X"],
        "polarity":  "negative",
        "dtc_label": "Front Crash",
    },
    "rear": {
        "sensors":   ["CTx", "Rear_RSU_X"],
        "polarity":  "positive",
        "dtc_label": "Rear Crash",
    },
    "left": {
        "sensors":   ["CTy", "B_Pillar_Left_X", "B_Pillar_Left_Y",
                      "C_Pillar_Left_X", "C_Pillar_Left_Y"],
        "polarity":  "negative",
        "dtc_label": "Left Crash",
    },
    "right": {
        "sensors":   ["CTy", "B_Pillar_Right_X", "B_Pillar_Right_Y",
                      "C_Pillar_Right_X", "C_Pillar_Right_Y"],
        "polarity":  "positive",
        "dtc_label": "Right Crash",
    },
}


# Tolerance for input G vs decoded G comparison (G units).
RSU_DECODE_TOLERANCE_G = 0.05

# Expected "empty EDR" byte (every payload byte equals this when not populated).
EDR_EMPTY_BYTE = "0xFF"

# Expected "forced-zero other RSU" byte (used by TC 5–8).
EDR_FORCED_ZERO_BYTE = "0x7F"


# ── DeltaV EDR (used by the EDR_Element_IDs_Deltav* test cases) ─────────────
# The crash DeltaV record is read from EDR1 DID 0x0455 and EDR2 DID 0x045B
# (read with L1 security). DeltaV samples are recorded every 10 ms.
DELTAV_EDR1_DID = "0x0455"
DELTAV_EDR2_DID = "0x045B"
DELTAV_SAMPLE_INTERVAL_MS = 10
DELTAV_THRESHOLD_KMPH = 8          # |DeltaVx| threshold called out in the spec
DELTAV_PARAMETERS = [
    "DeltaVLgt",
    "DeltaVLat",
    "TimeMaxDeltaVLgt",
    "TimeMaxDeltaVLat",
    "MaxDeltaVLgt",
    "MaxDeltaVLat",
]


# ── RSU fault types (used by the TC_EDR_*_Negative_OtherRSU_* test cases) ───
# Each fault is injected on the "other" RSUs (those not part of the active
# crash group). After the crash, those faulted RSUs must read all-0xFF in EDR.
# `dtc_label` is what Read_DTC reports; confirm the exact DTC code per fault
# from the ECU spec and fill RSU_FAULT_DTC below if you want exact matching.
RSU_FAULT_TYPES = {
    "OpenFault":     "Open circuit fault on the RSU line",
    "S2B":           "Short-to-battery fault on the RSU line",
    "S2G":           "Short-to-ground fault on the RSU line",
    "InternalFault": "RSU internal/self-test fault",
    "CommFault":     "RSU communication fault",
    "ConfigFault":   "RSU configuration mismatch fault",
    "OutOfRange":    "RSU signal out-of-range fault",
}
# Optional exact DTCs per fault type (fill from spec; left blank = label only).
RSU_FAULT_DTC = {
    # "OpenFault": "0xXX 0xXX 0x00",
}


# ── Full-EDR read DID (individual-parameter test cases) ────────────────────
# SUBS_EDR_Element_ID_* read the whole EDR record (DID 0x0455) with L1 security
# and verify one named parameter. read_edr_parameters() handles the decode; the
# DID below is passed through to it.
EDR_FULL_READ_DID = "0455"
EDR_L1_SECURITY_LEVEL = 0x01


# ── Generic RSU/Hi-G DID readout (edr_decoding_functions.read_all_rsu_dids) ──
# read_all_rsu_dids() / read_rsu_did() in shared_libraries/edr_decoding_functions.py
# are project-agnostic; they read the two symbols below from THIS file via the
# project_config_loader. To support a new project, drop the same two symbols
# into that project's rsu_config.py.
#
# RSU_DID_MAP: one entry per sensor with its EDR1/EDR2 DID and the decode
# "sensor_type" (selects the scale in RSU_DECODE_CONVENTION). Pre-populated from
# SENSOR_DID_EDR1/EDR2; set "sensor_type" per the ECU spec ("rsu", "hig_x", ...).
RSU_DID_MAP = {
    name: {
        "edr1": SENSOR_DID_EDR1.get(name),
        "edr2": SENSOR_DID_EDR2.get(name),
        "sensor_type": "rsu",
    }
    for name in SENSOR_TO_RSU_CHANNEL
}

# Decode convention for the 8-bit offset-binary RSU DID payload:
#   each payload byte is offset-binary around `center`; `zero_byte` decodes to 0;
#   the per-sensor-type `scale` is applied: physical = (byte - center) * scale.
RSU_DECODE_CONVENTION = {
    "zero_byte": 0x7F,
    "center": 127,
    "scale": {"rsu": 2, "hig_x": 1, "hig_y": 1},
    "default_scale": 1,
}


# ── Sampling: input curve interval vs EDR RSU recording interval (PROJECT) ──
# Express both as INTERVALS in MICROSECONDS — this is the per-project knob.
# The OUTPUT-DUPLICATION FACTOR (how many high-rate input samples map to one
# EDR output sample) is:
#
#   factor = round(EDR_RSU_RECORDING_INTERVAL_US / RSU_INPUT_INTERVAL_US)
#
# Comparison is done at the INPUT (high) resolution: every decoded EDR output
# value is duplicated `factor` times so the lower-rate output lines up with the
# full-resolution input curve. e.g. factor 4:
#       output  [20, 28, 34]
#       becomes [20,20,20,20, 28,28,28,28, 34,34,34,34]
#
# U171: input curve = 500 µs/sample, EDR RSU recording = 2000 µs/sample → 4.
# A project that records RSU at a coarser interval just sets a larger value,
# e.g. EDR_RSU_RECORDING_INTERVAL_US = 500000 for a 500 ms recording, or
# = 1000 for a 1 ms recording. Nothing else needs to change.
RSU_INPUT_INTERVAL_US = 500            # input curve: one sample per 500 µs
EDR_RSU_RECORDING_INTERVAL_US = 2000   # EDR records one RSU sample per 2000 µs

# Optional per-sensor interval override: sensor -> (input_us, edr_us).
SENSOR_SAMPLE_INTERVALS_US = {
    # "CTx": (500, 2000),
}

# ── Legacy rate aliases (kept so any external reference still resolves) ─────
# Derived from the intervals above — edit the *_INTERVAL_US values, not these.
RSU_INPUT_SAMPLE_RATE_HZ = (
    int(round(1_000_000 / RSU_INPUT_INTERVAL_US)) if RSU_INPUT_INTERVAL_US else 0
)
EDR_RSU_RECORDING_RATE_HZ = (
    int(round(1_000_000 / EDR_RSU_RECORDING_INTERVAL_US)) if EDR_RSU_RECORDING_INTERVAL_US else 0
)
# Legacy per-sensor rate override (sensor -> (input_hz, edr_hz)); still honored.
SENSOR_SAMPLE_RATES_HZ = {
    # "CTx": (2000, 500),
}


def output_duplication_factor(sensor: "str | None" = None) -> int:
    """How many times each decoded EDR output sample is duplicated to line up
    with the higher-resolution input curve, for `sensor`.

        factor = round(EDR recording interval / input interval)
               = round(input_hz / edr_hz)

    Precedence: per-sensor interval override → per-sensor rate override →
    project-wide interval → project-wide rate. Always >= 1 (never upsamples;
    if the EDR recording is not coarser than the input, the factor is 1).
    This signature/return is unchanged from before — callers are unaffected."""
    # 1. Per-sensor interval override (µs)
    iv = SENSOR_SAMPLE_INTERVALS_US.get(sensor) if sensor else None
    if iv:
        in_us, edr_us = iv
        if in_us and edr_us and edr_us > in_us:
            return max(1, int(round(edr_us / in_us)))
        return 1
    # 2. Per-sensor rate override (Hz, legacy)
    rt = SENSOR_SAMPLE_RATES_HZ.get(sensor) if sensor else None
    if rt:
        in_hz, edr_hz = rt
        if in_hz and edr_hz and in_hz > edr_hz:
            return max(1, int(round(in_hz / edr_hz)))
        return 1
    # 3. Project-wide interval (µs) — primary knob; AUTHORITATIVE when set
    #    (does not fall through to rates, so equal intervals correctly give 1).
    if RSU_INPUT_INTERVAL_US and EDR_RSU_RECORDING_INTERVAL_US:
        if EDR_RSU_RECORDING_INTERVAL_US > RSU_INPUT_INTERVAL_US:
            return max(1, int(round(EDR_RSU_RECORDING_INTERVAL_US / RSU_INPUT_INTERVAL_US)))
        return 1
    # 4. Project-wide rate (Hz, back-compat) — only when intervals are unset
    if (RSU_INPUT_SAMPLE_RATE_HZ and EDR_RSU_RECORDING_RATE_HZ
            and RSU_INPUT_SAMPLE_RATE_HZ > EDR_RSU_RECORDING_RATE_HZ):
        return max(1, int(round(RSU_INPUT_SAMPLE_RATE_HZ / EDR_RSU_RECORDING_RATE_HZ)))
    return 1


# ── Helpers (pure stdlib) ──────────────────────────────────────────────────
def build_read_did_request(did_str: str) -> str:
    """'0x0460' or '0x0460/0x0468' → '0x22 0x04 0x60'.
    Uses the first DID when a slash-separated pair is given (EDR1 response DID).
    """
    s = str(did_str).split("/")[0].strip()
    if s.lower().startswith("0x"):
        s = s[2:]
    s = s.zfill(4)
    return "0x22 0x{} 0x{}".format(s[:2], s[2:])


def lsb_curve_from_file(path: str) -> list:
    """Read a single-column LSB curve into a list[float]. Returns [] on any
    failure so callers can record the gap and move on (rather than crashing
    a whole test run because one curve path is unreachable)."""
    try:
        out = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                # Take the first numeric token on the line (curves are 1-column).
                try:
                    out.append(float(line.split()[0]))
                except ValueError:
                    continue
        return out
    except Exception:
        return []


def input_g_from_lsb(lsb_values, sensitivity):
    """Input curve LSB → G at FULL input resolution (no sampling/decimation).
    Comparison happens at this high resolution; the EDR output is duplicated
    up to match (see expand_decoded_to_input_rate)."""
    return [v * sensitivity for v in lsb_values]


def expand_decoded_to_input_rate(decoded_g, factor: "int | None" = None,
                                 sensor: "str | None" = None):
    """Duplicate each decoded EDR output value `factor` times so the lower-rate
    EDR output lines up with the full-resolution input curve.

        factor 4:  [20, 28, 34]  ->  [20,20,20,20, 28,28,28,28, 34,34,34,34]

    `factor` defaults to output_duplication_factor(sensor). A factor of 1 (input
    and EDR already at the same rate) returns the list unchanged."""
    if factor is None:
        factor = output_duplication_factor(sensor)
    if factor <= 1:
        return list(decoded_g)
    out = []
    for v in decoded_g:
        out.extend([v] * factor)
    return out


def decode_uds_response_to_g(response_str: str, port_resolution: float) -> list:
    """Parse a SendDiagByValues response string and return decoded G values.

    A typical response looks like:
        '0x62 0x04 0x60 0xAB 0xCD 0xAB 0xCC ...'
    The first 3 bytes are response-SID + 2-byte DID; the remainder is a
    sequence of signed 16-bit big-endian samples that we scale by
    `port_resolution`.
    """
    tokens = [t for t in str(response_str).strip().split() if t]
    cleaned = []
    for t in tokens:
        t = t.replace("0x", "").replace("0X", "")
        if t:
            cleaned.append(t)
    if len(cleaned) < 3:
        return []
    out = []
    for i in range(3, len(cleaned), 2):
        if i + 1 >= len(cleaned):
            break
        try:
            val = int(cleaned[i] + cleaned[i + 1], 16)
        except ValueError:
            continue
        if val >= 0x8000:
            val -= 0x10000
        out.append(val * port_resolution)
    return out


def curve_path_for_channel(crash_curve_config: dict, crash_type: str, rsu_channel: str):
    """Look up the .txt curve file Aria played on `rsu_channel` for `crash_type`.
    Returns None if not configured. Strips the inversion flag from (path, bool)."""
    spec = (
        crash_curve_config.get(crash_type, {})
        .get("RSU", {})
        .get(rsu_channel)
    )
    if spec is None:
        return None
    if isinstance(spec, tuple):
        return spec[0]
    return spec


def did_response_payload_tokens(response_str: str) -> list:
    """Return only the payload bytes (everything after response-SID + 2-byte DID).
    Used by EDR-emptiness checks ('all 0xFF' or 'all 0x7F')."""
    tokens = [t for t in str(response_str).strip().split() if t]
    return tokens[3:] if len(tokens) > 3 else []


# ── Legacy aliases (do not remove — older scripts in the repo still read these)
SENSOR_CHANNELS = {
    "FRONT_LEFT":  0,
    "FRONT_RIGHT": 1,
    "SIDE_LEFT":   2,
    "SIDE_RIGHT":  3,
    "REAR":        4,
    "ROLLOVER":    5,
}
