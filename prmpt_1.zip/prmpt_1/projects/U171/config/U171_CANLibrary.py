# U171 Project CAN Rx Mapping
CAN_SIGNAL_Rx_MAP = {
    "U171": {
        "TESTER_PHYSICAL_REQ_PCU": ("TESTER_PHYSICAL_REQ_PCU", "TESTER_PHYSICAL_REQ_PCU"),
        "REAR_SEAT_BELT_FAULTY_STS": ("SRS_TEST1", "REAR_SEAT_BELT_FAULTY_STS"),
        "SEAT_OCCUPANT_FAULTY_STS": ("SRS_TEST1", "SEAT_OCCUPANT_FAULTY_STS"),

        "RESERVED_SRS": ("SRS_ACTIVE", "RESERVED_SRS"),

        "PSGR_REAR_SEAT_BELT": ("SRS2_100", "PSGR_REAR_SEAT_BELT"),
        "SEAT_OCCUPANT_STS": ("SRS2_100", "SEAT_OCCUPANT_STS"),

        "DIAG_SRS_RES_DATA": ("SRS_DIAG_RES", "DIAG_SRS_RES_DATA"),

        "INDC_SRS": ("SRS1_20", "INDC_SRS"),
        "DOOR_UNLOCK": ("SRS1_20", "DOOR_UNLOCK"),
        "STS_CRASH": ("SRS1_20", "STS_CRASH"),
        "INDC_PADL": ("SRS1_20", "INDC_PADL"),
        "SRS_RESERVE1": ("SRS1_20", "SRS_RESERVE1"),
        "EVEN_PARITY_BIT": ("SRS1_20", "EVEN_PARITY_BIT"),
        "SRS_RESERVE2": ("SRS1_20", "SRS_RESERVE2"),
        "STS_SEAT_BLT_DRV": ("SRS1_20", "STS_SEAT_BLT_DRV"),
        "STS_SEAT_BLT_PSGR": ("SRS1_20", "STS_SEAT_BLT_PSGR"),
        "CRASH_LOCATION": ("SRS1_20", "CRASH_LOCATION"),
        "IGN_STS_SRS": ("SRS1_20", "IGN_STS_SRS"),
        "NEAR_CRASH": ("SRS1_20", "NEAR_CRASH"),
        "SRS_OPERATION_MODE": ("SRS1_20", "SRS_OPERATION_MODE"),
        "SCM_CNT": ("SRS1_20", "SCM_CNT"),
        "SRS_MSG_CNT": ("SRS1_20", "SRS_MSG_CNT"),
        "SRS_CRC": ("SRS1_20", "SRS_CRC"),

        "AEB_WARNING_MSG1": ("HPCAd_33_50", "AEB_WARNING_MSG1"),
        "NP_SYS_STS1": ("HPCAd_33_50", "NP_SYS_STS1"),
        "AES_SYS_STS1": ("HPCAd_33_50", "AES_SYS_STS1"),
        "AES_WARNING1": ("HPCAd_33_50", "AES_WARNING1"),
        "AEB_FCTA_WARN": ("HPCAd_33_50", "AEB_FCTA_WARN1"),
        "ESA_SYS_STS1": ("HPCAd_33_50", "ESA_SYS_STS1"),
        "ELK_ONCOMING_WARNING1": ("HPCAd_33_50", "ELK_ONCOMING_WARNING1"),
        "LDW_LKA_WARNING1": ("HPCAd_33_50", "LDW_LKA_WARNING1"),
        "ELK_OVERTAKING_WARNING1": ("HPCAd_33_50", "ELK_OVERTAKING_WARNING1"),
        "ELK_SIDE_WARNING1": ("HPCAd_33_50", "ELK_SIDE_WARNING1"),
        "LKA_HANDSOFF_DISPLAY_WARNING1": ("HPCAd_33_50", "LKA_HANDSOFF_DISPLAY_WARNING1"),
        "LC_PATH_STATE1": ("HPCAd_33_50", "LC_PATH_STATE1"),
        "LCF_SYS_STATE1": ("HPCAd_33_50", "LCF_SYS_STATE1"),
        "SPA_LCF_HANDS_OFF_WARNING1": ("HPCAd_33_50", "SPA_LCF_HANDS_OFF_WARNING1"),
        "LDW_LKA_SYS_STATE1": ("HPCAd_33_50", "LDW_LKA_SYS_STATE1"),
        "SPA_SYS_STATE1": ("HPCAd_33_50", "SPA_SYS_STATE1"),
        "RMS_MODE_STATE1": ("HPCAd_33_50", "RMS_MODE_STATE1"),

        "ADAS_Des_StrWhl_Angle_Cmd": ("HPCAd_31_10", "ADAS_DES_STRWHL_ANGLE_CMD1"),

        "ACC_SYS_STATE": ("FRM2_20", "ACC_SYS_STATE"),

        "Tyre_Pressure_FL": ("MBFM6_100", "FL_TYRE_PRESSURE"),
        "Tyre_Pressure_FR": ("MBFM6_100", "FR_TYRE_PRESSURE"),
        "Tyre_Pressure_RL": ("MBFM6_100", "RL_TYRE_PRESSURE"),
        "Tyre_Pressure_RR": ("MBFM6_100", "RR_TYRE_PRESSURE"),

        "FL_TYRE_TEMP": ("MBFM6_100", "FL_TYRE_TEMP"),
        "FR_TYRE_TEMP": ("MBFM6_100", "FR_TYRE_TEMP"),
        "RL_TYRE_TEMP": ("MBFM6_100", "RL_TYRE_TEMP"),
        "RR_TYRE_TEMP": ("MBFM6_100", "RR_TYRE_TEMP"),

        "Door Lock Status": ("MBFM5_100", "STS_DOOR_LATCH"),
        "STS_TPMS_LED": ("MBFM5_100", "STS_TPMS_LED"),

        "MBFM_WAKEUP_REASON": ("MBFM_WAKEUP", "MBFM_WAKEUP_REASON"),
        "MBFM_SLEEP_RESERVED_2": ("MBFM_SLEEP", "RESERVED_2"),
        "MBFM_ACTIVE_RESERVED_2": ("MBFM_ACTIVE", "RESERVED_2"),
        "RESERVED_2": ("MBFM_SLEEP", "RESERVED_2"),
        "BattVolt": ("MBFM7_100", "BATT_VOLT"),
        "DoorsOpenStatus": ("MBFM1_100", "STS_DOOR"),
        "STS_HIGH_BEAM": ("MBFM1_100", "STS_HIGH_BEAM"),
        "STS_LOW_BEAM": ("MBFM1_100", "STS_LOW_BEAM"),

        "VehSpdLgt": ("ESC12_10", "VEHICLE_SPEED_ESC12"),
        "VehSpdLgtAtTimeZero": ("ESC12_10", "VEHICLE_SPEED_ESC12"),
        "ESC12_MSG_CNT": ("ESC12_10", "ESC12_MSG_CNT"),
        "ESC12_CRC": ("ESC12_10", "ESC12_CRC"),

        "Master_Cylinder_Pressure": ("ESC10_20", "MASTER_CYL_PRESSURE"),

        "LATERAL_ACCEL": ("ESC7_20", "LATTERAL_ACCEL"),
        "LONG_ACCEL": ("ESC7_20", "LONG_ACCEL"),
        "YAW_RATE": ("ESC7_20", "YAW_RATE"),
        "ESC7_MSG_CNT": ("ESC7_20", "ESC7_MSG_CNT"),
        "ESC7_CRC": ("ESC7_20", "ESC7_CRC"),

        "ESC_ACTIVE": ("ESC5_10", "ESC_ACTIVE"),
        "ABS_ACTIVE": ("ESC5_10", "ABS_ACTIVE"),
        "ESC5_MSG_CNT": ("ESC5_10", "ESC5_MSG_CNT"),
        "ESC5_CRC": ("ESC5_10", "ESC5_CRC"),

        "TCS_ACTIVE_IEB": ("ESC2_10", "TCS_ACTIVE"),

        "ACC_PED": ("EMS36_10", "ACC_PED1"),
        "Engine_Speed": ("EMS36_10", "ENG_SPD1"),
        "EMS36_MSG_CNT": ("EMS36_10", "EMS36_MSG_CNT"),
        "EMS36_CRC": ("EMS36_10", "EMS36_CRC"),

        "BRAKE_PEDAL_VALUE": ("EMS21_10", "BRK_PEDAL1"),
        "EMS21_MSG_CNT": ("EMS21_10", "EMS21_MSG_CNT"),
        "EMS21_CRC": ("EMS21_10", "EMS21_CRC"),

        "CLUTCH_STS": ("EMS3_10", "CLUTCH_STS"),

        "DISP_AMBT_TEMP_EMS": ("EMS6_500", "DISP_AMBT_TEMP_EMS"),

        "VIN_DATA_2": ("EMS5_500", "VIN_DATA_2"),
        "VIN_DATA_1": ("EMS5_500", "VIN_DATA_1"),
        "VIN_DATA_0": ("EMS5_500", "VIN_DATA_0"),
        "VIN_INDEX": ("EMS5_500", "VIN_INDEX"),

        "INDC_CRUISE": ("EMS1_10", "INDC_CRUISE"),
        "CURRENT_GEAR_MT": ("EMS1_10", "CURRENT_GEAR_MT"),
        "STS_ENG": ("EMS1_10", "STS_ENG"),

        "EventDtYear": ("IS3_500", "CLOCK_YEAR"),
        "EventDt_Month": ("IS3_500", "CLOCK_MONTH"),
        "CLOCK_FORMAT": ("IS3_500", "CLOCK_FORMAT"),
        "EventDt": ("IS3_500", "CLOCK_DATE"),
        "EventTime": ("IS3_500", "CLOCK_HOUR"),
        "CLOCK_MIN": ("IS3_500", "CLOCK_MIN"),

        "DRL_EN_SW": ("IS1_100", "DRL_EN_SW"),

        "Odometer": ("IC2_100", "ODOMTR_READING"),
        "CuttoffSwitchFPsngr": ("IC2_100", "PSGR_AIRBAG_SW_IC"),

        "STEERING_ABSOLUTE_ANGLE": ("EPS_SAS1_10", "ABSOLUTE_ANGLE"),
        "SAS_MSG_CNT": ("EPS_SAS1_10", "SAS_MSG_CNT"),
        "SAS_CRC": ("EPS_SAS1_10", "SAS_CRC"),

        "GEAR_ACTUAL": ("TCU5_10", "GEAR_ACTUAL"),

        "DIAG_GLOBAL_REQ_DATA": ("GLOBAL_DIAG_REQ", "DIAG_GLOBAL_REQ_DATA"),
        "DIAG_SRS_REQ_DATA": ("SRS_DIAG_REQ", "DIAG_SRS_REQ_DATA"),
    }
}
# Warning lamp signal values for INDC_SRS (SRS1_20)
Signal_Value_2C0 = {
    "ON": "0x01",
    "OFF": "0x00",
}
# Expected CAN signal values for each crash type
CAN_SIGNAL_Rx_EXPECTED_VALUES = {
    "front": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "STS_CRASH_OUTPUT": "0x1",  # 1 = Front Crash
        "DOOR_UNLOCK": "0x1"
    },
    "left": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "STS_CRASH_OUTPUT": "0x3",  # 3 = Left Hand Side
        "DOOR_UNLOCK": "0x1"
    },
    "right": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "STS_CRASH_OUTPUT": "0x2",  # 2 = Right Hand Side
        "DOOR_UNLOCK": "0x1"
    },
    "rear": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "STS_CRASH_OUTPUT": "0x4",  # 4 = Rear Crash
        "DOOR_UNLOCK": "0x1"
    },
    "near": {
        "STS_CRASH": "0x0",
        "INDC_SRS": "0x0",
        "STS_CRASH_OUTPUT": "0x0",
        "DOOR_UNLOCK": "0x0"
    }
}

# Nodebsent DTC's of U171 Project
CAN_NODE_ABSENT_DTC = {
    "HPCAD": "0xD1 0x61 0x00",   # D161 - HPCAd_31_10
    "EMS":   "0xD1 0x01 0x00",   # D101 - EMS KEY MSG (EMS3_10)
    "TCU":   "0xD1 0x02 0x00",   # D102 - TCU KEY MSG (TCU5_10)
    "ESC":   "0xD1 0x03 0x00",   # D103 - ESC KEY MSG (ESC5_10)
    "MBFM":  "0xD1 0x04 0x00",   # D104 - MBFM KEY MSG (MBFM1_100)
    "IC":    "0xD1 0x05 0x00",   # D105 - IC KEY MSG (IC2_100)
    "IS":    "0xD1 0x08 0x00",   # D108 - IS KEY MSG (IS1_100)
    "SAS":   "0xD1 0x10 0x00",   # D110 - SAS KEY MSG (SAS1_10)
    "FRM":   "0xD1 0x4F 0x00",   # D14F - FRM KEY MSG (FRM2_20)
}

# Message Content Failure DTC's of U171 Project
# Add CRC and MSG_CNT signal names here and append the DTC for the respective variant per database.

CAN_MESSAGE_CONTENT_FAILURE_DTC = {
    "EMS21_CRC":      "0xE4 0x71 0x00",   # E471 - EMS21_10 (0x127)
    "EMS21_MSG_CNT":  "0xE4 0x71 0x00",

    "EMS36_CRC":      "0xE4 0xA2 0x00",   # E4A2 - EMS36_10 (0x142)
    "EMS36_MSG_CNT":  "0xE4 0xA2 0x00",

    "IS1_500_CRC":    "0xE4 0x85 0x00",   # E485 - IS1_500 (0x220)
    "IS1_500_MSG_CNT":"0xE4 0x85 0x00",

    "EPS_SAS1_CRC":   "0xE4 0x26 0x00",   # E426 - EPS_SAS1_10 (0x114)
    "EPS_SAS1_MSG_CNT":"0xE4 0x26 0x00",

    "ESC12_CRC":      "0xE4 0xAE 0x00",   # E4AE - ESC12_10 (0x282)
    "ESC12_MSG_CNT":  "0xE4 0xAE 0x00",

    "ESC5_CRC":       "0xE4 0x20 0x00",   # E420 - ESC5_10 (0x10D)
    "ESC5_MSG_CNT":   "0xE4 0x20 0x00",

    "ESC7_CRC":       "0xE4 0x84 0x00",   # E484 - ESC7_20 (0x170)
    "ESC7_MSG_CNT":   "0xE4 0x84 0x00",

    "EMS3_CRC":       "0xE4 0x03 0x00",   # E403 - EMS3_10 (0x142)
    "EMS3_MSG_CNT":   "0xE4 0x03 0x00",
}

# Message Timeout DTCs of U171 Project
CAN_MESSAGE_TIMEOUT_DTC = {
    "EMS":  "0xD0 0x01 0x00",   # D001 - EMS Message Timeout
    "ESC":  "0xD0 0x03 0x00",   # D003 - ESC Message Timeout
    "MBFM": "0xD0 0x04 0x00",   # D004 - MBFM Message Timeout
    "IC":   "0xD0 0x05 0x00",   # D005 - IC Message Timeout
    "IS":   "0xD0 0x08 0x00",   # D008 - IS Message Timeout
}

CAN_MESSAGES = {
    "EMS": "EMS",
    "ESC": "ESC",
    "MBFM": "MBFM",
    "IC": "IC",
    "IS": "IS",
    "VCU": "VCU",
    "FR_ZONE": "FR_ZONE",
    "HPCAD": "HPCAD"
}

# Signal Content Failure DTCs
CAN_SIGNAL_CONTENT_FAILURE_DTC = {
    "ADAS_DES_STRWHL_ANGLE_CMD": "0xE1 0x77 0x00",   # E177
    "FL_TYRE_PRESSURE":          "0xE0 0xD6 0x00",   # E0D6
    "FR_TYRE_PRESSURE":          "0xE0 0xD7 0x00",   # E0D7
    "RL_TYRE_PRESSURE":          "0xE0 0xD8 0x00",   # E0D8
    "RR_TYRE_PRESSURE":          "0xE0 0xD9 0x00",   # E0D9

    "GEAR_ACTUAL":               "0xE1 0x1D 0x00",   # E11D
    "MASTER_CYL_PRESSURE":       "0xE1 0x8D 0x00",   # E18D

    "ODOMTR_READING_IS":         "0xE0 0x12 0x00",   # E012
    "STEERING_ABSOLUTE_ANGLE":   "0xE0 0x58 0x00",   # E058

    "ACC_PED":                  "0xE0 0x01 0x00",   # E001
    "BRK_PEDAL":                "0xE0 0x02 0x00",   # E002
    "ENG_SPD":                  "0xE0 0x04 0x00",   # E004
    "CURRENT_GEAR_MT":           "0xE0 0x03 0x00",   # E003

    "LATTERAL_ACCEL":            "0xE0 0x53 0x00",   # E053
    "LONG_ACCEL":                "0xE0 0x54 0x00",   # E054
    "YAW_RATE":                  "0xE0 0x59 0x00",   # E059

    "DISP_AMBT_TEMP_EMS":        "0xE0 0xBE 0x00",   # E0BE

    "CLUTCH_STS":                "0xE0 0x09 0x00",   # E009
}

# Message Content Failure DTCs
CAN_MESSAGE_CONTENT_FAILURE_DTC = {
    "EMS21":     "0xE4 0x71 0x00",   # E471 - EMS21_10
    "EMS36":     "0xE4 0xA2 0x00",   # E4A2 - EMS36_10
    "IS1_500":   "0xE4 0x85 0x00",   # E485 - IS1_500

    "EPS_SAS1":  "0xE4 0x26 0x00",   # E426 - EPS_SAS1_10
    "ESC12":     "0xE4 0xAE 0x00",   # E4AE - ESC12_10
    "ESC5":      "0xE4 0x20 0x00",   # E420 - ESC5_10
    "ESC7":      "0xE4 0x84 0x00",   # E484 - ESC7_20

    "EMS3":      "0xE4 0x03 0x00",   # E403 - EMS3_10
}

# Unified configuration for all Tx messages, signals, and DTCs

CAN_TX_MESSAGE_CONFIG = {
    "TESTER_PHYSICAL_REQ_PCU": {
        "signals": ["TESTER_PHYSICAL_REQ_PCU"],
        "key_node": "TESTER",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("TESTER"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("TESTER"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "HPCAd_33_50": {
        "signals": [
            "AEB_WARNING_MSG1",
            "NP_SYS_STS1",
            "AES_SYS_STS1",
            "AES_WARNING1",
            "AEB_FCTA_WARN",
            "ESA_SYS_STS1",
            "ELK_ONCOMING_WARNING1",
            "LDW_LKA_WARNING1",
            "ELK_OVERTAKING_WARNING1",
            "ELK_SIDE_WARNING1",
            "LKA_HANDSOFF_DISPLAY_WARNING1",
            "LC_PATH_STATE1",
            "LCF_SYS_STATE1",
            "SPA_LCF_HANDS_OFF_WARNING1",
            "LDW_LKA_SYS_STATE1",
            "SPA_SYS_STATE1",
            "RMS_MODE_STATE1",
        ],
        "key_node": "HPCAD",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "HPCAd_31_10": {
        "signals": ["ADAS_Des_StrWhl_Angle_Cmd"],
        "key_node": "HPCAD",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtcs": {
            "ADAS_Des_StrWhl_Angle_Cmd": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ADAS_DES_STRWHL_ANGLE_CMD"),
        },
        "message_content_failure_dtcs": {}
    },

    "FRM2_20": {
        "signals": ["ACC_SYS_STATE"],
        "key_node": "FRM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("FRM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("FRM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM6_100": {
        "signals": [
            "Tyre_Pressure_FL",
            "Tyre_Pressure_FR",
            "Tyre_Pressure_RL",
            "Tyre_Pressure_RR",
            "FL_TYRE_TEMP",
            "FR_TYRE_TEMP",
            "RL_TYRE_TEMP",
            "RR_TYRE_TEMP",
        ],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {
            "Tyre_Pressure_FL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FL_TYRE_PRESSURE"),
            "Tyre_Pressure_FR": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FR_TYRE_PRESSURE"),
            "Tyre_Pressure_RL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RL_TYRE_PRESSURE"),
            "Tyre_Pressure_RR": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RR_TYRE_PRESSURE"),
        },
        "message_content_failure_dtcs": {}
    },

    "MBFM5_100": {
        "signals": [
            "Door Lock Status",
            "STS_TPMS_LED",
        ],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM_WAKEUP": {
        "signals": ["MBFM_WAKEUP_REASON"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM_SLEEP": {
        "signals": ["MBFM_SLEEP_RESERVED_2"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM_ACTIVE": {
        "signals": ["MBFM_ACTIVE_RESERVED_2"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM7_100": {
        "signals": ["BattVolt"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM1_100": {
        "signals": [
            "DoorsOpenStatus",
            "STS_HIGH_BEAM",
            "STS_LOW_BEAM",
        ],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "ESC12_10": {
        "signals": [
            "VehSpdLgt",
            "VehSpdLgtAtTimeZero",
            "ESC12_MSG_CNT",
            "ESC12_CRC",
        ],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {
            "ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"),
            "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC"),
        }
    },

    "ESC10_20": {
        "signals": ["Master_Cylinder_Pressure"],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {
            "Master_Cylinder_Pressure": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("MASTER_CYL_PRESSURE"),
        },
        "message_content_failure_dtcs": {}
    },

    "ESC7_20": {
        "signals": [
            "LATERAL_ACCEL",
            "LONG_ACCEL",
            "YAW_RATE",
            "ESC7_MSG_CNT",
            "ESC7_CRC",
        ],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {
            "LATERAL_ACCEL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LATTERAL_ACCEL"),
            "LONG_ACCEL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LONG_ACCEL"),
            "YAW_RATE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("YAW_RATE"),
        },
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    },

    "ESC5_10": {
        "signals": [
            "ESC_ACTIVE",
            "ABS_ACTIVE",
            "ESC5_MSG_CNT",
            "ESC5_CRC",
        ],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        }
    },

    "ESC2_10": {
        "signals": ["TCS_ACTIVE_IEB"],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "EMS36_10": {
        "signals": [
            "ACC_PED",
            "Engine_Speed",
            "EMS36_MSG_CNT",
            "EMS36_CRC",
        ],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "ACC_PED": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ACC_PED"),
            "Engine_Speed": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ENG_SPD"),
        },
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        }
    },

    "EMS21_10": {
        "signals": [
            "BRAKE_PEDAL_VALUE",
            "EMS21_MSG_CNT",
            "EMS21_CRC",
        ],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "BRAKE_PEDAL_VALUE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("BRK_PEDAL"),
        },
        "message_content_failure_dtcs": {
            "EMS21_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_MSG_CNT"),
            "EMS21_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_CRC"),
        }
    },

    "EMS3_10": {
        "signals": ["CLUTCH_STS"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "CLUTCH_STS": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CLUTCH_STS"),
        },
        "message_content_failure_dtcs": {}
    },

    "EMS6_500": {
        "signals": ["DISP_AMBT_TEMP_EMS"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "DISP_AMBT_TEMP_EMS": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("DISP_AMBT_TEMP_EMS"),
        },
        "message_content_failure_dtcs": {}
    },

    "EMS5_500": {
        "signals": [
            "VIN_DATA_2",
            "VIN_DATA_1",
            "VIN_DATA_0",
            "VIN_INDEX",
        ],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "EMS1_10": {
        "signals": [
            "INDC_CRUISE",
            "CURRENT_GEAR_MT",
            "STS_ENG",
        ],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "CURRENT_GEAR_MT": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CURRENT_GEAR_MT"),
        },
        "message_content_failure_dtcs": {}
    },

    "IS3_500": {
        "signals": [
            "EventDtYear",
            "EventDt_Month",
            "CLOCK_FORMAT",
            "EventDt",
            "EventTime",
            "CLOCK_MIN",
        ],
        "key_node": "IS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IS"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "IS1_100": {
        "signals": ["DRL_EN_SW"],
        "key_node": "IS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IS"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "IC2_100": {
        "signals": [
            "Odometer",
            "CuttoffSwitchFPsngr",
        ],
        "key_node": "IC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IC"),
        "signal_content_failure_dtcs": {
            "Odometer": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ODOMTR_READING_IS"),
        },
        "message_content_failure_dtcs": {}
    },

    "EPS_SAS1_10": {
        "signals": [
            "STEERING_ABSOLUTE_ANGLE",
            "SAS_MSG_CNT",
            "SAS_CRC",
        ],
        "key_node": "SAS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtcs": {
            "STEERING_ABSOLUTE_ANGLE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("STEERING_ABSOLUTE_ANGLE"),
        },
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EPS_SAS1_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EPS_SAS1_CRC"),
        }
    },

    "TCU5_10": {
        "signals": ["GEAR_ACTUAL"],
        "key_node": "TCU",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("TCU"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("TCU"),
        "signal_content_failure_dtcs": {
            "GEAR_ACTUAL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("GEAR_ACTUAL"),
        },
        "message_content_failure_dtcs": {}
    },    
}


# VEHICLE_SPEED_ESC12 signal dictionary (frame: ESC12_10, signal: VEHICLE_SPEED_ESC12)
CAN_VEHICLE_SPEED = {
    "frame": 'ESC12_10',
    "signal": 'VEHICLE_SPEED_ESC12',
    "frame_ID": 0x282,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.015625,
    "Offset": 0,
    "UNIT": 'kmph',
    "MIN": 0x0000,
    "MID": 0x2580,
    "MAX": 0x4B00,
    "TestCase_1_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    ],
    "TestCase_1_1_OutofRange_Values": [
        0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00,
        0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00,
    ],
    "TestCase_1_1_values": [
        0x0000, 0x0840, 0x1080, 0x1900, 0x2140, 0x2980, 0x3200, 0x3A40,
        0x4280, 0x4B00, 0x0000, 0x0840, 0x1080, 0x1900, 0x2140, 0x2980,
    ],
    "EDR_Parameter": 'VehSpdLgt',
    "fault_logic": {
        "key_message": 'ESC12_10',
        "fault_type": 'node_absent',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("VEHICLE_SPEED_ESC12"),
        "message_content_failure_dtcs": {"ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"), "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC")},
    }
}

# BRK_PEDAL1 signal dictionary (frame: EMS21_10, signal: BRK_PEDAL1)
CAN_BRK_PDL = {
    "frame": 'EMS21_10',
    "signal": 'BRK_PEDAL1',
    "frame_ID": 0x127,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x01,
    "MAX": 0x03,
    "TestCase_2_1_Invalid_Values": [
        0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
        0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
    ],
    "TestCase_2_1_Reserved_Values": [
        0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
        0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
    ],
    "TestCase_2_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'Brake_Switch',
    "fault_logic": {
        "key_message": 'EMS21_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("BRK_PEDAL1"),
        "message_content_failure_dtcs": {"EMS21_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_MSG_CNT"), "EMS21_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_CRC")},
    }
}

# ACC_PED1 signal dictionary (frame: EMS36_10, signal: ACC_PED1)
CAN_ACC_PED = {
    "frame": 'EMS36_10',
    "signal": 'ACC_PED1',
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.4,
    "Offset": 0,
    "UNIT": '%',
    "MIN": 0x00,
    "MID": 0x7D,
    "MAX": 0xFA,
    "TestCase_3_1_Invalid_Values": [
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    ],
    "TestCase_3_1_values": [
        0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, 0x96, 0xAF,
        0xC8, 0xE1, 0xFA, 0x00, 0x19, 0x32, 0x4B, 0x64,
    ],
    "TestCase_3_values": [
        0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, 0x96, 0xAF,
        0xC8, 0xE1, 0xFA, 0x00, 0x19, 0x32, 0x4B, 0x64,
    ],
    "EDR_Parameter": 'ACC_PED',
    "fault_logic": {
        "key_message": 'EMS36_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ACC_PED1"),
        "message_content_failure_dtcs": {"EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"), "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC")},
    }
}

# ENG_SPD1 signal dictionary (frame: EMS36_10, signal: ENG_SPD1)
CAN_MOTOR_SPD = {
    "frame": 'EMS36_10',
    "signal": 'ENG_SPD1',
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": 'rpm',
    "MIN": 0x0000,
    "MID": 0x8000,
    "MAX": 0x1F3F,
    "TestCase_4_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
    ],
    "TestCase_4_1_values": [
        0x0000, 0x1111, 0x2222, 0x3333, 0x4444, 0x5555, 0x6666, 0x7777,
        0x8888, 0x9999, 0xAAAA, 0xBBBB, 0xCCCC, 0xDDDD, 0xEEEE, 0xFFFF,
    ],
    "EDR_Parameter": 'MOTOR_SPD',
    "fault_logic": {
        "key_message": 'EMS36_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ENG_SPD1"),
        "message_content_failure_dtcs": {"EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"), "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC")},
    }
}

# ABSOLUTE_ANGLE signal dictionary (frame: EPS_SAS1_10, signal: ABSOLUTE_ANGLE)
CAN_ABSOLUTE_ANGLE = {
    "frame": 'EPS_SAS1_10',
    "signal": 'ABSOLUTE_ANGLE',
    "frame_ID": 0x114,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.1,
    "Offset": 0,
    "UNIT": 'Deg/bit',
    "MIN": 0xE188,
    "MID": 0x0000,
    "MAX": 0x1E77,
    "TestCase_5_1_Invalid_Values": [
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
    ],
    "TestCase_5_1_OutofRange_Values": [
        0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20,
        0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20,
    ],
    "TestCase_5_1_values": [
        0xE188, 0xE598, 0xE9A8, 0xEDB8, 0xF1C8, 0xF5D8, 0xF9E8, 0xFDF8,
        0x01FE, 0x060E, 0x0A1E, 0x0E2E, 0x123E, 0x164E, 0x1A5E, 0x1E6E,
    ],
    "EDR_Parameter": 'Absolute_Angle',
    "fault_logic": {
        "key_message": 'EPS_SAS1_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ABSOLUTE_ANGLE"),
        "message_content_failure_dtcs": {"SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_MSG_CNT"), "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_CRC")},
    }
}

# GEAR_ACTUAL signal dictionary (frame: TCU5_10, signal: GEAR_ACTUAL)
CAN_GEAR_ACTUAL = {
    "frame": 'TCU5_10',
    "signal": 'GEAR_ACTUAL',
    "frame_ID": 0x136,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x01,
    "MAX": 0x0F,
    "TestCase_6_1_Invalid_Values": [
        0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F,
        0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F,
        0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F,
    ],
    "TestCase_6_1_Reserved_Values": [
        0x07, 0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x07,
        0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x07, 0x08,
        0x09, 0x0B, 0x0C, 0x0D, 0x0E, 0x07,
    ],
    "TestCase_6_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x0A,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x0A,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05,
    ],
    "EDR_Parameter": 'Gear_Actual',
    "fault_logic": {
        "key_message": 'TCU5_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("TCU"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("TCU"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("GEAR_ACTUAL"),
        "message_content_failure_dtcs": {},
    }
}

# VEHICLE_SPEED_ESC12 signal dictionary (frame: ESC12_10, signal: VEHICLE_SPEED_ESC12)
CAN_VEHSPD_AT_TIME_ZERO = {
    "frame": 'ESC12_10',
    "signal": 'VEHICLE_SPEED_ESC12',
    "frame_ID": 0x282,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.015625,
    "Offset": 0,
    "UNIT": 'kmph',
    "MIN": 0x0000,
    "MID": 0x2580,
    "MAX": 0x4B00,
    "TestCase_7_1_OutofRange_Values": [0x7D00],
    "TestCase_7_1_values": [0x0000],
    "EDR_Parameter": 'VehSpdLgtAtTimeZero',
    "fault_logic": {
        "key_message": 'ESC12_10',
        "fault_type": 'node_absent',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("VEHICLE_SPEED_ESC12"),
        "message_content_failure_dtcs": {"ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"), "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC")},
    }
}

# ODOMTR_READING signal dictionary (frame: IC2_100, signal: ODOMTR_READING)
CAN_ODOMETER = {
    "frame": 'IC2_100',
    "signal": 'ODOMTR_READING',
    "frame_ID": 0x340,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": 'km',
    "MIN": 0x00000,
    "MID": 0x00001,
    "MAX": 0xF423F,
    "TestCase_8_1_Invalid_Values": [0xFFFFF],
    "TestCase_8_1_OutofRange_Values": [0xF4240],
    "TestCase_8_1_values": [0x004B0],
    "EDR_Parameter": 'Odometer',
    "fault_logic": {
        "key_message": 'IC2_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ODOMTR_READING"),
        "message_content_failure_dtcs": {},
    }
}

# VEHICLE_MODE signal dictionary (frame: VCU16_500, signal: VEHICLE_MODE)
CAN_VEHICLE_MODE = {
    "frame": 'VCU16_500',
    "signal": 'VEHICLE_MODE',
    "frame_ID": 0x590,
    "ch": 2,
    "periodicity": 500,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x03,
    "MAX": 0x05,
    "TestCase_9_1_Invalid_Values": [0x07],
    "TestCase_9_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
    ],
    "EDR_Parameter": 'VEHICLE_STATE',
    "fault_logic": {
        "key_message": 'VCU16_500',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("VCU"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("VCU"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("VEHICLE_MODE"),
        "message_content_failure_dtcs": {},
    }
}

# CLUTCH_STS signal dictionary (frame: EMS3_10, signal: CLUTCH_STS)
CAN_CLUTCH_STS = {
    "frame": 'EMS3_10',
    "signal": 'CLUTCH_STS',
    "frame_ID": 0x108,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_12_1_Invalid_Values": [
        0x07, 0x07, 0x07, 0x07, 0x07, 0x07,
    ],
    "TestCase_12_1_Reserved_Values": [
        0x03, 0x04, 0x05, 0x06, 0x03, 0x04,
    ],
    "TestCase_12_1_values": [
        0x00, 0x01, 0x02, 0x00, 0x01, 0x02,
    ],
    "EDR_Parameter": 'Clutch_Sts',
    "fault_logic": {
        "key_message": 'EMS3_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CLUTCH_STS"),
        "message_content_failure_dtcs": {},
    }
}

# ABS_ACTIVE signal dictionary (frame: ESC5_10, signal: ABS_ACTIVE)
CAN_ABS_ACTIVE = {
    "frame": 'ESC5_10',
    "signal": 'ABS_ACTIVE',
    "frame_ID": 0x10d,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x01,
    "TestCase_13_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'ABS_Active',
    "fault_logic": {
        "key_message": 'ESC5_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ABS_ACTIVE"),
        "message_content_failure_dtcs": {"ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"), "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC")},
    }
}

# ESC_ACTIVE signal dictionary (frame: ESC5_10, signal: ESC_ACTIVE)
CAN_ESC_ACTIVE = {
    "frame": 'ESC5_10',
    "signal": 'ESC_ACTIVE',
    "frame_ID": 0x10d,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x01,
    "TestCase_14_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'ESC_Active',
    "fault_logic": {
        "key_message": 'ESC5_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ESC_ACTIVE"),
        "message_content_failure_dtcs": {"ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"), "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC")},
    }
}

# STS_TPMS_LED signal dictionary (frame: MBFM5_100, signal: STS_TPMS_LED)
CAN_STS_TPMS_LED = {
    "frame": 'MBFM5_100',
    "signal": 'STS_TPMS_LED',
    "frame_ID": 0x214,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x03,
    "TestCase_15_1_Reserved_Values": [
        0x04, 0x05, 0x06, 0x07, 0x04, 0x05,
    ],
    "TestCase_15_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x00, 0x01,
    ],
    "EDR_Parameter": 'STS_TPMS_LED',
    "fault_logic": {
        "key_message": 'MBFM5_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("STS_TPMS_LED"),
        "message_content_failure_dtcs": {},
    }
}

# STS_DOOR_LATCH signal dictionary (frame: MBFM5_100, signal: STS_DOOR_LATCH)
CAN_DOOR_LOCK_STATUS = {
    "frame": 'MBFM5_100',
    "signal": 'STS_DOOR_LATCH',
    "frame_ID": 0x214,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x03,
    "TestCase_16_1_Invalid_Values": [
        0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
        0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
        0x03, 0x03, 0x03, 0x03,
    ],
    "TestCase_16_1_Reserved_Values": [
        0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
        0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
        0x02, 0x02, 0x02, 0x02,
    ],
    "TestCase_16_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'Door_Lock_Status',
    "fault_logic": {
        "key_message": 'MBFM5_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("STS_DOOR_LATCH"),
        "message_content_failure_dtcs": {},
    }
}

# TCS_ACTIVE signal dictionary (frame: ESC2_10, signal: TCS_ACTIVE)
CAN_TCS_ACTIVE_IEB = {
    "frame": 'ESC2_10',
    "signal": 'TCS_ACTIVE',
    "frame_ID": 0x2cc,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x01,
    "TestCase_17_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
        0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'TCS_ACTIVE_IEB',
    "fault_logic": {
        "key_message": 'ESC2_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("TCS_ACTIVE"),
        "message_content_failure_dtcs": {},
    }
}

# AEB_WARNING_MSG1 signal dictionary (frame: HPCAd_33_50, signal: AEB_WARNING_MSG1)
CAN_AEB_WARNING_MSG1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'AEB_WARNING_MSG1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x0F,
    "TestCase_18_1_Reserved_Values": [
        0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C,
        0x0D, 0x0E, 0x0F, 0x05, 0x06, 0x07, 0x08, 0x09,
        0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    ],
    "TestCase_18_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02,
        0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04, 0x00,
        0x01, 0x02, 0x03, 0x04, 0x00, 0x01,
    ],
    "EDR_Parameter": 'AEB_WARNING_MSG1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("AEB_WARNING_MSG1"),
        "message_content_failure_dtcs": {},
    }
}

# AEB_FCTA_WARN1 signal dictionary (frame: HPCAd_33_50, signal: AEB_FCTA_WARN1)
CAN_AEB_FCTA_WARN = {
    "frame": 'HPCAd_33_50',
    "signal": 'AEB_FCTA_WARN1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x03,
    "TestCase_19_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03,
        0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'AEB_FCTA_WARN',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("AEB_FCTA_WARN1"),
        "message_content_failure_dtcs": {},
    }
}

# AES_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: AES_WARNING1)
CAN_AES_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'AES_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_20_1_Reserved_Values": [
        0x01, 0x02, 0x05, 0x06, 0x07, 0x01, 0x02, 0x05,
        0x06, 0x07, 0x01, 0x02, 0x05, 0x06, 0x07, 0x01,
        0x02, 0x05, 0x06, 0x07, 0x01, 0x02,
    ],
    "TestCase_20_1_values": [
        0x00, 0x03, 0x04, 0x00, 0x03, 0x04, 0x00, 0x03,
        0x04, 0x00, 0x03, 0x04, 0x00, 0x03, 0x04, 0x00,
        0x03, 0x04, 0x00, 0x03, 0x04, 0x00,
    ],
    "EDR_Parameter": 'AES_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("AES_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# AES_SYS_STS1 signal dictionary (frame: HPCAd_33_50, signal: AES_SYS_STS1)
CAN_AES_SYS_STS1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'AES_SYS_STS1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x06,
    "TestCase_21_1_Reserved_Values": [
        0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
        0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
        0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
    ],
    "TestCase_21_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x00,
        0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x00, 0x01,
        0x02, 0x03, 0x05, 0x06, 0x07, 0x00,
    ],
    "EDR_Parameter": 'AES_SYS_STS1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("AES_SYS_STS1"),
        "message_content_failure_dtcs": {},
    }
}

# ESA_SYS_STS1 signal dictionary (frame: HPCAd_33_50, signal: ESA_SYS_STS1)
CAN_ESA_SYS_STS1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'ESA_SYS_STS1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_22_1_Reserved_Values": [
        0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
        0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
        0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
    ],
    "TestCase_22_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x00,
        0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x00, 0x01,
        0x02, 0x03, 0x05, 0x06, 0x07, 0x00,
    ],
    "EDR_Parameter": 'ESA_SYS_STS1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ESA_SYS_STS1"),
        "message_content_failure_dtcs": {},
    }
}

# LDW_LKA_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: LDW_LKA_WARNING1)
CAN_LDW_LKA_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'LDW_LKA_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x03,
    "TestCase_23_1_values": [
        0x00, 0x01, 0x02, 0x00, 0x01, 0x02, 0x00, 0x01,
        0x02, 0x00, 0x01, 0x02,
    ],
    "EDR_Parameter": 'LDW_LKA_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LDW_LKA_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# LDW_LKA_SYS_STATE1 signal dictionary (frame: HPCAd_33_50, signal: LDW_LKA_SYS_STATE1)
CAN_LDW_LKA_SYS_STATE1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'LDW_LKA_SYS_STATE1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_24_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'LDW_LKA_SYS_STATE1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LDW_LKA_SYS_STATE1"),
        "message_content_failure_dtcs": {},
    }
}

# LKA_HANDSOFF_DISPLAY_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: LKA_HANDSOFF_DISPLAY_WARNING1)
CAN_LKA_HANDSOFF_DISPLAY_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'LKA_HANDSOFF_DISPLAY_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x03,
    "TestCase_25_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'LKA_HANDSOFF_DISPLAY_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LKA_HANDSOFF_DISPLAY_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# LCF_SYS_STATE1 signal dictionary (frame: HPCAd_33_50, signal: LCF_SYS_STATE1)
CAN_LCF_SYS_STATE1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'LCF_SYS_STATE1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_26_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'LCF_SYS_STATE1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LCF_SYS_STATE1"),
        "message_content_failure_dtcs": {},
    }
}

# SPA_SYS_STATE1 signal dictionary (frame: HPCAd_33_50, signal: SPA_SYS_STATE1)
CAN_SPA_SYS_STATE1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'SPA_SYS_STATE1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_27_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'SPA_SYS_STATE1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("SPA_SYS_STATE1"),
        "message_content_failure_dtcs": {},
    }
}

# SPA_LCF_HANDS_OFF_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: SPA_LCF_HANDS_OFF_WARNING1)
CAN_SPA_LCF_HANDS_OFF_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'SPA_LCF_HANDS_OFF_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x03,
    "TestCase_28_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03,
        0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'SPA_LCF_HANDS_OFF_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("SPA_LCF_HANDS_OFF_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# NP_SYS_STS1 signal dictionary (frame: HPCAd_33_50, signal: NP_SYS_STS1)
CAN_NP_SYS_STS1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'NP_SYS_STS1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x0F,
    "TestCase_29_1_Reserved_Values": [
        0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A,
        0x0B, 0x0C, 0x0D, 0x0E,
    ],
    "TestCase_29_1_values": [
        0x00, 0x01, 0x02, 0x00, 0x01, 0x02, 0x00, 0x01,
        0x02, 0x00, 0x01, 0x02,
    ],
    "EDR_Parameter": 'NP_SYS_STS1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("NP_SYS_STS1"),
        "message_content_failure_dtcs": {},
    }
}

# RMS_MODE_STATE1 signal dictionary (frame: HPCAd_33_50, signal: RMS_MODE_STATE1)
CAN_RMS_MODE_STATE1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'RMS_MODE_STATE1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_30_1_Reserved_Values": [
        0x04, 0x06, 0x04, 0x06, 0x04, 0x06, 0x04, 0x06,
        0x04, 0x06, 0x04, 0x06, 0x04, 0x06, 0x04, 0x06,
        0x04, 0x06, 0x04, 0x06, 0x04, 0x06,
    ],
    "TestCase_30_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x05, 0x00, 0x01, 0x02,
        0x03, 0x05, 0x00, 0x01, 0x02, 0x03, 0x05, 0x00,
        0x01, 0x02, 0x03, 0x05, 0x00, 0x01,
    ],
    "EDR_Parameter": 'RMS_MODE_STATE1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RMS_MODE_STATE1"),
        "message_content_failure_dtcs": {},
    }
}

# LC_PATH_STATE1 signal dictionary (frame: HPCAd_33_50, signal: LC_PATH_STATE1)
CAN_LC_PATH_STATE1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'LC_PATH_STATE1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_31_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'LC_PATH_STATE1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LC_PATH_STATE1"),
        "message_content_failure_dtcs": {},
    }
}

# ELK_ONCOMING_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: ELK_ONCOMING_WARNING1)
CAN_ELK_ONCOMING_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'ELK_ONCOMING_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_32_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02,
        0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04, 0x00,
        0x01, 0x02, 0x03, 0x04, 0x00, 0x01,
    ],
    "EDR_Parameter": 'ELK_ONCOMING_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ELK_ONCOMING_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# ELK_SIDE_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: ELK_SIDE_WARNING1)
CAN_ELK_SIDE_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'ELK_SIDE_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_33_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02,
        0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04, 0x00,
        0x01, 0x02, 0x03, 0x04, 0x00, 0x01,
    ],
    "EDR_Parameter": 'ELK_SIDE_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ELK_SIDE_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# ELK_OVERTAKING_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: ELK_OVERTAKING_WARNING1)
CAN_ELK_OVERTAKING_WARNING1 = {
    "frame": 'HPCAd_33_50',
    "signal": 'ELK_OVERTAKING_WARNING1',
    "frame_ID": 0x2c5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_34_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02,
        0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04, 0x00,
        0x01, 0x02, 0x03, 0x04, 0x00, 0x01,
    ],
    "EDR_Parameter": 'ELK_OVERTAKING_WARNING1',
    "fault_logic": {
        "key_message": 'HPCAd_33_50',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAd"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAd"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ELK_OVERTAKING_WARNING1"),
        "message_content_failure_dtcs": {},
    }
}

# ACC_SYS_STATE signal dictionary (frame: FRM2_20, signal: ACC_SYS_STATE)
CAN_ACC_SYS_STATE = {
    "frame": 'FRM2_20',
    "signal": 'ACC_SYS_STATE',
    "frame_ID": 0x24c,
    "ch": 2,
    "periodicity": 20,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x07,
    "TestCase_35_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
    ],
    "EDR_Parameter": 'ACC_SYS_STATE',
    "fault_logic": {
        "key_message": 'FRM2_20',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("FRM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("FRM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ACC_SYS_STATE"),
        "message_content_failure_dtcs": {},
    }
}

# STS_HIGH_BEAM signal dictionary (frame: MBFM1_100, signal: STS_HIGH_BEAM)
CAN_STS_HIGH_BEAM = {
    "frame": 'MBFM1_100',
    "signal": 'STS_HIGH_BEAM',
    "frame_ID": 0x348,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x01,
    "TestCase_36_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'STS_HIGH_BEAM',
    "fault_logic": {
        "key_message": 'MBFM1_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("STS_HIGH_BEAM"),
        "message_content_failure_dtcs": {},
    }
}

# STS_LOW_BEAM signal dictionary (frame: MBFM1_100, signal: STS_LOW_BEAM)
CAN_STS_LOW_BEAM = {
    "frame": 'MBFM1_100',
    "signal": 'STS_LOW_BEAM',
    "frame_ID": 0x348,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x00,
    "MAX": 0x01,
    "TestCase_37_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
    ],
    "EDR_Parameter": 'STS_LOW_BEAM',
    "fault_logic": {
        "key_message": 'MBFM1_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("STS_LOW_BEAM"),
        "message_content_failure_dtcs": {},
    }
}

# EventDt composite dictionary (frame: IS3_500, signals: CLOCK_DATE/CLOCK_MONTH/CLOCK_YEAR)
CAN_EventDt = {
    "frame": 'IS3_500',
    "signals": ['CLOCK_DATE', 'CLOCK_MONTH', 'CLOCK_YEAR'],
    "frame_ID": 0x3CA,
    "ch": 2,
    "periodicity": 500,
    "components": {
        "CLOCK_DATE": {"Factor": 1, "Offset": 0, "UNIT": None, "MIN": 0x00, "MID": 0x10, "MAX": 0x1F},
        "CLOCK_MONTH": {"Factor": 1, "Offset": 0, "UNIT": None, "MIN": 0x00, "MID": 0x08, "MAX": 0x0F},
        "CLOCK_YEAR": {"Factor": 1, "Offset": 2020, "UNIT": None, "MIN": 0x00, "MID": 0x20, "MAX": 0x3F},
    },
    "TestCase_38_1_values": [
        {"CLOCK_DATE": 0x0A, "CLOCK_MONTH": 0x09, "CLOCK_YEAR": 0x04},  # 10/09/2024
        {"CLOCK_DATE": 0x03, "CLOCK_MONTH": 0x0C, "CLOCK_YEAR": 0x07},  # 03/12/2027
        {"CLOCK_DATE": 0x17, "CLOCK_MONTH": 0x01, "CLOCK_YEAR": 0x1E},  # 23/01/2050
    ],
    "TestCase_38_4_OutofRange_Values": [
        {"CLOCK_DATE": 0x20, "CLOCK_MONTH": 0x0D, "CLOCK_YEAR": 0x02},  # 32/13/2022
        {"CLOCK_DATE": 0x00, "CLOCK_MONTH": 0x00, "CLOCK_YEAR": 0x01},  # 00/00/2021
        {"CLOCK_DATE": 0x20, "CLOCK_MONTH": 0x0D, "CLOCK_YEAR": 0x02},  # 32/13/2022
    ],
    "EDR_Parameter": 'EventDt',
    "fault_logic": {
        "key_message": 'IS3_500',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# EventTime composite dictionary (frame: IS3_500, signals: CLOCK_HOUR/CLOCK_MIN)
CAN_EventTime = {
    "frame": 'IS3_500',
    "signals": ['CLOCK_HOUR', 'CLOCK_MIN'],
    "frame_ID": 0x3CA,
    "ch": 2,
    "periodicity": 500,
    "components": {
        "CLOCK_HOUR": {"Factor": 1, "Offset": 0, "UNIT": None, "MIN": 0x00, "MID": 0x10, "MAX": 0x1F},
        "CLOCK_MIN": {"Factor": 1, "Offset": 0, "UNIT": None, "MIN": 0x00, "MID": 0x20, "MAX": 0x3F},
    },
    "TestCase_39_1_values": [
        {"CLOCK_HOUR": 0x0B, "CLOCK_MIN": 0x23},  # 11:35
        {"CLOCK_HOUR": 0x08, "CLOCK_MIN": 0x07},  # 08:07
        {"CLOCK_HOUR": 0x17, "CLOCK_MIN": 0x3B},  # 23:59
    ],
    "TestCase_39_4_OutofRange_Values": [
        {"CLOCK_HOUR": 0x1F, "CLOCK_MIN": 0x3F},  # 31:63
        {"CLOCK_HOUR": 0x18, "CLOCK_MIN": 0x3C},  # 24:60
        {"CLOCK_HOUR": 0x19, "CLOCK_MIN": 0x63},  # 25:99
    ],
    "EDR_Parameter": 'EventTime',
    "fault_logic": {
        "key_message": 'IS3_500',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_ENG signal dictionary (frame: EMS1_10, signal: STS_ENG)
CAN_STS_ENG = {
    "frame": 'EMS1_10',
    "signal": 'STS_ENG',
    "frame_ID": 0x124,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x03,
    "MAX": 0x05,
    "TestCase_10_1_values": [0x00, 0x01, 0x02, 0x03, 0x04, 0x05],
    "TestCase_10_4_Reserved_Values": [0x06, 0x07],
    "EDR_Parameter": 'STS_ENG',
    "fault_logic": {
        "key_message": 'EMS1_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_DOOR signal dictionary (frame: MBFM1_100, signal: STS_DOOR)
CAN_DoorOpenStatus = {
    "frame": 'MBFM1_100',
    "signal": 'STS_DOOR',
    "frame_ID": 0x348,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x10,
    "MAX": 0x3F,
    "TestCase_11_1_values": [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x3F],
    "EDR_Parameter": 'DoorOpenStatus',
    "fault_logic": {
        "key_message": 'MBFM1_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# ENG_SPD1 signal dictionary (frame: EMS36_10, signal: ENG_SPD1)
CAN_Engine_Speed = {
    "frame": 'EMS36_10',
    "signal": 'ENG_SPD1',
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": 'rpm',
    "MIN": 0x0000,
    "MID": 0x0FA0,
    "MAX": 0x1F3F,
    "TestCase_40_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF,
    ],
    "TestCase_40_1_values": [
        0x0000, 0x01F4, 0x03E8, 0x05DC, 0x07D0, 0x09C4, 0x0BB8, 0x0FA0,
        0x1770, 0x1B58, 0x1E78, 0x1F3F, 0x1E78, 0x1B58, 0x1770, 0x0BB8,
        0x0000,
    ],
    "TestCase_40_3_values": [
        0x0000, 0x01F4, 0x03E8, 0x05DC, 0x07D0, 0x09C4, 0x0BB8, 0x0FA0,
        0x1770, 0x1B58, 0x1E78,
    ],
    "TestCase_40_4_values": [0x1E78, 0x1F3F, 0x1E78, 0x1B58, 0x1770, 0x0BB8, 0x0000],
    "EDR_Parameter": 'Engine_Speed',
    "fault_logic": {
        "key_message": 'EMS36_10',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ENG_SPD"),
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        },
    }
}

# ABSOLUTE_ANGLE signal dictionary (frame: EPS_SAS1_10, signal: ABSOLUTE_ANGLE)
CAN_STEERING_ABSOLUTE_ANGLE = {
    "frame": 'EPS_SAS1_10',
    "signal": 'ABSOLUTE_ANGLE',
    "frame_ID": 0x114,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.1,
    "Offset": 0,
    "UNIT": 'deg',
    "MIN": 0xE188,
    "MID": 0x0000,
    "MAX": 0x1E77,
    "TestCase_41_1_Invalid_Values": [
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF,
    ],
    "TestCase_41_1_values": [
        0xE188, 0xE69C, 0xEBA0, 0xF0A4, 0xF5A8, 0xFAEC, 0xFDA8, 0xFF9C,
        0x0000, 0x0064, 0x0258, 0x0514, 0x0A28, 0x0F3C, 0x1450, 0x1964,
        0x1E77,
    ],
    "TestCase_41_3_values": [
        0xE188, 0xE69C, 0xEBA0, 0xF0A4, 0xF5A8, 0xFAEC, 0xFDA8, 0xFF9C,
        0x0000, 0x0064, 0x0258,
    ],
    "TestCase_41_4_values": [0x0258, 0x0514, 0x0A28, 0x0F3C, 0x1450, 0x1964, 0x1E77],
    "EDR_Parameter": 'STEERING_ABSOLUTE_ANGLE',
    "fault_logic": {
        "key_message": 'EPS_SAS1_10',
        "fault_type": 'node_absent',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("STEERING_ABSOLUTE_ANGLE"),
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EPS_SAS1_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EPS_SAS1_CRC"),
        },
    }
}

# FL_TYRE_PRESSURE signal dictionary (frame: MBFM6_100, signal: FL_TYRE_PRESSURE)
CAN_Tyre_Pressure_FL = {
    "frame": 'MBFM6_100',
    "signal": 'FL_TYRE_PRESSURE',
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": 'bar',
    "MIN": 0x00,
    "MID": 0x80,
    "MAX": 0xFE,
    "TestCase_42_1_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "TestCase_42_1_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_42_3_values": [0x00, 0x20, 0x40, 0x60, 0x80],
    "TestCase_42_4_values": [0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "EDR_Parameter": 'Tyre_Pressure_FL',
    "fault_logic": {
        "key_message": 'MBFM6_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FL_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

CAN_Tyre_Pressure_FR = {
    "frame": 'MBFM6_100',
    "signal": 'FR_TYRE_PRESSURE',
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": 'bar',
    "MIN": 0x00,
    "MID": 0x80,
    "MAX": 0xFE,
    "TestCase_43_1_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "TestCase_43_1_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_43_3_values": [0x00, 0x20, 0x40, 0x60, 0x80],
    "TestCase_43_4_values": [0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "EDR_Parameter": 'Tyre_Pressure_FR',
    "fault_logic": {
        "key_message": 'MBFM6_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FR_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

CAN_Tyre_Pressure_RL = {
    "frame": 'MBFM6_100',
    "signal": 'RL_TYRE_PRESSURE',
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": 'bar',
    "MIN": 0x00,
    "MID": 0x80,
    "MAX": 0xFE,
    "TestCase_44_1_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "TestCase_44_1_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_44_3_values": [0x00, 0x20, 0x40, 0x60, 0x80],
    "TestCase_44_4_values": [0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "EDR_Parameter": 'Tyre_Pressure_RL',
    "fault_logic": {
        "key_message": 'MBFM6_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RL_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

CAN_Tyre_Pressure_RR = {
    "frame": 'MBFM6_100',
    "signal": 'RR_TYRE_PRESSURE',
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": 'bar',
    "MIN": 0x00,
    "MID": 0x80,
    "MAX": 0xFE,
    "TestCase_45_1_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "TestCase_45_1_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_45_3_values": [0x00, 0x20, 0x40, 0x60, 0x80],
    "TestCase_45_4_values": [0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "EDR_Parameter": 'Tyre_Pressure_RR',
    "fault_logic": {
        "key_message": 'MBFM6_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RR_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# MASTER_CYL_PRESSURE signal dictionary (frame: ESC10_20, signal: MASTER_CYL_PRESSURE)
CAN_Master_Cylinder_Pressure = {
    "frame": 'ESC10_20',
    "signal": 'MASTER_CYL_PRESSURE',
    "frame_ID": 0x171,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.05,
    "Offset": -40,
    "UNIT": 'bar',
    "MIN": 0x0000,
    "MID": 0x1130,
    "MAX": 0x2260,
    "TestCase_46_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF,
    ],
    "TestCase_46_1_values": [
        0x0000, 0x0226, 0x044C, 0x0672, 0x0898, 0x0ABE, 0x0CE4, 0x0F0A,
        0x1130, 0x1356, 0x157C, 0x17A2, 0x19C8, 0x1BEE, 0x1E14, 0x203A,
        0x2260,
    ],
    "TestCase_46_3_values": [
        0x0000, 0x0226, 0x044C, 0x0672, 0x0898, 0x0ABE, 0x0CE4, 0x0F0A,
        0x1130, 0x1356, 0x157C,
    ],
    "TestCase_46_4_values": [0x157C, 0x17A2, 0x19C8, 0x1BEE, 0x1E14, 0x203A, 0x2260],
    "EDR_Parameter": 'Master_Cylinder_Pressure',
    "fault_logic": {
        "key_message": 'ESC10_20',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("MASTER_CYL_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# YAW_RATE signal dictionary (frame: ESC7_20, signal: YAW_RATE)
CAN_YAW_RATE = {
    "frame": 'ESC7_20',
    "signal": 'YAW_RATE',
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.005,
    "Offset": -163.84,
    "UNIT": 'deg/s',
    "MIN": 0x0000,
    "MID": 0x8000,
    "MAX": 0xFFFE,
    "TestCase_47_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF,
    ],
    "TestCase_47_1_values": [
        0x0000, 0x12A0, 0x2240, 0x39B0, 0x5120, 0x6890, 0x7830, 0x7F38,
        0x8000, 0x80C8, 0x87D0, 0x9770, 0xAEE0, 0xC650, 0xDDC0, 0xED60,
        0xFFFE,
    ],
    "TestCase_47_3_values": [
        0x0000, 0x12A0, 0x2240, 0x39B0, 0x5120, 0x6890, 0x7830, 0x7F38,
        0x8000, 0x80C8, 0x87D0,
    ],
    "TestCase_47_4_values": [0x87D0, 0x9770, 0xAEE0, 0xC650, 0xDDC0, 0xED60, 0xFFFE],
    "EDR_Parameter": 'YAW_RATE',
    "fault_logic": {
        "key_message": 'ESC7_20',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("YAW_RATE"),
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        },
    }
}

# LATTERAL_ACCEL signal dictionary (frame: ESC7_20, signal: LATTERAL_ACCEL)
CAN_LATERAL_ACCEL = {
    "frame": 'ESC7_20',
    "signal": 'LATTERAL_ACCEL',
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.000127465,
    "Offset": -4.1768,
    "UNIT": 'g',
    "MIN": 0x0000,
    "MID": 0x8000,
    "MAX": 0xFFFD,
    "TestCase_48_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF,
    ],
    "TestCase_48_1_values": [
        0x0000, 0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000,
        0x8000, 0x9000, 0xA000, 0xB000, 0xC000, 0xD000, 0xE000, 0xF000,
        0xFFFD,
    ],
    "TestCase_48_3_values": [
        0x0000, 0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000,
        0x8000, 0x9000, 0xA000,
    ],
    "TestCase_48_4_values": [0xA000, 0xB000, 0xC000, 0xD000, 0xE000, 0xF000, 0xFFFD],
    "EDR_Parameter": 'LATERAL_ACCEL',
    "fault_logic": {
        "key_message": 'ESC7_20',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LATTERAL_ACCEL"),
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        },
    }
}

# LONG_ACCEL signal dictionary (frame: ESC7_20, signal: LONG_ACCEL)
CAN_LONG_ACCEL = {
    "frame": 'ESC7_20',
    "signal": 'LONG_ACCEL',
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.000127465,
    "Offset": -4.1768,
    "UNIT": 'g',
    "MIN": 0x0000,
    "MID": 0x8000,
    "MAX": 0xFFFD,
    "TestCase_49_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF,
    ],
    "TestCase_49_1_values": [
        0x0000, 0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000,
        0x8000, 0x9000, 0xA000, 0xB000, 0xC000, 0xD000, 0xE000, 0xF000,
        0xFFFD,
    ],
    "TestCase_49_3_values": [
        0x0000, 0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000,
        0x8000, 0x9000, 0xA000,
    ],
    "TestCase_49_4_values": [0xA000, 0xB000, 0xC000, 0xD000, 0xE000, 0xF000, 0xFFFD],
    "EDR_Parameter": 'LONG_ACCEL',
    "fault_logic": {
        "key_message": 'ESC7_20',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LONG_ACCEL"),
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        },
    }
}

# ADAS_DES_STRWHL_ANGLE_CMD1 signal dictionary (frame: HPCAd_31_10, signal: ADAS_DES_STRWHL_ANGLE_CMD1)
CAN_ADAS_Des_StrWhl_Angle_Cmd = {
    "frame": 'HPCAd_31_10',
    "signal": 'ADAS_DES_STRWHL_ANGLE_CMD1',
    "frame_ID": 0x14C,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.1,
    "Offset": -720,
    "UNIT": 'deg',
    "MIN": 0x0000,
    "MID": 0x1C20,
    "MAX": 0x3840,
    "TestCase_50_1_Invalid_Values": [
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
    ],
    "TestCase_50_1_values": [
        0x0000, 0x05A0, 0x0B40, 0x10E0, 0x1680, 0x1C20, 0x21C0, 0x2760,
        0x2D00, 0x32A0, 0x3840,
    ],
    "TestCase_50_3_values": [0x0000, 0x05A0, 0x0B40, 0x10E0, 0x1680, 0x1C20, 0x21C0],
    "TestCase_50_4_values": [0x21C0, 0x2760, 0x2D00, 0x32A0, 0x3840],
    "EDR_Parameter": 'ADAS_Des_StrWhl_Angle_Cmd',
    "fault_logic": {
        "key_message": 'HPCAd_31_10',
        "fault_type": 'node_absent',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ADAS_DES_STRWHL_ANGLE_CMD"),
        "message_content_failure_dtcs": {},
    }
}

# BATT_VOLT signal dictionary (frame: MBFM7_100, signal: BATT_VOLT)
CAN_BATT_VOLT = {
    "frame": 'MBFM7_100',
    "signal": 'BATT_VOLT',
    "frame_ID": 0x21C,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": 'V',
    "MIN": 0x00,
    "MID": 0x7D,
    "MAX": 0xFE,
    "TestCase_51_1_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "TestCase_51_1_values": [0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, 0x96, 0xAF, 0xC8, 0xE1, 0xFE],
    "TestCase_51_3_values": [0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, 0x96],
    "TestCase_51_4_values": [0x96, 0xAF, 0xC8, 0xE1, 0xFE],
    "EDR_Parameter": 'BATT_VOLT',
    "fault_logic": {
        "key_message": 'MBFM7_100',
        "fault_type": 'message_timeout',
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

MAH_CAN_SIGNAL_DEFS = {
    "AEB_WARNING_MSG1": CAN_AEB_WARNING_MSG1,
    "NP_SYS_STS1": CAN_NP_SYS_STS1,
    "AES_SYS_STS1": CAN_AES_SYS_STS1,
    "AES_WARNING1": CAN_AES_WARNING1,
    "AEB_FCTA_WARN": CAN_AEB_FCTA_WARN,
    "ESA_SYS_STS1": CAN_ESA_SYS_STS1,
    "ELK_ONCOMING_WARNING1": CAN_ELK_ONCOMING_WARNING1,
    "LDW_LKA_WARNING1": CAN_LDW_LKA_WARNING1,
    "ELK_OVERTAKING_WARNING1": CAN_ELK_OVERTAKING_WARNING1,
    "ELK_SIDE_WARNING1": CAN_ELK_SIDE_WARNING1,
    "LKA_HANDSOFF_DISPLAY_WARNING1": CAN_LKA_HANDSOFF_DISPLAY_WARNING1,
    "LC_PATH_STATE1": CAN_LC_PATH_STATE1,
    "LCF_SYS_STATE1": CAN_LCF_SYS_STATE1,
    "SPA_LCF_HANDS_OFF_WARNING1": CAN_SPA_LCF_HANDS_OFF_WARNING1,
    "LDW_LKA_SYS_STATE1": CAN_LDW_LKA_SYS_STATE1,
    "SPA_SYS_STATE1": CAN_SPA_SYS_STATE1,
    "RMS_MODE_STATE1": CAN_RMS_MODE_STATE1,
    "ADAS_Des_StrWhl_Angle_Cmd": CAN_ADAS_Des_StrWhl_Angle_Cmd,
    "ACC_SYS_STATE": CAN_ACC_SYS_STATE,
    "Tyre_Pressure_FL": CAN_Tyre_Pressure_FL,
    "Tyre_Pressure_FR": CAN_Tyre_Pressure_FR,
    "Tyre_Pressure_RL": CAN_Tyre_Pressure_RL,
    "Tyre_Pressure_RR": CAN_Tyre_Pressure_RR,
    "Door Lock Status": CAN_DOOR_LOCK_STATUS,
    "STS_TPMS_LED": CAN_STS_TPMS_LED,
    "BattVolt": CAN_BATT_VOLT,
    "DoorsOpenStatus": CAN_DoorOpenStatus,
    "STS_HIGH_BEAM": CAN_STS_HIGH_BEAM,
    "STS_LOW_BEAM": CAN_STS_LOW_BEAM,
    "VehSpdLgt": CAN_VEHICLE_SPEED,
    "VehSpdLgtAtTimeZero": CAN_VEHSPD_AT_TIME_ZERO,
    "Master_Cylinder_Pressure": CAN_Master_Cylinder_Pressure,
    "LATERAL_ACCEL": CAN_LATERAL_ACCEL,
    "LONG_ACCEL": CAN_LONG_ACCEL,
    "YAW_RATE": CAN_YAW_RATE,
    "ESC_ACTIVE": CAN_ESC_ACTIVE,
    "ABS_ACTIVE": CAN_ABS_ACTIVE,
    "TCS_ACTIVE_IEB": CAN_TCS_ACTIVE_IEB,
    "ACC_PED": CAN_ACC_PED,
    "Engine_Speed": CAN_Engine_Speed,
    "BRAKE_PEDAL_VALUE": CAN_BRK_PDL,
    "CLUTCH_STS": CAN_CLUTCH_STS,
    "STS_ENG": CAN_STS_ENG,
    "EventDtYear": CAN_EventDt,
    "EventDt_Month": CAN_EventDt,
    "EventDt": CAN_EventDt,
    "EventTime": CAN_EventTime,
    "CLOCK_MIN": CAN_EventTime,
    "Odometer": CAN_ODOMETER,
    "STEERING_ABSOLUTE_ANGLE": CAN_STEERING_ABSOLUTE_ANGLE,
    "GEAR_ACTUAL": CAN_GEAR_ACTUAL,
    "VEHICLE_MODE": CAN_VEHICLE_MODE,
}

# Key Nodes Definition
KEY_TX_FRAMES = { 
    "TESTER_PHYSICAL_REQ_PCU": False,

    # HPCAD node
    "HPCAd_31_10": True,
    "HPCAd_33_50": False,

    # FRM node
    "FRM2_20": True,

    # MBFM node
    "MBFM1_100": True,
    "MBFM5_100": False,
    "MBFM6_100": False,
    "MBFM7_100": False,
    "MBFM_WAKEUP": False,
    "MBFM_SLEEP": False,
    "MBFM_ACTIVE": False,

    # ESC node
    "ESC5_10": True,
    "ESC2_10": False,
    "ESC7_20": False,
    "ESC10_20": False,
    "ESC12_10": False,

    # EMS node
    "EMS3_10": True,
    "EMS1_10": False,
    "EMS5_500": False,
    "EMS6_500": False,
    "EMS21_10": False,
    "EMS36_10": False,

    # IS node
    "IS1_100": True,
    "IS3_500": False,

    # IC node
    "IC2_100": True,

    # SAS node
    "EPS_SAS1_10": True,

    # TCU node
    "TCU5_10": True,

    # Diagnostic/tool frames
    "GLOBAL_DIAG_REQ": False,
    "SRS_DIAG_REQ": False,
}























# -------- Functions: reads CAN config dictionaries and resolves key-message, timeout, node-absent, and content-failure DTC logic --------

def is_key_message(frame_name: str) -> bool:
    """Return True if the Tx frame is a key message, else False."""
    return bool(KEY_TX_FRAMES.get(frame_name, False))


def get_message_timeout_dtc(frame_name: str) -> str | None:
    cfg = CAN_TX_MESSAGE_CONFIG.get(frame_name)
    if not cfg:
        return None
    return cfg.get("message_timeout_dtc")


def get_node_absent_dtc(frame_name: str) -> str | None:
    cfg = CAN_TX_MESSAGE_CONFIG.get(frame_name)
    if not cfg:
        return None
    return cfg.get("node_absent_dtc")


def get_signal_content_failure_dtc(signal_name: str) -> str | None:
    """Return the signal content failure DTC based on signal name."""
    return CAN_SIGNAL_CONTENT_FAILURE_DTC.get(signal_name)


def get_message_content_failure_dtcs(frame_name: str) -> dict:
    """
    Return the message content failure DTCs defined for the frame in
    `CAN_TX_MESSAGE_CONFIG` (e.g., for CNT/CRC signals). If not present,
    returns an empty dict.
    """
    cfg = CAN_TX_MESSAGE_CONFIG.get(frame_name) or {}
    return cfg.get("message_content_failure_dtcs", {}) or {}


def get_message_content_failure_signals(frame_name: str) -> list:
    """Return the list of signal names that have message content failure DTCs for the given frame."""
    dtcs = get_message_content_failure_dtcs(frame_name)
    return list(dtcs.keys())


def choose_message_content_failure_signal(frame_name: str) -> str | None:
    """
    Select an appropriate message-content-failure signal for the frame.
    Preference order:
    1) Signal containing 'MSG_CNT'
    2) Signal containing 'CRC'
    3) First available signal
    Returns None if no signals are defined.
    """
    signals = get_message_content_failure_signals(frame_name)
    if not signals:
        return None
    upper = [s.upper() for s in signals]
    for idx, name in enumerate(upper):
        if "MSG_CNT" in name:
            return signals[idx]
    for idx, name in enumerate(upper):
        if "CRC" in name:
            return signals[idx]
    return signals[0]


def get_frame_message_content_failure_dtc(frame_name: str) -> tuple[str | None, str | None]:
    """
    Simple helper to fetch the Message Content Failure DTC for a given frame.
    - Chooses an appropriate content signal via `choose_message_content_failure_signal`.
    - Returns (dtc_code, signal_name). If no mapping exists, returns (None, None).
    """
    dtc_map = get_message_content_failure_dtcs(frame_name) or {}
    sig = choose_message_content_failure_signal(frame_name)
    if not sig:
        return None, None
    return dtc_map.get(sig), sig


def resolve_dtc_for_event(event_type: str, frame_name: str | None, signal_name: str | None = None):
    """
    Resolve the appropriate DTC(s) based on the event type and context.

    event_type:
      - "message_timeout": Return message-timeout DTC for the frame.
      - "node_absent": Return node-absent DTC for the frame.
      - "frame_disabled": If frame is key -> node_absent, else -> message_timeout.
      - "signal_invalid": Return signal_content_failure for the signal.
      - "message_content_failure": Return dict of message-content failure DTCs.

    Returns a string (single DTC), a dict (multiple DTCs), or None if unknown.
    """
    if event_type == "message_timeout":
        return get_message_timeout_dtc(frame_name) if frame_name else None
    if event_type == "node_absent":
        return get_node_absent_dtc(frame_name) if frame_name else None
    if event_type == "frame_disabled":
        if not frame_name:
            return None
        return get_node_absent_dtc(frame_name) if is_key_message(frame_name) else get_message_timeout_dtc(frame_name)
    if event_type == "signal_invalid" and signal_name:
        return get_signal_content_failure_dtc(signal_name)
    if event_type == "message_content_failure":
        return get_message_content_failure_dtcs(frame_name) if frame_name else {}
    return None

