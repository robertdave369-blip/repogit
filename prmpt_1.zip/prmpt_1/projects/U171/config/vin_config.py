"""
Module Configuration: VIN
Project: U171
============================================================

Location: projects/U171/config/vin_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is VIN
    ctx.get_module_config("VIN").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "VIN"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── VIN Settings ──
VIN_DID = 0xF190
VIN_LENGTH = 17
TEST_VIN = "WBA00000000000001"

SECURITY_ACCESS_LEVEL = 0x01
SECURITY_SEED_DID = 0x27
