"""
Module Configuration: E_CALL
Project: U171
============================================================

Location: projects/U171/config/e_call_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is E_CALL
    ctx.get_module_config("E_CALL").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "E_CALL"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── E_CALL Settings ──
ECALL_TRIGGER_DID = 0x0470
ECALL_STATUS_DID = 0x0471
ECALL_MSD_DID = 0x0472

ECALL_TYPES = {
    0x01: "Automatic",
    0x02: "Manual",
    0x03: "Test",
}

CALL_SETUP_TIMEOUT = 60
MSD_SEND_TIMEOUT = 10
CALLBACK_TIMEOUT = 3600

TEST_PSAP_NUMBER = "+00000000000"
