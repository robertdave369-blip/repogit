"""
Module Configuration: CANC
Project: U171
============================================================

Location: projects/U171/config/canc_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is CANC
    ctx.get_module_config("CANC").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "CANC"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CANC Settings ──
# TEST_CAN_MESSAGES = [
#     {"id": 0x100, "data": [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]},
#     {"id": 0x200, "data": [0xFF, 0xFE, 0xFD, 0xFC, 0x00, 0x00, 0x00, 0x00]},
#     {"id": 0x300, "data": [0x00] * 8},
# ]

# BUS_OFF_RECOVERY_TIME = 2.0
# MESSAGE_CYCLE_TIME = 0.01
# TIMEOUT_MONITORING = 1.0

"""CAN Library - CAN bus communication utilities."""


__all__ = [
    "CAN_SIGNAL_Rx_MAP", "CAN_SIGNAL_Rx_EXPECTED_VALUES",
    "CAN_NODE_ABSENT_DTC", "CAN_MESSAGE_CONTENT_FAILURE_DTC",
    "CAN_MESSAGE_TIMEOUT_DTC", "CAN_MESSAGES",
    "CAN_SIGNAL_CONTENT_FAILURE_DTC", "CAN_TX_MESSAGE_CONFIG",
    "CAN_ACC_PED", "CAN_ABSOLUTE_ANGLE", "CAN_MOTOR_SPD",
    "CAN_BRK_PDL", "CAN_GEAR_ACTUAL", "CAN_ODOMETER", "CAN_VEHICLE_SPEED",
    "KEY_TX_FRAMES", "MAH_CAN_SIGNAL_DEFS", "Signal_Value_2C0",
    # Helpers
    "choose_message_content_failure_signal",
    "get_frame_message_content_failure_dtc",
    "get_message_content_failure_dtcs",
    "get_message_content_failure_signals",
    "get_message_timeout_dtc",
    "get_node_absent_dtc",
    "get_signal_content_failure_dtc",
    "is_key_message",
    "resolve_dtc_for_event",
]


CAN_SIGNAL_Rx_MAP = {
    "U171": {
        "INDC_SRS": ("SRS1_20", "INDC_SRS"),
        "DOOR_UNLOCK": ("SRS1_20", "DOOR_UNLOCK"),
        "STS_CRASH": ("SRS1_20", "STS_CRASH"),
        "INDC_PADL": ("SRS1_20", "INDC_PADL"),
        "SRS_RESERVE1": ("SRS1_20", "SRS_RESERVE1"),
        "EVEN_PARITY_BIT": ("SRS1_20", "EVEN_PARITY_BIT"),
        "SRS_RESERVE2": ("SRS1_20", "SRS_RESERVE2"),
        "STS_SEAT_BLT_DRV": ("SRS1_20", "STS_SEAT_BLT_DRV"),
        "STS_SEAT_BLT_PSGR": ("SRS1_20", "STS_SEAT_BLT_PSGR"),
        "CRASH_LOCATION": ("SRS1_20", "CRASH_LOCATION"),
        "SCM_CNT": ("SRS1_20", "SCM_CNT"),
        "SRS_MSG_CNT": ("SRS1_20", "SRS_MSG_CNT"),
        "SRS_CRC": ("SRS1_20", "SRS_CRC"),
    },
}

# Warning lamp signal values for INDC_SRS (SRS1_20)
Signal_Value_2C0 = {
    "ON": "0x01",
    "OFF": "0x00",
}
# Expected CAN signal values for each crash type
CAN_SIGNAL_Rx_EXPECTED_VALUES = {
    "front": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "CRASH_LOCATION": "0x1",  # 1 = Front Crash
        "DOOR_UNLOCK": "0x1"
    },
    "left": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "CRASH_LOCATION": "0x3",  # 3 = Left Hand Side
        "DOOR_UNLOCK": "0x1"
    },
    "right": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "CRASH_LOCATION": "0x2",  # 2 = Right Hand Side
        "DOOR_UNLOCK": "0x1"
    },
    "rear": {
        "STS_CRASH": "0x1",
        "INDC_SRS": "0x1",
        "CRASH_LOCATION": "0x4",  # 4 = Rear Crash
        "DOOR_UNLOCK": "0x1"
    },
    "near": {
        "STS_CRASH": "0x0",
        "INDC_SRS": "0x0",
        "CRASH_LOCATION": "0x0",
        "DOOR_UNLOCK": "0x0"
    }
}

# Common DTC dictionaries with simple naming convention (node/message name as key)
CAN_NODE_ABSENT_DTC = {
    "HPCAD": "0xD1 0x61 0x00",  
    "IC": "0xD1 0x05 0x00",    
    "EPS": "0xD1 0x11 0x00",  
    "VCU": "0xD1 0x54 0x00",   
    "HPCC": "0xD1 0x60 0x00",
    "IEB": "0xD1 0x03 0x00",
    "FR_ZONE": "0xD1 0x04 0x00",
    "EMS": "0xD1 0x01 0x00",
    "TCU": "0xD1 0x02 0x00",
    "MBFM": "0xD1 0x04 0x00",
    "IS": "0xD1 0x08 0x00",
    "SAS": "0xD1 0x11 0x00",
    "FRM": "0xD1 0x4F 0x00",
    "ESC": "0xD1 0x03 0x00",
}


# Message Content Failure DTCs
# Add CRC and MSG_CNT signal names here and append the DTC for the respective variant per database.
CAN_MESSAGE_CONTENT_FAILURE_DTC = {
    "EMS36_CRC": "0xE4 0xA2 0x00",
    "EMS36_MSG_CNT": "0xE4 0xA2 0x00",
    "EMS21_CRC": "0xE4 0x71 0x00",
    "EMS21_MSG_CNT": "0xE4 0x71 0x00",
    "ESC7_CRC": "0xE4 0x84 0x00",
    "ESC7_MSG_CNT": "0xE4 0x84 0x00",
    "ESC12_CRC": "0xE4 0xAE 0x00",
    "ESC12_MSG_CNT": "0xE4 0xAE 0x00",
    "ESC5_CRC": "0xE4 0x20 0x00",
    "ESC5_MSG_CNT": "0xE4 0x20 0x00",
    "SAS_CRC": "0xE4 0x26 0x00",
    "SAS_MSG_CNT": "0xE4 0x26 0x00",
}

# Message Timeout DTCs
CAN_MESSAGE_TIMEOUT_DTC = {
    "EMS": "0xD0 0x01 0x00",
    "ESC": "0xD0 0x03 0x00",
    "MBFM": "0xD0 0x04 0x00",
    "IC": "0xD0 0x05 0x00",
    "IS": "0xD0 0x08 0x00",
    "TCU": "0xD0 0x02 0x00",
    "FR_ZONE": "0xD0 0x04 0x00",
    "HPCAD": "0xD0 0x5B 0x00"
}

CAN_MESSAGES = {
    "EMS": "EMS",
    "ESC": "ESC",
    "MBFM": "MBFM",
    "IC": "IC",
    "IS": "IS",
    "TCU": "TCU",
    "FR_ZONE": "FR_ZONE",
    "HPCAD": "HPCAD"
}

# Signal Content Failure DTCs
CAN_SIGNAL_CONTENT_FAILURE_DTC = {
    "ACC_PED1": "0xE0 0x01 0x00", #U171
    "ADAS_DES_STRWHL_ANGLE_CMD1": "0xE1 0x77 0x00",
    "BRK_PEDAL1": "0xE0 0x02 0x00",
    "ENG_SPD1": "0xE0 0x04 0x00",
    "CURRENT_GEAR_MT": "0xE0 0x03 0x00",
    "LATTERAL_ACCEL": "0xE0 0x53 0x00",
    "LONG_ACCEL": "0xE0 0x54 0x00",
    "YAW_RATE": "0xE0 0x59 0x00",
    "DISP_AMBT_TEMP_EMS": "0xE0 0xBE 0x00",
    "CLUTCH_STS": "0xE0 0x09 0x00",
    "FL_TYRE_PRESSURE": "0xE0 0xD6 0x00",
    "FR_TYRE_PRESSURE": "0xE0 0xD7 0x00",
    "RL_TYRE_PRESSURE": "0xE0 0xD8 0x00",
    "RR_TYRE_PRESSURE": "0xE0 0xD9 0x00",
    "GEAR_ACTUAL": "0xE1 0x1D 0x00",
    "MASTER_CYL_PRESSURE": "0xE1 0x8D 0x00",
    "ODOMTR_READING_IS": "0xE0 0x12 0x00",
    "VEHICLE_SPEED_ESC12": "0xE0 0x13 0x00",
    "ABSOLUTE_ANGLE": "0xE0 0x58 0x00"
}

# Unified configuration for all Tx messages, signals, and DTCs
CAN_TX_MESSAGE_CONFIG = {

    "MBFM_SLEEP": {
        "signals": ["RESERVED_2"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },
    "MBFM_ACTIVE": {
        "signals": ["RESERVED_2"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },
    "MBFM_WAKEUP": {
        "signals": ["MBFM_WAKEUP_REASON"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },
    "MBFM1_100": {
        "signals": ["STS_DOOR", "STS_HIGH_BEAM", "STS_LOW_BEAM"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM5_100": {
        "signals": ["STS_DOOR_LATCH", "STS_TPMS_LED"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },

    "MBFM6_100": {
        "signals": ["FL_TYRE_PRESSURE", "FR_TYRE_PRESSURE", "RL_TYRE_PRESSURE", "RR_TYRE_PRESSURE"],
        "key_node": "MBFM",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtcs": {
            "FL_TYRE_PRESSURE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FL_TYRE_PRESSURE"),
            "FR_TYRE_PRESSURE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FR_TYRE_PRESSURE"),
            "RL_TYRE_PRESSURE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RL_TYRE_PRESSURE"),
            "RR_TYRE_PRESSURE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RR_TYRE_PRESSURE"),
        },
        "message_content_failure_dtcs": {}
    },
    "HPCAd_31_10": {
        "signals": ["ADAS_DES_STRWHL_ANGLE_CMD1"],
        "key_node": "HPCAD",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtcs": {
            "ADAS_DES_STRWHL_ANGLE_CMD1": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ADAS_DES_STRWHL_ANGLE_CMD1"),
        },
        "message_content_failure_dtcs": {}
    },

    "HPCAd_33_50": {
        "signals": [
            "AEB_WARNING_MSG1", "NP_SYS_STS1", "AES_SYS_STS1", "AES_WARNING1", "AEB_FCTA_WARN1",
            "ESA_SYS_STS1", "ELK_ONCOMING_WARNING1", "LDW_LKA_WARNING1", "ELK_OVERTAKING_WARNING1",
            "ELK_SIDE_WARNING1", "LKA_HANDSOFF_DISPLAY_WARNING1", "LC_PATH_STATE1", "LCF_SYS_STATE1",
            "SPA_LCF_HANDS_OFF_WARNING1", "LDW_LKA_SYS_STATE1", "SPA_SYS_STATE1", "RMS_MODE_STATE1"
        ],
        "key_node": "HPCAD",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },
 
    "TCU5_10": {
        "signals": ["GEAR_ACTUAL"],
        "key_node": "TCU",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("TCU"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("TCU"),
        "signal_content_failure_dtcs": {
            "GEAR_ACTUAL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("GEAR_ACTUAL"),
        },
        "message_content_failure_dtcs": {}
    },
    "ESC12_10": {
        "signals": ["VEHICLE_SPEED_ESC12", "ESC12_MSG_CNT", "ESC12_CRC"],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {
            "VEHICLE_SPEED_ESC12": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("VEHICLE_SPEED_ESC12"),
        },
        "message_content_failure_dtcs": {
            "ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"),
            "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC"),
        }
    },
    "EPS_SAS1_10": {
        "signals": ["ABSOLUTE_ANGLE", "SAS_MSG_CNT", "SAS_CRC"],
        "key_node": "SAS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtcs": {
            "ABSOLUTE_ANGLE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ABSOLUTE_ANGLE"),
        },
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_CRC"),
        }
    },
    "SAS1_10": {
        "signals": ["ABSOLUTE_ANGLE", "SAS_MSG_CNT", "SAS_CRC"],
        "key_node": "SAS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtcs": {
            "ABSOLUTE_ANGLE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ABSOLUTE_ANGLE"),
        },
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_CRC"),
        }
    },
    "EMS36_10": {
        "signals": ["ACC_PED1", "ENG_SPD1", "EMS36_MSG_CNT", "EMS36_CRC"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "ACC_PED1": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ACC_PED1"),
            "ENG_SPD1": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ENG_SPD1"),
        },
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        }
    },
    "EMS5_500": {
        "signals": ["VIN_DATA_2", "VIN_DATA_1", "VIN_DATA_0", "VIN_INDEX"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },
    "EMS6_500": {
        "signals": ["DISP_AMBT_TEMP_EMS"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "DISP_AMBT_TEMP_EMS": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("DISP_AMBT_TEMP_EMS"),
        },
        "message_content_failure_dtcs": {}
    },

    "EMS1_10": {
        "signals": ["INDC_CRUISE", "CURRENT_GEAR_MT"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "CURRENT_GEAR_MT": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CURRENT_GEAR_MT"),
        },
        "message_content_failure_dtcs": {}
    },
    "EMS3_10": {
        "signals": ["CLUTCH_STS"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "CLUTCH_STS": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CLUTCH_STS"),
        },
        "message_content_failure_dtcs": {}
    },
    "EMS21_10": {
        "signals": ["BRK_PEDAL1", "EMS21_MSG_CNT", "EMS21_CRC"],
        "key_node": "EMS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtcs": {
            "BRK_PEDAL1": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("BRK_PEDAL1"),
        },
        "message_content_failure_dtcs": {
            "EMS21_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_MSG_CNT"),
            "EMS21_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_CRC"),
        }
    },
    "IC2_100": {
        "signals": ["ODOMTR_READING", "PSGR_AIRBAG_SW_IC"],
        "key_node": "IC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IC"),
        "signal_content_failure_dtcs": {
            "ODOMTR_READING": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ODOMTR_READING_IS"),
        },
        "message_content_failure_dtcs": {}
    },
    "IS1_100": {
        "signals": ["DRL_EN_SW"],
        "key_node": "IS",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IS"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    },
    "ESC10_20": {
        "signals": ["MASTER_CYL_PRESSURE"],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {
            "MASTER_CYL_PRESSURE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("MASTER_CYL_PRESSURE"),
        },
        "message_content_failure_dtcs": {}
    },
    "ESC7_20": {
        "signals": ["LATTERAL_ACCEL", "LONG_ACCEL", "YAW_RATE", "ESC7_MSG_CNT", "ESC7_CRC"],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {
            "LATTERAL_ACCEL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LATTERAL_ACCEL"),
            "LONG_ACCEL": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LONG_ACCEL"),
            "YAW_RATE": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("YAW_RATE"),
        },
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    },
    "ESC5_10": {
        "signals": ["ESC_ACTIVE", "ABS_ACTIVE", "STS_ESC", "ESC5_MSG_CNT", "ESC5_CRC"],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        }
    },
    "ESC2_10": {
        "signals": [],
        "key_node": "ESC",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtcs": {},
        "message_content_failure_dtcs": {}
    }
}


# ACC_PED signal dictionary (frame: EMS36_10, signal: ACC_PED1)

CAN_ACC_PED = {
    "frame": "EMS36_10",
    "signal": "ACC_PED1",
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.4,
    "Offset": 0,
    "UNIT": "%",
    "MIN": 0x0,
    "MID": 0x7D,
    "MAX": 0xFA,
    "Default_Value": 0x0,
    "TestCase_3_values": [0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, 0x96, 0xAF, 0xC8, 0xF9, 0x7D, 0x05, 0x19, 0x32, 0x4B, 0x64,0x7D],
    "TestCase_3_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],  # Physical value is 255
    "TestCase_3_OutofRange_Values": [
        0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB,
        0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB, 0xFB
    ],


    "EDR_Parameter": "ACC_PED",
    # Fault logic
    "fault_logic": {
        "key_message": "EMS3_10",         
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ACC_PED1"),
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        }
    }
}


# ABSOLUTE_ANGLE signal dictionary (frame: EPS_SAS1_10, signal: ABSOLUTE_ANGLE)
CAN_ABSOLUTE_ANGLE = {
    "frame": "EPS_SAS1_10",
    "signal": "ABSOLUTE_ANGLE",
    "frame_ID": 0x114,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.1,
    "Offset": 0,
    "UNIT": "deg",
    # Raw sample bounds taken from provided EDR test samples
    "MIN": 0xE188,
    "MID": 0x0000,
    "MAX": 0x1E6E,
    "Default_Value": 0x00,
    # Test case values aligned to EDR samples
    "TestCase_5_values": [0xE188, 0xE69C, 0xEBB0, 0xF0C4, 0xF5D8, 0xFAEC, 0xFDA8, 0xFF9C, 0x0000, 0x0064, 0x0258, 0x0514, 0x0A28, 0x0F3C, 0x1450, 0x1964, 0x1E77],
    "TestCase_5_Invalid_Values": [
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF
    ],
    "TestCase_5_OutofRange_Values": [
        0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20,
        0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20, 0x4E20,
        0x4E20
    ],
    "EDR_Parameter": "STEERING_ABSOLUTE_ANGLE",
    # Fault logic
    "fault_logic": {
        "key_message": "EPS_SAS1_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ABSOLUTE_ANGLE"),
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_CRC"),
        }
    },
    "TestCase_41_values": [0xE188, 0xE69C, 0xEBB0, 0xF0C4, 0xF5D8, 0xFAEC, 0xFDA8, 0xFF9C, 0x0000, 0x0064, 0x0258, 0x0514, 0x0A28, 0x0F3C, 0x1450, 0x1964, 0x1E77],
    "TestCase_41_Invalid_Values": [0xFFF6, 0xFF7E, 0xFEFC, 0xFE7A, 0xFDF8, 0xFFC4, 0xFD76, 0xFCF4, 0x0000, 0x000A, 0x0082, 0x0104, 0x0186, 0x0208, 0x003C, 0x028A, 0x030B],
}


# MOTOR_SPD signal dictionary (frame: EMS36_10, signal: ENG_SPD1)
CAN_MOTOR_SPD = {
    "frame": "EMS36_10",
    "signal": "ENG_SPD1",
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0000,
    "MID": 0x8000,
    "MAX": 0xFFFF,
    "Default_Value": 0x0,
    # Test case values aligned to EDR samples
    "TestCase_4_values": [
        0x0000, 0x1111, 0x2222, 0x3333, 0x4444, 0x5555, 0x6666, 0x7777,
        0x8888, 0x9999, 0xAAAA, 0xBBBB, 0xCCCC, 0xDDDD, 0xEEEE, 0xFFFF,
        0xFFFF
    ],
    "TestCase_4_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF
    ],
    "TestCase_4_OutofRange_Values": [
        0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40,
        0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40, 0x1F40,
        0x1F40
    ],
    "EDR_Parameter": "Engine_Speed",
    # Fault logic mirrors ACC_PED on the same frame
    "fault_logic": {
        "key_message": "EMS36_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ENG_SPD1"),
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        }
    },
    "TestCase_40_values": [0x0000, 0x01F4, 0x03E8, 0x05DC, 0x07D0, 0x09C4, 0x0BB8, 0x0FA0, 0x1770, 0x1B58, 0x1E78, 0x1F3F, 0x1E78, 0x1B58, 0x1770, 0x0BB8, 0x0000],
    "TestCase_40_Invalid_Values": [0x0000, 0x03E8, 0x05DC, 0x07D0, 0x09C4, 0x0BB8, 0x0FA0, 0x01F4, 0x1770, 0x1B58, 0x1E78, 0x1F3F],
    "TestCase_40_OutofRange_Values": [0x1F72, 0x1FA4, 0x2008, 0x206C, 0x20D0, 0x2134, 0x2198, 0x21FC, 0x2260, 0x22C4, 0x2328, 0x238C, 0x23F0],
}


# GEAR_ACTUAL signal dictionary (frame: TCU5_10, signal: GEAR_ACTUAL)
CAN_GEAR_ACTUAL = {
    "frame": "TCU5_10",
    "signal": "GEAR_ACTUAL",
    "frame_ID": 0x136,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x00,
    "MID": 0x01,
    "MAX": 0x05,
    "Default_Value": 0x0,
    # Test case values aligned to EDR samples
    "TestCase_6_values": [
        0x01, 0x02, 0x02, 0x05, 0x00, 0x01, 0x02, 0x05, 0x1,
        0x01, 0x02, 0x02, 0x05, 0x00, 0x01, 0x02, 0x05, 0x1,
        0x01, 0x02, 0x02
    ],
    "TestCase_6_Invalid_Values": [
        0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F,
        0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F,
        0x0F, 0x0F, 0x0F
    ],
    "TestCase_6_Reserved_Values": [
        0x07, 0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E,
        0x07, 0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E,
        0x07, 0x08, 0x09, 0x0B, 0x0C, 0x0D, 0x0E
    ],
    "EDR_Parameter": "GEAR_ACTUAL",
    # Fault logic
    "fault_logic": {
        "key_message": "TCU5_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("TCU"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("TCU"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("GEAR_ACTUAL"),
        "message_content_failure_dtcs": {}
    },
    "TestCase_6_OutofRange_Values": [0x03, 0x04, 0x06],
}


# ODOMTR_READING signal dictionary (frame: IC2_100, signal: ODOMTR_READING)
CAN_ODOMETER = {
    "frame": "IC2_100",
    "signal": "ODOMTR_READING",
    "frame_ID": 0x340,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": "km",
    "MIN": 0x000000,
    "MID": 0x000001,
    "MAX": 0xFFFFFF,
    "Default_Value": 0x0,
    # Simple incremental samples to exercise odometer updates around event
    "TestCase_8_values": [0x100, 0x1200, 0xF0000],
    "TestCase_8_Invalid_Values": [0xFFFFFF],
    # Out-of-range examples:
    # - 0x0F4240 (1,000,000) > logical max 999,999 but still within field size
    "TestCase_8_OutofRange_Values": [0x0F4240],
    "EDR_Parameter": "Odometer",
    # Fault logic
    "fault_logic": {
        "key_message": "IC2_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("ODOMTR_READING_IS"),
        "message_content_failure_dtcs": {}
    }
}

# BRK_PEDAL1 signal dictionary (frame: EMS21_10, signal: BRK_PEDAL1)
CAN_BRK_PDL = {
    "frame": "EMS21_10",
    "signal": "BRK_PEDAL1",
    "frame_ID": 0x127,
    "ch": 2,  # Channel, update if needed
    "periodicity": 10,  # ms, update if needed
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,   # 0 = Not pressed
    "MID": 0x1,   # 1 = Pressed 
    "MAX": 0x3,   # 3 = Fault (from JSON, max=3
    "Default_Value": 0x0,
    # Test case values aligned to EDR sample timeline (-5s to +3s at 0.5s)
    # 17 samples: Not pressed until -1s, pressed from -0.5s to +2s, released afterwards
    "TestCase_2_1_values": [
        0x0, 0x1, 0x0, 0x1, 0x0, 0x1, 0x0, 0x1, 0x0,  # -5.0s .. -1.0s (9 samples)
        0x1, 0x0, 0x1, 0x0, 0x1,                      # -0.5s .. +2.0s (5 samples, total 14)
        0x0, 0x1, 0x0                                 # +2.5s .. +3.0s (3 samples, total 17)
    ],
    # Keep an additional simple cycling set if needed elsewhere
    "TestCase_2_1_Invalid":  0x3,
    "TestCase_2_1_Reserved_Values": 0x2,
    "EDR_Parameter": "BRAKE_PEDAL_VALUE",
    
    # Fault logic
    "fault_logic": {
        "key_message": "EMS21_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("BRK_PEDAL1"),
        "message_content_failure_dtcs": {
            "EMS21_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_MSG_CNT"),
            "EMS21_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_CRC"),
        }
    },
    "TestCase_2_values": [0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01],
    "TestCase_2_Invalid_Values": 0x03,
    "TestCase_2_OutofRange_Values": 0x02,
}


# VEHICLE_SPEED signal dictionary (frame: ESC12_10, signal: VEHICLE_SPEED_ESC12)
CAN_VEHICLE_SPEED = {
    "frame": "ESC12_10",
    "signal": "VEHICLE_SPEED_ESC12",
    "frame_ID": 0x282,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.015625,
    "Offset": 0,
    "UNIT": "kmph",
    "MIN": 0x0000,          # 0 kmph
    "MID": 0x2580,          # 150 kmph -> 150*64 = 9600 (0x2580)
    "MAX": 0x4B00,          # 300 kmph -> 300*64 = 19200 (0x4B00)
    "Default_Value": 0xFFFE,
    # TestCase_1_values are RAW 16-bit counts; physical [kmph] = raw * 0.015625
    # Physical sequence approx: [0.0, 20.0, 40.0, 60.0, 80.0, 100.0, 120.0, 140.0,
    # 160.0, 180.0, 200.0, 150.0, 120.0, 80.0, 40.0, 20.0, 0.0]
    "TestCase_1_values": [
        0x03E00, 0x0500, 0x0A00, 0x0F00, 0x1400, 0x1900, 0x1E00, 0x2300, 0x2800, 0x2D00, 0x3200, 0x2580, 0x1E00, 0x1400, 0x0A00, 0x0500, 0x0C80
    ],
    # Invalid raw 16-bit values
    "TestCase_1_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF
    ],
    # Out-of-range raw 16-bit values for vehicle speed (physical=500.0 kmph)
    "TestCase_1_OutofRange_Values": [
        0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00,
        0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00, 0x7D00,
        0x7D00
    ],
    "EDR_Parameter": "VehSpdLgt",
    # Fault logic
    "fault_logic": {
        "key_message": "ESC12_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("VEHICLE_SPEED_ESC12"),
        "message_content_failure_dtcs": {
            "ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"),
            "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC"),
        },
        # Frame to disable for message-timeout scenario tests (e.g., 1.2)
        "non_key_timeout_frame": "EMS36_10",
    }
}


# Additional signal dictionaries (JSON-backed)

# RESERVED_2 signal dictionary (frame: MBFM_SLEEP, signal: RESERVED_2)
CAN_RESERVED_2_MBFM_SLEEP = {
    "frame": "MBFM_SLEEP",
    "signal": "RESERVED_2",
    "frame_ID": 0x3C4,
    "ch": 2,
    "periodicity": None,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 1.8446744074e19,
    "Default_Value": 0x0,
    "EDR_Parameter": "RESERVED_2",
    "fault_logic": {
        "key_message": "MBFM_SLEEP",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# RESERVED_2 signal dictionary (frame: MBFM_ACTIVE, signal: RESERVED_2)
CAN_RESERVED_2_MBFM_ACTIVE = {
    "frame": "MBFM_ACTIVE",
    "signal": "RESERVED_2",
    "frame_ID": 0x3C1,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 1.8446744074e19,
    "Default_Value": 0x0,
    "EDR_Parameter": "RESERVED_2",
    "fault_logic": {
        "key_message": "MBFM_ACTIVE",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# MBFM_WAKEUP_REASON signal dictionary (frame: MBFM_WAKEUP, signal: MBFM_WAKEUP_REASON)
CAN_MBFM_WAKEUP_REASON = {
    "frame": "MBFM_WAKEUP",
    "signal": "MBFM_WAKEUP_REASON",
    "frame_ID": 0x97,
    "ch": 2,
    "periodicity": 20,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFFFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "MBFM_WAKEUP_REASON",
    "fault_logic": {
        "key_message": "MBFM_WAKEUP",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_DOOR signal dictionary (frame: MBFM1_100, signal: STS_DOOR)
CAN_STS_DOOR = {
    "frame": "MBFM1_100",
    "signal": "STS_DOOR",
    "frame_ID": 0x348,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3F,
    "Default_Value": 0x0,
    "TestCase_1_values": [0x01],
    "TestCase_3_values": [0x01],
    "TestCase_11_values": [0x01],
    "EDR_Parameter": "DoorsOpenStatus",
    "fault_logic": {
        "key_message": "MBFM1_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_HIGH_BEAM signal dictionary (frame: MBFM1_100, signal: STS_HIGH_BEAM)
CAN_STS_HIGH_BEAM = {
    "frame": "MBFM1_100",
    "signal": "STS_HIGH_BEAM",
    "frame_ID": 0x348,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "TestCase_36_values": [0x00, 0x01, 0x00, 0x01, 0x00, 0x01],
    "EDR_Parameter": "STS_HIGH_BEAM",
    "fault_logic": {
        "key_message": "MBFM1_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_LOW_BEAM signal dictionary (frame: MBFM1_100, signal: STS_LOW_BEAM)
CAN_STS_LOW_BEAM = {
    "frame": "MBFM1_100",
    "signal": "STS_LOW_BEAM",
    "frame_ID": 0x348,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "TestCase_37_values": [0x00, 0x01, 0x00, 0x01, 0x00, 0x01],
    "EDR_Parameter": "STS_LOW_BEAM",
    "fault_logic": {
        "key_message": "MBFM1_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_DOOR_LATCH signal dictionary (frame: MBFM5_100, signal: STS_DOOR_LATCH)
CAN_STS_DOOR_LATCH = {
    "frame": "MBFM5_100",
    "signal": "STS_DOOR_LATCH",
    "frame_ID": 0x214,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "Invalid_Value": 0x3,
    "TestCase_1_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00,
        0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
    ],
    "TestCase_16_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00,
        0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
    ],
    "TestCase_16_OutofRange_Values": [
        0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
        0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02
    ],
    "TestCase_16_Invalid_Values": [
        0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
        0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03
    ],
    "EDR_Parameter": "Door Lock Status",
    "fault_logic": {
        "key_message": "MBFM5_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_TPMS_LED signal dictionary (frame: MBFM5_100, signal: STS_TPMS_LED)
CAN_STS_TPMS_LED = {
    "frame": "MBFM5_100",
    "signal": "STS_TPMS_LED",
    "frame_ID": 0x214,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "TestCase_15_values": [0x00, 0x01, 0x02, 0x03, 0x00, 0x01],
    "EDR_Parameter": "STS_TPMS_LED",
    "fault_logic": {
        "key_message": "MBFM5_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_15_OutofRange_Values": [0x04, 0x05, 0x06, 0x07],
}

# FL_TYRE_PRESSURE signal dictionary (frame: MBFM6_100, signal: FL_TYRE_PRESSURE)
CAN_FL_TYRE_PRESSURE = {
    "frame": "MBFM6_100",
    "signal": "FL_TYRE_PRESSURE",
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": "Psi",
    "MIN": 0x0,
    "MAX": 0xFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFF,
    "TestCase_42_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_42_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "EDR_Parameter": "Tyre_Pressure_FL",
    "fault_logic": {
        "key_message": "MBFM6_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FL_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# FR_TYRE_PRESSURE signal dictionary (frame: MBFM6_100, signal: FR_TYRE_PRESSURE)
CAN_FR_TYRE_PRESSURE = {
    "frame": "MBFM6_100",
    "signal": "FR_TYRE_PRESSURE",
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": "Psi",
    "MIN": 0x0,
    "MAX": 0xFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFF,
    "TestCase_43_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_43_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "EDR_Parameter": "Tyre_Pressure_FR",
    "fault_logic": {
        "key_message": "MBFM6_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("FR_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# RL_TYRE_PRESSURE signal dictionary (frame: MBFM6_100, signal: RL_TYRE_PRESSURE)
CAN_RL_TYRE_PRESSURE = {
    "frame": "MBFM6_100",
    "signal": "RL_TYRE_PRESSURE",
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": "Psi",
    "MIN": 0x0,
    "MAX": 0xFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFF,
    "TestCase_44_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_44_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "EDR_Parameter": "Tyre_Pressure_RL",
    "fault_logic": {
        "key_message": "MBFM6_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RL_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# RR_TYRE_PRESSURE signal dictionary (frame: MBFM6_100, signal: RR_TYRE_PRESSURE)
CAN_RR_TYRE_PRESSURE = {
    "frame": "MBFM6_100",
    "signal": "RR_TYRE_PRESSURE",
    "frame_ID": 0x218,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": "Psi",
    "MIN": 0x0,
    "MAX": 0xFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFF,
    "TestCase_45_values": [0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0, 0xE0, 0xFE],
    "TestCase_45_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "EDR_Parameter": "Tyre_Pressure_RR",
    "fault_logic": {
        "key_message": "MBFM6_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("RR_TYRE_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# BATT_VOLT signal dictionary (frame: MBFM7_100, signal: BATT_VOLT)
CAN_BATT_VOLT = {
    "frame": "MBFM7_100",
    "signal": "BATT_VOLT",
    "frame_ID": 0x21C,
    "ch": 2,
    "periodicity": 100,
    "Factor": 0.25,
    "Offset": 0,
    "UNIT": "V",
    "MIN": 0x0,
    "MAX": 0xFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFF,
    "TestCase_51_values": [0x00, 0x19, 0x32, 0x4B, 0x64, 0x7D, 0x96, 0xAF, 0xC8, 0xE1, 0xFE],
    "TestCase_51_Invalid_Values": [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
    "EDR_Parameter": "BATT_VOLT",
    "fault_logic": {
        "key_message": "MBFM7_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("MBFM"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("MBFM"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# ADAS_DES_STRWHL_ANGLE_CMD1 signal dictionary (frame: HPCAd_31_10, signal: ADAS_DES_STRWHL_ANGLE_CMD1)
CAN_ADAS_DES_STRWHL_ANGLE_CMD1 = {
    "frame": "HPCAd_31_10",
    "signal": "ADAS_DES_STRWHL_ANGLE_CMD1",
    "frame_ID": 0x14C,
    "ch": 2,
    "periodicity": 10,
    "Factor": 0.1,
    "Offset": -720,
    "UNIT": "deg",
    "MIN": 0x0,
    "MAX": 0x3840,
    "Default_Value": 0x0,
    "Invalid_Value": 0x7FFF,
    "TestCase_50_values": [
        0x0000, 0x05A0, 0x0B40, 0x10E0, 0x1680, 0x1C20,
        0x21C0, 0x2760, 0x2D00, 0x32A0, 0x3840
    ],
    "TestCase_50_Invalid_Values": [
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF,
        0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF
    ],
    "EDR_Parameter": "ADAS_Des_StrWhl_Angle_Cmd",
    "fault_logic": {
        "key_message": "HPCAd_31_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# AEB_WARNING_MSG1 signal dictionary (frame: HPCAd_33_50, signal: AEB_WARNING_MSG1)
CAN_AEB_WARNING_MSG1 = {
    "frame": "HPCAd_33_50",
    "signal": "AEB_WARNING_MSG1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "TestCase_1_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00
    ],
    "TestCase_18_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00
    ],
    "EDR_Parameter": "AEB_WARNING_MSG1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_18_OutofRange_Values": [0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x05, 0x06, 0x07, 0x08, 0x09],
}

# NP_SYS_STS1 signal dictionary (frame: HPCAd_33_50, signal: NP_SYS_STS1)
CAN_NP_SYS_STS1 = {
    "frame": "HPCAd_33_50",
    "signal": "NP_SYS_STS1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "TestCase_29_values": [
        0x00, 0x01, 0x02, 0x00, 0x01, 0x02, 0x00, 0x01, 0x02, 0x00,
        0x01
    ],
    "EDR_Parameter": "NP_SYS_STS1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_29_OutofRange_Values": [0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09],
}

# AES_SYS_STS1 signal dictionary (frame: HPCAd_33_50, signal: AES_SYS_STS1)
CAN_AES_SYS_STS1 = {
    "frame": "HPCAd_33_50",
    "signal": "AES_SYS_STS1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x6,
    "Default_Value": 0x0,
    "TestCase_21_values": [
        0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x00, 0x01, 0x02,
        0x03, 0x05, 0x06, 0x07, 0x00, 0x01, 0x02, 0x03, 0x05, 0x06,
        0x07
    ],
    "EDR_Parameter": "AES_SYS_STS1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_21_OutofRange_Values": 0x04,
}

# AES_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: AES_WARNING1)
CAN_AES_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "AES_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_20_values": [
        0x00, 0x03, 0x04, 0x00, 0x03, 0x04, 0x00, 0x03, 0x04, 0x00,
        0x03, 0x04, 0x00, 0x03, 0x04, 0x00, 0x03, 0x04, 0x00, 0x03,
        0x04
    ],
    "EDR_Parameter": "AES_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_20_OutofRange_Values": [0x01, 0x02, 0x05, 0x06, 0x07],
}

# AEB_FCTA_WARN1 signal dictionary (frame: HPCAd_33_50, signal: AEB_FCTA_WARN1)
CAN_AEB_FCTA_WARN1 = {
    "frame": "HPCAd_33_50",
    "signal": "AEB_FCTA_WARN1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "TestCase_19_values": [
        0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03, 0x00, 0x01,
        0x02
    ],
    "EDR_Parameter": "AEB_FCTA_WARN",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# ESA_SYS_STS1 signal dictionary (frame: HPCAd_33_50, signal: ESA_SYS_STS1)
CAN_ESA_SYS_STS1 = {
    "frame": "HPCAd_33_50",
    "signal": "ESA_SYS_STS1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_22_values": [
        0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x00, 0x01, 0x02,
        0x03, 0x05, 0x06, 0x07, 0x00, 0x01, 0x02, 0x03, 0x05, 0x06,
        0x07
    ],
    "EDR_Parameter": "ESA_SYS_STS1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_22_OutofRange_Values": 0x04,
}

# ELK_ONCOMING_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: ELK_ONCOMING_WARNING1)
CAN_ELK_ONCOMING_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "ELK_ONCOMING_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_32_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00
    ],
    "EDR_Parameter": "ELK_ONCOMING_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# LDW_LKA_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: LDW_LKA_WARNING1)
CAN_LDW_LKA_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "LDW_LKA_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "TestCase_23_values": [
        0x00, 0x01, 0x02, 0x00, 0x01, 0x02, 0x00, 0x01, 0x02, 0x00,
        0x01
    ],
    "EDR_Parameter": "LDW_LKA_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# ELK_OVERTAKING_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: ELK_OVERTAKING_WARNING1)
CAN_ELK_OVERTAKING_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "ELK_OVERTAKING_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_34_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00
    ],
    "EDR_Parameter": "ELK_OVERTAKING_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# ELK_SIDE_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: ELK_SIDE_WARNING1)
CAN_ELK_SIDE_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "ELK_SIDE_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_33_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x01, 0x02, 0x03, 0x04,
        0x00
    ],
    "EDR_Parameter": "ELK_SIDE_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# LKA_HANDSOFF_DISPLAY_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: LKA_HANDSOFF_DISPLAY_WARNING1)
CAN_LKA_HANDSOFF_DISPLAY_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "LKA_HANDSOFF_DISPLAY_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "TestCase_25_values": [0x00, 0x01, 0x00, 0x01, 0x00, 0x01],
    "EDR_Parameter": "LKA_HANDSOFF_DISPLAY_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# LC_PATH_STATE1 signal dictionary (frame: HPCAd_33_50, signal: LC_PATH_STATE1)
CAN_LC_PATH_STATE1 = {
    "frame": "HPCAd_33_50",
    "signal": "LC_PATH_STATE1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_31_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02
    ],
    "EDR_Parameter": "LC_PATH_STATE1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# LCF_SYS_STATE1 signal dictionary (frame: HPCAd_33_50, signal: LCF_SYS_STATE1)
CAN_LCF_SYS_STATE1 = {
    "frame": "HPCAd_33_50",
    "signal": "LCF_SYS_STATE1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_26_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02
    ],
    "EDR_Parameter": "LCF_SYS_STATE1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# SPA_LCF_HANDS_OFF_WARNING1 signal dictionary (frame: HPCAd_33_50, signal: SPA_LCF_HANDS_OFF_WARNING1)
CAN_SPA_LCF_HANDS_OFF_WARNING1 = {
    "frame": "HPCAd_33_50",
    "signal": "SPA_LCF_HANDS_OFF_WARNING1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "TestCase_28_values": [
        0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03, 0x00, 0x01,
        0x02
    ],
    "EDR_Parameter": "SPA_LCF_HANDS_OFF_WARNING1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# LDW_LKA_SYS_STATE1 signal dictionary (frame: HPCAd_33_50, signal: LDW_LKA_SYS_STATE1)
CAN_LDW_LKA_SYS_STATE1 = {
    "frame": "HPCAd_33_50",
    "signal": "LDW_LKA_SYS_STATE1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_24_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02
    ],
    "EDR_Parameter": "LDW_LKA_SYS_STATE1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# SPA_SYS_STATE1 signal dictionary (frame: HPCAd_33_50, signal: SPA_SYS_STATE1)
CAN_SPA_SYS_STATE1 = {
    "frame": "HPCAd_33_50",
    "signal": "SPA_SYS_STATE1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_27_values": [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01, 0x02, 0x03,
        0x04, 0x05, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x00, 0x01,
        0x02
    ],
    "EDR_Parameter": "SPA_SYS_STATE1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# RMS_MODE_STATE1 signal dictionary (frame: HPCAd_33_50, signal: RMS_MODE_STATE1)
CAN_RMS_MODE_STATE1 = {
    "frame": "HPCAd_33_50",
    "signal": "RMS_MODE_STATE1",
    "frame_ID": 0x2C5,
    "ch": 2,
    "periodicity": 50,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "TestCase_30_values": [
        0x00, 0x01, 0x02, 0x03, 0x05, 0x00, 0x01, 0x02, 0x03, 0x05,
        0x00, 0x01, 0x02, 0x03, 0x05, 0x00, 0x01, 0x02, 0x03, 0x05,
        0x00
    ],
    "EDR_Parameter": "RMS_MODE_STATE1",
    "fault_logic": {
        "key_message": "HPCAd_33_50",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("HPCAD"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("HPCAD"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    },
    "TestCase_30_OutofRange_Values": [0x04, 0x06],
}

# ESC12_MSG_CNT signal dictionary (frame: ESC12_10, signal: ESC12_MSG_CNT)
CAN_ESC12_MSG_CNT = {
    "frame": "ESC12_10",
    "signal": "ESC12_MSG_CNT",
    "frame_ID": 0x282,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "ESC12_MSG_CNT",
    "fault_logic": {
        "key_message": "ESC12_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"),
            "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC"),
        },
    }
}

# ESC12_CRC signal dictionary (frame: ESC12_10, signal: ESC12_CRC)
CAN_ESC12_CRC = {
    "frame": "ESC12_10",
    "signal": "ESC12_CRC",
    "frame_ID": 0x282,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "ESC12_CRC",
    "fault_logic": {
        "key_message": "ESC12_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC12_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_MSG_CNT"),
            "ESC12_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC12_CRC"),
        },
    }
}

# SAS_MSG_CNT signal dictionary (frame: EPS_SAS1_10, signal: SAS_MSG_CNT)
CAN_SAS_MSG_CNT = {
    "frame": "EPS_SAS1_10",
    "signal": "SAS_MSG_CNT",
    "frame_ID": 0x114,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "SAS_MSG_CNT",
    "fault_logic": {
        "key_message": "EPS_SAS1_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_CRC"),
        },
    }
}

# SAS_CRC signal dictionary (frame: EPS_SAS1_10, signal: SAS_CRC)
CAN_SAS_CRC = {
    "frame": "EPS_SAS1_10",
    "signal": "SAS_CRC",
    "frame_ID": 0x114,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "SAS_CRC",
    "fault_logic": {
        "key_message": "EPS_SAS1_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("SAS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("SAS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "SAS_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_MSG_CNT"),
            "SAS_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("SAS_CRC"),
        },
    }
}

# EMS36_MSG_CNT signal dictionary (frame: EMS36_10, signal: EMS36_MSG_CNT)
CAN_EMS36_MSG_CNT = {
    "frame": "EMS36_10",
    "signal": "EMS36_MSG_CNT",
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "EMS36_MSG_CNT",
    "fault_logic": {
        "key_message": "EMS36_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        }
    }
}

# EMS36_CRC signal dictionary (frame: EMS36_10, signal: EMS36_CRC)
CAN_EMS36_CRC = {
    "frame": "EMS36_10",
    "signal": "EMS36_CRC",
    "frame_ID": 0x142,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "EMS36_CRC",
    "fault_logic": {
        "key_message": "EMS36_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "EMS36_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_MSG_CNT"),
            "EMS36_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS36_CRC"),
        }
    }
}

# EMS21_MSG_CNT signal dictionary (frame: EMS21_10, signal: EMS21_MSG_CNT)
CAN_EMS21_MSG_CNT = {
    "frame": "EMS21_10",
    "signal": "EMS21_MSG_CNT",
    "frame_ID": 0x127,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "EMS21_MSG_CNT",
    "fault_logic": {
        "key_message": "EMS21_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "EMS21_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_MSG_CNT"),
            "EMS21_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_CRC"),
        }
    }
}

# EMS21_CRC signal dictionary (frame: EMS21_10, signal: EMS21_CRC)
CAN_EMS21_CRC = {
    "frame": "EMS21_10",
    "signal": "EMS21_CRC",
    "frame_ID": 0x127,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "EMS21_CRC",
    "fault_logic": {
        "key_message": "EMS21_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "EMS21_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_MSG_CNT"),
            "EMS21_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("EMS21_CRC"),
        }
    }
}

# VIN_DATA_2 signal dictionary (frame: EMS5_500, signal: VIN_DATA_2)
CAN_VIN_DATA_2 = {
    "frame": "EMS5_500",
    "signal": "VIN_DATA_2",
    "frame_ID": 0x3C0,
    "ch": 2,
    "periodicity": 500,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFFFFFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "VIN_DATA_2",
    "fault_logic": {
        "key_message": "EMS5_500",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# VIN_DATA_1 signal dictionary (frame: EMS5_500, signal: VIN_DATA_1)
CAN_VIN_DATA_1 = {
    "frame": "EMS5_500",
    "signal": "VIN_DATA_1",
    "frame_ID": 0x3C0,
    "ch": 2,
    "periodicity": 500,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 7.2057594038,
    "Default_Value": 0x0,
    "EDR_Parameter": "VIN_DATA_1",
    "fault_logic": {
        "key_message": "EMS5_500",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# VIN_DATA_0 signal dictionary (frame: EMS5_500, signal: VIN_DATA_0)
CAN_VIN_DATA_0 = {
    "frame": "EMS5_500",
    "signal": "VIN_DATA_0",
    "frame_ID": 0x3C0,
    "ch": 2,
    "periodicity": 500,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 7.2057594038,
    "Default_Value": 0x0,
    "EDR_Parameter": "VIN_DATA_0",
    "fault_logic": {
        "key_message": "EMS5_500",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# VIN_INDEX signal dictionary (frame: EMS5_500, signal: VIN_INDEX)
CAN_VIN_INDEX = {
    "frame": "EMS5_500",
    "signal": "VIN_INDEX",
    "frame_ID": 0x3C0,
    "ch": 2,
    "periodicity": 500,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "Invalid_Value": 0x3,
    "EDR_Parameter": "VIN_INDEX",
    "fault_logic": {
        "key_message": "EMS5_500",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# DISP_AMBT_TEMP_EMS signal dictionary (frame: EMS6_500, signal: DISP_AMBT_TEMP_EMS)
CAN_DISP_AMBT_TEMP_EMS = {
    "frame": "EMS6_500",
    "signal": "DISP_AMBT_TEMP_EMS",
    "frame_ID": 0x308,
    "ch": 2,
    "periodicity": 500,
    "Factor": 1,
    "Offset": -40,
    "UNIT": "deg C.",
    "MIN": 0x0,
    "MAX": 0xFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFF,
    "EDR_Parameter": "DISP_AMBT_TEMP_EMS",
    "fault_logic": {
        "key_message": "EMS6_500",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("DISP_AMBT_TEMP_EMS"),
        "message_content_failure_dtcs": {},
    }
}

# INDC_CRUISE signal dictionary (frame: EMS1_10, signal: INDC_CRUISE)
CAN_INDC_CRUISE = {
    "frame": "EMS1_10",
    "signal": "INDC_CRUISE",
    "frame_ID": 0x124,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "Invalid_Value": 0x3,
    "EDR_Parameter": "INDC_CRUISE",
    "fault_logic": {
        "key_message": "EMS1_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# CURRENT_GEAR_MT signal dictionary (frame: EMS1_10, signal: CURRENT_GEAR_MT)
CAN_CURRENT_GEAR_MT = {
    "frame": "EMS1_10",
    "signal": "CURRENT_GEAR_MT",
    "frame_ID": 0x124,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "Invalid_Value": 0xF,
    "EDR_Parameter": "CURRENT_GEAR_MT",
    "fault_logic": {
        "key_message": "EMS1_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CURRENT_GEAR_MT"),
        "message_content_failure_dtcs": {},
    }
}

# CLUTCH_STS signal dictionary (frame: EMS3_10, signal: CLUTCH_STS)
CAN_CLUTCH_STS = {
    "frame": "EMS3_10",
    "signal": "CLUTCH_STS",
    "frame_ID": 0x108,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x7,
    "Default_Value": 0x0,
    "Invalid_Value": 0x7,
    "TestCase_1_values": [0x00, 0x01, 0x02, 0x03, 0x04, 0x05],
    "TestCase_12_Invalid_Values": [0x07, 0x07, 0x07, 0x07, 0x07, 0x07],
    "EDR_Parameter": "CLUTCH_STS",
    "fault_logic": {
        "key_message": "EMS3_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("EMS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("EMS"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("CLUTCH_STS"),
        "message_content_failure_dtcs": {},
    },
    "TestCase_12_values": [0x00, 0x01, 0x02, 0x00, 0x01, 0x02],
    "TestCase_12_OutofRange_Values": [0x03, 0x04, 0x05, 0x06],
}

# PSGR_AIRBAG_SW_IC signal dictionary (frame: IC2_100, signal: PSGR_AIRBAG_SW_IC)
CAN_PSGR_AIRBAG_SW_IC = {
    "frame": "IC2_100",
    "signal": "PSGR_AIRBAG_SW_IC",
    "frame_ID": 0x340,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "EDR_Parameter": "PSGR_AIRBAG_SW_IC",
    "fault_logic": {
        "key_message": "IC2_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# DRL_EN_SW signal dictionary (frame: IS1_100, signal: DRL_EN_SW)
CAN_DRL_EN_SW = {
    "frame": "IS1_100",
    "signal": "DRL_EN_SW",
    "frame_ID": 0x220,
    "ch": 2,
    "periodicity": 100,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "EDR_Parameter": "DRL_EN_SW",
    "fault_logic": {
        "key_message": "IS1_100",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("IS"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("IS"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# MASTER_CYL_PRESSURE signal dictionary (frame: ESC10_20, signal: MASTER_CYL_PRESSURE)
CAN_MASTER_CYL_PRESSURE = {
    "frame": "ESC10_20",
    "signal": "MASTER_CYL_PRESSURE",
    "frame_ID": 0x171,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.05,
    "Offset": -40,
    "UNIT": "Bar",
    "MIN": 0x0,
    "MAX": 0x2260,
    "Default_Value": 0xFFFE,
    "Invalid_Value": 0xFFFF,
    "TestCase_46_values": [
        0x0000, 0x0226, 0x044C, 0x0672, 0x0898, 0x0ABE, 0x0CE4, 0x0F0A,
        0x1130, 0x1356, 0x157C, 0x17A2, 0x19C8, 0x1BEE, 0x1E14, 0x203A,
        0x2260
    ],
    "TestCase_46_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF
    ],
    "EDR_Parameter": "Master_Cylinder_Pressure",
    "fault_logic": {
        "key_message": "ESC10_20",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("MASTER_CYL_PRESSURE"),
        "message_content_failure_dtcs": {},
    }
}

# LATTERAL_ACCEL signal dictionary (frame: ESC7_20, signal: LATTERAL_ACCEL)
CAN_LATTERAL_ACCEL = {
    "frame": "ESC7_20",
    "signal": "LATTERAL_ACCEL",
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.000127465,
    "Offset": -4.1768,
    "UNIT": "g",
    "MIN": 0x0,
    "MAX": 0xFFFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFFFF,
    "TestCase_48_values": [
        0x0000, 0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000,
        0x8000, 0x9000, 0xA000, 0xB000, 0xC000, 0xD000, 0xE000, 0xF000,
        0xFFFD
    ],
    "TestCase_48_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF
    ],
    "EDR_Parameter": "LATERAL_ACCEL",
    "fault_logic": {
        "key_message": "ESC7_20",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LATTERAL_ACCEL"),
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    }
}

# LONG_ACCEL signal dictionary (frame: ESC7_20, signal: LONG_ACCEL)
CAN_LONG_ACCEL = {
    "frame": "ESC7_20",
    "signal": "LONG_ACCEL",
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.000127465,
    "Offset": -4.1768,
    "UNIT": "g",
    "MIN": 0x0,
    "MAX": 0xFFFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFFFF,
    "TestCase_49_values": [
        0x0000, 0x1000, 0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000,
        0x8000, 0x9000, 0xA000, 0xB000, 0xC000, 0xD000, 0xE000, 0xF000,
        0xFFFD
    ],
    "TestCase_49_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF
    ],
    "EDR_Parameter": "LONG_ACCEL",
    "fault_logic": {
        "key_message": "ESC7_20",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("LONG_ACCEL"),
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    }
}

# YAW_RATE signal dictionary (frame: ESC7_20, signal: YAW_RATE)
CAN_YAW_RATE = {
    "frame": "ESC7_20",
    "signal": "YAW_RATE",
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 0.005,
    "Offset": -163.84,
    "UNIT": "deg/sec",
    "MIN": 0x0,
    "MAX": 0xFFFE,
    "Default_Value": 0x0,
    "Invalid_Value": 0xFFFF,
    "TestCase_47_values": [
        0x0000, 0x12A0, 0x2240, 0x39B0, 0x5120, 0x6890, 0x7830, 0x7F38,
        0x8000, 0x80C8, 0x87D0, 0x9770, 0xAEE0, 0xC650, 0xDDC0, 0xED60,
        0xFFFE
    ],
    "TestCase_47_Invalid_Values": [
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
        0xFFFF
    ],
    "EDR_Parameter": "YAW_RATE",
    "fault_logic": {
        "key_message": "ESC7_20",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": CAN_SIGNAL_CONTENT_FAILURE_DTC.get("YAW_RATE"),
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    }
}

# ESC7_MSG_CNT signal dictionary (frame: ESC7_20, signal: ESC7_MSG_CNT)
CAN_ESC7_MSG_CNT = {
    "frame": "ESC7_20",
    "signal": "ESC7_MSG_CNT",
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "ESC7_MSG_CNT",
    "fault_logic": {
        "key_message": "ESC7_20",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    }
}

# ESC7_CRC signal dictionary (frame: ESC7_20, signal: ESC7_CRC)
CAN_ESC7_CRC = {
    "frame": "ESC7_20",
    "signal": "ESC7_CRC",
    "frame_ID": 0x170,
    "ch": 2,
    "periodicity": 20,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "ESC7_CRC",
    "fault_logic": {
        "key_message": "ESC7_20",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC7_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_MSG_CNT"),
            "ESC7_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC7_CRC"),
        }
    }
}

# ESC_ACTIVE signal dictionary (frame: ESC5_10, signal: ESC_ACTIVE)
CAN_ESC_ACTIVE = {
    "frame": "ESC5_10",
    "signal": "ESC_ACTIVE",
    "frame_ID": 0x10D,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "TestCase_14_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00,
        0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
    ],
    "EDR_Parameter": "ESC_ACTIVE",
    "fault_logic": {
        "key_message": "ESC5_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        },
    }
}

# ABS_ACTIVE signal dictionary (frame: ESC5_10, signal: ABS_ACTIVE)
CAN_ABS_ACTIVE = {
    "frame": "ESC5_10",
    "signal": "ABS_ACTIVE",
    "frame_ID": 0x10D,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "TestCase_13_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00,
        0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
    ],
    "EDR_Parameter": "ABS_ACTIVE",
    "fault_logic": {
        "key_message": "ESC5_10",
        "non_key_timeout_frame": "ESC2_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        },
    }
}

# STS_ESC signal dictionary (frame: ESC5_10, signal: STS_ESC)
CAN_STS_ESC = {
    "frame": "ESC5_10",
    "signal": "STS_ESC",
    "frame_ID": 0x10D,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x3,
    "Default_Value": 0x0,
    "EDR_Parameter": "STS_ESC",
    "fault_logic": {
        "key_message": "ESC5_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        },
    }
}

# ESC5_MSG_CNT signal dictionary (frame: ESC5_10, signal: ESC5_MSG_CNT)
CAN_ESC5_MSG_CNT = {
    "frame": "ESC5_10",
    "signal": "ESC5_MSG_CNT",
    "frame_ID": 0x10D,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xF,
    "Default_Value": 0x0,
    "EDR_Parameter": "ESC5_MSG_CNT",
    "fault_logic": {
        "key_message": "ESC5_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        },
    }
}

# ESC5_CRC signal dictionary (frame: ESC5_10, signal: ESC5_CRC)
CAN_ESC5_CRC = {
    "frame": "ESC5_10",
    "signal": "ESC5_CRC",
    "frame_ID": 0x10D,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0xFF,
    "Default_Value": 0x0,
    "EDR_Parameter": "ESC5_CRC",
    "fault_logic": {
        "key_message": "ESC5_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {
            "ESC5_MSG_CNT": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_MSG_CNT"),
            "ESC5_CRC": CAN_MESSAGE_CONTENT_FAILURE_DTC.get("ESC5_CRC"),
        },
    }
}

# STS_ABS signal dictionary (frame: ESC2_10, signal: STS_ABS)
CAN_STS_ABS = {
    "frame": "ESC2_10",
    "signal": "STS_ABS",
    "frame_ID": 0x2CC,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "EDR_Parameter": "STS_ABS",
    "fault_logic": {
        "key_message": "ESC2_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# TCS_ACTIVE signal dictionary (frame: ESC2_10, signal: TCS_ACTIVE)
CAN_TCS_ACTIVE = {
    "frame": "ESC2_10",
    "signal": "TCS_ACTIVE",
    "frame_ID": 0x2CC,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "TestCase_17_values": [
        0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00,
        0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
    ],
    "EDR_Parameter": "TCS_ACTIVE_IEB",
    "fault_logic": {
        "key_message": "ESC2_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}

# STS_TCS signal dictionary (frame: ESC2_10, signal: STS_TCS)
CAN_STS_TCS = {
    "frame": "ESC2_10",
    "signal": "STS_TCS",
    "frame_ID": 0x2CC,
    "ch": 2,
    "periodicity": 10,
    "Factor": 1,
    "Offset": 0,
    "UNIT": None,
    "MIN": 0x0,
    "MAX": 0x1,
    "Default_Value": 0x0,
    "EDR_Parameter": "STS_TCS",
    "fault_logic": {
        "key_message": "ESC2_10",
        "fault_type": "message_timeout",
        "node_absent_dtc": CAN_NODE_ABSENT_DTC.get("ESC"),
        "message_timeout_dtc": CAN_MESSAGE_TIMEOUT_DTC.get("ESC"),
        "signal_content_failure_dtc": None,
        "message_content_failure_dtcs": {},
    }
}


MAH_CAN_SIGNAL_DEFS = {
    "ACC_PED1": CAN_ACC_PED,
    "ABSOLUTE_ANGLE": CAN_ABSOLUTE_ANGLE,
    "ENG_SPD1": CAN_MOTOR_SPD,
    "BRK_PEDAL1": CAN_BRK_PDL,
    "VEHICLE_SPEED_ESC12": CAN_VEHICLE_SPEED,
    "GEAR_ACTUAL": CAN_GEAR_ACTUAL,
    "ODOMTR_READING": CAN_ODOMETER,
    "RESERVED_2_MBFM_SLEEP": CAN_RESERVED_2_MBFM_SLEEP,
    "RESERVED_2_MBFM_ACTIVE": CAN_RESERVED_2_MBFM_ACTIVE,
    "MBFM_WAKEUP_REASON": CAN_MBFM_WAKEUP_REASON,
    "STS_DOOR": CAN_STS_DOOR,
    "STS_HIGH_BEAM": CAN_STS_HIGH_BEAM,
    "STS_LOW_BEAM": CAN_STS_LOW_BEAM,
    "STS_DOOR_LATCH": CAN_STS_DOOR_LATCH,
    "STS_TPMS_LED": CAN_STS_TPMS_LED,
    "FL_TYRE_PRESSURE": CAN_FL_TYRE_PRESSURE,
    "FR_TYRE_PRESSURE": CAN_FR_TYRE_PRESSURE,
    "RL_TYRE_PRESSURE": CAN_RL_TYRE_PRESSURE,
    "RR_TYRE_PRESSURE": CAN_RR_TYRE_PRESSURE,
    "BATT_VOLT": CAN_BATT_VOLT,
    "ADAS_DES_STRWHL_ANGLE_CMD1": CAN_ADAS_DES_STRWHL_ANGLE_CMD1,
    "AEB_WARNING_MSG1": CAN_AEB_WARNING_MSG1,
    "NP_SYS_STS1": CAN_NP_SYS_STS1,
    "AES_SYS_STS1": CAN_AES_SYS_STS1,
    "AES_WARNING1": CAN_AES_WARNING1,
    "AEB_FCTA_WARN1": CAN_AEB_FCTA_WARN1,
    "ESA_SYS_STS1": CAN_ESA_SYS_STS1,
    "ELK_ONCOMING_WARNING1": CAN_ELK_ONCOMING_WARNING1,
    "LDW_LKA_WARNING1": CAN_LDW_LKA_WARNING1,
    "ELK_OVERTAKING_WARNING1": CAN_ELK_OVERTAKING_WARNING1,
    "ELK_SIDE_WARNING1": CAN_ELK_SIDE_WARNING1,
    "LKA_HANDSOFF_DISPLAY_WARNING1": CAN_LKA_HANDSOFF_DISPLAY_WARNING1,
    "LC_PATH_STATE1": CAN_LC_PATH_STATE1,
    "LCF_SYS_STATE1": CAN_LCF_SYS_STATE1,
    "SPA_LCF_HANDS_OFF_WARNING1": CAN_SPA_LCF_HANDS_OFF_WARNING1,
    "LDW_LKA_SYS_STATE1": CAN_LDW_LKA_SYS_STATE1,
    "SPA_SYS_STATE1": CAN_SPA_SYS_STATE1,
    "RMS_MODE_STATE1": CAN_RMS_MODE_STATE1,
    "ESC12_MSG_CNT": CAN_ESC12_MSG_CNT,
    "ESC12_CRC": CAN_ESC12_CRC,
    "SAS_MSG_CNT": CAN_SAS_MSG_CNT,
    "SAS_CRC": CAN_SAS_CRC,
    "EMS36_MSG_CNT": CAN_EMS36_MSG_CNT,
    "EMS36_CRC": CAN_EMS36_CRC,
    "EMS21_MSG_CNT": CAN_EMS21_MSG_CNT,
    "EMS21_CRC": CAN_EMS21_CRC,
    "VIN_DATA_2": CAN_VIN_DATA_2,
    "VIN_DATA_1": CAN_VIN_DATA_1,
    "VIN_DATA_0": CAN_VIN_DATA_0,
    "VIN_INDEX": CAN_VIN_INDEX,
    "DISP_AMBT_TEMP_EMS": CAN_DISP_AMBT_TEMP_EMS,
    "INDC_CRUISE": CAN_INDC_CRUISE,
    "CURRENT_GEAR_MT": CAN_CURRENT_GEAR_MT,
    "CLUTCH_STS": CAN_CLUTCH_STS,
    "PSGR_AIRBAG_SW_IC": CAN_PSGR_AIRBAG_SW_IC,
    "DRL_EN_SW": CAN_DRL_EN_SW,
    "MASTER_CYL_PRESSURE": CAN_MASTER_CYL_PRESSURE,
    "LATTERAL_ACCEL": CAN_LATTERAL_ACCEL,
    "LONG_ACCEL": CAN_LONG_ACCEL,
    "YAW_RATE": CAN_YAW_RATE,
    "ESC7_MSG_CNT": CAN_ESC7_MSG_CNT,
    "ESC7_CRC": CAN_ESC7_CRC,
    "ESC_ACTIVE": CAN_ESC_ACTIVE,
    "ABS_ACTIVE": CAN_ABS_ACTIVE,
    "STS_ESC": CAN_STS_ESC,
    "ESC5_MSG_CNT": CAN_ESC5_MSG_CNT,
    "ESC5_CRC": CAN_ESC5_CRC,
    "STS_ABS": CAN_STS_ABS,
    "TCS_ACTIVE": CAN_TCS_ACTIVE,
    "STS_TCS": CAN_STS_TCS,
}
# --- Helpers: Key message classification and DTC resolution ---

# Define which Tx frames are "key messages" (per user-provided list)
KEY_TX_FRAMES = {
    # ESC #No CAN DTC applicable in UPP for ESC
    "ESC10_20": False,
    "ESC12_10": False,
    "ESC2_10": False,
    "ESC5_10": True,
    "ESC7_20": False,
    # IC
    "IC2_100": True,
    # IS
    "IS1_100": True,
    "IS3_500": False,
    # SAS
    "EPS_SAS1_10": True,
    # EMS/MBFM/TCU
    "EMS1_10": False,
    "EMS3_10": True,
    "EMS21_10": False,
    "EMS36_10": False,
    "EMS5_500": False,
    "EMS6_500": False,

    "MBFM1_100": True,
    "MBFM5_100": False,
    "MBFM6_100": False,
    "MBFM_ACTIVE": False,
    "MBFM_SLEEP": False,
    "MBFM_WAKEUP": False,
    "MBFM7_100": False,
    
    "TCU5_10": True,
    # HPCAD
    "HPCAd_31_10": True,
    "HPCAd_33_50": False,
    # EMS
    
}


def is_key_message(frame_name: str) -> bool:
    """Return True if the Tx frame is a key message, else False."""
    return bool(KEY_TX_FRAMES.get(frame_name, False))


def get_message_timeout_dtc(frame_name: str) -> str | None:
    cfg = CAN_TX_MESSAGE_CONFIG.get(frame_name)
    if not cfg:
        return None
    return cfg.get("message_timeout_dtc")


def get_node_absent_dtc(frame_name: str) -> str | None:
    cfg = CAN_TX_MESSAGE_CONFIG.get(frame_name)
    if not cfg:
        return None
    return cfg.get("node_absent_dtc")


def get_signal_content_failure_dtc(signal_name: str) -> str | None:
    """Return the signal content failure DTC based on signal name."""
    return CAN_SIGNAL_CONTENT_FAILURE_DTC.get(signal_name)


def get_message_content_failure_dtcs(frame_name: str) -> dict:
    """
    Return the message content failure DTCs defined for the frame in
    `CAN_TX_MESSAGE_CONFIG` (e.g., for CNT/CRC signals). If not present,
    returns an empty dict.
    """
    cfg = CAN_TX_MESSAGE_CONFIG.get(frame_name) or {}
    return cfg.get("message_content_failure_dtcs", {}) or {}


def get_message_content_failure_signals(frame_name: str) -> list:
    """Return the list of signal names that have message content failure DTCs for the given frame."""
    dtcs = get_message_content_failure_dtcs(frame_name)
    return list(dtcs.keys())


def choose_message_content_failure_signal(frame_name: str) -> str | None:
    """
    Select an appropriate message-content-failure signal for the frame.
    Preference order:
    1) Signal containing 'MSG_CNT'
    2) Signal containing 'CRC'
    3) First available signal
    Returns None if no signals are defined.
    """
    signals = get_message_content_failure_signals(frame_name)
    if not signals:
        return None
    upper = [s.upper() for s in signals]
    for idx, name in enumerate(upper):
        if "MSG_CNT" in name:
            return signals[idx]
    for idx, name in enumerate(upper):
        if "CRC" in name:
            return signals[idx]
    return signals[0]


def get_frame_message_content_failure_dtc(frame_name: str) -> tuple[str | None, str | None]:
    """
    Simple helper to fetch the Message Content Failure DTC for a given frame.
    - Chooses an appropriate content signal via `choose_message_content_failure_signal`.
    - Returns (dtc_code, signal_name). If no mapping exists, returns (None, None).
    """
    dtc_map = get_message_content_failure_dtcs(frame_name) or {}
    sig = choose_message_content_failure_signal(frame_name)
    if not sig:
        return None, None
    return dtc_map.get(sig), sig


def resolve_dtc_for_event(event_type: str, frame_name: str | None, signal_name: str | None = None):
    """
    Resolve the appropriate DTC(s) based on the event type and context.

    event_type:
      - "message_timeout": Return message-timeout DTC for the frame.
      - "node_absent": Return node-absent DTC for the frame.
      - "frame_disabled": If frame is key -> node_absent, else -> message_timeout.
      - "signal_invalid": Return signal_content_failure for the signal.
      - "message_content_failure": Return dict of message-content failure DTCs.

    Returns a string (single DTC), a dict (multiple DTCs), or None if unknown.
    """
    if event_type == "message_timeout":
        return get_message_timeout_dtc(frame_name) if frame_name else None
    if event_type == "node_absent":
        return get_node_absent_dtc(frame_name) if frame_name else None
    if event_type == "frame_disabled":
        if not frame_name:
            return None
        return get_node_absent_dtc(frame_name) if is_key_message(frame_name) else get_message_timeout_dtc(frame_name)
    if event_type == "signal_invalid" and signal_name:
        return get_signal_content_failure_dtc(signal_name)
    if event_type == "message_content_failure":
        return get_message_content_failure_dtcs(frame_name) if frame_name else None
    return None


