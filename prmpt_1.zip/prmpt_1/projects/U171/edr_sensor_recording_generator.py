"""edr_sensor_recording_generator.py — emit the 8 Sensor_Recording test
scripts described in C:\\project_req\\m314\\tc_edr\\edr_additional_sesnor_cases.csv.

Each TC is a two-crash sequence (first crash → EDR1; second crash → EDR2,
EDR1 retains first values). Test cases 5-8 additionally force the "other"
RSU sensors to zero and expect that group's EDR payload to read as the
EDR_FORCED_ZERO_BYTE.

The generated scripts use ONLY existing framework helpers:
  - shared_libraries.core_functions: load_crash_curves, TriggerCrash,
    Read_DTC, fault_free_profile_classic_can, create_report_and_logging,
    resolve_can_log_ids, enter_ext_session, read_software_version, Sleep
  - shared_libraries.jscript_translation: CAN.SendDiagByValues, PS.*
  - shared_libraries.ascent_batch_lib: RESULT
  - apym.reports: aria_reports
  - projects.U171.config.rsu_config: SENSOR_*, CRASH_SENSOR_GROUPS, helpers

Default: dry-run. Re-run with --apply to write files.
"""

from __future__ import annotations
import argparse
import sys
from pathlib import Path

OUT_DIR_DEFAULT = Path(r"C:\Framework_IOEM_Py\projects\U171\modules\EDR\scripts")


# (tc_num, crash_a, crash_b, force_zero_other, csv_name)
TEST_CASES = [
    (1, "front", "rear",  False, "TC_EDR_Front_Crash_Rear_Crash_Sensor_recording_01"),
    (2, "rear",  "front", False, "TC_EDR_Rear_Crash_Front_Crash_Sensor_recording_02"),
    (3, "left",  "right", False, "TC_EDR_Left_Crash_Right_Crash_Sensor_recording_03"),
    (4, "right", "left",  False, "TC_EDR_Right_Crash_Left_Crash_Sensor_recording_04"),
    (5, "front", "rear",  True,  "TC_EDR_Front_Crash_Rear_Crash_Sensor_recording_05"),
    (6, "rear",  "front", True,  "TC_EDR_Rear_Crash_Front_Crash_Sensor_recording_06"),
    (7, "left",  "right", True,  "TC_EDR_Left_Crash_Right_Crash_Sensor_recording_07"),
    (8, "right", "left",  True,  "TC_EDR_Right_Crash_Left_Crash_Sensor_recording_08"),
]


SCRIPT_TEMPLATE = '''\
# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, Read_DTC_Req, Read_DTC_Resp, DTC_status,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import (
    U171_CRASH_CURVE_CONFIG,
)
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep,
    Read_DTC,
    TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
    enter_ext_session,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.rsu_config import (
    SENSOR_TO_RSU_CHANNEL,
    SENSOR_SENSITIVITY,
    SENSOR_PORT_RES,
    SENSOR_DID_EDR1,
    SENSOR_DID_EDR2,
    CRASH_SENSOR_GROUPS,
    RSU_DECODE_TOLERANCE_G,
    EDR_EMPTY_BYTE,
    EDR_FORCED_ZERO_BYTE,
    build_read_did_request,
    lsb_curve_from_file,
    input_g_from_lsb,
    expand_decoded_to_input_rate,
    output_duplication_factor,
    decode_uds_response_to_g,
    curve_path_for_channel,
    did_response_payload_tokens,
)


# ── Local verification helpers (one place per file, no shared-lib changes) ──
def _verify_sensor_did_against_curve(sensor, did_label, did_str, crash_type, polarity):
    """Read a sensor's DID and compare the decoded G stream against the curve
    that Aria played for the given crash_type."""
    aria_reports.add_group(
        f"RSU Decode :: {{sensor}} ({{did_label}} {{did_str}}) vs {{crash_type}} curve".format(
            sensor=sensor, did_label=did_label, did_str=did_str, crash_type=crash_type,
        )
    )
    rsu_channel = SENSOR_TO_RSU_CHANNEL.get(sensor)
    sensitivity = SENSOR_SENSITIVITY.get(sensor)
    port_res    = SENSOR_PORT_RES.get(sensor)

    if not (rsu_channel and sensitivity and port_res):
        RESULT.LogCustomAction(
            f"{{sensor}} metadata".format(sensor=sensor),
            "missing from rsu_config",
            "rsu_config must define channel/sensitivity/port_res",
            TestStatus.Failed,
        )
        aria_reports.close_group()
        return

    request  = build_read_did_request(did_str)
    response = CAN.SendDiagByValues(request)
    RESULT.InsertComment(f"UDS REQ {{request}}    RESP {{response}}".format(
        request=request, response=response,
    ))

    # Decode ECU output -> G, then duplicate each output sample `factor` times
    # so the lower-rate EDR output lines up with the full-resolution input curve.
    factor   = output_duplication_factor(sensor)
    decoded  = decode_uds_response_to_g(response, port_res)
    decoded_expanded = expand_decoded_to_input_rate(decoded, factor=factor)
    curve    = curve_path_for_channel(U171_CRASH_CURVE_CONFIG, crash_type, rsu_channel)

    if curve:
        lsb     = lsb_curve_from_file(curve)
        input_g = input_g_from_lsb(lsb, sensitivity)   # full input resolution, no decimation
        RESULT.InsertComment(
            f"Curve {{curve}}  |  input LSB {{lsb_n}}  input G {{in_n}}  "
            f"decoded G {{dec_n}}  expanded(x{{factor}}) {{exp_n}}".format(
                curve=curve, lsb_n=len(lsb), in_n=len(input_g),
                dec_n=len(decoded), factor=factor, exp_n=len(decoded_expanded),
            )
        )
        n = min(len(decoded_expanded), len(input_g))
        if n == 0:
            RESULT.LogCustomAction(
                f"{{sensor}} sample count".format(sensor=sensor),
                "input_g={{}} expanded_output={{}}".format(len(input_g), len(decoded_expanded)),
                "non-zero on both sides",
                TestStatus.Failed,
            )
        for i in range(n):
            diff = abs(decoded_expanded[i] - input_g[i])
            ok   = diff <= RSU_DECODE_TOLERANCE_G
            RESULT.LogCustomAction(
                f"{{sensor}} sample {{i}}".format(sensor=sensor, i=i),
                "output={{:.4f}}G  input={{:.4f}}G  diff={{:.4f}}".format(
                    decoded_expanded[i], input_g[i], diff,
                ),
                "within +/- {{:.4f}}G".format(RSU_DECODE_TOLERANCE_G),
                TestStatus.Passed if ok else TestStatus.Failed,
            )
    else:
        RESULT.InsertComment(
            f"No curve configured for channel {{rsu_channel}} under crash '{{crash_type}}'. ".format(
                rsu_channel=rsu_channel, crash_type=crash_type,
            )
            + "Logging decoded (expanded x{{factor}}) output values only.".format(factor=factor)
        )
        for i, g in enumerate(decoded_expanded):
            RESULT.InsertComment(
                "  {{sensor}} output[{{i}}] = {{g:.4f}}G".format(sensor=sensor, i=i, g=g)
            )

    first_nz = next((g for g in decoded if abs(g) > 1e-6), 0.0)
    polarity_ok = (
        (polarity == "negative" and first_nz < 0) or
        (polarity == "positive" and first_nz > 0)
    )
    RESULT.LogCustomAction(
        f"{{sensor}} polarity".format(sensor=sensor),
        "first non-zero decoded G = {{:.4f}}".format(first_nz),
        polarity,
        TestStatus.Passed if polarity_ok else TestStatus.Failed,
    )
    aria_reports.close_group()


def _verify_did_payload_is_byte(sensor, did_label, did_str, target_byte):
    """Read a DID and assert every payload byte equals target_byte
    (e.g. '0xFF' for empty EDR slots, '0x7F' for forced-zero other-RSU)."""
    aria_reports.add_group(
        f"{{sensor}} {{did_label}} expected all-{{target_byte}}".format(
            sensor=sensor, did_label=did_label, target_byte=target_byte,
        )
    )
    request  = build_read_did_request(did_str)
    response = CAN.SendDiagByValues(request)
    RESULT.InsertComment(f"UDS REQ {{request}}    RESP {{response}}".format(
        request=request, response=response,
    ))
    payload  = did_response_payload_tokens(response)
    norm     = lambda t: t.lower().replace("0x", "").zfill(2)
    target   = norm(target_byte)
    all_ok   = bool(payload) and all(norm(t) == target for t in payload)
    RESULT.InterpretEqualResult(
        f"{{sensor}} {{did_label}} payload all {{target_byte}}".format(
            sensor=sensor, did_label=did_label, target_byte=target_byte,
        ),
        "all-{{}}".format(target_byte) if all_ok else " ".join(payload),
        "all-{{}}".format(target_byte),
    )
    aria_reports.close_group()


def _read_crash_dtc(label):
    """Verify the crash DTC is active after triggering the given crash type."""
    combined = Crash_DTC + " " + DTC_status["DTC_active"]
    Read_DTC(label, Read_DTC_Resp + " " + combined, Read_DTC_Req)


# ── Test body ───────────────────────────────────────────────────────────────
def run_test():
    tc_id   = "{tc_id}"
    tc_desc = (
        "{csv_name}: "
        "First crash {crash_a} -> verify EDR1 against input curves and "
        "{crash_a_polarity} polarity; EDR2 starts as all-0xFF. "
        "Second crash {crash_b} -> EDR1 retains first crash values; EDR2 takes "
        "second crash with {crash_b_polarity} polarity. "
        "IGN cycle -> both EDRs retain their values."
    )

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc,
    )

    # ── Bench setup ─────────────────────────────────────────────────────────
    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    enter_ext_session()

    group_a = CRASH_SENSOR_GROUPS["{crash_a}"]
    group_b = CRASH_SENSOR_GROUPS["{crash_b}"]
    # "Other" RSUs that this TC forces to zero (5-8 only).
    other_a_sensors = [s for s in group_b["sensors"] if s not in group_a["sensors"]]
    other_b_sensors = [s for s in group_a["sensors"] if s not in group_b["sensors"]]

    # ── 1st crash: {crash_a_upper} ────────────────────────────────────────────────
    aria_reports.add_group("Crash 1 :: {crash_a_upper}")
    load_crash_curves("{crash_a}")
{force_zero_a_block}
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc("{crash_a_dtc_label} DTC after 1st trigger")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 vs INPUT after {crash_a_upper} crash (first trigger)")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR1.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR1", did, "{crash_a}", group_a["polarity"])
    aria_reports.close_group()

    aria_reports.add_group("EDR2 should be empty (all-0xFF) after first trigger")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR2.get(sensor)
        if did:
            _verify_did_payload_is_byte(sensor, "EDR2", did, EDR_EMPTY_BYTE)
    aria_reports.close_group()
{forced_zero_a_check}

    # ── 2nd crash: {crash_b_upper} ────────────────────────────────────────────────
    aria_reports.add_group("Crash 2 :: {crash_b_upper}")
    load_crash_curves("{crash_b}")
{force_zero_b_block}
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc("{crash_b_dtc_label} DTC after 2nd trigger")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 retention check after {crash_b_upper} (still matches first/{crash_a_upper} values)")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR1.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR1", did, "{crash_a}", group_a["polarity"])
    aria_reports.close_group()

    aria_reports.add_group("EDR2 vs INPUT after {crash_b_upper} crash (second trigger)")
    for sensor in group_b["sensors"]:
        did = SENSOR_DID_EDR2.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR2", did, "{crash_b}", group_b["polarity"])
    aria_reports.close_group()
{forced_zero_b_check}

    # ── IGN cycle and retention check ───────────────────────────────────────
    aria_reports.add_group("IGN cycle")
    PS.IGN_OFF()
    Sleep(2)
    PS.IGN_ON()
    Sleep(5)
    aria_reports.close_group()

    aria_reports.add_group("EDR1 retention after IGN cycle (still matches first/{crash_a_upper})")
    for sensor in group_a["sensors"]:
        did = SENSOR_DID_EDR1.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR1", did, "{crash_a}", group_a["polarity"])
    aria_reports.close_group()

    aria_reports.add_group("EDR2 retention after IGN cycle (still matches second/{crash_b_upper})")
    for sensor in group_b["sensors"]:
        did = SENSOR_DID_EDR2.get(sensor)
        if did:
            _verify_sensor_did_against_curve(sensor, "EDR2", did, "{crash_b}", group_b["polarity"])
    aria_reports.close_group()

    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
'''


FORCE_ZERO_BLOCK = '''
    # Forced-zero "other" RSU sensors for this TC variant (sensors not in
    # the crash group themselves but listed in the test to be held at 0).
    for sensor in other_{which}_sensors:
        RESULT.InsertComment(
            "Force-zero placeholder: sensor '" + sensor + "' should be driven to 0 "
            "via RSU.SendAcceleration(<channel>, <zero curve>) so the ECU sees no "
            "input on this sensor for this crash. Fill the zero-curve path in "
            "rsu_config.py / crash_configuration.py and call it here."
        )'''


FORCED_ZERO_CHECK_BLOCK = '''
    aria_reports.add_group("{slot} for forced-zero 'other' RSUs (expect all-0x7F)")
    for sensor in other_{which}_sensors:
        did = SENSOR_DID_{slot}.get(sensor)
        if did:
            _verify_did_payload_is_byte(sensor, "{slot}", did, EDR_FORCED_ZERO_BYTE)
    aria_reports.close_group()'''


def render_script(tc_num, crash_a, crash_b, force_zero, csv_name):
    g_a_label = f"{crash_a.title()} Crash"
    g_b_label = f"{crash_b.title()} Crash"
    polarity = {"front": "negative", "rear": "positive", "left": "negative", "right": "positive"}

    force_zero_a_block = (FORCE_ZERO_BLOCK.format(which="a") if force_zero else "")
    force_zero_b_block = (FORCE_ZERO_BLOCK.format(which="b") if force_zero else "")
    forced_zero_a_check = (
        FORCED_ZERO_CHECK_BLOCK.format(slot="EDR1", which="a") if force_zero else ""
    )
    forced_zero_b_check = (
        FORCED_ZERO_CHECK_BLOCK.format(slot="EDR2", which="b") if force_zero else ""
    )

    return SCRIPT_TEMPLATE.format(
        tc_id=f"Sensor_Recording_{tc_num:02d}",
        csv_name=csv_name,
        crash_a=crash_a,
        crash_b=crash_b,
        crash_a_upper=crash_a.upper(),
        crash_b_upper=crash_b.upper(),
        crash_a_polarity=polarity[crash_a],
        crash_b_polarity=polarity[crash_b],
        crash_a_dtc_label=g_a_label,
        crash_b_dtc_label=g_b_label,
        force_zero_a_block=force_zero_a_block,
        force_zero_b_block=force_zero_b_block,
        forced_zero_a_check=forced_zero_a_check,
        forced_zero_b_check=forced_zero_b_check,
    )


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--out-dir", default=str(OUT_DIR_DEFAULT),
                    help="EDR scripts folder")
    ap.add_argument("--apply", action="store_true",
                    help="Actually write files (default: dry-run).")
    args = ap.parse_args()
    out_dir = Path(args.out_dir)
    if not out_dir.is_dir():
        print(f"ERROR: out dir not found: {out_dir}", file=sys.stderr)
        return 2

    print(f"Output dir: {out_dir}")
    print(f"Mode      : {'APPLY' if args.apply else 'dry-run'}")
    print()
    print("Planned files:")
    plans = []
    for tc_num, crash_a, crash_b, force_zero, csv_name in TEST_CASES:
        body = render_script(tc_num, crash_a, crash_b, force_zero, csv_name)
        fname = f"SUBS_EDR_Sensor_Recording_TestCase_{tc_num}.py"
        plans.append((out_dir / fname, body))
        flag = " (forced-zero variant)" if force_zero else ""
        print(f"  + {fname}   {crash_a} -> {crash_b}{flag}")

    if not args.apply:
        print("\nDry-run only. Re-run with --apply to write the files.")
        return 0

    for path, body in plans:
        path.write_text(body, encoding="utf-8")
    print(f"\nWrote {len(plans)} file(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
