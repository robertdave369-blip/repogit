# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── Z121 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "33.9"
    tc_desc = (
        "ELK_SIDE_WARNING1 variant code error scenario: disable variant code bit (simulate variant code error), "
        "send values for full duration (-5.5s to +2.5s simulation -> -5s to +3s recording), trigger crash at T0, verify EDR records 0xFFFE in all samples."
    )

    elk_side_warning1_def = MAH_CAN_SIGNAL_DEFS["ELK_SIDE_WARNING1"]
    msg = elk_side_warning1_def["frame"]
    sig = elk_side_warning1_def["signal"]
    periodicity = elk_side_warning1_def["periodicity"]
    values = elk_side_warning1_def["TestCase_33_values"]
    edr_param = elk_side_warning1_def["EDR_Parameter"]
    veh_edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = elk_side_warning1_def.get("Factor", 1)
    offset = elk_side_warning1_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # Use resolve_dtc_for_event to get correct DTC for variant code error event
        
    combined_can_dtc_final = Variant_Code_DTC + " " + DTC_status["DTC_active"]
    print(f"Resolved Variant_Code_DTC for Variant_Code: combined with status: {combined_can_dtc_final}")        

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([elk_side_warning1_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    sleep(10)
    
    # Disable variant code bit from variant code BEFORE power cycle
    # This simulates "variant code error" - ECU will never receive this signal from startup
    RESULT.InsertComment(f"Disabling variant code bit from variant code to simulate 'variant code error' scenario.")
    enter_ext_session()
    Internal_Security_Access(0x01)
    manage_variant_code("VARIANT_STATUS", "disable", project="UPP_EV", base_from_project_default=True)
    
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # Derive time axis and T0 index from definition and RSU offsets
        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis (one sample interval before recording time)
        # If recording is from -5s to +3s with 500ms interval:
        # - Simulation starts at -5.5s and value simulated from -5.5s to -5s gets recorded at -5s
        # - Simulation at +2.5s to +3s gets recorded at +3s
        sample_interval_s = sample_interval_ms / 1000.0  # Convert ms to seconds
        
        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Expected EDR value for "variant code error" scenario
        signal_never_received_raw = 0xFFFE  # 65534 in decimal

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(f"Total values to simulate: {len(values)}")
        print(f"Expected EDR value (variant code error): 0xFFFE ({signal_never_received_raw})")

        aria_reports.add_group(
            "ELK_SIDE_WARNING1 33.9: variant bit disabled from variant code (variant code error), send values for full duration (sim: -5.5s to +2.5s -> rec: -5s to +3s), trigger crash at T0, verify EDR records 0xFFFE in all samples."
        )

        # Loop through ALL values - simulate entire duration
        # Simulation starts at -5.5s, value simulated from -5.5s to -5s gets recorded at -5s
        # Simulation at +2.5s to +3s gets recorded at +3s
        for idx, val in enumerate(values):        
            value_to_send = val
            
            # Get simulation time and recording time for current index
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)", 
                str(received_val_int), 
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s)", 
                str(received_phys), 
                str(expected_phys))

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                # Continue to next iteration, do not break
                continue

        # After simulation loop completes, wait and read only crash DTCs (no CAN fault DTC)
        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc + " " + combined_can_dtc_final, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = veh_edr_def.get("scaling_factor", 1) if veh_edr_def else 1
        offset_edr = veh_edr_def.get("offset", 0) if veh_edr_def else 0

        # Calculate expected physical value for 0xFFFE
        expected_signal_never_received = signal_never_received_raw * scaling + offset_edr

        # EDR verification:
        # All samples should show 0xFFFE (variant code error) because variant code was disabled
        aria_reports.add_group("EDR Output Verification - Variant Code Error")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("ELK_SIDE_WARNING1 Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            
            # All samples should be 0xFFFE (variant code error)
            RESULT.InterpretEqualResult(
                f"ELK_SIDE_WARNING1 recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - expected 0xFFFE (variant code error)",
                str(observed),
                str(expected_signal_never_received)
            )
        aria_reports.close_group()

    # Cleanup - restore signal and frame    
    CAN.ChangeSignalValue(msg, sig, "0")
    sleep(2)
    enter_ext_session()
    Internal_Security_Access(0x01)
    manage_variant_code("VARIANT_STATUS", "enable", project="UPP_EV", base_from_project_default=True)
    CAN.ReloadDefaultPeriodicFrame(msg)
    
    
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()

#display_tracebility(34976557, 34984937)
