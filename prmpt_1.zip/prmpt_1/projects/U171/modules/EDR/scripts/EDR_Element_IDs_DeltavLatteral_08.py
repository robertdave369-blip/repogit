# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import (
    U171_CRASH_CURVE_CONFIG,
    CRASH_TYPES,
)
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
    enter_ext_session,
    Internal_Security_Access,
    NVM_Clear_L61,
    ClearDTC,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.rsu_config import (
    SENSOR_TO_RSU_CHANNEL, SENSOR_SENSITIVITY, SENSOR_PORT_RES,
    SENSOR_DID_EDR1, SENSOR_DID_EDR2,
    CRASH_SENSOR_GROUPS, RSU_DECODE_TOLERANCE_G,
    EDR_EMPTY_BYTE, EDR_FORCED_ZERO_BYTE,
    DELTAV_EDR1_DID, DELTAV_EDR2_DID, DELTAV_PARAMETERS,
    DELTAV_SAMPLE_INTERVAL_MS, DELTAV_THRESHOLD_KMPH,
    RSU_FAULT_TYPES, RSU_FAULT_DTC,
    EDR_FULL_READ_DID, EDR_L1_SECURITY_LEVEL,
    build_read_did_request, lsb_curve_from_file,
    input_g_from_lsb, expand_decoded_to_input_rate, output_duplication_factor,
    decode_uds_response_to_g, curve_path_for_channel, did_response_payload_tokens,
)


def _read_crash_dtc(label):
    """Verify the standard crash + pretensioner DTCs are active."""
    combined = (Crash_DTC + " " + DTC_status["DTC_active"]
                + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"])
    Read_DTC(label, Read_DTC_Resp + " " + combined, Read_DTC_Req)


def _verify_did_payload_is_byte(sensor, did_label, did_str, target_byte):
    """Read a DID and assert every payload byte equals target_byte."""
    aria_reports.add_group(sensor + " " + did_label + " expected all-" + target_byte)
    request = build_read_did_request(did_str)
    response = CAN.SendDiagByValues(request)
    RESULT.InsertComment("UDS REQ " + request + "    RESP " + str(response))
    payload = did_response_payload_tokens(response)
    norm = lambda t: t.lower().replace("0x", "").zfill(2)
    target = norm(target_byte)
    all_ok = bool(payload) and all(norm(t) == target for t in payload)
    RESULT.InterpretEqualResult(
        sensor + " " + did_label + " payload all " + target_byte,
        ("all-" + target_byte) if all_ok else " ".join(payload),
        "all-" + target_byte,
    )
    aria_reports.close_group()


def _verify_sensor_did_against_curve(sensor, did_label, did_str, crash_type, polarity):
    """Read a sensor's DID and compare the (output-duplicated) decoded G stream
    against the full-resolution input curve Aria played for `crash_type`."""
    aria_reports.add_group(
        "RSU Decode :: " + sensor + " (" + did_label + " " + did_str + ") vs " + crash_type + " curve"
    )
    rsu_channel = SENSOR_TO_RSU_CHANNEL.get(sensor)
    sensitivity = SENSOR_SENSITIVITY.get(sensor)
    port_res = SENSOR_PORT_RES.get(sensor)
    if not (rsu_channel and sensitivity and port_res):
        RESULT.LogCustomAction(sensor + " metadata", "missing from rsu_config",
                               "channel/sensitivity/port_res required", TestStatus.Failed)
        aria_reports.close_group()
        return
    request = build_read_did_request(did_str)
    response = CAN.SendDiagByValues(request)
    RESULT.InsertComment("UDS REQ " + request + "    RESP " + str(response))
    factor = output_duplication_factor(sensor)
    decoded = decode_uds_response_to_g(response, port_res)
    decoded_expanded = expand_decoded_to_input_rate(decoded, factor=factor)
    curve = curve_path_for_channel(U171_CRASH_CURVE_CONFIG, crash_type, rsu_channel)
    if curve:
        lsb = lsb_curve_from_file(curve)
        input_g = input_g_from_lsb(lsb, sensitivity)
        n = min(len(decoded_expanded), len(input_g))
        for i in range(n):
            diff = abs(decoded_expanded[i] - input_g[i])
            ok = diff <= RSU_DECODE_TOLERANCE_G
            RESULT.LogCustomAction(
                sensor + " sample " + str(i),
                "output=%.4fG input=%.4fG diff=%.4f" % (decoded_expanded[i], input_g[i], diff),
                "within +/- %.4fG" % RSU_DECODE_TOLERANCE_G,
                TestStatus.Passed if ok else TestStatus.Failed,
            )
    else:
        for i, g in enumerate(decoded_expanded):
            RESULT.InsertComment("  " + sensor + " output[" + str(i) + "] = %.4fG" % g)
    first_nz = next((g for g in decoded if abs(g) > 1e-6), 0.0)
    polarity_ok = ((polarity == "negative" and first_nz < 0)
                   or (polarity == "positive" and first_nz > 0))
    RESULT.LogCustomAction(sensor + " polarity", "first non-zero G = %.4f" % first_nz,
                           polarity, TestStatus.Passed if polarity_ok else TestStatus.Failed)
    aria_reports.close_group()



def run_test():
    tc_id = "EDR_Element_IDs_DeltavLatteral_08"
    tc_desc = "DeltaVLat: lateral |DeltaVx| < 8 km/h with RSU input 0G."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids()
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    enter_ext_session()
    Internal_Security_Access(EDR_L1_SECURITY_LEVEL)

    axis = "Lat"            # "Lgt" or "Lat"
    crash_a, crash_b = "left", "right"

    # ── 1st crash ───────────────────────────────────────────────────────────
    aria_reports.add_group("Crash 1 :: " + crash_a.upper() + " (DeltaV" + axis + ")")
    RESULT.InsertComment(
        "SPEC STEP (project-specific stimulus): Load 0 to RSU; load CTy so |DeltaVx| < 8 km/h within 150 ms. "
        "Shape the onboard CT" + ("x" if axis == "Lgt" else "y") + " curve to the target |DeltaV| "
        "relative to the " + str(DELTAV_THRESHOLD_KMPH) + " km/h threshold, and set the RSU input as the "
        "test calls for. load_crash_curves() plays the configured crash curve below."
    )
    load_crash_curves(crash_a)
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc(crash_a.title() + " Crash DTC (1st)")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 (" + DELTAV_EDR1_DID + ") DeltaV params after 1st crash")
    edr1 = read_edr_parameters(DELTAV_PARAMETERS, did=DELTAV_EDR1_DID.replace("0x", ""),
                               crash_type=crash_a, return_data=True)
    RESULT.InsertComment("EDR1 read (" + DELTAV_EDR1_DID + "): " + str(edr1))
    RESULT.InsertComment("DeltaV" + axis + " records every " + str(DELTAV_SAMPLE_INTERVAL_MS) + " ms/sample.")
    aria_reports.close_group()

    aria_reports.add_group("EDR2 (" + DELTAV_EDR2_DID + ") should be empty (all-0xFF) after 1st crash")
    _verify_did_payload_is_byte("DeltaV" + axis, "EDR2", DELTAV_EDR2_DID, EDR_EMPTY_BYTE)
    aria_reports.close_group()

    # ── IGN cycle, then 2nd crash ───────────────────────────────────────────
    aria_reports.add_group("IGN cycle (proveout)")
    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)
    aria_reports.close_group()

    aria_reports.add_group("Crash 2 :: " + crash_b.upper() + " (DeltaV" + axis + ")")
    RESULT.InsertComment("SPEC STEP (project-specific stimulus): Load 0 to RSU; load CTy so |DeltaVx| < 8 km/h within 150 ms.")
    load_crash_curves(crash_b)
    TriggerCrash()
    Sleep(2)
    _read_crash_dtc(crash_b.title() + " Crash DTC (2nd)")
    aria_reports.close_group()

    Sleep(5)
    aria_reports.add_group("EDR1 retention after 2nd crash (should still hold 1st-crash DeltaV)")
    edr1_again = read_edr_parameters(DELTAV_PARAMETERS, did=DELTAV_EDR1_DID.replace("0x", ""),
                                     crash_type=crash_a, return_data=True)
    RESULT.InsertComment("EDR1 re-read (" + DELTAV_EDR1_DID + "): " + str(edr1_again))
    aria_reports.close_group()

    aria_reports.add_group("EDR2 (" + DELTAV_EDR2_DID + ") DeltaV params after 2nd crash")
    edr2 = read_edr_parameters(DELTAV_PARAMETERS, did=DELTAV_EDR2_DID.replace("0x", ""),
                               crash_type=crash_b, return_data=True)
    RESULT.InsertComment("EDR2 read (" + DELTAV_EDR2_DID + "): " + str(edr2))
    RESULT.InsertComment("Expected polarity note from spec: below-threshold case")
    aria_reports.close_group()

    aria_reports.add_group("IGN cycle retention check (both EDRs unchanged)")
    PS.IGN_OFF(); Sleep(2); PS.IGN_ON(); Sleep(5)
    RESULT.InsertComment("Re-read EDR1/EDR2 and confirm values match the previous ignition cycle.")
    aria_reports.close_group()

    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
