# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── Z121 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "40.1"
    tc_desc = "Verify Engine_Speed EDR sampling with raw values"

    signal_def = MAH_CAN_SIGNAL_DEFS["Engine_Speed"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]

    # Use the defined test values from CANLibrary
    values = signal_def["TestCase_40_values"]
    edr_param = signal_def["EDR_Parameter"]  # "Engine_Speed"
    edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    # Log relevant CAN IDs: baseline + frame ID for the signal under test
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(test_case_file,can_ids=can_ids,direct_write=False,tc_desc=tc_desc,)

    # Prep environment
    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    # read_software_version()
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"
    
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)
        # Fit array value from test values to values
        if not isinstance(values, list):
            values = [values]
        # Determine T0 index from EDR sample timeline.
        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)

        # Calculate simulation time axis (one sample interval before recording time)
        sample_interval_s = sample_interval_ms / 1000.0  # Convert ms to seconds
        
        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Total values to simulate: {len(values)}")

        # Send each raw value at the specified periodicity
        # Trigger crash one sample before T0 so value at T0 is the one sent at T0 index.
        trigger_idx = t0_sample_idx - 1
        factor = signal_def.get("Factor", 1)
        offset = signal_def.get("Offset", 0)
        
        for idx, val in enumerate(values):
            # Get simulation time and recording time for current index
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            CAN.ChangeSignalValue(msg, sig, str(val))
            # Allow EDR sampling window; cadence sourced from EDR definition
            Wait(sample_interval_ms)

            # Validate the set value via CAN readback
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                if isinstance(received_val, str) and received_val.startswith("0x"):
                    received_val_int = int(received_val, 16)
                else:
                    received_val_int = int(received_val)
            except Exception:
                received_val_int = int(received_val)

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {val} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)", 
                str(received_val_int), 
                str(val))

            expected_phys = (val * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s)",
                str(received_phys),
                str(expected_phys))

            # Trigger crash one sample before T0
            if idx == trigger_idx:
                TriggerCrash()
                continue

        # Validate expected DTCs after crash
        combineDTC = (Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]) 
        Read_DTC(f"Front Crash ", Read_DTC_Resp + " " + combineDTC, Read_DTC_Req)

        # Read EDR parameter after crash
        Sleep(5)
        edr_read = read_edr_parameters([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        # Compare decoded EDR samples with the values sent
        decoded_samples = []
        raw_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []
            raw_samples = edr_read.get("raw", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0
        aria_reports.add_group("EDR Output Verification - Valid Value")
        for i, expected_raw in enumerate(values):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("Engine_Speed Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            expected_phys = expected_raw * scaling + offset_edr
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            RESULT.InterpretEqualResult(
                f"Engine_Speed phyiscial value recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s)",
                str(observed),
                str(expected_phys))
            if i >= len(raw_samples):
                RESULT.LogCustomAction(
                    "Engine_Speed Raw",
                    f"Missing raw sample {i}",
                    f"Missing raw sample {i}",
                    TestStatus.Failed,
                )
                continue
            raw_observed = raw_samples[i]
            raw_observed_str = str(raw_observed)
            raw_observed_clean = raw_observed_str.strip()
            try:
                raw_observed_int = int(raw_observed_clean, 16) if raw_observed_clean.lower().startswith("0x") else int(raw_observed_clean)
                raw_observed_norm = f"0x{raw_observed_int:02X}"
            except ValueError:
                raw_observed_norm = raw_observed_clean.upper()
                if not raw_observed_norm.startswith("0X"):
                    raw_observed_norm = f"0x{raw_observed_norm}"
            expected_raw_norm = f"0x{expected_raw:02X}"
            RESULT.InterpretEqualResult(
                f"Engine_Speed raw recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s)",
                raw_observed_norm,
                expected_raw_norm)
        aria_reports.close_group()
    # Restore signal and periodic frame
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)

    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()

