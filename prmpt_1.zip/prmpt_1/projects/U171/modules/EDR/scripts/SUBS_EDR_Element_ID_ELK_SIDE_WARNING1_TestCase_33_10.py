# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── Z121 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "33.10"
    tc_desc = (
        "ELK_SIDE_WARNING1 under-voltage scenario: send first non-zero value, induce under-voltage fault, "
        "continue CAN simulation with actual values, trigger crash at T0, verify EDR latches non-zero value in all samples after fault, and DTCs are set."
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["ELK_SIDE_WARNING1"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_33_values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # Under Voltage DTC
    under_voltage_dtc = Under_Voltage + " " + DTC_status["DTC_active"]
    print(f"Under Voltage DTC: {under_voltage_dtc}")

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # Derive time axis and T0 index from definition and RSU offsets
        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis (one sample interval before recording time)
        sample_interval_s = sample_interval_ms / 1000.0  # Convert ms to seconds
        
        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Find first non-zero value index to induce under-voltage after simulating it
        first_nonzero_index = next((i for i, v in enumerate(values) if int(v) != 0), 0)
        disable_index = first_nonzero_index
        latched_raw = values[disable_index] if disable_index < len(values) else values[-1]

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(f"Disable index: {disable_index}")
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"ELK_SIDE_WARNING1 {tc_id}: Send first non-zero value, induce under-voltage fault, "
            "continue CAN simulation with actual values, trigger crash at T0, verify EDR latches non-zero value in all samples after fault."
        )
        fault_induced = False

        # Loop through ALL values - simulate entire duration
        for idx, val in enumerate(values):
            # Get simulation time and recording time for current index
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            # SIMULATION: Always send actual values from the list (different values at each sample)
            # Continue normal simulation even after fault is induced
            # ECU will latch due to under-voltage, but CAN simulation continues with actual values
            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            
            # Determine fault status for logging
            if not fault_induced:
                fault_status = ""
            else:
                fault_status = " [Under Voltage Active - ECU latching]"
                
            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s){fault_status}", 
                str(received_val_int), 
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s){fault_status}", 
                str(received_phys), 
                str(expected_phys))

            # Induce under-voltage fault immediately after first non-zero sample
            if not fault_induced and idx == disable_index:
                RESULT.InsertComment(f"Inducing under-voltage fault at index {disable_index} (simulated from {simulation_start_time}s to {recording_time}s).")
                RESULT.InsertComment(f"ECU will latch value {latched_raw} (physical: {latched_raw * factor + offset}) for all subsequent samples.")
                RESULT.InsertComment(f"CAN simulation continues with actual values from list, but ECU will latch due to under-voltage.")
                # Induce under-voltage using power supply
                PS.SetVoltage(6.6)  # Set voltage below threshold to induce under-voltage
                fault_induced = True
                Sleep(2)  # Wait for fault to register
                Read_DTC("Under Voltage (after fault induced)", Read_DTC_Resp + " " + under_voltage_dtc, Read_DTC_Req)

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                # Continue to next iteration, do not break - simulation continues for post-crash samples
                continue

        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        final_combined_dtc = combined_crash_dtc + " " + under_voltage_dtc
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        # EDR verification:
        # - Samples up to and including disable_index: actual values (ECU received them before fault)
        # - Samples after disable_index: latched value (ECU couldn't receive new values due to under-voltage)
        aria_reports.add_group("EDR Output Verification - Under Voltage (Latched Value)")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("ELK_SIDE_WARNING1 Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            
            if i <= disable_index:
                # Before/at fault: expect actual values (ECU received them)
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (before/at fault)"
            else:
                # After fault: expect latched value (ECU couldn't receive new values)
                expected_phys = expected_phys_latched
                description = "latched value (under-voltage active)"
                
            RESULT.InterpretEqualResult(
                f"ELK_SIDE_WARNING1 recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys)
            )
        aria_reports.close_group()

    # Restore voltage and cleanup
    PS.SetVoltage(12.0)  # Restore normal voltage
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()
