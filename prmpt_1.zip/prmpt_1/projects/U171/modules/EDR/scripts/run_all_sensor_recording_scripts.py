"""Run the SUBS_EDR_Sensor_Recording_TestCase_*.py scripts one by one.

Same structure as run_all_edr_scripts.py — a thin sibling runner so the EDR
mainline list stays untouched. These 8 test cases verify RSU input vs decoded
ECU output for the two-crash sequence scenarios; all of their inputs (sensor
metadata, DIDs, sensitivities, polarities, tolerances, expected EDR-empty
byte) live in projects/U171/config/rsu_config.py — no CSV or external file
is read at run time.
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

# Edit this list to choose which scripts run.
# To skip a script, comment that line with #.
SCRIPT_FILES = [
    "SUBS_EDR_Sensor_Recording_TestCase_1.py",
    "SUBS_EDR_Sensor_Recording_TestCase_2.py",
    "SUBS_EDR_Sensor_Recording_TestCase_3.py",
    "SUBS_EDR_Sensor_Recording_TestCase_4.py",
    "SUBS_EDR_Sensor_Recording_TestCase_5.py",
    "SUBS_EDR_Sensor_Recording_TestCase_6.py",
    "SUBS_EDR_Sensor_Recording_TestCase_7.py",
    "SUBS_EDR_Sensor_Recording_TestCase_8.py",
]


def get_python_scripts():
    scripts = []
    missing_files = []

    for script_name in SCRIPT_FILES:
        script_path = SCRIPT_DIR / script_name
        if script_path.is_file():
            scripts.append(script_path)
        else:
            missing_files.append(script_name)

    if missing_files:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for script_name in missing_files:
            print(f"- {script_name}")
        print()

    return scripts


def build_environment():
    env = os.environ.copy()
    framework_root = SCRIPT_DIR.parents[4]
    import_root = framework_root.parent
    existing_pythonpath = env.get("PYTHONPATH")

    if existing_pythonpath:
        env["PYTHONPATH"] = str(import_root) + os.pathsep + existing_pythonpath
    else:
        env["PYTHONPATH"] = str(import_root)

    return env


def run_script(script_path: Path, env):
    print("=" * 100)
    print(f"Running: {script_path.name}")
    print("=" * 100)

    completed = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(SCRIPT_DIR),
        env=env,
    )

    if completed.returncode == 0:
        print(f"PASSED: {script_path.name}")
    else:
        print(f"FAILED: {script_path.name} (exit code {completed.returncode})")

    return completed.returncode


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run selected RSU Sensor_Recording scripts one by one."
    )
    parser.add_argument(
        "--stop-on-fail",
        action="store_true",
        help="Stop immediately when a script fails.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    scripts = get_python_scripts()

    if not scripts:
        print("No scripts selected. Uncomment at least one filename in SCRIPT_FILES.")
        return 0

    env = build_environment()
    failures = []
    completed_count = 0

    print(f"Selected {len(scripts)} script(s) to run in: {SCRIPT_DIR}")

    for index, script_path in enumerate(scripts, start=1):
        print(f"\n[{index}/{len(scripts)}]")
        return_code = run_script(script_path, env)
        completed_count += 1

        if return_code != 0:
            failures.append((script_path.name, return_code))
            if args.stop_on_fail:
                break

    print("\n" + "=" * 100)
    print("Run summary")
    print("=" * 100)
    print(f"Total selected: {len(scripts)}")
    print(f"Completed: {completed_count}")
    print(f"Passed: {completed_count - len(failures)}")
    print(f"Failed: {len(failures)}")

    if failures:
        print("\nFailed scripts:")
        for script_name, return_code in failures:
            print(f"- {script_name}: exit code {return_code}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
