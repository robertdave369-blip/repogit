"""
Generate the parallel-simulation input workbook/CSVs from the live framework's
own signal defs so the inputs never drift out of sync with code.

Run once inside the framework environment:

    python edr_sim_input_generator.py

Produces (in <module>/test_data/):
    edr_sim_signals.xlsx    (Signals + Faults + README sheets) -- only if openpyxl is installed
    edr_sim_signals.csv     (CSV - Signals)
    edr_sim_faults.csv      (CSV - Faults)

Point the parallel-sim scripts at it via:
    set EDR_SIM_XLSX=<full path to edr_sim_signals.xlsx or .csv>
"""

import csv
import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.can_library import MAH_CAN_SIGNAL_DEFS  # noqa: E402
from Framework_IOEM_Py.shared_libraries.data_conversions import (              # noqa: E402
    get_sample_interval_ms,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (        # noqa: E402
    get_edr_parameters,
)


SIGNAL_COLUMNS = [
    "edr_param",
    "signal_def_key",
    "frame",
    "signal",
    "ch",
    "sample_rate_ms",
    "recording_start_s",
    "recording_end_s",
    "values",
    "factor",
    "offset",
]

FAULT_COLUMNS = [
    "edr_param",
    "fault_type",
    "timing",
    "clear_at_t0",
    "fault_default",
    "param1",
    "param2",
]


def _resolve_window(edr_param, edr_params):
    try:
        sr = get_sample_range(edr_param, edr_params)
        if sr:
            return float(min(sr)), float(max(sr))
    except Exception:
        pass
    return -5.0, 3.0


def _pick_values_field(sd, n_samples):
    """Pick the first available TestCase_<n>_values list (skip Invalid/OutofRange) and trim/pad."""
    for k in sd:
        if (
            k.startswith("TestCase_")
            and k.endswith("_values")
            and "Invalid" not in k
            and "OutofRange" not in k
        ):
            vals = sd[k]
            if isinstance(vals, list) and vals:
                if len(vals) < n_samples:
                    vals = vals + [vals[-1]] * (n_samples - len(vals))
                elif len(vals) > n_samples:
                    vals = vals[:n_samples]
                return vals
    mid = int(sd.get("MID", 0) or 0)
    return [mid] * max(1, n_samples)


def collect_signal_rows():
    edr_params = get_edr_parameters() or []
    rows = []
    for key, sd in MAH_CAN_SIGNAL_DEFS.items():
        edr_param = sd.get("EDR_Parameter")
        if not edr_param:
            continue
        sample_ms = get_sample_interval_ms(edr_param, default_ms=500)
        rec_start, rec_end = _resolve_window(edr_param, edr_params)
        sample_s = sample_ms / 1000.0
        n_samples = int(round((rec_end - rec_start) / sample_s)) + 1
        values = _pick_values_field(sd, n_samples)

        rows.append({
            "edr_param": edr_param,
            "signal_def_key": key,
            "frame": sd.get("frame"),
            "signal": sd.get("signal"),
            "ch": sd.get("ch"),
            "sample_rate_ms": sample_ms,
            "recording_start_s": rec_start,
            "recording_end_s": rec_end,
            "values": ", ".join(str(int(v)) for v in values),
            "factor": sd.get("Factor", 1),
            "offset": sd.get("Offset", 0),
        })
    rows.sort(key=lambda r: str(r["edr_param"]))
    return rows


def collect_fault_rows(signal_rows):
    rows = []
    for sr in signal_rows:
        sd = MAH_CAN_SIGNAL_DEFS.get(sr.get("signal_def_key") or "", {}) or {}
        fl = sd.get("fault_logic") or {}

        if fl.get("message_content_failure_dtcs"):
            ftype = "MESSAGE_CONTENT_FAIL"
            timing = "PRE_HALF"
            param1 = next(
                (k for k in fl["message_content_failure_dtcs"] if "CRC" in str(k).upper()),
                "",
            )
        elif fl.get("message_timeout_dtc") and fl.get("key_message"):
            ftype = "MESSAGE_TIMEOUT"
            timing = "PRE_HALF"
            param1 = fl.get("key_message")
        elif fl.get("node_absent_dtc") and fl.get("key_message"):
            ftype = "NODE_ABSENT"
            timing = "PRE_HALF"
            param1 = fl.get("key_message")
        else:
            ftype = "NONE"
            timing = ""
            param1 = ""

        rows.append({
            "edr_param": sr["edr_param"],
            "fault_type": ftype,
            "timing": timing,
            "clear_at_t0": "false",
            "fault_default": "",
            "param1": param1 or "",
            "param2": "",
        })
    return rows


def write_csv(path, columns, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=columns)
        w.writeheader()
        for r in rows:
            w.writerow({c: ("" if r.get(c) is None else r[c]) for c in columns})


def write_xlsx(path, signal_rows, fault_rows):
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        print("[WARN] openpyxl not installed - skipping .xlsx (CSV files still written).")
        return False

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Signals"
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="305496")
    ws.append(SIGNAL_COLUMNS)
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
    for r in signal_rows:
        ws.append([r.get(c, "") for c in SIGNAL_COLUMNS])
    widths = {"values": 60, "signal_def_key": 22}
    for i, col in enumerate(SIGNAL_COLUMNS, 1):
        ws.column_dimensions[chr(64 + i)].width = widths.get(col, 14)

    ws2 = wb.create_sheet("Faults")
    ws2.append(FAULT_COLUMNS)
    for cell in ws2[1]:
        cell.font = header_font
        cell.fill = header_fill
    for r in fault_rows:
        ws2.append([r.get(c, "") for c in FAULT_COLUMNS])

    notes = wb.create_sheet("README")
    notes.append(["Field", "Allowed values / notes"])
    for cell in notes[1]:
        cell.font = header_font
        cell.fill = header_fill
    notes_rows = [
        ("edr_param",          "Name of the EDR parameter (matches get_edr_parameters())."),
        ("sample_rate_ms",     "Per-signal sample interval. Different signals may differ."),
        ("recording_start_s",  "Negative number, e.g. -5.0 (pre-crash window start)."),
        ("recording_end_s",    "Positive number, e.g.  3.0 (post-crash window end)."),
        ("values",             "Comma-separated raw values, one per recorded sample. Decimal or 0xHH."),
        ("factor / offset",    "Raw->physical scaling applied during CAN readback assertion."),
        ("",                   ""),
        ("fault_type",
            "NONE | MESSAGE_TIMEOUT | NODE_ABSENT | MESSAGE_CONTENT_FAIL | "
            "SIGNAL_CONTENT_FAIL | VARIANT_CODE_ERROR | NEVER_RECEIVED | BUS_OFF"),
        ("timing",             "PRE_SIM (before run) | PRE_HALF | AT_T0 | POST_HALF"),
        ("clear_at_t0",        "true => re-enable at T0 so post-crash records normally."),
        ("fault_default",
            "Raw value the EDR is expected to record while a PRE_SIM fault is active "
            "(variant code / never received / bus off). Leave blank to skip comparison."),
        ("param1",
            "MESSAGE_TIMEOUT/NODE_ABSENT/NEVER_RECEIVED: frame name to disable. "
            "MESSAGE_CONTENT_FAIL: CRC signal name. "
            "SIGNAL_CONTENT_FAIL: invalid raw value to hold. "
            "VARIANT_CODE_ERROR: wrong variant code to write."),
    ]
    for row in notes_rows:
        notes.append(row)
    notes.column_dimensions["A"].width = 20
    notes.column_dimensions["B"].width = 90

    wb.save(path)
    return True


def main():
    out_dir = Path(__file__).resolve().parent.parent / "test_data"
    out_dir.mkdir(parents=True, exist_ok=True)

    signal_rows = collect_signal_rows()
    fault_rows = collect_fault_rows(signal_rows)

    xlsx_path = out_dir / "edr_sim_signals.xlsx"
    csv_sig = out_dir / "edr_sim_signals.csv"
    csv_flt = out_dir / "edr_sim_faults.csv"

    write_csv(csv_sig, SIGNAL_COLUMNS, signal_rows)
    write_csv(csv_flt, FAULT_COLUMNS, fault_rows)
    wrote_xlsx = write_xlsx(xlsx_path, signal_rows, fault_rows)

    print(f"Signals : {len(signal_rows)}")
    print(f"Faults  : {len(fault_rows)}")
    print(f"CSV     : {csv_sig}")
    print(f"CSV     : {csv_flt}")
    if wrote_xlsx:
        print(f"XLSX    : {xlsx_path}")
        print(f"\nPoint the parallel-sim scripts at it via:")
        print(f"  set EDR_SIM_XLSX={xlsx_path}")
    else:
        print(f"\nPoint the parallel-sim scripts at it via:")
        print(f"  set EDR_SIM_XLSX={csv_sig}")


if __name__ == "__main__":
    main()
