# W616 Requirement Skill

Use this file as local AI/Copilot context for module-specific requirement and testcase questions. Prefer this skill over broad project memory when answering about this module.

## How To Use This Skill
- Answer with requirement/testcase IDs and source filenames when available.
- Prefer active `Approved` or `In_Review` rows over `Obsolete` rows unless the user asks for history.
- For exact row-level details, use the companion CSV catalogs generated beside this file.
- Do not infer behavior across modules unless the same requirement row is explicitly mapped to both modules.

## Module Snapshot
| Metric | Value |
| --- | --- |
| Requirement rows | 3866 |
| Testcase rows | 0 |
| Domains | CAN_C, DIDList, EOL, FaultList, GPO, IOControl, RoutineList, VIN, Variant_Code |
| Requirement statuses | Approved: 3680, n/a: 156, Obsolete: 30 |
| Requirement types | Functional Requirement: 3710, Heading: 104, Information: 52 |

## Source Workbooks
| Workbook | Domain | Requirement rows | Testcase rows |
| --- | --- | --- | --- |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_CAN_C.xlsx | CAN_C | 1464 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_Customer_DIDList.xlsx | DIDList | 563 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_Customer_IOControl.xlsx | IOControl | 55 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_Customer_RoutineList.xlsx | RoutineList | 35 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_EOL_Additional.xlsx | EOL | 30 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_FaultList_Additional.xlsx | FaultList | 1589 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_Process_GPO (2).xlsx | GPO | 40 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_VIN.xlsx | VIN | 36 | 0 |
| 84222_Mahindra_SC3_2S_W616 - DES_SW_Mahindra_Variant code_Additional.xlsx | Variant_Code | 54 | 0 |

## Requirement Domains

### CAN_C
| Metric | Value |
| --- | --- |
| Rows | 1464 |
| Statuses | Approved: 1335, n/a: 129 |
| Types | Functional Requirement: 1335, Heading: 89, Information: 40 |
| Verification methods | SW Qualification: 1349 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 33836677 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x124) EMS1_10 |
| 33836678 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x127) EMS21_10 |
| 33836679 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message(0x108)EMS3_10 |
| 33836680 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x142) EMS36_10 |
| 33836681 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x3C0) EMS5_500 |
| 33836682 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x308) EMS6_500 |
| 33836683 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x114) EPS_SAS1_10 |
| 33836684 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x171) ESC10_20 |
| 33836696 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x282) ESC12_10 |
| 33836697 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x2CC) ESC2_10 |
| 33836698 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x10D) ESC5_10 |
| 33836700 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x170) ESC7_20 |
| 33836701 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x24C) FRM2_20 |
| 33836702 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x7DF) GLOBAL_DIAG_REQ |
| 33836703 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x14C) HPCAd_31_10 |
| 33836704 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x2C5) HPCAd_33_50 |
| 33836705 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x340) IC2_100 |
| 33836706 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x220) IS1_100 |
| 33836707 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x3CA) IS3_500 |
| 33836708 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x3C1) MBFM_ACTIVE |
| 33836709 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x3C4) MBFM_SLEEP |
| 33836710 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x97) MBFM_WAKEUP |
| 33836819 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x348) MBFM1_100 |
| 33836834 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x214) MBFM5_100 |
| 33836835 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x218) MBFM6_100 |
| 33836836 | Inputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x730) SRS_DIAG_REQ |
| 33836838 | The Software shall acquire the CAN Message (0x136) TCU5_10 | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x136) TCU5_10 |
| 33836840 | Outputs | Approved | Functional Requirement |  | The Software shall Provide the CAN Message (0x406) SRS_ACTIVE |
| 33836841 | Outputs | Approved | Functional Requirement |  | The Software shall respond the CAN Message (0x738) SRS_DIAG_RES |
| 33836842 | Outputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x63F) SRS_TEST1 |
| 33836843 | Outputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x2C0) SRS1_20 |
| 33836844 | Outputs | Approved | Functional Requirement |  | The Software shall acquire the CAN Message (0x478) SRS2_100 |
| 33963361 | Functionality | Approved | Functional Requirement |  | The Software Shall transmit all the HS-CAN TX Configured Signals |
| 33963360 | Functionality | Approved | Functional Requirement |  | The Software shall acquire all the CAN RX configured Signals as per above mentioned Inputs and Outputs messages ID`s. |
| 33963366 | CAN Network monitoring conditions | Approved | Functional Requirement |  | The Software shall inhibit CAN related diagnostics (error handling) upon T15 OFF. |
| 33963367 | CAN Network monitoring conditions | Approved | Functional Requirement |  | During normal mode the Software shall support CAN related diagnostics (error handling) after T15 ON. |
| 33963372 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall check and verify the RAM usage CAN application during initilization. |
| 33963373 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall Shutdown for current ignition cycle if RAM check failure is detected. |
| 33963374 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall perform an additional check for critical received CAN signals to ensure the consistency of the signal. |
| 33963375 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The software shall store each critical received CAN signal in two locations: one location shall contain the original value, and the second location shall contain the complement of the original value. |
| 33963376 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The software shall periodically perform diagnostics on each critical received CAN signal by checking both the original value and its complement and shall store a fault in NVM if an error is detected. |
| 33963377 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall use the key message Monitoring concept to detect the presence of a node in the network. |
| 33963378 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall monitor one key message from each node for node absent ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px... |
| 33963379 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall set a node as absent if timeout of the key message is detected. |
| 33963380 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall continously monitor the key message for error detection threshold. |
| 33963381 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall ignore the messages from the absent node. |
| 33963382 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall take the fail safe values when node absence is detected. |
| 33963383 | Check of RAM used for CAN Application | Approved | Functional Requirement |  | The Software shall set the message error if a particular message sent by a node is lost due to any unexpected reason. |
| 33963385 | Node Absence Detection | Approved | Functional Requirement |  | The software shall monitor the presence of each partner ECU in the network by checking for the reception of the designated key message from each partner ECU. |
| 33963386 | Node Absence Detection | Approved | Functional Requirement |  | The software shall designate the highest priority message received from each partner ECU as the key message for monitoring the presence of that partner ECU. |
| 33963387 | Node Absence Detection | Approved | Functional Requirement |  | Software shall set the default value of error detection threshold to 5 times the periodicity of received message. |
| 33963388 | Node Absence Detection | Approved | Functional Requirement |  | The software shall provide a calibratable parameter for the error detection threshold value of the key message. |
| 33963389 | Node Absence Detection | Approved | Functional Requirement |  | The software shall record a Diagnostic Trouble Code (DTC) if the missing detection timer for a received message exceeds the timeout threshold defined by (u8NodeAbsentDetection* cycle time). |
| 33963390 | Node Absence Detection | Approved | Functional Requirement |  | When a node timeout DTC entry occurs, the received message of this node shall not be monitored further. |
| 33963391 | Node Absence Detection | Approved | Functional Requirement |  | When the node timeout failure is recovered, the timeout monitoring for each message of the node shall be activated again. |
| 33963392 | Node Absence Detection | Approved | Functional Requirement |  | The software shall deactivate timeout monitoring when the ACU enters the Bus-off mode. |
| 33963393 | Node Absence Detection | Approved | Functional Requirement |  | The software shall switch all signals from a node to their on-fail values if a timeout error occurs for that node, and shall continue to use the on-fail values until the fault is matured. |
| 33963394 | Node Absence Detection | Approved | Functional Requirement |  | The node absent timeout error shall be healed if the message reception starts again and continues with desired periodicity, for a node abscent recovery period of time (u8NodeAbsentRecovery * cycle time). |
| 33963395 | Node Absence Detection | Approved | Functional Requirement |  | The node absent timeout error shall be healed if the message reception starts again and continues with desired periodicity(Atleast, 80% of u8NodeAbsentRecovery messages(considering latency delay) reception in the time period "u8NodeAbsentRecovery * cycle ti... |
| 33963397 | Message Timeout Fault | Approved | Functional Requirement |  | The software shall record the inter-message time period between sequential receptions of each message from a partner ECU, except for the key message from that ECU. |
| 33963398 | Message Timeout Fault | Approved | Functional Requirement |  | The Software shall raise single DTC for timeout error of other than key messages. |
| 33963399 | Message Timeout Fault | Approved | Functional Requirement |  | The software shall raise a message timeout Diagnostic Trouble Code (DTC) against the transmitter node if the inter-message time period for any received message exceeds the configurable error detection threshold. |
| 33963400 | Message Timeout Fault | Approved | Functional Requirement |  | The Software shall retain the last valid value until the fault matures |
| 33963401 | Message Timeout Fault | Approved | Functional Requirement |  | The Software shall set the fail safe value once the fault matures. |
| 33963406 | Healing of Timeout Faults | Approved | Functional Requirement |  | The Software shall hold the fail safe value untill fault is healed. |
| 33963403 | Healing of Timeout Faults | Approved | Functional Requirement |  | The Software shall trigger the healing condition for message timeout errors and node absent errors once the reception starts again and continues for a calibrated period of time. |
| 33977712 | Healing of Timeout Faults | Approved | Functional Requirement |  | The software shall set the default value of the error healing time to 10 times the periodicity of the received message and shall require that at least 8 messages (considering latency delay) are received within this period for error healing. |
| 33963404 | Healing of Timeout Faults | Approved | Functional Requirement |  | The software shall hold the fail safe value until fault is healed. |
| 33963408 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software Shall specifies one transmit and one receive-error counter for every node. |
| 33963409 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall increment the error counter by a specific value for every detected erroneous message transmission. |
| 33963410 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall increment the error counter by a specific value for every detected erroneous message reception. |
| 33963411 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall decrement the error counter by one for each successful transmission message. |
| 33963412 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall decrement the error counter by one for each successful reception message. |
| 33963413 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall hold increment of error counts greater than the decrement of error counts. |
| 33963414 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall set any of the following CAN error based on the error counter value; • Error-active • Error-Passive • Bus-off |
| 33963415 | CAN Bus-Off failure | Approved | Functional Requirement |  | The Software shall set a CAN controller bus-off DTC when bus-off error is detected. |
| 33963418 | Signal content failure | Approved | Functional Requirement |  | The Software shall monitor CAN message signal content validation |
| 33963419 | Signal content failure | Approved | Functional Requirement |  | The Software shall perform range check on received signal values to ensure the validity of data received. |
| 33963420 | Signal content failure | Approved | Functional Requirement |  | The Software shall use last valid or fail safe signal value if a fault is identified. |
| 33963421 | Signal content failure | Approved | Functional Requirement |  | When the fault is qualified the Software shall follow ON-Fail Strategy based on the criticality of signal. |

### DIDList
| Metric | Value |
| --- | --- |
| Rows | 563 |
| Statuses | Approved: 562, n/a: 1 |
| Types | Functional Requirement: 562, Information: 1 |
| Verification methods | SW Qualification: 561, SW Integration: 2 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 34464843 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall ensure that security access is not required when reading DID 0x0434 using the $22 service. |
| 34464844 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall support DID 0x0434 in both the default diagnostic session and the extended diagnostic session. |
| 34464845 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall return the negative response code $NRC31 when reading DID 0x0434 in the programming session. |
| 34464846 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall ensure that the $2E service is not permitted to write DID 0x0434and shall respond with negative response code $NRC31. |
| 34464860 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The Software shall provide the Deployment Control Resistance values of the configured squibs using the $22 Read Data By Identifier service for DID 0x0434. |
| 34464861 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | Software shall read the resistance of the configured squibs during IGN ON state. |
| 34464847 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide a response with a length of 24 bytes when reading DID 0x0434. |
| 34464848 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Driver Airbag squib resistance values from Byte 0 to 1. |
| 34464849 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Passenger Airbag squib resistance values from Byte 2 to 3. |
| 34464850 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Driver Pre-tensioner_1 Squib (Belt) resistance values in byte 4 and 5. |
| 34464851 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Passenger Pre-tensioner_1 Squib (Belt) resistance values from Byte 6 to 7. |
| 34464852 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Driver Pre-tensioner_2 Squib (Lap) resistance values from Byte 8 to 9. |
| 34464853 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Passenger Pre-tensioner_2 Squib (Lap) resistance values from Byte 10 to 11. |
| 34464854 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Driver Side Airbag resistance values from Byte 12 to 13. |
| 34464855 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Passenger Side Airbag resistance values from Byte 14 to 15. |
| 34464856 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Driver Curtain Airbag resistance values from Byte 16 to 17. |
| 34464857 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Passenger Curtain Airbag resistance values from Byte 18 to 19. |
| 34464858 | 0x0434_Deployment Control Resistance | Approved | Functional Requirement | min/max=0/65535 | The software shall provide the Driver Knee Airbag resistance values from Byte 20 to 21. |
| 34464872 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall ensure that security access is not required when reading DID 0x0446 using the $22 service. |
| 34464871 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The Software shall provide the Squib Status of the configured squibs using the $22 Read Data By Identifier service for DID 0x0446. |
| 34464873 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall support DID 0x0446 in both default and extended diagnostic sessions. |
| 34464874 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall return the negative response code $NRC31 when reading DID 0x0446 in the programming session. |
| 34464875 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall ensure that the $2E service is not permitted to write DID 0x0446 and shall respond with negative response code $NRC31. |
| 34464876 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide a response with a length of 12 bytes when reading DID 0x0446. |
| 34464877 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Driver Pretensioner Status in Byte 0. |
| 34464878 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Driver Airbag Status in Byte 1. |
| 34464879 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Passenger Pretensioner Status in Byte 2. |
| 34464880 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Passenger Airbag Status in Byte 3. |
| 34464881 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Driver Lap Pretensioner Status in Byte 4. |
| 34464882 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Passenger Lap Pretensioner Status in Byte 5. |
| 34464883 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Status_Driver Side Airbag in Byte 6. |
| 34464884 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Passenger Side Airbag Status in Byte 7. |
| 34464885 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Driver Curtain Airbag Status in Byte 8. |
| 34464886 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Passenger Curtain Airbag Status in Byte 9. |
| 34464887 | 0x0446_Squib Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Squib Driver Knee Airbag Status in Byte 10. |
| 34464896 | 0x0448_Sensor Status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the Passenger seat belt status in byte 0, bits 0 and 1. |
| 34464898 | 0x0448_Sensor Status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the Passenger Airbag Status in byte 0, bit2. |
| 34464899 | 0x0448_Sensor Status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the Reserved value in byte 0, bit3 as 0x0. |
| 34464897 | 0x0448_Sensor Status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the Driver seat belt status in byte 0, bits 4 and .5 |
| 34464906 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The Software shall provide the Sensor Status of the configured sensors using the $22 Read Data by Identifier service for DID 0x0457. |
| 34464907 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall ensure that security access is not required when reading DID 0x0457 using the $22 service. |
| 34464908 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall support DID 0x0457 in both default and extended diagnostic sessions. |
| 34464909 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall return the negative response code $NRC31 when reading DID 0x0457 in the programming session. |
| 34464910 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall ensure that the $2E service is not permitted to write DID 0x0457and shall respond with negative response code $NRC31. |
| 34464911 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide a response with a length of 12 bytes when reading DID 0x0457. |
| 34464912 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Left front Sensor Fault Status in byte 0. |
| 34464913 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Right front Sensor Fault Status in byte 1. |
| 34464914 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the B-pillar side Sensor Fault Status in byte 2. |
| 34464915 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the B-pillar side Sensor Fault Status in byte 3. |
| 34464920 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Right side A Pillar Fault Status in byte 8. |
| 34464921 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Left side A Pillar Fault Status in byte 9. |
| 34531776 | 0x0457_Sensor Fault_Status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the Reserved value in byte 4 to byte 8 and byte 10 to byte 11. |
| 34464925 | 0x0449_Read Doors Status | Approved | Functional Requirement | min/max=0/1 | The Software shall provide the Doors Status from STS_DOOR signal in MBFM1_100(0x348) by using the $22 Read Data by Identifier service for DID 0x0449. |
| 34464926 | 0x0449_Read Doors Status | Approved | Functional Requirement | min/max=0/1 | The software shall ensure that security access is not required when reading DID 0x0449 using the $22 service. |
| 34464927 | 0x0449_Read Doors Status | Approved | Functional Requirement | min/max=0/1 | The software shall support DID 0x0449 in both default and extended diagnostic sessions. |
| 34464928 | 0x0449_Read Doors Status | Approved | Functional Requirement | min/max=0/1 | The software shall return the negative response code $NRC31 when reading DID 0x0449 in the programming session. |
| 34464929 | 0x0449_Read Doors Status | Approved | Functional Requirement | min/max=0/1 | The software shall ensure that the $2E service is not permitted to write DID 0x0449 and shall respond with negative response code $NRC31. |
| 34464930 | 0x0449_Read Doors Status | Approved | Functional Requirement | min/max=0/1 | The software shall provide a response with a length of 1 byte when reading DID 0x0449. |
| 34464938 | 0x044A_Read PADI status and PADS and PADI fault status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the PAB ON Lamp status as OFF in byte 0, bit 0 when PADS status set to PAB OFF in PSGR_AIRBAG_SW_IC signal. |
| 34531999 | 0x044A_Read PADI status and PADS and PADI fault status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the PAB ON Lamp status as ON in byte 0, bit 0 when PADS status set PAB ON in PSGR_AIRBAG_SW_IC signal. |
| 34464939 | 0x044A_Read PADI status and PADS and PADI fault status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the PAB OFF Lamp status as OFF in byte 0, bit 1 when PADS status set to PAB ON in PSGR_AIRBAG_SW_IC signal. |
| 34532000 | 0x044A_Read PADI status and PADS and PADI fault status | Approved | Functional Requirement | min/max=0/1 | The software shall provide the PAB OFF Lamp status as ON in byte 0, bit 1 when PADS status set PAB OFF in PSGR_AIRBAG_SW_IC signal |
| 34464940 | 0x044A_Read PADI status and PADS and PADI fault status | Approved | Functional Requirement | min/max=0/128 | The software shall provide the PADI ON Lamp fault status in byte 1. |
| 34464941 | 0x044A_Read PADI status and PADS and PADI fault status | Approved | Functional Requirement | min/max=0/255 | The software shall provide the PADI Off Lamp fault status in byte 2. |
| 34464943 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The Software shall provide the Airbag Warning Lamp Status by using the $22 Read Data By Identifier service for DID 0x044B. |
| 34464944 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The software shall ensure that security access is not required when reading DID 0x044B using the $22 service. |
| 34464945 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The software shall support DID 0x044B in both default and extended diagnostic sessions. |
| 34464946 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The software shall return the negative response code $NRC31 when reading DID 0x044B in the programming session. |
| 34464947 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The software shall ensure that the $2E service is not permitted to write DID 0x044B and shall respond with negative response code $NRC31. |
| 34464948 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The software shall provide a response with a length of 1 byte in byte0 bit 0 & 1. |
| 34464949 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The Software shall provide the Airbag Warning Lamp Status in byte 0 as 0 for No faults during that time Lamp Off or Default in INDC_SRS signal. |
| 34532002 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The Software shall provide the Airbag Warning Lamp Status in byte 0 as 1 for any faults during that time Lamp ON in INDC_SRS signal. \\ Note: Communication Faults (U-Code DTC) will be ignored |
| 34532003 | 0x044B_Airbag Warning Lamp Status | Approved | Functional Requirement | min/max=0/3 | The Software shall provide the Airbag Warning Lamp Status in byte 0 as 3 during Lamp is flashing 1Hz if ECU is in Plant Mode. |
| 34464959 | 0x0102_Write EOL Config | Approved | Functional Requirement | min/max=0/1 | The Software shall provide the configured data of 20 bytes length by using the $22 Read Data by Identifier service for DID 0x0102. |
| 34464960 | 0x0102_Write EOL Config | Approved | Functional Requirement | min/max=0/1 | The software shall ensure that security access is not required when reading DID 0x0102 using the $22 service. |
| 34464961 | 0x0102_Write EOL Config | Approved | Functional Requirement | min/max=0/1 | The software shall support DID 0x0102 in both default and extended diagnostic sessions. |
| 34464962 | 0x0102_Write EOL Config | Approved | Functional Requirement | min/max=0/1 | The software shall return the negative response code $NRC31 when reading DID 0x0102 in the programming session. |
| 34464963 | 0x0102_Write EOL Config | Approved | Functional Requirement | min/max=0/1 | The software shall allow to update the configuration using $2E service Data Identifier (DID) 0x0102 only after successful authentication of Security Level 1. |
| 34465083 | 0xF1B0_Odometer_values | Approved | Functional Requirement | min/max=0/16777215; offset/factor=0/ | The Software shall provide the Odometer value from IC2_100 Node shall be read by using the $22 Read Data by Identifier service for DID 0xF1B0. |
| 34465086 | 0xF1B0_Odometer_values | Approved | Functional Requirement | min/max=0/16777215; offset/factor=0/ | The software shall ensure that security access is not required when reading DID 0xF1B0 using the $22 service. |
| 34465087 | 0xF1B0_Odometer_values | Approved | Functional Requirement | min/max=0/16777215; offset/factor=0/ | The software shall support DID 0xF1B0 in both default and extended diagnostic sessions. |
| 34465089 | 0xF1B0_Odometer_values | Approved | Functional Requirement | min/max=0/16777215; offset/factor=0/ | The software shall return the negative response code $NRC31 when reading DID 0xF1B0 in the programming session. |
| 34465091 | 0xF1B0_Odometer_values | Approved | Functional Requirement | min/max=0/16777215; offset/factor=0/ | The software shall ensure that the $2E service is not permitted to write DID 0xF1B0 and shall respond with negative response code $NRC31. |
| 34465093 | 0xF1B0_Odometer_values | Approved | Functional Requirement | min/max=0/16777215; offset/factor=0/ | The software shall provide a response with a length of 3 bytes when reading DID 0xF1B0. |
| 34465096 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The Software shall provide the Battery Voltage by using the $22 Read Data By Identifier service for DID 0xF1B1. |
| 34465097 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall ensure that security access is not required when reading DID 0xF1B1 using the $22 service. |
| 34465098 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall support DID 0xF1B1 in both default and extended diagnostic sessions. |
| 34465100 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall return the negative response code $NRC31 when reading DID 0xF1B1 in the programming session. |
| 34465102 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall ensure that the $2E service is not permitted to write DID 0xF1B1 and shall respond with negative response code $NRC31. |
| 34465103 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall provide a response with a length of 2 bytes when reading DID 0xF1B1. |
| 34465105 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall provide the power supply voltage (VBAT) information in byte 0 of DID 0xF1B1. |
| 34465106 | 0xF1B1_Battery Voltage | Approved | Functional Requirement | min/max=7/25.5 | The software shall provide the SRS ECU Operating voltage information in byte 1 of DID 0xF1B1. |
| 34465109 | 0xF1B2_Vehicle Speed | Approved | Functional Requirement | min/max=0/300; offset/factor=/64 | The Software shall provide the Vehicle Speed from ESC12 Node by using the $22 Read Data by Identifier service for DID 0xF1B2. |
| 34465111 | 0xF1B2_Vehicle Speed | Approved | Functional Requirement | min/max=0/300; offset/factor=/64 | The software shall ensure that security access is not required when reading DID 0xF1B2 using the $22 service. |
| 34465112 | 0xF1B2_Vehicle Speed | Approved | Functional Requirement | min/max=0/300; offset/factor=/64 | The software shall support DID 0xF1B2 in both default and extended diagnostic sessions. |
| 34465113 | 0xF1B2_Vehicle Speed | Approved | Functional Requirement | min/max=0/300; offset/factor=/64 | The software shall return the negative response code $NRC31 when reading DID 0xF1B2 in the programming session. |
| 34465114 | 0xF1B2_Vehicle Speed | Approved | Functional Requirement | min/max=0/300; offset/factor=/64 | The software shall ensure that the $2E service is not permitted to write DID 0xF1B2 and shall respond with negative response code $NRC31. |
| 34465115 | 0xF1B2_Vehicle Speed | Approved | Functional Requirement | min/max=0/300; offset/factor=/64 | The software shall provide a response with a length of 2 bytes when reading DID 0xF1B2. |
| 34465117 | 0xF1B3_Engine Speed | Approved | Functional Requirement | min/max=-32760/32760; offset/factor=-32767/1 | The Software shall provide the Engine Speed from EMS36_10 Node by using the $22 Read Data by Identifier service for DID 0xF1B3. |
| 34465118 | 0xF1B3_Engine Speed | Approved | Functional Requirement | min/max=-32760/32760; offset/factor=-32767/1 | The software shall ensure that security access is not required when reading DID 0xF1B3 using the $22 service. |
| 34465119 | 0xF1B3_Engine Speed | Approved | Functional Requirement | min/max=-32760/32760; offset/factor=-32767/1 | The software shall support DID 0xF1B3 in both default and extended diagnostic sessions. |
| 34465120 | 0xF1B3_Engine Speed | Approved | Functional Requirement | min/max=-32760/32760; offset/factor=-32767/1 | The software shall return the negative response code $NRC31 when reading DID 0xF1B3 in the programming session. |
| 34465121 | 0xF1B3_Engine Speed | Approved | Functional Requirement | min/max=-32760/32760; offset/factor=-32767/1 | The software shall ensure that the $2E service is not permitted to write DID 0xF1B3 and shall respond with negative response code $NRC31. |
| 34465122 | 0xF1B3_Engine Speed | Approved | Functional Requirement | min/max=-32760/32760; offset/factor=-32767/1 | The software shall provide a response with a length of 2 bytes when reading DID 0xF1B3. |
| 34465139 | 0xF1B6_Ignition Counter | Approved | Functional Requirement | min/max=0/4294967295; offset/factor=0/ | The Software shall provide the Reset Counter data by using the $22 Read Data By Identifier service for DID 0xF1B6. |
| 34465140 | 0xF1B6_Ignition Counter | Approved | Functional Requirement | min/max=0/4294967295; offset/factor=0/ | The software shall ensure that security access is not required when reading DID 0xF1B6 using the $22 service. |
| 34465141 | 0xF1B6_Ignition Counter | Approved | Functional Requirement | min/max=0/4294967295; offset/factor=0/ | The software shall support DID 0xF1B6 in both default and extended diagnostic sessions. |
| 34465142 | 0xF1B6_Ignition Counter | Approved | Functional Requirement | min/max=0/4294967295; offset/factor=0/ | The software shall return the negative response code $NRC31 when reading DID 0xF1B6 in the programming session. |
| 34465143 | 0xF1B6_Ignition Counter | Approved | Functional Requirement | min/max=0/4294967295; offset/factor=0/ | The software shall ensure that the $2E service is not permitted to write DID 0xF1B6 and shall respond with negative response code $NRC31. |
| 34465144 | 0xF1B6_Ignition Counter | Approved | Functional Requirement | min/max=0/4294967295; offset/factor=0/ | The software shall provide a response with a length of 4 bytes when reading DID 0xF1B6. |
| 34465152 | 0xF1B9_Vehicle Status | Approved | Functional Requirement | min/max=0/7; offset/factor=0/ | The software shall ensure that security access is not required when reading DID 0xF1B9 using the $22 service. |
| 34465154 | 0xF1B9_Vehicle Status | Approved | Functional Requirement | min/max=0/7; offset/factor=0/ | The software shall support DID 0xF1B9 in both default and extended diagnostic sessions. |
| 34465155 | 0xF1B9_Vehicle Status | Approved | Functional Requirement | min/max=0/7; offset/factor=0/ | The software shall return the negative response code $NRC31 when reading DID 0xF1B9 in the programming session. |
| 34465157 | 0xF1B9_Vehicle Status | Approved | Functional Requirement | min/max=0/7; offset/factor=0/ | The software shall ensure that the $2E service is not permitted to write DID 0xF1B9 and shall respond with negative response code $NRC31. |
| 34465158 | 0xF1B9_Vehicle Status | Approved | Functional Requirement | min/max=0/7; offset/factor=0/ | The software shall provide a 1-byte response when reading DID 0xF1B9, with valid data in bit positions 0, 1, and 2. |
| 34465199 | 0x0459_Brake Switch Status | Approved | Functional Requirement | min/max=0/3 | The Software shall provide the Brake Switch Status from EMS21 Node by using the $22 Read Data by Identifier service for DID 0x0459. |
| 34465200 | 0x0459_Brake Switch Status | Approved | Functional Requirement | min/max=0/3 | The software shall ensure that security access is not required when reading DID 0x0459 using the $22 service. |
| 34465203 | 0x0459_Brake Switch Status | Approved | Functional Requirement | min/max=0/3 | The software shall support DID 0x0459 in both default and extended diagnostic sessions. |
| 34465204 | 0x0459_Brake Switch Status | Approved | Functional Requirement | min/max=0/3 | The software shall return the negative response code $NRC31 when reading DID 0x0459 in the programming session. |
| 34465205 | 0x0459_Brake Switch Status | Approved | Functional Requirement | min/max=0/3 | The software shall ensure that the $2E service is not permitted to write DID 0x0459 and shall respond with negative response code $NRC31. |

### EOL
| Metric | Value |
| --- | --- |
| Rows | 30 |
| Statuses | Approved: 25, n/a: 3, Obsolete: 2 |
| Types | Functional Requirement: 27, Information: 3 |
| Verification methods | SW Qualification: 23, SW Integration: 5 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 34460119 | EOL Functionality | Approved | Functional Requirement |  | During ECU initialization, ECU shall perform EOL code check which is stored in NVM configuration. |
| 34460121 | EOL Functionality | Approved | Functional Requirement |  | During the execution of EOL code checks, the software shall accept the feature code and store it in NVM when all the following conditions are met: |
| 34467846 |  | Approved | Functional Requirement |  | Security level 1 unlocked with extended session. |
| 34467849 |  | Approved | Functional Requirement |  | Vehicle Speed is not grater then 5Kmph |
| 34467850 |  | Approved | Functional Requirement |  | Internal DTCs shall not be active. |
| 34467851 |  | Approved | Functional Requirement |  | Minimum 1 loop and 1 RSU enabled |
| 34467852 |  | Approved | Functional Requirement |  | If Passenger Airbag (Byte 0 of Bit 0) is configured, then only PABD lamp OFF & PABD lamp ON & PABD Switch Source shall be enable/ configured. |
| 34467854 |  | Approved | Functional Requirement |  | No Reserved Bit is enabled. |
| 34460386 | EOL Functionality | Approved | Functional Requirement |  | The software shall enable and configure the PABD lamp OFF (Byte4 bit3), the PABD lamp ON (Byte5 bit4), and the PABD via CAN (Byte3 Bit3) only when the Passenger Airbag (Byte 0, Bit 0) is configured. |
| 34460126 | EOL Functionality | Approved | Functional Requirement |  | The ECU shall retain the feature code present in the NVM after completing the successful CAN flashing process. |
| 34460181 | EOL Functionality | Approved | Functional Requirement |  | ECU shall response with NRC 31 for EOL DID $0102 upon any below condition are meet. - If Passenger Airbag (Byte 0 of Bit 0) is not configured in EOL then any of PABD lamp OFF or PABD lamp ON (Byte 5 Bit 3, Bit 4) or PABD Switch Source enabling/configuring i... |
| 34460183 | EOL Functionality | Approved | Functional Requirement |  | Upon receiving Diagnostic request $0102 with EOL code, if any of the below conditions are met, the ECU shall respond with NRC 88. - Vehicle Speed exceeds 5Kmph |
| 34043620 | EOL Functionality | Approved | Functional Requirement |  | The software shall require a power cycle to enable the devices after the EOL code is written to NVM. |
| 34042898 | EOL Functionality | Approved | Functional Requirement |  | The Software shall verify the RSU configuration bits in the NVM sheet DeviceCfgMgr_NvmConfig.RsuConfig._x_ to ensure correct configuration. \\ Note: Refer RSUs configuration in [CB:/doc/150707817/content] |
| 34043136 | EOL Functionality | Approved | Functional Requirement |  | The Software shall verify the DCS mapping bits in the NVM sheet DeviceCfgMgr_NvmConfig.DcsMapping._x_ to ensure correct configuration. \\ \\ Note: Refer DCS mapping in [CB:/doc/150707817/content] |
| 34043535 | EOL Functionality | Approved | Functional Requirement |  | The Software shall verify the Loops mapping bits in the NVM sheet DeviceCfgMgr_NvmConfig.OpsActConfig._x- to ensure correct configuration. \\ \\ Note: Refer Loops mapping in [CB:/doc/150707817/content] |
| 34043395 |  | Approved | Functional Requirement |  | The Software shall verify the GPO config bits in the NVM sheet DeviceCfgMgr_NvmConfig.LampsConfig._x_ and DeviceCfgMgr_NvmConfig.CrashOutputConfig._x_to ensure correct configuration. \\ \\ Note: Refer GPO configuration in [CB:/doc/150707817/content] |
| 34416270 | EOL Functionality | Approved | Functional Requirement |  | The Software shall verify the EOL configured bits in the NVM sheet DiagMgr_DID_NvmData.u8Feature_Code. _x_ to ensure correct configuration. \\ \\ Note: Feature Code Bytes are 0 to 19 |
| 34043530 | EOL Functionality | Approved | Functional Requirement |  | The software shall inhibit the loops which are de-configured using feature code during any deployment crash event occurred. \\ Note: All individual loops to be tested. |
| 34054269 | EOL Functionality | Approved | Functional Requirement |  | The software shall inhibit the passenger airbag deployment when following conditions are met: 1. PABD via CAN is set in the feature code 2. PSGR_AIRBAG_SW_IC set to PAB OFF. ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-sp... |
| 34408049 | EOL Functionality | Approved | Functional Requirement |  | The software shall consider the alive counter range based on the value of Byte 6 Bit2 as follows: 1.Byte 6 Bit2 equals 0, the software shall consider the alive counter range from 0 to 15 2. Byte 6 Bit2 equals 1, the software shall consider the alive counter... |
| 34043625 | DTC Management | Approved | Functional Requirement |  | The software shall qualify ECU_Configuration_Error 0xB120200(9202-00) and Unexpected Load DTC if EOL code checks fail during ECU initialization. |
| 34467873 | DTC Management | Approved | Functional Requirement |  | The software shall qualify ECU_Configuration_Error (DTC 0xB120200) and respective loops Unexpected Load and electrical faults if EOL code checks fail during ECU initialization. \\ Note: Loops fault qualification as per prioritization. Refer [Multiple Failur... |
| 34467877 | DTC Management | Approved | Functional Requirement |  | The software shall qualify ECU_Configuration_Error (DTC 0xB120200) and respective RSU unmatched configured unexpected Load if EOL code checks fail during ECU initialization. |
| 34467883 | DTC Management | Approved | Functional Requirement |  | The software shall qualify ECU_Configuration_Error (DTC 0xB120200) and respective GPO unmatched configured unexpected Load if EOL code checks fail during ECU initialization. |

### FaultList
| Metric | Value |
| --- | --- |
| Rows | 1589 |
| Statuses | Approved: 1571, Obsolete: 18 |
| Types | Functional Requirement: 1589 |
| Verification methods | SW Qualification: 1589 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 34036867 | GPO_F_SHORT_GND_0 | Approved | Functional Requirement | DTC=0x9218; FTB=11 | GPO_F_SHORT_GND_0 |
| 34036868 | GPO_F_SHORT_GND_1 | Approved | Functional Requirement | DTC=0x9024; FTB=11 | GPO_F_SHORT_GND_1 |
| 34036869 | GPO_F_SHORT_GND_2 | Approved | Functional Requirement | DTC=0x9210; FTB=11 | GPO_F_SHORT_GND_2 |
| 34036870 | GPO_F_SHORT_GND_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SHORT_GND_3 |
| 34036871 | GPO_F_SHORT_GND_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SHORT_GND_4 |
| 34036872 | GPO_F_SHORT_BAT_0 | Approved | Functional Requirement | DTC=0x9218; FTB=12 | GPO_F_SHORT_BAT_0 |
| 34036873 | GPO_F_SHORT_BAT_1 | Approved | Functional Requirement | DTC=0x9024; FTB=12 | GPO_F_SHORT_BAT_1 |
| 34036874 | GPO_F_SHORT_BAT_2 | Approved | Functional Requirement | DTC=0x9210; FTB=12 | GPO_F_SHORT_BAT_2 |
| 34036875 | GPO_F_SHORT_BAT_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SHORT_BAT_3 |
| 34036876 | GPO_F_SHORT_BAT_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SHORT_BAT_4 |
| 34036877 | GPO_F_OPEN_0 | Approved | Functional Requirement | DTC=0x9218; FTB=13 | GPO_F_OPEN_0 |
| 34036878 | GPO_F_OPEN_1 | Approved | Functional Requirement | DTC=0x9024; FTB=13 | GPO_F_OPEN_1 |
| 34036879 | GPO_F_OPEN_2 | Approved | Functional Requirement | DTC=0x9210; FTB=13 | GPO_F_OPEN_2 |
| 34036880 | GPO_F_OPEN_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_OPEN_3 |
| 34036881 | GPO_F_OPEN_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_OPEN_4 |
| 34036882 | GPO_F_CFG_0 | Approved | Functional Requirement | DTC=0x9218; FTB=64 | GPO_F_CFG_0 |
| 34036883 | GPO_F_CFG_1 | Approved | Functional Requirement | DTC=0x9024; FTB=64 | GPO_F_CFG_1 |
| 34036884 | GPO_F_CFG_2 | Approved | Functional Requirement | DTC=0x9210; FTB=64 | GPO_F_CFG_2 |
| 34036885 | GPO_F_CFG_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_CFG_3 |
| 34036886 | GPO_F_CFG_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_CFG_4 |
| 34036887 | GPO_F_THERMAL_0 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_THERMAL_0 |
| 34036888 | GPO_F_THERMAL_1 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_THERMAL_1 |
| 34036889 | GPO_F_THERMAL_2 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_THERMAL_2 |
| 34036890 | GPO_F_THERMAL_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_THERMAL_3 |
| 34036891 | GPO_F_THERMAL_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_THERMAL_4 |
| 34036892 | GPO_F_INTERNAL_0 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_INTERNAL_0 |
| 34036893 | GPO_F_INTERNAL_1 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_INTERNAL_1 |
| 34036894 | GPO_F_INTERNAL_2 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_INTERNAL_2 |
| 34036895 | GPO_F_INTERNAL_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_INTERNAL_3 |
| 34036896 | GPO_F_INTERNAL_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_INTERNAL_4 |
| 34036897 | GPO_F_SPI_0 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SPI_0 |
| 34036898 | GPO_F_SPI_1 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SPI_1 |
| 34036899 | GPO_F_SPI_2 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SPI_2 |
| 34036900 | GPO_F_SPI_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SPI_3 |
| 34036901 | GPO_F_SPI_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_SPI_4 |
| 34036902 | GPO_F_UNEXEPCTED_LOAD_0 | Approved | Functional Requirement | DTC=0x9218; FTB=64 | GPO_F_UNEXEPCTED_LOAD_0 |
| 34036903 | GPO_F_UNEXEPCTED_LOAD_1 | Approved | Functional Requirement | DTC=0x9024; FTB=64 | GPO_F_UNEXEPCTED_LOAD_1 |
| 34036904 | GPO_F_UNEXEPCTED_LOAD_2 | Approved | Functional Requirement | DTC=0x9210; FTB=64 | GPO_F_UNEXEPCTED_LOAD_2 |
| 34036905 | GPO_F_UNEXEPCTED_LOAD_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_UNEXEPCTED_LOAD_3 |
| 34036906 | GPO_F_UNEXEPCTED_LOAD_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | GPO_F_UNEXEPCTED_LOAD_4 |
| 34036907 | RSU_F_ASIC_CHANNEL_SPI_0 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_0 |
| 34036908 | RSU_F_ASIC_CHANNEL_SPI_1 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_1 |
| 34036909 | RSU_F_ASIC_CHANNEL_SPI_2 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_2 |
| 34036910 | RSU_F_ASIC_CHANNEL_SPI_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_3 |
| 34036911 | RSU_F_ASIC_CHANNEL_SPI_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_4 |
| 34036912 | RSU_F_ASIC_CHANNEL_SPI_5 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_5 |
| 34036913 | RSU_F_ASIC_CHANNEL_SPI_6 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_6 |
| 34036914 | RSU_F_ASIC_CHANNEL_SPI_7 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_7 |
| 34036915 | RSU_F_ASIC_CHANNEL_SPI_8 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_8 |
| 34036916 | RSU_F_ASIC_CHANNEL_SPI_9 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_9 |
| 34036917 | RSU_F_ASIC_CHANNEL_SPI_10 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_10 |
| 34036918 | RSU_F_ASIC_CHANNEL_SPI_11 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_SPI_11 |
| 34036919 | RSU_F_ASIC_CHANNEL_CONFIG_0 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_0 |
| 34036920 | RSU_F_ASIC_CHANNEL_CONFIG_1 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_1 |
| 34036921 | RSU_F_ASIC_CHANNEL_CONFIG_2 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_2 |
| 34036922 | RSU_F_ASIC_CHANNEL_CONFIG_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_3 |
| 34036923 | RSU_F_ASIC_CHANNEL_CONFIG_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_4 |
| 34036924 | RSU_F_ASIC_CHANNEL_CONFIG_5 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_5 |
| 34036925 | RSU_F_ASIC_CHANNEL_CONFIG_6 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_6 |
| 34036926 | RSU_F_ASIC_CHANNEL_CONFIG_7 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_7 |
| 34036927 | RSU_F_ASIC_CHANNEL_CONFIG_8 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_8 |
| 34036928 | RSU_F_ASIC_CHANNEL_CONFIG_9 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_9 |
| 34036929 | RSU_F_ASIC_CHANNEL_CONFIG_10 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_10 |
| 34036930 | RSU_F_ASIC_CHANNEL_CONFIG_11 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CONFIG_11 |
| 34036931 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_0 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_0 |
| 34036932 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_1 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_1 |
| 34036933 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_2 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_2 |
| 34036934 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_3 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_3 |
| 34036935 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_4 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_4 |
| 34036936 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_5 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_5 |
| 34036937 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_6 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_6 |
| 34036938 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_7 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_7 |
| 34036939 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_8 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_8 |
| 34036940 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_9 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_9 |
| 34036941 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_10 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_10 |
| 34036942 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_11 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_ASIC_CHANNEL_CRC_CHECKER_11 |
| 34036943 | RSU_F_SAT_COMM_0 | Approved | Functional Requirement | DTC=0x9236; FTB=81 | RSU_F_SAT_COMM_0 |
| 34036944 | RSU_F_SAT_COMM_1 | Approved | Functional Requirement | DTC=0x9236; FTB=81 | RSU_F_SAT_COMM_1 |
| 34036945 | RSU_F_SAT_COMM_2 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_2 |
| 34036946 | RSU_F_SAT_COMM_3 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_3 |
| 34036947 | RSU_F_SAT_COMM_4 | Approved | Functional Requirement | DTC=0x9237; FTB=81 | RSU_F_SAT_COMM_4 |
| 34036948 | RSU_F_SAT_COMM_5 | Approved | Functional Requirement | DTC=0x9237; FTB=81 | RSU_F_SAT_COMM_5 |
| 34036949 | RSU_F_SAT_COMM_6 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_6 |
| 34036950 | RSU_F_SAT_COMM_7 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_7 |
| 34036951 | RSU_F_SAT_COMM_8 | Approved | Functional Requirement | DTC=0x920A; FTB=81 | RSU_F_SAT_COMM_8 |
| 34036952 | RSU_F_SAT_COMM_9 | Approved | Functional Requirement | DTC=0x920A; FTB=81 | RSU_F_SAT_COMM_9 |
| 34036953 | RSU_F_SAT_COMM_10 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_10 |
| 34036954 | RSU_F_SAT_COMM_11 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_11 |
| 34036955 | RSU_F_SAT_COMM_12 | Approved | Functional Requirement | DTC=0x920B; FTB=81 | RSU_F_SAT_COMM_12 |
| 34036956 | RSU_F_SAT_COMM_13 | Approved | Functional Requirement | DTC=0x920B; FTB=81 | RSU_F_SAT_COMM_13 |
| 34036957 | RSU_F_SAT_COMM_14 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_14 |
| 34036958 | RSU_F_SAT_COMM_15 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_15 |
| 34036959 | RSU_F_SAT_COMM_16 | Approved | Functional Requirement | DTC=0x8090; FTB=81 | RSU_F_SAT_COMM_16 |
| 34036960 | RSU_F_SAT_COMM_17 | Approved | Functional Requirement | DTC=0x8090; FTB=81 | RSU_F_SAT_COMM_17 |
| 34036961 | RSU_F_SAT_COMM_18 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_18 |
| 34036962 | RSU_F_SAT_COMM_19 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_19 |
| 34036963 | RSU_F_SAT_COMM_20 | Approved | Functional Requirement | DTC=0x8095; FTB=81 | RSU_F_SAT_COMM_20 |
| 34036964 | RSU_F_SAT_COMM_21 | Approved | Functional Requirement | DTC=0x8095; FTB=81 | RSU_F_SAT_COMM_21 |
| 34036965 | RSU_F_SAT_COMM_22 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_22 |
| 34036966 | RSU_F_SAT_COMM_23 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_23 |
| 34036967 | RSU_F_SAT_COMM_24 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_24 |
| 34036968 | RSU_F_SAT_COMM_25 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_25 |
| 34036969 | RSU_F_SAT_COMM_26 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_26 |
| 34036970 | RSU_F_SAT_COMM_27 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_27 |
| 34036971 | RSU_F_SAT_COMM_28 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_28 |
| 34036972 | RSU_F_SAT_COMM_29 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_29 |
| 34036973 | RSU_F_SAT_COMM_30 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_30 |
| 34036974 | RSU_F_SAT_COMM_31 | Approved | Functional Requirement | DTC=0x9262; FTB=0 | RSU_F_SAT_COMM_31 |
| 34036975 | RSU_F_SAT_COMM_32 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_32 |
| 34036976 | RSU_F_SAT_COMM_33 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_33 |
| 34036977 | RSU_F_SAT_COMM_34 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_34 |
| 34036978 | RSU_F_SAT_COMM_35 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_35 |
| 34036979 | RSU_F_SAT_COMM_36 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_36 |
| 34036980 | RSU_F_SAT_COMM_37 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_37 |
| 34036981 | RSU_F_SAT_COMM_38 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_38 |
| 34036982 | RSU_F_SAT_COMM_39 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_39 |
| 34036983 | RSU_F_SAT_COMM_40 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_40 |
| 34036984 | RSU_F_SAT_COMM_41 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_41 |
| 34036985 | RSU_F_SAT_COMM_42 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_42 |
| 34036986 | RSU_F_SAT_COMM_43 | Approved | Functional Requirement | DTC=0x9013; FTB=49 | RSU_F_SAT_COMM_43 |

### GPO
| Metric | Value |
| --- | --- |
| Rows | 40 |
| Statuses | Approved: 36, n/a: 4 |
| Types | Functional Requirement: 36, Information: 4 |
| Verification methods | SW Qualification: 40 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 34046995 | Crash Output Configuration | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(255... |
| 34046999 | Crash Output Initialization Behavior | Approved | Functional Requirement |  | During initialization after power ON, the software shall ensure that the crash output signal shall remain at a constant high level. The software shall ensure that the initialization time shall be between 350 milliseconds and 400 milliseconds to guarantee ti... |
| 34047024 | Crash Output PWM Signal Timing during No Deployment | Approved | Functional Requirement |  | The software shall send the crash output signal as a PWM signal with a fixed period of 40 ms. During no deployment, the PWM duty cycle shall be 25 ms high and 15 ms low. |
| 34047035 | Crash Output PWM Signal Timing during Deployment | Approved | Functional Requirement |  | The software shall send the crash output signal as a PWM signal with a fixed period of 40 ms. During a deployment event lasting 20 cycles (800 ms), the duty cycle shall be 15 ms high and 25 ms low to clearly differentiate between normal and deployment states. |
| 34047046 | Behavior of Crash output during De-Configured in EOL Code and Load is connected | Approved | Functional Requirement |  | The Software shall send the crash output pulse during IGN ON when the hardware crash output feature is disabled as per below: - The AECU shall continue Init pulse sequence until the PDC completes and identifies that the crash output feature is disabled. - A... |
| 34047216 | Behavior of Crash output during OPEN / STB | Approved | Functional Requirement |  | During the IGN ON state, the software shall send the crash output signal as a normal pulse with reduced amplitude if No load is connected to the crash output pin (Crash output Open). [!1761832805132.png#941fdef13a5e4ae6fb6126b1b317e53d!] ;font-style:normal;... |
| 34047235 | Behavior of Crash output during STG | Approved | Functional Requirement |  | The software shall send the crash output signal as a constant low during IGN ON if the crash output pin is shorted to the ground line. [!1753342663371.png#c5211b8f52be584598e7098908be6a13!] |
| 34047242 | Behavior of Crash output during IGN ON Normal Mode | Approved | Functional Requirement |  | The software shall send the crash output signal during the ignition ON state according to the specified behavior shown in the associated diagram. \\ \\ [!1753342814314.png#268771353e3981cc7ee7d70cb34077f1!] |
| 34047247 | Behavior of Crash output during IGN ON and High Side Crash Detection | Approved | Functional Requirement |  | The software shall send the crash output signal during the ignition ON state in accordance with the specified behavior shown in the associated diagram. \\ [!1753342894271.png#58db072a12269806066cc76d6fe2dc22!] |
| 34047251 | Behavior of Crash output during IGN ON and Low Side Crash Detection | Approved | Functional Requirement |  | The software shall send the crash output signal during the ignition ON state as specified in the associated diagram. \\ [!1753342959143.png#a50ef71e9f62d26f03d422ffe6529b26!] |
| 34047252 | Behavior of Crash output during crash battery disconnected | Approved | Functional Requirement |  | The software shall send the crash output signal during the battery disconnected during crash state according to the specified behavior shown in the associated diagram. \\ [!1753343046708.png#bab3155cdcccd54057e9ad38e2820d3d!] |
| 34047253 | Behavior of Crash output during Housekeeping/Post Run | Approved | Functional Requirement |  | The software shall send the crash output signal during the post run/housekeeping state according to the specified behavior shown in the associated diagram. \\ [!1753343105627.png#5808e593013507c348a535c1e2c11665!] |
| 34054345 | GPO1 Type | Approved | Functional Requirement |  | The software shall support CH1 as a PADI Lamp ON type with low side control. |
| 34054347 | GPO1 configuration | Approved | Functional Requirement |  | The software shall configure CH1 as the PADI Lamp ON signal. |
| 34054355 | Behavior of GPO1 during Short to Battery | Approved | Functional Requirement |  | The software shall send the GPO1 output pin as a constant high (Lamp is Off) when shorted to Battery. \\ [!1753424567485.png#edee370d5622a3428a15821b9c5e25f3!] |
| 34054358 | Behavior of GPO1 during Lamp OFF Short to Ground and load connected | Approved | Functional Requirement |  | The software shall send the GPO1 output pin as a constant low if the pin is shorted to any ground pin. \\ [!1762177555657.png#3237c216ebf72546f4e033e80fcabd21!] |
| 34054369 | Behavior of GPO1 during Load connected and De-Configured in EOL | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(255... |
| 34615209 | Behavior of GPO1 during Lamp ON and OPEN DTC is set | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(255... |
| 34054378 | Behavior of GPO1 during Lamp OFF and OPEN DTC is set. | Approved | Functional Requirement |  | The software shall send the GPO1 output pin as a constant high during an OPEN DTC condition. |
| 34054381 | Behavior of PADI Lamp On during PSGR_AIRBAG_SW_IC PAB ON | Approved | Functional Requirement |  | Post proveout, ECU shall switch the PADI Lamp ON output to constant low pulse (Lamp ON) during PSGR_AIRBAG_SW_IC received as PAB ON (0x0). \\ |
| 34054386 | Behavior of PADI Lamp On during PSGR_AIRBAG_SW_IC PAB OFF | Approved | Functional Requirement |  | Post proveout, ECU shall switch the PADI Lamp ON output to constant High (Lamp OFF) during PSGR_AIRBAG_SW_IC received as PAB Off (0x1). |
| 34054387 | Behavior of PADI Lamp On during IC2_100 Node Absent | Approved | Functional Requirement |  | Post proveout, The software shall switch the PADI Lamp ON output to a constant low state (Lamp ON) when the IC2_100 node is absent. \\ |
| 34054399 | GPO2 Type | Approved | Functional Requirement |  | The software shall support CH2 as a PADI Lamp OFF type with low side control. |
| 34054473 | GPO2 Configuration | Approved | Functional Requirement |  | The software shall configure CH2 as the PADI Lamp OFF signal. |
| 34054580 | Behavior of GPO2 during Lamp OFF Short to Battery and Load connected | Approved | Functional Requirement |  | The software shall send the PADI Lamp OFF output pin as a constant high when shorted to Battery. \\ [CB:/displayDocument/1762177391410.png?task_id=34615202&artifact_id=151551324&version=1&history=false&notification=false] |
| 34054582 | Behavior of GPO2 during Lamp Off during Short to Ground and load connected | Approved | Functional Requirement |  | The software shall send the GPO2 output pin as a constant low if the pin is shorted to any ground pin. \\ [CB:/displayDocument/1762177555657.png?task_id=34054358&artifact_id=151551362&version=1&history=false&notification=false] |
| 34054604 | Behavior of GPO2 during Load Connected and de-configured in EOL | Approved | Functional Requirement |  | The software shall send the PADI Lamp OFF output pin as a constant high during an EOL configuration error. \\ [!1753425447270.png#11ee96b7c98df26045087673206ae65f!] |
| 34054606 | Behavior of GPO2 during Lamp ON and OPEN DTC is set | Approved | Functional Requirement |  | The software shall send the GPO2 output pin as constant low during no load is connected to the GPO2 pin \\ [CB:/displayDocument/1762177878800.png?task_id=34615209&artifact_id=151551424&version=1&history=false&notification=false] |
| 34054650 | Behavior of PADI Lamp Off during PSGR_AIRBAG_SW_IC PAB OFF | Approved | Functional Requirement |  | The software shall switch the PADI Lamp OFF output to a low constant pulse (HW Lamp ON) when PSGR_AIRBAG_SW_IC is received as PAB OFF. \\ |
| 34054708 | Behavior of PADI Lamp Off during PSGR_AIRBAG_SW_IC PAB ON | Approved | Functional Requirement |  | The software shall switch the PADI Lamp OFF output to a high constant pulse (HW lamp OFF) when PSGR_AIRBAG_SW_IC is received as PAB ON. |
| 34054829 | Behavior of PADI Lamp Off during IC2_100 Node Absent | Approved | Functional Requirement |  | The software shall switch the PADI Lamp OFF output to a high constant pulse (HW lamp OFF) when the IC2_100 node is absent. \\ |
| 34054926 | Behavior of INDC_PADL Lamp OFF in 2C0 message | Approved | Functional Requirement |  | The software shall send the INDC PADL as Lamp OFF if any of the following conditions are met: # PSGR_AIRBAG_SW_IC is set as PAB ON (0x00). # IC2_100 node is absent. # Using IO control feature |
| 34054940 | Behavior of INDC_PADL Lamp ON in 2C0 message | Approved | Functional Requirement |  | The software shall send the INDC PADL as Lamp ON when PSGR_AIRBAG_SW_IC is set as PAB OFF (0x01). |
| 34054942 | Behavior of INDC_PADL during Prove out / IGN ON | Approved | Functional Requirement |  | The software shall send the INDC PADL as ON for 6 seconds and OFF for 1 second, after which the INDC PADL status shall be updated based on diagnostics and PAB status. |
| 34054953 | Refer the DTC for Active | Approved | Functional Requirement |  | [Active State SUBS_DTC-33620984/ISSUE:33620984] |
| 34054954 | Refer the DTC for Historic | Approved | Functional Requirement |  | [Healed/Historic State SUBS_DTC-33620997/ISSUE:33620997] |

### IOControl
| Metric | Value |
| --- | --- |
| Rows | 55 |
| Statuses | Approved: 44, n/a: 11 |
| Types | Functional Requirement: 44, Heading: 11 |
| Verification methods | SW Qualification: 55 |

### RoutineList
| Metric | Value |
| --- | --- |
| Rows | 35 |
| Statuses | Approved: 30, n/a: 4, Obsolete: 1 |
| Types | Functional Requirement: 31, Heading: 4 |
| Verification methods | SW Qualification: 35 |

### VIN
| Metric | Value |
| --- | --- |
| Rows | 36 |
| Statuses | Approved: 35, n/a: 1 |
| Types | Functional Requirement: 35, Information: 1 |
| Verification methods | SW Qualification: 34, SW Integration: 2 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 34468717 | Functionality | Approved | Functional Requirement |  | When the ACU is virgin (new from the plant), the software shall store the VIN data byte in EEPROM as hexadecimal default value 0x39. |
| 34468718 | Functionality | Approved | Functional Requirement |  | Upon receiving Diagnostic request $F190 with VIN Data and Security level 1 Unlocked, the software shall write 17 bytes of VIN Data to EEPROM. |
| 34468719 | Functionality | Approved | Functional Requirement |  | The software shall perform the VIN validation only during the ignition ON / CAN WAKEP phase at system initialization. |
| 34694129 | Functionality | Approved | Functional Requirement |  | The software shall perform the VIN validation after below conditions are recovered if the VIN validation is not completed - Bus off fast recovery - Bus off slow recovery - Under and Over Voltage recovery - Cranking |
| 34468721 | Functionality | Approved | Functional Requirement |  | The software shall start the comparison with the VIN data received on CAN during normal condition after DID 0103 parameter NM IGN On Startup Delay (Default Value - 2000ms) from ignition ON / CAN WAKEUP. - No Bus off condition is set - No Under and Over Volt... |
| 34694499 | Functionality | Approved | Functional Requirement |  | The software shall start the comparison with the VIN data received on CAN if fault conditions are recovered (Low Voltage, High Voltage, Bus off recovery and cranking) after DID 0103 parameter NM IGN On Startup Delay (Default Value - 2000ms) + NM Restart Del... |
| 34468723 | Functionality | Approved | Functional Requirement |  | The software shall receive the 17-byte VIN data in three cycles, each identified by a VIN_INDEX value of 0, 1, or 2. |
| 34571862 | Functionality | Approved | Functional Requirement |  | The software shall receive the first 7 bytes of VIN data when VIN_INDEX equals 0. |
| 34571863 | Functionality | Approved | Functional Requirement |  | The software shall receive the second 7 bytes of VIN data when VIN_INDEX equals 1. |
| 34571864 | Functionality | Approved | Functional Requirement |  | The software shall receive the last 3 bytes of VIN data when VIN_INDEX equals 2. |
| 34468724 | Functionality | Approved | Functional Requirement |  | The software shall validate VIN data by considering all three VIN_INDEX combinations are valid. Note: Combinations shall be VIN_INDEX 0,1,2 is valid ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;te... |
| 34468725 | Functionality | Approved | Functional Requirement |  | The software shall stop any subsequent VIN validation attempts after the first set of complete VIN data passes the validation check. |
| 34697132 | Functionality | Approved | Functional Requirement |  | The software shall set the VIN mismatch DTC VIN_MISMATCH_ERROR during incomplete VIN_INDEX frames (0,1,2) are received at VIN Check. |
| 34468726 | Functionality | Approved | Functional Requirement |  | The software shall attempt to validate each subsequent set of complete VIN data until the elapsed time since Ignition ON / CAN WAKEUP reaches as per VIN DTC qualification time. |
| 34468728 | Functionality | Approved | Functional Requirement |  | The software shall not set the VIN mismatch DTC VIN_MISMATCH_ERROR during IGN ON/ CAN WAKEUP if the software detects a bus-off condition on the CAN bus. |
| 34571972 | Functionality | Approved | Functional Requirement |  | During IGN ON/ CAN WAKEUP, the software shall not set the VIN mismatch DTC - VIN_MISMATCH_ERROR if the voltage is below the undervoltage threshold. |
| 34571973 | Functionality | Approved | Functional Requirement |  | During IGN ON/ CAN WAKEUP, the software shall not set the VIN mismatch DTC - VIN_MISMATCH_ERROR if the voltage exceeds the specified Overvoltage threshold. |
| 34571975 | Functionality | Approved | Functional Requirement |  | During IGN ON/ CAN WAKEUP, the software shall not set the VIN mismatch DTC - VIN_MISMATCH_ERROR if the variant code is active. |
| 34571978 | Functionality | Approved | Functional Requirement |  | During IGN ON / WAKEUP, the software shall suppressed VIN mismatch DTC VIN_MISMATCH_ERROR if the VIN master node absent DTC is active. |
| 34694742 | Functionality | Approved | Functional Requirement |  | During IGN ON / WAKEUP, the software shall suppressed VIN mismatch DTC VIN_MISMATCH_ERROR if the VIN master key message content failure DTC is active. |
| 34694824 | Functionality | Approved | Functional Requirement |  | During IGN ON / WAKEUP, the software shall suppressed VIN mismatch DTC VIN_MISMATCH_ERROR if the STS_ENG = 0x1(Vehicle cranking due to T50) / 0x5(Vehicle cranking due to ESS). |
| 34468729 | Functionality | Approved | Functional Requirement |  | The Software shall allow to write the 17Bytes of VIN data with any value in hexadecimal format. |
| 34695005 | Functionality | Approved | Functional Requirement |  | The Software shall set the VIN mismatch DTC VIN_MISMATCH_ERROR during VIN Data received via CAN and VIN written in the EEPROM is mismatched. |
| 34468730 | Functionality | Approved | Functional Requirement |  | The software shall set the VIN mismatch DTC VIN_MISMATCH_ERROR if each of the 17 bytes of the received VIN data and each of the 17 bytes of the VIN data stored in the EEPROM are 0x00. |
| 34697149 | Functionality | Approved | Functional Requirement |  | The software shall set the VIN mismatch DTC VIN_MISMATCH_ERROR if each of the 17 bytes of the received VIN data are zeros and each of the 17 bytes of the VIN data stored in the EEPROM are non-zero. |
| 34572087 | Functionality | Approved | Functional Requirement |  | The software shall increment the comparison count by one upon the failure. |
| 34572089 | Functionality | Approved | Functional Requirement |  | The software shall set the VIN_MISMATCH_ERROR flag when the comparison count reaches three. |
| 34468731 | Functionality | Approved | Functional Requirement |  | If all the 17 bytes of VIN Data received are default value 0x39 & All the 17 bytes of VIN Data stored in EEPROM are also 0x39, then the software will be considered as a failure case. (VIN_MISMATCH_ERROR will not be set). |
| 34468732 | Functionality | Approved | Functional Requirement |  | The software shall restart the VIN validation check when any of the following conditions is recovered during IGN ON initialization or CAN wakeup, provided that the VIN validation is incomplete: * the VIN master node DTC becomes historic * the BUS OFF DTC be... |
| 34468733 | Functionality | Approved | Functional Requirement |  | The software shall stop the VIN validation check when any of the following conditions is set during IGN ON initialization or CAN wakeup, provided that the VIN validation is incomplete: - VIN master node DTC active. - BUS OFF DTC active. - Variant code DTC a... |
| 34572133 | Functionality | Approved | Functional Requirement |  | If the VIN received via CAN matches the VIN stored in EEPROM, the software shall not perform any further VIN comparison and shall not register the VIN Mismatch Diagnostic Trouble Code (DTC). |
| 34572135 | Functionality | Approved | Functional Requirement |  | The software shall suppress the DLC Error Monitoring for the VIN_MESSAGE if the VIN validation is completed and passed. |
| 34572248 | Functionality | Approved | Functional Requirement |  | If the engine remains in the cranking state (STS_ENG = 0x1) for more than 10 seconds, the software shall perform the VIN validation as per Network Identifier Value 0103 after 10 seconds of continuous cranking. |
| 34468740 | Functionality | Approved | Functional Requirement |  | The software shall disable the VIN comparison during the ACU post run phase and during every interrupted post run phase. |
| 34468741 | Functionality | Approved | Functional Requirement |  | The software shall inhibit the deployment when the VIN mismatch DTC is active. |

### Variant_Code
| Metric | Value |
| --- | --- |
| Rows | 54 |
| Statuses | Approved: 42, Obsolete: 9, n/a: 3 |
| Types | Functional Requirement: 51, Information: 3 |
| Verification methods | SW Qualification: 51 |

Key indexed rows:
| ID | Summary | Status | Type | Fields | Description / Criteria |
| --- | --- | --- | --- | --- | --- |
| 34019142 | Functionality | Approved | Functional Requirement |  | During the Initialization, the software shall perform a variant code check from NVM. |
| 34462978 | Functionality | Approved | Functional Requirement |  | If ACU is virgin, the software shall store Variant code as 0x0 in NVM note: Virgin means it's a brand new directly from Manufacturing Plant. |
| 34462988 | Functionality | Approved | Functional Requirement |  | The software shall accept the variant code DID $0101 when the following conditions are met: - Enable Security Level 1 when the extended session is unlocked. - Vehicle speed is less than 5 kilometers per hour (km/h). |
| 34463107 | Functionality | Approved | Functional Requirement |  | Once the Variant code is written to the NVM, the software shall require toggle IGN ON to enable the devices as per new variant Code. |
| 34019737 | Functionality | Approved | Functional Requirement |  | During ACU initialization, the software shall read the Variant code from NVM and activate the corresponding configuration. |
| 34463002 | Functionality | Approved | Functional Requirement |  | The software shall respond with NRC 88 upon receiving the Diagnostic request $0101 with variant code if the vehicle speed exceeds 5 km/h. |
| 34019755 | Functionality | Approved | Functional Requirement |  | The software shall perform a Variant Code check during the ACU initialization process at every Ignition ON. |
| 34020257 | Functionality | Approved | Functional Requirement |  | The software shall ensure that a Variant Code error is not recoverable within the same ignition cycle. |
| 34020265 | Functionality | Approved | Functional Requirement |  | The software shall write the variant code to ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0p... |
| 34463066 | Functionality | Approved | Functional Requirement |  | The software shall retain the variant code present in the NVM after completing the successful CAN flashing process. |
| 34020370 | Functionality | Approved | Functional Requirement |  | The software shall read the variant code in ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px... |
| 34020419 | Functionality | Approved | Functional Requirement |  | The software shall enable the corresponding node if the Variant code bit is set. |
| 34020422 | Functionality | Approved | Functional Requirement |  | The software shall disable the corresponding node If the Variant code bit is clear. |
| 34020937 | Functionality | Approved | Functional Requirement |  | The software shall enable/disable the bits in SRS variant code for Nodes based on availability (Refer DBC). |
| 34463106 | Functionality | Approved | Functional Requirement |  | The software shall enable the bits in variant code for below Key Nodes which are applicable for SRS ECU. EMS ABS ESC / IEB EPS SAS PKE / SKM ICU SRS PODS EPB ESCL TCU AMT ITM TC CNG DCT EBRANKING IC MBFM/BCM HVAC/CCM/FATC ETC EVDC ACC PTC HLCU WLC / WLC 1 S... |
| 34023017 | Functionality | Approved | Functional Requirement |  | The software shall require ACU Sleep after writing the Variant code to NVM in order to enable devices according to the new Variant code. |
| 34023602 | Functionality | Approved | Functional Requirement |  | If any of the below conditions are met, the software shall disable the specific functionality that requires CAN information from the partner ACU for the same ignition cycle. __-__ The partner ACU is not configured in the variant code. __- __The partner ACU... |
| 35127089 | ABS and ESC both nodes are enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:start;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(25... |
| 35127090 | ABS enabled and ESC disabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;text-decoration-thickness:initial;text-d... |
| 35127091 | ABS disabled and ESC Enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;text-decoration-thickness:initial;text-d... |
| 35127092 | ABS and ESC both nodes are disabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;text-decoration-thickness:initial;text-d... |
| 35127093 | ABS Node Enabled in Variant Code | Approved | Functional Requirement |  | During ABS Node enabled in variant code then software shall process the below messages and monitor all the related DTCs. 1. ESC12_10 (0x282). 2. ESC2_10 (0x2CC). 3. ESC5_10 (0x10D). |
| 35127094 | ABS Node Enabled in Variant Code and EDR Recording | Approved | Functional Requirement |  | During ABS Node enabled in variant code then the software shall process the below messages and if any error in the messages, then as per On-fail specification values will be recorded in EDR during the event of crash. 1. ESC12_10 (0x282). 2. ESC2_10 (0x2CC).... |
| 35127095 | ABS Node Enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:start;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(25... |
| 35127096 | ABS Node Enabled in Variant Code and EDR Recording | Approved | Functional Requirement |  | When the ABS Node is enabled in the variant code, the software shall record the default value in EDR during the crash event for below signals: 1. LATTERAL_ACCEL as 0. 2. LONG_ACCEL as 0. 3. YAW_RATE as 0. |
| 35127097 | ESC Node Enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(245... |
| 35127098 | Snapshot DID F1B2 recording during ABS or ESC Node Enabled | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(245... |
| 35127100 | TCU and AMT both nodes are enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:start;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(25... |
| 35127101 | TCU enabled and AMT disabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;text-decoration-thickness:initial;text-d... |
| 35127102 | TCU disabled and AMT Enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;text-decoration-thickness:initial;text-d... |
| 35127103 | TCU and AMT both nodes are disabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;text-decoration-thickness:initial;text-d... |
| 35127104 | TCU node Enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:start;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(25... |
| 35127105 | TCU Node Enabled in Variant Code and EDR Recording | Approved | Functional Requirement |  | During TCU Node enabled in variant code then software shall process the TCU5_10 (0x136) message and if any error in the message, then as per On-fail specification values will be recorded in EDR during the event of crash. |
| 35127106 | AMT node Enabled in Variant Code | Approved | Functional Requirement |  | ;font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:start;text-indent:0px;text-transform:none;widows:2;word-spacing:0px;-webkit-text-stroke-width:0px;white-space:normal;background-color:rgb(25... |
| 34038560 | DTC Management | Approved | Functional Requirement |  | The software shall qualify an SRS Variant code error during variant code checks if any of the following conditions are met: \\ If both ABS and ESC bits are set as Present. If both AMT and TCU bits are set as Present. If both PKE and ICU bits are set as Pres... |
| 34038867 | DTC Management | Approved | Functional Requirement |  | The software shall qualify a Node Absent error if the partner ACU is configured in the Variant code and the respective key CAN message is not received. |
| 34046894 | DTC Management | Approved | Functional Requirement |  | If the partner ACU is configured in the Variant code and the respective CAN message is not received, then the software shall qualify a Node Absent error which is applicable only to the SRS ACU. |
| 34583853 | DTC Management | Approved | Functional Requirement |  | If byte 0 bit 0 is zero, then the software shall set the variant code DTC. |
| 34583857 | DTC Management | Approved | Functional Requirement |  | If byte 0 bit 0 is one, then the software shall set the variant code DTC is inactive. |
| 34852531 |  | Approved | Functional Requirement |  | The software shall consider gear information only if both the EMS and TCU nodes are indicated as present (0x01). In this case, the CURRENT_GEAR_MT signal from EMS1 shall be ignored. |
| 34852532 |  | Approved | Functional Requirement |  | The software shall use gear information from the EMS if the EMS node is present and the TCU node is not indicated as present (0x01). In this scenario, the TCU node shall be considered disabled. |
| 34852533 |  | Approved | Functional Requirement |  | The software shall consider gear information from the TCU if the TCU node is indicated as present (0x01) and the EMS node is indicated as not present (0x00). In this case, the CURRENT_GEAR_MT Signal shall be treated as disabled. |

## Companion Files
- `module_requirement_catalog.csv`: full extracted requirement rows for all modules.
- `module_testcase_catalog.csv`: full extracted testcase rows and flattened action/expected-result text.
- `module_skill_generation_review.txt`: included/skipped files, counts, and validation summary.
