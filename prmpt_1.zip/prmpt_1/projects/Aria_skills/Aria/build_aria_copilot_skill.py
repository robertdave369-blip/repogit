from __future__ import annotations

import csv
import re
import textwrap
import zlib
from collections import Counter, defaultdict
from pathlib import Path


PDF_PATH = Path(r"C:\ARIA5.20\Documentation\ARIA User Functions.pdf")
TS_PATHS = [
    Path(r"C:\27_tax_\tax_april_test_files_27\Framework_UPP_Krishna\Library\libCommon.ts"),
    Path(r"C:\27_tax_\tax_april_test_files_27\Framework_UPP_Krishna\Library\libExtractResultTest.ts"),
    Path(r"C:\27_tax_\tax_april_test_files_27\Framework_UPP_Krishna\Library\libMahindra.ts"),
]

OUT_MD = Path("ARIA_TS_COPILOT_SKILL.md")
OUT_CSV = Path("aria_ts_function_catalog.csv")
OUT_REVIEW = Path("aria_ts_skill_review.txt")
OUT_PDF_TEXT = Path("aria_user_functions_pdf_extracted_compact.txt")


CONTROL_WORDS = {
    "if",
    "for",
    "while",
    "switch",
    "catch",
    "function",
    "return",
    "parseInt",
    "parseFloat",
    "String",
    "Number",
    "Boolean",
    "Array",
    "Object",
    "Math.abs",
    "Math.round",
    "Math.floor",
    "Math.ceil",
}

DIRECT_API_PREFIXES = {
    "ARIA",
    "CAN",
    "RESULT",
    "Thread",
    "PS",
    "PowerSupply",
    "LAMPS",
    "RSU",
    "SQUIB",
    "SPI",
    "SLS",
    "LOG",
    "MessageBox",
    "ActiveXObject",
    "PowerOn",
    "PowerOff",
    "PowerSetVoltage",
    "Crash",
    "Date",
}


DOMAIN_RULES = [
    ("Bench / Power / Ignition", r"bench|power|ign|voltage|gpo|normal_condition|back_to_dv"),
    ("Diagnostics / UDS / DTC", r"dtc|diag|session|security|seed|key|routine|did|vin|reset|nrc|wdbi|testerpresent"),
    ("CAN / Message / Signal / Logging", r"can|frame|message|signal|periodic|periodicity|dlc|log|rx|tx"),
    ("EDR Read / Decode", r"edr|parameter|reserved|decodeparameter|printparameter"),
    ("Crash / Deployment / RSU / Squib", r"crash|deploy|rsu|squib|dcs|pads|padi|ens|lamp"),
    ("Result / Reporting / Extraction", r"result|compare|eval|extract|plot|screenshot|saleae|scope"),
    ("Utilities / Conversion / File Parsing", r"hex|byte|bit|array|pad|range|sort|convert|timestamp|time|sleep|line|file|twos"),
]


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    return re.sub(r"//.*", "", text)


def line_number(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def find_matching_brace(text: str, open_idx: int) -> int:
    depth = 0
    in_string = ""
    escaped = False
    for idx in range(open_idx, len(text)):
        char = text[idx]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == in_string:
                in_string = ""
            continue
        if char in {"'", '"'}:
            in_string = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return idx
    return len(text) - 1


def categorize(name: str, signature: str) -> str:
    value = f"{name} {signature}".lower()
    for domain, pattern in DOMAIN_RULES:
        if re.search(pattern, value):
            return domain
    return "Other / Project Specific"


def parse_ts_functions() -> list[dict]:
    all_functions: list[dict] = []
    function_re = re.compile(r"\bfunction\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*(?::\s*[A-Za-z_][\w\[\]]*)?\s*\{", re.M)
    for path in TS_PATHS:
        raw = path.read_text(encoding="utf-8", errors="ignore")
        clean = strip_comments(raw)
        for match in function_re.finditer(clean):
            name = match.group(1)
            args = re.sub(r"\s+", " ", match.group(2).strip())
            open_brace = clean.find("{", match.end() - 1)
            close_brace = find_matching_brace(clean, open_brace)
            body = clean[open_brace + 1 : close_brace]
            signature = f"function {name}({args})"
            all_functions.append(
                {
                    "file": path.name,
                    "path": str(path),
                    "line": line_number(clean, match.start()),
                    "name": name,
                    "signature": signature,
                    "args": args,
                    "body": body,
                    "domain": categorize(name, signature),
                }
            )
    return all_functions


def extract_calls(functions: list[dict]) -> tuple[list[dict], Counter]:
    wrapper_names = {fn["name"] for fn in functions}
    external_counter: Counter = Counter()
    call_re = re.compile(r"\b([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)\s*\(")
    for fn in functions:
        calls = []
        external = []
        for match in call_re.finditer(fn["body"]):
            call = match.group(1)
            if call in CONTROL_WORDS or call == fn["name"]:
                continue
            if call in wrapper_names:
                calls.append(call)
            elif call.split(".")[0] in DIRECT_API_PREFIXES:
                external.append(call)
                external_counter[call] += 1
        fn["wrapper_calls"] = sorted(set(calls))
        fn["external_calls"] = sorted(set(external))
    return functions, external_counter


def stream_data(obj: bytes) -> bytes:
    match = re.search(rb"stream\r?\n(.*?)\r?\nendstream", obj, re.S)
    if not match:
        return b""
    raw = match.group(1)
    if b"/FlateDecode" in obj:
        try:
            raw = zlib.decompress(raw)
        except Exception:
            return b""
    return raw


def parse_cmap(raw: bytes) -> dict[bytes, str]:
    text = raw.decode("latin-1", "ignore")
    mapping: dict[bytes, str] = {}
    for block in re.finditer(r"beginbfchar(.*?)endbfchar", text, re.S):
        for src, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", block.group(1)):
            try:
                mapping[bytes.fromhex(src)] = bytes.fromhex(dst).decode("utf-16-be", "ignore")
            except Exception:
                pass
    for block in re.finditer(r"beginbfrange(.*?)endbfrange", text, re.S):
        body = block.group(1)
        for src1, src2, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", body):
            try:
                start = int(src1, 16)
                end = int(src2, 16)
                base = int(dst, 16)
                width = len(src1) // 2
                for code in range(start, end + 1):
                    mapping[code.to_bytes(width, "big")] = chr(base + code - start)
            except Exception:
                pass
    return mapping


def unescape_pdf_literal(data: bytes) -> bytes:
    out = bytearray()
    i = 0
    while i < len(data):
        char = data[i]
        if char == 92 and i + 1 < len(data):
            i += 1
            char = data[i]
            if char in b"nrtbf":
                out.append(32)
            elif char in b"()\\":
                out.append(char)
            elif 48 <= char <= 55:
                octal = bytes([char])
                steps = 0
                while i + 1 < len(data) and steps < 2 and 48 <= data[i + 1] <= 55:
                    i += 1
                    steps += 1
                    octal += bytes([data[i]])
                out.append(int(octal, 8))
            else:
                out.append(char)
        else:
            out.append(char)
        i += 1
    return bytes(out)


def decode_pdf_bytes(data: bytes, mapping: dict[bytes, str], keys: list[bytes]) -> str:
    out: list[str] = []
    i = 0
    while i < len(data):
        matched = False
        for key in keys:
            if data.startswith(key, i):
                out.append(mapping[key])
                i += len(key)
                matched = True
                break
        if not matched:
            if 32 <= data[i] < 127:
                out.append(chr(data[i]))
            i += 1
    return "".join(out)


def compact_pdf_text(text: str) -> str:
    compacted = re.sub(
        r"(?:(?<=\b)[A-Za-z0-9]\s+){2,}[A-Za-z0-9]\b",
        lambda m: m.group(0).replace(" ", ""),
        text,
    )
    return re.sub(r"\s+", " ", compacted).strip()


def normalize_pdf_api_name(name: str) -> str:
    value = name.replace("N", ".")
    fixes = {
        "Eunction": "Function",
        "Eault": "Fault",
        "Eilter": "Filter",
        "Erequency": "Frequency",
        "Erame": "Frame",
        "Erames": "Frames",
        "Elexray": "Flexray",
        "Erom": "From",
        "OEE": "OFF",
        "Dool": "Bool",
        "Dyte": "Byte",
        "ConfIgure": "Configure",
        "StartLampMonItorIng": "StartLampMonitoring",
        "GetLampRecordedSamples": "GetLampRecordedSamples",
        "SendDiagDy": "SendDiagBy",
        "SendAndWaItEor": "SendAndWaitFor",
    }
    for bad, good in fixes.items():
        value = value.replace(bad, good)
    return value


def extract_pdf_api_hints() -> tuple[list[str], str, int]:
    if not PDF_PATH.exists():
        return [], "", 0
    data = PDF_PATH.read_bytes()
    objects = {int(m.group(1)): m.group(2) for m in re.finditer(rb"(\d+)\s+0\s+obj(.*?)endobj", data, re.S)}
    cmap: dict[bytes, str] = {}
    for obj in objects.values():
        raw = stream_data(obj)
        if b"begincmap" in raw:
            cmap.update(parse_cmap(raw))
    keys = sorted(cmap.keys(), key=len, reverse=True)

    parts: list[str] = []
    for obj in objects.values():
        raw = stream_data(obj)
        if b"Tj" not in raw and b"TJ" not in raw:
            continue
        for match in re.finditer(rb"<([0-9A-Fa-f\s]+)>|\((?:\\.|[^\\)])*\)", raw, re.S):
            token = match.group(0)
            if token.startswith(b"<"):
                hex_value = re.sub(rb"\s+", b"", match.group(1))
                if len(hex_value) % 2:
                    continue
                value = bytes.fromhex(hex_value.decode())
            else:
                value = unescape_pdf_literal(token[1:-1])
            decoded = decode_pdf_bytes(value, cmap, keys)
            if decoded:
                parts.append(decoded)

    text = compact_pdf_text(" ".join(parts))
    OUT_PDF_TEXT.write_text(text[:500000], encoding="utf-8")

    namespaces = [
        "ARIA",
        "CAN",
        "LAMPS",
        "PS",
        "PowerSupply",
        "RESULT",
        "RSU",
        "SQUIB",
        "SPI",
        "LIN",
        "Flexray",
    ]
    api_hints = set()
    for ns in namespaces:
        for match in re.finditer(rf"\b{re.escape(ns)}N[A-Za-z0-9N]{{3,80}}", text):
            api_hints.add(normalize_pdf_api_name(match.group(0)))
    return sorted(api_hints), text, len(cmap)


def markdown_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        safe = [str(cell).replace("|", "/").replace("\n", " ").strip() for cell in row]
        lines.append("| " + " | ".join(safe) + " |")
    return lines


def write_catalog(functions: list[dict]) -> None:
    with OUT_CSV.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=[
                "name",
                "signature",
                "domain",
                "file",
                "line",
                "wrapper_calls",
                "external_calls",
            ],
        )
        writer.writeheader()
        for fn in functions:
            writer.writerow(
                {
                    "name": fn["name"],
                    "signature": fn["signature"],
                    "domain": fn["domain"],
                    "file": fn["file"],
                    "line": fn["line"],
                    "wrapper_calls": ", ".join(fn["wrapper_calls"]),
                    "external_calls": ", ".join(fn["external_calls"]),
                }
            )


def build_skill(functions: list[dict], external_counter: Counter, pdf_hints: list[str], cmap_entries: int) -> str:
    by_domain: dict[str, list[dict]] = defaultdict(list)
    by_file = Counter(fn["file"] for fn in functions)
    for fn in functions:
        by_domain[fn["domain"]].append(fn)

    external_by_namespace: dict[str, list[tuple[str, int]]] = defaultdict(list)
    for call, count in external_counter.most_common():
        namespace = call.split(".")[0] if "." in call else "global"
        external_by_namespace[namespace].append((call, count))

    lines: list[str] = []
    lines.extend(
        [
            "# ARIA TypeScript Copilot Local Skill",
            "",
            "Use this file as local Copilot/agent context for ARIA `.ts` test automation. It is intentionally standalone: do not place it in `.github/copilot-instructions.md` unless you explicitly want repository-wide Copilot sync.",
            "",
            "## Non-Negotiable Coding Rules",
            "- Target the ARIA TypeScript runtime style used by these libraries, effectively ECMAScript 2009 / ES5-compatible script.",
            "- Never use `let`, `const`, arrow functions, classes, template literals, destructuring, async/await, spread syntax, optional chaining, or modern module syntax.",
            "- Use `var` for every variable declaration.",
            "- Prefer existing wrappers from `libCommon.ts`, `libMahindra.ts`, and `libExtractResultTest.ts` before calling raw ARIA APIs.",
            "- Keep functions globally callable; do not introduce imports/exports unless the surrounding project already uses them.",
            "- Follow existing result style: use `RESULT.InterpretEqualResult`, `RESULT.InsertComment`, or existing wrapper comparison functions rather than ad-hoc logging.",
            "- Preserve existing timing patterns. Use `sleep(ms)` wrapper or `Thread.Sleep(ms)` consistently with surrounding code.",
            "",
            "## Source Map",
        ]
    )
    lines.extend(
        markdown_table(
            ["Source", "Purpose", "Parsed items"],
            [
                ["ARIA User Functions.pdf", "Direct ARIA API documentation. PDF text was extracted locally and normalized; use PDF hints as API discovery, not as a replacement for exact wrapper signatures.", f"{len(pdf_hints)} API hints, {cmap_entries} ToUnicode entries"],
                ["libCommon.ts", "Common utilities, CAN helpers, diagnostics, logging, power, crash utilities.", by_file.get("libCommon.ts", 0)],
                ["libExtractResultTest.ts", "Result extraction helper.", by_file.get("libExtractResultTest.ts", 0)],
                ["libMahindra.ts", "Project-specific Mahindra wrappers for bench, UDS, EDR, crash, DTC, CAN and fault flows.", by_file.get("libMahindra.ts", 0)],
            ],
        )
    )

    lines.extend(
        [
            "",
            "## Function Selection Graph",
            "```mermaid",
            "flowchart TD",
            "  Need[Need to write or modify an ARIA TS testcase] --> Style[Apply ES5/EMA2009 style: var only, no modern TS/JS syntax]",
            "  Style --> Existing{Does a wrapper already exist?}",
            "  Existing -->|Bench/power/IGN| Bench[Use Bench_Normal_Condition, Bench_Back_to_DV, cycle_IGN, powerSupplyControl]",
            "  Existing -->|UDS/DTC/security| Diag[Use enterExtSession, Internal_Security_Access, Read_DTC, clearDTC, routineControl, DataIdentifier_Read_Write]",
            "  Existing -->|CAN signal/frame| Can[Use changeCAN_SignalValue, generateSignal, generateMessage, setAllRxMessages, Verify_Periodicity_2C0/2C01]",
            "  Existing -->|EDR| Edr[Use read_EDR*, decodeParameterValues, printParameterValues, Default_Read_EDR]",
            "  Existing -->|Crash/fault| Fault[Use TriggerCrash, front_crash*, DisableFrameByName, EnableFrameByName, Message_Content_Failure, SetGpoFaultCondition]",
            "  Existing -->|Result parsing| Result[Use ExtractTestStatus, extractCompareResponseData, EvalManStepEqual]",
            "  Existing -->|No wrapper| Direct[Use direct ARIA API only after checking PDF/API hints and existing call patterns]",
            "  Direct --> Validate[Keep wrapper-like argument checks and RESULT interpretation]",
            "```",
            "",
            "## Preferred Wrapper Entry Points",
        ]
    )

    preferred = [
        ["Bench setup", "`Bench_Normal_Condition()`, `Bench_Back_to_DV()`, `cycle_IGN()`, `cycleIgnitionViaCAN()`", "Use at test start/end and before DTC-sensitive validation."],
        ["Power", "`powerSupplyControl(Voltage, Control, tDelay)`, `powersetVoltage(voltage)`, `powerReset(TDelay)`", "Prefer wrappers; they encode bench-specific behavior."],
        ["Diagnostics / DTC", "`enterExtSession()`, `Internal_Security_Access(...)`, `Read_DTC(...)`, `clearDTC()`, `clearDTC_Response(response)`", "Use existing UDS constants and compare through `RESULT`."],
        ["Routine / DID", "`routineControl(...)`, `DataIdentifier_Read_Write(...)`, `write_VIN_number()`, `NVM_Clear()`", "Avoid raw diag bytes unless no wrapper exists."],
        ["CAN signal/frame", "`changeCAN_SignalValue(...)`, `generateSignal(...)`, `generateMessage(...)`, `setAllRxMessages(...)`", "Use raw `CAN.*` only when wrapper lacks the exact operation."],
        ["CAN timing/logging", "`startCANLogging(...)`, `Verify_Periodicity_2C0(...)`, `Verify_Periodicity_2C01(...)`, `Verify_MsgDLC_2C0(...)`", "For log-based checks, preserve path and message-id conventions."],
        ["EDR", "`Default_Read_EDR()`, `readEDR*`, `read_EDR*`, `decodeParameterValues(...)`, `printParameterValues(...)`", "Use existing decode helpers for parameter-specific byte interpretation."],
        ["Crash/deployment", "`TriggerCrash()`, `front_crash*`, `left_side_crash*`, `right_side_crash*`, `rear_crash*`, `understage*`, `near_crash*`", "Use named crash wrappers so sensor/files/channel setup stays consistent."],
        ["Fault simulation", "`DisableFrameByName(...)`, `EnableFrameByName(...)`, `Message_Content_Failure(...)`, `SetGpoFaultCondition(...)`, `RSU_Faulty(...)`", "For pre/post crash faults, make the fault-active value and cleared value explicit."],
        ["Result extraction", "`ExtractTestStatus(pathName)`, `extractCompareResponseData(...)`, `EvalManStepEqual(...)`", "Use for post-processing and manual step assertions."],
    ]
    lines.extend(markdown_table(["Need", "Use", "Rule"], preferred))

    lines.extend(["", "## Wrapper Catalog By Domain"])
    for domain in sorted(by_domain):
        rows = []
        for fn in sorted(by_domain[domain], key=lambda x: (x["file"], x["line"], x["name"])):
            external = ", ".join(fn["external_calls"][:6])
            wrappers = ", ".join(fn["wrapper_calls"][:6])
            rows.append([fn["signature"], fn["file"], fn["line"], external, wrappers])
        lines.extend(["", f"### {domain}"])
        lines.extend(markdown_table(["Signature", "File", "Line", "Direct ARIA/API calls", "Wrapper calls"], rows))

    lines.extend(["", "## Direct ARIA API Namespaces Observed In Wrappers"])
    for namespace in sorted(external_by_namespace):
        calls = external_by_namespace[namespace][:25]
        call_text = ", ".join(f"`{call}` ({count})" for call, count in calls)
        lines.append(f"- `{namespace}`: {call_text}")

    lines.extend(["", "## PDF API Hints"])
    lines.append("These names were extracted from `ARIA User Functions.pdf`. The PDF uses embedded font maps, so a small amount of glyph normalization was applied. Prefer exact wrapper names above when available.")
    for namespace in ["ARIA", "CAN", "LAMPS", "PS", "PowerSupply", "RESULT", "RSU", "SQUIB", "SPI", "LIN", "Flexray"]:
        entries = [item for item in pdf_hints if item.startswith(namespace + ".")][:80]
        if entries:
            lines.append("")
            lines.append(f"### {namespace}")
            for chunk_start in range(0, len(entries), 8):
                lines.append("- " + ", ".join(f"`{entry}`" for entry in entries[chunk_start : chunk_start + 8]))

    lines.extend(
        [
            "",
            "## Generation / Maintenance",
            "- Regenerate this file with `python build_aria_copilot_skill.py` from the workspace directory.",
            "- Review `aria_ts_skill_review.txt` after regeneration; it reports parsed counts and high-frequency direct API calls.",
            "- If Copilot needs this context in a single prompt, attach this Markdown file. Do not rely on VS Code settings sync.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    functions = parse_ts_functions()
    functions, external_counter = extract_calls(functions)
    pdf_hints, _pdf_text, cmap_entries = extract_pdf_api_hints()

    write_catalog(functions)
    OUT_MD.write_text(build_skill(functions, external_counter, pdf_hints, cmap_entries), encoding="utf-8")

    review = [
        f"skill_file={OUT_MD.resolve()}",
        f"catalog_csv={OUT_CSV.resolve()}",
        f"pdf_compact_extract={OUT_PDF_TEXT.resolve()}",
        f"functions_parsed={len(functions)}",
        f"pdf_api_hints={len(pdf_hints)}",
        f"pdf_tounicode_entries={cmap_entries}",
        "",
        "functions_by_file:",
    ]
    for file, count in sorted(Counter(fn["file"] for fn in functions).items()):
        review.append(f"- {file}: {count}")
    review.extend(["", "functions_by_domain:"])
    for domain, count in sorted(Counter(fn["domain"] for fn in functions).items()):
        review.append(f"- {domain}: {count}")
    review.extend(["", "top_external_calls:"])
    for call, count in external_counter.most_common(40):
        review.append(f"- {call}: {count}")
    OUT_REVIEW.write_text("\n".join(review) + "\n", encoding="utf-8")

    print(f"Wrote {OUT_MD.resolve()}")
    print(f"Wrote {OUT_CSV.resolve()}")
    print(f"Wrote {OUT_REVIEW.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
