# ARIA TypeScript Copilot Local Skill

Use this file as local Copilot/agent context for ARIA `.ts` test automation. It is intentionally standalone: do not place it in `.github/copilot-instructions.md` unless you explicitly want repository-wide Copilot sync.

## Non-Negotiable Coding Rules
- Target the ARIA TypeScript runtime style used by these libraries, effectively ECMAScript 2009 / ES5-compatible script.
- Never use `let`, arrow functions, classes, template literals, destructuring, async/await, spread syntax, optional chaining, or modern module syntax.
- Use `var`, `const` for every variable declaration.
- Prefer existing wrappers from `libCommon.ts`, `libMahindra.ts`, and `libExtractResultTest.ts` before calling raw ARIA APIs.
- Keep functions globally callable; do not introduce imports/exports unless the surrounding project already uses them.
- Follow existing result style: use `RESULT.InterpretEqualResult`, `RESULT.InsertComment`, or existing wrapper comparison functions rather than ad-hoc logging.
- Preserve existing timing patterns. Use `sleep(ms)` wrapper or `Thread.Sleep(ms)` consistently with surrounding code.

## Source Map
| Source | Purpose | Parsed items |
| --- | --- | --- |
| ARIA User Functions.pdf | Direct ARIA API documentation. PDF text was extracted locally and normalized; use PDF hints as API discovery, not as a replacement for exact wrapper signatures. | 256 API hints, 210 ToUnicode entries |
| libCommon.ts | Common utilities, CAN helpers, diagnostics, logging, power, crash utilities. | 80 |
| libExtractResultTest.ts | Result extraction helper. | 1 |
| libMahindra.ts | Project-specific Mahindra wrappers for bench, UDS, EDR, crash, DTC, CAN and fault flows. | 152 |

## Function Selection Graph
```mermaid
flowchart TD
  Need[Need to write or modify an ARIA TS testcase] --> Style[Apply ES5/EMA2009 style: var only, no modern TS/JS syntax]
  Style --> Existing{Does a wrapper already exist?}
  Existing -->|Bench/power/IGN| Bench[Use Bench_Normal_Condition, Bench_Back_to_DV, cycle_IGN, powerSupplyControl]
  Existing -->|UDS/DTC/security| Diag[Use enterExtSession, Internal_Security_Access, Read_DTC, clearDTC, routineControl, DataIdentifier_Read_Write]
  Existing -->|CAN signal/frame| Can[Use changeCAN_SignalValue, generateSignal, generateMessage, setAllRxMessages, Verify_Periodicity_2C0/2C01]
  Existing -->|EDR| Edr[Use read_EDR*, decodeParameterValues, printParameterValues, Default_Read_EDR]
  Existing -->|Crash/fault| Fault[Use TriggerCrash, front_crash*, DisableFrameByName, EnableFrameByName, Message_Content_Failure, SetGpoFaultCondition]
  Existing -->|Result parsing| Result[Use ExtractTestStatus, extractCompareResponseData, EvalManStepEqual]
  Existing -->|No wrapper| Direct[Use direct ARIA API only after checking PDF/API hints and existing call patterns]
  Direct --> Validate[Keep wrapper-like argument checks and RESULT interpretation]
```

## Preferred Wrapper Entry Points
| Need | Use | Rule |
| --- | --- | --- |
| Bench setup | `Bench_Normal_Condition()`, `Bench_Back_to_DV()`, `cycle_IGN()`, `cycleIgnitionViaCAN()` | Use at test start/end and before DTC-sensitive validation. |
| Power | `powerSupplyControl(Voltage, Control, tDelay)`, `powersetVoltage(voltage)`, `powerReset(TDelay)` | Prefer wrappers; they encode bench-specific behavior. |
| Diagnostics / DTC | `enterExtSession()`, `Internal_Security_Access(...)`, `Read_DTC(...)`, `clearDTC()`, `clearDTC_Response(response)` | Use existing UDS constants and compare through `RESULT`. |
| Routine / DID | `routineControl(...)`, `DataIdentifier_Read_Write(...)`, `write_VIN_number()`, `NVM_Clear()` | Avoid raw diag bytes unless no wrapper exists. |
| CAN signal/frame | `changeCAN_SignalValue(...)`, `generateSignal(...)`, `generateMessage(...)`, `setAllRxMessages(...)` | Use raw `CAN.*` only when wrapper lacks the exact operation. |
| CAN timing/logging | `startCANLogging(...)`, `Verify_Periodicity_2C0(...)`, `Verify_Periodicity_2C01(...)`, `Verify_MsgDLC_2C0(...)` | For log-based checks, preserve path and message-id conventions. |
| EDR | `Default_Read_EDR()`, `readEDR*`, `read_EDR*`, `decodeParameterValues(...)`, `printParameterValues(...)` | Use existing decode helpers for parameter-specific byte interpretation. |
| Crash/deployment | `TriggerCrash()`, `front_crash*`, `left_side_crash*`, `right_side_crash*`, `rear_crash*`, `understage*`, `near_crash*` | Use named crash wrappers so sensor/files/channel setup stays consistent. |
| Fault simulation | `DisableFrameByName(...)`, `EnableFrameByName(...)`, `Message_Content_Failure(...)`, `SetGpoFaultCondition(...)`, `RSU_Faulty(...)` | For pre/post crash faults, make the fault-active value and cleared value explicit. |
| Result extraction | `ExtractTestStatus(pathName)`, `extractCompareResponseData(...)`, `EvalManStepEqual(...)` | Use for post-processing and manual step assertions. |

## Wrapper Catalog By Domain

### Bench / Power / Ignition
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function powerSupplyControl(Voltage, Control, tDelay: int) | libCommon.ts | 260 | CAN.InsertLogMessage, PS.PowerOff, PS.PowerOn, PS.SetVoltage, PowerOff, PowerOn | sleep |
| function checkCAN_SignalValue(Text, Msg_Name, Signal_Name, ExpectedValue) | libCommon.ts | 435 | CAN.GetSignalFromFrame, RESULT.InterpretEqualResult |  |
| function PowerOFF(typeOf: String) | libCommon.ts | 1621 | CAN.InsertLogMessage, MessageBox.Show, PS.ClearModulePower, PS.ClearVBAT, PS.PowerOff, PowerOff |  |
| function PowerON(typeOf: String) | libCommon.ts | 1677 | CAN.InsertLogMessage, MessageBox.Show, PS.PowerOn, PS.SetModulePower, PS.SetVBAT, PowerOn |  |
| function powersetVoltage(voltage) | libCommon.ts | 1732 | CAN.InsertLogMessage, MessageBox.Show, PS.SetCurrentLimit, PS.SetVoltage, PowerSetVoltage, RESULT.InsertComment |  |
| function cycle_IGN() | libCommon.ts | 1765 | CAN.InsertLogMessage, Thread.Sleep | PowerOFF, PowerON |
| function changeCAN_SignalValue(Msg_Name, Signal_Name, Signal_Value) | libCommon.ts | 1805 | CAN.PeriodicChangeSignal, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function cycleIgnitionViaCAN() | libMahindra.ts | 54 | CAN.PeriodicDisableFrame, CAN.PeriodicEnableFrame, Thread.Sleep |  |
| function Bench_Normal_Condition() | libMahindra.ts | 63 | CAN.SendDiagByValues, CAN.SetDiagnosticAdressingMode, RESULT.InsertComment, RESULT.InterpretEqualResult | Read_Software_Version, cycle_IGN, getDateTime, sleep |
| function powerReset(TDelay: int) | libMahindra.ts | 375 |  | powerSupplyControl, sleep |
| function CAN_Signal_Info_during_crash() | libMahindra.ts | 1452 | CAN.GetSignalFromFrame, CAN.SendDiagByValues, PS.GetVoltageBattery, RESULT.InterpretEqualResult, RESULT.LogCustomAction | val2key |
| function CAN_Signal_Info_during_crash_PADL() | libMahindra.ts | 1513 | CAN.GetSignalFromFrame, CAN.SendDiagByValues, RESULT.InterpretEqualResult, RESULT.LogCustomAction | val2key |
| function DCS_CAN_Signal_Info_during_crash() | libMahindra.ts | 1574 | CAN.GetSignalFromFrame, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function EDR_SRS_Mal_Lamp_IGN_Counter() | libMahindra.ts | 2238 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, decodeParameterValues, enterExtSession, printParameterValues |
| function EDR_IGNCycleCrash() | libMahindra.ts | 2278 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, decodeParameterValues, enterExtSession, printParameterValues |
| function readEDR_battery_voltage() | libMahindra.ts | 3637 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, enterExtSession |
| function SetGpoFaultCondition(LAMP_Name, flt_type) | libMahindra.ts | 4564 | LAMPS.ConfigureLamp, PS.ClearLeakageGNDBusHigh, PS.ClearLeakageVBATBusHigh, PS.SetLeakageGNDBusHigh, PS.SetLeakageVBATBusHigh, RESULT.InterpretEqualResult | sleep |
| function Bench_Back_to_DV() | libMahindra.ts | 4780 | CAN.SendDiagByValues, RESULT.InsertComment, RESULT.InterpretEqualResult | Clear_L61, enterExtSession, getDateTime |

### CAN / Message / Signal / Logging
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function startCANLogging(channel_no : int, TestCase_ID) | libCommon.ts | 477 | CAN.StartLoggingToFile | getFormattedDate |
| function checkPeriodRangeOfMessage(pathName : String, MsgId, Expected_Range) | libCommon.ts | 1013 |  | getDifferenceFromElements, getNoOfElementsOutOfRange, getRangeOfElements, getSamplesFromLogFile |
| function getSamplesFromLogFile(pathName : String, MsgId) | libCommon.ts | 1030 | ActiveXObject | decimalToHex |
| function readMsgTimeFromLogLine(Line : String) | libCommon.ts | 1160 |  |  |
| function readTimeStampFromLogLine(Line : String) | libCommon.ts | 1170 |  |  |
| function triggerCANDisturbance(Application_Handle) | libCommon.ts | 1408 |  |  |
| function stopCANDisturbance(Application_Handle) | libCommon.ts | 1416 |  |  |
| function newLogFilter(file_path: String, filterIDs: Array) | libCommon.ts | 1550 | ActiveXObject, RESULT.InsertComment |  |
| function FaultMaturationDematurationLogic(sActionName: String, ObtainedValue: float, fLowLimit: float, fHighLimit: float) | libMahindra.ts | 1410 | RESULT.ExpectTestResult, RESULT.LogCustomAction |  |
| function Message_Content_Failure(paramName) | libMahindra.ts | 3852 | CAN.SetPeriodicFrame, RESULT.InsertComment, Thread.Sleep |  |
| function DisableFrame(paramName) | libMahindra.ts | 3885 | CAN.PeriodicDisableFrame, RESULT.InsertComment, Thread.Sleep |  |
| function EnableFrame(paramName) | libMahindra.ts | 3918 | CAN.PeriodicEnableFrame, RESULT.InsertComment, Thread.Sleep |  |
| function reload_frames() | libMahindra.ts | 4529 | CAN.ReloadDefaultPeriodicFrame |  |
| function Verify_Periodicity_2C01(TestCase_Description,Message_ID:String, ExpectedPeriodicity:uint,Logpath:String) | libMahindra.ts | 4600 | LOG.LoadCanLog, RESULT.InsertComment, RESULT.InterpretEqualResult, RESULT.LogAction |  |
| function Verify_Periodicity_2C0(TestCase_Description,Message_ID:String, ExpectedPeriodicity:uint,Logpath:String) | libMahindra.ts | 4629 | LOG.LoadCanLog, RESULT.InsertComment, RESULT.InterpretEqualResult, RESULT.LogAction |  |
| function Verify_MsgDLC_2C0(TestCase_Description,Message_ID:String, ExpectedDLC:uint,Logpath:String) | libMahindra.ts | 4669 | LOG.LoadCanLog, RESULT.InsertComment, RESULT.InterpretEqualResult, RESULT.LogAction |  |
| function findResponseTimestamp(requestID, requestData, responseID, responsePrefix, Logpath:String) | libMahindra.ts | 4694 | LOG.LoadCanLog | isExactMatch, startsWith |
| function isMessageActiveAfter(TestCase_Description, Message_ID, startTime,windowSize, Logpath:String) | libMahindra.ts | 4730 | LOG.LoadCanLog, RESULT.LogAction |  |
| function setAllRxMessages(action, ch) | libMahindra.ts | 4864 | CAN.PeriodicDisableFrame, CAN.PeriodicEnableFrame, RESULT.LogAction |  |

### Crash / Deployment / RSU / Squib
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function squibFault(FaultType, SquibName, Squib, Fault) | libCommon.ts | 190 | ARIA.AFT_iLoadBoxWrapper, RESULT.InterpretEqualResult, SQUIB.SendRequest |  |
| function DCS_CC_Fault(Action, DCS_Name1, DCS1, DCS_Name2, DCS2,Fault) | libCommon.ts | 447 | RESULT.InterpretEqualResult, SLS.SendRequest |  |
| function squib_CC_Fault(FaultType, SquibName, Squib, Fault) | libCommon.ts | 457 | RESULT.InterpretEqualResult, SQUIB.SendRequest |  |
| function osciloscope_screenshot(filename) | libCommon.ts | 929 | ActiveXObject |  |
| function ScopeMeasurements(CrashOutput, PWidth_crash_QualRange, NWidth_crash_QualRange) | libCommon.ts | 946 | RESULT.InterpretEqualResultRange |  |
| function TriggerCrash() | libCommon.ts | 1794 | ARIA.AFT_iTriggerWrapper, RESULT.ExpectTestResult |  |
| function RSU_setAcceleration(RSUName, SaturationData) | libCommon.ts | 1822 | CAN.SendFrame, RESULT.InsertComment, RESULT.InterpretEqualResult | decimalToHex |
| function DCS_Condition(DCS, Condition) | libCommon.ts | 1845 | RESULT.InterpretEqualResult, RESULT.LogCustomAction, SLS.SendRequest |  |
| function PADS_Condition(PADS, Condition) | libCommon.ts | 1862 | RESULT.InterpretEqualResult, RESULT.LogCustomAction, SLS.SendRequest |  |
| function Lamps_Condition(ENS, Condition) | libCommon.ts | 1879 | LAMPS.ConfigureLamp, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function PADI_Condition(PADI, Condition) | libCommon.ts | 1896 | LAMPS.ConfigureLamp, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function ENS_Condition(ENS, Condition) | libCommon.ts | 1912 | LAMPS.ConfigureLamp, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function PAB_ON_LAMP_Condition(PAB_ON_LAMP, Condition) | libCommon.ts | 1955 | RESULT.InterpretEqualResult, RESULT.LogCustomAction, SLS.SendRequest |  |
| function Lamps_Condition_PAB_ON(PAB_ON_LAMP, Condition) | libCommon.ts | 1972 | LAMPS.ConfigureLamp, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function Lamps_Condition_PAB_OFF(PAB_OFF_LAMP, Condition) | libCommon.ts | 1988 | LAMPS.ConfigureLamp, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function Lamps_Condition_ENS(ENS, Condition) | libCommon.ts | 2004 | LAMPS.ConfigureLamp, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function RSU_Faulty(Fault : String, RSUName : String) | libCommon.ts | 2021 | RESULT.InterpretEqualResult, RSU.ClearFault, RSU.ResetRSU, RSU.SetFaultMancester, RSU.SetFaultNoData, RSU.SetFaultOpen |  |
| function padStart(binaryString, targetLength, padChar) | libMahindra.ts | 151 |  |  |
| function loadCrashFiles(sensorType, CrashType) | libMahindra.ts | 509 |  |  |
| function loadRSUfiles(ID, filename: String, RSUNo: int) | libMahindra.ts | 515 |  |  |
| function check_deploymentTime() | libMahindra.ts | 1105 | ARIA.AFT_GetTTFAndFDResults, RESULT.InterpretEqualResult |  |
| function Sensor_Convert(data) | libMahindra.ts | 1185 |  |  |
| function FRSU_Sensor_Convert(data) | libMahindra.ts | 1198 |  |  |
| function SRSU_Sensor_Convert(data) | libMahindra.ts | 1211 |  |  |
| function front_crash() | libMahindra.ts | 3950 | PS.PowerOff, PS.PowerOn, PS.TriggerMain, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep | CAN_Signal_Info_during_crash |
| function front_crash_loadcurves() | libMahindra.ts | 4016 | PS.PowerOff, PS.PowerOn, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep |  |
| function left_side_crash() | libMahindra.ts | 4043 | PS.PowerOff, PS.PowerOn, PS.TriggerMain, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep | CAN_Signal_Info_during_crash |
| function left_side_crash_loadcurves() | libMahindra.ts | 4064 | PS.PowerOff, PS.PowerOn, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep |  |
| function right_side_crash() | libMahindra.ts | 4080 | PS.PowerOff, PS.PowerOn, PS.TriggerMain, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep | CAN_Signal_Info_during_crash |
| function right_side_crash_loadcurves() | libMahindra.ts | 4100 | PS.PowerOff, PS.PowerOn, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep |  |
| function rear_crash() | libMahindra.ts | 4114 | PS.PowerOff, PS.PowerOn, PS.TriggerMain, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep | CAN_Signal_Info_during_crash |
| function rear_crash_loadcurves() | libMahindra.ts | 4136 | PS.PowerOff, PS.PowerOn, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep |  |
| function understrike_crash() | libMahindra.ts | 4153 | PS.PowerOff, PS.PowerOn, PS.TriggerMain, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep | CAN_Signal_Info_during_crash |
| function understrike_crash_loadcurves() | libMahindra.ts | 4175 | PS.PowerOff, PS.PowerOn, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep |  |
| function near_crash() | libMahindra.ts | 4192 | PS.PowerOff, PS.PowerOn, PS.TriggerMain, RSU.SendAcceleration, SPI.SendCrashData, Thread.Sleep | CAN_Signal_Info_during_crash |
| function near_crash_load_curves() | libMahindra.ts | 4213 | PS.PowerOff, PS.PowerOn, SPI.SendCrashData, Thread.Sleep |  |

### Diagnostics / UDS / DTC
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function DataIdentifierCheck(DataIdentifier,DIDArray,checkDID) | libCommon.ts | 354 |  |  |
| function CheckNoDTC() | libCommon.ts | 423 |  | Read_DTC |
| function routineControl(SF, DID, routineControlOptionRecord, routineStatusRecord) | libCommon.ts | 495 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function DataIdentifier_Read_Write(SID, DID, DataRecord) | libCommon.ts | 523 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function Scrap_SeedRequest() | libCommon.ts | 719 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function Scrap_SecurityAccess(valid) | libCommon.ts | 734 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | Scrap_SeedRequest, sleep |
| function Scrap_SafetySession() | libCommon.ts | 772 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function Scrap_RoutineControl_ExecuteSPL() | libCommon.ts | 789 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function scrapAcuReset(Response) | libCommon.ts | 805 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function DeploymentLoopStatus(DeployedID, Status) | libCommon.ts | 823 | CAN.SendDiagByValues, CAN.SetDiagnosticAdressingMode, RESULT.InterpretEqualResult |  |
| function NRC13_DIDCheck(SID, DID, DATARecord) | libCommon.ts | 1485 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function val2key(val, array) | libCommon.ts | 1532 |  |  |
| function reset_rsu() | libCommon.ts | 2075 | PS.PowerOff, PS.PowerOn, RSU.ResetRSU, Thread.Sleep |  |
| function enterExtSession() | libMahindra.ts | 93 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function enterDefSession() | libMahindra.ts | 121 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function enterProgrammingSession() | libMahindra.ts | 159 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function dtcSplit(DTC) | libMahindra.ts | 177 |  |  |
| function Qualification_DeQualification(Max_Time, Start_time, DTC, DTCStatus) | libMahindra.ts | 196 | CAN.SendDiagByValues, Date | dtcSplit, serviceIDCheck, sleep |
| function Read_DTC(FaultName, FaultDTC, ReadDTC_Code) | libMahindra.ts | 293 | CAN.SendDiagByValues, RESULT.InterpretEqualResult, RESULT.LogCustomAction, Thread.Sleep | dtcSplit |
| function softReset() | libMahindra.ts | 349 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function hardReset() | libMahindra.ts | 362 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function clearDTC() | libMahindra.ts | 389 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function readDTC() | libMahindra.ts | 400 | CAN.SendDiagByValues, RESULT.InterpretEqualResult, RESULT.LogCustomAction |  |
| function checkdtc(array, DTC) | libMahindra.ts | 450 |  |  |
| function Internal_Security_Access(parameterValue) | libMahindra.ts | 467 | CAN.SecurityAccess, RESULT.InsertComment, RESULT.InterpretEqualResult | zeroPadding |
| function securityAccessForWDBI() | libMahindra.ts | 501 |  | Internal_Security_Access |
| function testerPresent(periodicity, state: String) | libMahindra.ts | 530 | CAN.ChangePeriodicity, CAN.PeriodicDisableFrame, CAN.PeriodicEnableFrame, RESULT.InterpretEqualResult, Thread.Sleep |  |
| function SA_seedRequest(level: String) | libMahindra.ts | 545 | CAN.SendDiagByValues, RESULT.InsertComment, RESULT.InterpretEqualResult |  |
| function Security_SeedRequest(SecurityLevel) | libMahindra.ts | 572 | CAN.SendDiagByValues, RESULT.InterpretEqualResult |  |
| function Security_KeyUnlock(SecurityLevel) | libMahindra.ts | 589 | CAN.SendDiagByValues, RESULT.InsertComment, RESULT.InterpretEqualResult | Security_SeedRequest, calculateKey, convertToByteStream, decimalToHex |
| function calculateKey(Security_UnlockInitiation) | libMahindra.ts | 625 | RESULT.InsertComment | Xr_Highbyte, decimalToHex |
| function Internal_Security_Access_1() | libMahindra.ts | 971 | CAN.SendDiagByValues, CAN.SetDiagnosticAdressingMode, RESULT.InsertComment, RESULT.InterpretEqualResult, Thread.Sleep | CalculateKey_1, enterExtSession |
| function CalculateKey_1(value) | libMahindra.ts | 996 |  | arrayRotate1, bin2hex, convertToByteStream, hex2Bin, zeroPadding |
| function faultTimeMeasurement(expected_DTCNumber) | libMahindra.ts | 1325 | CAN.SendDiagByValues, Date, RESULT.LogAction, Thread.Sleep |  |
| function write_VIN_number() | libMahindra.ts | 3629 | Thread.Sleep | DataIdentifier_Read_Write, Internal_Security_Access, cycle_IGN, enterExtSession |
| function clearDTC_Response(response) | libMahindra.ts | 4821 | CAN.SendDiagByValues, RESULT.InsertComment, RESULT.InterpretEqualResult | enterExtSession, sleep |

### EDR Read / Decode
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function EvalManStepEqual(sActionName: String, sReceivedResult: String, sExpectedResult: String) | libCommon.ts | 161 | RESULT.ExpectTestResult, RESULT.LogCustomAction |  |
| function Erase_Area(parameter) | libMahindra.ts | 917 | CAN.SendDiagByValues, RESULT.InterpretEqualResult, Thread.Sleep |  |
| function readEDRBeforeCrash() | libMahindra.ts | 1606 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, enterExtSession, printParameterValues |
| function printParameterValues(paramName, paramValues) | libMahindra.ts | 1613 | RESULT.LogCustomAction |  |
| function readEDR2() | libMahindra.ts | 1634 |  | DataIdentifier_Read_Write, Internal_Security_Access, enterExtSession |
| function readEDRparameters1() | libMahindra.ts | 1640 | Crash, RESULT.InsertComment, RESULT.LogCustomAction, Thread.Sleep | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 1648 | RESULT.InsertComment, RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 1743 | Crash | binary_conversion |
| function readEDRparameters2() | libMahindra.ts | 1934 | RESULT.InsertComment, RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 1941 | RESULT.InsertComment, RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2020 |  | binary_conversion |
| function EDR_SRS_Mal_Lamp() | libMahindra.ts | 2175 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 2182 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2206 |  | binary_conversion |
| function printParameterValues(paramName, values) | libMahindra.ts | 2245 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2257 |  |  |
| function printParameterValues(paramName, values) | libMahindra.ts | 2285 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2297 |  |  |
| function readEDRParameters_DCS() | libMahindra.ts | 2317 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 2324 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2331 |  | binary_conversion |
| function readEDR_PADI_lamp_after_crash() | libMahindra.ts | 2407 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 2415 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2426 |  | binary_conversion |
| function readEDR_Change_Velocity() | libMahindra.ts | 2485 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 2493 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2520 |  | binary_conversion |
| function readEDRparameters_EPS_Node() | libMahindra.ts | 2551 | RESULT.InsertComment, RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, cycle_IGN, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 2559 | RESULT.InsertComment, RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2588 |  |  |
| function readEDRparameters_FR_Zone_Node() | libMahindra.ts | 2613 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 2625 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2671 |  | binary_conversion |
| function readEDRparameters_HPCC_Node() | libMahindra.ts | 2745 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, cycle_IGN, decodeParameterValues, enterExtSession, printParameterValues |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2753 |  |  |
| function printParameterValues(paramName, values) | libMahindra.ts | 2757 | RESULT.LogCustomAction |  |
| function readEDRparameters_IEB_Node() | libMahindra.ts | 2785 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 2794 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2850 |  | binary_conversion |
| function readEDRparameters_VCU11_FD_10() | libMahindra.ts | 2898 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 2906 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 2970 |  | binary_conversion |
| function readEDRparameters_VCU2_FD_100() | libMahindra.ts | 3033 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 3041 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3056 |  | binary_conversion |
| function readEDRparameters_HPCAd_1_10() | libMahindra.ts | 3107 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 3115 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3152 |  | binary_conversion |
| function readEDRparameters_HPCAd_3_50_Node() | libMahindra.ts | 3189 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 3201 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3217 |  | binary_conversion |
| function readEDRparameters_HPCAd_2_50_Node() | libMahindra.ts | 3408 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 3416 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3432 |  | binary_conversion |
| function readEDRparameters_HPCAd_4_10_Node() | libMahindra.ts | 3465 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 3473 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3489 |  | binary_conversion |
| function readEDRparameters_VCU1_FD_20_Node() | libMahindra.ts | 3535 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, cycle_IGN, decodeParameterValues, enterExtSession |
| function printParameterValues(paramName, values) | libMahindra.ts | 3544 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3572 |  | binary_conversion |
| function readEDR_date_time() | libMahindra.ts | 3661 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 3669 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 3689 |  | binary_conversion |
| function read_EDR_invalid_values() | libMahindra.ts | 4226 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 4237 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 4359 |  | binary_conversion |
| function read_EDR_Reserved_values() | libMahindra.ts | 4426 | RESULT.LogCustomAction | DataIdentifier_Read_Write, Internal_Security_Access, binary_conversion, decodeParameterValues, enterExtSession, printParameterValues |
| function printParameterValues(paramName, values) | libMahindra.ts | 4440 | RESULT.LogCustomAction |  |
| function decodeParameterValues(paramName, values) | libMahindra.ts | 4464 |  | binary_conversion |

### Other / Project Specific
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function TestCount() | libCommon.ts | 84 | RESULT.InsertComment |  |
| function subFunctionCheck(subfunctionlist, subfunction) | libCommon.ts | 339 |  |  |
| function serviceIDCheck(serviceIDlist, serviceID) | libCommon.ts | 373 |  |  |
| function getFormattedDate() | libCommon.ts | 405 | Date |  |
| function scrapProcess(LoopID, LoopStatus) | libCommon.ts | 842 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | sleep |
| function IMLOIF_Check(SID, Valid_Rq_Data , Valid_Rq_Length) | libCommon.ts | 1463 | CAN.SendDiagByValues, RESULT.InterpretEqualResult | Random_HexNU |
| function triggerMain() | libCommon.ts | 1780 | CAN.InsertLogMessage, PS.TriggerMain, RESULT.InsertComment, RESULT.InterpretEqualResult, RESULT.LogCustomAction | getDateTime |
| function checkWLof2C0(Status:String) | libCommon.ts | 2086 | CAN.GetSignalFromFrame, RESULT.InterpretEqualResult |  |
| function NVM_Clear_L61() | libMahindra.ts | 139 | CAN.SecurityAccess, CAN.SendDiagByValues, RESULT.InterpretEqualResult, Thread.Sleep | enterExtSession |
| function NVM_Clear() | libMahindra.ts | 929 | ARIA.ClearAllDeployTime, CAN.SendDiagByValues, RESULT.InterpretEqualResult, Thread.Sleep | cycle_IGN, sleep |
| function binary_conversion(values) | libMahindra.ts | 1085 |  |  |
| function Read_Software_Version() | libMahindra.ts | 1291 | CAN.SendDiagByValues, CAN.SetDiagnosticAdressingMode, RESULT.InsertComment, RESULT.InterpretEqualResult | enterDefSession, hex2ascii |
| function Default_Variant_Code() | libMahindra.ts | 3744 | CAN.SendFrameFD, PS.PowerOff, PS.PowerOn, RESULT.LogAction, Thread.Sleep | Internal_Security_Access, enterExtSession |
| function Disable_Variant_Code(paramName) | libMahindra.ts | 3758 | CAN.SendFrameFD, PS.PowerOff, PS.PowerOn, RESULT.LogAction, Thread.Sleep | Internal_Security_Access, enterExtSession |
| function isExactMatch(payload, b0, b1, b2) | libMahindra.ts | 4719 |  |  |
| function startsWith(payload, b0, b1) | libMahindra.ts | 4725 |  |  |
| function Clear_L61() | libMahindra.ts | 4762 | CAN.SecurityAccess, Thread.Sleep | enterExtSession |
| function checkWLof13C(Status:String) | libMahindra.ts | 4811 |  |  |

### Result / Reporting / Extraction
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function createNewResultFile(File_name : String) | libCommon.ts | 73 |  |  |
| function read_ByteValue_BitValue(DataAlone, BytePosition, bitPosition, bitWidth) | libCommon.ts | 576 | RESULT.InterpretEqualResult | hex2Bin |
| function extractCompareResponseData(Complete_Data, Data_Name, Operation_Expected_Data) | libCommon.ts | 1187 | RESULT.InterpretEqualResult | decimalToHex |
| function ExtractTestStatus(pathName : String) | libExtractResultTest.ts | 23 | RESULT.InsertComment |  |
| function Result_CompareStrings(str1, str2) | libMahindra.ts | 109 | RESULT.LogAction |  |
| function RunSaleaeCapture(filepath, filename, ch0, ch1, ch2, ch3, duration) | libMahindra.ts | 4844 | ActiveXObject |  |

### Utilities / Conversion / File Parsing
| Signature | File | Line | Direct ARIA/API calls | Wrapper calls |
| --- | --- | --- | --- | --- |
| function ConvertByteStringToASCII(Data: String, ... ExtraParams: Object[]) | libCommon.ts | 115 | RESULT.ExpectTestResult |  |
| function sortNumber(a, b) | libCommon.ts | 211 |  |  |
| function range(value, tolerance) | libCommon.ts | 223 |  |  |
| function configurePS(filename : String) | libCommon.ts | 238 | ActiveXObject, Date | sleep |
| function sleep(time : int) | libCommon.ts | 330 | RESULT.LogCustomAction, Thread.Sleep |  |
| function decimalToHex(Decimal, Padding) | libCommon.ts | 388 |  |  |
| function XOR32Bit(num1 : uint, num2 : uint) | libCommon.ts | 415 |  |  |
| function bin2hex(binValue, Padding) | libCommon.ts | 617 |  |  |
| function hex2Bin(hexValue, Padding) | libCommon.ts | 635 |  | zeroPadding |
| function zeroPadding(number, length) | libCommon.ts | 664 |  |  |
| function objectToArray(objectName) | libCommon.ts | 677 |  |  |
| function configureCRO(filename : String) | libCommon.ts | 896 | ActiveXObject |  |
| function readCROmeasurements(filename : String) | libCommon.ts | 911 | ActiveXObject |  |
| function getDifferenceFromElements(Element_Array) | libCommon.ts | 1057 |  |  |
| function getNoOfElementsOutOfRange(Element_Array, Range_Min, Range_Max) | libCommon.ts | 1070 |  |  |
| function getRangeOfElements(Element_Array) | libCommon.ts | 1095 |  |  |
| function findFirstMatchFromFileWithinLineRange(pathName : String, Data : String, Line_min, Line_max) | libCommon.ts | 1110 | ActiveXObject |  |
| function readNthLineFromFile(pathName : String, Line_no : uint) | libCommon.ts | 1135 | ActiveXObject |  |
| function TwosComplement(Neg_Number, Bit_Length_Required) | libCommon.ts | 1267 |  |  |
| function convertToByteStream(Data : String) | libCommon.ts | 1279 |  |  |
| function Random_HexNU(len: int) | libCommon.ts | 1518 |  | decimalToHex |
| function hex2ascii1(hexValue) | libCommon.ts | 1927 |  |  |
| function hex2ascii(hexValue) | libCommon.ts | 1938 |  |  |
| function QualMulti(start_time, MaxTime, Error1) | libMahindra.ts | 411 | CAN.ReadAllDTCCodes, CAN.SendDiagByValues, Date | dtcSplit, sleep |
| function arrayRotate(arr, direction) | libMahindra.ts | 487 |  |  |
| function Xr_Highbyte(Xl, S) | libMahindra.ts | 882 |  |  |
| function arrayRotate1(arr, direction) | libMahindra.ts | 1070 |  |  |
| function faultTimeCheck(Faulttime_Measured, Faulttime_Expected, tolerance) | libMahindra.ts | 1168 | RESULT.InsertComment, RESULT.InterpretEqualResultRange | range |
| function getDateTime() | libMahindra.ts | 1225 | Date |  |
| function Sleep_Random_Number() | libMahindra.ts | 1274 | RESULT.LogCustomAction, Thread.Sleep |  |
| function formatHex(decimalValue) | libMahindra.ts | 1595 |  |  |

## Direct ARIA API Namespaces Observed In Wrappers
- `ARIA`: `ARIA.AFT_iLoadBoxWrapper` (1), `ARIA.AFT_iTriggerWrapper` (1), `ARIA.ClearAllDeployTime` (1), `ARIA.AFT_GetTTFAndFDResults` (1)
- `CAN`: `CAN.SendDiagByValues` (59), `CAN.ReloadDefaultPeriodicFrame` (12), `CAN.GetSignalFromFrame` (10), `CAN.PeriodicDisableFrame` (9), `CAN.PeriodicEnableFrame` (9), `CAN.SendFrameFD` (8), `CAN.InsertLogMessage` (7), `CAN.SetPeriodicFrame` (5), `CAN.SetDiagnosticAdressingMode` (4), `CAN.SecurityAccess` (4), `CAN.StartLoggingToFile` (1), `CAN.PeriodicChangeSignal` (1), `CAN.SendFrame` (1), `CAN.ReadAllDTCCodes` (1), `CAN.ChangePeriodicity` (1)
- `LAMPS`: `LAMPS.ConfigureLamp` (11)
- `LOG`: `LOG.LoadCanLog` (5)
- `MessageBox`: `MessageBox.Show` (3)
- `PS`: `PS.PowerOn` (24), `PS.PowerOff` (24), `PS.TriggerMain` (7), `PS.SetVoltage` (3), `PS.ClearVBAT` (1), `PS.ClearModulePower` (1), `PS.SetVBAT` (1), `PS.SetModulePower` (1), `PS.SetCurrentLimit` (1), `PS.GetVoltageBattery` (1), `PS.SetLeakageGNDBusHigh` (1), `PS.SetLeakageVBATBusHigh` (1), `PS.ClearLeakageGNDBusHigh` (1), `PS.ClearLeakageVBATBusHigh` (1)
- `RESULT`: `RESULT.LogCustomAction` (170), `RESULT.InterpretEqualResult` (140), `RESULT.InsertComment` (65), `RESULT.LogAction` (23), `RESULT.InterpretEqualResultRange` (7), `RESULT.ExpectTestResult` (4)
- `RSU`: `RSU.SendAcceleration` (28), `RSU.SetFaultParity` (2), `RSU.ResetRSU` (2), `RSU.SetFaultMancester` (1), `RSU.SetFaultNoData` (1), `RSU.SetFaultOpen` (1), `RSU.SetFaultShortGround` (1), `RSU.SetFaultShortBattery` (1), `RSU.ClearFault` (1)
- `SLS`: `SLS.SendRequest` (5)
- `SPI`: `SPI.SendCrashData` (12)
- `SQUIB`: `SQUIB.SendRequest` (2)
- `Thread`: `Thread.Sleep` (96)
- `global`: `Crash` (14), `Date` (10), `ActiveXObject` (9), `PowerOn` (3), `PowerOff` (3), `PowerSetVoltage` (2)

## PDF API Hints
These names were extracted from `ARIA User Functions.pdf`. The PDF uses embedded font maps, so a small amount of glyph normalization was applied. Prefer exact wrapper names above when available.

### ARIA
- `ARIA.AET`, `ARIA.CheckTImeAfterCanCardGetsReadyToLIsten`, `ARIA.GetConfIgDIr`, `ARIA.GetLampDImmIngFrequency`, `ARIA.GetLampE.SDutyCycle`, `ARIA.GetLampE.SFrequency`, `ARIA.GetLampEDStatus`, `ARIA.GetLampEIlteredStatus`
- `ARIA.GetLampInstantStatus`, `ARIA.GetTTEAndEDResults`, `ARIA.GetTTEResults`, `ARIA.GetTestEnvIronment`, `ARIA.IUpdate`, `ARIA.IUpdateDrIveDataWrapper`, `ARIA.LoadProfIle`, `ARIA.LoadProfIles`
- `ARIA.LoadProfIlesCustom`, `ARIA.ODS`, `ARIA.ReloadPerIodIcs`, `ARIA.RemovePerIodIcFrames`, `ARIA.SaveProfIle`, `ARIA.SetDynamIcLIbraryProperty`, `ARIA.StartCombInedLoggIng`, `ARIA.StartDIagLoggIng`
- `ARIA.StartLoggIng`, `ARIA.StopCombInedLoggIng`, `ARIA.StopDIagLoggIng`, `ARIA.StopLoggIng`

### LAMPS
- `LAMPS.ConfigureLamp`, `LAMPS.GetEIlteredStatus`, `LAMPS.GetLampDImmIngFrequency`, `LAMPS.GetLampE.SFrequency`, `LAMPS.GetLampEDStatus`, `LAMPS.GetLampEIlteredStatus`, `LAMPS.GetLampElashIngOffTIme`, `LAMPS.GetLampInstantStatus`
- `LAMPS.GetLampLsHs`, `LAMPS.GetLampPulseParameters`, `LAMPS.GetLampRecordedSamples`, `LAMPS.SetLampDImmIngFrequency`, `LAMPS.SetLampElashIngOffTIme`, `LAMPS.SetLampLsHs`, `LAMPS.StartLampMonitoring`, `LAMPS.StopLampMonItorIng`

### PS
- `PS.ClearCurrent`, `PS.ClearExternalIG.`, `PS.ClearExternalVDAT`, `PS.ClearIG.`, `PS.ClearLeakageG.DDusHIgh`, `PS.ClearLeakageG.DDusLow`, `PS.ClearLeakageVDATDusHIgh`, `PS.ClearLeakageVDATDusLow`
- `PS.ClearModulePower`, `PS.ClearPPIG.`, `PS.ClearPPVDAT`, `PS.ClearPushPull`, `PS.ClearTQ`, `PS.ClearVDAT`, `PS.ClearVDATIG.`, `PS.ClearVoltage`
- `PS.GetCurrentIG.`, `PS.GetCurrentVDAT`, `PS.GetVoltageDattery`, `PS.GetVoltageIG.`, `PS.LoadCurve`, `PS.PowerOff`, `PS.PowerOn`, `PS.Read`
- `PS.ReadCurrent`, `PS.ReadStatus`, `PS.ReadVoltage`, `PS.RemotePowerDown`, `PS.RemotePowerUp`, `PS.ResetCard`, `PS.SetCurrent`, `PS.SetCurrentLImIt`
- `PS.SetExternalIG.`, `PS.SetExternalVDAT`, `PS.SetIG.`, `PS.SetLeakageG.DDusHIgh`, `PS.SetLeakageG.DDusLow`, `PS.SetLeakageVDATDusHIgh`, `PS.SetLeakageVDATDusLow`, `PS.SetModulePower`
- `PS.SetMultIpleSequence`, `PS.SetPPIG.`, `PS.SetPPVDAT`, `PS.SetPushPull`, `PS.SetTQ`, `PS.SetTQGaInMultI2`, `PS.SetTQGaInMultIT`, `PS.SetVDAT`
- `PS.SetVDATIG.`, `PS.SetVoltage`, `PS.StartCurve`, `PS.StartDIagFrame`, `PS.StartUCut`, `PS.StartWaveEorm`, `PS.Status`, `PS.StatusCurrent`
- `PS.StatusDIagFrame`, `PS.StatusRelay`, `PS.StatusTQ`, `PS.StatusTQGaIn`, `PS.StatusVDATIG.`, `PS.StatusVoltage`, `PS.StopCurve`, `PS.StopDIagFrame`
- `PS.StopUCut`, `PS.StopWaveEorm`, `PS.TrIggerMaIn`, `PS.WrIte`

### RESULT
- `RESULT.InsertComment`, `RESULT.InsertEIle`, `RESULT.InsertPIcture`, `RESULT.InterpretEqualResult`, `RESULT.InterpretEqualResultRange`, `RESULT.InterpretEqualResultWIthoutCheck`, `RESULT.LogActIon`, `RESULT.LogCustomActIon`
- `RESULT.PlotConfIgProp.IsAmper`, `RESULT.PlotConfIgProp.IsSeconds`, `RESULT.PlotConfIgProp.PlotColor`, `RESULT.PlotConfIgProp.XColor`, `RESULT.PlotConfIgProp.YColor`, `RESULT.PlotConfIgProp.YUnIt`

### RSU
- `RSU.ClearFault`, `RSU.ClearSlotFault`, `RSU.GetConfIgInfo`, `RSU.GetEeedVoltage`, `RSU.IUpdateDrIveDataWrapper`, `RSU.LoadCurve`, `RSU.ResetRSU`, `RSU.SelectCrashEIle`
- `RSU.SendAcceleratIon`, `RSU.SendChannelConfIg`, `RSU.SendDlendedSamples`, `RSU.SendPlayback`, `RSU.SetConfIgEIle`, `RSU.SetConfIgEIleTo`, `RSU.SetFault`, `RSU.SetFault.oData`
- `RSU.SetFaultMancester`, `RSU.SetFaultOpen`, `RSU.SetFaultParIty`, `RSU.SetFaultShortDattery`, `RSU.SetFaultShortGround`, `RSU.SetIdFault`, `RSU.SetSensorConfIg`, `RSU.SetSensorStartup`
- `RSU.SetSlotConfIguratIon`, `RSU.SetStartUpEIle`, `RSU.StartCrash`

### SPI
- `SPI.ChangeState`, `SPI.CrashErrorActIon`, `SPI.CrashTrIggerContInuos`, `SPI.CrashTrIggerSIngle`, `SPI.DeflectIonCurves`, `SPI.GetVersIon`, `SPI.ReadCardInfo`, `SPI.ReadCardInfoHost`
- `SPI.ReadIpAddress`, `SPI.RemoveAllCurves`, `SPI.ResetSpICard`, `SPI.SImulateSensor`, `SPI.SendCrashData`, `SPI.SendDeflectIonCurves`, `SPI.SendEvt`, `SPI.TrIggerEvtErrors`
- `SPI.UpdateDrIveAcceleratIonData`, `SPI.UpdateProtocolInfo`

## Generation / Maintenance
- Regenerate this file with `python build_aria_copilot_skill.py` from the workspace directory.
- Review `aria_ts_skill_review.txt` after regeneration; it reports parsed counts and high-frequency direct API calls.
- If Copilot needs this context in a single prompt, attach this Markdown file. Do not rely on VS Code settings sync.
