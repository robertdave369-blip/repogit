"""Operate the local ARIA 5.x tool the way a bench engineer does, from the command line.

    python tools/aria_ctl.py [--aria-dir DIR] <command>
      versions                    every ARIA install, its version, data folder, shipped apym, firewall gaps
      status                      what is running, which project, is the API up
      logs [--all]                distinct messages of the newest ApplicationLog
      ping [--port N]             apym handshake + read-only queries
      use-config FILE             make FILE (AriaMain.json) the active project
      start [--py-host]           launch ARIA (GUI, or headless API host)
      stop [--force]              close ARIA
      clean-stale                 drop ActiveInstances files of dead ARIA processes
      check-inputs [--config F] [--profile F] [--rsu F] [--dbc F ...] [--live]
                                  is ARIA set up with the files the user named (project, loadbox profile,
                                  RSU workbook, DBC content of each simulation; --live asks the running ARIA)
      read-dtc [--project P]      the framework's fault-free check (Read_DTC_Req answered with no DTC)
      compat                      installed apym against the selected ARIA's own local-API handler table
      verify-internals            re-check, in the selected version's binaries, the facts these tools rely on
      api-reference OUT.md        apym call table, marked against the selected ARIA version

The install is --aria-dir, else %ARIA_DIR%, else the newest C:\\ARIA*\\ARIA.exe. Its per-version data
folder is %ProgramData%\\Aria\\<major><minor> (RuntimeProperties: "{0}/Aria/{1}{2}/").
use-config, start, stop, clean-stale and read-dtc only print their plan unless --apply is given.
Starting ARIA with a chassis connected resets the cards and loads the loadbox profile
(SystemReset/LoadProfile in the .accf), so the agent asks the user before --apply.
compat and verify-internals read the ARIA binaries by reflection (tools/aria_il_dump.ps1; no ARIA
code runs) into %LOCALAPPDATA%\\aria_re\\<version>, outside the repo.
"""

from __future__ import annotations

import argparse
import ast
import datetime as dt
import hashlib
import json
import os
import re
import socket
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
DUMPER = REPO_ROOT / "tools" / "aria_il_dump.ps1"
ARIA_DATA = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Aria"
SHARED = ARIA_DATA / "Shared"
ACTIVE_INSTANCES = SHARED / "ActiveInstances"
CACHE = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "aria_re"
INTERNAL_ASSEMBLIES = ("ARIA.exe", "AriaBase.dll", "AriaCore.dll", "LocalApiHost.dll")
# Noise ARIA writes when its telemetry MongoDB host is unreachable (offline / firewalled).
LOG_NOISE = re.compile(r"MongoDB|No such host is known|An exception occurred while opening a connection")
INSTALL: dict = {}  # the selected install, set by main()

# (fact, assembly, exact dump line, agent section that depends on it). Read from ARIA 5.20.0.7.
INTERNAL_FACTS = [
    ("active project = rts ActiveConfigurationPath", "AriaBase.dll", "P System.String ActiveConfigurationPath", "§4.1 §18.1"),
    ("settings file named rts", "AriaBase.dll", "S rts", "§18.1"),
    ("per-version data folder {major}{minor}", "AriaBase.dll", "S {0}/Aria/{1}{2}/", "§18.1"),
    ("ActiveInstances discovery folder", "AriaBase.dll", "S ActiveInstances/", "§18.1 §18.5"),
    ("instance file holds LocalApiHostPort", "AriaBase.dll", "P System.Int32 LocalApiHostPort", "§18.1 §18.5"),
    ("stale instance files cleaned at start", "AriaBase.dll", "M static System.Void ClearInactiveInstancesTrash()", "§18.1"),
    ("modal AriaMain.json dialog when the path is invalid", "AriaBase.dll", "S Select the AriaMain.json configuration file", "§18.1 §21"),
    ("memory-mapped API channel name", "ARIA.exe", "S aria_mmap_host_{0}", "§18.1"),
    ("CLI -config_path", "ARIA.exe", "F System.String CONFIG_PATH = config_path", "§18.3"),
    ("CLI -py_host", "ARIA.exe", "F System.String PYTHON_HOST = py_host", "§18.3"),
    ("CLI -py_host named event", "ARIA.exe", "S Failed to open named event", "§18.3 §21"),
    ("CLI -run / -runlist / -runeventmode", "ARIA.exe", "F System.String RUN_EVENTMODE = runeventmode", "§18.3"),
    ("close confirmation dialog", "ARIA.exe", "S Do you really want to close the program?", "§18.1 §18.4"),
    ("GUI Python runs through the py launcher", "LocalApiHost.dll", "S /C py -V:", "§18.4 F"),
    ("GUI Python scripts must be in ScriptsFolder", "LocalApiHost.dll", "S Script is not located in configured scripts folder. Workspace based imports will fail", "§18.4 F §21"),
    ("report path storage item", "LocalApiHost.dll", "F System.String LastCreatedOutputPathItemName = apym_auto_last_created_report_path", "§18.4 F"),
    ("API level error text", "LocalApiHost.dll", "S Api level {0} not supported. Use newer aria version.", "§18.5 §21"),
    ("single client: second handshake refused", "LocalApiHost.dll", "S Request denied. Handshake already performed and multiple calls are not allowed.", "§18.5 §21"),
    ("RSU V1 workbook sheet OR_Start", "AriaCore.dll", "S OR_Start", "§19.2"),
    ("RSU V1 startup markers", "AriaCore.dll", "S Value_Slot{0}_Start", "§19.2"),
    ("RSU V1 mode marker", "AriaCore.dll", "S RSU_Mode_Slot{0}", "§19.2"),
    ("RSU V1 repetition marker", "AriaCore.dll", "S Repetition_factor_Slot{0}", "§19.2"),
    ("RSU V1 type marker", "AriaCore.dll", "S Type_Slot{0}", "§19.2"),
    ("RSU V1 present marker", "AriaCore.dll", "S Present_Slot{0}", "§19.2"),
    ("RSU V1 status marker", "AriaCore.dll", "S Sensor_Status_Slot{0}", "§19.2"),
    ("RSU V1 config markers", "AriaCore.dll", "S Config_Parmcount{0}", "§19.2"),
    ("RSU startup .rsux line count", "AriaCore.dll", "S 36 lines of startup config data are required", "§19.4 §21"),
    ("RSU config .rsux line count", "AriaCore.dll", "S 26 lines of config data are required", "§19.4 §21"),
    ("RSU V2 workbook area markers", "AriaCore.dll", "S SensorConfig", "§19.1"),
    ("RSU fault names", "LocalApiHost.dll", "S LKG-TO-BATT", "§7"),
]
# RSU_Mode_Slot value -> (SyncAsync, BitMode, RSU_Mode) in RsuV1ConfigurationParser.LoadStartupParameterMode.
RSU_MODE_TABLE = [(0, 10, 4), (1, 10, 8), (0, 8, 8), (1, 8, 16)]


def ps(command: str) -> str:
    return subprocess.run(["powershell", "-NoProfile", "-Command", command], capture_output=True, text=True).stdout


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def version_key(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def find_installs() -> list[dict]:
    dirs = {Path(p) for p in Path("C:/").glob("ARIA*") if (Path(p) / "ARIA.exe").is_file()}
    if os.environ.get("ARIA_DIR"):
        dirs.add(Path(os.environ["ARIA_DIR"]))
    dirs = sorted(d.resolve() for d in dirs if (d / "ARIA.exe").is_file())
    if not dirs:
        return []
    out = ps("; ".join(f"(Get-Item '{d / 'ARIA.exe'}').VersionInfo.FileVersion" for d in dirs)).split()
    return sorted(({"dir": d, "exe": d / "ARIA.exe", "version": v} for d, v in zip(dirs, out)), key=lambda i: version_key(i["version"]))


def select_install(aria_dir: str | None) -> dict:
    installs = find_installs()
    wanted = Path(aria_dir or os.environ.get("ARIA_DIR", "")).resolve() if (aria_dir or os.environ.get("ARIA_DIR")) else None
    if wanted:
        match = [i for i in installs if i["dir"] == wanted]
        if not match:
            raise SystemExit(f"no ARIA.exe in {wanted}")
        return match[0]
    if not installs:
        raise SystemExit("no ARIA install found (C:\\ARIA*\\ARIA.exe); pass --aria-dir")
    if len(installs) > 1:
        print(f"note: {len(installs)} ARIA installs; using the newest, {installs[-1]['dir']}. "
              "Pin one with --aria-dir or ARIA_DIR once the user confirms it.", file=sys.stderr)
    return installs[-1]


def version_folder(install: dict | None = None) -> Path:
    major, minor = (version_key((install or INSTALL)["version"]) + (0, 0))[:2]
    return ARIA_DATA / f"{major}{minor}"


def aria_processes() -> list[dict]:
    """pid, exe and start time (ISO; ARIA reads its project files at start, not later)."""
    out = ps("Get-Process ARIA -ErrorAction SilentlyContinue | ForEach-Object { "
             "'{0}|{1}|{2}' -f $_.Id, $_.Path, $(if ($_.StartTime) { $_.StartTime.ToString('s') }) }")
    return [{"pid": int(p), "exe": x, "started": s or None} for p, x, s in (l.split("|", 2) for l in out.splitlines() if l.count("|") >= 2)]


def aria_pids() -> list[int]:
    """PIDs of the selected install's ARIA.exe."""
    return [p["pid"] for p in aria_processes() if p["exe"] and Path(p["exe"]).resolve() == INSTALL["exe"]]


def running_pids() -> set[int]:
    out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True).stdout
    return {int(m.group(1)) for m in re.finditer(r'^"[^"]*","(\d+)"', out, re.M)}


def instances(live: set[int]) -> list[dict]:
    """ActiveInstances/<pid> = {LocalApiHostPort, LocalApiHostChannel, SynopsysVdkHostPort}; shared by all versions."""
    found = []
    for f in sorted(ACTIVE_INSTANCES.glob("*")) if ACTIVE_INSTANCES.is_dir() else []:
        try:
            data = read_json(f)
        except (OSError, ValueError):
            data = {}
        pid = int(f.name) if f.name.isdigit() else None
        found.append({"file": str(f), "pid": pid, "alive": pid in live, "port": data.get("LocalApiHostPort")})
    return found


def port_open(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def describe_config(main_json: Path) -> dict:
    """Project facts a human checks before starting: customer, files, chassis use, loadbox, scripts folder."""
    info: dict = {"path": str(main_json), "exists": main_json.is_file()}
    if not info["exists"]:
        return info
    cfg = read_json(main_json).get("Configuration", {})
    info["customer"] = cfg.get("Customer")
    info["missing_files"] = [v for k, v in cfg.items()
                             if k not in ("Customer", "EventMode") and v and not (main_json.parent / v).exists()]
    chassis = main_json.parent / (cfg.get("Chassis") or "ChassisConfig.json")
    if chassis.is_file():
        c = read_json(chassis).get("Configuration", {})
        scripts = c.get("ScriptsFolder")
        info["scripts_folder"] = str((main_json.parent / scripts).resolve()) if scripts else None
        info["results_folder"] = c.get("ResultsFolder")
    sensors = main_json.parent / (cfg.get("Sensors") or "SensorsConfig.json")
    if sensors.is_file():  # RsuConfiguration.Path = the RSU workbook ARIA preloads [AD §4.2.1.6]
        rsu = read_json(sensors).get("RsuConfiguration") or {}
        info["rsu_workbook"] = str((main_json.parent / rsu["Path"]).resolve()) if rsu.get("Path") else None
        info["rsu_sensors"] = [s.get("Name") for s in rsu.get("RsuSensors") or []]
    accf = main_json.with_suffix(".accf")
    if accf.is_file():
        root = ET.parse(accf).getroot()
        data = accf.parent / f"{accf.stem}_accdata"  # the bundle's files, each kind under its FilesPath
        hw = root.find("Hardware")
        chan = hw.find("ChassisChannelProperties") if hw is not None else None
        lb = chan.find("LoadboxProperties") if chan is not None else None
        info["accf"] = str(accf)
        info["accf_version"] = root.get("Version")
        info["use_chassis"] = (chan is not None and chan.findtext("CommunicationProperties/IsConnected") == "true")
        if lb is not None:
            info["loadbox"] = lb.findtext("LoadboxFile")
            info["profile"] = lb.findtext("ProfileFile")
            info["reset_and_load_profile_at_start"] = lb.findtext("SystemReset") == "true" and lb.findtext("LoadProfile") == "true"
            info["load_profile_at_start"] = lb.findtext("LoadProfile") == "true"
            folder = data / (lb.get("FilesPath") or "Loadbox")
            info["loadbox_path"] = str(folder / info["loadbox"]) if info["loadbox"] else None
            info["profile_path"] = str(folder / info["profile"]) if info["profile"] else None
        per = root.find("Periodics")
        if per is not None:  # CAN simulations; each .acpdf is a DBC import that names its DatabaseSource per frame
            folder = data / (per.get("FilesPath") or "Periodics")
            info["periodics"] = [{"name": p.get("Name"), "dut": p.findtext("Dut"), "enabled": p.findtext("IsEnabled") == "true",
                                  "file": str(folder / f) if (f := p.findtext("DefinitionsFile")) else None}
                                 for p in per if p.tag.startswith("CanPeriodics")]
    return info


def dbc_frames(path: Path) -> dict[str, dict]:
    """name -> {id, dlc, signals {name: (start bit, length, endian)}} from the BO_/SG_ lines of a DBC."""
    frames: dict[str, dict] = {}
    cur = None
    for line in path.read_text(encoding="latin-1").splitlines():
        m = re.match(r"BO_\s+(\d+)\s+(\w+)\s*:\s*(\d+)\s+\w+", line)
        if m:
            cur = None if m.group(2) == "VECTOR__INDEPENDENT_SIG_MSG" else \
                frames.setdefault(m.group(2), {"id": int(m.group(1)) & 0x1FFFFFFF, "dlc": int(m.group(3)), "signals": {}})
            continue
        m = re.match(r"\s+SG_\s+(\w+)\s*(?:\w+\s*)?:\s*(\d+)\|(\d+)@([01])", line)  # optional multiplexer token
        if m and cur is not None:
            cur["signals"][m.group(1)] = (int(m.group(2)), int(m.group(3)), "Intel" if m.group(4) == "1" else "Motorola")
    return frames


def acpdf_frames(path: Path) -> tuple[dict[str, dict], set[str]]:
    """The frames of an ARIA periodics file (same shape as dbc_frames) and the DBC names it was imported from."""
    frames, sources = {}, set()
    node = ET.parse(path).getroot().find("Frames")
    for f in (list(node) if node is not None else []):
        sources.add(f.findtext("DatabaseSource") or "")
        frames[f.get("Name")] = {"id": int(f.get("Id")) & 0x1FFFFFFF, "dlc": int(f.get("Dlc")),
                                 "diagnostic": f.find(".//DiagnosticPduDefinition") is not None,
                                 "signals": {s.get("Name"): (int(s.findtext("StartBit")), int(s.findtext("BitLength")), s.findtext("Endian"))
                                             for s in f.iter("SignalDefinition")}}
    return frames, sources - {""}


def compare_frames(aria: dict[str, dict], dbc: dict[str, dict]) -> list[str]:
    """Differences between what ARIA simulates/decodes and the DBC. None in ARIA's data = not known (live mapping)."""
    out = [f"frame {n} is in the DBC but not in ARIA" for n in dbc if n not in aria]
    for name, a in aria.items():
        d = dbc.get(name)
        if d is None:
            out.append(f"frame {name} is in ARIA but not in the DBC")
            continue
        if a.get("id") not in (None, d["id"]) or a.get("dlc") not in (None, d["dlc"]):
            out.append(f"frame {name}: DBC id 0x{d['id']:X} DLC {d['dlc']}, ARIA id 0x{a['id']:X} DLC {a['dlc']}")
        if a.get("diagnostic"):
            continue  # ARIA carries a diagnostic frame as one raw PDU, without the DBC's data signal
        for s, (start, length, endian) in d["signals"].items():
            got = a["signals"].get(s)
            if got is None:
                out.append(f"{name}.{s} is in the DBC but not in ARIA")
            elif got[1] is not None and (got[1] != length or got[2] != endian or (endian == "Intel" and got[0] != start)):
                # Motorola start bits are numbered differently by the two tools: only the length is compared
                out.append(f"{name}.{s}: DBC start {start} length {length} {endian}, ARIA start {got[0]} length {got[1]} {got[2]}")
        out += [f"{name}.{s} is in ARIA but not in the DBC" for s in a["signals"] if s not in d["signals"]]
    return out


def same_file(a: Path, b: Path) -> bool:
    if a.resolve() == b.resolve():
        return True
    return a.is_file() and b.is_file() and hashlib.sha256(a.read_bytes()).digest() == hashlib.sha256(b.read_bytes()).digest()


def block_rules() -> list[str]:
    """'<Direction>|<Enabled>|<Program>' of every 'Block ARIA*' firewall rule."""
    return [l for l in ps("Get-NetFirewallRule -DisplayName 'Block ARIA*' | ForEach-Object { "
                          "'{0}|{1}|{2}' -f $_.Direction, $_.Enabled, ($_ | Get-NetFirewallApplicationFilter).Program }").splitlines() if "|" in l]


def unblocked(rules: list[str], exes: list[Path]) -> list[str]:
    """Exe + direction of an install that no enabled block rule covers."""
    covered = {(d.lower(), p.lower()) for d, e, p in (r.split("|", 2) for r in rules) if e == "True"}
    return [f"{d}: {exe}" for exe in exes for d in ("Outbound", "Inbound") if (d.lower(), str(exe).lower()) not in covered]


def shipped_apym(install: dict) -> str | None:
    wheels = sorted((install["dir"] / "pymodules").glob("apym-*.whl"))
    m = re.match(r"apym-([\d.]+)-", wheels[-1].name) if wheels else None
    return m.group(1) if m else None


def aria_windows(pids: list[int]) -> list[str]:
    """Top-level window titles of ARIA (UI Automation): shows a modal dialog blocking an unattended start."""
    if not pids:
        return []
    out = ps("Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes; "
             "$root = [Windows.Automation.AutomationElement]::RootElement; "
             f"foreach ($p in @({','.join(map(str, pids))})) {{ "
             "$c = New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::ProcessIdProperty, $p); "
             "$root.FindAll([Windows.Automation.TreeScope]::Children, $c) | ForEach-Object { $_.Current.Name } }")
    return [l for l in out.splitlines() if l.strip()]


def newest_log() -> Path | None:
    logs = sorted((version_folder() / "ApplicationLog").glob("AppLog_*.log"), key=lambda p: p.stat().st_mtime)
    return logs[-1] if logs else None


def cmd_versions(_: argparse.Namespace) -> int:
    rules = block_rules()
    rows = []
    for i in find_installs():
        rows.append({"dir": str(i["dir"]), "version": i["version"], "selected": i["dir"] == INSTALL["dir"],
                     "data_folder": str(version_folder(i)), "data_folder_exists": (version_folder(i) / "rts").is_file(),
                     "shipped_apym": shipped_apym(i), "network_unblocked": unblocked(rules, sorted(i["dir"].rglob("*.exe")))})
    print(json.dumps(rows, indent=2))
    return 0


def cmd_status(_: argparse.Namespace) -> int:
    live = running_pids()
    rts_path = version_folder() / "rts"
    rts = read_json(rts_path) if rts_path.is_file() else {}
    active = rts.get("ActiveConfigurationPath")
    procs = aria_processes()
    pids = [p["pid"] for p in procs if p["exe"] and Path(p["exe"]).resolve() == INSTALL["exe"]]
    report = {
        "selected_install": {"dir": str(INSTALL["dir"]), "version": INSTALL["version"], "data_folder": str(version_folder())},
        "aria_processes": procs,
        "aria_windows": aria_windows([p["pid"] for p in procs]),
        "active_instances": instances(live),
        "rts": str(rts_path) if rts_path.is_file() else f"{rts_path} (missing: this version was never started)",
        "active_configuration": describe_config(Path(active)) if active else None,
        "network_unblocked": unblocked(block_rules(), sorted(INSTALL["dir"].rglob("*.exe"))),
        "newest_app_log": None,
    }
    if any(p not in pids for p in (q["pid"] for q in procs)):
        report["note"] = "an ARIA of another install is running; apym auto-discovery sees all instances"
    log = newest_log()
    if log:
        report["newest_app_log"] = {"path": str(log), "MB": round(log.stat().st_size / 1e6, 1)}
    print(json.dumps(report, indent=2))
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    log = Path(args.file) if args.file else newest_log()
    if not log or not log.is_file():
        print("no ApplicationLog found")
        return 1
    ts = re.compile(r"^(\d\d:\d\d:\d\d:\d+)\t(.*)")
    first: dict[str, str] = {}
    count: Counter = Counter()
    with log.open("rb") as f:
        for raw in f:
            m = ts.match(raw.decode("utf-8", "replace").rstrip("\r\n"))
            if not m or (not args.all and LOG_NOISE.search(m.group(2))):
                continue
            key = re.sub(r"\d+", "#", m.group(2).split(" at ")[0])[:200]
            count[key] += 1
            first.setdefault(key, f"{m.group(1)}  {m.group(2)[:300]}")
    print(f"{log}  ({log.stat().st_size / 1e6:.1f} MB, {sum(count.values())} lines kept)")
    for key, line in list(first.items())[-args.tail:]:
        print(f"x{count[key]:<6} {line}")
    return 0


def load_apym():
    sys.dont_write_bytecode = True  # no .pyc into protected shared_libraries/ (decisions.md D-2026-08-29-11)
    sys.path.insert(0, str(REPO_ROOT))
    from shared_libraries.apym_imports import ensure_apym_on_path  # locates the apym sdist
    ensure_apym_on_path()
    try:
        import apym
    except ImportError:  # apym lives in C:\Python 3.14.0\Lib\apym-*; other interpreters lack it
        raise SystemExit('apym missing: run with  py -3.14  or  "C:\\Python 3.14.0\\python.exe"')
    return apym


def cmd_ping(args: argparse.Namespace) -> int:
    live = [i for i in instances(running_pids()) if i["alive"]]
    if not args.port and not live:
        print("ARIA is not running: no live ActiveInstances file"
              + (" (stale ones exist: run clean-stale)" if instances(set()) else ""))
        return 1
    load_apym()
    from shared_libraries.apym_imports import init_instance  # steps the API level down for older ARIA
    from apym.connection import Instance
    from apym.functions import Api
    init_instance(Instance, args.port)
    cfg = Api.Configuration
    out = {"aria_version": cfg.get_aria_version(),
           "communication_channels": cfg.get_communication_channels(),
           "uds_channels": cfg.get_uds_channels(),
           "simulations": cfg.get_simulations()}
    try:
        out["loadbox_cards"] = [{"slot": c.slot, "name": c.name, "type": c.type,
                                 "functions": [f"{f.channel}:{f.name}({f.type})" for f in c.functions]}
                                for c in cfg.get_loadbox_configuration()]
    except Exception as exc:  # no chassis / no loadbox is a valid answer, not a ping failure
        out["loadbox_cards"] = f"unavailable: {exc}"
    print(json.dumps(out, indent=2, default=str))
    return 0


def cmd_use_config(args: argparse.Namespace) -> int:
    target = Path(args.file).resolve()
    info = describe_config(target)
    if not info["exists"] or target.suffix.lower() != ".json":
        print(f"refused: {target} is not an existing AriaMain.json (ARIA would open a file dialog at start)")
        return 2
    if info.get("missing_files"):
        print(f"refused: files referenced by {target.name} are missing: {info['missing_files']}")
        return 2
    rts_path = version_folder() / "rts"
    if not rts_path.is_file():
        print(f"refused: {rts_path} does not exist yet. Start ARIA {INSTALL['version']} once; it asks for the "
              "AriaMain.json in a dialog and creates the file. Then use-config works.")
        return 2
    rts = read_json(rts_path)
    print(json.dumps({"rts": str(rts_path), "from": rts.get("ActiveConfigurationPath"), "to": str(target), "project": info}, indent=2))
    if aria_pids():
        print("refused: close ARIA first; it loads the configuration only at start")
        return 2
    if not args.apply:
        print("plan only; add --apply to write rts (a timestamped backup is kept next to it)")
        return 0
    backup = rts_path.with_name(f"rts.bak-{dt.datetime.now():%Y%m%d-%H%M%S}")
    backup.write_bytes(rts_path.read_bytes())
    rts["ActiveConfigurationPath"] = str(target)
    rts_path.write_text(json.dumps(rts, indent=2), encoding="utf-8")
    print(f"ActiveConfigurationPath set; backup {backup}")
    return 0


def cmd_start(args: argparse.Namespace) -> int:
    rts_path = version_folder() / "rts"
    rts = read_json(rts_path) if rts_path.is_file() else {}
    info = describe_config(Path(rts.get("ActiveConfigurationPath") or "."))
    print(json.dumps({"exe": str(INSTALL["exe"]), "version": INSTALL["version"], "py_host": args.py_host, "project": info}, indent=2))
    if not info["exists"]:
        print("refused: no valid active project for this version (ARIA would wait in a file dialog); run use-config first")
        return 2
    if aria_processes() and not args.allow_second:
        print("refused: an ARIA is already running (apym cannot auto-pick between two instances)")
        return 2
    if not args.apply:
        warn = " With a chassis this resets the cards and loads the loadbox profile." if info.get("use_chassis") else ""
        print(f"plan only; add --apply to launch.{warn}")
        return 0
    argv = [str(INSTALL["exe"])] + (["-py_host"] if args.py_host else [])
    proc = subprocess.Popen(argv, cwd=str(INSTALL["dir"]), creationflags=0x00000008 | 0x00000200)  # DETACHED | NEW_GROUP
    deadline = time.time() + args.timeout
    instance = ACTIVE_INSTANCES / str(proc.pid)
    while time.time() < deadline:
        if instance.is_file():
            port = read_json(instance).get("LocalApiHostPort")
            if port and port_open(port):
                print(json.dumps({"pid": proc.pid, "port": port, "ready_s": round(args.timeout - (deadline - time.time()), 1)}))
                return 0
        if proc.poll() is not None:
            print(f"ARIA exited with code {proc.returncode} before the API came up; run 'logs'")
            return 1
        time.sleep(1)
    print(f"ARIA pid {proc.pid} started but the API was not up after {args.timeout} s. The API starts before any "
          "window, so look for the modal 'Select the AriaMain.json configuration file' dialog: run 'status' "
          "(window titles) and 'logs'")
    return 1


def cmd_stop(args: argparse.Namespace) -> int:
    pids = aria_pids()
    print(json.dumps({"aria_processes": pids, "force": args.force}))
    if not pids:
        return 0
    if not args.apply:
        print("plan only; add --apply. Without --force ARIA asks 'Do you really want to close the program?' on screen. "
              "With --force the chassis keeps its last relay/power state; put the ECU in a safe state first.")
        return 0
    for pid in pids:
        subprocess.run(["taskkill", "/PID", str(pid)] + (["/F"] if args.force else []))
    return 0


def cmd_clean_stale(args: argparse.Namespace) -> int:
    stale = [i for i in instances(running_pids()) if not i["alive"]]
    print(json.dumps(stale, indent=2))
    if stale and not args.apply:
        print("plan only; add --apply to delete these files (ARIA itself deletes them at its next start)")
        return 0
    for i in stale:
        Path(i["file"]).unlink(missing_ok=True)
    return 0


def live_api():
    """apym Api connected to the one live instance of the selected install, or None."""
    if len([i for i in instances(running_pids()) if i["alive"]]) != 1:
        return None
    load_apym()
    from shared_libraries.apym_imports import init_instance
    from apym.connection import Instance
    from apym.functions import Api
    init_instance(Instance, None)
    return Api


def cmd_check_inputs(args: argparse.Namespace) -> int:
    """Is ARIA set up with the files the user named? Read-only: files, and with --live the running ARIA's get_* calls."""
    rts_path = version_folder() / "rts"
    active = (read_json(rts_path) if rts_path.is_file() else {}).get("ActiveConfigurationPath")
    info = describe_config(Path(active)) if active else {"path": None, "exists": False}
    checks: list[dict] = []

    def add(check: str, ok: bool | None, detail: str) -> None:  # ok None = a note, not a problem
        checks.append({"check": check, "status": "ok" if ok else "note" if ok is None else "problem", "detail": detail})

    if args.config:
        # by path: AriaMain.json files of different projects can be byte-identical (they only name their siblings)
        add("project", bool(active) and Path(active).resolve() == Path(args.config).resolve(),
            f"ARIA's active project is {active}; expected {args.config}" + ("" if info["exists"] else " (active file missing)"))
    elif not info["exists"]:
        add("project", False, f"no valid active project: {active}")
    if info["exists"]:
        file_checks(args, info, add)
    out = {"project": info, "checks": checks, "problems": [f"{c['check']}: {c['detail']}" for c in checks if c["status"] == "problem"]}
    print(json.dumps(out, indent=2, default=str))
    return 0


def file_checks(args: argparse.Namespace, info: dict, add) -> None:
    """The active project's files against the ones the user named; --live adds the running ARIA."""

    proc = next((p for p in aria_processes() if p["exe"] and Path(p["exe"]).resolve() == INSTALL["exe"]), None)
    if proc and proc["started"]:  # ARIA read these at its start: a later change is not what it runs
        started = dt.datetime.fromisoformat(proc["started"])
        files = [info["path"], info.get("accf"), info.get("loadbox_path"), info.get("profile_path"), info.get("rsu_workbook")]
        files += [p["file"] for p in info.get("periodics", []) if p["enabled"]]
        later = [f for f in files if f and Path(f).is_file() and dt.datetime.fromtimestamp(Path(f).stat().st_mtime) > started]
        add("files unchanged since ARIA started", not later,
            f"changed after ARIA started at {proc['started']} (restart ARIA to load them): {later}" if later else f"ARIA started {proc['started']}")

    if args.profile:
        have = info.get("profile_path")
        ok = bool(have) and same_file(Path(have), Path(args.profile))
        add("loadbox profile", ok, f"ARIA's profile is {have}; expected {args.profile}")
        if ok and not info.get("load_profile_at_start"):
            add("loadbox profile", None, "LoadProfile is false: ARIA does not apply the profile at start")

    if args.rsu:
        have = info.get("rsu_workbook")
        add("RSU workbook", bool(have) and same_file(Path(have), Path(args.rsu)),
            f"ARIA preloads {have} (SensorsConfig.json RsuConfiguration.Path, sensors {info.get('rsu_sensors')}); expected {args.rsu}")

    dbcs = {Path(d).name: dbc_frames(Path(d)) for d in args.dbc or []}
    if dbcs and not info.get("periodics"):
        add("DBC", False, f"the active project has no CAN simulation (.accf Periodics) to compare with {sorted(dbcs)}")
    used: set[str] = set()
    for sim in info.get("periodics", []) if dbcs else []:
        if not sim["enabled"]:
            add(f"DBC {sim['name']}", None, f"simulation {sim['name']} (Dut {sim['dut']}) is disabled in ARIA: not checked")
            continue
        try:
            frames, sources = acpdf_frames(Path(sim["file"]))
        except (OSError, ET.ParseError, TypeError, ValueError) as exc:
            add(f"DBC {sim['name']}", False, f"cannot read {sim['file']}: {exc}")
            continue
        name, dbc = max(dbcs.items(), key=lambda kv: len(set(kv[1]) & set(frames)))
        if not set(dbc) & set(frames):
            add(f"DBC {sim['name']}", False, f"no given DBC shares a frame with simulation {sim['name']} (imported from {sorted(sources)})")
            continue
        used.add(name)
        diff = compare_frames(frames, dbc)
        if sources != {name}:  # another file name with the same content is a note, not a wrong DBC
            add(f"DBC {sim['name']}", None if not diff else False,
                f"simulation {sim['name']} was imported from {sorted(sources)}, the given DBC is {name}")
        add(f"DBC {sim['name']} content", not diff, f"{len(diff)} difference(s) to {name}: " + "; ".join(diff[:15]) if diff
            else f"{len(frames)} frames match {name}")
    for name in sorted(set(dbcs) - used) if info.get("periodics") is not None else []:
        add(f"DBC {name}", None, f"{name} is used by no enabled ARIA simulation")

    if args.live:
        try:
            api = live_api()
        except Exception as exc:  # a failed connection is a finding, not a crash
            api, error = None, exc
        else:
            error = "no single live ARIA instance"
        if api is None:
            add("live ARIA", None, f"live checks skipped: {error}")
        else:
            try:
                live_checks(api, info, dbcs, add)
            except Exception as exc:
                add("live ARIA", None, f"live checks stopped: {exc}")


def live_checks(api, info: dict, dbcs: dict[str, dict], add) -> None:
    """What the running ARIA has loaded (read-only get_* calls) against the active project and the given DBCs."""
    sims = api.Configuration.get_simulations() or []
    expected = [p["name"] for p in info.get("periodics", []) if p["enabled"]]
    add("live simulations", set(expected) <= set(sims), f"running ARIA has simulations {sims}; the active project enables {expected}")
    for sim in [s for s in sims if s in expected] if dbcs else []:
        live = {f.name: {"id": None, "dlc": None, "diagnostic": not any(p.signals for p in f.pdus.values()),
                         "signals": {s: (None, None, None) for p in f.pdus.values() for s in p.signals}}
                for f in (api.Configuration.get_simulation_mapping(sim) or {}).values()}
        name, dbc = max(dbcs.items(), key=lambda kv: len(set(kv[1]) & set(live)))
        diff = compare_frames(live, dbc) if set(dbc) & set(live) else [f"no given DBC shares a frame with {sim}"]
        add(f"live DBC {sim}", not diff, "; ".join(diff[:15]) if diff else f"{len(live)} frames match {name}")
    ldbx = Path(info["loadbox_path"]) if info.get("loadbox_path") else None
    if ldbx and ldbx.is_file():
        want = {(c["Slot"], c["Name"]) for c in read_json(ldbx).get("Content", {}).get("Cards", [])}
        try:
            have = {(c.slot, c.name) for c in api.Configuration.get_loadbox_configuration()}
        except Exception as exc:  # no chassis
            add("live loadbox", None, f"loadbox not readable: {exc}")
            return
        # shortcut: whether the API lists absent (PresenceGroups) cards is unverified, so a partial difference is a note
        add("live loadbox", True if want == have else None if want & have else False, f"{len(have)} cards as in {ldbx.name}" if want == have
            else f"running ARIA has {len(have)} cards, {ldbx.name} defines {len(want)}; differ: {sorted(want ^ have)[:10]}")


def cmd_read_dtc(args: argparse.Namespace) -> int:
    """The framework's own fault-free check: Read_DTC_Req (shared configuration_control) answered with no DTC."""
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(REPO_ROOT))
    if args.project:
        os.environ["FRAMEWORK_PROJECT"] = args.project  # the framework picks the project's channels from it
    from shared_libraries.configuration_control import Read_DTC_Req
    result = {"request": Read_DTC_Req, "project": args.project, "fault_free": None}
    if not args.apply:
        print(json.dumps(result))
        print("plan only: sends one UDS ReadDTCInformation request on the framework's default diagnostic channel "
              "(no write, no power change); add --apply")
        return 0
    if len([i for i in instances(running_pids()) if i["alive"]]) != 1:
        print(json.dumps(dict(result, error="no single live ARIA instance")))
        return 1
    load_apym()
    from shared_libraries import jscript_translation as jt
    if not jt.ensure_runtime():
        print(json.dumps(dict(result, error=f"framework runtime: {jt._runtime_error}")))
        return 1
    resp = jt.CAN.SendDiagByValuesNoLog(Read_DTC_Req)  # returns the exception instead of raising
    dtcs = None if isinstance(resp, Exception) else dtc_records(str(resp))
    if dtcs is None:
        print(json.dumps(dict(result, response=str(resp), error="no positive answer: is the ECU powered and past its proveout?")))
        return 1
    print(json.dumps(dict(result, fault_free=not dtcs, response=str(resp), dtcs=dtcs)))  # one line: callers read the last line
    return 0


def dtc_records(response: str) -> list[dict] | None:
    """DTCs of a '0x59 0x02 <availability mask> [3 DTC bytes + status]...' answer; None if it is not one."""
    data = [int(t, 16) for t in response.split() if re.fullmatch(r"0x[0-9A-Fa-f]{2}", t)]
    if len(data) < 3 or data[:2] != [0x59, 0x02]:
        return None
    return [{"dtc": "0x" + "".join(f"{b:02X}" for b in data[i:i + 3]), "status": f"0x{data[i + 3]:02X}",
             "active": bool(data[i + 3] & 0x01)} for i in range(3, len(data) - 3, 4)]  # bit 0 = testFailed


def ensure_dumps(install: dict, refresh: bool = False) -> Path:
    """Reflection dumps of the internal assemblies of one ARIA version (cached per version)."""
    out = CACHE / install["version"]
    if refresh or not all((out / f"{a}.txt").is_file() for a in INTERNAL_ASSEMBLIES):
        print(f"reading {install['dir']} by reflection into {out} (about a minute)...", file=sys.stderr)
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(DUMPER), "-AriaDir",
                        str(install["dir"]), "-Out", str(out), "-Assemblies", ",".join(INTERNAL_ASSEMBLIES)],
                       check=True, capture_output=True, text=True)
    return out


def handler_keys(local_api_dump: str) -> tuple[set[str], int]:
    """String literals of the LevelN constructors = the Category/Name keys ARIA registers; N max = API level."""
    keys: set[str] = set()
    level, in_level, in_ctor = 0, False, False
    for line in local_api_dump.splitlines():
        if line.startswith("T "):
            m = re.match(r"T LocalApiHost\.Api\.Levels\.Level(\d+) :", line)
            in_level, in_ctor = bool(m), False
            if m:
                level = max(level, int(m.group(1)))
        elif line.startswith("  M "):
            in_ctor = in_level and line.startswith("  M .ctor(")
        elif in_ctor and line.startswith("    S "):
            keys.add(line[6:].strip())
    return keys, level


def rsu_mode_table(il: str) -> list[tuple[int, int, int]]:
    """(SyncAsync, BitMode, RSU_Mode) per mode case, from the IL of LoadStartupParameterMode."""
    rows, current, last = [], {}, None
    for line in il.splitlines():
        m = re.search(r"ldc\.i4(?:\.s)? (-?\d+)$|ldc\.i4\.(\d)\s*$", line.strip())
        if m:
            last = int(m.group(1) or m.group(2))
        s = re.search(r"set_(SyncAsync|BitMode|RSU_Mode)", line)
        if s and last is not None:
            current[s.group(1)] = last
            if s.group(1) == "RSU_Mode":
                rows.append((current.get("SyncAsync"), current.get("BitMode"), last))
                current = {}
    return rows


def apym_calls(source: Path) -> list[dict]:
    """Walk the nested Api classes; each function's AriaApiRequest(level, category, name, ...)."""
    calls = []

    def walk(node: ast.AST, prefix: list[str]) -> None:
        for n in getattr(node, "body", []):
            if isinstance(n, ast.ClassDef):
                walk(n, prefix + [n.name])
            elif isinstance(n, ast.FunctionDef) and prefix:
                req = next((c for c in ast.walk(n) if isinstance(c, ast.Call)
                            and getattr(c.func, "id", getattr(c.func, "attr", "")) == "AriaApiRequest"), None)
                if req is None or len(req.args) < 3:
                    continue
                try:
                    category, name = ast.literal_eval(req.args[1]), ast.literal_eval(req.args[2])
                except ValueError:
                    continue
                doc = (ast.get_docstring(n) or "").strip().splitlines()
                calls.append({"call": ".".join(prefix + [n.name]), "args": ast.unparse(n.args),
                              "returns": ast.unparse(n.returns) if n.returns else "None",
                              "aria": f"{category}/{name}", "doc": doc[0] if doc else ""})

    walk(ast.parse(source.read_text(encoding="utf-8")), [])
    return calls


def apym_level(connection_py: Path) -> int | None:
    m = re.search(r"LATEST_API_LEVEL\s*:\s*int\s*=\s*(\d+)", connection_py.read_text(encoding="utf-8"))
    return int(m.group(1)) if m else None


def compat_report(refresh: bool = False) -> dict:
    apym = load_apym()
    pkg = Path(apym.__file__ or "").parent
    version = re.search(r"apym-([\d.]+)", str(pkg))
    keys, aria_level = handler_keys((ensure_dumps(INSTALL, refresh) / "LocalApiHost.dll.txt").read_text(encoding="utf-8", errors="replace"))
    calls = apym_calls(pkg / "functions.py")
    level = apym_level(pkg / "connection.py")
    return {"aria": INSTALL["version"], "aria_api_level": aria_level, "aria_handlers": len(keys),
            "apym": version.group(1) if version else str(pkg), "apym_api_level": level,
            "apym_shipped_with_aria": shipped_apym(INSTALL), "apym_calls": len(calls),
            "handshake_ok": level is not None and level <= aria_level,
            "not_served": [f"{c['call']} -> {c['aria']}" for c in calls if c["aria"].split("/", 1)[1] not in keys],
            "_calls": calls, "_keys": keys}


def cmd_compat(args: argparse.Namespace) -> int:
    r = compat_report(args.refresh)
    print(json.dumps({k: v for k, v in r.items() if not k.startswith("_")}, indent=2))
    return 0 if r["handshake_ok"] else 1


def cmd_verify_internals(args: argparse.Namespace) -> int:
    d = ensure_dumps(INSTALL, args.refresh)
    lines = {a: {l.strip() for l in (d / f"{a}.txt").read_text(encoding="utf-8", errors="replace").splitlines()}
             for a in INTERNAL_ASSEMBLIES}
    results = [{"fact": f, "assembly": a, "ok": needle in lines[a], "agent_sections": s} for f, a, needle, s in INTERNAL_FACTS]
    il = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(DUMPER), "-AriaDir", str(INSTALL["dir"]),
                         "-Assemblies", "AriaCore.dll", "-Disasm", r"RsuV1ConfigurationParser::LoadStartupParameterMode$"],
                        capture_output=True, text=True).stdout
    modes = rsu_mode_table(il)
    results.append({"fact": "RSU_Mode 0..3 = Sync10/Async10/Sync8/Async8", "assembly": "AriaCore.dll",
                    "ok": modes == RSU_MODE_TABLE, "agent_sections": "§19.2", "found": modes})
    changed = [r for r in results if not r["ok"]]
    print(json.dumps({"aria": INSTALL["version"], "checked": len(results), "changed": changed,
                      "verdict": "all facts hold" if not changed else
                      "re-derive the changed facts (tools/aria_il_dump.ps1 -Disasm) and update the agent sections listed"}, indent=2))
    return 1 if changed else 0


def cmd_api_reference(args: argparse.Namespace) -> int:
    r = compat_report()
    missing = {c.split(" -> ")[1] for c in r["not_served"]}
    ver = r["aria"]
    lines = [f"# apym call reference (apym {r['apym']}, checked against ARIA {ver})", "",
             f"Generated by `python tools/aria_ctl.py api-reference` from the installed apym and the ARIA {ver} local-API",
             "handler table. Do not edit by hand. Each call sends `{Category, Name, Params}` JSON to the ARIA local API",
             f"(loopback TCP). apym API level {r['apym_api_level']}, ARIA API level {r['aria_api_level']}.",
             f"`not in {ver}` = ARIA {ver} has no handler for it; the call fails with "
             "\"Api <Name> not found in category <Category>\".", "",
             "| apym call | arguments | returns | ARIA request | note |", "|---|---|---|---|---|"]
    for c in r["_calls"]:
        note = f"not in {ver}" if c["aria"] in missing else ""
        doc = c["doc"].replace("|", "/").replace("<br/>", "")
        lines.append(f"| `{c['call']}` | `{c['args']}` | `{c['returns']}` | {c['aria']} | {note} {doc}".rstrip() + " |")
    text = "\n".join(lines) + "\n"
    out = Path(args.out)
    if args.check:
        same = out.is_file() and out.read_text(encoding="utf-8") == text
        print(f"{out}: {'up to date' if same else 'differs from a fresh generation'}")
        return 0 if same else 1
    out.write_text(text, encoding="utf-8")
    print(f"{len(r['_calls'])} calls -> {out}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Operate the local ARIA 5.x tool from the command line.")
    ap.add_argument("--aria-dir", help="ARIA install folder (default: %%ARIA_DIR%%, else the newest C:\\ARIA*)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("versions").set_defaults(fn=cmd_versions)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    p = sub.add_parser("logs"); p.set_defaults(fn=cmd_logs)
    p.add_argument("--file"); p.add_argument("--all", action="store_true", help="keep telemetry noise")
    p.add_argument("--tail", type=int, default=80, help="last N distinct messages")
    p = sub.add_parser("ping"); p.set_defaults(fn=cmd_ping); p.add_argument("--port", type=int)
    p = sub.add_parser("use-config"); p.set_defaults(fn=cmd_use_config)
    p.add_argument("file"); p.add_argument("--apply", action="store_true")
    p = sub.add_parser("start"); p.set_defaults(fn=cmd_start)
    p.add_argument("--py-host", action="store_true", help="headless API host, no main window")
    p.add_argument("--timeout", type=int, default=180); p.add_argument("--allow-second", action="store_true")
    p.add_argument("--apply", action="store_true")
    p = sub.add_parser("stop"); p.set_defaults(fn=cmd_stop)
    p.add_argument("--force", action="store_true"); p.add_argument("--apply", action="store_true")
    p = sub.add_parser("clean-stale"); p.set_defaults(fn=cmd_clean_stale); p.add_argument("--apply", action="store_true")
    p = sub.add_parser("check-inputs"); p.set_defaults(fn=cmd_check_inputs)
    p.add_argument("--config", help="AriaMain.json the user named"); p.add_argument("--profile", help="loadbox profile JSON")
    p.add_argument("--rsu", help="RSU workbook"); p.add_argument("--dbc", action="append", help="DBC file (repeat)")
    p.add_argument("--live", action="store_true", help="also ask the running ARIA (read-only get_* calls)")
    p = sub.add_parser("read-dtc"); p.set_defaults(fn=cmd_read_dtc)
    p.add_argument("--project", help="framework project (FRAMEWORK_PROJECT)"); p.add_argument("--apply", action="store_true")
    p = sub.add_parser("compat"); p.set_defaults(fn=cmd_compat); p.add_argument("--refresh", action="store_true")
    p = sub.add_parser("verify-internals"); p.set_defaults(fn=cmd_verify_internals); p.add_argument("--refresh", action="store_true")
    p = sub.add_parser("api-reference"); p.set_defaults(fn=cmd_api_reference)
    p.add_argument("out"); p.add_argument("--check", action="store_true", help="compare instead of writing")
    args = ap.parse_args(argv)
    INSTALL.clear()
    INSTALL.update(select_install(args.aria_dir))
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
