"""Offline check of the jscript_translation wrappers, RESULT reporting and faultTimeMeasurement.

Runs against the REAL apym reporter (apym.reports.ApymReports, offline: no ARIA needed) and
a fake apym ``Api`` that records every call, so nothing touches ARIA or the bench. The
faultTimeMeasurement checks use a simulated ECU answering 19 02.

Usage:  python tools/check_jscript_wrappers_offline.py [report_dir]
        (report_dir defaults to a new temporary folder; FRAMEWORK_PARENT selects the folder
        holding Framework_IOEM_Py, default the parent of this repository)
Prints one line per check - PASS/FAIL, the check, what was observed - and exits 1 on any FAIL.
Record of the review behind it: docs/improvements/jscript-wrapper-review.md
"""
from __future__ import annotations

import os
import sys
import tempfile
import time
import uuid
from types import SimpleNamespace

os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "M310_M314_M110")
FRAMEWORK_PARENT = os.environ.get(
    "FRAMEWORK_PARENT", os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, FRAMEWORK_PARENT)
sys.path.insert(0, os.path.join(FRAMEWORK_PARENT, "Framework_IOEM_Py"))

import Framework_IOEM_Py.shared_libraries.jscript_translation as jt  # noqa: E402  (puts apym on sys.path)
import Framework_IOEM_Py.shared_libraries.core_functions as cf  # noqa: E402

import apym.reports as apym_reports  # noqa: E402
from apym.reports import ApymReports, ApymReportsOptions  # noqa: E402
from Framework_IOEM_Py.shared_libraries.configuration_control import TestStatus  # noqa: E402

REPORT_DIR = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix="jscript_wrapper_check_")
RESULTS: list[tuple[bool, str, str]] = []


def check(name: str, ok: bool, observed: object) -> None:
    RESULTS.append((bool(ok), name, str(observed)))


# ── real reporter, with every step recorded as the HTML renders it ───────────
STEPS: list[dict] = []
_RealStepNode = apym_reports.StepNode


class RecordingStepNode(_RealStepNode):
    def __init__(self, name, expect, actual, passed, content, timestamp, shared_data):
        super().__init__(name, expect, actual, passed, content, timestamp, shared_data)
        # apym renders FAILED only for ``passed == False`` (report_nodes.StepNode).
        STEPS.append({"name": name, "expected": expect, "obtained": actual,
                      "passed_arg": passed, "html": "FAILED" if passed == False else "PASSED"})  # noqa: E712


apym_reports.StepNode = RecordingStepNode
options = ApymReportsOptions()
options.store_as_last_generated_report_path = False  # no ARIA connection offline
options.direct_write = True
ApymReports.create(os.path.join(REPORT_DIR, "harness_report.html"), "harness", options)


def insertion_node():
    return ApymReports._ApymReports__current_insertion_node


def group_depth() -> int:
    depth, node = 0, insertion_node()
    while node.parent_node is not None:
        depth, node = depth + 1, node.parent_node
    return depth


def last_step_after(call) -> tuple[dict | None, int]:
    """Run call inside an outer group; return (new step or None, groups left open/closed delta)."""
    ApymReports.add_group("outer")
    before_steps = len(STEPS)
    depth_before = group_depth()
    try:
        call()
    except Exception as exc:  # the wrappers must not raise; record it
        STEPS.append({"name": "<raised>", "expected": "", "obtained": repr(exc), "passed_arg": None, "html": "RAISED"})
    depth_after = group_depth()
    ApymReports.close_group()
    new = STEPS[before_steps:]
    return (new[-1] if new else None), depth_after - depth_before


def verdict_of(call) -> str:
    step, delta = last_step_after(call)
    verdict = "NO STEP" if step is None else step["html"]
    return verdict + ("" if delta == 0 else f" (group balance {delta:+d})")


# ── 1. reporting functions ────────────────────────────────────────────────────
R = jt.RESULT
cases = [
    # (description, call, expected HTML verdict)
    ("LogCustomAction verdict TestStatus.Failed", lambda: R.LogCustomAction("x", "exp", "obt", TestStatus.Failed), "FAILED"),
    ("LogCustomAction verdict TestStatus.Passed", lambda: R.LogCustomAction("x", "exp", "obt", TestStatus.Passed), "PASSED"),
    ("LogCustomAction verdict False", lambda: R.LogCustomAction("x", "exp", "obt", False), "FAILED"),
    ("LogCustomAction verdict True", lambda: R.LogCustomAction("x", "exp", "obt", True), "PASSED"),
    ("LogCustomAction no verdict, expected != obtained", lambda: R.LogCustomAction("x", "exp", "obt"), "FAILED"),
    ("LogCustomAction no verdict, expected == obtained", lambda: R.LogCustomAction("x", "same", "same"), "PASSED"),
    ("LogCustomAction verdict 'FAILED' string", lambda: R.LogCustomAction("x", "a", "a", "FAILED"), "FAILED"),
    ("InterpretEqualResult no verdict, mismatch", lambda: R.InterpretEqualResult("x", "0x0B", "0x0A"), "FAILED"),
    ("InterpretEqualResult no verdict, match", lambda: R.InterpretEqualResult("x", "0x0B", "0x0B"), "PASSED"),
    ("InterpretEqualResult TestStatus.Failed", lambda: R.InterpretEqualResult("x", "a", "a", TestStatus.Failed), "FAILED"),
    ("InterpretEqualResult TestStatus.Passed", lambda: R.InterpretEqualResult("x", "a", "b", TestStatus.Passed), "PASSED"),
    ("InterpretEqualResult verdict False (bool)", lambda: R.InterpretEqualResult("x", "a", "b", False), "FAILED"),
    ("InterpretEqualResult verdict True (bool)", lambda: R.InterpretEqualResult("x", "a", "a", True), "PASSED"),
    ("ExpectTestResult verdict False", lambda: R.ExpectTestResult("x", "a", "b", False), "FAILED"),
    ("ExpectTestResult verdict True", lambda: R.ExpectTestResult("x", "a", "b", True), "PASSED"),
    ("ExpectTestResult TestStatus.Failed", lambda: R.ExpectTestResult("x", "a", "a", TestStatus.Failed), "FAILED"),
    ("ExpectTestResult no verdict mismatch", lambda: R.ExpectTestResult("x", "a", "b"), "FAILED"),
    ("EvalManStepEqual verdict False", lambda: R.EvalManStepEqual("x", "a", "b", False), "FAILED"),
    ("ResultStep verdict True", lambda: R.ResultStep("x", "", "", True), "PASSED"),
    ("ResultStep verdict False", lambda: R.ResultStep("x", "a", "b", False), "FAILED"),
    ("ResultStep TestStatus.Failed", lambda: R.ResultStep("x", "a", "a", TestStatus.Failed), "FAILED"),
    ("ResultStep no verdict mismatch (exception record)", lambda: R.ResultStep("Exception", "", "boom"), "FAILED"),
    ("ResultStep None obt + TestStatus.Failed", lambda: R.ResultStep("x", None, None, TestStatus.Failed), "FAILED"),
    ("InterpretEqualResultRange in range", lambda: R.InterpretEqualResultRange("x", 5.0, 4.75, 5.25), "PASSED"),
    ("InterpretEqualResultRange out of range", lambda: R.InterpretEqualResultRange("x", 6.0, 4.75, 5.25), "FAILED"),
    ("InterpretEqualResultRange None (no measurement)", lambda: R.InterpretEqualResultRange("x", None, 0, 10), "FAILED"),
    ("InterpretEqualResultRange ARIA form ['1111','5']", lambda: R.InterpretEqualResultRange("x", ["1111", "5"], 4.75, 5.25), "FAILED"),
    ("InterpretEqualResultRange empty list", lambda: R.InterpretEqualResultRange("x", [], 0, 10), "FAILED"),
    ("InterpretEqualResultRange non-numeric", lambda: R.InterpretEqualResultRange("x", "abc", 0, 10), "FAILED"),
    ("LogAction(name, TestStatus.Failed)", lambda: R.LogAction("x", TestStatus.Failed), "FAILED"),
    ("CommentStep(content, TestStatus.Failed)", lambda: R.CommentStep("x", TestStatus.Failed), "FAILED"),
]
for description, call, expected in cases:
    observed = verdict_of(call)
    check(f"[report] {description} -> {expected}", observed == expected, observed)

# LogCustomAction must not leave the enclosing group (double close_group).
ApymReports.add_group("enclosing")
depth = group_depth()
R.LogCustomAction("x", "a", "a", True)
check("[report] LogCustomAction keeps the enclosing group open", group_depth() == depth, f"depth {depth} -> {group_depth()}")
ApymReports.close_group()

# Columns: expected goes to the expected column.
step, _ = last_step_after(lambda: R.LogCustomAction("cols", "EXPECTED", "OBTAINED", False))
check("[report] LogCustomAction column order (expected, obtained)",
      step is not None and step["expected"] == "EXPECTED" and step["obtained"] == "OBTAINED",
      None if step is None else (step["expected"], step["obtained"]))

# A TestStatus imported through the other package path must still count as Failed.
import shared_libraries.configuration_control as other_cc  # noqa: E402

foreign_failed = other_cc.TestStatus.Failed
check("[report] other-path TestStatus is a distinct class (precondition)", foreign_failed.__class__ is not TestStatus, foreign_failed.__class__)
for fn_name in ("InterpretEqualResult", "LogCustomAction", "ExpectTestResult"):
    fn = getattr(R, fn_name)
    observed = verdict_of(lambda fn=fn: fn("x", "a", "a", foreign_failed))
    check(f"[report] {fn_name} with TestStatus.Failed from the other import path -> FAILED", observed == "FAILED", observed)


# ── 2. CAN / diag wrappers against a fake apym Api ───────────────────────────
class Recorder:
    def __init__(self):
        self.calls: list[tuple] = []

    def count(self, name):
        return sum(1 for c in self.calls if c[0] == name)


REC = Recorder()
UDS_BEHAVIOUR = {"request": lambda data: bytearray(b"\x62\xF1\x90"), "security": lambda level: bytearray(b"\x67\x02")}


class FakeUds:
    @staticmethod
    def request(channel, data):
        REC.calls.append(("uds.request", channel, bytes(data)))
        return UDS_BEHAVIOUR["request"](data)

    @staticmethod
    def security_access(channel, level):
        REC.calls.append(("uds.security_access", channel, level))
        return UDS_BEHAVIOUR["security"](level)

    @staticmethod
    def change_can_request_id(channel, value):
        REC.calls.append(("uds.change_can_request_id", channel, value))

    @staticmethod
    def change_can_response_id(channel, value):
        REC.calls.append(("uds.change_can_response_id", channel, value))

    @staticmethod
    def change_response_pending_timeout(channel, value):
        REC.calls.append(("uds.change_response_pending_timeout", channel, value))


FRAMES = {"VCU1": bytearray(8)}


def _rec(name):
    def fn(*args):
        REC.calls.append((name, *args))
    return fn


class FakeFrame:
    @staticmethod
    def change_payload(sim, frame, payload):
        REC.calls.append(("frame.change_payload", frame, bytes(payload)))
        if frame not in FRAMES:
            raise Exception(f"Frame {frame} not found")
        FRAMES[frame] = bytearray(payload)

    @staticmethod
    def add_new_can_frame(sim, frame, frame_id, periodicity, payload, is_fd=False):
        REC.calls.append(("frame.add_new_can_frame", frame, frame_id, periodicity, bytes(payload), is_fd))
        FRAMES[frame] = bytearray(payload)

    change_can_frame_cycle_time = staticmethod(_rec("frame.change_can_frame_cycle_time"))
    enable = staticmethod(_rec("frame.enable"))
    disable = staticmethod(_rec("frame.disable"))
    reload = staticmethod(_rec("frame.reload"))
    remove_frame = staticmethod(_rec("frame.remove_frame"))


SIGNAL_VALUES = {}


class FakeSignal:
    @staticmethod
    def change_raw_value(sim, frame, pdu, signal, value):
        REC.calls.append(("signal.change_raw_value", frame, pdu, signal, value))
        SIGNAL_VALUES[(frame, signal)] = str(value)

    @staticmethod
    def read_raw_value(sim, frame, pdu, signal):
        REC.calls.append(("signal.read_raw_value", frame, pdu, signal))
        return SIGNAL_VALUES.get((frame, signal), "0")

    @staticmethod
    def play_physical_values_curve(sim, frame, pdu, signal, values, repeat_forever=False):
        REC.calls.append(("signal.play_physical_values_curve", frame, pdu, signal, list(values), repeat_forever))

    enable = staticmethod(_rec("signal.enable"))
    disable = staticmethod(_rec("signal.disable"))


CALLBACKS = {}


class FakeEvents:
    @staticmethod
    def attach_callback_on_signal_changed(callback, sim, frame, pdu, signal):
        port = 5000 + len(CALLBACKS)
        CALLBACKS[port] = callback
        REC.calls.append(("events.attach", frame, signal, port))
        return port

    @staticmethod
    def detach_callback(port):
        REC.calls.append(("events.detach", port))
        CALLBACKS.pop(port, None)


LOAD_PROFILE_ERRORS = []
CURVES_SENT = []
MISSING_LOOPS: set[str] = set()


class FakeApi:
    class Configuration:
        get_simulations = staticmethod(lambda: ["CANFD", "HSCAN"])
        get_communication_channels = staticmethod(lambda: ["CANFD", "HSCAN"])
        get_uds_channels = staticmethod(lambda: ["CANFD", "Level 61"])
        get_simulation_id = staticmethod(lambda name: f"sim-{name}")
        get_uds_channel_id = staticmethod(lambda name: f"uds-{name}")
        get_channel_id = staticmethod(lambda name: f"ch-{name}")
        get_can_uds_channel_request_id = staticmethod(lambda ch: 0x730)
        get_can_uds_channel_response_id = staticmethod(lambda ch: 0x738)

    class Diagnostics:
        Uds = FakeUds

    class Simulation:
        Frame = FakeFrame
        Signal = FakeSignal
        start_simulation = staticmethod(_rec("sim.start"))
        stop_simulation = staticmethod(_rec("sim.stop"))

    class Communication:
        send_can_frame = staticmethod(_rec("comm.send_can_frame"))
        send_can_fd_frame = staticmethod(_rec("comm.send_can_fd_frame"))

        class Log:
            stop_log = staticmethod(_rec("log.stop_log"))
            start_log_to_file = staticmethod(lambda path, options: (REC.calls.append(("log.start_log_to_file", path)), uuid.uuid4())[1])
            start_log_to_memory = staticmethod(lambda size, options: uuid.uuid4())
            remove_log = staticmethod(_rec("log.remove_log"))

    class Chassis:
        @staticmethod
        def load_profile(path):
            REC.calls.append(("chassis.load_profile", path))
            return list(LOAD_PROFILE_ERRORS)

        set_relay = staticmethod(_rec("chassis.set_relay"))
        reset_card = staticmethod(_rec("chassis.reset_card"))
        set_trigger = staticmethod(_rec("chassis.set_trigger"))

        class Spi:
            @staticmethod
            def send_crash_curves(function_name, curves):
                CURVES_SENT.append([(c.filePath, c.inverted) for c in curves])
                REC.calls.append(("spi.send_crash_curves", function_name, len(curves)))

            remove_all_crash_curves = staticmethod(_rec("spi.remove_all_crash_curves"))

        class Power:
            set = staticmethod(_rec("power.set"))
            clear = staticmethod(_rec("power.clear"))

            class V2:
                class Voltage:
                    set = staticmethod(_rec("power.v2.voltage.set"))

        class ResistorDecade:
            read_resistance = staticmethod(lambda name: 2.7)

        class Squib:
            @staticmethod
            def get_deploy_parameters(function_name):
                REC.calls.append(("squib.get_deploy_parameters", function_name))
                if function_name in MISSING_LOOPS:
                    raise Exception(f"Squib function {function_name} not found")
                number = int(function_name.removeprefix("LOOP"))
                return (10.0 + number, 2.0, 1.75)   # (timeToFire, fireDuration, fireAmplitude)

            clear_deploy = staticmethod(_rec("squib.clear_deploy"))

        class Rsu:
            @staticmethod
            def load_curve_from_file(function_name, file_path, invert=False):
                REC.calls.append(("rsu.load_curve_from_file", function_name, file_path, invert))

    Events = FakeEvents


class FakeCanUdsChannel:
    """apym.objects.CanUdsChannel: its request/security_access are Api.Diagnostics.Uds calls on its id."""

    def __init__(self, name):
        self.name = name
        self.id = FakeApi.Configuration.get_uds_channel_id(name)

    def request(self, data):
        return FakeUds.request(self.id, data)

    def security_access(self, level):
        return FakeUds.security_access(self.id, level)

    def change_response_pending_timeout(self, value):
        FakeUds.change_response_pending_timeout(self.id, value)


_real_get_type = jt.get_type


def fake_get_type(name, strict=True):
    if name == "CanUdsChannel":
        return FakeCanUdsChannel
    if name == "CurveData":
        return jt.CurveData
    return _real_get_type(name, strict=strict)


jt.get_type = fake_get_type


def install_fake_runtime():
    jt.Api = FakeApi
    jt.CanChannel = None  # no bus capture
    jt.CurveData = type("CurveData", (), {})
    jt.vehcSimulationChannels = ["CANFD", "HSCAN"]
    jt.diagChannels = ["CANFD", "Level 61"]
    jt.diag_ch = FakeCanUdsChannel("CANFD")   # built by ensure_runtime on the bench
    jt.diag_ch_id = "uds-CANFD"
    jt.diag_ch_id_1 = "uds-Level 61"
    jt.simulation_id = "sim-CANFD"
    jt._runtime_initialized = True


install_fake_runtime()
C = jt.CAN

# 2a. a request answered with an empty response (e.g. suppressPosRspMsgIndicationBit) is sent once
REC.calls.clear()
UDS_BEHAVIOUR["request"] = lambda data: bytearray()
C.SendDiagByValues("0x11 0x81")
check("[uds] SendDiagByValues('11 81') with no response sends the request exactly once",
      REC.count("uds.request") == 1, f"{REC.count('uds.request')} request(s) on the bus")

# 2b. a request that times out is sent once and the error is returned
REC.calls.clear()


def _timeout(data):
    raise TimeoutError("UDS response timeout")


UDS_BEHAVIOUR["request"] = _timeout
result = C.SendDiagByValues("0x14 0xFF 0xFF 0xFF")
check("[uds] SendDiagByValues timeout sends once", REC.count("uds.request") == 1, f"{REC.count('uds.request')} request(s)")
check("[uds] SendDiagByValues timeout returns the error", isinstance(result, Exception), repr(result))

# 2c. normal positive response formatting
REC.calls.clear()
UDS_BEHAVIOUR["request"] = lambda data: bytearray(b"\x62\xF1\x90\x41")
result = C.SendDiagByValues("22F190")
check("[uds] SendDiagByValues formats '0x62 0xF1 0x90 0x41'", result == "0x62 0xF1 0x90 0x41", result)

# 2d. security access performs one seed/key exchange even when the first answer is negative/empty
REC.calls.clear()
UDS_BEHAVIOUR["security"] = lambda level: bytearray()
C.SecurityAccess(1)
check("[uds] SecurityAccess with an empty answer performs one seed/key exchange",
      REC.count("uds.security_access") == 1, f"{REC.count('uds.security_access')} exchange(s)")
REC.calls.clear()


def _sa_timeout(level):
    raise TimeoutError("timeout")


UDS_BEHAVIOUR["security"] = _sa_timeout
C.SecurityAccess(1)
check("[uds] SecurityAccess timeout performs one seed/key exchange",
      REC.count("uds.security_access") == 1, f"{REC.count('uds.security_access')} exchange(s)")
UDS_BEHAVIOUR["security"] = lambda level: bytearray(b"\x67\x02")
check("[uds] SecurityAccess positive returns '6702'", C.SecurityAccess(1) == "6702", C.SecurityAccess(1))

# 2e. request payload parsing
for text, expected in (("22 F1 90", [0x22, 0xF1, 0x90]), ("0x22 0xF1 0x90", [0x22, 0xF1, 0x90]),
                       ("22F190", [0x22, 0xF1, 0x90]), ("1 22", [0x01, 0x22]), ("0x3E 0x0", [0x3E, 0x00]),
                       ("3E 0", [0x3E, 0x00]), ("19 2 9", [0x19, 0x02, 0x09])):
    try:
        parsed = list(jt._prepare_diag_payload(text))
    except Exception as exc:
        parsed = repr(exc)
    check(f"[uds] request text {text!r} -> {expected}", parsed == expected, parsed)
try:
    parsed = list(jt._prepare_diag_payload("22F19"))
except Exception as exc:
    parsed = f"rejected: {exc}"
check("[uds] odd-length request text '22F19' is rejected, not sent with a guessed byte",
      isinstance(parsed, str) and parsed.startswith("rejected"), parsed)

# 2f. CheckSingleDTC: DTC given as hex text without 0x
UDS_BEHAVIOUR["request"] = lambda data: bytearray(b"\x59\x02\xFF\x80\x50\x13\x0B")
for code in ("805013", "0x805013", 0x805013, "80 50 13"):
    out = C.CheckSingleDTC(None, code)
    check(f"[dtc] CheckSingleDTC({code!r}) finds DTC 805013", isinstance(out, list) and out[0] == "0000", out)

# 2g. StopLogging stops the log id that StartLoggingToFile returned
REC.calls.clear()
handle = C.StartLoggingToFile("TC", os.path.join(REPORT_DIR, "x.log"), None)
C.StopLogging(handle)
check("[log] StopLogging(handle from StartLoggingToFile) calls stop_log", REC.count("log.stop_log") == 1,
      f"stop_log calls: {REC.count('log.stop_log')}; handle type {type(handle).__name__}")
REC.calls.clear()
mem = C.StartLoggingToMemory("CANFD")
out = C.StopLoggingToFile(mem)
check("[log] StopLoggingToFile(StartLoggingToMemory result) stops that log id",
      REC.count("log.stop_log") == 1 and REC.calls[-1][1] == mem[1] if REC.count("log.stop_log") else False,
      f"{REC.calls[-1:]}; returned {out}")

# 2h. SetPeriodicFrame: existing frame -> payload change, return None; new frame -> added
REC.calls.clear()
out = C.SetPeriodicFrame("CANFD", "VCU1", 0x100, 20, [1, 2, 3, 4, 5, 6, 7, 8])
check("[sim] SetPeriodicFrame on an existing frame changes the payload and returns None (callers' success value)",
      out is None and REC.count("frame.change_payload") == 1 and REC.count("frame.add_new_can_frame") == 0, (out, REC.calls))
REC.calls.clear()
out = C.SetPeriodicFrame("CANFD", "NEW_FRAME", 0x123, 50, [0, 0])
check("[sim] SetPeriodicFrame on a new frame adds it and returns None", out is None and REC.count("frame.add_new_can_frame") == 1, (out, REC.calls))
def _refuse_frame(*_args, **_kwargs):
    raise Exception("ARIA refused the frame")


saved_add = FakeFrame.__dict__["add_new_can_frame"]
setattr(FakeFrame, "add_new_can_frame", staticmethod(_refuse_frame))
try:
    out = C.SetPeriodicFrame("CANFD", "OTHER_FRAME", 0x124, 50, [0, 0])
except Exception as exc:
    out = f"raised {exc!r}"
setattr(FakeFrame, "add_new_can_frame", saved_add)
check("[sim] SetPeriodicFrame returns (does not raise) a refused add, as its callers expect",
      isinstance(out, str) and not out.startswith("raised"), out)

# 2i. PlayPhysicalValuesCurve sends values as the documented list[str]
REC.calls.clear()
C.PlayPhysicalValuesCurve("CANFD", "VCU1", "VCU1Pdu", "SIG", [0, 1.5, 3])
sent = [c for c in REC.calls if c[0] == "signal.play_physical_values_curve"]
check("[sim] PlayPhysicalValuesCurve sends list[str]", bool(sent) and all(isinstance(v, str) for v in sent[0][4]), sent)
# channel-less legacy form, as simulate_vin_can_signals uses it: no cycle time given
REC.calls.clear()
C.PlayPhysicalValuesCurve("VCU1", "VCU1Pdu", "SIG", ["5"], True)  # pyright: ignore[reportArgumentType]
cycle_changes = [c for c in REC.calls if c[0] == "frame.change_can_frame_cycle_time"]
played = [c for c in REC.calls if c[0] == "signal.play_physical_values_curve"]
check("[sim] PlayPhysicalValuesCurve(frame, pdu, signal, values, True) leaves the cycle time alone",
      not cycle_changes and bool(played) and played[0][5] is True, REC.calls)

# 2j. ReadAllDTCNamesWithStatus without internal errors
jt.IsVeoneerInternalErrorcode_to_be_Read = "YES"
internal_list = os.path.join(REPORT_DIR, "internal_errors.txt")
with open(internal_list, "w") as fh:
    fh.write("0x01 0x02,ERR_ONE\n")
jt.internalErrorsListFile = internal_list
UDS_BEHAVIOUR["request"] = lambda data: bytearray(b"\x62\xFD\x39" + b"\x00" * 6)
out = C.ReadAllDTCNamesWithStatus()
check("[dtc] ReadAllDTCNamesWithStatus with no internal error reports 'No error found.'", out == "No error found.", repr(out))
UDS_BEHAVIOUR["request"] = lambda data: bytearray(b"\x62\xFD\x39\x0A\x0B\x0C")
try:
    out = C.ReadAllDTCNamesWithStatus()
except Exception as exc:
    out = f"raised {exc!r}"
check("[dtc] ReadAllDTCNamesWithStatus with an unlisted code does not raise", not str(out).startswith("raised"), out)

# 2k. ARIA.LoadProfile surfaces profile errors so LoadProfileJson's check can fail
LOAD_PROFILE_ERRORS[:] = ["Card SPI1 not found"]
out = jt.ARIA.LoadProfile(os.path.join(REPORT_DIR, "profile.json"))
verdict = verdict_of(lambda: jt.RESULT.InterpretEqualResult("ARIA Profile Loading Status", out))
check("[aria] LoadProfile errors make 'ARIA Profile Loading Status' FAILED", verdict == "FAILED", f"returned {out!r}, step {verdict}")
LOAD_PROFILE_ERRORS[:] = []
out = jt.ARIA.LoadProfile(os.path.join(REPORT_DIR, "profile.json"))
verdict = verdict_of(lambda: jt.RESULT.InterpretEqualResult("ARIA Profile Loading Status", out))
check("[aria] LoadProfile without errors keeps the check PASSED", verdict == "PASSED", f"returned {out!r}, step {verdict}")

# 2l. SPI.SendCrashData: inversion flags sent as bool and paired with their own curve
CURVES_SENT.clear()
jt.SPI.SendCrashData("GEN6_XY", "C:\\a.txt", 1, "C:\\b.txt", 0, "C:\\c.txt", True)
check("[spi] SendCrashData sends bool inversions for every curve",
      bool(CURVES_SENT) and [(p, type(i), i) for p, i in CURVES_SENT[0]]
      == [("C:\\a.txt", bool, True), ("C:\\b.txt", bool, False), ("C:\\c.txt", bool, True)], CURVES_SENT)
CURVES_SENT.clear()
jt.SPI.SendCrashData("GEN6_XY", "C:\\a.txt", None, "C:\\b.txt", True)
check("[spi] SendCrashData keeps curve/inversion pairs aligned",
      bool(CURVES_SENT) and CURVES_SENT[0] == [("C:\\a.txt", False), ("C:\\b.txt", True)], CURVES_SENT)
spi_answer = jt.SPI.SendCrashData("GEN6_XY", "C:\\a.txt", False)
check("[spi] SendCrashData answers ['0000', ''] once ARIA took the curves", spi_answer == ["0000", ""], spi_answer)
spi_answer = jt.SPI.SendCrashData("GEN6_XY", "C:\\a.txt", "maybe")
verdict = verdict_of(lambda: jt.RESULT.InterpretEqualResult("curves loaded", spi_answer[0], "0000"))
check("[spi] SendCrashData with a bad inversion flag answers an error code a caller can grade",
      spi_answer[0] != "0000" and verdict == "FAILED", (spi_answer, verdict))
REC.calls.clear()
spi_answer = jt.SPI.RemoveAllCrashCurves()
check("[spi] RemoveAllCrashCurves calls apym remove_all_crash_curves and answers '0000'",
      spi_answer[0] == "0000" and REC.count("spi.remove_all_crash_curves") == 1, (spi_answer, REC.calls))

# 2m. on-change event uses the value ARIA delivers to the callback
REC.calls.clear()
SIGNAL_VALUES.clear()
SIGNAL_VALUES[("SUP", "S")] = "0"   # stale value: ARIA has not been re-read
out = C.CreateOnChangeSignalEventChangeSignalAction("CANFD", "SUP", "S", 5, "ACT", "A", 7)
port = out[1]
CALLBACKS[port]("5", "5.0")   # ARIA delivers raw '5'
check("[sim] on-change action fires on the raw value ARIA delivers",
      SIGNAL_VALUES.get(("ACT", "A")) == "7", SIGNAL_VALUES)
C.ClearOnEventList()

# 2n. Sleep honours fractional seconds
started = time.monotonic()
jt.Sleep(0.3)
elapsed = time.monotonic() - started
check("[util] Sleep(0.3) sleeps about 0.3 s", 0.25 <= elapsed <= 0.6, f"{elapsed:.3f} s")
started = time.monotonic()
jt.Wait(150.5)
elapsed = time.monotonic() - started
check("[util] Wait(150.5) waits about 150 ms", 0.13 <= elapsed <= 0.4, f"{elapsed * 1000:.1f} ms")

# 2o. leakage wrappers bring the runtime up themselves and return '1111' on failure
jt._runtime_initialized = False
jt.Api = None
saved_ensure = jt.ensure_runtime
jt.ensure_runtime = lambda force=False: (install_fake_runtime(), True)[1]
try:
    out = jt.PS.SetLeakageVBATBusHigh()
except Exception as exc:
    out = repr(exc)
check("[ps] SetLeakageVBATBusHigh initialises the runtime itself (no AttributeError on Api=None)",
      out in ("0000", "1111"), out)
jt.ensure_runtime = saved_ensure
install_fake_runtime()

# 2p. RD.ReadResistance keeps the fractional ohms
out = jt.RD.ReadResistance("RD1")
check("[rd] RD.ReadResistance keeps 2.7 ohm (no int truncation)", out == 2.7, out)


# ── 3. faultTimeMeasurement with a simulated ECU ─────────────────────────────
class SimEcu:
    def __init__(self):
        self.t0: float = 0.0
        self.schedule = []   # (time_s, set of records)
        self.reads = 0

    def respond(self, *args):
        self.reads += 1
        now = time.monotonic() - self.t0
        records = set()
        for when, recs in self.schedule:
            if now >= when:
                records = recs
        time.sleep(0.004)    # ECU + transport
        body = b"".join(sorted(records))
        return " ".join(f"0x{b:02X}" for b in b"\x59\x02\x09" + body)


ECU = SimEcu()
CONFIG = {"CAN_FAULT_POLL_INTERVAL_MS": 10.0}
real_lookup = cf._get_optional_project_config_symbol


def fake_lookup(name, modules, default=None, **kw):
    return CONFIG.get(name, default)


cf._get_optional_project_config_symbol = fake_lookup
cf.CAN = SimpleNamespace(SendDiagByValuesNoLog=ECU.respond)

DTC_A = b"\x80\x50\x13\x0B"
DTC_B = b"\x92\x01\x00\x0B"

ECU.t0 = time.monotonic()
ECU.schedule = [(0.300, {DTC_A})]
ms = cf.faultTimeMeasurement("0x80 0x50 0x13 0x0B")
check("[ftm] DTC set at 300 ms is measured 300..330 ms", ms is not None and 300 <= ms <= 330, ms)

ECU.t0 = time.monotonic()
ECU.schedule = [(0.100, {DTC_A}), (0.250, {DTC_A, DTC_B})]
ms = cf.faultTimeMeasurement("0x80 0x50 0x13 0x0B;0x92 0x01 0x00 0x0B")
check("[ftm] two DTCs: time of the later one (250..280 ms)", ms is not None and 250 <= ms <= 280, ms)

ECU.t0 = time.monotonic()
ECU.schedule = [(0.0, {DTC_A})]
ms = cf.faultTimeMeasurement("0x80 0x50 0x13 0x0A")
CONFIG["FAULT_TIME_MEASUREMENT_TIMEOUT_MS"] = 400
ECU.t0 = time.monotonic()
started = time.monotonic()
ms = None
try:
    ms = cf.faultTimeMeasurement("0x80 0x50 0x13 0x0A")
    outcome = ms
except Exception as exc:
    outcome = repr(exc)
elapsed = time.monotonic() - started
check("[ftm] honours canc_config FAULT_TIME_MEASUREMENT_TIMEOUT_MS (400 ms -> None after ~0.4 s)",
      ms is None and elapsed < 2.0, f"{outcome}, gave up after {elapsed:.2f} s")

ECU.t0 = time.monotonic()
ECU.schedule = []
try:
    outcome = cf.faultTimeMeasurement("0x59 0x02")
except Exception as exc:
    outcome = repr(exc)
check("[ftm] CANC_DTC_Read_Timing target '0x59 0x02' returns the time of one read",
      isinstance(outcome, float) and 0 < outcome < 50, outcome)
CONFIG.pop("FAULT_TIME_MEASUREMENT_TIMEOUT_MS")

# fault_time_check verdicts
for measured, verdict in ((None, "FAILED"), (95.0, "PASSED"), (120.0, "PASSED"), (80.0, "PASSED"),
                          (120.5, "FAILED"), (79.0, "FAILED")):
    observed = verdict_of(lambda measured=measured: cf.fault_time_check(measured, 100, 20))
    check(f"[ftm] fault_time_check({measured}, 100 +/- 20) -> {verdict}", observed == verdict, observed)

cf._get_optional_project_config_symbol = real_lookup

# ── 4. core_functions helpers built on the wrappers ──────────────────────────
import ast  # noqa: E402

install_fake_runtime()

# 4a. READ_TTFANDFDResult: ARIA.GetTTFAndFDResults over the project's ACTIVE_SQUIB_LOOPS
expected_loops = sorted(real_lookup("ACTIVE_SQUIB_LOOPS", ("squibs_config",), None) or [])
REC.calls.clear()
step_count = len(STEPS)
out = cf.READ_TTFANDFDResult()
read = [c[1] for c in REC.calls if c[0] == "squib.get_deploy_parameters"]
check("[cf] READ_TTFANDFDResult reads ACTIVE_SQUIB_LOOPS (LOOP<n>) through apym get_deploy_parameters",
      bool(read) and read == [f"LOOP{n}" for n in expected_loops], read)
check("[cf] READ_TTFANDFDResult returns ARIA's ['0000', TTF[], FD[], CURRENT[]]",
      isinstance(out, list) and len(out) == 4 and out[0] == "0000" and out[1] == [10.0 + n for n in expected_loops],
      out)
failed_steps = [s for s in STEPS[step_count:] if s["html"] == "FAILED"]
check("[cf] READ_TTFANDFDResult on a working bench writes no FAILED step", not failed_steps, failed_steps)
MISSING_LOOPS.add(f"LOOP{expected_loops[-1]}" if expected_loops else "LOOP15")
step_count = len(STEPS)
out = cf.READ_TTFANDFDResult()
MISSING_LOOPS.clear()
failed_steps = [s for s in STEPS[step_count:] if s["html"] == "FAILED"]
check("[cf] READ_TTFANDFDResult with an unreadable loop returns '0001' and exactly one FAILED step",
      isinstance(out, list) and out[0] == "0001" and len(failed_steps) == 1, (out, [s["obtained"] for s in failed_steps]))

# 4b. RemoveRsuFaultCondition INTERNAL: RSU_0LSB.txt created when missing, then sent
rsu_dir = os.path.join(REPORT_DIR, "rsu_zero_curve")   # folder does not exist yet
zero_path = os.path.join(rsu_dir, "RSU_0LSB.txt")
REC.calls.clear()
depth = group_depth()
cf.RemoveRsuFaultCondition("INTERNAL", "RSU_CH3", rsu_dir + os.sep)
sent = [c for c in REC.calls if c[0] == "rsu.load_curve_from_file"]
lines = open(zero_path, encoding="ascii").read().split() if os.path.isfile(zero_path) else None
check("[cf] RemoveRsuFaultCondition INTERNAL creates a missing RSU_0LSB.txt: 600 samples of 0 LSB",
      lines == ["0"] * 600, None if lines is None else (len(lines), sorted(set(lines))))
check("[cf] RemoveRsuFaultCondition INTERNAL sends the zero curve to RSU_CH3, not inverted",
      sent == [("rsu.load_curve_from_file", "RSU_CH3", os.path.abspath(zero_path), False)], sent)
check("[cf] RemoveRsuFaultCondition INTERNAL keeps the report groups balanced", group_depth() == depth,
      f"depth {depth} -> {group_depth()}")
os.makedirs(rsu_dir, exist_ok=True)
with open(zero_path, "w", encoding="ascii") as handle:
    handle.write("0\n0\n0\n")   # an existing file is used as it is
REC.calls.clear()
cf.RemoveRsuFaultCondition("INTERNAL", "3", rsu_dir)   # numeric id, folder without a trailing separator
sent = [c for c in REC.calls if c[0] == "rsu.load_curve_from_file"]
check("[cf] RemoveRsuFaultCondition INTERNAL keeps an existing RSU_0LSB.txt and accepts id '3'",
      open(zero_path, encoding="ascii").read() == "0\n0\n0\n"
      and sent == [("rsu.load_curve_from_file", "RSU_CH3", os.path.abspath(zero_path), False)], sent)
REC.calls.clear()
step_count = len(STEPS)
cf.RemoveRsuFaultCondition("INTERNAL", "RSU_CH3", os.path.join(zero_path, "sub"))   # parent is a file
sent = [c for c in REC.calls if c[0] == "rsu.load_curve_from_file"]
failed_steps = [s for s in STEPS[step_count:] if s["html"] == "FAILED"]
check("[cf] RemoveRsuFaultCondition INTERNAL: a curve that cannot be created is a FAILED step and is not sent",
      not sent and len(failed_steps) == 1, (sent, [s["obtained"] for s in failed_steps]))

# 4b2. LoadSpiCurves: every SPI curve removed, the RSU channels zeroed, then the curves sent
curve_dir = os.path.join(REPORT_DIR, "spi_curves")
os.makedirs(curve_dir, exist_ok=True)
curve_paths = []
for curve_name in ("a.txt", "b.txt", "zero.txt"):
    curve_paths.append(os.path.join(curve_dir, curve_name))
    with open(curve_paths[-1], "w", encoding="ascii") as handle:
        handle.write("0\n0\n")
REC.calls.clear()
CURVES_SENT.clear()
loaded = cf.LoadSpiCurves("Panasonic", [(curve_paths[0], False), (curve_paths[1], True)],
                          ["RSU_CH1", "RSU_CH2"], curve_paths[2])
order = [c[0] for c in REC.calls
         if c[0] in ("spi.remove_all_crash_curves", "rsu.load_curve_from_file", "spi.send_crash_curves")]
check("[cf] LoadSpiCurves removes every SPI curve, zeroes the RSU channels, then sends the curves",
      loaded is True and order == ["spi.remove_all_crash_curves", "rsu.load_curve_from_file",
                                   "rsu.load_curve_from_file", "spi.send_crash_curves"]
      and CURVES_SENT == [[(curve_paths[0], False), (curve_paths[1], True)]], (loaded, order, CURVES_SENT))
REC.calls.clear()
CURVES_SENT.clear()
step_count = len(STEPS)
loaded = cf.LoadSpiCurves("Panasonic", [(os.path.join(curve_dir, "missing.txt"), False)], ["RSU_CH1"], curve_paths[2])
failed_steps = [s for s in STEPS[step_count:] if s["html"] == "FAILED"]
check("[cf] LoadSpiCurves with a missing curve file is a FAILED step and loads nothing",
      loaded is False and not REC.calls and not CURVES_SENT and len(failed_steps) == 1,
      (loaded, REC.calls, [s["name"] for s in failed_steps]))

# 4c. no Sleep (seconds) is given a millisecond value in the shared libraries
shared_dir = os.path.join(FRAMEWORK_PARENT, "Framework_IOEM_Py", "shared_libraries")
ms_sleeps = []
for file_name in sorted(os.listdir(shared_dir)):
    if not file_name.endswith(".py"):
        continue
    with open(os.path.join(shared_dir, file_name), encoding="utf-8") as handle:
        tree = ast.parse(handle.read())
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", getattr(node.func, "attr", None)) == "Sleep" and node.args:
            arg = node.args[0]
            text = ast.unparse(arg)
            if (isinstance(arg, ast.Constant) and isinstance(arg.value, (int, float)) and arg.value >= 20) \
                    or "PROVEOUT_COMPLETION_TIME" in text or "_MS" in text.upper():
                ms_sleeps.append(f"{file_name}:{node.lineno} Sleep({text})")
check("[util] no Sleep() in shared_libraries is given a millisecond value", not ms_sleeps, ms_sleeps)

# ── summary ──────────────────────────────────────────────────────────────────
ApymReports.write_to_file()
failed = [r for r in RESULTS if not r[0]]
for ok, name, observed in RESULTS:
    print(f"{'PASS' if ok else 'FAIL'}  {name}  ::  {observed}")
print(f"\n{len(RESULTS) - len(failed)}/{len(RESULTS)} checks pass, {len(failed)} fail")
print(f"report and scratch files: {REPORT_DIR}")
sys.exit(1 if failed else 0)
