"""Check that every project's edr_config describes the one common EDR record.

The ICE and EV event records are a common EDR: the ICE specification
(ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx) and the EV one (M312_M112_M210_SRS_V2.7_DIAG_RE.xlsx)
share all but two elements. So every project's edr_config lists every element of both,
and a project runs scripts only for the elements that apply to it. This checks, project
by project:

  1. every element of either specification is decoded by an entry (matched on the
     entry's 'spec_name', which is a list where one entry decodes several);
  2. every entry carries 'spec_name' and 'variants', and 'variants' names exactly the
     vehicle classes whose specification defines the element;
  3. an entry for a single element has that element's layout and scaling as its own
     class's specification gives them (the other class's, for an element only the
     other class defines). Entries that split or group elements (U171's Event Date
     day / month / year, CrashLocation, ...) are listed, not compared;
  4. the module exposes the names every edr_config shares.

M210 is compared with M312_M112_M210_SRS_V3.4_DIAG_RE.xlsx instead of the EV class's V2.7:
its ECU implements V3.4 (source review 2026-10-28).

Offline only: reads the specifications and imports the configs. Exit code 1 when
anything is missing or differs.

Usage:
    py -3.14 tools/check_edr_config_common.py                # U171, Z121, M310_M314_M110, M210
    py -3.14 tools/check_edr_config_common.py --project U171
"""

from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import build_edr_config_from_diag as builder  # noqa: E402

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
# M210: the EV project on the M210 DBC (user 2026-10-22: separate configs per DBC).
PROJECTS = {"U171": "ICE", "Z121": "ICE", "M310_M314_M110": "EV", "M210": "EV"}
# The specification each vehicle class is built from (keys of builder.PROJECTS).
SPEC_PROJECT = {"ICE": "U171", "EV": "M310_M314_M110"}
# A project compared with its own specification rather than its class's. The builder has
# no M210 entry, so M210's V3.4 sheet is added to its table here, in memory only.
PROJECT_SPEC = {"M210": "M210"}
builder.PROJECTS.setdefault("M210", {
    **builder.PROJECTS["M310_M314_M110"],
    "workbook": REPOSITORY_ROOT / "docs" / "project_documents" / "EDR_Spec Common" / "EV"
                / "M312_M112_M210_SRS_V3.4_DIAG_RE.xlsx",
    "source_label": "M312_M112_M210_SRS_V3.4_DIAG_RE.xlsx",
})
# Elements a specification names differently from the configs' common spec_name.
SPEC_RENAMES = {"M210": {"Completion Status": "CompletionStatus"}}  # V2.7 "CompletionStatus"

COMMON_NAMES = (
    "PROJECT_NAME", "MODULE_NAME", "VEHICLE_CLASS", "RESPONSE_HEADER_BYTES", "EDR_DIDS",
    "EDR_RECORD_DIDS", "HOUSEKEEPING_CRASH_TRIGGER_MAX_DELAY_MS", "DECONFIGURED_BYTE_VALUE",
    "RESERVED_BYTE_VALUE", "CRASH_LOCATION_BITS", "EDR_DECODER_CONFIG", "EDR_PARAMETERS",
    "EDR_PARAMETERS_BY_NAME", "RESERVED_ALLOCATIONS", "INTERVAL_PARAMETERS",
    "SNAPSHOT_PARAMETERS", "get_sample_range", "get_sample_interval_ms",
    "SQUIB_DEPLOYMENT_LABELS",
)
COMPARED = ("type", "data_start_byte", "data_end_byte", "data_byte_length", "data_bit_length",
            "data_samples_number", "data_first_bit_offset", "signed", "scaling_factor",
            "offset", "sample_range", "range")


def spec_elements() -> dict[str, dict[str, dict[str, Any]]]:
    """Vehicle class (or PROJECT_SPEC key) -> element name -> the entry its specification builds."""
    out = {}
    for key, project in {**SPEC_PROJECT, **PROJECT_SPEC}.items():
        entries, _other, _elements, _skipped = builder.project_entries(project)
        renames = SPEC_RENAMES.get(project, {})
        # Entries that group several elements (Squib_Deployment_Status) are not elements.
        out[key] = {renames.get(entry["spec_name"], entry["spec_name"]): entry for entry in entries
                    if isinstance(entry["spec_name"], str)}
    return out


def load(project: str) -> Any:
    path = REPOSITORY_ROOT / "projects" / project / "config" / "edr_config.py"
    spec = importlib.util.spec_from_file_location(f"_common_check_{project}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check(project: str, specs: dict[str, dict[str, dict[str, Any]]]) -> int:
    variant = PROJECTS[project]
    other_variant = "EV" if variant == "ICE" else "ICE"
    classes = {variant: specs[PROJECT_SPEC.get(project, variant)], other_variant: specs[other_variant]}
    module = load(project)
    entries = module.EDR_PARAMETERS
    every = {**classes["ICE"], **classes["EV"]}
    problems: list[str] = []
    grouped: list[str] = []

    decoded: set[str] = set()
    for entry in entries:
        if "spec_name" not in entry or "variants" not in entry:
            problems.append(f"{entry['name']}: no spec_name / variants")
            continue
        names = entry["spec_name"] if isinstance(entry["spec_name"], list) else [entry["spec_name"]]
        unknown = [name for name in names if name not in every]
        if unknown:
            problems.append(f"{entry['name']}: spec_name {unknown} is in neither specification")
            continue
        decoded.update(names)
        defined = [v for v in ("ICE", "EV") if any(name in classes[v] for name in names)]
        if entry["variants"] != defined:
            problems.append(f"{entry['name']}: variants {entry['variants']}, the specifications "
                            f"define it for {defined}")
        if len(names) > 1 or entry.get("type") == "custom_bits":
            grouped.append(f"{entry['name']} -> {len(names)} element(s): {', '.join(names)[:90]}")
            continue
        source = classes[variant] if names[0] in classes[variant] else classes[other_variant]
        reference = source[names[0]]
        if reference["data_byte_length"] != entry.get("data_byte_length") and \
                entry.get("data_start_byte") != reference["data_start_byte"]:
            grouped.append(f"{entry['name']} -> part of {names[0]}")
            continue
        for field in COMPARED:
            if entry.get(field) != reference.get(field):
                problems.append(f"{entry['name']}: {field} {entry.get(field)!r}, specification "
                                f"{reference.get(field)!r}")

    missing = sorted(set(every) - decoded)
    absent_names = [name for name in COMMON_NAMES if not hasattr(module, name)]
    print(f"== {project} ({variant}): {len(entries)} entries decode {len(decoded)} of "
          f"{len(every)} elements of the common record")
    for name in missing:
        problems.append(f"element not in this config: {name}")
    for name in absent_names:
        problems.append(f"module has no {name}")
    if grouped:
        print(f"   {len(grouped)} entries split or group elements (not compared):")
        for line in grouped:
            print(f"     {line}")
    for line in problems:
        print(f"   PROBLEM {line}")
    print(f"   {len(problems)} problem(s)")
    return len(problems)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", choices=sorted(PROJECTS))
    arguments = parser.parse_args()
    sys.path.insert(0, str(REPOSITORY_ROOT.parent))
    specs = spec_elements()
    projects = [arguments.project] if arguments.project else list(PROJECTS)
    total = sum(check(project, specs) for project in projects)
    # The squib deployment labels sit on the same bits in every common-record project
    # (Z121's labels, user 2026-10-20), so every config must hold the same table.
    tables = {project: getattr(load(project), "SQUIB_DEPLOYMENT_LABELS", None) for project in projects}
    reference = tables.get("Z121") or next(iter(tables.values()))
    differing = [project for project, table in tables.items() if table != reference]
    print(f"== SQUIB_DEPLOYMENT_LABELS: {len(reference or [])} labels, "
          + (f"different in {differing}" if differing else "the same in every project"))
    total += len(differing)
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
