"""Write the SPI curve files of the M310_M314_M110 IMU and GEN6 simulation.

Author: Kris

The ARIA SPI-FPGA functions Panasonic (the ECU's IMU) and GEN6_XY (the central high-g sensor)
answer the ECU's SPI reads from .txt curves, one file per ARIA axis, one line per sample
(modules/CANC/IMU_SPI_SIMULATION.md):
    <signed integer>                     the axis data of the sample (the card frames it)
    <value>#SPI_<function>:<HEX32>       a raw SPI answer the card sends in that sample
This tool writes every curve the scripts load into crash_data/m310_m314_m110/spi_curves:
    RSU_zero.txt                         600 samples of 0 for every RSU channel before a trigger
    <function>_rest_<samples>.txt        0 on every sample (the axes a case leaves at rest)
    Panasonic_step_axis<n>_<counts>.txt  the CAN-C stimulus counts, then rest (13C 1-12)
    <function>_<fault>_axis<n>.txt       the fault, then valid data (13C 131, Fault_List IMU/HighG)
from projects/M310_M314_M110/config/imu_config.py (IMU SPI CURVE SIMULATION SETTINGS) and the
CAN-C stimulus of canc_config (CANC_IMU_SPI_AXIS, _STIMULUS, _COUNTS_PER_UNIT). The folder belongs
to this tool: a .txt file it no longer writes is deleted.

Usage:
    py -3.14 tools/build_imu_spi_curves.py          # write the files
    py -3.14 tools/build_imu_spi_curves.py --check  # compare only, exit 1 on a difference
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parent))
os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "M310_M314_M110")
from Framework_IOEM_Py.projects.M310_M314_M110.config import canc_config, imu_config  # noqa: E402

OUT_DIR = Path(imu_config.IMU_SPI_CURVE_DIR)


# ---------------------------------------------------------------------------
# SPI answers
# ---------------------------------------------------------------------------

def frame_crc(word: int, frame: dict) -> int:
    """CRC of a 32-bit SPI answer: the bitwise division of all 32 bits, CRC field cleared,
    by the frame's polynomial from its initial value (ARIA CalculateCRC_Panasonic /
    CalculateCRC_Gen6)."""
    bits = frame["crc_bits"]
    crc = frame["crc_init"]
    word &= ~((1 << bits) - 1) & 0xFFFFFFFF
    for bit in range(31, -1, -1):
        crc = (crc << 1) | ((word >> bit) & 1)
        if crc >> bits:
            crc ^= frame["crc_poly"]
    return crc


def with_crc(word: int, frame: dict) -> int:
    """The answer with a valid CRC."""
    mask = (1 << frame["crc_bits"]) - 1
    return (word & ~mask & 0xFFFFFFFF) | frame_crc(word, frame)


def fault_word(sensor: str, axis: int, recipe: dict) -> int:
    """The raw answer of a word fault on an axis: the axis's data-0 answer (or the one of
    recipe['source_axis'][axis]) with recipe['clear'] bits cleared and recipe['set'] bits
    set, CRC recomputed, then the CRC bits flipped by recipe['crc_xor']."""
    spec = imu_config.IMU_SPI_SENSORS[sensor]
    source = recipe.get("source_axis", {}).get(axis, axis)
    word = spec["axis_word"][source]
    word = (word & ~recipe.get("clear", 0) & 0xFFFFFFFF) | recipe.get("set", 0)
    word = with_crc(word, spec["frame"])
    return word ^ recipe.get("crc_xor", 0)


def samples(ms: float) -> int:
    count = ms / imu_config.IMU_SPI_CURVE_SAMPLE_MS
    assert count == int(count) and count > 0, f"{ms} ms is not a whole number of samples"
    return int(count)


# ---------------------------------------------------------------------------
# Curves
# ---------------------------------------------------------------------------

def text(lines: list[str]) -> str:
    return "\n".join(lines) + "\n"


NAMES = imu_config.IMU_SPI_CURVE_NAMES   # the scripts build the same names from it


def rest_name(sensor: str, count: int) -> str:
    return NAMES["rest"].format(function=imu_config.IMU_SPI_SENSORS[sensor]["function"], samples=count)


def step_name(axis: int, counts: int) -> str:
    return NAMES["step"].format(function=imu_config.IMU_SPI_SENSORS["Panasonic"]["function"], axis=axis, counts=counts)


def fault_name(sensor: str, family: str, axis: int) -> str:
    return NAMES["fault"].format(function=imu_config.IMU_SPI_SENSORS[sensor]["function"], family=family, axis=axis)


def build() -> dict[str, tuple[str, str]]:
    """{file name: (content, description)}."""
    files: dict[str, tuple[str, str]] = {}
    files[imu_config.IMU_SPI_RSU_ZERO_CURVE] = (
        text(["0"] * imu_config.IMU_SPI_RSU_ZERO_SAMPLES),
        f"{imu_config.IMU_SPI_RSU_ZERO_SAMPLES} samples of 0: every RSU channel before a trigger")
    rests: set[tuple[str, int]] = set()

    # CAN-C stimulus (canc_config): stimulus counts on the signal's axis, then rest. The negative
    # stimulus is the same file sent inverted.
    step = imu_config.IMU_SPI_STEP_CURVE
    step_count, step_rest = samples(step["step_ms"]), samples(step["rest_ms"])
    for key, stimulus in canc_config.CANC_IMU_SPI_STIMULUS.items():
        axis = canc_config.CANC_IMU_SPI_AXIS[key]
        counts = round(stimulus * canc_config.CANC_IMU_SPI_COUNTS_PER_UNIT[key])
        assert 0 < counts <= 0x7FFF, (key, counts)
        name = step_name(axis, counts)
        files[name] = (text([str(counts)] * step_count + ["0"] * step_rest),
                       f"{key}: {counts} counts ({stimulus:g} {canc_config.MAH_CAN_SIGNAL_DEFS[key]['UNIT']}) "
                       f"for {step['step_ms']} ms, then 0 for {step['rest_ms']} ms")
        rests.add(("Panasonic", step_count + step_rest))

    for sensor, families in imu_config.IMU_SPI_FAULT_CURVES.items():
        spec = imu_config.IMU_SPI_SENSORS[sensor]
        function = spec["function"]
        for family, recipe in families.items():
            fault, recovery = samples(recipe["fault_ms"]), samples(recipe["valid_ms"])
            rests.add((sensor, fault + recovery))
            for axis in recipe["axes"]:
                channel = spec["axes"][axis]
                if "value" in recipe:
                    value = recipe["value"]
                    assert 0 < value <= 0x7FFF, (sensor, family, value)
                    lines = [str(value)] * fault
                    what = f"data {value}"
                else:
                    word = fault_word(sensor, axis, recipe)
                    assert word, "ARIA skips a blended word of 0"
                    lines = [f"0#SPI_{function}:{word:08X}"] * fault
                    what = f"raw answer 0x{word:08X}"
                files[fault_name(sensor, family, axis)] = (
                    text(lines + ["0"] * recovery),
                    f"{channel}: {what} for {recipe['fault_ms']} ms, then valid data for {recipe['valid_ms']} ms")
    for sensor, count in sorted(rests):
        files[rest_name(sensor, count)] = (text(["0"] * count), f"0 on all {count} samples")
    return files


def readme(files: dict[str, tuple[str, str]]) -> str:
    lines = [
        "# SPI curves of the IMU and GEN6 simulation",
        "",
        "Written by `tools/build_imu_spi_curves.py` from `projects/M310_M314_M110/config/imu_config.py`",
        "(IMU SPI CURVE SIMULATION SETTINGS) and the CAN-C stimulus in `canc_config.py`; do not edit by",
        "hand. Method: `projects/M310_M314_M110/modules/CANC/IMU_SPI_SIMULATION.md`.",
        "",
        f"One line per sample, {imu_config.IMU_SPI_CURVE_SAMPLE_MS:g} ms each (IMU_SPI_CURVE_SAMPLE_MS, an "
        "assumption to confirm on the bench): a signed",
        "integer is the axis data, `<value>#SPI_<function>:<HEX32>` a raw SPI answer the card sends in that",
        "sample. The files also load by hand in ARIA's Crash Simulation tab.",
        "",
        "| File | Samples | Content |",
        "|---|---|---|",
    ]
    for name, (content, description) in sorted(files.items()):
        lines.append(f"| `{name}` | {content.count(chr(10))} | {description} |")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Write the IMU / GEN6 SPI curve files.")
    parser.add_argument("--check", action="store_true", help="compare with the files on disk only")
    args = parser.parse_args()
    files = build()
    wanted = {name: content for name, (content, _) in files.items()}
    wanted["README.md"] = readme(files)
    changed = []
    for name, content in wanted.items():
        path = OUT_DIR / name
        # core.autocrlf may give a checked-out file CRLF endings; ARIA reads either.
        old = path.read_text(encoding="ascii").replace("\r\n", "\n") if path.is_file() else None
        if old != content:
            changed.append(name)
            if not args.check:
                OUT_DIR.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="ascii", newline="\n")
    stale = sorted(p.name for p in OUT_DIR.glob("*.txt") if p.name not in wanted) if OUT_DIR.is_dir() else []
    for name in stale:
        changed.append(f"{name} (not written by this tool)")
        if not args.check:
            (OUT_DIR / name).unlink()
    print(f"{len(wanted)} files, {len(changed)} {'differ' if args.check else 'written or removed'}")
    for name in changed:
        print("  " + name)
    return 1 if (args.check and changed) else 0


if __name__ == "__main__":
    sys.exit(main())
