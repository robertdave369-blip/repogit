"""First-pass inventory of test results for the report-review pipeline (evidence only, no verdicts).

    py -3.14 tools/report_review.py scan <folder|file> [...] --out <results.json> [--spec <test spec.xlsx>]

Reads
  framework / apym HTML reports   overall <!--PASSED|FAILED--> marker, header fields (#Test Case ID,
                                  #Test Case Description, ...), groups and steps with Expected /
                                  Obtained / Result, step text (exceptions)
  ARIA XML results (JScript)      header comment (Test case ID, Result Test, requirement), <Action>
                                  Expected / Obtained / Result, IsFinished, XML signature present
  CAN logs .txt/.log/.asc/.blf    paired with a report by name: the framework writes
                                  <case>_<YYYYMMDD_HHMMSS>.html and the log under the same stem
Flags evidence the agent then judges: incomplete report (no verdict marker / IsFinished != Yes),
unsigned ARIA XML, failed steps, exceptions, a PASSED report without a single checked value,
a report without a log. With --spec each report is matched to a test case (by ID, else by name)
and every expected result of the spec that no report step mentions is listed.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from spec_trace import read_cases, score, tokens  # noqa: E402  (same name matching as the traceability tool)

LOG_EXT = {".txt", ".log", ".asc", ".blf"}
STAMP = re.compile(r"_\d{8}_\d{6}$")


def text(fragment: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", fragment))).strip()


def parse_html(path: Path) -> dict:
    t = path.read_text(encoding="utf-8", errors="replace")
    verdict = re.search(r"<!--(PASSED|FAILED)-->\s*$", t)
    rec = {"file": str(path), "format": "html", "verdict": verdict.group(1) if verdict else "INCOMPLETE",
           "fields": {}, "steps": [], "groups": [], "messages": []}
    for attrs, body in re.findall(r"<tr([^>]*)>(.*?)</tr>", t, re.S):
        cells = [text(c) for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", body, re.S)]
        m = re.search(r'class="([^"]*)"', attrs)
        cls = m.group(1) if m else ""
        if not cls:  # header table: "#Key:" cells followed by their values
            for k, v in zip(cells[0::2], cells[1::2]):
                if k.startswith("#"):
                    rec["fields"][k.strip("#: ")] = v
            continue
        result = "FAILED" if "-failed" in cls else "PASSED" if "-passed" in cls else ""
        # Row kinds: "group header" [n, time, name, duration, result]; "step" and "step header" (a step
        # with an expandable detail) [n, time, name, expected, obtained, duration, result]; "content" = detail.
        if "group header" in cls and len(cells) >= 5:
            rec["groups"].append({"n": cells[0], "time": cells[1], "name": cells[2], "result": cells[4] or result})
        elif "content" in cls:
            if cells and (result == "FAILED" or "Traceback" in cells[0] or 'File "' in cells[0]):
                m = cells[0]  # a traceback ends with the exception: keep both ends
                rec["messages"].append(m if len(m) <= 700 else f"{m[:200]} … {m[-500:]}")
        elif "step" in cls and len(cells) >= 5:
            rec["steps"].append({"n": cells[0], "time": cells[1], "name": cells[2], "expected": cells[3], "obtained": cells[4],
                                 "result": (cells[6] if len(cells) > 6 and cells[6] in ("PASSED", "FAILED") else result)})
    return rec


def parse_xml(path: Path) -> dict:
    raw = path.read_text(encoding="iso-8859-1", errors="replace")
    header = re.search(r"<!--(.*?)-->", raw, re.S)
    head = header.group(1) if header else ""
    def get(label: str) -> str:  # value on the same line only: an empty field must not take the next line
        m = re.search(rf"{label}[ \t]*:[ \t]*(.*)", head)
        return m.group(1).strip() if m else ""
    rec = {"file": str(path), "format": "aria-xml", "fields": {"Test Case ID": get("Test case ID"), "Requirement": get("Requirement under test")},
           "verdict": (get("Result Test").split() or ["INCOMPLETE"])[0].upper(), "steps": [], "groups": [], "messages": []}
    try:
        root = ET.fromstring(re.sub(r"<\?xml-stylesheet[^>]*\?>", "", raw).encode("iso-8859-1", errors="replace"))
    except ET.ParseError as exc:
        rec["messages"].append(f"XML not parseable: {exc}")
        rec["verdict"] = "INCOMPLETE"
        return rec
    rec["finished"] = root.get("IsFinished")
    rec["signed"] = any(el.tag.endswith("Signature") for el in root)
    for i, a in enumerate(root.iter("Action"), 1):
        rec["steps"].append({"n": str(i), "name": a.get("Name", ""), "expected": a.findtext("Expected", "").strip(),
                             "obtained": a.findtext("Obtained", "").strip(), "result": a.findtext("Result", "").strip().upper()})
    return rec


def flags(rec: dict) -> list[str]:
    out = []
    if rec["verdict"] == "INCOMPLETE":
        out.append("REPORT_INTEGRITY: no final verdict (script stopped before the report was closed)")
    if rec.get("finished") not in (None, "Yes"):
        out.append(f"REPORT_INTEGRITY: IsFinished={rec.get('finished')}")
    if rec["format"] == "aria-xml" and not rec.get("signed"):
        out.append("REPORT_INTEGRITY: ARIA XML without signature (edited or not produced by ARIA)")
    failed = [s for s in rec["steps"] if s["result"] == "FAILED"]
    if failed:
        out.append(f"{len(failed)} failed step(s): " + "; ".join(f"{s['n']} @{s.get('time', '')} {s['name'][:60]} expected {s['expected'][:80]!r} got {s['obtained'][:60]!r}" for s in failed[:5]))
    if rec["messages"]:
        out.append(f"{len(rec['messages'])} error message(s) in the report")
    if rec["verdict"] == "PASSED" and not any(s["expected"] for s in rec["steps"]):
        out.append("FALSE_PASS?: PASSED without a single step that compares an expected value")
    if rec.get("log") is None:
        out.append("no CAN log found for this report")
    return out


def match_spec(rec: dict, cases: list[dict]) -> dict | None:
    key = rec["fields"].get("Test Case ID", "")
    for c in cases:
        if key and (key == c["name"] or key in str(c.get("verifies") or "")):
            return c
    name = " ".join([rec["fields"].get("Test Case Description", ""), STAMP.sub("", Path(rec["file"]).stem)])
    tok = tokens(name)
    ranked = sorted(((score(tok, tokens(f"{c['name']} {c['description']}"))[0], i) for i, c in enumerate(cases)), reverse=True)
    return cases[ranked[0][1]] if ranked and ranked[0][0] >= 0.35 else None


def cmd_scan(a: argparse.Namespace) -> int:
    files = []
    for p in map(Path, a.paths):
        files += sorted(p.rglob("*")) if p.is_dir() else [p]
    logs = {STAMP.sub("", f.stem).lower(): f for f in files if f.suffix.lower() in LOG_EXT}
    logs.update({f.stem.lower(): f for f in files if f.suffix.lower() in LOG_EXT})
    cases = read_cases(Path(a.spec))[2] if a.spec else []
    records = []
    for f in files:
        ext = f.suffix.lower()
        if ext not in (".html", ".htm", ".xml") or f.name.endswith(".xsl"):
            continue
        rec = parse_html(f) if ext in (".html", ".htm") else parse_xml(f)
        log = logs.get(f.stem.lower()) or logs.get(STAMP.sub("", f.stem).lower())
        rec["log"] = str(log) if log else None
        if cases:
            c = match_spec(rec, cases)
            rec["spec_case"] = c["name"] if c else None
            if c:
                said = " ".join(f"{s['name']} {s['expected']} {s['obtained']}" for s in rec["steps"])
                done = tokens(said)
                rec["spec_checks_not_in_report"] = [e for e in c["steps"] if tokens(e)[1] and not (tokens(e)[1] & done[1])][:10]
        rec["flags"] = flags(rec)
        records.append(rec)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")
    summary: dict[str, int] = {}
    for r in records:
        summary[r["verdict"]] = summary.get(r["verdict"], 0) + 1
    print(json.dumps({"reports": len(records), "logs": len(set(logs.values())), "verdicts": summary,
                      "with_flags": sum(1 for r in records if r["flags"]), "out": a.out}, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Inventory HTML/XML test reports and CAN logs")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("scan"); p.set_defaults(fn=cmd_scan)
    p.add_argument("paths", nargs="+"); p.add_argument("--out", required=True); p.add_argument("--spec")
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
