"""Build the merged crash-curve sets named in shared_libraries/crash_configuration.py.

MULTI_EVENT_SETS there gives each set (parallel, concatenated, multi, single, boundary) its
events and its T0-to-T0 delays. This tool runs the edr-rsu-curve-generation runner (vendored
Crash Curve Tool, hash-pinned): first the standard front/left/right/rear/near set (seed 0,
2026-10-22, the set installed in crash_data/<project>/<type>_crash), then one multi-event merge
per set with the in-file negations of multi_event_inversion_tokens. Each merge is installed in
crash_data/multi_event/multi_crash_<key>, which every project's crash table points to. A channel
the merge leaves out because it is zero in every event gets the set's zero curve.

Edit MULTI_EVENT_SETS, not the curves. Offline only: writes curve files; nothing is loaded
into ARIA or the HIL.

Usage:
    py -3.14 tools/build_multi_event_crash_sets.py
    py -3.14 tools/build_multi_event_crash_sets.py --check
"""

from __future__ import annotations

import argparse
import contextlib
import importlib.util
import io
import shutil
import sys
import tempfile
from pathlib import Path
from types import ModuleType

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = REPOSITORY_ROOT / ".github" / "skills" / "edr-rsu-curve-generation" / "scripts" / "edr_curve_runner.py"
CONFIG_PATH = REPOSITORY_ROOT / "shared_libraries" / "crash_configuration.py"
TARGET_DIR = REPOSITORY_ROOT / "crash_data" / "multi_event"
STANDARD_TYPES = ("front", "left", "right", "rear", "near")
SEED, DATE = 0, "2026-10-22"


def load(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"Unable to load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run(runner: ModuleType, *argv: str) -> None:
    output = io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
        code = runner.main(list(argv))
    if code:
        raise SystemExit(f"runner {' '.join(argv)} exited {code}:\n{output.getvalue()}")


def build(work: Path) -> dict[str, dict[str, bytes]]:
    """Every set's files (name -> content), built under work."""
    runner = load("edr_curve_runner", RUNNER_PATH)
    config = load("crash_configuration", CONFIG_PATH)
    common = ("--seed", str(SEED), "--date", DATE)
    standard = work / "std"
    run(runner, "generate", "--output", str(standard), "--types", *STANDARD_TYPES, *common)
    sets = {}
    for key, (events, delays) in config.MULTI_EVENT_SETS.items():
        output = work / "me" / key
        run(runner, "multi-event", "--output", str(output), "--events", *events,
            "--delays-ms", *(str(delay) for delay in delays),
            "--invert", *config.multi_event_inversion_tokens(events),
            "--source", *(str(standard / f"{event}_crash_{DATE}") for event in events), *common)
        (case_dir,) = [path for path in output.iterdir() if path.is_dir()]
        files = {path.name: path.read_bytes() for path in sorted(case_dir.glob("*.txt"))}
        # The merge leaves out a channel that is zero in every event (near_near_near); write it as
        # the set's zero curve so every configured channel loads.
        for path in sorted((standard / f"{events[0]}_crash_{DATE}").glob("*.txt")):
            if "summary" not in path.name:
                files.setdefault(path.name, files["Sensor_With_0_values.txt"])
        # The summary names the temporary source folders; keep only their names.
        files["multi_event_summary.txt"] = files["multi_event_summary.txt"].replace(
            str(standard).encode() + b"\\", b"")
        sets[key] = files
    return sets


def installed(key: str) -> dict[str, bytes]:
    folder = TARGET_DIR / f"multi_crash_{key}"
    return {path.name: path.read_bytes() for path in sorted(folder.glob("*.txt"))} if folder.is_dir() else {}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--check", action="store_true", help="rebuild in a temporary folder and compare")
    args = parser.parse_args()
    # Short root: the engine's file names are ~80 characters and Windows stops at 260.
    work = Path(tempfile.mkdtemp(prefix="mecs-"))
    try:
        sets = build(work)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    stale = sorted(path.name for path in TARGET_DIR.glob("multi_crash_*")
                   if path.name.removeprefix("multi_crash_") not in sets) if TARGET_DIR.is_dir() else []
    if args.check:
        differ = [key for key, files in sets.items() if installed(key) != files]
        for key in differ:
            print(f"out of date: multi_crash_{key}")
        for name in stale:
            print(f"not in MULTI_EVENT_SETS: {name}")
        print(f"{len(sets) - len(differ)}/{len(sets)} sets up to date")
        return 1 if differ or stale else 0
    for name in stale:
        shutil.rmtree(TARGET_DIR / name)
        print(f"removed {name}")
    for key, files in sets.items():
        folder = TARGET_DIR / f"multi_crash_{key}"
        shutil.rmtree(folder, ignore_errors=True)
        folder.mkdir(parents=True)
        for name, content in files.items():
            (folder / name).write_bytes(content)
    print(f"{len(sets)} sets written to {TARGET_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
