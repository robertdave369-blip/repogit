"""Check the CAN NM knowledge base against its sources.

Reads docs/can-network-management/*.md and the CAN NM agent profile and reports:
  * OEM requirement IDs (8 digits, 31xxxxxx-33xxxxxx) that are in no source workbook (error),
    and obsolete ones cited on a line that does not say so (warning);
  * SWS_CanNm IDs (also the short 00xxx form) missing from the verified list in
    standards-and-terminology.md section 2 (error);
  * repository paths in backticks or Markdown links that do not exist (error).

Usage: py -3 tools/check_cannm_docs.py      Exit code 0 = no errors, 1 = errors.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs" / "can-network-management"
FILES = sorted(DOCS.glob("*.md")) + [ROOT / ".github" / "agents" / "can-network-management-engineer.agent.md"]
REQ_SOURCES = [ROOT / "project_reuirements" / "m310_m314_m110" / "DES_SW_Mahindra_Network_Management.xlsx",
               *sorted((ROOT / "project_reuirements" / "m310_m314_m110" / "CAN C Requirements").glob("*.xlsx"))]
PATH_ROOTS = (".github/", "docs/", "projects/", "project_dbc/", "project_reuirements/", "shared_libraries/",
              "tools/", "tests/", "test_logs/", "test_results/")

REQ_RE = re.compile(r"(?<![\w.])(3[123]\d{6})(?![\w.])")
SWS_RE = re.compile(r"SWS_CanNm_(\d{5})((?:,\s*\d{5})*)")
SHORT_SWS_RE = re.compile(r"(?<![\w.])(00\d{3})(?![\w.])")


def load_requirements() -> dict[str, str]:
    """Requirement ID -> status from the OEM workbooks (column headers 'ID' and '_ReqStatus')."""
    found = {}
    for path in REQ_SOURCES:
        ws = openpyxl.load_workbook(path, read_only=True, data_only=True).worksheets[0]
        rows = ws.iter_rows(values_only=True)
        header = [str(h) for h in next(rows)]
        id_col, status_col = header.index("ID"), header.index("_ReqStatus")
        for row in rows:
            req_id = row[id_col]
            if isinstance(req_id, (int, float)):
                found[str(int(req_id))] = str(row[status_col])
    return found


def verified_sws() -> set[str]:
    text = (DOCS / "standards-and-terminology.md").read_text(encoding="utf-8")
    section = text.split("## 2. Verified", 1)[1].split("\n## ", 1)[0]
    return {m.group(1) for m in re.finditer(r"SWS_CanNm_(\d{5})", section)}


def main() -> int:
    requirements, verified = load_requirements(), verified_sws()
    # Guards: an empty source would make every check pass silently.
    assert len(requirements) > 60 and len(verified) > 40, "requirement or SWS sources not read"
    errors, warnings = [], []
    for path in FILES:
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            where = f"{path.relative_to(ROOT).as_posix()}:{number}"
            for req in REQ_RE.findall(line):
                status = requirements.get(req)
                if status is None:
                    errors.append(f"{where}: requirement {req} not in any source workbook")
                elif status == "Obsolete" and "bsolete" not in line:
                    warnings.append(f"{where}: requirement {req} is Obsolete")
            cited = set()
            for first, rest in SWS_RE.findall(line):
                cited |= {first, *re.findall(r"\d{5}", rest)}
            if path.name != "standards-and-terminology.md":
                cited |= set(SHORT_SWS_RE.findall(line))
            errors += [f"{where}: SWS_CanNm_{sws} is not in the verified list" for sws in sorted(cited - verified)]
            if "does not exist" in line or "missing" in line:
                continue  # the line reports the path as absent on purpose (e.g. finding F-05)
            paths = [(ROOT, p) for p in re.findall(r"`([^`\s]+)`", line) if p.startswith(PATH_ROOTS)]
            paths += [(path.parent, p) for p in re.findall(r"\]\(([^)\s#]+\.md)\)", line)]
            for base, link in paths:
                link = re.sub(r":\d+(-\d+)?$", "", link.rstrip(".,;:"))  # file.py:131 -> file.py
                if not any(ch in link for ch in "<*") and not (base / link).exists():
                    errors.append(f"{where}: path {link} does not exist")
    for message in errors:
        print("ERROR  ", message)
    for message in warnings:
        print("WARNING", message)
    print(f"{len(FILES)} files, {len(requirements)} OEM requirements, {len(verified)} verified SWS IDs: "
          f"{len(errors)} errors, {len(warnings)} warnings")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
