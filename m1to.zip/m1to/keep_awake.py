"""Keep this PC awake and online while a pipeline task runs, also with the screen locked.

    py -3.14 tools/keep_awake.py start --task <name> [--hours 12] [--display]
    py -3.14 tools/keep_awake.py stop  --task <name> | --all
    py -3.14 tools/keep_awake.py status

One hidden background holder serves every running task. It asks Windows to keep the system out
of idle sleep (SetThreadExecutionState ES_CONTINUOUS | ES_SYSTEM_REQUIRED, plus
ES_DISPLAY_REQUIRED with --display), checks the internet every 30 s and reconnects the Wi-Fi
profile that was connected at start when two checks in a row fail, and exits when its last task
is stopped or its hours run out (so a forgotten hold cannot keep the PC up for ever).
A locked screen does not stop it. Closing the lid (lid action "sleep"), the power button, a
battery shutdown or a Windows Update restart still can; `status` warns about the lid and battery.
State: %LOCALAPPDATA%\\test_pipelines\\keep_awake.json, log keep_awake.log beside it.
"""

from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import json
import os
import re
import socket
import subprocess
import sys
import time
from pathlib import Path

STATE_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "test_pipelines"
ES_CONTINUOUS, ES_SYSTEM_REQUIRED, ES_DISPLAY_REQUIRED = 0x80000000, 0x00000001, 0x00000002
PROBES = (("github.com", 443), ("api.githubcopilot.com", 443), ("8.8.8.8", 53))
LID_ACTIONS = {0: "do nothing", 1: "sleep", 2: "hibernate", 3: "shut down"}


def state_file() -> Path:
    return STATE_DIR / "keep_awake.json"


def load() -> dict:
    try:
        return json.loads(state_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"tasks": {}}


def save(state: dict) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = state_file().with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    tmp.replace(state_file())


def log(message: str) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with (STATE_DIR / "keep_awake.log").open("a", encoding="utf-8") as f:
        f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} {message}\n")


def active(tasks: dict, now: dt.datetime) -> dict:
    return {k: v for k, v in tasks.items() if dt.datetime.fromisoformat(v["until"]) > now}


def pid_alive(pid: int | None) -> bool:
    if not pid:
        return False
    out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"], capture_output=True, text=True).stdout
    return f'"{pid}"' in out


def online() -> bool:
    for host, port in PROBES:
        try:
            with socket.create_connection((host, port), timeout=5):
                return True
        except OSError:
            continue
    return False


def wifi_profile() -> str | None:
    """Network name of the connected Wi-Fi interface. Get-NetConnectionProfile needs no location
    permission, unlike `netsh wlan show interfaces` on Windows 11."""
    out = subprocess.run(["powershell", "-NoProfile", "-Command",
                          "(Get-NetConnectionProfile | Where-Object { $_.InterfaceAlias -match 'Wi-?Fi|WLAN' } | Select-Object -First 1).Name"],
                         capture_output=True, text=True).stdout.strip()
    return out or None


def lid_action(powercfg_text: str) -> dict[str, str]:
    idx = dict(re.findall(r"Current (AC|DC) Power Setting Index:\s*0x([0-9a-fA-F]+)", powercfg_text))
    return {k: LID_ACTIONS.get(int(v, 16), str(v)) for k, v in idx.items()}


def hold() -> int:
    """The background holder: runs until no task is active."""
    kernel32 = ctypes.windll.kernel32
    misses = 0
    state = load()
    state["pid"] = os.getpid()
    save(state)
    log(f"holder {os.getpid()} started for {sorted(state['tasks'])}")
    try:
        while True:
            state = load()
            tasks = active(state.get("tasks", {}), dt.datetime.now())
            if not tasks or state.get("pid") != os.getpid():
                break
            flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED | (ES_DISPLAY_REQUIRED if any(t.get("display") for t in tasks.values()) else 0)
            kernel32.SetThreadExecutionState(flags)
            if online():
                if misses:
                    log("internet back")
                misses = 0
            else:
                misses += 1
                log(f"internet check failed ({misses})")
                if misses >= 2 and state.get("wifi_profile"):
                    out = subprocess.run(["netsh", "wlan", "connect", f"name={state['wifi_profile']}"], capture_output=True, text=True)
                    log(f"reconnect Wi-Fi '{state['wifi_profile']}': {(out.stdout or out.stderr).strip()[:120]}")
            state["last_check"] = {"at": dt.datetime.now().isoformat(timespec="seconds"), "online": misses == 0}
            current = load()  # keep tasks added meanwhile; only our own fields change
            current["last_check"], current["pid"] = state["last_check"], os.getpid()
            save(current)
            time.sleep(30)
    finally:
        kernel32.SetThreadExecutionState(ES_CONTINUOUS)  # back to the normal power policy
        state = load()
        if state.get("pid") == os.getpid():
            state["pid"] = None
            save(state)
        log(f"holder {os.getpid()} stopped")
    return 0


def spawn_holder() -> int:
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    exe = str(pythonw if pythonw.is_file() else sys.executable)
    base = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED | NEW_PROCESS_GROUP | NO_WINDOW
    for flags in (base | 0x01000000, base):      # first try to leave the VS Code terminal's job
        try:
            return subprocess.Popen([exe, str(Path(__file__).resolve()), "_hold"], creationflags=flags, close_fds=True,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).pid
        except OSError:
            continue
    raise SystemExit("could not start the keep-awake holder")


def cmd_start(a: argparse.Namespace) -> int:
    state = load()
    now = dt.datetime.now()
    state.setdefault("tasks", {})[a.task] = {"until": (now + dt.timedelta(hours=a.hours)).isoformat(timespec="seconds"),
                                            "started": now.isoformat(timespec="seconds"), "display": a.display}
    fresh = not pid_alive(state.get("pid"))
    if fresh:
        state["wifi_profile"] = wifi_profile()  # the network in use now, not one from an earlier hold
    save(state)
    if fresh:
        spawn_holder()
        for _ in range(20):
            time.sleep(0.5)
            if pid_alive(load().get("pid")):
                break
    log(f"start {a.task} for {a.hours} h")
    return cmd_status(a)


def cmd_stop(a: argparse.Namespace) -> int:
    state = load()
    gone = list(state.get("tasks", {})) if a.all else [a.task] if a.task in state.get("tasks", {}) else []
    for t in gone:
        state["tasks"].pop(t)
    save(state)
    log(f"stop {gone or 'nothing'}")
    print(json.dumps({"stopped": gone, "still_held_for": sorted(state["tasks"])}, indent=2))
    return 0


def cmd_status(_: argparse.Namespace) -> int:
    state = load()
    now = dt.datetime.now()
    lid = lid_action(subprocess.run(["powercfg", "/qh", "SCHEME_CURRENT", "SUB_BUTTONS", "LIDACTION"],  # /qh: the lid
                                    capture_output=True, text=True).stdout)                          # setting is hidden
    battery = subprocess.run(["powershell", "-NoProfile", "-Command", "(Get-CimInstance Win32_Battery).BatteryStatus"],
                             capture_output=True, text=True).stdout.strip()
    report = {"holder_running": pid_alive(state.get("pid")), "pid": state.get("pid"),
              "tasks": {k: {"until": v["until"], "display_on": v.get("display", False)} for k, v in active(state.get("tasks", {}), now).items()},
              "wifi_profile_to_reconnect": state.get("wifi_profile"), "last_check": state.get("last_check"),
              "lid_close_action": lid, "on_mains_power": battery in ("", "2", "6", "7", "8", "9")}
    warnings = []
    if any(v != "do nothing" for v in lid.values()):
        warnings.append(f"closing the lid will {lid.get('AC', '?')} on mains / {lid.get('DC', '?')} on battery: keep it open")
    if not report["on_mains_power"]:
        warnings.append("running on battery: plug in, a low battery shuts the PC down")
    report["warnings"] = warnings
    print(json.dumps(report, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Keep the PC awake and online while a pipeline runs.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("start"); p.set_defaults(fn=cmd_start)
    p.add_argument("--task", required=True); p.add_argument("--hours", type=float, default=12)
    p.add_argument("--display", action="store_true", help="also keep the display on")
    p = sub.add_parser("stop"); p.set_defaults(fn=cmd_stop)
    g = p.add_mutually_exclusive_group(required=True); g.add_argument("--task"); g.add_argument("--all", action="store_true")
    sub.add_parser("status").set_defaults(fn=cmd_status)
    sub.add_parser("_hold").set_defaults(fn=lambda _: hold())
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
