"""Codebeamer-format test specs and their traceability (test-case-writer pipeline).

    py -3.14 tools/spec_trace.py render --cases <designed_cases.json> --out <spec.xlsx> [--template T] [--title T]
    py -3.14 tools/spec_trace.py trace  --spec <existing spec.xlsx> --req <source> [--req ...] --out <folder>
    py -3.14 tools/spec_trace.py apply  --traced <spec>_traced.xlsx --rows <accepted rows|all> [--replace]

render  the test cases the agent designed -> the Codebeamer import workbook of the
        veoneer-test-spec-generator skill (its bundled cleaned master by default), written and checked
        by that skill's own validate_specification / render_specification / validate_rendered_workbook.
        Verifies = "[ISSUE:<id>] - null" per requirement. JSON:
        {"title": "...", "test_cases": [{"name", "description", "pre_action", "post_action", "priority",
          "verifies": ["<req id>"], "technique", "technique_rationale", "status", "type", "project",
          "script_path", "test_type", "verification_method",
          "steps": [{"action", "expected", "critical": true|false}]}]}
trace   an existing spec + the requirement set -> <spec>_traced.xlsx (a copy with three added
        columns: Proposed Verifies, Trace basis, Trace confidence; no existing cell is changed), a
        Coverage sheet, and findings_trace.json for `test_task.py findings --kind trace`.
apply   writes the proposals the user accepted into the Verifies cells -> <spec>_corrected.xlsx.
Requirement sources: workbook/docx/pdf/csv/json read by the skill's requirement parser, or a
campaign's Codebeamer fetch as cb:<campaign folder>. A requirement is "approved" when its status
says approved, accepted or released; "[STRUCK: ...]" text is not an active requirement.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any

try:
    import openpyxl
except ImportError:
    raise SystemExit('openpyxl missing: run `py -3.14 tools/test_task.py setup --pipeline tc-writer`')

REPO = Path(__file__).resolve().parents[1]
SKILL = REPO / ".github" / "skills" / "veoneer-test-spec-generator"
sys.dont_write_bytecode = True  # the skill's __pycache__ is tracked in git: do not rewrite it
sys.path.insert(0, str(SKILL / "scripts"))
STOP = set("the a an and or of to in on for with by is are be shall should must will when then if not no "
           "this that from as at it its into via per all any each test case step verify check".split())


def ids_in(text: Any) -> list[str]:
    """Requirement IDs in a Verifies-style cell: [ISSUE:<id>] references, else bare comma-separated IDs."""
    s = "" if text is None else str(text)
    found = re.findall(r"\[ISSUE:\s*([\w.-]+)\s*\]", s)
    return found or [t for t in re.split(r"[,;\s]+", s) if re.fullmatch(r"[A-Za-z]*[-_]?\d[\w.-]*", t)]


def verifies(req_ids: list[str]) -> str:
    return ",".join(f"[ISSUE:{i}] - null" for i in req_ids)


def flat(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("name") or value.get("value") or "")
    if isinstance(value, list):
        return " ".join(flat(v) for v in value)
    return "" if value is None else str(value)


def load_requirements(sources: list[str]) -> list[dict]:
    reqs: list[dict] = []
    for src in sources:
        if src.startswith("cb:"):
            for f in sorted(Path(src[3:]).glob("inputs/cb/*.json")):
                if f.name == "index.json":
                    continue
                item = json.loads(f.read_text(encoding="utf-8-sig"))["item"]
                reqs.append({"id": str(item.get("id") or f.stem), "title": item.get("name") or "",
                             "text": flat(item.get("description")), "status": flat(item.get("status")),
                             "source": f"Codebeamer item {f.stem}"})
            continue
        from requirement_parser import parse_sources
        parsed, _ = parse_sources([src])
        for r in parsed:
            reqs.append({"id": r.identifier, "title": r.title or "", "text": r.text, "status": r.status or "",
                         "source": f"{Path(r.provenance.source_path).name} {r.provenance.location}"})
    return reqs


def approved(req: dict) -> bool:
    return bool(re.search(r"approv|accept|releas", str(req.get("status", "")), re.I))


def struck(req: dict) -> bool:
    return str(req.get("text", "")).lstrip().upper().startswith("[STRUCK")


def tokens(text: str) -> tuple[set[str], set[str]]:
    """(words, strong tokens). Strong = engineering identifiers: hex, signal_names, DIDs/DTCs, values with units."""
    low = text.lower()
    strong = {t for t in re.findall(r"0x[0-9a-f]+|\b[a-z][a-z0-9]*_[a-z0-9_]+\b|\b(?=[a-z0-9]*\d)(?=[a-z0-9]*[a-z])[a-z0-9]{3,}\b", low)}
    strong |= {n + u for n, u in re.findall(r"\b(\d+(?:\.\d+)?)\s?(ms|s|v|mv|ma|a|hz|khz|g|%)\b", low)}  # values with units
    words = {w for w in re.findall(r"[a-z]{3,}", low) if w not in STOP}
    return words, strong


def score(case: tuple[set[str], set[str]], req: tuple[set[str], set[str]]) -> tuple[float, int]:
    words = len(case[0] & req[0]) / max(1, len(case[0] | req[0]))
    shared = len(case[1] & req[1])
    return min(1.0, words + 0.25 * shared), shared


def confidence(best: float, shared: int, margin: float) -> str:
    level = "High" if shared >= 2 and best >= 0.6 else "Medium" if best >= 0.45 else "Low"
    if margin < 0.05:  # a near tie: someone has to choose
        level = {"High": "Medium", "Medium": "Low"}.get(level, "Low")
    return level


def read_cases(spec: Path) -> tuple[str, int, list[dict]]:
    """(sheet, header row, cases) for a Codebeamer Export workbook or any sheet with a Name-like header."""
    wb = openpyxl.load_workbook(spec, data_only=True)
    for ws in wb.worksheets:
        for r in range(1, 16):
            head = {str(c.value).strip().lower(): c.column for c in ws[r] if c.value not in (None, "")}
            name_col = next((head[k] for k in ("name", "test case", "test case name", "title") if k in head), None)
            if not name_col:
                continue
            ver_col = next((v for k, v in head.items() if k in ("verifies", "requirement", "requirements", "req id", "traceability")), None)
            desc_col = next((v for k, v in head.items() if k.startswith("description")), None)
            step_cols = [v for k, v in head.items() if "action" in k or "expected" in k]
            cases, cur = [], None
            for row in range(r + 1, ws.max_row + 1):
                name = ws.cell(row, name_col).value
                if name not in (None, ""):
                    cur = {"row": row, "name": str(name), "description": str(ws.cell(row, desc_col).value or "") if desc_col else "",
                           "verifies": ws.cell(row, ver_col).value if ver_col else None, "steps": []}
                    cases.append(cur)
                if cur is not None:
                    cur["steps"] += [str(ws.cell(row, c).value) for c in step_cols if ws.cell(row, c).value not in (None, "")]
            return ws.title, r, cases
    raise SystemExit(f"no sheet with a Name / Test case header in the first 15 rows of {spec}")


def cmd_trace(a: argparse.Namespace) -> int:
    reqs = load_requirements(a.req)
    if not reqs:
        raise SystemExit("no requirements read from --req")
    by_id = {r["id"]: r for r in reqs if r["id"]}
    req_tok = {r["id"]: tokens(f"{r['title']} {r['text']}") for r in reqs if r["id"] and not struck(r)}
    sheet, head_row, cases = read_cases(Path(a.spec))
    findings, rows, covered_existing, covered_proposed, seen_names = [], {}, {}, {}, {}
    for c in cases:
        current = ids_in(c["verifies"])
        tok = tokens(" ".join([c["name"], c["description"], *c["steps"]]))
        ranked = sorted(((score(tok, t), rid) for rid, t in req_tok.items()), key=lambda x: -x[0][0])
        (best, shared), best_id = ranked[0] if ranked else ((0.0, 0), None)
        margin = best - (ranked[1][0][0] if len(ranked) > 1 else 0.0)
        base = {"test_case": c["name"], "row": c["row"], "current": ", ".join(current), "status": "to review"}
        for rid in current:
            covered_existing.setdefault(rid, []).append(c["name"])
            req = by_id.get(rid)
            if req is None:
                findings.append(dict(base, category="UNKNOWN_REQ", severity="High", proposed="",
                                     basis=f"{rid} is not in the requirement set", confidence="High"))
            elif struck(req):
                findings.append(dict(base, category="STRUCK_REQ", severity="High", proposed="", basis=f"{rid} is struck", confidence="High"))
            elif not approved(req):
                findings.append(dict(base, category="UNAPPROVED_REQ", severity="Low", proposed="",
                                     basis=f"{rid} status '{req['status']}'", confidence="High"))
        proposal = ""
        if not current:
            if best_id and best >= 0.3:
                conf = confidence(best, shared, margin)
                proposal = verifies([best_id])
                covered_proposed.setdefault(best_id, []).append(c["name"])
                alt = f"; near tie with {ranked[1][1]}" if margin < 0.05 and len(ranked) > 1 else ""
                basis = f"score {best:.2f}, {shared} shared identifiers with {best_id}{alt}"
                findings.append(dict(base, category="MISSING_TRACE", severity="High", proposed=proposal, basis=basis, confidence=conf))
            else:
                basis, conf = "no requirement scores >= 0.30: ask the user or the requirement owner", "Low"
                findings.append(dict(base, category="MISSING_TRACE", severity="High", proposed="", basis=basis, confidence=conf))
            rows[c["row"]] = (proposal, basis, conf)
        elif best_id and best_id not in current and best >= 0.6:
            own = max((score(tok, req_tok[r])[0] for r in current if r in req_tok), default=0.0)
            if own < 0.15:
                findings.append(dict(base, category="WRONG_TRACE", severity="Medium", proposed=verifies([best_id]),
                                     basis=f"traced requirements score {own:.2f}; {best_id} scores {best:.2f}", confidence="Low"))
        key = re.sub(r"\W+", " ", c["name"].lower()).strip()
        if key in seen_names:
            findings.append(dict(base, category="DUPLICATE_CASE", severity="Low", proposed="",
                                 basis=f"same name as row {seen_names[key]}", confidence="High"))
        seen_names.setdefault(key, c["row"])
    for r in reqs:
        if not r["id"] or struck(r) or r["id"] in covered_existing or r["id"] in covered_proposed:
            continue
        if approved(r):
            findings.append({"test_case": "", "row": "", "category": "UNTESTED_REQ", "severity": "High", "current": r["id"],
                             "proposed": "write a test case", "basis": f"{r['title'][:80]} ({r['source']})", "confidence": "High",
                             "status": "to review"})
        else:  # not designed until approved, but the gap stays visible
            findings.append({"test_case": "", "row": "", "category": "UNAPPROVED_REQ", "severity": "Low", "current": r["id"],
                             "proposed": "design once approved", "basis": f"status '{r['status']}', no test case: {r['title'][:60]}",
                             "confidence": "High", "status": "to review"})
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    src = Path(a.spec)
    traced = out / f"{src.stem}_traced{src.suffix}"
    shutil.copy2(src, traced)
    wb = openpyxl.load_workbook(traced, keep_vba=src.suffix.lower() == ".xlsm")
    ws = wb[sheet]
    col = ws.max_column + 1
    for i, h in enumerate(("Proposed Verifies", "Trace basis", "Trace confidence")):
        ws.cell(head_row, col + i, h)
    for row, values in rows.items():
        for i, v in enumerate(values):
            ws.cell(row, col + i, v)
    cov = wb.create_sheet("Coverage")
    cov.append(["Requirement ID", "Title", "Status", "Test cases (traced)", "Test cases (proposed)", "Covered"])
    for r in reqs:
        if r["id"] and not struck(r):
            ex, pr = covered_existing.get(r["id"], []), covered_proposed.get(r["id"], [])
            cov.append([r["id"], r["title"], r["status"], "\n".join(ex), "\n".join(pr), "yes" if ex else "proposed" if pr else "NO"])
    wb.save(traced)
    (out / "findings_trace.json").write_text(json.dumps(findings, indent=2, ensure_ascii=False), encoding="utf-8")
    counts: dict[str, int] = {}
    for f in findings:
        counts[f["category"]] = counts.get(f["category"], 0) + 1
    print(json.dumps({"traced_copy": str(traced), "cases": len(cases), "requirements": len(reqs), "findings": counts}, indent=2))
    return 0


def cmd_apply(a: argparse.Namespace) -> int:
    """Write the user-accepted proposals of a traced copy into its Verifies cells -> <spec>_corrected.xlsx."""
    src = Path(a.traced)
    wb = openpyxl.load_workbook(src, keep_vba=src.suffix.lower() == ".xlsm")
    sheet, head_row, _ = read_cases(src)
    ws = wb[sheet]
    head = {str(c.value).strip(): c.column for c in ws[head_row] if c.value not in (None, "")}
    if "Proposed Verifies" not in head:
        raise SystemExit(f"{src} is not a traced copy (no 'Proposed Verifies' column); run `trace` first")
    ver = next((v for k, v in head.items() if k.lower() in ("verifies", "requirement", "requirements", "req id", "traceability")), None)
    if ver is None:
        raise SystemExit("the spec has no Verifies column to write into")
    rows = [int(r) for r in re.split(r"[,\s]+", a.rows) if r] if a.rows != "all" else \
        [r for r in range(head_row + 1, ws.max_row + 1) if ws.cell(r, head["Proposed Verifies"]).value]
    done = []
    for r in rows:
        proposal = ws.cell(r, head["Proposed Verifies"]).value
        if not proposal:
            raise SystemExit(f"row {r} has no proposal")
        if ws.cell(r, ver).value not in (None, "") and not a.replace:
            raise SystemExit(f"row {r} already has Verifies '{ws.cell(r, ver).value}'; pass --replace if the user accepted replacing it")
        ws.cell(r, ver).value = proposal
        done.append(r)
    out = Path(a.out) if a.out else src.with_name(src.stem.replace("_traced", "") + "_corrected" + src.suffix)
    wb.save(out)
    print(json.dumps({"corrected_copy": str(out), "rows_written": done}, indent=2))
    return 0


def cmd_render(a: argparse.Namespace) -> int:
    from models import TestCase, TestMethodology, TestSpecification, TestStep
    from validation import validate_rendered_workbook, validate_specification
    from workbook_codec import load_profile, render_specification
    data = json.loads(Path(a.cases).read_text(encoding="utf-8-sig"))
    cases = []
    for c in data["test_cases"]:
        if not c.get("steps"):
            raise SystemExit(f"test case '{c.get('name')}' has no steps")
        cases.append(TestCase(
            name=c["name"], description=c.get("description", ""),
            steps=[TestStep(action=s["action"], expected_result=s["expected"], critical=s.get("critical")) for s in c["steps"]],
            methodology=TestMethodology(primary_technique=c.get("technique"), rationale=c.get("technique_rationale", "")),
            requirement_ids=[str(i) for i in c.get("verifies", [])], pre_action=c.get("pre_action"), post_action=c.get("post_action"),
            priority=c.get("priority"), status=c.get("status"), item_type=c.get("type"), project=c.get("project"),
            script_path=c.get("script_path"), test_type=c.get("test_type"), verification_method=c.get("verification_method")))
    spec = TestSpecification(title=a.title or data.get("title", "Test specification"), test_cases=cases)
    profile = load_profile()
    template = Path(a.template) if a.template else SKILL / "assets" / "veoneer_codebeamer_test_spec_template.cleaned.xlsx"
    pre = validate_specification(spec, template_path=template, profile=profile)
    errors = [i for i in pre if i.severity == "error"]
    if errors:
        print(json.dumps([{"code": i.code, "message": i.message, "location": i.location} for i in errors], indent=2))
        return 1
    render_specification(spec, template_path=template, destination_path=a.out, write_mode="replace_data",
                         profile=profile, overwrite=a.overwrite)
    post = validate_rendered_workbook(a.out, profile=profile)
    print(json.dumps({"output": a.out, "test_cases": len(cases), "preflight_warnings": len(pre) - len(errors),
                      "postflight": post["summary"]}, indent=2))
    return 1 if post["summary"]["errors"] else 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Codebeamer-format test specs and traceability")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("render"); p.set_defaults(fn=cmd_render)
    p.add_argument("--cases", required=True); p.add_argument("--out", required=True)
    p.add_argument("--template"); p.add_argument("--title"); p.add_argument("--overwrite", action="store_true")
    p = sub.add_parser("apply"); p.set_defaults(fn=cmd_apply)
    p.add_argument("--traced", required=True, help="the <spec>_traced.xlsx written by trace")
    p.add_argument("--rows", required=True, help="spec rows the user accepted, e.g. 3,7, or 'all'")
    p.add_argument("--out"); p.add_argument("--replace", action="store_true", help="also overwrite an existing Verifies")
    p = sub.add_parser("trace"); p.set_defaults(fn=cmd_trace)
    p.add_argument("--spec", required=True); p.add_argument("--req", action="append", required=True); p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
