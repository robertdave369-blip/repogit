"""Build a project's EDR record configuration from its diagnostic specification.

The `EDR_0455_045B` sheet of a customer diagnostic specification defines the event record
byte for byte: position, length, resolution, offset, unit and range. It is the only source
for that information - the DRBFM is not used here - so this builder reads nothing else.

An element is every row whose parameter name, once its `at <time> S` suffix is removed, is
the same. One row is a snapshot; several rows are the samples of a recording interval, and
their time suffixes give the interval.

Run with `--check` against a project that already has a configuration to confirm the
builder reproduces it before trusting its output for one that does not.

Offline only: reads a workbook, writes one Python file.

Usage:
    py -3.14 tools/build_edr_config_from_diag.py --project U171 --check
    py -3.14 tools/build_edr_config_from_diag.py --project M310_M314_M110
"""

from __future__ import annotations

import argparse
import importlib.util
import re
import sys
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]

# Bytes of positive response header (62 04 55) ahead of the specification's payload byte 0.
# read_edr_parameters indexes a response as data[n - 1], so specification byte b is n = b + 4.
RESPONSE_HEADER_OFFSET = 4

# The EDR parameter names are common to every project: an element is called the same in
# every edr_config and in every canc_config's EDR_Parameter, while the message and signal
# that carry it are each project's own. The names are U171's (user decision 2026-10-21);
# an element not listed here keeps its specification name, which both sheets share.
# 'spec_name' keeps the sheet's name either way. U171 also splits Event Date and Event
# Time over several entries, so those two are not renamed here.
# Two of these need a word: the sheet's "Battery Voltage" is the snapshot supply voltage
# the ECU measures itself, and its ZONAL_BATT_VOLT the CAN battery voltage over an
# interval, so the CAN one is named after its signal and the snapshot battery_voltage.
COMMON_ELEMENT_NAMES = {
    'ABS_ACTIVE_IEB':                         'ABS_ACTIVE',
    'Accelerator pedal, % full':              'ACC_PED',
    'AEB_WARNING_MSG':                        'AEB_WARNING_MSG1',
    'AES_SYS_STS':                            'AES_SYS_STS1',
    'AES_Warning':                            'AES_WARNING1',
    'Battery Voltage':                        'battery_voltage',
    'Brake switch status':                    'BRAKE_PEDAL_VALUE',
    'Clutch Status':                          'CLUTCH_STS',
    'Doors Open Status':                      'DoorsOpenStatus',
    'Driver Door Lock Status':                'Door Lock Status',
    'ELK_Oncoming_Warning':                   'ELK_ONCOMING_WARNING1',
    'ELK_Overtaking_Warning':                 'ELK_OVERTAKING_WARNING1',
    'ELK_SIDE_WARNING':                       'ELK_SIDE_WARNING1',
    'ENGINE SPEED':                           'Engine_Speed',
    'Engine State':                           'STS_ENG',
    'ESA_SYS_STS':                            'ESA_SYS_STS1',
    'ESC_ACTIVE_IEB':                         'ESC_ACTIVE',
    'Gear':                                   'GEAR_ACTUAL',
    'LC_PATH_STATE':                          'LC_PATH_STATE1',
    'LCF_SYS_STATE':                          'LCF_SYS_STATE1',
    'LDW_LKA_SYS_STATE':                      'LDW_LKA_SYS_STATE1',
    'LDW_LKA_WARNING':                        'LDW_LKA_WARNING1',
    'LKA_HANDSOFF_DISPLAY_WARNING':           'LKA_HANDSOFF_DISPLAY_WARNING1',
    'NP_SYS_STS':                             'NP_SYS_STS1',
    'RMS_MODE_STATE':                         'RMS_MODE_STATE1',
    'SPA_LCF_HANDSOFF_ WARNING':              'SPA_LCF_HANDS_OFF_WARNING1',
    'SPA_SYS_STATE':                          'SPA_SYS_STATE1',
    'STS_HIGHBEAM':                           'STS_HIGH_BEAM',
    'STS_LOWBEAM':                            'STS_LOW_BEAM',
    'Vehicle Speed Longitudinal':             'VehSpdLgt',
    'VehicleSpeed Longitudinal At Time Zero': 'VehSpdLgtAtTimeZero',
    'ZONAL_BATT_VOLT':                        'BATT_VOLT',
}

# Corrections to the diagnostic sheets, by the sheet's element name. Doors Open Status is
# six bits, one per door or closure (0..63), as the STS_DOOR signal is in the U171 and M314
# DBCs; the sheets give five bits, which cannot hold the RR door (32). User decision B4,
# 2026-10-22, and EDR_COMMON_GAPS.md.
# Payload byte 855 numbers its fields from bit 0 upwards (operation mode bit 0, DOMS bits
# 1-2, first-crash type bit 3, child-seat class from bit 4), the only reading without
# overlaps; the child-seat class is 4 bits, as its enum and MAX_VALUE (7) and the M314 DBC
# signal need. User, 2026-10-28; EDR_COMMON_PARAMETERS.md.
SHEET_CORRECTIONS: dict[str, dict[str, Any]] = {
    'Doors Open Status': {"data_bit_length": 6, "maximum": 63.0, "low_bit": 0},
    'DOMS Seat Belt Identification Status at T0': {"data_bit_length": 2, "maximum": 3.0, "low_bit": 1},
    'SRS_OCS_SUBSEAT_CLASSIFICATION at T0': {"data_bit_length": 4, "maximum": 7.0, "low_bit": 4},
}

PROJECTS: dict[str, dict[str, Any]] = {
    "U171": {
        "vehicle_class": "ICE",
        "workbook": REPOSITORY_ROOT / "docs" / "project_documents" / "Common Diag Spec"
                    / "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx",
        "source_label": "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx",
        "common_with": "M310_M314_M110",
    },
    "M310_M314_M110": {
        "vehicle_class": "EV",
        "workbook": REPOSITORY_ROOT / "docs" / "project_documents" / "M310"
                    / "Customer Diag Spec" / "M312_M112_M210_SRS_V2.7_DIAG_RE.xlsx",
        "source_label": "M312_M112_M210_SRS_V2.7_DIAG_RE.xlsx",
        "common_with": "U171",
    },
}

# The ICE and EV event records are one common EDR: the two specifications share all but
# two elements (Clutch Status and SRS TX SRS_OCS_PASS_CLASS_FAULT_STS are ICE only). Every
# configuration therefore lists every element of both, each entry saying which vehicle
# classes define it ('variants'), and a project runs scripts only for the elements that
# apply to it. An element the other class alone defines takes that class's definition.
#
# Where both classes define an element, this file holds its own specification's values:
# 32 shared elements differ between the two (deployment-time resolution 0.5 ms ICE /
# 1.0 ms EV, IMU offsets, the packing of SEB_WARNING_RIGHT / STS_LOWBEAM / STS_EBD, the
# byte of SRS ECU Status at T0, the ECALL_PWM_ACK_CRASH sample step).

RECORD_PREFIX = re.compile(r"^\s*Record\s*1\s*-\s*", re.IGNORECASE)
# The sheet writes a sample time as "at -5 S", "at -5.0 Sec" or "at 250 mS".
TIME_SUFFIX = re.compile(r"\s*at\s*([-+]?\d+(?:\.\d+)?)\s*(m?)s(?:ec)?\s*$", re.IGNORECASE)


def _text(value: Any) -> str:
    return "" if value is None else str(value)


def _number(value: Any) -> float | None:
    """A numeric cell, or None when the sheet holds prose or a formula it never evaluated."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    cleaned = re.sub(r"[^0-9.eE+-]", "", str(value))
    if cleaned in ("", "-", "+", ".", "e", "E"):
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def _element_name(raw: str) -> tuple[str, float | None]:
    """The element this row belongs to, and the sample time the row carries."""
    name = RECORD_PREFIX.sub("", raw)
    seconds: float | None = None
    match = TIME_SUFFIX.search(name)
    if match:
        seconds = float(match.group(1)) / (1000.0 if match.group(2) else 1.0)
        name = name[: match.start()]
    return re.sub(r"\s+", " ", name).strip(), seconds


def read_elements(workbook_path: Path) -> list[dict[str, Any]]:
    """Every Record 1 element, in the order the sheet introduces it."""
    import openpyxl

    workbook = openpyxl.load_workbook(workbook_path, data_only=True)
    sheet = workbook["EDR_0455_045B"]
    header = {_text(sheet.cell(1, column).value).strip(): column
              for column in range(1, sheet.max_column + 1)}

    def cell(row: int, name: str) -> Any:
        column = header.get(name)
        return sheet.cell(row, column).value if column else None

    grouped: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    # A bit-packed sample after the first in its byte leaves POS_IN_BYTES blank: the byte
    # is the one the row above started. Walking the sheet in order lets each such row
    # inherit it, which is also how the reserved fields are laid out.
    owning_byte: float | None = None
    for row in range(2, sheet.max_row + 1):
        raw = _text(cell(row, "PARAM_NAME"))
        if not raw.strip():
            continue
        # The sheet is the first record throughout - every row carries DID 0x0455 - and
        # fifty of its rows omit the "Record 1 - " prefix the rest carry, so the prefix is
        # stripped where present rather than used to decide what counts.
        name, seconds = _element_name(raw)
        if not name:
            continue
        position = _number(cell(row, "POS_IN_BYTES"))
        if position is not None:
            owning_byte = position
        entry = grouped.get(name)
        if entry is None:
            entry = grouped[name] = {"name": name, "rows": [], "repeated_rows": []}
            order.append(name)
        if seconds is not None and any(row["seconds"] == seconds for row in entry["rows"]):
            # The sheet lists the same sample twice: the ICE sheets repeat ECALL_PWM_ACK_CRASH
            # (-1 to +1 s) a second time in other bits of the same byte, overlapping the
            # first. The first set is the element - it is the one the EV sheet has alone.
            entry["repeated_rows"].append(row)
            continue
        entry["rows"].append({
            "row": row,
            "seconds": seconds,
            "pos_bytes": position if position is not None else owning_byte,
            "pos_bits": _number(cell(row, "POS_IN_BITS")),
            "len_bytes": _number(cell(row, "LEN_IN_BYTES")),
            "len_bits": _number(cell(row, "LEN_IN_BITS")),
            "offset": _number(cell(row, "OFFSET")),
            "resolution": _number(cell(row, "RESOLUTION")),
            "unit": _text(cell(row, "UNIT")).strip() or None,
            "minimum": _number(cell(row, "MIN_VALUE")),
            "maximum": _number(cell(row, "MAX_VALUE")),
        })
    return [grouped[name] for name in order]


def _first_bit_offset(rows: list[dict[str, Any]], width: int) -> int | None:
    """Bits between the top of the start byte and the first sample of a packed element.

    The samples are packed MSB first, one after another, but an element need not start at
    the top of its byte: M314 SEB_WARNING_RIGHT starts in bits 1..0 of the byte whose
    upper bits end SEB_WARNING_LEFT. The sheet's POS_IN_BITS is the field's high bit for
    some elements and its low bit for others, so the reading taken is the one under which
    every sample fits inside its byte and the samples follow each other without a gap.
    None when neither reading gives such a stream.
    """
    for reading in ("high", "low"):
        positions = []
        for row in rows:
            position = int(row["pos_bits"] or 0)
            high = position if reading == "high" else position + width - 1
            if high - width + 1 < 0 or high > 7 or row["pos_bytes"] is None:
                positions = None
                break
            positions.append(int(row["pos_bytes"]) * 8 + (7 - high))
        if positions and all(later - earlier == width
                             for earlier, later in zip(positions, positions[1:])):
            return positions[0] - int(rows[0]["pos_bytes"]) * 8
    return None


def build_entry(element: dict[str, Any]) -> dict[str, Any] | None:
    """One `EDR_PARAMETERS` entry, or None when the sheet gives it no byte position."""
    rows = element["rows"]
    first, last = rows[0], rows[-1]
    if first["pos_bytes"] is None:
        return None

    samples = len(rows)
    bytes_per_sample = int(first["len_bytes"]) if first["len_bytes"] else 1
    # A bit-packed field states its width in LEN_IN_BITS. The first row of such a group
    # usually also carries LEN_IN_BYTES = 1, naming the byte the packing starts in, so the
    # test is on the bit width itself: anything narrower than a byte is packed.
    sub_byte = first["len_bits"] is not None and int(first["len_bits"]) < 8
    bit_length = int(first["len_bits"]) if sub_byte else bytes_per_sample * 8

    start_byte = int(first["pos_bytes"]) + RESPONSE_HEADER_OFFSET
    end_byte = int(last["pos_bytes"]) + RESPONSE_HEADER_OFFSET
    if not sub_byte:
        end_byte += bytes_per_sample - 1

    if samples > 1:
        kind = "multi_sample_bits" if sub_byte else "multi_sample_bytes"
    elif sub_byte:
        kind = "bit" if bit_length == 1 else "bits"
    else:
        kind = "int"

    resolution = first["resolution"] if first["resolution"] is not None else 1.0
    offset = first["offset"] if first["offset"] is not None else 0.0
    minimum = first["minimum"]

    # The specification labels a field SIGNED inconsistently, so signedness is read off its
    # own arithmetic: the raw minimum is (MIN_VALUE - OFFSET) / RESOLUTION, and the raw is
    # two's complement exactly when that is negative.
    signed = False
    if minimum is not None and resolution:
        signed = ((minimum - offset) / resolution) < -1e-9

    entry: dict[str, Any] = {
        "name": element["name"],
        "type": kind,
        "data_start_byte": start_byte,
        "data_end_byte": end_byte,
        "data_byte_length": end_byte - start_byte + 1,
        "data_bit_length": bit_length,
        "data_bytes_per_sample": bytes_per_sample,
        "data_samples_number": samples,
        "signed": signed,
        "scaling_factor": float(resolution),
        "offset": float(offset),
        "unit": first["unit"],
        "minimum": minimum,
        "maximum": first["maximum"],
        "sample_range": None,
        "recording_model": "interval" if samples > 1 else "snapshot",
    }

    times = sorted(row["seconds"] for row in rows if row["seconds"] is not None)
    if samples > 1 and len(times) == samples:
        # The interval is taken from the sorted times: three elements list their samples
        # out of chronological order, and the bounds must not follow row order.
        step = round(times[1] - times[0], 6) if samples > 1 else 0.0
        entry["sample_range"] = {"start": times[0], "end": times[-1], "step": step}

    if kind == "multi_sample_bits":
        offset_bits = _first_bit_offset(rows, bit_length)
        if offset_bits:
            entry["data_first_bit_offset"] = offset_bits

    if kind in ("bit", "bits"):
        # POS_IN_BITS is the field's high bit, so the field runs down from it. A few rows
        # give 0 for a field several bits wide, where that reading is impossible; there the
        # position is the low bit and the field runs up.
        position = int(first["pos_bits"] or 0)
        low = position - bit_length + 1
        high = position
        if low < 0:
            low, high = position, position + bit_length - 1
        entry["range"] = (f"{start_byte}.{low}" if bit_length == 1
                          else f"{start_byte}.{low}-{start_byte}.{high}")

    correction = SHEET_CORRECTIONS.get(element["name"])
    if correction:
        low = correction.get("low_bit", 0)
        entry["data_bit_length"] = bit_length = correction["data_bit_length"]
        entry["maximum"] = correction["maximum"]
        entry["range"] = f"{start_byte}.{low}-{start_byte}.{low + bit_length - 1}"
    return entry


HEADER = '''"""
Module Configuration: EDR - {project}
============================================================

Location: projects/{project}/config/edr_config.py

Vehicle class: {vehicle_class}

GENERATED FILE - rebuild with:
    py -3.14 tools/build_edr_config_from_diag.py --project {project}

Source: docs/.../{source_label}, sheet EDR_0455_045B. That sheet is the only source for
byte position, length, resolution, offset and range; nothing here comes from the DRBFM.

Field meanings
--------------
  data_start_byte / data_end_byte  Byte span of the element, numbered the way
                                   read_edr_parameters indexes a diagnostic response:
                                   the specification's payload byte plus the three-byte
                                   positive response header, read as data[n - 1]. A whole
                                   record held as `payload` is therefore indexed
                                   payload[data_start_byte - 1].
  data_byte_length                 Bytes the element occupies in total.
  type                             How decodeParameterValues splits that span:
                                   multi_sample_bytes, multi_sample_bits, int, bits, bit.
  data_bit_length                  Width of one sample in bits.
  data_bytes_per_sample            Bytes consumed per sample, for byte-packed elements.
  data_samples_number              Samples stored; 1 for a snapshot element.
  data_first_bit_offset            multi_sample_bits only, and only where it is not 0:
                                   bits between the top of data_start_byte and the first
                                   sample, for an element packed on from the one before
                                   it within a shared byte.
  range                            Sub-byte field position, for the bit and bits types.
  signed                           Raw sample is two's complement. Derived from the
                                   specification's own arithmetic rather than its
                                   DATA_TYPE label: the raw minimum is
                                   (MIN_VALUE - OFFSET) / RESOLUTION, and the raw is
                                   signed when that is negative.
  scaling_factor / offset          physical = raw * scaling_factor + offset.
  minimum / maximum                Physical range as stated by the specification.
  unit                             Unit as stated by the specification.
  sample_range                     start/end/step in seconds relative to T0. None means
                                   the element has no recording interval.
  recording_model                  interval or snapshot.
  spec_name                        The element's name in the diagnostic specification,
                                   the same in every project; 'name' is what this
                                   project's scripts look the element up by.
  variants                         Vehicle classes whose specification defines the
                                   element (ICE, EV). The record is common to both, so
                                   every element of either is listed; an element this
                                   class does not define records the deconfigured value
                                   here, and no script of this project reads it.

Deconfigured and reserved encoding
----------------------------------
An element that does not apply to this variant records all ones (0xFF per byte) across
its allocation. A reserved bit or byte records 0x00.
"""

PROJECT_NAME = "{project}"
MODULE_NAME = "EDR"
VEHICLE_CLASS = "{vehicle_class}"

# Bytes of positive response header (62 04 55) ahead of the specification's payload
# byte 0. Recorded for reference only: every byte number in this file already includes
# it, so nothing downstream needs to add it.
RESPONSE_HEADER_BYTES = 3

# Event record DIDs. Both records share the layout below.
EDR_DIDS = {{
    "EDR_EVENT_1": 0x0455,
    "EDR_EVENT_2": 0x045B,
}}

# The same records in the order a test reads them, as the four-digit strings
# read_edr_parameters expects. Test scripts take their record list from here, so a DID
# that changes is a configuration edit and no script has to be touched.
EDR_RECORD_DIDS = tuple(f"{{did:04X}}" for did in EDR_DIDS.values())

# Maximum delay from IGN OFF to the crash-trigger call for the housekeeping cases.
HOUSEKEEPING_CRASH_TRIGGER_MAX_DELAY_MS = 50

# Value recorded for an element that is not configured on this variant, per byte.
DECONFIGURED_BYTE_VALUE = 0xFF
# Value recorded for a reserved bit or byte.
RESERVED_BYTE_VALUE = 0x00

EDR_PARAMETERS = [
'''

FOOTER = ''']

EDR_PARAMETERS_BY_NAME = {{parameter["name"]: parameter for parameter in EDR_PARAMETERS}}

# Reserved fields, which record 0x00. Byte numbers use the same indexing as
# data_start_byte, so a whole record read as `payload` is checked at payload[byte - 1].
RESERVED_ALLOCATIONS = [
{reserved}]

# Elements that record across an interval, so they support pre-crash and post-crash cases.
INTERVAL_PARAMETERS = [
    p["name"] for p in EDR_PARAMETERS if p["sample_range"] is not None
]

# Elements recorded as a single snapshot, verified by repeating the case per value.
SNAPSHOT_PARAMETERS = [p["name"] for p in EDR_PARAMETERS if p["sample_range"] is None]

# How the shared EDR decoder (get_edr_parameters / read_edr_parameters) reads the record.
# Both specifications give DID 0x0455 the same access (sheet ECUIdentifiers: read, no
# write, security level L1), so this is the same block in every project.
EDR_DECODER_CONFIG = {{
    "parameter_definitions_symbol": "EDR_PARAMETERS",
    "read": {{
        "service": "22",
        "default_did": f"{{EDR_DIDS['EDR_EVENT_1']:04X}}",
        "did_hex_length": 4,
        "prepare_session": True,
        "security_access_level": 0x01,
        "response_header_bytes": RESPONSE_HEADER_BYTES,
        "parameter_byte_index_offset": -1,
        "positive_response_prefix": ["62"],
        "record_ready_wait_ms": 5000,
    }},
}}


def get_sample_range(parameter_name: str) -> dict | None:
    """Recording interval for an element, or None when it has no interval."""
    parameter = EDR_PARAMETERS_BY_NAME.get(parameter_name)
    return None if parameter is None else parameter["sample_range"]


def get_sample_interval_ms(parameter_name: str, default_ms: int = 500) -> int:
    """Spacing between recorded samples, in milliseconds."""
    sample_range = get_sample_range(parameter_name)
    if not sample_range:
        return default_ms
    return int(round(float(sample_range["step"]) * 1000))


# The squib deployment status bits as (label, byte, bit) - the same table in every
# project's edr_config, derived from the Squib_Deployment_Status entry above (byte
# numbers as data_start_byte).
SQUIB_DEPLOYMENT_LABELS = [
    (label, int(field.split(".")[0]), int(field.split(".")[1]))
    for label, field in zip(EDR_PARAMETERS_BY_NAME["Squib_Deployment_Status"]["labels"],
                            EDR_PARAMETERS_BY_NAME["Squib_Deployment_Status"]["range"])
]
{carried}'''

FIELD_ORDER = [
    "name", "spec_name", "type", "data_start_byte", "data_end_byte", "data_byte_length",
    "data_bit_length", "data_bytes_per_sample", "data_samples_number",
    "data_first_bit_offset", "signed",
    "scaling_factor", "offset", "unit", "minimum", "maximum", "sample_range",
    "recording_model", "range", "labels", "variants",
]


RESERVED_NAME = re.compile(r"^reserved\b", re.IGNORECASE)

# Definitions that are not derivable from the sheet and must survive a rebuild. They are
# copied verbatim out of the file being replaced.
CARRIED_SYMBOLS = ("CRASH_LOCATION_BITS",)

# The squib deployment status bits read together, each with the label the decoder and the
# reports use - the labels of Z121's edr_config (the up-to-date set, user 2026-10-20),
# which apply to every project on the common record. Driver-side squibs are the right-hand
# ones. The bit of each comes from the project's own sheet.
SQUIB_DEPLOYMENT_GROUP = "Squib_Deployment_Status"
SQUIB_DEPLOYMENT_LABEL_OF = {
    "Driver Airbag squib - Deployment Status": "Driver Airbag",
    "Passenger Airbag squib - Deployment Status": "Passenger Airbag",
    "Driver Pre-tensioner -1 Squib(Belt) - Deployment Status": "Right pretensioner",
    "Passenger Pre-tensioner -1 Squib(Belt) - Deployment Status": "Left pretensioner",
    "Driver Pre-tensioner -2 Squib(Lap) - Deployment Status": "Right lap pretensioner",
    "Passenger Pre-tensioner -2 Squib(Lap) - Deployment Status": "Left lap pretensioner",
    "Driver Side Airbag - Deployment Status": "Right Side airbag",
    "Passenger Side Airbag - Deployment Status": "Left Side airbag",
    "Driver Curtain Airbag - Deployment Status": "Right curtain airbag",
    "Passenger Curtain Airbag - Deployment Status": "Left Curtain airbag",
    "Driver Knee Airbag - Deployment Status": "Driver Knee Airbag",
    "Center airbag - Deployment Status": "Center airbag",
}


def squib_deployment_entry(entries: list[dict[str, Any]]) -> dict[str, Any]:
    """The Squib_Deployment_Status entry: the labelled status bits as one custom_bits field."""
    by_name = {entry["spec_name"]: entry for entry in entries}
    missing = [name for name in SQUIB_DEPLOYMENT_LABEL_OF if name not in by_name]
    if missing:
        raise SystemExit(f"the sheet has no squib deployment element {missing}")
    members = [by_name[name] for name in SQUIB_DEPLOYMENT_LABEL_OF]
    bits = [member["range"] for member in members]
    start = min(member["data_start_byte"] for member in members)
    end = max(member["data_end_byte"] for member in members)
    variants = sorted({v for member in members for v in member["variants"]},
                      key=["ICE", "EV"].index)
    return {
        "name": SQUIB_DEPLOYMENT_GROUP, "spec_name": list(SQUIB_DEPLOYMENT_LABEL_OF),
        "type": "custom_bits", "data_start_byte": start, "data_end_byte": end,
        "data_byte_length": end - start + 1, "data_bit_length": len(bits),
        "data_bytes_per_sample": end - start + 1, "data_samples_number": 1, "signed": False,
        "scaling_factor": 1, "offset": 0, "unit": None, "minimum": None, "maximum": None,
        "sample_range": None, "recording_model": "snapshot", "range": bits,
        "labels": list(SQUIB_DEPLOYMENT_LABEL_OF.values()), "variants": variants,
        "_comment": ["The squib deployment status bits read as one field, each with its label",
                     "(the labels of Z121's edr_config). SQUIB_DEPLOYMENT_LABELS below is derived",
                     "from this entry."],
    }


def _reserved_allocations(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The reserved bits and bytes, which record 0x00.

    They are held apart from EDR_PARAMETERS because they are not elements a test reads by
    name; the whole-record check walks this list instead.
    """
    allocations = []
    for element in elements:
        if not RESERVED_NAME.match(element["name"]):
            continue
        for row in element["rows"]:
            if row["pos_bytes"] is None:
                continue
            byte = int(row["pos_bytes"]) + RESPONSE_HEADER_OFFSET
            width = int(row["len_bits"]) if row["len_bits"] else 8
            length = int(row["len_bytes"]) if row["len_bytes"] else 1
            high = int(row["pos_bits"]) if row["pos_bits"] is not None else 7
            low = high - width + 1
            if low < 0:
                low, high = high, high + width - 1
            allocations.append({"data_byte": byte, "high_bit": high, "low_bit": low,
                                "byte_length": length})
    return allocations


def carried_definitions(project: str) -> str:
    """Top-level assignments copied verbatim out of the configuration being replaced."""
    import ast

    path = REPOSITORY_ROOT / "projects" / project / "config" / "edr_config.py"
    if not path.is_file():
        return ""
    source = path.read_text(encoding="utf-8")
    lines = source.splitlines()
    blocks = []
    for node in ast.parse(source).body:
        if not isinstance(node, ast.Assign):
            continue
        names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        if any(name in CARRIED_SYMBOLS for name in names):
            blocks.append("\n".join(lines[node.lineno - 1:node.end_lineno]))
    if not blocks:
        return ""
    return ("\n\n# Carried over from the configuration this file replaces: the diagnostic\n"
            "# specification sheet does not state these, so a rebuild must not drop them.\n"
            + "\n\n".join(blocks) + "\n")


def render(entries: list[dict[str, Any]], elements: list[dict[str, Any]],
           project: str, other_entries: list[dict[str, Any]] | None = None) -> str:
    settings = PROJECTS[project]
    body = []

    def add(entry: dict[str, Any]) -> None:
        for line in entry.get("_comment", ()):
            body.append(f"    # {line}" if line else "    #")
        body.append("    {")
        for field in FIELD_ORDER:
            if field not in entry:
                continue
            body.append(f"        {field!r}: {entry[field]!r},")
        body.append("    },")

    for entry in entries:
        add(entry)
    if other_entries:
        other = PROJECTS[settings["common_with"]]
        body.append("")
        body.append(f"    # -- Elements only {other['vehicle_class']} defines "
                    + "-" * (58 - len(other["vehicle_class"])))
        body.append(f"    # The common record also carries these, defined by "
                    f"{other['source_label']}.")
        body.append(f"    # {settings['vehicle_class']} never feeds them and no "
                    f"{settings['vehicle_class']} script reads them. Bytes no "
                    f"{settings['vehicle_class']} element")
        body.append(f"    # uses record the deconfigured value; where "
                    f"{settings['vehicle_class']} uses the same bytes, a note says which.")
        for entry in other_entries:
            add(entry)
    reserved = "".join(f"    {allocation!r},\n"
                       for allocation in _reserved_allocations(elements))
    return (HEADER.format(project=project, vehicle_class=settings["vehicle_class"],
                          source_label=settings["source_label"])
            + "\n".join(body) + "\n"
            + FOOTER.format(reserved=reserved, carried=carried_definitions(project)))


def project_entries(project: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]],
                                           list[dict[str, Any]], int]:
    """This project's entries, the other class's own elements, all sheet elements, skips.

    Every entry carries 'spec_name' (the sheet's element name, before any project rename)
    and 'variants' (the vehicle classes whose sheet defines an element of that name).
    """
    settings = PROJECTS[project]
    other_project = settings["common_with"]
    other = PROJECTS[other_project]
    elements = read_elements(settings["workbook"])
    other_elements = read_elements(other["workbook"])
    own_names = {element["name"] for element in elements}
    other_names = {element["name"] for element in other_elements}

    def variants(name: str) -> list[str]:
        return [settings["vehicle_class"]] * (name in own_names) \
            + [other["vehicle_class"]] * (name in other_names)

    def entries_of(source: list[dict[str, Any]], renames: dict[str, str]) -> tuple[list, int]:
        named = [element for element in source if not RESERVED_NAME.match(element["name"])]
        built = []
        for element in named:
            entry = build_entry(element)
            if entry is None:
                continue
            entry["spec_name"] = element["name"]
            entry["name"] = renames.get(element["name"], element["name"])
            entry["variants"] = sorted(variants(element["name"]), key=["ICE", "EV"].index)
            built.append(entry)
        return built, len(named) - len(built)

    entries, skipped = entries_of(elements, COMMON_ELEMENT_NAMES)
    entries.append(squib_deployment_entry(entries))
    only_other = [element for element in other_elements if element["name"] not in own_names]
    other_entries, _ = entries_of(only_other, COMMON_ELEMENT_NAMES)
    own_bytes = {}
    for entry in entries:
        for byte in range(entry["data_start_byte"], entry["data_end_byte"] + 1):
            own_bytes.setdefault(byte, []).append(entry["name"])
    for entry in other_entries:
        shared = sorted({name for byte in range(entry["data_start_byte"],
                                                entry["data_end_byte"] + 1)
                         for name in own_bytes.get(byte, [])})
        if shared:
            entry["_comment"] = [f"{other['vehicle_class']} only. On {settings['vehicle_class']} "
                                 f"these bytes hold {', '.join(shared)}."]
    return entries, other_entries, elements, skipped


def load_existing(project: str) -> dict[str, Any] | None:
    path = REPOSITORY_ROOT / "projects" / project / "config" / "edr_config.py"
    if not path.is_file():
        return None
    spec = importlib.util.spec_from_file_location(f"_{project}_edr", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return getattr(module, "EDR_PARAMETERS_BY_NAME", None)


def check(entries: list[dict[str, Any]], project: str) -> int:
    existing = load_existing(project)
    if not existing:
        print(f"{project} has no existing configuration to check against.")
        return 1
    built = {entry["name"]: entry for entry in entries}
    compared = ["data_start_byte", "data_end_byte", "data_byte_length", "data_bit_length",
                "data_bytes_per_sample", "data_samples_number", "data_first_bit_offset",
                "signed",
                "scaling_factor", "offset", "unit", "sample_range", "recording_model",
                "type", "range", "spec_name", "variants"]
    only_existing = sorted(set(existing) - set(built))
    only_built = sorted(set(built) - set(existing))
    differing = []
    for name in sorted(set(existing) & set(built)):
        for field in compared:
            was, now = existing[name].get(field), built[name].get(field)
            if was != now:
                differing.append((name, field, was, now))
    print(f"{project}: built {len(built)}, existing {len(existing)}, "
          f"shared {len(set(existing) & set(built))}")
    for name in only_existing:
        print(f"  only in the existing configuration: {name}")
    for name in only_built:
        print(f"  only in the built configuration   : {name}")
    for name, field, was, now in differing:
        print(f"  {name}: {field} existing={was!r} built={now!r}")
    total = len(only_existing) + len(only_built) + len(differing)
    print(f"  {total} difference(s)")
    return 0 if total == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, choices=sorted(PROJECTS))
    parser.add_argument("--check", action="store_true",
                        help="compare with the project's existing configuration, write nothing")
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()

    entries, other_entries, elements, skipped = project_entries(arguments.project)

    if arguments.check:
        return check(entries + other_entries, arguments.project)

    output = arguments.output or (
        REPOSITORY_ROOT / "projects" / arguments.project / "config" / "edr_config.py")
    output.write_text(render(entries, elements, arguments.project, other_entries),
                      encoding="utf-8")
    print(f"Wrote {output}")
    print(f"  {len(entries)} element(s)"
          + (f", {skipped} skipped for having no byte position" if skipped else "")
          + f", plus {len(other_entries)} the other vehicle class alone defines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
