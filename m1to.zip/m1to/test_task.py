"""Mechanical steps of the test-execution pipeline (.github/agents/test-execution-pipeline.agent.md).

One task = one campaign folder test_campaigns/<project>/<YYYYMMDD>_<task>/ (git-ignored):
    manifest.json                 task, sources, attempts, corrections, package, PTC target
    inputs/cb/<id>.json           raw Codebeamer item + relations (read-only), inputs/cb/index.json
    inputs/oem/                   OEM level-10 spec copies or extracts
    analysis/                     agent-written alignment, source review; script_map.json, risk.json
    testcases/<task>_testcases.xlsx + original.json   Excel copy of the CB test cases for editing
    runs/<n>/                     <tc>.console.txt + results.json per attempt
    triage/attempt<n>.json        failure evidence; decisions.json = the agent's verdicts
    package/                      <test case name>.html / .txt / .console.txt + summary.csv
    bugs.xlsx, bugs.md, issues.md

    py -3.14 tools/test_task.py setup            check + auto-install the Python requirements
    py -3.14 tools/test_task.py init --project M310_M314_M110 --task "<task id or title>" [...]
    py -3.14 tools/test_task.py <command> <campaign folder> ...
Commands: setup, init, finish, findings, add-tc, note, cb-fetch, tc-workbook, tc-diff, map, risk, plan, run, collect, triage-scan, bugs,
backup-script, zip, ptc-request. `run` needs --apply (it drives the bench); `zip` and
`ptc-request` refuse without every path and name the user gave. Judgement (alignment, triage,
corrections) stays with the agent; this tool only does what must be repeatable.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
CB_CLI = REPO / ".github" / "skills" / "code-beamer" / "scripts" / "codebeamer_cli.py"
CB_REQUIREMENTS = CB_CLI.parents[1] / "requirements.txt"
CAMPAIGNS = REPO / "test_campaigns"
REPORT_LINE = re.compile(r"\[create_report_and_logging\].*?report=(?P<report>.+?\.html), log=(?P<log>.+?\.txt)")
VERDICT = re.compile(r"<!--(PASSED|FAILED)-->\s*$")
# Signatures that point at the bench or the tool chain rather than the ECU (aria-bench §21).
BENCH_HINTS = re.compile(r"Connection to Aria failed|No available aria host|Multiple aria instances|Api level \d+ not supported|"
                         r"Power card not found|There are no rsu cards|There is no rsu function|not found in configuration|"
                         r"Connection to aria was lost|Request failed|channel .{0,40} not found|ConnectionRefused|TimeoutError", re.I)
SCRIPT_HINTS = re.compile(r"^(\w+\.)*(NameError|ImportError|ModuleNotFoundError|AttributeError|KeyError|TypeError|"
                          r"SyntaxError|IndexError|ValueError|UnboundLocalError|ZeroDivisionError)\b.*$", re.M)
# Operations that change the ECU permanently or deploy; listed for the user before a run (aria-bench §0).
RISKS = {
    "flash": r"\b(flash|Flashing|winidea|WinIDEA|memtool|Memtool|Download\(|\.s37|\.hex\b)",
    "nvm/eol/vin/variant write": r"\b(WriteDataByIdentifier|NVM|EOL|VIN|Variant_?Code|WriteDID|0x2E\b|\"2E)",
    "routine control": r"\b(RoutineControl|0x31\b|\"31 0)",
    "security access": r"(SecurityAccess|Security_Access|security_access|\b0x27\b|\"27 )",
    "crash trigger / deployment": r"\b(set_trigger|SetTrigger|TriggerMain|TRIGGER_MAIN|Trigger\(|deploy)",
    "ecu reset": r"\b(ECUReset|EcuReset|0x11\b|\"11 0)",
    "dtc memory cleared": r"(Clear_DTC|ClearDTC|ClearDiagnosticInformation|\b0x14\b|\"14 FF)",
    "io-control override (outputs forced)": r"(IOControl|IO_Control|InputOutputControl|_2F_|\b0x2F\b|\"2F )",
}
# A pattern scan only: the agent still reads every mapped script (pipeline S6/S7).


def safe_name(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1F]+', "_", str(value or "").strip())
    return re.sub(r"\s+", "_", value).strip(" ._")[:120] or "unnamed"


def load(path: Path, default: Any = None) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.is_file() else default


def save(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def campaign(arg: str) -> Path:
    root = Path(arg).resolve()
    if not (root / "manifest.json").is_file():
        raise SystemExit(f"not a campaign folder (no manifest.json): {root}")
    return root


def ids(text: str | None) -> list[str]:
    return [t for t in re.split(r"[,\s]+", text or "") if t]


def cmd_init(a: argparse.Namespace) -> int:
    known = sorted(p.name for p in (REPO / "projects").iterdir() if p.is_dir() and not p.name.startswith("_"))
    if a.project not in known and a.pipeline == "test":  # bench runs need the project's scripts and config
        raise SystemExit(f"unknown project {a.project}; projects: {known}")
    root = CAMPAIGNS / a.project / f"{dt.date.today():%Y%m%d}_{safe_name(a.task)[:60]}"
    inputs = bench_inputs(a)
    if (root / "manifest.json").exists():
        print(f"campaign exists, reusing: {root}")
        man = load(root / "manifest.json")
        if a.aria_config or any(inputs.values()):  # the user changed the bench files: keep what they named now
            man["aria_config"] = a.aria_config or man.get("aria_config")
            man["bench_inputs"] = {k: v or (man.get("bench_inputs") or {}).get(k) for k, v in inputs.items()}
            save(root / "manifest.json", man)
        keep_awake("start", root, a.keep_awake_hours)
        return 0
    for sub in ("inputs/cb", "inputs/oem", "analysis", "testcases", "runs", "triage", "package", "review"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    save(root / "manifest.json", {
        "pipeline": a.pipeline,
        "task": a.task, "project": a.project, "created": dt.datetime.now().isoformat(timespec="seconds"),
        "task_source": a.task_source, "cb": {"requirements": ids(a.cb_req), "test_cases": ids(a.cb_tc)},
        "oem_spec": a.oem_spec, "source_dir": a.source_dir, "aria_dir": a.aria_dir, "aria_config": a.aria_config,
        "bench_inputs": inputs,
        "gaps": [g for g, missing in (("no OEM L10 spec", not a.oem_spec), ("no ECU source review", not a.source_dir)) if missing],
        "attempts": [], "corrections": [], "zip": None, "ptc": None})
    if a.manager_file:  # the manager's instructions, verbatim: the task definition when Codebeamer lags
        shutil.copy2(a.manager_file, root / "inputs" / "manager_task.md")
    (root / "issues.md").write_text(f"# Issue log — {a.task} ({a.project})\n\n", encoding="utf-8")
    keep_awake("start", root, a.keep_awake_hours)
    print(root)
    return 0


def bench_inputs(a: argparse.Namespace) -> dict:
    """The ARIA files the user named for this task; `run` checks ARIA against them (aria_ctl check-inputs)."""
    out = {"dbc": [str(Path(d).resolve()) for d in a.dbc or []],
           "rsu_workbook": str(Path(a.rsu_workbook).resolve()) if a.rsu_workbook else None,
           "loadbox_profile": str(Path(a.loadbox_profile).resolve()) if a.loadbox_profile else None}
    missing = [f for f in [*out["dbc"], out["rsu_workbook"], out["loadbox_profile"], a.aria_config] if f and not Path(f).is_file()]
    if missing:
        raise SystemExit(f"file(s) not found: {missing}")
    return out


def keep_awake(action: str, root: Path, hours: float = 12) -> None:
    """Hold the PC awake and online for this task (tools/keep_awake.py); hours <= 0 skips it."""
    if action == "start" and hours <= 0:
        return
    extra = ["--hours", str(hours)] if action == "start" else []
    out = subprocess.run([sys.executable, str(REPO / "tools" / "keep_awake.py"), action, "--task", root.name, *extra],
                         capture_output=True, text=True)
    if out.returncode:
        print(f"keep-awake {action} failed: {out.stderr.strip()[-300:]}", file=sys.stderr)
    else:
        warnings = (json.loads(out.stdout).get("warnings") if action == "start" and out.stdout.strip().startswith("{") else None) or []
        for w in warnings:
            print(f"keep-awake: {w}", file=sys.stderr)


def cmd_finish(a: argparse.Namespace) -> int:
    """End of a task: release the keep-awake hold and mark the manifest."""
    root = campaign(a.campaign)
    keep_awake("stop", root)
    man = load(root / "manifest.json")
    man["finished"] = dt.datetime.now().isoformat(timespec="seconds")
    save(root / "manifest.json", man)
    print(f"finished {root.name}; keep-awake released")
    return 0


def pip_install(*spec: str) -> None:
    """Install into this interpreter what the pipeline needs; the user asked for it to happen automatically."""
    print(f"installing {' '.join(spec)} into {sys.executable} ...", file=sys.stderr)
    out = subprocess.run([sys.executable, "-m", "pip", "install", *spec], capture_output=True, text=True)
    if out.returncode:
        raise SystemExit(f"pip install {' '.join(spec)} failed (network or proxy?):\n{out.stderr.strip()[-800:]}")


def cb(*args: str) -> object:
    """Read-only Codebeamer call through the code-beamer skill CLI (its .env holds the credentials)."""
    for first_try in (True, False):
        out = subprocess.run([sys.executable, str(CB_CLI), *args], capture_output=True, text=True)
        if out.returncode and first_try and "No module named" in out.stderr + out.stdout:
            pip_install("-r", str(CB_REQUIREMENTS))  # the CLI's own requirements.txt, then one retry
            continue
        break
    if out.returncode:
        raise SystemExit(f"codebeamer_cli {' '.join(args)} failed:\n{out.stderr.strip() or out.stdout.strip()}")
    return json.loads(out.stdout)


SKILLS = REPO / ".github" / "skills"
# What each pipeline installs (pip requirement files of the skills it drives, or package names).
PIPELINE_NEEDS = {
    "test": [CB_REQUIREMENTS, "openpyxl"],
    "req-review": [CB_REQUIREMENTS, SKILLS / "veoneer-test-spec-generator" / "requirements.txt"],
    "tc-writer": [CB_REQUIREMENTS, SKILLS / "veoneer-test-spec-generator" / "requirements.txt"],
    "tc-review": [CB_REQUIREMENTS, SKILLS / "veoneer-test-spec-generator" / "requirements.txt"],
    "report-review": [SKILLS / "veoneer-test-spec-generator" / "requirements.txt", "python-can"],
}


def cmd_setup(a: argparse.Namespace) -> int:
    """Install (pip) and check everything a pipeline needs in this interpreter."""
    report = []
    for need in PIPELINE_NEEDS[a.pipeline]:
        spec = ["-r", str(need)] if isinstance(need, Path) else [need]
        label = str(need.relative_to(REPO)) if isinstance(need, Path) else need
        out = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", *spec],
                             capture_output=True, text=True)  # already-satisfied requirements cost no download
        report.append((f"pip {label}", out.returncode == 0, "" if out.returncode == 0 else out.stderr.strip()[-200:]))
    if a.pipeline != "report-review":
        env = CB_CLI.parents[1] / ".env"
        report.append(("code-beamer credentials file", env.is_file(),
                       "" if env.is_file() else f"create {env.relative_to(REPO)} from .env.example (the user, never in chat)"))
    if a.pipeline == "test":
        apym = subprocess.run([sys.executable, "-B", "-c", "import sys; sys.path.insert(0, sys.argv[1]); "
                               "from shared_libraries.apym_imports import ensure_apym_on_path as e; e(); import apym; print(apym.__file__)",
                               str(REPO)], capture_output=True, text=True)
        report.append(("apym (ARIA Python API)", apym.returncode == 0, apym.stdout.strip() or
                       "not found: it comes with ARIA (<install>\\pymodules); installing it is the user's decision"))
    if a.online:
        ok = subprocess.run([sys.executable, str(CB_CLI), "validate"], capture_output=True, text=True)
        report.append(("code-beamer login (online)", ok.returncode == 0, (ok.stdout or ok.stderr).strip()[:200]))
    for name, ok, note in report:
        print(f"{'OK     ' if ok else 'MISSING'} {name:<32} {note}")
    return 0 if all(ok for _, ok, _ in report) else 1


def related_ids(relations: object, own: str) -> list[str]:
    """Every referenced item id in a relations payload, whatever its exact shape."""
    found: list[str] = []

    def walk(o: object) -> None:
        if isinstance(o, dict):
            for k in ("itemRevision", "item", "target", "source", "to", "from"):
                v = o.get(k)
                if isinstance(v, dict) and str(v.get("id", "")) not in ("", own) and str(v["id"]) not in found:
                    found.append(str(v["id"]))
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    walk(relations)
    return found


def cmd_cb_fetch(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    index = load(root / "inputs/cb/index.json", {})
    todo = [(i, "requested") for i in ids(a.items)]
    if a.tracker:  # a whole tracker (optionally one status): every item becomes a requested item
        listed = cb("list-item-details", "--tracker-id", a.tracker, *(["--status", a.status] if a.status else []))
        items = listed if isinstance(listed, list) else listed.get("items", []) if isinstance(listed, dict) else []
        todo += [(str(i["id"]), "requested") for i in items if isinstance(i, dict) and i.get("id")]
        print(f"tracker {a.tracker}: {len(items)} items{' with status ' + a.status if a.status else ''}", file=sys.stderr)
    if not todo:
        raise SystemExit("nothing to fetch: pass --items and/or --tracker")
    seen = set(index)
    while todo:
        item_id, via = todo.pop(0)
        if item_id in seen and via != "requested":
            continue
        item = cb("get-item", "--item-id", item_id)
        rel = cb("get-item-relations", "--item-id", item_id)
        save(root / f"inputs/cb/{item_id}.json", {"item": item, "relations": rel})
        tracker = item.get("tracker") or {}
        links = related_ids(rel, item_id)
        index[item_id] = {"name": item.get("name"), "status": (item.get("status") or {}).get("name"),
                          "tracker_id": tracker.get("id"), "tracker": tracker.get("name"), "via": via, "related": links}
        seen.add(item_id)
        if a.follow and via == "requested":
            todo += [(r, f"related to {item_id}") for r in links if r not in seen]
    save(root / "inputs/cb/index.json", index)
    for k, v in index.items():
        print(f"{k:>10}  {v['tracker'] or '?':<28} {v['status'] or '?':<14} {v['name']}  ({v['via']}; related {len(v['related'])})")
    return 0


def cmd_add_tc(a: argparse.Namespace) -> int:
    """Register a test case that is not (yet) in Codebeamer, e.g. from the manager's instructions."""
    root = campaign(a.campaign)
    index = load(root / "inputs/cb/index.json", {})
    index[a.id] = {"name": a.name, "status": "not in Codebeamer", "tracker_id": None, "tracker": "Test Cases (manager)",
                   "via": a.source, "related": ids(a.requirements)}
    save(root / "inputs/cb/index.json", index)
    print(f"{a.id}: {a.name} (source: {a.source})")
    return 0


def flat(value: object) -> str:
    if isinstance(value, dict):
        return str(value.get("name") or value.get("value") or json.dumps(value, ensure_ascii=False))
    if isinstance(value, list):
        return "\n".join(" | ".join(flat(c) for c in v) if isinstance(v, list) else flat(v) for v in value)
    return "" if value is None else str(value)


def tc_row(item_id: str, data: dict, index: dict) -> dict[str, str]:
    item = data["item"]
    row = {"CB ID": item_id, "Name": item.get("name", ""), "Status": flat(item.get("status")),
           "Tracker": flat(item.get("tracker")), "Related items": ", ".join(index.get(item_id, {}).get("related", [])),
           "Description": flat(item.get("description"))}
    for f in item.get("customFields") or []:
        values = f.get("values", f.get("value"))
        refs = [v["id"] for v in values if isinstance(v, dict) and v.get("id")] if isinstance(values, list) else []
        # A Verifies reference field is written as the Codebeamer export does, so spec_trace can trace this copy.
        # shortcut: field shape taken from the Codebeamer REST item JSON, not yet seen live; other shapes stay flat()
        row[str(f.get("name"))] = (",".join(f"[ISSUE:{i}] - null" for i in refs)
                                   if refs and str(f.get("name")).strip().lower() == "verifies" else flat(values))
    return row


def cmd_tc_workbook(a: argparse.Namespace) -> int:
    try:
        import openpyxl
    except ImportError:
        raise SystemExit('openpyxl missing: run with  py -3.14')
    root = campaign(a.campaign)
    index = load(root / "inputs/cb/index.json", {})
    wanted = ids(a.ids) or [k for k, v in index.items() if "test" in str(v.get("tracker", "")).lower()]
    if not wanted:
        raise SystemExit("no test-case items: pass --ids or fetch the test cases first")
    def data(i: str) -> dict:  # a manager test case (add-tc) has no Codebeamer item yet
        e = index.get(i, {})
        return load(root / f"inputs/cb/{i}.json") or {"item": {"name": e.get("name", ""), "status": {"name": e.get("status")},
                                                               "tracker": {"name": e.get("tracker")}}}
    rows = [tc_row(i, data(i), index) for i in wanted]
    cols = list(dict.fromkeys(["CB ID", "Name", "Status", "Tracker", "Related items", "Description"]
                              + [c for r in rows for c in r] + ["Script", "Review notes"]))
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "TestCases"
    ws.append(cols)
    smap = load(root / "analysis/script_map.json", {})
    for r in rows:
        r.setdefault("Script", (smap.get(r["CB ID"]) or {}).get("script", ""))
        ws.append([r.get(c, "") for c in cols])
    ws.freeze_panes = "C2"
    out = root / "testcases" / f"{safe_name(load(root / 'manifest.json')['task'])[:60]}_testcases.xlsx"
    wb.save(out)
    save(root / "testcases/original.json", {r["CB ID"]: r for r in rows})
    print(f"{len(rows)} test cases -> {out}  (edit here; Codebeamer is updated only after the user reviews tc-diff)")
    return 0


def cmd_tc_diff(a: argparse.Namespace) -> int:
    import openpyxl
    root = campaign(a.campaign)
    original = load(root / "testcases/original.json", {})
    book = next((root / "testcases").glob("*_testcases.xlsx"))
    ws = openpyxl.load_workbook(book, data_only=True)["TestCases"]
    head = [c.value for c in ws[1]]
    changes = {}
    for values in ws.iter_rows(min_row=2, values_only=True):
        row = {h: ("" if v is None else str(v)) for h, v in zip(head, values)}
        before = original.get(row.get("CB ID"), {})
        diff = {k: {"before": before.get(k, ""), "after": v} for k, v in row.items()
                if k not in ("Script", "Review notes") and v != before.get(k, "")}
        if diff:
            changes[row["CB ID"]] = {"name": row.get("Name"), "fields": diff, "notes": row.get("Review notes", "")}
    save(root / "testcases/changes.json", changes)
    lines = [f"# Test-case changes for review ({len(changes)} items)", "",
             "Nothing is written to Codebeamer from here. After the user approves, build full-item payloads",
             "with the code-beamer skill (get-item-fields, plan-mutation) and apply only the approved plan ID.", ""]
    for cid, ch in changes.items():
        lines += [f"## {cid} — {ch['name']}", ch["notes"] and f"Notes: {ch['notes']}", ""]
        lines += [f"- **{k}**: `{html.escape(v['before'])[:300]}` → `{html.escape(v['after'])[:300]}`" for k, v in ch["fields"].items()] + [""]
    (root / "testcases/changes.md").write_text("\n".join(l for l in lines if l is not None), encoding="utf-8")
    print(f"{len(changes)} changed test cases -> testcases/changes.md")
    return 0


def tokens(text: str) -> set[str]:
    """Words and numbers apart, so 'Testcase1' and 'test case 1' share '1' and differ from 'Testcase2'."""
    words = re.findall(r"[a-z]+|\d+", text.lower())
    return {(str(int(t)) if t.isdigit() else t) for t in words
            if t not in {"py", "test", "case", "testcase", "tc", "the", "and", "of"}}


def cmd_map(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    man = load(root / "manifest.json")
    smap = load(root / "analysis/script_map.json", {})
    for pair in a.set or []:
        tc, _, path = pair.partition("=")
        p = (REPO / path).resolve()
        if not p.is_file():
            raise SystemExit(f"no such script: {path}")
        smap.setdefault(tc, {}).update({"script": str(p.relative_to(REPO)), "confirmed": True})
        save(root / "analysis/script_map.json", smap)
        print(f"confirmed {tc} -> {p.relative_to(REPO)}")
    if a.set:
        return 0
    index = load(root / "inputs/cb/index.json", {})
    tcs = ids(a.ids) or man["cb"]["test_cases"] or [k for k, v in index.items() if "test" in str(v.get("tracker", "")).lower()]
    scripts = [p for p in (REPO / "projects" / man["project"] / "modules").rglob("scripts/*.py")]
    texts = {p: p.read_text(encoding="utf-8", errors="replace")[:4000] for p in scripts}
    for tc in tcs:
        name = (index.get(tc) or {}).get("name") or tc
        want = tokens(name)
        scored = []
        for p, t in texts.items():
            if re.search(rf"\b{re.escape(tc)}\b", t):
                scored.append((1.0, p, "CB id in script"))
                continue
            have = tokens(p.stem) | tokens(" ".join(re.findall(r"tc_(?:id|desc)\s*=\s*['\"]([^'\"]+)", t)))
            if want and have:
                score = len(want & have) / len(want | have)
                if score >= 0.3:
                    scored.append((round(score, 2), p, "name overlap"))
        scored.sort(key=lambda s: -s[0])
        prev = smap.get(tc, {})
        smap[tc] = {"name": name, "confirmed": prev.get("confirmed", False), "script": prev.get("script"),
                    "candidates": [{"script": str(p.relative_to(REPO)), "score": s, "basis": b} for s, p, b in scored[:3]]}
        if not prev.get("confirmed") and scored and scored[0][2] == "CB id in script":  # a name match is only a proposal
            smap[tc].update({"script": str(scored[0][1].relative_to(REPO)), "confirmed": True})
        best = smap[tc]["candidates"][0] if smap[tc]["candidates"] else None
        shown = (f"{smap[tc]['script']} (confirmed)" if smap[tc]["confirmed"] else
                 f"{best['script']} ({best['score']}, proposal)" if best else "no candidate: no script exists")
        print(f"{tc:>10}  {'OK ' if smap[tc]['confirmed'] else '?? '} {name[:60]:<60} -> {shown}")
    save(root / "analysis/script_map.json", smap)
    print("confirm each '??' with: map <campaign> --set <CB id>=<script path>")
    return 0


def cmd_risk(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    smap = load(root / "analysis/script_map.json", {})
    report = {}
    for tc, m in smap.items():
        if not m.get("script"):
            continue
        lines = (REPO / m["script"]).read_text(encoding="utf-8", errors="replace").splitlines()
        hits = {k: [f"{i}: {l.strip()[:120]}" for i, l in enumerate(lines, 1) if re.search(rx, l) and not l.lstrip().startswith("#")]
                for k, rx in RISKS.items()}
        report[tc] = {"script": m["script"], "risks": {k: v[:5] for k, v in hits.items() if v}}
    save(root / "analysis/risk.json", report)
    for tc, r in report.items():
        print(f"{tc:>10}  {', '.join(r['risks']) or 'no irreversible operation found'}  ({r['script']})")
    return 0


def bench_status(man: dict) -> dict:
    cmd = [sys.executable, str(REPO / "tools" / "aria_ctl.py")] + (["--aria-dir", man["aria_dir"]] if man.get("aria_dir") else []) + ["status"]
    out = subprocess.run(cmd, capture_output=True, text=True, cwd=REPO)
    try:
        return json.loads(out.stdout)
    except ValueError:
        return {"error": f"aria_ctl status failed: {out.stderr.strip()[:300]}"}


def bench_problems(man: dict, st: dict) -> list[str]:
    """What makes a run impossible: exactly one live ARIA API (apym refuses two instance files)."""
    if "error" in st:
        return [st["error"]]
    problems = []
    inst = st["active_instances"]
    if not any(i["alive"] for i in inst):
        problems.append("ARIA is not running (start it per aria-bench §18.4 D; with a chassis that is a hardware step)")
    if len(inst) != 1:
        problems.append(f"{len(inst)} ActiveInstances files: scripts need exactly one (aria_ctl clean-stale)")
    return problems


def preflight(man: dict) -> list[str]:
    return bench_problems(man, bench_status(man))


def aria_ctl(man: dict, *args: str, timeout: int = 300) -> dict:
    """Run tools/aria_ctl.py for this task's install; its answer is the last stdout line that is a JSON object."""
    cmd = [sys.executable, str(REPO / "tools" / "aria_ctl.py")] + (["--aria-dir", man["aria_dir"]] if man.get("aria_dir") else []) + list(args)
    out = subprocess.run(cmd, capture_output=True, text=True, cwd=REPO, timeout=timeout,
                         env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    text = out.stdout.strip()
    for start in [0] + [i + 1 for i, ch in enumerate(text) if ch == "\n" and text[i + 1:i + 2] == "{"][::-1]:
        try:  # check-inputs prints one indented object, read-dtc one line after the framework's own prints
            return json.loads(text[start:])
        except ValueError:
            continue
    return {"error": f"aria_ctl {args[0]} failed: {(out.stderr or out.stdout).strip()[-300:]}"}


def input_check(man: dict, live: bool = True) -> dict:
    """Is ARIA running the project, loadbox profile, RSU workbook and DBC content the user named? (read-only)"""
    b = man.get("bench_inputs") or {}
    args = ["check-inputs"] + (["--config", man["aria_config"]] if man.get("aria_config") else [])
    args += (["--profile", b["loadbox_profile"]] if b.get("loadbox_profile") else []) + (["--rsu", b["rsu_workbook"]] if b.get("rsu_workbook") else [])
    args += [x for d in b.get("dbc") or [] for x in ("--dbc", d)] + (["--live"] if live else [])
    res = aria_ctl(man, *args)
    return res if "checks" in res else {"checks": [], "problems": [res.get("error", "check-inputs gave no answer")]}


def fault_check(man: dict) -> dict:
    """The framework's fault-free definition: Read_DTC_Req answered with no DTC. Sends one UDS read: only after the user's go."""
    res = aria_ctl(man, "read-dtc", "--project", man["project"], "--apply", timeout=120)
    if res.get("fault_free") is True:
        res["problems"] = []
    elif res.get("fault_free") is False:
        res["problems"] = ["bench not fault free: " + ", ".join(f"{d['dtc']} status {d['status']}{' (active)' if d['active'] else ''}"
                                                              for d in res.get("dtcs", []))]
    else:
        res["problems"] = [f"fault-free check not possible: {res.get('error')}"]
    return res


def cmd_plan(a: argparse.Namespace) -> int:
    """Render analysis/g2_plan.md, the execution plan the user approves at gate G2; the agent completes it."""
    root = campaign(a.campaign)
    man = load(root / "manifest.json")
    smap = load(root / "analysis/script_map.json", {})
    risk = load(root / "analysis/risk.json", {})
    st = bench_status(man)
    cfg = st.get("active_configuration") or {}
    run = [(tc, m) for tc, m in smap.items() if m.get("confirmed") and m.get("script")]
    lines = [f"# G2 execution plan — {man['task']} ({man['project']})", "",
             "## Test cases to run", "", "| Test case | Name | Script | Irreversible / notable operations (pattern scan + reading) |", "|---|---|---|---|"]
    lines += [f"| {tc} | {m.get('name', '')} | `{m['script']}` | {', '.join(risk.get(tc, {}).get('risks', {})) or 'none found by scan'} |"
              for tc, m in run]
    not_run = [tc for tc, m in smap.items() if (tc, m) not in run]
    lines += ["", f"Not run: {', '.join(not_run) or 'none'} (unconfirmed mapping or no script).", "",
              "## Bench", "",
              f"- ARIA: {(st.get('selected_install') or {}).get('dir')} {(st.get('selected_install') or {}).get('version')}; "
              f"running: {bool(st.get('aria_processes'))}; instance files: {len(st.get('active_instances', []))}",
              f"- Active project: {cfg.get('path')} (customer {cfg.get('customer')!r}, loadbox {cfg.get('loadbox')}, "
              f"chassis {cfg.get('use_chassis')}); expected for this task: {man.get('aria_config') or 'not recorded'}",
              "- Reports and logs: written by the framework to test_results/ and test_logs/ of this repo "
              "(ARIA's ScriptsFolder matters only for scripts started from the ARIA GUI).",
              f"- Network still open for: {', '.join(st.get('network_unblocked', [])) or 'nothing'}", "",
              "## Must be done before the run", ""]
    checks = input_check(man, live=any(i["alive"] for i in st.get("active_instances", [])))
    lines += [f"- {p}" for p in bench_problems(man, st) + checks["problems"]] or ["- nothing: pre-flight is clean"]
    b = man.get("bench_inputs") or {}
    lines += ["", "## ARIA set-up against the files you named", "",
              f"Named: project {man.get('aria_config') or '-'}; loadbox profile {b.get('loadbox_profile') or '-'}; "
              f"RSU workbook {b.get('rsu_workbook') or '-'}; DBC {', '.join(b.get('dbc') or []) or '-'}", ""]
    lines += [f"- {c['status'].upper()}: {c['check']} — {c['detail']}" for c in checks["checks"]] or ["- (no check ran)"]
    lines += ["", "Fault-free check: right after \"go\" and before the first test case, `aria_ctl.py read-dtc` sends the "
              "framework's `Read_DTC_Req` (shared configuration_control) once; the bench is fault free when the ECU answers "
              "with no DTC. The ECU must be on. With DTCs, or without an answer, the run stops and shows them; it goes on "
              "only if you say so (`run --accept-bench \"<your words>\"`)."]
    lines += ["", "## Gaps", ""] + ([f"- {g}" for g in man.get("gaps", [])] or ["- none"])
    lines += ["", "## Questions for the user", "", "- (agent: list what you need confirmed)", "",
              "## After \"go\"", "", f"`py -3.14 tools/test_task.py run {root} --apply`, then collect / triage-scan; "
              "at most two re-runs per test case, each with its reason."]
    out = root / "analysis" / "g2_plan.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(out)
    return 0


def cmd_note(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    with (root / "issues.md").open("a", encoding="utf-8") as f:
        f.write(f"- {dt.datetime.now():%Y-%m-%d %H:%M} {'GAP: ' if a.gap else ''}{a.text}\n")
    if a.gap:
        man = load(root / "manifest.json")
        man.setdefault("gaps", []).append(a.text)
        save(root / "manifest.json", man)
    return 0


def cmd_run(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    man = load(root / "manifest.json")
    smap = load(root / "analysis/script_map.json", {})
    selected = [tc for tc in (ids(a.only) or list(smap)) if smap.get(tc, {}).get("confirmed") and smap[tc].get("script")]
    skipped = [tc for tc in (ids(a.only) or list(smap)) if tc not in selected]
    attempt = len(man["attempts"]) + 1
    print(json.dumps({"attempt": attempt, "run": {tc: smap[tc]["script"] for tc in selected},
                      "not_run (unconfirmed or no script)": skipped}, indent=2))
    if not a.apply:
        print("plan only: running drives the bench (power, CAN, faults, curves). Add --apply after the user's go.")
        return 0
    problems = preflight(man)
    if problems:
        print("pre-flight failed:\n- " + "\n- ".join(problems))
        return 2
    checks, faults = input_check(man), fault_check(man)
    found = checks["problems"] + faults["problems"]
    print(json.dumps({"bench_check": [f"{c['status']}: {c['check']} — {c['detail'][:200]}" for c in checks["checks"]],
                      "fault_free": faults.get("fault_free"), "dtcs": faults.get("dtcs")}, indent=2))
    if found and not a.accept_bench:
        print("bench check failed, nothing was run:\n- " + "\n- ".join(found) +
              "\nFix it (aria-bench runbook), or re-run with --accept-bench \"<the user's words>\" only if the user said so.")
        return 2
    out_dir = root / "runs" / str(attempt)
    out_dir.mkdir(parents=True, exist_ok=True)
    save(out_dir / "bench_check.json", {"checks": checks, "faults": faults, "accepted_by_user": a.accept_bench if found else None})
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", FRAMEWORK_PROJECT=man["project"])
    results = []
    for tc in selected:
        script = REPO / smap[tc]["script"]
        start = dt.datetime.now()
        try:
            proc = subprocess.run([sys.executable, str(script)], cwd=REPO, env=env, capture_output=True, text=True, timeout=a.timeout)
            console, code, status = proc.stdout + "\n--- stderr ---\n" + proc.stderr, proc.returncode, None
        except subprocess.TimeoutExpired as exc:
            console, code, status = f"{exc.stdout or ''}\n--- stderr ---\n{exc.stderr or ''}", None, "TIMEOUT"
        (out_dir / f"{safe_name(tc)}.console.txt").write_text(str(console), encoding="utf-8")
        m = REPORT_LINE.search(str(console))
        report, log = (m.group("report"), m.group("log")) if m else (None, None)
        verdict = None
        if report and Path(report).is_file():
            v = VERDICT.search(Path(report).read_text(encoding="utf-8", errors="replace")[-200:])
            verdict = v.group(1) if v else None
        status = status or verdict or ("NO_REPORT" if code == 0 else "ERROR")
        results.append({"tc": tc, "name": smap[tc].get("name"), "script": smap[tc]["script"], "status": status,
                        "exit_code": code, "report": report, "log": log, "started": start.isoformat(timespec="seconds"),
                        "seconds": round((dt.datetime.now() - start).total_seconds(), 1)})
        save(out_dir / "results.json", results)
        print(f"{tc:>10}  {status:<9} {smap[tc]['script']}")
    man["attempts"].append({"n": attempt, "at": dt.datetime.now().isoformat(timespec="seconds"), "tcs": selected,
                            "reason": a.reason or ("first run" if attempt == 1 else ""),
                            "bench_problems_accepted": {"problems": found, "user": a.accept_bench} if found else None})
    save(root / "manifest.json", man)
    return 0


def latest_results(root: Path) -> dict[str, dict]:
    """Newest result per test case across all attempts."""
    best: dict[str, dict] = {}
    for d in sorted((root / "runs").iterdir(), key=lambda p: int(p.name) if p.name.isdigit() else 0):
        for r in load(d / "results.json", []):
            best[r["tc"]] = dict(r, attempt=int(d.name))
    return best


def cmd_collect(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    pkg = root / "package"
    used: set[str] = set()
    rows = []
    for tc, r in latest_results(root).items():
        base = safe_name(r.get("name") or tc)
        if base.lower() in used:
            base = f"{base}_{tc}"
        used.add(base.lower())
        for src, ext in ((r.get("report"), ".html"), (r.get("log"), ".txt"),
                         (root / "runs" / str(r["attempt"]) / f"{safe_name(tc)}.console.txt", ".console.txt")):
            if src and Path(src).is_file():
                shutil.copy2(src, pkg / f"{base}{ext}")
        rows.append({"CB ID": tc, "Test case": r.get("name"), "File base": base, "Verdict": r["status"],
                     "Attempt": r["attempt"], "Script": r["script"], "Report": r.get("report"), "Log": r.get("log")})
    with (pkg / "summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ["CB ID"])
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} test cases -> {pkg}")
    return 0


def failed_steps(report: str | None) -> list[str]:
    if not report or not Path(report).is_file():
        return []
    text = Path(report).read_text(encoding="utf-8", errors="replace")
    steps = re.findall(r'<tr[^>]*class="[^"]*-failed\s+step[^"]*"[^>]*>(.*?)</tr>', text, re.S)
    clean = [re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", s))).strip() for s in steps]
    return [c[:300] for c in clean if c][:10]


def cmd_triage_scan(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    out = []
    for tc, r in latest_results(root).items():
        if r["status"] == "PASSED":
            continue
        console = (root / "runs" / str(r["attempt"]) / f"{safe_name(tc)}.console.txt").read_text(encoding="utf-8", errors="replace")
        bench = sorted(set(m.group(0) for m in BENCH_HINTS.finditer(console)))
        errors = sorted(set(m.group(0).strip() for m in SCRIPT_HINTS.finditer(console)))
        steps = failed_steps(r.get("report"))
        hint = ("BENCH" if bench else "SCRIPT" if errors or r["status"] in ("ERROR", "NO_REPORT") else
                "NEEDS_ANALYSIS (ECU / test case / requirement)" if steps else "UNDETERMINED")
        out.append({"tc": tc, "name": r.get("name"), "status": r["status"], "attempt": r["attempt"], "hint": hint,
                    "bench_signatures": bench, "exceptions": errors, "failed_steps": steps,
                    "console_tail": console.strip().splitlines()[-25:], "script": r["script"], "report": r.get("report")})
    save(root / f"triage/attempt{max([r['attempt'] for r in out], default=0)}.json", out)
    for t in out:
        print(f"{t['tc']:>10}  {t['status']:<9} hint={t['hint']}")
    print(f"{len(out)} failures; write the verdicts to decisions.json (see the agent file), then run 'bugs'")
    return 0


CATEGORIES = ("ECU_DEFECT", "BENCH", "SCRIPT", "TEST_CASE", "REQUIREMENT", "UNDETERMINED")


def cmd_bugs(a: argparse.Namespace) -> int:
    import openpyxl
    root = campaign(a.campaign)
    decisions = load(root / "decisions.json", [])
    bad = [d for d in decisions if d.get("category") not in CATEGORIES or d.get("confidence") not in ("High", "Medium", "Low")]
    if bad:
        raise SystemExit(f"decisions.json: category must be one of {CATEGORIES} and confidence High/Medium/Low: {bad[:2]}")
    cols = ["tc", "name", "requirement", "category", "confidence", "summary", "evidence", "action", "rerun_result", "status"]
    wb = openpyxl.Workbook()
    for title, rows in (("Bugs to verify", [d for d in decisions if d["category"] in ("ECU_DEFECT", "UNDETERMINED")]),
                        ("All failures", decisions)):
        ws = wb.create_sheet(title)
        ws.append(cols)
        for d in rows:
            ws.append([d.get(c, "") if not isinstance(d.get(c), list) else "\n".join(map(str, d[c])) for c in cols])
    del wb["Sheet"]
    wb.save(root / "bugs.xlsx")
    md = ["# Bugs and failures — user to verify", "", "| TC | Category | Confidence | Summary | Action |", "|---|---|---|---|---|"]
    md += [f"| {d['tc']} | {d['category']} | {d['confidence']} | {str(d.get('summary', '')).replace('|', '/')} | "
           f"{str(d.get('action', '')).replace('|', '/')} |" for d in decisions]
    (root / "bugs.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(f"{len(decisions)} failures, {sum(d['category'] == 'ECU_DEFECT' for d in decisions)} suspected ECU defects -> bugs.xlsx")
    return 0


def generator_owners(rel: Path) -> list[str]:
    """Why a test script may be generator output: its folder's generated list, or a tools/ generator writing there."""
    project, module, name = rel.parts[1], rel.parts[3], rel.name
    owners = []
    listed = REPO / rel.parent / "generated_script_list.json"
    if name in (load(listed, []) or []):
        owners.append(f"{listed.relative_to(REPO)} (its generator may no longer exist; check git log)")
    for gen in sorted((REPO / "tools").glob("generate_*.py")):
        text = gen.read_text(encoding="utf-8", errors="replace")
        if re.search(rf"[\"'/]{re.escape(module)}[\"'/]", text) and "scripts" in text and (project in text or "--project" in text):
            owners.append(f"tools/{gen.name}")
    return owners


LEVELS = ("High", "Medium", "Low")
# Review workbooks of the review pipelines: allowed categories and the column order.
FINDING_KINDS = {
    "requirement-review": {
        "title": "Requirement review",
        "categories": ("CORRECTNESS", "COMPLETENESS", "AMBIGUITY", "TESTABILITY", "CONSISTENCY", "TRACEABILITY",
                       "TERMINOLOGY", "FORMAT", "STATUS", "MISSING_REQUIREMENT"),
        "columns": ("id", "requirement", "source_reference", "category", "severity", "finding", "written", "source_says",
                    "proposed_wording", "confidence", "evidence", "status")},
    "trace": {
        "title": "Test specification traceability and corrections",
        "categories": ("MISSING_TRACE", "WRONG_TRACE", "UNKNOWN_REQ", "UNAPPROVED_REQ", "STRUCK_REQ", "UNTESTED_REQ",
                       "DUPLICATE_CASE", "STEP_QUALITY", "EXPECTED_RESULT", "FORMAT"),
        "columns": ("test_case", "row", "category", "severity", "current", "proposed", "basis", "confidence", "status")},
    "tc-review": {
        "title": "Test-case review",
        "categories": ("MISSING_TEST", "COVERAGE_GAP", "TRACEABILITY", "EXPECTED_RESULT", "STEP", "PRECONDITION", "TIMING",
                       "DIAGNOSTICS", "COMMUNICATION", "CONFIGURATION", "DUPLICATE", "SOURCE_CONFLICT", "AUTOMATION", "FORMAT"),
        "columns": ("test_case", "row", "requirement", "category", "severity", "finding", "evidence", "impact", "current",
                    "proposed", "additional_tests", "confidence", "status")},
    "report-review": {
        "title": "Test results review",
        "categories": ("ECU_DEFECT", "BENCH", "SCRIPT", "TEST_CASE", "REQUIREMENT", "REPORT_INTEGRITY", "FALSE_PASS",
                       "COVERAGE_GAP", "LOG_ANOMALY", "UNDETERMINED"),
        "columns": ("test_case", "report", "verdict", "category", "severity", "finding", "expected", "observed",
                    "evidence", "confidence", "action", "status")},
}


def cmd_findings(a: argparse.Namespace) -> int:
    """Validated findings JSON -> review/<task>_<kind>.xlsx + .md for the user to review."""
    import openpyxl
    from openpyxl.styles import Alignment, Font
    root = campaign(a.campaign)
    kind = FINDING_KINDS[a.kind]
    src = Path(a.input) if a.input else root / "analysis" / f"findings_{a.kind}.json"
    rows = load(src)
    if not isinstance(rows, list):
        raise SystemExit(f"{src}: expected a JSON list of findings")
    bad = [r for r in rows if r.get("category") not in kind["categories"] or r.get("severity") not in LEVELS
           or r.get("confidence") not in LEVELS]
    if bad:
        raise SystemExit(f"{len(bad)} findings need category in {kind['categories']}, severity and confidence in {LEVELS}; "
                         f"first: {json.dumps(bad[0], ensure_ascii=False)[:300]}")
    order = {lvl: i for i, lvl in enumerate(LEVELS)}
    rows.sort(key=lambda r: (order[r["severity"]], order[r["confidence"]]))
    cols = kind["columns"]
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Findings"
    ws.append([c.replace("_", " ").capitalize() for c in cols])
    for c in ws[1]:
        c.font = Font(bold=True)
    for r in rows:
        ws.append(["\n".join(map(str, r[c])) if isinstance(r.get(c), list) else r.get(c, "") for c in cols])
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 18 if col[0].value in ("Category", "Severity", "Confidence", "Status", "Row") else 45
        for cell in col[1:]:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    base = f"{safe_name(load(root / 'manifest.json')['task'])[:60]}_{a.kind}"
    out = root / "review" / f"{base}.xlsx"
    out.parent.mkdir(exist_ok=True)
    wb.save(out)
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["category"]] = counts.get(r["category"], 0) + 1
    md = [f"# {kind['title']} — {load(root / 'manifest.json')['task']}", "",
          f"{len(rows)} findings: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())), "",
          "| " + " | ".join(c.replace("_", " ") for c in cols[:6]) + " |", "|" + "---|" * min(6, len(cols))]
    md += ["| " + " | ".join(str(r.get(c, "")).replace("|", "/").replace("\n", " ")[:120] for c in cols[:6]) + " |" for r in rows]
    (out.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print(f"{len(rows)} findings -> {out}")
    return 0


def cmd_backup_script(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    man = load(root / "manifest.json")
    script = (REPO / a.script).resolve()
    rel = script.relative_to(REPO)
    if not re.fullmatch(rf"projects[\\/]{re.escape(man['project'])}[\\/]modules[\\/].+[\\/]scripts[\\/][^\\/]+\.py", str(rel)):
        raise SystemExit(f"refused: only test scripts of {man['project']} (projects/<p>/modules/**/scripts/*.py) may be corrected")
    owners = generator_owners(rel)
    if owners and not a.generated_ok:
        raise SystemExit(f"refused: {rel.name} looks generator-owned ({'; '.join(owners)}). Fix the generator and regenerate, "
                         "or pass --generated-ok once the user agrees to edit the generated file directly.")
    if not a.apply:
        print(f"plan only: git commit of {rel} as it is now, then backup {rel}.bak-<time>; add --apply")
        return 0
    subprocess.run(["git", "add", "--", str(rel)], cwd=REPO, check=True)
    staged = subprocess.run(["git", "diff", "--cached", "--quiet", "--", str(rel)], cwd=REPO).returncode
    commit = None
    if staged:
        subprocess.run(["git", "commit", "-m", f"test pipeline: {rel.name} before correction ({man['task']})", "--", str(rel)],
                       cwd=REPO, check=True, capture_output=True)
        commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=REPO, capture_output=True, text=True).stdout.strip()
    backup = script.with_name(f"{script.name}.bak-{dt.datetime.now():%Y%m%d-%H%M%S}")
    shutil.copy2(script, backup)
    man["corrections"].append({"script": str(rel), "commit_before": commit, "backup": str(backup.relative_to(REPO)),
                               "at": dt.datetime.now().isoformat(timespec="seconds"), "reason": a.reason})
    save(root / "manifest.json", man)
    print(json.dumps(man["corrections"][-1], indent=2))
    return 0


def cmd_zip(a: argparse.Namespace) -> int:
    root = campaign(a.campaign)
    if not a.name or not a.dest:
        raise SystemExit("refused: the zip name and destination come from the user; pass both --name and --dest")
    if re.search(r'[\\/<>:"|?*]', a.name):
        raise SystemExit("refused: --name is a file name, not a path")
    dest = Path(a.dest) / (a.name if a.name.lower().endswith(".zip") else a.name + ".zip")
    if dest.exists() and not a.overwrite:
        raise SystemExit(f"refused: {dest} exists (pass --overwrite after the user agrees)")
    dest.parent.mkdir(parents=True, exist_ok=True)
    extra = [p for p in (root / "bugs.xlsx", root / "bugs.md") if p.is_file()]
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted((root / "package").iterdir()):
            z.write(p, p.name)
        for p in extra:
            z.write(p, p.name)
    digest = hashlib.sha256(dest.read_bytes()).hexdigest()
    man = load(root / "manifest.json")
    man["zip"] = {"path": str(dest), "sha256": digest, "files": len(list((root / "package").iterdir())) + len(extra)}
    save(root / "manifest.json", man)
    print(json.dumps(man["zip"], indent=2))
    return 0


def cmd_ptc_request(a: argparse.Namespace) -> int:
    """Stage the zip and write a windchill-ptc-project-automation AddArchives request (approval false)."""
    root = campaign(a.campaign)
    man = load(root / "manifest.json")
    missing = [k for k in ("source_root", "sandbox_root", "ptc_project", "change_package", "target_folder") if not getattr(a, k)]
    if missing or not man.get("zip"):
        raise SystemExit(f"refused: the user must give {missing or ''}{' and zip first' if not man.get('zip') else ''}")
    zip_path = Path(man["zip"]["path"])
    rel = Path(a.target_folder) / zip_path.name
    policy = load(REPO / ".github/skills/windchill-ptc-project-automation/config/defaults.json", {}).get("filePolicy", {})
    denied = {n.lower() for n in policy.get("deniedDirectoryNames", [])}
    if clash := [s for s in rel.parent.parts if s.lower() in denied]:
        raise SystemExit(f"refused: the Windchill skill silently skips files under {clash} (filePolicy.deniedDirectoryNames "
                         f"{sorted(denied)}); the zip would not be uploaded. Ask the user for another target folder name.")
    staged = Path(a.source_root) / rel
    staged.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(zip_path, staged)
    request = {"operation": "AddArchives", "sourceRoot": a.source_root, "sandboxRoot": a.sandbox_root,
               "ptcProject": a.ptc_project, "changePackageId": a.change_package,
               "description": f"Test logs {man['project']} {man['task']}",
               "subprojects": {"naming": "same-name", "createMissing": False, "allowExistingExpectedProjects": True},
               "fileSelection": {"mode": "explicit-files", "explicitRelativePaths": [str(rel)], "allowAllFiles": False},
               "approval": {"approved": False, "approvedBy": "", "approvedAtUtc": "", "reason": "user reviews the preflight first"}}
    out = root / "ptc_request.json"
    save(out, request)
    man["ptc"] = {"request": str(out), "staged": str(staged)}
    save(root / "manifest.json", man)
    print(f"{out}\nnext: Invoke-WindchillPtcAutomation.ps1 -RequestPath {out} -OutputRoot {root} -Mode DryRun "
          "(check counts.files == 1), then -Mode Preflight; Apply only after the user approves "
          "(approval.approved=true and -Approve)")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Mechanical steps of the task pipelines (test run, requirement review, test-case writing and review, results review)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.set_defaults(fn=cmd_init)
    p.add_argument("--project", required=True); p.add_argument("--task", required=True)
    p.add_argument("--task-source", default="codebeamer", help="codebeamer | manager (not yet in Codebeamer) | other")
    p.add_argument("--cb-req"); p.add_argument("--cb-tc"); p.add_argument("--oem-spec"); p.add_argument("--source-dir")
    p.add_argument("--aria-dir"); p.add_argument("--aria-config", help="the AriaMain.json this project runs on")
    p.add_argument("--dbc", action="append", help="DBC the user named (repeat): ARIA's simulations must match it")
    p.add_argument("--rsu-workbook", help="RSU workbook the user named: ARIA must preload it")
    p.add_argument("--loadbox-profile", help="loadbox profile JSON the user named: ARIA must load it")
    p.add_argument("--manager-file", help="text file with the manager's instructions, copied verbatim")
    p.add_argument("--pipeline", choices=sorted(PIPELINE_NEEDS), default="test")
    p.add_argument("--keep-awake-hours", type=float, default=12, help="hold the PC awake/online this long (0 = no hold)")
    p = sub.add_parser("finish"); p.set_defaults(fn=cmd_finish); p.add_argument("campaign")
    p = sub.add_parser("findings"); p.set_defaults(fn=cmd_findings); p.add_argument("campaign")
    p.add_argument("--kind", required=True, choices=sorted(FINDING_KINDS))
    p.add_argument("--input", help=f"findings JSON (default analysis/findings_<kind>.json)")
    p = sub.add_parser("add-tc"); p.set_defaults(fn=cmd_add_tc); p.add_argument("campaign")
    p.add_argument("--id", required=True, help="CB id if known, else a short id like M1"); p.add_argument("--name", required=True)
    p.add_argument("--requirements", help="requirement ids it verifies"); p.add_argument("--source", default="manager")
    p = sub.add_parser("setup"); p.set_defaults(fn=cmd_setup)
    p.add_argument("--online", action="store_true", help="also log in to Codebeamer once (read-only validate)")
    p.add_argument("--pipeline", choices=sorted(PIPELINE_NEEDS), default="test")
    p = sub.add_parser("note"); p.set_defaults(fn=cmd_note); p.add_argument("campaign")
    p.add_argument("--text", required=True); p.add_argument("--gap", action="store_true", help="also record it as a gap")
    p = sub.add_parser("plan"); p.set_defaults(fn=cmd_plan); p.add_argument("campaign")
    for name, fn in (("cb-fetch", cmd_cb_fetch), ("tc-workbook", cmd_tc_workbook), ("tc-diff", cmd_tc_diff), ("map", cmd_map),
                     ("risk", cmd_risk), ("run", cmd_run), ("collect", cmd_collect), ("triage-scan", cmd_triage_scan),
                     ("bugs", cmd_bugs), ("backup-script", cmd_backup_script), ("zip", cmd_zip), ("ptc-request", cmd_ptc_request)):
        p = sub.add_parser(name); p.set_defaults(fn=fn); p.add_argument("campaign")
        if name == "cb-fetch":
            p.add_argument("--items"); p.add_argument("--follow", action="store_true", help="also fetch directly related items")
            p.add_argument("--tracker", help="fetch every item of this tracker"); p.add_argument("--status", help="only this status")
        if name in ("tc-workbook", "map"):
            p.add_argument("--ids")
        if name == "map":
            p.add_argument("--set", action="append", help="<CB id>=<script path> (confirmed mapping)")
        if name == "run":
            p.add_argument("--only"); p.add_argument("--timeout", type=int, default=1800)
            p.add_argument("--reason"); p.add_argument("--apply", action="store_true")
            p.add_argument("--accept-bench", help="the user's words accepting the bench-check problems (DTCs, set-up differences)")
        if name == "backup-script":
            p.add_argument("script"); p.add_argument("--reason", required=True); p.add_argument("--apply", action="store_true")
            p.add_argument("--generated-ok", action="store_true", help="the user agreed to edit a generator-owned script")
        if name == "zip":
            p.add_argument("--name"); p.add_argument("--dest"); p.add_argument("--overwrite", action="store_true")
        if name == "ptc-request":
            for k in ("--source-root", "--sandbox-root", "--ptc-project", "--change-package", "--target-folder"):
                p.add_argument(k)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
