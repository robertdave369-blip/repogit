# Metadata + IL string dump of ARIA's .NET Framework assemblies, reflection-only: no ARIA code runs.
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\aria_il_dump.ps1 -AriaDir C:\ARIA5.20 -Assemblies ARIA.exe,AriaCore.dll
#   ... -Disasm 'RsuV1ConfigurationParser::LoadStartupParameterMode$'   full IL of matching methods
# Per assembly writes <Out>\<name>.txt: types (base, enum values), fields, properties, methods with their
# string literals (S) and callees (C). The output is derived from vendor binaries: keep it outside the repo
# (default %LOCALAPPDATA%\aria_re\dump). tools/aria_ctl.py calls this for verify-internals and compat.
param(
    [Parameter(Mandatory = $true)][string]$AriaDir,
    [string]$Out = (Join-Path $env:LOCALAPPDATA "aria_re\dump"),
    [string[]]$Assemblies,
    [string]$Disasm   # regex on "Type::Method": print full IL of matching methods instead of the dump
)
$ErrorActionPreference = "Stop"
$Assemblies = $Assemblies -split ','   # -File passes "a,b" as one string
New-Item -ItemType Directory -Force $Out | Out-Null

Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;

public static class IlDump {
    static readonly Dictionary<short, OpCode> Ops = new Dictionary<short, OpCode>();
    static string _dir;
    static IlDump() {
        foreach (var f in typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)) {
            var op = (OpCode)f.GetValue(null); Ops[op.Value] = op;
        }
    }
    static Assembly Resolve(object s, ResolveEventArgs e) {
        string name = new AssemblyName(e.Name).Name;
        foreach (var ext in new[] { ".dll", ".exe" }) {
            string p = Path.Combine(_dir, name + ext);
            if (File.Exists(p)) { try { return Assembly.ReflectionOnlyLoadFrom(p); } catch { } }
        }
        try { return Assembly.ReflectionOnlyLoad(e.Name); } catch { return null; }
    }
    public static void Init(string dir) {
        _dir = dir;
        AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += Resolve;
    }
    static string Sig(MethodBase m) {
        try {
            var ps = string.Join(", ", m.GetParameters().Select(p => SafeName(p.ParameterType) + " " + p.Name));
            var mi = m as MethodInfo;
            return (m.IsStatic ? "static " : "") + (mi != null ? SafeName(mi.ReturnType) + " " : "") + m.Name + "(" + ps + ")";
        } catch { return m.Name + "(?)"; }
    }
    static string SafeName(Type t) { try { return t.FullName ?? t.Name; } catch { return "?"; } }
    // Full IL listing of every method whose "Type::Method" matches the regex (operands resolved).
    public static string Disasm(string path, string pattern) {
        var asm = Assembly.ReflectionOnlyLoadFrom(path);
        var rx = new System.Text.RegularExpressions.Regex(pattern);
        var sb = new StringBuilder();
        Type[] types;
        try { types = asm.GetTypes(); } catch (ReflectionTypeLoadException ex) { types = ex.Types.Where(t => t != null).ToArray(); }
        var mod = asm.ManifestModule;
        const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
        foreach (var t in types) {
            MethodBase[] ms;
            try { ms = t.GetMethods(all).Cast<MethodBase>().Concat(t.GetConstructors(all)).ToArray(); } catch { continue; }
            foreach (var m in ms) {
                if (!rx.IsMatch(t.FullName + "::" + m.Name)) continue;
                byte[] il = null;
                try { var b = m.GetMethodBody(); if (b != null) il = b.GetILAsByteArray(); } catch { }
                if (il == null) continue;
                sb.AppendLine("== " + t.FullName + "::" + Sig(m));
                int i = 0;
                while (i < il.Length) {
                    int at = i; OpCode op; short v = il[i];
                    if (v == 0xFE && i + 1 < il.Length) { v = (short)(0xFE00 | il[i + 1]); i += 2; } else i += 1;
                    if (!Ops.TryGetValue(v, out op)) { sb.AppendLine("  ?? " + v); break; }
                    string arg = "";
                    switch (op.OperandType) {
                        case OperandType.InlineNone: break;
                        case OperandType.ShortInlineBrTarget: arg = "IL_" + (i + 1 + (sbyte)il[i]).ToString("X4"); i += 1; break;
                        case OperandType.ShortInlineI: case OperandType.ShortInlineVar: arg = ((sbyte)il[i]).ToString(); i += 1; break;
                        case OperandType.InlineVar: arg = BitConverter.ToInt16(il, i).ToString(); i += 2; break;
                        case OperandType.InlineI8: arg = BitConverter.ToInt64(il, i).ToString(); i += 8; break;
                        case OperandType.InlineR: arg = BitConverter.ToDouble(il, i).ToString(); i += 8; break;
                        case OperandType.ShortInlineR: arg = BitConverter.ToSingle(il, i).ToString(); i += 4; break;
                        case OperandType.InlineI: arg = BitConverter.ToInt32(il, i).ToString(); i += 4; break;
                        case OperandType.InlineBrTarget: arg = "IL_" + (i + 4 + BitConverter.ToInt32(il, i)).ToString("X4"); i += 4; break;
                        case OperandType.InlineSwitch: {
                            int n = BitConverter.ToInt32(il, i); int bas = i + 4 + 4 * n; var tg = new List<string>();
                            for (int k = 0; k < n; k++) tg.Add("IL_" + (bas + BitConverter.ToInt32(il, i + 4 + 4 * k)).ToString("X4"));
                            arg = string.Join(",", tg); i = bas; break; }
                        case OperandType.InlineString: try { arg = "\"" + mod.ResolveString(BitConverter.ToInt32(il, i)) + "\""; } catch { } i += 4; break;
                        case OperandType.InlineMethod: try { var c = mod.ResolveMethod(BitConverter.ToInt32(il, i)); arg = (c.DeclaringType != null ? c.DeclaringType.Name : "") + "::" + c.Name; } catch { arg = "?"; } i += 4; break;
                        case OperandType.InlineField: try { var f = mod.ResolveField(BitConverter.ToInt32(il, i)); arg = f.DeclaringType.Name + "::" + f.Name; } catch { arg = "?"; } i += 4; break;
                        case OperandType.InlineType: case OperandType.InlineTok: try { arg = mod.ResolveMember(BitConverter.ToInt32(il, i)).Name; } catch { arg = "?"; } i += 4; break;
                        default: i += 4; break;
                    }
                    sb.AppendLine("  IL_" + at.ToString("X4") + " " + op.Name + " " + arg);
                }
            }
        }
        return sb.ToString();
    }
    public static string Dump(string path) {
        var asm = Assembly.ReflectionOnlyLoadFrom(path);
        var sb = new StringBuilder();
        sb.AppendLine("# " + asm.FullName);
        Type[] types;
        try { types = asm.GetTypes(); } catch (ReflectionTypeLoadException ex) { types = ex.Types.Where(t => t != null).ToArray(); }
        var mod = asm.ManifestModule;
        const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
        foreach (var t in types.OrderBy(x => x.FullName)) {
            string bt = ""; try { bt = t.BaseType != null ? t.BaseType.FullName : ""; } catch { bt = "?"; }
            sb.AppendLine("T " + t.FullName + " : " + bt);
            try {
                if (t.IsEnum) {
                    foreach (var f in t.GetFields(BindingFlags.Public | BindingFlags.Static))
                        sb.AppendLine("  E " + f.Name + " = " + f.GetRawConstantValue());
                    continue;
                }
                foreach (var f in t.GetFields(all)) {
                    string v = "";
                    if (f.IsLiteral) { try { v = " = " + f.GetRawConstantValue(); } catch { } }
                    sb.AppendLine("  F " + SafeName(f.FieldType) + " " + f.Name + v);
                }
                foreach (var p in t.GetProperties(all)) sb.AppendLine("  P " + SafeName(p.PropertyType) + " " + p.Name);
            } catch (Exception ex) { sb.AppendLine("  !fields " + ex.GetType().Name); }
            MethodBase[] ms;
            try { ms = t.GetMethods(all).Cast<MethodBase>().Concat(t.GetConstructors(all)).ToArray(); } catch { continue; }
            foreach (var m in ms) {
                sb.AppendLine("  M " + Sig(m));
                byte[] il = null;
                try { var b = m.GetMethodBody(); if (b != null) il = b.GetILAsByteArray(); } catch { }
                if (il == null) continue;
                var strs = new List<string>(); var calls = new List<string>();
                int i = 0;
                while (i < il.Length) {
                    OpCode op; short v = il[i];
                    if (v == 0xFE && i + 1 < il.Length) { v = (short)(0xFE00 | il[i + 1]); i += 2; } else i += 1;
                    if (!Ops.TryGetValue(v, out op)) break;
                    int size = 0;
                    switch (op.OperandType) {
                        case OperandType.InlineNone: size = 0; break;
                        case OperandType.ShortInlineBrTarget: case OperandType.ShortInlineI: case OperandType.ShortInlineVar: size = 1; break;
                        case OperandType.InlineVar: size = 2; break;
                        case OperandType.InlineI8: case OperandType.InlineR: size = 8; break;
                        case OperandType.InlineSwitch: size = 4 + 4 * BitConverter.ToInt32(il, i); break;
                        default: size = 4; break;
                    }
                    if (op.OperandType == OperandType.InlineString) {
                        try { strs.Add(mod.ResolveString(BitConverter.ToInt32(il, i))); } catch { }
                    } else if (op.OperandType == OperandType.InlineMethod) {
                        try {
                            var c = mod.ResolveMethod(BitConverter.ToInt32(il, i));
                            calls.Add((c.DeclaringType != null ? c.DeclaringType.Name : "") + "." + c.Name);
                        } catch { }
                    }
                    i += size;
                }
                foreach (var s in strs) sb.AppendLine("    S " + s.Replace("\r", "\\r").Replace("\n", "\\n"));
                if (calls.Count > 0) sb.AppendLine("    C " + string.Join(" ", calls.Distinct()));
            }
        }
        return sb.ToString();
    }
}
'@

[IlDump]::Init($AriaDir)
if ($Disasm) {
    foreach ($a in $Assemblies) {
        $p = if ([IO.Path]::IsPathRooted($a)) { $a } else { Join-Path $AriaDir $a }
        [IlDump]::Disasm($p, $Disasm)
    }
    return
}
foreach ($a in $Assemblies) {
    $p = if ([IO.Path]::IsPathRooted($a)) { $a } else { Join-Path $AriaDir $a }
    $dst = Join-Path $Out ([IO.Path]::GetFileName($p) + ".txt")
    try {
        [IO.File]::WriteAllText($dst, [IlDump]::Dump($p))
        "{0,-45} {1,10:N0} bytes" -f ([IO.Path]::GetFileName($p)), (Get-Item $dst).Length
    } catch { "{0,-45} FAILED {1}" -f ([IO.Path]::GetFileName($p)), $_.Exception.Message }
}
