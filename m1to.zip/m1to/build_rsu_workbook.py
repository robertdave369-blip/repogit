"""Inspect, build and export ARIA RSU (PSI5 satellite) marker workbooks — RSU V1 cards.

    python tools/build_rsu_workbook.py inspect WORKBOOK [--xml-dir DIR] [--sensor-xml X.xml --slots 1,2]
    python tools/build_rsu_workbook.py build --descriptor aria_projects/P/P.project.json --out OUT.xlsx
    python tools/build_rsu_workbook.py export-rsux WORKBOOK --slot N --out-dir DIR [--prefix NAME]

ARIA reads the workbook by Excel defined names on sheet OR_Start (RsuV1ConfigurationParser,
ARIA 5.20), per RSU function LogicalIndex n:
    Value_Slot{n}_Start..Value_Slot{n}_End   32 startup nibbles D1..D32, hex
    RSU_Mode_Slot{n}                         0 Sync 10-bit, 1 Async 10-bit, 2 Sync 8-bit, 3 Async 8-bit
    Repetition_factor_Slot{n}, Type_Slot{n}, Present_Slot{n}, Sensor_Status_Slot{n}   decimal
    Config_Start{n}..Config_End{n}           Config_Parmcount{n} config values, hex (26 in Config.xml)
A startup .rsux is the same data as 37 lines (32 hex, mode, repetition, type, present, status);
a config .rsux is 26 hex lines. Base sensor data always comes from a known-good workbook slot or
explicit values; sensor XMLs (Config_folder/RSU/XML/<Sensor>_Sensor.xml) only label nibbles and
translate named field edits such as {"Range": "240g", "Serial Number": "123456789ABC"}.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import openpyxl
except ImportError:  # the bare `python` on PATH of this PC has no openpyxl (agent_sc3.md §21.1)
    raise SystemExit('openpyxl missing: run with  py -3.14  or  "C:\\Python 3.14.0\\python.exe"')

SHEET = "OR_Start"
DEFAULT_CONFIG_ROOT = Path(r"C:\AriaConfigFiles_Generic\AriaConfigFiles")
MODES = {"sync_10bit_mode": 0, "async_10bit_mode": 1, "sync_8bit_mode": 2, "async_8bit_mode": 3}
SETTINGS = {"mode": "RSU_Mode_Slot{}", "repetition_factor": "Repetition_factor_Slot{}", "type": "Type_Slot{}",
            "present": "Present_Slot{}", "status": "Sensor_Status_Slot{}"}
HEX = re.compile(r"^[0-9A-Fa-f]+$")


def markers(wb) -> tuple[dict[str, str], list[str]]:
    """Defined name -> 'A1' or 'A1:B2' on OR_Start; broken names reported, as ARIA would fail on them."""
    found, broken = {}, []
    for name, dn in wb.defined_names.items():
        try:
            dest = [(s, r.replace("$", "")) for s, r in dn.destinations]
        except Exception:
            broken.append(f"{name}: {dn.attr_text}")
            continue
        if len(dest) != 1 or dest[0][0] != SHEET:
            broken.append(f"{name}: {dn.attr_text}")
            continue
        found[name] = dest[0][1]
    return found, broken


def column_cells(ws, start: str, end: str) -> list:
    a, b = ws[start], ws[end]
    if a.column != b.column or b.row < a.row:
        raise ValueError(f"markers {start}..{end} are not one column top-down")
    return [ws.cell(r, a.column) for r in range(a.row, b.row + 1)]


def text(v) -> str:
    return "" if v is None else str(v).strip()


def read_slot(ws, names: dict[str, str], n: int) -> dict | None:
    if f"Present_Slot{n}" not in names:
        return None
    slot: dict = {k: text(ws[names[p.format(n)]].value) if p.format(n) in names else None for k, p in SETTINGS.items()}
    slot["slot"] = n
    s, e = f"Value_Slot{n}_Start", f"Value_Slot{n}_End"
    slot["startup"] = [text(c.value) for c in column_cells(ws, names[s], names[e])] if s in names and e in names else None
    s, e, c = f"Config_Start{n}", f"Config_End{n}", f"Config_Parmcount{n}"
    slot["config"] = [text(x.value) for x in column_cells(ws, names[s], names[e])] if s in names and e in names and ":" not in names[s] else None
    slot["config_count"] = text(ws[names[c]].value) if c in names else None
    return slot


def validate(slot: dict) -> list[str]:
    """The checks ARIA's parser makes (messages it would raise in brackets)."""
    err = []
    st = slot.get("startup")
    if st is None or len(st) != 32:
        err.append(f"startup: {0 if st is None else len(st)} values, 32 required [32 bytes of startup config data are required]")
    elif any(not HEX.match(v) or int(v, 16) > 0xFF for v in st):
        err.append("startup: non-hex value [Data values must be in hex]")
    for k in SETTINGS:
        v = slot.get(k)
        if v is None or not v.lstrip("-").isdigit():
            err.append(f"{k}: '{v}' is not decimal [settings values in decimal]")
    if (slot.get("mode") or "").isdigit() and int(slot["mode"]) > 3:
        err.append(f"mode {slot['mode']} not in 0..3 [Invalid configuration mode]")
    cfg, cnt = slot.get("config"), slot.get("config_count")
    if cfg is not None:
        if not (cnt or "").isdigit() or int(cnt) != len(cfg):
            err.append(f"config: {len(cfg)} values but Config_Parmcount = {cnt} [{cnt} values of config data are required]")
        if any(not HEX.match(v) for v in cfg):
            err.append("config: non-hex value [Data values must be in hex]")
    return err


def config_names(xml_dir: Path | None) -> list[str]:
    p = xml_dir / "Config.xml" if xml_dir else None
    return [text(r.get("name")) for r in ET.parse(p).getroot().findall("RowName")] if p and p.is_file() else []


def sensor_rows(xml_path: Path) -> list[dict]:
    """<Startup><Sensor><RowName name><Nibble>D2,D3|D11-D20</Nibble><Combo><Parm>Label:code ...>"""
    rows = []
    for r in ET.parse(xml_path).getroot().iter("RowName"):
        spec = text(r.findtext("Nibble"))
        idx = []
        for part in spec.split(","):
            m = re.fullmatch(r"D(\d+)(?:-D(\d+))?", part.strip())
            if m:
                a, b = int(m.group(1)), int(m.group(2) or m.group(1))
                idx += list(range(a - 1, b))
        combo = {}
        for p in r.iter("Parm"):
            label, _, code = text(p.text).rpartition(":")
            if label:
                combo[label.lower()] = code
        rows.append({"name": text(r.get("name")), "nibbles": idx, "combo": combo})
    return rows


def decode(startup: list[str], rows: list[dict]) -> dict[str, str]:
    out = {}
    for r in rows:
        if r["nibbles"] and max(r["nibbles"]) < 32:
            code = "".join(startup[i] for i in r["nibbles"]).upper()
            label = next((l for l, c in r["combo"].items() if c.upper() == code), None)
            out[r["name"]] = f"{code} ({label})" if label else code
    return out


def apply_fields(startup: list[str], fields: dict[str, str], rows: list[dict]) -> list[str]:
    """Named edits: XML row name -> combo label or hex code with one digit per nibble."""
    new = list(startup)
    for name, value in fields.items():
        row = next((r for r in rows if r["name"].lower() == name.strip().lower()), None)
        if row is None:
            raise ValueError(f"field '{name}' is not a row of the sensor XML ({[r['name'] for r in rows]})")
        if not row["nibbles"] or max(row["nibbles"]) >= 32:
            raise ValueError(f"field '{name}' is outside D1..D32; set mode / status / repetition_factor instead")
        code = row["combo"].get(str(value).lower(), str(value))
        if not HEX.match(code) or len(code) != len(row["nibbles"]):
            raise ValueError(f"field '{name}' needs {len(row['nibbles'])} hex digit(s) or one of {list(row['combo'])}, got '{value}'")
        for i, ch in zip(row["nibbles"], code.upper()):
            new[i] = ch
    return new


def cmd_inspect(args: argparse.Namespace) -> int:
    wb = openpyxl.load_workbook(args.workbook, data_only=True)
    if SHEET not in wb.sheetnames:
        print(f"no '{SHEET}' sheet: not an RSU V1 marker workbook (V2 cards use Overview/Channels/Slots/Sensor sheets)")
        return 2
    ws, (names, broken) = wb[SHEET], markers(wb)
    xml_dir = Path(args.xml_dir) if args.xml_dir else Path(args.workbook).resolve().parent.parent / "XML"
    cfg_names = config_names(xml_dir)
    rows = sensor_rows(Path(args.sensor_xml)) if args.sensor_xml else []
    wanted = {int(s) for s in args.slots.split(",")} if args.slots else None
    report = {"workbook": args.workbook, "broken_defined_names": broken, "slots": []}
    for n in range(1, 65):
        slot = read_slot(ws, names, n)
        if slot is None or (wanted and n not in wanted):
            continue
        slot["errors"] = validate(slot)
        if cfg_names and slot.get("config") and len(slot["config"]) == len(cfg_names):
            slot["config_named"] = {k: f"{v} (={int(v, 16)})" if HEX.match(v) else v for k, v in zip(cfg_names, slot["config"])}
        if rows and slot.get("startup") and len(slot["startup"]) == 32:
            slot["startup_fields"] = decode(slot["startup"], rows)
        report["slots"].append(slot)
    print(json.dumps(report, indent=2))
    return 1 if any(s["errors"] for s in report["slots"]) else 0


def resolve(path: str, root: Path) -> Path:
    p = Path(path)
    return p if p.is_absolute() else root / p


def cmd_build(args: argparse.Namespace) -> int:
    desc = json.loads(Path(args.descriptor).read_text(encoding="utf-8-sig"))  # PowerShell 5.1 writes a BOM
    rsu = desc.get("rsu") or {}
    root = Path(args.config_root)
    template = resolve(args.template or rsu.get("sheet_template", ""), root)
    if not template.is_file():
        print(f"template workbook not found: {template}")
        return 2
    xml_dir = Path(args.xml_dir) if args.xml_dir else root / "Config_folder" / "RSU" / "XML"
    sensor_xml = {s["name"].lower(): xml_dir / s["xml"] for s in rsu.get("sensors", []) if s.get("xml")}
    out = Path(args.out)
    shutil.copyfile(template, out)
    wb = openpyxl.load_workbook(out)
    ws, (names, _) = wb[SHEET], markers(wb)
    refs: dict[Path, tuple] = {}
    for entry in rsu.get("slots", []):
        n = entry["index"]
        slot = read_slot(ws, names, n)
        if slot is None:
            print(f"slot {n}: the template has no Present_Slot{n} marker")
            return 2
        if "reference" in entry:
            rp = resolve(entry["reference"]["workbook"], root)
            if rp not in refs:
                rwb = openpyxl.load_workbook(rp, data_only=True)
                refs[rp] = (rwb[SHEET], markers(rwb)[0])
            base = read_slot(*refs[rp], entry["reference"]["slot"])
            if base is None:
                print(f"slot {n}: reference slot {entry['reference']['slot']} not in {rp}")
                return 2
            slot.update({k: base[k] for k in ("startup", "config", *SETTINGS)})
        if "startup_params" in entry:
            slot["startup"] = [text(v).upper() for v in entry["startup_params"]]
        if "config_params" in entry:
            slot["config"] = [text(v).upper() for v in entry["config_params"]]
        if entry.get("fields"):
            xml = sensor_xml.get(text(entry.get("sensor")).lower())
            if xml is None or not xml.is_file():
                print(f"slot {n}: 'fields' need rsu.sensors[] xml for sensor '{entry.get('sensor')}' (looked in {xml_dir})")
                return 2
            slot["startup"] = apply_fields(slot["startup"], entry["fields"], sensor_rows(xml))
        for k in SETTINGS:
            if k in entry:
                v = entry[k]
                v = MODES.get(str(v).lower(), v) if k == "mode" else int(v) if isinstance(v, bool) else v
                slot[k] = text(v)
        errors = validate(slot)
        if errors:
            print(json.dumps({"slot": n, "errors": errors}, indent=2))
            return 1
        for cell, value in zip(column_cells(ws, names[f"Value_Slot{n}_Start"], names[f"Value_Slot{n}_End"]), slot["startup"]):
            cell.value = value
        cfg_cells = column_cells(ws, names[f"Config_Start{n}"], names[f"Config_End{n}"])
        if len(cfg_cells) != len(slot["config"]):
            print(f"slot {n}: template has {len(cfg_cells)} config cells, data has {len(slot['config'])}; not restructuring the sheet")
            return 1
        for cell, value in zip(cfg_cells, slot["config"]):
            cell.value = value
        for k, p in SETTINGS.items():
            ws[names[p.format(n)]].value = slot[k]
    wb.save(out)
    listed = {e["index"] for e in rsu.get("slots", [])}
    check = openpyxl.load_workbook(out, data_only=True)
    cws, (cnames, _) = check[SHEET], markers(check)
    result = {"out": str(out), "template": str(template), "written_slots": sorted(listed),
              "untouched_template_slots": [n for n in range(1, 65) if f"Present_Slot{n}" in cnames and n not in listed],
              "errors": {n: e for n in sorted(listed) if (e := validate(read_slot(cws, cnames, n)))}}
    print(json.dumps(result, indent=2))
    return 1 if result["errors"] else 0


def cmd_export(args: argparse.Namespace) -> int:
    wb = openpyxl.load_workbook(args.workbook, data_only=True)
    slot = read_slot(wb[SHEET], markers(wb)[0], args.slot)
    errors = validate(slot) if slot else [f"no slot {args.slot}"]
    if errors or len(slot["config"] or []) != 26:
        print(json.dumps({"slot": args.slot, "errors": errors or ["config .rsux needs 26 values"]}, indent=2))
        return 1
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    prefix = f"{args.prefix}_" if args.prefix else ""
    startup = out / f"{prefix}Slot{args.slot}_Startup.rsux"
    config = out / f"{prefix}Slot{args.slot}_Config.rsux"
    lines = slot["startup"] + [slot[k] for k in ("mode", "repetition_factor", "type", "present", "status")]
    startup.write_text("\r\n".join(lines) + "\r\n", encoding="ascii", newline="")
    config.write_text("\r\n".join(slot["config"]) + "\r\n", encoding="ascii", newline="")
    print(json.dumps({"startup": str(startup), "config": str(config)}))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="ARIA RSU V1 marker workbook tool")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("inspect"); p.set_defaults(fn=cmd_inspect)
    p.add_argument("workbook"); p.add_argument("--xml-dir"); p.add_argument("--sensor-xml"); p.add_argument("--slots")
    p = sub.add_parser("build"); p.set_defaults(fn=cmd_build)
    p.add_argument("--descriptor", required=True); p.add_argument("--out", required=True)
    p.add_argument("--template"); p.add_argument("--xml-dir")
    p.add_argument("--config-root", default=str(DEFAULT_CONFIG_ROOT), help="base for relative descriptor paths")
    p = sub.add_parser("export-rsux"); p.set_defaults(fn=cmd_export)
    p.add_argument("workbook"); p.add_argument("--slot", type=int, required=True)
    p.add_argument("--out-dir", required=True); p.add_argument("--prefix")
    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
