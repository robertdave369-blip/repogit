# Blocks every network connection, inbound and outbound, for every .exe of every ARIA install.
# Run in an elevated PowerShell, again after installing a new ARIA version (rules are per exe path):
#   powershell -ExecutionPolicy Bypass -File tools\block_aria_network.ps1 [-AriaDir C:\ARIA5.22]
# Without -AriaDir it covers every C:\ARIA* folder that contains ARIA.exe.
# Rule names: "Block <install folder> <outbound|inbound> - <exe>"; existing rules are kept.
# Loopback (127.0.0.1: apym <-> ARIA local API) is not filtered by Windows Firewall.
param([string[]]$AriaDir)

$ErrorActionPreference = 'Stop'
$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated (Administrator) PowerShell.'
}
if (-not $AriaDir) {
    $AriaDir = Get-ChildItem 'C:\' -Directory -Filter 'ARIA*' | Where-Object { Test-Path (Join-Path $_.FullName 'ARIA.exe') } |
        ForEach-Object FullName
}
if (-not $AriaDir) { throw 'No ARIA install found; pass -AriaDir.' }

foreach ($dir in $AriaDir) {
    $leaf = Split-Path $dir -Leaf
    foreach ($exe in Get-ChildItem $dir -Recurse -Filter *.exe -File) {
        foreach ($direction in 'Outbound', 'Inbound') {
            $name = "Block $leaf $($direction.ToLower()) - $($exe.Name)"
            if (Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue) {
                Write-Host "exists : $name"
                continue
            }
            New-NetFirewallRule -DisplayName $name -Direction $direction -Program $exe.FullName `
                -Action Block -Profile Any -Enabled True | Out-Null
            Write-Host "created: $name"
        }
    }
}

Get-NetFirewallRule -DisplayName 'Block ARIA*' |
    Sort-Object DisplayName |
    Format-Table DisplayName, Direction, Action, Enabled -AutoSize
