"""Requirement -> test case -> script -> result coverage from Codebeamer exports.

Joins requirement exports (columns ID, Summary, _ReqStatus, Type) with test-specification exports
(ID, Name, Verifies, Status, Type, _ScriptPath, _LatestResult) and reports:
  * which Approved functional requirements no test case verifies;
  * how every Verifies link resolves: by ID ([ISSUE:n] or a bare number), by unique requirement
    Summary, ambiguous, or not at all - name links are weak evidence and are counted separately;
  * links to requirements that are not Approved;
  * test cases with no link, script paths that do not exist in the repository, latest results.

It only reads the workbooks. A link that does not resolve means "not resolvable from the exports
given", not "missing in Codebeamer": pass every requirement export the test cases may point to.

Usage
  py -3 tools/trace_coverage.py --req <req.xlsx> [...] --tests <spec.xlsx> [...] [--out <dir>]
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from collections import Counter
from pathlib import Path

import openpyxl

REPO = Path(__file__).resolve().parents[1]
NOT_REQUIREMENTS = {"heading", "information", "folder"}  # structure rows, not verifiable requirements
ISSUE_RE = re.compile(r"\[ISSUE:(\d+)\]")


def norm(text) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(text or "").lower()).strip()


def rows(path: Path) -> list[dict]:
    """Every data row of the export sheet as {header: value}; header names, never positions."""
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb["Export"] if "Export" in wb.sheetnames else wb.worksheets[0]
    it = ws.iter_rows(values_only=True)
    header = [str(h).strip() if h is not None else "" for h in next(it)]
    out = [dict(zip(header, r)) for r in it]
    wb.close()
    return [r for r in out if isinstance(r.get("ID"), (int, float)) or str(r.get("ID") or "").strip().isdigit()]


def load_requirements(paths: list[Path]) -> tuple[dict[str, dict], int]:
    reqs, duplicates = {}, 0
    for path in paths:
        for r in rows(path):
            rid = str(int(float(r["ID"])))
            if rid in reqs:
                duplicates += 1
                continue
            reqs[rid] = {"id": rid, "summary": str(r.get("Summary") or "").strip(),
                         "status": str(r.get("_ReqStatus") or r.get("Status") or "").strip(),
                         "type": str(r.get("Type") or "").strip(), "source": path.name, "tests": [],
                         "by_id": False}
    return reqs, duplicates


def parse_links(cell) -> tuple[list[str], list[str]]:
    """(requirement IDs, requirement names) named in one Verifies cell."""
    text = str(cell or "")
    ids = ISSUE_RE.findall(text)
    rest = ISSUE_RE.sub("", text)
    names = []
    for token in re.split(r"[,\n]", rest):
        token = re.sub(r"\s*-\s*null\s*$", "", token).strip()
        if token.isdigit():
            ids.append(token)
        elif token and token.lower() != "null":
            names.append(token)
    return list(dict.fromkeys(ids)), list(dict.fromkeys(names))


def analyse(req_paths: list[Path], test_paths: list[Path]) -> dict:
    reqs, duplicates = load_requirements(req_paths)
    by_name: dict[str, list[str]] = {}
    for rid, r in reqs.items():
        if r["summary"]:
            by_name.setdefault(norm(r["summary"]), []).append(rid)
    links, tests, seen, test_duplicates = Counter(), [], set(), 0
    for path in test_paths:
        for t in rows(path):
            if str(t.get("Type") or "").strip().lower() == "folder":
                continue
            tid = str(int(float(t["ID"])))
            if tid in seen:  # the same test case exported in several workbooks counts once (first file wins)
                test_duplicates += 1
                continue
            seen.add(tid)
            ids, names = parse_links(t.get("Verifies"))
            resolved, issues = [], []
            for rid in ids:
                if rid in reqs:
                    resolved.append(rid)
                    reqs[rid]["by_id"] = True
                    links["id_resolved"] += 1
                else:
                    issues.append(f"unknown ID {rid}")
                    links["id_unknown"] += 1
            for name in names:
                hits = by_name.get(norm(name), [])
                if len(hits) == 1:
                    resolved.append(hits[0])
                    links["name_resolved"] += 1
                elif hits:
                    issues.append(f"ambiguous name '{name}' ({len(hits)} requirements)")
                    links["name_ambiguous"] += 1
                else:
                    issues.append(f"unresolved name '{name}'")
                    links["name_unresolved"] += 1
            for rid in dict.fromkeys(resolved):
                reqs[rid]["tests"].append(tid)
                if reqs[rid]["status"].lower() != "approved":
                    issues.append(f"links {rid} with status '{reqs[rid]['status']}'")
                    links["to_not_approved"] += 1
            script = str(t.get("_ScriptPath") or "").strip()
            tests.append({"id": tid, "name": str(t.get("Name") or "").strip(),
                          "status": str(t.get("Status") or "").strip(), "source": path.name,
                          "requirements": ";".join(dict.fromkeys(resolved)), "issues": "; ".join(issues),
                          "has_links": bool(ids or names), "script": script,
                          "script_exists": bool(script) and (REPO / script).exists(),
                          "latest_result": str(t.get("_LatestResult") or "").strip()})
    functional = [r for r in reqs.values() if r["type"].lower() not in NOT_REQUIREMENTS]
    approved = [r for r in functional if r["status"].lower() == "approved"]
    return {"requirements": reqs, "tests": tests, "links": links, "duplicates": duplicates,
            "test_duplicates": test_duplicates,
            "functional": functional, "approved": approved,
            "uncovered": [r for r in approved if not r["tests"]]}


def summary(result: dict) -> str:
    tests, links = result["tests"], result["links"]
    approved = result["approved"]
    lines = [
        "# Trace coverage",
        "",
        f"- Requirements read: {len(result['requirements'])} ({len(result['functional'])} functional, "
        f"{len(approved)} Approved; {result['duplicates']} duplicate rows skipped)",
        f"- Approved requirements verified by at least one test case: {len(approved) - len(result['uncovered'])}"
        f" of {len(approved)} ({sum(r['by_id'] for r in approved)} through an ID link; the rest only through "
        f"name links)",
        f"- Test cases: {len(tests)} distinct ({result['test_duplicates']} repeated rows in other workbooks "
        f"skipped); without any Verifies link: {sum(not t['has_links'] for t in tests)}",
        f"- Links by ID: {links['id_resolved']} resolved, {links['id_unknown']} unknown ID",
        f"- Links by name (weak): {links['name_resolved']} resolved, {links['name_ambiguous']} ambiguous, "
        f"{links['name_unresolved']} unresolved",
        f"- Links to requirements that are not Approved: {links['to_not_approved']}",
        f"- Script paths given: {sum(bool(t['script']) for t in tests)}; existing in the repository: "
        f"{sum(t['script_exists'] for t in tests)}",
        f"- Latest results: {dict(Counter(t['latest_result'] or '(none)' for t in tests))}",
    ]
    return "\n".join(lines) + "\n"


def write(result: dict, out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    (out / "coverage_summary.md").write_text(summary(result), encoding="utf-8")
    with open(out / "requirements.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "status", "type", "summary", "source", "verified_by"])
        for r in result["requirements"].values():
            w.writerow([r["id"], r["status"], r["type"], r["summary"], r["source"], ";".join(r["tests"])])
    with open(out / "test_links.csv", "w", newline="", encoding="utf-8") as f:
        keys = ["id", "name", "status", "source", "requirements", "issues", "script", "script_exists", "latest_result"]
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(result["tests"])


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # pyright: ignore[reportAttributeAccessIssue]
    ap = argparse.ArgumentParser(description="Requirement -> test case -> script -> result coverage.")
    ap.add_argument("--req", nargs="+", type=Path, required=True, help="requirement export workbook(s)")
    ap.add_argument("--tests", nargs="+", type=Path, required=True, help="test-specification export workbook(s)")
    ap.add_argument("--out", type=Path, help="folder for coverage_summary.md, requirements.csv, test_links.csv")
    a = ap.parse_args()
    result = analyse(a.req, a.tests)
    print(summary(result), end="")
    if a.out:
        write(result, a.out)
        print(f"written to {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
