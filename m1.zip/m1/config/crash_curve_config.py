"""Crash curves of M210.

The shared crash_configuration table (PROJECT_CRASH_CURVE_CONFIGS) has no M210 entry, and the
crash-curve resolver of core_functions reads CRASH_CURVE_CONFIG from this module before it
falls back to that table. M314 value: M210 uses the EV curve files (crash_data/m310_m314_m110)
and their SPI layout until its own curves are supplied. The RSU channel allocation and
inversion below are M210's own bench wiring (user, 2026-10-28).
"""
from Framework_IOEM_Py.shared_libraries.crash_configuration import (
    CRASH_TYPES,
    M310_M314_M110_FRONT_CRASH_TEST_DATA_DIR,
    M310_M314_M110_LEFT_CRASH_TEST_DATA_DIR,
    M310_M314_M110_NEAR_CRASH_TEST_DATA_DIR,
    M310_M314_M110_REAR_CRASH_TEST_DATA_DIR,
    M310_M314_M110_REAR_SPI_SPECS,
    M310_M314_M110_RIGHT_CRASH_TEST_DATA_DIR,
    M310_M314_M110_RIGHT_SPI_SPECS,
    M310_M314_M110_SPI_SPECS,
    M310_M314_M110_UNDERSTRIKE_CRASH_TEST_DATA_DIR,
    build_rsu_config,
    build_spi_config,
    multi_event_crash_curve_configs,
)

PROJECT_NAME = "M210"

# M210 RSU channels (user, 2026-10-28): (ARIA channel, curve, inverted, match the curve file
# by name). Generated curves are positive; the inversion gives the onboard sign at the ECU
# input (right-side and centre sensors inverted). Channels 10, 12 and 19 were not given and
# the curve set has no HVD RSU curve, so those channels play the zero curve.
M210_RSU_CHANNEL_SPECS = [
    ("RSU_CH1", "Side A-Pillar Left RSU_Acc_Y", False, True),
    ("RSU_CH2", "Side A-Pillar Left RSU_Acc_X", False, True),
    ("RSU_CH3", "Side A-Pillar Right RSU_Acc_Y", True, True),
    ("RSU_CH4", "Side A-Pillar Right RSU_Acc_X", True, True),
    ("RSU_CH5", "Side B-Pillar Left RSU_Acc_Y", False, True),
    ("RSU_CH6", "Side B-Pillar Left RSU_Acc_X", False, True),
    ("RSU_CH7", "Side B-Pillar Right RSU_Acc_Y", True, True),
    ("RSU_CH8", "Side B-Pillar Right RSU_Acc_X", True, True),
    ("RSU_CH9", "Front Left RSU_Acc_X", False, True),
    ("RSU_CH10", "Sensor_With_0_values", False, True),
    ("RSU_CH11", "Front Right RSU_Acc_X", False, True),
    ("RSU_CH12", "Sensor_With_0_values", False, True),
    ("RSU_CH13", "Side C-Pillar Left RSU_Acc_Y", False, True),
    ("RSU_CH14", "Side C-Pillar Left RSU_Acc_X", False, True),
    ("RSU_CH15", "Side C-Pillar Right RSU_Acc_Y", True, True),
    ("RSU_CH16", "Side C-Pillar Right RSU_Acc_X", True, True),
    ("RSU_CH17", "Sensor_With_0_values", True, True),   # HVD RSU Y, inverted
    ("RSU_CH18", "Sensor_With_0_values", True, True),   # HVD RSU Z, inverted
    ("RSU_CH19", "Sensor_With_0_values", False, True),
    ("RSU_CH20", "Mid Center RSU_Acc_X", True, True),
]

# Curve folder and SPI layout of each crash type (the EV curve set).
_FOLDERS = {
    "front": M310_M314_M110_FRONT_CRASH_TEST_DATA_DIR,
    "left": M310_M314_M110_LEFT_CRASH_TEST_DATA_DIR,
    "right": M310_M314_M110_RIGHT_CRASH_TEST_DATA_DIR,
    "rear": M310_M314_M110_REAR_CRASH_TEST_DATA_DIR,
    "near": M310_M314_M110_NEAR_CRASH_TEST_DATA_DIR,
    "understrike": M310_M314_M110_UNDERSTRIKE_CRASH_TEST_DATA_DIR,
}
M210_SPI_SPECS = {
    "front": M310_M314_M110_SPI_SPECS,
    "left": M310_M314_M110_SPI_SPECS,
    "right": M310_M314_M110_RIGHT_SPI_SPECS,
    "rear": M310_M314_M110_REAR_SPI_SPECS,
    "near": M310_M314_M110_SPI_SPECS,
    "understrike": M310_M314_M110_SPI_SPECS,
}

CRASH_CURVE_CONFIG = {
    crash_type: {
        "RSU": build_rsu_config(folder, M210_RSU_CHANNEL_SPECS),
        "SPI": build_spi_config(folder, M210_SPI_SPECS[crash_type]),
    }
    for crash_type, folder in _FOLDERS.items()
}
CRASH_CURVE_CONFIG.update(multi_event_crash_curve_configs(
    dict.fromkeys(CRASH_TYPES, M210_RSU_CHANNEL_SPECS),
    {crash_type: M210_SPI_SPECS[crash_type] for crash_type in CRASH_TYPES},
))
