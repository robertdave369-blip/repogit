# Author: Kris
#
# EDR CAN-C 5.4, M210 (EV) - DoorsOpenStatus (FR_ZONE3_100 / STS_DOOR).
# Signal never received, one crash per value of TestCase_5_Values.
# The variant code is changed before each pair of crashes (the pair ends with the
# fault-free profile); every crash must record the on-fail default value.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants,
# bench and report calls, EDR decoding). The two ARIA calls come through it and run
# before anything below uses the bench or the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration: the signal, its EDR element, the crash timing.
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_TX_MESSAGE_CONFIG, MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    EDR_DECODER_CONFIG, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.M210.config.project_config import DEFAULT_VARIANT_CODE
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS


def run_test():
    tc_id = "5.4"
    tc_desc = ("Signal never received: the DoorsOpenStatus snapshot must hold the on-fail "
               "default value.")
    tc_behaviour = ("Signal never received: every crash records the on-fail default "
                    "value.")

    # -- 1. What is tested, from the configuration ----------------------------------
    signal = MAH_CAN_SIGNAL_DEFS["STS_DOOR"]       # FR_ZONE3_100 / STS_DOOR
    frame, name = signal["frame"], signal["signal"]
    values = signal["TestCase_5_Values"]              # raw CAN values, one per sample
    element = EDR_PARAMETERS_BY_NAME[signal["EDR_Parameter"]]
    bits, unit = element["data_bit_length"], element["unit"]
    can_unit = signal.get("UNIT") or ""    # the CAN signal's unit, for the report
    can_bits = signal["bit_length"]    # the CAN signal's width, for the bench read-back

    # A snapshot element: the record keeps the one value present at T0. Each value is
    # driven, the crash fires half a window later, and the ECU takes T0 t0_offset_ms
    # after the trigger (rsu_config, 0 when not known) while the value is still driven.
    crash_type = "front"
    interval_ms = get_sample_interval_ms(element["name"])
    time_axis, t0_index = build_time_axis_and_t0(element["name"], crash_type)
    t0_offset_ms = RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS["default"])
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    # The crash fires half a window after the value is set and T0 follows t0_offset_ms
    # later, while the value is still driven.
    if t0_offset_ms < 0:
        raise ValueError(f"T0 offset {t0_offset_ms} ms: T0 cannot come before the trigger")
    # Signal never received: the bit of the node that sends the frame is cleared in the
    # variant code, so the ECU treats the node as not installed.
    target = CAN_TX_MESSAGE_CONFIG[frame]["key_node"]

    # -- 2. Expected results -------------------------------------------------------
    # On-fail requirement: every crash records the signal's default value (DBC "Default").
    crashes = list(values)
    if len(crashes) % len(EDR_RECORD_DIDS):
        crashes.append(crashes[0])    # both records are always written
    # The node is treated as not installed, so it is not monitored: crash DTCs only.
    expected_dtcs = " ".join([
        Read_DTC_Resp,
        Crash_DTC, DTC_status["DTC_active"],
        PT_Crash_DTC, DTC_status["DTC_active"],
    ])

    # -- 3. Report and bench ---------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#EDR Element:", element["name"])
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)

    # A snapshot element holds one sample: each crash records one value.
    RESULT.InterpretEqualResult(
        "Samples in the record (snapshot)", str(element["data_samples_number"]), "1")
    # The record keeps the CAN signal's resolution, so a recorded raw equals the CAN raw.
    RESULT.InterpretEqualResult(
        "Record resolution / offset = CAN resolution / offset",
        f"{format_physical(element['scaling_factor'])} / {format_physical(element['offset'])}",
        f"{format_physical(signal['Factor'])} / {format_physical(signal['Offset'])}")

    fault_free_profile()
    read_software_version()

    try:
        for first in range(0, len(crashes), len(EDR_RECORD_DIDS)):
            # The fault is created before the crashes. The write starts from the project's default
            # variant code and includes the ignition cycle that applies it.
            result = manage_variant_code(target, "disable", base_variant_code=DEFAULT_VARIANT_CODE)
            RESULT.InterpretEqualResult(
                f"Variant code written with {target} cleared", result.get("status"), "PASS")
            RESULT.InterpretEqualResult(
                f"{target} was set in the default variant code, so clearing it changes it",
                "changed" if result.get("bit_before") != result.get("bit_after") else "unchanged",
                "changed")

            for did, value in zip(EDR_RECORD_DIDS, crashes[first:first + len(EDR_RECORD_DIDS)]):
                expected = [signal["Default_Value"]]

                # -- 4. Drive the T0 window, crash at T0 ----------------------------
                load_crash_curves(crash_type)    # power-cycles the ECU with the crash curves loaded
                aria_reports.add_group(
                    f"Record {did}: CAN simulation of {frame} / {name} = {value}, "
                    "signal never received")
                raw = value
                CAN.ChangeSignalValue(frame, name, str(raw))
                # The crash fires half a window after the value is set; T0 is t0_offset_ms later.
                Wait(interval_ms // 2)
                TriggerCrash()
                Wait(interval_ms - interval_ms // 2 + t0_offset_ms)
                on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                RESULT.InterpretEqualResult(
                    f"CAN simulation {frame} / {name}, T0 sample: "
                    f"{format_physical(raw * signal['Factor'] + signal['Offset'])} {can_unit}",
                    raw_hex(on_bench, can_bits), raw_hex(raw, can_bits))
                aria_reports.close_group()

                # -- 5. DTCs, read once the interval is over ------------------------------
                aria_reports.add_group(f"Record {did}: DTCs")
                Read_DTC("DTCs after the crash", expected_dtcs, Read_DTC_Req)
                aria_reports.close_group()

                # -- 6. The event record -------------------------------------------------
                Wait(record_ready_ms)
                response = read_edr_parameters(
                    [element["name"]], did=did, crash_type=crash_type, return_data=True)
                recorded = edr_sample_records(element["name"], response["data"])
                aria_reports.add_group(f"Record {did}: {element['name']} as recorded")
                for index, raw in enumerate(expected):
                    missing = {"hex": "no sample", "physical": "no sample"}
                    sample = recorded[index] if index < len(recorded) else missing
                    label = f"{element['name']} at T0"
                    RESULT.InterpretEqualResult(f"{label} - raw", sample["hex"], raw_hex(raw, bits))
                    RESULT.InterpretEqualResult(
                        f"{label} - {unit}", format_physical(sample["physical"]),
                        format_physical(raw * element["scaling_factor"] + element["offset"]))
                aria_reports.close_group()

            # Both records hold a locked crash: back to fault free (NVM cleared) for the
            # next pair.
            fault_free_profile()

    finally:
        # -- 7. Restore the bench, even when a step above raised ------------------------
        # fault_free_profile() below writes the default variant code back.
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
