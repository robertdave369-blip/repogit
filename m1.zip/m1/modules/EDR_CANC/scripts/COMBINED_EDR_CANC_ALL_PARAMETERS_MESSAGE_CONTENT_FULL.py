# Author: Christy, Krishna
#
# Every CAN-C parameter driven together in one crash, with one fault family applied to
# every parameter that supports it (or none, for the nominal run).

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M210 project configuration ---------------------
from Framework_IOEM_Py.projects.M210.config.edr_config import EDR_DECODER_CONFIG, EDR_DIDS
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS
from Framework_IOEM_Py.projects.M210.config.canc_config import PROJECT_NAME
from Framework_IOEM_Py.projects.M210.config.canc_config import *
# The Variant Code DTC is common to every project and defined once, in the shared
# configuration control. It is imported after the project configuration, so nothing
# there can replace it.
from Framework_IOEM_Py.shared_libraries.configuration_control import Variant_Code_DTC


EDR_RECORD_DIDS = tuple(f"{did:04X}" for did in EDR_DIDS.values())

FAULT_MODE = 'message_content'
FAULT_SCOPE = 'full'

# series    the per-case series number, which names the value arrays in canc_config
# signal    the key into MAH_CAN_SIGNAL_DEFS
# element   the EDR element the record carries it in
# applies   whether this run's fault is applied to it (it has that per-case script)
# follows   the interval series whose value a snapshot sharing its CAN signal records
PARAMETERS = [   {   'series': 1,
        'signal': 'VEHICLE_SPEED_ESC12',
        'element': 'VehSpdLgtAtTimeZero',
        'applies': True,
        'follows': 6},
    {   'series': 2,
        'signal': 'ODOMTR_READING',
        'element': 'Odometer',
        'applies': True,
        'follows': None},
    {   'series': 3,
        'signal': 'STS_HIGH_BEAM',
        'element': 'Front Head Lamp Status',
        'applies': True,
        'follows': 49},
    {   'series': 5,
        'signal': 'STS_DOOR',
        'element': 'DoorsOpenStatus',
        'applies': True,
        'follows': None},
    {   'series': 6,
        'signal': 'VEHICLE_SPEED_ESC12',
        'element': 'VehSpdLgt',
        'applies': True,
        'follows': None},
    {   'series': 7,
        'signal': 'BRK_SWITCH',
        'element': 'BRAKE_PEDAL_VALUE',
        'applies': True,
        'follows': None},
    {'series': 8, 'signal': 'ACC_PED1', 'element': 'ACC_PED', 'applies': True, 'follows': None},
    {   'series': 9,
        'signal': 'ENG_SPD1',
        'element': 'Engine_Speed',
        'applies': True,
        'follows': None},
    {   'series': 10,
        'signal': 'ABS_ACTIVE',
        'element': 'ABS_ACTIVE',
        'applies': True,
        'follows': None},
    {   'series': 11,
        'signal': 'ABSOLUTE_ANGLE',
        'element': 'STEERING_ABSOLUTE_ANGLE',
        'applies': True,
        'follows': None},
    {   'series': 12,
        'signal': 'ESC_ACTIVE',
        'element': 'ESC_ACTIVE',
        'applies': True,
        'follows': None},
    {   'series': 13,
        'signal': 'FL_TYRE_PRESSURE',
        'element': 'Tyre_Pressure_FL',
        'applies': True,
        'follows': None},
    {   'series': 14,
        'signal': 'FR_TYRE_PRESSURE',
        'element': 'Tyre_Pressure_FR',
        'applies': True,
        'follows': None},
    {   'series': 15,
        'signal': 'RL_TYRE_PRESSURE',
        'element': 'Tyre_Pressure_RL',
        'applies': True,
        'follows': None},
    {   'series': 16,
        'signal': 'RR_TYRE_PRESSURE',
        'element': 'Tyre_Pressure_RR',
        'applies': True,
        'follows': None},
    {   'series': 17,
        'signal': 'MASTER_CYL_PRESSURE',
        'element': 'Master_Cylinder_Pressure',
        'applies': True,
        'follows': None},
    {   'series': 18,
        'signal': 'GEAR_ACTUAL',
        'element': 'GEAR_ACTUAL',
        'applies': True,
        'follows': None},
    {   'series': 19,
        'signal': 'STS_DRIVER_DOOR_LATCH',
        'element': 'Door Lock Status',
        'applies': True,
        'follows': None},
    {   'series': 23,
        'signal': 'TCS_ACTIVE_IEB',
        'element': 'TCS_ACTIVE_IEB',
        'applies': True,
        'follows': None},
    {   'series': 24,
        'signal': 'AEB_WARNING_MSG1',
        'element': 'AEB_WARNING_MSG1',
        'applies': True,
        'follows': None},
    {   'series': 25,
        'signal': 'AEB_FCTA_WARN',
        'element': 'AEB_FCTA_WARN',
        'applies': True,
        'follows': None},
    {'series': 26, 'signal': 'RCTA_WARN', 'element': 'RCTA_WARN', 'applies': True, 'follows': None},
    {   'series': 27,
        'signal': 'SEB_WARNING_LEFT',
        'element': 'SEB_WARNING_LEFT',
        'applies': True,
        'follows': None},
    {   'series': 28,
        'signal': 'SEB_WARNING_RIGHT',
        'element': 'SEB_WARNING_RIGHT',
        'applies': True,
        'follows': None},
    {   'series': 29,
        'signal': 'AES_WARNING1',
        'element': 'AES_WARNING1',
        'applies': True,
        'follows': None},
    {   'series': 30,
        'signal': 'AES_SYS_STS1',
        'element': 'AES_SYS_STS1',
        'applies': True,
        'follows': None},
    {   'series': 31,
        'signal': 'ESA_SYS_STS1',
        'element': 'ESA_SYS_STS1',
        'applies': True,
        'follows': None},
    {   'series': 32,
        'signal': 'LDW_LKA_WARNING1',
        'element': 'LDW_LKA_WARNING1',
        'applies': True,
        'follows': None},
    {   'series': 33,
        'signal': 'ADAS_DES_STRWHL_ANGLE_CMD',
        'element': 'ADAS_Des_StrWhl_Angle_Cmd',
        'applies': True,
        'follows': None},
    {   'series': 34,
        'signal': 'LDW_LKA_SYS_STATE1',
        'element': 'LDW_LKA_SYS_STATE1',
        'applies': True,
        'follows': None},
    {   'series': 35,
        'signal': 'LKA_HANDSOFF_DISPLAY_WARNING1',
        'element': 'LKA_HANDSOFF_DISPLAY_WARNING1',
        'applies': True,
        'follows': None},
    {   'series': 36,
        'signal': 'LCF_SYS_STATE1',
        'element': 'LCF_SYS_STATE1',
        'applies': True,
        'follows': None},
    {   'series': 37,
        'signal': 'SPA_SYS_STATE1',
        'element': 'SPA_SYS_STATE1',
        'applies': True,
        'follows': None},
    {   'series': 38,
        'signal': 'SPA_LCF_HANDS_OFF_WARNING1',
        'element': 'SPA_LCF_HANDS_OFF_WARNING1',
        'applies': True,
        'follows': None},
    {   'series': 39,
        'signal': 'ACC_SYS_STATE',
        'element': 'ACC_SYS_STATE',
        'applies': True,
        'follows': None},
    {   'series': 40,
        'signal': 'NP_SYS_STS1',
        'element': 'NP_SYS_STS1',
        'applies': True,
        'follows': None},
    {   'series': 41,
        'signal': 'RMS_MODE_STATE1',
        'element': 'RMS_MODE_STATE1',
        'applies': True,
        'follows': None},
    {   'series': 42,
        'signal': 'LC_PATH_STATE1',
        'element': 'LC_PATH_STATE1',
        'applies': True,
        'follows': None},
    {   'series': 43,
        'signal': 'ELK_ONCOMING_WARNING1',
        'element': 'ELK_ONCOMING_WARNING1',
        'applies': True,
        'follows': None},
    {   'series': 44,
        'signal': 'ELK_SIDE_WARNING1',
        'element': 'ELK_SIDE_WARNING1',
        'applies': True,
        'follows': None},
    {   'series': 45,
        'signal': 'ELK_OVERTAKING_WARNING1',
        'element': 'ELK_OVERTAKING_WARNING1',
        'applies': True,
        'follows': None},
    {'series': 46, 'signal': 'RCW_WARN', 'element': 'RCW_WARN', 'applies': True, 'follows': None},
    {   'series': 47,
        'signal': 'VCU_OPRT_REQ',
        'element': 'VCU_OPRT_REQ',
        'applies': True,
        'follows': None},
    {   'series': 48,
        'signal': 'VCU_TRQ_CMD',
        'element': 'VCU_TRQ_CMD',
        'applies': True,
        'follows': None},
    {   'series': 49,
        'signal': 'STS_HIGH_BEAM',
        'element': 'STS_HIGH_BEAM',
        'applies': True,
        'follows': None},
    {   'series': 50,
        'signal': 'STS_LOW_BEAM',
        'element': 'STS_LOW_BEAM',
        'applies': True,
        'follows': None},
    {   'series': 51,
        'signal': 'STS_TPMS_LED',
        'element': 'STS_TPMS_LED',
        'applies': True,
        'follows': None},
    {'series': 52, 'signal': 'BATT_VOLT', 'element': 'BATT_VOLT', 'applies': True, 'follows': None},
    {'series': 53, 'signal': 'STS_ABS', 'element': 'STS_ABS', 'applies': True, 'follows': None},
    {'series': 54, 'signal': 'STS_EBD', 'element': 'STS_EBD', 'applies': True, 'follows': None},
    {'series': 55, 'signal': 'STS_ESC', 'element': 'STS_ESC', 'applies': True, 'follows': None},
    {'series': 56, 'signal': 'STS_TCS', 'element': 'STS_TCS', 'applies': True, 'follows': None},
    {   'series': 57,
        'signal': 'PADDLE_SHIFT_POSITION',
        'element': 'PADDLE_SHIFT_POSITION',
        'applies': True,
        'follows': None},
    {   'series': 58,
        'signal': 'VCU_IGN_STS',
        'element': 'VCU_IGN_STS',
        'applies': True,
        'follows': None},
    {   'series': 59,
        'signal': 'EMERGENCY_BRAKING_REQ',
        'element': 'EMERGENCY_BRAKING_REQ',
        'applies': True,
        'follows': None},
    {   'series': 60,
        'signal': 'TORQUE_SPLIT_RATIO',
        'element': 'TORQUE_SPLIT_RATIO',
        'applies': True,
        'follows': None},
    {   'series': 61,
        'signal': 'ALERT_MESSAGE',
        'element': 'ALERT_MESSAGE',
        'applies': True,
        'follows': None},
    {   'series': 62,
        'signal': 'VCU_DRV_ADV_MODE',
        'element': 'VCU_DRV_ADV_MODE',
        'applies': True,
        'follows': None},
    {   'series': 63,
        'signal': 'VCU_DRV_ADV_MODE_STS',
        'element': 'VCU_DRV_ADV_MODE_STS',
        'applies': True,
        'follows': None}]

# Signal never received clears, per frame, the variant-code bit of the node that sends it:
# CAN_TX_MESSAGE_CONFIG key_node, except where this map names another node.
SNR_NODE_OVERRIDE = {'HPCC_1_100': 'HPC_C'}

# What the record holds while each fault family is active (on-fail matrix).
REACTION = {
    "node_absent": "last_valid",
    "message_timeout": "last_valid",
    "message_content": "last_valid",
    "signal_content": "consume",
    "signal_never_received": "default",
    "variant_code_error": "default",
}


def _raw(value):
    try:
        return int(str(value), 16) if str(value).lower().startswith("0x") else int(value)
    except (TypeError, ValueError):
        return None


def run_test():
    tc_id = 'ALL.MESSAGE_CONTENT_FULL'
    tc_name = 'COMBINED_EDR_CANC_ALL_PARAMETERS_MESSAGE_CONTENT_FULL'
    tc_desc = 'Verify every EV (M210) CAN-C EDR parameter recording while Message Content in full interval is applied to the 59 parameter(s) that support it, all driven together in one crash on their own recording intervals, with the crash triggered at T0.'
    tc_category = 'Message Content in full interval - all parameters together'
    tc_priority = 'Highest'

    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"
    t0_offset_ms = int(RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS.get("default", 0)) or 0)
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    definitions = {parameter.get("name"): parameter for parameter in get_edr_parameters()}
    reaction = REACTION.get(FAULT_MODE)

    # -- One plan per parameter, from canc_config and edr_config --------------
    plans = []
    for entry in PARAMETERS:
        signal_def = MAH_CAN_SIGNAL_DEFS[entry["signal"]]
        record = definitions.get(entry["element"]) or {}
        fault_logic = signal_def.get("fault_logic") or {}
        invalid = signal_def.get(f"TestCase_{entry['series']}_Invalid_Values") or []
        values = signal_def.get(f"TestCase_{entry['series']}_Values") or []
        # Recording times count from the ECU's T0; the T0 offset moves the trigger only.
        time_axis, t0_index = build_time_axis_and_t0(entry["element"], crash_type)
        time_axis = [round(float(t), 6) for t in time_axis]
        plans.append({
            **entry,
            "signal_def": signal_def,
            "frame": signal_def["frame"],
            "sig": signal_def["signal"],
            "key_frame": fault_logic.get("key_message"),
            "timeout_frame": fault_logic.get("non_key_timeout_frame"),
            # The variant-code node of the frame (manage_variant_code takes node names).
            "node": SNR_NODE_OVERRIDE.get(signal_def["frame"])
                    or (CAN_TX_MESSAGE_CONFIG.get(signal_def["frame"]) or {}).get("key_node"),
            "periodicity": signal_def.get("periodicity"),
            "bit_length": signal_def.get("bit_length") or record.get("data_bit_length"),
            "signed": signal_def.get("Signed", False),
            "factor": signal_def.get("Factor", 1),
            "offset": signal_def.get("Offset", 0),
            # A recorded sample stands for raw x resolution + offset, in the unit of the
            # CAN signal it is taken from.
            "edr_unit": signal_def.get("UNIT") or record.get("unit") or "",
            "default_raw": signal_def.get("Default_Value", 0),
            # On-fail requirement where it differs from the DBC default (canc_config).
            "snr_required": signal_def.get(f"TestCase_{entry['series']}_SNR_Values"),
            "vc_required": signal_def.get(f"TestCase_{entry['series']}_VC_Values"),
            "invalid_raw": invalid[0] if invalid else None,
            "exception_codes": set(invalid),
            "values": values if isinstance(values, list) else [values],
            "time_axis": time_axis,
            "t0": next((i for i, t in enumerate(time_axis) if abs(t) < 1e-9), t0_index),
            "samples": record.get("data_samples_number") or 1,
            "record": record,
            "edr_bits": record.get("data_bit_length") or signal_def.get("bit_length"),
            "edr_signed": bool(record.get("signed")),
            "edr_scaling": record.get("scaling_factor", 1),
            "edr_offset": record.get("offset", 0),
        })
    by_series = {plan["series"]: plan for plan in plans}
    driven = [plan for plan in plans if not plan["follows"]]
    applying = [plan for plan in driven if plan["applies"]]

    # Without its record layout a parameter has nothing to verify. That is a configuration
    # gap rather than a test result, so it stops the run here, before the bench is touched.
    missing = [plan["element"] for plan in plans if not plan["record"]]
    if missing:
        raise KeyError(f"No {PROJECT_NAME} edr_config entry for: {', '.join(missing)}")

    # -- Which parameters the fault reaches ------------------------------------
    # Node absent stops each applying parameter's node key frame, so every parameter of
    # those nodes holds its last valid value; a node with a parameter on another frame stops
    # every frame canc_config gives it, as stopping the key frame alone would leave that
    # parameter on the bus until the ECU detects the absent node (50 key-frame periods).
    # Message timeout stops each signal-carrying
    # frame, message content breaks each frame's integrity signal, signal content drives
    # the invalid code of each applying signal, and signal never received clears each
    # applying node from the variant code. Variant code error clears the variant status
    # bit instead, which puts every parameter received from a node in error at once.
    stopped_frames, broken_frames, cleared_nodes, consuming = [], [], [], set()
    key_frames = set()
    if FAULT_MODE == "node_absent":
        key_frames = {plan["key_frame"] for plan in applying if plan["key_frame"]}
        stopped_frames = set(key_frames)
        for plan in plans:
            if plan["key_frame"] in key_frames and plan["frame"] != plan["key_frame"]:
                node = CAN_TX_MESSAGE_CONFIG[plan["key_frame"]]["key_node"]
                stopped_frames.update(frame for frame, config in CAN_TX_MESSAGE_CONFIG.items()
                                      if config["key_node"] == node)
        stopped_frames = sorted(stopped_frames)
    elif FAULT_MODE == "message_timeout":
        stopped_frames = sorted({plan["timeout_frame"] for plan in applying if plan["timeout_frame"]})
    elif FAULT_MODE == "message_content":
        broken_frames = sorted({(plan["frame"], choose_message_content_failure_signal(plan["frame"]))
                                for plan in applying})
        broken_frames = [pair for pair in broken_frames if pair[1]]
    elif FAULT_MODE == "signal_content":
        consuming = {plan["series"] for plan in applying if plan["invalid_raw"] is not None}
    elif FAULT_MODE == "signal_never_received":
        cleared_nodes = sorted({plan["node"] for plan in applying if plan["node"]})
    elif FAULT_MODE == "variant_code_error":
        cleared_nodes = ["VARIANT_STATUS"]

    def affected(plan):
        if FAULT_MODE == "node_absent":
            return plan["key_frame"] in stopped_frames
        if FAULT_MODE == "message_timeout":
            return plan["frame"] in stopped_frames
        if FAULT_MODE == "message_content":
            return plan["frame"] in {frame for frame, _ in broken_frames}
        if FAULT_MODE == "signal_content":
            return plan["series"] in consuming
        if FAULT_MODE == "signal_never_received":
            return plan["node"] in cleared_nodes
        if FAULT_MODE == "variant_code_error":
            return plan["key_frame"] is not None
        return False

    def in_fault(plan, idx):
        if not affected(plan):
            return False
        if FAULT_SCOPE == "pre":
            return idx < plan["t0"]
        if FAULT_SCOPE == "post":
            return idx > plan["t0"]
        return True

    # -- Report and logging --------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([plan["signal_def"] for plan in driven])
    create_report_and_logging(test_case_file, can_ids=can_ids, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Test Case Category:", tc_category)
    aria_reports.add_report_info("#Priority:", tc_priority)
    aria_reports.add_report_info("#Parameters covered:", str(len(plans)))
    aria_reports.add_report_info(
        "#Parameters the fault reaches:", str(sum(1 for plan in plans if affected(plan))))

    for plan in plans:
        if plan["samples"] > 1:
            RESULT.InterpretEqualResult(
                f"{plan['element']}: values driven match the samples the record holds",
                str(len(plan["values"])), str(plan["samples"]))

    # -- DTCs the fault raises ---------------------------------------------------
    # A pre-crash fault heals before T0 and no ignition cycle comes before the DTC read, so
    # its DTC reads healed (on-fail rule; the per-case scripts expect the same).
    status = DTC_status["DTC_healed" if FAULT_SCOPE == "pre" else "DTC_active_WLOFF"]
    can_dtcs = []
    if FAULT_MODE == "node_absent":
        can_dtcs = [resolve_dtc_for_event("node_absent", frame) for frame in sorted(key_frames)]
        # A silent node's non-key frames are missing too, so its message timeout DTC is set
        # as well (DTC list: "at least one non-key message is missing").
        can_dtcs += [resolve_dtc_for_event("message_timeout", frame)
                     for frame in stopped_frames if frame not in key_frames]
    elif FAULT_MODE == "message_timeout":
        can_dtcs = [resolve_dtc_for_event("message_timeout", frame) for frame in stopped_frames]
    elif FAULT_MODE == "message_content":
        can_dtcs = [get_message_content_failure_dtcs(frame).get(integrity)
                    for frame, integrity in broken_frames]
    elif FAULT_MODE == "signal_content":
        can_dtcs = [resolve_dtc_for_event("signal_invalid", by_series[n]["frame"], by_series[n]["sig"])
                    for n in sorted(consuming)]
    can_dtcs = list(dict.fromkeys(code for code in can_dtcs if code))
    combined_can_dtc = " ".join(f"{code} {status}" for code in can_dtcs)
    if FAULT_MODE == "variant_code_error":
        # The cleared variant status bit sets SRS Variant Code Error (warning lamp on),
        # read next to the crash DTCs.
        combined_can_dtc = Variant_Code_DTC + " " + DTC_status["DTC_active"]
    qualification = max([qualification_ms(FAULT_MODE, plan["periodicity"]) or 0
                         for plan in plans if affected(plan)] or [0]) if FAULT_MODE else 0
    if FAULT_MODE == "node_absent":
        # Node absent counts key-frame periods, a silent node's timeout its fastest stopped
        # non-key frame's; the DTCs are read once the later one has matured. The frame
        # periods are the signal definitions' (canc_config).
        period = {definition["frame"]: definition.get("periodicity")
                  for definition in MAH_CAN_SIGNAL_DEFS.values()}
        times = [qualification_ms("node_absent", period[frame]) for frame in key_frames]
        for node in {CAN_TX_MESSAGE_CONFIG[frame]["key_node"] for frame in stopped_frames
                     if frame not in key_frames}:
            times.append(min(qualification_ms("message_timeout", period[frame])
                             for frame in stopped_frames if frame not in key_frames
                             and CAN_TX_MESSAGE_CONFIG[frame]["key_node"] == node
                             and period.get(frame)))
        qualification = max(times or [0])

    # -- Crashes -------------------------------------------------------------
    # An interval element records its whole vector in every crash. A snapshot records one
    # value per crash, so the run takes as many crashes as the longest snapshot list, made
    # even so that every value pair fills both event records.
    snapshots = [plan for plan in driven if plan["samples"] == 1]
    total_crashes = max([1] + [len(plan["values"]) for plan in snapshots])
    total_crashes += total_crashes % len(EDR_RECORD_DIDS)
    instants = sorted({t for plan in driven for t in plan["time_axis"]})
    steps = [abs(plan["time_axis"][1] - plan["time_axis"][0])
             for plan in driven if len(plan["time_axis"]) > 1]
    # A pre-crash fault heals half-way through the finest T0 window: after the last
    # pre-crash sample of every element, before T0.
    heal_at = -min(steps) / 2 if steps else -0.25

    def create_variant_fault():
        # Chained so each cleared node builds on the previous write; one ignition cycle.
        base = None
        for index, node in enumerate(cleared_nodes):
            last = index == len(cleared_nodes) - 1
            result = manage_variant_code(
                node, "disable", project=PROJECT_NAME,
                base_from_project_default=base is None,
                base_variant_code=base, apply_ignition_cycle=last) or {}
            # The helper reports a failed write by its status, never by raising.
            RESULT.InterpretEqualResult(
                f"Variant code written with {node} cleared", result.get("status"), "PASS")
            base = result.get("variant_hex") or base
        if FAULT_MODE == "variant_code_error":
            RESULT.InsertComment(
                f"[{report_timestamp()}] Cleared the variant status bit (VARIANT_STATUS) of the "
                f"variant code: every parameter received from a node is in variant code error.")
        else:
            RESULT.InsertComment(
                f"[{report_timestamp()}] Cleared {len(cleared_nodes)} node(s) from the variant "
                f"code: {', '.join(cleared_nodes)}.")

    def set_fault(on, reference):
        for frame in stopped_frames:
            if on:
                CAN.PeriodicDisableFrame(frame)
            else:
                CAN.ReloadDefaultPeriodicFrame(frame)
        for frame, integrity in broken_frames:
            if on:
                CAN.DynamicDisableSignal(frame, integrity)
            else:
                CAN.DynamicEnableSignal(frame, integrity)
        RESULT.InsertComment(
            f"[{report_timestamp(reference)}] {tc_category}: fault "
            f"{'created' if on else 'healed'} ({len(stopped_frames)} frame(s) stopped, "
            f"{len(broken_frames)} integrity signal(s) broken, {len(consuming)} signal(s) "
            f"carrying their invalid code).")

    # -- Bench bring-up ------------------------------------------------------
    fault_free_profile()
    PS.Power_Cycle()
    Wait(1000)
    read_software_version()
    if cleared_nodes:
        create_variant_fault()

    for crash_index in range(total_crashes):
        did = EDR_RECORD_DIDS[crash_index % len(EDR_RECORD_DIDS)]
        load_crash_curves(crash_type)
        for plan in driven:
            if plan["samples"] == 1 and plan["values"]:
                plan["current"] = [plan["values"][crash_index % len(plan["values"])]]
            else:
                plan["current"] = list(plan["values"])

        def driven_value(plan, idx):
            value = plan["current"][idx]
            if not in_fault(plan, idx):
                return value
            if reaction == "consume":
                return plan["invalid_raw"]
            if plan["samples"] == 1:
                # A snapshot drives a different valid value while the fault is active, so
                # the record can show whether the ECU held or substituted.
                others = [v for v in plan["values"] if v != value] or [
                    v for v in (plan["signal_def"].get("MIN"), plan["signal_def"].get("MAX"))
                    if v is not None and v != value]
                return others[0] if others else value
            return value

        def expected_can(plan, idx):
            if plan["follows"]:
                leader = by_series[plan["follows"]]
                return expected_can(leader, leader["t0"])
            value = plan["current"][idx]
            if not in_fault(plan, idx):
                return value
            if reaction == "consume":
                return plan["invalid_raw"]
            if reaction == "default":
                required = plan["snr_required" if FAULT_MODE == "signal_never_received"
                                else "vc_required"]
                if required:
                    return required[0] if len(required) == 1 else frozenset(required)
                return plan["default_raw"]
            # Last valid: what was received before the fault started - the first value
            # when it covers the start of the interval, the T0 value when it starts after.
            return plan["current"][plan["t0"]] if FAULT_SCOPE == "post" else plan["current"][0]

        aria_reports.add_group(f"{test_case_file} - DID {did} - CAN signal simulation")
        crash_reference = None
        fault_on = False
        if FAULT_MODE in ("node_absent", "message_timeout", "message_content") and FAULT_SCOPE != "post":
            # The fault covers the start of the interval, so each parameter is primed with
            # its first value before it starts: that is the value the record must hold.
            for plan in driven:
                if plan["current"]:
                    CAN.ChangeSignalValue(plan["frame"], plan["sig"], str(plan["current"][0]))
            Wait(500)
            set_fault(True, crash_reference)
            fault_on = True

        # The ECU takes T0 t0_offset_ms after the trigger, so the trigger fires that long
        # before instant 0 and T0 lands on it. Inside a window the heal and the trigger
        # happen in time order; no sleep, the sampling grid does not move.
        trigger_at = -t0_offset_ms / 1000.0
        previous = instants[0] - (min(steps) if steps else 0.5)
        if trigger_at <= previous:
            raise ValueError(f"The {t0_offset_ms} ms T0 offset is longer than the recording"
                             f" interval before T0.")
        if FAULT_SCOPE == "pre" and qualification:
            # The fault heals at heal_at. Its DTCs mature after the qualification time, up to
            # the tolerance later; with the DTC read margin on top, where the recording before
            # the heal is shorter than that the fault starts lead_ms before the recording.
            lead_ms = max(0, qualification * (1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
                          + DTC_READ_EXTRA_WAIT_MS - (heal_at - previous) * 1000)
            if reaction == "consume":
                # The invalid codes go on the bus from here, so each lasts at least as long.
                for plan in driven:
                    if in_fault(plan, 0):
                        CAN.ChangeSignalValue(plan["frame"], plan["sig"], str(plan["invalid_raw"]))
            if lead_ms:
                RESULT.InsertComment(
                    f"[{report_timestamp(crash_reference)}] {tc_category}: fault held "
                    f"{lead_ms:g} ms before the recording, so its DTCs mature before it heals.")
                Wait(lead_ms)
        for instant in instants:
            for plan in driven:
                if instant in plan["time_axis"]:
                    idx = plan["time_axis"].index(instant)
                    if idx < len(plan["current"]):
                        CAN.ChangeSignalValue(plan["frame"], plan["sig"],
                                              str(driven_value(plan, idx)))
            moments = []
            if fault_on and FAULT_SCOPE == "pre" and previous < heal_at < instant:
                moments.append((heal_at, "heal"))
            if crash_reference is None and previous < trigger_at <= instant:
                moments.append((trigger_at, "trigger"))
            reached = previous
            for moment, action in sorted(moments):
                if moment > reached:
                    Wait(int(round((moment - reached) * 1000)))
                    reached = moment
                if action == "heal":
                    set_fault(False, crash_reference)
                    fault_on = False
                else:
                    TriggerCrash()
                    crash_reference = time.monotonic() + t0_offset_ms / 1000.0
            if instant > reached:
                Wait(int(round((instant - reached) * 1000)))
            previous = instant
            if abs(instant) < 1e-9:
                RESULT.InsertComment(
                    f"[{report_timestamp(crash_reference)}] Crash {crash_index + 1} triggered"
                    + (f" {t0_offset_ms} ms before T0." if t0_offset_ms else " at T0."))
                if FAULT_SCOPE == "post" and FAULT_MODE in ("node_absent", "message_timeout", "message_content"):
                    set_fault(True, crash_reference)
                    fault_on = True

        if qualification:
            Wait(qualification)
            # Margin for a DTC that matures late within the timing tolerance (user decision
            # 2026-10-22): record_ready_ms + CAN_FAULT_TIMING_TOLERANCE_PERCENT of the
            # qualification time + DTC_READ_EXTRA_WAIT_MS (canc_config).
            Wait(record_ready_ms + qualification * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
                 + DTC_READ_EXTRA_WAIT_MS)
        Wait(1000)
        combined_crash_dtc = (Crash_DTC + " " + DTC_status["DTC_active"] + " "
                              + PT_Crash_DTC + " " + DTC_status["DTC_active"])
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc
                 + ((" " + combined_can_dtc) if combined_can_dtc else ""), Read_DTC_Req)
        aria_reports.close_group()

        # -- EDR output verification, every parameter from one record read -------
        Wait(record_ready_ms)
        payload = read_edr_record_bytes(did=did, crash_type=crash_type)
        aria_reports.add_group(f"{test_case_file} - DID {did} - EDR output verification")
        for plan in plans:
            samples = edr_sample_records(plan["element"], payload)
            count = 1 if plan["follows"] else len(plan.get("current") or [])
            scaling, record_offset = plan["edr_scaling"], plan["edr_offset"]
            unit_text = f" {plan['edr_unit']}" if plan["edr_unit"] else ""
            resolution = (f"resolution {format_physical(scaling)}{unit_text}"
                          + (f", offset {format_physical(record_offset)}{unit_text}"
                             if record_offset else ""))
            for idx in range(count):
                instant = plan["time_axis"][idx] if idx < len(plan["time_axis"]) else idx
                # A snapshot that follows an interval element records the leader's T0 value,
                # so it is under the fault exactly when the leader's T0 sample is.
                leader = by_series[plan["follows"]] if plan["follows"] else None
                faulted = (in_fault(leader, leader["t0"]) if leader is not None
                           else in_fault(plan, idx))
                state = "fault active" if faulted else "valid input"
                can_raw = expected_can(plan, idx)
                # Two checks per sample: the raw value the record holds and the physical
                # value it stands for at the record's resolution.
                if isinstance(can_raw, frozenset):
                    # The on-fail requirement allows any of a set of consumed values.
                    accepted_raws = sorted(int(round(((code * plan["factor"] + plan["offset"])
                                                      - record_offset) / scaling))
                                           for code in can_raw)
                    expected_raw_text = "any of " + ", ".join(
                        raw_hex(code, plan['edr_bits']) for code in accepted_raws)
                    expected_physical_text = "any of " + ", ".join(
                        format_physical(code * scaling + record_offset)
                        for code in accepted_raws) + unit_text
                else:
                    accepted_raws = None
                    if can_raw in plan["exception_codes"]:
                        # A DBC marker code is not a measurement; it is stored as it stands.
                        expected_raw, exact = int(can_raw), True
                    else:
                        precise = ((can_raw * plan["factor"] + plan["offset"])
                                   - record_offset) / scaling
                        expected_raw = int(round(precise))
                        exact = abs(precise - expected_raw) < 1e-6
                    expected_signed = (raw_signed(expected_raw, plan["edr_bits"])
                                       if plan["edr_signed"] else expected_raw)
                    low = high = expected_signed
                    expected_raw_text = raw_hex(expected_raw, plan['edr_bits'])
                    expected_physical_text = (
                        f"{format_physical(expected_signed * scaling + record_offset)}{unit_text}")
                    if not exact:
                        # The conversions do not divide evenly, so the record holds the
                        # nearest whole count; one count either side is accepted.
                        low, high = expected_signed - 1, expected_signed + 1
                        expected_raw_text += " +/- 1 count"
                        expected_physical_text += f" +/- {format_physical(scaling)}{unit_text}"
                sample_name = f"{plan['element']} at {instant}s ({state})"
                if idx >= len(samples):
                    sample_passed = False
                    observed_raw_text = observed_physical_text = "no sample in the record"
                else:
                    observed = samples[idx]
                    if accepted_raws is not None:
                        sample_passed = observed["raw"] in accepted_raws
                    else:
                        sample_passed = low <= observed["raw"] <= high
                    observed_raw_text = observed['hex']
                    observed_physical_text = f"{format_physical(observed['physical'])}{unit_text}"
                sample_verdict = TestStatus.Passed if sample_passed else TestStatus.Failed
                RESULT.InterpretEqualResult(
                    f"{sample_name} - EDR raw value",
                    observed_raw_text, expected_raw_text, sample_verdict)
                RESULT.InterpretEqualResult(
                    f"{sample_name} - physical value, {resolution}",
                    observed_physical_text, expected_physical_text, sample_verdict)
        aria_reports.close_group()

        # The record is verified; the fault comes off before the next crash is driven.
        if fault_on:
            set_fault(False, crash_reference)
            fault_on = False
        last_of_pair = crash_index % len(EDR_RECORD_DIDS) == len(EDR_RECORD_DIDS) - 1
        if last_of_pair and crash_index < total_crashes - 1:
            RESULT.InsertComment(
                f"[{report_timestamp()}] Records {EDR_RECORD_DIDS[0]} and {EDR_RECORD_DIDS[-1]}"
                f" verified; fault-free profile before the next pair.")
            fault_free_profile()
            if cleared_nodes:
                create_variant_fault()

    # -- Restore the bench ---------------------------------------------------
    for node in cleared_nodes:
        result = manage_variant_code(node, "enable", project=PROJECT_NAME,
                                     base_from_project_default=True,
                                     apply_ignition_cycle=False) or {}
        RESULT.InterpretEqualResult(
            f"Variant code written with {node} restored", result.get("status"), "PASS")
    for plan in driven:
        CAN.ReloadDefaultPeriodicFrame(plan["frame"])
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
