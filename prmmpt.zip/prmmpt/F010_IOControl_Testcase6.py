# Author: Christy
# IO Control: IOControl_Testcase6  |  Section: F010 - ACTIVATE CRASH

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    IOC_REQ_2F_F0_10_03_01,
    IOC_REQ_SESSION_DEFAULT,
    IOC_REQ_SESSION_EXTENDED,
    IOC_RESP_NEG_NRC33,
    IOC_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase6"
    tc_desc = 'F010 IO-control - F010 - ACTIVATE CRASH'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        _resp = CAN.SendDiagByValues(IOC_REQ_SESSION_EXTENDED)
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, IOC_RESP_SESSION_EXTENDED)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_10_03_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x10 0x03 0x01 (NRC 0x33 securityAccessDenied)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC33)
    finally:
        try:
            # back to default session: per ISO 14229-1 this stops any active
            # IO control and re-locks security, isolating the next test
            CAN.SendDiagByValuesNoLog(IOC_REQ_SESSION_DEFAULT)
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
