# Author: Christy
# IO Control: IOControl_Testcase130  |  Section: SEAT BELT LAMP

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    IOC_REQ_2F_F0_18_01,
    IOC_REQ_2F_F0_18_03_01,
    IOC_REQ_SESSION_DEFAULT,
    IOC_REQ_SESSION_EXTENDED,
    IOC_RESP_6F_F0_18_01,
    IOC_RESP_6F_F0_18_03,
    IOC_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase130"
    tc_desc = 'F018 IO-control - SEAT BELT LAMP'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738, 0x13C], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        # Set the Second Row LH SEAT BELT to unbuckled state
        SET_DCS_LOADS("200R", 10)  # ODS Present prerequisite
        SET_DCS_LOADS("200R", 3)
        _resp = CAN.SendDiagByValues(IOC_REQ_SESSION_EXTENDED)
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, IOC_RESP_SESSION_EXTENDED)
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_18_03_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x18 0x03 0x01", " ".join(_tok[:4]), IOC_RESP_6F_F0_18_03)
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_SEC_ROW_LEFT_BLT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_SEC_ROW_LEFT_BLT', _v, "0x1")
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_18_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x18 0x01", " ".join(_tok[:4]), IOC_RESP_6F_F0_18_01)
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_SEC_ROW_LEFT_BLT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_SEC_ROW_LEFT_BLT', _v, "0x0")
    finally:
        try:
            # back to default session: per ISO 14229-1 this stops any active
            # IO control and re-locks security, isolating the next test
            CAN.SendDiagByValuesNoLog(IOC_REQ_SESSION_DEFAULT)
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
