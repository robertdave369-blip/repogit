# Author: Christy
# IO Control: IOControl_Testcase2  |  Section: F010 - ACTIVATE CRASH

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    IOC_REQ_2F_F0_10_00,
    IOC_REQ_2F_F0_10_03_01,
    IOC_REQ_SESSION_DEFAULT,
    IOC_REQ_SESSION_EXTENDED,
    IOC_REQ_TESTER_PRESENT,
    IOC_RESP_6F_F0_10_00,
    IOC_RESP_6F_F0_10_03,
    IOC_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase2"
    tc_desc = 'F010 IO-control - F010 - ACTIVATE CRASH'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738, 0x2C0, 0x13C], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        _v = str(CAN.GetSignalFromFrame("HSCAN", "SRS1_20", "DOOR_UNLOCK")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial DOOR_UNLOCK', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_CRASH")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial STS_CRASH', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "CRASH_LOCATION")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial CRASH_LOCATION', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "SCM_CNT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial SCM_CNT', _v, "0x0")
        _resp = CAN.SendDiagByValues(IOC_REQ_SESSION_EXTENDED)
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, IOC_RESP_SESSION_EXTENDED)
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_10_03_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x10 0x03 0x01", " ".join(_tok[:4]), IOC_RESP_6F_F0_10_03)
        _s0 = []
        _s1 = []
        _s2 = []
        _s3 = []
        for _i in range(25):
            _v = str(CAN.GetSignalFromFrame("HSCAN", "SRS1_20", "DOOR_UNLOCK")).strip()
            try:
                _s0.append(f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}")
            except Exception:
                _s0.append(_v)
            _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_CRASH")).strip()
            try:
                _s1.append(f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}")
            except Exception:
                _s1.append(_v)
            _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "CRASH_LOCATION")).strip()
            try:
                _s2.append(f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}")
            except Exception:
                _s2.append(_v)
            _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "SCM_CNT")).strip()
            try:
                _s3.append(int(_v, 16) if _v.lower().startswith("0x") else int(float(_v)))
            except Exception:
                pass
            if _i in (8, 16):
                CAN.SendDiagByValuesNoLog(IOC_REQ_TESTER_PRESENT)  # keep session alive (S3 = 5 s)
            if _i < 24:
                Wait(190)
        _bad = [f"t={_i*0.19:.2f}s -> {_x}" for _i, _x in enumerate(_s0) if _x != "0x1"]
        _ok = 25 - len(_bad)
        RESULT.LogCustomAction('After control DOOR_UNLOCK (hold 5s)', "DOOR_UNLOCK == 0x1 on every sample for 5 s (25 samples @ ~190 ms)", f"{_ok}/25 samples == 0x1; deviations: " + (", ".join(_bad) if _bad else "none") + " | samples: " + str(_s0), TestStatus.Passed if not _bad else TestStatus.Failed)
        _bad = [f"t={_i*0.19:.2f}s -> {_x}" for _i, _x in enumerate(_s1) if _x != "0x1"]
        _ok = 25 - len(_bad)
        RESULT.LogCustomAction('After control STS_CRASH (hold 5s)', "STS_CRASH == 0x1 on every sample for 5 s (25 samples @ ~190 ms)", f"{_ok}/25 samples == 0x1; deviations: " + (", ".join(_bad) if _bad else "none") + " | samples: " + str(_s1), TestStatus.Passed if not _bad else TestStatus.Failed)
        _bad = [f"t={_i*0.19:.2f}s -> {_x}" for _i, _x in enumerate(_s2) if _x != "0x1"]
        _ok = 25 - len(_bad)
        RESULT.LogCustomAction('After control CRASH_LOCATION (hold 5s)', "CRASH_LOCATION == 0x1 on every sample for 5 s (25 samples @ ~190 ms)", f"{_ok}/25 samples == 0x1; deviations: " + (", ".join(_bad) if _bad else "none") + " | samples: " + str(_s2), TestStatus.Passed if not _bad else TestStatus.Failed)
        _dist = sorted(set(_s3))
        RESULT.LogCustomAction('After control SCM_CNT', "SCM_CNT stays within 0..15 AND keeps changing for 5 s (25 samples @ ~190 ms)", f"{len(_s3)}/25 readable samples; {len(_dist)} distinct values {_dist}" + " | samples: " + str(_s3), TestStatus.Passed if _s3 and all(0 <= _x <= 15 for _x in _s3) and len(_dist) >= 2 else TestStatus.Failed)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_10_00)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x10 0x00", " ".join(_tok[:4]), IOC_RESP_6F_F0_10_00)
        _v = str(CAN.GetSignalFromFrame("HSCAN", "SRS1_20", "DOOR_UNLOCK")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control DOOR_UNLOCK', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_CRASH")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_CRASH', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "CRASH_LOCATION")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control CRASH_LOCATION', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "SCM_CNT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control SCM_CNT', _v, "0x0")
    finally:
        try:
            # back to default session: per ISO 14229-1 this stops any active
            # IO control and re-locks security, isolating the next test
            CAN.SendDiagByValuesNoLog(IOC_REQ_SESSION_DEFAULT)
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
