# Author: Christy
# IO Control: IOControl_Testcase264  |  Section: SEAT BELT LAMP

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    IOC_REQ_2F_F0_21_00,
    IOC_REQ_2F_F0_21_01,
    IOC_REQ_2F_F0_21_02,
    IOC_REQ_2F_F0_21_03_00,
    IOC_REQ_2F_F0_21_03_01,
    IOC_REQ_SESSION_DEFAULT,
    IOC_REQ_SESSION_PROGRAMMING,
    IOC_RESP_NEG_NRC11,
    IOC_RESP_NEG_NRC7F,
    IOC_RESP_SESSION_DEFAULT,
    IOC_RESP_SESSION_PROGRAMMING,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase264"
    tc_desc = 'F021 IO-control - SEAT BELT LAMP'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        _resp = CAN.SendDiagByValues(IOC_REQ_SESSION_DEFAULT)
        RESULT.InterpretEqualResult("Enter default diagnostic session", _resp, IOC_RESP_SESSION_DEFAULT)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_03_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x03 0x01 (NRC 0x7F serviceNotSupportedInActiveSession)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC7F)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_03_00)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x03 0x00 (NRC 0x7F serviceNotSupportedInActiveSession)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC7F)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_00)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x00 (NRC 0x7F serviceNotSupportedInActiveSession)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC7F)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x01 (NRC 0x7F serviceNotSupportedInActiveSession)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC7F)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_02)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x02 (NRC 0x7F serviceNotSupportedInActiveSession)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC7F)
        # Level-3 unlock on purpose: $2F needs level 1, so it must still be rejected
        Internal_Security_Access(0x03)
        Wait(50)
        _resp = CAN.SendDiagByValues(IOC_REQ_SESSION_PROGRAMMING)
        RESULT.InterpretEqualResult("Enter programming diagnostic session", _resp, IOC_RESP_SESSION_PROGRAMMING)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_03_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x03 0x01 (NRC 0x11 serviceNotSupported)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC11)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_03_00)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x03 0x00 (NRC 0x11 serviceNotSupported)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC11)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_00)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x00 (NRC 0x11 serviceNotSupported)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC11)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x01 (NRC 0x11 serviceNotSupported)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC11)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_21_02)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0xF0 0x21 0x02 (NRC 0x11 serviceNotSupported)", " ".join(_tok[:3]), IOC_RESP_NEG_NRC11)
    finally:
        try:
            # back to default session: per ISO 14229-1 this stops any active
            # IO control and re-locks security, isolating the next test
            CAN.SendDiagByValuesNoLog(IOC_REQ_SESSION_DEFAULT)
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
