# Author: Christy
# IO Control: IOControl_Testcase138  |  Section: SEAT BELT LAMP

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    IOC_REQ_2F_F0_18_01,
    IOC_REQ_2F_F0_18_03_01,
    IOC_REQ_SESSION_DEFAULT,
    IOC_REQ_SESSION_EXTENDED,
    IOC_REQ_TESTER_PRESENT,
    IOC_RESP_6F_F0_18_01,
    IOC_RESP_6F_F0_18_03,
    IOC_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase138"
    tc_desc = 'F018 IO-control - SEAT BELT LAMP'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738, 0x13C], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        # Set the Second Row LH SEAT BELT to STB faulty state
        SET_DCS_LOADS("200R", 10)  # ODS Present prerequisite
        SET_DCS_LOADS("BUS", 3)
        PS.SetLeakageVBATBusHigh()
        Wait(500)
        _resp = CAN.SendDiagByValues(IOC_REQ_SESSION_EXTENDED)
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, IOC_RESP_SESSION_EXTENDED)
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_18_03_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x18 0x03 0x01", " ".join(_tok[:4]), IOC_RESP_6F_F0_18_03)
        _samples = []
        for _i in range(25):
            _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_SEC_ROW_LEFT_BLT")).strip()
            try:
                _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
            except Exception:
                pass
            _samples.append(_v)
            if _i in (8, 16):
                CAN.SendDiagByValuesNoLog(IOC_REQ_TESTER_PRESENT)  # keep session alive (S3 = 5 s)
            if _i < 24:
                Wait(190)
        _bad = [f"t={_i*0.19:.2f}s -> {_x}" for _i, _x in enumerate(_samples) if _x != "0x1"]
        _ok = 25 - len(_bad)
        RESULT.LogCustomAction('After control STS_SEC_ROW_LEFT_BLT (hold 5s)', "STS_SEC_ROW_LEFT_BLT == 0x1 on every sample for 5 s (25 samples @ ~190 ms)", f"{_ok}/25 samples == 0x1; deviations: " + (", ".join(_bad) if _bad else "none") + " | samples: " + str(_samples), TestStatus.Passed if not _bad else TestStatus.Failed)
        _resp = CAN.SendDiagByValues(IOC_REQ_2F_F0_18_01)
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x18 0x01", " ".join(_tok[:4]), IOC_RESP_6F_F0_18_01)
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_SEC_ROW_LEFT_BLT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_SEC_ROW_LEFT_BLT', _v, "0x0")
    finally:
        try:
            # back to default session: per ISO 14229-1 this stops any active
            # IO control and re-locks security, isolating the next test
            CAN.SendDiagByValuesNoLog(IOC_REQ_SESSION_DEFAULT)
        except Exception:
            pass
        try:
            PS.ClearLeakageVBATBusHigh()
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
