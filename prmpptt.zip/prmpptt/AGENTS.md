# Agent instructions

The complete knowledge base and working rules for this repository are in **`agent.md`** (repo
root). Read the relevant section before acting:

- **Core engineering principles & operational framework (governs everything)**: §0 — quality
  over speed; assume every artefact may be wrong and verify independently; every conclusion
  evidence-backed (else say "Evidence unavailable.") with a confidence level and
  fact/inference/assumption labelling; 13-stage workflow with quality gates; cross-document
  correlation + contradiction detection (→ D-register); change impact analysis;
  multi-perspective self-review; §0.15 success criteria define "complete"
- ECU modules, protocols, requirement analysis, D-01…D-12 discrepancy register: §1–§12, §3.1
- Test-case authoring (Veoneer Excel format, requirement-ID mapping, DTC status bytes — CAN
  faults active = `0B`, crash locks `8B` — and NRC rules): §16
- Test DESIGN methodology (mandatory for requirement-based test writing): §16.10 — minimal
  high-value suite, never pad test counts; analyse + decompose requirements and derive
  objectives before any case; equivalence/boundary/state/MC-DC/risk-based techniques; negative
  + fault-injection sweep; optimise (merge/deduplicate/parameterise); coverage report with
  uncovered behaviour listed; full traceability, no orphan cases; **priority/high-value cases
  first in the delivered spec**
- Reading Excel sources without content loss (full openpyxl dump, header-name column resolution,
  Codebeamer markup decoding, extraction verification): §16.5
- Reading PDFs/Word documents (library selection, table integrity, OCR with confidence flags,
  completeness cross-checks, extraction-quality reporting): §16.6
- Excel sanitization & normalization pipeline (strip presentation artifacts only, preserve all
  engineering tokens, `[STRUCK:]` markers, integrity verification gate before analysis): §16.7
- DBC & CAN/diagnostic log analysis (cantools/python-can/asammdf/polars, install-what-you-need
  mandate, `tools\extract_dbc_signals.py`, multi-GB streaming, signal/temporal checks, ISO-TP
  diagnostic timeline, requirement→signal→message→code→test→log correlation, root-cause
  format): §16.8
- Library manifest for every file format (`tools\analysis-requirements.txt`) + the four pipeline
  practices (fallback parser chains, extraction validation, common internal model, provenance on
  every extracted item): §16.9
- Multi-agent orchestration for batch tasks: §17 — workflow roles §17.1–17.2, the 13-specialist
  virtual team (incl. Cybersecurity) + independence/consensus rules §17.3–17.4, execution
  substrates (simulated passes
  / subagents / Copilot CLI terminal / cloud coding agent, with graceful fallback) §17.5,
  incremental execution §17.6, self-verification loop §17.7, unified report structure §17.8
- Python script authoring (module config + shared_libraries wrappers ONLY — never direct
  library/`Api.*` calls; new bench wrappers → `jscript_translation.py`, new user-defined
  functions → `core_functions.py`, both project-agnostic; scripts clean like the EDR scripts;
  config-driven with inform-and-suggest on gaps; timing/ignition-cycle discipline; legacy ARIA
  API porting rules): §18
- Test-case review & cross-document validation protocol (ingest-correlate first, module-aware,
  evidence-based findings, full report deliverables): §19
- AI behavioral rules: §20
- Environment, tooling & repository map + quick-reference card (interpreters, where every source
  lives, key constants): §21
- Task playbooks (question / test cases / script / JS port / review / batch / new variant): §22
- **Safety & permission boundaries — read before running anything**: §23 (writing code ≠ running
  it; never actuate bench/ECU, flash, or write EOL/VC/VIN/NVM without an explicit user request;
  never hand-edit generated artifacts)
- Glossary: §24
- ARIA 5.20 simulation environment (docs at `C:\ARIA5.20\`, bench/cards/APYM/RTSE, **§25.5
  fault-creation catalog — if a fault isn't there or you're doubtful, ask the user**, loadbox
  electrical states): §25
- Saleae / oscilloscope PWM verification (ENS 40 ms, 62.5 %/37.5 % duty; instrument settings):
  §26
- Electrical-engineering basics + communication protocols (SPI, PSI5, CAN/CAN FD, LIN/K-line,
  PWM) for hardware questions: §27
- **Cybersecurity, CRC & communication protection** (secure boot/flashing, secure UDS,
  SecOC/E2E, MAC/freshness/replay, CRC & alive/rolling counters, crypto/keys, debug-port
  security): §28 — senior-cybersecurity-engineer workflow, ISO/SAE 21434 & WP.29 R155 & AUTOSAR
  SecOC/Crypto awareness, **§28.10 CRC & E2E algorithm reference** (CRC-8/16/32/64 params +
  AUTOSAR E2E profiles P1–P7), E2E-vs-SecOC distinction, security tests, findings format;
  security weaknesses on actuation/flash/NVM paths are safety issues. UDS per ISO 14229 — deviate
  only for a documented OEM deviation or explicit user request (§4.3)
- Maintaining this document: §29

Non-negotiable: verify requirement IDs, DTC codes, and shared-library function signatures in
their source files before using them; all constants come from `projects\<project>\config\` or the
DBC (missing constant → inform the user and suggest a config placement, never inline); if a
needed wrapper function does not exist anywhere in `shared_libraries`, stop and suggest/ask
permission to create one (per agent.md §18.4/§18.6) instead of writing inline bench logic; if
unsure how to create a fault in a script, ask (agent.md §25.5).
