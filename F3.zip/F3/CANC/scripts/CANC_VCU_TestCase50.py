# Author: Kris
#
# Test case  : CANC_VCU_TestCase50 (Codebeamer ID 36766287)
# Workbook   : VCU_Node_TestCases.xlsx
# Objective  : Verify that VIN_NUMBER received in VCU4_FD_1500 is decoded to the correct
#              physical value.
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '36766287'
    tc_name = 'CANC_VCU_TestCase50'
    tc_desc = (
        'Verify that VIN_NUMBER received in VCU4_FD_1500 is decoded to the correct physical '
        'value.'
    )
    automation = 'Automatic'

    vin_def = MAH_CAN_SIGNAL_DEFS['VIN_NUMBER']
    vin_bytes = VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY]

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([vin_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(vin_def['bus'], vin_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(vin_def['bus'], vin_def['frame'])
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Transmit the project VIN in VIN_NUMBER and compare the decoded value')
        simulate_vin_can_signals_fd(vin_bytes)
        Wait(3 * vin_def['periodicity'])
        compare_vin_can_signals_fd(vin_bytes)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Read DTC')
        Read_DTC('No DTC with the project VIN on the bus', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
