# Author: Kris
#
# Test case  : CANC_13C_TestCase_55 (Codebeamer ID 35773273)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Verify Alive counter for 13C and 2C0 restarts from 0 when a CAN wakeup cycle
#              occurs
# Automation : Automatic
# Note       : The case wakes the ECU with the VCU NM active wakeup bit, and so does the script
#              (from bus sleep, with PKE_CLMP_STATE at its wake value too): on 2026-10-15 the
#              PKE clamp state alone did not wake the sleeping ECU, the VCU NM frame did (13C
#              48).
# Note       : On 2026-10-15 every SRS1_20 frame carried SRSHS_MSG_CNT = 0 (byte 6 = 0x00 in all
#              logged frames) with the default EOL code, whose alive-counter bit (byte 6 bit 2)
#              is 0, i.e. 0..15 per agent_sc3.md section 2.2: an ECU finding the HS-CAN alive-
#              counter checks report until it is fixed.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_COUNTER_SAMPLE_ROLLOVERS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_HS_ALIVE_COUNTER_MAX,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_NM_WAKEUP_FRAME,
    CAN_NM_WAKEUP_SIGNAL,
    CAN_NM_WAKEUP_VALUE,
    CAN_PKE_SLEEP_VALUE,
    CAN_PKE_WAKEUP_SIGNAL_KEY,
    CAN_PKE_WAKEUP_VALUES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    CAN_WAKEUP_BUS_SLEEP_WAIT_MS,
    CAN_WAKEUP_STATUS_FRAME,
    CAN_WAKEUP_STATUS_SIGNAL,
    CAN_WAKEUP_STATUS_VALUE,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
    DEFAULT_EOL_CODE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.eol_config import (
    M310_M314_M110_FEATURE_MAP,
)


def run_test():
    tc_id = '35773273'
    tc_name = 'CANC_13C_TestCase_55'
    tc_desc = (
        'To Verify Alive counter for 13C and 2C0 restarts from 0 when a CAN wakeup cycle '
        'occurs'
    )
    automation = 'Automatic'

    alive_byte, alive_bit = M310_M314_M110_FEATURE_MAP['ALIVE_COUNTER']
    default_alive_action = 'enable' if int(DEFAULT_EOL_CODE.split()[alive_byte], 16) & (1 << alive_bit) else 'disable'
    counter_specs = [('SRS_MSG_CNT', (1 << MAH_CAN_SIGNAL_DEFS['SRS_MSG_CNT']['bit_length']) - 1), ('SRSHS_MSG_CNT', CANC_HS_ALIVE_COUNTER_MAX[default_alive_action])]
    counter_window_ms = max((CANC_COUNTER_SAMPLE_ROLLOVERS * (counter_max + 1) + 4)
                            * MAH_CAN_SIGNAL_DEFS[counter_key]['periodicity'] for counter_key, counter_max in counter_specs)
    pke_def = MAH_CAN_SIGNAL_DEFS[CAN_PKE_WAKEUP_SIGNAL_KEY]
    nm_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == CAN_NM_WAKEUP_FRAME)
    wake_status_key = next(key for key, d in MAH_CAN_SIGNAL_DEFS.items()
                           if d['frame'] == CAN_WAKEUP_STATUS_FRAME and d['signal'] == CAN_WAKEUP_STATUS_SIGNAL)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(pke_def['bus'], pke_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: IGN OFF until bus sleep, then CAN wakeup (VCU NM active wakeup bit = 1)')
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
        presence3_ids = [fd_id, hs_id]
        presence3_file = os.path.splitext(log_path)[0] + '_bus_sleep.txt'
        presence3_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_bus_sleep', filepath=presence3_file,
            listOption=presence3_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence3_logger)
        presence3_frames = []
        if os.path.isfile(presence3_file):
            with open(presence3_file, encoding='utf-8', errors='replace') as presence3_log:
                presence3_fields = [line.split(',', 2) for line in presence3_log if ' id=' in line and line.count(',') >= 2]
            presence3_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence3_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence3_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence3_frames = [frame_data for frame_data in presence3_frames if frame_data.id in presence3_ids]
        presence3_fd_count = sum(1 for frame_data in presence3_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResult(
            f"{fd_frame} is not transmitted (frames in the window)",
            presence3_fd_count, 0)
        presence3_hs_count = sum(1 for frame_data in presence3_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence3_hs_count, 0)
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ChangeSignalValue(nm_def['bus'], CAN_NM_WAKEUP_FRAME, CAN_NM_WAKEUP_SIGNAL, str(CAN_NM_WAKEUP_VALUE))
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_WAKEUP_VALUES[0]))
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        check_started = time.monotonic()
        for check_key, check_expected in [(wake_status_key, CAN_WAKEUP_STATUS_VALUE)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult('ECU awake through CAN: ' + f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Verify the alive counters')
        running_ids = [hs_id, fd_id]
        running_file = os.path.splitext(log_path)[0] + '_alive_running.txt'
        running_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_running', filepath=running_file,
            listOption=running_ids, channel_names=[CAN_HS_CHANNEL_NAME, CAN_FD_CHANNEL_NAME])
        Wait(counter_window_ms)
        CAN.StopLoggingToFile(running_logger)
        running_frames = []
        if os.path.isfile(running_file):
            with open(running_file, encoding='utf-8', errors='replace') as running_log:
                running_fields = [line.split(',', 2) for line in running_log if ' id=' in line and line.count(',') >= 2]
            running_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in running_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(running_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        running_frames = [frame_data for frame_data in running_frames if frame_data.id in running_ids]
        for counter_key, counter_max in counter_specs:
            counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
            counter_values = [extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key], counter_def['bit_length'])
                              for frame_data in running_frames
                              if frame_data.id == CAN_RX_MESSAGE_CONFIG[counter_def['frame']]['frame_ID']]
            # validate_counter covers power-of-two ranges only; 0..14 needs the modulo check.
            counter_errors = [(index, earlier, later)
                              for index, (earlier, later) in enumerate(zip(counter_values, counter_values[1:]), 1)
                              if (later - earlier) % (counter_max + 1) != 1]
            RESULT.InterpretEqualResult(f"{counter_def['signal']} counts by one", str(counter_errors[:10]), "[]")
            RESULT.InterpretEqualResult(f"{counter_def['signal']} range",
                                        f"{min(counter_values, default=None)}..{max(counter_values, default=None)}",
                                        f"0..{counter_max}")
        aria_reports.close_group()
        aria_reports.add_group('Step 5: CAN wakeup off and on while the counters run, and observe the restart')
        restart_ids = [hs_id, fd_id]
        restart_file = os.path.splitext(log_path)[0] + '_alive_restart.txt'
        restart_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_restart', filepath=restart_file,
            listOption=restart_ids, channel_names=[CAN_HS_CHANNEL_NAME, CAN_FD_CHANNEL_NAME])
        # Active wakeup bit off: no VCU NM frame and the PKE clamp state at rest, until
        # the ECU sleeps; then the VCU NM frame with the active wakeup bit wakes it again.
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ChangeSignalValue(nm_def['bus'], CAN_NM_WAKEUP_FRAME, CAN_NM_WAKEUP_SIGNAL, str(CAN_NM_WAKEUP_VALUE))
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_WAKEUP_VALUES[0]))
        Wait(NM_IGN_ON_STARTUP_DELAY_MS + counter_window_ms)
        CAN.StopLoggingToFile(restart_logger)
        restart_frames = []
        if os.path.isfile(restart_file):
            with open(restart_file, encoding='utf-8', errors='replace') as restart_log:
                restart_fields = [line.split(',', 2) for line in restart_log if ' id=' in line and line.count(',') >= 2]
            restart_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in restart_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(restart_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        restart_frames = [frame_data for frame_data in restart_frames if frame_data.id in restart_ids]
        for counter_key, counter_max in counter_specs:
            counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
            counter_rows = [(frame_data.timestamp / 1000,
                             extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key], counter_def['bit_length']))
                            for frame_data in restart_frames
                            if frame_data.id == CAN_RX_MESSAGE_CONFIG[counter_def['frame']]['frame_ID']]
            # The restart is the gap in transmission or, failing one, the first break in the count.
            counter_gap = next((index for index in range(1, len(counter_rows))
                                if counter_rows[index][0] - counter_rows[index - 1][0] > 5 * counter_def['periodicity']), None)
            counter_break = next((index for index in range(1, len(counter_rows))
                                  if (counter_rows[index][1] - counter_rows[index - 1][1]) % (counter_max + 1) != 1), None)
            counter_restart = counter_gap if counter_gap is not None else counter_break
            counter_after = [value for _, value in counter_rows[counter_restart:]] if counter_restart is not None else []
            RESULT.InterpretEqualResult(f"{counter_def['signal']} restarts from 0", counter_after[:1], [0])
            RESULT.InterpretEqualResult(f"{counter_def['signal']} counts by one after the restart",
                                        all((later - earlier) % (counter_max + 1) == 1
                                            for earlier, later in zip(counter_after, counter_after[1:])), True)
            RESULT.InterpretEqualResult(f"{counter_def['signal']} runs up to {counter_max} after the restart",
                                        max(counter_after, default=None), counter_max)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
            PS.IGN_ON()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
