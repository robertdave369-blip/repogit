# Author: Kris
#
# Test case  : CANC_2C0_TestCase_04 (Codebeamer ID 35736851)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check signal Values of INDC_PADL(Warning lamp in Prove out condition) Signal
#              2C0 Msg
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_LAMP_PROVEOUT_OFF_MS,
    CANC_LAMP_PROVEOUT_ON_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_PROVEOUT_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736851'
    tc_name = 'CANC_2C0_TestCase_04'
    tc_desc = (
        'To Check signal Values of INDC_PADL(Warning lamp in Prove out condition) Signal 2C0 '
        'Msg'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Cycle IGN and record the lamp proveout')
        proveout_ids = [hs_id]
        proveout_file = os.path.splitext(log_path)[0] + '_proveout.txt'
        proveout_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_proveout', filepath=proveout_file,
            listOption=proveout_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS + CANC_LAMP_PROVEOUT_ON_MS + CANC_LAMP_PROVEOUT_OFF_MS)
        CAN.StopLoggingToFile(proveout_logger)
        proveout_frames = []
        if os.path.isfile(proveout_file):
            with open(proveout_file, encoding='utf-8', errors='replace') as proveout_log:
                proveout_fields = [line.split(',', 2) for line in proveout_log if ' id=' in line and line.count(',') >= 2]
            proveout_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in proveout_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(proveout_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        proveout_frames = [frame_data for frame_data in proveout_frames if frame_data.id in proveout_ids]
        for lamp_key in ['SRS1_20_INDC_PADL']:
            lamp_def = MAH_CAN_SIGNAL_DEFS[lamp_key]
            lamp_id = CAN_RX_MESSAGE_CONFIG[lamp_def['frame']]['frame_ID']
            lamp_on_value = lamp_def['State_Values']['Lamp ON']
            lamp_off_value = lamp_def['State_Values']['Lamp OFF/Default']
            lamp_rows = [(frame_data.timestamp / 1000,
                          extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[lamp_key], lamp_def['bit_length']))
                         for frame_data in proveout_frames if frame_data.id == lamp_id]
            # The capture may span the restart: keep the frames after the last gap.
            lamp_restart = max([index for index in range(1, len(lamp_rows))
                                if lamp_rows[index][0] - lamp_rows[index - 1][0] > 5 * lamp_def['periodicity']] or [0])
            lamp_rows = lamp_rows[lamp_restart:]
            lamp_on_times = [t for t, value in lamp_rows if value == lamp_on_value]
            lamp_off_at = next((t for t, value in lamp_rows
                                if lamp_on_times and t > lamp_on_times[0] and value != lamp_on_value), None)
            lamp_on_ms = round(lamp_off_at - lamp_on_times[0], 1) if lamp_on_times and lamp_off_at is not None else None
            # The ECU's first frames after IGN ON carry the lamp OFF for about 60 ms before
            # the proveout starts (2026-10-15: 6 frames at 10 ms); the proveout must start
            # within the proveout tolerance of the first frame.
            RESULT.InterpretEqualResultRange(
                f"{lamp_def['frame']} {lamp_def['signal']} ON from the start of transmission (ms after the first frame)",
                round(lamp_on_times[0] - lamp_rows[0][0], 1) if lamp_on_times else None,
                0, CANC_LAMP_PROVEOUT_ON_MS * CANC_PROVEOUT_TOLERANCE_PERCENT / 100)
            RESULT.InterpretEqualResultRange(
                f"{lamp_def['frame']} {lamp_def['signal']} ON time in proveout (ms)", lamp_on_ms,
                CANC_LAMP_PROVEOUT_ON_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                CANC_LAMP_PROVEOUT_ON_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
            lamp_after = sorted({value for t, value in lamp_rows
                                 if lamp_off_at is not None and lamp_off_at <= t <= lamp_off_at + CANC_LAMP_PROVEOUT_OFF_MS})
            RESULT.InterpretEqualResult(
                f"{lamp_def['frame']} {lamp_def['signal']} OFF for {CANC_LAMP_PROVEOUT_OFF_MS} ms after proveout",
                lamp_after, [lamp_off_value])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
