# Author: Kris
#
# Test case  : CANC_13C_TestCase_124 (Codebeamer ID 36754028)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify SRS_OCC_CNT for "Passenger Child 0x7 Update"
# Automation : Automatic
# Note       : With the passenger seat unoccupied for the OCS (OCS_PASS_CLASS = EMPTY, no OCS
#              fault), the system requirement (Mahindra System Requirements M112/M312/Z121 V1.8,
#              tables 1.7 and 1.9) has STS_SEAT_BLT_PSGR sent as 1 (Buckled) whatever the buckle
#              switch, and the ECU does so (2026-10-15); the script expects that where the case
#              gives 0x0.
# Note       : OCS is enabled in the variant code for the case (the project default has the OCS
#              node off); fault_free_profile restores the default codes afterwards.
# Note       : The seat statuses and counts are read CANC_OCCUPANT_COUNT_SETTLE_MS after the
#              last seat change: on 2026-10-15 a rear seat (ODS present, belt buckled) showed in
#              SRS_BKL_CNT 7.5 s after the change and the counts the earlier scripts read after
#              1 s were still the old ones.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_BELT_CHANNEL,
    CANC_DCS_FAULT_LOAD,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_OCCUPANT_COUNT_SETTLE_MS,
    CANC_ODS_CHANNEL,
    CANC_ODS_LOADS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    SLSNumber,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.ods_config import (
    ODSNumber,
)


def run_test():
    tc_id = '36754028'
    tc_name = 'CANC_13C_TestCase_124'
    tc_desc = (
        'Verify SRS_OCC_CNT for "Passenger Child 0x7 Update"'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    ods_loads = {'PRESENT': CANC_ODS_LOADS['PRESENT'], 'PRESENT_ADULT': CANC_ODS_LOADS['PRESENT_ADULT'],
                 'PRESENT_CHILD': CANC_ODS_LOADS['PRESENT_CHILD'], 'NOT_PRESENT': CANC_ODS_LOADS['NOT_PRESENT'],
                 'FAULTY': CANC_DCS_FAULT_LOAD}
    belt_loads = {'UNBUCKLED': DCS_Fault_Description['unbuckle'], 'BUCKLED': DCS_Fault_Description['buckle'],
                  'FAULTY': CANC_DCS_FAULT_LOAD}
    ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
    ocs_fault_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS_FAULT_STS']

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Enable OCS in the variant code')
        manage_variant_code('OCS', 'enable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Set the baseline (rear seats not present, belts unbuckled, passenger empty)')
        PS.ClearLeakageVBATBusHigh()
        for ods_key, ods_state in [
            ('STS_SEAT_ODS_SEC_ROW_LEFT', 'NOT_PRESENT'),
            ('STS_SEAT_ODS_SEC_ROW_MIDDLE', 'NOT_PRESENT'),
            ('STS_SEAT_ODS_SEC_ROW_RIGHT', 'NOT_PRESENT'),
            ('STS_SEAT_ODS_TRD_ROW_LEFT', 'NOT_PRESENT'),
            ('STS_SEAT_ODS_TRD_ROW_RIGHT', 'NOT_PRESENT'),
        ]:
            SET_DCS_LOADS(ods_loads[ods_state], ODSNumber[CANC_ODS_CHANNEL[ods_key]])
        for seat_belt_key, seat_belt_state in [
            ('STS_SEC_ROW_LEFT_BLT', 'UNBUCKLED'),
            ('STS_SEC_ROW_MIDDLE_BLT', 'UNBUCKLED'),
            ('STS_SEC_ROW_RIGHT_BLT', 'UNBUCKLED'),
            ('STS_TRD_ROW_LEFT_BLT', 'UNBUCKLED'),
            ('STS_TRD_ROW_RIGHT_BLT', 'UNBUCKLED'),
            ('STS_SEAT_BLT_PSGR', 'UNBUCKLED'),
            ('STS_SEAT_BLT_DRV', 'UNBUCKLED'),
        ]:
            SET_DCS_LOADS(belt_loads[seat_belt_state], SLSNumber[CANC_BELT_CHANNEL[seat_belt_key]])
        CAN.ChangeSignalValue(ocs_fault_def['bus'], ocs_fault_def['frame'],
                              ocs_fault_def['signal'], str(ocs_fault_def['State_Values']['No_Fault']))
        CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'],
                              ocs_class_def['signal'], str(ocs_class_def['State_Values']['EMPTY']))
        Wait(CANC_OCCUPANT_COUNT_SETTLE_MS)
        check_pairs = [
            ('STS_SEAT_ODS_SEC_ROW_LEFT', MAH_CAN_SIGNAL_DEFS['STS_SEAT_ODS_SEC_ROW_LEFT']['State_Values']['NOT_PRESENT_DEFAULT']),
            ('STS_SEAT_ODS_SEC_ROW_MIDDLE', MAH_CAN_SIGNAL_DEFS['STS_SEAT_ODS_SEC_ROW_MIDDLE']['State_Values']['NOT_PRESENT_DEFAULT']),
            ('STS_SEAT_ODS_SEC_ROW_RIGHT', MAH_CAN_SIGNAL_DEFS['STS_SEAT_ODS_SEC_ROW_RIGHT']['State_Values']['NOT_PRESENT_DEFAULT']),
            ('STS_SEAT_ODS_TRD_ROW_LEFT', MAH_CAN_SIGNAL_DEFS['STS_SEAT_ODS_TRD_ROW_LEFT']['State_Values']['NOT_PRESENT_DEFAULT']),
            ('STS_SEAT_ODS_TRD_ROW_RIGHT', MAH_CAN_SIGNAL_DEFS['STS_SEAT_ODS_TRD_ROW_RIGHT']['State_Values']['NOT_PRESENT_DEFAULT']),
            ('STS_SEC_ROW_LEFT_BLT', next(value for label, value in MAH_CAN_SIGNAL_DEFS['STS_SEC_ROW_LEFT_BLT']['State_Values'].items() if label.startswith('Not Buckled'))),
            ('STS_SEC_ROW_MIDDLE_BLT', next(value for label, value in MAH_CAN_SIGNAL_DEFS['STS_SEC_ROW_MIDDLE_BLT']['State_Values'].items() if label.startswith('Not Buckled'))),
            ('STS_SEC_ROW_RIGHT_BLT', next(value for label, value in MAH_CAN_SIGNAL_DEFS['STS_SEC_ROW_RIGHT_BLT']['State_Values'].items() if label.startswith('Not Buckled'))),
            ('STS_TRD_ROW_LEFT_BLT', next(value for label, value in MAH_CAN_SIGNAL_DEFS['STS_TRD_ROW_LEFT_BLT']['State_Values'].items() if label.startswith('Not Buckled'))),
            ('STS_TRD_ROW_RIGHT_BLT', next(value for label, value in MAH_CAN_SIGNAL_DEFS['STS_TRD_ROW_RIGHT_BLT']['State_Values'].items() if label.startswith('Not Buckled'))),
            ('STS_SEAT_BLT_PSGR', MAH_CAN_SIGNAL_DEFS['STS_SEAT_BLT_PSGR']['State_Values']['Buckled']),
            ('STS_SEAT_BLT_DRV', next(value for label, value in MAH_CAN_SIGNAL_DEFS['STS_SEAT_BLT_DRV']['State_Values'].items() if label.startswith('Not Buckled'))),
        ]
        check_started = time.monotonic()
        for check_key, check_expected in check_pairs:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult('Baseline: ' + f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Set the combination and observe the counts')
        CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'],
                              ocs_class_def['signal'], str(7))
        Wait(CANC_OCCUPANT_COUNT_SETTLE_MS)
        count_1_def = MAH_CAN_SIGNAL_DEFS['SRS_OCC_CNT']
        count_1_text = str(CAN.GetSignalFromFrame(count_1_def['bus'], count_1_def['frame'], count_1_def['signal'])).strip()
        try:
            count_1 = int(count_1_text, 16) if count_1_text.lower().startswith("0x") else int(float(count_1_text))
        except ValueError:
            count_1 = None
        RESULT.InterpretEqualResult('SRS_OCC_CNT', str(count_1), str(1))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.ClearLeakageVBATBusHigh()
            for ods_key in CANC_ODS_CHANNEL:
                SET_DCS_LOADS(CANC_ODS_LOADS['NOT_PRESENT'], ODSNumber[CANC_ODS_CHANNEL[ods_key]])
            for seat_belt_key in CANC_BELT_CHANNEL:
                SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], SLSNumber[CANC_BELT_CHANNEL[seat_belt_key]])
            CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
