# Author: Kris
#
# Test case  : CANC_2C0_TestCase_16 (Codebeamer ID 35736863)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Verify Alive counter is 0 to 15 & 0 to 14 in HS CAN
# Automation : Automatic
# Note       : On 2026-10-15 every SRS1_20 frame carried SRSHS_MSG_CNT = 0 (byte 6 = 0x00 in all
#              logged frames) with the default EOL code, whose alive-counter bit (byte 6 bit 2)
#              is 0, i.e. 0..15 per agent_sc3.md section 2.2: an ECU finding the HS-CAN alive-
#              counter checks report until it is fixed.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_COUNTER_SAMPLE_ROLLOVERS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_HS_ALIVE_COUNTER_MAX,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736863'
    tc_name = 'CANC_2C0_TestCase_16'
    tc_desc = (
        'To Verify Alive counter is 0 to 15 & 0 to 14 in HS CAN'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Write the EOL code with the alive-counter bit disabled and cycle IGN')
        manage_eol_code('ALIVE_COUNTER', 'disable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Verify the HS-CAN alive counter')
        alive_disable_ids = [hs_id]
        alive_disable_file = os.path.splitext(log_path)[0] + '_alive_disable.txt'
        alive_disable_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_disable', filepath=alive_disable_file,
            listOption=alive_disable_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait((CANC_COUNTER_SAMPLE_ROLLOVERS * (CANC_HS_ALIVE_COUNTER_MAX['disable'] + 1) + 4) * hs_period_ms)
        CAN.StopLoggingToFile(alive_disable_logger)
        alive_disable_frames = []
        if os.path.isfile(alive_disable_file):
            with open(alive_disable_file, encoding='utf-8', errors='replace') as alive_disable_log:
                alive_disable_fields = [line.split(',', 2) for line in alive_disable_log if ' id=' in line and line.count(',') >= 2]
            alive_disable_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in alive_disable_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(alive_disable_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        alive_disable_frames = [frame_data for frame_data in alive_disable_frames if frame_data.id in alive_disable_ids]
        alive_disable_def = MAH_CAN_SIGNAL_DEFS['SRSHS_MSG_CNT']
        alive_disable_values = [extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT['SRSHS_MSG_CNT'], alive_disable_def['bit_length'])
                        for frame_data in alive_disable_frames
                        if frame_data.id == CAN_RX_MESSAGE_CONFIG[alive_disable_def['frame']]['frame_ID']]
        # validate_counter covers power-of-two ranges only; 0..14 needs the modulo check.
        alive_disable_errors = [(index, earlier, later)
                        for index, (earlier, later) in enumerate(zip(alive_disable_values, alive_disable_values[1:]), 1)
                        if (later - earlier) % (CANC_HS_ALIVE_COUNTER_MAX['disable'] + 1) != 1]
        RESULT.InterpretEqualResult(f"{alive_disable_def['signal']} counts by one", str(alive_disable_errors[:10]), "[]")
        RESULT.InterpretEqualResult(f"{alive_disable_def['signal']} range",
                                    f"{min(alive_disable_values, default=None)}..{max(alive_disable_values, default=None)}",
                                    f"0..{CANC_HS_ALIVE_COUNTER_MAX['disable']}")
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Write the EOL code with the alive-counter bit enabled and cycle IGN')
        manage_eol_code('ALIVE_COUNTER', 'enable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Verify the HS-CAN alive counter')
        alive_enable_ids = [hs_id]
        alive_enable_file = os.path.splitext(log_path)[0] + '_alive_enable.txt'
        alive_enable_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_enable', filepath=alive_enable_file,
            listOption=alive_enable_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait((CANC_COUNTER_SAMPLE_ROLLOVERS * (CANC_HS_ALIVE_COUNTER_MAX['enable'] + 1) + 4) * hs_period_ms)
        CAN.StopLoggingToFile(alive_enable_logger)
        alive_enable_frames = []
        if os.path.isfile(alive_enable_file):
            with open(alive_enable_file, encoding='utf-8', errors='replace') as alive_enable_log:
                alive_enable_fields = [line.split(',', 2) for line in alive_enable_log if ' id=' in line and line.count(',') >= 2]
            alive_enable_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in alive_enable_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(alive_enable_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        alive_enable_frames = [frame_data for frame_data in alive_enable_frames if frame_data.id in alive_enable_ids]
        alive_enable_def = MAH_CAN_SIGNAL_DEFS['SRSHS_MSG_CNT']
        alive_enable_values = [extract_counter(frame_data.payload, CAN_SIGNAL_START_BIT['SRSHS_MSG_CNT'], alive_enable_def['bit_length'])
                        for frame_data in alive_enable_frames
                        if frame_data.id == CAN_RX_MESSAGE_CONFIG[alive_enable_def['frame']]['frame_ID']]
        # validate_counter covers power-of-two ranges only; 0..14 needs the modulo check.
        alive_enable_errors = [(index, earlier, later)
                        for index, (earlier, later) in enumerate(zip(alive_enable_values, alive_enable_values[1:]), 1)
                        if (later - earlier) % (CANC_HS_ALIVE_COUNTER_MAX['enable'] + 1) != 1]
        RESULT.InterpretEqualResult(f"{alive_enable_def['signal']} counts by one", str(alive_enable_errors[:10]), "[]")
        RESULT.InterpretEqualResult(f"{alive_enable_def['signal']} range",
                                    f"{min(alive_enable_values, default=None)}..{max(alive_enable_values, default=None)}",
                                    f"0..{CANC_HS_ALIVE_COUNTER_MAX['enable']}")
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
