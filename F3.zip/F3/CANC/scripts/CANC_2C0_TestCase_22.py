# Author: Kris
#
# Test case  : CANC_2C0_TestCase_22 (Codebeamer ID 35736869)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : Verify the signal STS_SEAT_BLT_PSGR during run state
# Automation : Automatic
# Note       : A faulty belt is load CANC_DCS_FAULT_LOAD with Leakage VBAT Bus High (bench
#              note); the cross-connect puts both belt channels on that load without the leakage
#              (assumed wiring).
# Note       : SRS1_20 (0x2C0) carries no seat-belt signal; the belt status is read in
#              SRS1_FD_10.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_BELT_CHANNEL,
    CANC_DCS_FAULT_LOAD,
    CANC_DCS_STATE_SETTLE_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    DCS_fault_time,
    SLSNumber,
)


def run_test():
    tc_id = '35736869'
    tc_name = 'CANC_2C0_TestCase_22'
    tc_desc = (
        'Verify the signal STS_SEAT_BLT_PSGR during run state'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    dcs_fault_ms = int(DCS_fault_time['Qualification'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
    dcs_heal_ms = int(DCS_fault_time['Dequalification'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    dcs_cc_ms = int(DCS_fault_time['Qualification_CC'] * (1 + DCS_fault_time['Qualification_Tolerance'] / 100))
    dcs_cc_heal_ms = int(DCS_fault_time['Dequalification_CC'] * (1 + DCS_fault_time['Dequalification_Tolerance'] / 100))
    belt_key = 'STS_SEAT_BLT_PSGR'
    belt_states = MAH_CAN_SIGNAL_DEFS[belt_key]['State_Values']
    belt_unbuckled = next(value for label, value in belt_states.items() if label.startswith('Not Buckled'))
    belt_buckled = belt_states['Buckled']
    belt_faulty = belt_states['Buckle Faulty']
    belt_channel = SLSNumber[CANC_BELT_CHANNEL[belt_key]]
    partner_channel = SLSNumber[CANC_BELT_CHANNEL['STS_SEAT_BLT_DRV']]

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Set the belt to unbuckled')
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
        check_started = time.monotonic()
        for check_key, check_expected in [(belt_key, belt_unbuckled)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Set the belt to buckled')
        SET_DCS_LOADS(DCS_Fault_Description['buckle'], belt_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
        check_started = time.monotonic()
        for check_key, check_expected in [(belt_key, belt_buckled)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Set the belt to faulty (short to battery)')
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, belt_channel)
        PS.SetLeakageVBATBusHigh()
        Wait(dcs_fault_ms)
        check_started = time.monotonic()
        for check_key, check_expected in [(belt_key, belt_faulty)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        PS.ClearLeakageVBATBusHigh()
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        Wait(dcs_heal_ms)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Set the belt to faulty (cross-connected with STS_SEAT_BLT_DRV)')
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, belt_channel)
        SET_DCS_LOADS(CANC_DCS_FAULT_LOAD, partner_channel)
        Wait(dcs_cc_ms)
        check_started = time.monotonic()
        for check_key, check_expected in [(belt_key, belt_faulty)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], partner_channel)
        Wait(dcs_cc_heal_ms)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.ClearLeakageVBATBusHigh()
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], belt_channel)
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], partner_channel)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
