# Author: Kris
#
# Test case  : CANC_13C_TestCase_9 (Codebeamer ID 35739853)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check Signal Values of YAW_RATE Signal in ID 13C
# Automation : Semi-automatic (operator moves the ECU)
# Note       : The stationary value is graded against CANC_IMU_STATIC_EXPECTED +/-
#              CANC_IMU_STATIC_TOLERANCE and the movement against CANC_IMU_MOTION_MIN_SWING; the
#              case gives no band, so these canc_config values are assumptions to confirm.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_IMU_MOTION_MIN_SWING,
    CANC_IMU_STATIC_EXPECTED,
    CANC_IMU_STATIC_TOLERANCE,
    CANC_MANUAL_ACTION_WINDOW_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_NM_WAKEUP_FRAME,
    CAN_PKE_WAKEUP_SIGNAL_KEY,
    CAN_PKE_WAKEUP_VALUES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    CAN_WAKEUP_STATUS_FRAME,
    CAN_WAKEUP_STATUS_SIGNAL,
    CAN_WAKEUP_STATUS_VALUE,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35739853'
    tc_name = 'CANC_13C_TestCase_9'
    tc_desc = (
        'To Check Signal Values of YAW_RATE Signal in ID 13C'
    )
    automation = 'Semi-automatic (operator moves the ECU)'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    pke_def = MAH_CAN_SIGNAL_DEFS[CAN_PKE_WAKEUP_SIGNAL_KEY]
    nm_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == CAN_NM_WAKEUP_FRAME)
    wake_status_key = next(key for key, d in MAH_CAN_SIGNAL_DEFS.items()
                           if d['frame'] == CAN_WAKEUP_STATUS_FRAME and d['signal'] == CAN_WAKEUP_STATUS_SIGNAL)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(pke_def['bus'], pke_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Verify YAW_RATE on a stationary ECU')
        static_ids = [fd_id]
        static_file = os.path.splitext(log_path)[0] + '_static.txt'
        static_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_static', filepath=static_file,
            listOption=static_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(static_logger)
        static_frames = []
        if os.path.isfile(static_file):
            with open(static_file, encoding='utf-8', errors='replace') as static_log:
                static_fields = [line.split(',', 2) for line in static_log if ' id=' in line and line.count(',') >= 2]
            static_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in static_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(static_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        static_frames = [frame_data for frame_data in static_frames if frame_data.id in static_ids]
        static_def = MAH_CAN_SIGNAL_DEFS['YAW_RATE']
        static_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['YAW_RATE'],
                                                                 static_def['bit_length']),
                                              scaling=static_def['Factor'], offset=static_def['Offset'],
                                              bits=static_def['bit_length'], signed=bool(static_def.get('Signed'))), 4)
                        for frame_data in static_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{static_def['signal']} on a stationary ECU ({static_def.get('UNIT') or 'physical'})",
                                         static_values or [None],
                                         CANC_IMU_STATIC_EXPECTED['YAW_RATE'] - CANC_IMU_STATIC_TOLERANCE['YAW_RATE'],
                                         CANC_IMU_STATIC_EXPECTED['YAW_RATE'] + CANC_IMU_STATIC_TOLERANCE['YAW_RATE'])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: IGN OFF, then CAN wakeup (PKE_CLMP_STATE at its wake value)')
        for pke_value in CAN_PKE_WAKEUP_VALUES:
            RESULT.InsertComment(f"CAN wakeup with {pke_def['signal']} = {pke_value}")
            PS.IGN_ON()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
            PS.IGN_OFF()
            CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(pke_value))
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
            check_started = time.monotonic()
            for check_key, check_expected in [(wake_status_key, CAN_WAKEUP_STATUS_VALUE)]:
                check_def = MAH_CAN_SIGNAL_DEFS[check_key]
                while True:
                    check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                    try:
                        check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                    except ValueError:
                        check_value = check_text
                    if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult('ECU awake through CAN: ' + f"{check_def['frame']} {check_def['signal']}",
                                            str(check_value), str(check_expected))
            presence4_ids = [fd_id, hs_id]
            presence4_file = os.path.splitext(log_path)[0] + '_can_wake.txt'
            presence4_logger = CAN.StartLoggingToFile(
                TestCase_ID=tc_name + '_can_wake', filepath=presence4_file,
                listOption=presence4_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
            Wait(presence_window_ms)
            CAN.StopLoggingToFile(presence4_logger)
            presence4_frames = []
            if os.path.isfile(presence4_file):
                with open(presence4_file, encoding='utf-8', errors='replace') as presence4_log:
                    presence4_fields = [line.split(',', 2) for line in presence4_log if ' id=' in line and line.count(',') >= 2]
                presence4_frames = [
                    SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                    id=int(fields[1].split('=')[1], 16),
                                    payload=bytearray.fromhex(fields[2].strip()))
                    for fields in presence4_fields]
            else:
                RESULT.LogCustomAction(f"CAN log {os.path.basename(presence4_file)} written", "File present",
                                       "File missing: no frames to evaluate", False)
            presence4_frames = [frame_data for frame_data in presence4_frames if frame_data.id in presence4_ids]
            presence4_fd_count = sum(1 for frame_data in presence4_frames if frame_data.id == fd_id)
            RESULT.InterpretEqualResultRange(
                f"{fd_frame} is transmitted (frames in the window)",
                presence4_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
            presence4_hs_count = sum(1 for frame_data in presence4_frames if frame_data.id == hs_id)
            RESULT.InterpretEqualResultRange(
                f"{hs_frame} is transmitted (frames in the window)",
                presence4_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Rotate the ECU in the yaw direction (arc-shaped movement)')
        motion_ids = [fd_id]
        motion_file = os.path.splitext(log_path)[0] + '_motion.txt'
        motion_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_motion', filepath=motion_file,
            listOption=motion_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        RESULT.InsertComment(f'OPERATOR ACTION: Rotate the ECU in the yaw direction (arc-shaped movement) during the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        print(f'OPERATOR ACTION: Rotate the ECU in the yaw direction (arc-shaped movement) during the next {CANC_MANUAL_ACTION_WINDOW_MS / 1000:.0f} s.')
        Wait(CANC_MANUAL_ACTION_WINDOW_MS)
        CAN.StopLoggingToFile(motion_logger)
        motion_frames = []
        if os.path.isfile(motion_file):
            with open(motion_file, encoding='utf-8', errors='replace') as motion_log:
                motion_fields = [line.split(',', 2) for line in motion_log if ' id=' in line and line.count(',') >= 2]
            motion_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in motion_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(motion_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        motion_frames = [frame_data for frame_data in motion_frames if frame_data.id in motion_ids]
        motion_def = MAH_CAN_SIGNAL_DEFS['YAW_RATE']
        motion_values = [round(raw_to_physical(extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT['YAW_RATE'],
                                                                 motion_def['bit_length']),
                                              scaling=motion_def['Factor'], offset=motion_def['Offset'],
                                              bits=motion_def['bit_length'], signed=bool(motion_def.get('Signed'))), 4)
                        for frame_data in motion_frames if frame_data.id == fd_id]
        RESULT.InterpretEqualResultRange(f"{motion_def['signal']} follows the movement (swing, physical)",
                                         round(max(motion_values) - min(motion_values), 4) if motion_values else None,
                                         CANC_IMU_MOTION_MIN_SWING['YAW_RATE'], float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
            PS.IGN_ON()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
