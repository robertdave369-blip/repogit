# Author: Kris
#
# Test case  : CANC_2C0_TestCase_24 (Codebeamer ID 35736871)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : Verify the signals STS_SEAT_BLT_PSGR STS_SEAT_BLT_DRV during proveout state
# Automation : Automatic
# Note       : SRS1_20 (0x2C0) carries no seat-belt signal; the belt status is read in
#              SRS1_FD_10.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_BELT_CHANNEL,
    CANC_DCS_STATE_SETTLE_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_SEAT_BELT_INIT_WINDOW_MS,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    SLSNumber,
)


def run_test():
    tc_id = '35736871'
    tc_name = 'CANC_2C0_TestCase_24'
    tc_desc = (
        'Verify the signals STS_SEAT_BLT_PSGR STS_SEAT_BLT_DRV during proveout state'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    psgr_key = 'STS_SEAT_BLT_PSGR'
    psgr_states = MAH_CAN_SIGNAL_DEFS[psgr_key]['State_Values']
    psgr_unbuckled = next(value for label, value in psgr_states.items() if label.startswith('Not Buckled'))
    psgr_reserved = psgr_states['Reserved']
    psgr_channel = SLSNumber[CANC_BELT_CHANNEL[psgr_key]]
    drv_key = 'STS_SEAT_BLT_DRV'
    drv_states = MAH_CAN_SIGNAL_DEFS[drv_key]['State_Values']
    drv_unbuckled = next(value for label, value in drv_states.items() if label.startswith('Not Buckled'))
    drv_reserved = drv_states['Reserved']
    drv_channel = SLSNumber[CANC_BELT_CHANNEL[drv_key]]

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Set both front belts to unbuckled')
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], psgr_channel)
        SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], drv_channel)
        Wait(CANC_DCS_STATE_SETTLE_MS)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN and observe the belt status in the first frames')
        init_ids = [fd_id]
        init_file = os.path.splitext(log_path)[0] + '_belt_init.txt'
        init_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_belt_init', filepath=init_file,
            listOption=init_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        PS.Power_Cycle()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS + CANC_SEAT_BELT_INIT_WINDOW_MS)
        CAN.StopLoggingToFile(init_logger)
        init_frames = []
        if os.path.isfile(init_file):
            with open(init_file, encoding='utf-8', errors='replace') as init_log:
                init_fields = [line.split(',', 2) for line in init_log if ' id=' in line and line.count(',') >= 2]
            init_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in init_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(init_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        init_frames = [frame_data for frame_data in init_frames if frame_data.id in init_ids]
        psgr_init_rows = [(frame_data.timestamp / 1000,
                       extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[psgr_key], MAH_CAN_SIGNAL_DEFS[psgr_key]['bit_length']))
                      for frame_data in init_frames if frame_data.id == fd_id]
        psgr_init_restart = max([index for index in range(1, len(psgr_init_rows))
                             if psgr_init_rows[index][0] - psgr_init_rows[index - 1][0] > 5 * fd_period_ms] or [0])
        psgr_init_rows = psgr_init_rows[psgr_init_restart:]
        psgr_init_reserved = [t for t, value in psgr_init_rows if value == psgr_reserved]
        # The ECU's first frames after IGN ON carry the default for about 60 ms before
        # the Reserved state (2026-10-15: 0 for 60 ms, Reserved until 230 ms, then the
        # actual value), so Reserved must show within the init window, not in frame one.
        RESULT.InterpretEqualResultRange(f"{psgr_key} reads Reserved at the start of transmission (ms after the first frame)",
                                         round(psgr_init_reserved[0] - psgr_init_rows[0][0], 1) if psgr_init_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResultRange(f"{psgr_key} Reserved after IGN ON for (ms)",
                                         round(psgr_init_reserved[-1] - psgr_init_rows[0][0], 1) + fd_period_ms if psgr_init_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResult(f"{psgr_key} then takes the actual value",
                                    psgr_init_rows[-1][1] if psgr_init_rows else None, psgr_unbuckled)
        drv_init_rows = [(frame_data.timestamp / 1000,
                       extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[drv_key], MAH_CAN_SIGNAL_DEFS[drv_key]['bit_length']))
                      for frame_data in init_frames if frame_data.id == fd_id]
        drv_init_restart = max([index for index in range(1, len(drv_init_rows))
                             if drv_init_rows[index][0] - drv_init_rows[index - 1][0] > 5 * fd_period_ms] or [0])
        drv_init_rows = drv_init_rows[drv_init_restart:]
        drv_init_reserved = [t for t, value in drv_init_rows if value == drv_reserved]
        # The ECU's first frames after IGN ON carry the default for about 60 ms before
        # the Reserved state (2026-10-15: 0 for 60 ms, Reserved until 230 ms, then the
        # actual value), so Reserved must show within the init window, not in frame one.
        RESULT.InterpretEqualResultRange(f"{drv_key} reads Reserved at the start of transmission (ms after the first frame)",
                                         round(drv_init_reserved[0] - drv_init_rows[0][0], 1) if drv_init_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResultRange(f"{drv_key} Reserved after IGN ON for (ms)",
                                         round(drv_init_reserved[-1] - drv_init_rows[0][0], 1) + fd_period_ms if drv_init_reserved else None,
                                         0, CANC_SEAT_BELT_INIT_WINDOW_MS)
        RESULT.InterpretEqualResult(f"{drv_key} then takes the actual value",
                                    drv_init_rows[-1][1] if drv_init_rows else None, drv_unbuckled)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.ClearLeakageVBATBusHigh()
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], psgr_channel)
            SET_DCS_LOADS(DCS_Fault_Description['unbuckle'], drv_channel)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
