# Author: Kris
#
# Test case  : CAN_BUSOFF_13 (Codebeamer ID 35721119)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : 1. To check the behaviour of ACU during busoff condition. 2. To test no CAN
#              messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is not BUS
#              OFF)
# Automation : Semi-automatic (operator creates and removes the bus-off)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.
# Note       : After the variant code error is historic the case still expects the lamp ON; with
#              only D27100 active (warning lamp 0 in the customer DTC list) the script expects
#              the lamp the configured bus-off status gives.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_BUS_OFF_ACTIVE_STATUS_KEY,
    CAN_BUS_OFF_DTC,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35721119'
    tc_name = 'CAN_BUSOFF_13'
    tc_desc = (
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages '
        'diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is not BUS OFF)'
    )
    automation = 'Semi-automatic (operator creates and removes the bus-off)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    lamp_on = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp ON']
    lamp_off = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp OFF/Default']
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)
    hs_busoff_lamp = lamp_on if int(DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']], 16) & 0x80 else lamp_off

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues')
        RESULT.InsertComment('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        print('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_hs.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_hs', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence2_hs_count, 0)
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_fd_alive.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_fd_alive', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create a variant code error and check the warning lamp in SRS1_FD_10')
        manage_variant_code('VARIANT_STATUS', 'disable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        Wait(busoff_settle_ms)
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_on)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult('Warning lamp with the variant code error: ' + f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Read DTC while the bus-off is active')
        settle_time_ms = faultTimeMeasurement(f"{CAN_BUS_OFF_DTC['HSCAN']} {DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']]};{Variant_Code_DTC} {DTC_status['DTC_active']}")
        RESULT.LogAction('Time until the bus-off and variant code DTCs are active (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'HS-CAN bus-off and variant code DTCs active',
            " ".join([Read_DTC_Resp_CANC,
                      CAN_BUS_OFF_DTC['HSCAN'], DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']],
                      Variant_Code_DTC, DTC_status['DTC_active']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Make the variant code error historic and check the warning lamp')
        manage_variant_code('DEFAULT', project=PROJECT_NAME)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        Wait(busoff_settle_ms)
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', hs_busoff_lamp)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult('Warning lamp with only the HS-CAN bus-off active: ' + f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
