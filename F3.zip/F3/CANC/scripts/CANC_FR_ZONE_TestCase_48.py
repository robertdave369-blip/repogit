# Author: Kris
#
# Test case  : CANC_FR_ZONE_TestCase_48 (Codebeamer ID 35660025)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that message-content failure (DLC) for FR_ZONE3_100 is not qualified while
#              Over-Voltage condition is active.
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_OVERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    MAH_CAN_SIGNAL_DEFS,
    get_frame_message_content_failure_dtc,
    get_message_content_failure_signals,
    qualification_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35660025'
    tc_name = 'CANC_FR_ZONE_TestCase_48'
    tc_desc = (
        'Verify that message-content failure (DLC) for FR_ZONE3_100 is not qualified while '
        'Over-Voltage condition is active.'
    )
    automation = 'Automatic'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    mcf_frame = 'FR_ZONE3_100'
    mcf_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == mcf_frame)
    mcf_bus = mcf_def['bus']
    mcf_dtc = get_frame_message_content_failure_dtc(mcf_frame)[0]
    if mcf_dtc is None:
        mcf_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(mcf_frame)
    mcf_error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[mcf_def['dlc']])
    mcf_dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals(mcf_frame)
                           if key in MAH_CAN_SIGNAL_DEFS]
    mcf_qualify_nominal_ms = qualification_ms('message_content', mcf_def['periodicity'])
    mcf_qualify_ms = int(mcf_qualify_nominal_ms * margin)
    voltage_level = CANC_OVERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Over_Voltage

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([mcf_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure (DLC) DTC of {mcf_frame}', mcf_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(mcf_bus, mcf_frame)
        CAN.ReloadDefaultPeriodicFrame(mcf_bus, mcf_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create over-voltage condition')
        PS.SetVoltage(voltage_level)
        voltage_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]}")
        RESULT.LogAction('Time until the voltage DTC is active (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create fault while the abnormal voltage is present - inject incorrect DLC on FR_ZONE3_100')
        for mcf_dynamic_signal in mcf_dynamic_signals:
            CAN.DynamicDisableSignal(mcf_bus, mcf_frame, mcf_dynamic_signal)
        CAN.SetPeriodicFrame(mcf_bus, mcf_frame, mcf_def['frame_ID'], mcf_def['periodicity'],
                             mcf_error_payload, mcf_def['is_fd'])
        CAN.PeriodicEnableFrame(mcf_bus, mcf_frame)
        Wait(mcf_qualify_ms)
        Read_DTC(
            'Message content failure not qualified while the abnormal voltage is present',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage, then valid message content - restore correct DLC on FR_ZONE3_100')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.ReloadDefaultPeriodicFrame(mcf_bus, mcf_frame)
        for mcf_dynamic_signal in mcf_dynamic_signals:
            CAN.DynamicEnableSignal(mcf_bus, mcf_frame, mcf_dynamic_signal)
        CAN.PeriodicEnableFrame(mcf_bus, mcf_frame)
        voltage_time_ms = faultTimeMeasurement(f"{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]}")
        RESULT.LogAction('Time until the voltage DTC is healed (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC healed, message content failure remains not active',
            " ".join([Read_DTC_Resp_CANC,
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.ReloadDefaultPeriodicFrame(mcf_bus, mcf_frame)
            for mcf_dynamic_signal in mcf_dynamic_signals:
                CAN.DynamicEnableSignal(mcf_bus, mcf_frame, mcf_dynamic_signal)
            CAN.PeriodicEnableFrame(mcf_bus, mcf_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
