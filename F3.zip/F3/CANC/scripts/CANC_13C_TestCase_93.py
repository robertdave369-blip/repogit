# Author: Kris
#
# Test case  : CANC_13C_TestCase_93 (Codebeamer ID 36753997)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify_STS_FIRST_CRASH_ROLL
# Automation : Automatic once the multi-event crash curves are delivered (blocked until then)
# Note       : load_crash_curves sends the central-sensor curves of every crash type through the
#              SPI sensor card (SPI.SendCrashData). On 2026-10-15 ARIA answered 'Card not
#              present in ARIA Chassis', which fails the case even where the satellite curves
#              alone produced the crash (13C 35/37/95/96: STS_CRASH held 800 ms with the right
#              CRASH_LOCATION). The case runs as it stands once the card is fitted.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_LOCATION_STATE,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '36753997'
    tc_name = 'CANC_13C_TestCase_93'
    tc_desc = (
        'Verify_STS_FIRST_CRASH_ROLL'
    )
    automation = 'Automatic once the multi-event crash curves are delivered (blocked until then)'

    crash1_curve_key = CANC_CRASH_CURVE_KEY['front_then_rollover']
    crash1_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash1_curve_key) or {}
    crash1_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash1_curve_set.get('RSU', {}).values())
    crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
    crash2_curve_key = CANC_CRASH_CURVE_KEY['rollover']
    crash2_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash2_curve_key) or {}
    crash2_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash2_curve_set.get('RSU', {}).values())
    crash3_curve_key = CANC_CRASH_CURVE_KEY['left_then_rollover']
    crash3_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash3_curve_key) or {}
    crash3_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash3_curve_set.get('RSU', {}).values())
    crash4_curve_key = CANC_CRASH_CURVE_KEY['rollover']
    crash4_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash4_curve_key) or {}
    crash4_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash4_curve_set.get('RSU', {}).values())
    crash5_curve_key = CANC_CRASH_CURVE_KEY['right_then_rollover']
    crash5_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash5_curve_key) or {}
    crash5_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash5_curve_set.get('RSU', {}).values())
    crash6_curve_key = CANC_CRASH_CURVE_KEY['rollover']
    crash6_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash6_curve_key) or {}
    crash6_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash6_curve_set.get('RSU', {}).values())
    crash7_curve_key = CANC_CRASH_CURVE_KEY['rear_then_rollover']
    crash7_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash7_curve_key) or {}
    crash7_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash7_curve_set.get('RSU', {}).values())
    crash8_curve_key = CANC_CRASH_CURVE_KEY['rollover']
    crash8_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash8_curve_key) or {}
    crash8_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash8_curve_set.get('RSU', {}).values())
    crash9_curve_key = CANC_CRASH_CURVE_KEY['underbody_then_rollover']
    crash9_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash9_curve_key) or {}
    crash9_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash9_curve_set.get('RSU', {}).values())
    crash10_curve_key = CANC_CRASH_CURVE_KEY['rollover']
    crash10_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash10_curve_key) or {}
    crash10_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash10_curve_set.get('RSU', {}).values())
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash1_curve_key}', crash1_curves_ready or None),
            (f'crash curves for {crash2_curve_key}', crash2_curves_ready or None),
            (f'crash curves for {crash3_curve_key}', crash3_curves_ready or None),
            (f'crash curves for {crash4_curve_key}', crash4_curves_ready or None),
            (f'crash curves for {crash5_curve_key}', crash5_curves_ready or None),
            (f'crash curves for {crash6_curve_key}', crash6_curves_ready or None),
            (f'crash curves for {crash7_curve_key}', crash7_curves_ready or None),
            (f'crash curves for {crash8_curve_key}', crash8_curves_ready or None),
            (f'crash curves for {crash9_curve_key}', crash9_curves_ready or None),
            (f'crash curves for {crash10_curve_key}', crash10_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: First crash rollover: front then rollover')
        load_crash_curves(crash1_curve_key, project=PROJECT_NAME)
        seq1_ids = [fd_id, hs_id]
        seq1_file = os.path.splitext(log_path)[0] + '_seq1.txt'
        seq1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq1', filepath=seq1_file,
            listOption=seq1_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq1_logger)
        seq1_frames = []
        if os.path.isfile(seq1_file):
            with open(seq1_file, encoding='utf-8', errors='replace') as seq1_log:
                seq1_fields = [line.split(',', 2) for line in seq1_log if ' id=' in line and line.count(',') >= 2]
            seq1_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq1_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq1_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq1_frames = [frame_data for frame_data in seq1_frames if frame_data.id in seq1_ids]
        seq1_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq1_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq1_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq1_frames if frame_data.id == fd_id]
        seq1_fd_locations = [row['loc'] for row in seq1_fd if row['sts'] == crash_set]
        seq1_fd_sequence = [value for position, value in enumerate(seq1_fd_locations)
                           if position == 0 or value != seq1_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq1_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['front']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq1_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_NOT_FIRST_CRASH_DEFAULT']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 4: First crash rollover: rollover')
        load_crash_curves(crash2_curve_key, project=PROJECT_NAME)
        seq2_ids = [fd_id, hs_id]
        seq2_file = os.path.splitext(log_path)[0] + '_seq2.txt'
        seq2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq2', filepath=seq2_file,
            listOption=seq2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq2_logger)
        seq2_frames = []
        if os.path.isfile(seq2_file):
            with open(seq2_file, encoding='utf-8', errors='replace') as seq2_log:
                seq2_fields = [line.split(',', 2) for line in seq2_log if ' id=' in line and line.count(',') >= 2]
            seq2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq2_frames = [frame_data for frame_data in seq2_frames if frame_data.id in seq2_ids]
        seq2_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq2_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq2_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq2_frames if frame_data.id == fd_id]
        seq2_fd_locations = [row['loc'] for row in seq2_fd if row['sts'] == crash_set]
        seq2_fd_sequence = [value for position, value in enumerate(seq2_fd_locations)
                           if position == 0 or value != seq2_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq2_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rollover']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq2_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_IS_FIRST_CRASH']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 5: First crash rollover: left then rollover')
        load_crash_curves(crash3_curve_key, project=PROJECT_NAME)
        seq3_ids = [fd_id, hs_id]
        seq3_file = os.path.splitext(log_path)[0] + '_seq3.txt'
        seq3_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq3', filepath=seq3_file,
            listOption=seq3_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq3_logger)
        seq3_frames = []
        if os.path.isfile(seq3_file):
            with open(seq3_file, encoding='utf-8', errors='replace') as seq3_log:
                seq3_fields = [line.split(',', 2) for line in seq3_log if ' id=' in line and line.count(',') >= 2]
            seq3_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq3_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq3_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq3_frames = [frame_data for frame_data in seq3_frames if frame_data.id in seq3_ids]
        seq3_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq3_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq3_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq3_frames if frame_data.id == fd_id]
        seq3_fd_locations = [row['loc'] for row in seq3_fd if row['sts'] == crash_set]
        seq3_fd_sequence = [value for position, value in enumerate(seq3_fd_locations)
                           if position == 0 or value != seq3_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq3_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['left']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq3_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_NOT_FIRST_CRASH_DEFAULT']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 6: First crash rollover: rollover')
        load_crash_curves(crash4_curve_key, project=PROJECT_NAME)
        seq4_ids = [fd_id, hs_id]
        seq4_file = os.path.splitext(log_path)[0] + '_seq4.txt'
        seq4_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq4', filepath=seq4_file,
            listOption=seq4_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq4_logger)
        seq4_frames = []
        if os.path.isfile(seq4_file):
            with open(seq4_file, encoding='utf-8', errors='replace') as seq4_log:
                seq4_fields = [line.split(',', 2) for line in seq4_log if ' id=' in line and line.count(',') >= 2]
            seq4_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq4_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq4_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq4_frames = [frame_data for frame_data in seq4_frames if frame_data.id in seq4_ids]
        seq4_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq4_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq4_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq4_frames if frame_data.id == fd_id]
        seq4_fd_locations = [row['loc'] for row in seq4_fd if row['sts'] == crash_set]
        seq4_fd_sequence = [value for position, value in enumerate(seq4_fd_locations)
                           if position == 0 or value != seq4_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq4_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rollover']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq4_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_IS_FIRST_CRASH']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 7: First crash rollover: right then rollover')
        load_crash_curves(crash5_curve_key, project=PROJECT_NAME)
        seq5_ids = [fd_id, hs_id]
        seq5_file = os.path.splitext(log_path)[0] + '_seq5.txt'
        seq5_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq5', filepath=seq5_file,
            listOption=seq5_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq5_logger)
        seq5_frames = []
        if os.path.isfile(seq5_file):
            with open(seq5_file, encoding='utf-8', errors='replace') as seq5_log:
                seq5_fields = [line.split(',', 2) for line in seq5_log if ' id=' in line and line.count(',') >= 2]
            seq5_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq5_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq5_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq5_frames = [frame_data for frame_data in seq5_frames if frame_data.id in seq5_ids]
        seq5_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq5_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq5_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq5_frames if frame_data.id == fd_id]
        seq5_fd_locations = [row['loc'] for row in seq5_fd if row['sts'] == crash_set]
        seq5_fd_sequence = [value for position, value in enumerate(seq5_fd_locations)
                           if position == 0 or value != seq5_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq5_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['right']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq5_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_NOT_FIRST_CRASH_DEFAULT']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 8: First crash rollover: rollover')
        load_crash_curves(crash6_curve_key, project=PROJECT_NAME)
        seq6_ids = [fd_id, hs_id]
        seq6_file = os.path.splitext(log_path)[0] + '_seq6.txt'
        seq6_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq6', filepath=seq6_file,
            listOption=seq6_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq6_logger)
        seq6_frames = []
        if os.path.isfile(seq6_file):
            with open(seq6_file, encoding='utf-8', errors='replace') as seq6_log:
                seq6_fields = [line.split(',', 2) for line in seq6_log if ' id=' in line and line.count(',') >= 2]
            seq6_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq6_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq6_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq6_frames = [frame_data for frame_data in seq6_frames if frame_data.id in seq6_ids]
        seq6_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq6_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq6_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq6_frames if frame_data.id == fd_id]
        seq6_fd_locations = [row['loc'] for row in seq6_fd if row['sts'] == crash_set]
        seq6_fd_sequence = [value for position, value in enumerate(seq6_fd_locations)
                           if position == 0 or value != seq6_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq6_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rollover']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq6_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_IS_FIRST_CRASH']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 9: First crash rollover: rear then rollover')
        load_crash_curves(crash7_curve_key, project=PROJECT_NAME)
        seq7_ids = [fd_id, hs_id]
        seq7_file = os.path.splitext(log_path)[0] + '_seq7.txt'
        seq7_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq7', filepath=seq7_file,
            listOption=seq7_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq7_logger)
        seq7_frames = []
        if os.path.isfile(seq7_file):
            with open(seq7_file, encoding='utf-8', errors='replace') as seq7_log:
                seq7_fields = [line.split(',', 2) for line in seq7_log if ' id=' in line and line.count(',') >= 2]
            seq7_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq7_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq7_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq7_frames = [frame_data for frame_data in seq7_frames if frame_data.id in seq7_ids]
        seq7_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq7_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq7_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq7_frames if frame_data.id == fd_id]
        seq7_fd_locations = [row['loc'] for row in seq7_fd if row['sts'] == crash_set]
        seq7_fd_sequence = [value for position, value in enumerate(seq7_fd_locations)
                           if position == 0 or value != seq7_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq7_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rear']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq7_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_NOT_FIRST_CRASH_DEFAULT']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 10: First crash rollover: rollover')
        load_crash_curves(crash8_curve_key, project=PROJECT_NAME)
        seq8_ids = [fd_id, hs_id]
        seq8_file = os.path.splitext(log_path)[0] + '_seq8.txt'
        seq8_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq8', filepath=seq8_file,
            listOption=seq8_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq8_logger)
        seq8_frames = []
        if os.path.isfile(seq8_file):
            with open(seq8_file, encoding='utf-8', errors='replace') as seq8_log:
                seq8_fields = [line.split(',', 2) for line in seq8_log if ' id=' in line and line.count(',') >= 2]
            seq8_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq8_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq8_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq8_frames = [frame_data for frame_data in seq8_frames if frame_data.id in seq8_ids]
        seq8_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq8_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq8_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq8_frames if frame_data.id == fd_id]
        seq8_fd_locations = [row['loc'] for row in seq8_fd if row['sts'] == crash_set]
        seq8_fd_sequence = [value for position, value in enumerate(seq8_fd_locations)
                           if position == 0 or value != seq8_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq8_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rollover']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq8_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_IS_FIRST_CRASH']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 11: First crash rollover: underbody then rollover')
        load_crash_curves(crash9_curve_key, project=PROJECT_NAME)
        seq9_ids = [fd_id, hs_id]
        seq9_file = os.path.splitext(log_path)[0] + '_seq9.txt'
        seq9_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq9', filepath=seq9_file,
            listOption=seq9_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq9_logger)
        seq9_frames = []
        if os.path.isfile(seq9_file):
            with open(seq9_file, encoding='utf-8', errors='replace') as seq9_log:
                seq9_fields = [line.split(',', 2) for line in seq9_log if ' id=' in line and line.count(',') >= 2]
            seq9_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq9_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq9_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq9_frames = [frame_data for frame_data in seq9_frames if frame_data.id in seq9_ids]
        seq9_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq9_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq9_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq9_frames if frame_data.id == fd_id]
        seq9_fd_locations = [row['loc'] for row in seq9_fd if row['sts'] == crash_set]
        seq9_fd_sequence = [value for position, value in enumerate(seq9_fd_locations)
                           if position == 0 or value != seq9_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq9_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['underbody']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq9_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_NOT_FIRST_CRASH_DEFAULT']])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 12: First crash rollover: rollover')
        load_crash_curves(crash10_curve_key, project=PROJECT_NAME)
        seq10_ids = [fd_id, hs_id]
        seq10_file = os.path.splitext(log_path)[0] + '_seq10.txt'
        seq10_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq10', filepath=seq10_file,
            listOption=seq10_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq10_logger)
        seq10_frames = []
        if os.path.isfile(seq10_file):
            with open(seq10_file, encoding='utf-8', errors='replace') as seq10_log:
                seq10_fields = [line.split(',', 2) for line in seq10_log if ' id=' in line and line.count(',') >= 2]
            seq10_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq10_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq10_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq10_frames = [frame_data for frame_data in seq10_frames if frame_data.id in seq10_ids]
        seq10_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION', 'roll': 'STS_FIRST_CRASH_ROLL'}
        seq10_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq10_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq10_frames if frame_data.id == fd_id]
        seq10_fd_locations = [row['loc'] for row in seq10_fd if row['sts'] == crash_set]
        seq10_fd_sequence = [value for position, value in enumerate(seq10_fd_locations)
                           if position == 0 or value != seq10_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq10_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['rollover']]])
        RESULT.InterpretEqualResult(f"{fd_frame} STS_FIRST_CRASH_ROLL",
                                    sorted({row['roll'] for row in seq10_fd if row['sts'] == crash_set}),
                                    [MAH_CAN_SIGNAL_DEFS['STS_FIRST_CRASH_ROLL']['State_Values']['ROLLOVER_IS_FIRST_CRASH']])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
