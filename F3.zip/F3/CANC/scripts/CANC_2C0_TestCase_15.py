# Author: Kris
#
# Test case  : CANC_2C0_TestCase_15 (Codebeamer ID 35736862)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check value of Even parity signal when Crash occurs
# Automation : Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent
#              through it)
# Note       : load_crash_curves sends the central-sensor curves of every crash type through the
#              SPI sensor card (SPI.SendCrashData). On 2026-10-15 ARIA answered 'Card not
#              present in ARIA Chassis', which fails the case even where the satellite curves
#              alone produced the crash (13C 35/37/95/96: STS_CRASH held 800 ms with the right
#              CRASH_LOCATION). The case runs as it stands once the card is fitted.
# Note       : The case expects EVEN_PARITY_BIT = 1 throughout the crash; the bit follows byte 0
#              (DBC: even parity over bits 0-6), so the script grades every frame against byte 0
#              and records the values seen.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736862'
    tc_name = 'CANC_2C0_TestCase_15'
    tc_desc = (
        'To Check value of Even parity signal when Crash occurs'
    )
    automation = 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)'

    parity_key = 'SRS1_20_EVEN_PARITY_BIT'
    parity_def = MAH_CAN_SIGNAL_DEFS[parity_key]
    parity_id = CAN_RX_MESSAGE_CONFIG[parity_def['frame']]['frame_ID']
    # EVEN_PARITY_BIT makes the count of ones in bits 0 to (its start bit - 1) of byte 0 even.
    parity_mask = (1 << CAN_SIGNAL_START_BIT[parity_key]) - 1
    parity_odd = parity_def['State_Values']['ODD/Default']
    crash_curve_key = CANC_CRASH_CURVE_KEY['front']
    crash_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash_curve_key) or {}
    crash_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash_curve_set.get('RSU', {}).values())
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash_curve_key}', crash_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Verify EVEN_PARITY_BIT with no fault')
        idle_ids = [hs_id]
        idle_file = os.path.splitext(log_path)[0] + '_parity_idle.txt'
        idle_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_parity_idle', filepath=idle_file,
            listOption=idle_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(idle_logger)
        idle_frames = []
        if os.path.isfile(idle_file):
            with open(idle_file, encoding='utf-8', errors='replace') as idle_log:
                idle_fields = [line.split(',', 2) for line in idle_log if ' id=' in line and line.count(',') >= 2]
            idle_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in idle_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(idle_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        idle_frames = [frame_data for frame_data in idle_frames if frame_data.id in idle_ids]
        idle_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in idle_frames if frame_data.id == parity_id]
        idle_errors = [row for row in idle_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str(idle_errors[:5]), "[]")
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT", sorted({row[1] for row in idle_rows}), [parity_odd])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Simulate a front crash and verify EVEN_PARITY_BIT')
        load_crash_curves(crash_curve_key, project=PROJECT_NAME)
        fault_ids = [hs_id]
        fault_file = os.path.splitext(log_path)[0] + '_fault.txt'
        fault_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_fault', filepath=fault_file,
            listOption=fault_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(3 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(fault_logger)
        fault_frames = []
        if os.path.isfile(fault_file):
            with open(fault_file, encoding='utf-8', errors='replace') as fault_log:
                fault_fields = [line.split(',', 2) for line in fault_log if ' id=' in line and line.count(',') >= 2]
            fault_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in fault_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(fault_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        fault_frames = [frame_data for frame_data in fault_frames if frame_data.id in fault_ids]
        fault_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in fault_frames if frame_data.id == parity_id]
        fault_errors = [row for row in fault_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str(fault_errors[:5]), "[]")
        RESULT.LogAction(f"{parity_def['frame']} EVEN_PARITY_BIT values during the crash", str(sorted({row[1] for row in fault_rows})))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
