# Author: Kris
#
# Test case  : CANC_DIAGNOSTICS_Testcase2 (Codebeamer ID 35720676)
# Workbook   : Diagnostic_ID_TestCases.xlsx
# Objective  : To Verify message IDs 7DF & 738 in CANFD bus
# Automation : Automatic
# Note       : The case expects '62 01 02' for a 22 01 01 request; ISO 14229-1 echoes the
#              requested DID, so the script expects 62 01 01 followed by the variant code
#              fault_free_profile writes.
# Note       : On 2026-10-15 the ECU answered 10 03 on 7DF but nothing at all to 22 01 01 on 7DF
#              (no first frame on 738), while 22 01 01 on 730 works: an ECU finding unless the
#              requirement excludes DID 01 01 from functional requests.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    DEFAULT_VARIANT_CODE,
    DIAG_FUNCTIONAL_ID,
    DIAG_RX_ID,
    DIAG_TX_ID,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_SESSION_EXTENDED,
)


def run_test():
    tc_id = '35720676'
    tc_name = 'CANC_DIAGNOSTICS_Testcase2'
    tc_desc = (
        'To Verify message IDs 7DF & 738 in CANFD bus'
    )
    automation = 'Automatic'

    variant_code_request = f"{READ_SID} {VARIANT_CODE_DID}"
    variant_code_response = f"0x{int(READ_SID, 16) + 0x40:02X} {VARIANT_CODE_DID} {DEFAULT_VARIANT_CODE}"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Use functional addressing (request 7DF, response 738)')
        RESULT.LogAction('Addressing', CAN.SetDiagnosticAdressingMode(DIAG_FUNCTIONAL_ID, DIAG_RX_ID))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Enter the extended session and unlock security level 1')
        RESULT.InterpretEqualResult('Extended session', str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)), UDS_RESP_SESSION_EXTENDED)
        # Security access is a physical request (730), as the case says.
        CAN.SetDiagnosticAdressingMode(DIAG_TX_ID, DIAG_RX_ID)
        Internal_Security_Access(0x01)
        CAN.SetDiagnosticAdressingMode(DIAG_FUNCTIONAL_ID, DIAG_RX_ID)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Read DID 01 01 (variant code)')
        variant_code_read = str(CAN.SendDiagByValues(variant_code_request))
        RESULT.InterpretEqualResult("Response on 738 to 22 01 01", variant_code_read.upper(), variant_code_response.upper())
        RESULT.InterpretEqualResult("Variant code data bytes", len(variant_code_read.split()) - 3,
                                    len(DEFAULT_VARIANT_CODE.split()))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.SetDiagnosticAdressingMode(DIAG_TX_ID, DIAG_RX_ID)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
