# Author: Kris
#
# Test case  : CAN_BUSOFF_5 (Codebeamer ID 35721111)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : If Bus off happens under conditions Under voltage or Over voltage(supply voltage
#              out of VNW_Diag_Low_OFF to VNW_Diag_High_OFF), ACU should not qualify the
#              CAN_BUS_OFF_FAULT. Whenever BUS OFF condition is removed, then the CAN
#              communication should become normal.
# Automation : Semi-automatic (operator creates and removes the bus-off)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.
# Note       : The case lowers the supply to 7 V; the script uses CANC_UNDERVOLTAGE_TEST_VOLTAGE
#              (6.5 V), also below the 9 V threshold. The case does not name the bus, so both
#              buses are used.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_OVERVOLTAGE_TEST_VOLTAGE,
    CANC_UNDERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35721111'
    tc_name = 'CAN_BUSOFF_5'
    tc_desc = (
        'If Bus off happens under conditions Under voltage or Over voltage(supply voltage out '
        'of VNW_Diag_Low_OFF to VNW_Diag_High_OFF), ACU should not qualify the '
        'CAN_BUS_OFF_FAULT. Whenever BUS OFF condition is removed, then the CAN communication '
        'should become normal.'
    )
    automation = 'Semi-automatic (operator creates and removes the bus-off)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create under-voltage condition')
        PS.SetVoltage(CANC_UNDERVOLTAGE_TEST_VOLTAGE)
        voltage_time_ms = faultTimeMeasurement(f"{Under_Voltage} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]}")
        RESULT.LogAction('Time until the voltage DTC is active (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      Under_Voltage, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create a bus-off longer than the fast recovery time, then remove it')
        busoff_text = (f"Create a bus-off on both buses with the CAN stress tool for "
                       f"{BUSOFF_FAST_RECOVERY_TIME_MS + BUSOFF_SLOW_RECOVERY_TIME_MS} ms, then remove it.")
        RESULT.InsertComment("OPERATOR ACTION: " + busoff_text)
        print("OPERATOR ACTION: " + busoff_text)
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        Wait(busoff_settle_ms)
        Read_DTC(
            'No bus-off DTC qualified during the abnormal voltage',
            " ".join([Read_DTC_Resp_CANC,
                      Under_Voltage, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        voltage_time_ms = faultTimeMeasurement(f"{Under_Voltage} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]}")
        RESULT.LogAction('Time until the voltage DTC is healed (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      Under_Voltage, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Clear DTC')
        Clear_DTC_Info()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        Read_DTC('No DTC', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Create over-voltage condition')
        PS.SetVoltage(CANC_OVERVOLTAGE_TEST_VOLTAGE)
        voltage_time_ms = faultTimeMeasurement(f"{Over_Voltage} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]}")
        RESULT.LogAction('Time until the voltage DTC is active (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      Over_Voltage, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Create a bus-off longer than the fast recovery time, then remove it')
        busoff_text = (f"Create a bus-off on both buses with the CAN stress tool for "
                       f"{BUSOFF_FAST_RECOVERY_TIME_MS + BUSOFF_SLOW_RECOVERY_TIME_MS} ms, then remove it.")
        RESULT.InsertComment("OPERATOR ACTION: " + busoff_text)
        print("OPERATOR ACTION: " + busoff_text)
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        Wait(busoff_settle_ms)
        Read_DTC(
            'No bus-off DTC qualified during the abnormal voltage',
            " ".join([Read_DTC_Resp_CANC,
                      Over_Voltage, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 8: Restore the supply voltage')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        voltage_time_ms = faultTimeMeasurement(f"{Over_Voltage} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]}")
        RESULT.LogAction('Time until the voltage DTC is healed (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      Over_Voltage, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
            PS.SetVoltage(NOMINAL_VOLTAGE)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
