# Author: Kris
#
# Test case  : CANC_FR_ZONE_TestCase_24 (Codebeamer ID 36766236)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify increment, rollover, and reset behavior of alive counter signal
#              FR_ZONE3_COUNTER in FR_ZONE3_100.
# Automation : Automatic
# Note       : The alive counter is the one the bench transmits; the script checks that it runs,
#              rolls over and restarts in the frames on the bus and that the ECU reports no
#              message content failure throughout.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_COUNTER_SAMPLE_ROLLOVERS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '36766236'
    tc_name = 'CANC_FR_ZONE_TestCase_24'
    tc_desc = (
        'Verify increment, rollover, and reset behavior of alive counter signal '
        'FR_ZONE3_COUNTER in FR_ZONE3_100.'
    )
    automation = 'Automatic'

    counter_key = 'FR_ZONE3_COUNTER'
    counter_def = MAH_CAN_SIGNAL_DEFS[counter_key]
    frame = counter_def['frame']
    bus = counter_def['bus']
    period_ms = counter_def['periodicity']
    counter_bits = counter_def['bit_length']
    counter_start_bit = CAN_SIGNAL_START_BIT[counter_key]
    counter_window_ms = (CANC_COUNTER_SAMPLE_ROLLOVERS * (1 << counter_bits) + 4) * period_ms
    restart_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * period_ms

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([counter_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(bus, frame)
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Observe FR_ZONE3_COUNTER over consecutive messages until it rolls over')
        counter_ids = [counter_def['frame_ID']]
        counter_file = os.path.splitext(log_path)[0] + '_alive_counter.txt'
        counter_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_counter', filepath=counter_file,
            listOption=counter_ids, channel_names=[bus])
        Wait(counter_window_ms)
        CAN.StopLoggingToFile(counter_logger)
        counter_frames = []
        if os.path.isfile(counter_file):
            with open(counter_file, encoding='utf-8', errors='replace') as counter_log:
                counter_fields = [line.split(',', 2) for line in counter_log if ' id=' in line and line.count(',') >= 2]
            counter_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in counter_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(counter_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        counter_frames = [frame_data for frame_data in counter_frames if frame_data.id in counter_ids]
        counters = [extract_counter(frame_data.payload, counter_start_bit, counter_bits) for frame_data in counter_frames]
        counter_verdict = validate_counter(counters, counter_bits)
        RESULT.InterpretEqualResultRange(f"{frame} frames captured", len(counters), (1 << counter_bits) + 1, float('inf'))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} increments by one from frame to frame",
                                    str(counter_verdict['errors'][:10]), "[]")
        RESULT.InterpretEqualResultRange(f"{counter_def['signal']} rollovers", counter_verdict['rollovers'], 1, float('inf'))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} range",
                                    f"{min(counters, default=None)}..{max(counters, default=None)}",
                                    f"{counter_def['MIN']}..{counter_def['MAX']}")
        Read_DTC('No message content failure while the counter runs and rolls over', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Cycle IGN and observe FR_ZONE3_COUNTER after transmission restarts')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        restart_ids = [counter_def['frame_ID']]
        restart_file = os.path.splitext(log_path)[0] + '_alive_counter_restart.txt'
        restart_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_alive_counter_restart', filepath=restart_file,
            listOption=restart_ids, channel_names=[bus])
        CAN.ReloadDefaultPeriodicFrame(bus, frame)
        Wait(restart_window_ms)
        CAN.StopLoggingToFile(restart_logger)
        restart_frames = []
        if os.path.isfile(restart_file):
            with open(restart_file, encoding='utf-8', errors='replace') as restart_log:
                restart_fields = [line.split(',', 2) for line in restart_log if ' id=' in line and line.count(',') >= 2]
            restart_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in restart_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(restart_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        restart_frames = [frame_data for frame_data in restart_frames if frame_data.id in restart_ids]
        restart_counters = [extract_counter(frame_data.payload, counter_start_bit, counter_bits)
                            for frame_data in restart_frames]
        restart_errors = validate_counter(restart_counters, counter_bits)['errors']
        RESULT.LogAction(f"{counter_def['signal']} after the restart", str(restart_counters[:20]))
        # Either the capture opens on the reset value, or the one break in it is the
        # reset. The bench increments the counter before it sends a reloaded frame, so
        # the first value on the bus is MIN + 1 (2026-10-15 logs: EPS1_FD_10, HPCAd_1_10
        # and FR_ZONE2_100 all restarted at 1).
        counter_restart_values = [counter_def['MIN'], counter_def['MIN'] + 1]
        counter_reset = ((not restart_errors and restart_counters[:1] and restart_counters[0] in counter_restart_values)
                         or (len(restart_errors) == 1 and restart_errors[0][2] in counter_restart_values))
        RESULT.InterpretEqualResult(f"{counter_def['signal']} restarts from {counter_def['MIN']} "
                                    f"(first frame after the reload {counter_def['MIN']} or {counter_def['MIN'] + 1})",
                                    bool(counter_reset), True)
        Read_DTC('No message content failure after the restart', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame(bus, frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
