# Author: Kris
#
# Test case  : CANC_13C_TestCase_133 (Codebeamer ID 36767372)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify IMU signal behavior across OPS states
# Automation : Automatic (ECU/OPS states approximated by supply transitions)
# Note       : Standby, INIT and the OPS states cannot be commanded individually; the script
#              steps the supply (off, power-up with proveout and run, IGN OFF housekeeping,
#              power down) and checks the IMU values wherever SRS1_FD_10 is sent.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_LAMP_PROVEOUT_OFF_MS,
    CANC_LAMP_PROVEOUT_ON_MS,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_NM_WAKEUP_FRAME,
    CAN_PKE_SLEEP_VALUE,
    CAN_PKE_WAKEUP_SIGNAL_KEY,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    CAN_WAKEUP_BUS_SLEEP_WAIT_MS,
    MAH_CAN_SIGNAL_DEFS,
    NM_IGN_ON_STARTUP_DELAY_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '36767372'
    tc_name = 'CANC_13C_TestCase_133'
    tc_desc = (
        'Verify IMU signal behavior across OPS states'
    )
    automation = 'Automatic (ECU/OPS states approximated by supply transitions)'

    pke_def = MAH_CAN_SIGNAL_DEFS[CAN_PKE_WAKEUP_SIGNAL_KEY]
    nm_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == CAN_NM_WAKEUP_FRAME)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(pke_def['bus'], pke_def['frame'])
        CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
        CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: ECU off / idle - no IMU signal')
        PS.BATT_OFF()
        PS.IGN_OFF()
        presence3_ids = [fd_id]
        presence3_file = os.path.splitext(log_path)[0] + '_ecu_off.txt'
        presence3_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_ecu_off', filepath=presence3_file,
            listOption=presence3_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence3_logger)
        presence3_frames = []
        if os.path.isfile(presence3_file):
            with open(presence3_file, encoding='utf-8', errors='replace') as presence3_log:
                presence3_fields = [line.split(',', 2) for line in presence3_log if ' id=' in line and line.count(',') >= 2]
            presence3_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence3_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence3_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence3_frames = [frame_data for frame_data in presence3_frames if frame_data.id in presence3_ids]
        presence3_fd_count = sum(1 for frame_data in presence3_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResult(
            f"{fd_frame} is not transmitted (frames in the window)",
            presence3_fd_count, 0)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Power up: initialisation, proveout and run - IMU values valid')
        startup_ids = [fd_id]
        startup_file = os.path.splitext(log_path)[0] + '_imu_startup.txt'
        startup_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_startup', filepath=startup_file,
            listOption=startup_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        PS.BATT_ON()
        PS.IGN_ON()
        Wait(NM_IGN_ON_STARTUP_DELAY_MS + CANC_LAMP_PROVEOUT_ON_MS + CANC_LAMP_PROVEOUT_OFF_MS)
        CAN.StopLoggingToFile(startup_logger)
        startup_frames = []
        if os.path.isfile(startup_file):
            with open(startup_file, encoding='utf-8', errors='replace') as startup_log:
                startup_fields = [line.split(',', 2) for line in startup_log if ' id=' in line and line.count(',') >= 2]
            startup_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in startup_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(startup_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        startup_frames = [frame_data for frame_data in startup_frames if frame_data.id in startup_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in startup_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} valid (not the invalid value) from start-up through proveout and run",
                                        bool(imu_raw) and all(value != imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Housekeeping (IGN OFF while SRS1_FD_10 is still sent) - IMU values valid')
        housekeeping_ids = [fd_id]
        housekeeping_file = os.path.splitext(log_path)[0] + '_imu_housekeeping.txt'
        housekeeping_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_imu_housekeeping', filepath=housekeeping_file,
            listOption=housekeeping_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(housekeeping_logger)
        housekeeping_frames = []
        if os.path.isfile(housekeeping_file):
            with open(housekeeping_file, encoding='utf-8', errors='replace') as housekeeping_log:
                housekeeping_fields = [line.split(',', 2) for line in housekeeping_log if ' id=' in line and line.count(',') >= 2]
            housekeeping_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in housekeeping_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(housekeeping_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        housekeeping_frames = [frame_data for frame_data in housekeeping_frames if frame_data.id in housekeeping_ids]
        for imu_key in ['LATTERAL_ACCEL', 'LONG_ACCEL', 'YAW_RATE', 'X_AXIS_ANGULAR', 'Y_AXIS_ANGULAR', 'Z_AXIS_ACCEL']:
            imu_def = MAH_CAN_SIGNAL_DEFS[imu_key]
            imu_raw = [extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[imu_key], imu_def['bit_length'])
                       for frame_data in housekeeping_frames if frame_data.id == fd_id]
            RESULT.InterpretEqualResult(f"{imu_key} valid while SRS1_FD_10 is sent after IGN OFF",
                                        bool(imu_raw) and all(value != imu_def['State_Values']['Signal Invalid']
                                                              for value in imu_raw), True)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: IGN OFF until power down - no IMU signal')
        PS.IGN_OFF()
        CAN.ChangeSignalValue(pke_def['bus'], pke_def['frame'], pke_def['signal'], str(CAN_PKE_SLEEP_VALUE))
        CAN.PeriodicDisableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
        Wait(CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
        presence6_ids = [fd_id, hs_id]
        presence6_file = os.path.splitext(log_path)[0] + '_bus_sleep.txt'
        presence6_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_bus_sleep', filepath=presence6_file,
            listOption=presence6_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence6_logger)
        presence6_frames = []
        if os.path.isfile(presence6_file):
            with open(presence6_file, encoding='utf-8', errors='replace') as presence6_log:
                presence6_fields = [line.split(',', 2) for line in presence6_log if ' id=' in line and line.count(',') >= 2]
            presence6_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence6_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence6_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence6_frames = [frame_data for frame_data in presence6_frames if frame_data.id in presence6_ids]
        presence6_fd_count = sum(1 for frame_data in presence6_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResult(
            f"{fd_frame} is not transmitted (frames in the window)",
            presence6_fd_count, 0)
        presence6_hs_count = sum(1 for frame_data in presence6_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence6_hs_count, 0)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(nm_def['bus'], CAN_NM_WAKEUP_FRAME)
            CAN.ReloadDefaultPeriodicFrame(pke_def['bus'], pke_def['frame'])
            PS.IGN_ON()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
