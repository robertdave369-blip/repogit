# Author: Kris
#
# Test case  : CANC_13C_TestCase_30 (Codebeamer ID 35739883)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : To Check signal Values of INDC_SRS(Warning lamp by DID 044B) Signal in ID 13C &
#              2C0 Msg
# Automation : Automatic
# Note       : The ECU compares the received VIN with DID F190 only while it starts up
#              (agent_sc3.md section 2.9), so the wrong VIN is put on the bus before an IGN
#              cycle and the project VIN back before the next one; the mismatch DTC is then
#              expected historic, not healed in the same cycle. On 2026-10-15 a VIN changed in a
#              running cycle gave no D30600 within 10 s.
# Note       : 'Any node absent DTC' and 'message content failure' are created on the first key
#              frame of KEY_TX_FRAMES (frame stopped / CRC no longer updated). Each lamp check
#              waits for the DTC that drives it, and every lamp read after an IGN cycle waits
#              for the end of the start-up: the proveout keeps the lamp ON for 6 s and OFF for 1
#              s whatever the faults (2026-10-15).

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_LOOP_FAULT_SQUIB,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_WARNING_LAMP_DID,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_RX_MESSAGE_CONFIG,
    KEY_TX_FRAMES,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
    get_message_content_failure_dtcs,
    get_message_content_failure_signals,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.squibs_config import (
    DTC_Squib_FaultCode,
    SquibNumber,
    Squib_FaultTypeCode,
    Squib_Fault_Description,
    squib_fault_time,
)


def run_test():
    tc_id = '35739883'
    tc_name = 'CANC_13C_TestCase_30'
    tc_desc = (
        'To Check signal Values of INDC_SRS(Warning lamp by DID 044B) Signal in ID 13C & 2C0 '
        'Msg'
    )
    automation = 'Automatic'

    lamp_on = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp ON']
    lamp_off = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp OFF/Default']
    loop_device = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}"
    loop_dtc = DTC_Squib_FaultCode[CANC_LOOP_FAULT_SQUIB] + " " + Squib_FaultTypeCode['Open']
    loop_qualify_ms = int(squib_fault_time['Qualification_Time'] * (1 + squib_fault_time['Qualification_Tolerance'] / 100))
    loop_recover_ms = int(squib_fault_time['Dequalification_Time'] * (1 + squib_fault_time['Dequalification_Tolerance'] / 100))
    vin_period_ms = MAH_CAN_SIGNAL_DEFS['VIN_NUMBER']['periodicity']
    absent_frame = next(iter(KEY_TX_FRAMES))
    absent_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == absent_frame)
    absent_bus = absent_def['bus']
    absent_dtc = resolve_dtc_for_event('frame_disabled', absent_frame)
    content_frame = next(iter(KEY_TX_FRAMES))
    content_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == content_frame)
    content_bus = content_def['bus']
    content_signal = next((s for s in get_message_content_failure_signals(content_frame) if 'CRC' in s.upper()), None)
    content_signal_name = MAH_CAN_SIGNAL_DEFS.get(content_signal, {}).get('signal')
    content_dtc = get_message_content_failure_dtcs(content_frame).get(content_signal)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([absent_def, content_def], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'frame-loss DTC of {absent_frame}', absent_dtc),
            (f'message content failure (CRC) DTC of {content_frame}', content_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(absent_bus, absent_frame)
        CAN.ReloadDefaultPeriodicFrame(absent_bus, absent_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Warning lamp OFF with no fault')
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_off), ('SRS1_20_INDC_SRS', lamp_off)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_off:02X}".upper())
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Create an open fault on Loop0')
        SQUIB.SendRequest(loop_device, Squib_Fault_Description['Open'])
        Wait(loop_qualify_ms)
        Read_DTC(
            'Loop open DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      loop_dtc, DTC_status['DTC_active']]),
            Read_DTC_Req_CANC)
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_on), ('SRS1_20_INDC_SRS', lamp_on)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_on:02X}".upper())
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Make the open fault historic')
        SQUIB.SendRequest(loop_device, Squib_Fault_Description['NoFault'])
        Wait(loop_recover_ms)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_off), ('SRS1_20_INDC_SRS', lamp_off)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_off:02X}".upper())
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Create a node-absent DTC - stop transmission of IEB1_FD_10')
        CAN.PeriodicDisableFrame(absent_bus, absent_frame)
        absent_time_ms = faultTimeMeasurement(f"{absent_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.LogAction('Time until the node-absent DTC is active (ms)', None if absent_time_ms is None else round(absent_time_ms))
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_off), ('SRS1_20_INDC_SRS', lamp_off)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_off:02X}".upper())
        aria_reports.close_group()
        aria_reports.add_group('Step 7: Make the node-absent fault historic')
        CAN.PeriodicEnableFrame(absent_bus, absent_frame)
        CAN.ReloadDefaultPeriodicFrame(absent_bus, absent_frame)
        absent_time_ms = faultTimeMeasurement(f"{absent_dtc} {DTC_status['DTC_healed']}")
        RESULT.LogAction('Time until the node-absent DTC is healed (ms)', None if absent_time_ms is None else round(absent_time_ms))
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        aria_reports.close_group()
        aria_reports.add_group('Step 8: Create a message content failure - inject CRC error on IEB1_FD_10 (CRC no longer updated)')
        CAN.DynamicDisableSignal(content_bus, content_frame, content_signal_name)
        content_time_ms = faultTimeMeasurement(f"{content_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.LogAction('Time until the message content failure is active (ms)', None if content_time_ms is None else round(content_time_ms))
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_off), ('SRS1_20_INDC_SRS', lamp_off)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_off:02X}".upper())
        CAN.DynamicEnableSignal(content_bus, content_frame, content_signal_name)
        content_time_ms = faultTimeMeasurement(f"{content_dtc} {DTC_status['DTC_healed']}")
        RESULT.LogAction('Time until the message content failure is healed (ms)', None if content_time_ms is None else round(content_time_ms))
        aria_reports.close_group()
        aria_reports.add_group('Step 9: Create a VIN mismatch (wrong VIN at start-up)')
        simulate_vin_can_signals_fd(VIN_STRATEGY_OPTIONS['wrong_vin_for_comparison'])
        Wait(2 * vin_period_ms)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        vin_time_ms = faultTimeMeasurement(f"{Vin_DTC_Code} {DTC_status['DTC_active']}")
        RESULT.LogAction('Time after the start-up until the VIN mismatch DTC is active (ms)', None if vin_time_ms is None else round(vin_time_ms))
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_on), ('SRS1_20_INDC_SRS', lamp_on)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_on:02X}".upper())
        simulate_vin_can_signals_fd(VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY])
        Wait(2 * vin_period_ms)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        vin_time_ms = faultTimeMeasurement(f"{Vin_DTC_Code} {DTC_status['DTC_historic']}")
        RESULT.LogAction('Time after the start-up until the VIN mismatch DTC is historic (ms)', None if vin_time_ms is None else round(vin_time_ms))
        aria_reports.close_group()
        aria_reports.add_group('Step 10: Create a variant code error')
        manage_variant_code('VARIANT_STATUS', 'disable', project=PROJECT_NAME, base_from_project_default=True)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        check_started = time.monotonic()
        for check_key, check_expected in [('INDC_SRS', lamp_on), ('SRS1_20_INDC_SRS', lamp_on)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        lamp_did_read = str(CAN.SendDiagByValues(f"{READ_SID} {CANC_WARNING_LAMP_DID}"))
        RESULT.InterpretEqualResult("Warning lamp status by DID 04 4B", lamp_did_read.upper(),
                                    f"0x{int(READ_SID, 16) + 0x40:02X} {CANC_WARNING_LAMP_DID} 0x{lamp_on:02X}".upper())
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            SQUIB.SendRequest(loop_device, Squib_Fault_Description['NoFault'])
            simulate_vin_can_signals_fd(VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY])
            CAN.DynamicEnableSignal(content_bus, content_frame, content_signal_name)
            CAN.PeriodicEnableFrame(absent_bus, absent_frame)
            CAN.ReloadDefaultPeriodicFrame(absent_bus, absent_frame)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
