"""Run the M310_M314_M110 CAN-C scripts that are not fully automatic.

Author: Kris

The 82 CAN-C scripts that are not fully automatic, grouped by what the bench needs.
Before each script that needs an operator the runner waits for Enter (s skips, q stops);
the scripts print each operator instruction while they run and wait a set time for it.
The plant-mode scripts change the ECU for good and run only after "yes". The blocked and
not-executable scripts run without a prompt: each reports what is missing and stops
before acting on the bench. The fully automatic scripts are in run_all_canc_automatic_scripts.py.

Groups, in the order they run:
    bus-off          17  Bus-off: short CAN-H to CAN-L, or hold a bus-off with the CAN stress tool, when the script says
    ecu-motion       14  ECU motion: move, tilt or shake the ECU when the script says
    ecu-fault         3  ECU faults no shared-library call creates: inject and remove them when the script says
    thermal           5  Thermal chamber: set the chamber when the script says and let the ECU soak
    partial           2  Partly automatic: no zone 3 current preset, the rest of the case runs
    approximated      2  Automatic, with the ECU/OPS states approximated by supply transitions
    bench-hardware   23  Need the ARIA SPI sensor card (crash curves) or the EVT sheets, both missing on the 2026-10-15 bench
    crash-curves      9  Blocked until the crash curves are delivered: each reports the missing curves and stops
    not-executable    3  Not executable (hard constraint): each reports what is missing and stops
    plant-mode        4  Plant mode, one run per software flash: the learned phase of life changes for good

    py -3.14 run_all_canc_non_automatic_scripts.py                            # every group, in order
    py -3.14 run_all_canc_non_automatic_scripts.py --group bus-off            # one group
    py -3.14 run_all_canc_non_automatic_scripts.py --only 13C                 # name contains 13C
    py -3.14 run_all_canc_non_automatic_scripts.py --start-from CAN_BUSOFF_5  # skip the ones before
    py -3.14 run_all_canc_non_automatic_scripts.py --list                     # show what would run

Each script runs in its own Python process and writes its own ARIA report under
test_results/M310_M314_M110/<date>/. The status shown for a script is the verdict apym
writes on the last line of that report (<!--PASSED--> or <!--FAILED-->); ERROR means the
script crashed or left no verdict. Results go to canc_non_automatic_results.json, rewritten
after every script so an interrupted run keeps what finished. Ctrl+C stops the run once
the current script has finished its own cleanup.

These scripts drive a bench. Run them only against a rig you are authorized to use.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
FRAMEWORK_ROOT = SCRIPT_DIR.parents[4]
REPORT_DIR = FRAMEWORK_ROOT / "test_results" / SCRIPT_DIR.parents[2].name
RESULTS_FILE = SCRIPT_DIR / "canc_non_automatic_results.json"

# Group: (prompt before each script, what the bench needs). Prompt "operator" waits
# for Enter, "confirm" wants "yes", "none" runs straight on.
GROUPS = {
    'bus-off': ('operator', 'Bus-off: short CAN-H to CAN-L, or hold a bus-off with the CAN stress tool, when the script says'),
    'ecu-motion': ('operator', 'ECU motion: move, tilt or shake the ECU when the script says'),
    'ecu-fault': ('operator', 'ECU faults no shared-library call creates: inject and remove them when the script says'),
    'thermal': ('operator', 'Thermal chamber: set the chamber when the script says and let the ECU soak'),
    'partial': ('none', 'Partly automatic: no zone 3 current preset, the rest of the case runs'),
    'approximated': ('none', 'Automatic, with the ECU/OPS states approximated by supply transitions'),
    'bench-hardware': ('none', 'Need the ARIA SPI sensor card (crash curves) or the EVT sheets, both missing on the 2026-10-15 bench'),
    'crash-curves': ('none', 'Blocked until the crash curves are delivered: each reports the missing curves and stops'),
    'not-executable': ('none', 'Not executable (hard constraint): each reports what is missing and stops'),
    'plant-mode': ('confirm', 'Plant mode, one run per software flash: the learned phase of life changes for good'),
}

# Comment out a line to skip that script.
SCRIPT_FILES = [
    # bus-off: Bus-off: short CAN-H to CAN-L, or hold a bus-off with the CAN stress tool, when the script says (17)
    "CAN_BUSOFF_1.py",
    "CAN_BUSOFF_2.py",
    "CAN_BUSOFF_3.py",
    "CAN_BUSOFF_4.py",
    "CAN_BUSOFF_5.py",
    "CAN_BUSOFF_6.py",
    "CAN_BUSOFF_7.py",
    "CAN_BUSOFF_8.py",
    "CAN_BUSOFF_9.py",
    "CAN_BUSOFF_10.py",
    "CAN_BUSOFF_11.py",
    "CAN_BUSOFF_12.py",
    "CAN_BUSOFF_13.py",
    "CAN_BUSOFF_14.py",
    "CAN_BUSOFF_15.py",
    "CAN_BUSOFF_16.py",
    "CANC_2C0_TestCase_21.py",
    # ecu-motion: ECU motion: move, tilt or shake the ECU when the script says (14)
    "CANC_13C_TestCase_1.py",
    "CANC_13C_TestCase_2.py",
    "CANC_13C_TestCase_3.py",
    "CANC_13C_TestCase_4.py",
    "CANC_13C_TestCase_5.py",
    "CANC_13C_TestCase_6.py",
    "CANC_13C_TestCase_7.py",
    "CANC_13C_TestCase_8.py",
    "CANC_13C_TestCase_9.py",
    "CANC_13C_TestCase_10.py",
    "CANC_13C_TestCase_11.py",
    "CANC_13C_TestCase_12.py",
    "CANC_13C_TestCase_21.py",
    "CANC_13C_TestCase_135.py",
    # ecu-fault: ECU faults no shared-library call creates: inject and remove them when the script says (3)
    "CANC_13C_TestCase_131.py",
    "CANC_13C_TestCase_134.py",
    "CANC_2C0_TestCase_31.py",
    # thermal: Thermal chamber: set the chamber when the script says and let the ECU soak (5)
    "CANC_13C_TestCase_23.py",
    "CANC_13C_TestCase_24.py",
    "CANC_13C_TestCase_25.py",
    "CANC_13C_TestCase_26.py",
    "CANC_13C_TestCase_27.py",
    # partial: Partly automatic: no zone 3 current preset, the rest of the case runs (2)
    "CANC_13C_TestCase_91.py",
    "CANC_13C_TestCase_92.py",
    # approximated: Automatic, with the ECU/OPS states approximated by supply transitions (2)
    "CANC_13C_TestCase_132.py",
    "CANC_13C_TestCase_133.py",
    # bench-hardware: Need the ARIA SPI sensor card (crash curves) or the EVT sheets, both missing on the 2026-10-15 bench (23)
    "CANC_13C_TestCase_34.py",
    "CANC_13C_TestCase_35.py",
    "CANC_13C_TestCase_36.py",
    "CANC_13C_TestCase_37.py",
    "CANC_13C_TestCase_38.py",
    "CANC_13C_TestCase_39.py",
    "CANC_13C_TestCase_40.py",
    "CANC_13C_TestCase_41.py",
    "CANC_13C_TestCase_42.py",
    "CANC_13C_TestCase_43.py",
    "CANC_13C_TestCase_46.py",
    "CANC_13C_TestCase_53.py",
    "CANC_13C_TestCase_94.py",
    "CANC_13C_TestCase_95.py",
    "CANC_13C_TestCase_96.py",
    "CANC_13C_TestCase_97.py",
    "CANC_13C_TestCase_98.py",
    "CANC_2C0_TestCase_07.py",
    "CANC_2C0_TestCase_08.py",
    "CANC_2C0_TestCase_09.py",
    "CANC_2C0_TestCase_10.py",
    "CANC_2C0_TestCase_15.py",
    "CANC_2C0_TestCase_28.py",
    # crash-curves: Blocked until the crash curves are delivered: each reports the missing curves and stops (9)
    "CANC_13C_TestCase_20.py",
    "CANC_13C_TestCase_22.py",
    "CANC_13C_TestCase_59.py",
    "CANC_13C_TestCase_60.py",
    "CANC_13C_TestCase_61.py",
    "CANC_13C_TestCase_93.py",
    "CANC_13C_TestCase_99.py",
    "CANC_2C0_TestCase_11.py",
    "CANC_2C0_TestCase_12.py",
    # not-executable: Not executable (hard constraint): each reports what is missing and stops (3)
    "CANC_VCU_TestCase55.py",
    "CANC_VCU_TestCase58.py",
    "CANC_VCU_TestCase59.py",
    # plant-mode: Plant mode, one run per software flash: the learned phase of life changes for good (4)
    "CANC_13C_TestCase_29.py",
    "CANC_13C_TestCase_45.py",
    "CANC_2C0_TestCase_02.py",
    "CANC_2C0_TestCase_30.py",
]

# Group, automation and objective of each script.
SCRIPT_INFO = {
    "CAN_BUSOFF_1.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages diagnosis when Bus OFF is present.(HS CAN & FD CAN BOTH ARE BU...'),
    "CAN_BUSOFF_2.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN...'),
    "CAN_BUSOFF_3.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages diagnosis when Bus OFF is present.(HS CAN is notBUS OFF & FD C...'),
    "CAN_BUSOFF_4.py": (
        'bus-off', 'Semi-automatic (operator holds the bus-off; recovery timing evaluated from the saved log)',
        'To check the behaviour of ACU during busoff condition'),
    "CAN_BUSOFF_5.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        'If Bus off happens under conditions Under voltage or Over voltage(supply voltage out of VNW_Diag_Low_OFF to VNW_Diag_High_OFF), ACU should not qual...'),
    "CAN_BUSOFF_6.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages diagnosis when Bus OFF is present.(HS CAN & FD CAN BOTH ARE BU...'),
    "CAN_BUSOFF_7.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages diagnosis when Bus OFF is present.(HS CAN & FD CAN BOTH ARE BU...'),
    "CAN_BUSOFF_8.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is...'),
    "CAN_BUSOFF_9.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is...'),
    "CAN_BUSOFF_10.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is...'),
    "CAN_BUSOFF_11.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is...'),
    "CAN_BUSOFF_12.py": (
        'bus-off', 'Semi-automatic (operator holds the bus-off; recovery timing evaluated from the saved log)',
        'To check the behaviour of ACU during busoff condition'),
    "CAN_BUSOFF_13.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test no CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN...'),
    "CAN_BUSOFF_14.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is...'),
    "CAN_BUSOFF_15.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is...'),
    "CAN_BUSOFF_16.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        'To check the Timeout DTC when CANFD channel is in Bus Off DTC is active.'),
    "CANC_2C0_TestCase_21.py": (
        'bus-off', 'Semi-automatic (operator creates and removes the bus-off)',
        'To Verify Alive counter starts from 0 when Bus off is performed.'),
    "CANC_13C_TestCase_1.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check signal Values of LATTERAL_ACCEL Signal in ID 13C'),
    "CANC_13C_TestCase_2.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check Signal Values of LONG_ACCEL Signal in ID 13C'),
    "CANC_13C_TestCase_3.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check Signal Values of YAW_RATE Signal in ID 13C'),
    "CANC_13C_TestCase_4.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To check signal Value of X_AXIS_ANGULAR Signal in ID 13C'),
    "CANC_13C_TestCase_5.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To check signal Value of Y_AXIS_ANGULAR Signal in ID 13C'),
    "CANC_13C_TestCase_6.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check Signal Value of Z_AXIS_ACCEL Signal In ID 13C'),
    "CANC_13C_TestCase_7.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check signal Values of LATTERAL_ACCEL Signal in ID 13C'),
    "CANC_13C_TestCase_8.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check Signal Values of LONG_ACCEL Signal in ID 13C'),
    "CANC_13C_TestCase_9.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check Signal Values of YAW_RATE Signal in ID 13C'),
    "CANC_13C_TestCase_10.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To check signal Value of X_AXIS_ANGULAR Signal in ID 13C'),
    "CANC_13C_TestCase_11.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To check signal Value of Y_AXIS_ANGULAR Signal in ID 13C'),
    "CANC_13C_TestCase_12.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'To Check Signal Value of Z_AXIS_ACCEL Signal In ID 13C'),
    "CANC_13C_TestCase_21.py": (
        'ecu-motion', 'Semi-automatic (operator shakes the ECU)',
        'To Check Signal Values of Near_Crash Signal in ID 13C in IGN On condition'),
    "CANC_13C_TestCase_135.py": (
        'ecu-motion', 'Semi-automatic (operator moves the ECU)',
        'Verify IMU initialization and calibration behavior'),
    "CANC_13C_TestCase_131.py": (
        'ecu-fault', 'Semi-automatic (no IMU fault-injection method or EVT exists for the Panasonic IMU)',
        'Verify IMU faulty condition output value'),
    "CANC_13C_TestCase_134.py": (
        'ecu-fault', 'Semi-automatic (operator forces low-power mode)',
        'Verify IMU signal behavior in other scenarios'),
    "CANC_2C0_TestCase_31.py": (
        'ecu-fault', 'Semi-automatic (no shared-library call injects an internal MCAL fault)',
        'To Check Signal Value of SRS_OPERATION_MODE Signal in 2C0 Msg when System critical fault is active'),
    "CANC_13C_TestCase_23.py": (
        'thermal', 'Manual environment (thermal chamber), automatic check',
        'To Check Signal values of IMU TEMP Signal in 13C'),
    "CANC_13C_TestCase_24.py": (
        'thermal', 'Manual environment (thermal chamber), automatic check',
        'To Check Signal values of IMU TEMP Signal in 13C'),
    "CANC_13C_TestCase_25.py": (
        'thermal', 'Manual environment (thermal chamber), automatic check',
        'To Check Signal values of IMU TEMP Signal in 13C'),
    "CANC_13C_TestCase_26.py": (
        'thermal', 'Manual environment (thermal chamber), automatic check',
        'To Check Signal values of IMU TEMP Signal in 13C'),
    "CANC_13C_TestCase_27.py": (
        'thermal', 'Manual environment (thermal chamber), automatic check',
        'To Check Signal values of IMU TEMP Signal in 13C'),
    "CANC_13C_TestCase_91.py": (
        'partial', 'Partly automatic (zone 3 current not available)',
        'Verify front-right STPS zone'),
    "CANC_13C_TestCase_92.py": (
        'partial', 'Partly automatic (zone 3 current not available)',
        'Verify front-left STPS zone'),
    "CANC_13C_TestCase_132.py": (
        'approximated', 'Automatic (ECU/OPS states approximated by supply transitions)',
        'Verify IMU signal behavior across ECU states'),
    "CANC_13C_TestCase_133.py": (
        'approximated', 'Automatic (ECU/OPS states approximated by supply transitions)',
        'Verify IMU signal behavior across OPS states'),
    "CANC_13C_TestCase_34.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CrashLocation Signal in ID 13C & 2C0 Msg for front crash'),
    "CANC_13C_TestCase_35.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for right side crash crash'),
    "CANC_13C_TestCase_36.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for rear side crash crash'),
    "CANC_13C_TestCase_37.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for left side crash'),
    "CANC_13C_TestCase_38.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for Understrike crash'),
    "CANC_13C_TestCase_39.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CrashLocation Signal in ID 13C & 2C0 Msg for front crash'),
    "CANC_13C_TestCase_40.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for right side crash crash'),
    "CANC_13C_TestCase_41.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for rear side crash crash'),
    "CANC_13C_TestCase_42.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for left side crash'),
    "CANC_13C_TestCase_43.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_CRASH & CRASH_LOCATION Signal in ID 13C & 2C0 Msg for Understrike crash'),
    "CANC_13C_TestCase_46.py": (
        'bench-hardware', 'Automatic once the EVT sheets and the ARIA SPI sensor card are available (blocked until then)',
        'To Check Signal Values of SRS_Operation_Mode with GEN6XY sensor X-axis faulty then SRS_Operation_Mode is inactive'),
    "CANC_13C_TestCase_53.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check value of Even parity signal when Crash occurs'),
    "CANC_13C_TestCase_94.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during FRONT crash'),
    "CANC_13C_TestCase_95.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during LEFT crash'),
    "CANC_13C_TestCase_96.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during RIGHT crash'),
    "CANC_13C_TestCase_97.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during REAR crash'),
    "CANC_13C_TestCase_98.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during UNDERBODY crash'),
    "CANC_2C0_TestCase_07.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for front crash'),
    "CANC_2C0_TestCase_08.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for Right crash'),
    "CANC_2C0_TestCase_09.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for Left crash'),
    "CANC_2C0_TestCase_10.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for Rear crash'),
    "CANC_2C0_TestCase_15.py": (
        'bench-hardware', 'Automatic once the ARIA chassis has the SPI sensor card (crash curves are sent through it)',
        'To Check value of Even parity signal when Crash occurs'),
    "CANC_2C0_TestCase_28.py": (
        'bench-hardware', 'Automatic once the EVT sheets and the ARIA SPI sensor card are available (blocked until then)',
        'To Check Signal Value of SRS_OPERATION_MODE Signal in 2C0 Msg when HIGH G sensor faults are active'),
    "CANC_13C_TestCase_20.py": (
        'crash-curves', 'Automatic once the near-crash curves are delivered (blocked until then)',
        'To Check Signal Values of Near_Crash Signal in ID 13C in IGN On condition'),
    "CANC_13C_TestCase_22.py": (
        'crash-curves', 'Automatic once the near-crash curves are delivered (blocked until then)',
        'To Check Signal Values of Near_Crash Signal in ID 13C in CAN WAKE UP'),
    "CANC_13C_TestCase_59.py": (
        'crash-curves', 'Automatic once the rollover crash curves are delivered (blocked until then)',
        'Verify rollover coding of STS_CRASH and CRASH_LOCATION using SRS1_FD_10 and SRS1_20 databases.'),
    "CANC_13C_TestCase_60.py": (
        'crash-curves', 'Automatic once the PT-only crash curves are delivered (blocked until then)',
        'Verify PT-only front deployment and near crash does not update STS_CRASH or CRASH_LOCATION crash.'),
    "CANC_13C_TestCase_61.py": (
        'crash-curves', 'Automatic once the multi-event crash curves are delivered (blocked until then)',
        'Verify CRASH_LOCATION multi-event priority with DBC coding.'),
    "CANC_13C_TestCase_93.py": (
        'crash-curves', 'Automatic once the multi-event crash curves are delivered (blocked until then)',
        'Verify_STS_FIRST_CRASH_ROLL'),
    "CANC_13C_TestCase_99.py": (
        'crash-curves', 'Automatic once the rollover crash curves are delivered (blocked until then)',
        'Verify SRS_DEPLOYEMENT_STS and SRS_DELTA_V during ROLLOVER crash'),
    "CANC_2C0_TestCase_11.py": (
        'crash-curves', 'Automatic once the multi-event crash curves are delivered (blocked until then)',
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signals shall transmit the data for the newly detected crash event in the next...'),
    "CANC_2C0_TestCase_12.py": (
        'crash-curves', 'Automatic once the near-crash curves are delivered (blocked until then)',
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for Near crash'),
    "CANC_VCU_TestCase55.py": (
        'not-executable', 'Not executable (hard constraint)',
        'Verify signal content failure detection and recovery for VCU_MCU_MOTOR_SPEED in VCU11_FD_10.'),
    "CANC_VCU_TestCase58.py": (
        'not-executable', 'Not executable (hard constraint)',
        'Verify that Message Content Failure (DLC) overrides Signal Content Failure (VCU_MCU_MOTOR_SPEED) according to the fault priority model for VCU11_FD...'),
    "CANC_VCU_TestCase59.py": (
        'not-executable', 'Not executable (hard constraint)',
        'Verify that Node Absent (VCU11_FD_10) overrides Signal Content Failure (VCU_MCU_MOTOR_SPEED) according to the fault priority model for VCU11_FD_10.'),
    "CANC_13C_TestCase_29.py": (
        'plant-mode', 'Automatic (irreversible: changes the learned phase of life)',
        'To Check signal Values of INDC_SRS(Warning lamp in plantmode) Signal in ID 13C & 2C0 Msg'),
    "CANC_13C_TestCase_45.py": (
        'plant-mode', 'Automatic (irreversible: changes the learned phase of life)',
        'To Check Signal Values of SRS_Operation_Mode when ECU in Plant Mode DTC is Active then SRS_Operation_Mode is inactive'),
    "CANC_2C0_TestCase_02.py": (
        'plant-mode', 'Automatic (irreversible: changes the learned phase of life)',
        'To Check signal Values of INDC_SRS(Warning lamp in plantmode) Signal 2C0 Msg'),
    "CANC_2C0_TestCase_30.py": (
        'plant-mode', 'Automatic (irreversible: changes the learned phase of life)',
        'To Check Signal Value of SRS_OPERATION_MODE Signal in 2C0 Msg when Plant mode DTC is active'),
}


def finish_selection(arguments, selected, missing):
    if missing:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for name in missing:
            print("- " + name)
        print()
    if arguments.start_from:
        names = [path.stem for path in selected]
        start = arguments.start_from.removesuffix(".py")
        if start not in names:
            print("--start-from " + arguments.start_from + " is not one of the selected scripts.")
            return None
        selected = selected[names.index(start):]
    return selected


def build_environment():
    env = os.environ.copy()
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = str(FRAMEWORK_ROOT.parent) + (os.pathsep + existing if existing else "")
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def read_report(path, started):
    """The report this run of the script wrote, the verdict apym put on its last
    line and the passed/total step count beside it."""
    report_name = re.compile(re.escape(path.stem) + r"_\d{8}_\d{6}\.html")
    reports = [report for report in REPORT_DIR.glob("*/" + path.stem + "_*.html")
               if report_name.fullmatch(report.name) and report.stat().st_mtime >= started - 2]
    if not reports:
        return None, None, None
    report = max(reports, key=os.path.getmtime)
    with open(report, "rb") as handle:
        handle.seek(0, os.SEEK_END)
        handle.seek(max(0, handle.tell() - 512))
        tail = handle.read().decode("utf-8", "replace")
    verdict = re.search(r"<!--(PASSED|FAILED)-->\s*$", tail)
    steps = re.search(r'id="successStepsCount">(\d+/\d+)<', tail)
    return report, verdict.group(1) if verdict else None, steps.group(1) if steps else None


def run_script(path, env):
    """Run one script in its own Python process and show its output as it comes,
    so an operator instruction appears the moment the script prints it."""
    started = time.time()
    process = subprocess.Popen([sys.executable, "-u", str(path)], cwd=str(SCRIPT_DIR), env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               encoding="utf-8", errors="replace")
    output, interrupted = [], False
    while True:
        try:
            for line in process.stdout:
                print(line, end="", flush=True)
                output.append(line)
            exit_code = process.wait()
            break
        except KeyboardInterrupt:
            # The script gets the same Ctrl+C and runs its own cleanup; keep reading
            # until it ends so that cleanup is not cut off.
            interrupted = True
            print("\nCtrl+C: stopping once " + path.name + " has cleaned up.", flush=True)
    report, verdict, steps = read_report(path, started)
    if interrupted:
        status = "INTERRUPTED"
    elif verdict and exit_code == 0:
        status = verdict
    else:
        status = "ERROR"
    result = {"status": status, "exit_code": exit_code, "steps_passed": steps,
              "minutes": round((time.time() - started) / 60, 1), "report": str(report) if report else None}
    if status != "PASSED":
        result["output_tail"] = [line.rstrip("\n") for line in output[-40:]]
    print(status + ": " + path.name + " (" + (steps + " steps passed" if steps else "no verdict") + ", "
          + str(result["minutes"]) + " min)")
    if report:
        print("Report: " + str(report))
    return result


def save_results(run):
    run["finished"] = datetime.now().isoformat(timespec="seconds")
    RESULTS_FILE.write_text(json.dumps(run, indent=2), encoding="utf-8")


def print_summary(run):
    results = run["results"]
    counts = {}
    for result in results.values():
        counts[result["status"]] = counts.get(result["status"], 0) + 1
    print("=" * 100)
    print("Ran " + str(len(results)) + " script(s): "
          + (", ".join(str(count) + " " + status for status, count in sorted(counts.items())) or "none"))
    for name, result in results.items():
        if result["status"] != "PASSED":
            print("  " + result["status"].ljust(11) + " " + name
                  + ("  " + result["report"] if result.get("report") else ""))
    print("Results written to " + str(RESULTS_FILE))


def select_scripts(arguments):
    selected, missing = [], []
    for name in SCRIPT_FILES:
        if arguments.only and arguments.only.lower() not in name.lower():
            continue
        if arguments.group and SCRIPT_INFO[name][0] != arguments.group:
            continue
        path = SCRIPT_DIR / name
        if path.is_file():
            selected.append(path)
        else:
            missing.append(name)
    return finish_selection(arguments, selected, missing)


def ask(prompt):
    """Wait for the operator before a script that needs one: run, skip or stop."""
    if prompt == "operator":
        question = "Bench ready for this script? Enter = run, s = skip, q = stop: "
    elif prompt == "confirm":
        question = "This cannot be undone on this software flash. Type yes to run, s = skip, q = stop: "
    else:
        return "run"
    while True:
        try:
            answer = input(question).strip().lower()
        except EOFError:
            return "stop"
        if answer in ("s", "skip"):
            return "skip"
        if answer in ("q", "quit", "stop"):
            return "stop"
        if (prompt == "operator" and answer == "") or (prompt == "confirm" and answer == "yes"):
            return "run"


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--group", choices=list(GROUPS), help="run one group only")
    parser.add_argument("--only", help="run the scripts whose name contains this text")
    parser.add_argument("--start-from", help="skip the selected scripts before this one")
    parser.add_argument("--list", action="store_true", help="list what would run, then exit")
    arguments = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    scripts = select_scripts(arguments)
    if scripts is None:
        return 2
    if arguments.list:
        for path in scripts:
            group, automation, objective = SCRIPT_INFO[path.name]
            print(path.name.ljust(30) + " [" + group + "] " + automation)
        print()
        print(str(len(scripts)) + " script(s) selected.")
        return 0
    if not scripts:
        print("No scripts selected.")
        return 1

    env = build_environment()
    run = {"runner": Path(__file__).name, "started": datetime.now().isoformat(timespec="seconds"), "results": {}}
    current_group = None
    try:
        for index, path in enumerate(scripts, 1):
            group, automation, objective = SCRIPT_INFO[path.name]
            prompt, title = GROUPS[group]
            if group != current_group:
                current_group = group
                members = [item for item in scripts if SCRIPT_INFO[item.name][0] == group]
                print()
                print("#" * 100)
                print("# " + title + " (" + str(len(members)) + " script(s))")
                print("#" * 100)
            print("=" * 100)
            print("[" + str(index) + "/" + str(len(scripts)) + "] " + path.name)
            print("Objective : " + objective)
            print("Automation: " + automation)
            print("=" * 100)
            choice = ask(prompt)
            if choice == "stop":
                break
            if choice == "skip":
                run["results"][path.name] = {"status": "SKIPPED", "group": group}
                print("SKIPPED: " + path.name)
            else:
                run["results"][path.name] = dict(run_script(path, env), group=group)
            save_results(run)
            if run["results"][path.name]["status"] == "INTERRUPTED":
                break
    except KeyboardInterrupt:
        print("\nStopped.")
    save_results(run)
    print_summary(run)
    results = run["results"].values()
    return 0 if results and all(result["status"] == "PASSED" for result in results) else 1


if __name__ == "__main__":
    sys.exit(main())
