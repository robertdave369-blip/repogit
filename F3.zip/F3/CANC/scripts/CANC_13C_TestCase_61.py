# Author: Kris
#
# Test case  : CANC_13C_TestCase_61 (Codebeamer ID 36753965)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify CRASH_LOCATION multi-event priority with DBC coding.
# Automation : Automatic once the multi-event crash curves are delivered (blocked until then)
# Note       : load_crash_curves sends the central-sensor curves of every crash type through the
#              SPI sensor card (SPI.SendCrashData). On 2026-10-15 ARIA answered 'Card not
#              present in ARIA Chassis', which fails the case even where the satellite curves
#              alone produced the crash (13C 35/37/95/96: STS_CRASH held 800 ms with the right
#              CRASH_LOCATION). The case runs as it stands once the card is fitted.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_LOCATION_STATE,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '36753965'
    tc_name = 'CANC_13C_TestCase_61'
    tc_desc = (
        'Verify CRASH_LOCATION multi-event priority with DBC coding.'
    )
    automation = 'Automatic once the multi-event crash curves are delivered (blocked until then)'

    crash1_curve_key = CANC_CRASH_CURVE_KEY['rear_then_front']
    crash1_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash1_curve_key) or {}
    crash1_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash1_curve_set.get('RSU', {}).values())
    crash_set = MAH_CAN_SIGNAL_DEFS['STS_CRASH']['State_Values']['CRASH(Request to stop engine)']
    crash2_curve_key = CANC_CRASH_CURVE_KEY['underbody_then_left']
    crash2_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash2_curve_key) or {}
    crash2_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash2_curve_set.get('RSU', {}).values())
    crash3_curve_key = CANC_CRASH_CURVE_KEY['rollover_then_right']
    crash3_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash3_curve_key) or {}
    crash3_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash3_curve_set.get('RSU', {}).values())
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash1_curve_key}', crash1_curves_ready or None),
            (f'crash curves for {crash2_curve_key}', crash2_curves_ready or None),
            (f'crash curves for {crash3_curve_key}', crash3_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Multi-event: rear then front')
        load_crash_curves(crash1_curve_key, project=PROJECT_NAME)
        seq1_ids = [fd_id, hs_id]
        seq1_file = os.path.splitext(log_path)[0] + '_seq1.txt'
        seq1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq1', filepath=seq1_file,
            listOption=seq1_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq1_logger)
        seq1_frames = []
        if os.path.isfile(seq1_file):
            with open(seq1_file, encoding='utf-8', errors='replace') as seq1_log:
                seq1_fields = [line.split(',', 2) for line in seq1_log if ' id=' in line and line.count(',') >= 2]
            seq1_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq1_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq1_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq1_frames = [frame_data for frame_data in seq1_frames if frame_data.id in seq1_ids]
        seq1_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION'}
        seq1_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq1_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq1_frames if frame_data.id == fd_id]
        seq1_fd_locations = [row['loc'] for row in seq1_fd if row['sts'] == crash_set]
        seq1_fd_sequence = [value for position, value in enumerate(seq1_fd_locations)
                           if position == 0 or value != seq1_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq1_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['front']]])
        seq1_hs_keys = {'sts': 'SRS1_20_STS_CRASH', 'loc': 'SRS1_20_CRASH_LOCATION'}
        seq1_hs = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq1_hs_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq1_frames if frame_data.id == hs_id]
        seq1_hs_locations = [row['loc'] for row in seq1_hs if row['sts'] == crash_set]
        seq1_hs_sequence = [value for position, value in enumerate(seq1_hs_locations)
                           if position == 0 or value != seq1_hs_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{hs_frame} CRASH_LOCATION after the sequence", seq1_hs_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['front']]])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Multi-event: underbody then left')
        load_crash_curves(crash2_curve_key, project=PROJECT_NAME)
        seq2_ids = [fd_id, hs_id]
        seq2_file = os.path.splitext(log_path)[0] + '_seq2.txt'
        seq2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq2', filepath=seq2_file,
            listOption=seq2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq2_logger)
        seq2_frames = []
        if os.path.isfile(seq2_file):
            with open(seq2_file, encoding='utf-8', errors='replace') as seq2_log:
                seq2_fields = [line.split(',', 2) for line in seq2_log if ' id=' in line and line.count(',') >= 2]
            seq2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq2_frames = [frame_data for frame_data in seq2_frames if frame_data.id in seq2_ids]
        seq2_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION'}
        seq2_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq2_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq2_frames if frame_data.id == fd_id]
        seq2_fd_locations = [row['loc'] for row in seq2_fd if row['sts'] == crash_set]
        seq2_fd_sequence = [value for position, value in enumerate(seq2_fd_locations)
                           if position == 0 or value != seq2_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq2_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['left']]])
        seq2_hs_keys = {'sts': 'SRS1_20_STS_CRASH', 'loc': 'SRS1_20_CRASH_LOCATION'}
        seq2_hs = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq2_hs_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq2_frames if frame_data.id == hs_id]
        seq2_hs_locations = [row['loc'] for row in seq2_hs if row['sts'] == crash_set]
        seq2_hs_sequence = [value for position, value in enumerate(seq2_hs_locations)
                           if position == 0 or value != seq2_hs_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{hs_frame} CRASH_LOCATION after the sequence", seq2_hs_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['left']]])
        fault_free_profile()
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Multi-event: rollover then right')
        load_crash_curves(crash3_curve_key, project=PROJECT_NAME)
        seq3_ids = [fd_id, hs_id]
        seq3_file = os.path.splitext(log_path)[0] + '_seq3.txt'
        seq3_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_seq3', filepath=seq3_file,
            listOption=seq3_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(4 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(seq3_logger)
        seq3_frames = []
        if os.path.isfile(seq3_file):
            with open(seq3_file, encoding='utf-8', errors='replace') as seq3_log:
                seq3_fields = [line.split(',', 2) for line in seq3_log if ' id=' in line and line.count(',') >= 2]
            seq3_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in seq3_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(seq3_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        seq3_frames = [frame_data for frame_data in seq3_frames if frame_data.id in seq3_ids]
        seq3_fd_keys = {'sts': 'STS_CRASH', 'loc': 'CRASH_LOCATION'}
        seq3_fd = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq3_fd_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq3_frames if frame_data.id == fd_id]
        seq3_fd_locations = [row['loc'] for row in seq3_fd if row['sts'] == crash_set]
        seq3_fd_sequence = [value for position, value in enumerate(seq3_fd_locations)
                           if position == 0 or value != seq3_fd_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{fd_frame} CRASH_LOCATION after the sequence", seq3_fd_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['right']]])
        seq3_hs_keys = {'sts': 'SRS1_20_STS_CRASH', 'loc': 'SRS1_20_CRASH_LOCATION'}
        seq3_hs = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in seq3_hs_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in seq3_frames if frame_data.id == hs_id]
        seq3_hs_locations = [row['loc'] for row in seq3_hs if row['sts'] == crash_set]
        seq3_hs_sequence = [value for position, value in enumerate(seq3_hs_locations)
                           if position == 0 or value != seq3_hs_locations[position - 1]]
        RESULT.InterpretEqualResult(f"{hs_frame} CRASH_LOCATION after the sequence", seq3_hs_sequence[-1:], [MAH_CAN_SIGNAL_DEFS['CRASH_LOCATION']['State_Values'][CANC_CRASH_LOCATION_STATE['right']]])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
