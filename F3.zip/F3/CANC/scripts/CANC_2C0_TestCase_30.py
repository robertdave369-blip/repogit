# Author: Kris
#
# Test case  : CANC_2C0_TestCase_30 (Codebeamer ID 35736877)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check Signal Value of SRS_OPERATION_MODE Signal in 2C0 Msg when Plant mode DTC
#              is active
# Automation : Automatic (irreversible: changes the learned phase of life)
# Note       : Entering plant mode moves the ECU's learned phase of life to Vehicle Assembly; 30
#              s fault-free it moves on to Owner, from which plantmode_config allows only
#              EndOfLife. The case can therefore run once per software flash; the script reads
#              the phase first and stops when plant mode cannot be entered.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.plantmode_config import (
    PHASE_OF_LIFE_STATES,
    PHASE_OF_LIFE_TRANSITIONS,
    PLANT_MODE_DTC,
    PLANT_MODE_OWNER_TRANSITION_DELAY_MS,
    ROUTINE_CONTROL_SECURITY_LEVEL,
    build_phase_of_life_start_routine,
    build_phase_of_life_status_request,
    build_routine_control_positive_response,
    format_uds_bytes,
)


def run_test():
    tc_id = '35736877'
    tc_name = 'CANC_2C0_TestCase_30'
    tc_desc = (
        'To Check Signal Value of SRS_OPERATION_MODE Signal in 2C0 Msg when Plant mode DTC is '
        'active'
    )
    automation = 'Automatic (irreversible: changes the learned phase of life)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    mode_active = MAH_CAN_SIGNAL_DEFS['SRS_OPERATION_MODE']['State_Values']['active']
    mode_inactive = MAH_CAN_SIGNAL_DEFS['SRS_OPERATION_MODE']['State_Values']['Non active']
    vehicle_assembly = next(phase for phase, name in PHASE_OF_LIFE_STATES.items() if name == 'VehicleAssembly')
    plant_request = format_uds_bytes(build_phase_of_life_start_routine(vehicle_assembly))
    plant_response = format_uds_bytes(build_routine_control_positive_response(vehicle_assembly))
    plant_window_ms = int(PLANT_MODE_OWNER_TRANSITION_DELAY_MS * margin)
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: SRS_OPERATION_MODE active with no fault')
        check_started = time.monotonic()
        for check_key, check_expected in [('SRS1_20_SRS_OPERATION_MODE', mode_active)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Put the ECU in plant mode')
        phase_response = str(CAN.SendDiagByValues(format_uds_bytes(build_phase_of_life_status_request())))
        phase_tokens = phase_response.split()
        current_phase = int(phase_tokens[3], 16) if len(phase_tokens) > 3 and phase_tokens[0].upper() == "0X62" else None
        RESULT.LogAction("Phase of life before plant mode", phase_response)
        if (current_phase, vehicle_assembly) not in PHASE_OF_LIFE_TRANSITIONS:
            RESULT.LogCustomAction(
                "Plant mode can be entered from the current phase of life",
                f"phase in {sorted(source for source, target in PHASE_OF_LIFE_TRANSITIONS if target == vehicle_assembly)}",
                f"phase {current_phase}", False)
            return
        enter_ext_session()
        Internal_Security_Access(ROUTINE_CONTROL_SECURITY_LEVEL)
        RESULT.InterpretEqualResult("Enter plant mode (phase of life Vehicle Assembly)",
                                    str(CAN.SendDiagByValues(plant_request)), plant_response)
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        Read_DTC("Plant mode DTC active",
                 " ".join([Read_DTC_Resp_CANC, PLANT_MODE_DTC['code'], PLANT_MODE_DTC['active_status']]),
                 Read_DTC_Req_CANC)
        check_started = time.monotonic()
        for check_key, check_expected in [('SRS1_20_SRS_OPERATION_MODE', mode_inactive)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Remove the fault')
        Wait(plant_window_ms)
        Read_DTC("Plant mode DTC healed",
                 " ".join([Read_DTC_Resp_CANC, PLANT_MODE_DTC['code'], PLANT_MODE_DTC['healed_status']]),
                 Read_DTC_Req_CANC)
        check_started = time.monotonic()
        for check_key, check_expected in [('SRS1_20_SRS_OPERATION_MODE', mode_active)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
