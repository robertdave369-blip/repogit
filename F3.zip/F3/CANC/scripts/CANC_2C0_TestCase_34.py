# Author: Kris
#
# Test case  : CANC_2C0_TestCase_34 (Codebeamer ID 35736881)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Verify 738 message response
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_SESSION_EXTENDED,
)


def run_test():
    tc_id = '35736881'
    tc_name = 'CANC_2C0_TestCase_34'
    tc_desc = (
        'To Verify 738 message response'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Cycle IGN and send 10 03 on 730')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        RESULT.InterpretEqualResult('Response on 738', str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)), UDS_RESP_SESSION_EXTENDED)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
