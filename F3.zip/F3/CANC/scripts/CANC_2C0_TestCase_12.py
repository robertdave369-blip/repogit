# Author: Kris
#
# Test case  : CANC_2C0_TestCase_12 (Codebeamer ID 35736859)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for
#              Near crash
# Automation : Automatic once the near-crash curves are delivered (blocked until then)
# Note       : load_crash_curves sends the central-sensor curves of every crash type through the
#              SPI sensor card (SPI.SendCrashData). On 2026-10-15 ARIA answered 'Card not
#              present in ARIA Chassis', which fails the case even where the satellite curves
#              alone produced the crash (13C 35/37/95/96: STS_CRASH held 800 ms with the right
#              CRASH_LOCATION). The case runs as it stands once the card is fitted.
# Note       : The case expects STS_CRASH, DOOR_UNLOCK and CRASH_LOCATION to show a left crash
#              for a near crash, and NEAR_CRASH in SRS1_20, which does not carry it; the script
#              expects canc_config CAN_SIGNAL_Rx_EXPECTED_VALUES['near'] in SRS1_20 and
#              NEAR_CRASH in SRS1_FD_10.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_CRASH_CURVE_KEY,
    CANC_CRASH_SIGNAL_HOLD_MS,
    CANC_EDR_MAX_DELTA_V_ELEMENT,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_NEAR_CRASH_DELTA_V_MIN_KMH,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_PROVEOUT_TOLERANCE_PERCENT,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_HSCAN_SIGNAL_Rx_MAP,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
    PROJECT_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
)


def run_test():
    tc_id = '35736859'
    tc_name = 'CANC_2C0_TestCase_12'
    tc_desc = (
        'To Check signal Values of STS_ CRASH, DOOR_UNLOCK and CRASH_LOCATION signal for Near '
        'crash'
    )
    automation = 'Automatic once the near-crash curves are delivered (blocked until then)'

    crash_curve_key = CANC_CRASH_CURVE_KEY['near']
    crash_curve_set = get_project_crash_curve_config(PROJECT_NAME).get(crash_curve_key) or {}
    crash_curves_ready = any((spec[0] if isinstance(spec, tuple) else spec)
                             for spec in crash_curve_set.get('RSU', {}).values())
    near_set = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['Crash']
    near_clear = MAH_CAN_SIGNAL_DEFS['NEAR_CRASH']['State_Values']['No Near Crash']
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'crash curves for {crash_curve_key}', crash_curves_ready or None),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id, hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Load the near-crash curves')
        load_crash_curves(crash_curve_key, project=PROJECT_NAME)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: NEAR_CRASH initial value')
        check_started = time.monotonic()
        for check_key, check_expected in [('NEAR_CRASH', near_clear)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Create the near crash')
        crash_ids = [fd_id, hs_id]
        crash_file = os.path.splitext(log_path)[0] + '_crash.txt'
        crash_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_crash', filepath=crash_file,
            listOption=crash_ids, channel_names=[CAN_FD_CHANNEL_NAME, CAN_HS_CHANNEL_NAME])
        TriggerCrash()
        Wait(3 * CANC_CRASH_SIGNAL_HOLD_MS)
        CAN.StopLoggingToFile(crash_logger)
        crash_frames = []
        if os.path.isfile(crash_file):
            with open(crash_file, encoding='utf-8', errors='replace') as crash_log:
                crash_fields = [line.split(',', 2) for line in crash_log if ' id=' in line and line.count(',') >= 2]
            crash_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in crash_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(crash_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        crash_frames = [frame_data for frame_data in crash_frames if frame_data.id in crash_ids]
        near_rows_keys = {'near': 'NEAR_CRASH'}
        near_rows = [
            dict({role: extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[key],
                                           MAH_CAN_SIGNAL_DEFS[key]['bit_length'])
                  for role, key in near_rows_keys.items()}, t=frame_data.timestamp / 1000)
            for frame_data in crash_frames if frame_data.id == fd_id]
        near_on = [row for row in near_rows if row['near'] == near_set]
        near_hold_ms = round(near_on[-1]['t'] - near_on[0]['t'], 1) + fd_period_ms if near_on else None
        RESULT.InterpretEqualResultRange("SRS1_FD_10 NEAR_CRASH set for (ms)", near_hold_ms,
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 - CANC_PROVEOUT_TOLERANCE_PERCENT / 100),
                                         CANC_CRASH_SIGNAL_HOLD_MS * (1 + CANC_PROVEOUT_TOLERANCE_PERCENT / 100))
        # A near crash deploys nothing: SRS1_20 keeps the values canc_config gives for it.
        for short_name, expected_text in CAN_SIGNAL_Rx_EXPECTED_VALUES['near'].items():
            near_frame, near_signal = CAN_HSCAN_SIGNAL_Rx_MAP[short_name]
            near_text = str(CAN.GetSignalFromFrame(CAN_HS_CHANNEL_NAME, near_frame, near_signal)).strip()
            try:
                near_value = int(near_text, 16) if near_text.lower().startswith("0x") else int(float(near_text))
            except ValueError:
                near_value = near_text
            RESULT.InterpretEqualResult(f"{near_frame} {near_signal} after the near crash", str(near_value),
                                        str(int(expected_text, 16)))
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Read the longitudinal and lateral delta-V in the EDR')
        try:
            near_edr = read_edr_parameters(list(CANC_EDR_MAX_DELTA_V_ELEMENT.values()), crash_type='near',
                                           return_data=True) or {}
        except Exception as edr_error:
            near_edr = {}
            RESULT.LogCustomAction("EDR delta-V of the near crash read", "Decoded by read_edr_parameters",
                                   f"Not possible: {edr_error!r}", False)
        for direction, element in CANC_EDR_MAX_DELTA_V_ELEMENT.items():
            near_delta = (near_edr.get('decoded') or {}).get(element)
            near_delta = near_delta[0] if isinstance(near_delta, (list, tuple)) and near_delta else near_delta
            RESULT.InterpretEqualResultRange(f"EDR {direction} delta-V of the near crash (km/h)",
                                             abs(near_delta) if isinstance(near_delta, (int, float)) else near_delta,
                                             CANC_NEAR_CRASH_DELTA_V_MIN_KMH, float('inf'))
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            fault_free_profile()
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
