# Author: Kris
#
# Test case  : CANC_VCU_TestCase58 (Codebeamer ID 35662147)
# Workbook   : VCU_Node_TestCases.xlsx
# Objective  : Verify that Message Content Failure (DLC) overrides Signal Content Failure
#              (VCU_MCU_MOTOR_SPEED) according to the fault priority model for VCU11_FD_10.
# Automation : Not executable (hard constraint)
# Note       : canc_config has no invalid value and no signal content failure DTC for
#              VCU_MCU_MOTOR_SPEED (and the customer DTC list defines none), so the fault cannot
#              be created or checked. The script reports this and stops before acting on the
#              bench.
# Note       : A wrong DLC is produced by giving the simulated frame itself the payload length
#              CAN_DLC_ERROR_PAYLOAD_LENGTH gives (CAN.SetPeriodicFrame on the frame's own name
#              changes its payload), with the bench-computed CRC / alive counter held meanwhile;
#              the default payload is reloaded to heal. A copy on the same identifier is refused
#              by ARIA ('Frame ID ... already in simulation', 2026-10-15). Confirm on the bench
#              that the frame goes out with the shorter length.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_TX_MESSAGE_CONFIG,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
    get_frame_message_content_failure_dtc,
    get_message_content_failure_signals,
    qualification_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35662147'
    tc_name = 'CANC_VCU_TestCase58'
    tc_desc = (
        'Verify that Message Content Failure (DLC) overrides Signal Content Failure '
        '(VCU_MCU_MOTOR_SPEED) according to the fault priority model for VCU11_FD_10.'
    )
    automation = 'Not executable (hard constraint)'

    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lower_key = 'VCU_MCU_MOTOR_SPEED'
    lower_def = MAH_CAN_SIGNAL_DEFS[lower_key]
    lower_frame = lower_def['frame']
    lower_bus = lower_def['bus']
    lower_dtc = CAN_TX_MESSAGE_CONFIG[lower_frame]['signal_content_failure_dtcs'].get(lower_def['signal'])
    lower_invalid = lower_def.get('Invalid_Value')
    lower_recovery = lower_def.get('SCF_Recovery_Value')
    if lower_recovery is None:
        lower_recovery = lower_def.get('Default_Value')
    lower_qualify_nominal_ms = qualification_ms('signal_content', lower_def['periodicity'])
    lower_qualify_tolerance_ms = int(lower_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    higher_frame = 'VCU11_FD_10'
    higher_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == higher_frame)
    higher_bus = higher_def['bus']
    higher_dtc = get_frame_message_content_failure_dtc(higher_frame)[0]
    if higher_dtc is None:
        higher_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(higher_frame)
    higher_error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[higher_def['dlc']])
    higher_dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals(higher_frame)
                           if key in MAH_CAN_SIGNAL_DEFS]
    higher_qualify_nominal_ms = qualification_ms('message_content', higher_def['periodicity'])
    higher_qualify_tolerance_ms = int(higher_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([lower_def, higher_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'signal content failure DTC of {lower_key}', lower_dtc),
            (f'invalid value of {lower_key}', lower_invalid),
            (f'recovery value of {lower_key}', lower_recovery),
            (f'message content failure (DLC) DTC of {higher_frame}', higher_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(lower_bus, lower_frame)
        CAN.ReloadDefaultPeriodicFrame(lower_bus, lower_frame)
        CAN.PeriodicEnableFrame(higher_bus, higher_frame)
        CAN.ReloadDefaultPeriodicFrame(higher_bus, higher_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create and qualify the lower-priority fault - inject the invalid value for VCU_MCU_MOTOR_SPEED')
        CAN.ChangeSignalValue(lower_bus, lower_frame, lower_def['signal'], str(lower_invalid))
        lower_qualification_time_ms = faultTimeMeasurement(f"{lower_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {lower_dtc} ({lower_qualify_nominal_ms // lower_def['periodicity']} x {lower_def['periodicity']} ms): expected {lower_qualify_nominal_ms} ms, limits {lower_qualify_nominal_ms - lower_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {lower_qualify_nominal_ms + lower_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(lower_qualification_time_ms, lower_qualify_nominal_ms + measurement_lag_ms / 2, lower_qualify_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'Lower-priority DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      lower_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create the higher-priority fault - inject incorrect DLC on VCU11_FD_10')
        for higher_dynamic_signal in higher_dynamic_signals:
            CAN.DynamicDisableSignal(higher_bus, higher_frame, higher_dynamic_signal)
        CAN.SetPeriodicFrame(higher_bus, higher_frame, higher_def['frame_ID'], higher_def['periodicity'],
                             higher_error_payload, higher_def['is_fd'])
        CAN.PeriodicEnableFrame(higher_bus, higher_frame)
        higher_qualification_time_ms = faultTimeMeasurement(f"{higher_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {higher_dtc} ({higher_qualify_nominal_ms // higher_def['periodicity']} x {higher_def['periodicity']} ms): expected {higher_qualify_nominal_ms} ms, limits {higher_qualify_nominal_ms - higher_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {higher_qualify_nominal_ms + higher_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(higher_qualification_time_ms, higher_qualify_nominal_ms + measurement_lag_ms / 2, higher_qualify_tolerance_ms + measurement_lag_ms / 2)
        # Before an IGN cycle the lower-priority DTC may still read active, so the
        # list is recorded rather than graded.
        RESULT.LogAction("DTCs before the IGN cycle", CAN.SendDiagByValues(Read_DTC_Req_CANC))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{higher_dtc} {DTC_status['DTC_active_WLOFF']};{lower_dtc} {DTC_status['DTC_healed']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Higher-priority DTC active, lower-priority DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      higher_dtc, DTC_status['DTC_active_WLOFF'],
                      lower_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{higher_dtc} {DTC_status['DTC_active_WLOFF']};{lower_dtc} {DTC_status['DTC_historic']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Higher-priority DTC active, lower-priority DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      higher_dtc, DTC_status['DTC_active_WLOFF'],
                      lower_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame(higher_bus, higher_frame)
            for higher_dynamic_signal in higher_dynamic_signals:
                CAN.DynamicEnableSignal(higher_bus, higher_frame, higher_dynamic_signal)
            CAN.PeriodicEnableFrame(higher_bus, higher_frame)
            CAN.ChangeSignalValue(lower_bus, lower_frame, lower_def['signal'], str(lower_recovery))
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
