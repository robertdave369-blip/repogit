# Author: Kris
#
# Test case  : CANC_HPCAd_TestCase_36 (Codebeamer ID 35659769)
# Workbook   : HPCAD_Node_TestCases.xlsx
# Objective  : Verify that when a message content fault is followed by loss of HPCAd_3_50
#              reception, the reported communication fault changes according to the specified
#              priority.
# Automation : Automatic
# Note       : A wrong DLC is produced by giving the simulated frame itself the payload length
#              CAN_DLC_ERROR_PAYLOAD_LENGTH gives (CAN.SetPeriodicFrame on the frame's own name
#              changes its payload), with the bench-computed CRC / alive counter held meanwhile;
#              the default payload is reloaded to heal. A copy on the same identifier is refused
#              by ARIA ('Frame ID ... already in simulation', 2026-10-15). Confirm on the bench
#              that the frame goes out with the shorter length.
# Note       : The case steps and expected results are copied from other cases and contradict
#              each other (lower-priority DTC both historic and healed after the same IGN
#              cycle); the script expects the pattern the other priority cases give: after the
#              first IGN cycle the higher-priority DTC active and the lower-priority DTC healed,
#              after the second the lower-priority DTC historic.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
    get_frame_message_content_failure_dtc,
    get_message_content_failure_signals,
    is_key_message,
    qualification_ms,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35659769'
    tc_name = 'CANC_HPCAd_TestCase_36'
    tc_desc = (
        'Verify that when a message content fault is followed by loss of HPCAd_3_50 '
        'reception, the reported communication fault changes according to the specified '
        'priority.'
    )
    automation = 'Automatic'

    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lower_frame = 'HPCAd_3_50'
    lower_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == lower_frame)
    lower_bus = lower_def['bus']
    lower_dtc = get_frame_message_content_failure_dtc(lower_frame)[0]
    if lower_dtc is None:
        lower_dtc = CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(lower_frame)
    lower_error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[lower_def['dlc']])
    lower_dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals(lower_frame)
                           if key in MAH_CAN_SIGNAL_DEFS]
    lower_qualify_nominal_ms = qualification_ms('message_content', lower_def['periodicity'])
    lower_qualify_tolerance_ms = int(lower_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    higher_frame = 'HPCAd_3_50'
    higher_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == higher_frame)
    higher_bus = higher_def['bus']
    higher_mode = 'node_absent' if is_key_message(higher_frame) else 'message_timeout'
    higher_dtc = resolve_dtc_for_event('frame_disabled', higher_frame)
    higher_qualify_nominal_ms = qualification_ms(higher_mode, higher_def['periodicity'])
    higher_qualify_tolerance_ms = int(higher_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([lower_def, higher_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'message content failure (DLC) DTC of {lower_frame}', lower_dtc),
            (f'frame-loss DTC of {higher_frame}', higher_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(lower_bus, lower_frame)
        CAN.ReloadDefaultPeriodicFrame(lower_bus, lower_frame)
        CAN.PeriodicEnableFrame(higher_bus, higher_frame)
        CAN.ReloadDefaultPeriodicFrame(higher_bus, higher_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create and qualify the lower-priority fault - inject incorrect DLC on HPCAd_3_50')
        for lower_dynamic_signal in lower_dynamic_signals:
            CAN.DynamicDisableSignal(lower_bus, lower_frame, lower_dynamic_signal)
        CAN.SetPeriodicFrame(lower_bus, lower_frame, lower_def['frame_ID'], lower_def['periodicity'],
                             lower_error_payload, lower_def['is_fd'])
        CAN.PeriodicEnableFrame(lower_bus, lower_frame)
        lower_qualification_time_ms = faultTimeMeasurement(f"{lower_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {lower_dtc} ({lower_qualify_nominal_ms // lower_def['periodicity']} x {lower_def['periodicity']} ms): expected {lower_qualify_nominal_ms} ms, limits {lower_qualify_nominal_ms - lower_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {lower_qualify_nominal_ms + lower_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(lower_qualification_time_ms, lower_qualify_nominal_ms + measurement_lag_ms / 2, lower_qualify_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'Lower-priority DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      lower_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create the higher-priority fault - stop transmission of HPCAd_3_50')
        CAN.PeriodicDisableFrame(higher_bus, higher_frame)
        higher_qualification_time_ms = faultTimeMeasurement(f"{higher_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {higher_dtc} ({higher_qualify_nominal_ms // higher_def['periodicity']} x {higher_def['periodicity']} ms): expected {higher_qualify_nominal_ms} ms, limits {higher_qualify_nominal_ms - higher_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {higher_qualify_nominal_ms + higher_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(higher_qualification_time_ms, higher_qualify_nominal_ms + measurement_lag_ms / 2, higher_qualify_tolerance_ms + measurement_lag_ms / 2)
        # Before an IGN cycle the lower-priority DTC may still read active, so the
        # list is recorded rather than graded.
        RESULT.LogAction("DTCs before the IGN cycle", CAN.SendDiagByValues(Read_DTC_Req_CANC))
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{higher_dtc} {DTC_status['DTC_active_WLOFF']};{lower_dtc} {DTC_status['DTC_healed']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Higher-priority DTC active, lower-priority DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      higher_dtc, DTC_status['DTC_active_WLOFF'],
                      lower_dtc, DTC_status['DTC_healed']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Cycle IGN and read DTC')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        settle_time_ms = faultTimeMeasurement(f"{higher_dtc} {DTC_status['DTC_active_WLOFF']};{lower_dtc} {DTC_status['DTC_historic']}")
        RESULT.LogAction('Time until the DTCs settle after the IGN cycle (ms)', None if settle_time_ms is None else round(settle_time_ms))
        Read_DTC(
            'Higher-priority DTC active, lower-priority DTC historic',
            " ".join([Read_DTC_Resp_CANC,
                      higher_dtc, DTC_status['DTC_active_WLOFF'],
                      lower_dtc, DTC_status['DTC_historic']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableFrame(higher_bus, higher_frame)
            CAN.ReloadDefaultPeriodicFrame(higher_bus, higher_frame)
            CAN.ReloadDefaultPeriodicFrame(lower_bus, lower_frame)
            for lower_dynamic_signal in lower_dynamic_signals:
                CAN.DynamicEnableSignal(lower_bus, lower_frame, lower_dynamic_signal)
            CAN.PeriodicEnableFrame(lower_bus, lower_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
