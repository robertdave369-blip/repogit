# Author: Kris
#
# Test case  : CAN_BUSOFF_11 (Codebeamer ID 35721117)
# Workbook   : BussOff_TestCases.xlsx
# Objective  : 1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages
#              diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is not BUS OFF)
# Automation : Semi-automatic (operator creates and removes the bus-off)
# Note       : No shared-library call can short CAN-H to CAN-L or drive a CAN stress tool, so
#              the operator applies and removes the bus-off when the script asks (it waits
#              CAN_BUS_OFF_OPERATOR_WINDOW_MS); the script then checks the frames on the bus and
#              the DTCs itself.
# Note       : The case asks for 'any fault'; a loop open is used because CAN faults have 'no
#              bus-off' as a precondition in the customer DTC list.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    BUSOFF_FAST_RECOVERY_COUNT,
    BUSOFF_FAST_RECOVERY_TIME_MS,
    BUSOFF_SLOW_RECOVERY_TIME_MS,
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_LOOP_FAULT_SQUIB,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CANC_TESTER_PRESENT_PERIOD_MS,
    CAN_BUS_OFF_ACTIVE_STATUS_KEY,
    CAN_BUS_OFF_DTC,
    CAN_BUS_OFF_OPERATOR_WINDOW_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_RX_MESSAGE_CONFIG,
    NM_IGN_ON_STARTUP_DELAY_MS,
    NM_RESTART_DELAY_AFTER_BUS_OFF_MS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    CAN_HS_CHANNEL_NAME,
    DIAG_TX_ID,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_REQ_85_02,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_C5_02,
    UDS_RESP_SESSION_EXTENDED,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.squibs_config import (
    SquibNumber,
    Squib_Fault_Description,
    squib_fault_time,
)


def run_test():
    tc_id = '35721117'
    tc_name = 'CAN_BUSOFF_11'
    tc_desc = (
        '1. To check the behaviour of ACU during busoff condition. 2. To test CAN messages '
        'diagnosis when Bus OFF is present.(HS CAN is BUS OFF & FD CAN is not BUS OFF)'
    )
    automation = 'Semi-automatic (operator creates and removes the bus-off)'

    margin = 1 + CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    busoff_settle_ms = (int((BUSOFF_FAST_RECOVERY_COUNT * BUSOFF_FAST_RECOVERY_TIME_MS
                             + BUSOFF_SLOW_RECOVERY_TIME_MS) * margin) + NM_RESTART_DELAY_AFTER_BUS_OFF_MS)
    loop_device = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}"
    loop_qualify_ms = int(squib_fault_time['Qualification_Time'] * (1 + squib_fault_time['Qualification_Tolerance'] / 100))

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create bus-off on HS-CAN only - SRS1_20 stops, SRS1_FD_10 continues')
        RESULT.InsertComment('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        print('OPERATOR ACTION: Short CAN-H to CAN-L on the HS-CAN bus and keep the short.')
        Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_hs.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_hs', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResult(
            f"{hs_frame} is not transmitted (frames in the window)",
            presence2_hs_count, 0)
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_busoff_fd_alive.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_busoff_fd_alive', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Restart the bench messages and read DTC while the bus-off is active')
        CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
        CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
        Wait(busoff_settle_ms)
        Read_DTC(
            'HS-CAN bus-off DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      CAN_BUS_OFF_DTC['HSCAN'], DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Send Tester Present periodically and enter the extended session')
        tester_present(CAN_FD_CHANNEL_NAME, CANC_TESTER_PRESENT_PERIOD_MS, 'start',
                       frame_name='CANC_TESTER_PRESENT', frame_id=DIAG_TX_ID)
        RESULT.InterpretEqualResult("Extended session", str(CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)),
                                    UDS_RESP_SESSION_EXTENDED)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Control DTC setting')
        RESULT.InterpretEqualResult('Control DTC setting response', str(CAN.SendDiagByValues(UDS_REQ_85_02)), UDS_RESP_C5_02)
        aria_reports.close_group()
        aria_reports.add_group('Step 6: Create a fault on the bench (loop open)')
        SQUIB.SendRequest(loop_device, Squib_Fault_Description['Open'])
        Wait(loop_qualify_ms)
        Read_DTC(
            'The new fault is not logged while DTC setting is off',
            " ".join([Read_DTC_Resp_CANC,
                      CAN_BUS_OFF_DTC['HSCAN'], DTC_status[CAN_BUS_OFF_ACTIVE_STATUS_KEY['HSCAN']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            CAN.PeriodicEnableAllFrames(CAN_FD_CHANNEL_NAME)
            CAN.PeriodicEnableAllFrames(CAN_HS_CHANNEL_NAME)
            RESULT.InsertComment('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            print('OPERATOR ACTION: remove any CAN-H to CAN-L short left on either bus.')
            Wait(CAN_BUS_OFF_OPERATOR_WINDOW_MS)
            SQUIB.SendRequest(loop_device, Squib_Fault_Description['NoFault'])
            tester_present(CAN_FD_CHANNEL_NAME, None, 'stop', frame_name='CANC_TESTER_PRESENT')
            PS.Power_Cycle()
            Wait(NM_IGN_ON_STARTUP_DELAY_MS)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
