// Author: Kris
//
// CAN-C fault qualification and dequalification timing for M310_M314_M110 (M314 EV).
//
// One standalone ARIA script. It has no CALL includes: every function it needs is in this
// file, and it talks to the bench only through the ARIA user functions (CAN, PS, RESULT).
// ECMAScript 2009 (ES5) syntax only: var, function declarations and classic for loops.
//
// For each CAN fault the project defines, the script creates the fault on the bench,
// measures how long the ECU takes to set the DTC (qualification), removes the fault and
// measures how long the DTC takes to heal (dequalification):
//   node absent       stop the key frame of a node, or its only frame
//   message timeout   stop a frame that is not the key frame of its node
//   CRC error         the bench stops computing the CRC of the frame (the CRC is held)
//   alive counter     the bench stops computing the alive counter (the counter is held)
//   wrong DLC         the frame is sent with a shorter payload (64 to 32 bytes, 8 to 7)
//   signal content    the invalid value of a signal is sent
//
// Expected time = fault list count x frame period: node absent 50 frames to qualify and
// 10 to heal, every other CAN fault 60 and 10. A time passes when it lies between the
// expected time minus 10 percent and the expected time plus 10 percent, adjusted only for
// what the measurement itself costs (MEASUREMENT_ALLOWANCE, on by default):
//   upper limit  plus the read resolution of that one measurement: the time from the request
//                of the last DTC read that still showed the old state to the answer that
//                showed the new one (UDS 19 02 0B is polled about every 10 ms). The reads can
//                only make a measured time late, never early.
//   both limits  plus or minus the step of this PC's millisecond clock, measured at the start
//                of the run (1 ms on most benches, about 16 ms on a coarse Windows timer).
// Every timing check in the report states the nominal time and the allowance it used.
//
// Expected DTC status: 0x0B once qualified (no warning lamp) and 0x0A once healed, as the
// ECU reported every CAN DTC on the bench on 2026-10-15.
//
// Fault-free bench. The run starts with the fault-free profile of the Python bench
// (fault_free_profile_can_fd): NVM clear, default EOL code and variant code, bench VIN on CAN
// and in F1 90, ignition cycles, DTCs cleared, all read back. After every test the frame is
// restored, the DTCs are cleared, and the bench must show no new active DTC for as long as
// the tested fault needs to qualify. If one shows, every frame is restored and the profile is
// applied again, and the test is marked failed.
//
// The ECU only monitors a node that the variant code switches on, and the default variant
// code has OCS and E-Call off. Their targets run last, under the same profile with their two
// bits set, and the default profile is applied again at the end.
//
// Data copied on 2026-10-16 from projects/M310_M314_M110/config: canc_config.py (frames,
// signals, DTCs, counts) and project_config.py (EOL code, variant code), and from
// shared_libraries/configuration_control.py (VIN, DIDs, NVM clear routines).
// Diagnostics: physical 0x730 and 0x738 on CAN-FD channel 2.


// Bench settings

var ECU_CHANNEL = 2;                     // CAN-FD channel of the ECU, also used for diagnostics
var DIAG_REQUEST_ID = 0x730;             // physical diagnostic request
var DIAG_RESPONSE_ID = 0x738;            // physical diagnostic response
var IGNITION_CYCLE_WITH_BATT = true;     // switch BATT as well as IGN, as the 2026-10-15 bench power cycle did; false: IGN only
var POWER_OFF_MS = 4000;                 // off time of an ignition cycle
var STARTUP_MS = 8000;                   // wait after power on: proveout 7 s plus margin
var ENABLE_NODES_IN_VARIANT_CODE = true; // switch OCS and E-Call on for their targets
var LOG_EACH_TARGET = true;              // CAN log per target: the frame under test and the diagnostics
var LOG_FOLDER = "C:\\Framework\\TestLogs\\";


// Timing settings

var TOLERANCE_PERCENT = 10;
var MEASUREMENT_ALLOWANCE = true;        // false: plain minus and plus 10 percent, no allowance for read resolution and clock step
var clockStepMs = 1;                     // measured at the start of the run
var POLL_PAUSE_MS = 10;                  // pause between two DTC reads
var MAX_FAILED_READS = 50;               // DTC reads in a row without a valid answer before a measurement stops
var SETTLE_MS = 1000;                    // wait after restoring a frame, before the DTCs are cleared
var AFTER_CLEAR_MS = 1000;               // wait after clearing the DTCs, before the precondition read
var DTC_STATUS_ACTIVE = 0x0B;            // test failed, test failed this cycle, confirmed, no warning lamp
var DTC_STATUS_HEALED = 0x0A;            // test failed this cycle, confirmed


// Fault-free profile: the values the Python bench writes in fault_free_profile_can_fd().
// project_config.py DEFAULT_EOL_CODE and DEFAULT_VARIANT_CODE; configuration_control.py
// VIN_STRATEGY_OPTIONS "sample_32" (the same in vin_config.py), sent in VIN_FD_FRAME_NAME
// VIN_FD_SIGNAL_NAME and written to F1 90; configuration_control.py EOL_DID, VARIANT_CODE_DID
// and NVM_CLEAR_RIDS (routine control, security level 0x61).

var EOL_DID = "0x01 0x02";
var VARIANT_CODE_DID = "0x01 0x01";
var VIN_DID = "0xF1 0x90";
var DEFAULT_EOL_CODE = [0xFF, 0xBF, 0xFF, 0xAF, 0xFE, 0x1F, 0x31, 0x14, 0x03, 0x00,
                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
var DEFAULT_VARIANT_CODE = [0x19, 0x00, 0x00, 0x02, 0x00, 0x14, 0x00, 0x04, 0x00, 0x00,
                            0x00, 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
var BENCH_VIN = [0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32,
                 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32];
var BENCH_VIN_DECIMAL = "17080840378776518950318411667163267084850";  // the 17 VIN bytes as one number
var VIN_FRAME = "VCU4_FD_1500";
var VIN_SIGNAL = "VIN_NUMBER";
var NVM_CLEAR_ROUTINES = ["0xF1 0x04", "0xF1 0x05"];


// Selection: set a kind to false to skip it, or name one frame to run only its targets.

var RUN_KINDS = {
    NODE_ABSENT: true,
    MESSAGE_TIMEOUT: true,
    CRC: true,
    ALIVE_COUNTER: true,
    DLC: true,
    SIGNAL_CONTENT: true
};
var ONLY_FRAME = "";


// Fault list counts per kind: frames to qualify, frames to heal.

var FAULT_COUNTS = {
    NODE_ABSENT: [50, 10],
    MESSAGE_TIMEOUT: [60, 10],
    CRC: [60, 10],
    ALIVE_COUNTER: [60, 10],
    DLC: [60, 10],
    SIGNAL_CONTENT: [60, 10]
};

var KIND_NAMES = {
    NODE_ABSENT: "Node absent",
    MESSAGE_TIMEOUT: "Message timeout",
    CRC: "CRC error",
    ALIVE_COUNTER: "Alive counter error",
    DLC: "Wrong DLC",
    SIGNAL_CONTENT: "Signal content failure"
};


// Byte and bit of each node in the variant code (DID 0x0101).

var NODE_VARIANT_BITS = {
    IEB: [0, 0x08],
    EPS: [0, 0x10],
    OCS: [1, 0x02],
    E_CALL: [2, 0x08],
    HPCC: [5, 0x04],
    FR_ZONE: [5, 0x10],
    HPCAD: [7, 0x04],
    VCU: [12, 0x01]
};


// Frames the bench sends to the ECU: channel, identifier, period in ms, data length,
// CAN-FD or classic CAN, node, and the CRC and alive counter signals ("" when none).

var FRAMES = {
    E_CALL1_100:  { channel: 3, frameId: 0x34A, period: 100,  dlc: 8,  isFd: false, node: "E_CALL",  crc: "",             counter: "" },
    VCU11_FD_10:  { channel: 2, frameId: 0x16E, period: 10,   dlc: 64, isFd: true,  node: "VCU",     crc: "VCU11FD_CRC",  counter: "VCU11FD_MSG_CNT" },
    VCU1_FD_20:   { channel: 2, frameId: 0x207, period: 20,   dlc: 64, isFd: true,  node: "VCU",     crc: "VCU1FD_CRC",   counter: "VCU1FD_MSG_CNT" },
    VCU2_FD_100:  { channel: 2, frameId: 0x30E, period: 100,  dlc: 64, isFd: true,  node: "VCU",     crc: "VCU2FD_CRC",   counter: "VCU2FD_MSG_CNT" },
    VCU4_FD_1500: { channel: 2, frameId: 0x3F0, period: 1500, dlc: 64, isFd: true,  node: "VCU",     crc: "",             counter: "" },
    FR_ZONE2_100: { channel: 2, frameId: 0x319, period: 100,  dlc: 64, isFd: true,  node: "FR_ZONE", crc: "FR_ZONE2_CRC", counter: "FR_ZONE2_COUNTER" },
    FR_ZONE3_100: { channel: 2, frameId: 0x31A, period: 100,  dlc: 64, isFd: true,  node: "FR_ZONE", crc: "FR_ZONE3_CRC", counter: "FR_ZONE3_COUNTER" },
    IEB1_FD_10:   { channel: 2, frameId: 0x13B, period: 10,   dlc: 64, isFd: true,  node: "IEB",     crc: "IEB1_CRC",     counter: "IEB1_MSG_CNT" },
    HPCC_1_100:   { channel: 2, frameId: 0x318, period: 100,  dlc: 64, isFd: true,  node: "HPCC",    crc: "HPCC_1_CRC",   counter: "HPCC_1_MSG_COUNT" },
    HPCC_24_500:  { channel: 2, frameId: 0x58E, period: 500,  dlc: 64, isFd: true,  node: "HPCC",    crc: "",             counter: "" },
    EPS1_FD_10:   { channel: 2, frameId: 0x13A, period: 10,   dlc: 64, isFd: true,  node: "EPS",     crc: "EPS1_CRC",     counter: "EPS1_MSG_COUNT" },
    HPCAd_1_10:   { channel: 2, frameId: 0x13E, period: 10,   dlc: 64, isFd: true,  node: "HPCAD",   crc: "HPCA_1_CRC",   counter: "HPCA_1_MSG_COUNT" },
    HPCAd_2_50:   { channel: 2, frameId: 0x2AF, period: 50,   dlc: 64, isFd: true,  node: "HPCAD",   crc: "HPCA_2_CRC",   counter: "HPCA_2_MSG_COUNT" },
    HPCAd_3_50:   { channel: 2, frameId: 0x2B1, period: 50,   dlc: 64, isFd: true,  node: "HPCAD",   crc: "HPCA_3_CRC",   counter: "HPCA_3_MSG_COUNT" },
    HPCAd_4_10:   { channel: 2, frameId: 0x13F, period: 10,   dlc: 64, isFd: true,  node: "HPCAD",   crc: "HPCA_4_CRC",   counter: "HPCA_4_MSG_COUNT" },
    OCS1_500:     { channel: 3, frameId: 0x5FF, period: 500,  dlc: 8,  isFd: false, node: "OCS",     crc: "",             counter: "" }
};


// Targets. Node absent: the key frame of each node, or its only frame. FR_ZONE's key frame
// is FR_ZONE2_100 (bench 2026-10-15).

var NODE_ABSENT_TARGETS = [
    ["E_CALL1_100", "D1 73 00"],
    ["VCU11_FD_10", "D1 54 00"],
    ["FR_ZONE2_100", "D1 04 00"],
    ["IEB1_FD_10", "D1 03 00"],
    ["HPCC_1_100", "D1 60 00"],
    ["EPS1_FD_10", "D1 11 00"],
    ["HPCAd_1_10", "D1 61 00"],
    ["OCS1_500", "D1 70 00"]
];

// Message timeout: every frame with a timeout DTC that is not the key frame of its node.
// HPCC_24_500 is not in the fault list; its DTC comes from the customer DTC list.

var MESSAGE_TIMEOUT_TARGETS = [
    ["HPCC_24_500", "D0 5A 00"],
    ["FR_ZONE3_100", "D0 04 00"],
    ["HPCAd_3_50", "D0 5B 00"],
    ["VCU2_FD_100", "D0 54 00"],
    ["VCU1_FD_20", "D0 54 00"],
    ["VCU4_FD_1500", "D0 54 00"],
    ["HPCAd_4_10", "D0 5B 00"],
    ["HPCAd_2_50", "D0 5B 00"]
];

// CRC and alive counter: every frame with a CRC and an alive counter, and its message
// content DTC. The signal comes from the frame table.

var MESSAGE_CONTENT_TARGETS = [
    ["VCU11_FD_10", "E7 26 00"],
    ["FR_ZONE2_100", "E7 1C 00"],
    ["FR_ZONE3_100", "E7 24 00"],
    ["IEB1_FD_10", "E7 20 00"],
    ["HPCC_1_100", "E7 1F 00"],
    ["EPS1_FD_10", "E7 25 00"],
    ["HPCAd_3_50", "E7 1E 00"],
    ["VCU2_FD_100", "E7 23 00"],
    ["VCU1_FD_20", "E7 22 00"],
    ["HPCAd_4_10", "E7 29 00"],
    ["HPCAd_2_50", "E7 32 00"],
    ["HPCAd_1_10", "E7 1D 00"]
];

// Wrong DLC: the message content frames, plus the two frames whose DLC is their only
// content check (VCU4_FD_1500, OCS1_500).

var DLC_TARGETS = [
    ["VCU11_FD_10", "E7 26 00"],
    ["FR_ZONE2_100", "E7 1C 00"],
    ["FR_ZONE3_100", "E7 24 00"],
    ["IEB1_FD_10", "E7 20 00"],
    ["HPCC_1_100", "E7 1F 00"],
    ["EPS1_FD_10", "E7 25 00"],
    ["HPCAd_3_50", "E7 1E 00"],
    ["VCU2_FD_100", "E7 23 00"],
    ["VCU1_FD_20", "E7 22 00"],
    ["VCU4_FD_1500", "E7 27 00"],
    ["HPCAd_4_10", "E7 29 00"],
    ["HPCAd_2_50", "E7 32 00"],
    ["HPCAd_1_10", "E7 1D 00"],
    ["OCS1_500", "E7 61 00"]
];

// Signal content failure: frame, signal, invalid raw value, recovery raw value, DTC.

var SIGNAL_CONTENT_TARGETS = [
    ["VCU11_FD_10", "GEAR_ACTUAL", 15, 0, "E1 1D 00"],
    ["FR_ZONE3_100", "FL_TYRE_PRESSURE", 255, 0, "E0 D6 00"],
    ["FR_ZONE3_100", "FR_TYRE_PRESSURE", 255, 0, "E0 D7 00"],
    ["FR_ZONE3_100", "RL_TYRE_PRESSURE", 255, 0, "E0 D8 00"],
    ["FR_ZONE3_100", "RR_TYRE_PRESSURE", 255, 0, "E0 D9 00"],
    ["IEB1_FD_10", "VEHICLE_SPEED", 65535, 0, "E0 13 00"],
    ["IEB1_FD_10", "MASTER_CYL_PRESSURE", 65535, 0, "E1 8D 00"],
    ["HPCC_1_100", "ODOMTR_READING", 1048575, 0, "E0 12 00"],
    ["EPS1_FD_10", "STEERING_ABSOLUTE_ANGLE", 32767, 0, "E0 58 00"],
    ["VCU2_FD_100", "GEAR_ACTUAL", 15, 0, "E1 1D 00"],
    ["VCU1_FD_20", "VEHICLE_STATE", 4, 0, "E1 79 00"],
    ["HPCAd_1_10", "ADAS_DES_STRWHL_ANGLE_CMD", 32767, 0, "E1 77 00"]
];


// Report

function reportNote(text) {
    RESULT.InsertComment(text);
}

function reportCheck(name, expected, obtained, passed) {
    RESULT.LogCustomAction(name, expected, obtained, passed ? TestStatus.Passed : TestStatus.Failed);
}


// Time

function nowMs() {
    return new Date().getTime();
}

function waitMs(durationMs) {
    if (durationMs > 0) {
        Thread.Sleep(Math.round(durationMs));
    }
}

function twoDigits(value) {
    return value < 10 ? "0" + value : String(value);
}

function dateStamp() {
    var now = new Date();
    return String(now.getFullYear()) + twoDigits(now.getMonth() + 1) + twoDigits(now.getDate()) + "_" +
        twoDigits(now.getHours()) + twoDigits(now.getMinutes()) + twoDigits(now.getSeconds());
}

// Smallest step the millisecond clock takes between two 1 ms pauses.
function measureClockStep() {
    var smallest = -1;
    var last = nowMs();
    for (var i = 0; i < 20; i++) {
        waitMs(1);
        var current = nowMs();
        var step = current - last;
        if (step > 0 && (smallest < 0 || step < smallest)) {
            smallest = step;
        }
        last = current;
    }
    return smallest < 1 ? 1 : smallest;
}


// Text and bytes

function describeError(err) {
    if (err !== null && err !== undefined && err.message !== undefined) {
        return String(err.message);
    }
    return String(err);
}

function hexByte(value) {
    var text = (value & 0xFF).toString(16).toUpperCase();
    return text.length < 2 ? "0" + text : text;
}

function bytesToText(bytes) {
    var parts = [];
    for (var i = 0; i < bytes.length; i++) {
        parts.push(hexByte(bytes[i]));
    }
    return parts.join(" ");
}

function bytesToRequest(bytes) {
    var parts = [];
    for (var i = 0; i < bytes.length; i++) {
        parts.push("0x" + hexByte(bytes[i]));
    }
    return parts.join(" ");
}

// Reads "0x59 0x02 0xCB", "59 02 CB" or "5902CB" into numbers.
function parseHexBytes(text) {
    var bytes = [];
    var parts = String(text).replace(/0x/gi, " ").replace(/[^0-9A-Fa-f]+/g, " ").split(" ");
    for (var i = 0; i < parts.length; i++) {
        var part = parts[i];
        if (part.length === 0) {
            continue;
        }
        if (part.length % 2 === 1) {
            part = "0" + part;
        }
        for (var j = 0; j < part.length; j = j + 2) {
            bytes.push(parseInt(part.substring(j, j + 2), 16));
        }
    }
    return bytes;
}

function zeroBytes(count) {
    var bytes = [];
    for (var i = 0; i < count; i++) {
        bytes.push(0);
    }
    return bytes;
}

// A wrong DLC is a payload length the bus accepts but the DBC does not give the frame.
function shortLength(dlc) {
    if (dlc === 64) {
        return 32;
    }
    if (dlc === 8) {
        return 7;
    }
    return dlc - 1;
}

function addUnique(list, value) {
    for (var i = 0; i < list.length; i++) {
        if (list[i] === value) {
            return;
        }
    }
    list.push(value);
}

function sameBytes(first, second) {
    if (first.length !== second.length) {
        return false;
    }
    for (var i = 0; i < first.length; i++) {
        if (first[i] !== second[i]) {
            return false;
        }
    }
    return true;
}


// Bench calls. Each returns the ARIA answer [code, text]; "9999" marks a call that threw.

function callFailed(err) {
    return ["9999", describeError(err)];
}

function apiOk(answer) {
    try {
        return String(answer[0]) === "0000";
    } catch (err) {
        return false;
    }
}

function apiText(answer) {
    var code = "";
    var text = "";
    try {
        code = String(answer[0]);
        text = String(answer[1]);
    } catch (err) {
        return String(answer);
    }
    if (text === "undefined" || text === "null") {
        text = "";
    }
    return text.length > 0 ? code + " " + text : code;
}

function stopFrame(channel, frameName) {
    try {
        return CAN.PeriodicDisableFrame(channel, frameName);
    } catch (err) {
        return callFailed(err);
    }
}

function startFrame(channel, frameName) {
    try {
        return CAN.PeriodicEnableFrame(channel, frameName);
    } catch (err) {
        return callFailed(err);
    }
}

function reloadFrame(channel, frameName) {
    try {
        return CAN.ReloadDefaultPeriodicFrame(channel, frameName);
    } catch (err) {
        return callFailed(err);
    }
}

function holdSignal(channel, frameName, signalName) {
    try {
        return CAN.DisableDynamicSignal(channel, frameName, signalName);
    } catch (err) {
        return callFailed(err);
    }
}

function releaseSignal(channel, frameName, signalName) {
    try {
        return CAN.EnableDynamicSignal(channel, frameName, signalName);
    } catch (err) {
        return callFailed(err);
    }
}

function setSignalValue(channel, frameName, signalName, value) {
    try {
        return CAN.PeriodicChangeSignalValue(channel, frameName, signalName, String(value));
    } catch (err) {
        return callFailed(err);
    }
}

function setSignalBytes(channel, frameName, signalName, data) {
    try {
        return CAN.PeriodicChangeSignal(channel, frameName, signalName, data);
    } catch (err) {
        return callFailed(err);
    }
}

function changeFrameData(channel, frameName, data) {
    try {
        return CAN.PeriodicChangeDataAndName(channel, frameName, frameName, data);
    } catch (err) {
        return callFailed(err);
    }
}

function addCardFrame(channel, frameId, period, data, isFd) {
    try {
        return CAN.SetPeriodicFrame(channel, frameId, period, data.length, isFd, data);
    } catch (err) {
        return callFailed(err);
    }
}

function removeCardFrame(channel, frameId) {
    try {
        return CAN.RemovePeriodicFrame(channel, frameId);
    } catch (err) {
        return callFailed(err);
    }
}


// Diagnostics

function setDiagAddressing() {
    try {
        CAN.SetDiagnosticAdressingMode(ECU_CHANNEL, DIAG_REQUEST_ID, DIAG_RESPONSE_ID);
    } catch (err) {
        reportNote("Diagnostic addressing not set: " + describeError(err));
    }
}

function sendDiag(request) {
    var answer;
    try {
        answer = CAN.SendDiagByValues(request);
    } catch (err) {
        answer = callFailed(err);
    }
    var ok = apiOk(answer);
    var text = "";
    try {
        text = String(answer[1]);
    } catch (err2) {
        text = String(answer);
    }
    return { ok: ok, bytes: ok ? parseHexBytes(text) : [], text: text };
}

// UDS 19 02 0B: every DTC with test failed, test failed this cycle or confirmed set.
function readDtcs() {
    var reply = sendDiag("0x19 0x02 0x0B");
    var readout = { ok: false, records: [], text: reply.text };
    var bytes = reply.bytes;
    if (!reply.ok || bytes.length < 3 || bytes[0] !== 0x59 || bytes[1] !== 0x02) {
        return readout;
    }
    for (var i = 3; i + 3 < bytes.length; i = i + 4) {
        readout.records.push({ code: [bytes[i], bytes[i + 1], bytes[i + 2]], status: bytes[i + 3] });
    }
    readout.ok = true;
    return readout;
}

function clearDtcs() {
    var reply = sendDiag("0x14 0xFF 0xFF 0xFF");
    return reply.ok && reply.bytes.length > 0 && reply.bytes[0] === 0x54;
}

function clearAndRead(waitTime) {
    clearDtcs();
    waitMs(waitTime);
    return readDtcs();
}

function findDtc(readout, code) {
    for (var i = 0; i < readout.records.length; i++) {
        if (sameBytes(readout.records[i].code, code)) {
            return readout.records[i];
        }
    }
    return null;
}

function isTestFailed(status) {
    return (status & 0x01) === 0x01;
}

// Qualified: test failed and confirmed both set.
function isQualified(status) {
    return (status & 0x09) === 0x09;
}

function codeListed(list, code) {
    for (var i = 0; i < list.length; i++) {
        if (sameBytes(list[i], code)) {
            return true;
        }
    }
    return false;
}

function activeCodes(readout) {
    var codes = [];
    for (var i = 0; i < readout.records.length; i++) {
        if (isTestFailed(readout.records[i].status)) {
            codes.push(readout.records[i].code);
        }
    }
    return codes;
}

// Active DTCs, leaving out skipCode and every code in the known list.
function activeDtcsText(readout, skipCode, known) {
    var parts = [];
    for (var i = 0; i < readout.records.length; i++) {
        var record = readout.records[i];
        if (!isTestFailed(record.status) || codeListed(known, record.code)) {
            continue;
        }
        if (skipCode !== null && sameBytes(record.code, skipCode)) {
            continue;
        }
        parts.push(bytesToText(record.code) + " (0x" + hexByte(record.status) + ")");
    }
    return parts.join(", ");
}

function codesText(codes) {
    var parts = [];
    for (var i = 0; i < codes.length; i++) {
        parts.push(bytesToText(codes[i]));
    }
    return parts.join(", ");
}

function statusText(status) {
    return status < 0 ? "not reported" : "0x" + hexByte(status);
}


// Session, security and data identifiers

function extendedSession() {
    var reply = sendDiag("0x10 0x03");
    return { ok: reply.ok && reply.bytes.length > 1 && reply.bytes[0] === 0x50 && reply.bytes[1] === 0x03, text: reply.text };
}

// Security access through the ARIA product configuration: the documented form first, then
// the form the bench TS library uses.
function unlockLevel(level) {
    var answer;
    try {
        answer = CAN.SecurityAccess(ECU_CHANNEL, level);
    } catch (err) {
        answer = callFailed(err);
    }
    if (apiOk(answer)) {
        return { ok: true, text: apiText(answer) };
    }
    var firstText = apiText(answer);
    try {
        answer = CAN.SecurityAccess(level);
    } catch (err2) {
        answer = callFailed(err2);
    }
    return { ok: apiOk(answer), text: firstText + "; " + apiText(answer) };
}

// Extended session, security level 1, then 2E with the DID and the data.
function writeDid(didText, data, name) {
    var session = extendedSession();
    if (!session.ok) {
        reportCheck("Write " + name + ": extended session", "50 03", session.text, false);
        return false;
    }
    waitMs(100);
    var unlock = unlockLevel(1);
    if (!unlock.ok) {
        reportCheck("Write " + name + ": security access level 1", "0000 (unlocked)", unlock.text, false);
        return false;
    }
    waitMs(100);
    var did = parseHexBytes(didText);
    var reply = sendDiag("0x2E " + didText + " " + bytesToRequest(data));
    var written = reply.ok && reply.bytes.length >= 3 && reply.bytes[0] === 0x6E && reply.bytes[1] === did[0] && reply.bytes[2] === did[1];
    reportCheck("Write " + name + " " + bytesToText(data), "6E " + bytesToText(did), reply.text, written);
    return written;
}

function checkDid(didText, data, name) {
    var did = parseHexBytes(didText);
    var reply = sendDiag("0x22 " + didText);
    var readable = reply.ok && reply.bytes.length >= 3 && reply.bytes[0] === 0x62 && reply.bytes[1] === did[0] && reply.bytes[2] === did[1];
    var value = readable ? reply.bytes.slice(3) : [];
    var same = readable && sameBytes(value, data);
    reportCheck(name + " read back (22 " + bytesToText(did) + ")", bytesToText(data),
        readable ? bytesToText(value) : "not readable: " + reply.text, same);
    return same;
}

// NVM clear routines with security level 0x61, as the Python bench runs them. The DTC clear
// that follows the profile does not depend on them.
function clearNvm() {
    var session = extendedSession();
    var unlock = session.ok ? unlockLevel(0x61) : { ok: false, text: "no extended session: " + session.text };
    if (!unlock.ok) {
        reportNote("NVM clear skipped: security level 0x61 not granted (" + unlock.text + ").");
        return false;
    }
    var allOk = true;
    for (var i = 0; i < NVM_CLEAR_ROUTINES.length; i++) {
        var routine = parseHexBytes(NVM_CLEAR_ROUTINES[i]);
        var reply = sendDiag("0x31 0x01 " + NVM_CLEAR_ROUTINES[i]);
        var done = reply.ok && reply.bytes.length >= 4 && reply.bytes[0] === 0x71 && reply.bytes[1] === 0x01 &&
            reply.bytes[2] === routine[0] && reply.bytes[3] === routine[1];
        reportCheck("NVM clear routine " + bytesToText(routine), "71 01 " + bytesToText(routine), reply.text, done);
        allOk = allOk && done;
    }
    return allOk;
}


// Power

// Switches one power line: "IGN" (ignition) or "BATT" (battery).
function switchPowerLine(line, turnOn) {
    var answer;
    try {
        if (turnOn) {
            answer = PS.PowerOn(line);
        } else {
            answer = PS.PowerOff(line);
        }
    } catch (err) {
        answer = callFailed(err);
    }
    return { ok: apiOk(answer), text: (turnOn ? "PowerOn(" : "PowerOff(") + line + ") " + apiText(answer) };
}

// IGN off, then BATT off; after the off time BATT on, then IGN on. Returns true when every
// power command was accepted.
function ignitionCycle() {
    var lines = IGNITION_CYCLE_WITH_BATT ? ["IGN", "BATT"] : ["IGN"];
    var steps = [];
    var allOk = true;
    var step;
    var i;
    for (i = 0; i < lines.length; i++) {
        step = switchPowerLine(lines[i], false);
        steps.push(step.text);
        allOk = allOk && step.ok;
    }
    waitMs(POWER_OFF_MS);
    for (i = lines.length - 1; i >= 0; i--) {
        step = switchPowerLine(lines[i], true);
        steps.push(step.text);
        allOk = allOk && step.ok;
    }
    waitMs(STARTUP_MS);
    setDiagAddressing();
    reportCheck("Ignition cycle: " + lines.join(" and ") + " off for " + POWER_OFF_MS + " ms, then on, " + STARTUP_MS +
        " ms start-up", "0000 for every power command", steps.join("; "), allOk);
    return allOk;
}


// Frames and the fault-free profile

function holdIntegritySignals(frameName) {
    var frame = FRAMES[frameName];
    var notes = [];
    if (frame.crc.length > 0) {
        notes.push("hold " + frame.crc + ": " + apiText(holdSignal(frame.channel, frameName, frame.crc)));
    }
    if (frame.counter.length > 0) {
        notes.push("hold " + frame.counter + ": " + apiText(holdSignal(frame.channel, frameName, frame.counter)));
    }
    return notes.join(", ");
}

function releaseIntegritySignals(frameName) {
    var frame = FRAMES[frameName];
    if (frame.crc.length > 0) {
        releaseSignal(frame.channel, frameName, frame.crc);
    }
    if (frame.counter.length > 0) {
        releaseSignal(frame.channel, frameName, frame.counter);
    }
}

// Sends the bench VIN in VCU4_FD_1500 VIN_NUMBER. The ECU compares it with F1 90 at start-up,
// so it must be back in the frame before every ignition cycle.
function sendBenchVin() {
    var answer = setSignalBytes(ECU_CHANNEL, VIN_FRAME, VIN_SIGNAL, BENCH_VIN);
    if (apiOk(answer)) {
        return { ok: true, text: "PeriodicChangeSignal: " + apiText(answer) };
    }
    var firstText = apiText(answer);
    answer = setSignalValue(ECU_CHANNEL, VIN_FRAME, VIN_SIGNAL, BENCH_VIN_DECIMAL);
    return { ok: apiOk(answer), text: "PeriodicChangeSignal: " + firstText + "; PeriodicChangeSignalValue: " + apiText(answer) };
}

// Leaves the frame as the bench configuration defines it, whatever state it is in.
function restoreFrame(frameName, cardFrame) {
    var frame = FRAMES[frameName];
    if (cardFrame) {
        removeCardFrame(frame.channel, frame.frameId);
    }
    reloadFrame(frame.channel, frameName);
    releaseIntegritySignals(frameName);
    startFrame(frame.channel, frameName);
    if (frameName === VIN_FRAME) {
        sendBenchVin();
    }
}

function restoreAllFrames() {
    for (var frameName in FRAMES) {
        restoreFrame(frameName, false);
    }
}

// The Python bench fault-free profile with the given variant code: every frame restored,
// NVM clear, ignition cycle, default EOL code and the variant code, bench VIN on CAN and in
// F1 90, ignition cycle, all three read back, DTCs cleared. Returns true when the ignition
// cycles ran and the EOL code, variant code and VIN read back as written.
function applyFaultFreeProfile(variantCode, reason) {
    reportNote("Fault-free profile (" + reason + "): EOL code " + bytesToText(DEFAULT_EOL_CODE) + ", variant code " +
        bytesToText(variantCode) + ", VIN " + bytesToText(BENCH_VIN) + ".");
    restoreAllFrames();
    clearNvm();
    var cycled = ignitionCycle();
    writeDid(EOL_DID, DEFAULT_EOL_CODE, "EOL code");
    writeDid(VARIANT_CODE_DID, variantCode, "variant code");
    var vin = sendBenchVin();
    reportCheck("Bench VIN in " + VIN_FRAME + " " + VIN_SIGNAL, "0000 (signal set)", vin.text, vin.ok);
    waitMs(1000);
    writeDid(VIN_DID, BENCH_VIN, "VIN");
    cycled = ignitionCycle() && cycled;
    var eolOk = checkDid(EOL_DID, DEFAULT_EOL_CODE, "EOL code");
    var variantOk = checkDid(VARIANT_CODE_DID, variantCode, "Variant code");
    var vinOk = checkDid(VIN_DID, BENCH_VIN, "VIN");
    if (!clearDtcs()) {
        reportNote("Clear DTCs (14 FF FF FF) got no positive answer after the fault-free profile.");
    }
    return cycled && eolOk && variantOk && vinOk;
}


// Variant code

function nodeSwitchedOn(variantCode, node) {
    var bit = NODE_VARIANT_BITS[node];
    if (bit === undefined) {
        return true;
    }
    return (variantCode[bit[0]] & bit[1]) === bit[1];
}

function withNodes(variantCode, nodes) {
    var code = variantCode.slice(0);
    for (var i = 0; i < nodes.length; i++) {
        var bit = NODE_VARIANT_BITS[nodes[i]];
        if (bit !== undefined) {
            code[bit[0]] = code[bit[0]] | bit[1];
        }
    }
    return code;
}


// Targets

function makeTarget(kind, frameName, signalName, invalidValue, recoveryValue, dtc) {
    return {
        kind: kind,
        frame: frameName,
        signal: signalName,
        invalidValue: invalidValue,
        recoveryValue: recoveryValue,
        dtc: dtc,
        code: parseHexBytes(dtc)
    };
}

function buildTargets() {
    var list = [];
    var i;
    for (i = 0; i < NODE_ABSENT_TARGETS.length; i++) {
        list.push(makeTarget("NODE_ABSENT", NODE_ABSENT_TARGETS[i][0], "", null, null, NODE_ABSENT_TARGETS[i][1]));
    }
    for (i = 0; i < MESSAGE_TIMEOUT_TARGETS.length; i++) {
        list.push(makeTarget("MESSAGE_TIMEOUT", MESSAGE_TIMEOUT_TARGETS[i][0], "", null, null, MESSAGE_TIMEOUT_TARGETS[i][1]));
    }
    for (i = 0; i < MESSAGE_CONTENT_TARGETS.length; i++) {
        var frameName = MESSAGE_CONTENT_TARGETS[i][0];
        list.push(makeTarget("CRC", frameName, FRAMES[frameName].crc, null, null, MESSAGE_CONTENT_TARGETS[i][1]));
    }
    for (i = 0; i < MESSAGE_CONTENT_TARGETS.length; i++) {
        var counterFrame = MESSAGE_CONTENT_TARGETS[i][0];
        list.push(makeTarget("ALIVE_COUNTER", counterFrame, FRAMES[counterFrame].counter, null, null, MESSAGE_CONTENT_TARGETS[i][1]));
    }
    for (i = 0; i < DLC_TARGETS.length; i++) {
        list.push(makeTarget("DLC", DLC_TARGETS[i][0], "", null, null, DLC_TARGETS[i][1]));
    }
    for (i = 0; i < SIGNAL_CONTENT_TARGETS.length; i++) {
        var row = SIGNAL_CONTENT_TARGETS[i];
        list.push(makeTarget("SIGNAL_CONTENT", row[0], row[1], row[2], row[3], row[4]));
    }
    return list;
}

function selectTargets(list) {
    var selected = [];
    for (var i = 0; i < list.length; i++) {
        var target = list[i];
        if (RUN_KINDS[target.kind] !== true) {
            continue;
        }
        if (ONLY_FRAME.length > 0 && target.frame !== ONLY_FRAME) {
            continue;
        }
        if (FRAMES[target.frame] === undefined) {
            reportNote("Skipped: " + target.frame + " is not in the frame table.");
            continue;
        }
        selected.push(target);
    }
    return selected;
}

function targetTitle(target) {
    var signalPart = target.signal.length > 0 ? " " + target.signal : "";
    return KIND_NAMES[target.kind] + ", " + target.frame + signalPart + ", DTC " + target.dtc;
}

function faultText(target) {
    var frame = FRAMES[target.frame];
    if (target.kind === "NODE_ABSENT" || target.kind === "MESSAGE_TIMEOUT") {
        return "stop " + target.frame;
    }
    if (target.kind === "CRC") {
        return "hold the CRC " + target.signal + " of " + target.frame;
    }
    if (target.kind === "ALIVE_COUNTER") {
        return "hold the alive counter " + target.signal + " of " + target.frame;
    }
    if (target.kind === "DLC") {
        return "send " + target.frame + " with " + shortLength(frame.dlc) + " data bytes instead of " + frame.dlc;
    }
    return "send the invalid value " + target.invalidValue + " in " + target.signal + " of " + target.frame;
}

function healText(target) {
    if (target.kind === "NODE_ABSENT" || target.kind === "MESSAGE_TIMEOUT") {
        return "send " + target.frame + " again";
    }
    if (target.kind === "CRC" || target.kind === "ALIVE_COUNTER") {
        return "compute " + target.signal + " again";
    }
    if (target.kind === "DLC") {
        return "send the default " + target.frame + " again";
    }
    return "send the valid value " + target.recoveryValue + " in " + target.signal;
}

function nodesOf(targets) {
    var nodes = [];
    for (var i = 0; i < targets.length; i++) {
        addUnique(nodes, FRAMES[targets[i].frame].node);
    }
    return nodes;
}

// The node absent target of a node: its frame, DTC and qualification time.
function nodeAbsentInfo(node) {
    for (var i = 0; i < NODE_ABSENT_TARGETS.length; i++) {
        var frameName = NODE_ABSENT_TARGETS[i][0];
        if (FRAMES[frameName].node === node) {
            return {
                frame: frameName,
                dtc: NODE_ABSENT_TARGETS[i][1],
                code: parseHexBytes(NODE_ABSENT_TARGETS[i][1]),
                qualifyMs: FAULT_COUNTS.NODE_ABSENT[0] * FRAMES[frameName].period
            };
        }
    }
    return null;
}


// Faults

// Creates the fault. startMs is taken right after the call that creates it.
function applyFault(target) {
    var frame = FRAMES[target.frame];
    var result = { ok: false, startMs: 0, text: "", cardFrame: false };
    var answer;
    if (target.kind === "NODE_ABSENT" || target.kind === "MESSAGE_TIMEOUT") {
        answer = stopFrame(frame.channel, target.frame);
        result.startMs = nowMs();
        result.ok = apiOk(answer);
        result.text = "PeriodicDisableFrame: " + apiText(answer);
    } else if (target.kind === "CRC" || target.kind === "ALIVE_COUNTER") {
        answer = holdSignal(frame.channel, target.frame, target.signal);
        result.startMs = nowMs();
        result.ok = apiOk(answer);
        result.text = "DisableDynamicSignal: " + apiText(answer);
    } else if (target.kind === "SIGNAL_CONTENT") {
        answer = setSignalValue(frame.channel, target.frame, target.signal, target.invalidValue);
        result.startMs = nowMs();
        result.ok = apiOk(answer);
        result.text = "PeriodicChangeSignalValue: " + apiText(answer);
    } else {
        // The CRC and alive counter are held so the bench does not write them into the short payload.
        var held = holdIntegritySignals(target.frame);
        var data = zeroBytes(shortLength(frame.dlc));
        answer = changeFrameData(frame.channel, target.frame, data);
        if (apiOk(answer)) {
            result.startMs = nowMs();
            result.ok = true;
            result.text = "PeriodicChangeDataAndName: " + apiText(answer);
        } else {
            // Fallback: stop the simulated frame and send a short copy on its identifier.
            var firstText = apiText(answer);
            var stopAnswer = stopFrame(frame.channel, target.frame);
            answer = addCardFrame(frame.channel, frame.frameId, frame.period, data, frame.isFd);
            result.startMs = nowMs();
            result.ok = apiOk(answer);
            result.cardFrame = result.ok;
            result.text = "PeriodicChangeDataAndName: " + firstText + "; PeriodicDisableFrame: " + apiText(stopAnswer) +
                "; SetPeriodicFrame: " + apiText(answer);
        }
        if (held.length > 0) {
            result.text = result.text + "; " + held;
        }
    }
    return result;
}

// Removes the fault. startMs is taken right after the frame is valid again.
function removeFault(target, applied) {
    var frame = FRAMES[target.frame];
    var result = { ok: false, startMs: 0, text: "" };
    var answer;
    if (target.kind === "NODE_ABSENT" || target.kind === "MESSAGE_TIMEOUT") {
        var reloadAnswer = reloadFrame(frame.channel, target.frame);
        answer = startFrame(frame.channel, target.frame);
        result.startMs = nowMs();
        result.ok = apiOk(answer);
        result.text = "ReloadDefaultPeriodicFrame: " + apiText(reloadAnswer) + "; PeriodicEnableFrame: " + apiText(answer);
    } else if (target.kind === "CRC" || target.kind === "ALIVE_COUNTER") {
        answer = releaseSignal(frame.channel, target.frame, target.signal);
        result.startMs = nowMs();
        result.ok = apiOk(answer);
        result.text = "EnableDynamicSignal: " + apiText(answer);
    } else if (target.kind === "SIGNAL_CONTENT") {
        answer = setSignalValue(frame.channel, target.frame, target.signal, target.recoveryValue);
        result.startMs = nowMs();
        result.ok = apiOk(answer);
        result.text = "PeriodicChangeSignalValue: " + apiText(answer);
    } else {
        var removeText = "";
        if (applied.cardFrame) {
            removeText = "RemovePeriodicFrame: " + apiText(removeCardFrame(frame.channel, frame.frameId)) + "; ";
        }
        answer = reloadFrame(frame.channel, target.frame);
        releaseIntegritySignals(target.frame);
        var startAnswer = startFrame(frame.channel, target.frame);
        result.startMs = nowMs();
        result.ok = apiOk(answer) && (!applied.cardFrame || apiOk(startAnswer));
        result.text = removeText + "ReloadDefaultPeriodicFrame: " + apiText(answer) + "; PeriodicEnableFrame: " + apiText(startAnswer);
    }
    return result;
}


// Measurement

// Polls the DTC until it is qualified (wantActive) or healed, or the limit passes.
// resolutionMs: from the request of the last read that still showed the old state to the
// answer that showed the new one. The change happened inside that time.
function measureDtc(code, wantActive, startMs, limitMs) {
    var outcome = { reached: false, elapsedMs: 0, status: -1, resolutionMs: 0, failedReads: 0, others: "", lastText: "" };
    var lastOldStateRequestMs = startMs;
    var failedInRow = 0;
    while (true) {
        var requestMs = nowMs();
        var readout = readDtcs();
        var answerMs = nowMs();
        outcome.elapsedMs = answerMs - startMs;
        if (readout.ok) {
            failedInRow = 0;
            var record = findDtc(readout, code);
            outcome.status = record === null ? -1 : record.status;
            outcome.others = activeDtcsText(readout, code, []);
            if (wantActive && record !== null && isQualified(record.status)) {
                outcome.reached = true;
            }
            if (!wantActive && (record === null || !isTestFailed(record.status))) {
                outcome.reached = true;
            }
            if (outcome.reached) {
                outcome.resolutionMs = answerMs - lastOldStateRequestMs;
                return outcome;
            }
            lastOldStateRequestMs = requestMs;
        } else {
            outcome.failedReads = outcome.failedReads + 1;
            outcome.lastText = readout.text;
            failedInRow = failedInRow + 1;
            if (failedInRow >= MAX_FAILED_READS) {
                return outcome;
            }
        }
        if (outcome.elapsedMs > limitMs) {
            return outcome;
        }
        waitMs(POLL_PAUSE_MS);
    }
}

function measureLimit(nominalMs) {
    return Math.round(nominalMs * 1.5) + 2000;
}

// Grades one time against nominal minus 10 percent .. nominal plus 10 percent. With
// MEASUREMENT_ALLOWANCE both limits are widened by the clock step and the upper one also by
// the read resolution. Returns the verdict and the summary text.
function gradeTime(name, outcome, nominalMs) {
    var stepMs = MEASUREMENT_ALLOWANCE ? clockStepMs : 0;
    var readMs = MEASUREMENT_ALLOWANCE ? outcome.resolutionMs : 0;
    var lowMs = Math.round(nominalMs * (100 - TOLERANCE_PERCENT) / 100) - stepMs;
    var highMs = Math.round(nominalMs * (100 + TOLERANCE_PERCENT) / 100) + readMs + stepMs;
    var expected = lowMs + " to " + highMs + " ms (nominal " + nominalMs + " ms, minus " + TOLERANCE_PERCENT +
        " percent to plus " + TOLERANCE_PERCENT + " percent";
    if (MEASUREMENT_ALLOWANCE) {
        expected = expected + ", both limits widened by the " + stepMs + " ms clock step, upper limit also by the " +
            readMs + " ms read resolution)";
    } else {
        expected = expected + ", no measurement allowance)";
    }
    var obtained;
    var passed = false;
    var summary;
    if (outcome.reached) {
        passed = outcome.elapsedMs >= lowMs && outcome.elapsedMs <= highMs;
        obtained = outcome.elapsedMs + " ms";
        summary = outcome.elapsedMs + " ms (" + lowMs + " to " + highMs + ")";
    } else if (outcome.failedReads >= MAX_FAILED_READS) {
        obtained = "no valid DTC answer for " + outcome.failedReads + " reads (" + outcome.lastText + ")";
        summary = "no DTC answer";
    } else {
        obtained = "not seen within " + outcome.elapsedMs + " ms";
        summary = "not seen within " + outcome.elapsedMs + " ms";
    }
    if (outcome.others.length > 0) {
        obtained = obtained + "; other active DTCs: " + outcome.others;
    }
    reportCheck(name, expected, obtained, passed);
    return { passed: passed, summary: summary };
}

function checkStatus(name, outcome, expectedStatus, meaning) {
    var passed = outcome.status === expectedStatus;
    reportCheck(name, "0x" + hexByte(expectedStatus) + " (" + meaning + ")", statusText(outcome.status), passed);
    return passed;
}


// CAN log of one target

function startTargetLog(target, number, stamp) {
    var frame = FRAMES[target.frame];
    var path = LOG_FOLDER + "CANC_Fault_Timing_" + stamp + "_" + twoDigits(number) + "_" + target.kind + "_" + target.frame + ".log";
    var ids = [frame.frameId, DIAG_REQUEST_ID, DIAG_RESPONSE_ID];
    var answer;
    try {
        if (frame.channel === ECU_CHANNEL) {
            answer = CAN.StartLoggingToFile(ECU_CHANNEL, path, ids);
        } else {
            answer = CAN.StartLoggingToFile([ECU_CHANNEL, frame.channel], path, ids);
        }
    } catch (err) {
        answer = callFailed(err);
    }
    if (apiOk(answer)) {
        return path;
    }
    reportNote("CAN log not started (" + apiText(answer) + "); the timing checks go on without it.");
    return "";
}

function stopTargetLog(path) {
    if (path.length === 0) {
        return;
    }
    try {
        CAN.StopLoggingToFile(path);
        RESULT.InsertFile(path, "CAN log of this target");
    } catch (err) {
        reportNote("CAN log " + path + " not stopped cleanly: " + describeError(err));
    }
}


// Bench state

// Clears the DTCs, waits for the node absent time of the given nodes, then reports whether
// the ECU receives each node and whether any DTC is active. Returns the nodes not received
// (node name to reason) and the active DTCs: bench faults the later checks do not count again.
function checkBenchState(nodes, label) {
    var state = { missing: {}, active: [] };
    var waitTime = 0;
    var i;
    var info;
    for (i = 0; i < nodes.length; i++) {
        info = nodeAbsentInfo(nodes[i]);
        if (info !== null && info.qualifyMs > waitTime) {
            waitTime = info.qualifyMs;
        }
    }
    waitTime = Math.max(AFTER_CLEAR_MS, Math.round(waitTime * (100 + TOLERANCE_PERCENT) / 100) + 1000);
    reportNote("Bench check " + label + ": DTCs cleared, " + waitTime + " ms for any fault to set.");
    var readout = clearAndRead(waitTime);
    if (!readout.ok) {
        reportCheck("Bench fault free " + label, "no active DTC", "DTC read failed: " + readout.text, false);
        for (i = 0; i < nodes.length; i++) {
            state.missing[nodes[i]] = "the DTC read failed in the bench check " + label;
        }
        return state;
    }
    for (i = 0; i < nodes.length; i++) {
        info = nodeAbsentInfo(nodes[i]);
        if (info === null) {
            continue;
        }
        var record = findDtc(readout, info.code);
        var received = record === null || !isTestFailed(record.status);
        reportCheck("ECU receives " + nodes[i] + " (" + info.frame + ")", "node absent DTC " + info.dtc + " not active",
            statusText(record === null ? -1 : record.status), received);
        if (!received) {
            state.missing[nodes[i]] = "node absent DTC " + info.dtc + " is active: the ECU does not receive " + info.frame +
                " on channel " + FRAMES[info.frame].channel;
        }
    }
    state.active = activeCodes(readout);
    var activeText = activeDtcsText(readout, null, []);
    reportCheck("Bench fault free " + label, "no active DTC", activeText.length > 0 ? activeText : "none", activeText.length === 0);
    clearDtcs();
    return state;
}

// After a test: DTCs cleared, then no new active DTC for as long as the tested fault needs
// to qualify. If one shows, the profile is applied again and the bench checked once more; a
// DTC still active then is counted as a bench fault from that point, so it is reported once
// instead of after every later test. Returns true when the bench was fault free without the
// recovery.
function checkFaultFreeAfter(qualifyMs, context) {
    var waitTime = Math.max(AFTER_CLEAR_MS, Math.round(qualifyMs * (100 + TOLERANCE_PERCENT) / 100) + 500);
    var known = context.baseline.length > 0 ? "; not counted, active since the bench check: " + codesText(context.baseline) : "";
    var expected = "no new active DTC " + waitTime + " ms after clearing the DTCs" + known;
    var readout = clearAndRead(waitTime);
    var found = readout.ok ? activeDtcsText(readout, null, context.baseline) : "DTC read failed: " + readout.text;
    var clean = readout.ok && found.length === 0;
    reportCheck("Bench fault free after the test", expected, clean ? "none" : found, clean);
    if (clean) {
        return true;
    }
    reportNote("Recovery: every frame restored and the fault-free profile applied again.");
    applyFaultFreeProfile(context.variantCode, "recovery after a test");
    readout = clearAndRead(waitTime);
    found = readout.ok ? activeDtcsText(readout, null, context.baseline) : "DTC read failed: " + readout.text;
    var recovered = readout.ok && found.length === 0;
    reportCheck("Bench fault free after the recovery", expected, recovered ? "none" : found, recovered);
    if (!recovered && readout.ok) {
        var still = activeCodes(readout);
        for (var i = 0; i < still.length; i++) {
            if (!codeListed(context.baseline, still[i])) {
                context.baseline.push(still[i]);
            }
        }
        reportNote("Still active after the recovery, so counted as bench faults from here on: " + found + ".");
    }
    return false;
}


// One target

function newSummary(target) {
    return { title: targetTitle(target), verdict: "FAIL", qualifyText: "not measured", healText: "not measured", note: "" };
}

function addNote(summary, text) {
    summary.note = summary.note.length > 0 ? summary.note + "; " + text : text;
}

function skipTarget(target, number, total, reason) {
    var summary = newSummary(target);
    summary.verdict = "NOT RUN";
    summary.note = reason;
    reportNote("Target " + number + " of " + total + ": " + summary.title);
    reportCheck("Run " + summary.title, "the target runs", "not run: " + reason, false);
    return summary;
}

function runTarget(target, number, total, stamp, context) {
    var frame = FRAMES[target.frame];
    var counts = FAULT_COUNTS[target.kind];
    var qualifyMs = counts[0] * frame.period;
    var healMs = counts[1] * frame.period;
    var summary = newSummary(target);
    var applied = null;
    var logPath = "";
    var allPassed = true;
    reportNote("Target " + number + " of " + total + ": " + summary.title);
    reportNote("Fault: " + faultText(target) + ". Frame period " + frame.period + " ms: " + counts[0] + " frames to qualify (" +
        qualifyMs + " ms), " + counts[1] + " frames to heal (" + healMs + " ms).");
    try {
        // Precondition: frame as configured, DTCs cleared, the DTC under test not active.
        restoreFrame(target.frame, false);
        waitMs(Math.max(SETTLE_MS, 2 * frame.period));
        if (!clearDtcs()) {
            reportNote("Clear DTCs (14 FF FF FF) got no positive answer; the precondition read decides.");
        }
        waitMs(AFTER_CLEAR_MS);
        var before = readDtcs();
        if (!before.ok) {
            reportCheck("Read DTCs before the fault", "59 02 followed by the DTC records", before.text, false);
            addNote(summary, "DTC read failed before the fault");
            return summary;
        }
        var existing = findDtc(before, target.code);
        var notActive = existing === null || !isTestFailed(existing.status);
        reportCheck("DTC " + target.dtc + " not active before the fault", "not reported, or test failed bit clear",
            statusText(existing === null ? -1 : existing.status), notActive);
        if (!notActive) {
            addNote(summary, "DTC already active before the fault");
            return summary;
        }
        var otherBefore = activeDtcsText(before, target.code, context.baseline);
        if (otherBefore.length > 0) {
            reportNote("Other active DTCs before the fault (not graded here): " + otherBefore);
        }

        if (LOG_EACH_TARGET) {
            logPath = startTargetLog(target, number, stamp);
        }

        // Fault and qualification.
        applied = applyFault(target);
        reportCheck("Create fault: " + faultText(target), "the bench accepts the command", applied.text, applied.ok);
        if (!applied.ok) {
            addNote(summary, "the fault could not be created on the bench");
            return summary;
        }
        var qualify = measureDtc(target.code, true, applied.startMs, measureLimit(qualifyMs));
        var qualifyGrade = gradeTime("Qualification time of " + target.dtc, qualify, qualifyMs);
        summary.qualifyText = qualifyGrade.summary;
        allPassed = allPassed && qualifyGrade.passed;
        if (qualify.reached) {
            allPassed = checkStatus("Status of " + target.dtc + " once qualified", qualify, DTC_STATUS_ACTIVE,
                "test failed, confirmed, no warning lamp") && allPassed;
        }

        // Heal and dequalification. Not timed when the DTC never qualified.
        var removed = removeFault(target, applied);
        reportCheck("Remove fault: " + healText(target), "the bench accepts the command", removed.text, removed.ok);
        allPassed = allPassed && removed.ok;
        if (qualify.reached && removed.ok) {
            var heal = measureDtc(target.code, false, removed.startMs, measureLimit(healMs));
            var healGrade = gradeTime("Dequalification time of " + target.dtc, heal, healMs);
            summary.healText = healGrade.summary;
            allPassed = allPassed && healGrade.passed;
            if (heal.reached) {
                allPassed = checkStatus("Status of " + target.dtc + " once healed", heal, DTC_STATUS_HEALED,
                    "test failed this cycle, confirmed") && allPassed;
            }
        } else if (!qualify.reached) {
            addNote(summary, "the DTC did not qualify, so the heal was not timed");
        }
        summary.verdict = allPassed ? "PASS" : "FAIL";
    } catch (err) {
        reportCheck("Run " + summary.title, "no script error", describeError(err), false);
        summary.verdict = "FAIL";
        addNote(summary, "script error: " + describeError(err));
    } finally {
        restoreFrame(target.frame, applied !== null && applied.cardFrame);
        stopTargetLog(logPath);
        try {
            if (!checkFaultFreeAfter(qualifyMs, context)) {
                summary.verdict = "FAIL";
                addNote(summary, "the bench was not fault free after the test");
            }
        } catch (err2) {
            reportCheck("Bench fault free after the test", "no script error", describeError(err2), false);
            summary.verdict = "FAIL";
        }
    }
    return summary;
}

function runOrSkip(target, number, total, missing, stamp, context) {
    var reason = missing[FRAMES[target.frame].node];
    if (reason !== undefined) {
        return skipTarget(target, number, total, reason);
    }
    return runTarget(target, number, total, stamp, context);
}


// Run

function reportSummary(summaries) {
    var passed = 0;
    var failed = 0;
    var notRun = 0;
    reportNote("Summary");
    for (var i = 0; i < summaries.length; i++) {
        var item = summaries[i];
        if (item.verdict === "PASS") {
            passed = passed + 1;
        } else if (item.verdict === "NOT RUN") {
            notRun = notRun + 1;
        } else {
            failed = failed + 1;
        }
        var notePart = item.note.length > 0 ? ". " + item.note : "";
        reportNote(item.verdict + ": " + item.title + ". Qualification " + item.qualifyText + ", dequalification " +
            item.healText + notePart + ".");
    }
    reportCheck("CAN fault timing, all targets", summaries.length + " targets pass",
        passed + " passed, " + failed + " failed, " + notRun + " not run",
        summaries.length > 0 && failed === 0 && notRun === 0);
}

function runAllTargets() {
    var summaries = [];
    var stamp = dateStamp();
    var context = { baseline: [], variantCode: DEFAULT_VARIANT_CODE };
    var defaultNodes = [];
    var nodesSwitchedOn = false;
    try {
        try {
            RESULT.ResultName = "CANC_Fault_Quali_Dequali_Timing_";
        } catch (err) {
            reportNote("Result file name not set: " + describeError(err));
        }
        reportNote("CAN-C fault qualification and dequalification timing, M310_M314_M110, run " + stamp + ".");
        clockStepMs = measureClockStep();
        if (MEASUREMENT_ALLOWANCE) {
            reportNote("Pass window: nominal (fault list count x frame period) minus " + TOLERANCE_PERCENT + " percent to plus " +
                TOLERANCE_PERCENT + " percent, both limits widened by the clock step of this PC (" + clockStepMs +
                " ms), the upper limit also by the read resolution of each measurement.");
        } else {
            reportNote("Pass window: nominal (fault list count x frame period) minus " + TOLERANCE_PERCENT + " percent to plus " +
                TOLERANCE_PERCENT + " percent, no measurement allowance.");
        }
        setDiagAddressing();
        var firstRead = readDtcs();
        if (!firstRead.ok) {
            ignitionCycle();
            firstRead = readDtcs();
        }
        reportCheck("ECU answers the DTC read 19 02 0B", "59 02 followed by the DTC records", firstRead.text, firstRead.ok);
        if (!firstRead.ok) {
            reportNote("Stopped: without DTC reads no time can be measured. Check the ECU power and diagnostic channel " +
                ECU_CHANNEL + ".");
            return;
        }
        if (!applyFaultFreeProfile(DEFAULT_VARIANT_CODE, "start of the run")) {
            reportNote("The fault-free profile did not read back as written; the tests still run and each reports its own state.");
        }

        var targets = selectTargets(buildTargets());
        var ready = [];
        var later = [];
        var laterNodes = [];
        var i;
        for (i = 0; i < targets.length; i++) {
            var node = FRAMES[targets[i].frame].node;
            if (nodeSwitchedOn(DEFAULT_VARIANT_CODE, node)) {
                ready.push(targets[i]);
            } else {
                later.push(targets[i]);
                addUnique(laterNodes, node);
            }
        }
        defaultNodes = nodesOf(ready);
        reportNote(targets.length + " targets selected: " + ready.length + " run with the default variant code, " + later.length +
            " need " + (laterNodes.length > 0 ? laterNodes.join(" and ") : "no other node") + " switched on.");
        var total = targets.length;
        var number = 0;

        var state = checkBenchState(defaultNodes, "before the tests");
        context.baseline = state.active;
        for (i = 0; i < ready.length; i++) {
            number = number + 1;
            summaries.push(runOrSkip(ready[i], number, total, state.missing, stamp, context));
        }

        if (later.length > 0) {
            var skipReason = "";
            if (!ENABLE_NODES_IN_VARIANT_CODE) {
                skipReason = laterNodes.join(" and ") + " not switched on in the variant code (ENABLE_NODES_IN_VARIANT_CODE is false)";
            } else {
                var nodesCode = withNodes(DEFAULT_VARIANT_CODE, laterNodes);
                nodesSwitchedOn = true;
                context.variantCode = nodesCode;
                if (!applyFaultFreeProfile(nodesCode, "switch on " + laterNodes.join(" and "))) {
                    skipReason = "the profile with " + laterNodes.join(" and ") + " switched on did not read back as written";
                }
            }
            var laterState = { missing: {}, active: [] };
            if (skipReason.length === 0) {
                laterState = checkBenchState(laterNodes, "with " + laterNodes.join(" and ") + " switched on");
            }
            context.baseline = laterState.active;
            for (i = 0; i < later.length; i++) {
                number = number + 1;
                if (skipReason.length > 0) {
                    summaries.push(skipTarget(later[i], number, total, skipReason));
                } else {
                    summaries.push(runOrSkip(later[i], number, total, laterState.missing, stamp, context));
                }
            }
        }
    } catch (err2) {
        reportCheck("CAN fault timing run", "no script error", describeError(err2), false);
    } finally {
        try {
            if (nodesSwitchedOn) {
                applyFaultFreeProfile(DEFAULT_VARIANT_CODE, "end of the run, default variant code");
            }
            if (summaries.length > 0) {
                checkBenchState(defaultNodes, "at the end of the run");
            }
        } catch (err3) {
            reportCheck("Fault-free bench at the end of the run", "no script error", describeError(err3), false);
        }
        reportSummary(summaries);
    }
}

runAllTargets();
