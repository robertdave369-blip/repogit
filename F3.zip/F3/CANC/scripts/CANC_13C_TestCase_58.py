# Author: Kris
#
# Test case  : CANC_13C_TestCase_58 (Codebeamer ID 36753962)
# Workbook   : M314 CANC 13C signal and message spec test cases.xlsx
# Objective  : Verify SRS1_FD_10 is transmitted after IGN ON with DBC length 64.
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_RX_MESSAGE_CONFIG,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
)


def run_test():
    tc_id = '36753962'
    tc_name = 'CANC_13C_TestCase_58'
    tc_desc = (
        'Verify SRS1_FD_10 is transmitted after IGN ON with DBC length 64.'
    )
    automation = 'Automatic'

    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [fd_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_fd_count = sum(1 for frame_data in presence2_frames if frame_data.id == fd_id)
        RESULT.InterpretEqualResultRange(
            f"{fd_frame} is transmitted (frames in the window)",
            presence2_fd_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Monitor consecutive SRS1_FD_10 frames')
        dlc1_ids = [fd_id]
        dlc1_file = os.path.splitext(log_path)[0] + '_srs1_fd_10_dlc_1.txt'
        dlc1_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_srs1_fd_10_dlc_1', filepath=dlc1_file,
            listOption=dlc1_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(dlc1_logger)
        dlc1_frames = []
        if os.path.isfile(dlc1_file):
            with open(dlc1_file, encoding='utf-8', errors='replace') as dlc1_log:
                dlc1_fields = [line.split(',', 2) for line in dlc1_log if ' id=' in line and line.count(',') >= 2]
            dlc1_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in dlc1_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(dlc1_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        dlc1_frames = [frame_data for frame_data in dlc1_frames if frame_data.id in dlc1_ids]
        RESULT.InterpretEqualResultRange(f"{fd_frame} frames captured", len(dlc1_frames),
                                         CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        RESULT.InterpretEqualResult(f"{fd_frame} DLC", sorted({len(frame_data.payload) for frame_data in dlc1_frames}),
                                    [CAN_RX_MESSAGE_CONFIG[fd_frame]['dlc']])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Repeat after an IGN cycle')
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        dlc2_ids = [fd_id]
        dlc2_file = os.path.splitext(log_path)[0] + '_srs1_fd_10_dlc_2.txt'
        dlc2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_srs1_fd_10_dlc_2', filepath=dlc2_file,
            listOption=dlc2_ids, channel_names=[CAN_FD_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(dlc2_logger)
        dlc2_frames = []
        if os.path.isfile(dlc2_file):
            with open(dlc2_file, encoding='utf-8', errors='replace') as dlc2_log:
                dlc2_fields = [line.split(',', 2) for line in dlc2_log if ' id=' in line and line.count(',') >= 2]
            dlc2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in dlc2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(dlc2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        dlc2_frames = [frame_data for frame_data in dlc2_frames if frame_data.id in dlc2_ids]
        RESULT.InterpretEqualResultRange(f"{fd_frame} frames captured", len(dlc2_frames),
                                         CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        RESULT.InterpretEqualResult(f"{fd_frame} DLC", sorted({len(frame_data.payload) for frame_data in dlc2_frames}),
                                    [CAN_RX_MESSAGE_CONFIG[fd_frame]['dlc']])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            pass
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
