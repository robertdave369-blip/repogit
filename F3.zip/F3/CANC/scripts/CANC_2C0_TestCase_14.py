# Author: Kris
#
# Test case  : CANC_2C0_TestCase_14 (Codebeamer ID 35736861)
# Workbook   : M314 CANC 2C0 signal and message spec test cases.xlsx
# Objective  : To Check value of Even parity signal when WL turns on due to active dtc
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_FRAME_PRESENCE_CYCLES,
    CANC_LOOP_FAULT_SQUIB,
    CANC_PERIODICITY_SAMPLE_FRAMES,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_RX_MESSAGE_CONFIG,
    CAN_SIGNAL_START_BIT,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_HS_CHANNEL_NAME,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.squibs_config import (
    DTC_Squib_FaultCode,
    SquibNumber,
    Squib_FaultTypeCode,
    Squib_Fault_Description,
    squib_fault_time,
)


def run_test():
    tc_id = '35736861'
    tc_name = 'CANC_2C0_TestCase_14'
    tc_desc = (
        'To Check value of Even parity signal when WL turns on due to active dtc'
    )
    automation = 'Automatic'

    parity_key = 'SRS1_20_EVEN_PARITY_BIT'
    parity_def = MAH_CAN_SIGNAL_DEFS[parity_key]
    parity_id = CAN_RX_MESSAGE_CONFIG[parity_def['frame']]['frame_ID']
    # EVEN_PARITY_BIT makes the count of ones in bits 0 to (its start bit - 1) of byte 0 even.
    parity_mask = (1 << CAN_SIGNAL_START_BIT[parity_key]) - 1
    parity_odd = parity_def['State_Values']['ODD/Default']
    parity_even = parity_def['State_Values']['Even']
    loop_device = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}"
    loop_dtc = DTC_Squib_FaultCode[CANC_LOOP_FAULT_SQUIB] + " " + Squib_FaultTypeCode['Open']
    loop_qualify_ms = int(squib_fault_time['Qualification_Time'] * (1 + squib_fault_time['Qualification_Tolerance'] / 100))
    fd_frame = 'SRS1_FD_10'
    hs_frame = 'SRS1_20'
    fd_id = CAN_RX_MESSAGE_CONFIG[fd_frame]['frame_ID']
    hs_id = CAN_RX_MESSAGE_CONFIG[hs_frame]['frame_ID']
    fd_period_ms = CAN_RX_MESSAGE_CONFIG[fd_frame]['periodicity']
    hs_period_ms = CAN_RX_MESSAGE_CONFIG[hs_frame]['periodicity']
    presence_window_ms = (CANC_PERIODICITY_SAMPLE_FRAMES + 4) * max(fd_period_ms, hs_period_ms)
    lamp_on = MAH_CAN_SIGNAL_DEFS['INDC_SRS']['State_Values']['Lamp ON']

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([], [fd_id, hs_id]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Monitor the ECU frames')
        presence2_ids = [hs_id]
        presence2_file = os.path.splitext(log_path)[0] + '_monitor.txt'
        presence2_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_monitor', filepath=presence2_file,
            listOption=presence2_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(presence2_logger)
        presence2_frames = []
        if os.path.isfile(presence2_file):
            with open(presence2_file, encoding='utf-8', errors='replace') as presence2_log:
                presence2_fields = [line.split(',', 2) for line in presence2_log if ' id=' in line and line.count(',') >= 2]
            presence2_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in presence2_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(presence2_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        presence2_frames = [frame_data for frame_data in presence2_frames if frame_data.id in presence2_ids]
        presence2_hs_count = sum(1 for frame_data in presence2_frames if frame_data.id == hs_id)
        RESULT.InterpretEqualResultRange(
            f"{hs_frame} is transmitted (frames in the window)",
            presence2_hs_count, CANC_FRAME_PRESENCE_CYCLES, float('inf'))
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Verify EVEN_PARITY_BIT with no fault')
        idle_ids = [hs_id]
        idle_file = os.path.splitext(log_path)[0] + '_parity_idle.txt'
        idle_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_parity_idle', filepath=idle_file,
            listOption=idle_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(idle_logger)
        idle_frames = []
        if os.path.isfile(idle_file):
            with open(idle_file, encoding='utf-8', errors='replace') as idle_log:
                idle_fields = [line.split(',', 2) for line in idle_log if ' id=' in line and line.count(',') >= 2]
            idle_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in idle_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(idle_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        idle_frames = [frame_data for frame_data in idle_frames if frame_data.id in idle_ids]
        idle_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in idle_frames if frame_data.id == parity_id]
        idle_errors = [row for row in idle_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str(idle_errors[:5]), "[]")
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT", sorted({row[1] for row in idle_rows}), [parity_odd])
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Create a loop fault and verify EVEN_PARITY_BIT')
        SQUIB.SendRequest(loop_device, Squib_Fault_Description['Open'])
        Wait(loop_qualify_ms)
        Read_DTC(
            'Loop open DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      loop_dtc, DTC_status['DTC_active']]),
            Read_DTC_Req_CANC)
        check_started = time.monotonic()
        for check_key, check_expected in [('SRS1_20_INDC_SRS', lamp_on)]:
            check_def = MAH_CAN_SIGNAL_DEFS[check_key]
            while True:
                check_text = str(CAN.GetSignalFromFrame(check_def['bus'], check_def['frame'], check_def['signal'])).strip()
                try:
                    check_value = int(check_text, 16) if check_text.lower().startswith("0x") else int(float(check_text))
                except ValueError:
                    check_value = check_text
                if str(check_value) == str(check_expected) or time.monotonic() - check_started >= (PROVEOUT_COMPLETION_TIME) / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult('Warning lamp ON with the loop fault: ' + f"{check_def['frame']} {check_def['signal']}",
                                        str(check_value), str(check_expected))
        fault_ids = [hs_id]
        fault_file = os.path.splitext(log_path)[0] + '_parity_fault.txt'
        fault_logger = CAN.StartLoggingToFile(
            TestCase_ID=tc_name + '_parity_fault', filepath=fault_file,
            listOption=fault_ids, channel_names=[CAN_HS_CHANNEL_NAME])
        Wait(presence_window_ms)
        CAN.StopLoggingToFile(fault_logger)
        fault_frames = []
        if os.path.isfile(fault_file):
            with open(fault_file, encoding='utf-8', errors='replace') as fault_log:
                fault_fields = [line.split(',', 2) for line in fault_log if ' id=' in line and line.count(',') >= 2]
            fault_frames = [
                SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                id=int(fields[1].split('=')[1], 16),
                                payload=bytearray.fromhex(fields[2].strip()))
                for fields in fault_fields]
        else:
            RESULT.LogCustomAction(f"CAN log {os.path.basename(fault_file)} written", "File present",
                                   "File missing: no frames to evaluate", False)
        fault_frames = [frame_data for frame_data in fault_frames if frame_data.id in fault_ids]
        fault_rows = [(frame_data.payload[0] & parity_mask,
                     extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[parity_key], parity_def['bit_length']))
                    for frame_data in fault_frames if frame_data.id == parity_id]
        fault_errors = [row for row in fault_rows if (bin(row[0]).count("1") + row[1]) % 2]
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT keeps byte 0 even in every frame",
                                    str(fault_errors[:5]), "[]")
        RESULT.InterpretEqualResult(f"{parity_def['frame']} EVEN_PARITY_BIT", sorted({row[1] for row in fault_rows}), [parity_even])
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            SQUIB.SendRequest(loop_device, Squib_Fault_Description['NoFault'])
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
