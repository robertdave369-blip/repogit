# Author: Kris
#
# Test case  : CANC_FR_ZONE_TestCase_45 (Codebeamer ID 35660022)
# Workbook   : FR_ZONE_Node_TestCases.xlsx
# Objective  : Verify that FR_ZONE2_100 node-absent fault remains active when Under-Voltage is
#              induced, and voltage DTC behavior follows expected active/healed transitions.
# Automation : Automatic

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CANC_UNDERVOLTAGE_TEST_VOLTAGE,
    CANC_VOLTAGE_DTC_STATUS_KEYS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
    qualification_ms,
    recovery_ms,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    tc_id = '35660022'
    tc_name = 'CANC_FR_ZONE_TestCase_45'
    tc_desc = (
        'Verify that FR_ZONE2_100 node-absent fault remains active when Under-Voltage is '
        'induced, and voltage DTC behavior follows expected active/healed transitions.'
    )
    automation = 'Automatic'

    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    loss_frame = 'FR_ZONE2_100'
    loss_def = next(d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == loss_frame)
    loss_bus = loss_def['bus']
    loss_mode = 'node_absent'
    loss_dtc = resolve_dtc_for_event(loss_mode, loss_frame)
    loss_qualify_nominal_ms = qualification_ms(loss_mode, loss_def['periodicity'])
    loss_recover_nominal_ms = recovery_ms(loss_mode, loss_def['periodicity'])
    loss_qualify_tolerance_ms = int(loss_qualify_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    loss_recover_tolerance_ms = int(loss_recover_nominal_ms * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100)
    voltage_level = CANC_UNDERVOLTAGE_TEST_VOLTAGE
    voltage_dtc = Under_Voltage

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([loss_def]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Automation:", automation)

    try:
        missing = [label for label, value in (
            (f'frame-loss DTC of {loss_frame}', loss_dtc),
        ) if value is None]
        if missing:
            RESULT.LogCustomAction(
                "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                "Missing: " + ", ".join(missing), False)
            return

        aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        fault_free_profile()
        # DTC status and warning lamp are valid only after the start-up proveout.
        Wait(PROVEOUT_COMPLETION_TIME)
        read_software_version()
        Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 2: Create fault - stop transmission of FR_ZONE2_100')
        CAN.PeriodicDisableFrame(loss_bus, loss_frame)
        loss_qualification_time_ms = faultTimeMeasurement(f"{loss_dtc} {DTC_status['DTC_active_WLOFF']}")
        RESULT.InsertComment(f"Qualification time of {loss_dtc} ({loss_qualify_nominal_ms // loss_def['periodicity']} x {loss_def['periodicity']} ms): expected {loss_qualify_nominal_ms} ms, limits {loss_qualify_nominal_ms - loss_qualify_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {loss_qualify_nominal_ms + loss_qualify_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(loss_qualification_time_ms, loss_qualify_nominal_ms + measurement_lag_ms / 2, loss_qualify_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'Frame-loss DTC active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF']]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 3: Create under-voltage condition')
        PS.SetVoltage(voltage_level)
        voltage_time_ms = faultTimeMeasurement(f"{loss_dtc} {DTC_status['DTC_active_WLOFF']};{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]}")
        RESULT.LogAction('Time until the voltage DTC is active (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC active, frame-loss DTC remains active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF'],
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['active']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 4: Restore the supply voltage')
        PS.SetVoltage(NOMINAL_VOLTAGE)
        voltage_time_ms = faultTimeMeasurement(f"{loss_dtc} {DTC_status['DTC_active_WLOFF']};{voltage_dtc} {DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]}")
        RESULT.LogAction('Time until the voltage DTC is healed (ms)', None if voltage_time_ms is None else round(voltage_time_ms))
        Read_DTC(
            'Voltage DTC healed, frame-loss DTC remains active',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_active_WLOFF'],
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
        aria_reports.add_group('Step 5: Remove fault - resume valid transmission of FR_ZONE2_100')
        CAN.PeriodicEnableFrame(loss_bus, loss_frame)
        CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        loss_dequalification_time_ms = faultTimeMeasurement(f"{loss_dtc} {DTC_status['DTC_healed']}")
        RESULT.InsertComment(f"Dequalification time of {loss_dtc} ({loss_recover_nominal_ms // loss_def['periodicity']} x {loss_def['periodicity']} ms): expected {loss_recover_nominal_ms} ms, limits {loss_recover_nominal_ms - loss_recover_tolerance_ms} ms "
                             f"(-{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} %) to {loss_recover_nominal_ms + loss_recover_tolerance_ms + measurement_lag_ms} ms "
                             f"(+{CAN_FAULT_TIMING_TOLERANCE_PERCENT:g} % and the {measurement_lag_ms} ms measurement lag)")
        fault_time_check(loss_dequalification_time_ms, loss_recover_nominal_ms + measurement_lag_ms / 2, loss_recover_tolerance_ms + measurement_lag_ms / 2)
        Read_DTC(
            'Frame-loss DTC healed',
            " ".join([Read_DTC_Resp_CANC,
                      loss_dtc, DTC_status['DTC_healed'],
                      voltage_dtc, DTC_status[CANC_VOLTAGE_DTC_STATUS_KEYS['healed']]]),
            Read_DTC_Req_CANC)
        aria_reports.close_group()
    except Exception as raised:
        RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
    finally:
        try:
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.PeriodicEnableFrame(loss_bus, loss_frame)
            CAN.ReloadDefaultPeriodicFrame(loss_bus, loss_frame)
        finally:
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
