"""
Module Configuration: CAND
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/cand_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is CAND
    ctx.get_module_config("CAND").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "CAND"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CAND Settings ──
DIAG_REQUEST_IDS = [0x730, 0x7DF]
DIAG_RESPONSE_IDS = [0x738]
SUPPORTED_SERVICES = [0x10, 0x11, 0x14, 0x19, 0x22, 0x2E, 0x31, 0x3E]

# ============================================================
# UDS / Service-Identifier test configuration
# ------------------------------------------------------------
# This block is DATA ONLY 
# ============================================================

# -- Diagnostic CAN identifiers used by this ECU (ACU) --------
UDS_PHYS_REQUEST_ID = 0x730      # physical diagnostic request ID
UDS_RESPONSE_ID     = 0x738      # diagnostic response ID
UDS_FUNC_REQUEST_ID = 0x7DF      # functional diagnostic request ID

# M314 has two buses; each has a periodic frame used to confirm bus communication.
UDS_NETWORK_ALIVE_ID    = 0x2C0  # HS-CAN bus alive frame
UDS_NETWORK_ALIVE_ID_FD = 0x13C  # CAN-FD bus alive frame

# Includes both bus alive frames (0x2C0 HS-CAN, 0x13C CAN-FD).
UDS_LOG_CAN_IDS = [0x730, 0x738, 0x7DF, 0x2C0, 0x13C]

# -- Security Access (SID $27) -------------------------------
UDS_SECURITY_LEVEL = {1: 0x01, 3: 0x03, 5: 0x05}

# -- Negative Response Codes -> readable names ---------------
UDS_NRC_NAMES = {
    0x10: "generalReject",
    0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat",
    0x14: "responseTooLong",
    0x21: "busyRepeatRequest",
    0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError",
    0x31: "requestOutOfRange",
    0x33: "securityAccessDenied",
    0x35: "invalidKey",
    0x36: "exceedNumberOfAttempts",
    0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted",
    0x72: "generalProgrammingFailure",
    0x78: "requestCorrectlyReceivedResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}

# --- Requests (UDS) ---
UDS_REQ_10_04                            = "0x10 0x04"  # DiagnosticSessionControl request
UDS_REQ_10_08_2E_01_02_7F_0F             = "0x10 0x08 0x2E 0x01 0x02 0x7F 0x0F"  # DiagnosticSessionControl request
UDS_REQ_10_81                            = "0x10 0x81"  # DiagnosticSessionControl request
UDS_REQ_10_82                            = "0x10 0x82"  # DiagnosticSessionControl request
UDS_REQ_10_83                            = "0x10 0x83"  # DiagnosticSessionControl request
UDS_REQ_11_01                            = "0x11 0x01"  # ECUReset request
UDS_REQ_11_01_00                         = "0x11 0x01 0x00"  # ECUReset request
UDS_REQ_11_03                            = "0x11 0x03"  # ECUReset request
UDS_REQ_11_03_00                         = "0x11 0x03 0x00"  # ECUReset request
UDS_REQ_11_81                            = "0x11 0x81"  # ECUReset request
UDS_REQ_11_83                            = "0x11 0x83"  # ECUReset request
UDS_REQ_14_00_00_00                      = "0x14 0x00 0x00 0x00"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_EE_F9                      = "0x14 0xFF 0xEE 0xF9"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_EE_FF                      = "0x14 0xFF 0xEE 0xFF"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF                         = "0x14 0xFF 0xFF"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_F0                      = "0x14 0xFF 0xFF 0xF0"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_FF_01                   = "0x14 0xFF 0xFF 0xFF 0x01"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_FF_03                   = "0x14 0xFF 0xFF 0xFF 0x03"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_FF_06                   = "0x14 0xFF 0xFF 0xFF 0x06"  # ClearDiagnosticInformation request
UDS_REQ_19                               = "0x19"  # ReadDTCInformation request
UDS_REQ_19_01_CB                         = "0x19 0x01 0xCB"  # ReadDTCInformation request
UDS_REQ_19_01_FF                         = "0x19 0x01 0xFF"  # ReadDTCInformation request
UDS_REQ_19_01_FF_FF_FF                   = "0x19 0x01 0xFF 0xFF 0xFF"  # ReadDTCInformation request
UDS_REQ_19_02_08                         = "0x19 0x02 0x08"  # ReadDTCInformation request
UDS_REQ_19_02_80_01_13_FF                = "0x19 0x02 0x80 0x01 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_02_FF                         = "0x19 0x02 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_80_10_1A_01                = "0x19 0x04 0x80 0x10 0x1A 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_10_1A_02                = "0x19 0x04 0x80 0x10 0x1A 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_10_1A_FF                = "0x19 0x04 0x80 0x10 0x1A 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_80_70_13_01                = "0x19 0x04 0x80 0x70 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_70_13_02                = "0x19 0x04 0x80 0x70 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_72_11_01                = "0x19 0x04 0x80 0x72 0x11 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_72_11_02                = "0x19 0x04 0x80 0x72 0x11 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_72_11_FF                = "0x19 0x04 0x80 0x72 0x11 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_80_95_96_01                = "0x19 0x04 0x80 0x95 0x96 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_95_96_02                = "0x19 0x04 0x80 0x95 0x96 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_95_96_FF                = "0x19 0x04 0x80 0x95 0x96 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_04_1B_01                = "0x19 0x04 0x92 0x04 0x1B 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_04_1B_02                = "0x19 0x04 0x92 0x04 0x1B 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_04_1B_FF                = "0x19 0x04 0x92 0x04 0x1B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_06_64_01                = "0x19 0x04 0x92 0x06 0x64 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_06_64_02                = "0x19 0x04 0x92 0x06 0x64 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_06_64_FF                = "0x19 0x04 0x92 0x06 0x64 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_07_12_01                = "0x19 0x04 0x92 0x07 0x12 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_07_12_02                = "0x19 0x04 0x92 0x07 0x12 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_07_12_FF                = "0x19 0x04 0x92 0x07 0x12 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_0A_13_FF                = "0x19 0x04 0x92 0x0A 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_0B_13_01                = "0x19 0x04 0x92 0x0B 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_0B_13_02                = "0x19 0x04 0x92 0x0B 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_0B_13_FF                = "0x19 0x04 0x92 0x0B 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_10_12_01                = "0x19 0x04 0x92 0x10 0x12 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_10_12_02                = "0x19 0x04 0x92 0x10 0x12 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_10_12_FF                = "0x19 0x04 0x92 0x10 0x12 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_18_11_01                = "0x19 0x04 0x92 0x18 0x11 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_18_11_02                = "0x19 0x04 0x92 0x18 0x11 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_18_11_FF                = "0x19 0x04 0x92 0x18 0x11 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_1C_13_01                = "0x19 0x04 0x92 0x1C 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_1C_13_02                = "0x19 0x04 0x92 0x1C 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_1C_13_FF                = "0x19 0x04 0x92 0x1C 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_53_2B_01                = "0x19 0x04 0x92 0x53 0x2B 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_53_2B_02                = "0x19 0x04 0x92 0x53 0x2B 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_53_2B_FF                = "0x19 0x04 0x92 0x53 0x2B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_54_2B_01                = "0x19 0x04 0x92 0x54 0x2B 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_54_2B_02                = "0x19 0x04 0x92 0x54 0x2B 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_54_2B_FF                = "0x19 0x04 0x92 0x54 0x2B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_98_F9_13_01                = "0x19 0x04 0x98 0xF9 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_98_F9_13_02                = "0x19 0x04 0x98 0xF9 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_98_F9_13_FF                = "0x19 0x04 0x98 0xF9 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_99_0E_13_01                = "0x19 0x04 0x99 0x0E 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_99_0E_13_02                = "0x19 0x04 0x99 0x0E 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_99_0E_13_FF                = "0x19 0x04 0x99 0x0E 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_99_14_13_01                = "0x19 0x04 0x99 0x14 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_99_14_13_02                = "0x19 0x04 0x99 0x14 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_99_14_13_FF                = "0x19 0x04 0x99 0x14 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_D2_71_00_01                = "0x19 0x04 0xD2 0x71 0x00 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_D2_71_00_02                = "0x19 0x04 0xD2 0x71 0x00 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_D2_71_00_FF                = "0x19 0x04 0xD2 0x71 0x00 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_FF                         = "0x19 0x04 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06                            = "0x19 0x06"  # ReadDTCInformation request
UDS_REQ_19_06_80_01_13_FF                = "0x19 0x06 0x80 0x01 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_10_13_FF                = "0x19 0x06 0x80 0x10 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_70_13_FF                = "0x19 0x06 0x80 0x70 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_72_13_FF                = "0x19 0x06 0x80 0x72 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_90_13_FF                = "0x19 0x06 0x80 0x90 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_95_13_FF                = "0x19 0x06 0x80 0x95 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_90_13_49_FF                = "0x19 0x06 0x90 0x13 0x49 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_90_32_12_FF                = "0x19 0x06 0x90 0x32 0x12 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_0A_13_FF                = "0x19 0x06 0x92 0x0A 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_11_01                = "0x19 0x06 0x92 0x0B 0x11 0x01"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_11_02                = "0x19 0x06 0x92 0x0B 0x11 0x02"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_11_FF                = "0x19 0x06 0x92 0x0B 0x11 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_13_FF                = "0x19 0x06 0x92 0x0B 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_1B_13_FF                = "0x19 0x06 0x92 0x1B 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_1C_13_FF                = "0x19 0x06 0x92 0x1C 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_36_13_FF                = "0x19 0x06 0x92 0x36 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_37_13_FF                = "0x19 0x06 0x92 0x37 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_D1_01_00_FF                = "0x19 0x06 0xD1 0x01 0x00 0xFF"  # ReadDTCInformation request
UDS_REQ_19_08_80_90_13_FF                = "0x19 0x08 0x80 0x90 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0A_FF                         = "0x19 0x0A 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0B_FF                         = "0x19 0x0B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0C_FF                         = "0x19 0x0C 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0E_FF                         = "0x19 0x0E 0xFF"  # ReadDTCInformation request
UDS_REQ_22                               = "0x22"  # ReadDataByIdentifier request
UDS_REQ_22_01_00                         = "0x22 0x01 0x00"  # ReadDataByIdentifier request
UDS_REQ_22_02_00                         = "0x22 0x02 0x00"  # ReadDataByIdentifier request
UDS_REQ_22_04_5A                         = "0x22 0x04 0x5A"  # ReadDataByIdentifier request
UDS_REQ_22_F1_00                         = "0x22 0xF1 0x00"  # ReadDataByIdentifier request
UDS_REQ_22_F1_99                         = "0x22 0xF1 0x99"  # ReadDataByIdentifier request
UDS_REQ_22_F1_9D                         = "0x22 0xF1 0x9D"  # ReadDataByIdentifier request
UDS_REQ_22_F1_B2                         = "0x22 0xF1 0xB2"  # ReadDataByIdentifier request
UDS_REQ_22_F1_B6                         = "0x22 0xF1 0xB6"  # ReadDataByIdentifier request
UDS_REQ_22_F1_C0                         = "0x22 0xF1 0xC0"  # ReadDataByIdentifier request
UDS_REQ_27_01                            = "0x27 0x01"  # SecurityAccess request
UDS_REQ_27_01_FF_FF_FF_FF_FF             = "0x27 0x01 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_02                            = "0x27 0x02"  # SecurityAccess request
UDS_REQ_27_02_AA_AA_AA_AA                = "0x27 0x02 0xAA 0xAA 0xAA 0xAA"  # SecurityAccess request
UDS_REQ_27_02_FF_FF_FF_FF_FF             = "0x27 0x02 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_05                            = "0x27 0x05"  # SecurityAccess request
UDS_REQ_27_05_FF_FF_FF_FF_FF             = "0x27 0x05 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_06                            = "0x27 0x06"  # SecurityAccess request
UDS_REQ_27_06_AA_AA_AA_AA                = "0x27 0x06 0xAA 0xAA 0xAA 0xAA"  # SecurityAccess request
UDS_REQ_27_06_FF_FF_FF_FF_FF             = "0x27 0x06 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_61                            = "0x27 0x61"  # SecurityAccess request
UDS_REQ_27_85                            = "0x27 0x85"  # SecurityAccess request
UDS_REQ_28_00_01                         = "0x28 0x00 0x01"  # CommunicationControl request
UDS_REQ_28_00_02                         = "0x28 0x00 0x02"  # CommunicationControl request
UDS_REQ_28_00_03                         = "0x28 0x00 0x03"  # CommunicationControl request
UDS_REQ_28_00_FF                         = "0x28 0x00 0xFF"  # CommunicationControl request
UDS_REQ_28_01_01                         = "0x28 0x01 0x01"  # CommunicationControl request
UDS_REQ_28_01_02                         = "0x28 0x01 0x02"  # CommunicationControl request
UDS_REQ_28_01_03                         = "0x28 0x01 0x03"  # CommunicationControl request
UDS_REQ_28_01_FF                         = "0x28 0x01 0xFF"  # CommunicationControl request
UDS_REQ_28_02_01                         = "0x28 0x02 0x01"  # CommunicationControl request
UDS_REQ_28_02_02                         = "0x28 0x02 0x02"  # CommunicationControl request
UDS_REQ_28_02_03                         = "0x28 0x02 0x03"  # CommunicationControl request
UDS_REQ_28_02_FF                         = "0x28 0x02 0xFF"  # CommunicationControl request
UDS_REQ_28_03                            = "0x28 0x03"  # CommunicationControl request
UDS_REQ_28_03_01                         = "0x28 0x03 0x01"  # CommunicationControl request
UDS_REQ_28_03_02                         = "0x28 0x03 0x02"  # CommunicationControl request
UDS_REQ_28_03_03                         = "0x28 0x03 0x03"  # CommunicationControl request
UDS_REQ_28_80_01                         = "0x28 0x80 0x01"  # CommunicationControl request
UDS_REQ_28_80_02                         = "0x28 0x80 0x02"  # CommunicationControl request
UDS_REQ_28_80_03                         = "0x28 0x80 0x03"  # CommunicationControl request
UDS_REQ_28_81_01                         = "0x28 0x81 0x01"  # CommunicationControl request
UDS_REQ_28_81_02                         = "0x28 0x81 0x02"  # CommunicationControl request
UDS_REQ_28_81_03                         = "0x28 0x81 0x03"  # CommunicationControl request
UDS_REQ_28_82_01                         = "0x28 0x82 0x01"  # CommunicationControl request
UDS_REQ_28_82_02                         = "0x28 0x82 0x02"  # CommunicationControl request
UDS_REQ_28_82_03                         = "0x28 0x82 0x03"  # CommunicationControl request
UDS_REQ_28_83_01                         = "0x28 0x83 0x01"  # CommunicationControl request
UDS_REQ_28_83_02                         = "0x28 0x83 0x02"  # CommunicationControl request
UDS_REQ_28_83_03                         = "0x28 0x83 0x03"  # CommunicationControl request
UDS_REQ_2E_01_00_18                      = "0x2E 0x01 0x00 0x18"  # WriteDataByIdentifier request
UDS_REQ_2E_01_00_18_18_18_18_18_18_18_18_18__5befe0 = "0x2E 0x01 0x00 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18"  # WriteDataByIdentifier request
UDS_REQ_2E_01_01_19_00_00_02_00_14_00_04_00__c9c75d = "0x2E 0x01 0x01 0x19 0x00 0x00 0x02 0x00 0x14 0x00 0x04 0x00 0x00 0x00 0x04 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_01_01_2B_10_00_03_20_00_20_04_00__bed290 = "0x2E 0x01 0x01 0x2B 0x10 0x00 0x03 0x20 0x00 0x20 0x04 0x00 0x00 0x00 0x04 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_01_02_03_03_CD_A0             = "0x2E 0x01 0x02 0x03 0x03 0xCD 0xA0"  # WriteDataByIdentifier request
UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01    = "0x2E 0x01 0x02 0x7F 0x0F 0x0F 0xAB 0x2A 0x18 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_01_02_7F_8F_CF_AF_AA_1A_01    = "0x2E 0x01 0x02 0x7F 0x8F 0xCF 0xAF 0xAA 0x1A 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_02_00_02                      = "0x2E 0x02 0x00 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_02_01_02                      = "0x2E 0x02 0x01 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_04_46_02                      = "0x2E 0x04 0x46 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_00_01                      = "0x2E 0xF1 0x00 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_00_02                      = "0x2E 0xF1 0x00 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_00_03                      = "0x2E 0xF1 0x00 0x03"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_80_02                      = "0x2E 0xF1 0x80 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_81                         = "0x2E 0xF1 0x81"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_82_02                      = "0x2E 0xF1 0x82 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_86_02                      = "0x2E 0xF1 0x86 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_87_02                      = "0x2E 0xF1 0x87 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_8A_02                      = "0x2E 0xF1 0x8A 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_8B_02                      = "0x2E 0xF1 0x8B 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_8C_02                      = "0x2E 0xF1 0x8C 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_90                         = "0x2E 0xF1 0x90"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_90_32_32_32_32_32_32_32_32_32__faa1a9 = "0x2E 0xF1 0x90 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_91_02                      = "0x2E 0xF1 0x91 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086 = "0x2E 0xF1 0x98 0xAA 0xAA 0xAA 0xAA 0xAA 0xAA 0x20 0x20 0x20 0x20 0x20 0x20 0x20 0x20 0x20 0x20"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_99_23_02_26                = "0x2E 0xF1 0x99 0x23 0x02 0x26"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_9D_18_09_18                = "0x2E 0xF1 0x9D 0x18 0x09 0x18"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_B7_02                      = "0x2E 0xF1 0xB7 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_C0_03                      = "0x2E 0xF1 0xC0 0x03"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_C0_05                      = "0x2E 0xF1 0xC0 0x05"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_C0_0A                      = "0x2E 0xF1 0xC0 0x0A"  # WriteDataByIdentifier request
UDS_REQ_3E                               = "0x3E"  # TesterPresent request
UDS_REQ_3E_80                            = "0x3E 0x80"  # TesterPresent request
UDS_REQ_85_01                            = "0x85 0x01"  # ControlDTCSetting request
UDS_REQ_85_02                            = "0x85 0x02"  # ControlDTCSetting request
UDS_REQ_85_7F                            = "0x85 0x7F"  # ControlDTCSetting request
UDS_REQ_85_81                            = "0x85 0x81"  # ControlDTCSetting request
UDS_REQ_85_82                            = "0x85 0x82"  # ControlDTCSetting request
UDS_REQ_CLEAR_ALL_DTC                    = "0x14 0xFF 0xFF 0xFF"  # ClearDiagnosticInformation request
UDS_REQ_READ_ACTIVE_SESSION              = "0x22 0xF1 0x86"  # ReadDataByIdentifier request
UDS_REQ_SESSION_DEFAULT                  = "0x10 0x01"  # DiagnosticSessionControl request
UDS_REQ_SESSION_EXTENDED                 = "0x10 0x03"  # DiagnosticSessionControl request
UDS_REQ_SESSION_PROGRAMMING              = "0x10 0x02"  # DiagnosticSessionControl request
UDS_REQ_TESTER_PRESENT                   = "0x3E 0x00"  # TesterPresent request

# --- Expected responses ---
UDS_NO_RESPONSE                          = "No response"  # ECU shall not respond
UDS_RESP_50_01_00_32_13_88               = "0x50 0x01 0x00 0x32 0x13 0x88"  # DiagnosticSessionControl positive response
UDS_RESP_50_01_00_C8_01_F4               = "0x50 0x01 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_50_02                           = "0x50 0x02"  # DiagnosticSessionControl positive response
UDS_RESP_50_02_00_C8_01_F4               = "0x50 0x02 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_50_03                           = "0x50 0x03"  # DiagnosticSessionControl positive response
UDS_RESP_50_03_00_32_13_88               = "0x50 0x03 0x00 0x32 0x13 0x88"  # DiagnosticSessionControl positive response
UDS_RESP_50_03_00_C8_01_F4               = "0x50 0x03 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_51_01                           = "0x51 0x01"  # ECUReset positive response
UDS_RESP_51_03                           = "0x51 0x03"  # ECUReset positive response
UDS_RESP_54                              = "0x54"  # ClearDiagnosticInformation positive response
UDS_RESP_59_01_CB                        = "0x59 0x01 0xCB"  # ReadDTCInformation positive response
UDS_RESP_59_02_80_01_13                  = "0x59 0x02 0x80 0x01 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_02_80_01_13_00_00            = "0x59 0x02 0x80 0x01 0x13 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_02_CB                        = "0x59 0x02 0xCB"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_10_1A_8B_01_11         = "0x59 0x04 0x80 0x10 0x1A 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_10_1A_8B_02_11         = "0x59 0x04 0x80 0x10 0x1A 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_72_11_8B_01_11         = "0x59 0x04 0x80 0x72 0x11 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_72_11_8B_02_11         = "0x59 0x04 0x80 0x72 0x11 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_95_96_08_01_11         = "0x59 0x04 0x80 0x95 0x96 0x08 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_95_96_08_02_11         = "0x59 0x04 0x80 0x95 0x96 0x08 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_00_00_8B               = "0x59 0x04 0x92 0x00 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_04_1B_8B_01_11         = "0x59 0x04 0x92 0x04 0x1B 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_04_1B_8B_02_11         = "0x59 0x04 0x92 0x04 0x1B 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_06_64_8B_01_11         = "0x59 0x04 0x92 0x06 0x64 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_06_64_8B_02_11         = "0x59 0x04 0x92 0x06 0x64 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_07_12_8B_01_11         = "0x59 0x04 0x92 0x07 0x12 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_07_12_8B_02_11         = "0x59 0x04 0x92 0x07 0x12 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_0B_13_8B_01_11         = "0x59 0x04 0x92 0x0B 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_0B_13_8B_02_11         = "0x59 0x04 0x92 0x0B 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_10_12_8B_01_11         = "0x59 0x04 0x92 0x10 0x12 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_10_12_8B_02_11         = "0x59 0x04 0x92 0x10 0x12 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_18_11_8B_01_11         = "0x59 0x04 0x92 0x18 0x11 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_18_11_8B_02_11         = "0x59 0x04 0x92 0x18 0x11 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_1C_13_13_8B_02         = "0x59 0x04 0x92 0x1C 0x13 0x13 0x8B 0x02"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_1C_13_8B_01_11         = "0x59 0x04 0x92 0x1C 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_53_2B_8B_01_11         = "0x59 0x04 0x92 0x53 0x2B 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_53_2B_8B_02_11         = "0x59 0x04 0x92 0x53 0x2B 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_54_2B_8B_01_11         = "0x59 0x04 0x92 0x54 0x2B 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_54_2B_8B_02_11         = "0x59 0x04 0x92 0x54 0x2B 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_98_F9_13_8B_01_11         = "0x59 0x04 0x98 0xF9 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_98_F9_13_8B_02_11         = "0x59 0x04 0x98 0xF9 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_0E_13_8B_01_11         = "0x59 0x04 0x99 0x0E 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_0E_13_8B_02_11         = "0x59 0x04 0x99 0x0E 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_14_13_8B_01_11         = "0x59 0x04 0x99 0x14 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_14_13_8B_02_11         = "0x59 0x04 0x99 0x14 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_D2_71_00_8B               = "0x59 0x04 0xD2 0x71 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_01_13                  = "0x59 0x06 0x80 0x01 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_01_13_8B_01            = "0x59 0x06 0x80 0x01 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_10_13_40               = "0x59 0x06 0x80 0x10 0x13 0x40"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_10_13_8B_01            = "0x59 0x06 0x80 0x10 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13                  = "0x59 0x06 0x80 0x70 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13_00_00            = "0x59 0x06 0x80 0x70 0x13 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13_00_8B            = "0x59 0x06 0x80 0x70 0x13 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13_8B_01            = "0x59 0x06 0x80 0x70 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_72_13                  = "0x59 0x06 0x80 0x72 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_72_13_00_00            = "0x59 0x06 0x80 0x72 0x13 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_72_13_00_8B            = "0x59 0x06 0x80 0x72 0x13 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_90_13                  = "0x59 0x06 0x80 0x90 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_90_13_40               = "0x59 0x06 0x80 0x90 0x13 0x40"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_90_13_8B_01            = "0x59 0x06 0x80 0x90 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_95_13_00               = "0x59 0x06 0x80 0x95 0x13 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_95_13_8B_01            = "0x59 0x06 0x80 0x95 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_90_13_49_00_00            = "0x59 0x06 0x90 0x13 0x49 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_90_13_49_8B_01            = "0x59 0x06 0x90 0x13 0x49 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_90_32_12_40               = "0x59 0x06 0x90 0x32 0x12 0x40"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0A_13                  = "0x59 0x06 0x92 0x0A 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_08_01_01         = "0x59 0x06 0x92 0x0B 0x11 0x08 0x01 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_8B_01_01         = "0x59 0x06 0x92 0x0B 0x11 0x8B 0x01 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_8B_02            = "0x59 0x06 0x92 0x0B 0x11 0x8B 0x02"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_8B_02_01         = "0x59 0x06 0x92 0x0B 0x11 0x8B 0x02 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_13                  = "0x59 0x06 0x92 0x0B 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_13_00               = "0x59 0x06 0x92 0x0B 0x13 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_1B_13_8B_01            = "0x59 0x06 0x92 0x1B 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_1C_13                  = "0x59 0x06 0x92 0x1C 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_1C_13_8B_01            = "0x59 0x06 0x92 0x1C 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_36_13                  = "0x59 0x06 0x92 0x36 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_37_13                  = "0x59 0x06 0x92 0x37 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_D1_01_00_00               = "0x59 0x06 0xD1 0x01 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_D1_01_00_8B_01            = "0x59 0x06 0xD1 0x01 0x00 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_62_02_00_01                     = "0x62 0x02 0x00 0x01"  # ReadDataByIdentifier positive response
UDS_RESP_62_04_5A                        = "0x62 0x04 0x5A"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1                           = "0x62 0xF1"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_00_01                     = "0x62 0xF1 0x00 0x01"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_00_02                     = "0x62 0xF1 0x00 0x02"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_00_03                     = "0x62 0xF1 0x00 0x03"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_86                        = "0x62 0xF1 0x86"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_90                        = "0x62 0xF1 0x90"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_99_23_02_26               = "0x62 0xF1 0x99 0x23 0x02 0x26"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_9D_18_09_18               = "0x62 0xF1 0x9D 0x18 0x09 0x18"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2                        = "0x62 0xF1 0xB2"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_00_00                  = "0x62 0xF1 0xB2 0x00 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_00_C0                  = "0x62 0xF1 0xB2 0x00 0xC0"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_19_00                  = "0x62 0xF1 0xB2 0x19 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_4B_00                  = "0x62 0xF1 0xB2 0x4B 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00                     = "0x62 0xF1 0xB6 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00                  = "0x62 0xF1 0xB6 0x00 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_00_1B            = "0x62 0xF1 0xB6 0x00 0x00 0x00 0x1B"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_00_1C            = "0x62 0xF1 0xB6 0x00 0x00 0x00 0x1C"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_02_42            = "0x62 0xF1 0xB6 0x00 0x00 0x02 0x42"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_02_43_00         = "0x62 0xF1 0xB6 0x00 0x00 0x02 0x43 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_C0_03                     = "0x62 0xF1 0xC0 0x03"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_C0_05                     = "0x62 0xF1 0xC0 0x05"  # ReadDataByIdentifier positive response
UDS_RESP_67_01                           = "0x67 0x01"  # SecurityAccess positive response
UDS_RESP_67_01_00_00_00_00               = "0x67 0x01 0x00 0x00 0x00 0x00"  # SecurityAccess positive response
UDS_RESP_67_05                           = "0x67 0x05"  # SecurityAccess positive response
UDS_RESP_67_06                           = "0x67 0x06"  # SecurityAccess positive response
UDS_RESP_67_61                           = "0x67 0x61"  # SecurityAccess positive response
UDS_RESP_68_00                           = "0x68 0x00"  # CommunicationControl positive response
UDS_RESP_68_01                           = "0x68 0x01"  # CommunicationControl positive response
UDS_RESP_68_02                           = "0x68 0x02"  # CommunicationControl positive response
UDS_RESP_68_03                           = "0x68 0x03"  # CommunicationControl positive response
UDS_RESP_6E_01_00                        = "0x6E 0x01 0x00"  # WriteDataByIdentifier positive response
UDS_RESP_6E_01_01                        = "0x6E 0x01 0x01"  # WriteDataByIdentifier positive response
UDS_RESP_6E_01_02                        = "0x6E 0x01 0x02"  # WriteDataByIdentifier positive response
UDS_RESP_6E_F1_00                        = "0x6E 0xF1 0x00"  # WriteDataByIdentifier positive response
UDS_RESP_6E_F1_C0                        = "0x6E 0xF1 0xC0"  # WriteDataByIdentifier positive response
UDS_RESP_7F_10_33                        = "0x7F 0x10 0x33"  # DiagnosticSessionControl negative response (NRC 0x33)
UDS_RESP_7F_10_78                        = "0x7F 0x10 0x78"  # DiagnosticSessionControl negative response (NRC 0x78)
UDS_RESP_7F_10_7E                        = "0x7F 0x10 0x7E"  # DiagnosticSessionControl negative response (NRC 0x7E)
UDS_RESP_7F_10_88                        = "0x7F 0x10 0x88"  # DiagnosticSessionControl negative response (NRC 0x88)
UDS_RESP_7F_11                           = "0x7F 0x11"  # service 0x3F positive response
UDS_RESP_7F_11_22                        = "0x7F 0x11 0x22"  # ECUReset negative response (NRC 0x22)
UDS_RESP_7F_11_7F                        = "0x7F 0x11 0x7F"  # ECUReset negative response (NRC 0x7F)
UDS_RESP_7F_11_88                        = "0x7F 0x11 0x88"  # ECUReset negative response (NRC 0x88)
UDS_RESP_7F_14_11                        = "0x7F 0x14 0x11"  # ClearDiagnosticInformation negative response (NRC 0x11)
UDS_RESP_7F_14_13                        = "0x7F 0x14 0x13"  # ClearDiagnosticInformation negative response (NRC 0x13)
UDS_RESP_7F_14_22                        = "0x7F 0x14 0x22"  # ClearDiagnosticInformation negative response (NRC 0x22)
UDS_RESP_7F_14_31                        = "0x7F 0x14 0x31"  # ClearDiagnosticInformation negative response (NRC 0x31)
UDS_RESP_7F_14_7F                        = "0x7F 0x14 0x7F"  # ClearDiagnosticInformation negative response (NRC 0x7F)
UDS_RESP_7F_14_88                        = "0x7F 0x14 0x88"  # ClearDiagnosticInformation negative response (NRC 0x88)
UDS_RESP_7F_19_11                        = "0x7F 0x19 0x11"  # ReadDTCInformation negative response (NRC 0x11)
UDS_RESP_7F_19_12                        = "0x7F 0x19 0x12"  # ReadDTCInformation negative response (NRC 0x12)
UDS_RESP_7F_19_13                        = "0x7F 0x19 0x13"  # ReadDTCInformation negative response (NRC 0x13)
UDS_RESP_7F_19_31                        = "0x7F 0x19 0x31"  # ReadDTCInformation negative response (NRC 0x31)
UDS_RESP_7F_27_12                        = "0x7F 0x27 0x12"  # SecurityAccess negative response (NRC 0x12)
UDS_RESP_7F_27_13                        = "0x7F 0x27 0x13"  # SecurityAccess negative response (NRC 0x13)
UDS_RESP_7F_27_24                        = "0x7F 0x27 0x24"  # SecurityAccess negative response (NRC 0x24)
UDS_RESP_7F_27_24_FF_FF_FF_FF            = "0x7F 0x27 0x24 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess negative response (NRC 0x24)
UDS_RESP_7F_27_35                        = "0x7F 0x27 0x35"  # SecurityAccess negative response (NRC 0x35)
UDS_RESP_7F_27_36                        = "0x7F 0x27 0x36"  # SecurityAccess negative response (NRC 0x36)
UDS_RESP_7F_27_37                        = "0x7F 0x27 0x37"  # SecurityAccess negative response (NRC 0x37)
UDS_RESP_7F_27_7F                        = "0x7F 0x27 0x7F"  # SecurityAccess negative response (NRC 0x7F)
UDS_RESP_7F_28_13                        = "0x7F 0x28 0x13"  # CommunicationControl negative response (NRC 0x13)
UDS_RESP_7F_28_31                        = "0x7F 0x28 0x31"  # CommunicationControl negative response (NRC 0x31)
UDS_RESP_7F_28_7F                        = "0x7F 0x28 0x7F"  # CommunicationControl negative response (NRC 0x7F)
UDS_RESP_7F_28_88                        = "0x7F 0x28 0x88"  # CommunicationControl negative response (NRC 0x88)
UDS_RESP_7F_2E_11_00_00_00_00            = "0x7F 0x2E 0x11 0x00 0x00 0x00 0x00"  # WriteDataByIdentifier negative response (NRC 0x11)
UDS_RESP_7F_2E_13                        = "0x7F 0x2E 0x13"  # WriteDataByIdentifier negative response (NRC 0x13)
UDS_RESP_7F_2E_22                        = "0x7F 0x2E 0x22"  # WriteDataByIdentifier negative response (NRC 0x22)
UDS_RESP_7F_2E_31                        = "0x7F 0x2E 0x31"  # WriteDataByIdentifier negative response (NRC 0x31)
UDS_RESP_7F_2E_33                        = "0x7F 0x2E 0x33"  # WriteDataByIdentifier negative response (NRC 0x33)
UDS_RESP_7F_2E_7F                        = "0x7F 0x2E 0x7F"  # WriteDataByIdentifier negative response (NRC 0x7F)
UDS_RESP_7F_2E_83_00_00_00_00            = "0x7F 0x2E 0x83 0x00 0x00 0x00 0x00"  # WriteDataByIdentifier negative response (NRC 0x83)
UDS_RESP_7F_2E_88                        = "0x7F 0x2E 0x88"  # WriteDataByIdentifier negative response (NRC 0x88)
UDS_RESP_7F_3E_13                        = "0x7F 0x3E 0x13"  # TesterPresent negative response (NRC 0x13)
UDS_RESP_7F_85_7F                        = "0x7F 0x85 0x7F"  # ControlDTCSetting negative response (NRC 0x7F)
UDS_RESP_ACTIVE_SESSION_DEFAULT          = "0x62 0xF1 0x86 0x01"  # ReadDataByIdentifier positive response
UDS_RESP_ACTIVE_SESSION_EXTENDED         = "0x62 0xF1 0x86 0x03"  # ReadDataByIdentifier positive response
UDS_RESP_ACTIVE_SESSION_PROGRAMMING      = "0x62 0xF1 0x86 0x02"  # ReadDataByIdentifier positive response
UDS_RESP_C5_01                           = "0xC5 0x01"  # ControlDTCSetting positive response
UDS_RESP_C5_02                           = "0xC5 0x02"  # ControlDTCSetting positive response
UDS_RESP_SESSION_DEFAULT                 = "0x50 0x01 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_SESSION_EXTENDED                = "0x50 0x03 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_SESSION_PROGRAMMING             = "0x50 0x02 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_TESTER_PRESENT                  = "0x7E 0x00"  # TesterPresent positive response

# --- Requests ---
IOC_REQ_2F_0F_22_00          = "0x2F 0x0F 0x22 0x00"  # IO-control ($2F) request
IOC_REQ_2F_0F_22_01          = "0x2F 0x0F 0x22 0x01"  # IO-control ($2F) request
IOC_REQ_2F_0F_22_02          = "0x2F 0x0F 0x22 0x02"  # IO-control ($2F) request
IOC_REQ_2F_0F_22_03_00       = "0x2F 0x0F 0x22 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_0F_22_03_01       = "0x2F 0x0F 0x22 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_0F_22_03_01_00    = "0x2F 0x0F 0x22 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_0F_22_03_02       = "0x2F 0x0F 0x22 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_0F_22_04          = "0x2F 0x0F 0x22 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_00          = "0x2F 0xF0 0x10 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_01          = "0x2F 0xF0 0x10 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_02          = "0x2F 0xF0 0x10 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_00       = "0x2F 0xF0 0x10 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_01       = "0x2F 0xF0 0x10 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_01_00    = "0x2F 0xF0 0x10 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_10_03_02       = "0x2F 0xF0 0x10 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_04       = "0x2F 0xF0 0x10 0x03 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_08       = "0x2F 0xF0 0x10 0x03 0x08"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_10       = "0x2F 0xF0 0x10 0x03 0x10"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_20       = "0x2F 0xF0 0x10 0x03 0x20"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_40       = "0x2F 0xF0 0x10 0x03 0x40"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_03_40_00    = "0x2F 0xF0 0x10 0x03 0x40 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_10_03_80       = "0x2F 0xF0 0x10 0x03 0x80"  # IO-control ($2F) request
IOC_REQ_2F_F0_10_04_00       = "0x2F 0xF0 0x10 0x04 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_00          = "0x2F 0xF0 0x11 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_01          = "0x2F 0xF0 0x11 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_02          = "0x2F 0xF0 0x11 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_03_00       = "0x2F 0xF0 0x11 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_03_01       = "0x2F 0xF0 0x11 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_03_01_00    = "0x2F 0xF0 0x11 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_11_03_02       = "0x2F 0xF0 0x11 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_11_04          = "0x2F 0xF0 0x11 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_00          = "0x2F 0xF0 0x12 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_01          = "0x2F 0xF0 0x12 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_02          = "0x2F 0xF0 0x12 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_03_00       = "0x2F 0xF0 0x12 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_03_01       = "0x2F 0xF0 0x12 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_03_01_00    = "0x2F 0xF0 0x12 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_12_03_02       = "0x2F 0xF0 0x12 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_12_04          = "0x2F 0xF0 0x12 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_00          = "0x2F 0xF0 0x13 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_01          = "0x2F 0xF0 0x13 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_02          = "0x2F 0xF0 0x13 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_03_00       = "0x2F 0xF0 0x13 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_03_01       = "0x2F 0xF0 0x13 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_03_01_00    = "0x2F 0xF0 0x13 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_13_03_02       = "0x2F 0xF0 0x13 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_13_04          = "0x2F 0xF0 0x13 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_00          = "0x2F 0xF0 0x14 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_01          = "0x2F 0xF0 0x14 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_02          = "0x2F 0xF0 0x14 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_00       = "0x2F 0xF0 0x14 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_01       = "0x2F 0xF0 0x14 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_01_00    = "0x2F 0xF0 0x14 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_14_03_02       = "0x2F 0xF0 0x14 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_02_00    = "0x2F 0xF0 0x14 0x03 0x02 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_14_03_04       = "0x2F 0xF0 0x14 0x03 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_04_00    = "0x2F 0xF0 0x14 0x03 0x04 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_14_03_08       = "0x2F 0xF0 0x14 0x03 0x08"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_08_00    = "0x2F 0xF0 0x14 0x03 0x08 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_14_03_10       = "0x2F 0xF0 0x14 0x03 0x10"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_10_00    = "0x2F 0xF0 0x14 0x03 0x10 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_14_03_20       = "0x2F 0xF0 0x14 0x03 0x20"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_40       = "0x2F 0xF0 0x14 0x03 0x40"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_03_80       = "0x2F 0xF0 0x14 0x03 0x80"  # IO-control ($2F) request
IOC_REQ_2F_F0_14_04          = "0x2F 0xF0 0x14 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_00          = "0x2F 0xF0 0x15 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_01          = "0x2F 0xF0 0x15 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_02          = "0x2F 0xF0 0x15 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_03_00       = "0x2F 0xF0 0x15 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_03_01       = "0x2F 0xF0 0x15 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_03_01_00    = "0x2F 0xF0 0x15 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_15_03_02       = "0x2F 0xF0 0x15 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_03_02_00    = "0x2F 0xF0 0x15 0x03 0x02 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_15_03_04       = "0x2F 0xF0 0x15 0x03 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_03_04_00    = "0x2F 0xF0 0x15 0x03 0x04 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_15_03_08       = "0x2F 0xF0 0x15 0x03 0x08"  # IO-control ($2F) request
IOC_REQ_2F_F0_15_04          = "0x2F 0xF0 0x15 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_00          = "0x2F 0xF0 0x16 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_01          = "0x2F 0xF0 0x16 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_02          = "0x2F 0xF0 0x16 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_03_00       = "0x2F 0xF0 0x16 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_03_01       = "0x2F 0xF0 0x16 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_03_01_00    = "0x2F 0xF0 0x16 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_16_03_02       = "0x2F 0xF0 0x16 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_03_04       = "0x2F 0xF0 0x16 0x03 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_16_04          = "0x2F 0xF0 0x16 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_17_00          = "0x2F 0xF0 0x17 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_17_01          = "0x2F 0xF0 0x17 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_17_02          = "0x2F 0xF0 0x17 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_17_03_00       = "0x2F 0xF0 0x17 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_17_03_01       = "0x2F 0xF0 0x17 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_17_03_01_00    = "0x2F 0xF0 0x17 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_17_04          = "0x2F 0xF0 0x17 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_18_00          = "0x2F 0xF0 0x18 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_18_01          = "0x2F 0xF0 0x18 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_18_02          = "0x2F 0xF0 0x18 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_18_03_00       = "0x2F 0xF0 0x18 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_18_03_01       = "0x2F 0xF0 0x18 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_18_03_01_00    = "0x2F 0xF0 0x18 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_18_04          = "0x2F 0xF0 0x18 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_19_00          = "0x2F 0xF0 0x19 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_19_01          = "0x2F 0xF0 0x19 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_19_02          = "0x2F 0xF0 0x19 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_19_03_00       = "0x2F 0xF0 0x19 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_19_03_01       = "0x2F 0xF0 0x19 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_19_03_01_00    = "0x2F 0xF0 0x19 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_19_04          = "0x2F 0xF0 0x19 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_20_00          = "0x2F 0xF0 0x20 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_20_01          = "0x2F 0xF0 0x20 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_20_02          = "0x2F 0xF0 0x20 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_20_03_00       = "0x2F 0xF0 0x20 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_20_03_01       = "0x2F 0xF0 0x20 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_20_03_01_00    = "0x2F 0xF0 0x20 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_20_04          = "0x2F 0xF0 0x20 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_21_00          = "0x2F 0xF0 0x21 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_21_01          = "0x2F 0xF0 0x21 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_21_02          = "0x2F 0xF0 0x21 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_21_03_00       = "0x2F 0xF0 0x21 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_21_03_01       = "0x2F 0xF0 0x21 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_21_03_01_00    = "0x2F 0xF0 0x21 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_21_04          = "0x2F 0xF0 0x21 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_00          = "0x2F 0xF0 0x22 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_01          = "0x2F 0xF0 0x22 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_02          = "0x2F 0xF0 0x22 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_00       = "0x2F 0xF0 0x22 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_01       = "0x2F 0xF0 0x22 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_01_00    = "0x2F 0xF0 0x22 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_22_03_02       = "0x2F 0xF0 0x22 0x03 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_03       = "0x2F 0xF0 0x22 0x03 0x03"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_04       = "0x2F 0xF0 0x22 0x03 0x04"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_05       = "0x2F 0xF0 0x22 0x03 0x05"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_06       = "0x2F 0xF0 0x22 0x03 0x06"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_07       = "0x2F 0xF0 0x22 0x03 0x07"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_08       = "0x2F 0xF0 0x22 0x03 0x08"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_09       = "0x2F 0xF0 0x22 0x03 0x09"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_0A       = "0x2F 0xF0 0x22 0x03 0x0A"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_0B       = "0x2F 0xF0 0x22 0x03 0x0B"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_0C       = "0x2F 0xF0 0x22 0x03 0x0C"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_0D       = "0x2F 0xF0 0x22 0x03 0x0D"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_0E       = "0x2F 0xF0 0x22 0x03 0x0E"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_0F       = "0x2F 0xF0 0x22 0x03 0x0F"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_10       = "0x2F 0xF0 0x22 0x03 0x10"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_11       = "0x2F 0xF0 0x22 0x03 0x11"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_12       = "0x2F 0xF0 0x22 0x03 0x12"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_13       = "0x2F 0xF0 0x22 0x03 0x13"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_14       = "0x2F 0xF0 0x22 0x03 0x14"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_15       = "0x2F 0xF0 0x22 0x03 0x15"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_16       = "0x2F 0xF0 0x22 0x03 0x16"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_17       = "0x2F 0xF0 0x22 0x03 0x17"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_18       = "0x2F 0xF0 0x22 0x03 0x18"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_19       = "0x2F 0xF0 0x22 0x03 0x19"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_1A       = "0x2F 0xF0 0x22 0x03 0x1A"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_1B       = "0x2F 0xF0 0x22 0x03 0x1B"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_1C       = "0x2F 0xF0 0x22 0x03 0x1C"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_1D       = "0x2F 0xF0 0x22 0x03 0x1D"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_1E       = "0x2F 0xF0 0x22 0x03 0x1E"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_1F       = "0x2F 0xF0 0x22 0x03 0x1F"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_20       = "0x2F 0xF0 0x22 0x03 0x20"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_21       = "0x2F 0xF0 0x22 0x03 0x21"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_22       = "0x2F 0xF0 0x22 0x03 0x22"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_23       = "0x2F 0xF0 0x22 0x03 0x23"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_24       = "0x2F 0xF0 0x22 0x03 0x24"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_25       = "0x2F 0xF0 0x22 0x03 0x25"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_26       = "0x2F 0xF0 0x22 0x03 0x26"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_27       = "0x2F 0xF0 0x22 0x03 0x27"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_28       = "0x2F 0xF0 0x22 0x03 0x28"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_29       = "0x2F 0xF0 0x22 0x03 0x29"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_2A       = "0x2F 0xF0 0x22 0x03 0x2A"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_2B       = "0x2F 0xF0 0x22 0x03 0x2B"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_2C       = "0x2F 0xF0 0x22 0x03 0x2C"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_2D       = "0x2F 0xF0 0x22 0x03 0x2D"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_2E       = "0x2F 0xF0 0x22 0x03 0x2E"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_2F       = "0x2F 0xF0 0x22 0x03 0x2F"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_30       = "0x2F 0xF0 0x22 0x03 0x30"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_31       = "0x2F 0xF0 0x22 0x03 0x31"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_32       = "0x2F 0xF0 0x22 0x03 0x32"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_33       = "0x2F 0xF0 0x22 0x03 0x33"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_34       = "0x2F 0xF0 0x22 0x03 0x34"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_35       = "0x2F 0xF0 0x22 0x03 0x35"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_36       = "0x2F 0xF0 0x22 0x03 0x36"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_37       = "0x2F 0xF0 0x22 0x03 0x37"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_38       = "0x2F 0xF0 0x22 0x03 0x38"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_39       = "0x2F 0xF0 0x22 0x03 0x39"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_3A       = "0x2F 0xF0 0x22 0x03 0x3A"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_3B       = "0x2F 0xF0 0x22 0x03 0x3B"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_3C       = "0x2F 0xF0 0x22 0x03 0x3C"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_3D       = "0x2F 0xF0 0x22 0x03 0x3D"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_3E       = "0x2F 0xF0 0x22 0x03 0x3E"  # IO-control ($2F) request
IOC_REQ_2F_F0_22_03_3F       = "0x2F 0xF0 0x22 0x03 0x3F"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_00          = "0x2F 0xF0 0x23 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_01          = "0x2F 0xF0 0x23 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_02          = "0x2F 0xF0 0x23 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_00       = "0x2F 0xF0 0x23 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_01       = "0x2F 0xF0 0x23 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_01_00    = "0x2F 0xF0 0x23 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_2F_F0_23_03_05       = "0x2F 0xF0 0x23 0x03 0x05"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_08       = "0x2F 0xF0 0x23 0x03 0x08"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_09       = "0x2F 0xF0 0x23 0x03 0x09"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_0C       = "0x2F 0xF0 0x23 0x03 0x0C"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_0D       = "0x2F 0xF0 0x23 0x03 0x0D"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_20       = "0x2F 0xF0 0x23 0x03 0x20"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_21       = "0x2F 0xF0 0x23 0x03 0x21"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_24       = "0x2F 0xF0 0x23 0x03 0x24"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_25       = "0x2F 0xF0 0x23 0x03 0x25"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_28       = "0x2F 0xF0 0x23 0x03 0x28"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_29       = "0x2F 0xF0 0x23 0x03 0x29"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_2C       = "0x2F 0xF0 0x23 0x03 0x2C"  # IO-control ($2F) request
IOC_REQ_2F_F0_23_03_2D       = "0x2F 0xF0 0x23 0x03 0x2D"  # IO-control ($2F) request
IOC_REQ_2F_F0_24_00          = "0x2F 0xF0 0x24 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_24_01          = "0x2F 0xF0 0x24 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_24_02          = "0x2F 0xF0 0x24 0x02"  # IO-control ($2F) request
IOC_REQ_2F_F0_24_03_00       = "0x2F 0xF0 0x24 0x03 0x00"  # IO-control ($2F) request
IOC_REQ_2F_F0_24_03_01       = "0x2F 0xF0 0x24 0x03 0x01"  # IO-control ($2F) request
IOC_REQ_2F_F0_24_03_01_00    = "0x2F 0xF0 0x24 0x03 0x01 0x00"  # IO-control ($2F) request with one extra byte - deliberate invalid length (NRC 0x13 test)
IOC_REQ_SESSION_DEFAULT      = "0x10 0x01"  # DiagnosticSessionControl - return to default session
IOC_REQ_SESSION_EXTENDED     = "0x10 0x03"  # DiagnosticSessionControl - enter extended session
IOC_REQ_SESSION_PROGRAMMING  = "0x10 0x02"  # DiagnosticSessionControl - enter programming session
IOC_REQ_TESTER_PRESENT       = "0x3E 0x00"  # TesterPresent - keep session alive

# --- Responses ---
IOC_RESP_6F_0F_22_00         = "0x6F 0x0F 0x22 0x00"  # IO-control ($2F) response
IOC_RESP_6F_0F_22_01         = "0x6F 0x0F 0x22 0x01"  # IO-control ($2F) response
IOC_RESP_6F_0F_22_02         = "0x6F 0x0F 0x22 0x02"  # IO-control ($2F) response
IOC_RESP_6F_0F_22_03         = "0x6F 0x0F 0x22 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_10_00         = "0x6F 0xF0 0x10 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_10_01         = "0x6F 0xF0 0x10 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_10_02         = "0x6F 0xF0 0x10 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_10_03         = "0x6F 0xF0 0x10 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_11_00         = "0x6F 0xF0 0x11 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_11_01         = "0x6F 0xF0 0x11 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_11_02         = "0x6F 0xF0 0x11 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_11_03         = "0x6F 0xF0 0x11 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_12_00         = "0x6F 0xF0 0x12 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_12_01         = "0x6F 0xF0 0x12 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_12_02         = "0x6F 0xF0 0x12 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_12_03         = "0x6F 0xF0 0x12 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_13_00         = "0x6F 0xF0 0x13 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_13_01         = "0x6F 0xF0 0x13 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_13_02         = "0x6F 0xF0 0x13 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_13_03         = "0x6F 0xF0 0x13 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_14_00         = "0x6F 0xF0 0x14 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_14_01         = "0x6F 0xF0 0x14 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_14_02         = "0x6F 0xF0 0x14 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_14_03         = "0x6F 0xF0 0x14 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_15_00         = "0x6F 0xF0 0x15 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_15_01         = "0x6F 0xF0 0x15 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_15_02         = "0x6F 0xF0 0x15 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_15_03         = "0x6F 0xF0 0x15 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_16_00         = "0x6F 0xF0 0x16 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_16_01         = "0x6F 0xF0 0x16 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_16_02         = "0x6F 0xF0 0x16 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_16_03         = "0x6F 0xF0 0x16 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_17_00         = "0x6F 0xF0 0x17 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_17_01         = "0x6F 0xF0 0x17 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_17_02         = "0x6F 0xF0 0x17 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_17_03         = "0x6F 0xF0 0x17 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_18_00         = "0x6F 0xF0 0x18 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_18_01         = "0x6F 0xF0 0x18 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_18_02         = "0x6F 0xF0 0x18 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_18_03         = "0x6F 0xF0 0x18 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_19_00         = "0x6F 0xF0 0x19 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_19_01         = "0x6F 0xF0 0x19 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_19_02         = "0x6F 0xF0 0x19 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_19_03         = "0x6F 0xF0 0x19 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_20_00         = "0x6F 0xF0 0x20 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_20_01         = "0x6F 0xF0 0x20 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_20_02         = "0x6F 0xF0 0x20 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_20_03         = "0x6F 0xF0 0x20 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_21_00         = "0x6F 0xF0 0x21 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_21_01         = "0x6F 0xF0 0x21 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_21_02         = "0x6F 0xF0 0x21 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_21_03         = "0x6F 0xF0 0x21 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_22_00         = "0x6F 0xF0 0x22 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_22_01         = "0x6F 0xF0 0x22 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_22_02         = "0x6F 0xF0 0x22 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_22_03         = "0x6F 0xF0 0x22 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_23_00         = "0x6F 0xF0 0x23 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_23_01         = "0x6F 0xF0 0x23 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_23_02         = "0x6F 0xF0 0x23 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_23_03         = "0x6F 0xF0 0x23 0x03"  # IO-control ($2F) response
IOC_RESP_6F_F0_24_00         = "0x6F 0xF0 0x24 0x00"  # IO-control ($2F) response
IOC_RESP_6F_F0_24_01         = "0x6F 0xF0 0x24 0x01"  # IO-control ($2F) response
IOC_RESP_6F_F0_24_02         = "0x6F 0xF0 0x24 0x02"  # IO-control ($2F) response
IOC_RESP_6F_F0_24_03         = "0x6F 0xF0 0x24 0x03"  # IO-control ($2F) response
IOC_RESP_NEG_NRC11           = "0x7F 0x2F 0x11"  # Negative response - NRC 0x11 serviceNotSupported
IOC_RESP_NEG_NRC13           = "0x7F 0x2F 0x13"  # Negative response - NRC 0x13 incorrectMessageLengthOrInvalidFormat
IOC_RESP_NEG_NRC31           = "0x7F 0x2F 0x31"  # Negative response - NRC 0x31 requestOutOfRange
IOC_RESP_NEG_NRC33           = "0x7F 0x2F 0x33"  # Negative response - NRC 0x33 securityAccessDenied
IOC_RESP_NEG_NRC7F           = "0x7F 0x2F 0x7F"  # Negative response - NRC 0x7F serviceNotSupportedInActiveSession
IOC_RESP_NEG_NRC88           = "0x7F 0x2F 0x88"  # Negative response - NRC 0x88 vehicleSpeedTooHigh
IOC_RESP_SESSION_DEFAULT     = "0x50 0x01 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response (default)
IOC_RESP_SESSION_EXTENDED    = "0x50 0x03 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response (extended)
IOC_RESP_SESSION_PROGRAMMING = "0x50 0x02 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response (programming)

# --- Requests ---
UDS_REQ_10_04                            = "0x10 0x04"  # DiagnosticSessionControl request
UDS_REQ_10_08_2E_01_02_7F_0F             = "0x10 0x08 0x2E 0x01 0x02 0x7F 0x0F"  # DiagnosticSessionControl request
UDS_REQ_10_81                            = "0x10 0x81"  # DiagnosticSessionControl request
UDS_REQ_10_82                            = "0x10 0x82"  # DiagnosticSessionControl request
UDS_REQ_10_83                            = "0x10 0x83"  # DiagnosticSessionControl request
UDS_REQ_11_01                            = "0x11 0x01"  # ECUReset request
UDS_REQ_11_01_00                         = "0x11 0x01 0x00"  # ECUReset request
UDS_REQ_11_03                            = "0x11 0x03"  # ECUReset request
UDS_REQ_11_03_00                         = "0x11 0x03 0x00"  # ECUReset request
UDS_REQ_11_81                            = "0x11 0x81"  # ECUReset request
UDS_REQ_11_83                            = "0x11 0x83"  # ECUReset request
UDS_REQ_14_00_00_00                      = "0x14 0x00 0x00 0x00"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_EE_F9                      = "0x14 0xFF 0xEE 0xF9"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_EE_FF                      = "0x14 0xFF 0xEE 0xFF"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF                         = "0x14 0xFF 0xFF"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_F0                      = "0x14 0xFF 0xFF 0xF0"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_FF_01                   = "0x14 0xFF 0xFF 0xFF 0x01"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_FF_03                   = "0x14 0xFF 0xFF 0xFF 0x03"  # ClearDiagnosticInformation request
UDS_REQ_14_FF_FF_FF_06                   = "0x14 0xFF 0xFF 0xFF 0x06"  # ClearDiagnosticInformation request
UDS_REQ_19                               = "0x19"  # ReadDTCInformation request
UDS_REQ_19_01_CB                         = "0x19 0x01 0xCB"  # ReadDTCInformation request
UDS_REQ_19_01_FF                         = "0x19 0x01 0xFF"  # ReadDTCInformation request
UDS_REQ_19_01_FF_FF_FF                   = "0x19 0x01 0xFF 0xFF 0xFF"  # ReadDTCInformation request
UDS_REQ_19_02_08                         = "0x19 0x02 0x08"  # ReadDTCInformation request
UDS_REQ_19_02_80_01_13_FF                = "0x19 0x02 0x80 0x01 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_02_FF                         = "0x19 0x02 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_80_10_1A_01                = "0x19 0x04 0x80 0x10 0x1A 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_10_1A_02                = "0x19 0x04 0x80 0x10 0x1A 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_10_1A_FF                = "0x19 0x04 0x80 0x10 0x1A 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_80_70_13_01                = "0x19 0x04 0x80 0x70 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_70_13_02                = "0x19 0x04 0x80 0x70 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_72_11_01                = "0x19 0x04 0x80 0x72 0x11 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_72_11_02                = "0x19 0x04 0x80 0x72 0x11 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_72_11_FF                = "0x19 0x04 0x80 0x72 0x11 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_80_95_96_01                = "0x19 0x04 0x80 0x95 0x96 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_80_95_96_02                = "0x19 0x04 0x80 0x95 0x96 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_80_95_96_FF                = "0x19 0x04 0x80 0x95 0x96 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_04_1B_01                = "0x19 0x04 0x92 0x04 0x1B 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_04_1B_02                = "0x19 0x04 0x92 0x04 0x1B 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_04_1B_FF                = "0x19 0x04 0x92 0x04 0x1B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_06_64_01                = "0x19 0x04 0x92 0x06 0x64 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_06_64_02                = "0x19 0x04 0x92 0x06 0x64 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_06_64_FF                = "0x19 0x04 0x92 0x06 0x64 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_07_12_01                = "0x19 0x04 0x92 0x07 0x12 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_07_12_02                = "0x19 0x04 0x92 0x07 0x12 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_07_12_FF                = "0x19 0x04 0x92 0x07 0x12 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_0A_13_FF                = "0x19 0x04 0x92 0x0A 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_0B_13_01                = "0x19 0x04 0x92 0x0B 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_0B_13_02                = "0x19 0x04 0x92 0x0B 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_0B_13_FF                = "0x19 0x04 0x92 0x0B 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_10_12_01                = "0x19 0x04 0x92 0x10 0x12 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_10_12_02                = "0x19 0x04 0x92 0x10 0x12 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_10_12_FF                = "0x19 0x04 0x92 0x10 0x12 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_18_11_01                = "0x19 0x04 0x92 0x18 0x11 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_18_11_02                = "0x19 0x04 0x92 0x18 0x11 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_18_11_FF                = "0x19 0x04 0x92 0x18 0x11 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_1C_13_01                = "0x19 0x04 0x92 0x1C 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_1C_13_02                = "0x19 0x04 0x92 0x1C 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_1C_13_FF                = "0x19 0x04 0x92 0x1C 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_53_2B_01                = "0x19 0x04 0x92 0x53 0x2B 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_53_2B_02                = "0x19 0x04 0x92 0x53 0x2B 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_53_2B_FF                = "0x19 0x04 0x92 0x53 0x2B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_92_54_2B_01                = "0x19 0x04 0x92 0x54 0x2B 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_92_54_2B_02                = "0x19 0x04 0x92 0x54 0x2B 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_92_54_2B_FF                = "0x19 0x04 0x92 0x54 0x2B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_98_F9_13_01                = "0x19 0x04 0x98 0xF9 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_98_F9_13_02                = "0x19 0x04 0x98 0xF9 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_98_F9_13_FF                = "0x19 0x04 0x98 0xF9 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_99_0E_13_01                = "0x19 0x04 0x99 0x0E 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_99_0E_13_02                = "0x19 0x04 0x99 0x0E 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_99_0E_13_FF                = "0x19 0x04 0x99 0x0E 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_99_14_13_01                = "0x19 0x04 0x99 0x14 0x13 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_99_14_13_02                = "0x19 0x04 0x99 0x14 0x13 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_99_14_13_FF                = "0x19 0x04 0x99 0x14 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_D2_71_00_01                = "0x19 0x04 0xD2 0x71 0x00 0x01"  # ReadDTCInformation request
UDS_REQ_19_04_D2_71_00_02                = "0x19 0x04 0xD2 0x71 0x00 0x02"  # ReadDTCInformation request
UDS_REQ_19_04_D2_71_00_FF                = "0x19 0x04 0xD2 0x71 0x00 0xFF"  # ReadDTCInformation request
UDS_REQ_19_04_FF                         = "0x19 0x04 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06                            = "0x19 0x06"  # ReadDTCInformation request
UDS_REQ_19_06_80_01_13_FF                = "0x19 0x06 0x80 0x01 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_10_13_FF                = "0x19 0x06 0x80 0x10 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_70_13_FF                = "0x19 0x06 0x80 0x70 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_72_13_FF                = "0x19 0x06 0x80 0x72 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_90_13_FF                = "0x19 0x06 0x80 0x90 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_80_95_13_FF                = "0x19 0x06 0x80 0x95 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_90_13_49_FF                = "0x19 0x06 0x90 0x13 0x49 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_90_32_12_FF                = "0x19 0x06 0x90 0x32 0x12 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_0A_13_FF                = "0x19 0x06 0x92 0x0A 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_11_01                = "0x19 0x06 0x92 0x0B 0x11 0x01"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_11_02                = "0x19 0x06 0x92 0x0B 0x11 0x02"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_11_FF                = "0x19 0x06 0x92 0x0B 0x11 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_0B_13_FF                = "0x19 0x06 0x92 0x0B 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_1B_13_FF                = "0x19 0x06 0x92 0x1B 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_1C_13_FF                = "0x19 0x06 0x92 0x1C 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_36_13_FF                = "0x19 0x06 0x92 0x36 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_92_37_13_FF                = "0x19 0x06 0x92 0x37 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_06_D1_01_00_FF                = "0x19 0x06 0xD1 0x01 0x00 0xFF"  # ReadDTCInformation request
UDS_REQ_19_08_80_90_13_FF                = "0x19 0x08 0x80 0x90 0x13 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0A_FF                         = "0x19 0x0A 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0B_FF                         = "0x19 0x0B 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0C_FF                         = "0x19 0x0C 0xFF"  # ReadDTCInformation request
UDS_REQ_19_0E_FF                         = "0x19 0x0E 0xFF"  # ReadDTCInformation request
UDS_REQ_22                               = "0x22"  # ReadDataByIdentifier request
UDS_REQ_22_01_00                         = "0x22 0x01 0x00"  # ReadDataByIdentifier request
UDS_REQ_22_02_00                         = "0x22 0x02 0x00"  # ReadDataByIdentifier request
UDS_REQ_22_04_5A                         = "0x22 0x04 0x5A"  # ReadDataByIdentifier request
UDS_REQ_22_F1_00                         = "0x22 0xF1 0x00"  # ReadDataByIdentifier request
UDS_REQ_22_F1_99                         = "0x22 0xF1 0x99"  # ReadDataByIdentifier request
UDS_REQ_22_F1_9D                         = "0x22 0xF1 0x9D"  # ReadDataByIdentifier request
UDS_REQ_22_F1_B2                         = "0x22 0xF1 0xB2"  # ReadDataByIdentifier request
UDS_REQ_22_F1_B6                         = "0x22 0xF1 0xB6"  # ReadDataByIdentifier request
UDS_REQ_22_F1_C0                         = "0x22 0xF1 0xC0"  # ReadDataByIdentifier request
UDS_REQ_27_01                            = "0x27 0x01"  # SecurityAccess request
UDS_REQ_27_01_FF_FF_FF_FF_FF             = "0x27 0x01 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_02                            = "0x27 0x02"  # SecurityAccess request
UDS_REQ_27_02_AA_AA_AA_AA                = "0x27 0x02 0xAA 0xAA 0xAA 0xAA"  # SecurityAccess request
UDS_REQ_27_02_FF_FF_FF_FF_FF             = "0x27 0x02 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_05                            = "0x27 0x05"  # SecurityAccess request
UDS_REQ_27_05_FF_FF_FF_FF_FF             = "0x27 0x05 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_06                            = "0x27 0x06"  # SecurityAccess request
UDS_REQ_27_06_AA_AA_AA_AA                = "0x27 0x06 0xAA 0xAA 0xAA 0xAA"  # SecurityAccess request
UDS_REQ_27_06_FF_FF_FF_FF_FF             = "0x27 0x06 0xFF 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess request
UDS_REQ_27_61                            = "0x27 0x61"  # SecurityAccess request
UDS_REQ_27_85                            = "0x27 0x85"  # SecurityAccess request
UDS_REQ_28_00_01                         = "0x28 0x00 0x01"  # CommunicationControl request
UDS_REQ_28_00_02                         = "0x28 0x00 0x02"  # CommunicationControl request
UDS_REQ_28_00_03                         = "0x28 0x00 0x03"  # CommunicationControl request
UDS_REQ_28_00_FF                         = "0x28 0x00 0xFF"  # CommunicationControl request
UDS_REQ_28_01_01                         = "0x28 0x01 0x01"  # CommunicationControl request
UDS_REQ_28_01_02                         = "0x28 0x01 0x02"  # CommunicationControl request
UDS_REQ_28_01_03                         = "0x28 0x01 0x03"  # CommunicationControl request
UDS_REQ_28_01_FF                         = "0x28 0x01 0xFF"  # CommunicationControl request
UDS_REQ_28_02_01                         = "0x28 0x02 0x01"  # CommunicationControl request
UDS_REQ_28_02_02                         = "0x28 0x02 0x02"  # CommunicationControl request
UDS_REQ_28_02_03                         = "0x28 0x02 0x03"  # CommunicationControl request
UDS_REQ_28_02_FF                         = "0x28 0x02 0xFF"  # CommunicationControl request
UDS_REQ_28_03                            = "0x28 0x03"  # CommunicationControl request
UDS_REQ_28_03_01                         = "0x28 0x03 0x01"  # CommunicationControl request
UDS_REQ_28_03_02                         = "0x28 0x03 0x02"  # CommunicationControl request
UDS_REQ_28_03_03                         = "0x28 0x03 0x03"  # CommunicationControl request
UDS_REQ_28_80_01                         = "0x28 0x80 0x01"  # CommunicationControl request
UDS_REQ_28_80_02                         = "0x28 0x80 0x02"  # CommunicationControl request
UDS_REQ_28_80_03                         = "0x28 0x80 0x03"  # CommunicationControl request
UDS_REQ_28_81_01                         = "0x28 0x81 0x01"  # CommunicationControl request
UDS_REQ_28_81_02                         = "0x28 0x81 0x02"  # CommunicationControl request
UDS_REQ_28_81_03                         = "0x28 0x81 0x03"  # CommunicationControl request
UDS_REQ_28_82_01                         = "0x28 0x82 0x01"  # CommunicationControl request
UDS_REQ_28_82_02                         = "0x28 0x82 0x02"  # CommunicationControl request
UDS_REQ_28_82_03                         = "0x28 0x82 0x03"  # CommunicationControl request
UDS_REQ_28_83_01                         = "0x28 0x83 0x01"  # CommunicationControl request
UDS_REQ_28_83_02                         = "0x28 0x83 0x02"  # CommunicationControl request
UDS_REQ_28_83_03                         = "0x28 0x83 0x03"  # CommunicationControl request
UDS_REQ_2E_01_00_18                      = "0x2E 0x01 0x00 0x18"  # WriteDataByIdentifier request
UDS_REQ_2E_01_00_18_18_18_18_18_18_18_18_18__5befe0 = "0x2E 0x01 0x00 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18 0x18"  # WriteDataByIdentifier request
UDS_REQ_2E_01_01_19_00_00_02_00_14_00_04_00__c9c75d = "0x2E 0x01 0x01 0x19 0x00 0x00 0x02 0x00 0x14 0x00 0x04 0x00 0x00 0x00 0x04 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_01_01_2B_10_00_03_20_00_20_04_00__bed290 = "0x2E 0x01 0x01 0x2B 0x10 0x00 0x03 0x20 0x00 0x20 0x04 0x00 0x00 0x00 0x04 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_01_02_03_03_CD_A0             = "0x2E 0x01 0x02 0x03 0x03 0xCD 0xA0"  # WriteDataByIdentifier request
UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01    = "0x2E 0x01 0x02 0x7F 0x0F 0x0F 0xAB 0x2A 0x18 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_01_02_7F_8F_CF_AF_AA_1A_01    = "0x2E 0x01 0x02 0x7F 0x8F 0xCF 0xAF 0xAA 0x1A 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_02_00_02                      = "0x2E 0x02 0x00 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_02_01_02                      = "0x2E 0x02 0x01 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_04_46_02                      = "0x2E 0x04 0x46 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_00_01                      = "0x2E 0xF1 0x00 0x01"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_00_02                      = "0x2E 0xF1 0x00 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_00_03                      = "0x2E 0xF1 0x00 0x03"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_80_02                      = "0x2E 0xF1 0x80 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_81                         = "0x2E 0xF1 0x81"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_82_02                      = "0x2E 0xF1 0x82 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_86_02                      = "0x2E 0xF1 0x86 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_87_02                      = "0x2E 0xF1 0x87 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_8A_02                      = "0x2E 0xF1 0x8A 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_8B_02                      = "0x2E 0xF1 0x8B 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_8C_02                      = "0x2E 0xF1 0x8C 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_90                         = "0x2E 0xF1 0x90"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_90_32_32_32_32_32_32_32_32_32__faa1a9 = "0x2E 0xF1 0x90 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32 0x32"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_91_02                      = "0x2E 0xF1 0x91 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086 = "0x2E 0xF1 0x98 0xAA 0xAA 0xAA 0xAA 0xAA 0xAA 0x20 0x20 0x20 0x20 0x20 0x20 0x20 0x20 0x20 0x20"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_99_23_02_26                = "0x2E 0xF1 0x99 0x23 0x02 0x26"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_9D_18_09_18                = "0x2E 0xF1 0x9D 0x18 0x09 0x18"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_B7_02                      = "0x2E 0xF1 0xB7 0x02"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_C0_03                      = "0x2E 0xF1 0xC0 0x03"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_C0_05                      = "0x2E 0xF1 0xC0 0x05"  # WriteDataByIdentifier request
UDS_REQ_2E_F1_C0_0A                      = "0x2E 0xF1 0xC0 0x0A"  # WriteDataByIdentifier request
UDS_REQ_3E                               = "0x3E"  # TesterPresent request
UDS_REQ_3E_80                            = "0x3E 0x80"  # TesterPresent request
UDS_REQ_85_01                            = "0x85 0x01"  # ControlDTCSetting request
UDS_REQ_85_02                            = "0x85 0x02"  # ControlDTCSetting request
UDS_REQ_85_7F                            = "0x85 0x7F"  # ControlDTCSetting request
UDS_REQ_85_81                            = "0x85 0x81"  # ControlDTCSetting request
UDS_REQ_85_82                            = "0x85 0x82"  # ControlDTCSetting request
UDS_REQ_CLEAR_ALL_DTC                    = "0x14 0xFF 0xFF 0xFF"  # ClearDiagnosticInformation request
UDS_REQ_READ_ACTIVE_SESSION              = "0x22 0xF1 0x86"  # ReadDataByIdentifier request
UDS_REQ_SESSION_DEFAULT                  = "0x10 0x01"  # DiagnosticSessionControl request
UDS_REQ_SESSION_EXTENDED                 = "0x10 0x03"  # DiagnosticSessionControl request
UDS_REQ_SESSION_PROGRAMMING              = "0x10 0x02"  # DiagnosticSessionControl request
UDS_REQ_TESTER_PRESENT                   = "0x3E 0x00"  # TesterPresent request

# --- Expected responses ---
UDS_NO_RESPONSE                          = "No response"  # ECU shall not respond
UDS_RESP_50_01_00_32_01_F4               = "0x50 0x01 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_50_01_00_C8_01_F4               = "0x50 0x01 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_50_02                           = "0x50 0x02"  # DiagnosticSessionControl positive response
UDS_RESP_50_02_00_C8_01_F4               = "0x50 0x02 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_50_03                           = "0x50 0x03"  # DiagnosticSessionControl positive response
UDS_RESP_50_03_00_32_13_88               = "0x50 0x03 0x00 0x32 0x13 0x88"  # DiagnosticSessionControl positive response
UDS_RESP_50_03_00_C8_01_F4               = "0x50 0x03 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_51_01                           = "0x51 0x01"  # ECUReset positive response
UDS_RESP_51_03                           = "0x51 0x03"  # ECUReset positive response
UDS_RESP_54                              = "0x54"  # ClearDiagnosticInformation positive response
UDS_RESP_59_01_CB                        = "0x59 0x01 0xCB"  # ReadDTCInformation positive response
UDS_RESP_59_02_80_01_13                  = "0x59 0x02 0x80 0x01 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_02_80_01_13_00_00            = "0x59 0x02 0x80 0x01 0x13 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_02_CB                        = "0x59 0x02 0xCB"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_10_1A_8B_01_11         = "0x59 0x04 0x80 0x10 0x1A 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_10_1A_8B_02_11         = "0x59 0x04 0x80 0x10 0x1A 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_72_11_8B_01_11         = "0x59 0x04 0x80 0x72 0x11 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_72_11_8B_02_11         = "0x59 0x04 0x80 0x72 0x11 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_95_96_08_01_11         = "0x59 0x04 0x80 0x95 0x96 0x08 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_80_95_96_08_02_11         = "0x59 0x04 0x80 0x95 0x96 0x08 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_00_00_8B               = "0x59 0x04 0x92 0x00 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_04_1B_8B_01_11         = "0x59 0x04 0x92 0x04 0x1B 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_04_1B_8B_02_11         = "0x59 0x04 0x92 0x04 0x1B 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_06_64_8B_01_11         = "0x59 0x04 0x92 0x06 0x64 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_06_64_8B_02_11         = "0x59 0x04 0x92 0x06 0x64 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_07_12_8B_01_11         = "0x59 0x04 0x92 0x07 0x12 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_07_12_8B_02_11         = "0x59 0x04 0x92 0x07 0x12 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_0B_13_8B_01_11         = "0x59 0x04 0x92 0x0B 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_0B_13_8B_02_11         = "0x59 0x04 0x92 0x0B 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_10_12_8B_01_11         = "0x59 0x04 0x92 0x10 0x12 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_10_12_8B_02_11         = "0x59 0x04 0x92 0x10 0x12 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_18_11_8B_01_11         = "0x59 0x04 0x92 0x18 0x11 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_18_11_8B_02_11         = "0x59 0x04 0x92 0x18 0x11 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_1C_13_13_8B_02         = "0x59 0x04 0x92 0x1C 0x13 0x13 0x8B 0x02"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_1C_13_8B_01_11         = "0x59 0x04 0x92 0x1C 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_53_2B_8B_01_11         = "0x59 0x04 0x92 0x53 0x2B 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_53_2B_8B_02_11         = "0x59 0x04 0x92 0x53 0x2B 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_54_2B_8B_01_11         = "0x59 0x04 0x92 0x54 0x2B 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_92_54_2B_8B_02_11         = "0x59 0x04 0x92 0x54 0x2B 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_98_F9_13_8B_01_11         = "0x59 0x04 0x98 0xF9 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_98_F9_13_8B_02_11         = "0x59 0x04 0x98 0xF9 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_0E_13_8B_01_11         = "0x59 0x04 0x99 0x0E 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_0E_13_8B_02_11         = "0x59 0x04 0x99 0x0E 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_14_13_8B_01_11         = "0x59 0x04 0x99 0x14 0x13 0x8B 0x01 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_99_14_13_8B_02_11         = "0x59 0x04 0x99 0x14 0x13 0x8B 0x02 0x11"  # ReadDTCInformation positive response
UDS_RESP_59_04_D2_71_00_8B               = "0x59 0x04 0xD2 0x71 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_01_13                  = "0x59 0x06 0x80 0x01 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_01_13_8B_01            = "0x59 0x06 0x80 0x01 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_10_13_40               = "0x59 0x06 0x80 0x10 0x13 0x40"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_10_13_8B_01            = "0x59 0x06 0x80 0x10 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13                  = "0x59 0x06 0x80 0x70 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13_00_00            = "0x59 0x06 0x80 0x70 0x13 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13_00_8B            = "0x59 0x06 0x80 0x70 0x13 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_70_13_8B_01            = "0x59 0x06 0x80 0x70 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_72_13                  = "0x59 0x06 0x80 0x72 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_72_13_00_00            = "0x59 0x06 0x80 0x72 0x13 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_72_13_00_8B            = "0x59 0x06 0x80 0x72 0x13 0x00 0x8B"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_90_13                  = "0x59 0x06 0x80 0x90 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_90_13_40               = "0x59 0x06 0x80 0x90 0x13 0x40"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_90_13_8B_01            = "0x59 0x06 0x80 0x90 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_95_13_00               = "0x59 0x06 0x80 0x95 0x13 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_80_95_13_8B_01            = "0x59 0x06 0x80 0x95 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_90_13_49_00_00            = "0x59 0x06 0x90 0x13 0x49 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_90_13_49_8B_01            = "0x59 0x06 0x90 0x13 0x49 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_90_32_12_40               = "0x59 0x06 0x90 0x32 0x12 0x40"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0A_13                  = "0x59 0x06 0x92 0x0A 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_08_01_01         = "0x59 0x06 0x92 0x0B 0x11 0x08 0x01 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_8B_01_01         = "0x59 0x06 0x92 0x0B 0x11 0x8B 0x01 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_8B_02            = "0x59 0x06 0x92 0x0B 0x11 0x8B 0x02"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_11_8B_02_01         = "0x59 0x06 0x92 0x0B 0x11 0x8B 0x02 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_13                  = "0x59 0x06 0x92 0x0B 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_0B_13_00               = "0x59 0x06 0x92 0x0B 0x13 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_1B_13_8B_01            = "0x59 0x06 0x92 0x1B 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_1C_13                  = "0x59 0x06 0x92 0x1C 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_1C_13_8B_01            = "0x59 0x06 0x92 0x1C 0x13 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_36_13                  = "0x59 0x06 0x92 0x36 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_92_37_13                  = "0x59 0x06 0x92 0x37 0x13"  # ReadDTCInformation positive response
UDS_RESP_59_06_D1_01_00_00               = "0x59 0x06 0xD1 0x01 0x00 0x00"  # ReadDTCInformation positive response
UDS_RESP_59_06_D1_01_00_8B_01            = "0x59 0x06 0xD1 0x01 0x00 0x8B 0x01"  # ReadDTCInformation positive response
UDS_RESP_62_02_00_01                     = "0x62 0x02 0x00 0x01"  # ReadDataByIdentifier positive response
UDS_RESP_62_04_5A                        = "0x62 0x04 0x5A"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1                           = "0x62 0xF1"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_00_01                     = "0x62 0xF1 0x00 0x01"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_00_02                     = "0x62 0xF1 0x00 0x02"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_00_03                     = "0x62 0xF1 0x00 0x03"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_86                        = "0x62 0xF1 0x86"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_90                        = "0x62 0xF1 0x90"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_99_23_02_26               = "0x62 0xF1 0x99 0x23 0x02 0x26"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_9D_18_09_18               = "0x62 0xF1 0x9D 0x18 0x09 0x18"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2                        = "0x62 0xF1 0xB2"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_00_00                  = "0x62 0xF1 0xB2 0x00 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_00_C0                  = "0x62 0xF1 0xB2 0x00 0xC0"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_19_00                  = "0x62 0xF1 0xB2 0x19 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B2_4B_00                  = "0x62 0xF1 0xB2 0x4B 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00                     = "0x62 0xF1 0xB6 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00                  = "0x62 0xF1 0xB6 0x00 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_00_1B            = "0x62 0xF1 0xB6 0x00 0x00 0x00 0x1B"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_00_1C            = "0x62 0xF1 0xB6 0x00 0x00 0x00 0x1C"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_02_42            = "0x62 0xF1 0xB6 0x00 0x00 0x02 0x42"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_B6_00_00_02_43_00         = "0x62 0xF1 0xB6 0x00 0x00 0x02 0x43 0x00"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_C0_03                     = "0x62 0xF1 0xC0 0x03"  # ReadDataByIdentifier positive response
UDS_RESP_62_F1_C0_05                     = "0x62 0xF1 0xC0 0x05"  # ReadDataByIdentifier positive response
UDS_RESP_67_01                           = "0x67 0x01"  # SecurityAccess positive response
UDS_RESP_67_01_00_00_00_00               = "0x67 0x01 0x00 0x00 0x00 0x00"  # SecurityAccess positive response
UDS_RESP_67_05                           = "0x67 0x05"  # SecurityAccess positive response
UDS_RESP_67_06                           = "0x67 0x06"  # SecurityAccess positive response
UDS_RESP_67_61                           = "0x67 0x61"  # SecurityAccess positive response
UDS_RESP_68_00                           = "0x68 0x00"  # CommunicationControl positive response
UDS_RESP_68_01                           = "0x68 0x01"  # CommunicationControl positive response
UDS_RESP_68_02                           = "0x68 0x02"  # CommunicationControl positive response
UDS_RESP_68_03                           = "0x68 0x03"  # CommunicationControl positive response
UDS_RESP_6E_01_00                        = "0x6E 0x01 0x00"  # WriteDataByIdentifier positive response
UDS_RESP_6E_01_01                        = "0x6E 0x01 0x01"  # WriteDataByIdentifier positive response
UDS_RESP_6E_01_02                        = "0x6E 0x01 0x02"  # WriteDataByIdentifier positive response
UDS_RESP_6E_F1_00                        = "0x6E 0xF1 0x00"  # WriteDataByIdentifier positive response
UDS_RESP_6E_F1_C0                        = "0x6E 0xF1 0xC0"  # WriteDataByIdentifier positive response
UDS_RESP_7F_10_33                        = "0x7F 0x10 0x33"  # DiagnosticSessionControl negative response (NRC 0x33)
UDS_RESP_7F_10_78                        = "0x7F 0x10 0x78"  # DiagnosticSessionControl negative response (NRC 0x78)
UDS_RESP_7F_10_7E                        = "0x7F 0x10 0x7E"  # DiagnosticSessionControl negative response (NRC 0x7E)
UDS_RESP_7F_10_88                        = "0x7F 0x10 0x88"  # DiagnosticSessionControl negative response (NRC 0x88)
UDS_RESP_7F_11                           = "0x7F 0x11"  # service 0x3F positive response
UDS_RESP_7F_11_22                        = "0x7F 0x11 0x22"  # ECUReset negative response (NRC 0x22)
UDS_RESP_7F_11_7F                        = "0x7F 0x11 0x7F"  # ECUReset negative response (NRC 0x7F)
UDS_RESP_7F_11_33                        = "0x7F 0x11 0x33"  # ECUReset negative response (NRC 0x33)
UDS_RESP_7F_11_13                        = "0x7F 0x11 0x13"  # ECUReset negative response (NRC 0x13)
UDS_RESP_7F_11_88                        = "0x7F 0x11 0x88"  # ECUReset negative response (NRC 0x88)
UDS_RESP_7F_14_11                        = "0x7F 0x14 0x11"  # ClearDiagnosticInformation negative response (NRC 0x11)
UDS_RESP_7F_14_13                        = "0x7F 0x14 0x13"  # ClearDiagnosticInformation negative response (NRC 0x13)
UDS_RESP_7F_14_22                        = "0x7F 0x14 0x22"  # ClearDiagnosticInformation negative response (NRC 0x22)
UDS_RESP_7F_14_31                        = "0x7F 0x14 0x31"  # ClearDiagnosticInformation negative response (NRC 0x31)
UDS_RESP_7F_14_7F                        = "0x7F 0x14 0x7F"  # ClearDiagnosticInformation negative response (NRC 0x7F)
UDS_RESP_7F_14_88                        = "0x7F 0x14 0x88"  # ClearDiagnosticInformation negative response (NRC 0x88)
UDS_RESP_7F_19_11                        = "0x7F 0x19 0x11"  # ReadDTCInformation negative response (NRC 0x11)
UDS_RESP_7F_19_12                        = "0x7F 0x19 0x12"  # ReadDTCInformation negative response (NRC 0x12)
UDS_RESP_7F_19_13                        = "0x7F 0x19 0x13"  # ReadDTCInformation negative response (NRC 0x13)
UDS_RESP_7F_19_31                        = "0x7F 0x19 0x31"  # ReadDTCInformation negative response (NRC 0x31)
UDS_RESP_7F_27_12                        = "0x7F 0x27 0x12"  # SecurityAccess negative response (NRC 0x12)
UDS_RESP_7F_27_13                        = "0x7F 0x27 0x13"  # SecurityAccess negative response (NRC 0x13)
UDS_RESP_7F_27_24                        = "0x7F 0x27 0x24"  # SecurityAccess negative response (NRC 0x24)
UDS_RESP_7F_27_24_FF_FF_FF_FF            = "0x7F 0x27 0x24 0xFF 0xFF 0xFF 0xFF"  # SecurityAccess negative response (NRC 0x24)
UDS_RESP_7F_27_35                        = "0x7F 0x27 0x35"  # SecurityAccess negative response (NRC 0x35)
UDS_RESP_7F_27_36                        = "0x7F 0x27 0x36"  # SecurityAccess negative response (NRC 0x36)
UDS_RESP_7F_27_37                        = "0x7F 0x27 0x37"  # SecurityAccess negative response (NRC 0x37)
UDS_RESP_7F_27_7F                        = "0x7F 0x27 0x7F"  # SecurityAccess negative response (NRC 0x7F)
UDS_RESP_7F_28_13                        = "0x7F 0x28 0x13"  # CommunicationControl negative response (NRC 0x13)
UDS_RESP_7F_28_31                        = "0x7F 0x28 0x31"  # CommunicationControl negative response (NRC 0x31)
UDS_RESP_7F_28_7F                        = "0x7F 0x28 0x7F"  # CommunicationControl negative response (NRC 0x7F)
UDS_RESP_7F_28_88                        = "0x7F 0x28 0x88"  # CommunicationControl negative response (NRC 0x88)
UDS_RESP_7F_2E_11_00_00_00_00            = "0x7F 0x2E 0x11 0x00 0x00 0x00 0x00"  # WriteDataByIdentifier negative response (NRC 0x11)
UDS_RESP_7F_2E_13                        = "0x7F 0x2E 0x13"  # WriteDataByIdentifier negative response (NRC 0x13)
UDS_RESP_7F_2E_22                        = "0x7F 0x2E 0x22"  # WriteDataByIdentifier negative response (NRC 0x22)
UDS_RESP_7F_2E_31                        = "0x7F 0x2E 0x31"  # WriteDataByIdentifier negative response (NRC 0x31)
UDS_RESP_7F_2E_33                        = "0x7F 0x2E 0x33"  # WriteDataByIdentifier negative response (NRC 0x33)
UDS_RESP_7F_2E_7F                        = "0x7F 0x2E 0x7F"  # WriteDataByIdentifier negative response (NRC 0x7F)
UDS_RESP_7F_2E_83_00_00_00_00            = "0x7F 0x2E 0x83 0x00 0x00 0x00 0x00"  # WriteDataByIdentifier negative response (NRC 0x83)
UDS_RESP_7F_2E_88                        = "0x7F 0x2E 0x88"  # WriteDataByIdentifier negative response (NRC 0x88)
UDS_RESP_7F_3E_13                        = "0x7F 0x3E 0x13"  # TesterPresent negative response (NRC 0x13)
UDS_RESP_7F_85_7F                        = "0x7F 0x85 0x7F"  # ControlDTCSetting negative response (NRC 0x7F)
UDS_RESP_ACTIVE_SESSION_DEFAULT          = "0x62 0xF1 0x86 0x01"  # ReadDataByIdentifier positive response
UDS_RESP_ACTIVE_SESSION_EXTENDED         = "0x62 0xF1 0x86 0x03"  # ReadDataByIdentifier positive response
UDS_RESP_ACTIVE_SESSION_PROGRAMMING      = "0x62 0xF1 0x86 0x02"  # ReadDataByIdentifier positive response
UDS_RESP_C5_01                           = "0xC5 0x01"  # ControlDTCSetting positive response
UDS_RESP_C5_02                           = "0xC5 0x02"  # ControlDTCSetting positive response
UDS_RESP_SESSION_DEFAULT                 = "0x50 0x01 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_SESSION_EXTENDED                = "0x50 0x03 0x00 0x32 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_SESSION_PROGRAMMING             = "0x50 0x02 0x00 0xC8 0x01 0xF4"  # DiagnosticSessionControl positive response
UDS_RESP_TESTER_PRESENT                  = "0x7E 0x00"  # TesterPresent positive response

# UDS $19/$04 snapshot schema. Remove a DID or binding for a variant that does
# not support it; the CAND script will then neither send that signal nor decode it.
SNAPSHOT_19_04_CONFIG = {
    "uds": {
        "request_prefix": (0x19, 0x04),
        "positive_response_prefix": (0x59, 0x04),
        "records": {"record_1": 0x01, "record_2": 0x02, "record_ff": 0xFF},
    },
    "fault": {
        "rsu_channel": "RSU_CH11",
        "fault_type": "Communication_Error",
    },
    "timing": {
        "signal_settle_ms": 200,
        "ignition_off_settle_ms": 1000,
        "post_ignition_initialization_ms": 7000,
    },
    "signal_bindings": {
        "vehicle_speed": "VEHICLE_SPEED",
        "battery_voltage": "BATT_VOLT",
        "odometer": "Odometer",
        "vehicle_state": "VEHICLE_STATE",
        "brake_switch": "BRK_SWITCH",
        "accelerator_pedal": "RAW_ACC_PEDAL_VALUE",
        "clock_date": "CLOCK_DATE",
        "clock_format": "CLOCK_FORMAT",
        "clock_hour": "CLOCK_HOUR",
        "clock_min": "CLOCK_MIN",
        "clock_month": "CLOCK_MONTH",
        "clock_year": "CLOCK_YEAR",
        "pke_clmp_state": "PKE_CLMP_STATE",
    },
    "decoder_defaults": {"byte_order": "big", "signed": False},
    "profiles": {
        "baseline": {
            "enabled": True,
            "values": {
                "vehicle_speed": {"expected": 5.0, "raw": 320},
                "battery_voltage": {"expected": 12.0, "raw": 48},
                "ign_voltage": {"expected": 12.0},
                "odometer": {"expected": 0x50, "raw": 0x50},
                "vehicle_state": {"expected": 2, "raw": 2},
                "passenger_seat_belt": {"expected": 0},
                "driver_seat_belt": {"expected": 0},
                "passenger_airbag_status": {"expected": 0},
                "passenger_ods": {"expected": 1},
                "airbag_warning_lamp": {"expected": 0},
                "brake_switch": {"expected": 1, "raw": 1},
                "accelerator_pedal": {"expected": 50.0, "raw": 500},
                "clock_date": {"expected": 1, "raw": 1},
                "clock_format": {"expected": 0, "raw": 0},
                "clock_hour": {"expected": 1, "raw": 1},
                "clock_min": {"expected": 1, "raw": 1},
                "clock_month": {"expected": 1, "raw": 1},
                "clock_year": {"expected": 2026, "raw": 6},
                "reset_counter": {"expected": 1},
                "srs_operation_mode": {"expected": 1},
                "stps_fr": {"expected": 0},
                "stps_fl": {"expected": 1},
                "passenger_seat_occupant": {"expected": 1},
                "pke_clmp_state": {"expected": 1, "raw": 1},
                "pab_on_lamp": {"expected": 0},
                "pab_off_lamp": {"expected": 1},
                "padi_on_fault": {"expected": 0},
                "padi_off_fault": {"expected": 0},
            },
        },
        "first_update": {
            "enabled": True,
            "values": {
                "vehicle_speed": {"expected": 0x27, "raw": 2496},
                "battery_voltage": {"expected": 13.0, "raw": 52},
                "ign_voltage": {"expected": 12.0},
                "vehicle_state": {"expected": 3, "raw": 3},
                "brake_switch": {"expected": 0, "raw": 0},
                "accelerator_pedal": {"expected": 63.0, "raw": 630},
                "airbag_warning_lamp": {"expected": 1},
                "pke_clmp_state": {"expected": 2, "raw": 2},
                "passenger_seat_occupant": {"expected": 1},
                "srs_operation_mode": {"expected": 1},
                "reset_counter": {"expected": 1},
            },
        },
        "second_update": {
            "enabled": False,
            "reason": "No third input-value set was supplied. Populate values and enable before execution.",
            "values": {},
        },
    },
    "dids": {
        "F1B2": {"payload_length": 2, "fields": [
            {"name": "vehicle_speed", "byte_offset": 0, "byte_length": 2, "bit_offset": 0, "bit_length": 16, "resolution": 0.015625, "factor": 64, "offset": 0, "value_key": "vehicle_speed", "tolerance": 0.0},
        ]},
        "F1B1": {"payload_length": 2, "fields": [
            {"name": "power_supply_voltage", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 0.1, "factor": 1, "offset": 0, "value_key": "battery_voltage", "tolerance": 0.0},
            {"name": "operating_voltage", "byte_offset": 1, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 0.1, "factor": 1, "offset": 0, "value_key": "ign_voltage", "tolerance": 0.5},
        ]},
        "F1B0": {"payload_length": 3, "fields": [
            {"name": "original_odometer_occurrence", "byte_offset": 0, "byte_length": 3, "bit_offset": 0, "bit_length": 24, "resolution": 1, "factor": 1, "offset": 0, "value_key": "odometer", "tolerance": 0},
        ]},
        "F1B9": {"payload_length": 1, "fields": [
            {"name": "vehicle_state", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 3, "resolution": 1, "factor": 1, "offset": 0, "value_key": "vehicle_state", "tolerance": 0},
        ]},
        "0444": {"payload_length": 4, "fields": [
            {"name": "most_recent_life_timer", "byte_offset": 0, "byte_length": 4, "bit_offset": 0, "bit_length": 32, "resolution": 1, "factor": 1, "offset": 0, "dynamic_rule": "live_increment"},
        ]},
        "0448": {"payload_length": 8, "fields": [
            {"name": "passenger_seat_belt_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0, "value_key": "passenger_seat_belt", "tolerance": 0},
            {"name": "passenger_airbag_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 2, "bit_length": 1, "resolution": 1, "factor": 1, "offset": 0, "value_key": "passenger_airbag_status", "tolerance": 0},
            {"name": "driver_seat_belt_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 4, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0, "value_key": "driver_seat_belt", "tolerance": 0},
            {"name": "second_row_right_seat_belt_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 6, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "second_row_middle_seat_belt_status", "byte_offset": 1, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "second_row_left_seat_belt_status", "byte_offset": 1, "byte_length": 1, "bit_offset": 2, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "third_row_right_seat_belt_status", "byte_offset": 1, "byte_length": 1, "bit_offset": 4, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "third_row_left_seat_belt_status", "byte_offset": 1, "byte_length": 1, "bit_offset": 6, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "second_row_right_ods_status", "byte_offset": 2, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "second_row_middle_ods_status", "byte_offset": 2, "byte_length": 1, "bit_offset": 2, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "second_row_left_ods_status", "byte_offset": 2, "byte_length": 1, "bit_offset": 4, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "third_row_right_ods_status", "byte_offset": 2, "byte_length": 1, "bit_offset": 6, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "third_row_left_ods_status", "byte_offset": 3, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "passenger_ods_status", "byte_offset": 3, "byte_length": 1, "bit_offset": 2, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0, "value_key": "passenger_ods", "tolerance": 0},
            {"name": "driver_stps_status_fr", "byte_offset": 4, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "driver_stps_status_zone2", "byte_offset": 5, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "co_driver_stps_status_fl", "byte_offset": 6, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0},
            {"name": "co_driver_stps_status_zone2", "byte_offset": 7, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0},
        ]},
        "044B": {"payload_length": 1, "fields": [
            {"name": "airbag_warning_lamp_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0, "value_key": "airbag_warning_lamp", "tolerance": 0},
        ]},
        "0459": {"payload_length": 1, "fields": [
            {"name": "brake_switch_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0, "value_key": "brake_switch", "tolerance": 0},
        ]},
        "045A": {"payload_length": 1, "fields": [
            {"name": "accelerator_pedal_position", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 0.4, "factor": 2.5, "offset": 0, "value_key": "accelerator_pedal", "tolerance": 0.0},
        ]},
        "F1B6": {"payload_length": 4, "fields": [
            {"name": "ignition_counter", "byte_offset": 0, "byte_length": 4, "bit_offset": 0, "bit_length": 32, "resolution": 1, "factor": 1, "offset": 0, "dynamic_rule": "live_equal"},
        ]},
        "00FF": {
            "payload_length": 8,
            "decode_enabled": False,
            "reason": "The source order YYYY/mm/DD/ff/HH/MM/ss conflicts with the supplied M314 sample payload.",
            "fields": [],
        },
        "F1B5": {"payload_length": 2, "fields": [
            {"name": "reset_counter", "byte_offset": 0, "byte_length": 2, "bit_offset": 0, "bit_length": 16, "resolution": 1, "factor": 1, "offset": 0, "value_key": "reset_counter", "tolerance": 0},
        ]},
        "049D": {"payload_length": 4, "fields": [
            {"name": "srs_ecu_reset_cycle_counter", "byte_offset": 0, "byte_length": 4, "bit_offset": 0, "bit_length": 32, "resolution": 1, "factor": 1, "offset": 0, "dynamic_rule": "record_1_stable"},
        ]},
        "04A3": {"payload_length": 1, "fields": [
            {"name": "srs_operation_mode", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0, "value_key": "srs_operation_mode", "tolerance": 0},
        ]},
        "04A4": {"payload_length": 2, "fields": [
            {"name": "srs_stps_zone_fr", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0, "value_key": "stps_fr", "tolerance": 0},
            {"name": "srs_stps_zone_fl", "byte_offset": 1, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0, "value_key": "stps_fl", "tolerance": 0},
        ]},
        "04A5": {
            "payload_length": 1,
            "unavailable_fields": ("srs_tx_srs_ocs_pass_class_fault_sts",),
            "fields": [
                {"name": "passenger_seat_occupant_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 2, "resolution": 1, "factor": 1, "offset": 0, "value_key": "passenger_seat_occupant", "tolerance": 0},
            ],
        },
        "04A6": {"payload_length": 1, "fields": [
            {"name": "pke_clmp_state", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0, "value_key": "pke_clmp_state", "tolerance": 0},
        ]},
        "044A": {"payload_length": 3, "fields": [
            {"name": "pab_on_lamp_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 0, "bit_length": 1, "resolution": 1, "factor": 1, "offset": 0, "value_key": "pab_on_lamp", "tolerance": 0},
            {"name": "pab_off_lamp_status", "byte_offset": 0, "byte_length": 1, "bit_offset": 1, "bit_length": 1, "resolution": 1, "factor": 1, "offset": 0, "value_key": "pab_off_lamp", "tolerance": 0},
            {"name": "padi_on_lamp_fault_status", "byte_offset": 1, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0, "value_key": "padi_on_fault", "tolerance": 0},
            {"name": "padi_off_lamp_fault_status", "byte_offset": 2, "byte_length": 1, "bit_offset": 0, "bit_length": 8, "resolution": 1, "factor": 1, "offset": 0, "value_key": "padi_off_fault", "tolerance": 0},
        ]},
    },
    "live_dynamic_references": [
        {"field": "0444.most_recent_life_timer", "request": "0x22 0x04 0x44", "increment_period_ms": 5000, "allowed_ticks": 1},
        {"field": "F1B6.ignition_counter", "request": "0x22 0xF1 0xB6"},
    ],
    "states": [
        {"enabled": True, "name": "initial_active", "apply_profile": "baseline", "transition": "activate", "capture_live_references": True, "expected_records": {"record_1": ["baseline"], "record_2": ["baseline"], "record_ff": ["baseline", "baseline"]}},
        {"enabled": True, "name": "historic_after_baseline", "apply_profile": "first_update", "transition": "clear_and_ignition_cycle", "capture_live_references": False, "expected_records": {"record_1": ["baseline"], "record_2": ["baseline"], "record_ff": ["baseline", "baseline"]}},
        {"enabled": True, "name": "first_update_active", "transition": "activate", "capture_live_references": True, "expected_records": {"record_1": ["baseline"], "record_2": ["first_update"], "record_ff": ["baseline", "first_update"]}},
        {"enabled": False, "name": "historic_after_second_update", "apply_profile": "second_update", "transition": "clear_and_ignition_cycle", "capture_live_references": False, "expected_records": {"record_1": ["baseline"], "record_2": ["first_update"], "record_ff": ["baseline", "first_update"]}},
        {"enabled": False, "name": "second_update_active", "transition": "activate", "capture_live_references": True, "expected_records": {"record_1": ["baseline"], "record_2": ["second_update"], "record_ff": ["baseline", "second_update"]}},
    ],
}
#