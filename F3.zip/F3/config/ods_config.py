"""
Module Configuration: ODS
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/ods_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is ODS
    ctx.get_module_config("ODS").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "ODS"

ENABLED = True

# ── ODS Settings ──
# ODS_STATUS_DID = 0x0450
# ODS_WEIGHT_DID = 0x0451
# ODS_CLASSIFICATION_DID = 0x0452

# ODS seat logical names
ODSName = [
    "DCS_Second_Row_Right_ODS",
    "DCS_Second_Row_Left_ODS",
    "DCS_Second_Row_Middle_ODS",
    "DCS_Third_Row_Right_ODS",
    "DCS_Third_Row_Left_ODS"
]

# ODS logical name -> DCS channel index
ODSNumber = {
    "DCS_Second_Row_Right_ODS": 9,
    "DCS_Second_Row_Left_ODS": 10,
    "DCS_Second_Row_Middle_ODS": 11,
    "DCS_Third_Row_Right_ODS": 14,
    "DCS_Third_Row_Left_ODS": 15
}

# ODS logical name -> software channel
ODSChannelName = {
    "DCS_Second_Row_Right_ODS": "SW_Channel_DCS_9",
    "DCS_Second_Row_Left_ODS": "SW_Channel_DCS_10",
    "DCS_Second_Row_Middle_ODS": "SW_Channel_DCS_11",
    "DCS_Third_Row_Right_ODS": "SW_Channel_DCS_14",
    "DCS_Third_Row_Left_ODS": "SW_Channel_DCS_15"
}

