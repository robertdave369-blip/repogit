"""
Module Configuration: VARIANTCODE
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/variantcode_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is VARIANTCODE
    ctx.get_module_config("VARIANTCODE").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "VARIANTCODE"


# ── VARIANTCODE Settings ──
VARIANTCODE_DID = 0x0101
vc_positive_res = "0x6E 0x01 0x01"
project_defaults = {
        "M310_M314_M110": {
            "enabled_nodes": [
                "VARIANT_STATUS",
                "EPS",
                "SAS",
                "IC",
                "MBFM",
                "HPC_C",
                "FR_ZONE",
                "RVC",
                "VCU",
            ],
            "variant_bytes": [0x19, 0x00, 0x00, 0x03, 0x00, 0x14, 0x04, 0x00,
                                0x00, 0x00, 0x00, 0x04, 0x01, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00],
            "description": "M310_M314_M110 Default - EV Platform Base Configuration (19 00 00 03 00 14 04 00 00 00 00 04 01 00 00 00 00 00 00 00)"
        },
        
    }
