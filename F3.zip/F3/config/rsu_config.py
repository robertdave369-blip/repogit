"""
Module Configuration: RSU
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/rsu_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is RSU
    ctx.get_module_config("RSU").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "RSU"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── RSU Settings ──
"""RSU configuration for the M310/M314/M110 project."""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "RSU"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# Source: project RSU channel-to-sensor allocation.
RSU_CHANNEL_TO_SENSOR = {
    "RSU_CH1": "A_PILLAR_LEFT_X",
    "RSU_CH2": "A_PILLAR_LEFT_Y",
    "RSU_CH3": "A_PILLAR_RIGHT_X",
    "RSU_CH4": "A_PILLAR_RIGHT_Y",
    "RSU_CH5": "B_PILLAR_LEFT_Y",
    "RSU_CH6": "B_PILLAR_LEFT_X",
    "RSU_CH7": "B_PILLAR_RIGHT_Y",
    "RSU_CH8": "B_PILLAR_RIGHT_X",
    "RSU_CH9": "FRONT_LEFT_X",
    "RSU_CH10": "FRONT_LEFT_Y",
    "RSU_CH11": "FRONT_RIGHT_X",
    "RSU_CH12": "FRONT_RIGHT_Y",
    "RSU_CH13": "C_PILLAR_LEFT_X",
    "RSU_CH14": "C_PILLAR_LEFT_Y",
    "RSU_CH15": "C_PILLAR_RIGHT_X",
    "RSU_CH16": "C_PILLAR_RIGHT_Y",
    "RSU_CH17": "UNDERBODY_Y",
    "RSU_CH18": "UNDERBODY_Z",
    "RSU_CH19": "PRESSURE_RIGHT_RSU",
    "RSU_CH20": "PRESSURE_LEFT_RSU",
    "RSU_CH21": "REAR_RSU_X",
}

rsu_names = list(RSU_CHANNEL_TO_SENSOR.values())
RSU_CHANNELS = list(RSU_CHANNEL_TO_SENSOR)
SENSOR_TO_RSU_CHANNEL = {
    sensor_name: channel_name
    for channel_name, sensor_name in RSU_CHANNEL_TO_SENSOR.items()
}

# The project has not yet supplied ARIA card addresses, slots, or channel IDs.
RSU_CARD_SLOT = {}
RSU_ATTRIBUTES = {}
RSU_ID = {
    channel_name: int(channel_name.removeprefix("RSU_CH"))
    for channel_name in RSU_CHANNELS
}

fault_names = ["S2B", "S2G", "Open", "Internal_Error", "Communication_Error"]
fault_status_values = ["Active", "Historic"]
status_code = {"Active": "0x8B", "Historic": "0x08"}
RSU_FaultDescription = {
    "Open": "OPEN",
    "S2B": "Short Battery Fault",
    "S2G": "Short Ground Fault",
    "Communication_Error": "Parity Fault",
    "Internal_Error": "Internal",
    "Inherent": "INHERENT",
    "ResetRSU": "ResetRSU",
}
rsu_fault_code = {
    "S2G": "0x11",
    "S2B": "0x12",
    "Open": "0x13",
    "Internal_Error": "0x96",
    "Communication_Error": "0x81",
}

# Electrical RSU DTC base codes. Pressure RSU bases use the confirmed Z121
# mapping for this project: right = 0x9216, left = 0x9212.
DTC_RSU_fault = {
    "RSU_CH1": "0x92 0x36",   # A-pillar left SRSU
    "RSU_CH2": "0x92 0x36",   # A-pillar left SRSU
    "RSU_CH3": "0x92 0x37",   # A-pillar right SRSU
    "RSU_CH4": "0x92 0x37",   # A-pillar right SRSU
    "RSU_CH5": "0x92 0x0A",   # B-pillar left SRSU
    "RSU_CH6": "0x92 0x0A",   # B-pillar left SRSU
    "RSU_CH7": "0x92 0x0B",   # B-pillar right SRSU
    "RSU_CH8": "0x92 0x0B",   # B-pillar right SRSU
    "RSU_CH9": "0x80 0x90",   # Left FRSU
    "RSU_CH10": "0x80 0x90",  # Left FRSU
    "RSU_CH11": "0x80 0x95",  # Right FRSU
    "RSU_CH12": "0x80 0x95",  # Right FRSU
    "RSU_CH13": "0x92 0x1B",  # C-pillar left SRSU
    "RSU_CH14": "0x92 0x1B",  # C-pillar left SRSU
    "RSU_CH15": "0x92 0x1C",  # C-pillar right SRSU
    "RSU_CH16": "0x92 0x1C",  # C-pillar right SRSU
    "RSU_CH17": "0x92 0x52",  # Underbody sensor
    "RSU_CH18": "0x92 0x52",  # Underbody sensor
    "RSU_CH19": "0x92 0x16",  # Right pressure RSU
    "RSU_CH20": "0x92 0x12",  # Left pressure RSU
    "RSU_CH21": "0x92 0x38",  # Rear RSU
}

# One representative physical channel is selected for each EOL feature.
# The channel table above remains authoritative for the X/Y sensor pair.
EOL_RSU_FEATURE_CHANNELS = {
    "UNDERBODY_RSU": "RSU_CH17",
    "LEFT_FRSU": "RSU_CH9",
    "RIGHT_FRSU": "RSU_CH11",
    "LEFT_SRSU": "RSU_CH5",
    "RIGHT_SRSU": "RSU_CH7",
    "RIGHT_SIDE_PRESSURE_RSU": "RSU_CH19",
    "LEFT_SIDE_PRESSURE_RSU": "RSU_CH20",
    "C_PILLAR_RIGHT_SRSU": "RSU_CH15",
    "C_PILLAR_LEFT_SRSU": "RSU_CH13",
    "A_PILLAR_RIGHT_SRSU": "RSU_CH3",
    "A_PILLAR_LEFT_SRSU": "RSU_CH1",
    "REAR_RSU": "RSU_CH21",
}

PILLAR_RSU_CHANNELS = [
    "RSU_CH1", "RSU_CH2", "RSU_CH3", "RSU_CH4",
    "RSU_CH5", "RSU_CH6", "RSU_CH7", "RSU_CH8",
    "RSU_CH13", "RSU_CH14", "RSU_CH15", "RSU_CH16",
]
FRSU_RSU_CHANNELS = ["RSU_CH9", "RSU_CH10", "RSU_CH11", "RSU_CH12"]
UNDERBODY_RSU_CHANNELS = ["RSU_CH17", "RSU_CH18"]
PRESSURE_RSU_CHANNELS = ["RSU_CH19", "RSU_CH20"]
REAR_RSU_CHANNELS = ["RSU_CH21"]

# EDR DID allocation and physical sensitivity are project calibration data.
RSU_DID_MAP = {}
SENSOR_SENSITIVITY = {}
RSU_DECODE_CONVENTION = {}

RSU_FAULT_TIME = {
    "Qualification": 1500,
    "Qualification_Tolerance": 10,
    "Dequalification": 1500,
    "Dequalification_Tolerance": 5,
}


def get_rsu_fault_dtc(rsu_channel: str, fault_type: str, status: str = "Active") -> str:
    """Return a complete RSU DTC only after its project base code is configured."""
    return f"{DTC_RSU_fault[rsu_channel]} {rsu_fault_code[fault_type]} {status_code[status]}"
