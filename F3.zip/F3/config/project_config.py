"""
Project Configuration: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/project_config.py

"""

from pathlib import Path

PROJECT_NAME = "M310_M314_M110"
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Report identity is project-specific. PC name defaults to the running machine.
# Tester Name: person who designed or owns the test case.
# Test Executor: person who actually ran the test on the bench or system.
# Author Name: person who created or documented the test script/specification.
REPORT_METADATA = {
    "pc_name": "",
    "tester_name": "",
    "test_executor": "",
    "author_name": "",
}

# ── Shared Defaults ──
ACTIVE_CAN_VARIANT = "M310_M314_M110"

# M314 identities decoded from user-supplied DID responses (2026-10-13).
APPLICATION_SW_VER = "W613SRSVRACD00H"
CALIBRATION_SW_VER = "W613SRSVRDCD00C"
HARDWARE_SW_VER = "W613H0-A"
EEPROM_SW_VER = "W613SRSVRECD00D"
BOOTLOADER_SW_VER = "W613SRSVRBCD00B"
AEF_SW_VER = "IMHBEV______2F10S15B06RHHPHHCHXHM1     D"
# FD42 excludes trailing NUL padding, matching read_software_version().
INTERNAL_SW_VERSION = "SC3M1I3AW613P27"

SOFTWARE_VERSION_READ_CONFIG = [
    {"did": "0xF1 0x81", "label": "Application Software", "expected": APPLICATION_SW_VER},
    {"did": "0xF1 0x82", "label": "Calibration Software", "expected": CALIBRATION_SW_VER},
    {"did": "0xF1 0x91", "label": "Hardware", "expected": HARDWARE_SW_VER},
    {"did": "0xF1 0xB7", "label": "EEPROM Version", "expected": EEPROM_SW_VER},
    {"did": "0xF1 0x80", "label": "Bootloader Version", "expected": BOOTLOADER_SW_VER},
    {"did": "0xFF 0xAA", "label": "AEF Version", "expected": AEF_SW_VER},
    {"did": "0xFD 0x42", "label": "Internal Version", "expected": INTERNAL_SW_VERSION},
] 
# 
SW_VERSION_DID = [item["did"] for item in SOFTWARE_VERSION_READ_CONFIG]
SW_PARAMETER = [item["label"] for item in SOFTWARE_VERSION_READ_CONFIG]
SW_VERSION_PARAM = [item["expected"] for item in SOFTWARE_VERSION_READ_CONFIG]

# M314 EOL and variant coding bytes supplied by the user (2026-10-13).
DEFAULT_EOL_BY_VARIANT = {
    "M310_M314_M110": "0xFF 0xBF 0xFF 0xAF 0xFE 0x1F 0x31 0x14 0x03 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00",
}

DEFAULT_VARIANT_CODE_BY_VARIANT = {
    "M310_M314_M110": "0x19 0x00 0x00 0x02 0x00 0x14 0x00 0x04 0x00 0x00 0x00 0x04 0x01 0x00 0x00 0x00 0x00 0x00 0x00 0x00",
}

DEFAULT_EOL_CODE = DEFAULT_EOL_BY_VARIANT.get(ACTIVE_CAN_VARIANT, "")
DEFAULT_VARIANT_CODE = DEFAULT_VARIANT_CODE_BY_VARIANT.get(ACTIVE_CAN_VARIANT, "")

# ── Tool Paths ──
WINIDEA_WORKSPACE = r"C:\iSYSTEM\M310_M314_M110\workspace.xjrf"
CAN_DB_PATH = r"C:\CAN_DB\M310_M314_M110\M310_M314_M110.dbc"
FLASH_FILE_PATH = r"C:\Builds\M310_M314_M110\latest.hex"

# ── Output ──
TEST_RESULTS_DIR = str(PROJECT_ROOT / "test_results")
TEST_LOGS_DIR = str(PROJECT_ROOT / "test_logs")

# ── CAN ──
CAN_FD_ENABLED = True
CAN_HS_ENABLED = True
CAN_FD_CHANNEL_NAME = "CANFD"
CAN_HS_CHANNEL_NAME = "HSCAN"

# ── Diagnostics ──
DIAG_RX_ID = 0x738
DIAG_TX_ID = 0x730
DIAG_FUNCTIONAL_ID = 0x7DF

DEFAULT_CAN_LOG_IDS = [0x2C0, 0x13C, 0x730, 0x738, 0x7DF, 0x7F1, 0x7F9]

# ── ECU ──
# M314 is an EV project, as confirmed by the user (2026-10-13).
ECU_VARIANT = "EV"
SOFTWARE_VERSION = "1.0.0"
HARDWARE_VERSION = "1.0"

# ── EVT ──
_EVT_DIRECTORY = Path(__file__).resolve().parents[3] / "evt" / "z121"
EOL_EVT_CONFIG = {
    "spi_function": "GEN6_XY",
    "corrupted_evt_path": str(_EVT_DIRECTORY / "GEN6_XY_EVT_Corrupted_EVT.xlsx"),
    "normal_evt_path": str(_EVT_DIRECTORY / "GEN6_XY_Z121_EVT_Christy.xlsx"),
}

# ── Loadbox Path ──
AriaFileConfig = r"C:\AriaConfigFile_UPP_EV\AriaConfigFiles\AriaMain_accdata\Loadbox\UPP_EV_LOADBOX1.ldbx"

# ── Timing ──
DEFAULT_TIMEOUT = 30
FLASH_TIMEOUT = 120
RESET_WAIT_TIME = 5

# ── WinIDEA ──
TARGET_CPU = "TC397"
