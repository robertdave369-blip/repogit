"""
Module Configuration: Fault_List
Project: M310_M314_M110
============================================================

Every fault of the project fault list, one entry per fault monitor, with a short name.

Source: project_reuirements/m310_m314_m110/DES_SW_Mahindra_FaultList.xlsx (Codebeamer export)
- 1055 faults that are not obsolete: 1012 in the project's fault set
  (FAULT_LIST) and 43 struck out by the customer (STRUCK_OUT_FAULTS).
Built with tools/build_m310_fault_list_config.py; rebuild it there rather than edit by hand.

Each fault is a dict:
    dtc               DTC with its failure type byte, as the ECU reports it in 19 02 (None: no DTC)
    qualify_ms        fault monitor maturation time in ms
    dequalify_ms      dematuration time in ms (both None where the list gives no plain ms value;
                      'timing' then quotes the list)
    qualify_counts /  CAN supervision: frames counted to mature / dematurate (time = count x
    dequalify_counts  the frame period)
    latched           True: stays active until cleared / over an IGN cycle (None: not given)
    monitor           fault monitor name in the fault list
    req               Codebeamer requirement ID
    text              fault list description (with the ECU fault event)

Lookups by bench name: LOOP_FAULT_BY_SQUIB (squibs_config names, Squib_FaultTypeCode keys),
DCS_FAULT_BY_CHANNEL (dcs_config / ods_config names, DCS_FaultTypeCode keys), GPO_FAULT_BY_OUTPUT
(gpo_config names, GPO_FaultStatus keys) and RSU_FAULT_BY_SATELLITE (rsu_fault_code keys).
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "Fault_List"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── Fault_List Settings ──


# ====================================================================================================
# Squib loops (400)
# One entry per squib and fault, named <squib>_<fault>; squibs as squibs_config names them (the
# fault list numbers the ECU lines: RPT line 0, LPT 1, RSA 2, LSA 3, RCA 4, LCA 5, DAB 6, PAB 7, DKA
# 11, RLPT 12, LLPT 13, R2RPT 16, CAB 17, R2LPT 18, DBFL 19, PBFL 20; LINE08-LINE10 are unconfigured
# lines and LINE24-LINE31 lines the ECU does not use). LOOP_ASIC<n>_* / LOOP<n>_CURRENT_MONITOR are
# per ASIC.
# ====================================================================================================
RPT_OPEN = {'dtc': '0x80 0x70 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_00', 'req': 36069465,
            'text': 'LOP Open circuit failure Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_OPEN)'}
RPT_S2G = {'dtc': '0x80 0x70 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_00', 'req': 36069365,
           'text': ('LOP Short to ground failure Line 0 '
                    '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
RPT_S2B = {'dtc': '0x80 0x70 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_00', 'req': 36069390,
           'text': ('LOP Short to battery failure Line 0 '
                    '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
RPT_LORES = {'dtc': '0x80 0x70 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_00', 'req': 36069415,
             'text': 'LOP Resistance too low Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_LOW_RES)'}
RPT_HIRES = {'dtc': '0x80 0x70 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_00', 'req': 36069440,
             'text': 'LOP Resistance too high Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_HIGH_RES)'}
RPT_XCONN = {'dtc': '0x80 0x70 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_00', 'req': 36069492,
             'text': 'LOP Cross connection failure Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_CROSS_CONNECT)'}
RPT_UNEXPECTED = {'dtc': '0x80 0x70 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_00', 'req': 36069549,
                  'text': ('LOP Present but not configured Line 0 '
                           '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
RPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_00', 'req': 36069170,
                'text': 'LOP ASIC internal error Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_00', 'req': 36069202,
                      'text': 'LOP monitor current failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_00', 'req': 36069235,
              'text': 'LOP supply voltage failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_00', 'req': 36069269,
                       'text': 'LOP Low side driver failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_00', 'req': 36069301,
                        'text': 'LOP High side driver failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_00', 'req': 36069333,
                   'text': 'LOP Loose of ground connection Low Side 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_00', 'req': 36069517,
                 'text': 'LOP DR Cross connection failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_00', 'req': 36069616,
                     'text': 'loops PDC skipped due to internal condition Line 0 (FLTMONR_E_ECU_INTERNAL)'}
RPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_00', 'req': 36069584,
                     'text': 'loops PDC skipped due to external condition Line 0 (FLTMONR_NO_DTC_EVENT)'}
RPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_00', 'req': 36069660,
             'text': 'LOP Firing time limiter and wording configuration failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
LPT_OPEN = {'dtc': '0x80 0x72 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_01', 'req': 36069466,
            'text': 'LOP Open circuit failure Line 1 (FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_OPEN)'}
LPT_S2G = {'dtc': '0x80 0x72 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_01', 'req': 36069366,
           'text': ('LOP Short to ground failure Line 1 '
                    '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
LPT_S2B = {'dtc': '0x80 0x72 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_01', 'req': 36069391,
           'text': ('LOP Short to battery failure Line 1 '
                    '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
LPT_LORES = {'dtc': '0x80 0x72 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_01', 'req': 36069416,
             'text': 'LOP Resistance too low Line 1 (FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_LOW_RES)'}
LPT_HIRES = {'dtc': '0x80 0x72 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_01', 'req': 36069441,
             'text': 'LOP Resistance too high Line 1 (FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_HIGH_RES)'}
LPT_XCONN = {'dtc': '0x80 0x72 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_01', 'req': 36069493,
             'text': ('LOP Cross connection failure Line 1 '
                      '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
LPT_UNEXPECTED = {'dtc': '0x80 0x72 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_01', 'req': 36069550,
                  'text': ('LOP Present but not configured Line 1 '
                           '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_UNEXPECTED_SQUIB)')}
LPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_01', 'req': 36069171,
                'text': 'LOP ASIC internal error Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_01', 'req': 36069203,
                      'text': 'LOP monitor current failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_01', 'req': 36069236,
              'text': 'LOP supply voltage failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_01', 'req': 36069270,
                       'text': 'LOP Low side driver failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_01', 'req': 36069302,
                        'text': 'LOP High side driver failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_01', 'req': 36069334,
                   'text': 'LOP Loose of ground connection Low Side 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_01', 'req': 36069518,
                 'text': 'LOP DR Cross connection failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_01', 'req': 36069617,
                     'text': 'loops PDC skipped due to internal condition Line 1 (FLTMONR_E_ECU_INTERNAL)'}
LPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_01', 'req': 36069585,
                     'text': 'loops PDC skipped due to external condition Line 1 (FLTMONR_NO_DTC_EVENT)'}
LPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_01', 'req': 36069661,
             'text': 'LOP Firing time limiter and wording configuration failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
RSA_OPEN = {'dtc': '0x92 0x06 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_02', 'req': 36069467,
            'text': 'LOP Open circuit failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_OPEN)'}
RSA_S2G = {'dtc': '0x92 0x06 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_02', 'req': 36069367,
           'text': 'LOP Short to ground failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
RSA_S2B = {'dtc': '0x92 0x06 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_02', 'req': 36069392,
           'text': 'LOP Short to battery failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_BAT)'}
RSA_LORES = {'dtc': '0x92 0x06 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_02', 'req': 36069417,
             'text': 'LOP Resistance too low Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_LOW_RES)'}
RSA_HIRES = {'dtc': '0x92 0x06 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_02', 'req': 36069442,
             'text': 'LOP Resistance too high Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_HIGH_RES)'}
RSA_XCONN = {'dtc': '0x92 0x06 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_02', 'req': 36069494,
             'text': 'LOP Cross connection failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_CROSS_CONNECT)'}
RSA_UNEXPECTED = {'dtc': '0x92 0x06 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_02', 'req': 36069551,
                  'text': ('LOP Present but not configured Line 2 '
                           '(FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_UNEXPECTED_SQUIB)')}
RSA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_02', 'req': 36069172,
                'text': 'LOP ASIC internal error Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_02', 'req': 36069204,
                      'text': 'LOP monitor current failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_02', 'req': 36069237,
              'text': 'LOP supply voltage failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_02', 'req': 36069271,
                       'text': 'LOP Low side driver failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_02', 'req': 36069303,
                        'text': 'LOP High side driver failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_02', 'req': 36069335,
                   'text': 'LOP Loose of ground connection Low Side 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_02', 'req': 36069519,
                 'text': 'LOP DR Cross connection failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_02', 'req': 36069618,
                     'text': 'loops PDC skipped due to internal condition Line 2 (FLTMONR_E_ECU_INTERNAL)'}
RSA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_02', 'req': 36069586,
                     'text': 'loops PDC skipped due to external condition Line 2 (FLTMONR_NO_DTC_EVENT)'}
RSA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_02', 'req': 36069662,
             'text': 'LOP Firing time limiter and wording configuration failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
LSA_OPEN = {'dtc': '0x92 0x08 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_03', 'req': 36069468,
            'text': 'LOP Open circuit failure Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_OPEN)'}
LSA_S2G = {'dtc': '0x92 0x08 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_03', 'req': 36069368,
           'text': 'LOP Short to ground failure Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
LSA_S2B = {'dtc': '0x92 0x08 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_03', 'req': 36069393,
           'text': 'LOP Short to battery failure Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_BAT)'}
LSA_LORES = {'dtc': '0x92 0x08 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_03', 'req': 36069418,
             'text': 'LOP Resistance too low Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_LOW_RES)'}
LSA_HIRES = {'dtc': '0x92 0x08 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_03', 'req': 36069443,
             'text': 'LOP Resistance too high Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_HIGH_RES)'}
LSA_XCONN = {'dtc': '0x92 0x08 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_03', 'req': 36069495,
             'text': 'LOP Cross connection failure Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_CROSS_CONNECT)'}
LSA_UNEXPECTED = {'dtc': '0x92 0x08 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_03', 'req': 36069552,
                  'text': ('LOP Present but not configured Line 3 '
                           '(FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_UNEXPECTED_SQUIB)')}
LSA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_03', 'req': 36069173,
                'text': 'LOP ASIC internal error Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_03', 'req': 36069205,
                      'text': 'LOP monitor current failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_03', 'req': 36069238,
              'text': 'LOP supply voltage failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_03', 'req': 36069272,
                       'text': 'LOP Low side driver failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_03', 'req': 36069304,
                        'text': 'LOP High side driver failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_03', 'req': 36069336,
                   'text': 'LOP Loose of ground connection Low Side 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_03', 'req': 36069520,
                 'text': 'LOP DR Cross connection failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_03', 'req': 36069619,
                     'text': 'loops PDC skipped due to internal condition Line 3 (FLTMONR_E_ECU_INTERNAL)'}
LSA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_03', 'req': 36069587,
                     'text': 'loops PDC skipped due to external condition Line 3 (FLTMONR_NO_DTC_EVENT)'}
LSA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_03', 'req': 36069663,
             'text': 'LOP Firing time limiter and wording configuration failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
RCA_OPEN = {'dtc': '0x92 0x07 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_04', 'req': 36069469,
            'text': 'LOP Open circuit failure Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_OPEN)'}
RCA_S2G = {'dtc': '0x92 0x07 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_04', 'req': 36069369,
           'text': 'LOP Short to ground failure Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
RCA_S2B = {'dtc': '0x92 0x07 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_04', 'req': 36069394,
           'text': 'LOP Short to battery failure Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_BAT)'}
RCA_LORES = {'dtc': '0x92 0x07 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_04', 'req': 36069419,
             'text': 'LOP Resistance too low Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_LOW_RES)'}
RCA_HIRES = {'dtc': '0x92 0x07 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_04', 'req': 36069444,
             'text': 'LOP Resistance too high Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_HIGH_RES)'}
RCA_XCONN = {'dtc': '0x92 0x07 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_04', 'req': 36069496,
             'text': 'LOP Cross connection failure Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_CROSS_CONNECT)'}
RCA_UNEXPECTED = {'dtc': '0x92 0x07 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_04', 'req': 36069553,
                  'text': ('LOP Present but not configured Line 4 '
                           '(FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_UNEXPECTED_SQUIB)')}
RCA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_04', 'req': 36069174,
                'text': 'LOP ASIC internal error Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_04', 'req': 36069206,
                      'text': 'LOP monitor current failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_04', 'req': 36069239,
              'text': 'LOP supply voltage failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_04', 'req': 36069273,
                       'text': 'LOP Low side driver failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_04', 'req': 36069305,
                        'text': 'LOP High side driver failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_04', 'req': 36069337,
                   'text': 'LOP Loose of ground connection Low Side 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_04', 'req': 36069521,
                 'text': 'LOP DR Cross connection failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_04', 'req': 36069620,
                     'text': 'loops PDC skipped due to internal condition Line 4 (FLTMONR_E_ECU_INTERNAL)'}
RCA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_04', 'req': 36069588,
                     'text': 'loops PDC skipped due to external condition Line 4 (FLTMONR_NO_DTC_EVENT)'}
RCA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_04', 'req': 36069664,
             'text': 'LOP Firing time limiter and wording configuration failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
LCA_OPEN = {'dtc': '0x92 0x09 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_05', 'req': 36069470,
            'text': 'LOP Open circuit failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_OPEN)'}
LCA_S2G = {'dtc': '0x92 0x09 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_05', 'req': 36069370,
           'text': 'LOP Short to ground failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
LCA_S2B = {'dtc': '0x92 0x09 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_05', 'req': 36069395,
           'text': 'LOP Short to battery failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_BAT)'}
LCA_LORES = {'dtc': '0x92 0x09 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_05', 'req': 36069420,
             'text': 'LOP Resistance too low Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_LOW_RES)'}
LCA_HIRES = {'dtc': '0x92 0x09 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_05', 'req': 36069445,
             'text': 'LOP Resistance too high Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_HIGH_RES)'}
LCA_XCONN = {'dtc': '0x92 0x09 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_05', 'req': 36069497,
             'text': 'LOP Cross connection failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_CROSS_CONNECT)'}
LCA_UNEXPECTED = {'dtc': '0x92 0x09 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_05', 'req': 36069554,
                  'text': ('LOP Present but not configured Line 5 '
                           '(FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_UNEXPECTED_SQUIB)')}
LCA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_05', 'req': 36069175,
                'text': 'LOP ASIC internal error Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_05', 'req': 36069207,
                      'text': 'LOP monitor current failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_05', 'req': 36069240,
              'text': 'LOP supply voltage failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_05', 'req': 36069274,
                       'text': 'LOP Low side driver failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_05', 'req': 36069306,
                        'text': 'LOP High side driver failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_05', 'req': 36069338,
                   'text': 'LOP Loose of ground connection Low Side 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_05', 'req': 36069522,
                 'text': 'LOP DR Cross connection failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_05', 'req': 36069621,
                     'text': 'loops PDC skipped due to internal condition Line 5 (FLTMONR_E_ECU_INTERNAL)'}
LCA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_05', 'req': 36069589,
                     'text': 'loops PDC skipped due to external condition Line 5 (FLTMONR_NO_DTC_EVENT)'}
LCA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_05', 'req': 36069665,
             'text': 'LOP Firing time limiter and wording configuration failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
DAB_OPEN = {'dtc': '0x80 0x01 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_06', 'req': 36069471,
            'text': 'LOP Open circuit failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_OPEN)'}
DAB_S2G = {'dtc': '0x80 0x01 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_06', 'req': 36069371,
           'text': 'LOP Short to ground failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_GND)'}
DAB_S2B = {'dtc': '0x80 0x01 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_06', 'req': 36069396,
           'text': 'LOP Short to battery failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_BAT)'}
DAB_LORES = {'dtc': '0x80 0x01 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_06', 'req': 36069421,
             'text': 'LOP Resistance too low Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_LOW_RES)'}
DAB_HIRES = {'dtc': '0x80 0x01 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_06', 'req': 36069446,
             'text': 'LOP Resistance too high Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_HIGH_RES)'}
DAB_XCONN = {'dtc': '0x80 0x01 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_06', 'req': 36069498,
             'text': 'LOP Cross connection failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_CROSS_CONNECT)'}
DAB_UNEXPECTED = {'dtc': '0x80 0x01 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_06', 'req': 36069555,
                  'text': ('LOP Present but not configured Line 6 '
                           '(FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_UNEXPECTED_SQUIB)')}
DAB_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_06', 'req': 36069176,
                'text': 'LOP ASIC internal error Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_06', 'req': 36069208,
                      'text': 'LOP monitor current failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_06', 'req': 36069243,
              'text': 'LOP supply voltage failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_06', 'req': 36069275,
                       'text': 'LOP Low side driver failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_06', 'req': 36069307,
                        'text': 'LOP High side driver failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_06', 'req': 36069339,
                   'text': 'LOP Loose of ground connection Low Side 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_06', 'req': 36069523,
                 'text': 'LOP DR Cross connection failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_06', 'req': 36069622,
                     'text': 'loops PDC skipped due to internal condition Line 6 (FLTMONR_E_ECU_INTERNAL)'}
DAB_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_06', 'req': 36069590,
                     'text': 'loops PDC skipped due to external condition Line 6 (FLTMONR_NO_DTC_EVENT)'}
DAB_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_06', 'req': 36069666,
             'text': 'LOP Firing time limiter and wording configuration failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
PAB_OPEN = {'dtc': '0x80 0x10 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_07', 'req': 36069472,
            'text': 'LOP Open circuit failure Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_OPEN)'}
PAB_S2G = {'dtc': '0x80 0x10 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_07', 'req': 36069372,
           'text': 'LOP Short to ground failure Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_GND)'}
PAB_S2B = {'dtc': '0x80 0x10 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_07', 'req': 36069397,
           'text': ('LOP Short to battery failure Line 7 '
                    '(FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
PAB_LORES = {'dtc': '0x80 0x10 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_07', 'req': 36069422,
             'text': 'LOP Resistance too low Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_LOW_RES)'}
PAB_HIRES = {'dtc': '0x80 0x10 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_07', 'req': 36069447,
             'text': 'LOP Resistance too high Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_HIGH_RES)'}
PAB_XCONN = {'dtc': '0x80 0x10 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_07', 'req': 36069499,
             'text': 'LOP Cross connection failure Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_CROSS_CONNECT)'}
PAB_UNEXPECTED = {'dtc': '0x80 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_07', 'req': 36069556,
                  'text': ('LOP Present but not configured Line 7 '
                           '(FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_UNEXPECTED_SQUIB)')}
PAB_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_07', 'req': 36069177,
                'text': 'LOP ASIC internal error Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_07', 'req': 36069209,
                      'text': 'LOP monitor current failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_07', 'req': 36069244,
              'text': 'LOP supply voltage failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_07', 'req': 36069276,
                       'text': 'LOP Low side driver failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_07', 'req': 36069308,
                        'text': 'LOP High side driver failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_07', 'req': 36069340,
                   'text': 'LOP Loose of ground connection Low Side 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_07', 'req': 36069524,
                 'text': 'LOP DR Cross connection failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_07', 'req': 36069623,
                     'text': 'loops PDC skipped due to internal condition Line 7 (FLTMONR_E_ECU_INTERNAL)'}
PAB_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_07', 'req': 36069591,
                     'text': 'loops PDC skipped due to external condition Line 7 (FLTMONR_NO_DTC_EVENT)'}
PAB_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_07', 'req': 36069667,
             'text': 'LOP Firing time limiter and wording configuration failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_OPEN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_08', 'req': 36069473,
               'text': 'LOP Open circuit failure Line 8 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE08_S2G = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_08', 'req': 36069373,
              'text': 'LOP Short to ground failure Line 8 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE08_S2B = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_08', 'req': 36069398,
              'text': ('LOP Short to battery failure Line 8 '
                       '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE08_LORES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_08', 'req': 36069423,
                'text': 'LOP Resistance too low Line 8 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE08_HIRES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_08', 'req': 36069448,
                'text': 'LOP Resistance too high Line 8 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE08_XCONN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_08', 'req': 36069500,
                'text': ('LOP Cross connection failure Line 8 '
                         '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE08_UNEXPECTED = {'dtc': '0x92 0x60 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': False, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_08', 'req': 36069557,
                     'text': ('LOP Present but not configured Line 8 '
                              '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE08_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_08', 'req': 36069178,
                   'text': 'LOP ASIC internal error Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_08', 'req': 36069210,
                         'text': 'LOP monitor current failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_08', 'req': 36069245,
                 'text': 'LOP supply voltage failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_08', 'req': 36069277,
                          'text': 'LOP Low side driver failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_08', 'req': 36069309,
                           'text': 'LOP High side driver failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_08', 'req': 36069341,
                      'text': 'LOP Loose of ground connection Low Side 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_08', 'req': 36069525,
                    'text': 'LOP DR Cross connection failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_08', 'req': 36069624,
                        'text': 'loops PDC skipped due to internal condition Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE08_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_08', 'req': 36069592,
                        'text': 'loops PDC skipped due to external condition Line 8 (FLTMONR_NO_DTC_EVENT)'}
LINE08_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_08', 'req': 36069668,
                'text': 'LOP Firing time limiter and wording configuration failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_OPEN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_09', 'req': 36069474,
               'text': 'LOP Open circuit failure Line 9 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE09_S2G = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_09', 'req': 36069374,
              'text': 'LOP Short to ground failure Line 9 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE09_S2B = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_09', 'req': 36069399,
              'text': ('LOP Short to battery failure Line 9 '
                       '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE09_LORES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_09', 'req': 36069424,
                'text': 'LOP Resistance too low Line 9 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE09_HIRES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_09', 'req': 36069449,
                'text': 'LOP Resistance too high Line 9 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE09_XCONN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_09', 'req': 36069501,
                'text': ('LOP Cross connection failure Line 9 '
                         '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE09_UNEXPECTED = {'dtc': '0x92 0x60 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': False, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_09', 'req': 36069558,
                     'text': ('LOP Present but not configured Line 9 '
                              '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE09_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_09', 'req': 36069179,
                   'text': 'LOP ASIC internal error Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_09', 'req': 36069211,
                         'text': 'LOP monitor current failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_09', 'req': 36069246,
                 'text': 'LOP supply voltage failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_09', 'req': 36069278,
                          'text': 'LOP Low side driver failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_09', 'req': 36069310,
                           'text': 'LOP High side driver failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_09', 'req': 36069342,
                      'text': 'LOP Loose of ground connection Low Side 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_09', 'req': 36069526,
                    'text': 'LOP DR Cross connection failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_09', 'req': 36069625,
                        'text': 'loops PDC skipped due to internal condition Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE09_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_09', 'req': 36069593,
                        'text': 'loops PDC skipped due to external condition Line 9 (FLTMONR_NO_DTC_EVENT)'}
LINE09_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_09', 'req': 36069669,
                'text': 'LOP Firing time limiter and wording configuration failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_OPEN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_10', 'req': 36069475,
               'text': 'LOP Open circuit failure Line 10 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE10_S2G = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_10', 'req': 36069375,
              'text': ('LOP Short to ground failure Line 10 '
                       '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE10_S2B = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_10', 'req': 36069400,
              'text': ('LOP Short to battery failure Line 10 '
                       '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE10_LORES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_10', 'req': 36069425,
                'text': 'LOP Resistance too low Line 10 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE10_HIRES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_10', 'req': 36069450,
                'text': 'LOP Resistance too high Line 10 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
LINE10_XCONN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_10', 'req': 36069502,
                'text': ('LOP Cross connection failure Line 10 '
                         '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE10_UNEXPECTED = {'dtc': '0x92 0x60 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': False, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_10', 'req': 36069559,
                     'text': ('LOP Present but not configured Line 10 '
                              '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
LINE10_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_10', 'req': 36069180,
                   'text': 'LOP ASIC internal error Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_10', 'req': 36069212,
                         'text': 'LOP monitor current failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_10', 'req': 36069247,
                 'text': 'LOP supply voltage failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_10', 'req': 36069279,
                          'text': 'LOP Low side driver failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_10', 'req': 36069311,
                           'text': 'LOP High side driver failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_10', 'req': 36069343,
                      'text': 'LOP Loose of ground connection Low Side 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_10', 'req': 36069527,
                    'text': 'LOP DR Cross connection failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_10', 'req': 36069626,
                        'text': 'loops PDC skipped due to internal condition Line 10 (FLTMONR_E_ECU_INTERNAL)'}
LINE10_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_10', 'req': 36069594,
                        'text': 'loops PDC skipped due to external condition Line 10 (FLTMONR_NO_DTC_EVENT)'}
LINE10_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_10', 'req': 36069670,
                'text': ('LOP Firing time limiter and wording configuration failure Line 10 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
DKA_OPEN = {'dtc': '0x92 0x11 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_11', 'req': 36069476,
            'text': 'LOP Open circuit failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_OPEN)'}
DKA_S2G = {'dtc': '0x92 0x11 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_11', 'req': 36069376,
           'text': 'LOP Short to ground failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
DKA_S2B = {'dtc': '0x92 0x11 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_11', 'req': 36069401,
           'text': 'LOP Short to battery failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_SHORT_CIRCUIT_TO_BAT)'}
DKA_LORES = {'dtc': '0x92 0x11 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_11', 'req': 36069426,
             'text': 'LOP Resistance too low Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_LOW_RES)'}
DKA_HIRES = {'dtc': '0x92 0x11 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_11', 'req': 36069451,
             'text': 'LOP Resistance too high Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_HIGH_RES)'}
DKA_XCONN = {'dtc': '0x92 0x11 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_11', 'req': 36069503,
             'text': 'LOP Cross connection failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_CROSS_CONNECT)'}
DKA_UNEXPECTED = {'dtc': '0x92 0x11 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_11', 'req': 36069560,
                  'text': ('LOP Present but not configured Line 11 '
                           '(FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_UNEXPECTED_SQUIB)')}
DKA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_11', 'req': 36069181,
                'text': 'LOP ASIC internal error Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_11', 'req': 36069213,
                      'text': 'LOP monitor current failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_11', 'req': 36069248,
              'text': 'LOP supply voltage failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_11', 'req': 36069280,
                       'text': 'LOP Low side driver failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_11', 'req': 36069312,
                        'text': 'LOP High side driver failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_11', 'req': 36069344,
                   'text': 'LOP Loose of ground connection Low Side 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_11', 'req': 36069528,
                 'text': 'LOP DR Cross connection failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_11', 'req': 36069627,
                     'text': 'loops PDC skipped due to internal condition Line 11 (FLTMONR_E_ECU_INTERNAL)'}
DKA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_11', 'req': 36069595,
                     'text': 'loops PDC skipped due to external condition Line 11 (FLTMONR_NO_DTC_EVENT)'}
DKA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_11', 'req': 36069671,
             'text': 'LOP Firing time limiter and wording configuration failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_OPEN = {'dtc': '0x92 0x03 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_OPEN_12', 'req': 36069477,
             'text': 'LOP Open circuit failure Line 12 (FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_OPEN)'}
RLPT_S2G = {'dtc': '0x92 0x03 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_GND_12', 'req': 36069377,
            'text': ('LOP Short to ground failure Line 12 '
                     '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
RLPT_S2B = {'dtc': '0x92 0x03 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_BATT_12', 'req': 36069402,
            'text': ('LOP Short to battery failure Line 12 '
                     '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
RLPT_LORES = {'dtc': '0x92 0x03 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_LOW_RES_12', 'req': 36069427,
              'text': 'LOP Resistance too low Line 12 (FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_LOW_RES)'}
RLPT_HIRES = {'dtc': '0x92 0x03 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_HIGH_RES_12', 'req': 36069452,
              'text': 'LOP Resistance too high Line 12 (FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_HIGH_RES)'}
RLPT_XCONN = {'dtc': '0x92 0x03 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_CROSS_CONNECT_12', 'req': 36069504,
              'text': ('LOP Cross connection failure Line 12 '
                       '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_CROSS_CONNECT)')}
RLPT_UNEXPECTED = {'dtc': '0x92 0x03 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                              'Within PDC(2 sec)'),
                   'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_12', 'req': 36069561,
                   'text': ('LOP Present but not configured Line 12 '
                            '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
RLPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                            'definition PDC: n/a DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_INTERNAL_12', 'req': 36069182,
                 'text': 'LOP ASIC internal error Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_ISRC_12', 'req': 36069214,
                       'text': 'LOP monitor current failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
               'monitor': 'LOOP_F_SQUIB_SUPPLY_12', 'req': 36069249,
               'text': 'LOP supply voltage failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_LS_TRANS_12', 'req': 36069281,
                        'text': 'LOP Low side driver failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_HS_TRANS_12', 'req': 36069313,
                         'text': 'LOP High side driver failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                    'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_12', 'req': 36069345,
                    'text': 'LOP Loose of ground connection Low Side 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                             'PDC: NA / DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_12', 'req': 36069529,
                  'text': 'LOP DR Cross connection failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_12', 'req': 36069628,
                      'text': 'loops PDC skipped due to internal condition Line 12 (FLTMONR_E_ECU_INTERNAL)'}
RLPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                      'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_12', 'req': 36069596,
                      'text': 'loops PDC skipped due to external condition Line 12 (FLTMONR_NO_DTC_EVENT)'}
RLPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
              'monitor': 'LOOP_F_DWELL_FTL_12', 'req': 36069672,
              'text': 'LOP Firing time limiter and wording configuration failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_OPEN = {'dtc': '0x92 0x04 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_OPEN_13', 'req': 36069478,
             'text': 'LOP Open circuit failure Line 13 (FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_OPEN)'}
LLPT_S2G = {'dtc': '0x92 0x04 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_GND_13', 'req': 36069378,
            'text': ('LOP Short to ground failure Line 13 '
                     '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
LLPT_S2B = {'dtc': '0x92 0x04 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_BATT_13', 'req': 36069403,
            'text': ('LOP Short to battery failure Line 13 '
                     '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
LLPT_LORES = {'dtc': '0x92 0x04 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_LOW_RES_13', 'req': 36069428,
              'text': 'LOP Resistance too low Line 13 (FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_LOW_RES)'}
LLPT_HIRES = {'dtc': '0x92 0x04 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_HIGH_RES_13', 'req': 36069453,
              'text': 'LOP Resistance too high Line 13 (FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_HIGH_RES)'}
LLPT_XCONN = {'dtc': '0x92 0x04 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_CROSS_CONNECT_13', 'req': 36069505,
              'text': ('LOP Cross connection failure Line 13 '
                       '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_CROSS_CONNECT)')}
LLPT_UNEXPECTED = {'dtc': '0x92 0x04 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                              'Within PDC(2 sec)'),
                   'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_13', 'req': 36069562,
                   'text': ('LOP Present but not configured Line 13 '
                            '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
LLPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                            'definition PDC: n/a DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_INTERNAL_13', 'req': 36069183,
                 'text': 'LOP ASIC internal error Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_ISRC_13', 'req': 36069216,
                       'text': 'LOP monitor current failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
               'monitor': 'LOOP_F_SQUIB_SUPPLY_13', 'req': 36069250,
               'text': 'LOP supply voltage failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_LS_TRANS_13', 'req': 36069282,
                        'text': 'LOP Low side driver failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_HS_TRANS_13', 'req': 36069314,
                         'text': 'LOP High side driver failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                    'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_13', 'req': 36069346,
                    'text': 'LOP Loose of ground connection Low Side 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                             'PDC: NA / DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_13', 'req': 36069530,
                  'text': 'LOP DR Cross connection failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_13', 'req': 36069629,
                      'text': 'loops PDC skipped due to internal condition Line 13 (FLTMONR_E_ECU_INTERNAL)'}
LLPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                      'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_13', 'req': 36069597,
                      'text': 'loops PDC skipped due to external condition Line 13 (FLTMONR_NO_DTC_EVENT)'}
LLPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
              'monitor': 'LOOP_F_DWELL_FTL_13', 'req': 36069673,
              'text': 'LOP Firing time limiter and wording configuration failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
DFV_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_14', 'req': 36069184,
                'text': 'LOP ASIC internal error Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_14', 'req': 36069217,
                      'text': 'LOP monitor current failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_14', 'req': 36069251,
              'text': 'LOP supply voltage failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_14', 'req': 36069283,
                       'text': 'LOP Low side driver failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_14', 'req': 36069315,
                        'text': 'LOP High side driver failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_14', 'req': 36069347,
                   'text': 'LOP Loose of ground connection Low Side 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_14', 'req': 36069531,
                 'text': 'LOP DR Cross connection failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_14', 'req': 36069630,
                     'text': 'loops PDC skipped due to internal condition Line 14 (FLTMONR_E_ECU_INTERNAL)'}
DFV_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_14', 'req': 36069598,
                     'text': 'loops PDC skipped due to external condition Line 14 (FLTMONR_NO_DTC_EVENT)'}
DFV_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_14', 'req': 36069674,
             'text': 'LOP Firing time limiter and wording configuration failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
PFV_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_15', 'req': 36069185,
                'text': 'LOP ASIC internal error Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_15', 'req': 36069218,
                      'text': 'LOP monitor current failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_15', 'req': 36069252,
              'text': 'LOP supply voltage failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_15', 'req': 36069284,
                       'text': 'LOP Low side driver failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_15', 'req': 36069316,
                        'text': 'LOP High side driver failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_15', 'req': 36069348,
                   'text': 'LOP Loose of ground connection Low Side 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_15', 'req': 36069532,
                 'text': 'LOP DR Cross connection failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_15', 'req': 36069631,
                     'text': 'loops PDC skipped due to internal condition Line 15 (FLTMONR_E_ECU_INTERNAL)'}
PFV_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_15', 'req': 36069599,
                     'text': 'loops PDC skipped due to external condition Line 15 (FLTMONR_NO_DTC_EVENT)'}
PFV_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_15', 'req': 36069675,
             'text': 'LOP Firing time limiter and wording configuration failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_OPEN = {'dtc': '0x99 0x0F 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_OPEN_16', 'req': 36073791,
              'text': 'LOP Open circuit failure Line 16 (FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_OPEN)'}
R2RPT_S2G = {'dtc': '0x99 0x0F 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_SHORT_TO_GND_16', 'req': 36073765,
             'text': ('LOP Short to ground failure Line 16 '
                      '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
R2RPT_S2B = {'dtc': '0x99 0x0F 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_SHORT_TO_BATT_16', 'req': 36073772,
             'text': ('LOP Short to battery failure Line 16 '
                      '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
R2RPT_LORES = {'dtc': '0x99 0x0F 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_LOW_RES_16', 'req': 36073779,
               'text': 'LOP Resistance too low Line 16 (FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_LOW_RES)'}
R2RPT_HIRES = {'dtc': '0x99 0x0F 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_HIGH_RES_16', 'req': 36073786,
               'text': 'LOP Resistance too high Line 16 (FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_HIGH_RES)'}
R2RPT_XCONN = {'dtc': '0x99 0x0F 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_CROSS_CONNECT_16', 'req': 36073798,
               'text': ('LOP Cross connection failure Line 16 '
                        '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
R2RPT_UNEXPECTED = {'dtc': '0x99 0x0F 0x64', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': True,
                    'monitor': 'LOOP_F_UNEXPECTED_LOAD_16', 'req': 36073803,
                    'text': ('LOP Present but not configured Line 16 '
                             '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
R2RPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                             'definition PDC: n/a DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_INTERNAL_16', 'req': 36069186,
                  'text': 'LOP ASIC internal error Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_ISRC_16', 'req': 36069219,
                        'text': 'LOP monitor current failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_16', 'req': 36069253,
                'text': 'LOP supply voltage failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_LS_TRANS_16', 'req': 36069285,
                         'text': 'LOP Low side driver failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_HS_TRANS_16', 'req': 36069317,
                          'text': 'LOP High side driver failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_16', 'req': 36069349,
                     'text': 'LOP Loose of ground connection Low Side 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                              'Platform: PDC: NA / DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_16', 'req': 36069533,
                   'text': 'LOP DR Cross connection failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_16', 'req': 36069632,
                       'text': 'loops PDC skipped due to internal condition Line 16 (FLTMONR_E_ECU_INTERNAL)'}
R2RPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                       'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_16', 'req': 36069600,
                       'text': 'loops PDC skipped due to external condition Line 16 (FLTMONR_NO_DTC_EVENT)'}
R2RPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
               'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_16', 'req': 36069676,
               'text': 'LOP Firing time limiter and wording configuration failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
CAB_OPEN = {'dtc': '0x92 0x33 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_17', 'req': 36069481,
            'text': 'LOP Open circuit failure Line 17 (FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_OPEN)'}
CAB_S2G = {'dtc': '0x92 0x33 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_17', 'req': 36069379,
           'text': ('LOP Short to ground failure Line 17 '
                    '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_SHORT_CIRCUIT_TO_GND)')}
CAB_S2B = {'dtc': '0x92 0x33 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_17', 'req': 36069404,
           'text': ('LOP Short to battery failure Line 17 '
                    '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
CAB_LORES = {'dtc': '0x92 0x33 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_17', 'req': 36069429,
             'text': 'LOP Resistance too low Line 17 (FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_LOW_RES)'}
CAB_HIRES = {'dtc': '0x92 0x33 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_17', 'req': 36069454,
             'text': 'LOP Resistance too high Line 17 (FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_HIGH_RES)'}
CAB_XCONN = {'dtc': '0x92 0x33 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_17', 'req': 36069506,
             'text': ('LOP Cross connection failure Line 17 '
                      '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_CROSS_CONNECT)')}
CAB_UNEXPECTED = {'dtc': '0x92 0x33 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_17', 'req': 36069565,
                  'text': ('LOP Present but not configured Line 17 '
                           '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_UNEXPECTED_SQUIB)')}
CAB_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_17', 'req': 36069187,
                'text': 'LOP ASIC internal error Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_17', 'req': 36069220,
                      'text': 'LOP monitor current failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_17', 'req': 36069254,
              'text': 'LOP supply voltage failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_17', 'req': 36069286,
                       'text': 'LOP Low side driver failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_17', 'req': 36069318,
                        'text': 'LOP High side driver failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_17', 'req': 36069350,
                   'text': 'LOP Loose of ground connection Low Side 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_17', 'req': 36069534,
                 'text': 'LOP DR Cross connection failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_17', 'req': 36069633,
                     'text': 'loops PDC skipped due to internal condition Line 17 (FLTMONR_E_ECU_INTERNAL)'}
CAB_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_17', 'req': 36069601,
                     'text': 'loops PDC skipped due to external condition Line 17 (FLTMONR_NO_DTC_EVENT)'}
CAB_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_17', 'req': 36069677,
             'text': 'LOP Firing time limiter and wording configuration failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_OPEN = {'dtc': '0x99 0x14 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_OPEN_18', 'req': 36073792,
              'text': 'LOP Open circuit failure Line 18 (FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_OPEN)'}
R2LPT_S2G = {'dtc': '0x99 0x14 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_SHORT_TO_GND_18', 'req': 36073766,
             'text': ('LOP Short to ground failure Line 18 '
                      '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
R2LPT_S2B = {'dtc': '0x99 0x14 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_SHORT_TO_BATT_18', 'req': 36073773,
             'text': ('LOP Short to battery failure Line 18 '
                      '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
R2LPT_LORES = {'dtc': '0x99 0x14 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_LOW_RES_18', 'req': 36073780,
               'text': 'LOP Resistance too low Line 18 (FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_LOW_RES)'}
R2LPT_HIRES = {'dtc': '0x99 0x14 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_HIGH_RES_18', 'req': 36073787,
               'text': 'LOP Resistance too high Line 18 (FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_HIGH_RES)'}
R2LPT_XCONN = {'dtc': '0x99 0x14 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_CROSS_CONNECT_18', 'req': 36073799,
               'text': ('LOP Cross connection failure Line 18 '
                        '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
R2LPT_UNEXPECTED = {'dtc': '0x99 0x14 0x64', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': True,
                    'monitor': 'LOOP_F_UNEXPECTED_LOAD_18', 'req': 36073804,
                    'text': ('LOP Present but not configured Line 18 '
                             '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
R2LPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                             'definition PDC: n/a DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_INTERNAL_18', 'req': 36069188,
                  'text': 'LOP ASIC internal error Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_ISRC_18', 'req': 36069221,
                        'text': 'LOP monitor current failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_18', 'req': 36069255,
                'text': 'LOP supply voltage failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_LS_TRANS_18', 'req': 36069287,
                         'text': 'LOP Low side driver failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_HS_TRANS_18', 'req': 36069319,
                          'text': 'LOP High side driver failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_18', 'req': 36069351,
                     'text': 'LOP Loose of ground connection Low Side 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                              'Platform: PDC: NA / DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_18', 'req': 36069535,
                   'text': 'LOP DR Cross connection failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_18', 'req': 36069634,
                       'text': 'loops PDC skipped due to internal condition Line 18 (FLTMONR_E_ECU_INTERNAL)'}
R2LPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                       'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_18', 'req': 36069602,
                       'text': 'loops PDC skipped due to external condition Line 18 (FLTMONR_NO_DTC_EVENT)'}
R2LPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
               'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_18', 'req': 36069678,
               'text': 'LOP Firing time limiter and wording configuration failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_OPEN = {'dtc': '0x92 0x63 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_OPEN_19', 'req': 36069482,
             'text': 'LOP Open circuit failure Line 19 (FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_OPEN)'}
DBFL_S2G = {'dtc': '0x92 0x63 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_GND_19', 'req': 36069380,
            'text': ('LOP Short to ground failure Line 19 '
                     '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
DBFL_S2B = {'dtc': '0x92 0x63 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_BATT_19', 'req': 36069405,
            'text': ('LOP Short to battery failure Line 19 '
                     '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
DBFL_LORES = {'dtc': '0x92 0x63 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_LOW_RES_19', 'req': 36069430,
              'text': 'LOP Resistance too low Line 19 (FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_LOW_RES)'}
DBFL_HIRES = {'dtc': '0x92 0x63 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_HIGH_RES_19', 'req': 36069455,
              'text': 'LOP Resistance too high Line 19 (FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_HIGH_RES)'}
DBFL_XCONN = {'dtc': '0x92 0x63 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_CROSS_CONNECT_19', 'req': 36069507,
              'text': ('LOP Cross connection failure Line 19 '
                       '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_CROSS_CONNECT)')}
DBFL_UNEXPECTED = {'dtc': '0x92 0x63 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                              'Within PDC(2 sec)'),
                   'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_19', 'req': 36069566,
                   'text': ('LOP Present but not configured Line 19 '
                            '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_UNEXPECTED_SQUIB)')}
DBFL_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                            'definition PDC: n/a DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_INTERNAL_19', 'req': 36069189,
                 'text': 'LOP ASIC internal error Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_ISRC_19', 'req': 36069222,
                       'text': 'LOP monitor current failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
               'monitor': 'LOOP_F_SQUIB_SUPPLY_19', 'req': 36069256,
               'text': 'LOP supply voltage failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_LS_TRANS_19', 'req': 36069288,
                        'text': 'LOP Low side driver failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_HS_TRANS_19', 'req': 36069320,
                         'text': 'LOP High side driver failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                    'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_19', 'req': 36069352,
                    'text': 'LOP Loose of ground connection Low Side 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                             'PDC: NA / DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_19', 'req': 36069536,
                  'text': 'LOP DR Cross connection failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_19', 'req': 36069635,
                      'text': 'loops PDC skipped due to internal condition Line 19 (FLTMONR_E_ECU_INTERNAL)'}
DBFL_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                      'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_19', 'req': 36069603,
                      'text': 'loops PDC skipped due to external condition Line 19 (FLTMONR_NO_DTC_EVENT)'}
DBFL_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
              'monitor': 'LOOP_F_DWELL_FTL_19', 'req': 36069679,
              'text': 'LOP Firing time limiter and wording configuration failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_OPEN = {'dtc': '0x92 0x64 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_OPEN_20', 'req': 36069483,
             'text': 'LOP Open circuit failure Line 20 (FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_OPEN)'}
PBFL_S2G = {'dtc': '0x92 0x64 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_GND_20', 'req': 36069381,
            'text': ('LOP Short to ground failure Line 20 '
                     '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
PBFL_S2B = {'dtc': '0x92 0x64 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_BATT_20', 'req': 36069406,
            'text': ('LOP Short to battery failure Line 20 '
                     '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
PBFL_LORES = {'dtc': '0x92 0x64 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_LOW_RES_20', 'req': 36069431,
              'text': 'LOP Resistance too low Line 20 (FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_LOW_RES)'}
PBFL_HIRES = {'dtc': '0x92 0x64 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_HIGH_RES_20', 'req': 36069456,
              'text': 'LOP Resistance too high Line 20 (FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_HIGH_RES)'}
PBFL_XCONN = {'dtc': '0x92 0x64 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_CROSS_CONNECT_20', 'req': 36069508,
              'text': ('LOP Cross connection failure Line 20 '
                       '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_CROSS_CONNECT)')}
PBFL_UNEXPECTED = {'dtc': '0x92 0x64 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                              'Within PDC(2 sec)'),
                   'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_20', 'req': 36069567,
                   'text': ('LOP Present but not configured Line 20 '
                            '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_UNEXPECTED_SQUIB)')}
PBFL_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                            'definition PDC: n/a DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_INTERNAL_20', 'req': 36069190,
                 'text': 'LOP ASIC internal error Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_ISRC_20', 'req': 36069223,
                       'text': 'LOP monitor current failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
               'monitor': 'LOOP_F_SQUIB_SUPPLY_20', 'req': 36069257,
               'text': 'LOP supply voltage failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_LS_TRANS_20', 'req': 36069289,
                        'text': 'LOP Low side driver failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_HS_TRANS_20', 'req': 36069321,
                         'text': 'LOP High side driver failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                    'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_20', 'req': 36069353,
                    'text': 'LOP Loose of ground connection Low Side 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                             'PDC: NA / DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_20', 'req': 36069537,
                  'text': 'LOP DR Cross connection failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_20', 'req': 36069636,
                      'text': 'loops PDC skipped due to internal condition Line 20 (FLTMONR_E_ECU_INTERNAL)'}
PBFL_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                      'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_20', 'req': 36069604,
                      'text': 'loops PDC skipped due to external condition Line 20 (FLTMONR_NO_DTC_EVENT)'}
PBFL_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
              'monitor': 'LOOP_F_DWELL_FTL_20', 'req': 36069680,
              'text': 'LOP Firing time limiter and wording configuration failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                            'definition PDC: n/a DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_INTERNAL_21', 'req': 36069191,
                 'text': 'LOP ASIC internal error Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_ISRC_21', 'req': 36069224,
                       'text': 'LOP monitor current failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
               'monitor': 'LOOP_F_SQUIB_SUPPLY_21', 'req': 36069258,
               'text': 'LOP supply voltage failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_LS_TRANS_21', 'req': 36069290,
                        'text': 'LOP Low side driver failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_HS_TRANS_21', 'req': 36069322,
                         'text': 'LOP High side driver failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                    'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_21', 'req': 36069354,
                    'text': 'LOP Loose of ground connection Low Side 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                             'PDC: NA / DRIVE: 4'),
                  'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_21', 'req': 36069538,
                  'text': 'LOP DR Cross connection failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_21', 'req': 36069637,
                      'text': 'loops PDC skipped due to internal condition Line 21 (FLTMONR_E_ECU_INTERNAL)'}
HVBD_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                      'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_21', 'req': 36069605,
                      'text': 'loops PDC skipped due to external condition Line 21 (FLTMONR_NO_DTC_EVENT)'}
HVBD_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
              'monitor': 'LOOP_F_DWELL_FTL_21', 'req': 36069681,
              'text': 'LOP Firing time limiter and wording configuration failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
PPC_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_22', 'req': 36069192,
                'text': 'LOP ASIC internal error Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_22', 'req': 36069225,
                      'text': 'LOP monitor current failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_22', 'req': 36069259,
              'text': 'LOP supply voltage failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_22', 'req': 36069291,
                       'text': 'LOP Low side driver failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_22', 'req': 36069323,
                        'text': 'LOP High side driver failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_22', 'req': 36069355,
                   'text': 'LOP Loose of ground connection Low Side 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_22', 'req': 36069539,
                 'text': 'LOP DR Cross connection failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_22', 'req': 36069638,
                     'text': 'loops PDC skipped due to internal condition Line 22 (FLTMONR_E_ECU_INTERNAL)'}
PPC_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_22', 'req': 36069606,
                     'text': 'loops PDC skipped due to external condition Line 22 (FLTMONR_NO_DTC_EVENT)'}
PPC_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_22', 'req': 36069682,
             'text': 'LOP Firing time limiter and wording configuration failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
DPC_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                           'definition PDC: n/a DRIVE: 4'),
                'latched': False, 'monitor': 'LOOP_F_INTERNAL_23', 'req': 36069193,
                'text': 'LOP ASIC internal error Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': True, 'monitor': 'LOOP_F_ISRC_23', 'req': 36069226,
                      'text': 'LOP monitor current failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4', 'latched': False,
              'monitor': 'LOOP_F_SQUIB_SUPPLY_23', 'req': 36069260,
              'text': 'LOP supply voltage failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': True, 'monitor': 'LOOP_F_LS_TRANS_23', 'req': 36069292,
                       'text': 'LOP Low side driver failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_HS_TRANS_23', 'req': 36069324,
                        'text': 'LOP High side driver failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_23', 'req': 36069356,
                   'text': 'LOP Loose of ground connection Low Side 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: Platform: '
                            'PDC: NA / DRIVE: 4'),
                 'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_23', 'req': 36069540,
                 'text': 'LOP DR Cross connection failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_23', 'req': 36069639,
                     'text': 'loops PDC skipped due to internal condition Line 23 (FLTMONR_E_ECU_INTERNAL)'}
DPC_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                     'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_23', 'req': 36069607,
                     'text': 'loops PDC skipped due to external condition Line 23 (FLTMONR_NO_DTC_EVENT)'}
DPC_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a', 'latched': True,
             'monitor': 'LOOP_F_DWELL_FTL_23', 'req': 36069683,
             'text': 'LOP Firing time limiter and wording configuration failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
LINE24_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_24', 'req': 36069382,
              'text': 'LOP Short to ground failure Line 24 (FLTMONR_E_ECU_INTERNAL)'}
LINE25_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_25', 'req': 36069383,
              'text': 'LOP Short to ground failure Line 25 (FLTMONR_E_ECU_INTERNAL)'}
LINE26_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_26', 'req': 36069384,
              'text': 'LOP Short to ground failure Line 26 (FLTMONR_E_ECU_INTERNAL)'}
LINE27_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_27', 'req': 36069385,
              'text': 'LOP Short to ground failure Line 27 (FLTMONR_E_ECU_INTERNAL)'}
LINE28_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_28', 'req': 36069386,
              'text': 'LOP Short to ground failure Line 28 (FLTMONR_E_ECU_INTERNAL)'}
LINE29_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_29', 'req': 36069387,
              'text': 'LOP Short to ground failure Line 29 (FLTMONR_E_ECU_INTERNAL)'}
LINE30_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_30', 'req': 36069388,
              'text': 'LOP Short to ground failure Line 30 (FLTMONR_E_ECU_INTERNAL)'}
LINE31_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_31', 'req': 36069389,
              'text': 'LOP Short to ground failure Line 31 (FLTMONR_E_ECU_INTERNAL)'}
LOOP0_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_CMT_00', 'req': 36069700,
                         'text': 'Current Monitor Counter failure Line 00 (FLTMONR_E_ECU_INTERNAL)'}
LOOP1_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_CMT_01', 'req': 36069701,
                         'text': 'Current Monitor Counter failure Line 01 (FLTMONR_E_ECU_INTERNAL)'}
LOOP2_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_CMT_02', 'req': 36069702,
                         'text': 'Current Monitor Counter failure Line 02 (FLTMONR_E_ECU_INTERNAL)'}
LOOP3_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_CMT_03', 'req': 36069703,
                         'text': 'Current Monitor Counter failure Line 03 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC0_VRCM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_ASIC_VRCM_00', 'req': 36069648,
                   'text': 'LOOP ASIC VRCM&OXI failure SB3_M (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC1_VRCM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_ASIC_VRCM_01', 'req': 36069649,
                   'text': 'LOOP ASIC VRCM&OXI failure SB3_S (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC2_VRCM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': False, 'monitor': 'LOOP_F_ASIC_VRCM_02', 'req': 36069650,
                   'text': 'LOOP ASIC VRCM&OXI failure EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC0_LOCKING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_ASIC_LOCKING_00', 'req': 36069652,
                      'text': 'LOP Lock/UnLock failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC1_LOCKING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_ASIC_LOCKING_01', 'req': 36069653,
                      'text': 'LOP Lock/UnLock failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC2_LOCKING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_ASIC_LOCKING_02', 'req': 36069654,
                      'text': 'LOP Lock/UnLock failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC0_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': False, 'monitor': 'LOOP_F_ASIC_CONFIG_00', 'req': 36069656,
                     'text': 'LOP Configuration failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC1_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': False, 'monitor': 'LOOP_F_ASIC_CONFIG_01', 'req': 36069657,
                     'text': 'LOP Configuration failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC2_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                     'latched': False, 'monitor': 'LOOP_F_ASIC_CONFIG_02', 'req': 36069658,
                     'text': 'LOP Configuration failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC0_DEPLOY_COMMAND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_DEP_COMMAND_00', 'req': 36069692,
                             'text': 'Deployment Command Register failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC1_DEPLOY_COMMAND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_DEP_COMMAND_01', 'req': 36069693,
                             'text': 'Deployment Command Register failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC2_DEPLOY_COMMAND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_DEP_COMMAND_02', 'req': 36069694,
                             'text': 'Deployment Command Register failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC0_DEPLOY_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_DEP_CMP_00', 'req': 36069696,
                             'text': 'Comparator register deployment failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC1_DEPLOY_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_DEP_CMP_01', 'req': 36069697,
                             'text': 'Comparator register deployment failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
LOOP_ASIC2_DEPLOY_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_DEP_CMP_02', 'req': 36069698,
                             'text': 'Comparator register deployment failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}

LOOP_FAULTS = {
    'RPT_OPEN': RPT_OPEN,
    'RPT_S2G': RPT_S2G,
    'RPT_S2B': RPT_S2B,
    'RPT_LORES': RPT_LORES,
    'RPT_HIRES': RPT_HIRES,
    'RPT_XCONN': RPT_XCONN,
    'RPT_UNEXPECTED': RPT_UNEXPECTED,
    'RPT_INTERNAL': RPT_INTERNAL,
    'RPT_CURRENT_SOURCE': RPT_CURRENT_SOURCE,
    'RPT_SUPPLY': RPT_SUPPLY,
    'RPT_LOW_SIDE_SWITCH': RPT_LOW_SIDE_SWITCH,
    'RPT_HIGH_SIDE_SWITCH': RPT_HIGH_SIDE_SWITCH,
    'RPT_GROUND_LOSS': RPT_GROUND_LOSS,
    'RPT_CSR_XCONN': RPT_CSR_XCONN,
    'RPT_PDC_ABORT_INT': RPT_PDC_ABORT_INT,
    'RPT_PDC_ABORT_EXT': RPT_PDC_ABORT_EXT,
    'RPT_DWELL': RPT_DWELL,
    'LPT_OPEN': LPT_OPEN,
    'LPT_S2G': LPT_S2G,
    'LPT_S2B': LPT_S2B,
    'LPT_LORES': LPT_LORES,
    'LPT_HIRES': LPT_HIRES,
    'LPT_XCONN': LPT_XCONN,
    'LPT_UNEXPECTED': LPT_UNEXPECTED,
    'LPT_INTERNAL': LPT_INTERNAL,
    'LPT_CURRENT_SOURCE': LPT_CURRENT_SOURCE,
    'LPT_SUPPLY': LPT_SUPPLY,
    'LPT_LOW_SIDE_SWITCH': LPT_LOW_SIDE_SWITCH,
    'LPT_HIGH_SIDE_SWITCH': LPT_HIGH_SIDE_SWITCH,
    'LPT_GROUND_LOSS': LPT_GROUND_LOSS,
    'LPT_CSR_XCONN': LPT_CSR_XCONN,
    'LPT_PDC_ABORT_INT': LPT_PDC_ABORT_INT,
    'LPT_PDC_ABORT_EXT': LPT_PDC_ABORT_EXT,
    'LPT_DWELL': LPT_DWELL,
    'RSA_OPEN': RSA_OPEN,
    'RSA_S2G': RSA_S2G,
    'RSA_S2B': RSA_S2B,
    'RSA_LORES': RSA_LORES,
    'RSA_HIRES': RSA_HIRES,
    'RSA_XCONN': RSA_XCONN,
    'RSA_UNEXPECTED': RSA_UNEXPECTED,
    'RSA_INTERNAL': RSA_INTERNAL,
    'RSA_CURRENT_SOURCE': RSA_CURRENT_SOURCE,
    'RSA_SUPPLY': RSA_SUPPLY,
    'RSA_LOW_SIDE_SWITCH': RSA_LOW_SIDE_SWITCH,
    'RSA_HIGH_SIDE_SWITCH': RSA_HIGH_SIDE_SWITCH,
    'RSA_GROUND_LOSS': RSA_GROUND_LOSS,
    'RSA_CSR_XCONN': RSA_CSR_XCONN,
    'RSA_PDC_ABORT_INT': RSA_PDC_ABORT_INT,
    'RSA_PDC_ABORT_EXT': RSA_PDC_ABORT_EXT,
    'RSA_DWELL': RSA_DWELL,
    'LSA_OPEN': LSA_OPEN,
    'LSA_S2G': LSA_S2G,
    'LSA_S2B': LSA_S2B,
    'LSA_LORES': LSA_LORES,
    'LSA_HIRES': LSA_HIRES,
    'LSA_XCONN': LSA_XCONN,
    'LSA_UNEXPECTED': LSA_UNEXPECTED,
    'LSA_INTERNAL': LSA_INTERNAL,
    'LSA_CURRENT_SOURCE': LSA_CURRENT_SOURCE,
    'LSA_SUPPLY': LSA_SUPPLY,
    'LSA_LOW_SIDE_SWITCH': LSA_LOW_SIDE_SWITCH,
    'LSA_HIGH_SIDE_SWITCH': LSA_HIGH_SIDE_SWITCH,
    'LSA_GROUND_LOSS': LSA_GROUND_LOSS,
    'LSA_CSR_XCONN': LSA_CSR_XCONN,
    'LSA_PDC_ABORT_INT': LSA_PDC_ABORT_INT,
    'LSA_PDC_ABORT_EXT': LSA_PDC_ABORT_EXT,
    'LSA_DWELL': LSA_DWELL,
    'RCA_OPEN': RCA_OPEN,
    'RCA_S2G': RCA_S2G,
    'RCA_S2B': RCA_S2B,
    'RCA_LORES': RCA_LORES,
    'RCA_HIRES': RCA_HIRES,
    'RCA_XCONN': RCA_XCONN,
    'RCA_UNEXPECTED': RCA_UNEXPECTED,
    'RCA_INTERNAL': RCA_INTERNAL,
    'RCA_CURRENT_SOURCE': RCA_CURRENT_SOURCE,
    'RCA_SUPPLY': RCA_SUPPLY,
    'RCA_LOW_SIDE_SWITCH': RCA_LOW_SIDE_SWITCH,
    'RCA_HIGH_SIDE_SWITCH': RCA_HIGH_SIDE_SWITCH,
    'RCA_GROUND_LOSS': RCA_GROUND_LOSS,
    'RCA_CSR_XCONN': RCA_CSR_XCONN,
    'RCA_PDC_ABORT_INT': RCA_PDC_ABORT_INT,
    'RCA_PDC_ABORT_EXT': RCA_PDC_ABORT_EXT,
    'RCA_DWELL': RCA_DWELL,
    'LCA_OPEN': LCA_OPEN,
    'LCA_S2G': LCA_S2G,
    'LCA_S2B': LCA_S2B,
    'LCA_LORES': LCA_LORES,
    'LCA_HIRES': LCA_HIRES,
    'LCA_XCONN': LCA_XCONN,
    'LCA_UNEXPECTED': LCA_UNEXPECTED,
    'LCA_INTERNAL': LCA_INTERNAL,
    'LCA_CURRENT_SOURCE': LCA_CURRENT_SOURCE,
    'LCA_SUPPLY': LCA_SUPPLY,
    'LCA_LOW_SIDE_SWITCH': LCA_LOW_SIDE_SWITCH,
    'LCA_HIGH_SIDE_SWITCH': LCA_HIGH_SIDE_SWITCH,
    'LCA_GROUND_LOSS': LCA_GROUND_LOSS,
    'LCA_CSR_XCONN': LCA_CSR_XCONN,
    'LCA_PDC_ABORT_INT': LCA_PDC_ABORT_INT,
    'LCA_PDC_ABORT_EXT': LCA_PDC_ABORT_EXT,
    'LCA_DWELL': LCA_DWELL,
    'DAB_OPEN': DAB_OPEN,
    'DAB_S2G': DAB_S2G,
    'DAB_S2B': DAB_S2B,
    'DAB_LORES': DAB_LORES,
    'DAB_HIRES': DAB_HIRES,
    'DAB_XCONN': DAB_XCONN,
    'DAB_UNEXPECTED': DAB_UNEXPECTED,
    'DAB_INTERNAL': DAB_INTERNAL,
    'DAB_CURRENT_SOURCE': DAB_CURRENT_SOURCE,
    'DAB_SUPPLY': DAB_SUPPLY,
    'DAB_LOW_SIDE_SWITCH': DAB_LOW_SIDE_SWITCH,
    'DAB_HIGH_SIDE_SWITCH': DAB_HIGH_SIDE_SWITCH,
    'DAB_GROUND_LOSS': DAB_GROUND_LOSS,
    'DAB_CSR_XCONN': DAB_CSR_XCONN,
    'DAB_PDC_ABORT_INT': DAB_PDC_ABORT_INT,
    'DAB_PDC_ABORT_EXT': DAB_PDC_ABORT_EXT,
    'DAB_DWELL': DAB_DWELL,
    'PAB_OPEN': PAB_OPEN,
    'PAB_S2G': PAB_S2G,
    'PAB_S2B': PAB_S2B,
    'PAB_LORES': PAB_LORES,
    'PAB_HIRES': PAB_HIRES,
    'PAB_XCONN': PAB_XCONN,
    'PAB_UNEXPECTED': PAB_UNEXPECTED,
    'PAB_INTERNAL': PAB_INTERNAL,
    'PAB_CURRENT_SOURCE': PAB_CURRENT_SOURCE,
    'PAB_SUPPLY': PAB_SUPPLY,
    'PAB_LOW_SIDE_SWITCH': PAB_LOW_SIDE_SWITCH,
    'PAB_HIGH_SIDE_SWITCH': PAB_HIGH_SIDE_SWITCH,
    'PAB_GROUND_LOSS': PAB_GROUND_LOSS,
    'PAB_CSR_XCONN': PAB_CSR_XCONN,
    'PAB_PDC_ABORT_INT': PAB_PDC_ABORT_INT,
    'PAB_PDC_ABORT_EXT': PAB_PDC_ABORT_EXT,
    'PAB_DWELL': PAB_DWELL,
    'LINE08_OPEN': LINE08_OPEN,
    'LINE08_S2G': LINE08_S2G,
    'LINE08_S2B': LINE08_S2B,
    'LINE08_LORES': LINE08_LORES,
    'LINE08_HIRES': LINE08_HIRES,
    'LINE08_XCONN': LINE08_XCONN,
    'LINE08_UNEXPECTED': LINE08_UNEXPECTED,
    'LINE08_INTERNAL': LINE08_INTERNAL,
    'LINE08_CURRENT_SOURCE': LINE08_CURRENT_SOURCE,
    'LINE08_SUPPLY': LINE08_SUPPLY,
    'LINE08_LOW_SIDE_SWITCH': LINE08_LOW_SIDE_SWITCH,
    'LINE08_HIGH_SIDE_SWITCH': LINE08_HIGH_SIDE_SWITCH,
    'LINE08_GROUND_LOSS': LINE08_GROUND_LOSS,
    'LINE08_CSR_XCONN': LINE08_CSR_XCONN,
    'LINE08_PDC_ABORT_INT': LINE08_PDC_ABORT_INT,
    'LINE08_PDC_ABORT_EXT': LINE08_PDC_ABORT_EXT,
    'LINE08_DWELL': LINE08_DWELL,
    'LINE09_OPEN': LINE09_OPEN,
    'LINE09_S2G': LINE09_S2G,
    'LINE09_S2B': LINE09_S2B,
    'LINE09_LORES': LINE09_LORES,
    'LINE09_HIRES': LINE09_HIRES,
    'LINE09_XCONN': LINE09_XCONN,
    'LINE09_UNEXPECTED': LINE09_UNEXPECTED,
    'LINE09_INTERNAL': LINE09_INTERNAL,
    'LINE09_CURRENT_SOURCE': LINE09_CURRENT_SOURCE,
    'LINE09_SUPPLY': LINE09_SUPPLY,
    'LINE09_LOW_SIDE_SWITCH': LINE09_LOW_SIDE_SWITCH,
    'LINE09_HIGH_SIDE_SWITCH': LINE09_HIGH_SIDE_SWITCH,
    'LINE09_GROUND_LOSS': LINE09_GROUND_LOSS,
    'LINE09_CSR_XCONN': LINE09_CSR_XCONN,
    'LINE09_PDC_ABORT_INT': LINE09_PDC_ABORT_INT,
    'LINE09_PDC_ABORT_EXT': LINE09_PDC_ABORT_EXT,
    'LINE09_DWELL': LINE09_DWELL,
    'LINE10_OPEN': LINE10_OPEN,
    'LINE10_S2G': LINE10_S2G,
    'LINE10_S2B': LINE10_S2B,
    'LINE10_LORES': LINE10_LORES,
    'LINE10_HIRES': LINE10_HIRES,
    'LINE10_XCONN': LINE10_XCONN,
    'LINE10_UNEXPECTED': LINE10_UNEXPECTED,
    'LINE10_INTERNAL': LINE10_INTERNAL,
    'LINE10_CURRENT_SOURCE': LINE10_CURRENT_SOURCE,
    'LINE10_SUPPLY': LINE10_SUPPLY,
    'LINE10_LOW_SIDE_SWITCH': LINE10_LOW_SIDE_SWITCH,
    'LINE10_HIGH_SIDE_SWITCH': LINE10_HIGH_SIDE_SWITCH,
    'LINE10_GROUND_LOSS': LINE10_GROUND_LOSS,
    'LINE10_CSR_XCONN': LINE10_CSR_XCONN,
    'LINE10_PDC_ABORT_INT': LINE10_PDC_ABORT_INT,
    'LINE10_PDC_ABORT_EXT': LINE10_PDC_ABORT_EXT,
    'LINE10_DWELL': LINE10_DWELL,
    'DKA_OPEN': DKA_OPEN,
    'DKA_S2G': DKA_S2G,
    'DKA_S2B': DKA_S2B,
    'DKA_LORES': DKA_LORES,
    'DKA_HIRES': DKA_HIRES,
    'DKA_XCONN': DKA_XCONN,
    'DKA_UNEXPECTED': DKA_UNEXPECTED,
    'DKA_INTERNAL': DKA_INTERNAL,
    'DKA_CURRENT_SOURCE': DKA_CURRENT_SOURCE,
    'DKA_SUPPLY': DKA_SUPPLY,
    'DKA_LOW_SIDE_SWITCH': DKA_LOW_SIDE_SWITCH,
    'DKA_HIGH_SIDE_SWITCH': DKA_HIGH_SIDE_SWITCH,
    'DKA_GROUND_LOSS': DKA_GROUND_LOSS,
    'DKA_CSR_XCONN': DKA_CSR_XCONN,
    'DKA_PDC_ABORT_INT': DKA_PDC_ABORT_INT,
    'DKA_PDC_ABORT_EXT': DKA_PDC_ABORT_EXT,
    'DKA_DWELL': DKA_DWELL,
    'RLPT_OPEN': RLPT_OPEN,
    'RLPT_S2G': RLPT_S2G,
    'RLPT_S2B': RLPT_S2B,
    'RLPT_LORES': RLPT_LORES,
    'RLPT_HIRES': RLPT_HIRES,
    'RLPT_XCONN': RLPT_XCONN,
    'RLPT_UNEXPECTED': RLPT_UNEXPECTED,
    'RLPT_INTERNAL': RLPT_INTERNAL,
    'RLPT_CURRENT_SOURCE': RLPT_CURRENT_SOURCE,
    'RLPT_SUPPLY': RLPT_SUPPLY,
    'RLPT_LOW_SIDE_SWITCH': RLPT_LOW_SIDE_SWITCH,
    'RLPT_HIGH_SIDE_SWITCH': RLPT_HIGH_SIDE_SWITCH,
    'RLPT_GROUND_LOSS': RLPT_GROUND_LOSS,
    'RLPT_CSR_XCONN': RLPT_CSR_XCONN,
    'RLPT_PDC_ABORT_INT': RLPT_PDC_ABORT_INT,
    'RLPT_PDC_ABORT_EXT': RLPT_PDC_ABORT_EXT,
    'RLPT_DWELL': RLPT_DWELL,
    'LLPT_OPEN': LLPT_OPEN,
    'LLPT_S2G': LLPT_S2G,
    'LLPT_S2B': LLPT_S2B,
    'LLPT_LORES': LLPT_LORES,
    'LLPT_HIRES': LLPT_HIRES,
    'LLPT_XCONN': LLPT_XCONN,
    'LLPT_UNEXPECTED': LLPT_UNEXPECTED,
    'LLPT_INTERNAL': LLPT_INTERNAL,
    'LLPT_CURRENT_SOURCE': LLPT_CURRENT_SOURCE,
    'LLPT_SUPPLY': LLPT_SUPPLY,
    'LLPT_LOW_SIDE_SWITCH': LLPT_LOW_SIDE_SWITCH,
    'LLPT_HIGH_SIDE_SWITCH': LLPT_HIGH_SIDE_SWITCH,
    'LLPT_GROUND_LOSS': LLPT_GROUND_LOSS,
    'LLPT_CSR_XCONN': LLPT_CSR_XCONN,
    'LLPT_PDC_ABORT_INT': LLPT_PDC_ABORT_INT,
    'LLPT_PDC_ABORT_EXT': LLPT_PDC_ABORT_EXT,
    'LLPT_DWELL': LLPT_DWELL,
    'DFV_INTERNAL': DFV_INTERNAL,
    'DFV_CURRENT_SOURCE': DFV_CURRENT_SOURCE,
    'DFV_SUPPLY': DFV_SUPPLY,
    'DFV_LOW_SIDE_SWITCH': DFV_LOW_SIDE_SWITCH,
    'DFV_HIGH_SIDE_SWITCH': DFV_HIGH_SIDE_SWITCH,
    'DFV_GROUND_LOSS': DFV_GROUND_LOSS,
    'DFV_CSR_XCONN': DFV_CSR_XCONN,
    'DFV_PDC_ABORT_INT': DFV_PDC_ABORT_INT,
    'DFV_PDC_ABORT_EXT': DFV_PDC_ABORT_EXT,
    'DFV_DWELL': DFV_DWELL,
    'PFV_INTERNAL': PFV_INTERNAL,
    'PFV_CURRENT_SOURCE': PFV_CURRENT_SOURCE,
    'PFV_SUPPLY': PFV_SUPPLY,
    'PFV_LOW_SIDE_SWITCH': PFV_LOW_SIDE_SWITCH,
    'PFV_HIGH_SIDE_SWITCH': PFV_HIGH_SIDE_SWITCH,
    'PFV_GROUND_LOSS': PFV_GROUND_LOSS,
    'PFV_CSR_XCONN': PFV_CSR_XCONN,
    'PFV_PDC_ABORT_INT': PFV_PDC_ABORT_INT,
    'PFV_PDC_ABORT_EXT': PFV_PDC_ABORT_EXT,
    'PFV_DWELL': PFV_DWELL,
    'R2RPT_OPEN': R2RPT_OPEN,
    'R2RPT_S2G': R2RPT_S2G,
    'R2RPT_S2B': R2RPT_S2B,
    'R2RPT_LORES': R2RPT_LORES,
    'R2RPT_HIRES': R2RPT_HIRES,
    'R2RPT_XCONN': R2RPT_XCONN,
    'R2RPT_UNEXPECTED': R2RPT_UNEXPECTED,
    'R2RPT_INTERNAL': R2RPT_INTERNAL,
    'R2RPT_CURRENT_SOURCE': R2RPT_CURRENT_SOURCE,
    'R2RPT_SUPPLY': R2RPT_SUPPLY,
    'R2RPT_LOW_SIDE_SWITCH': R2RPT_LOW_SIDE_SWITCH,
    'R2RPT_HIGH_SIDE_SWITCH': R2RPT_HIGH_SIDE_SWITCH,
    'R2RPT_GROUND_LOSS': R2RPT_GROUND_LOSS,
    'R2RPT_CSR_XCONN': R2RPT_CSR_XCONN,
    'R2RPT_PDC_ABORT_INT': R2RPT_PDC_ABORT_INT,
    'R2RPT_PDC_ABORT_EXT': R2RPT_PDC_ABORT_EXT,
    'R2RPT_DWELL': R2RPT_DWELL,
    'CAB_OPEN': CAB_OPEN,
    'CAB_S2G': CAB_S2G,
    'CAB_S2B': CAB_S2B,
    'CAB_LORES': CAB_LORES,
    'CAB_HIRES': CAB_HIRES,
    'CAB_XCONN': CAB_XCONN,
    'CAB_UNEXPECTED': CAB_UNEXPECTED,
    'CAB_INTERNAL': CAB_INTERNAL,
    'CAB_CURRENT_SOURCE': CAB_CURRENT_SOURCE,
    'CAB_SUPPLY': CAB_SUPPLY,
    'CAB_LOW_SIDE_SWITCH': CAB_LOW_SIDE_SWITCH,
    'CAB_HIGH_SIDE_SWITCH': CAB_HIGH_SIDE_SWITCH,
    'CAB_GROUND_LOSS': CAB_GROUND_LOSS,
    'CAB_CSR_XCONN': CAB_CSR_XCONN,
    'CAB_PDC_ABORT_INT': CAB_PDC_ABORT_INT,
    'CAB_PDC_ABORT_EXT': CAB_PDC_ABORT_EXT,
    'CAB_DWELL': CAB_DWELL,
    'R2LPT_OPEN': R2LPT_OPEN,
    'R2LPT_S2G': R2LPT_S2G,
    'R2LPT_S2B': R2LPT_S2B,
    'R2LPT_LORES': R2LPT_LORES,
    'R2LPT_HIRES': R2LPT_HIRES,
    'R2LPT_XCONN': R2LPT_XCONN,
    'R2LPT_UNEXPECTED': R2LPT_UNEXPECTED,
    'R2LPT_INTERNAL': R2LPT_INTERNAL,
    'R2LPT_CURRENT_SOURCE': R2LPT_CURRENT_SOURCE,
    'R2LPT_SUPPLY': R2LPT_SUPPLY,
    'R2LPT_LOW_SIDE_SWITCH': R2LPT_LOW_SIDE_SWITCH,
    'R2LPT_HIGH_SIDE_SWITCH': R2LPT_HIGH_SIDE_SWITCH,
    'R2LPT_GROUND_LOSS': R2LPT_GROUND_LOSS,
    'R2LPT_CSR_XCONN': R2LPT_CSR_XCONN,
    'R2LPT_PDC_ABORT_INT': R2LPT_PDC_ABORT_INT,
    'R2LPT_PDC_ABORT_EXT': R2LPT_PDC_ABORT_EXT,
    'R2LPT_DWELL': R2LPT_DWELL,
    'DBFL_OPEN': DBFL_OPEN,
    'DBFL_S2G': DBFL_S2G,
    'DBFL_S2B': DBFL_S2B,
    'DBFL_LORES': DBFL_LORES,
    'DBFL_HIRES': DBFL_HIRES,
    'DBFL_XCONN': DBFL_XCONN,
    'DBFL_UNEXPECTED': DBFL_UNEXPECTED,
    'DBFL_INTERNAL': DBFL_INTERNAL,
    'DBFL_CURRENT_SOURCE': DBFL_CURRENT_SOURCE,
    'DBFL_SUPPLY': DBFL_SUPPLY,
    'DBFL_LOW_SIDE_SWITCH': DBFL_LOW_SIDE_SWITCH,
    'DBFL_HIGH_SIDE_SWITCH': DBFL_HIGH_SIDE_SWITCH,
    'DBFL_GROUND_LOSS': DBFL_GROUND_LOSS,
    'DBFL_CSR_XCONN': DBFL_CSR_XCONN,
    'DBFL_PDC_ABORT_INT': DBFL_PDC_ABORT_INT,
    'DBFL_PDC_ABORT_EXT': DBFL_PDC_ABORT_EXT,
    'DBFL_DWELL': DBFL_DWELL,
    'PBFL_OPEN': PBFL_OPEN,
    'PBFL_S2G': PBFL_S2G,
    'PBFL_S2B': PBFL_S2B,
    'PBFL_LORES': PBFL_LORES,
    'PBFL_HIRES': PBFL_HIRES,
    'PBFL_XCONN': PBFL_XCONN,
    'PBFL_UNEXPECTED': PBFL_UNEXPECTED,
    'PBFL_INTERNAL': PBFL_INTERNAL,
    'PBFL_CURRENT_SOURCE': PBFL_CURRENT_SOURCE,
    'PBFL_SUPPLY': PBFL_SUPPLY,
    'PBFL_LOW_SIDE_SWITCH': PBFL_LOW_SIDE_SWITCH,
    'PBFL_HIGH_SIDE_SWITCH': PBFL_HIGH_SIDE_SWITCH,
    'PBFL_GROUND_LOSS': PBFL_GROUND_LOSS,
    'PBFL_CSR_XCONN': PBFL_CSR_XCONN,
    'PBFL_PDC_ABORT_INT': PBFL_PDC_ABORT_INT,
    'PBFL_PDC_ABORT_EXT': PBFL_PDC_ABORT_EXT,
    'PBFL_DWELL': PBFL_DWELL,
    'HVBD_INTERNAL': HVBD_INTERNAL,
    'HVBD_CURRENT_SOURCE': HVBD_CURRENT_SOURCE,
    'HVBD_SUPPLY': HVBD_SUPPLY,
    'HVBD_LOW_SIDE_SWITCH': HVBD_LOW_SIDE_SWITCH,
    'HVBD_HIGH_SIDE_SWITCH': HVBD_HIGH_SIDE_SWITCH,
    'HVBD_GROUND_LOSS': HVBD_GROUND_LOSS,
    'HVBD_CSR_XCONN': HVBD_CSR_XCONN,
    'HVBD_PDC_ABORT_INT': HVBD_PDC_ABORT_INT,
    'HVBD_PDC_ABORT_EXT': HVBD_PDC_ABORT_EXT,
    'HVBD_DWELL': HVBD_DWELL,
    'PPC_INTERNAL': PPC_INTERNAL,
    'PPC_CURRENT_SOURCE': PPC_CURRENT_SOURCE,
    'PPC_SUPPLY': PPC_SUPPLY,
    'PPC_LOW_SIDE_SWITCH': PPC_LOW_SIDE_SWITCH,
    'PPC_HIGH_SIDE_SWITCH': PPC_HIGH_SIDE_SWITCH,
    'PPC_GROUND_LOSS': PPC_GROUND_LOSS,
    'PPC_CSR_XCONN': PPC_CSR_XCONN,
    'PPC_PDC_ABORT_INT': PPC_PDC_ABORT_INT,
    'PPC_PDC_ABORT_EXT': PPC_PDC_ABORT_EXT,
    'PPC_DWELL': PPC_DWELL,
    'DPC_INTERNAL': DPC_INTERNAL,
    'DPC_CURRENT_SOURCE': DPC_CURRENT_SOURCE,
    'DPC_SUPPLY': DPC_SUPPLY,
    'DPC_LOW_SIDE_SWITCH': DPC_LOW_SIDE_SWITCH,
    'DPC_HIGH_SIDE_SWITCH': DPC_HIGH_SIDE_SWITCH,
    'DPC_GROUND_LOSS': DPC_GROUND_LOSS,
    'DPC_CSR_XCONN': DPC_CSR_XCONN,
    'DPC_PDC_ABORT_INT': DPC_PDC_ABORT_INT,
    'DPC_PDC_ABORT_EXT': DPC_PDC_ABORT_EXT,
    'DPC_DWELL': DPC_DWELL,
    'LINE24_S2G': LINE24_S2G,
    'LINE25_S2G': LINE25_S2G,
    'LINE26_S2G': LINE26_S2G,
    'LINE27_S2G': LINE27_S2G,
    'LINE28_S2G': LINE28_S2G,
    'LINE29_S2G': LINE29_S2G,
    'LINE30_S2G': LINE30_S2G,
    'LINE31_S2G': LINE31_S2G,
    'LOOP0_CURRENT_MONITOR': LOOP0_CURRENT_MONITOR,
    'LOOP1_CURRENT_MONITOR': LOOP1_CURRENT_MONITOR,
    'LOOP2_CURRENT_MONITOR': LOOP2_CURRENT_MONITOR,
    'LOOP3_CURRENT_MONITOR': LOOP3_CURRENT_MONITOR,
    'LOOP_ASIC0_VRCM': LOOP_ASIC0_VRCM,
    'LOOP_ASIC1_VRCM': LOOP_ASIC1_VRCM,
    'LOOP_ASIC2_VRCM': LOOP_ASIC2_VRCM,
    'LOOP_ASIC0_LOCKING': LOOP_ASIC0_LOCKING,
    'LOOP_ASIC1_LOCKING': LOOP_ASIC1_LOCKING,
    'LOOP_ASIC2_LOCKING': LOOP_ASIC2_LOCKING,
    'LOOP_ASIC0_CONFIG': LOOP_ASIC0_CONFIG,
    'LOOP_ASIC1_CONFIG': LOOP_ASIC1_CONFIG,
    'LOOP_ASIC2_CONFIG': LOOP_ASIC2_CONFIG,
    'LOOP_ASIC0_DEPLOY_COMMAND': LOOP_ASIC0_DEPLOY_COMMAND,
    'LOOP_ASIC1_DEPLOY_COMMAND': LOOP_ASIC1_DEPLOY_COMMAND,
    'LOOP_ASIC2_DEPLOY_COMMAND': LOOP_ASIC2_DEPLOY_COMMAND,
    'LOOP_ASIC0_DEPLOY_COMPARE': LOOP_ASIC0_DEPLOY_COMPARE,
    'LOOP_ASIC1_DEPLOY_COMPARE': LOOP_ASIC1_DEPLOY_COMPARE,
    'LOOP_ASIC2_DEPLOY_COMPARE': LOOP_ASIC2_DEPLOY_COMPARE,
}


# ====================================================================================================
# General purpose outputs (32)
# <output>_<fault>: PAB_OFF (driver 0, passenger airbag OFF lamp), PAB_ON (driver 1, PAB ON lamp),
# ENS (driver 2, crash output) and ECALL (driver 3, E-Call output; not in gpo_config).
# ====================================================================================================
PAB_OFF_S2G = {'dtc': '0x92 0x10 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'GPO_F_SHORT_GND_0', 'req': 36068901,
               'text': 'GPO Driver 0 short to ground (FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_SHORT_TO_GND)'}
PAB_OFF_S2B = {'dtc': '0x92 0x10 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'GPO_F_SHORT_BAT_0', 'req': 36073723,
               'text': 'GPO Driver 0 short to battery (FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_SHORT_TO_BAT)'}
PAB_OFF_OPEN = {'dtc': '0x92 0x10 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'GPO_F_OPEN_0', 'req': 36068910,
                'text': 'GPO Driver 0 open circuit (FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_OPEN)'}
PAB_OFF_CONFIG = {'dtc': '0x92 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_0',
                  'req': 36068915,
                  'text': ('GPO Driver 0 configuration missmatch '
                           '(FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_CONFIGURATION_ERROR)')}
PAB_OFF_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                              '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                   'latched': True, 'monitor': 'GPO_F_THERMAL_0', 'req': 36068920,
                   'text': 'GPO Driver 0 over temperature (FLTMONR_E_ECU_INTERNAL)'}
PAB_OFF_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                               '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                    'latched': False, 'monitor': 'GPO_F_INTERNAL_0', 'req': 36068925,
                    'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                             'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to change '
                             'the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
PAB_OFF_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_0',
               'req': 36068930, 'text': 'GPO Driver 0 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
PAB_OFF_UNEXPECTED = {'dtc': '0x92 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_0', 'req': 36068935,
                      'text': ('GPO Driver 0 configuration missmatch '
                               '(FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_CONFIGURATION_ERROR)')}
PAB_ON_S2G = {'dtc': '0x90 0x24 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'GPO_F_SHORT_GND_1', 'req': 36068902,
              'text': 'GPO Driver 1 short to ground (FLTMONR_GPO_E_PAB_ON_LED_LINE_SHORT_TO_GND)'}
PAB_ON_S2B = {'dtc': '0x90 0x24 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'GPO_F_SHORT_BAT_1', 'req': 36068906,
              'text': 'GPO Driver 1 short to battery (FLTMONR_GPO_E_PAB_ON_LED_LINE_SHORT_TO_BAT)'}
PAB_ON_OPEN = {'dtc': '0x90 0x24 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'GPO_F_OPEN_1', 'req': 36068911,
               'text': 'GPO Driver 1 open circuit (FLTMONR_GPO_E_PAB_ON_LED_LINE_OPEN)'}
PAB_ON_CONFIG = {'dtc': '0x90 0x24 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_1',
                 'req': 36068916,
                 'text': 'GPO Driver 1 configuration missmatch (FLTMONR_GPO_E_PAB_ON_LED_LINE_CONFIGURATION_ERROR)'}
PAB_ON_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                             '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                  'latched': True, 'monitor': 'GPO_F_THERMAL_1', 'req': 36068921,
                  'text': 'GPO Driver 1 over temperature (FLTMONR_E_ECU_INTERNAL)'}
PAB_ON_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                              '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                   'latched': False, 'monitor': 'GPO_F_INTERNAL_1', 'req': 36068926,
                   'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                            'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to change '
                            'the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
PAB_ON_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_1',
              'req': 36068931, 'text': 'GPO Driver 1 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
PAB_ON_UNEXPECTED = {'dtc': '0x90 0x24 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_1', 'req': 36068936,
                     'text': ('GPO Driver 1 configuration missmatch '
                              '(FLTMONR_GPO_E_PAB_ON_LED_LINE_CONFIGURATION_ERROR)')}
ENS_S2G = {'dtc': '0x92 0x18 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'GPO_F_SHORT_GND_2', 'req': 36068903,
           'text': 'GPO Driver 2 short to ground (FLTMONR_GPO_CRASH_OUTPUT_E_SHORT_TO_GND)'}
ENS_S2B = {'dtc': '0x92 0x18 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'GPO_F_SHORT_BAT_2', 'req': 36068907,
           'text': 'GPO Driver 2 short to battery (FLTMONR_GPO_CRASH_OUTPUT_E_SHORT_TO_BAT)'}
ENS_OPEN = {'dtc': '0x92 0x18 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'GPO_F_OPEN_2', 'req': 36068912,
            'text': 'GPO Driver 2 open circuit (FLTMONR_GPO_CRASH_OUTPUT_E_OPEN)'}
ENS_CONFIG = {'dtc': '0x92 0x18 0x64', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_2',
              'req': 36068917,
              'text': 'GPO Driver 2 configuration missmatch (FLTMONR_GPO_CRASH_OUTPUT_E_CONFIGURATION_ERROR)'}
ENS_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                          '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
               'latched': True, 'monitor': 'GPO_F_THERMAL_2', 'req': 36068922,
               'text': 'GPO Driver 2 over temperature (FLTMONR_E_ECU_INTERNAL)'}
ENS_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                           '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                'latched': False, 'monitor': 'GPO_F_INTERNAL_2', 'req': 36068927,
                'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations during '
                         'AND/ORED Bits acquisition and process) and GPO Control Error(unable to change the duty '
                         'cycle) (FLTMONR_E_ECU_INTERNAL)')}
ENS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
           'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_2',
           'req': 36068932, 'text': 'GPO Driver 2 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
ENS_UNEXPECTED = {'dtc': '0x92 0x18 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_2', 'req': 36068937,
                  'text': 'GPO Driver 2 configuration missmatch (FLTMONR_GPO_CRASH_OUTPUT_E_CONFIGURATION_ERROR)'}
ECALL_S2G = {'dtc': '0x99 0x0E 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'GPO_F_SHORT_GND_3', 'req': 36068904,
             'text': 'GPO Driver 3 short to ground (FLTMONR_GPO_ECALL_E_SHORT_TO_GND)'}
ECALL_S2B = {'dtc': '0x99 0x0E 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'GPO_F_SHORT_BAT_3', 'req': 36068908,
             'text': 'GPO Driver 3 short to battery (FLTMONR_GPO_ECALL_E_SHORT_TO_BAT)'}
ECALL_OPEN = {'dtc': '0x99 0x0E 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'GPO_F_OPEN_3', 'req': 36068913,
              'text': 'GPO Driver 3 open circuit (FLTMONR_GPO_ECALL_E_OPEN)'}
ECALL_CONFIG = {'dtc': '0x99 0x0E 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_3',
                'req': 36068918,
                'text': 'GPO Driver 3 configuration missmatch (FLTMONR_GPO_ECALL_E_CONFIGURATION_ERROR)'}
ECALL_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                            '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                 'latched': True, 'monitor': 'GPO_F_THERMAL_3', 'req': 36068923,
                 'text': 'GPO Driver 3 over temperature (FLTMONR_E_ECU_INTERNAL)'}
ECALL_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                             '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                  'latched': False, 'monitor': 'GPO_F_INTERNAL_3', 'req': 36068928,
                  'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                           'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to change '
                           'the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
ECALL_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_3',
             'req': 36068933, 'text': 'GPO Driver 3 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
ECALL_UNEXPECTED = {'dtc': '0x99 0x0E 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                               'Within PDC(2 sec)'),
                    'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_3', 'req': 36068938,
                    'text': 'GPO Load Unexpected Load EX3_0 CH3 (FLTMONR_GPO_ECALL_E_CONFIGURATION_ERROR)'}

GPO_FAULTS = {
    'PAB_OFF_S2G': PAB_OFF_S2G,
    'PAB_OFF_S2B': PAB_OFF_S2B,
    'PAB_OFF_OPEN': PAB_OFF_OPEN,
    'PAB_OFF_CONFIG': PAB_OFF_CONFIG,
    'PAB_OFF_THERMAL': PAB_OFF_THERMAL,
    'PAB_OFF_INTERNAL': PAB_OFF_INTERNAL,
    'PAB_OFF_SPI': PAB_OFF_SPI,
    'PAB_OFF_UNEXPECTED': PAB_OFF_UNEXPECTED,
    'PAB_ON_S2G': PAB_ON_S2G,
    'PAB_ON_S2B': PAB_ON_S2B,
    'PAB_ON_OPEN': PAB_ON_OPEN,
    'PAB_ON_CONFIG': PAB_ON_CONFIG,
    'PAB_ON_THERMAL': PAB_ON_THERMAL,
    'PAB_ON_INTERNAL': PAB_ON_INTERNAL,
    'PAB_ON_SPI': PAB_ON_SPI,
    'PAB_ON_UNEXPECTED': PAB_ON_UNEXPECTED,
    'ENS_S2G': ENS_S2G,
    'ENS_S2B': ENS_S2B,
    'ENS_OPEN': ENS_OPEN,
    'ENS_CONFIG': ENS_CONFIG,
    'ENS_THERMAL': ENS_THERMAL,
    'ENS_INTERNAL': ENS_INTERNAL,
    'ENS_SPI': ENS_SPI,
    'ENS_UNEXPECTED': ENS_UNEXPECTED,
    'ECALL_S2G': ECALL_S2G,
    'ECALL_S2B': ECALL_S2B,
    'ECALL_OPEN': ECALL_OPEN,
    'ECALL_CONFIG': ECALL_CONFIG,
    'ECALL_THERMAL': ECALL_THERMAL,
    'ECALL_INTERNAL': ECALL_INTERNAL,
    'ECALL_SPI': ECALL_SPI,
    'ECALL_UNEXPECTED': ECALL_UNEXPECTED,
}


# ====================================================================================================
# Belt buckles, seat track sensors and ODS (DCS channels) (72)
# <seat>_<fault>: DRV / PSGR = front seats, R2L / R2M / R2R = second row left / middle / right, R3L
# / R3R = third row; BELT = buckle switch, STPS1/2 = seat track position switch, ODS = occupant
# switch; ASIC = sensor ASIC failure. DCS16 is the unassigned sensor 16.
# ====================================================================================================
R2R_BELT_S2B = {'dtc': '0x92 0x43 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_0', 'req': 36069087,
                'text': 'DCS Sensor 0 short to battery (FLTMONR_DCS_E_SECOND_ROW_RIGHT_BUCKLE_SWITCH_LEAK_TO_PLUS)'}
R2R_BELT_XCONN = {'dtc': '0x92 0x55 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_0', 'req': 36068976,
                  'text': ('DCS Sensor 0 cross connected '
                           '(FLTMONR_DCS_E_SECOND_ROW_RIGHT_BUCKLE_SWITCH_CROSS_CONNECT)')}
R2R_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_0', 'req': 36069107,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R2R_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_0', 'req': 36069129,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
DRV_BELT_S2B = {'dtc': '0x90 0x33 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_1', 'req': 36069088,
                'text': 'DCS Sensor 1 short to battery (FLTMONR_DCS_E_DRIVER_SEAT_BELT_LEAK_TO_PLUS)'}
DRV_BELT_XCONN = {'dtc': '0x92 0x53 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_1', 'req': 36068977,
                  'text': ('DCS Sensor 1 cross connected '
                           '(FLTMONR_DCS_E_DRIVER_SEAT_BELT_BUCKLE_SWITCH_CROSS_CONNECT)')}
DRV_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_1', 'req': 36069108,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
DRV_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_1', 'req': 36069130,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
PSGR_BELT_S2B = {'dtc': '0x90 0x32 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                 'monitor': 'DCS_F_SHORT_PLUS_2', 'req': 36069089,
                 'text': 'DCS Sensor 2 short to battery (FLTMONR_DCS_E_PASSENGER_SEAT_BELT_LEAK_TO_PLUS)'}
PSGR_BELT_XCONN = {'dtc': '0x92 0x54 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                   'monitor': 'DCS_F_CROSS_CONNECT_2', 'req': 36068978,
                   'text': ('DCS Sensor 2 cross connected '
                            '(FLTMONR_DCS_E_PASSENGER_SEAT_BELT_BUCKLE_SWITCH_CROSS_CONNECT)')}
PSGR_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_INTERNAL_2', 'req': 36069109,
                  'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
PSGR_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_SPI_2', 'req': 36069131,
                 'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R2L_BELT_S2B = {'dtc': '0x92 0x42 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_3', 'req': 36069090,
                'text': 'DCS Sensor 3 short to battery (FLTMONR_DCS_E_SECOND_ROW_LEFT_BUCKLE_SWITCH_LEAK_TO_PLUS)'}
R2L_BELT_XCONN = {'dtc': '0x92 0x57 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_3', 'req': 36068979,
                  'text': ('DCS Sensor 3 cross connected '
                           '(FLTMONR_DCS_E_SECOND_ROW_LEFT_BUCKLE_SWITCH_CROSS_CONNECT)')}
R2L_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_3', 'req': 36069110,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R2L_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_3', 'req': 36069132,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R2M_BELT_S2B = {'dtc': '0x92 0x44 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_4', 'req': 36069091,
                'text': ('DCS Sensor 4 short to battery '
                         '(FLTMONR_DCS_E_SECOND_ROW_MIDDLE_BUCKLE_SWITCH_LEAK_TO_PLUS)')}
R2M_BELT_XCONN = {'dtc': '0x92 0x56 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_4', 'req': 36068980,
                  'text': ('DCS Sensor 4 cross connected '
                           '(FLTMONR_DCS_E_SECOND_ROW_MIDDLE_BUCKLE_SWITCH_CROSS_CONNECT)')}
R2M_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_4', 'req': 36069111,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R2M_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_4', 'req': 36069133,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
DRV_STPS1_S2B = {'dtc': '0x98 0xF9 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                 'monitor': 'DCS_F_SHORT_PLUS_5', 'req': 36069092,
                 'text': 'DCS Sensor 5 short to battery (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_LEAK_TO_PLUS)'}
DRV_STPS1_S2G = {'dtc': '0x98 0xF9 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                 'monitor': 'DCS_F_SHORT_GND_5', 'req': 36069077,
                 'text': 'DCS Sensor 5 short to ground (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_LEAK_TO_GND)'}
DRV_STPS1_OPEN = {'dtc': '0x98 0xF9 0x13', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_OPEN_5', 'req': 36069062,
                  'text': 'DCS Sensor 5 open circuit (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_OPEN)'}
DRV_STPS1_XCONN = {'dtc': '0x98 0xF9 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                   'monitor': 'DCS_F_CROSS_CONNECT_5', 'req': 36068981,
                   'text': 'DCS Sensor 5 cross connected (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_CROSS_CONNECTED)'}
DRV_STPS1_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                   'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                        'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_5', 'req': 36073729,
                        'text': ('DCS Sensor 5 wrong configuration '
                                 '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
DRV_STPS1_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_INTERNAL_5', 'req': 36069112,
                  'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
DRV_STPS1_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_SPI_5', 'req': 36069134,
                 'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
DRV_STPS2_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                   'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                        'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_6', 'req': 36073730,
                        'text': ('DCS Sensor 6 wrong configuration '
                                 '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
DRV_STPS2_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_INTERNAL_6', 'req': 36069113,
                  'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
DRV_STPS2_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_SPI_6', 'req': 36069135,
                 'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
PSGR_STPS1_S2B = {'dtc': '0x98 0xFB 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_7', 'req': 36069093,
                  'text': 'DCS Sensor 7 short to battery (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_LEAK_TO_PLUS)'}
PSGR_STPS1_S2G = {'dtc': '0x98 0xFB 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_GND_7', 'req': 36069078,
                  'text': 'DCS Sensor 7 short to ground (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_LEAK_TO_GND)'}
PSGR_STPS1_OPEN = {'dtc': '0x98 0xFB 0x13', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_OPEN_7', 'req': 36069063,
                   'text': 'DCS Sensor 7 open circuit (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_OPEN)'}
PSGR_STPS1_XCONN = {'dtc': '0x98 0xFB 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_7', 'req': 36068982,
                    'text': 'DCS Sensor 7 cross connected (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_CROSS_CONNECTED)'}
PSGR_STPS1_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                    'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                         'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_7', 'req': 36073731,
                         'text': ('DCS Sensor 7 wrong configuration '
                                  '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
PSGR_STPS1_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_7', 'req': 36069114,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
PSGR_STPS1_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_7', 'req': 36069136,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
PSGR_STPS2_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                    'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                         'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_8', 'req': 36073732,
                         'text': ('DCS Sensor 8 wrong configuration '
                                  '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
PSGR_STPS2_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_8', 'req': 36069115,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
PSGR_STPS2_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_8', 'req': 36069137,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R2R_ODS_S2B = {'dtc': '0x98 0xF5 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
               'monitor': 'DCS_F_SHORT_PLUS_9', 'req': 36069094,
               'text': 'DCS Sensor 9 short to battery (FLTMONR_DCS_E_SECOND_ROW_RIGHT_ODS_SWITCH_LEAK_TO_PLUS)'}
R2R_ODS_XCONN = {'dtc': '0x98 0xF5 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                 'monitor': 'DCS_F_CROSS_CONNECT_9', 'req': 36068983,
                 'text': 'DCS Sensor 9 cross connected (FLTMONR_DCS_E_SECOND_ROW_RIGHT_ODS_SWITCH_CROSS_CONNECT)'}
R2R_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_INTERNAL_9', 'req': 36069116,
                'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R2R_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
               'monitor': 'DCS_F_SPI_9', 'req': 36069138,
               'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R2L_ODS_S2B = {'dtc': '0x98 0xF4 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
               'monitor': 'DCS_F_SHORT_PLUS_10', 'req': 36069095,
               'text': 'DCS Sensor 10 short to battery (FLTMONR_DCS_E_SECOND_ROW_LEFT_ODS_SWITCH_LEAK_TO_PLUS)'}
R2L_ODS_XCONN = {'dtc': '0x98 0xF4 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                 'monitor': 'DCS_F_CROSS_CONNECT_10', 'req': 36068984,
                 'text': 'DCS Sensor 10 cross connected (FLTMONR_DCS_E_SECOND_ROW_LEFT_ODS_SWITCH_CROSS_CONNECT)'}
R2L_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_INTERNAL_10', 'req': 36069117,
                'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R2L_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
               'monitor': 'DCS_F_SPI_10', 'req': 36069139,
               'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R2M_ODS_S2B = {'dtc': '0x98 0xF6 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
               'monitor': 'DCS_F_SHORT_PLUS_11', 'req': 36069096,
               'text': 'DCS Sensor 11 short to battery (FLTMONR_DCS_E_SECOND_ROW_MIDDLE_ODS_SWITCH_LEAK_TO_PLUS)'}
R2M_ODS_XCONN = {'dtc': '0x98 0xF6 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                 'monitor': 'DCS_F_CROSS_CONNECT_11', 'req': 36068985,
                 'text': 'DCS Sensor 11 cross connected (FLTMONR_DCS_E_SECOND_ROW_MIDDLE_ODS_SWITCH_CROSS_CONNECT)'}
R2M_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_INTERNAL_11', 'req': 36069118,
                'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R2M_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
               'monitor': 'DCS_F_SPI_11', 'req': 36069140,
               'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R3R_BELT_S2B = {'dtc': '0x92 0x46 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_12', 'req': 36069097,
                'text': 'DCS Sensor 12 short to battery (FLTMONR_DCS_E_THIRD_ROW_RIGHT_BUCKLE_SWITCH_LEAK_TO_PLUS)'}
R3R_BELT_XCONN = {'dtc': '0x92 0x58 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_12', 'req': 36068986,
                  'text': ('DCS Sensor 12 cross connected '
                           '(FLTMONR_DCS_E_THIRD_ROW_RIGHT_BUCKLE_SWITCH_CROSS_CONNECT)')}
R3R_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_12', 'req': 36069119,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R3R_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_12', 'req': 36069141,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R3L_BELT_S2B = {'dtc': '0x92 0x45 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_13', 'req': 36069098,
                'text': 'DCS Sensor 13 short to battery (FLTMONR_DCS_E_THIRD_ROW_LEFT_BUCKLE_SWITCH_LEAK_TO_PLUS)'}
R3L_BELT_XCONN = {'dtc': '0x92 0x59 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_13', 'req': 36068987,
                  'text': ('DCS Sensor 13 cross connected '
                           '(FLTMONR_DCS_E_THIRD_ROW_LEFT_BUCKLE_SWITCH_CROSS_CONNECT)')}
R3L_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_13', 'req': 36069120,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R3L_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_13', 'req': 36069142,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R3R_ODS_S2B = {'dtc': '0x98 0xF8 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
               'monitor': 'DCS_F_SHORT_PLUS_14', 'req': 36069099,
               'text': 'DCS Sensor 14 short to battery (FLTMONR_DCS_E_THIRD_ROW_RIGHT_ODS_SWITCH_LEAK_TO_PLUS)'}
R3R_ODS_XCONN = {'dtc': '0x98 0xF8 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                 'monitor': 'DCS_F_CROSS_CONNECT_14', 'req': 36068988,
                 'text': 'DCS Sensor 14 cross connected (FLTMONR_DCS_E_THIRD_ROW_RIGHT_ODS_SWITCH_CROSS_CONNECT)'}
R3R_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_INTERNAL_14', 'req': 36069121,
                'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R3R_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
               'monitor': 'DCS_F_SPI_14', 'req': 36069143,
               'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
R3L_ODS_S2B = {'dtc': '0x98 0xF7 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
               'monitor': 'DCS_F_SHORT_PLUS_15', 'req': 36069100,
               'text': 'DCS Sensor 15 short to battery (FLTMONR_DCS_E_THIRD_ROW_LEFT_ODS_SWITCH_LEAK_TO_PLUS)'}
R3L_ODS_XCONN = {'dtc': '0x98 0xF7 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                 'monitor': 'DCS_F_CROSS_CONNECT_15', 'req': 36068989,
                 'text': 'DCS Sensor 15 cross connected (FLTMONR_DCS_E_THIRD_ROW_LEFT_ODS_SWITCH_CROSS_CONNECT)'}
R3L_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_INTERNAL_15', 'req': 36069122,
                'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
R3L_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
               'monitor': 'DCS_F_SPI_15', 'req': 36069144,
               'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
DCS16_S2B = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
             'monitor': 'DCS_F_SHORT_PLUS_16', 'req': 36069101,
             'text': 'DCS Sensor 16 short to battery (FLTMONR_E_ECU_INTERNAL)'}
DCS16_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
               'monitor': 'DCS_F_CROSS_CONNECT_16', 'req': 36068990,
               'text': 'DCS Sensor 16 cross connected (FLTMONR_E_ECU_INTERNAL)'}
DCS16_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
              'monitor': 'DCS_F_INTERNAL_16', 'req': 36069123,
              'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
DCS16_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
             'monitor': 'DCS_F_SPI_16', 'req': 36069145, 'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}

DCS_FAULTS = {
    'R2R_BELT_S2B': R2R_BELT_S2B,
    'R2R_BELT_XCONN': R2R_BELT_XCONN,
    'R2R_BELT_ASIC': R2R_BELT_ASIC,
    'R2R_BELT_SPI': R2R_BELT_SPI,
    'DRV_BELT_S2B': DRV_BELT_S2B,
    'DRV_BELT_XCONN': DRV_BELT_XCONN,
    'DRV_BELT_ASIC': DRV_BELT_ASIC,
    'DRV_BELT_SPI': DRV_BELT_SPI,
    'PSGR_BELT_S2B': PSGR_BELT_S2B,
    'PSGR_BELT_XCONN': PSGR_BELT_XCONN,
    'PSGR_BELT_ASIC': PSGR_BELT_ASIC,
    'PSGR_BELT_SPI': PSGR_BELT_SPI,
    'R2L_BELT_S2B': R2L_BELT_S2B,
    'R2L_BELT_XCONN': R2L_BELT_XCONN,
    'R2L_BELT_ASIC': R2L_BELT_ASIC,
    'R2L_BELT_SPI': R2L_BELT_SPI,
    'R2M_BELT_S2B': R2M_BELT_S2B,
    'R2M_BELT_XCONN': R2M_BELT_XCONN,
    'R2M_BELT_ASIC': R2M_BELT_ASIC,
    'R2M_BELT_SPI': R2M_BELT_SPI,
    'DRV_STPS1_S2B': DRV_STPS1_S2B,
    'DRV_STPS1_S2G': DRV_STPS1_S2G,
    'DRV_STPS1_OPEN': DRV_STPS1_OPEN,
    'DRV_STPS1_XCONN': DRV_STPS1_XCONN,
    'DRV_STPS1_UNEXPECTED': DRV_STPS1_UNEXPECTED,
    'DRV_STPS1_ASIC': DRV_STPS1_ASIC,
    'DRV_STPS1_SPI': DRV_STPS1_SPI,
    'DRV_STPS2_UNEXPECTED': DRV_STPS2_UNEXPECTED,
    'DRV_STPS2_ASIC': DRV_STPS2_ASIC,
    'DRV_STPS2_SPI': DRV_STPS2_SPI,
    'PSGR_STPS1_S2B': PSGR_STPS1_S2B,
    'PSGR_STPS1_S2G': PSGR_STPS1_S2G,
    'PSGR_STPS1_OPEN': PSGR_STPS1_OPEN,
    'PSGR_STPS1_XCONN': PSGR_STPS1_XCONN,
    'PSGR_STPS1_UNEXPECTED': PSGR_STPS1_UNEXPECTED,
    'PSGR_STPS1_ASIC': PSGR_STPS1_ASIC,
    'PSGR_STPS1_SPI': PSGR_STPS1_SPI,
    'PSGR_STPS2_UNEXPECTED': PSGR_STPS2_UNEXPECTED,
    'PSGR_STPS2_ASIC': PSGR_STPS2_ASIC,
    'PSGR_STPS2_SPI': PSGR_STPS2_SPI,
    'R2R_ODS_S2B': R2R_ODS_S2B,
    'R2R_ODS_XCONN': R2R_ODS_XCONN,
    'R2R_ODS_ASIC': R2R_ODS_ASIC,
    'R2R_ODS_SPI': R2R_ODS_SPI,
    'R2L_ODS_S2B': R2L_ODS_S2B,
    'R2L_ODS_XCONN': R2L_ODS_XCONN,
    'R2L_ODS_ASIC': R2L_ODS_ASIC,
    'R2L_ODS_SPI': R2L_ODS_SPI,
    'R2M_ODS_S2B': R2M_ODS_S2B,
    'R2M_ODS_XCONN': R2M_ODS_XCONN,
    'R2M_ODS_ASIC': R2M_ODS_ASIC,
    'R2M_ODS_SPI': R2M_ODS_SPI,
    'R3R_BELT_S2B': R3R_BELT_S2B,
    'R3R_BELT_XCONN': R3R_BELT_XCONN,
    'R3R_BELT_ASIC': R3R_BELT_ASIC,
    'R3R_BELT_SPI': R3R_BELT_SPI,
    'R3L_BELT_S2B': R3L_BELT_S2B,
    'R3L_BELT_XCONN': R3L_BELT_XCONN,
    'R3L_BELT_ASIC': R3L_BELT_ASIC,
    'R3L_BELT_SPI': R3L_BELT_SPI,
    'R3R_ODS_S2B': R3R_ODS_S2B,
    'R3R_ODS_XCONN': R3R_ODS_XCONN,
    'R3R_ODS_ASIC': R3R_ODS_ASIC,
    'R3R_ODS_SPI': R3R_ODS_SPI,
    'R3L_ODS_S2B': R3L_ODS_S2B,
    'R3L_ODS_XCONN': R3L_ODS_XCONN,
    'R3L_ODS_ASIC': R3L_ODS_ASIC,
    'R3L_ODS_SPI': R3L_ODS_SPI,
    'DCS16_S2B': DCS16_S2B,
    'DCS16_XCONN': DCS16_XCONN,
    'DCS16_ASIC': DCS16_ASIC,
    'DCS16_SPI': DCS16_SPI,
}


# ====================================================================================================
# Remote sensing units (217)
# <satellite>_S<slot>_<fault>, the satellite named as rsu_config names its side and pillar (right-
# hand drive: driver = right), S1/S2/S3 its sensor slot on the ASIC channel; RSU_CHANNEL<n>_* are
# per ASIC channel; OPS_RSU_* are algorithm checks of RSU line <n>.
# ====================================================================================================
A_PILLAR_LEFT_S1_OPEN = {'dtc': '0x92 0x36 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_0', 'req': 36069932,
                         'text': ('RSU Open Circuit on Sensor 0 SB3_M CH0 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_OPEN)')}
A_PILLAR_LEFT_S1_S2G = {'dtc': '0x92 0x36 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_0', 'req': 36069980,
                        'text': ('RSU Short to Ground Sensor 0 SB3_M CH0 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_GND)')}
A_PILLAR_LEFT_S1_S2B = {'dtc': '0x92 0x36 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_0', 'req': 36070028,
                        'text': ('RSU Short to Battery Sensor 0 SB3_M CH0 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_BAT)')}
A_PILLAR_LEFT_S1_COMM = {'dtc': '0x92 0x36 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_0', 'req': 36069788,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH0 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_COMMUNICATION_ERROR)')}
A_PILLAR_LEFT_S1_INTERNAL = {'dtc': '0x92 0x36 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_0', 'req': 36069884,
                             'text': ('RSU Internal error Sensor 0 SB3_M CH0 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_INTERNAL_ERROR)')}
A_PILLAR_LEFT_S1_CONFIG = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_0', 'req': 36070076,
                           'text': ('RSU Configuration error Sensor 0 SB3_M CH0 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_LEFT_S1_UNEXPECTED = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_0', 'req': 36069836,
                               'text': ('RSU Configuration error Sensor 0 SB3_M CH0 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_LEFT_S2_OPEN = {'dtc': '0x92 0x36 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_1', 'req': 36069933,
                         'text': ('RSU Open Circuit on Sensor 1 SB3_M CH0 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_OPEN)')}
A_PILLAR_LEFT_S2_S2G = {'dtc': '0x92 0x36 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_1', 'req': 36069981,
                        'text': ('RSU Short to Ground Sensor 1 SB3_M CH0 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_GND)')}
A_PILLAR_LEFT_S2_S2B = {'dtc': '0x92 0x36 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_1', 'req': 36070029,
                        'text': ('RSU Short to Battery Sensor 1 SB3_M CH0 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_BAT)')}
A_PILLAR_LEFT_S2_COMM = {'dtc': '0x92 0x36 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_1', 'req': 36069789,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH0 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_COMMUNICATION_ERROR)')}
A_PILLAR_LEFT_S2_INTERNAL = {'dtc': '0x92 0x36 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_1', 'req': 36069885,
                             'text': ('RSU Internal error Sensor 1 SB3_M CH0 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_INTERNAL_ERROR)')}
A_PILLAR_LEFT_S2_CONFIG = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_1', 'req': 36070077,
                           'text': ('RSU Configuration error Sensor 1 SB3_M CH0 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_LEFT_S2_UNEXPECTED = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_1', 'req': 36069837,
                               'text': ('RSU Configuration error Sensor 1 SB3_M CH0 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_RIGHT_S1_OPEN = {'dtc': '0x92 0x37 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_4', 'req': 36069936,
                          'text': ('RSU Open Circuit on Sensor 4 SB3_M CH1 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_OPEN)')}
A_PILLAR_RIGHT_S1_S2G = {'dtc': '0x92 0x37 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_4', 'req': 36069984,
                         'text': ('RSU Short to Ground Sensor 4 SB3_M CH1 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_GND)')}
A_PILLAR_RIGHT_S1_S2B = {'dtc': '0x92 0x37 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_4', 'req': 36070032,
                         'text': ('RSU Short to Battery Sensor 4 SB3_M CH1 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_BAT)')}
A_PILLAR_RIGHT_S1_COMM = {'dtc': '0x92 0x37 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_4', 'req': 36069792,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH1 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_COMMUNICATION_ERROR)')}
A_PILLAR_RIGHT_S1_INTERNAL = {'dtc': '0x92 0x37 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_4', 'req': 36069888,
                              'text': ('RSU Internal error Sensor 4 SB3_M CH1 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_INTERNAL_ERROR)')}
A_PILLAR_RIGHT_S1_CONFIG = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_4', 'req': 36070080,
                            'text': ('RSU Configuration error Sensor 4 SB3_M CH1 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_RIGHT_S1_UNEXPECTED = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_4', 'req': 36069840,
                                'text': ('RSU Configuration error Sensor 4 SB3_M CH1 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_RIGHT_S2_OPEN = {'dtc': '0x92 0x37 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_5', 'req': 36069937,
                          'text': ('RSU Open Circuit on Sensor 5 SB3_M CH1 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_OPEN)')}
A_PILLAR_RIGHT_S2_S2G = {'dtc': '0x92 0x37 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_5', 'req': 36069985,
                         'text': ('RSU Short to Ground Sensor 5 SB3_M CH1 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_GND)')}
A_PILLAR_RIGHT_S2_S2B = {'dtc': '0x92 0x37 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_5', 'req': 36070033,
                         'text': ('RSU Short to Battery Sensor 5 SB3_M CH1 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_BAT)')}
A_PILLAR_RIGHT_S2_COMM = {'dtc': '0x92 0x37 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_5', 'req': 36069793,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH1 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_COMMUNICATION_ERROR)')}
A_PILLAR_RIGHT_S2_INTERNAL = {'dtc': '0x92 0x37 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_5', 'req': 36069889,
                              'text': ('RSU Internal error Sensor 5 SB3_M CH1 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_INTERNAL_ERROR)')}
A_PILLAR_RIGHT_S2_CONFIG = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_5', 'req': 36070081,
                            'text': ('RSU Configuration error Sensor 5 SB3_M CH1 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
A_PILLAR_RIGHT_S2_UNEXPECTED = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_5', 'req': 36069841,
                                'text': ('RSU Configuration error Sensor 5 SB3_M CH1 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_LEFT_S1_OPEN = {'dtc': '0x92 0x0A 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_8', 'req': 36069940,
                         'text': ('RSU Open Circuit on Sensor 8 SB3_M CH2 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_OPEN)')}
B_PILLAR_LEFT_S1_S2G = {'dtc': '0x92 0x0A 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_8', 'req': 36069988,
                        'text': ('RSU Short to Ground Sensor 8 SB3_M CH2 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_GND)')}
B_PILLAR_LEFT_S1_S2B = {'dtc': '0x92 0x0A 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_8', 'req': 36070036,
                        'text': ('RSU Short to Battery Sensor 8 SB3_M CH2 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_BAT)')}
B_PILLAR_LEFT_S1_COMM = {'dtc': '0x92 0x0A 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_8', 'req': 36069796,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH2 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_COMMUNICATION_ERROR)')}
B_PILLAR_LEFT_S1_INTERNAL = {'dtc': '0x92 0x0A 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_8', 'req': 36069892,
                             'text': ('RSU Internal error Sensor 8 SB3_M CH2 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_INTERNAL_ERROR)')}
B_PILLAR_LEFT_S1_CONFIG = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_8', 'req': 36070084,
                           'text': ('RSU Configuration error Sensor 8 SB3_M CH2 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_LEFT_S1_UNEXPECTED = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_8', 'req': 36069844,
                               'text': ('RSU Configuration error Sensor 8 SB3_M CH2 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_LEFT_S2_OPEN = {'dtc': '0x92 0x0A 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_9', 'req': 36069941,
                         'text': ('RSU Open Circuit on Sensor 9 SB3_M CH2 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_OPEN)')}
B_PILLAR_LEFT_S2_S2G = {'dtc': '0x92 0x0A 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_9', 'req': 36069989,
                        'text': ('RSU Short to Ground Sensor 9 SB3_M CH2 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_GND)')}
B_PILLAR_LEFT_S2_S2B = {'dtc': '0x92 0x0A 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_9', 'req': 36070037,
                        'text': ('RSU Short to Battery Sensor 9 SB3_M CH2 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_BAT)')}
B_PILLAR_LEFT_S2_COMM = {'dtc': '0x92 0x0A 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_9', 'req': 36069797,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH2 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_COMMUNICATION_ERROR)')}
B_PILLAR_LEFT_S2_INTERNAL = {'dtc': '0x92 0x0A 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_9', 'req': 36069893,
                             'text': ('RSU Internal error Sensor 9 SB3_M CH2 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_INTERNAL_ERROR)')}
B_PILLAR_LEFT_S2_CONFIG = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_9', 'req': 36070085,
                           'text': ('RSU Configuration error Sensor 9 SB3_M CH2 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_LEFT_S2_UNEXPECTED = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_9', 'req': 36069845,
                               'text': ('RSU Configuration error Sensor 9 SB3_M CH2 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_RIGHT_S1_OPEN = {'dtc': '0x92 0x0B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_12', 'req': 36069944,
                          'text': ('RSU Open Circuit on Sensor 12 SB3_M CH3 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_OPEN)')}
B_PILLAR_RIGHT_S1_S2G = {'dtc': '0x92 0x0B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_12', 'req': 36069992,
                         'text': ('RSU Short to Ground Sensor 12 SB3_M CH3 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_GND)')}
B_PILLAR_RIGHT_S1_S2B = {'dtc': '0x92 0x0B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_12', 'req': 36070040,
                         'text': ('RSU Short to Battery Sensor 12 SB3_M CH3 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_BAT)')}
B_PILLAR_RIGHT_S1_COMM = {'dtc': '0x92 0x0B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_12', 'req': 36069800,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH3 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_COMMUNICATION_ERROR)')}
B_PILLAR_RIGHT_S1_INTERNAL = {'dtc': '0x92 0x0B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_12', 'req': 36069896,
                              'text': ('RSU Internal error Sensor 12 SB3_M CH3 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_INTERNAL_ERROR)')}
B_PILLAR_RIGHT_S1_CONFIG = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_12', 'req': 36070088,
                            'text': ('RSU Configuration error Sensor 12 SB3_M CH3 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_RIGHT_S1_UNEXPECTED = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_12', 'req': 36069848,
                                'text': ('RSU Configuration error Sensor 12 SB3_M CH3 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_RIGHT_S2_OPEN = {'dtc': '0x92 0x0B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_13', 'req': 36069945,
                          'text': ('RSU Open Circuit on Sensor 13 SB3_M CH3 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_OPEN)')}
B_PILLAR_RIGHT_S2_S2G = {'dtc': '0x92 0x0B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_13', 'req': 36069993,
                         'text': ('RSU Short to Ground Sensor 13 SB3_M CH3 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_GND)')}
B_PILLAR_RIGHT_S2_S2B = {'dtc': '0x92 0x0B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_13', 'req': 36070041,
                         'text': ('RSU Short to Battery Sensor 13 SB3_M CH3 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_BAT)')}
B_PILLAR_RIGHT_S2_COMM = {'dtc': '0x92 0x0B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_13', 'req': 36069801,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH3 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_COMMUNICATION_ERROR)')}
B_PILLAR_RIGHT_S2_INTERNAL = {'dtc': '0x92 0x0B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_13', 'req': 36069897,
                              'text': ('RSU Internal error Sensor 13 SB3_M CH3 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_INTERNAL_ERROR)')}
B_PILLAR_RIGHT_S2_CONFIG = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_13', 'req': 36070089,
                            'text': ('RSU Configuration error Sensor 13 SB3_M CH3 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
B_PILLAR_RIGHT_S2_UNEXPECTED = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_13', 'req': 36069849,
                                'text': ('RSU Configuration error Sensor 13 SB3_M CH3 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
FRONT_LEFT_S1_OPEN = {'dtc': '0x80 0x90 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                      'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_OPEN_16', 'req': 36069948,
                      'text': ('RSU Open Circuit on Sensor 16 SB3_M CH4 S1 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_OPEN)')}
FRONT_LEFT_S1_S2G = {'dtc': '0x80 0x90 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                     'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_SHORT_GND_16', 'req': 36069996,
                     'text': ('RSU Short to Ground Sensor 16 SB3_M CH4 S1 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_GND)')}
FRONT_LEFT_S1_S2B = {'dtc': '0x80 0x90 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                     'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_SHORT_BAT_16', 'req': 36070044,
                     'text': ('RSU Short to Battery Sensor 16 SB3_M CH4 S1 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_BAT)')}
FRONT_LEFT_S1_COMM = {'dtc': '0x80 0x90 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_COMM_16', 'req': 36069804,
                      'text': ('Satellite Manchester Data Communication Fault SB3_M CH4 S1 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_COMMUNICATION_ERROR)')}
FRONT_LEFT_S1_INTERNAL = {'dtc': '0x80 0x90 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                          'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_16', 'req': 36069900,
                          'text': ('RSU Internal error Sensor 16 SB3_M CH4 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_INTERNAL_ERROR)')}
FRONT_LEFT_S1_CONFIG = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_CFG_16', 'req': 36070092,
                        'text': ('RSU Configuration error Sensor 16 SB3_M CH4 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FRONT_LEFT_S1_UNEXPECTED = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                       'Value: Within PDC(2 sec)'),
                            'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_16', 'req': 36069852,
                            'text': ('RSU Configuration error Sensor 16 SB3_M CH4 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FRONT_LEFT_S2_OPEN = {'dtc': '0x80 0x90 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                      'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_OPEN_17', 'req': 36069949,
                      'text': ('RSU Open Circuit on Sensor 17 SB3_M CH4 S2 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_OPEN)')}
FRONT_LEFT_S2_S2G = {'dtc': '0x80 0x90 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                     'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_SHORT_GND_17', 'req': 36069997,
                     'text': ('RSU Short to Ground Sensor 17 SB3_M CH4 S2 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_GND)')}
FRONT_LEFT_S2_S2B = {'dtc': '0x80 0x90 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                     'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_SHORT_BAT_17', 'req': 36070045,
                     'text': ('RSU Short to Battery Sensor 17 SB3_M CH4 S2 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_BAT)')}
FRONT_LEFT_S2_COMM = {'dtc': '0x80 0x90 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_COMM_17', 'req': 36069805,
                      'text': ('Satellite Manchester Data Communication Fault SB3_M CH4 S2 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_COMMUNICATION_ERROR)')}
FRONT_LEFT_S2_INTERNAL = {'dtc': '0x80 0x90 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                          'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_17', 'req': 36069901,
                          'text': ('RSU Internal error Sensor 17 SB3_M CH4 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_INTERNAL_ERROR)')}
FRONT_LEFT_S2_CONFIG = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_CFG_17', 'req': 36070093,
                        'text': ('RSU Configuration error Sensor 17 SB3_M CH4 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FRONT_LEFT_S2_UNEXPECTED = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                       'Value: Within PDC(2 sec)'),
                            'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_17', 'req': 36069853,
                            'text': ('RSU Configuration error Sensor 17 SB3_M CH4 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FRONT_RIGHT_S1_OPEN = {'dtc': '0x80 0x95 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                       'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_OPEN_20', 'req': 36069952,
                       'text': ('RSU Open Circuit on Sensor 20 SB3_M CH5 S1 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_OPEN)')}
FRONT_RIGHT_S1_S2G = {'dtc': '0x80 0x95 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                      'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_SHORT_GND_20', 'req': 36070000,
                      'text': ('RSU Short to Ground Sensor 20 SB3_M CH5 S1 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_GND)')}
FRONT_RIGHT_S1_S2B = {'dtc': '0x80 0x95 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                      'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_SHORT_BAT_20', 'req': 36070048,
                      'text': ('RSU Short to Battery Sensor 20 SB3_M CH5 S1 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_BAT)')}
FRONT_RIGHT_S1_COMM = {'dtc': '0x80 0x95 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_COMM_20', 'req': 36069808,
                       'text': ('Satellite Manchester Data Communication Fault SB3_M CH5 S1 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_COMMUNICATION_ERROR)')}
FRONT_RIGHT_S1_INTERNAL = {'dtc': '0x80 0x95 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                           'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_20', 'req': 36069904,
                           'text': ('RSU Internal error Sensor 20 SB3_M CH5 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_INTERNAL_ERROR)')}
FRONT_RIGHT_S1_CONFIG = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_CFG_20', 'req': 36070096,
                         'text': ('RSU Configuration error Sensor 20 SB3_M CH5 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FRONT_RIGHT_S1_UNEXPECTED = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                        'Value: Within PDC(2 sec)'),
                             'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_20', 'req': 36069856,
                             'text': ('RSU Configuration error Sensor 20 SB3_M CH5 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FRONT_RIGHT_S2_OPEN = {'dtc': '0x80 0x95 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                       'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_OPEN_21', 'req': 36069953,
                       'text': ('RSU Open Circuit on Sensor 21 SB3_M CH5 S2 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_OPEN)')}
FRONT_RIGHT_S2_S2G = {'dtc': '0x80 0x95 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                      'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_SHORT_GND_21', 'req': 36070001,
                      'text': ('RSU Short to Ground Sensor 21 SB3_M CH5 S2 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_GND)')}
FRONT_RIGHT_S2_S2B = {'dtc': '0x80 0x95 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                      'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                      'monitor': 'RSU_F_SAT_SHORT_BAT_21', 'req': 36070049,
                      'text': ('RSU Short to Battery Sensor 21 SB3_M CH5 S2 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_BAT)')}
FRONT_RIGHT_S2_COMM = {'dtc': '0x80 0x95 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_COMM_21', 'req': 36069809,
                       'text': ('Satellite Manchester Data Communication Fault SB3_M CH5 S2 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_COMMUNICATION_ERROR)')}
FRONT_RIGHT_S2_INTERNAL = {'dtc': '0x80 0x95 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                           'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_21', 'req': 36069905,
                           'text': ('RSU Internal error Sensor 21 SB3_M CH5 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_INTERNAL_ERROR)')}
FRONT_RIGHT_S2_CONFIG = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_CFG_21', 'req': 36070097,
                         'text': ('RSU Configuration error Sensor 21 SB3_M CH5 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FRONT_RIGHT_S2_UNEXPECTED = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                        'Value: Within PDC(2 sec)'),
                             'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_21', 'req': 36069857,
                             'text': ('RSU Configuration error Sensor 21 SB3_M CH5 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
C_PILLAR_LEFT_S1_OPEN = {'dtc': '0x92 0x1B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_24', 'req': 36069956,
                         'text': ('RSU Open Circuit on Sensor 24 SB3_M CH6 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_OPEN)')}
C_PILLAR_LEFT_S1_S2G = {'dtc': '0x92 0x1B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_24', 'req': 36070004,
                        'text': ('RSU Short to Ground Sensor 24 SB3_M CH6 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_GND)')}
C_PILLAR_LEFT_S1_S2B = {'dtc': '0x92 0x1B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_24', 'req': 36070052,
                        'text': ('RSU Short to Battery Sensor 24 SB3_M CH6 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_BAT)')}
C_PILLAR_LEFT_S1_COMM = {'dtc': '0x92 0x1B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_24', 'req': 36069812,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH6 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_COMMUNICATION_ERROR)')}
C_PILLAR_LEFT_S1_INTERNAL = {'dtc': '0x92 0x1B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_24', 'req': 36069908,
                             'text': ('RSU Internal error Sensor 24 SB3_M CH6 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_INTERNAL_ERROR)')}
C_PILLAR_LEFT_S1_CONFIG = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_24', 'req': 36070100,
                           'text': ('RSU Configuration error Sensor 24 SB3_M CH6 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_LEFT_S1_UNEXPECTED = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_24', 'req': 36069860,
                               'text': ('RSU Configuration error Sensor 24 SB3_M CH6 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_LEFT_S2_OPEN = {'dtc': '0x92 0x1B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_25', 'req': 36069957,
                         'text': ('RSU Open Circuit on Sensor 25 SB3_M CH6 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_OPEN)')}
C_PILLAR_LEFT_S2_S2G = {'dtc': '0x92 0x1B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_25', 'req': 36070005,
                        'text': ('RSU Short to Ground Sensor 25 SB3_M CH6 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_GND)')}
C_PILLAR_LEFT_S2_S2B = {'dtc': '0x92 0x1B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_25', 'req': 36070053,
                        'text': ('RSU Short to Battery Sensor 25 SB3_M CH6 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_BAT)')}
C_PILLAR_LEFT_S2_COMM = {'dtc': '0x92 0x1B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_25', 'req': 36069813,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH6 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_COMMUNICATION_ERROR)')}
C_PILLAR_LEFT_S2_INTERNAL = {'dtc': '0x92 0x1B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_25', 'req': 36069909,
                             'text': ('RSU Internal error Sensor 25 SB3_M CH6 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_INTERNAL_ERROR)')}
C_PILLAR_LEFT_S2_CONFIG = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_25', 'req': 36070101,
                           'text': ('RSU Configuration error Sensor 25 SB3_M CH6 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_LEFT_S2_UNEXPECTED = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_25', 'req': 36069861,
                               'text': ('RSU Configuration error Sensor 25 SB3_M CH6 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_RIGHT_S1_OPEN = {'dtc': '0x92 0x1C 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_28', 'req': 36069960,
                          'text': ('RSU Open Circuit on Sensor 28 SB3_M CH7 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_OPEN)')}
C_PILLAR_RIGHT_S1_S2G = {'dtc': '0x92 0x1C 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_28', 'req': 36070008,
                         'text': ('RSU Short to Ground Sensor 28 SB3_M CH7 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_GND)')}
C_PILLAR_RIGHT_S1_S2B = {'dtc': '0x92 0x1C 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_28', 'req': 36070056,
                         'text': ('RSU Short to Battery Sensor 28 SB3_M CH7 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_BAT)')}
C_PILLAR_RIGHT_S1_COMM = {'dtc': '0x92 0x1C 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_28', 'req': 36069816,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH7 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_COMMUNICATION_ERROR)')}
C_PILLAR_RIGHT_S1_INTERNAL = {'dtc': '0x92 0x1C 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_28', 'req': 36069912,
                              'text': ('RSU Internal error Sensor 28 SB3_M CH7 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_INTERNAL_ERROR)')}
C_PILLAR_RIGHT_S1_CONFIG = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_28', 'req': 36070104,
                            'text': ('RSU Configuration error Sensor 28 SB3_M CH7 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_RIGHT_S1_UNEXPECTED = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_28', 'req': 36069864,
                                'text': ('RSU Configuration error Sensor 28 SB3_M CH7 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_RIGHT_S2_OPEN = {'dtc': '0x92 0x1C 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_29', 'req': 36069961,
                          'text': ('RSU Open Circuit on Sensor 29 SB3_M CH7 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_OPEN)')}
C_PILLAR_RIGHT_S2_S2G = {'dtc': '0x92 0x1C 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_29', 'req': 36070009,
                         'text': ('RSU Short to Ground Sensor 29 SB3_M CH7 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_GND)')}
C_PILLAR_RIGHT_S2_S2B = {'dtc': '0x92 0x1C 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_29', 'req': 36070057,
                         'text': ('RSU Short to Battery Sensor 29 SB3_M CH7 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_BAT)')}
C_PILLAR_RIGHT_S2_COMM = {'dtc': '0x92 0x1C 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_29', 'req': 36069817,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH7 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_COMMUNICATION_ERROR)')}
C_PILLAR_RIGHT_S2_INTERNAL = {'dtc': '0x92 0x1C 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_29', 'req': 36069913,
                              'text': ('RSU Internal error Sensor 29 SB3_M CH7 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_INTERNAL_ERROR)')}
C_PILLAR_RIGHT_S2_CONFIG = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_29', 'req': 36070105,
                            'text': ('RSU Configuration error Sensor 29 SB3_M CH7 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
C_PILLAR_RIGHT_S2_UNEXPECTED = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_29', 'req': 36069865,
                                'text': ('RSU Configuration error Sensor 29 SB3_M CH7 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
UNDERBODY_S1_OPEN = {'dtc': '0x92 0x52 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                     'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_OPEN_32', 'req': 36069964,
                     'text': ('RSU Open Circuit on Sensor 32 EX3_0 CH0 S1 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_OPEN)')}
UNDERBODY_S1_S2G = {'dtc': '0x92 0x52 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                    'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                    'monitor': 'RSU_F_SAT_SHORT_GND_32', 'req': 36070012,
                    'text': ('RSU Short to Ground Sensor 32 EX3_0 CH0 S1 '
                             '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_GND)')}
UNDERBODY_S1_S2B = {'dtc': '0x92 0x52 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                    'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                    'monitor': 'RSU_F_SAT_SHORT_BAT_32', 'req': 36070060,
                    'text': ('RSU Short to Battery Sensor 32 EX3_0 CH0 S1 '
                             '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_BAT)')}
UNDERBODY_S1_COMM = {'dtc': '0x92 0x52 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_COMM_32', 'req': 36069820,
                     'text': ('Satellite Manchester Data Communication Fault EX3_0 CH0 S1 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_COMMUNICATION_ERROR)')}
UNDERBODY_S1_INTERNAL = {'dtc': '0x92 0x52 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                         'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_32', 'req': 36069916,
                         'text': ('RSU Internal error Sensor 32 EX3_0 CH0 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_INTERNAL_ERROR)')}
UNDERBODY_S1_CONFIG = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_CFG_32', 'req': 36070108,
                       'text': ('RSU Configuration error Sensor 32 EX3_0 CH0 S1 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
UNDERBODY_S1_UNEXPECTED = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                      'Value: Within PDC(2 sec)'),
                           'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_32', 'req': 36069868,
                           'text': ('Unexpected Satellite on EX3_0 CH0 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
UNDERBODY_S2_OPEN = {'dtc': '0x92 0x52 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                     'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_OPEN_33', 'req': 36069965,
                     'text': ('RSU Open Circuit on Sensor 33 EX3_0 CH0 S2 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_OPEN)')}
UNDERBODY_S2_S2G = {'dtc': '0x92 0x52 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                    'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                    'monitor': 'RSU_F_SAT_SHORT_GND_33', 'req': 36070013,
                    'text': ('RSU Short to Ground Sensor 33 EX3_0 CH0 S2 '
                             '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_GND)')}
UNDERBODY_S2_S2B = {'dtc': '0x92 0x52 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                    'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                    'monitor': 'RSU_F_SAT_SHORT_BAT_33', 'req': 36070061,
                    'text': ('RSU Short to Battery Sensor 33 EX3_0 CH0 S2 '
                             '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_BAT)')}
UNDERBODY_S2_COMM = {'dtc': '0x92 0x52 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_COMM_33', 'req': 36069821,
                     'text': ('Satellite Manchester Data Communication Fault EX3_0 CH0 S2 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_COMMUNICATION_ERROR)')}
UNDERBODY_S2_INTERNAL = {'dtc': '0x92 0x52 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                         'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_33', 'req': 36069917,
                         'text': ('RSU Internal error Sensor 33 EX3_0 CH0 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_INTERNAL_ERROR)')}
UNDERBODY_S2_CONFIG = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_CFG_33', 'req': 36070109,
                       'text': ('RSU Configuration error Sensor 33 EX3_0 CH0 S2 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
UNDERBODY_S2_UNEXPECTED = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                      'Value: Within PDC(2 sec)'),
                           'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_33', 'req': 36069869,
                           'text': ('Unexpected Satellite on EX3_0 CH0 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
PRESSURE_RIGHT_S3_OPEN = {'dtc': '0x92 0x16 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_2', 'req': 36069934,
                          'text': ('RSU Open Circuit on Sensor 2 SB3_M CH0 S3 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_OPEN)')}
PRESSURE_RIGHT_S3_S2G = {'dtc': '0x92 0x16 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_2', 'req': 36069982,
                         'text': ('RSU Short to Ground Sensor 2 SB3_M CH0 S3 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_SHORT_TO_GND)')}
PRESSURE_RIGHT_S3_S2B = {'dtc': '0x92 0x16 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_2', 'req': 36070030,
                         'text': ('RSU Short to Battery Sensor 2 SB3_M CH0 S3 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_SHORT_TO_BAT)')}
PRESSURE_RIGHT_S3_COMM = {'dtc': '0x92 0x16 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_2', 'req': 36069790,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH0 S3 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_COMMUNICATION_ERROR)')}
PRESSURE_RIGHT_S3_INTERNAL = {'dtc': '0x92 0x16 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_2', 'req': 36069886,
                              'text': ('RSU Internal error Sensor 2 SB3_M CH0 S3 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_INTERNAL_ERROR)')}
PRESSURE_RIGHT_S3_CONFIG = {'dtc': '0x92 0x16 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_2', 'req': 36070078,
                            'text': ('RSU Configuration error Sensor 2 SB3_M CH0 S3 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_CONFIGURATION_ERROR)')}
PRESSURE_RIGHT_S3_UNEXPECTED = {'dtc': '0x92 0x16 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_2', 'req': 36069838,
                                'text': ('RSU Configuration error Sensor 2 SB3_M CH0 S3 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_CONFIGURATION_ERROR)')}
PRESSURE_LEFT_S3_OPEN = {'dtc': '0x92 0x12 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_6', 'req': 36069938,
                         'text': ('RSU Open Circuit on Sensor 6 SB3_M CH1 S3 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_OPEN)')}
PRESSURE_LEFT_S3_S2G = {'dtc': '0x92 0x12 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_6', 'req': 36069986,
                        'text': ('RSU Short to Ground Sensor 6 SB3_M CH1 S3 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_SHORT_TO_GND)')}
PRESSURE_LEFT_S3_S2B = {'dtc': '0x92 0x12 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_6', 'req': 36070034,
                        'text': ('RSU Short to Battery Sensor 6 SB3_M CH1 S3 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_SHORT_TO_BAT)')}
PRESSURE_LEFT_S3_COMM = {'dtc': '0x92 0x12 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_6', 'req': 36069794,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH1 S3 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_COMMUNICATION_ERROR)')}
PRESSURE_LEFT_S3_INTERNAL = {'dtc': '0x92 0x12 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_6', 'req': 36069890,
                             'text': ('RSU Internal error Sensor 6 SB3_M CH1 S3 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_INTERNAL_ERROR)')}
PRESSURE_LEFT_S3_CONFIG = {'dtc': '0x92 0x12 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_6', 'req': 36070082,
                           'text': ('RSU Configuration error Sensor 6 SB3_M CH1 S3 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_CONFIGURATION_ERROR)')}
PRESSURE_LEFT_S3_UNEXPECTED = {'dtc': '0x92 0x12 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_6', 'req': 36069842,
                               'text': ('RSU Configuration error Sensor 6 SB3_M CH1 S3 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_CONFIGURATION_ERROR)')}
REAR_S3_OPEN = {'dtc': '0x92 0x38 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                'monitor': 'RSU_F_SAT_OPEN_38', 'req': 36069970,
                'text': ('RSU Open Circuit on Sensor 38 EX3_0 CH1 S3 '
                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_OPEN)')}
REAR_S3_S2G = {'dtc': '0x92 0x38 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
               'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
               'monitor': 'RSU_F_SAT_SHORT_GND_38', 'req': 36070018,
               'text': ('RSU Short to Ground Sensor 38 EX3_0 CH1 S3 '
                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_SHORT_TO_GND)')}
REAR_S3_S2B = {'dtc': '0x92 0x38 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
               'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
               'monitor': 'RSU_F_SAT_SHORT_BAT_38', 'req': 36070066,
               'text': ('RSU Short to Battery Sensor 38 EX3_0 CH1 S3 '
                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_SHORT_TO_BAT)')}
REAR_S3_COMM = {'dtc': '0x92 0x38 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                'monitor': 'RSU_F_SAT_COMM_38', 'req': 36069826,
                'text': ('Satellite Manchester Data Communication Fault EX3_0 CH1 S3 '
                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_COMMUNICATION_ERROR)')}
REAR_S3_INTERNAL = {'dtc': '0x92 0x38 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                    'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_38', 'req': 36069922,
                    'text': ('RSU Internal error Sensor 38 EX3_0 CH1 S3 '
                             '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_INTERNAL_ERROR)')}
REAR_S3_CONFIG = {'dtc': '0x92 0x38 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                  'monitor': 'RSU_F_SAT_CFG_38', 'req': 36070114,
                  'text': ('RSU Configuration error Sensor 38 EX3_0 CH1 S3 '
                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_CONFIGURATION_ERROR)')}
REAR_S3_UNEXPECTED = {'dtc': '0x92 0x38 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_38', 'req': 36069874,
                      'text': ('Unexpected Satellite on EX3_0 CH1 S3 '
                               '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_CONFIGURATION_ERROR)')}
RSU_CHANNEL00_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_0', 'req': 36069764,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 0 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL00_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_0', 'req': 36069776,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 00 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL00_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_0', 'req': 36069752,
                     'text': 'RSU SPI communication error SB3_M Ch00 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL01_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_1', 'req': 36069765,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 1 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL01_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_1', 'req': 36069777,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 01 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL01_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_1', 'req': 36069753,
                     'text': 'RSU SPI communication error SB3_M Ch01 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL02_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_2', 'req': 36069766,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 2 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL02_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_2', 'req': 36069778,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 02 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL02_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_2', 'req': 36069754,
                     'text': 'RSU SPI communication error SB3_M Ch02 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL03_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_3', 'req': 36069767,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 3 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL03_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_3', 'req': 36069779,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 03 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL03_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_3', 'req': 36069755,
                     'text': 'RSU SPI communication error SB3_M Ch03 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL04_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_4', 'req': 36069768,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 4 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL04_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_4', 'req': 36069780,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 04 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL04_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_4', 'req': 36069756,
                     'text': 'RSU SPI communication error SB3_M Ch04 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL05_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_5', 'req': 36069769,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 5 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL05_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_5', 'req': 36069781,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 05 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL05_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_5', 'req': 36069757,
                     'text': 'RSU SPI communication error SB3_M Ch05 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL06_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_6', 'req': 36069770,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 6 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL06_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_6', 'req': 36069782,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 06 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL06_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_6', 'req': 36069758,
                     'text': 'RSU SPI communication error SB3_M Ch06 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL07_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_7', 'req': 36069771,
                        'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 7 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL07_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_7', 'req': 36069783,
                             'text': 'RSU ASIC Channel SPI Fault SB3_M CH 07 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL07_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_7', 'req': 36069759,
                     'text': 'RSU SPI communication error SB3_M Ch07 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL08_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_8', 'req': 36069772,
                        'text': 'RSU ASIC Channel Configuration Fault EX3_0 CH 0 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL08_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_8', 'req': 36069784,
                             'text': 'RSU ASIC Channel SPI Fault EX3_0 CH 00 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL08_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_8', 'req': 36069760,
                     'text': 'RSU SPI communication error EX3_0 Ch00 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL09_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_9', 'req': 36069773,
                        'text': 'RSU ASIC Channel Configuration Fault EX3_0 CH 1 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL09_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                             'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_9', 'req': 36069785,
                             'text': 'RSU ASIC Channel SPI Fault EX3_0 CH 01 (FLTMONR_E_ECU_INTERNAL)'}
RSU_CHANNEL09_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                     'monitor': 'RSU_F_ASIC_CHANNEL_SPI_9', 'req': 36069761,
                     'text': 'RSU SPI communication error EX3_0 Ch01 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_0', 'req': 36070228,
                    'text': 'OPS RSU Offset Failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_1', 'req': 36070229,
                    'text': 'OPS RSU Offset Failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_10 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_10', 'req': 36070238,
                     'text': 'OPS RSU Offset Failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_11 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_11', 'req': 36070239,
                     'text': 'OPS RSU Offset Failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_12 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_12', 'req': 36070240,
                     'text': 'OPS RSU Offset Failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_13 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_13', 'req': 36070241,
                     'text': 'OPS RSU Offset Failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_14 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_14', 'req': 36070242,
                     'text': 'OPS RSU Offset Failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_15 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_15', 'req': 36070243,
                     'text': 'OPS RSU Offset Failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_16 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_16', 'req': 36070244,
                     'text': 'OPS RSU Offset Failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_17 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_17', 'req': 36070245,
                     'text': 'OPS RSU Offset Failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_18 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                'Cycle'),
                     'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_18', 'req': 36070246,
                     'text': 'OPS RSU Offset Failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_2', 'req': 36070230,
                    'text': 'OPS RSU Offset Failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_3', 'req': 36070231,
                    'text': 'OPS RSU Offset Failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_4 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_4', 'req': 36070232,
                    'text': 'OPS RSU Offset Failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_5 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_5', 'req': 36070233,
                    'text': 'OPS RSU Offset Failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_6 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_6', 'req': 36070234,
                    'text': 'OPS RSU Offset Failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_7 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_7', 'req': 36070235,
                    'text': 'OPS RSU Offset Failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_8 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_8', 'req': 36070236,
                    'text': 'OPS RSU Offset Failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_OFFSET_9 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next Cycle',
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_9', 'req': 36070237,
                    'text': 'OPS RSU Offset Failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_0', 'req': 36070173,
                        'text': 'OPS RSU Saturation Failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_1', 'req': 36070174,
                        'text': 'OPS RSU Saturation Failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_10 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_10', 'req': 36070183,
                         'text': 'OPS RSU Saturation Failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_11 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_11', 'req': 36070184,
                         'text': 'OPS RSU Saturation Failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_12 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_12', 'req': 36070185,
                         'text': 'OPS RSU Saturation Failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_13 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_13', 'req': 36070186,
                         'text': 'OPS RSU Saturation Failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_14 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_14', 'req': 36070187,
                         'text': 'OPS RSU Saturation Failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_15 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_15', 'req': 36070188,
                         'text': 'OPS RSU Saturation Failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_16 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_16', 'req': 36070189,
                         'text': 'OPS RSU Saturation Failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_17 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_17', 'req': 36070190,
                         'text': 'OPS RSU Saturation Failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_18 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                         'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_18', 'req': 36070191,
                         'text': 'OPS RSU Saturation Failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_2', 'req': 36070175,
                        'text': 'OPS RSU Saturation Failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_3', 'req': 36070176,
                        'text': 'OPS RSU Saturation Failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_4 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_4', 'req': 36070177,
                        'text': 'OPS RSU Saturation Failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_5 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_5', 'req': 36070178,
                        'text': 'OPS RSU Saturation Failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_6 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_6', 'req': 36070179,
                        'text': 'OPS RSU Saturation Failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_7 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_7', 'req': 36070180,
                        'text': 'OPS RSU Saturation Failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_8 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_8', 'req': 36070181,
                        'text': 'OPS RSU Saturation Failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
OPS_RSU_SATURATION_9 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_9', 'req': 36070182,
                        'text': 'OPS RSU Saturation Failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
PWR_RSUSUPPLY_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 1075, 'dequalify_ms': 1075, 'latched': False,
                       'monitor': 'PWR_F_RSUSUPPLY_TOO_LOW_0', 'req': 36069726,
                       'text': 'RSU SUPPLY is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_RSUSUPPLY_LOW_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 1075, 'dequalify_ms': 1075, 'latched': False,
                       'monitor': 'PWR_F_RSUSUPPLY_TOO_LOW_1', 'req': 36069739,
                       'text': 'RSU SUPPLY is too low EX3_0 (FLTMONR_E_ECU_INTERNAL)'}

RSU_FAULTS = {
    'A_PILLAR_LEFT_S1_OPEN': A_PILLAR_LEFT_S1_OPEN,
    'A_PILLAR_LEFT_S1_S2G': A_PILLAR_LEFT_S1_S2G,
    'A_PILLAR_LEFT_S1_S2B': A_PILLAR_LEFT_S1_S2B,
    'A_PILLAR_LEFT_S1_COMM': A_PILLAR_LEFT_S1_COMM,
    'A_PILLAR_LEFT_S1_INTERNAL': A_PILLAR_LEFT_S1_INTERNAL,
    'A_PILLAR_LEFT_S1_CONFIG': A_PILLAR_LEFT_S1_CONFIG,
    'A_PILLAR_LEFT_S1_UNEXPECTED': A_PILLAR_LEFT_S1_UNEXPECTED,
    'A_PILLAR_LEFT_S2_OPEN': A_PILLAR_LEFT_S2_OPEN,
    'A_PILLAR_LEFT_S2_S2G': A_PILLAR_LEFT_S2_S2G,
    'A_PILLAR_LEFT_S2_S2B': A_PILLAR_LEFT_S2_S2B,
    'A_PILLAR_LEFT_S2_COMM': A_PILLAR_LEFT_S2_COMM,
    'A_PILLAR_LEFT_S2_INTERNAL': A_PILLAR_LEFT_S2_INTERNAL,
    'A_PILLAR_LEFT_S2_CONFIG': A_PILLAR_LEFT_S2_CONFIG,
    'A_PILLAR_LEFT_S2_UNEXPECTED': A_PILLAR_LEFT_S2_UNEXPECTED,
    'A_PILLAR_RIGHT_S1_OPEN': A_PILLAR_RIGHT_S1_OPEN,
    'A_PILLAR_RIGHT_S1_S2G': A_PILLAR_RIGHT_S1_S2G,
    'A_PILLAR_RIGHT_S1_S2B': A_PILLAR_RIGHT_S1_S2B,
    'A_PILLAR_RIGHT_S1_COMM': A_PILLAR_RIGHT_S1_COMM,
    'A_PILLAR_RIGHT_S1_INTERNAL': A_PILLAR_RIGHT_S1_INTERNAL,
    'A_PILLAR_RIGHT_S1_CONFIG': A_PILLAR_RIGHT_S1_CONFIG,
    'A_PILLAR_RIGHT_S1_UNEXPECTED': A_PILLAR_RIGHT_S1_UNEXPECTED,
    'A_PILLAR_RIGHT_S2_OPEN': A_PILLAR_RIGHT_S2_OPEN,
    'A_PILLAR_RIGHT_S2_S2G': A_PILLAR_RIGHT_S2_S2G,
    'A_PILLAR_RIGHT_S2_S2B': A_PILLAR_RIGHT_S2_S2B,
    'A_PILLAR_RIGHT_S2_COMM': A_PILLAR_RIGHT_S2_COMM,
    'A_PILLAR_RIGHT_S2_INTERNAL': A_PILLAR_RIGHT_S2_INTERNAL,
    'A_PILLAR_RIGHT_S2_CONFIG': A_PILLAR_RIGHT_S2_CONFIG,
    'A_PILLAR_RIGHT_S2_UNEXPECTED': A_PILLAR_RIGHT_S2_UNEXPECTED,
    'B_PILLAR_LEFT_S1_OPEN': B_PILLAR_LEFT_S1_OPEN,
    'B_PILLAR_LEFT_S1_S2G': B_PILLAR_LEFT_S1_S2G,
    'B_PILLAR_LEFT_S1_S2B': B_PILLAR_LEFT_S1_S2B,
    'B_PILLAR_LEFT_S1_COMM': B_PILLAR_LEFT_S1_COMM,
    'B_PILLAR_LEFT_S1_INTERNAL': B_PILLAR_LEFT_S1_INTERNAL,
    'B_PILLAR_LEFT_S1_CONFIG': B_PILLAR_LEFT_S1_CONFIG,
    'B_PILLAR_LEFT_S1_UNEXPECTED': B_PILLAR_LEFT_S1_UNEXPECTED,
    'B_PILLAR_LEFT_S2_OPEN': B_PILLAR_LEFT_S2_OPEN,
    'B_PILLAR_LEFT_S2_S2G': B_PILLAR_LEFT_S2_S2G,
    'B_PILLAR_LEFT_S2_S2B': B_PILLAR_LEFT_S2_S2B,
    'B_PILLAR_LEFT_S2_COMM': B_PILLAR_LEFT_S2_COMM,
    'B_PILLAR_LEFT_S2_INTERNAL': B_PILLAR_LEFT_S2_INTERNAL,
    'B_PILLAR_LEFT_S2_CONFIG': B_PILLAR_LEFT_S2_CONFIG,
    'B_PILLAR_LEFT_S2_UNEXPECTED': B_PILLAR_LEFT_S2_UNEXPECTED,
    'B_PILLAR_RIGHT_S1_OPEN': B_PILLAR_RIGHT_S1_OPEN,
    'B_PILLAR_RIGHT_S1_S2G': B_PILLAR_RIGHT_S1_S2G,
    'B_PILLAR_RIGHT_S1_S2B': B_PILLAR_RIGHT_S1_S2B,
    'B_PILLAR_RIGHT_S1_COMM': B_PILLAR_RIGHT_S1_COMM,
    'B_PILLAR_RIGHT_S1_INTERNAL': B_PILLAR_RIGHT_S1_INTERNAL,
    'B_PILLAR_RIGHT_S1_CONFIG': B_PILLAR_RIGHT_S1_CONFIG,
    'B_PILLAR_RIGHT_S1_UNEXPECTED': B_PILLAR_RIGHT_S1_UNEXPECTED,
    'B_PILLAR_RIGHT_S2_OPEN': B_PILLAR_RIGHT_S2_OPEN,
    'B_PILLAR_RIGHT_S2_S2G': B_PILLAR_RIGHT_S2_S2G,
    'B_PILLAR_RIGHT_S2_S2B': B_PILLAR_RIGHT_S2_S2B,
    'B_PILLAR_RIGHT_S2_COMM': B_PILLAR_RIGHT_S2_COMM,
    'B_PILLAR_RIGHT_S2_INTERNAL': B_PILLAR_RIGHT_S2_INTERNAL,
    'B_PILLAR_RIGHT_S2_CONFIG': B_PILLAR_RIGHT_S2_CONFIG,
    'B_PILLAR_RIGHT_S2_UNEXPECTED': B_PILLAR_RIGHT_S2_UNEXPECTED,
    'FRONT_LEFT_S1_OPEN': FRONT_LEFT_S1_OPEN,
    'FRONT_LEFT_S1_S2G': FRONT_LEFT_S1_S2G,
    'FRONT_LEFT_S1_S2B': FRONT_LEFT_S1_S2B,
    'FRONT_LEFT_S1_COMM': FRONT_LEFT_S1_COMM,
    'FRONT_LEFT_S1_INTERNAL': FRONT_LEFT_S1_INTERNAL,
    'FRONT_LEFT_S1_CONFIG': FRONT_LEFT_S1_CONFIG,
    'FRONT_LEFT_S1_UNEXPECTED': FRONT_LEFT_S1_UNEXPECTED,
    'FRONT_LEFT_S2_OPEN': FRONT_LEFT_S2_OPEN,
    'FRONT_LEFT_S2_S2G': FRONT_LEFT_S2_S2G,
    'FRONT_LEFT_S2_S2B': FRONT_LEFT_S2_S2B,
    'FRONT_LEFT_S2_COMM': FRONT_LEFT_S2_COMM,
    'FRONT_LEFT_S2_INTERNAL': FRONT_LEFT_S2_INTERNAL,
    'FRONT_LEFT_S2_CONFIG': FRONT_LEFT_S2_CONFIG,
    'FRONT_LEFT_S2_UNEXPECTED': FRONT_LEFT_S2_UNEXPECTED,
    'FRONT_RIGHT_S1_OPEN': FRONT_RIGHT_S1_OPEN,
    'FRONT_RIGHT_S1_S2G': FRONT_RIGHT_S1_S2G,
    'FRONT_RIGHT_S1_S2B': FRONT_RIGHT_S1_S2B,
    'FRONT_RIGHT_S1_COMM': FRONT_RIGHT_S1_COMM,
    'FRONT_RIGHT_S1_INTERNAL': FRONT_RIGHT_S1_INTERNAL,
    'FRONT_RIGHT_S1_CONFIG': FRONT_RIGHT_S1_CONFIG,
    'FRONT_RIGHT_S1_UNEXPECTED': FRONT_RIGHT_S1_UNEXPECTED,
    'FRONT_RIGHT_S2_OPEN': FRONT_RIGHT_S2_OPEN,
    'FRONT_RIGHT_S2_S2G': FRONT_RIGHT_S2_S2G,
    'FRONT_RIGHT_S2_S2B': FRONT_RIGHT_S2_S2B,
    'FRONT_RIGHT_S2_COMM': FRONT_RIGHT_S2_COMM,
    'FRONT_RIGHT_S2_INTERNAL': FRONT_RIGHT_S2_INTERNAL,
    'FRONT_RIGHT_S2_CONFIG': FRONT_RIGHT_S2_CONFIG,
    'FRONT_RIGHT_S2_UNEXPECTED': FRONT_RIGHT_S2_UNEXPECTED,
    'C_PILLAR_LEFT_S1_OPEN': C_PILLAR_LEFT_S1_OPEN,
    'C_PILLAR_LEFT_S1_S2G': C_PILLAR_LEFT_S1_S2G,
    'C_PILLAR_LEFT_S1_S2B': C_PILLAR_LEFT_S1_S2B,
    'C_PILLAR_LEFT_S1_COMM': C_PILLAR_LEFT_S1_COMM,
    'C_PILLAR_LEFT_S1_INTERNAL': C_PILLAR_LEFT_S1_INTERNAL,
    'C_PILLAR_LEFT_S1_CONFIG': C_PILLAR_LEFT_S1_CONFIG,
    'C_PILLAR_LEFT_S1_UNEXPECTED': C_PILLAR_LEFT_S1_UNEXPECTED,
    'C_PILLAR_LEFT_S2_OPEN': C_PILLAR_LEFT_S2_OPEN,
    'C_PILLAR_LEFT_S2_S2G': C_PILLAR_LEFT_S2_S2G,
    'C_PILLAR_LEFT_S2_S2B': C_PILLAR_LEFT_S2_S2B,
    'C_PILLAR_LEFT_S2_COMM': C_PILLAR_LEFT_S2_COMM,
    'C_PILLAR_LEFT_S2_INTERNAL': C_PILLAR_LEFT_S2_INTERNAL,
    'C_PILLAR_LEFT_S2_CONFIG': C_PILLAR_LEFT_S2_CONFIG,
    'C_PILLAR_LEFT_S2_UNEXPECTED': C_PILLAR_LEFT_S2_UNEXPECTED,
    'C_PILLAR_RIGHT_S1_OPEN': C_PILLAR_RIGHT_S1_OPEN,
    'C_PILLAR_RIGHT_S1_S2G': C_PILLAR_RIGHT_S1_S2G,
    'C_PILLAR_RIGHT_S1_S2B': C_PILLAR_RIGHT_S1_S2B,
    'C_PILLAR_RIGHT_S1_COMM': C_PILLAR_RIGHT_S1_COMM,
    'C_PILLAR_RIGHT_S1_INTERNAL': C_PILLAR_RIGHT_S1_INTERNAL,
    'C_PILLAR_RIGHT_S1_CONFIG': C_PILLAR_RIGHT_S1_CONFIG,
    'C_PILLAR_RIGHT_S1_UNEXPECTED': C_PILLAR_RIGHT_S1_UNEXPECTED,
    'C_PILLAR_RIGHT_S2_OPEN': C_PILLAR_RIGHT_S2_OPEN,
    'C_PILLAR_RIGHT_S2_S2G': C_PILLAR_RIGHT_S2_S2G,
    'C_PILLAR_RIGHT_S2_S2B': C_PILLAR_RIGHT_S2_S2B,
    'C_PILLAR_RIGHT_S2_COMM': C_PILLAR_RIGHT_S2_COMM,
    'C_PILLAR_RIGHT_S2_INTERNAL': C_PILLAR_RIGHT_S2_INTERNAL,
    'C_PILLAR_RIGHT_S2_CONFIG': C_PILLAR_RIGHT_S2_CONFIG,
    'C_PILLAR_RIGHT_S2_UNEXPECTED': C_PILLAR_RIGHT_S2_UNEXPECTED,
    'UNDERBODY_S1_OPEN': UNDERBODY_S1_OPEN,
    'UNDERBODY_S1_S2G': UNDERBODY_S1_S2G,
    'UNDERBODY_S1_S2B': UNDERBODY_S1_S2B,
    'UNDERBODY_S1_COMM': UNDERBODY_S1_COMM,
    'UNDERBODY_S1_INTERNAL': UNDERBODY_S1_INTERNAL,
    'UNDERBODY_S1_CONFIG': UNDERBODY_S1_CONFIG,
    'UNDERBODY_S1_UNEXPECTED': UNDERBODY_S1_UNEXPECTED,
    'UNDERBODY_S2_OPEN': UNDERBODY_S2_OPEN,
    'UNDERBODY_S2_S2G': UNDERBODY_S2_S2G,
    'UNDERBODY_S2_S2B': UNDERBODY_S2_S2B,
    'UNDERBODY_S2_COMM': UNDERBODY_S2_COMM,
    'UNDERBODY_S2_INTERNAL': UNDERBODY_S2_INTERNAL,
    'UNDERBODY_S2_CONFIG': UNDERBODY_S2_CONFIG,
    'UNDERBODY_S2_UNEXPECTED': UNDERBODY_S2_UNEXPECTED,
    'PRESSURE_RIGHT_S3_OPEN': PRESSURE_RIGHT_S3_OPEN,
    'PRESSURE_RIGHT_S3_S2G': PRESSURE_RIGHT_S3_S2G,
    'PRESSURE_RIGHT_S3_S2B': PRESSURE_RIGHT_S3_S2B,
    'PRESSURE_RIGHT_S3_COMM': PRESSURE_RIGHT_S3_COMM,
    'PRESSURE_RIGHT_S3_INTERNAL': PRESSURE_RIGHT_S3_INTERNAL,
    'PRESSURE_RIGHT_S3_CONFIG': PRESSURE_RIGHT_S3_CONFIG,
    'PRESSURE_RIGHT_S3_UNEXPECTED': PRESSURE_RIGHT_S3_UNEXPECTED,
    'PRESSURE_LEFT_S3_OPEN': PRESSURE_LEFT_S3_OPEN,
    'PRESSURE_LEFT_S3_S2G': PRESSURE_LEFT_S3_S2G,
    'PRESSURE_LEFT_S3_S2B': PRESSURE_LEFT_S3_S2B,
    'PRESSURE_LEFT_S3_COMM': PRESSURE_LEFT_S3_COMM,
    'PRESSURE_LEFT_S3_INTERNAL': PRESSURE_LEFT_S3_INTERNAL,
    'PRESSURE_LEFT_S3_CONFIG': PRESSURE_LEFT_S3_CONFIG,
    'PRESSURE_LEFT_S3_UNEXPECTED': PRESSURE_LEFT_S3_UNEXPECTED,
    'REAR_S3_OPEN': REAR_S3_OPEN,
    'REAR_S3_S2G': REAR_S3_S2G,
    'REAR_S3_S2B': REAR_S3_S2B,
    'REAR_S3_COMM': REAR_S3_COMM,
    'REAR_S3_INTERNAL': REAR_S3_INTERNAL,
    'REAR_S3_CONFIG': REAR_S3_CONFIG,
    'REAR_S3_UNEXPECTED': REAR_S3_UNEXPECTED,
    'RSU_CHANNEL00_CONFIG': RSU_CHANNEL00_CONFIG,
    'RSU_CHANNEL00_CRC_CHECKER': RSU_CHANNEL00_CRC_CHECKER,
    'RSU_CHANNEL00_SPI': RSU_CHANNEL00_SPI,
    'RSU_CHANNEL01_CONFIG': RSU_CHANNEL01_CONFIG,
    'RSU_CHANNEL01_CRC_CHECKER': RSU_CHANNEL01_CRC_CHECKER,
    'RSU_CHANNEL01_SPI': RSU_CHANNEL01_SPI,
    'RSU_CHANNEL02_CONFIG': RSU_CHANNEL02_CONFIG,
    'RSU_CHANNEL02_CRC_CHECKER': RSU_CHANNEL02_CRC_CHECKER,
    'RSU_CHANNEL02_SPI': RSU_CHANNEL02_SPI,
    'RSU_CHANNEL03_CONFIG': RSU_CHANNEL03_CONFIG,
    'RSU_CHANNEL03_CRC_CHECKER': RSU_CHANNEL03_CRC_CHECKER,
    'RSU_CHANNEL03_SPI': RSU_CHANNEL03_SPI,
    'RSU_CHANNEL04_CONFIG': RSU_CHANNEL04_CONFIG,
    'RSU_CHANNEL04_CRC_CHECKER': RSU_CHANNEL04_CRC_CHECKER,
    'RSU_CHANNEL04_SPI': RSU_CHANNEL04_SPI,
    'RSU_CHANNEL05_CONFIG': RSU_CHANNEL05_CONFIG,
    'RSU_CHANNEL05_CRC_CHECKER': RSU_CHANNEL05_CRC_CHECKER,
    'RSU_CHANNEL05_SPI': RSU_CHANNEL05_SPI,
    'RSU_CHANNEL06_CONFIG': RSU_CHANNEL06_CONFIG,
    'RSU_CHANNEL06_CRC_CHECKER': RSU_CHANNEL06_CRC_CHECKER,
    'RSU_CHANNEL06_SPI': RSU_CHANNEL06_SPI,
    'RSU_CHANNEL07_CONFIG': RSU_CHANNEL07_CONFIG,
    'RSU_CHANNEL07_CRC_CHECKER': RSU_CHANNEL07_CRC_CHECKER,
    'RSU_CHANNEL07_SPI': RSU_CHANNEL07_SPI,
    'RSU_CHANNEL08_CONFIG': RSU_CHANNEL08_CONFIG,
    'RSU_CHANNEL08_CRC_CHECKER': RSU_CHANNEL08_CRC_CHECKER,
    'RSU_CHANNEL08_SPI': RSU_CHANNEL08_SPI,
    'RSU_CHANNEL09_CONFIG': RSU_CHANNEL09_CONFIG,
    'RSU_CHANNEL09_CRC_CHECKER': RSU_CHANNEL09_CRC_CHECKER,
    'RSU_CHANNEL09_SPI': RSU_CHANNEL09_SPI,
    'OPS_RSU_OFFSET_0': OPS_RSU_OFFSET_0,
    'OPS_RSU_OFFSET_1': OPS_RSU_OFFSET_1,
    'OPS_RSU_OFFSET_10': OPS_RSU_OFFSET_10,
    'OPS_RSU_OFFSET_11': OPS_RSU_OFFSET_11,
    'OPS_RSU_OFFSET_12': OPS_RSU_OFFSET_12,
    'OPS_RSU_OFFSET_13': OPS_RSU_OFFSET_13,
    'OPS_RSU_OFFSET_14': OPS_RSU_OFFSET_14,
    'OPS_RSU_OFFSET_15': OPS_RSU_OFFSET_15,
    'OPS_RSU_OFFSET_16': OPS_RSU_OFFSET_16,
    'OPS_RSU_OFFSET_17': OPS_RSU_OFFSET_17,
    'OPS_RSU_OFFSET_18': OPS_RSU_OFFSET_18,
    'OPS_RSU_OFFSET_2': OPS_RSU_OFFSET_2,
    'OPS_RSU_OFFSET_3': OPS_RSU_OFFSET_3,
    'OPS_RSU_OFFSET_4': OPS_RSU_OFFSET_4,
    'OPS_RSU_OFFSET_5': OPS_RSU_OFFSET_5,
    'OPS_RSU_OFFSET_6': OPS_RSU_OFFSET_6,
    'OPS_RSU_OFFSET_7': OPS_RSU_OFFSET_7,
    'OPS_RSU_OFFSET_8': OPS_RSU_OFFSET_8,
    'OPS_RSU_OFFSET_9': OPS_RSU_OFFSET_9,
    'OPS_RSU_SATURATION_0': OPS_RSU_SATURATION_0,
    'OPS_RSU_SATURATION_1': OPS_RSU_SATURATION_1,
    'OPS_RSU_SATURATION_10': OPS_RSU_SATURATION_10,
    'OPS_RSU_SATURATION_11': OPS_RSU_SATURATION_11,
    'OPS_RSU_SATURATION_12': OPS_RSU_SATURATION_12,
    'OPS_RSU_SATURATION_13': OPS_RSU_SATURATION_13,
    'OPS_RSU_SATURATION_14': OPS_RSU_SATURATION_14,
    'OPS_RSU_SATURATION_15': OPS_RSU_SATURATION_15,
    'OPS_RSU_SATURATION_16': OPS_RSU_SATURATION_16,
    'OPS_RSU_SATURATION_17': OPS_RSU_SATURATION_17,
    'OPS_RSU_SATURATION_18': OPS_RSU_SATURATION_18,
    'OPS_RSU_SATURATION_2': OPS_RSU_SATURATION_2,
    'OPS_RSU_SATURATION_3': OPS_RSU_SATURATION_3,
    'OPS_RSU_SATURATION_4': OPS_RSU_SATURATION_4,
    'OPS_RSU_SATURATION_5': OPS_RSU_SATURATION_5,
    'OPS_RSU_SATURATION_6': OPS_RSU_SATURATION_6,
    'OPS_RSU_SATURATION_7': OPS_RSU_SATURATION_7,
    'OPS_RSU_SATURATION_8': OPS_RSU_SATURATION_8,
    'OPS_RSU_SATURATION_9': OPS_RSU_SATURATION_9,
    'PWR_RSUSUPPLY_LOW_0': PWR_RSUSUPPLY_LOW_0,
    'PWR_RSUSUPPLY_LOW_1': PWR_RSUSUPPLY_LOW_1,
}


# ====================================================================================================
# CAN supervision (68)
# <node>_NODE_ABSENT, <frame>_TIMEOUT, <frame>_CRC / _DLC / _COUNTER (message content failure: all
# three share the frame's DTC), <signal>_SCF (signal content failure). Times are in frame counts.
# ====================================================================================================
ECALL_NODE_ABSENT = {'dtc': '0xD1 0x73 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'ECALL_NODE_ABSENT', 'req': 36070404,
                     'text': 'ECALL Node Absent (FLTMONR_E_ECALL_NODE_ABSENT)'}
EPS_NODE_ABSENT = {'dtc': '0xD1 0x11 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'EPS_NODE_ABSENT', 'req': 36070334,
                   'text': 'EPS Node Absent (FLTMONR_E_EPS_NODE_ABSENT)'}
FR_ZONE_NODE_ABSENT = {'dtc': '0xD1 0x04 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                       'monitor': 'FR_ZONE_NODE_ABSENT', 'req': 36070333,
                       'text': 'FR_ZONE Node Absent (FLTMONR_E_FR_ZONE_NODE_ABSENT)'}
HPCAD_NODE_ABSENT = {'dtc': '0xD1 0x61 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD_NODE_ABSENT', 'req': 36070360,
                     'text': 'HPCAD Node Absent (FLTMONR_E_HPCAD_NODE_ABSENT)'}
HPCC_NODE_ABSENT = {'dtc': '0xD1 0x60 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                    'monitor': 'HPCC_NODE_ABSENT', 'req': 36070335,
                    'text': 'HPCC Node Absent (FLTMONR_E_HPCC_NODE_ABSENT)'}
IEB_NODE_ABSENT = {'dtc': '0xD1 0x03 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'IEB_NODE_ABSENT', 'req': 36070332,
                   'text': 'IEB Node Absent (FLTMONR_E_IEB_NODE_ABSENT)'}
OCS_NODE_ABSENT = {'dtc': '0xD1 0x70 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'OCS_NODE_ABSENT', 'req': 36070401,
                   'text': 'OCS1_500 Node Absent (FLTMONR_E_OCS_NODE_ABSENT)'}
VCU_NODE_ABSENT = {'dtc': '0xD1 0x54 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'VCU_NODE_ABSENT', 'req': 36070330,
                   'text': 'VCU Node Absent (FLTMONR_E_VCU_NODE_ABSENT)'}
FR_ZONE_TIMEOUT = {'dtc': '0xD0 0x04 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'FRZONE_MESSAGE_TIMEOUT', 'req': 36070373,
                   'text': 'FRZONE Message Timeout (FLTMONR_E_FRZONE_MESSAGE_TIMEOUT)'}
HPCAD2_TIMEOUT = {'dtc': '0xD0 0x5B 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD2_MESSAGE_TIMEOUT', 'req': 36070371,
                  'text': 'HPCAD Message Timeout (FLTMONR_E_HPCAD_MESSAGE_TIMEOUT)'}
HPCAD3_TIMEOUT = {'dtc': '0xD0 0x5B 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD3_MESSAGE_TIMEOUT', 'req': 36070391,
                  'text': 'HPCAD Message Timeout (FLTMONR_E_HPCAD_MESSAGE_TIMEOUT)'}
HPCAD4_TIMEOUT = {'dtc': '0xD0 0x5B 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD4_MESSAGE_TIMEOUT', 'req': 36070392,
                  'text': 'HPCAD Message Timeout (FLTMONR_E_HPCAD_MESSAGE_TIMEOUT)'}
SYNC_F_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 3; dematuration: 1', 'latched': False, 'monitor': 'SYNC_F_MESSAGE_TIMEOUT',
                  'req': 36069749,
                  'text': 'Missing message for Sync_Message (TripResetSyncMessage frame). (FLTMONR_E_ECU_INTERNAL)'}
VCU1_TIMEOUT = {'dtc': '0xD0 0x54 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'VCU1_MESSAGE_TIMEOUT', 'req': 36070331,
                'text': 'VCU Message Timeout (FLTMONR_E_VCU_MESSAGE_TIMEOUT)'}
VCU2_TIMEOUT = {'dtc': '0xD0 0x54 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'VCU2_MESSAGE_TIMEOUT', 'req': 36070393,
                'text': 'VCU Message Timeout (FLTMONR_E_VCU_MESSAGE_TIMEOUT)'}
E2E_PIB_CRC = {'dtc': '0x90 0x13 0x49', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': True,
               'monitor': 'F_E2E_PIB_CRC_MISMATCH', 'req': 36069751,
               'text': ('Error detected due to mismatch between CRC received via E2E frame and the CRC calcualted '
                        'based on E2E payload data. (FLTMONR_E_ECU_INTERNAL)')}
EPS1_CRC = {'dtc': '0xE7 0x25 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'EPS1_FD_CRC_MISMATCH', 'req': 36070345,
            'text': 'EPS1_FD_10(0x13A) CRC mismatch (FLTMONR_E_EPS1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FR_ZONE2_CRC = {'dtc': '0xE7 0x1C 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'FR_ZONE2_CRC_MISMATCH', 'req': 36070387,
                'text': 'FR_ZONE2_100(0x319) CRC mismatch (FLTMONR_E_FR_ZONE2_100_MESSAGE_CONTENT_FAILURE)'}
FR_ZONE3_CRC = {'dtc': '0xE7 0x24 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'FR_ZONE3_CRC_MISMATCH', 'req': 36070337,
                'text': 'FR_ZONE3_100(0x31A) CRC mismatch (FLTMONR_E_FR_ZONE3_100_MESSAGE_CONTENT_FAILURE)'}
HPCAD1_CRC = {'dtc': '0xE7 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_1_FD_CRC_MISMATCH', 'req': 36070374,
              'text': 'HPCAD1_FD_10 (0x13E) CRC mismatch (FLTMONR_E_HPCAD_1_10_MESSAGE_CONTENT_FAILURE)'}
HPCAD2_CRC = {'dtc': '0xE7 0x32 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_2_FD_CRC_MISMATCH', 'req': 36070376,
              'text': 'HPCAD2_FD_50 (0x2AF) CRC mismatch (FLTMONR_E_HPCAD_2_50_MESSAGE_CONTENT_FAILURE)'}
HPCAD3_CRC = {'dtc': '0xE7 0x1E 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_3_FD_CRC_MISMATCH', 'req': 36070378,
              'text': 'HPCAD3_FD_50 (0x2B1) CRC mismatch (FLTMONR_E_HPCAD_3_50_MESSAGE_CONTENT_FAILURE)'}
HPCAD4_CRC = {'dtc': '0xE7 0x29 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_4_FD_CRC_MISMATCH', 'req': 36070380,
              'text': 'HPCAD4_FD_10 (0x13F) CRC mismatch (FLTMONR_E_HPCAD_4_10_MESSAGE_CONTENT_FAILURE)'}
HPCC1_CRC = {'dtc': '0xE7 0x1F 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
             'monitor': 'HPCC_1_CRC_MISMATCH', 'req': 36070384,
             'text': 'HPCC_1_100 (0x318) DLC mismatch (FLTMONR_E_HPCC_1_100_MESSAGE_CONTENT_FAILURE)'}
IEB1_CRC = {'dtc': '0xE7 0x20 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'IEB1_FD_CRC_MISMATCH', 'req': 36070342,
            'text': 'IEB1_FD_10 (0x13B) CRC mismatch (FLTMONR_E_IEB1_FD_10_MESSAGE_CONTENT_FAILURE)'}
OCS1_CRC = {'dtc': '0xE7 0x61 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'OCS1_CRC_MISMATCH', 'req': 36070399,
            'text': 'OCS1_500(0x5FF) CRC mismatch (FLTMONR_E_OCS1_500_MESSAGE_CONTENT_FAILURE)'}
VCU11_CRC = {'dtc': '0xE7 0x26 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
             'monitor': 'VCU11_FD_CRC_MISMATCH', 'req': 36070382,
             'text': 'VCU11_FD_10(0x16E) CRC mismatch (FLTMONR_E_VCU11_FD_10_MESSAGE_CONTENT_FAILURE)'}
VCU1_CRC = {'dtc': '0xE7 0x22 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'VCU1_FD_CRC_MISMATCH', 'req': 36070348,
            'text': 'VCU1_FD_20 (0x207) CRC mismatch (FLTMONR_E_VCU1_FD_20_MESSAGE_CONTENT_FAILURE)'}
VCU2_CRC = {'dtc': '0xE7 0x23 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'VCU2_FD_CRC_MISMATCH', 'req': 36070351,
            'text': 'VCU2_FD_100 (0x30E) CRC mismatch (FLTMONR_E_VCU2_FD_100_MESSAGE_CONTENT_FAILURE)'}
EPS1_DLC = {'dtc': '0xE7 0x25 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'EPS1_FD_DLC_MISMATCH', 'req': 36070344,
            'text': 'EPS1_FD_10(0x13A) DLC mismatch (FLTMONR_E_EPS1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FR_ZONE2_DLC = {'dtc': '0xE7 0x1C 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'FR_ZONE2_DLC_MISMATCH', 'req': 36070386,
                'text': 'FR_ZONE2_100(0x319) DLC mismatch (FLTMONR_E_FR_ZONE2_100_MESSAGE_CONTENT_FAILURE)'}
FR_ZONE3_DLC = {'dtc': '0xE7 0x24 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'FR_ZONE3_DLC_MISMATCH', 'req': 36070336,
                'text': 'FR_ZONE3_100(0x31A) DLC mismatch (FLTMONR_E_FR_ZONE3_100_MESSAGE_CONTENT_FAILURE)'}
HPCAD1_DLC = {'dtc': '0xE7 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_1_FD_DLC_MISMATCH', 'req': 36070356,
              'text': 'HPCAD1_FD_10 (0x13E) DLC mismatch (FLTMONR_E_HPCAD_1_10_MESSAGE_CONTENT_FAILURE)'}
HPCAD2_DLC = {'dtc': '0xE7 0x32 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_2_FD_DLC_MISMATCH', 'req': 36070357,
              'text': 'HPCAD2_FD_50 (0x2AF) DLC mismatch (FLTMONR_E_HPCAD_2_50_MESSAGE_CONTENT_FAILURE)'}
HPCAD3_DLC = {'dtc': '0xE7 0x1E 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_3_FD_DLC_MISMATCH', 'req': 36070358,
              'text': 'HPCAD3_FD_50 (0x2B1) DLC mismatch (FLTMONR_E_HPCAD_3_50_MESSAGE_CONTENT_FAILURE)'}
HPCAD4_DLC = {'dtc': '0xE7 0x29 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
              'monitor': 'HPCAD_4_FD_DLC_MISMATCH', 'req': 36070359,
              'text': 'HPCAD4_FD_10 (0x13F) DLC mismatch (FLTMONR_E_HPCAD_4_10_MESSAGE_CONTENT_FAILURE)'}
HPCC1_DLC = {'dtc': '0xE7 0x1F 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
             'monitor': 'HPCC_1_DLC_MISMATCH', 'req': 36070340,
             'text': 'HPCC_1_100 (0x318) DLC mismatch (FLTMONR_E_HPCC_1_100_MESSAGE_CONTENT_FAILURE)'}
IEB1_DLC = {'dtc': '0xE7 0x20 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'IEB1_FD_DLC_MISMATCH', 'req': 36070341,
            'text': 'IEB1_FD_10 (0x13B) DLC mismatch (FLTMONR_E_IEB1_FD_10_MESSAGE_CONTENT_FAILURE)'}
OCS1_DLC = {'dtc': '0xE7 0x61 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'OCS1_DLC_MISMATCH', 'req': 36070398,
            'text': 'OCS1_500(0x5FF) DLC mismatch (FLTMONR_E_OCS1_500_MESSAGE_CONTENT_FAILURE)'}
VCU11_DLC = {'dtc': '0xE7 0x26 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
             'monitor': 'VCU11_FD_DLC_MISMATCH', 'req': 36070339,
             'text': 'VCU11_FD_10(0x16E) DLC mismatch (FLTMONR_E_VCU11_FD_10_MESSAGE_CONTENT_FAILURE)'}
VCU1_DLC = {'dtc': '0xE7 0x22 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'VCU1_FD_DLC_MISMATCH', 'req': 36070347,
            'text': 'VCU1_FD_20 (0x207) DLC mismatch (FLTMONR_E_VCU1_FD_20_MESSAGE_CONTENT_FAILURE)'}
VCU2_DLC = {'dtc': '0xE7 0x23 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'VCU2_FD_DLC_MISMATCH', 'req': 36070350,
            'text': 'VCU2_FD_100 (0x30E) DLC mismatch (FLTMONR_E_VCU2_FD_100_MESSAGE_CONTENT_FAILURE)'}
VCU4_DLC = {'dtc': '0xE7 0x27 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
            'monitor': 'VCU4_FD_DLC_MISMATCH', 'req': 36070389,
            'text': 'VCU4_FD_100 (0x30E) DLC mismatch (FLTMONR_E_VCU4_FD_100_MESSAGE_CONTENT_FAILURE)'}
EPS1_COUNTER = {'dtc': '0xE7 0x25 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'EPS1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070346,
                'text': 'EPS1_FD_10(0x13A) Alive counter mismatch (FLTMONR_E_EPS1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FR_ZONE2_COUNTER = {'dtc': '0xE7 0x1C 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                    'monitor': 'FR_ZONE2_ALIVECOUNTER_MISMATCH', 'req': 36070388,
                    'text': ('FR_ZONE2_100(0x319) Alive counter mismatch '
                             '(FLTMONR_E_FR_ZONE2_100_MESSAGE_CONTENT_FAILURE)')}
FR_ZONE3_COUNTER = {'dtc': '0xE7 0x24 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                    'monitor': 'FR_ZONE3_ALIVECOUNTER_MISMATCH', 'req': 36070338,
                    'text': ('FR_ZONE3_100(0x31A) Alive counter mismatch '
                             '(FLTMONR_E_FR_ZONE3_100_MESSAGE_CONTENT_FAILURE)')}
HPCAD1_COUNTER = {'dtc': '0xE7 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD_1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070375,
                  'text': ('HPCAD1_FD_10 (0x13E) ALIVECOUNTER mismatch '
                           '(FLTMONR_E_HPCAD_1_10_MESSAGE_CONTENT_FAILURE)')}
HPCAD2_COUNTER = {'dtc': '0xE7 0x32 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD_2_FD_ALIVECOUNTER_MISMATCH', 'req': 36070377,
                  'text': ('HPCAD2_FD_50 (0x2AF) ALIVECOUNTER mismatch '
                           '(FLTMONR_E_HPCAD_2_50_MESSAGE_CONTENT_FAILURE)')}
HPCAD3_COUNTER = {'dtc': '0xE7 0x1E 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD_3_FD_ALIVECOUNTER_MISMATCH', 'req': 36070379,
                  'text': ('HPCAD3_FD_50 (0x2B1) ALIVECOUNTER mismatch '
                           '(FLTMONR_E_HPCAD_3_50_MESSAGE_CONTENT_FAILURE)')}
HPCAD4_COUNTER = {'dtc': '0xE7 0x29 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                  'monitor': 'HPCAD_4_FD_ALIVECOUNTER_MISMATCH', 'req': 36070381,
                  'text': ('HPCAD4_FD_10 (0x13F) ALIVECOUNTER mismatch '
                           '(FLTMONR_E_HPCAD_4_10_MESSAGE_CONTENT_FAILURE)')}
HPCC1_COUNTER = {'dtc': '0xE7 0x1F 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCC_1_ALIVECOUNTER_MISMATCH', 'req': 36070385,
                 'text': 'HPCC_1_100 (0x318) DLC mismatch (FLTMONR_E_HPCC_1_100_MESSAGE_CONTENT_FAILURE)'}
IEB1_COUNTER = {'dtc': '0xE7 0x20 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'IEB1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070343,
                'text': 'IEB1_FD_10 (0x13B) Alive counter mismatch (FLTMONR_E_IEB1_FD_10_MESSAGE_CONTENT_FAILURE)'}
OCS1_COUNTER = {'dtc': '0xE7 0x61 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'OCS1_ALIVECOUNTER_MISMATCH', 'req': 36070400,
                'text': 'OCS1_500(0x5FF) Alive counter mismatch (FLTMONR_E_OCS1_500_MESSAGE_CONTENT_FAILURE)'}
VCU11_COUNTER = {'dtc': '0xE7 0x26 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'VCU11_FD_ALIVECOUNTER_MISMATCH', 'req': 36070383,
                 'text': 'VCU11_FD_10(0x16E) ALIVECOUNTER mismatch (FLTMONR_E_VCU11_FD_10_MESSAGE_CONTENT_FAILURE)'}
VCU1_COUNTER = {'dtc': '0xE7 0x22 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'VCU1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070349,
                'text': 'VCU1_FD_20 (0x207) Alive counter mismatch (FLTMONR_E_VCU1_FD_20_MESSAGE_CONTENT_FAILURE)'}
VCU2_COUNTER = {'dtc': '0xE7 0x23 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'VCU2_FD_ALIVECOUNTER_MISMATCH', 'req': 36070352,
                'text': ('VCU2_FD_100 (0x30E) Alive counter mismatch '
                         '(FLTMONR_E_VCU2_FD_100_MESSAGE_CONTENT_FAILURE)')}
FL_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD6 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'FL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070365,
                        'text': ('FL Tyre pressure Signal Content Error '
                                 '(FLTMONR_E_FL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
FR_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD7 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'FR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070368,
                        'text': ('FR Tyre Pressure Signal Content Error '
                                 '(FLTMONR_E_FR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
GEAR_ACTUAL_SCF = {'dtc': '0xE1 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'GEAR_ACTUAL_SIGNAL_CONTENT_FAILURE', 'req': 36070362,
                   'text': 'GEAR_ACTUAL signal Content Failure (FLTMONR_E_GEAR_ACTUAL_SIGNAL_CONTENT_FAILURE)'}
MASTER_CYL_PRESSURE_SCF = {'dtc': '0xE1 0x8D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                           'monitor': 'MASTER_CYL_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070364,
                           'text': ('Master cycle pressure Signal Content Error '
                                    '(FLTMONR_E_MASTER_CYL_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
MOTOR_SPEED_SCF = {'dtc': '0xE1 0x5F 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: NA; dematuration: NA', 'latched': False,
                   'monitor': 'MOTOR_SPD_SIGNAL_CONTENT_FAILURE', 'req': 36073809,
                   'text': 'MOTOR_SPD Signal Content Failure (FLTMONR_E_MOTOR_SPD_SIGNAL_CONTENT_FAILURE)'}
ODOMETER_SCF = {'dtc': '0xE0 0x12 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'ODOMTR_READING_IS_SIGNAL_CONTENT_FAILURE', 'req': 36070363,
                'text': ('ODOMTR_READING_IS Signal Content Failure '
                         '(FLTMONR_E_ODOMTR_READING_IS_SIGNAL_CONTENT_FAILURE)')}
RL_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD8 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'RL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070366,
                        'text': ('RL Tyre Pressure Signal Content Error '
                                 '(FLTMONR_E_RL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
RR_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD9 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'RR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070367,
                        'text': ('RR Tyre Pressure Signal Content Error '
                                 '(FLTMONR_E_RR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
STEERING_ANGLE_SCF = {'dtc': '0xE0 0x58 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'STEERING_ABSOLUTE_ANGLE_SIGNAL_CONTENT_FAILURE', 'req': 36070369,
                      'text': ('Steering Absolute Angle Signal Content Error '
                               '(FLTMONR_E_STEERING_ABSOLUTE_ANGLE_SIGNAL_CONTENT_FAILURE)')}
STEER_ANGLE_CMD_SCF = {'dtc': '0xE1 0x77 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                       'monitor': 'ADAS_DES_STRWHL_ANGLE_CMD_SIGNAL_CONTENT_FAILURE', 'req': 36070361,
                       'text': ('ADAS_DES_STRWHL_ANGLE_CMD Signal Content Error '
                                '(FLTMONR_E_ADAS_DES_STRWHL_ANGLE_SIGNAL_CONTENT_FAILURE)')}
VEHICLE_SPEED_SCF = {'dtc': '0xE0 0x13 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'VEHICLE_SPEED_SIGNAL_CONTENT_FAILURE', 'req': 36070327,
                     'text': 'Vehicle Speed Signal Content Error (FLTMONR_E_VEHICLE_SPEED_SIGNAL_CONTENT_FAILURE)'}
VEHICLE_STATE_SCF = {'dtc': '0xE1 0x79 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'VEHICLE_STATE_SIGNAL_CONTENT_FAILURE', 'req': 36070370,
                     'text': 'Vehicle state Signal Content Error (FLTMONR_E_VEHICLE_STATE_SIGNAL_CONTENT_FAILURE)'}

CAN_FAULTS = {
    'ECALL_NODE_ABSENT': ECALL_NODE_ABSENT,
    'EPS_NODE_ABSENT': EPS_NODE_ABSENT,
    'FR_ZONE_NODE_ABSENT': FR_ZONE_NODE_ABSENT,
    'HPCAD_NODE_ABSENT': HPCAD_NODE_ABSENT,
    'HPCC_NODE_ABSENT': HPCC_NODE_ABSENT,
    'IEB_NODE_ABSENT': IEB_NODE_ABSENT,
    'OCS_NODE_ABSENT': OCS_NODE_ABSENT,
    'VCU_NODE_ABSENT': VCU_NODE_ABSENT,
    'FR_ZONE_TIMEOUT': FR_ZONE_TIMEOUT,
    'HPCAD2_TIMEOUT': HPCAD2_TIMEOUT,
    'HPCAD3_TIMEOUT': HPCAD3_TIMEOUT,
    'HPCAD4_TIMEOUT': HPCAD4_TIMEOUT,
    'SYNC_F_TIMEOUT': SYNC_F_TIMEOUT,
    'VCU1_TIMEOUT': VCU1_TIMEOUT,
    'VCU2_TIMEOUT': VCU2_TIMEOUT,
    'E2E_PIB_CRC': E2E_PIB_CRC,
    'EPS1_CRC': EPS1_CRC,
    'FR_ZONE2_CRC': FR_ZONE2_CRC,
    'FR_ZONE3_CRC': FR_ZONE3_CRC,
    'HPCAD1_CRC': HPCAD1_CRC,
    'HPCAD2_CRC': HPCAD2_CRC,
    'HPCAD3_CRC': HPCAD3_CRC,
    'HPCAD4_CRC': HPCAD4_CRC,
    'HPCC1_CRC': HPCC1_CRC,
    'IEB1_CRC': IEB1_CRC,
    'OCS1_CRC': OCS1_CRC,
    'VCU11_CRC': VCU11_CRC,
    'VCU1_CRC': VCU1_CRC,
    'VCU2_CRC': VCU2_CRC,
    'EPS1_DLC': EPS1_DLC,
    'FR_ZONE2_DLC': FR_ZONE2_DLC,
    'FR_ZONE3_DLC': FR_ZONE3_DLC,
    'HPCAD1_DLC': HPCAD1_DLC,
    'HPCAD2_DLC': HPCAD2_DLC,
    'HPCAD3_DLC': HPCAD3_DLC,
    'HPCAD4_DLC': HPCAD4_DLC,
    'HPCC1_DLC': HPCC1_DLC,
    'IEB1_DLC': IEB1_DLC,
    'OCS1_DLC': OCS1_DLC,
    'VCU11_DLC': VCU11_DLC,
    'VCU1_DLC': VCU1_DLC,
    'VCU2_DLC': VCU2_DLC,
    'VCU4_DLC': VCU4_DLC,
    'EPS1_COUNTER': EPS1_COUNTER,
    'FR_ZONE2_COUNTER': FR_ZONE2_COUNTER,
    'FR_ZONE3_COUNTER': FR_ZONE3_COUNTER,
    'HPCAD1_COUNTER': HPCAD1_COUNTER,
    'HPCAD2_COUNTER': HPCAD2_COUNTER,
    'HPCAD3_COUNTER': HPCAD3_COUNTER,
    'HPCAD4_COUNTER': HPCAD4_COUNTER,
    'HPCC1_COUNTER': HPCC1_COUNTER,
    'IEB1_COUNTER': IEB1_COUNTER,
    'OCS1_COUNTER': OCS1_COUNTER,
    'VCU11_COUNTER': VCU11_COUNTER,
    'VCU1_COUNTER': VCU1_COUNTER,
    'VCU2_COUNTER': VCU2_COUNTER,
    'FL_TYRE_PRESSURE_SCF': FL_TYRE_PRESSURE_SCF,
    'FR_TYRE_PRESSURE_SCF': FR_TYRE_PRESSURE_SCF,
    'GEAR_ACTUAL_SCF': GEAR_ACTUAL_SCF,
    'MASTER_CYL_PRESSURE_SCF': MASTER_CYL_PRESSURE_SCF,
    'MOTOR_SPEED_SCF': MOTOR_SPEED_SCF,
    'ODOMETER_SCF': ODOMETER_SCF,
    'RL_TYRE_PRESSURE_SCF': RL_TYRE_PRESSURE_SCF,
    'RR_TYRE_PRESSURE_SCF': RR_TYRE_PRESSURE_SCF,
    'STEERING_ANGLE_SCF': STEERING_ANGLE_SCF,
    'STEER_ANGLE_CMD_SCF': STEER_ANGLE_CMD_SCF,
    'VEHICLE_SPEED_SCF': VEHICLE_SPEED_SCF,
    'VEHICLE_STATE_SCF': VEHICLE_STATE_SCF,
}


# ====================================================================================================
# Power, ECU and internal faults (158)
# Supply, VIN, variant code, bus-off, plant mode and every internal fault monitor (most share DTC
# 0x90 0x13 0x49, ECU internal), named <module>_<monitor>.
# ====================================================================================================
ALGO_FRONT_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                         'monitor': 'OPSCSHMGR_F_OPS_FRNTALG_SUPPRESSED', 'req': 36070217,
                         'text': 'OPS Front Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
ALGO_FRONT_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                'monitor': 'OPSCSHMGR_F_OPS_FRNTALG_UNCONFIRMED_CRASH', 'req': 36070211,
                                'text': 'OPS Front Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
ALGO_PEDESTRIAN_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                              'monitor': 'OPSCSHMGR_F_OPS_PEDALG_SUPPRESSED', 'req': 36070222,
                              'text': 'OPS Pedestrian Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
ALGO_PEDESTRIAN_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                     'monitor': 'OPSCSHMGR_F_OPS_PEDALG_UNCONFIRMED_CRASH', 'req': 36070216,
                                     'text': 'OPS Pedestrian Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
ALGO_REAR_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                        'monitor': 'OPSCSHMGR_F_OPS_REALG_SUPPRESSED', 'req': 36070218,
                        'text': 'OPS Rear Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
ALGO_REAR_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                               'monitor': 'OPSCSHMGR_F_OPS_REALG_UNCONFIRMED_CRASH', 'req': 36070212,
                               'text': 'OPS Rear Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
ALGO_ROLL_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                        'monitor': 'OPSCSHMGR_F_OPS_ROLLALG_SUPPRESSED', 'req': 36070221,
                        'text': 'OPS Roll Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
ALGO_ROLL_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                               'monitor': 'OPSCSHMGR_F_OPS_ROLLALG_UNCONFIRMED_CRASH', 'req': 36070215,
                               'text': 'OPS Roll Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
ALGO_SIDE_LEFT_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                             'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_LEFT_SUPPRESSED', 'req': 36070219,
                             'text': 'OPS Side Left Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
ALGO_SIDE_LEFT_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                    'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                    'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_LEFT_UNCONFIRMED_CRASH', 'req': 36070213,
                                    'text': ('OPS Side Left Part Algorithm Unconfirmed Crash '
                                             '(FLTMONR_E_ECU_INTERNAL)')}
ALGO_SIDE_RIGHT_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                              'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_RIGHT_SUPPRESSED', 'req': 36070220,
                              'text': 'OPS Side Right Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
ALGO_SIDE_RIGHT_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                     'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_RIGHT_UNCONFIRMED_CRASH', 'req': 36070214,
                                     'text': ('OPS Side Right Part Algorithm Unconfirmed Crash '
                                              '(FLTMONR_E_ECU_INTERNAL)')}
ASIC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
          'timing': ('maturation: 127 retries (NVM CRC not ok or NVM_Ready bit is not completed) 15 retries (NVM '
                     'USER CRC fails or NVM USER DATA from ASIC_NVM is different than the programmed NVM USER '
                     'DATA); dematuration: n/a'),
          'latched': True, 'monitor': 'ASICCTRL_F_ASIC_NVM_0', 'req': 36068941,
          'text': 'ASICCTRLL NVM Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
          'timing': ('maturation: 127 retries (NVM CRC not ok or NVM_Ready bit is not completed) 15 retries (NVM '
                     'USER CRC fails or NVM USER DATA from ASIC_NVM is different than the programmed NVM USER '
                     'DATA); dematuration: n/a'),
          'latched': True, 'monitor': 'ASICCTRL_F_ASIC_NVM_1', 'req': 36068951,
          'text': 'ASICCTRLL NVM Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_BACKGROUND_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 3.175; dematuration: n/a', 'latched': True,
                     'monitor': 'ASICCTRL_F_ASIC_BACKGROUND_0', 'req': 36068942,
                     'text': 'ASICCTRLL Background Monitor Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_BACKGROUND_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 3.175; dematuration: n/a', 'latched': True,
                     'monitor': 'ASICCTRL_F_ASIC_BACKGROUND_1', 'req': 36068952,
                     'text': 'ASICCTRLL Background Monitor Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_BIST_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
               'monitor': 'ASICCTRL_F_ASIC_BIST_0', 'req': 36068943,
               'text': 'ASICCTRLL BIST Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_BIST_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
               'monitor': 'ASICCTRL_F_ASIC_BIST_1', 'req': 36068953,
               'text': 'ASICCTRLL BIST Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_CLK_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 127 retries (IDLE); dematuration: n/a',
              'latched': True, 'monitor': 'ASICCTRL_F_ASIC_CLK_0', 'req': 36068948,
              'text': 'ASICCTRLL Either FLL or CLKERR Failure SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_CLK_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 127 retries (IDLE); dematuration: n/a',
              'latched': True, 'monitor': 'ASICCTRL_F_ASIC_CLK_1', 'req': 36068958,
              'text': 'ASICCTRLL Either FLL or CLKERR Failure SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_CONFIG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                 'monitor': 'ASICCTRL_F_ASIC_CONFG_0', 'req': 36068949,
                 'text': 'ASICCTRLL Either DEVICE_CTRL or CLK_CTRL config failure SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_CONFIG_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                 'monitor': 'ASICCTRL_F_ASIC_CONFG_1', 'req': 36068959,
                 'text': 'ASICCTRLL Either DEVICE_CTRL or CLK_CTRL config failure SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_SAFETY_ECHO_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 0.075; dematuration: n/a', 'latched': True,
                      'monitor': 'ASICCTRL_F_SAFETY_ECHO_0', 'req': 36068947,
                      'text': ('ASICCTRLL Safety Echo deployment is disabled in the ASIC SB3_M '
                               '(FLTMONR_E_ECU_INTERNAL)')}
ASIC_SAFETY_ECHO_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 0.075; dematuration: n/a', 'latched': True,
                      'monitor': 'ASICCTRL_F_SAFETY_ECHO_1', 'req': 36068957,
                      'text': ('ASICCTRLL Safety Echo deployment is disabled in the ASIC SB3_S '
                               '(FLTMONR_E_ECU_INTERNAL)')}
ASIC_SERIAL_NO_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                    'monitor': 'ASICCTRL_F_ASIC_SERIAL_NO_0', 'req': 36068946,
                    'text': 'ASICCTRLL ASIC Serial Number Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_SERIAL_NO_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                    'monitor': 'ASICCTRL_F_ASIC_SERIAL_NO_1', 'req': 36068956,
                    'text': 'ASICCTRLL ASIC Serial Number Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': ('maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 0.0635 (IDLE) 3.175 (PDC, Drive); '
                         'dematuration: n/a'),
              'latched': True, 'monitor': 'ASICCTRL_F_ASIC_SPI_0', 'req': 36068940,
              'text': 'ASICCTRLL SPI Communication Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_SPI_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': ('maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 0.0635 (IDLE) 3.175 (PDC, Drive); '
                         'dematuration: n/a'),
              'latched': True, 'monitor': 'ASICCTRL_F_ASIC_SPI_1', 'req': 36068950,
              'text': 'ASICCTRLL SPI Communication Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_SSM_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: 127 retries (IDLE) 3.175 (PDC, Drive); dematuration: n/a', 'latched': True,
              'monitor': 'ASICCTRL_F_ASIC_SSM_0', 'req': 36068944,
              'text': 'ASICCTRLL ASIC SYSTEM STATE Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_SSM_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: 127 retries (IDLE) 3.175 (PDC, Drive); dematuration: n/a', 'latched': True,
              'monitor': 'ASICCTRL_F_ASIC_SSM_1', 'req': 36068954,
              'text': 'ASICCTRLL ASIC SYSTEM STATE Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
ASIC_VERSION_ID_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                     'monitor': 'ASICCTRL_F_ASIC_VERSION_ID_0', 'req': 36068945,
                     'text': 'ASICCTRLL ASIC Veresion ID Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
ASIC_VERSION_ID_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                     'monitor': 'ASICCTRL_F_ASIC_VERSION_ID_1', 'req': 36068955,
                     'text': 'ASICCTRLL ASIC Veresion ID Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
BATT_OVERVOLTAGE = {'dtc': '0x94 0x2A 0x17', 'qualify_ms': 3175, 'dequalify_ms': 3200, 'latched': False,
                    'monitor': 'SYSCHAR_F_PWR_BATT_OVER', 'req': 36069748,
                    'text': 'Battery Overvoltage (FLTMONR_E_BATTERY_VOLTAGE_HIGH)'}
BATT_UNDERVOLTAGE = {'dtc': '0x94 0x2A 0x16', 'qualify_ms': 3175, 'dequalify_ms': 3200, 'latched': False,
                     'monitor': 'SYSCHAR_F_PWR_BATT_UNDER', 'req': 36069747,
                     'text': 'Battery Undervoltage (FLTMONR_E_BATTERY_VOLTAGE_LOW)'}
CYBER_HSM_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.5; dematuration: n/a', 'latched': True,
                     'monitor': 'CYBER_F_HSM_TIMEOUT', 'req': 36070301,
                     'text': 'The maximum waiting time for the HSM response. (FLTMONR_E_ECU_INTERNAL)'}
DEPLOY_OPS_EVENT_WITHOUT_SAFING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': 'maturation: 0.04; dematuration: NA', 'latched': True,
                                   'monitor': 'DPLMTMGR_F_OPS_EVENT_WITHOUT_SAFING', 'req': 36070295,
                                   'text': 'Crash event occured without safing (FLTMONR_E_ECU_INTERNAL)'}
DEVICE_CFG_CFG_NO_STEER_WHEEL_POS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 1; dematuration: 1', 'latched': False,
                                     'monitor': 'DEVICECFGMGR_F_CFG_NO_STEER_WHEEL_POS', 'req': 36070198,
                                     'text': ('Steering Wheel Position not received (NVM read) '
                                              '(FLTMONR_E_ECU_INTERNAL)')}
E2E_PIB_COUNTER = {'dtc': '0x90 0x13 0x49', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': True,
                   'monitor': 'F_E2E_PIB_ALIVE_COUNTER', 'req': 36069750,
                   'text': ('Alive counter sync errors due to high delta difference between stored value and '
                            'received value of E2E alive counter (FLTMONR_E_ECU_INTERNAL)')}
ECU_CONFIG_ERROR = {'dtc': '0x92 0x02 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 0.0025; dematuration: N/A', 'latched': False,
                    'monitor': 'ECU_CONFIGURATION_ERROR', 'req': 36070324,
                    'text': 'ECU Configuration Error related fault (FLTMONR_E_ECU_CONFIGURATION_ERROR)'}
EDR_LOCKED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None, 'timing': 'maturation: N/A; dematuration: N/A',
              'latched': False, 'monitor': 'RSTEDR_F_EDR_LOCKED_EVENT', 'req': 36070256,
              'text': 'A locked Event Data Record is located in NVM (FLTMONR_NO_DTC_EVENT)'}
EVENT_TRAP = {'dtc': '0xFF 0xFF 0xFF', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Qualification time; dematuration: Infinite', 'latched': False,
              'monitor': 'FLTMONR_E_EVENT_0_TRAP', 'req': 36068900, 'text': '(DEM_EVENT_INVALID)'}
EXT_FLASH_BROKEN_POLLING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Calibration specific; dematuration: NA', 'latched': True,
                            'monitor': 'EXTFLS_F_BROKEN_POLLING', 'req': 36070156,
                            'text': 'Job timeout nonrecoverable (FLTMONR_E_ECU_INTERNAL)'}
EXT_FLASH_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: immediate; dematuration: immediate', 'latched': True,
                     'monitor': 'EXTFLS_F_COMPARE', 'req': 36070158,
                     'text': 'Write Integrity check failed (if check enabled) (FLTMONR_E_ECU_INTERNAL)'}
EXT_FLASH_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: NA; dematuration: NA', 'latched': True, 'monitor': 'EXTFLS_F_INTERNAL',
                      'req': 36070155,
                      'text': ('Init write capability test failed, device busy at power on, SPI request rejected '
                               '(FLTMONR_E_ECU_INTERNAL)')}
EXT_FLASH_INVALID_DEVICE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                            'monitor': 'EXTFLS_F_INVALID_DEVICE', 'req': 36070154,
                            'text': 'Init wrong device identification (calib vs read) (FLTMONR_E_ECU_INTERNAL)'}
EXT_FLASH_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: 0.001 (Write Timeout) 0.3 (Sector Erase Timeout) 0.5 (Block Erase '
                                'Timeout) 24 (Chip Erase Timeout); dematuration: immediate'),
                     'latched': True, 'monitor': 'EXTFLS_F_TIMEOUT', 'req': 36070157,
                     'text': 'Job timeout recoverable (write/erase) (FLTMONR_E_ECU_INTERNAL)'}
FD_BUS_OFF = {'dtc': '0xD2 0x06 0x00', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': ('maturation: Immediate; dematuration: Busoff fast recovery: 100 ms Bus off Slow recovery: '
                         '500 ms'),
              'latched': False, 'monitor': 'CAN_BUS_OFF_FAULT', 'req': 36070326,
              'text': 'SRS CAN Bus off fault (FLTMONR_E_CAN_BUS_OFF_FAULT)'}
FEE_ADMIN_BLK_NOT_FOUND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                           'monitor': 'FEE_F_NVM_ADMIN_BLK_NOT_FOUND', 'req': 36070201,
                           'text': 'Header blocks are not programed (FLTMONR_E_ECU_INTERNAL)'}
FEE_CORRUPTED_FLASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                       'monitor': 'FEE_F_NVM_CORRUPTED_FLASH', 'req': 36070202,
                       'text': 'Data sector is corrupted (ECC failure) (FLTMONR_E_ECU_INTERNAL)'}
FEE_ENDURANCE_LIMIT_EXCEED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                              'monitor': 'FEE_F_NVM_ENDURANCE_LIMIT_EXCEED', 'req': 36070204,
                              'text': 'Flash Programming limit exceeded failure (FLTMONR_E_ECU_INTERNAL)'}
FEE_ERASE_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.0015; dematuration: Successful "Erase" Routine', 'latched': True,
                     'monitor': 'FEE_F_NVM_ERASE_FAILURE', 'req': 36070205,
                     'text': 'Flash Erase Block failure (FLTMONR_E_ECU_INTERNAL)'}
FEE_OUT_OF_OPERATING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0015; dematuration: NA', 'latched': True,
                        'monitor': 'FEE_F_NVM_OUT_OF_OPERATING', 'req': 36070203,
                        'text': 'Word Line corruption (3 consecutive attempts) (FLTMONR_E_ECU_INTERNAL)'}
FEE_OUT_OF_ORDER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                    'monitor': 'FEE_F_NVM_OUT_OF_ORDER', 'req': 36070200,
                    'text': 'Fee general failure (multiple operations e.g. WL failures) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ENTER_PAGE_MODE_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                  'monitor': 'FLS_F_MEM_ENTER_PAGE_MODE_SEQUENCE', 'req': 36070137,
                                  'text': 'Wrong sequence order (access operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ENTER_PAGE_MODE_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 0.00001; dematuration: NA', 'latched': True,
                                 'monitor': 'FLS_F_MEM_ENTER_PAGE_MODE_TIMEOUT', 'req': 36070138,
                                 'text': ('Response was not acknowledged (access operations) '
                                          '(FLTMONR_E_ECU_INTERNAL)')}
FLASH_ERASE_FINISH_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 4.233; dematuration: NA', 'latched': True,
                              'monitor': 'FLS_F_MEM_ERASE_FINISH_TIMEOUT', 'req': 36070152,
                              'text': 'Response was not acknowledged (erase operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_PROTECTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                          'monitor': 'FLS_F_MEM_ERASE_PROTECTION', 'req': 36070144,
                          'text': ('Operations on protected flash sectors (erase operation) '
                                   '(FLTMONR_E_ECU_INTERNAL)')}
FLASH_ERASE_RESUME_PROTECTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                 'monitor': 'FLS_F_MEM_ERASE_RESUME_PROTECTION', 'req': 36070151,
                                 'text': ('Operations on protected flash sectors (resume erase operation) '
                                          '(FLTMONR_E_ECU_INTERNAL)')}
FLASH_ERASE_RESUME_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                               'monitor': 'FLS_F_MEM_ERASE_RESUME_SEQUENCE', 'req': 36070150,
                               'text': 'Wrong sequence order (suspend operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_RESUME_WRONG_STATE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                  'monitor': 'FLS_F_MEM_ERASE_RESUME_WRONG_DRIVER_STATE', 'req': 36070149,
                                  'text': 'Other operation ongoing (Start/Suspend) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                        'monitor': 'FLS_F_MEM_ERASE_SEQUENCE', 'req': 36070143,
                        'text': 'Wrong sequence order (erase operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_START_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.00001; dematuration: NA', 'latched': True,
                             'monitor': 'FLS_F_MEM_ERASE_START_TIMEOUT', 'req': 36070145,
                             'text': 'Response was not acknowledged (erase operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_START_WRONG_STATE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                 'monitor': 'FLS_F_MEM_ERASE_START_WRONG_DRIVER_STATE', 'req': 36070142,
                                 'text': 'Other operation ongoing (Suspend/Resume) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_SUSPEND_ERROR_FLAG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                  'monitor': 'FLS_F_MEM_ERASE_SUSPEND_ERROR_FLAG', 'req': 36070147,
                                  'text': 'Access failure (erase suspend operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_ERASE_SUSPEND_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.000375; dematuration: NA', 'latched': True,
                               'monitor': 'FLS_F_MEM_ERASE_SUSPEND_TIMEOUT', 'req': 36070148,
                               'text': ('Response was not acknowledged (suspend operations) '
                                        '(FLTMONR_E_ECU_INTERNAL)')}
FLASH_ERASE_SUSPEND_WRONG_STATE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                   'monitor': 'FLS_F_MEM_ERASE_SUSPEND_WRONG_DRIVER_STATE', 'req': 36070146,
                                   'text': 'Other operation ongoing (Start/Resume) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_MICROCODE_OPERATION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'FLS_F_MEM_MICROCODE_OPERATION', 'req': 36070153,
                             'text': ('Flash microcode failure (read/write/suspend/resume operations) '
                                      '(FLTMONR_E_ECU_INTERNAL)')}
FLASH_WRITE_PAGE_PROTECTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                               'monitor': 'FLS_F_MEM_WRITE_PAGE_PROTECTION', 'req': 36070140,
                               'text': ('Operations on protected flash sectors (write operation) '
                                        '(FLTMONR_E_ECU_INTERNAL)')}
FLASH_WRITE_PAGE_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'FLS_F_MEM_WRITE_PAGE_SEQUENCE', 'req': 36070139,
                             'text': 'Wrong sequence order (write operations) (FLTMONR_E_ECU_INTERNAL)'}
FLASH_WRITE_PAGE_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.000426; dematuration: NA', 'latched': True,
                            'monitor': 'FLS_F_MEM_WRITE_PAGE_TIMEOUT', 'req': 36070141,
                            'text': 'Response was not acknowledged (write operations) (FLTMONR_E_ECU_INTERNAL)'}
HSS_ASIC_ADC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                  'monitor': 'HSS_F_ASIC_ADC_0', 'req': 36069158,
                  'text': 'HSS ADC Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
HSS_ASIC_ADC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                  'monitor': 'HSS_F_ASIC_ADC_1', 'req': 36069159,
                  'text': 'HSS ADC Fault HSS1 (FLTMONR_E_ECU_INTERNAL)'}
HSS_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                  'monitor': 'HSS_F_ASIC_SPI_0', 'req': 36069156,
                  'text': 'HSS Spi Communication Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
HSS_ASIC_SPI_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                  'monitor': 'HSS_F_ASIC_SPI_1', 'req': 36069157,
                  'text': 'HSS Spi Communication Fault HSS1 (FLTMONR_E_ECU_INTERNAL)'}
HSS_DIODE_SHORT_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                     'monitor': 'HSS_F_DIODE_SHORT_0', 'req': 36069169,
                     'text': 'ER Diode is Shorted SB3_M (FLTMONR_E_ECU_INTERNAL)'}
HSS_DRIVE_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: PDC: 4 consecutive retries DRIVE: 2; dematuration: PDC: n/a DRIVE: 4',
               'latched': False, 'monitor': 'HSS_F_DRIVE_0', 'req': 36069162,
               'text': 'HSS Failed During DRIVE HSS0 (FLTMONR_E_ECU_INTERNAL)'}
HSS_DRIVE_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: PDC: 3 consecutive retries / DRIVE: 2; dematuration: PDC: n/a DRIVE: 4',
               'latched': False, 'monitor': 'HSS_F_DRIVE_1', 'req': 36069163,
               'text': 'HSS Failed During DRIVE HSS1 (FLTMONR_E_ECU_INTERNAL)'}
HSS_ER_DIODE_OPEN_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                       'monitor': 'HSS_F_ER_DIODE_OPEN_0', 'req': 36069166,
                       'text': 'HSS ER Diode Open Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
HSS_ER_DIODE_OPEN_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                       'monitor': 'HSS_F_ER_DIODE_OPEN_1', 'req': 36069167,
                       'text': 'HSS ER Diode Open Fault HSS (FLTMONR_E_ECU_INTERNAL)'}
HSS_PDC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
             'monitor': 'HSS_F_PDC_0', 'req': 36069160,
             'text': 'HSS Failed During PDC HSS0 (FLTMONR_E_ECU_INTERNAL)'}
HSS_PDC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
             'monitor': 'HSS_F_PDC_1', 'req': 36069161,
             'text': 'HSS Failed During PDC HSS1 (FLTMONR_E_ECU_INTERNAL)'}
HSS_VBAT_DIODE_OPEN_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                         'monitor': 'HSS_F_VBAT_DIODE_OPEN_0', 'req': 36069164,
                         'text': 'HSS VBAT Diode Open Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
HSS_VBAT_DIODE_OPEN_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                         'monitor': 'HSS_F_VBAT_DIODE_OPEN_1', 'req': 36069165,
                         'text': 'HSS VBAT Diode Open Fault HSS1 (FLTMONR_E_ECU_INTERNAL)'}
HSS_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
             'monitor': 'HSS_F_XCONN', 'req': 36069168,
             'text': 'HSS Both HS0/HSS1 Switches Are Cross Connexted (FLTMONR_E_ECU_INTERNAL)'}
HS_BUS_OFF = {'dtc': '0xD2 0x71 0x00', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': ('maturation: Immediate; dematuration: Busoff fast recovery: 100 ms Bus off Slow recovery: '
                         '500 ms'),
              'latched': False, 'monitor': 'HSCAN_BUS_OFF_FAULT', 'req': 36070372,
              'text': 'SRS HSCAN Bus off fault (FLTMONR_E_HSCAN_BUS_OFF_FAULT)'}
MANUFACTURING_DATA_MISSING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: N/A; dematuration: N/A', 'latched': True,
                              'monitor': 'MANUDATA_F_MANUFACTURING_DATA_MISSING', 'req': 36070306,
                              'text': 'Manufacturing Data is missing (FLTMONR_E_ECU_INTERNAL)'}
MCAL_ADC_NOT_OPERATIONAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                            'monitor': 'MCAL_F_MCAL_ADC_NOT_OPERATIONAL', 'req': 36070127,
                            'text': 'ADC is Not Operational (FLTMONR_E_ECU_INTERNAL)'}
MCAL_SPI_POLLING_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                            'monitor': 'MCAL_F_MCAL_SPI_POLLING_TIMEOUT', 'req': 36070126,
                            'text': 'SPI pooling timeout failure (FLTMONR_E_ECU_INTERNAL)'}
MCAL_SPI_RECEIVE_FIFO_OVERFLOW = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                  'monitor': 'MCAL_F_MCAL_SPI_RECEIVE_FIFO_OVERFLOW', 'req': 36070125,
                                  'text': 'SPI reception failure (overflow) (FLTMONR_E_ECU_INTERNAL)'}
MCAL_SPI_TRANSMIT_BUSY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                          'monitor': 'MCAL_F_MCAL_SPI_TRANSMIT_BUSY', 'req': 36070124,
                          'text': 'SPI transmission failure (busy) (FLTMONR_E_ECU_INTERNAL)'}
MCU_LBIST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: Immediate; dematuration: n/a', 'latched': True,
             'monitor': 'F_MCU_PRERUN_TEST_FAILED_LBIST', 'req': 36070302,
             'text': 'Fault to report the identified MCU logic path Failures. (FLTMONR_E_ECU_INTERNAL)'}
MCU_MBIST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: not given; dematuration: n/a', 'latched': True,
             'monitor': 'F_MCU_PRERUN_TEST_FAILED_MBIST', 'req': 36070304,
             'text': ('Fault to indicate the Failures detected during the last MBIST test run. '
                      '(FLTMONR_E_ECU_INTERNAL)')}
MCU_MONBIST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: not given; dematuration: n/a', 'latched': True,
               'monitor': 'F_MCU_PRERUN_TEST_FAILED_MONBIST', 'req': 36070303,
               'text': ('Fault to indicate the Failures detected during the last MONBIST test run. '
                        '(FLTMONR_E_ECU_INTERNAL)')}
NVM_BLOCK_BLOCK_INTEGRITY_FAILED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                    'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                    'monitor': 'NVMBLKMGR_F_BLOCK_INTEGRITY_FAILED', 'req': 36070210,
                                    'text': 'NVM Block Manager Integrity check Failure (FLTMONR_E_ECU_INTERNAL)'}
NVM_INTEGRITY = {'dtc': '0x90 0x13 0x49', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': True,
                 'monitor': 'NVM_F_NVM_INTEGRITY_FAILED', 'req': 36070209,
                 'text': 'Stored CRC does not match the computed CRC for the user data (FLTMONR_E_ECU_INTERNAL)'}
OPS_ROLL_MUTED_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: N/A; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_ROLL_MUTED_0', 'req': 36070253,
                    'text': 'OPS ARS invalid Roll data Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
PLANT_MODE = {'dtc': '0x92 0x00 0x00', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: immediate/less than 1 sec; dematuration: 30s', 'latched': False,
              'monitor': 'ECU_IN_PLANT_MODE', 'req': 36070328,
              'text': 'ECU in plant mode (FLTMONR_E_ECU_IN_PLANT_MODE)'}
PWR_ASIC_ADC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_ADC_0',
                  'req': 36069718,
                  'text': "Any SB3_M ADC Read that doesn't contain new data (FLTMONR_E_ECU_INTERNAL)"}
PWR_ASIC_ADC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_ADC_1',
                  'req': 36069736,
                  'text': "Any EX3_0 ADC Read that doesn't contain new data (FLTMONR_E_ECU_INTERNAL)"}
PWR_ASIC_CONFIG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.1; dematuration: n/a', 'latched': True,
                     'monitor': 'PWR_F_ASIC_CONFIG_0', 'req': 36070278,
                     'text': 'PWR ASIC Configuration Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ASIC_CONFIG_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.1; dematuration: n/a', 'latched': True,
                     'monitor': 'PWR_F_ASIC_CONFIG_1', 'req': 36070287,
                     'text': 'PWR ASIC Configuration Fault EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
PWR_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_SPI_0',
                  'req': 36069717,
                  'text': 'PWR ASIC SPI Communication Fault (Parity error) SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ASIC_SPI_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_SPI_1',
                  'req': 36069735,
                  'text': 'PWR ASIC SPI Communication Fault (Parity error) EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
PWR_CRITICAL_CONDITION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.0005; dematuration: n/a', 'latched': True,
                            'monitor': 'PWR_F_CRITICAL_CONDITION_0', 'req': 36070284,
                            'text': 'Power Critical Error Condition present SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ERBST_DIODE_LOST_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 0.025; dematuration: 0.025', 'latched': True,
                          'monitor': 'PWR_F_ERBST_DIODE_LOST_0', 'req': 36069734,
                          'text': 'ER Boost Diode Lost SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ERBST_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 1.075; dematuration: 0.025', 'latched': True,
                    'monitor': 'PWR_F_ERBST_TOO_HIGH_0', 'req': 36069720,
                    'text': 'ERBST is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ERBST_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: 1.075; dematuration: 0.025', 'latched': True,
                   'monitor': 'PWR_F_ERBST_TOO_LOW_0', 'req': 36069719,
                   'text': 'ERBST is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_CAPACITANCE_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 15 Drive; dematuration: 5', 'latched': True,
                            'monitor': 'PWR_F_ER_CAPACITANCE_TOO_LOW_0', 'req': 36069730,
                            'text': 'ER Capacitance is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_CAPACITANCE_TEST_FAILED_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                    'timing': 'maturation: 15; dematuration: 5', 'latched': True,
                                    'monitor': 'PWR_F_ER_CAPACITANCE_TEST_FAILED_0', 'req': 36070286,
                                    'text': ('ER Capacitance value cannot be computed SB3_M. '
                                             '(FLTMONR_E_ECU_INTERNAL)')}
PWR_ER_CAP_OPEN_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.05 PDC 3 to 8 Drive; dematuration: NA PDC 1 Drive', 'latched': True,
                     'monitor': 'PWR_F_ER_CAP_OPEN_0', 'req': 36069727,
                     'text': 'ER CAP is Open SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_CHARGE_SWITCH_SHORTED_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 0.075; dematuration: 0.025', 'latched': True,
                                  'monitor': 'PWR_F_ER_CHARGE_SWITCH_SHORTED_0', 'req': 36070281,
                                  'text': 'ER Charge Switch shorted SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_CHARGE_TIME_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 8.3; dematuration: n/a', 'latched': True,
                        'monitor': 'PWR_F_ER_CHARGE_TIME_0', 'req': 36070282,
                        'text': 'ER Charge Up Time is Exceeded SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_ESR_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 15 Drive; dematuration: 5', 'latched': False,
                     'monitor': 'PWR_F_ER_ESR_TOO_HIGH_0', 'req': 36069731,
                     'text': 'ER ESR is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_SHORT_GND_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: 0.06 to 0.08; dematuration: 0.06 to 0.08 when failure is absent just '
                                 'before the test 0.08 to 2 when failure is absent just after the test'),
                      'latched': True, 'monitor': 'PWR_F_ER_SHORT_GND_0', 'req': 36070283,
                      'text': 'ER Cap is Shorted to GND SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_SWITCH_NOT_OPERATIONAL_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': 'maturation: 0.15; dematuration: n/a', 'latched': True,
                                   'monitor': 'PWR_F_ER_SWITCH_NOT_OPERATIONAL_0', 'req': 36070280,
                                   'text': 'ER Switch Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_VOLTAGE_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.2; dematuration: 0.2', 'latched': True,
                         'monitor': 'PWR_F_ER_VOLTAGE_TOO_HIGH_0', 'req': 36069729,
                         'text': 'ER Voltage is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_ER_VOLTAGE_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.2; dematuration: 0.2', 'latched': True,
                        'monitor': 'PWR_F_ER_VOLTAGE_TOO_LOW_0', 'req': 36069728,
                        'text': 'ER Voltage is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_EX3_VIN_DISCONNECTED_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                              'monitor': 'PWR_F_EX3_VIN_DISCONNECTED_1', 'req': 36069740,
                              'text': 'VIN Disconnected EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
PWR_GROUND_LOSS_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.075; dematuration: 0.05', 'latched': True,
                     'monitor': 'PWR_F_GROUND_LOSS_0', 'req': 36069732,
                     'text': 'Ground Loss(VCC, SatBuck and ERBoost Ground Loss) SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_REDUNDANT_VER_FAILURE_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                               'monitor': 'PWR_F_REDUNDANT_VER_FAILURE_0', 'req': 36069733,
                               'text': 'Redundant VER (PWR / DCS) is inconsistent SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_SATBUCK_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                      'monitor': 'PWR_F_SATBUCK_TOO_HIGH_0', 'req': 36069723,
                      'text': 'SATBUCK is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_SATBUCK_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                     'monitor': 'PWR_F_SATBUCK_TOO_LOW_0', 'req': 36069722,
                     'text': 'SATBUCK is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_SYSBST_DIODE_SHORT_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.15; dematuration: n/a', 'latched': True,
                            'monitor': 'PWR_F_SYSBST_DIODE_SHORT_0', 'req': 36070279,
                            'text': 'SYSBST Diode is in Short_Circuit mode SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_SYSBST_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                    'monitor': 'PWR_F_SYSBST_TOO_LOW_0', 'req': 36069721,
                    'text': 'SYSBST is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_SYSBST_LOW_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                    'monitor': 'PWR_F_SYSBST_TOO_LOW_1', 'req': 36069737,
                    'text': 'SYSBST is too low EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
PWR_V5_OUT_RANGE_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                      'monitor': 'PWR_F_V5_OUT_RANGE_0', 'req': 36069724,
                      'text': 'V5 Supply is Out Of Range SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_VSYNC_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                   'monitor': 'PWR_F_VSYNC_TOO_LOW_0', 'req': 36069725,
                   'text': 'VSYNC is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
PWR_VSYNC_LOW_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                   'monitor': 'PWR_F_VSYNC_TOO_LOW_1', 'req': 36069738,
                   'text': 'VSYNC is too low EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
RESET_UNEXPECTED_RESET = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Immediate; dematuration: n/a', 'latched': True,
                          'monitor': 'RESETDRVR_F_ECU_UNEXPECTED_RESET', 'req': 36070289,
                          'text': 'Unexpected reset occured (FLTMONR_E_ECU_INTERNAL)'}
SAFING_ARMING_LONG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 30; dematuration: n/a', 'latched': True,
                        'monitor': 'SAF_F_ARMING_TOO_LONG_0', 'req': 36069710,
                        'text': 'SAFING System is armed for too long SB3_M (FLTMONR_E_ECU_INTERNAL)'}
SAFING_ASIC_CC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                    'monitor': 'SAF_F_ASIC_CC_0', 'req': 36069706,
                    'text': 'SAFING ASIC CC (Compare Complete) Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
SAFING_ASIC_CONFIG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                        'monitor': 'SAF_F_ASIC_CONFIG_0', 'req': 36069707,
                        'text': 'SAFING Programming ASIC registers failed SB3_M (FLTMONR_E_ECU_INTERNAL)'}
SAFING_ASIC_CONFIG_ENABLES_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                                'monitor': 'SAF_F_ASIC_CONFIG_ENABLES_0', 'req': 36069709,
                                'text': ('SAFING Programming ASIC registers failed (Enable registers) SB3_M '
                                         '(FLTMONR_E_ECU_INTERNAL)')}
SAFING_ASIC_CONFIG_FOC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                            'monitor': 'SAF_F_ASIC_CONFIG_FOC_0', 'req': 36069708,
                            'text': ('SAFING Programming ASIC registers failed (FOC registers) SB3_M '
                                     '(FLTMONR_E_ECU_INTERNAL)')}
SAFING_ASIC_INTERNAL_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                          'monitor': 'SAF_F_ASIC_INTERNAL_0', 'req': 36069713,
                          'text': ('SAFING ASIC Internal faut for incorrect communications (SA and D bits not '
                                   'correct in response) SB3_M (FLTMONR_E_ECU_INTERNAL)')}
SAFING_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': True,
                     'monitor': 'SAF_F_ASIC_SPI_0', 'req': 36069705,
                     'text': 'SAFING ASIC SPI Communication Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
SAFING_SNOOPING_SB3_EX3_TEST_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                                  'monitor': 'SAF_F_SNOOPING_SB3_EX3_TEST_0', 'req': 36069712,
                                  'text': ('SAFING Snoop Test betweeen SB3 and EX3 Failed SB3_M '
                                           '(FLTMONR_E_ECU_INTERNAL)')}
SCRAP_DEPLOYED = {'dtc': '0x92 0x13 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                  'monitor': 'SCRAPMGR_F_SCRAP_DEPLOYED_BY_SCRAP', 'req': 36073808,
                  'text': 'At least one loop was deployed by scrap (FLTMONR_E_LOOP_ENABLED_DUE_TO_VEHICLE_SCRAP)'}
SCRAP_ENTERED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                 'monitor': 'SCRAPMGR_F_SCRAP_ENTERED_SCRAP', 'req': 36070208,
                 'text': 'Scrap was entered at least once during ECU lifetime (FLTMONR_E_ECU_INTERNAL)'}
SMU_ALARM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': 'maturation: not given; dematuration: n/a', 'latched': True,
             'monitor': 'F_SMU_ALARM_OCCURRED', 'req': 36070305,
             'text': ('Fault to report that atleast one SMU_Alarm was active in the last Reset_Cycle which had the '
                      'NMI reaction. (FLTMONR_E_ECU_INTERNAL)')}
SYS_CFG_BLOCK_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.001; dematuration: NA', 'latched': True,
                         'monitor': 'SYSCHAR_F_ECU_CFG_BLOCK_FAILURE', 'req': 36070292,
                         'text': ('System Configuration Monitor Failure (Memory corruption) '
                                  '(FLTMONR_E_ECU_INTERNAL)')}
SYS_CONTROL_SHUTDOWN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.001; dematuration: NA', 'latched': True,
                        'monitor': 'SYSCHAR_F_ECU_CONTROL_SHUTDOWN', 'req': 36070290,
                        'text': 'Controlled Shutdown Monitor Failure (FLTMONR_E_ECU_INTERNAL)'}
SYS_MANUFACTURING_MODE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                          'monitor': 'SYSCHAR_F_ECU_MANUFACTURING_MODE', 'req': 36070294,
                          'text': 'ECU is in manufacturing mode (FLTMONR_E_ECU_INTERNAL)'}
SYS_MODE_POSTRUN_POWER_CONDITIONS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 30; dematuration: NA', 'latched': True,
                                     'monitor': 'SYSMODMGR_F_ECU_POSTRUN_POWER_CONDITIONS', 'req': 36070297,
                                     'text': 'POST_RUN state time exceeded (FLTMONR_E_ECU_INTERNAL)'}
SYS_MODE_SHUTDOWN_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: On event, not time based.; dematuration: On event, not time '
                                        'based.'),
                             'latched': True, 'monitor': 'SYSMODMGR_F_ECU_SHUTDOWN_FAILURE', 'req': 36070298,
                             'text': 'Shutdown Failure module can not shutdown (FLTMONR_E_ECU_INTERNAL)'}
SYS_PHASE_OF_LIFE_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'SYSCHAR_F_ECU_PHASE_OF_LIFE_FAILURE', 'req': 36070293,
                             'text': ('Mismatch between the two NVM blocks storing the ECU phase of life OR IP '
                                      'cals (IP and Algo Var 3 in SC2 case) not present while in Manufacturing '
                                      '(FLTMONR_E_ECU_INTERNAL)')}
SYS_PROVEOUT_TIME_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: 1', 'latched': True,
                             'monitor': 'SYSCHAR_F_ECU_PROVEOUT_TIME_FAILURE', 'req': 36070291,
                             'text': 'Proveout Monitor Failure (FLTMONR_E_ECU_INTERNAL)'}
TASK_STACK_LOW = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.075; dematuration: 0.075', 'latched': True,
                  'monitor': 'TASKMONR_F_TASK_STACK_TOO_LOW', 'req': 36069704,
                  'text': 'Any monitored stack is less than configurable minimum (FLTMONR_E_ECU_INTERNAL)'}
TASK_UNDERRUN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                 'monitor': 'TASKMONR_F_TASK_UNDERRUN', 'req': 36070199,
                 'text': 'Task did not run (FLTMONR_E_ECU_INTERNAL)'}
TRAP_EVENT_OCCURRED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                       'monitor': 'TRAPSMGR_F_TRAP_EVENT_OCCURRED', 'req': 36070206,
                       'text': 'SW event trap (FLTMONR_E_ECU_INTERNAL)'}
TRAP_UNEXPECTED_EXCEPTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'TRAPSMGR_F_TRAP_UNEXPECTED_EXCEPTION', 'req': 36070207,
                             'text': 'SW unexpected exception (FLTMONR_E_ECU_INTERNAL)'}
UNDERSTRIKE_CRASH = {'dtc': '0x92 0x52 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': True,
                     'monitor': 'UNDERSTRIKE_CRASH_EVENT', 'req': 36070390,
                     'text': 'UnderStrike Crash Event (FLTMONR_E_CRASH_DETECT_UNDERSTRIKE)'}
VARIANT_CODE_ERROR = {'dtc': '0xD5 0x06 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Based on network management Identifiers; dematuration: Based on '
                                 'network management Identifiers'),
                      'latched': False, 'monitor': 'SRS_VARIANT_CODE_ERROR', 'req': 36070329,
                      'text': 'Variant Code Error (FLTMONR_E_SRS_VARIANT_CODE_ERROR)'}
VIN_MISMATCH = {'dtc': '0xD3 0x06 0x00', 'qualify_ms': 6500, 'dequalify_ms': 3500, 'latched': True,
                'monitor': 'VIN_MISMATCH_ERROR', 'req': 36070325,
                'text': 'SRS VIN Mismatch (FLTMONR_E_VIN_MISMATCH_ERROR)'}
WATCHDOG_ASIC_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 0.0015; dematuration: 0.0015', 'latched': True,
                          'monitor': 'WDG_F_ASIC_INTERNAL', 'req': 36069155,
                          'text': 'Watchdog internal fault (FLTMONR_E_ECU_INTERNAL)'}
WATCHDOG_ASIC_LOCKOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.0035; dematuration: 0.0035', 'latched': True,
                         'monitor': 'WDG_F_ASIC_LOCKOUT', 'req': 36069153,
                         'text': 'External Watchdog LO Test Failed (TBU) (FLTMONR_E_ECU_INTERNAL)'}
WATCHDOG_ASIC_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.0635; dematuration: 0.064', 'latched': True,
                     'monitor': 'WDG_F_ASIC_SPI', 'req': 36069154,
                     'text': 'External Watchdog SPI Test Failed (TBU) (FLTMONR_E_ECU_INTERNAL)'}
WATCHDOG_TEST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Immediate; dematuration: n/a', 'latched': True,
                 'monitor': 'WDG_F_WATCHDOG_TEST', 'req': 36070128,
                 'text': 'External Watchdog Test Failed (FLTMONR_E_ECU_INTERNAL)'}

SYSTEM_FAULTS = {
    'ALGO_FRONT_SUPPRESSED': ALGO_FRONT_SUPPRESSED,
    'ALGO_FRONT_UNCONFIRMED_CRASH': ALGO_FRONT_UNCONFIRMED_CRASH,
    'ALGO_PEDESTRIAN_SUPPRESSED': ALGO_PEDESTRIAN_SUPPRESSED,
    'ALGO_PEDESTRIAN_UNCONFIRMED_CRASH': ALGO_PEDESTRIAN_UNCONFIRMED_CRASH,
    'ALGO_REAR_SUPPRESSED': ALGO_REAR_SUPPRESSED,
    'ALGO_REAR_UNCONFIRMED_CRASH': ALGO_REAR_UNCONFIRMED_CRASH,
    'ALGO_ROLL_SUPPRESSED': ALGO_ROLL_SUPPRESSED,
    'ALGO_ROLL_UNCONFIRMED_CRASH': ALGO_ROLL_UNCONFIRMED_CRASH,
    'ALGO_SIDE_LEFT_SUPPRESSED': ALGO_SIDE_LEFT_SUPPRESSED,
    'ALGO_SIDE_LEFT_UNCONFIRMED_CRASH': ALGO_SIDE_LEFT_UNCONFIRMED_CRASH,
    'ALGO_SIDE_RIGHT_SUPPRESSED': ALGO_SIDE_RIGHT_SUPPRESSED,
    'ALGO_SIDE_RIGHT_UNCONFIRMED_CRASH': ALGO_SIDE_RIGHT_UNCONFIRMED_CRASH,
    'ASIC_0': ASIC_0,
    'ASIC_1': ASIC_1,
    'ASIC_BACKGROUND_0': ASIC_BACKGROUND_0,
    'ASIC_BACKGROUND_1': ASIC_BACKGROUND_1,
    'ASIC_BIST_0': ASIC_BIST_0,
    'ASIC_BIST_1': ASIC_BIST_1,
    'ASIC_CLK_0': ASIC_CLK_0,
    'ASIC_CLK_1': ASIC_CLK_1,
    'ASIC_CONFIG_0': ASIC_CONFIG_0,
    'ASIC_CONFIG_1': ASIC_CONFIG_1,
    'ASIC_SAFETY_ECHO_0': ASIC_SAFETY_ECHO_0,
    'ASIC_SAFETY_ECHO_1': ASIC_SAFETY_ECHO_1,
    'ASIC_SERIAL_NO_0': ASIC_SERIAL_NO_0,
    'ASIC_SERIAL_NO_1': ASIC_SERIAL_NO_1,
    'ASIC_SPI_0': ASIC_SPI_0,
    'ASIC_SPI_1': ASIC_SPI_1,
    'ASIC_SSM_0': ASIC_SSM_0,
    'ASIC_SSM_1': ASIC_SSM_1,
    'ASIC_VERSION_ID_0': ASIC_VERSION_ID_0,
    'ASIC_VERSION_ID_1': ASIC_VERSION_ID_1,
    'BATT_OVERVOLTAGE': BATT_OVERVOLTAGE,
    'BATT_UNDERVOLTAGE': BATT_UNDERVOLTAGE,
    'CYBER_HSM_TIMEOUT': CYBER_HSM_TIMEOUT,
    'DEPLOY_OPS_EVENT_WITHOUT_SAFING': DEPLOY_OPS_EVENT_WITHOUT_SAFING,
    'DEVICE_CFG_CFG_NO_STEER_WHEEL_POS': DEVICE_CFG_CFG_NO_STEER_WHEEL_POS,
    'E2E_PIB_COUNTER': E2E_PIB_COUNTER,
    'ECU_CONFIG_ERROR': ECU_CONFIG_ERROR,
    'EDR_LOCKED': EDR_LOCKED,
    'EVENT_TRAP': EVENT_TRAP,
    'EXT_FLASH_BROKEN_POLLING': EXT_FLASH_BROKEN_POLLING,
    'EXT_FLASH_COMPARE': EXT_FLASH_COMPARE,
    'EXT_FLASH_INTERNAL': EXT_FLASH_INTERNAL,
    'EXT_FLASH_INVALID_DEVICE': EXT_FLASH_INVALID_DEVICE,
    'EXT_FLASH_TIMEOUT': EXT_FLASH_TIMEOUT,
    'FD_BUS_OFF': FD_BUS_OFF,
    'FEE_ADMIN_BLK_NOT_FOUND': FEE_ADMIN_BLK_NOT_FOUND,
    'FEE_CORRUPTED_FLASH': FEE_CORRUPTED_FLASH,
    'FEE_ENDURANCE_LIMIT_EXCEED': FEE_ENDURANCE_LIMIT_EXCEED,
    'FEE_ERASE_FAILURE': FEE_ERASE_FAILURE,
    'FEE_OUT_OF_OPERATING': FEE_OUT_OF_OPERATING,
    'FEE_OUT_OF_ORDER': FEE_OUT_OF_ORDER,
    'FLASH_ENTER_PAGE_MODE_SEQUENCE': FLASH_ENTER_PAGE_MODE_SEQUENCE,
    'FLASH_ENTER_PAGE_MODE_TIMEOUT': FLASH_ENTER_PAGE_MODE_TIMEOUT,
    'FLASH_ERASE_FINISH_TIMEOUT': FLASH_ERASE_FINISH_TIMEOUT,
    'FLASH_ERASE_PROTECTION': FLASH_ERASE_PROTECTION,
    'FLASH_ERASE_RESUME_PROTECTION': FLASH_ERASE_RESUME_PROTECTION,
    'FLASH_ERASE_RESUME_SEQUENCE': FLASH_ERASE_RESUME_SEQUENCE,
    'FLASH_ERASE_RESUME_WRONG_STATE': FLASH_ERASE_RESUME_WRONG_STATE,
    'FLASH_ERASE_SEQUENCE': FLASH_ERASE_SEQUENCE,
    'FLASH_ERASE_START_TIMEOUT': FLASH_ERASE_START_TIMEOUT,
    'FLASH_ERASE_START_WRONG_STATE': FLASH_ERASE_START_WRONG_STATE,
    'FLASH_ERASE_SUSPEND_ERROR_FLAG': FLASH_ERASE_SUSPEND_ERROR_FLAG,
    'FLASH_ERASE_SUSPEND_TIMEOUT': FLASH_ERASE_SUSPEND_TIMEOUT,
    'FLASH_ERASE_SUSPEND_WRONG_STATE': FLASH_ERASE_SUSPEND_WRONG_STATE,
    'FLASH_MICROCODE_OPERATION': FLASH_MICROCODE_OPERATION,
    'FLASH_WRITE_PAGE_PROTECTION': FLASH_WRITE_PAGE_PROTECTION,
    'FLASH_WRITE_PAGE_SEQUENCE': FLASH_WRITE_PAGE_SEQUENCE,
    'FLASH_WRITE_PAGE_TIMEOUT': FLASH_WRITE_PAGE_TIMEOUT,
    'HSS_ASIC_ADC_0': HSS_ASIC_ADC_0,
    'HSS_ASIC_ADC_1': HSS_ASIC_ADC_1,
    'HSS_ASIC_SPI_0': HSS_ASIC_SPI_0,
    'HSS_ASIC_SPI_1': HSS_ASIC_SPI_1,
    'HSS_DIODE_SHORT_0': HSS_DIODE_SHORT_0,
    'HSS_DRIVE_0': HSS_DRIVE_0,
    'HSS_DRIVE_1': HSS_DRIVE_1,
    'HSS_ER_DIODE_OPEN_0': HSS_ER_DIODE_OPEN_0,
    'HSS_ER_DIODE_OPEN_1': HSS_ER_DIODE_OPEN_1,
    'HSS_PDC_0': HSS_PDC_0,
    'HSS_PDC_1': HSS_PDC_1,
    'HSS_VBAT_DIODE_OPEN_0': HSS_VBAT_DIODE_OPEN_0,
    'HSS_VBAT_DIODE_OPEN_1': HSS_VBAT_DIODE_OPEN_1,
    'HSS_XCONN': HSS_XCONN,
    'HS_BUS_OFF': HS_BUS_OFF,
    'MANUFACTURING_DATA_MISSING': MANUFACTURING_DATA_MISSING,
    'MCAL_ADC_NOT_OPERATIONAL': MCAL_ADC_NOT_OPERATIONAL,
    'MCAL_SPI_POLLING_TIMEOUT': MCAL_SPI_POLLING_TIMEOUT,
    'MCAL_SPI_RECEIVE_FIFO_OVERFLOW': MCAL_SPI_RECEIVE_FIFO_OVERFLOW,
    'MCAL_SPI_TRANSMIT_BUSY': MCAL_SPI_TRANSMIT_BUSY,
    'MCU_LBIST': MCU_LBIST,
    'MCU_MBIST': MCU_MBIST,
    'MCU_MONBIST': MCU_MONBIST,
    'NVM_BLOCK_BLOCK_INTEGRITY_FAILED': NVM_BLOCK_BLOCK_INTEGRITY_FAILED,
    'NVM_INTEGRITY': NVM_INTEGRITY,
    'OPS_ROLL_MUTED_0': OPS_ROLL_MUTED_0,
    'PLANT_MODE': PLANT_MODE,
    'PWR_ASIC_ADC_0': PWR_ASIC_ADC_0,
    'PWR_ASIC_ADC_1': PWR_ASIC_ADC_1,
    'PWR_ASIC_CONFIG_0': PWR_ASIC_CONFIG_0,
    'PWR_ASIC_CONFIG_1': PWR_ASIC_CONFIG_1,
    'PWR_ASIC_SPI_0': PWR_ASIC_SPI_0,
    'PWR_ASIC_SPI_1': PWR_ASIC_SPI_1,
    'PWR_CRITICAL_CONDITION_0': PWR_CRITICAL_CONDITION_0,
    'PWR_ERBST_DIODE_LOST_0': PWR_ERBST_DIODE_LOST_0,
    'PWR_ERBST_HIGH_0': PWR_ERBST_HIGH_0,
    'PWR_ERBST_LOW_0': PWR_ERBST_LOW_0,
    'PWR_ER_CAPACITANCE_LOW_0': PWR_ER_CAPACITANCE_LOW_0,
    'PWR_ER_CAPACITANCE_TEST_FAILED_0': PWR_ER_CAPACITANCE_TEST_FAILED_0,
    'PWR_ER_CAP_OPEN_0': PWR_ER_CAP_OPEN_0,
    'PWR_ER_CHARGE_SWITCH_SHORTED_0': PWR_ER_CHARGE_SWITCH_SHORTED_0,
    'PWR_ER_CHARGE_TIME_0': PWR_ER_CHARGE_TIME_0,
    'PWR_ER_ESR_HIGH_0': PWR_ER_ESR_HIGH_0,
    'PWR_ER_SHORT_GND_0': PWR_ER_SHORT_GND_0,
    'PWR_ER_SWITCH_NOT_OPERATIONAL_0': PWR_ER_SWITCH_NOT_OPERATIONAL_0,
    'PWR_ER_VOLTAGE_HIGH_0': PWR_ER_VOLTAGE_HIGH_0,
    'PWR_ER_VOLTAGE_LOW_0': PWR_ER_VOLTAGE_LOW_0,
    'PWR_EX3_VIN_DISCONNECTED_1': PWR_EX3_VIN_DISCONNECTED_1,
    'PWR_GROUND_LOSS_0': PWR_GROUND_LOSS_0,
    'PWR_REDUNDANT_VER_FAILURE_0': PWR_REDUNDANT_VER_FAILURE_0,
    'PWR_SATBUCK_HIGH_0': PWR_SATBUCK_HIGH_0,
    'PWR_SATBUCK_LOW_0': PWR_SATBUCK_LOW_0,
    'PWR_SYSBST_DIODE_SHORT_0': PWR_SYSBST_DIODE_SHORT_0,
    'PWR_SYSBST_LOW_0': PWR_SYSBST_LOW_0,
    'PWR_SYSBST_LOW_1': PWR_SYSBST_LOW_1,
    'PWR_V5_OUT_RANGE_0': PWR_V5_OUT_RANGE_0,
    'PWR_VSYNC_LOW_0': PWR_VSYNC_LOW_0,
    'PWR_VSYNC_LOW_1': PWR_VSYNC_LOW_1,
    'RESET_UNEXPECTED_RESET': RESET_UNEXPECTED_RESET,
    'SAFING_ARMING_LONG_0': SAFING_ARMING_LONG_0,
    'SAFING_ASIC_CC_0': SAFING_ASIC_CC_0,
    'SAFING_ASIC_CONFIG_0': SAFING_ASIC_CONFIG_0,
    'SAFING_ASIC_CONFIG_ENABLES_0': SAFING_ASIC_CONFIG_ENABLES_0,
    'SAFING_ASIC_CONFIG_FOC_0': SAFING_ASIC_CONFIG_FOC_0,
    'SAFING_ASIC_INTERNAL_0': SAFING_ASIC_INTERNAL_0,
    'SAFING_ASIC_SPI_0': SAFING_ASIC_SPI_0,
    'SAFING_SNOOPING_SB3_EX3_TEST_0': SAFING_SNOOPING_SB3_EX3_TEST_0,
    'SCRAP_DEPLOYED': SCRAP_DEPLOYED,
    'SCRAP_ENTERED': SCRAP_ENTERED,
    'SMU_ALARM': SMU_ALARM,
    'SYS_CFG_BLOCK_FAILURE': SYS_CFG_BLOCK_FAILURE,
    'SYS_CONTROL_SHUTDOWN': SYS_CONTROL_SHUTDOWN,
    'SYS_MANUFACTURING_MODE': SYS_MANUFACTURING_MODE,
    'SYS_MODE_POSTRUN_POWER_CONDITIONS': SYS_MODE_POSTRUN_POWER_CONDITIONS,
    'SYS_MODE_SHUTDOWN_FAILURE': SYS_MODE_SHUTDOWN_FAILURE,
    'SYS_PHASE_OF_LIFE_FAILURE': SYS_PHASE_OF_LIFE_FAILURE,
    'SYS_PROVEOUT_TIME_FAILURE': SYS_PROVEOUT_TIME_FAILURE,
    'TASK_STACK_LOW': TASK_STACK_LOW,
    'TASK_UNDERRUN': TASK_UNDERRUN,
    'TRAP_EVENT_OCCURRED': TRAP_EVENT_OCCURRED,
    'TRAP_UNEXPECTED_EXCEPTION': TRAP_UNEXPECTED_EXCEPTION,
    'UNDERSTRIKE_CRASH': UNDERSTRIKE_CRASH,
    'VARIANT_CODE_ERROR': VARIANT_CODE_ERROR,
    'VIN_MISMATCH': VIN_MISMATCH,
    'WATCHDOG_ASIC_INTERNAL': WATCHDOG_ASIC_INTERNAL,
    'WATCHDOG_ASIC_LOCKOUT': WATCHDOG_ASIC_LOCKOUT,
    'WATCHDOG_ASIC_SPI': WATCHDOG_ASIC_SPI,
    'WATCHDOG_TEST': WATCHDOG_TEST,
}


# ====================================================================================================
# IMU (34)
# Inertial measurement unit faults and its OPS plausibility checks.
# ====================================================================================================
IMU0_COMM = {'dtc': '0x92 0x1F 0x00', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': ('maturation: 0.01 (SMI8) 0.01 (SMI9) 0.01 (Panasonic); dematuration: 0.02 (SMI8) 0.02 '
                        '(SMI9) 0.02 (Panasonic)'),
             'latched': True, 'monitor': 'DRVR_F_LOGARS_COMM_0', 'req': 36070159,
             'text': 'IMU CRC Error Counter Instance 1 (FLTMONR_IMU_E_CRC_Error_Counter_Instance_1)'}
IMU0_INTERNAL = {'dtc': '0x92 0x22 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: 0.003 (SMI8FG1) 0.03 (SMI8FG4) 0.003 (SMI9FG1) 0.03 (SMI9FG4) 0.003 '
                            '(Panasonic); dematuration: 0.006 (SMI8FG1) 0.06 (SMI8FG4) 0.006 (SMI9FG1) 0.06 '
                            '(SMI9FG4) 0.006 (Panasonic)'),
                 'latched': True, 'monitor': 'DRVR_F_LOGARS_INTERNAL_0', 'req': 36070165,
                 'text': 'IMU Internal Failure Instance 1 (FLTMONR_IMU_E_Internal_Failure_Instance_1)'}
IMU0_INTERNAL_RECOVERABLE = {'dtc': '0x92 0x23 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 0.25 (SMI8FG2) 0.03 (SMI8FG3) 0.25 (SMI9FG2) 0.03 (SMI9FG3) '
                                        '0.003 (Panasonic); dematuration: 0.5 (SMI8FG2) 0.06 (SMI8FG3) 0.5 '
                                        '(SMI9FG2) 0.06 (SMI9FG3) 0.006 (Panasonic)'),
                             'latched': True, 'monitor': 'DRVR_F_LOGARS_INTERNAL_RECOV_0', 'req': 36070167,
                             'text': ('IMU Internal Recoverable Failure Instance 1 '
                                      '(FLTMONR_IMU_E_Internal_Recoverable_Failure_Instance_1)')}
IMU0_SELF_TEST = {'dtc': '0x92 0x21 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: 0.003 (SMI8) 0.003 (SMI9) 0.003 (Panasonic); dematuration: 0.006 (SMI8) '
                             '0.006 (SMI9) 0.006 (Panasonic)'),
                  'latched': True, 'monitor': 'DRVR_F_LOGARS_SELF_TEST_0', 'req': 36070163,
                  'text': 'IMU SelfTest Failure Instance 1 (FLTMONR_IMU_E_Self_Test_Failure_Instance_1)'}
IMU0_SPI = {'dtc': '0x92 0x20 0x00', 'qualify_ms': None, 'dequalify_ms': None,
            'timing': ('maturation: 0.003 (SMI8) 0.003 (SMI9) 0.003 (Panasonic); dematuration: 0.006 (SMI8) 0.006 '
                       '(SMI9) 0.006 (Panasonic)'),
            'latched': True, 'monitor': 'DRVR_F_LOGARS_SPI_0', 'req': 36070161,
            'text': 'IMU SPI Error Counter Instance 1 (FLTMONR_IMU_E_SPI_Error_Counter_Instance_1)'}
IMU_ARS_PITCH = {'dtc': '0x92 0x2A 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, '
                            'SEV2) 0.2 (IMU SEV3)'),
                 'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_PITCH', 'req': 36070263,
                 'text': 'IMU SEV1 or 2 failure on PITCH direction (FLTMONR_IMU_E_SEV123_failure_on_PITCH)'}
IMU_ARS_PITCH_OUT_RANGE = {'dtc': '0x92 0x31 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                           'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_PITCH_OUT_RANGE', 'req': 36070273,
                           'text': ('IMU Out of Range failure on PITCH direction '
                                    '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_PITCH)')}
IMU_ARS_ROLL = {'dtc': '0x92 0x29 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                           '0.2 (IMU SEV3)'),
                'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_ROLL', 'req': 36070262,
                'text': 'IMU SEV1 or 2 failure on ROLL direction (FLTMONR_IMU_E_SEV123_failure_on_ROLL)'}
IMU_ARS_ROLL_OUT_RANGE = {'dtc': '0x92 0x30 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                          'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_ROLL_OUT_RANGE', 'req': 36070272,
                          'text': ('IMU Out of Range failure on ROLL direction '
                                   '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_ROLL)')}
IMU_ARS_TEMP = {'dtc': '0x92 0x2B 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: NA(TBD); dematuration: NA(TBD)', 'latched': False,
                'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_TEMP', 'req': 36070267,
                'text': 'IMU SEV1 or 2 failure for Temperature (FLTMONR_IMU_E_SEV123_failure_for_TEMPERATURE)'}
IMU_ARS_YAW = {'dtc': '0x92 0x28 0x00', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                          '0.2 (IMU SEV3)'),
               'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_YAW', 'req': 36070261,
               'text': 'IMU SEV1 or 2 failure on YAW direction (FLTMONR_IMU_E_SEV123_failure_on_YAW)'}
IMU_ARS_YAW_OUT_RANGE = {'dtc': '0x92 0x2F 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                         'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_YAW_OUT_RANGE', 'req': 36070271,
                         'text': ('IMU Out of Range failure on YAW direction '
                                  '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_YAW)')}
IMU_ARS_YAW_TEMP_OUT_RANGE = {'dtc': '0x92 0x32 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: NA(TBD); dematuration: NA(TBD)', 'latched': False,
                              'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_YAW_TEMP_OUT_RANGE', 'req': 36070277,
                              'text': ('IMU Out of Range failure on YAW Temperature '
                                       '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_YAW_TEMPERATURE)')}
IMU_EXT_CAL_FAIL = {'dtc': '0x92 0x48 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                    'monitor': 'IMUMGR_F_IMU_EXT_CAL_FAIL', 'req': 36070354,
                    'text': 'Incorrect calibration (FLTMONR_IMU_EXT_CAL_FAIL)'}
IMU_EXT_CAL_MISSING = {'dtc': '0x92 0x47 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                       'monitor': 'IMUMGR_F_IMU_EXT_CAL_MISSING', 'req': 36070353,
                       'text': 'Missing calibration (FLTMONR_IMU_EXT_CAL_MISSING)'}
IMU_LOG_X = {'dtc': '0x92 0x25 0x00', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                        '0.2 (IMU SEV3)'),
             'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_X', 'req': 36070258,
             'text': 'IMU SEV1 or 2 failure on X direction (FLTMONR_IMU_E_SEV123_failure_on_X)'}
IMU_LOG_X_OUT_RANGE = {'dtc': '0x92 0x2C 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                       'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_X_OUT_RANGE', 'req': 36070268,
                       'text': 'IMU Out of Range failure on X direction (FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_X)'}
IMU_LOG_Y = {'dtc': '0x92 0x26 0x00', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                        '0.2 (IMU SEV3)'),
             'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Y', 'req': 36070259,
             'text': 'IMU SEV1 or 2 failure on Y direction (FLTMONR_IMU_E_SEV123_failure_on_Y)'}
IMU_LOG_Y_OUT_RANGE = {'dtc': '0x92 0x2D 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                       'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Y_OUT_RANGE', 'req': 36070269,
                       'text': 'IMU Out of Range failure on Y direction (FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_Y)'}
IMU_LOG_Z = {'dtc': '0x92 0x27 0x00', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                        '0.2 (IMU SEV3)'),
             'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Z', 'req': 36070260,
             'text': 'IMU SEV1 or 2 failure on Z direction (FLTMONR_IMU_E_SEV123_failure_on_Z)'}
IMU_LOG_Z_OUT_RANGE = {'dtc': '0x92 0x2E 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                       'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Z_OUT_RANGE', 'req': 36070270,
                       'text': 'IMU Out of Range failure on Z direction (FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_Z)'}
IMU_VEONEER_CHKSUM_FAIL = {'dtc': '0x92 0x24 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 1; dematuration: Send write DID request with correct checksum',
                           'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_VEONEER_CHKSUM_FAIL', 'req': 36070257,
                           'text': ('Veoneer Manufacturing IMU Calibration data integrity check failure on at '
                                    'least one of the channel (FLTMONR_IMUSGPOOLMGR_E_VEONEER_CHKSUM_FAIL)')}
OPS_ARS_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_OCR_0', 'req': 36070250,
                    'text': 'OPS ARS Offset Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_ARS_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_OCR_1', 'req': 36070251,
                    'text': 'OPS ARS Offset Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_ARS_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_OCR_2', 'req': 36070252,
                    'text': 'OPS ARS Offset Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_ARS_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 10; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_DEC_0', 'req': 36070195,
                        'text': 'OPS ARS Saturation Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_ARS_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_DEC_1', 'req': 36070196,
                        'text': 'OPS ARS Saturation Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_ARS_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: TBD; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_DEC_2', 'req': 36070197,
                        'text': 'OPS ARS Saturation Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_LOG_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: : FOC and SOC: 2.05s for FOC and 2500s for SOC. APPRISe: FOC and SOC: '
                               '2.05s for FOC and 2500s for SOC.; dematuration: N/A'),
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_OCR_0', 'req': 36070247,
                    'text': 'OPS LowG Offset Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_LOG_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: : FOC and SOC: 2.05s for FOC and 2500s for SOC. APPRISe: FOC and SOC: '
                               '2.05s for FOC and 2500s for SOC.; dematuration: N/A'),
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_OCR_1', 'req': 36070248,
                    'text': 'OPS LowG Offset Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_LOG_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: : FOC and SOC: 2.05s for FOC and 2500s for SOC. APPRISe: FOC and SOC: '
                               '2.05s for FOC and 2500s for SOC.; dematuration: N/A'),
                    'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_OCR_2', 'req': 36070249,
                    'text': 'OPS LowG Offset Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_LOG_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_DEC_0', 'req': 36070192,
                        'text': 'OPS LowG Saturation Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_LOG_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_DEC_1', 'req': 36070193,
                        'text': 'OPS LowG Saturation Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_LOG_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_DEC_2', 'req': 36070194,
                        'text': 'OPS LowG Saturation Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}

IMU_FAULTS = {
    'IMU0_COMM': IMU0_COMM,
    'IMU0_INTERNAL': IMU0_INTERNAL,
    'IMU0_INTERNAL_RECOVERABLE': IMU0_INTERNAL_RECOVERABLE,
    'IMU0_SELF_TEST': IMU0_SELF_TEST,
    'IMU0_SPI': IMU0_SPI,
    'IMU_ARS_PITCH': IMU_ARS_PITCH,
    'IMU_ARS_PITCH_OUT_RANGE': IMU_ARS_PITCH_OUT_RANGE,
    'IMU_ARS_ROLL': IMU_ARS_ROLL,
    'IMU_ARS_ROLL_OUT_RANGE': IMU_ARS_ROLL_OUT_RANGE,
    'IMU_ARS_TEMP': IMU_ARS_TEMP,
    'IMU_ARS_YAW': IMU_ARS_YAW,
    'IMU_ARS_YAW_OUT_RANGE': IMU_ARS_YAW_OUT_RANGE,
    'IMU_ARS_YAW_TEMP_OUT_RANGE': IMU_ARS_YAW_TEMP_OUT_RANGE,
    'IMU_EXT_CAL_FAIL': IMU_EXT_CAL_FAIL,
    'IMU_EXT_CAL_MISSING': IMU_EXT_CAL_MISSING,
    'IMU_LOG_X': IMU_LOG_X,
    'IMU_LOG_X_OUT_RANGE': IMU_LOG_X_OUT_RANGE,
    'IMU_LOG_Y': IMU_LOG_Y,
    'IMU_LOG_Y_OUT_RANGE': IMU_LOG_Y_OUT_RANGE,
    'IMU_LOG_Z': IMU_LOG_Z,
    'IMU_LOG_Z_OUT_RANGE': IMU_LOG_Z_OUT_RANGE,
    'IMU_VEONEER_CHKSUM_FAIL': IMU_VEONEER_CHKSUM_FAIL,
    'OPS_ARS_OFFSET_0': OPS_ARS_OFFSET_0,
    'OPS_ARS_OFFSET_1': OPS_ARS_OFFSET_1,
    'OPS_ARS_OFFSET_2': OPS_ARS_OFFSET_2,
    'OPS_ARS_SATURATION_0': OPS_ARS_SATURATION_0,
    'OPS_ARS_SATURATION_1': OPS_ARS_SATURATION_1,
    'OPS_ARS_SATURATION_2': OPS_ARS_SATURATION_2,
    'OPS_LOG_OFFSET_0': OPS_LOG_OFFSET_0,
    'OPS_LOG_OFFSET_1': OPS_LOG_OFFSET_1,
    'OPS_LOG_OFFSET_2': OPS_LOG_OFFSET_2,
    'OPS_LOG_SATURATION_0': OPS_LOG_SATURATION_0,
    'OPS_LOG_SATURATION_1': OPS_LOG_SATURATION_1,
    'OPS_LOG_SATURATION_2': OPS_LOG_SATURATION_2,
}


# ====================================================================================================
# High-g sensors (16)
# Central high-g sensor faults and its OPS checks.
# ====================================================================================================
HIGH_G0_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                    'monitor': 'DRVR_F_HIG_INTERNAL_0', 'req': 36070130,
                    'text': 'SMA&GEN6 sensor internal (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G0_SELF_TEST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                     'monitor': 'DRVR_F_HIG_SELF_TEST_0', 'req': 36070131,
                     'text': 'SMA&GEN6 sensor selftest (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G0_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: 0.3; dematuration: 0.6', 'latched': False, 'monitor': 'DRVR_F_HIG_SPI_0',
               'req': 36070129, 'text': 'SMA&GEN6 sensor SPI bus (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G0_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                  'monitor': 'DRVR_F_HIG_SUPPLY_0', 'req': 36070132,
                  'text': 'SMA&GEN6 sensor supply (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G1_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                    'monitor': 'DRVR_F_HIG_INTERNAL_1', 'req': 36070134,
                    'text': 'SMA&GEN6 sensor internal (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G1_SELF_TEST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                     'monitor': 'DRVR_F_HIG_SELF_TEST_1', 'req': 36070135,
                     'text': 'SMA&GEN6 sensor selftest (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G1_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: 0.3; dematuration: 0.6', 'latched': True, 'monitor': 'DRVR_F_HIG_SPI_1',
               'req': 36070133, 'text': 'SMA&GEN6 sensor SPI bus (FLTMONR_E_ECU_INTERNAL)'}
HIGH_G1_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                  'monitor': 'DRVR_F_HIG_SUPPLY_1', 'req': 36070136,
                  'text': 'SMA&GEN6 sensor supply (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_0', 'req': 36070224,
                    'text': 'OPS HighG Offset Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_1', 'req': 36070225,
                    'text': 'OPS HighG Offset Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_2', 'req': 36070226,
                    'text': 'OPS HighG Offset Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_OFFSET_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                    'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_3', 'req': 36070227,
                    'text': 'OPS HighG Offset Failure Axis 3 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_0', 'req': 36070169,
                        'text': 'OPS HighG Saturation Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_1', 'req': 36070170,
                        'text': 'OPS HighG Saturation Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_2', 'req': 36070171,
                        'text': 'OPS HighG Saturation Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
OPS_HIG_SATURATION_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                        'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_3', 'req': 36070172,
                        'text': 'OPS HighG Saturation Failure Axis 3 (FLTMONR_E_ECU_INTERNAL)'}

HIGH_G_FAULTS = {
    'HIGH_G0_INTERNAL': HIGH_G0_INTERNAL,
    'HIGH_G0_SELF_TEST': HIGH_G0_SELF_TEST,
    'HIGH_G0_SPI': HIGH_G0_SPI,
    'HIGH_G0_SUPPLY': HIGH_G0_SUPPLY,
    'HIGH_G1_INTERNAL': HIGH_G1_INTERNAL,
    'HIGH_G1_SELF_TEST': HIGH_G1_SELF_TEST,
    'HIGH_G1_SPI': HIGH_G1_SPI,
    'HIGH_G1_SUPPLY': HIGH_G1_SUPPLY,
    'OPS_HIG_OFFSET_0': OPS_HIG_OFFSET_0,
    'OPS_HIG_OFFSET_1': OPS_HIG_OFFSET_1,
    'OPS_HIG_OFFSET_2': OPS_HIG_OFFSET_2,
    'OPS_HIG_OFFSET_3': OPS_HIG_OFFSET_3,
    'OPS_HIG_SATURATION_0': OPS_HIG_SATURATION_0,
    'OPS_HIG_SATURATION_1': OPS_HIG_SATURATION_1,
    'OPS_HIG_SATURATION_2': OPS_HIG_SATURATION_2,
    'OPS_HIG_SATURATION_3': OPS_HIG_SATURATION_3,
}


# ====================================================================================================
# Loops fired (10)
# Records of fired loops (no DTC for the airbag groups).
# ====================================================================================================
KNEE_BAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                   'monitor': 'OPS_E_KNEE_BAGS_FIRED', 'req': 36070310,
                   'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FRONTAL_BAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                      'monitor': 'OPS_E_FRONTAL_BAGS_FIRED', 'req': 36070311,
                      'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FRONTAL_BAGS_FIRED_PASS_INHIBITED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                                     'monitor': 'OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBITED', 'req': 36070312,
                                     'text': 'This Fault records the DTC Logged when respective Loop is fired'}
BACK_IMPACT_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                     'monitor': 'OPS_E_BACK_IMPACT_FIRED', 'req': 36070318,
                     'text': 'This Fault records the DTC Logged when respective Loop is fired'}
LEFT_LATERAL_AIRBAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                              'monitor': 'OPS_E_LEFT_LATERAL_AIRBAGS_FIRED', 'req': 36070313,
                              'text': 'This Fault records the DTC Logged when respective Loop is fired'}
RIGHT_LATERAL_AIRBAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                               'monitor': 'OPS_E_RIGHT_LATERAL_AIRBAGS_FIRED', 'req': 36070314,
                               'text': 'This Fault records the DTC Logged when respective Loop is fired'}
LEFT_CURTAIN_AIRBAG_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                             'monitor': 'OPS_E_LEFT_CURTAIN_AIRBAG_FIRED', 'req': 36070315,
                             'text': 'This Fault records the DTC Logged when respective Loop is fired'}
RIGHT_CURTAIN_AIRBAG_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                              'monitor': 'OPS_E_RIGHT_CURTAIN_AIRBAG_FIRED', 'req': 36070316,
                              'text': 'This Fault records the DTC Logged when respective Loop is fired'}
PRETENSIONERS_FIRED = {'dtc': '0x92 0x1A 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                       'monitor': 'OPS_E_PRETENSIONERS_FIRED', 'req': 36070307,
                       'text': 'Crash related fault (FLTMONR_E_ECU_LOCKED_DUE_TO_PT_DEPLOYMENT)'}
STRAP_PRETENSIONER_FIRED = {'dtc': '0x92 0x1A 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                            'monitor': 'OPS_E_STRAP_RETURN_PRETENSIONER_FIRED', 'req': 36070309,
                            'text': 'Crash related fault (FLTMONR_E_ECU_LOCKED_DUE_TO_PT_DEPLOYMENT)'}

FIRED_FAULTS = {
    'KNEE_BAGS_FIRED': KNEE_BAGS_FIRED,
    'FRONTAL_BAGS_FIRED': FRONTAL_BAGS_FIRED,
    'FRONTAL_BAGS_FIRED_PASS_INHIBITED': FRONTAL_BAGS_FIRED_PASS_INHIBITED,
    'BACK_IMPACT_FIRED': BACK_IMPACT_FIRED,
    'LEFT_LATERAL_AIRBAGS_FIRED': LEFT_LATERAL_AIRBAGS_FIRED,
    'RIGHT_LATERAL_AIRBAGS_FIRED': RIGHT_LATERAL_AIRBAGS_FIRED,
    'LEFT_CURTAIN_AIRBAG_FIRED': LEFT_CURTAIN_AIRBAG_FIRED,
    'RIGHT_CURTAIN_AIRBAG_FIRED': RIGHT_CURTAIN_AIRBAG_FIRED,
    'PRETENSIONERS_FIRED': PRETENSIONERS_FIRED,
    'STRAP_PRETENSIONER_FIRED': STRAP_PRETENSIONER_FIRED,
}


# ====================================================================================================
# Crash records (5)
# Crash DTCs, set at once and kept (warning lamp ON).
# ====================================================================================================
ROLLOVER_CRASH = {'dtc': '0x99 0x15 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Immediate; dematuration: NA', 'latched': None, 'monitor': 'ROLLOVER_CRASH',
                  'req': 36141136, 'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
FRONT_CRASH = {'dtc': '0x90 0x61 0x96', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': 'maturation: Immediate; dematuration: NA', 'latched': None, 'monitor': 'FRONT_CRASH',
               'req': 36153766, 'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
REAR_CRASH = {'dtc': '0x92 0x1E 0x00', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: Immediate; dematuration: NA', 'latched': None, 'monitor': 'REAR_CRASH',
              'req': 36153767, 'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
RIGHT_SIDE_CRASH = {'dtc': '0x99 0x16 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Immediate; dematuration: NA', 'latched': None,
                    'monitor': 'RIGHT_SIDE_CRASH', 'req': 36153768,
                    'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
LEFT_SIDE_CRASH = {'dtc': '0x92 0x01 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Immediate; dematuration: NA', 'latched': None,
                   'monitor': 'LEFT_SIDE_CRASH', 'req': 36153769,
                   'text': '! Note: During this failure active the Warning LAMP status shall be ON'}

CRASH_FAULTS = {
    'ROLLOVER_CRASH': ROLLOVER_CRASH,
    'FRONT_CRASH': FRONT_CRASH,
    'REAR_CRASH': REAR_CRASH,
    'RIGHT_SIDE_CRASH': RIGHT_SIDE_CRASH,
    'LEFT_SIDE_CRASH': LEFT_SIDE_CRASH,
}


# ====================================================================================================
# Struck out by the customer (43)
# Faults the customer struck out of the fault list (heading 'Customer StrikeOut DTC'): kept for
# reference, not part of the project's fault set (not in FAULT_LIST).
# ====================================================================================================
DRV_STPS2_S2B = {'dtc': '0x98 0xFA 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                 'monitor': 'DCS_F_SHORT_PLUS_6', 'req': 36073761,
                 'text': 'DCS Sensor 6 short to battery (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_LEAK_TO_PLUS)'}
DRV_STPS2_S2G = {'dtc': '0x98 0xFA 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                 'monitor': 'DCS_F_SHORT_GND_6', 'req': 36073754,
                 'text': 'DCS Sensor 6 short to ground (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_LEAK_TO_GND)'}
DRV_STPS2_OPEN = {'dtc': '0x98 0xFA 0x13', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_OPEN_6', 'req': 36073747,
                  'text': 'DCS Sensor 6 open circuit (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_OPEN)'}
DRV_STPS2_XCONN = {'dtc': '0x98 0xFA 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                   'monitor': 'DCS_F_CROSS_CONNECT_6', 'req': 36073740,
                   'text': 'DCS Sensor 6 cross connected (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_CROSS_CONNECTED)'}
PSGR_STPS2_S2B = {'dtc': '0x98 0xFC 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_8', 'req': 36073762,
                  'text': 'DCS Sensor 8 short to battery (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_LEAK_TO_PLUS)'}
PSGR_STPS2_S2G = {'dtc': '0x98 0xFC 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_GND_8', 'req': 36073755,
                  'text': 'DCS Sensor 8 short to ground (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_LEAK_TO_GND)'}
PSGR_STPS2_OPEN = {'dtc': '0x98 0xFC 0x13', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                   'monitor': 'DCS_F_OPEN_8', 'req': 36073748,
                   'text': 'DCS Sensor 8 open circuit (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_OPEN)'}
PSGR_STPS2_XCONN = {'dtc': '0x98 0xFC 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_8', 'req': 36073741,
                    'text': 'DCS Sensor 8 cross connected (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_CROSS_CONNECTED)'}
DFV_OPEN = {'dtc': '0x92 0x61 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_14', 'req': 36069479,
            'text': 'LOP Open circuit failure Line 14 (FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_OPEN)'}
DFV_S2G = {'dtc': '0x92 0x61 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_14', 'req': 36073763,
           'text': ('LOP Short to ground failure Line 14 '
                    '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_GND)')}
DFV_S2B = {'dtc': '0x92 0x61 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_14', 'req': 36073770,
           'text': ('LOP Short to battery failure Line 14 '
                    '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
DFV_LORES = {'dtc': '0x92 0x61 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_14', 'req': 36073777,
             'text': 'LOP Resistance too low Line 14 (FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_LOW_RES)'}
DFV_HIRES = {'dtc': '0x92 0x61 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_14', 'req': 36073784,
             'text': 'LOP Resistance too high Line 14 (FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_HIGH_RES)'}
DFV_XCONN = {'dtc': '0x92 0x61 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_14', 'req': 36073796,
             'text': ('LOP Cross connection failure Line 14 '
                      '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_CROSS_CONNECT)')}
DFV_UNEXPECTED = {'dtc': '0x92 0x61 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_14', 'req': 36069563,
                  'text': ('LOP Present but not configured Line 14 '
                           '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_UNEXPECTED_SQUIB)')}
PFV_OPEN = {'dtc': '0x92 0x62 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_15', 'req': 36069480,
            'text': 'LOP Open circuit failure Line 15 (FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_OPEN)'}
PFV_S2G = {'dtc': '0x92 0x62 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_15', 'req': 36073764,
           'text': ('LOP Short to ground failure Line 15 '
                    '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_GND)')}
PFV_S2B = {'dtc': '0x92 0x62 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_15', 'req': 36073771,
           'text': ('LOP Short to battery failure Line 15 '
                    '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
PFV_LORES = {'dtc': '0x92 0x62 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_15', 'req': 36073778,
             'text': 'LOP Resistance too low Line 15 (FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_LOW_RES)'}
PFV_HIRES = {'dtc': '0x92 0x62 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_15', 'req': 36073785,
             'text': 'LOP Resistance too high Line 15 (FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_HIGH_RES)'}
PFV_XCONN = {'dtc': '0x92 0x62 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_15', 'req': 36073797,
             'text': ('LOP Cross connection failure Line 15 '
                      '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_CROSS_CONNECT)')}
PFV_UNEXPECTED = {'dtc': '0x92 0x62 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_15', 'req': 36069564,
                  'text': ('LOP Present but not configured Line 15 '
                           '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_UNEXPECTED_SQUIB)')}
HVBD_OPEN = {'dtc': '0x99 0x12 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_OPEN_21', 'req': 36073793,
             'text': 'LOP Open circuit failure Line 21 (FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_OPEN)'}
HVBD_S2G = {'dtc': '0x99 0x12 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_GND_21', 'req': 36073767,
            'text': ('LOP Short to ground failure Line 21 '
                     '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_SHORT_CIRCUIT_TO_GND)')}
HVBD_S2B = {'dtc': '0x99 0x12 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_SHORT_TO_BATT_21', 'req': 36073774,
            'text': ('LOP Short to battery failure Line 21 '
                     '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
HVBD_LORES = {'dtc': '0x99 0x12 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_LOW_RES_21', 'req': 36073781,
              'text': ('LOP Resistance too low Line 21 '
                       '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_LOW_RES)')}
HVBD_HIRES = {'dtc': '0x99 0x12 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_HIGH_RES_21', 'req': 36073788,
              'text': ('LOP Resistance too high Line 21 '
                       '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_HIGH_RES)')}
HVBD_XCONN = {'dtc': '0x99 0x12 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_CROSS_CONNECT_21', 'req': 36073800,
              'text': ('LOP Cross connection failure Line 21 '
                       '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_CROSS_CONNECT)')}
HVBD_UNEXPECTED = {'dtc': '0x99 0x12 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                              'Within PDC(2 sec)'),
                   'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_21', 'req': 36073805,
                   'text': ('LOP Present but not configured Line 21 '
                            '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_UNEXPECTED_SQUIB)')}
PPC_OPEN = {'dtc': '0x99 0x11 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_22', 'req': 36073794,
            'text': 'LOP Open circuit failure Line 22 (FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_OPEN)'}
PPC_S2G = {'dtc': '0x99 0x11 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_22', 'req': 36073768,
           'text': ('LOP Short to ground failure Line 22 '
                    '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_GND)')}
PPC_S2B = {'dtc': '0x99 0x11 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_22', 'req': 36073775,
           'text': ('LOP Short to battery failure Line 22 '
                    '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
PPC_LORES = {'dtc': '0x99 0x11 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_22', 'req': 36073782,
             'text': 'LOP Resistance too low Line 22 (FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_LOW_RES)'}
PPC_HIRES = {'dtc': '0x99 0x11 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_22', 'req': 36073789,
             'text': 'LOP Resistance too high Line 22 (FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_HIGH_RES)'}
PPC_XCONN = {'dtc': '0x99 0x11 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_22', 'req': 36073801,
             'text': ('LOP Cross connection failure Line 22 '
                      '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_CROSS_CONNECT)')}
PPC_UNEXPECTED = {'dtc': '0x99 0x11 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_22', 'req': 36073806,
                  'text': ('LOP Present but not configured Line 22 '
                           '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_UNEXPECTED_SQUIB)')}
DPC_OPEN = {'dtc': '0x99 0x10 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
            'monitor': 'LOOP_F_OPEN_23', 'req': 36073795,
            'text': 'LOP Open circuit failure Line 23 (FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_OPEN)'}
DPC_S2G = {'dtc': '0x99 0x10 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_GND_23', 'req': 36073769,
           'text': ('LOP Short to ground failure Line 23 '
                    '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_GND)')}
DPC_S2B = {'dtc': '0x99 0x10 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
           'monitor': 'LOOP_F_SHORT_TO_BATT_23', 'req': 36073776,
           'text': ('LOP Short to battery failure Line 23 '
                    '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
DPC_LORES = {'dtc': '0x99 0x10 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_LOW_RES_23', 'req': 36073783,
             'text': 'LOP Resistance too low Line 23 (FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_LOW_RES)'}
DPC_HIRES = {'dtc': '0x99 0x10 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_HIGH_RES_23', 'req': 36073790,
             'text': 'LOP Resistance too high Line 23 (FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_HIGH_RES)'}
DPC_XCONN = {'dtc': '0x99 0x10 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
             'monitor': 'LOOP_F_CROSS_CONNECT_23', 'req': 36073802,
             'text': ('LOP Cross connection failure Line 23 '
                      '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_CROSS_CONNECT)')}
DPC_UNEXPECTED = {'dtc': '0x99 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                             'Within PDC(2 sec)'),
                  'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_23', 'req': 36073807,
                  'text': ('LOP Present but not configured Line 23 '
                           '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_UNEXPECTED_SQUIB)')}

STRUCK_OUT_FAULTS = {
    'DRV_STPS2_S2B': DRV_STPS2_S2B,
    'DRV_STPS2_S2G': DRV_STPS2_S2G,
    'DRV_STPS2_OPEN': DRV_STPS2_OPEN,
    'DRV_STPS2_XCONN': DRV_STPS2_XCONN,
    'PSGR_STPS2_S2B': PSGR_STPS2_S2B,
    'PSGR_STPS2_S2G': PSGR_STPS2_S2G,
    'PSGR_STPS2_OPEN': PSGR_STPS2_OPEN,
    'PSGR_STPS2_XCONN': PSGR_STPS2_XCONN,
    'DFV_OPEN': DFV_OPEN,
    'DFV_S2G': DFV_S2G,
    'DFV_S2B': DFV_S2B,
    'DFV_LORES': DFV_LORES,
    'DFV_HIRES': DFV_HIRES,
    'DFV_XCONN': DFV_XCONN,
    'DFV_UNEXPECTED': DFV_UNEXPECTED,
    'PFV_OPEN': PFV_OPEN,
    'PFV_S2G': PFV_S2G,
    'PFV_S2B': PFV_S2B,
    'PFV_LORES': PFV_LORES,
    'PFV_HIRES': PFV_HIRES,
    'PFV_XCONN': PFV_XCONN,
    'PFV_UNEXPECTED': PFV_UNEXPECTED,
    'HVBD_OPEN': HVBD_OPEN,
    'HVBD_S2G': HVBD_S2G,
    'HVBD_S2B': HVBD_S2B,
    'HVBD_LORES': HVBD_LORES,
    'HVBD_HIRES': HVBD_HIRES,
    'HVBD_XCONN': HVBD_XCONN,
    'HVBD_UNEXPECTED': HVBD_UNEXPECTED,
    'PPC_OPEN': PPC_OPEN,
    'PPC_S2G': PPC_S2G,
    'PPC_S2B': PPC_S2B,
    'PPC_LORES': PPC_LORES,
    'PPC_HIRES': PPC_HIRES,
    'PPC_XCONN': PPC_XCONN,
    'PPC_UNEXPECTED': PPC_UNEXPECTED,
    'DPC_OPEN': DPC_OPEN,
    'DPC_S2G': DPC_S2G,
    'DPC_S2B': DPC_S2B,
    'DPC_LORES': DPC_LORES,
    'DPC_HIRES': DPC_HIRES,
    'DPC_XCONN': DPC_XCONN,
    'DPC_UNEXPECTED': DPC_UNEXPECTED,
}


# ====================================================================================================
# Every fault of the project's fault set (the struck-out ones are not in it)
# ====================================================================================================
FAULT_LIST = {
    **LOOP_FAULTS,
    **GPO_FAULTS,
    **DCS_FAULTS,
    **RSU_FAULTS,
    **CAN_FAULTS,
    **SYSTEM_FAULTS,
    **IMU_FAULTS,
    **HIGH_G_FAULTS,
    **FIRED_FAULTS,
    **CRASH_FAULTS,
}

# Squib (squibs_config name) -> fault type (Squib_FaultTypeCode key) -> fault.
LOOP_FAULT_BY_SQUIB = {
    'RPT': {'Open': RPT_OPEN, 'S2G': RPT_S2G, 'S2B': RPT_S2B, 'LoRes': RPT_LORES, 'HiRes': RPT_HIRES,
            'CrossConnect': RPT_XCONN, 'UNEX': RPT_UNEXPECTED, 'Internal': RPT_INTERNAL,
            'CurrentSource': RPT_CURRENT_SOURCE, 'Supply': RPT_SUPPLY, 'LowSideSwitch': RPT_LOW_SIDE_SWITCH,
            'HighSideSwitch': RPT_HIGH_SIDE_SWITCH, 'GroundLoss': RPT_GROUND_LOSS, 'CsrCrossConnect': RPT_CSR_XCONN,
            'PdcAbortInternal': RPT_PDC_ABORT_INT, 'PdcAbortExternal': RPT_PDC_ABORT_EXT, 'Dwell': RPT_DWELL},
    'LPT': {'Open': LPT_OPEN, 'S2G': LPT_S2G, 'S2B': LPT_S2B, 'LoRes': LPT_LORES, 'HiRes': LPT_HIRES,
            'CrossConnect': LPT_XCONN, 'UNEX': LPT_UNEXPECTED, 'Internal': LPT_INTERNAL,
            'CurrentSource': LPT_CURRENT_SOURCE, 'Supply': LPT_SUPPLY, 'LowSideSwitch': LPT_LOW_SIDE_SWITCH,
            'HighSideSwitch': LPT_HIGH_SIDE_SWITCH, 'GroundLoss': LPT_GROUND_LOSS, 'CsrCrossConnect': LPT_CSR_XCONN,
            'PdcAbortInternal': LPT_PDC_ABORT_INT, 'PdcAbortExternal': LPT_PDC_ABORT_EXT, 'Dwell': LPT_DWELL},
    'RSA': {'Open': RSA_OPEN, 'S2G': RSA_S2G, 'S2B': RSA_S2B, 'LoRes': RSA_LORES, 'HiRes': RSA_HIRES,
            'CrossConnect': RSA_XCONN, 'UNEX': RSA_UNEXPECTED, 'Internal': RSA_INTERNAL,
            'CurrentSource': RSA_CURRENT_SOURCE, 'Supply': RSA_SUPPLY, 'LowSideSwitch': RSA_LOW_SIDE_SWITCH,
            'HighSideSwitch': RSA_HIGH_SIDE_SWITCH, 'GroundLoss': RSA_GROUND_LOSS, 'CsrCrossConnect': RSA_CSR_XCONN,
            'PdcAbortInternal': RSA_PDC_ABORT_INT, 'PdcAbortExternal': RSA_PDC_ABORT_EXT, 'Dwell': RSA_DWELL},
    'LSA': {'Open': LSA_OPEN, 'S2G': LSA_S2G, 'S2B': LSA_S2B, 'LoRes': LSA_LORES, 'HiRes': LSA_HIRES,
            'CrossConnect': LSA_XCONN, 'UNEX': LSA_UNEXPECTED, 'Internal': LSA_INTERNAL,
            'CurrentSource': LSA_CURRENT_SOURCE, 'Supply': LSA_SUPPLY, 'LowSideSwitch': LSA_LOW_SIDE_SWITCH,
            'HighSideSwitch': LSA_HIGH_SIDE_SWITCH, 'GroundLoss': LSA_GROUND_LOSS, 'CsrCrossConnect': LSA_CSR_XCONN,
            'PdcAbortInternal': LSA_PDC_ABORT_INT, 'PdcAbortExternal': LSA_PDC_ABORT_EXT, 'Dwell': LSA_DWELL},
    'RCA': {'Open': RCA_OPEN, 'S2G': RCA_S2G, 'S2B': RCA_S2B, 'LoRes': RCA_LORES, 'HiRes': RCA_HIRES,
            'CrossConnect': RCA_XCONN, 'UNEX': RCA_UNEXPECTED, 'Internal': RCA_INTERNAL,
            'CurrentSource': RCA_CURRENT_SOURCE, 'Supply': RCA_SUPPLY, 'LowSideSwitch': RCA_LOW_SIDE_SWITCH,
            'HighSideSwitch': RCA_HIGH_SIDE_SWITCH, 'GroundLoss': RCA_GROUND_LOSS, 'CsrCrossConnect': RCA_CSR_XCONN,
            'PdcAbortInternal': RCA_PDC_ABORT_INT, 'PdcAbortExternal': RCA_PDC_ABORT_EXT, 'Dwell': RCA_DWELL},
    'LCA': {'Open': LCA_OPEN, 'S2G': LCA_S2G, 'S2B': LCA_S2B, 'LoRes': LCA_LORES, 'HiRes': LCA_HIRES,
            'CrossConnect': LCA_XCONN, 'UNEX': LCA_UNEXPECTED, 'Internal': LCA_INTERNAL,
            'CurrentSource': LCA_CURRENT_SOURCE, 'Supply': LCA_SUPPLY, 'LowSideSwitch': LCA_LOW_SIDE_SWITCH,
            'HighSideSwitch': LCA_HIGH_SIDE_SWITCH, 'GroundLoss': LCA_GROUND_LOSS, 'CsrCrossConnect': LCA_CSR_XCONN,
            'PdcAbortInternal': LCA_PDC_ABORT_INT, 'PdcAbortExternal': LCA_PDC_ABORT_EXT, 'Dwell': LCA_DWELL},
    'LLPT': {'Open': LLPT_OPEN, 'S2G': LLPT_S2G, 'S2B': LLPT_S2B, 'LoRes': LLPT_LORES, 'HiRes': LLPT_HIRES,
             'CrossConnect': LLPT_XCONN, 'UNEX': LLPT_UNEXPECTED, 'Internal': LLPT_INTERNAL,
             'CurrentSource': LLPT_CURRENT_SOURCE, 'Supply': LLPT_SUPPLY, 'LowSideSwitch': LLPT_LOW_SIDE_SWITCH,
             'HighSideSwitch': LLPT_HIGH_SIDE_SWITCH, 'GroundLoss': LLPT_GROUND_LOSS,
             'CsrCrossConnect': LLPT_CSR_XCONN, 'PdcAbortInternal': LLPT_PDC_ABORT_INT,
             'PdcAbortExternal': LLPT_PDC_ABORT_EXT, 'Dwell': LLPT_DWELL},
    'RLPT': {'Open': RLPT_OPEN, 'S2G': RLPT_S2G, 'S2B': RLPT_S2B, 'LoRes': RLPT_LORES, 'HiRes': RLPT_HIRES,
             'CrossConnect': RLPT_XCONN, 'UNEX': RLPT_UNEXPECTED, 'Internal': RLPT_INTERNAL,
             'CurrentSource': RLPT_CURRENT_SOURCE, 'Supply': RLPT_SUPPLY, 'LowSideSwitch': RLPT_LOW_SIDE_SWITCH,
             'HighSideSwitch': RLPT_HIGH_SIDE_SWITCH, 'GroundLoss': RLPT_GROUND_LOSS,
             'CsrCrossConnect': RLPT_CSR_XCONN, 'PdcAbortInternal': RLPT_PDC_ABORT_INT,
             'PdcAbortExternal': RLPT_PDC_ABORT_EXT, 'Dwell': RLPT_DWELL},
    'DKA': {'Open': DKA_OPEN, 'S2G': DKA_S2G, 'S2B': DKA_S2B, 'LoRes': DKA_LORES, 'HiRes': DKA_HIRES,
            'CrossConnect': DKA_XCONN, 'UNEX': DKA_UNEXPECTED, 'Internal': DKA_INTERNAL,
            'CurrentSource': DKA_CURRENT_SOURCE, 'Supply': DKA_SUPPLY, 'LowSideSwitch': DKA_LOW_SIDE_SWITCH,
            'HighSideSwitch': DKA_HIGH_SIDE_SWITCH, 'GroundLoss': DKA_GROUND_LOSS, 'CsrCrossConnect': DKA_CSR_XCONN,
            'PdcAbortInternal': DKA_PDC_ABORT_INT, 'PdcAbortExternal': DKA_PDC_ABORT_EXT, 'Dwell': DKA_DWELL},
    'DAB': {'Open': DAB_OPEN, 'S2G': DAB_S2G, 'S2B': DAB_S2B, 'LoRes': DAB_LORES, 'HiRes': DAB_HIRES,
            'CrossConnect': DAB_XCONN, 'UNEX': DAB_UNEXPECTED, 'Internal': DAB_INTERNAL,
            'CurrentSource': DAB_CURRENT_SOURCE, 'Supply': DAB_SUPPLY, 'LowSideSwitch': DAB_LOW_SIDE_SWITCH,
            'HighSideSwitch': DAB_HIGH_SIDE_SWITCH, 'GroundLoss': DAB_GROUND_LOSS, 'CsrCrossConnect': DAB_CSR_XCONN,
            'PdcAbortInternal': DAB_PDC_ABORT_INT, 'PdcAbortExternal': DAB_PDC_ABORT_EXT, 'Dwell': DAB_DWELL},
    'PAB': {'Open': PAB_OPEN, 'S2G': PAB_S2G, 'S2B': PAB_S2B, 'LoRes': PAB_LORES, 'HiRes': PAB_HIRES,
            'CrossConnect': PAB_XCONN, 'UNEX': PAB_UNEXPECTED, 'Internal': PAB_INTERNAL,
            'CurrentSource': PAB_CURRENT_SOURCE, 'Supply': PAB_SUPPLY, 'LowSideSwitch': PAB_LOW_SIDE_SWITCH,
            'HighSideSwitch': PAB_HIGH_SIDE_SWITCH, 'GroundLoss': PAB_GROUND_LOSS, 'CsrCrossConnect': PAB_CSR_XCONN,
            'PdcAbortInternal': PAB_PDC_ABORT_INT, 'PdcAbortExternal': PAB_PDC_ABORT_EXT, 'Dwell': PAB_DWELL},
    'CAB': {'Open': CAB_OPEN, 'S2G': CAB_S2G, 'S2B': CAB_S2B, 'LoRes': CAB_LORES, 'HiRes': CAB_HIRES,
            'CrossConnect': CAB_XCONN, 'UNEX': CAB_UNEXPECTED, 'Internal': CAB_INTERNAL,
            'CurrentSource': CAB_CURRENT_SOURCE, 'Supply': CAB_SUPPLY, 'LowSideSwitch': CAB_LOW_SIDE_SWITCH,
            'HighSideSwitch': CAB_HIGH_SIDE_SWITCH, 'GroundLoss': CAB_GROUND_LOSS, 'CsrCrossConnect': CAB_CSR_XCONN,
            'PdcAbortInternal': CAB_PDC_ABORT_INT, 'PdcAbortExternal': CAB_PDC_ABORT_EXT, 'Dwell': CAB_DWELL},
    'R2LPT': {'Open': R2LPT_OPEN, 'S2G': R2LPT_S2G, 'S2B': R2LPT_S2B, 'LoRes': R2LPT_LORES, 'HiRes': R2LPT_HIRES,
              'CrossConnect': R2LPT_XCONN, 'UNEX': R2LPT_UNEXPECTED, 'Internal': R2LPT_INTERNAL,
              'CurrentSource': R2LPT_CURRENT_SOURCE, 'Supply': R2LPT_SUPPLY, 'LowSideSwitch': R2LPT_LOW_SIDE_SWITCH,
              'HighSideSwitch': R2LPT_HIGH_SIDE_SWITCH, 'GroundLoss': R2LPT_GROUND_LOSS,
              'CsrCrossConnect': R2LPT_CSR_XCONN, 'PdcAbortInternal': R2LPT_PDC_ABORT_INT,
              'PdcAbortExternal': R2LPT_PDC_ABORT_EXT, 'Dwell': R2LPT_DWELL},
    'R2RPT': {'Open': R2RPT_OPEN, 'S2G': R2RPT_S2G, 'S2B': R2RPT_S2B, 'LoRes': R2RPT_LORES, 'HiRes': R2RPT_HIRES,
              'CrossConnect': R2RPT_XCONN, 'UNEX': R2RPT_UNEXPECTED, 'Internal': R2RPT_INTERNAL,
              'CurrentSource': R2RPT_CURRENT_SOURCE, 'Supply': R2RPT_SUPPLY, 'LowSideSwitch': R2RPT_LOW_SIDE_SWITCH,
              'HighSideSwitch': R2RPT_HIGH_SIDE_SWITCH, 'GroundLoss': R2RPT_GROUND_LOSS,
              'CsrCrossConnect': R2RPT_CSR_XCONN, 'PdcAbortInternal': R2RPT_PDC_ABORT_INT,
              'PdcAbortExternal': R2RPT_PDC_ABORT_EXT, 'Dwell': R2RPT_DWELL},
    'DBFL': {'Open': DBFL_OPEN, 'S2G': DBFL_S2G, 'S2B': DBFL_S2B, 'LoRes': DBFL_LORES, 'HiRes': DBFL_HIRES,
             'CrossConnect': DBFL_XCONN, 'UNEX': DBFL_UNEXPECTED, 'Internal': DBFL_INTERNAL,
             'CurrentSource': DBFL_CURRENT_SOURCE, 'Supply': DBFL_SUPPLY, 'LowSideSwitch': DBFL_LOW_SIDE_SWITCH,
             'HighSideSwitch': DBFL_HIGH_SIDE_SWITCH, 'GroundLoss': DBFL_GROUND_LOSS,
             'CsrCrossConnect': DBFL_CSR_XCONN, 'PdcAbortInternal': DBFL_PDC_ABORT_INT,
             'PdcAbortExternal': DBFL_PDC_ABORT_EXT, 'Dwell': DBFL_DWELL},
    'PBFL': {'Open': PBFL_OPEN, 'S2G': PBFL_S2G, 'S2B': PBFL_S2B, 'LoRes': PBFL_LORES, 'HiRes': PBFL_HIRES,
             'CrossConnect': PBFL_XCONN, 'UNEX': PBFL_UNEXPECTED, 'Internal': PBFL_INTERNAL,
             'CurrentSource': PBFL_CURRENT_SOURCE, 'Supply': PBFL_SUPPLY, 'LowSideSwitch': PBFL_LOW_SIDE_SWITCH,
             'HighSideSwitch': PBFL_HIGH_SIDE_SWITCH, 'GroundLoss': PBFL_GROUND_LOSS,
             'CsrCrossConnect': PBFL_CSR_XCONN, 'PdcAbortInternal': PBFL_PDC_ABORT_INT,
             'PdcAbortExternal': PBFL_PDC_ABORT_EXT, 'Dwell': PBFL_DWELL},
}

# DCS channel (dcs_config / ods_config name) -> fault type -> fault.
DCS_FAULT_BY_CHANNEL = {
    'DCS_Second_Row_Right': {'S2B': R2R_BELT_S2B, 'CrossConnect': R2R_BELT_XCONN, 'Internal': R2R_BELT_ASIC,
                             'SPI': R2R_BELT_SPI},
    'DCS_DRVR': {'S2B': DRV_BELT_S2B, 'CrossConnect': DRV_BELT_XCONN, 'Internal': DRV_BELT_ASIC,
                 'SPI': DRV_BELT_SPI},
    'DCS_PSGR': {'S2B': PSGR_BELT_S2B, 'CrossConnect': PSGR_BELT_XCONN, 'Internal': PSGR_BELT_ASIC,
                 'SPI': PSGR_BELT_SPI},
    'DCS_Second_Row_Left': {'S2B': R2L_BELT_S2B, 'CrossConnect': R2L_BELT_XCONN, 'Internal': R2L_BELT_ASIC,
                            'SPI': R2L_BELT_SPI},
    'DCS_Second_Row_Middle': {'S2B': R2M_BELT_S2B, 'CrossConnect': R2M_BELT_XCONN, 'Internal': R2M_BELT_ASIC,
                              'SPI': R2M_BELT_SPI},
    'DCS_Driver_Seat_Track_Sensor_1': {'S2B': DRV_STPS1_S2B, 'S2G': DRV_STPS1_S2G, 'Open': DRV_STPS1_OPEN,
                                       'CrossConnect': DRV_STPS1_XCONN, 'UNEX': DRV_STPS1_UNEXPECTED,
                                       'Internal': DRV_STPS1_ASIC, 'SPI': DRV_STPS1_SPI},
    'DCS_Driver_Seat_Track_Sensor_2': {'UNEX': DRV_STPS2_UNEXPECTED, 'Internal': DRV_STPS2_ASIC,
                                       'SPI': DRV_STPS2_SPI},
    'DCS_Passenger_Seat_Track_Sensor_1': {'S2B': PSGR_STPS1_S2B, 'S2G': PSGR_STPS1_S2G, 'Open': PSGR_STPS1_OPEN,
                                          'CrossConnect': PSGR_STPS1_XCONN, 'UNEX': PSGR_STPS1_UNEXPECTED,
                                          'Internal': PSGR_STPS1_ASIC, 'SPI': PSGR_STPS1_SPI},
    'DCS_Passenger_Seat_Track_Sensor_2': {'UNEX': PSGR_STPS2_UNEXPECTED, 'Internal': PSGR_STPS2_ASIC,
                                          'SPI': PSGR_STPS2_SPI},
    'DCS_Second_Row_Right_ODS': {'S2B': R2R_ODS_S2B, 'CrossConnect': R2R_ODS_XCONN, 'Internal': R2R_ODS_ASIC,
                                 'SPI': R2R_ODS_SPI},
    'DCS_Second_Row_Left_ODS': {'S2B': R2L_ODS_S2B, 'CrossConnect': R2L_ODS_XCONN, 'Internal': R2L_ODS_ASIC,
                                'SPI': R2L_ODS_SPI},
    'DCS_Second_Row_Middle_ODS': {'S2B': R2M_ODS_S2B, 'CrossConnect': R2M_ODS_XCONN, 'Internal': R2M_ODS_ASIC,
                                  'SPI': R2M_ODS_SPI},
    'DCS_Third_Row_Right': {'S2B': R3R_BELT_S2B, 'CrossConnect': R3R_BELT_XCONN, 'Internal': R3R_BELT_ASIC,
                            'SPI': R3R_BELT_SPI},
    'DCS_Third_Row_Left': {'S2B': R3L_BELT_S2B, 'CrossConnect': R3L_BELT_XCONN, 'Internal': R3L_BELT_ASIC,
                           'SPI': R3L_BELT_SPI},
    'DCS_Third_Row_Right_ODS': {'S2B': R3R_ODS_S2B, 'CrossConnect': R3R_ODS_XCONN, 'Internal': R3R_ODS_ASIC,
                                'SPI': R3R_ODS_SPI},
    'DCS_Third_Row_Left_ODS': {'S2B': R3L_ODS_S2B, 'CrossConnect': R3L_ODS_XCONN, 'Internal': R3L_ODS_ASIC,
                               'SPI': R3L_ODS_SPI},
}

# GPO output (gpo_config name, plus ECALL) -> fault type -> fault.
GPO_FAULT_BY_OUTPUT = {
    'PAB_OFF': {'S2G': PAB_OFF_S2G, 'S2B': PAB_OFF_S2B, 'OPEN': PAB_OFF_OPEN, 'CONFIG': PAB_OFF_CONFIG,
                'THERMAL': PAB_OFF_THERMAL, 'INTERNAL': PAB_OFF_INTERNAL, 'SPI': PAB_OFF_SPI,
                'UNEX': PAB_OFF_UNEXPECTED},
    'PAB_ON': {'S2G': PAB_ON_S2G, 'S2B': PAB_ON_S2B, 'OPEN': PAB_ON_OPEN, 'CONFIG': PAB_ON_CONFIG,
               'THERMAL': PAB_ON_THERMAL, 'INTERNAL': PAB_ON_INTERNAL, 'SPI': PAB_ON_SPI,
               'UNEX': PAB_ON_UNEXPECTED},
    'ENS': {'S2G': ENS_S2G, 'S2B': ENS_S2B, 'OPEN': ENS_OPEN, 'CONFIG': ENS_CONFIG, 'THERMAL': ENS_THERMAL,
            'INTERNAL': ENS_INTERNAL, 'SPI': ENS_SPI, 'UNEX': ENS_UNEXPECTED},
    'ECALL': {'S2G': ECALL_S2G, 'S2B': ECALL_S2B, 'OPEN': ECALL_OPEN, 'CONFIG': ECALL_CONFIG,
              'THERMAL': ECALL_THERMAL, 'INTERNAL': ECALL_INTERNAL, 'SPI': ECALL_SPI, 'UNEX': ECALL_UNEXPECTED},
}

# RSU satellite sensor -> fault type (rsu_fault_code key) -> fault.
RSU_FAULT_BY_SATELLITE = {
    'A_PILLAR_LEFT_S1': {'Open': A_PILLAR_LEFT_S1_OPEN, 'S2G': A_PILLAR_LEFT_S1_S2G, 'S2B': A_PILLAR_LEFT_S1_S2B,
                         'Communication_Error': A_PILLAR_LEFT_S1_COMM, 'Internal_Error': A_PILLAR_LEFT_S1_INTERNAL,
                         'Config': A_PILLAR_LEFT_S1_CONFIG, 'UNEX': A_PILLAR_LEFT_S1_UNEXPECTED},
    'A_PILLAR_LEFT_S2': {'Open': A_PILLAR_LEFT_S2_OPEN, 'S2G': A_PILLAR_LEFT_S2_S2G, 'S2B': A_PILLAR_LEFT_S2_S2B,
                         'Communication_Error': A_PILLAR_LEFT_S2_COMM, 'Internal_Error': A_PILLAR_LEFT_S2_INTERNAL,
                         'Config': A_PILLAR_LEFT_S2_CONFIG, 'UNEX': A_PILLAR_LEFT_S2_UNEXPECTED},
    'PRESSURE_RIGHT_S3': {'Open': PRESSURE_RIGHT_S3_OPEN, 'S2G': PRESSURE_RIGHT_S3_S2G,
                          'S2B': PRESSURE_RIGHT_S3_S2B, 'Communication_Error': PRESSURE_RIGHT_S3_COMM,
                          'Internal_Error': PRESSURE_RIGHT_S3_INTERNAL, 'Config': PRESSURE_RIGHT_S3_CONFIG,
                          'UNEX': PRESSURE_RIGHT_S3_UNEXPECTED},
    'A_PILLAR_RIGHT_S1': {'Open': A_PILLAR_RIGHT_S1_OPEN, 'S2G': A_PILLAR_RIGHT_S1_S2G,
                          'S2B': A_PILLAR_RIGHT_S1_S2B, 'Communication_Error': A_PILLAR_RIGHT_S1_COMM,
                          'Internal_Error': A_PILLAR_RIGHT_S1_INTERNAL, 'Config': A_PILLAR_RIGHT_S1_CONFIG,
                          'UNEX': A_PILLAR_RIGHT_S1_UNEXPECTED},
    'A_PILLAR_RIGHT_S2': {'Open': A_PILLAR_RIGHT_S2_OPEN, 'S2G': A_PILLAR_RIGHT_S2_S2G,
                          'S2B': A_PILLAR_RIGHT_S2_S2B, 'Communication_Error': A_PILLAR_RIGHT_S2_COMM,
                          'Internal_Error': A_PILLAR_RIGHT_S2_INTERNAL, 'Config': A_PILLAR_RIGHT_S2_CONFIG,
                          'UNEX': A_PILLAR_RIGHT_S2_UNEXPECTED},
    'PRESSURE_LEFT_S3': {'Open': PRESSURE_LEFT_S3_OPEN, 'S2G': PRESSURE_LEFT_S3_S2G, 'S2B': PRESSURE_LEFT_S3_S2B,
                         'Communication_Error': PRESSURE_LEFT_S3_COMM, 'Internal_Error': PRESSURE_LEFT_S3_INTERNAL,
                         'Config': PRESSURE_LEFT_S3_CONFIG, 'UNEX': PRESSURE_LEFT_S3_UNEXPECTED},
    'B_PILLAR_LEFT_S1': {'Open': B_PILLAR_LEFT_S1_OPEN, 'S2G': B_PILLAR_LEFT_S1_S2G, 'S2B': B_PILLAR_LEFT_S1_S2B,
                         'Communication_Error': B_PILLAR_LEFT_S1_COMM, 'Internal_Error': B_PILLAR_LEFT_S1_INTERNAL,
                         'Config': B_PILLAR_LEFT_S1_CONFIG, 'UNEX': B_PILLAR_LEFT_S1_UNEXPECTED},
    'B_PILLAR_LEFT_S2': {'Open': B_PILLAR_LEFT_S2_OPEN, 'S2G': B_PILLAR_LEFT_S2_S2G, 'S2B': B_PILLAR_LEFT_S2_S2B,
                         'Communication_Error': B_PILLAR_LEFT_S2_COMM, 'Internal_Error': B_PILLAR_LEFT_S2_INTERNAL,
                         'Config': B_PILLAR_LEFT_S2_CONFIG, 'UNEX': B_PILLAR_LEFT_S2_UNEXPECTED},
    'B_PILLAR_RIGHT_S1': {'Open': B_PILLAR_RIGHT_S1_OPEN, 'S2G': B_PILLAR_RIGHT_S1_S2G,
                          'S2B': B_PILLAR_RIGHT_S1_S2B, 'Communication_Error': B_PILLAR_RIGHT_S1_COMM,
                          'Internal_Error': B_PILLAR_RIGHT_S1_INTERNAL, 'Config': B_PILLAR_RIGHT_S1_CONFIG,
                          'UNEX': B_PILLAR_RIGHT_S1_UNEXPECTED},
    'B_PILLAR_RIGHT_S2': {'Open': B_PILLAR_RIGHT_S2_OPEN, 'S2G': B_PILLAR_RIGHT_S2_S2G,
                          'S2B': B_PILLAR_RIGHT_S2_S2B, 'Communication_Error': B_PILLAR_RIGHT_S2_COMM,
                          'Internal_Error': B_PILLAR_RIGHT_S2_INTERNAL, 'Config': B_PILLAR_RIGHT_S2_CONFIG,
                          'UNEX': B_PILLAR_RIGHT_S2_UNEXPECTED},
    'FRONT_LEFT_S1': {'Open': FRONT_LEFT_S1_OPEN, 'S2G': FRONT_LEFT_S1_S2G, 'S2B': FRONT_LEFT_S1_S2B,
                      'Communication_Error': FRONT_LEFT_S1_COMM, 'Internal_Error': FRONT_LEFT_S1_INTERNAL,
                      'Config': FRONT_LEFT_S1_CONFIG, 'UNEX': FRONT_LEFT_S1_UNEXPECTED},
    'FRONT_LEFT_S2': {'Open': FRONT_LEFT_S2_OPEN, 'S2G': FRONT_LEFT_S2_S2G, 'S2B': FRONT_LEFT_S2_S2B,
                      'Communication_Error': FRONT_LEFT_S2_COMM, 'Internal_Error': FRONT_LEFT_S2_INTERNAL,
                      'Config': FRONT_LEFT_S2_CONFIG, 'UNEX': FRONT_LEFT_S2_UNEXPECTED},
    'FRONT_RIGHT_S1': {'Open': FRONT_RIGHT_S1_OPEN, 'S2G': FRONT_RIGHT_S1_S2G, 'S2B': FRONT_RIGHT_S1_S2B,
                       'Communication_Error': FRONT_RIGHT_S1_COMM, 'Internal_Error': FRONT_RIGHT_S1_INTERNAL,
                       'Config': FRONT_RIGHT_S1_CONFIG, 'UNEX': FRONT_RIGHT_S1_UNEXPECTED},
    'FRONT_RIGHT_S2': {'Open': FRONT_RIGHT_S2_OPEN, 'S2G': FRONT_RIGHT_S2_S2G, 'S2B': FRONT_RIGHT_S2_S2B,
                       'Communication_Error': FRONT_RIGHT_S2_COMM, 'Internal_Error': FRONT_RIGHT_S2_INTERNAL,
                       'Config': FRONT_RIGHT_S2_CONFIG, 'UNEX': FRONT_RIGHT_S2_UNEXPECTED},
    'C_PILLAR_LEFT_S1': {'Open': C_PILLAR_LEFT_S1_OPEN, 'S2G': C_PILLAR_LEFT_S1_S2G, 'S2B': C_PILLAR_LEFT_S1_S2B,
                         'Communication_Error': C_PILLAR_LEFT_S1_COMM, 'Internal_Error': C_PILLAR_LEFT_S1_INTERNAL,
                         'Config': C_PILLAR_LEFT_S1_CONFIG, 'UNEX': C_PILLAR_LEFT_S1_UNEXPECTED},
    'C_PILLAR_LEFT_S2': {'Open': C_PILLAR_LEFT_S2_OPEN, 'S2G': C_PILLAR_LEFT_S2_S2G, 'S2B': C_PILLAR_LEFT_S2_S2B,
                         'Communication_Error': C_PILLAR_LEFT_S2_COMM, 'Internal_Error': C_PILLAR_LEFT_S2_INTERNAL,
                         'Config': C_PILLAR_LEFT_S2_CONFIG, 'UNEX': C_PILLAR_LEFT_S2_UNEXPECTED},
    'C_PILLAR_RIGHT_S1': {'Open': C_PILLAR_RIGHT_S1_OPEN, 'S2G': C_PILLAR_RIGHT_S1_S2G,
                          'S2B': C_PILLAR_RIGHT_S1_S2B, 'Communication_Error': C_PILLAR_RIGHT_S1_COMM,
                          'Internal_Error': C_PILLAR_RIGHT_S1_INTERNAL, 'Config': C_PILLAR_RIGHT_S1_CONFIG,
                          'UNEX': C_PILLAR_RIGHT_S1_UNEXPECTED},
    'C_PILLAR_RIGHT_S2': {'Open': C_PILLAR_RIGHT_S2_OPEN, 'S2G': C_PILLAR_RIGHT_S2_S2G,
                          'S2B': C_PILLAR_RIGHT_S2_S2B, 'Communication_Error': C_PILLAR_RIGHT_S2_COMM,
                          'Internal_Error': C_PILLAR_RIGHT_S2_INTERNAL, 'Config': C_PILLAR_RIGHT_S2_CONFIG,
                          'UNEX': C_PILLAR_RIGHT_S2_UNEXPECTED},
    'UNDERBODY_S1': {'Open': UNDERBODY_S1_OPEN, 'S2G': UNDERBODY_S1_S2G, 'S2B': UNDERBODY_S1_S2B,
                     'Communication_Error': UNDERBODY_S1_COMM, 'Internal_Error': UNDERBODY_S1_INTERNAL,
                     'Config': UNDERBODY_S1_CONFIG, 'UNEX': UNDERBODY_S1_UNEXPECTED},
    'UNDERBODY_S2': {'Open': UNDERBODY_S2_OPEN, 'S2G': UNDERBODY_S2_S2G, 'S2B': UNDERBODY_S2_S2B,
                     'Communication_Error': UNDERBODY_S2_COMM, 'Internal_Error': UNDERBODY_S2_INTERNAL,
                     'Config': UNDERBODY_S2_CONFIG, 'UNEX': UNDERBODY_S2_UNEXPECTED},
    'REAR_S3': {'Open': REAR_S3_OPEN, 'S2G': REAR_S3_S2G, 'S2B': REAR_S3_S2B, 'Communication_Error': REAR_S3_COMM,
                'Internal_Error': REAR_S3_INTERNAL, 'Config': REAR_S3_CONFIG, 'UNEX': REAR_S3_UNEXPECTED},
}
