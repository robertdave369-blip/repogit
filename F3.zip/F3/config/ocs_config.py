"""
Module Configuration: OCS
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/ocs_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is OCS
    ctx.get_module_config("OCS").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "OCS"

# ── OCS Settings ──

CLASSIFICATION_MAP = {
    0x00: "Empty",
    0x01: "Child Seat (RF)",
    0x02: "Child Seat (FF)",
    0x03: "Adult Small",
    0x04: "Adult Average",
    0x05: "Adult Large",
}

