"""
Module Configuration: Phase of Life
Project: M310_M314_M110
============================================================

Location: projects/M310_M314_M110/config/plantmode_config.py

Accessed via:
    ctx = FrameworkContext(project="M310_M314_M110", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is PlantMode
    ctx.get_module_config("PlantMode").<SETTING>  # from any other module
"""

PROJECT_NAME = "M310_M314_M110"
MODULE_NAME = "PlantMode"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── Phase of Life Settings ──
# Transition semantics, persistence and calibration metadata below are taken
# from the supplied Phase-of-Life diagram. The released M314 tracker must
# confirm identifiers and security requirements before bench execution.
PHASE_OF_LIFE_ROUTINE_ID = 0xF106
PHASE_OF_LIFE_STATUS_DID = 0xFD73
ROUTINE_CONTROL_SID = 0x31
START_ROUTINE_SUBFUNCTION = 0x01
ROUTINE_CONTROL_POSITIVE_SID = 0x71
READ_DATA_BY_IDENTIFIER_SID = 0x22
READ_DATA_BY_IDENTIFIER_POSITIVE_SID = 0x62
DIAGNOSTIC_SESSION_CONTROL_SID = 0x10
DIAGNOSTIC_SESSION_CONTROL_POSITIVE_SID = 0x50
EXTERNAL_IDENTIFIER_EVIDENCE = "Externally supplied; tracker verification pending"

# The supplied transition test definition uses Extended session and L61 access
# for RoutineControl. Apply this only to F106 routine edges until tracker
# evidence confirms the exact session/security matrix for every direction.
ROUTINE_CONTROL_SESSION = 0x03
ROUTINE_CONTROL_SECURITY_LEVEL = 0x61
PHASE_OF_LIFE_TEST_REQUIREMENT_IDS = ("TBD",)

PHASE_OF_LIFE_STATES = {
    0x00: "DesignValidation",
    0x01: "Manufacturing",
    0x02: "VehicleAssembly",
    0x03: "Owner",
    0x04: "Service",
    0x05: "EndOfLife",
}

# Pink diagram arrow: fixed calibration supplies the initial Manufacturing
# phase. Grey arrows represent a learned phase persisted in NVM. The observed
# project flash flow is separate: it restores Design/Validation (0x00).
ECU_DEFAULT_PHASE_OF_LIFE = 0x01
DEFAULT_PHASE_OF_LIFE = ECU_DEFAULT_PHASE_OF_LIFE
ECU_DEFAULT_PHASE_OF_LIFE_STORAGE = "fixed_calibration"
ECU_LEARNED_PHASE_OF_LIFE_STORAGE = "nvm"
LEARNED_PHASES = frozenset({0x01, 0x02, 0x03})
NOT_LEARNED_PHASES = frozenset({0x04, 0x05})
TERMINAL_PHASES = frozenset({0x05})

PHASE_CALIBRATION_PROFILES = {
    0x00: "not_labeled_in_diagram",
    0x01: "specific_manufacturing_calibration",
    0x02: "vehicle_fixed_calibration",
    0x03: "vehicle_fixed_calibration",
    0x04: "not_labeled_in_diagram",
    0x05: "not_labeled_in_diagram",
}

# Diagram annotation: an unlearned End-of-Life state returns to End of Life
# after reset. The diagram does not define the behavior for other unlearned
# states, so it is deliberately not generalized into a global fallback rule.
END_OF_LIFE_RESET_BEHAVIOR = {
    "target_phase": 0x05,
    "condition": "current_phase_is_not_learned",
}

PHASE_OF_LIFE_ENTRY_CONDITIONS = {
    "ignition": "ON",
    "vehicle_speed_kmh": 0,
    "engine_running": False,
}

PHASE_OF_LIFE_TRANSITIONS = {
    (0x00, 0x01): {
        "operation_type": "routine_control",
        "operation": "enter_manufacturing",
        "routine_id": PHASE_OF_LIFE_ROUTINE_ID,
        "identifier_evidence": EXTERNAL_IDENTIFIER_EVIDENCE,
        "reset_required": True,
    },
    (0x01, 0x02): {
        "operation_type": "routine_control",
        "operation": "enter_vehicle_assembly",
        "routine_id": PHASE_OF_LIFE_ROUTINE_ID,
        "identifier_evidence": EXTERNAL_IDENTIFIER_EVIDENCE,
        "reset_required": True,
    },
    (0x00, 0x02): {
        "operation_type": "routine_control",
        "operation": "enter_vehicle_assembly",
        "routine_id": PHASE_OF_LIFE_ROUTINE_ID,
        "identifier_evidence": EXTERNAL_IDENTIFIER_EVIDENCE,
        "reset_required": False,
    },
    (0x01, 0x00): {
        "operation_type": "routine_control",
        "operation": "enter_design_validation",
        "routine_id": PHASE_OF_LIFE_ROUTINE_ID,
        "identifier_evidence": EXTERNAL_IDENTIFIER_EVIDENCE,
        "reset_required": False,
    },
    (0x02, 0x00): {
        "operation_type": "routine_control",
        "operation": "enter_design_validation",
        "routine_id": PHASE_OF_LIFE_ROUTINE_ID,
        "identifier_evidence": EXTERNAL_IDENTIFIER_EVIDENCE,
        "reset_required": False,
    },
    (0x02, 0x01): {
        "operation_type": "routine_control",
        "operation": "enter_manufacturing",
        "routine_id": PHASE_OF_LIFE_ROUTINE_ID,
        "identifier_evidence": EXTERNAL_IDENTIFIER_EVIDENCE,
        "reset_required": True,
    },
    (0x02, 0x03): {
        "operation_type": "configurable",
        "operation": "enter_owner",
        "reset_required": False,
    },
    (0x00, 0x05): {
        "operation_type": "diagnostic_session",
        "operation": "enter_safety_session",
        "session": 0x04,
        "reset_required": True,
    },
    (0x03, 0x05): {
        "operation_type": "diagnostic_session",
        "operation": "enter_safety_session",
        "session": 0x04,
        "reset_required": True,
    },
}

# Service is not a learned Phase-of-Life value. The diagram represents it as
# a diagnostic-session overlay, reached by default/extended-session behavior
# and left when that session expires; it is not a RoutineControl transition.
SERVICE_SESSION_OVERLAY = {
    "phase": 0x04,
    "entry_sessions": (0x01, 0x03),
    "exit_trigger": "extended_session_timeout",
    "extended_session_timeout_ms": 5000,
    "reset_required": False,
    "learned": False,
}

# Production setup after flashing: Design/Validation to Manufacturing, then
# Manufacturing to Vehicle Assembly (Plant Mode). Both transitions require a
# reset before the target phase becomes effective.
ROUTINE_TRANSITION_TEST_ORDER = (
    (0x00, 0x01),
    (0x01, 0x02),
)

# Plant Mode DTC behavior supplied for this project. It is the only active DTC
# allowed during the no-fault Plant Mode release test. It heals to 0x0A upon
# Plant-to-Owner transition, then becomes historic (0x08) after an Owner
# ignition cycle.
PLANT_MODE_DTC = {
    "code": "0x92 0x00 0x00",
    "active_status": "0x8B",
    "healed_status": "0x0A",
    "historic_status": "0x08",
}

# User-specified Vehicle Assembly behavior: Plant Mode enters Owner 30 seconds
# after Plant entry only when no DTC other than PLANT_MODE_DTC is active. An
# unrelated active loop-open DTC holds Plant Mode; after the physical fault is
# removed, the same 30-second fault-free timer applies. Loop number, DTC code
# and debounce times are read from squibs_config.py by the test script.
PLANT_MODE_OWNER_TRANSITION_DELAY_MS = 30000
VEHICLE_ASSEMBLY_OWNER_HOLD_FAULT = {
    "squib_name": "RPT",
    "fault_type": "Open",
    "fault_free_to_owner_delay_ms": PLANT_MODE_OWNER_TRANSITION_DELAY_MS,
}

# SRS1_FD_10 warning-lamp behavior while a Plant Mode ECU is flashing. The
# message/signal and physical values are taken from the CAN-FD project config.
PLANT_MODE_FLASH_INDICATOR = {
    "channel": "CANFD",
    "frame": "SRS1_FD_10",
    "signal": "INDC_SRS",
    "before_flash_value": 0x00,
    "during_flash_value": 0x03,
    "sample_interval_ms": 100,
}

# Learned Phase-of-Life recovery is destructive. Flashing restores the
# user-observed Design/Validation phase for this project. It remains opt-in;
# the selected flash image and NVM erase policy require approval before use.
LEARNED_PHASE_ERASE_RECOVERY = {
    "enabled": False,
    "operation": "software_flashing",
    "post_flash_expected_phase": 0x00,
    "erase_evidence": "Unavailable; verify selected flash image and NVM policy",
}

INVALID_TRANSITIONS = frozenset(
    (source, target)
    for source in PHASE_OF_LIFE_STATES
    for target in PHASE_OF_LIFE_STATES
    if source != target and (source, target) not in PHASE_OF_LIFE_TRANSITIONS
)


def build_phase_of_life_start_routine(
    target_phase: int,
    source_phase: int | None = None,
) -> tuple[int, ...]:
    """Build a StartRoutine payload only for a configured routine transition."""
    if target_phase not in PHASE_OF_LIFE_STATES:
        raise ValueError(f"Unsupported phase-of-life target: 0x{target_phase:02X}")
    if source_phase is not None:
        transition = PHASE_OF_LIFE_TRANSITIONS.get((source_phase, target_phase))
        if transition is None or transition["operation_type"] != "routine_control":
            raise ValueError(
                f"No RoutineControl transition from 0x{source_phase:02X} "
                f"to 0x{target_phase:02X}"
            )
    elif not any(
        target == target_phase and transition["operation_type"] == "routine_control"
        for (_, target), transition in PHASE_OF_LIFE_TRANSITIONS.items()
    ):
        raise ValueError(f"Phase 0x{target_phase:02X} is not a RoutineControl target")
    return (
        ROUTINE_CONTROL_SID,
        START_ROUTINE_SUBFUNCTION,
        (PHASE_OF_LIFE_ROUTINE_ID >> 8) & 0xFF,
        PHASE_OF_LIFE_ROUTINE_ID & 0xFF,
        target_phase,
    )


def format_uds_bytes(payload: tuple[int, ...]) -> str:
    """Format a configured UDS payload for CAN.SendDiagByValues."""
    return " ".join(f"0x{value:02X}" for value in payload)


def build_phase_of_life_status_request() -> tuple[int, ...]:
    """Build the ReadDataByIdentifier request for the current lifecycle phase."""
    return (
        READ_DATA_BY_IDENTIFIER_SID,
        (PHASE_OF_LIFE_STATUS_DID >> 8) & 0xFF,
        PHASE_OF_LIFE_STATUS_DID & 0xFF,
    )


def build_phase_of_life_status_response(phase: int) -> tuple[int, ...]:
    """Build the expected positive DID response for a configured phase."""
    if phase not in PHASE_OF_LIFE_STATES:
        raise ValueError(f"Unsupported phase-of-life value: 0x{phase:02X}")
    return (
        READ_DATA_BY_IDENTIFIER_POSITIVE_SID,
        (PHASE_OF_LIFE_STATUS_DID >> 8) & 0xFF,
        PHASE_OF_LIFE_STATUS_DID & 0xFF,
        phase,
    )


def build_routine_control_positive_response(target_phase: int) -> tuple[int, ...]:
    """Build the expected positive response for a configured routine target."""
    return (
        ROUTINE_CONTROL_POSITIVE_SID,
        START_ROUTINE_SUBFUNCTION,
        (PHASE_OF_LIFE_ROUTINE_ID >> 8) & 0xFF,
        PHASE_OF_LIFE_ROUTINE_ID & 0xFF,
        target_phase,
    )
