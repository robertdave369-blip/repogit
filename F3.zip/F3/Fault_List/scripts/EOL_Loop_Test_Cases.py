# Author: Kris
#
# Script     : EOL_Loop_Test_Cases
# Objective  : Each squib loop EOL feature of eol_config.EOL_LOOP_TESTS disabled with the hardware
#              present: the feature's configuration DTC and the ECU configuration error
#              (eol_config.EOL_CONFIG_ERROR_DTC) active (0x8B) with the lamp ON; with the feature
#              enabled again both historic (0x08) and the lamp OFF; cleared.
# Targets    : eol_config.EOL_LOOP_TESTS; a feature of eol_config.EOL_PAB_Dependencies is switched
#              with its whole PAB group.
# Timing     : No timing grade: the DTCs are read after the start-up proveout that follows each EOL
#              write (manage_eol_code cycles the ignition).
# Notes      : EOL code written with the shared manage_eol_code: disabled = the project default with
#              the feature (group) cleared; enabled again = the project default itself, in which
#              every tested feature is on and PAB_MODE of the PAB group stays off. The cleanup
#              writes the project default back when the feature was left disabled.

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_POLL_INTERVAL_MS,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.eol_config import (
    EOL_CONFIG_ERROR_DTC,
    EOL_FEATURE_AVAILABLE_DTCS,
    EOL_LOOP_TESTS,
    EOL_PAB_Dependencies,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    PROJECT_NAME,
)


def run_test():
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_on = lamp_def['State_Values']['Lamp ON']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
    targets = list(EOL_LOOP_TESTS)
    print(f"{script_name}: {len(targets)} EOL features")
    for target_no, eol_test in enumerate(targets, start=1):
        feature = eol_test['feature']
        eol_changed = False
        feature_group = list(EOL_PAB_Dependencies) if feature in EOL_PAB_Dependencies else [feature]
        # eol_config gives each DTC as 'HHLL' plus its failure-type byte ('status_byte').
        fault_dtcs = [f"0x{record['dtc'][:2].upper()} 0x{record['dtc'][2:].upper()} 0x{record['status_byte'].upper()}"
                      for member in feature_group for record in EOL_FEATURE_AVAILABLE_DTCS.get(member, [])]
        if fault_dtcs:
            fault_dtcs.append(f"0x{EOL_CONFIG_ERROR_DTC['dtc'][:2].upper()} 0x{EOL_CONFIG_ERROR_DTC['dtc'][2:].upper()} "
                              f"0x{EOL_CONFIG_ERROR_DTC['status_byte'].upper()}")
        timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{script_name}_{target_no:02d}_{feature}"
        fault_text = f"EOL feature {feature} disabled with the squib loop present"
        tc_desc = (f"Verify that disabling EOL feature {feature} with the squib loop present sets its configuration "
                   f"DTC and the ECU configuration error with the warning lamp on, and that both are historic once "
                   f"the feature is enabled again.")
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids([lamp_def]), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
        try:
            missing = [label for label, value in (
                (f"eol_config.EOL_FEATURE_AVAILABLE_DTCS of {feature}", fault_dtcs),
            ) if not value]
            if missing:
                RESULT.LogCustomAction(
                    "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                    "Missing: " + ", ".join(missing), False)
                continue
            aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
            PS.SetVoltage(NOMINAL_VOLTAGE)
            fault_free_profile()
            # DTC status and warning lamp are valid only after the start-up proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            read_software_version()
            Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
            aria_reports.add_group("Step 2: Disable " + ", ".join(feature_group) + " in the EOL code")
            eol_result = manage_eol_code(feature_group, 'disable', project=PROJECT_NAME, base_from_project_default=True)
            eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
            RESULT.InterpretEqualResult(f"EOL code written with {', '.join(feature_group)} disabled",
                                        str(eol_status), "PASS")
            if eol_status != "PASS":
                aria_reports.close_group()
                continue
            eol_changed = True
            # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            settle_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs))
            RESULT.LogAction(f"Time until {timed_dtcs} is active after the start-up (ms)", None if settle_time_ms is None else round(settle_time_ms))
            Read_DTC('Configuration DTCs active with the feature disabled',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_on
            poll_label = f"Warning lamp ON with {timed_dtcs} active"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group("Step 3: Project default EOL code back - " + ", ".join(feature_group) + " enabled again")
            eol_result = manage_eol_code("DEFAULT", project=PROJECT_NAME)
            eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
            RESULT.InterpretEqualResult(f"Project default EOL code written ({', '.join(feature_group)} enabled again)",
                                        str(eol_status), "PASS")
            if eol_status != "PASS":
                aria_reports.close_group()
                continue
            eol_changed = False
            # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            Read_DTC('Configuration DTCs historic with the feature enabled again',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_historic']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} historic"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 4: Clear DTC and read DTC')
            ClearDTC()
            Read_DTC('No DTC present after clearing', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
        except Exception as raised:
            RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
        finally:
            try:
                if eol_changed:
                    manage_eol_code("DEFAULT", project=PROJECT_NAME)
                    Wait(PROVEOUT_COMPLETION_TIME)
            finally:
                aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
