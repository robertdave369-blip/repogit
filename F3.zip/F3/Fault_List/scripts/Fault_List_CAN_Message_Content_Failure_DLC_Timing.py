# Author: Kris
#
# Script     : Fault_List_CAN_Message_Content_Failure_DLC_Timing
# Objective  : Every CAN-C wrong DLC the configuration defines: DTC active (0x0B) within count x
#              period with the warning lamp off; healed (0x0A) within the recovery count x period;
#              historic (0x08) after an IGN cycle; cleared.
# Targets    : Every frame with a DLC (message content failure) DTC in canc_config.
# Timing     : Nominal = canc_config qualification_ms / recovery_ms (fault list count x frame
#              period); pass window nominal -10 % .. nominal +10 %
#              (CAN_FAULT_TIMING_TOLERANCE_PERCENT) + FAULT_TIME_MEASUREMENT_LAG_MS, the measured
#              DTC read lag.
# Notes      : Bench handling as in the CAN-C scripts, proven on the 2026-10-15 run; CAN DTC status
#              0x0B active (no lamp), 0x0A healed, 0x08 historic, read with 19 02 0B.
#            : Heal = reload of the default frame; the expected heal time is moved by the time from
#              the measurement's first DTC read to the first full-length frame in the CAN log.

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_DLC_ERROR_PAYLOAD_LENGTH,
    CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC,
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_SIGNAL_START_BIT,
    CAN_TX_MESSAGE_CONFIG,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    get_frame_message_content_failure_dtc,
    get_message_content_failure_signals,
    MAH_CAN_SIGNAL_DEFS,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    CAN_FD_CHANNEL_NAME,
    DIAG_TX_ID,
)


def run_test():
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
    qualify_tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT
    recover_tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT
    fault_mode = 'message_content'
    targets = [(frame_name, None) for frame_name in CAN_TX_MESSAGE_CONFIG
               if get_frame_message_content_failure_dtc(frame_name)[0]
               or CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(frame_name)]
    print(f"{script_name}: {len(targets)} targets")
    for target_no, (fault_frame, signal_key) in enumerate(targets, start=1):
        frame_def = next((d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame), None)
        fault_bus = frame_def['bus'] if frame_def else None
        fault_dtcs = [dtc for dtc in (get_frame_message_content_failure_dtc(fault_frame)[0]
                                      or CAN_DLC_ONLY_MESSAGE_CONTENT_FAILURE_DTC.get(fault_frame),) if dtc]
        dynamic_signals = [MAH_CAN_SIGNAL_DEFS[key]['signal'] for key in get_message_content_failure_signals(fault_frame)
                           if key in MAH_CAN_SIGNAL_DEFS]
        counter_key = next((key for key in get_message_content_failure_signals(fault_frame) if 'CRC' not in key.upper()), None)
        timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{script_name}_{target_no:02d}_" + fault_frame
        fault_text = f"payload of {fault_frame} shortened to {CAN_DLC_ERROR_PAYLOAD_LENGTH.get(frame_def['dlc']) if frame_def else None} bytes"
        tc_desc = (f"Verify that wrong DLC on {fault_frame} sets its DTC within count x period, heals within "
                   f"the recovery count x period and is historic after an IGN cycle.")
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids([frame_def] + [lamp_def] if frame_def else [lamp_def]), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
        try:
            missing = [label for label, value in (
                (f"MAH_CAN_SIGNAL_DEFS entry of {fault_frame}", frame_def),
                (f"wrong DLC DTC of {fault_frame}", fault_dtcs),
            ) if not value]
            if missing:
                RESULT.LogCustomAction(
                    "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                    "Missing: " + ", ".join(missing), False)
                continue
            qualify_nominal_ms = qualification_ms(fault_mode, frame_def['periodicity'])
            recover_nominal_ms = recovery_ms(fault_mode, frame_def['periodicity'])
            qualify_tolerance_ms = qualify_nominal_ms * qualify_tolerance_percent / 100
            recover_tolerance_ms = recover_nominal_ms * recover_tolerance_percent / 100
            RESULT.InsertComment(f"{fault_frame} period {frame_def['periodicity']} ms: "
                                 f"{qualify_nominal_ms // frame_def['periodicity']} frames to qualify, "
                                 f"{recover_nominal_ms // frame_def['periodicity']} frames to heal")
            aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
            for dynamic_signal in dynamic_signals:
                CAN.DynamicEnableSignal(fault_bus, fault_frame, dynamic_signal)
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
            fault_free_profile()
            # DTC status and warning lamp are valid only after the start-up proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            read_software_version()
            Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
            aria_reports.close_group()
            aria_reports.add_group(f"Step 2: Create fault - {fault_text}")
            # The frame itself goes out with the shorter payload (a second simulated frame on the same
            # identifier is refused by ARIA); the bench CRC / alive counter are held while it is short.
            error_payload = bytearray(CAN_DLC_ERROR_PAYLOAD_LENGTH[frame_def['dlc']])
            for dynamic_signal in dynamic_signals:
                CAN.DynamicDisableSignal(fault_bus, fault_frame, dynamic_signal)
            CAN.SetPeriodicFrame(fault_bus, fault_frame, frame_def['frame_ID'], frame_def['periodicity'],
                                 error_payload, frame_def['is_fd'])
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
            qualification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_active_WLOFF']}" for dtc in fault_dtcs))
            expected_ms = qualify_nominal_ms
            lower_ms = expected_ms - qualify_tolerance_ms
            upper_ms = expected_ms + qualify_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Qualification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{qualify_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{qualify_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(qualification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC active after the qualification time',
                     " ".join([Read_DTC_Resp_CANC] + [f"{dtc} {DTC_status['DTC_active_WLOFF']}" for dtc in fault_dtcs]),
                     Read_DTC_Req_CANC)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp stays OFF with {timed_dtcs} active (no lamp for this fault)"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group(f"Step 3: Remove fault - " + f"default payload of {fault_frame} reloaded")
            # The ECU counts valid frames only from the first full-length frame on the bus, so the reload
            # and the first 19 02 read of the measurement are logged: the time from that read to the first
            # full-length frame moves the expected heal time.
            restore_ids = [frame_def['frame_ID'], DIAG_TX_ID]
            restore_file = os.path.splitext(log_path)[0] + '_restore.txt'
            restore_logger = CAN.StartLoggingToFile(
                TestCase_ID=tc_name + '_restore', filepath=restore_file,
                listOption=restore_ids, channel_names=list(dict.fromkeys([fault_bus, CAN_FD_CHANNEL_NAME])))
            CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
            for dynamic_signal in dynamic_signals:
                CAN.DynamicEnableSignal(fault_bus, fault_frame, dynamic_signal)
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
            dequalification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs))
            CAN.StopLoggingToFile(restore_logger)
            restore_frames = []
            if os.path.isfile(restore_file):
                # ARIA writes a log with any extension other than .asc/.blf as text, one frame per line:
                # "<time s>\t<Can|CanFd> <channel>  <RX|TX>  l=<length>, id=<hex>, <payload bytes>".
                with open(restore_file, encoding='utf-8', errors='replace') as restore_log:
                    restore_fields = [line.split(',', 2) for line in restore_log if ' id=' in line and line.count(',') >= 2]
                restore_frames = [
                    SimpleNamespace(timestamp=round(float(fields[0].split()[0]) * 1e6),
                                    id=int(fields[1].split('=')[1], 16),
                                    payload=bytearray.fromhex(fields[2].strip()))
                    for fields in restore_fields]
            else:
                RESULT.LogCustomAction(f"CAN log {os.path.basename(restore_file)} written", "File present",
                                       "File missing: no frames to evaluate", False)
            restore_reads = [frame_data.timestamp for frame_data in restore_frames
                             if frame_data.id == DIAG_TX_ID and bytes(frame_data.payload[1:3]) == bytes([0x19, 0x02])]
            restore_rows = [frame_data for frame_data in restore_frames if frame_data.id == frame_def['frame_ID']]
            restore_short = [index for index, frame_data in enumerate(restore_rows) if len(frame_data.payload) != frame_def['dlc']]
            restore_full = next((index for index in range((restore_short[-1] + 1) if restore_short else 0, len(restore_rows))
                                 if len(restore_rows[index].payload) == frame_def['dlc']), None)
            if restore_full is None or not restore_reads:
                restart_ms = 0
                RESULT.LogCustomAction(
                    "First full-length frame and first DTC read after the reload", "Both in the CAN log",
                    "Not found: the heal time is graded from the measurement start", False)
            else:
                restart_ms = round((restore_rows[restore_full].timestamp - restore_reads[0]) / 1000, 1)
                RESULT.LogAction(f"{fault_frame} first full-length frame after the reload (ms after the first DTC read)",
                                 restart_ms)
                if restore_short and restore_full > 0:
                    RESULT.LogAction(f"{fault_frame} interval across the reload (ms, period {frame_def['periodicity']} ms)",
                                     round((restore_rows[restore_full].timestamp - restore_rows[restore_full - 1].timestamp) / 1000, 1))
                if counter_key in CAN_SIGNAL_START_BIT:
                    RESULT.LogAction(f"{counter_key} of the first frames after the reload", [
                        extract_can_signal(frame_data.payload, CAN_SIGNAL_START_BIT[counter_key],
                                           MAH_CAN_SIGNAL_DEFS[counter_key]['bit_length'])
                        for frame_data in restore_rows[restore_full:restore_full + 3]])
            expected_ms = recover_nominal_ms + restart_ms
            lower_ms = expected_ms - recover_tolerance_ms
            upper_ms = expected_ms + recover_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Dequalification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{recover_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{recover_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(dequalification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC healed after the dequalification time',
                     " ".join([Read_DTC_Resp_CANC] + [f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs]),
                     Read_DTC_Req_CANC)
            aria_reports.close_group()
            aria_reports.add_group('Step 4: Cycle IGN and read DTC')
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            Read_DTC('DTC historic after the IGN cycle',
                     " ".join([Read_DTC_Resp_CANC] + [f"{dtc} {DTC_status['DTC_historic']}" for dtc in fault_dtcs]),
                     Read_DTC_Req_CANC)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} historic"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 5: Clear DTC and read DTC')
            ClearDTC()
            Read_DTC('No DTC present after clearing', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
            aria_reports.close_group()
        except Exception as raised:
            RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
        finally:
            try:
                if frame_def:
                    CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
                    for dynamic_signal in dynamic_signals:
                        CAN.DynamicEnableSignal(fault_bus, fault_frame, dynamic_signal)
                    CAN.PeriodicEnableFrame(fault_bus, fault_frame)
            finally:
                aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
