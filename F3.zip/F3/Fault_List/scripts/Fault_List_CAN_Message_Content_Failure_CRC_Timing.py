# Author: Kris
#
# Script     : Fault_List_CAN_Message_Content_Failure_CRC_Timing
# Objective  : Every CAN-C CRC error the configuration defines: DTC active (0x0B) within count x
#              period with the warning lamp off; healed (0x0A) within the recovery count x period;
#              historic (0x08) after an IGN cycle; cleared.
# Targets    : Every CRC signal of canc_config get_message_content_failure_signals().
# Timing     : Nominal = canc_config qualification_ms / recovery_ms (fault list count x frame
#              period); pass window nominal -10 % .. nominal +10 %
#              (CAN_FAULT_TIMING_TOLERANCE_PERCENT) + FAULT_TIME_MEASUREMENT_LAG_MS, the measured
#              DTC read lag.
# Notes      : Bench handling as in the CAN-C scripts, proven on the 2026-10-15 run; CAN DTC status
#              0x0B active (no lamp), 0x0A healed, 0x08 historic, read with 19 02 0B.
#            : Not covered - the M310_M314_M110 CAN configuration defines no target for these fault
#              list entries: E2E_PIB_CRC (0x90 0x13 0x49), OCS1_CRC (0xE7 0x61 0x00).

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_POLL_INTERVAL_MS,
    CAN_FAULT_TIMING_TOLERANCE_PERCENT,
    CAN_TX_MESSAGE_CONFIG,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    get_message_content_failure_dtcs,
    get_message_content_failure_signals,
    MAH_CAN_SIGNAL_DEFS,
    qualification_ms,
    recovery_ms,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
    qualify_tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT
    recover_tolerance_percent = CAN_FAULT_TIMING_TOLERANCE_PERCENT
    fault_mode = 'message_content'
    targets = [(frame_name, signal_key) for frame_name in CAN_TX_MESSAGE_CONFIG
               for signal_key in get_message_content_failure_signals(frame_name) if 'CRC' in signal_key.upper()]
    print(f"{script_name}: {len(targets)} targets")
    for target_no, (fault_frame, signal_key) in enumerate(targets, start=1):
        frame_def = next((d for d in MAH_CAN_SIGNAL_DEFS.values() if d['frame'] == fault_frame), None)
        fault_bus = frame_def['bus'] if frame_def else None
        signal_name = MAH_CAN_SIGNAL_DEFS.get(signal_key, {}).get('signal')
        fault_dtcs = [dtc for dtc in (get_message_content_failure_dtcs(fault_frame).get(signal_key),) if dtc]
        timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{script_name}_{target_no:02d}_" + fault_frame + "_" + str(signal_key)
        fault_text = f"CRC of {fault_frame} no longer updated ({signal_name} held)"
        tc_desc = (f"Verify that CRC error on {fault_frame} sets its DTC within count x period, heals within "
                   f"the recovery count x period and is historic after an IGN cycle.")
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids([frame_def] + [lamp_def] if frame_def else [lamp_def]), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
        try:
            missing = [label for label, value in (
                (f"MAH_CAN_SIGNAL_DEFS entry of {fault_frame}", frame_def),
                (f"CRC error DTC of {fault_frame}", fault_dtcs),
                (f"signal of {signal_key}", signal_name),
            ) if not value]
            if missing:
                RESULT.LogCustomAction(
                    "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                    "Missing: " + ", ".join(missing), False)
                continue
            qualify_nominal_ms = qualification_ms(fault_mode, frame_def['periodicity'])
            recover_nominal_ms = recovery_ms(fault_mode, frame_def['periodicity'])
            qualify_tolerance_ms = qualify_nominal_ms * qualify_tolerance_percent / 100
            recover_tolerance_ms = recover_nominal_ms * recover_tolerance_percent / 100
            RESULT.InsertComment(f"{fault_frame} period {frame_def['periodicity']} ms: "
                                 f"{qualify_nominal_ms // frame_def['periodicity']} frames to qualify, "
                                 f"{recover_nominal_ms // frame_def['periodicity']} frames to heal")
            aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
            PS.SetVoltage(NOMINAL_VOLTAGE)
            CAN.PeriodicEnableFrame(fault_bus, fault_frame)
            CAN.ReloadDefaultPeriodicFrame(fault_bus, fault_frame)
            CAN.DynamicEnableSignal(fault_bus, fault_frame, signal_name)
            fault_free_profile()
            # DTC status and warning lamp are valid only after the start-up proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            read_software_version()
            Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
            aria_reports.close_group()
            aria_reports.add_group(f"Step 2: Create fault - {fault_text}")
            CAN.DynamicDisableSignal(fault_bus, fault_frame, signal_name)
            qualification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_active_WLOFF']}" for dtc in fault_dtcs))
            expected_ms = qualify_nominal_ms
            lower_ms = expected_ms - qualify_tolerance_ms
            upper_ms = expected_ms + qualify_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Qualification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{qualify_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{qualify_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(qualification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC active after the qualification time',
                     " ".join([Read_DTC_Resp_CANC] + [f"{dtc} {DTC_status['DTC_active_WLOFF']}" for dtc in fault_dtcs]),
                     Read_DTC_Req_CANC)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp stays OFF with {timed_dtcs} active (no lamp for this fault)"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group(f"Step 3: Remove fault - " + f"CRC of {fault_frame} updated again")
            CAN.DynamicEnableSignal(fault_bus, fault_frame, signal_name)
            dequalification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs))
            expected_ms = recover_nominal_ms
            lower_ms = expected_ms - recover_tolerance_ms
            upper_ms = expected_ms + recover_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Dequalification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{recover_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{recover_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(dequalification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC healed after the dequalification time',
                     " ".join([Read_DTC_Resp_CANC] + [f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs]),
                     Read_DTC_Req_CANC)
            aria_reports.close_group()
            aria_reports.add_group('Step 4: Cycle IGN and read DTC')
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            Read_DTC('DTC historic after the IGN cycle',
                     " ".join([Read_DTC_Resp_CANC] + [f"{dtc} {DTC_status['DTC_historic']}" for dtc in fault_dtcs]),
                     Read_DTC_Req_CANC)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} historic"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 5: Clear DTC and read DTC')
            ClearDTC()
            Read_DTC('No DTC present after clearing', Read_DTC_Resp_CANC, Read_DTC_Req_CANC)
            aria_reports.close_group()
        except Exception as raised:
            RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
        finally:
            try:
                if frame_def and signal_name:
                    CAN.DynamicEnableSignal(fault_bus, fault_frame, signal_name)
            finally:
                aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
