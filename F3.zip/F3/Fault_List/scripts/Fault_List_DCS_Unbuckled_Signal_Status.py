# Author: Kris
#
# Script     : Fault_List_DCS_Unbuckled_Signal_Status
# Objective  : Belt unbuckled (200R) after buckled is sent as Not Buckled on CAN without a DTC, and
#              again after an IGN cycle.
# Targets    : Every belt status signal of canc_config.CANC_BELT_CHANNEL (one report per belt).
# Timing     : Status read until it shows the value or PROVEOUT_COMPLETION_TIME has passed.
# Notes      : Rear belts: the seat ODS is set present first (canc_config.CANC_BELT_ODS; the rear
#              belt status needs it) and set back to not present in the cleanup.
#            : Passenger belt: the OCS class (bench-simulated OCS1_500) is set to the 50th-
#              percentile adult in the precondition, because with the seat empty the ECU sends
#              STS_SEAT_BLT_PSGR as Buckled whatever the switch (system requirement tables 1.7 /
#              1.9; ECU on 2026-10-15); the cleanup reloads the bench default OCS1_500 frame.
#            : Loads: dcs_config.DCS_Fault_Description buckle 800R / unbuckle 200R, canc_config
#              CANC_DCS_FAULT_LOAD for the fault, CANC_ODS_LOADS for the ODS, set with
#              SLS.SendRequest.

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_POLL_INTERVAL_MS,
    CANC_BELT_CHANNEL,
    CANC_BELT_ODS,
    CANC_DCS_FAULT_LOAD,
    CANC_ODS_CHANNEL,
    CANC_ODS_LOADS,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    DCSName,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.ods_config import (
    ODSChannelName,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
    unbuckle_load = DCS_Fault_Description['unbuckle']
    buckle_load = DCS_Fault_Description['buckle']
    fault_load = CANC_DCS_FAULT_LOAD
    ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
    targets = [(belt_key,) for belt_key in CANC_BELT_CHANNEL]
    print(f"{script_name}: {len(targets)} targets")
    for target_no, seat_keys in enumerate(targets, start=1):
        seat_channels = [CANC_BELT_CHANNEL[seat_key] for seat_key in seat_keys]
        seat_devices = [DCSName[name] for name in seat_channels]
        fault_dtcs = []
        timed_dtcs = " and ".join(fault_dtcs)
        seat_text = " and ".join(seat_keys)
        tc_name = f"{script_name}_{target_no:02d}_" + "_".join(seat_keys)
        fault_text = f"belt unbuckled ({unbuckle_load}) after buckled - {seat_text}"
        tc_desc = f"Verify that unbuckling {seat_text} is sent as Not Buckled on CAN without any DTC, also after an IGN cycle."
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids([MAH_CAN_SIGNAL_DEFS[seat_key] for seat_key in seat_keys] + [lamp_def, ocs_class_def]), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
        try:
            aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
            PS.SetVoltage(NOMINAL_VOLTAGE)
            # Passenger seat occupied for the OCS (50th-percentile adult): with the seat empty the ECU sends the
            # passenger belt as Buckled whatever the switch (system requirement tables 1.7 / 1.9).
            CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'], ocs_class_def['signal'],
                                  str(ocs_class_def['State_Values']['PERCENTILE_50TH_ADULT_DEFAULT']))
            for seat_device in seat_devices:
                RESULT.InterpretEqualResult(f"{seat_device} at rest ({unbuckle_load})", SLS.SendRequest(seat_device, unbuckle_load),
                                            f"{unbuckle_load} for {seat_device} set OK.")
            for seat_key in seat_keys:
                if CANC_BELT_ODS.get(seat_key):
                    SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
            fault_free_profile()
            # DTC status and warning lamp are valid only after the start-up proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            read_software_version()
            Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
            aria_reports.add_group('Step 2: Seat ODS present where the belt status needs it')
            for seat_key in seat_keys:
                ods_key = CANC_BELT_ODS.get(seat_key)
                if not ods_key:
                    continue
                ods_device = ODSChannelName[CANC_ODS_CHANNEL[ods_key]]
                RESULT.InterpretEqualResult(f"{ods_device} set to ODS present", SLS.SendRequest(ods_device, CANC_ODS_LOADS['PRESENT']),
                                            f"{CANC_ODS_LOADS['PRESENT']} for {ods_device} set OK.")
            for seat_key in seat_keys:
                ods_key = CANC_BELT_ODS.get(seat_key)
                if not ods_key:
                    continue
                poll_def = MAH_CAN_SIGNAL_DEFS[ods_key]
                poll_expected = MAH_CAN_SIGNAL_DEFS[ods_key]['State_Values']['PRESENT']
                poll_label = f"{ods_key} with the seat ODS present"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 3: Buckle the belt')
            for seat_device in seat_devices:
                RESULT.InterpretEqualResult(f"{seat_device} set to {buckle_load}", SLS.SendRequest(seat_device, buckle_load),
                                            f"{buckle_load} for {seat_device} set OK.")
            for seat_key in seat_keys:
                seat_states = MAH_CAN_SIGNAL_DEFS[seat_key]['State_Values']
                poll_def = MAH_CAN_SIGNAL_DEFS[seat_key]
                poll_expected = seat_states['Buckled']
                poll_label = f"{seat_key} buckled"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 4: Unbuckle the belt')
            for seat_device in seat_devices:
                RESULT.InterpretEqualResult(f"{seat_device} set to {unbuckle_load}", SLS.SendRequest(seat_device, unbuckle_load),
                                            f"{unbuckle_load} for {seat_device} set OK.")
            for seat_key in seat_keys:
                seat_states = MAH_CAN_SIGNAL_DEFS[seat_key]['State_Values']
                poll_def = MAH_CAN_SIGNAL_DEFS[seat_key]
                poll_expected = next(value for label, value in seat_states.items() if label.startswith('Not Buckled'))
                poll_label = f"{seat_key} unbuckled"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 5: No DTC with the belt status, also after an IGN cycle')
            Read_DTC('No DTC present', Read_DTC_Resp, Read_DTC_Req)
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            for seat_key in seat_keys:
                seat_states = MAH_CAN_SIGNAL_DEFS[seat_key]['State_Values']
                poll_def = MAH_CAN_SIGNAL_DEFS[seat_key]
                poll_expected = next(value for label, value in seat_states.items() if label.startswith('Not Buckled'))
                poll_label = f"{seat_key} after the IGN cycle"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
            Read_DTC('No DTC present after the IGN cycle', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
        except Exception as raised:
            RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
        finally:
            try:
                for seat_device in seat_devices:
                    SLS.SendRequest(seat_device, unbuckle_load)
                for seat_key in seat_keys:
                    if CANC_BELT_ODS.get(seat_key):
                        SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
                CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])
            finally:
                aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
