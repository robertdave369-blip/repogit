# Author: Kris
#
# Script     : Fault_List_DCS_Fault_CrossConnect
# Objective  : Pairs of belt buckles cross-connected (both on the BUS load, no leakage): both cross-
#              connect DTCs active (0x8B) within the qualification time and lamp ON; healed (0x0A)
#              within the dequalification time and lamp OFF; historic (0x08) after an IGN cycle;
#              cleared.
# Targets    : Belt buckle pairs of canc_config.CANC_BELT_CROSS_CONNECT_PARTNER, each pair once (4
#              pairs).
# Timing     : dcs_config.DCS_fault_time 1900 / 1900 (cross connect) ms + dcs_faultcounter_offset
#              (10 ms), tolerance percent 10; upper limit + FAULT_TIME_MEASUREMENT_LAG_MS.
# Notes      : Loads are set with SLS.SendRequest (no 1 s wait as in SET_DCS_LOADS).

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_POLL_INTERVAL_MS,
    CANC_BELT_CHANNEL,
    CANC_BELT_CROSS_CONNECT_PARTNER,
    CANC_DCS_FAULT_LOAD,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    DCS_fault_time,
    DCSName,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.fault_list_config import (
    DCS_FAULT_BY_CHANNEL,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)


def run_test():
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_on = lamp_def['State_Values']['Lamp ON']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
    fault_kind = 'CrossConnect'
    fault_load = CANC_DCS_FAULT_LOAD
    rest_load = DCS_Fault_Description['unbuckle']
    # Nominal fault times and tolerances (percent) from dcs_config.DCS_fault_time (cross-connect times, fault counter offset added).
    qualify_nominal_ms = DCS_fault_time['Qualification_CC'] + DCS_fault_time['dcs_faultcounter_offset']
    qualify_tolerance_percent = DCS_fault_time['Qualification_Tolerance']
    qualify_tolerance_ms = qualify_nominal_ms * qualify_tolerance_percent / 100
    recover_nominal_ms = DCS_fault_time['Dequalification_CC'] + DCS_fault_time['dcs_faultcounter_offset']
    recover_tolerance_percent = DCS_fault_time['Dequalification_Tolerance']
    recover_tolerance_ms = recover_nominal_ms * recover_tolerance_percent / 100
    # Pairs from canc_config.CANC_BELT_CROSS_CONNECT_PARTNER, each pair once.
    targets = []
    for belt_key, partner_key in CANC_BELT_CROSS_CONNECT_PARTNER.items():
        pair = (CANC_BELT_CHANNEL[belt_key], CANC_BELT_CHANNEL[partner_key])
        if pair not in targets and pair[::-1] not in targets:
            targets.append(pair)
    print(f"{script_name}: {len(targets)} channel pairs")
    for target_no, (first_channel, second_channel) in enumerate(targets, start=1):
        first_device = DCSName[first_channel]
        second_device = DCSName[second_channel]
        fault_entries = [DCS_FAULT_BY_CHANNEL.get(name, {}).get(fault_kind) for name in (first_channel, second_channel)]
        fault_dtcs = [entry['dtc'] for entry in fault_entries if entry and entry['dtc']]
        timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{script_name}_{target_no:02d}_{first_channel}_{second_channel}"
        fault_text = f"cross connection of {first_channel} and {second_channel} (both on {fault_load})"
        tc_desc = (f"Verify that a cross connection of {first_channel} and {second_channel} sets both "
                   f"cross-connect DTCs within the qualification time with the warning lamp on, that both heal "
                   f"within the dequalification time and are historic after an IGN cycle.")
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids([lamp_def]), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
        try:
            missing = [label for label, value in (
                (f"fault list cross-connect DTCs of {first_channel} and {second_channel}", len(fault_dtcs) == 2),
            ) if not value]
            if missing:
                RESULT.LogCustomAction(
                    "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                    "Missing: " + ", ".join(missing), False)
                continue
            aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
            PS.SetVoltage(NOMINAL_VOLTAGE)
            RESULT.InterpretEqualResult(f"{first_device} at rest ({rest_load})", SLS.SendRequest(first_device, rest_load),
                                        f"{rest_load} for {first_device} set OK.")
            RESULT.InterpretEqualResult(f"{second_device} at rest ({rest_load})", SLS.SendRequest(second_device, rest_load),
                                        f"{rest_load} for {second_device} set OK.")
            fault_free_profile()
            # DTC status and warning lamp are valid only after the start-up proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            read_software_version()
            Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
            aria_reports.add_group(f"Step 2: Create fault - {fault_text}")
            first_response = SLS.SendRequest(first_device, fault_load)
            RESULT.InterpretEqualResult(f"{first_device} ({first_channel}) set to {fault_load}", first_response,
                                        f"{fault_load} for {first_device} set OK.")
            if first_response != f"{fault_load} for {first_device} set OK.":
                aria_reports.close_group()
                continue
            second_response = SLS.SendRequest(second_device, fault_load)
            RESULT.InterpretEqualResult(f"{second_device} ({second_channel}) set to {fault_load}", second_response,
                                        f"{fault_load} for {second_device} set OK.")
            if second_response != f"{fault_load} for {second_device} set OK.":
                aria_reports.close_group()
                continue
            qualification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs))
            expected_ms = qualify_nominal_ms
            lower_ms = expected_ms - qualify_tolerance_ms
            upper_ms = expected_ms + qualify_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Qualification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{qualify_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{qualify_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(qualification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC active after the qualification time',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_on
            poll_label = f"Warning lamp ON with {timed_dtcs} active"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group(f"Step 3: Remove fault - both channels back to {rest_load}")
            first_response = SLS.SendRequest(first_device, rest_load)
            RESULT.InterpretEqualResult(f"{first_device} ({first_channel}) set back to {rest_load}", first_response,
                                        f"{rest_load} for {first_device} set OK.")
            second_response = SLS.SendRequest(second_device, rest_load)
            RESULT.InterpretEqualResult(f"{second_device} ({second_channel}) set back to {rest_load}", second_response,
                                        f"{rest_load} for {second_device} set OK.")
            dequalification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs))
            expected_ms = recover_nominal_ms
            lower_ms = expected_ms - recover_tolerance_ms
            upper_ms = expected_ms + recover_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Dequalification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{recover_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{recover_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(dequalification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC healed after the dequalification time',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} healed"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 4: Cycle IGN and read DTC')
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            Read_DTC('DTC historic after the IGN cycle',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_historic']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} historic"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 5: Clear DTC and read DTC')
            ClearDTC()
            Read_DTC('No DTC present after clearing', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
        except Exception as raised:
            RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
        finally:
            try:
                SLS.SendRequest(first_device, rest_load)
                SLS.SendRequest(second_device, rest_load)
            finally:
                aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
