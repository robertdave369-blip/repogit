# Author: Kris
#
# Script     : EOL_Switch_DCS_Test_Cases
# Objective  : EOL switch / DCS features. Seat switch or ODS: disabled and shorted to battery - no
#              DTC and the status sent as the default; enabled again with the short - its DTC active
#              (0x8B), lamp ON, status faulty; short removed - healed within the dequalification
#              time; historic after an IGN cycle; cleared. STPS sensor: configuration DTC + ECU
#              configuration error active while disabled, historic once enabled.
# Targets    : eol_config.EOL_SWITCH_DCS_TESTS (15 features; DOMS has no expected DTC in the
#              configuration and reports that).
# Timing     : dcs_config.DCS_fault_time 3200 / 3200 ms + dcs_faultcounter_offset (10 ms), tolerance
#              percent 10; upper limit + FAULT_TIME_MEASUREMENT_LAG_MS. (healing of the seat short).
# Notes      : The EOL feature -> seat channel table is written into the script (no configuration
#              table links them).
#            : Fault = canc_config CANC_DCS_FAULT_LOAD with the power card leakage VBAT to bus high;
#              DTC from fault_list_config.DCS_FAULT_BY_CHANNEL.
#            : Enabled again = the project default EOL code (manage_eol_code DEFAULT), in which
#              every tested feature is on.
#            : Passenger belt: the OCS class (bench-simulated OCS1_500) is set to the 50th-
#              percentile adult in the precondition, because with the seat empty the ECU sends
#              STS_SEAT_BLT_PSGR as Buckled whatever the switch (system requirement tables 1.7 /
#              1.9; ECU on 2026-10-15); the cleanup reloads the bench default OCS1_500 frame.

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides; the two
# ARIA calls come through it and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- M310_M314_M110 project configuration -------------------------------------
from Framework_IOEM_Py.projects.M310_M314_M110.config.canc_config import (
    CAN_FAULT_POLL_INTERVAL_MS,
    CANC_BELT_CHANNEL,
    CANC_BELT_ODS,
    CANC_DCS_FAULT_LOAD,
    CANC_ODS_CHANNEL,
    CANC_ODS_LOADS,
    FAULT_TIME_MEASUREMENT_LAG_MS,
    MAH_CAN_SIGNAL_DEFS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.dcs_config import (
    DCS_Fault_Description,
    DCS_fault_time,
    DCSName,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.eol_config import (
    EOL_CONFIG_ERROR_DTC,
    EOL_FEATURE_AVAILABLE_DTCS,
    EOL_PAB_Dependencies,
    EOL_SWITCH_DCS_TESTS,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.fault_list_config import (
    DCS_FAULT_BY_CHANNEL,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.ods_config import (
    ODSChannelName,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.power_config import (
    NOMINAL_VOLTAGE,
)
from Framework_IOEM_Py.projects.M310_M314_M110.config.project_config import (
    PROJECT_NAME,
)


def run_test():
    script_name = os.path.splitext(os.path.basename(__file__))[0]
    # faultTimeMeasurement sees a DTC change only after it happened: at most the bench-measured
    # lag later (canc_config FAULT_TIME_MEASUREMENT_LAG_MS), never earlier. The upper timing
    # limit therefore gets the lag on top and the lower limit does not.
    measurement_lag_ms = FAULT_TIME_MEASUREMENT_LAG_MS
    lamp_def = MAH_CAN_SIGNAL_DEFS['INDC_SRS']
    lamp_on = lamp_def['State_Values']['Lamp ON']
    lamp_off = lamp_def['State_Values']['Lamp OFF/Default']
    # EOL feature -> DCS / ODS channel. No configuration table links the two; both sides are names
    # from eol_config.EOL_SWITCH_DCS_FEATURES and dcs_config.DCSName / ods_config.ODSChannelName.
    eol_seat_channel = {
        'DRIVER_SEAT_BELT_BUCKLE_SWITCH': 'DCS_DRVR',
        'PASSENGER_SEAT_BELT_BUCKLE_SWITCH': 'DCS_PSGR',
        'SECOND_ROW_RIGHT_BUCKLE_SWITCH': 'DCS_Second_Row_Right',
        'SECOND_ROW_RIGHT_ODS': 'DCS_Second_Row_Right_ODS',
        'SECOND_ROW_MIDDLE_BUCKLE_SWITCH': 'DCS_Second_Row_Middle',
        'SECOND_ROW_MIDDLE_ODS': 'DCS_Second_Row_Middle_ODS',
        'SECOND_ROW_LEFT_BUCKLE_SWITCH': 'DCS_Second_Row_Left',
        'SECOND_ROW_LEFT_ODS': 'DCS_Second_Row_Left_ODS',
        'THIRD_ROW_RIGHT_BUCKLE_SWITCH': 'DCS_Third_Row_Right',
        'THIRD_ROW_RIGHT_ODS': 'DCS_Third_Row_Right_ODS',
        'THIRD_ROW_LEFT_BUCKLE_SWITCH': 'DCS_Third_Row_Left',
        'THIRD_ROW_LEFT_ODS': 'DCS_Third_Row_Left_ODS',
    }
    # Nominal fault times and tolerances (percent) from dcs_config.DCS_fault_time (fault counter offset added).
    qualify_nominal_ms = DCS_fault_time['Qualification'] + DCS_fault_time['dcs_faultcounter_offset']
    qualify_tolerance_percent = DCS_fault_time['Qualification_Tolerance']
    qualify_tolerance_ms = qualify_nominal_ms * qualify_tolerance_percent / 100
    recover_nominal_ms = DCS_fault_time['Dequalification'] + DCS_fault_time['dcs_faultcounter_offset']
    recover_tolerance_percent = DCS_fault_time['Dequalification_Tolerance']
    recover_tolerance_ms = recover_nominal_ms * recover_tolerance_percent / 100
    fault_load = CANC_DCS_FAULT_LOAD
    ocs_class_def = MAH_CAN_SIGNAL_DEFS['OCS_PASS_CLASS']
    targets = list(EOL_SWITCH_DCS_TESTS)
    print(f"{script_name}: {len(targets)} EOL features")
    for target_no, eol_test in enumerate(targets, start=1):
        feature = eol_test['feature']
        eol_changed = False
        seat_channel = eol_seat_channel.get(feature)
        seat_device = DCSName.get(seat_channel) or ODSChannelName.get(seat_channel)
        rest_load = DCS_Fault_Description['unbuckle'] if seat_channel in DCSName else CANC_ODS_LOADS['NOT_PRESENT']
        status_key = next((key for key, name in list(CANC_BELT_CHANNEL.items()) + list(CANC_ODS_CHANNEL.items())
                           if name == seat_channel), None)
        seat_keys = [status_key] if status_key in CANC_BELT_ODS else []
        feature_group = list(EOL_PAB_Dependencies) if feature in EOL_PAB_Dependencies else [feature]
        # eol_config gives each DTC as 'HHLL' plus its failure-type byte ('status_byte').
        fault_dtcs = [f"0x{record['dtc'][:2].upper()} 0x{record['dtc'][2:].upper()} 0x{record['status_byte'].upper()}"
                      for member in feature_group for record in EOL_FEATURE_AVAILABLE_DTCS.get(member, [])]
        if fault_dtcs:
            fault_dtcs.append(f"0x{EOL_CONFIG_ERROR_DTC['dtc'][:2].upper()} 0x{EOL_CONFIG_ERROR_DTC['dtc'][2:].upper()} "
                              f"0x{EOL_CONFIG_ERROR_DTC['status_byte'].upper()}")
        timed_dtcs = " and ".join(fault_dtcs)
        if not fault_dtcs and seat_channel:
            fault_entry = DCS_FAULT_BY_CHANNEL.get(seat_channel, {}).get('S2B')
            fault_dtcs = [fault_entry['dtc']] if fault_entry and fault_entry['dtc'] else []
            timed_dtcs = " and ".join(fault_dtcs)
        tc_name = f"{script_name}_{target_no:02d}_{feature}"
        fault_text = (f"EOL feature {feature} disabled, short to battery on {seat_channel}" if seat_channel and not
                      EOL_FEATURE_AVAILABLE_DTCS.get(feature) else f"EOL feature {feature} disabled with the sensor present")
        tc_desc = (f"Verify the EOL configuration of {feature}: disabled it is not monitored (no DTC for a seat "
                   f"switch, the configuration DTC for a sensor), enabled it is monitored again.")
        report_path, log_path = create_report_and_logging(
            tc_name, can_ids=resolve_can_log_ids([lamp_def, ocs_class_def]), tc_desc=tc_desc)
        aria_reports.add_report_info("#Test Case Name:", tc_name)
        aria_reports.add_report_info("#Fault:", fault_text)
        try:
            missing = [label for label, value in (
                (f"expected DTC of EOL feature {feature} (eol_config or the DCS/ODS fault list entry)", fault_dtcs),
                (f"CAN status signal of {seat_channel}", status_key or not seat_channel),
            ) if not value]
            if missing:
                RESULT.LogCustomAction(
                    "Configuration the case needs", "Present in the M310_M314_M110 configuration",
                    "Missing: " + ", ".join(missing), False)
                continue
            aria_reports.add_group('Step 1: Bench in normal condition, IGN ON, no DTC present')
            PS.SetVoltage(NOMINAL_VOLTAGE)
            # Passenger seat occupied for the OCS (50th-percentile adult): with the seat empty the ECU sends the
            # passenger belt as Buckled whatever the switch (system requirement tables 1.7 / 1.9).
            CAN.ChangeSignalValue(ocs_class_def['bus'], ocs_class_def['frame'], ocs_class_def['signal'],
                                  str(ocs_class_def['State_Values']['PERCENTILE_50TH_ADULT_DEFAULT']))
            if seat_device:
                PS.ClearLeakageVBATBusHigh()
                RESULT.InterpretEqualResult(f"{seat_device} at rest ({rest_load})", SLS.SendRequest(seat_device, rest_load),
                                            f"{rest_load} for {seat_device} set OK.")
            fault_free_profile()
            # DTC status and warning lamp are valid only after the start-up proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            read_software_version()
            Read_DTC('Bench is fault free with no DTC present', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
            if EOL_FEATURE_AVAILABLE_DTCS.get(feature) or not seat_channel:
                aria_reports.add_group("Step 2: Disable " + ", ".join(feature_group) + " in the EOL code")
                eol_result = manage_eol_code(feature_group, 'disable', project=PROJECT_NAME, base_from_project_default=True)
                eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
                RESULT.InterpretEqualResult(f"EOL code written with {', '.join(feature_group)} disabled",
                                            str(eol_status), "PASS")
                if eol_status != "PASS":
                    aria_reports.close_group()
                    continue
                eol_changed = True
                # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
                Wait(PROVEOUT_COMPLETION_TIME)
                settle_time_ms = faultTimeMeasurement(
                    ";".join(f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs))
                RESULT.LogAction(f"Time until {timed_dtcs} is active after the start-up (ms)", None if settle_time_ms is None else round(settle_time_ms))
                Read_DTC('Configuration DTCs active with the feature disabled',
                         " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs]),
                         Read_DTC_Req)
                poll_def = lamp_def
                poll_expected = lamp_on
                poll_label = f"Warning lamp ON with {timed_dtcs} active"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
                aria_reports.close_group()
                aria_reports.add_group("Step 3: Project default EOL code back - " + ", ".join(feature_group) + " enabled again")
                eol_result = manage_eol_code("DEFAULT", project=PROJECT_NAME)
                eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
                RESULT.InterpretEqualResult(f"Project default EOL code written ({', '.join(feature_group)} enabled again)",
                                            str(eol_status), "PASS")
                if eol_status != "PASS":
                    aria_reports.close_group()
                    continue
                eol_changed = False
                # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
                Wait(PROVEOUT_COMPLETION_TIME)
                Read_DTC('Configuration DTCs historic with the feature enabled again',
                         " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_historic']}" for dtc in fault_dtcs]),
                         Read_DTC_Req)
                poll_def = lamp_def
                poll_expected = lamp_off
                poll_label = f"Warning lamp OFF with {timed_dtcs} historic"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
                aria_reports.close_group()
                aria_reports.add_group('Step 4: Clear DTC and read DTC')
                ClearDTC()
                Read_DTC('No DTC present after clearing', Read_DTC_Resp, Read_DTC_Req)
                aria_reports.close_group()
                continue
            aria_reports.add_group("Step 2: Seat ODS present where the belt status needs it")
            for seat_key in seat_keys:
                ods_key = CANC_BELT_ODS.get(seat_key)
                if not ods_key:
                    continue
                ods_device = ODSChannelName[CANC_ODS_CHANNEL[ods_key]]
                RESULT.InterpretEqualResult(f"{ods_device} set to ODS present", SLS.SendRequest(ods_device, CANC_ODS_LOADS['PRESENT']),
                                            f"{CANC_ODS_LOADS['PRESENT']} for {ods_device} set OK.")
            for seat_key in seat_keys:
                ods_key = CANC_BELT_ODS.get(seat_key)
                if not ods_key:
                    continue
                poll_def = MAH_CAN_SIGNAL_DEFS[ods_key]
                poll_expected = MAH_CAN_SIGNAL_DEFS[ods_key]['State_Values']['PRESENT']
                poll_label = f"{ods_key} with the seat ODS present"
                poll_started = time.monotonic()
                while True:
                    poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                    poll_text = str(poll_text).strip()
                    try:
                        poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                    except ValueError:
                        poll_value = poll_text
                    poll_seconds = time.monotonic() - poll_started
                    if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                        break
                    time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
                RESULT.InterpretEqualResult(
                    f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                    str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group(f"Step 3: Disable {feature}, then short {seat_channel} to battery")
            eol_result = manage_eol_code(feature_group, 'disable', project=PROJECT_NAME, base_from_project_default=True)
            eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
            RESULT.InterpretEqualResult(f"EOL code written with {', '.join(feature_group)} disabled",
                                        str(eol_status), "PASS")
            if eol_status != "PASS":
                aria_reports.close_group()
                continue
            eol_changed = True
            # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            RESULT.InterpretEqualResult("Power card leakage VBAT to bus high set", PS.SetLeakageVBATBusHigh(), "0000")
            fault_response = SLS.SendRequest(seat_device, fault_load)
            RESULT.InterpretEqualResult(f"{seat_device} ({seat_channel}) set to {fault_load}", fault_response,
                                        f"{fault_load} for {seat_device} set OK.")
            if fault_response != f"{fault_load} for {seat_device} set OK.":
                aria_reports.close_group()
                continue
            # Not configured, the channel is not monitored: no DTC over the qualification time.
            Wait(int(qualify_nominal_ms + qualify_tolerance_ms + measurement_lag_ms))
            Read_DTC('No DTC with the feature disabled', Read_DTC_Resp, Read_DTC_Req)
            poll_def = MAH_CAN_SIGNAL_DEFS[status_key]
            poll_expected = MAH_CAN_SIGNAL_DEFS[status_key].get('Default_Value')
            poll_label = f"{status_key} sent as the default with {feature} disabled"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group(f"Step 4: Project default EOL code back - {feature} enabled again, the short still applied")
            eol_result = manage_eol_code("DEFAULT", project=PROJECT_NAME)
            eol_status = eol_result.get('status') if isinstance(eol_result, dict) else eol_result
            RESULT.InterpretEqualResult(f"Project default EOL code written ({', '.join(feature_group)} enabled again)",
                                        str(eol_status), "PASS")
            if eol_status != "PASS":
                aria_reports.close_group()
                continue
            eol_changed = False
            # manage_eol_code cycles the ignition after the write; the DTCs are valid after the proveout.
            Wait(PROVEOUT_COMPLETION_TIME)
            settle_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs))
            RESULT.LogAction(f"Time until {timed_dtcs} is active after the start-up (ms)", None if settle_time_ms is None else round(settle_time_ms))
            Read_DTC('Short-to-battery DTC active with the feature enabled',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_active']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_on
            poll_label = f"Warning lamp ON with {timed_dtcs} active"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            poll_def = MAH_CAN_SIGNAL_DEFS[status_key]
            poll_expected = next(value for label, value in MAH_CAN_SIGNAL_DEFS[status_key]['State_Values'].items() if 'FAULTY' in label.upper())
            poll_label = f"{status_key} faulty"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group(f"Step 5: Remove fault - {seat_device} back to {rest_load}")
            RESULT.InterpretEqualResult("Power card leakage VBAT to bus high cleared", PS.ClearLeakageVBATBusHigh(), "0000")
            heal_response = SLS.SendRequest(seat_device, rest_load)
            RESULT.InterpretEqualResult(f"{seat_device} ({seat_channel}) set back to {rest_load}", heal_response,
                                        f"{rest_load} for {seat_device} set OK.")
            dequalification_time_ms = faultTimeMeasurement(
                ";".join(f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs))
            expected_ms = recover_nominal_ms
            lower_ms = expected_ms - recover_tolerance_ms
            upper_ms = expected_ms + recover_tolerance_ms + measurement_lag_ms
            RESULT.InsertComment(f"Dequalification time of {timed_dtcs}: expected {expected_ms:g} ms, "
                                 f"limits {lower_ms:g} ms (-{recover_tolerance_percent:g} %) to {upper_ms:g} ms "
                                 f"(+{recover_tolerance_percent:g} % and the {measurement_lag_ms} ms measurement lag)")
            fault_time_check(dequalification_time_ms, (lower_ms + upper_ms) / 2, (upper_ms - lower_ms) / 2)
            Read_DTC('DTC healed after the dequalification time',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_healed']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} healed"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 6: Cycle IGN and read DTC')
            PS.Power_Cycle()
            Wait(PROVEOUT_COMPLETION_TIME)
            Read_DTC('DTC historic after the IGN cycle',
                     " ".join([Read_DTC_Resp] + [f"{dtc} {DTC_status['DTC_historic']}" for dtc in fault_dtcs]),
                     Read_DTC_Req)
            poll_def = lamp_def
            poll_expected = lamp_off
            poll_label = f"Warning lamp OFF with {timed_dtcs} historic"
            poll_started = time.monotonic()
            while True:
                poll_text = CAN.GetSignalFromFrame(poll_def['bus'], poll_def['frame'], poll_def['signal'])
                poll_text = str(poll_text).strip()
                try:
                    poll_value = int(poll_text, 16) if poll_text.lower().startswith("0x") else int(float(poll_text))
                except ValueError:
                    poll_value = poll_text
                poll_seconds = time.monotonic() - poll_started
                if str(poll_value) == str(poll_expected) or poll_seconds >= PROVEOUT_COMPLETION_TIME / 1000:
                    break
                time.sleep(CAN_FAULT_POLL_INTERVAL_MS / 1000)
            RESULT.InterpretEqualResult(
                f"{poll_label}: {poll_def['frame']} {poll_def['signal']} (read for {poll_seconds:.1f} s)",
                str(poll_value), str(poll_expected))
            aria_reports.close_group()
            aria_reports.add_group('Step 7: Clear DTC and read DTC')
            ClearDTC()
            Read_DTC('No DTC present after clearing', Read_DTC_Resp, Read_DTC_Req)
            aria_reports.close_group()
        except Exception as raised:
            RESULT.LogCustomAction("Test execution", "Completes without an exception", repr(raised), False)
        finally:
            try:
                if seat_device:
                    PS.ClearLeakageVBATBusHigh()
                    SLS.SendRequest(seat_device, rest_load)
                for seat_key in seat_keys:
                    SLS.SendRequest(ODSChannelName[CANC_ODS_CHANNEL[CANC_BELT_ODS[seat_key]]], CANC_ODS_LOADS['NOT_PRESENT'])
                CAN.ReloadDefaultPeriodicFrame(ocs_class_def['bus'], ocs_class_def['frame'])
                if eol_changed:
                    manage_eol_code("DEFAULT", project=PROJECT_NAME)
                    Wait(PROVEOUT_COMPLETION_TIME)
            finally:
                aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
