# Author: Kris
#
# EDR CAN-C 24.6, M210 (EV) - AEB_WARNING_MSG1 (HPCAd_3_50 / AEB_WARNING_MSG).
# Message timeout only before the crash (up to T0), both event records.
# The fault is created after one window of the first value and heals at the start
# of the T0 window, half-way between the last faulty sample and T0.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants,
# bench and report calls, EDR decoding). The two ARIA calls come through it and run
# before anything below uses the bench or the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration: the signal, its EDR element, the crash timing.
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_FAULT_TIMING_TOLERANCE_PERCENT, DTC_READ_EXTRA_WAIT_MS, MAH_CAN_SIGNAL_DEFS,
    qualification_ms, resolve_dtc_for_event,
)
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    EDR_DECODER_CONFIG, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS


def run_test():
    tc_id = "24.6"
    tc_desc = ("Message timeout only before the crash (up to T0): AEB_WARNING_MSG1 must "
               "hold the last valid value while the fault is present.")
    tc_behaviour = ("Message timeout: the ECU holds the last valid value while the frame "
                    "is missing.")

    # -- 1. What is tested, from the configuration ----------------------------------
    signal = MAH_CAN_SIGNAL_DEFS["AEB_WARNING_MSG1"]       # HPCAd_3_50 / AEB_WARNING_MSG
    frame, name = signal["frame"], signal["signal"]
    values = signal["TestCase_24_Values"]             # raw CAN values, one per sample
    element = EDR_PARAMETERS_BY_NAME[signal["EDR_Parameter"]]
    bits, unit = element["data_bit_length"], element["unit"]
    can_unit = signal.get("UNIT") or ""    # the CAN signal's unit, for the report

    # The recording grid: one sample every interval_ms, T0 at t0_index (edr_config).
    # Each value is driven for one window and T0 is the middle of the T0 window, so
    # every sample is taken half-way through the window of its own value. The ECU takes
    # T0 t0_offset_ms after the crash trigger (rsu_config, 0 when not known), so the
    # trigger fires that long before T0 and the samples stay on the T0 grid.
    crash_type = "front"
    interval_ms = get_sample_interval_ms(element["name"])
    time_axis, t0_index = build_time_axis_and_t0(element["name"], crash_type)
    t0_offset_ms = RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS["default"])
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    # Where the trigger falls: t0_offset_ms before T0, i.e. in window trigger_index,
    # trigger_wait_ms after it starts (the T0 window, half-way in, when the offset is 0).
    trigger_index, trigger_wait_ms = divmod(
        t0_index * interval_ms + interval_ms // 2 - t0_offset_ms, interval_ms)
    if t0_offset_ms < 0 or trigger_index < 0:
        raise ValueError(f"T0 offset {t0_offset_ms} ms does not fit before T0 in the record")
    # Message timeout: the frame that carries the signal stops (it is not the node's
    # key frame, so the node stays present).
    fault_frame = signal["fault_logic"]["non_key_timeout_frame"]
    can_dtc = resolve_dtc_for_event("message_timeout", fault_frame)    # canc_config DTC tables
    qualification = qualification_ms("message_timeout", signal["periodicity"])
    # The DTC may mature up to CAN_FAULT_TIMING_TOLERANCE_PERCENT later (canc_config).
    tolerance_ms = qualification * CAN_FAULT_TIMING_TOLERANCE_PERCENT / 100

    # -- 2. Expected results -------------------------------------------------------
    # Before T0 every sample holds the first value, driven before the fault started;
    # the fault heals before T0, so T0 and the samples after it record what is driven.
    expected = [values[0]] * t0_index + values[t0_index:]
    # Healed before T0 and no ignition cycle before the DTC read: healed status.
    expected_dtcs = " ".join([
        Read_DTC_Resp,
        Crash_DTC, DTC_status["DTC_active"],
        PT_Crash_DTC, DTC_status["DTC_active"],
        can_dtc, DTC_status["DTC_healed"],
    ])

    # -- 3. Report and bench ---------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#EDR Element:", element["name"])
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)

    # The expectations above assume one sample per driven value.
    RESULT.InterpretEqualResult(
        "Samples in the record = values driven",
        str(element["data_samples_number"]), str(len(values)))
    # The record keeps the CAN signal's resolution, so a recorded raw equals the CAN raw.
    RESULT.InterpretEqualResult(
        "Record resolution / offset = CAN resolution / offset",
        f"{format_physical(element['scaling_factor'])} / {format_physical(element['offset'])}",
        f"{format_physical(signal['Factor'])} / {format_physical(signal['Offset'])}")

    fault_free_profile()
    read_software_version()

    try:
        for did in EDR_RECORD_DIDS:
            # -- 4. Drive the recording interval, crash at T0 ------------------------
            load_crash_curves(crash_type)    # power-cycles the ECU with the crash curves loaded
            aria_reports.add_group(
                f"Record {did}: CAN simulation of {frame} / {name}, message timeout pre")
            # The ECU must receive a value before the fault starts: the first value is
            # driven for one window and is the last valid value the record must hold.
            CAN.ChangeSignalValue(frame, name, str(values[0]))
            RESULT.CommentStep(f"CAN simulation {frame} / {name} = {raw_hex(values[0], bits)}",
                               "for one window before the fault (the last valid value)")
            Wait(interval_ms)
            RESULT.InterpretEqualResult(
                f"CAN simulation: frame {fault_frame} stopped (message timeout)",
                CAN.PeriodicDisableFrame(fault_frame), f"Simulation Stopped on {fault_frame}")
            for index, raw in enumerate(values):
                if index == t0_index:
                    # Heal at the start of the T0 window: the sample before T0 still sees the
                    # fault, T0 is half a window later.
                    RESULT.InterpretEqualResult(
                        f"CAN simulation: frame {fault_frame} started again",
                        CAN.PeriodicEnableFrame(fault_frame), f"Simulation Started on {fault_frame}")
                # The values keep being driven while the fault is present.
                CAN.ChangeSignalValue(frame, name, str(raw))
                if index == trigger_index:
                    # The crash fires t0_offset_ms before T0, the middle of the T0 window.
                    Wait(trigger_wait_ms)
                    TriggerCrash()
                    Wait(interval_ms - trigger_wait_ms)
                else:
                    Wait(interval_ms)
                on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                RESULT.InterpretEqualResult(
                    f"CAN simulation {frame} / {name}, {time_axis[index]:+g} s sample: "
                    f"{format_physical(raw * signal['Factor'] + signal['Offset'])} {can_unit}",
                    raw_hex(on_bench, bits), raw_hex(raw, bits))
            aria_reports.close_group()

            # -- 5. DTCs, read once the interval is over ------------------------------
            Wait(qualification)    # the DTC is read only after its qualification time
            # Margin for a DTC that matures late within the timing tolerance (user decision 2026-10-22).
            Wait(record_ready_ms + tolerance_ms + DTC_READ_EXTRA_WAIT_MS)
            aria_reports.add_group(f"Record {did}: DTCs")
            Read_DTC("DTCs after the crash", expected_dtcs, Read_DTC_Req)
            aria_reports.close_group()

            # -- 6. The event record -------------------------------------------------
            Wait(record_ready_ms)
            response = read_edr_parameters(
                [element["name"]], did=did, crash_type=crash_type, return_data=True)
            recorded = edr_sample_records(element["name"], response["data"])
            aria_reports.add_group(f"Record {did}: {element['name']} as recorded")
            for index, raw in enumerate(expected):
                missing = {"hex": "no sample", "physical": "no sample"}
                sample = recorded[index] if index < len(recorded) else missing
                label = f"{element['name']} at {time_axis[index]:+g} s"
                RESULT.InterpretEqualResult(f"{label} - raw", sample["hex"], raw_hex(raw, bits))
                RESULT.InterpretEqualResult(
                    f"{label} - {unit}", format_physical(sample["physical"]),
                    format_physical(raw * element["scaling_factor"] + element["offset"]))
            aria_reports.close_group()

    finally:
        # -- 7. Restore the bench, even when a step above raised ------------------------
        # The fault is removed here too, in case a step above raised.
        CAN.PeriodicEnableFrame(fault_frame)
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
