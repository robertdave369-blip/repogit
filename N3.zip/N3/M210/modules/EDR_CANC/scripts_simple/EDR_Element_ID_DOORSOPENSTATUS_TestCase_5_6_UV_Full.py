# Author: Kris
#
# EDR CAN-C 5.6, M210 (EV) - DoorsOpenStatus (FR_ZONE3_100 / STS_DOOR).
# Under voltage at T0, one crash per value of TestCase_5_Values.
# Each value is driven for one window, then the supply goes out of range and a
# different value is driven; the record must hold the last valid value.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants,
# bench and report calls, EDR decoding). The two ARIA calls come through it and run
# before anything below uses the bench or the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration: the signal, its EDR element, the crash timing.
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    MAH_CAN_SIGNAL_DEFS, NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS,
)
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    EDR_DECODER_CONFIG, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import (
    NOMINAL_VOLTAGE, UNDERVOLTAGE_TEST_VOLTAGE,
)
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS
# The supply-voltage DTC is common to every project and defined once, in the shared
# configuration control. It is imported after the project configuration, so nothing
# there can replace it.
from Framework_IOEM_Py.shared_libraries.configuration_control import Under_Voltage


def run_test():
    tc_id = "5.6"
    tc_desc = ("Under voltage at T0: the DoorsOpenStatus snapshot must hold the last "
               "valid value.")
    tc_behaviour = ("Under voltage: the ECU holds the last valid value while the supply "
                    "is out of range.")

    # -- 1. What is tested, from the configuration ----------------------------------
    signal = MAH_CAN_SIGNAL_DEFS["STS_DOOR"]       # FR_ZONE3_100 / STS_DOOR
    frame, name = signal["frame"], signal["signal"]
    values = signal["TestCase_5_Values"]              # raw CAN values, one per sample
    element = EDR_PARAMETERS_BY_NAME[signal["EDR_Parameter"]]
    bits, unit = element["data_bit_length"], element["unit"]
    can_unit = signal.get("UNIT") or ""    # the CAN signal's unit, for the report

    # A snapshot element: the record keeps the one value present at T0. Each value is
    # driven, the crash fires half a window later, and the ECU takes T0 t0_offset_ms
    # after the trigger (rsu_config, 0 when not known) while the value is still driven.
    crash_type = "front"
    interval_ms = get_sample_interval_ms(element["name"])
    time_axis, t0_index = build_time_axis_and_t0(element["name"], crash_type)
    t0_offset_ms = RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS["default"])
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    # The crash fires half a window after the value is set and T0 follows t0_offset_ms
    # later, while the value is still driven.
    if t0_offset_ms < 0:
        raise ValueError(f"T0 offset {t0_offset_ms} ms: T0 cannot come before the trigger")
    # Under voltage: the supply goes to UNDERVOLTAGE_TEST_VOLTAGE (power_config).
    # After it is restored the ECU receives CAN again only NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS
    # (canc_config) later.
    restart_ms = NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS

    # -- 2. Expected results -------------------------------------------------------
    # Each crash records the value driven before the supply fault: the last valid value.
    crashes = list(values)
    if len(crashes) % len(EDR_RECORD_DIDS):
        crashes.append(crashes[0])    # both records are always written
    # The supply DTC reads 0x08 (on-fail rule: "for over and under voltage, status
    # remains 8").
    expected_dtcs = " ".join([
        Read_DTC_Resp,
        Crash_DTC, DTC_status["DTC_active"],
        PT_Crash_DTC, DTC_status["DTC_active"],
        Under_Voltage, DTC_status["DTC_historic"],
    ])

    # -- 3. Report and bench ---------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#EDR Element:", element["name"])
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)

    # A snapshot element holds one sample: each crash records one value.
    RESULT.InterpretEqualResult(
        "Samples in the record (snapshot)", str(element["data_samples_number"]), "1")
    # The record keeps the CAN signal's resolution, so a recorded raw equals the CAN raw.
    RESULT.InterpretEqualResult(
        "Record resolution / offset = CAN resolution / offset",
        f"{format_physical(element['scaling_factor'])} / {format_physical(element['offset'])}",
        f"{format_physical(signal['Factor'])} / {format_physical(signal['Offset'])}")

    fault_free_profile()
    read_software_version()

    try:
        for first in range(0, len(crashes), len(EDR_RECORD_DIDS)):
            for did, value in zip(EDR_RECORD_DIDS, crashes[first:first + len(EDR_RECORD_DIDS)]):
                expected = [value]

                # -- 4. Drive the T0 window, crash at T0 ----------------------------
                load_crash_curves(crash_type)    # power-cycles the ECU with the crash curves loaded
                aria_reports.add_group(
                    f"Record {did}: CAN simulation of {frame} / {name} = {value}, "
                    "under voltage")
                # The value is driven for one window first: it is the last valid value.
                CAN.ChangeSignalValue(frame, name, str(value))
                RESULT.CommentStep(f"CAN simulation {frame} / {name} = {raw_hex(value, bits)}",
                                   "for one window before the fault (the last valid value)")
                Wait(interval_ms)
                PS.SetVoltage(UNDERVOLTAGE_TEST_VOLTAGE)
                RESULT.CommentStep("Supply: under voltage", UNDERVOLTAGE_TEST_VOLTAGE, "V")
                # A different value is driven during the fault: a record holding it would show
                # the ECU did not keep the last valid value.
                candidates = values + [signal["MIN"], signal["MAX"]]
                raw = next(other for other in candidates if other != value)
                CAN.ChangeSignalValue(frame, name, str(raw))
                # The crash fires half a window after the value is set; T0 is t0_offset_ms later.
                Wait(interval_ms // 2)
                TriggerCrash()
                Wait(interval_ms - interval_ms // 2 + t0_offset_ms)
                on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                RESULT.InterpretEqualResult(
                    f"CAN simulation {frame} / {name}, T0 sample: "
                    f"{format_physical(raw * signal['Factor'] + signal['Offset'])} {can_unit}",
                    raw_hex(on_bench, bits), raw_hex(raw, bits))
                aria_reports.close_group()

                # -- 5. DTCs, read once the interval is over ------------------------------
                # The supply is restored before the DTCs are read, and the ECU is given its NM
                # restart delay to answer on the bus again.
                PS.SetVoltage(NOMINAL_VOLTAGE)
                RESULT.CommentStep("Supply: back to nominal", NOMINAL_VOLTAGE, "V")
                Wait(restart_ms)
                aria_reports.add_group(f"Record {did}: DTCs")
                Read_DTC("DTCs after the crash", expected_dtcs, Read_DTC_Req)
                aria_reports.close_group()

                # -- 6. The event record -------------------------------------------------
                Wait(record_ready_ms)
                response = read_edr_parameters(
                    [element["name"]], did=did, crash_type=crash_type, return_data=True)
                recorded = edr_sample_records(element["name"], response["data"])
                aria_reports.add_group(f"Record {did}: {element['name']} as recorded")
                for index, raw in enumerate(expected):
                    missing = {"hex": "no sample", "physical": "no sample"}
                    sample = recorded[index] if index < len(recorded) else missing
                    label = f"{element['name']} at T0"
                    RESULT.InterpretEqualResult(f"{label} - raw", sample["hex"], raw_hex(raw, bits))
                    RESULT.InterpretEqualResult(
                        f"{label} - {unit}", format_physical(sample["physical"]),
                        format_physical(raw * element["scaling_factor"] + element["offset"]))
                aria_reports.close_group()

            # Both records hold a locked crash: back to fault free (NVM cleared) for the
            # next pair.
            fault_free_profile()

    finally:
        # -- 7. Restore the bench, even when a step above raised ------------------------
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
