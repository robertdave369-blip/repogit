# Author: Kris
#
# EDR CAN-C 43.12, M210 (EV) - ELK_ONCOMING_WARNING1 (HPCAd_3_50 / ELK_ONCOMING_WARNING).
# Variant code error, both event records.
# The variant status bit of the variant code is cleared before both records (one
# ignition cycle applies it). The values keep being driven, so a record that followed
# them would show the ECU did not apply the on-fail value.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants,
# bench and report calls, EDR decoding). The two ARIA calls come through it and run
# before anything below uses the bench or the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration: the signal, its EDR element, the crash timing.
from Framework_IOEM_Py.projects.M210.config.canc_config import MAH_CAN_SIGNAL_DEFS
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    EDR_DECODER_CONFIG, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.M210.config.project_config import DEFAULT_VARIANT_CODE
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS


def run_test():
    tc_id = "43.12"
    tc_desc = ("Variant code error for both event records: ELK_ONCOMING_WARNING1 must "
               "hold the on-fail value.")
    tc_behaviour = "Variant code error: every sample records the on-fail value."

    # -- 1. What is tested, from the configuration ----------------------------------
    signal = MAH_CAN_SIGNAL_DEFS["ELK_ONCOMING_WARNING1"]
    frame, name = signal["frame"], signal["signal"]
    values = signal["TestCase_43_Values"]             # raw CAN values, one per sample
    element = EDR_PARAMETERS_BY_NAME[signal["EDR_Parameter"]]
    bits, unit = element["data_bit_length"], element["unit"]
    can_unit = signal.get("UNIT") or ""    # the CAN signal's unit, for the report

    # The recording grid: one sample every interval_ms, T0 at t0_index (edr_config).
    # Each value is driven for one window and T0 is the middle of the T0 window, so
    # every sample is taken half-way through the window of its own value. The ECU takes
    # T0 t0_offset_ms after the crash trigger (rsu_config, 0 when not known), so the
    # trigger fires that long before T0 and the samples stay on the T0 grid.
    crash_type = "front"
    interval_ms = get_sample_interval_ms(element["name"])
    time_axis, t0_index = build_time_axis_and_t0(element["name"], crash_type)
    t0_offset_ms = RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS["default"])
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    # Where the trigger falls: t0_offset_ms before T0, i.e. in window trigger_index,
    # trigger_wait_ms after it starts (the T0 window, half-way in, when the offset is 0).
    trigger_index, trigger_wait_ms = divmod(
        t0_index * interval_ms + interval_ms // 2 - t0_offset_ms, interval_ms)
    if t0_offset_ms < 0 or trigger_index < 0:
        raise ValueError(f"T0 offset {t0_offset_ms} ms does not fit before T0 in the record")
    # Variant code error: the variant status bit of the variant code is cleared, so the
    # ECU treats the whole variant code as in error and works with on-fail values.
    target = "VARIANT_STATUS"

    # -- 2. Expected results -------------------------------------------------------
    # On-fail requirement (canc_config TestCase_43_VC_Values): every sample holds one of
    # these codes.
    allowed = signal["TestCase_43_VC_Values"]
    # The variant status bit is clear: SRS Variant Code Error (D50600, warning lamp on,
    # ICE diagnostic specification) is set next to the crash DTCs.
    expected_dtcs = " ".join([
        Read_DTC_Resp,
        Crash_DTC, DTC_status["DTC_active"],
        PT_Crash_DTC, DTC_status["DTC_active"],
        Variant_Code_DTC, DTC_status["DTC_active"],
    ])

    # -- 3. Report and bench ---------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#EDR Element:", element["name"])
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)

    # The expectations above assume one sample per driven value.
    RESULT.InterpretEqualResult(
        "Samples in the record = values driven",
        str(element["data_samples_number"]), str(len(values)))
    # The record keeps the CAN signal's resolution, so a recorded raw equals the CAN raw.
    RESULT.InterpretEqualResult(
        "Record resolution / offset = CAN resolution / offset",
        f"{format_physical(element['scaling_factor'])} / {format_physical(element['offset'])}",
        f"{format_physical(signal['Factor'])} / {format_physical(signal['Offset'])}")

    fault_free_profile()
    read_software_version()

    try:
        # The fault is created before the crashes. The write starts from the project's default
        # variant code and includes the ignition cycle that applies it.
        result = manage_variant_code(target, "disable", base_variant_code=DEFAULT_VARIANT_CODE)
        RESULT.InterpretEqualResult(
            f"Variant code written with {target} cleared", result.get("status"), "PASS")
        RESULT.InterpretEqualResult(
            f"{target} was set in the default variant code, so clearing it changes it",
            "changed" if result.get("bit_before") != result.get("bit_after") else "unchanged",
            "changed")

        for did in EDR_RECORD_DIDS:
            # -- 4. Drive the recording interval, crash at T0 ------------------------
            load_crash_curves(crash_type)    # power-cycles the ECU with the crash curves loaded
            aria_reports.add_group(
                f"Record {did}: CAN simulation of {frame} / {name}, variant code error")
            for index, raw in enumerate(values):
                # The values keep being driven; the ECU must not use them.
                CAN.ChangeSignalValue(frame, name, str(raw))
                if index == trigger_index:
                    # The crash fires t0_offset_ms before T0, the middle of the T0 window.
                    Wait(trigger_wait_ms)
                    TriggerCrash()
                    Wait(interval_ms - trigger_wait_ms)
                else:
                    Wait(interval_ms)
                on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                RESULT.InterpretEqualResult(
                    f"CAN simulation {frame} / {name}, {time_axis[index]:+g} s sample: "
                    f"{format_physical(raw * signal['Factor'] + signal['Offset'])} {can_unit}",
                    raw_hex(on_bench, bits), raw_hex(raw, bits))
            aria_reports.close_group()

            # -- 5. DTCs, read once the interval is over ------------------------------
            aria_reports.add_group(f"Record {did}: DTCs")
            Read_DTC("DTCs after the crash", expected_dtcs, Read_DTC_Req)
            aria_reports.close_group()

            # -- 6. The event record -------------------------------------------------
            Wait(record_ready_ms)
            response = read_edr_parameters(
                [element["name"]], did=did, crash_type=crash_type, return_data=True)
            recorded = edr_sample_records(element["name"], response["data"])
            aria_reports.add_group(f"Record {did}: {element['name']} as recorded")
            for index in range(len(values)):
                sample = recorded[index] if index < len(recorded) else None
                label = f"{element['name']} at {time_axis[index]:+g} s"
                passed = sample is not None and sample["raw"] in allowed
                status = TestStatus.Passed if passed else TestStatus.Failed
                RESULT.InterpretEqualResult(
                    f"{label} - raw", sample["hex"] if sample else "no sample",
                    " or ".join(raw_hex(code, bits) for code in allowed), status)
            aria_reports.close_group()

    finally:
        # -- 7. Restore the bench, even when a step above raised ------------------------
        # fault_free_profile() below writes the default variant code back.
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
