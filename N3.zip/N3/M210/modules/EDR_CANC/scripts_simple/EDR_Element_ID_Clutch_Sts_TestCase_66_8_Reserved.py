# Author: Kris
#
# EDR CAN-C 66.8, M210 (EV) - CLUTCH_STS (EMS3_10 / CLUTCH_STS).
# NOT APPLICABLE TO M210 (EV): the CAN signal CLUTCH_STS is not in the M210 DBC, so the EDR
# element CLUTCH_STS is not configured for this variant and no runner runs this script. It is kept
# with the set for the common specification; the signal definition is the U171 (STS_ENG,
# Clutch_Sts) or M314 (CTRL_BRAKE_LIGHT, PIB_ACTIVE) one, canc_config
# NOT_APPLICABLE_CAN_SIGNAL_DEFS.
#
# Reserved code, both event records.
# Each reserved code of TestCase_66_Reserved_Values is driven for every sample of one crash;
# the crashes go two at a time into the event records, the NVM cleared after each pair.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants,
# bench and report calls, EDR decoding). The two ARIA calls come through it and run
# before anything below uses the bench or the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration: the signal, its EDR element, the crash timing.
from Framework_IOEM_Py.projects.M210.config.canc_config import NOT_APPLICABLE_CAN_SIGNAL_DEFS
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    EDR_DECODER_CONFIG, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS


def run_test():
    tc_id = "66.8"
    tc_desc = ("Reserved input: CLUTCH_STS must record each reserved code driven over the "
               "interval.")
    tc_behaviour = "A reserved code is a marker and is recorded as it stands."

    # -- 1. What is tested, from the configuration ----------------------------------
    signal = NOT_APPLICABLE_CAN_SIGNAL_DEFS["CLUTCH_STS"]       # EMS3_10 / CLUTCH_STS
    frame, name = signal["frame"], signal["signal"]
    values = signal["TestCase_66_Values"]             # raw CAN values, one per sample
    element = EDR_PARAMETERS_BY_NAME[signal["EDR_Parameter"]]
    bits, unit = element["data_bit_length"], element["unit"]
    can_unit = signal.get("UNIT") or ""    # the CAN signal's unit, for the report

    # The recording grid: one sample every interval_ms, T0 at t0_index (edr_config).
    # Each value is driven for one window and T0 is the middle of the T0 window, so
    # every sample is taken half-way through the window of its own value. The ECU takes
    # T0 t0_offset_ms after the crash trigger (rsu_config, 0 when not known), so the
    # trigger fires that long before T0 and the samples stay on the T0 grid.
    crash_type = "front"
    interval_ms = get_sample_interval_ms(element["name"])
    time_axis, t0_index = build_time_axis_and_t0(element["name"], crash_type)
    t0_offset_ms = RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS["default"])
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    # Where the trigger falls: t0_offset_ms before T0, i.e. in window trigger_index,
    # trigger_wait_ms after it starts (the T0 window, half-way in, when the offset is 0).
    trigger_index, trigger_wait_ms = divmod(
        t0_index * interval_ms + interval_ms // 2 - t0_offset_ms, interval_ms)
    if t0_offset_ms < 0 or trigger_index < 0:
        raise ValueError(f"T0 offset {t0_offset_ms} ms does not fit before T0 in the record")
    # -- 2. Expected results -------------------------------------------------------
    # One crash per reserved code of TestCase_66_Reserved_Values, each driven for the whole interval;
    # a reserved code is a marker, so the record holds it as it stands.
    codes = signal["TestCase_66_Reserved_Values"]
    crashes = [[code] * len(values) for code in codes]
    if len(crashes) % len(EDR_RECORD_DIDS):
        crashes.append(crashes[0])    # both records are always written
    # A front crash locks the crash and pretensioner DTCs; no CAN DTC is set.
    expected_dtcs = " ".join([
        Read_DTC_Resp,
        Crash_DTC, DTC_status["DTC_active"],
        PT_Crash_DTC, DTC_status["DTC_active"],
    ])

    # -- 3. Report and bench ---------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#EDR Element:", element["name"])
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)

    # The expectations above assume one sample per driven value.
    RESULT.InterpretEqualResult(
        "Samples in the record = values driven",
        str(element["data_samples_number"]), str(len(values)))
    # The record keeps the CAN signal's resolution, so a recorded raw equals the CAN raw.
    RESULT.InterpretEqualResult(
        "Record resolution / offset = CAN resolution / offset",
        f"{format_physical(element['scaling_factor'])} / {format_physical(element['offset'])}",
        f"{format_physical(signal['Factor'])} / {format_physical(signal['Offset'])}")

    fault_free_profile()
    read_software_version()

    try:
        for first in range(0, len(crashes), len(EDR_RECORD_DIDS)):
            for did, driven in zip(EDR_RECORD_DIDS, crashes[first:first + len(EDR_RECORD_DIDS)]):
                expected = list(driven)

                # -- 4. Drive the recording interval, crash at T0 --------------------
                load_crash_curves(crash_type)    # power-cycles the ECU with the crash curves loaded
                aria_reports.add_group(
                    f"Record {did}: CAN simulation of {frame} / {name} = {driven[0]}, "
                    "reserved code")
                for index, raw in enumerate(driven):
                    CAN.ChangeSignalValue(frame, name, str(raw))
                    if index == trigger_index:
                        # The crash fires t0_offset_ms before T0, the middle of the T0 window.
                        Wait(trigger_wait_ms)
                        TriggerCrash()
                        Wait(interval_ms - trigger_wait_ms)
                    else:
                        Wait(interval_ms)
                    on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                    RESULT.InterpretEqualResult(
                        f"CAN simulation {frame} / {name}, {time_axis[index]:+g} s sample: "
                        f"{format_physical(raw * signal['Factor'] + signal['Offset'])} {can_unit}",
                        raw_hex(on_bench, bits), raw_hex(raw, bits))
                aria_reports.close_group()

                # -- 5. DTCs, read once the interval is over ------------------------------
                aria_reports.add_group(f"Record {did}: DTCs")
                Read_DTC("DTCs after the crash", expected_dtcs, Read_DTC_Req)
                aria_reports.close_group()

                # -- 6. The event record -------------------------------------------------
                Wait(record_ready_ms)
                response = read_edr_parameters(
                    [element["name"]], did=did, crash_type=crash_type, return_data=True)
                recorded = edr_sample_records(element["name"], response["data"])
                aria_reports.add_group(f"Record {did}: {element['name']} as recorded")
                for index, raw in enumerate(expected):
                    missing = {"hex": "no sample", "physical": "no sample"}
                    sample = recorded[index] if index < len(recorded) else missing
                    label = f"{element['name']} at {time_axis[index]:+g} s"
                    RESULT.InterpretEqualResult(f"{label} - raw", sample["hex"], raw_hex(raw, bits))
                    RESULT.InterpretEqualResult(
                        f"{label} - {unit}", format_physical(sample["physical"]),
                        format_physical(raw * element["scaling_factor"] + element["offset"]))
                aria_reports.close_group()

            # Both records hold a locked crash: clear the NVM for the next pair.
            NVM_Clear_L61()

    finally:
        # -- 7. Restore the bench, even when a step above raised ------------------------
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
