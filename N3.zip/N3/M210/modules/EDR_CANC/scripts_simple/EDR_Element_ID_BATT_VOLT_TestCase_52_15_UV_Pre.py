# Author: Kris
#
# EDR CAN-C 52.15, M210 (EV) - BATT_VOLT (FR_ZONE3_100 / ZONAL_BATT_VOLT).
# Under voltage only before the crash (up to T0), both event records.
# The ECU stops taking CAN values while the supply is out of range and holds the last
# valid value; after the supply recovers it waits the NM restart delay before it
# receives again.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants,
# bench and report calls, EDR decoding). The two ARIA calls come through it and run
# before anything below uses the bench or the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration: the signal, its EDR element, the crash timing.
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    MAH_CAN_SIGNAL_DEFS, NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS,
)
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    EDR_DECODER_CONFIG, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import (
    NOMINAL_VOLTAGE, UNDERVOLTAGE_TEST_VOLTAGE,
)
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS
# The supply-voltage DTC is common to every project and defined once, in the shared
# configuration control. It is imported after the project configuration, so nothing
# there can replace it.
from Framework_IOEM_Py.shared_libraries.configuration_control import Under_Voltage


def run_test():
    tc_id = "52.15"
    tc_desc = ("Under voltage only before the crash (up to T0): BATT_VOLT must hold the "
               "last valid value while the supply is out of range.")
    tc_behaviour = ("Under voltage: the ECU holds the last valid value while the supply "
                    "is out of range.")

    # -- 1. What is tested, from the configuration ----------------------------------
    signal = MAH_CAN_SIGNAL_DEFS["BATT_VOLT"]       # FR_ZONE3_100 / ZONAL_BATT_VOLT
    frame, name = signal["frame"], signal["signal"]
    values = signal["TestCase_52_Values"]             # raw CAN values, one per sample
    element = EDR_PARAMETERS_BY_NAME[signal["EDR_Parameter"]]
    bits, unit = element["data_bit_length"], element["unit"]
    can_unit = signal.get("UNIT") or ""    # the CAN signal's unit, for the report

    # The recording grid: one sample every interval_ms, T0 at t0_index (edr_config).
    # Each value is driven for one window and T0 is the middle of the T0 window, so
    # every sample is taken half-way through the window of its own value. The ECU takes
    # T0 t0_offset_ms after the crash trigger (rsu_config, 0 when not known), so the
    # trigger fires that long before T0 and the samples stay on the T0 grid.
    crash_type = "front"
    interval_ms = get_sample_interval_ms(element["name"])
    time_axis, t0_index = build_time_axis_and_t0(element["name"], crash_type)
    t0_offset_ms = RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS["default"])
    record_ready_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    # Where the trigger falls: t0_offset_ms before T0, i.e. in window trigger_index,
    # trigger_wait_ms after it starts (the T0 window, half-way in, when the offset is 0).
    trigger_index, trigger_wait_ms = divmod(
        t0_index * interval_ms + interval_ms // 2 - t0_offset_ms, interval_ms)
    if t0_offset_ms < 0 or trigger_index < 0:
        raise ValueError(f"T0 offset {t0_offset_ms} ms does not fit before T0 in the record")
    # Under voltage: the supply goes to UNDERVOLTAGE_TEST_VOLTAGE (power_config).
    # After it is restored the ECU receives CAN again only NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS
    # (canc_config) later.
    restart_ms = NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS
    # The supply is restored early enough that CAN comes back at the start of the T0
    # window: the sample before T0 still holds the last valid value, T0 is live.
    heal_index, heal_offset_ms = divmod(t0_index * interval_ms - restart_ms, interval_ms)
    if not 0 <= heal_index < t0_index:
        raise ValueError(f"NM restart delay {restart_ms} ms does not fit before the T0 window")

    # -- 2. Expected results -------------------------------------------------------
    # Before T0 every sample holds the first value, driven before the fault started;
    # the fault heals before T0, so T0 and the samples after it record what is driven.
    expected = [values[0]] * t0_index + values[t0_index:]
    # The supply DTC reads 0x08 whatever part of the interval it covers (on-fail
    # rule: "for over and under voltage, status remains 8").
    expected_dtcs = " ".join([
        Read_DTC_Resp,
        Crash_DTC, DTC_status["DTC_active"],
        PT_Crash_DTC, DTC_status["DTC_active"],
        Under_Voltage, DTC_status["DTC_historic"],
    ])

    # -- 3. Report and bench ---------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(
        test_case_file, can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#EDR Element:", element["name"])
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)

    # The expectations above assume one sample per driven value.
    RESULT.InterpretEqualResult(
        "Samples in the record = values driven",
        str(element["data_samples_number"]), str(len(values)))
    # The record keeps the CAN signal's resolution, so a recorded raw equals the CAN raw.
    RESULT.InterpretEqualResult(
        "Record resolution / offset = CAN resolution / offset",
        f"{format_physical(element['scaling_factor'])} / {format_physical(element['offset'])}",
        f"{format_physical(signal['Factor'])} / {format_physical(signal['Offset'])}")

    fault_free_profile()
    read_software_version()

    try:
        for did in EDR_RECORD_DIDS:
            # -- 4. Drive the recording interval, crash at T0 ------------------------
            load_crash_curves(crash_type)    # power-cycles the ECU with the crash curves loaded
            aria_reports.add_group(
                f"Record {did}: CAN simulation of {frame} / {name}, under voltage pre")
            # The ECU must receive a value before the fault starts: the first value is
            # driven for one window and is the last valid value the record must hold.
            CAN.ChangeSignalValue(frame, name, str(values[0]))
            RESULT.CommentStep(f"CAN simulation {frame} / {name} = {raw_hex(values[0], bits)}",
                               "for one window before the fault (the last valid value)")
            Wait(interval_ms)
            PS.SetVoltage(UNDERVOLTAGE_TEST_VOLTAGE)
            RESULT.CommentStep("Supply: under voltage", UNDERVOLTAGE_TEST_VOLTAGE, "V")
            for index, raw in enumerate(values):
                # The values keep being driven while the fault is present.
                CAN.ChangeSignalValue(frame, name, str(raw))
                # The supply restore and the crash trigger may fall in the same window (a long T0
                # offset), so the events of a window are done in time order, in ms from its start.
                events = []
                if index == heal_index:
                    events.append((heal_offset_ms, "restore the supply"))
                if index == trigger_index:
                    events.append((trigger_wait_ms, "trigger the crash"))
                elapsed = 0
                for at_ms, event in sorted(events):
                    Wait(at_ms - elapsed)
                    elapsed = at_ms
                    if event == "restore the supply":
                        PS.SetVoltage(NOMINAL_VOLTAGE)
                        RESULT.CommentStep("Supply: back to nominal", NOMINAL_VOLTAGE, "V")
                    else:
                        TriggerCrash()    # t0_offset_ms before T0, the middle of the T0 window
                Wait(interval_ms - elapsed)
                on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                RESULT.InterpretEqualResult(
                    f"CAN simulation {frame} / {name}, {time_axis[index]:+g} s sample: "
                    f"{format_physical(raw * signal['Factor'] + signal['Offset'])} {can_unit}",
                    raw_hex(on_bench, bits), raw_hex(raw, bits))
            aria_reports.close_group()

            # -- 5. DTCs, read once the interval is over ------------------------------
            aria_reports.add_group(f"Record {did}: DTCs")
            Read_DTC("DTCs after the crash", expected_dtcs, Read_DTC_Req)
            aria_reports.close_group()

            # -- 6. The event record -------------------------------------------------
            Wait(record_ready_ms)
            response = read_edr_parameters(
                [element["name"]], did=did, crash_type=crash_type, return_data=True)
            recorded = edr_sample_records(element["name"], response["data"])
            aria_reports.add_group(f"Record {did}: {element['name']} as recorded")
            for index, raw in enumerate(expected):
                missing = {"hex": "no sample", "physical": "no sample"}
                sample = recorded[index] if index < len(recorded) else missing
                label = f"{element['name']} at {time_axis[index]:+g} s"
                RESULT.InterpretEqualResult(f"{label} - raw", sample["hex"], raw_hex(raw, bits))
                RESULT.InterpretEqualResult(
                    f"{label} - {unit}", format_physical(sample["physical"]),
                    format_physical(raw * element["scaling_factor"] + element["offset"]))
            aria_reports.close_group()

    finally:
        # -- 7. Restore the bench, even when a step above raised ------------------------
        PS.SetVoltage(NOMINAL_VOLTAGE)
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
