"""
Module Configuration: POWER
Project: M210
============================================================

Location: projects/M210/config/power_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "POWER"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── POWER Settings ──
NOMINAL_VOLTAGE = 12.0
UNDERVOLTAGE_THRESHOLD = 9.0
OVERVOLTAGE_THRESHOLD = 16.0

# Supply levels the tests drive to create a voltage fault. They sit clear of the
# thresholds above rather than on them, so the excursion is unambiguous, and they are
# stated here rather than derived: the two projects do not share a threshold.
# The EDR CAN-C scripts take their supply levels from here and their voltage DTCs from
# configuration_control (user decision 2026-10-22).
UNDERVOLTAGE_TEST_VOLTAGE = 6.5
OVERVOLTAGE_TEST_VOLTAGE = 20.0

POWER_MODES = {
    "RUN":   0x01,
    "ACC":   0x02,
    "OFF":   0x03,
    "CRANK": 0x04,
}

POWER_ON_DELAY = 0.5
POWER_OFF_DELAY = 5.0
CRANK_DURATION = 2.0
