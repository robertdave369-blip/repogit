"""
Module Configuration: E_CALL
Project: M210
============================================================

Location: projects/M210/config/e_call_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "E_CALL"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── E_CALL Settings ──
ECALL_TRIGGER_DID = 0x0470
ECALL_STATUS_DID = 0x0471
ECALL_MSD_DID = 0x0472

ECALL_TYPES = {
    0x01: "Automatic",
    0x02: "Manual",
    0x03: "Test",
}

CALL_SETUP_TIMEOUT = 60
MSD_SEND_TIMEOUT = 10
CALLBACK_TIMEOUT = 3600

TEST_PSAP_NUMBER = "+00000000000"

# The ARIA function that drives the E-Call crash output (bench project
# aria_projects/M314/M314.project.json slot_map[64]: slot 27 channel 2, ARIA type Ens, relay
# group ENS). The E-Call output is not a gpo_config GPO, so the Fault_List scripts drive it
# through LAMPS.configure_lamp with this name (2026-10-22).
ECALL_ARIA_FUNCTION = "E-Call"
