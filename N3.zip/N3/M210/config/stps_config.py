"""
Module Configuration: STPS
Project: M210
============================================================

Location: projects/M210/config/stps_config.py
"""
# 2026-10-27 (user: ODS, STPS and DCS each in its own config): the STPS channels of
# dcs_config.py and the STPS settings of canc_config.py, values unchanged. Like the other
# M210 configs they come from projects/M310_M314_M110 (M314 values until confirmed).

PROJECT_NAME = "M210"
MODULE_NAME = "STPS"


# ── STPS Settings ──

# Seat Track Position Sensors (STPS)
STPSName = [
    "DCS_Driver_Seat_Track_Sensor_1",
    "DCS_Driver_Seat_Track_Sensor_2",
    "DCS_Passenger_Seat_Track_Sensor_1",
    "DCS_Passenger_Seat_Track_Sensor_2"
]

STPSNumber = {
    "DCS_Driver_Seat_Track_Sensor_1": 5,
    "DCS_Driver_Seat_Track_Sensor_2": 6,
    "DCS_Passenger_Seat_Track_Sensor_1": 7,
    "DCS_Passenger_Seat_Track_Sensor_2": 8
}

# Mapping: logical name -> software channel name. STPSName is bound twice, as it was in
# dcs_config: this mapping replaces the list above, so importers get the mapping.
STPSName = {
    "DCS_Driver_Seat_Track_Sensor_1": "SW_Channel_DCS_5",
    "DCS_Driver_Seat_Track_Sensor_2": "SW_Channel_DCS_6",
    "DCS_Passenger_Seat_Track_Sensor_1": "SW_Channel_DCS_7",
    "DCS_Passenger_Seat_Track_Sensor_2": "SW_Channel_DCS_8"
}

# ── STPS loads and channels (from canc_config.py, 2026-10-27) ──
# Source: project_reuirements/project_feature-context/dcs_ocs_stps_prompt.md.
# STPS: 6 mA reads Zone 2, 14 mA reads Zone 1 (bench note; driver and passenger only).
# A load change settles in dcs_config CANC_DCS_STATE_SETTLE_MS (the STPS channels are on
# the DCS card).
CANC_STPS_LOADS = {'ZONE_2': '6mA', 'ZONE_1': '14mA'}
# Both track sensors of a seat are driven together (as the DCS seat-system check
# does): FR is the driver seat, FL the passenger seat (right-hand drive).
CANC_STPS_CHANNEL = {
    'SRS_STPS_ZONE_FR': ['DCS_Driver_Seat_Track_Sensor_1', 'DCS_Driver_Seat_Track_Sensor_2'],
    'SRS_STPS_ZONE_FL': ['DCS_Passenger_Seat_Track_Sensor_1', 'DCS_Passenger_Seat_Track_Sensor_2'],
}
