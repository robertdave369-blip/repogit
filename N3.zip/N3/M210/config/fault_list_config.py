"""
Module Configuration: Fault_List
Project: M210
============================================================

Every fault of the project fault list, one entry per fault monitor, with a short name.

Source: project_reuirements/m310_m314_m110/DES_SW_Mahindra_FaultList.xlsx (Codebeamer export)
- 1055 faults that are not obsolete: 1012 in the project's fault set
  (FAULT_LIST) and 43 struck out by the customer (STRUCK_OUT_FAULTS).
Built with tools/build_m310_fault_list_config.py; rebuild it there rather than edit by hand.

Each fault is a dict:
    dtc               DTC with its failure type byte, as the ECU reports it in 19 02 (None: no DTC)
    qualify_ms        fault monitor maturation time in ms
    dequalify_ms      dematuration time in ms (both None where the list gives no plain ms value;
                      'timing' then quotes the list)
    qualify_counts /  CAN supervision: frames counted to mature / dematurate (time = count x
    dequalify_counts  the frame period)
    latched           True: stays active until cleared / over an IGN cycle (None: not given)
    monitor           fault monitor name in the fault list
    req               Codebeamer requirement ID
    text              fault list description (with the ECU fault event)

Lookups by bench name: LOOP_FAULT_BY_SQUIB (squibs_config names, Squib_FaultTypeCode keys),
DCS_FAULT_BY_CHANNEL (dcs_config / ods_config names, DCS_FaultTypeCode keys), GPO_FAULT_BY_OUTPUT
(gpo_config names, GPO_FaultStatus keys) and RSU_FAULT_BY_SATELLITE (rsu_fault_code keys).
Each fault monitor entry is the variable FM_<short name>; the dicts and lookups are keyed by the
short name.

After the project fault list: the Fault_List settings of the per-DTC scripts and the common EV / ICE
DTC list (one dict per DTC, named by its mnemonic) - the same section as in every project's
fault_list_config.py, from tools/build_common_dtc_dictionary.py.
"""

PROJECT_NAME = "M210"
MODULE_NAME = "Fault_List"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── Fault_List Settings ──


# ====================================================================================================
# Squib loops (400)
# One entry per squib and fault, named <squib>_<fault>; squibs as squibs_config names them (the
# fault list numbers the ECU lines: RPT line 0, LPT 1, RSA 2, LSA 3, RCA 4, LCA 5, DAB 6, PAB 7, DKA
# 11, RLPT 12, LLPT 13, R2RPT 16, CAB 17, R2LPT 18, DBFL 19, PBFL 20; LINE08-LINE10 are unconfigured
# lines and LINE24-LINE31 lines the ECU does not use). LOOP_ASIC<n>_* / LOOP<n>_CURRENT_MONITOR are
# per ASIC.
# ====================================================================================================
FM_RPT_OPEN = {'dtc': '0x80 0x70 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_00', 'req': 36069465,
               'text': 'LOP Open circuit failure Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_OPEN)'}
FM_RPT_S2G = {'dtc': '0x80 0x70 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_00', 'req': 36069365,
              'text': ('LOP Short to ground failure Line 0 '
                       '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_RPT_S2B = {'dtc': '0x80 0x70 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_00', 'req': 36069390,
              'text': ('LOP Short to battery failure Line 0 '
                       '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_RPT_LORES = {'dtc': '0x80 0x70 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_00', 'req': 36069415,
                'text': 'LOP Resistance too low Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_LOW_RES)'}
FM_RPT_HIRES = {'dtc': '0x80 0x70 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_00', 'req': 36069440,
                'text': 'LOP Resistance too high Line 0 (FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_HIGH_RES)'}
FM_RPT_XCONN = {'dtc': '0x80 0x70 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_00', 'req': 36069492,
                'text': ('LOP Cross connection failure Line 0 '
                         '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
FM_RPT_UNEXPECTED = {'dtc': '0x80 0x70 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_00', 'req': 36069549,
                     'text': ('LOP Present but not configured Line 0 '
                              '(FLTMONR_LOP_E_DRIVER_PRE_TENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
FM_RPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_00', 'req': 36069170,
                   'text': 'LOP ASIC internal error Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_00', 'req': 36069202,
                         'text': 'LOP monitor current failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_00', 'req': 36069235,
                 'text': 'LOP supply voltage failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_00', 'req': 36069269,
                          'text': 'LOP Low side driver failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_00', 'req': 36069301,
                           'text': 'LOP High side driver failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_00', 'req': 36069333,
                      'text': 'LOP Loose of ground connection Low Side 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_00', 'req': 36069517,
                    'text': 'LOP DR Cross connection failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_00', 'req': 36069616,
                        'text': 'loops PDC skipped due to internal condition Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_00', 'req': 36069584,
                        'text': 'loops PDC skipped due to external condition Line 0 (FLTMONR_NO_DTC_EVENT)'}
FM_RPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_00', 'req': 36069660,
                'text': 'LOP Firing time limiter and wording configuration failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_OPEN = {'dtc': '0x80 0x72 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_01', 'req': 36069466,
               'text': 'LOP Open circuit failure Line 1 (FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_OPEN)'}
FM_LPT_S2G = {'dtc': '0x80 0x72 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_01', 'req': 36069366,
              'text': ('LOP Short to ground failure Line 1 '
                       '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_LPT_S2B = {'dtc': '0x80 0x72 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_01', 'req': 36069391,
              'text': ('LOP Short to battery failure Line 1 '
                       '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_LPT_LORES = {'dtc': '0x80 0x72 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_01', 'req': 36069416,
                'text': 'LOP Resistance too low Line 1 (FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_LOW_RES)'}
FM_LPT_HIRES = {'dtc': '0x80 0x72 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_01', 'req': 36069441,
                'text': 'LOP Resistance too high Line 1 (FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_HIGH_RES)'}
FM_LPT_XCONN = {'dtc': '0x80 0x72 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_01', 'req': 36069493,
                'text': ('LOP Cross connection failure Line 1 '
                         '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
FM_LPT_UNEXPECTED = {'dtc': '0x80 0x72 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_01', 'req': 36069550,
                     'text': ('LOP Present but not configured Line 1 '
                              '(FLTMONR_LOP_E_PASSENGER_PRE_TENSIONER_UNEXPECTED_SQUIB)')}
FM_LPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_01', 'req': 36069171,
                   'text': 'LOP ASIC internal error Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_01', 'req': 36069203,
                         'text': 'LOP monitor current failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_01', 'req': 36069236,
                 'text': 'LOP supply voltage failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_01', 'req': 36069270,
                          'text': 'LOP Low side driver failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_01', 'req': 36069302,
                           'text': 'LOP High side driver failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_01', 'req': 36069334,
                      'text': 'LOP Loose of ground connection Low Side 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_01', 'req': 36069518,
                    'text': 'LOP DR Cross connection failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_01', 'req': 36069617,
                        'text': 'loops PDC skipped due to internal condition Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_01', 'req': 36069585,
                        'text': 'loops PDC skipped due to external condition Line 1 (FLTMONR_NO_DTC_EVENT)'}
FM_LPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_01', 'req': 36069661,
                'text': 'LOP Firing time limiter and wording configuration failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_OPEN = {'dtc': '0x92 0x06 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_02', 'req': 36069467,
               'text': 'LOP Open circuit failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_OPEN)'}
FM_RSA_S2G = {'dtc': '0x92 0x06 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_02', 'req': 36069367,
              'text': 'LOP Short to ground failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
FM_RSA_S2B = {'dtc': '0x92 0x06 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_02', 'req': 36069392,
              'text': 'LOP Short to battery failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_BAT)'}
FM_RSA_LORES = {'dtc': '0x92 0x06 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_02', 'req': 36069417,
                'text': 'LOP Resistance too low Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_LOW_RES)'}
FM_RSA_HIRES = {'dtc': '0x92 0x06 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_02', 'req': 36069442,
                'text': 'LOP Resistance too high Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_HIGH_RES)'}
FM_RSA_XCONN = {'dtc': '0x92 0x06 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_02', 'req': 36069494,
                'text': 'LOP Cross connection failure Line 2 (FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_CROSS_CONNECT)'}
FM_RSA_UNEXPECTED = {'dtc': '0x92 0x06 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_02', 'req': 36069551,
                     'text': ('LOP Present but not configured Line 2 '
                              '(FLTMONR_LOP_E_DRIVER_SIDE_AIRBAG_UNEXPECTED_SQUIB)')}
FM_RSA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_02', 'req': 36069172,
                   'text': 'LOP ASIC internal error Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_02', 'req': 36069204,
                         'text': 'LOP monitor current failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_02', 'req': 36069237,
                 'text': 'LOP supply voltage failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_02', 'req': 36069271,
                          'text': 'LOP Low side driver failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_02', 'req': 36069303,
                           'text': 'LOP High side driver failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_02', 'req': 36069335,
                      'text': 'LOP Loose of ground connection Low Side 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_02', 'req': 36069519,
                    'text': 'LOP DR Cross connection failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_02', 'req': 36069618,
                        'text': 'loops PDC skipped due to internal condition Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_02', 'req': 36069586,
                        'text': 'loops PDC skipped due to external condition Line 2 (FLTMONR_NO_DTC_EVENT)'}
FM_RSA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_02', 'req': 36069662,
                'text': 'LOP Firing time limiter and wording configuration failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_OPEN = {'dtc': '0x92 0x08 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_03', 'req': 36069468,
               'text': 'LOP Open circuit failure Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_OPEN)'}
FM_LSA_S2G = {'dtc': '0x92 0x08 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_03', 'req': 36069368,
              'text': ('LOP Short to ground failure Line 3 '
                       '(FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_GND)')}
FM_LSA_S2B = {'dtc': '0x92 0x08 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_03', 'req': 36069393,
              'text': ('LOP Short to battery failure Line 3 '
                       '(FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_SHORT_CIRCUIT_TO_BAT)')}
FM_LSA_LORES = {'dtc': '0x92 0x08 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_03', 'req': 36069418,
                'text': 'LOP Resistance too low Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_LOW_RES)'}
FM_LSA_HIRES = {'dtc': '0x92 0x08 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_03', 'req': 36069443,
                'text': 'LOP Resistance too high Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_HIGH_RES)'}
FM_LSA_XCONN = {'dtc': '0x92 0x08 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_03', 'req': 36069495,
                'text': 'LOP Cross connection failure Line 3 (FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_CROSS_CONNECT)'}
FM_LSA_UNEXPECTED = {'dtc': '0x92 0x08 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_03', 'req': 36069552,
                     'text': ('LOP Present but not configured Line 3 '
                              '(FLTMONR_LOP_E_PASSENGER_SIDE_AIRBAG_UNEXPECTED_SQUIB)')}
FM_LSA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_03', 'req': 36069173,
                   'text': 'LOP ASIC internal error Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_03', 'req': 36069205,
                         'text': 'LOP monitor current failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_03', 'req': 36069238,
                 'text': 'LOP supply voltage failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_03', 'req': 36069272,
                          'text': 'LOP Low side driver failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_03', 'req': 36069304,
                           'text': 'LOP High side driver failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_03', 'req': 36069336,
                      'text': 'LOP Loose of ground connection Low Side 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_03', 'req': 36069520,
                    'text': 'LOP DR Cross connection failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_03', 'req': 36069619,
                        'text': 'loops PDC skipped due to internal condition Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_LSA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_03', 'req': 36069587,
                        'text': 'loops PDC skipped due to external condition Line 3 (FLTMONR_NO_DTC_EVENT)'}
FM_LSA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_03', 'req': 36069663,
                'text': 'LOP Firing time limiter and wording configuration failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_OPEN = {'dtc': '0x92 0x07 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_04', 'req': 36069469,
               'text': 'LOP Open circuit failure Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_OPEN)'}
FM_RCA_S2G = {'dtc': '0x92 0x07 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_04', 'req': 36069369,
              'text': ('LOP Short to ground failure Line 4 '
                       '(FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_GND)')}
FM_RCA_S2B = {'dtc': '0x92 0x07 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_04', 'req': 36069394,
              'text': ('LOP Short to battery failure Line 4 '
                       '(FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_BAT)')}
FM_RCA_LORES = {'dtc': '0x92 0x07 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_04', 'req': 36069419,
                'text': 'LOP Resistance too low Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_LOW_RES)'}
FM_RCA_HIRES = {'dtc': '0x92 0x07 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_04', 'req': 36069444,
                'text': 'LOP Resistance too high Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_HIGH_RES)'}
FM_RCA_XCONN = {'dtc': '0x92 0x07 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_04', 'req': 36069496,
                'text': 'LOP Cross connection failure Line 4 (FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_CROSS_CONNECT)'}
FM_RCA_UNEXPECTED = {'dtc': '0x92 0x07 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_04', 'req': 36069553,
                     'text': ('LOP Present but not configured Line 4 '
                              '(FLTMONR_LOP_E_RIGHT_CURTAIN_AIRBAG_UNEXPECTED_SQUIB)')}
FM_RCA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_04', 'req': 36069174,
                   'text': 'LOP ASIC internal error Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_04', 'req': 36069206,
                         'text': 'LOP monitor current failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_04', 'req': 36069239,
                 'text': 'LOP supply voltage failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_04', 'req': 36069273,
                          'text': 'LOP Low side driver failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_04', 'req': 36069305,
                           'text': 'LOP High side driver failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_04', 'req': 36069337,
                      'text': 'LOP Loose of ground connection Low Side 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_04', 'req': 36069521,
                    'text': 'LOP DR Cross connection failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_04', 'req': 36069620,
                        'text': 'loops PDC skipped due to internal condition Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RCA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_04', 'req': 36069588,
                        'text': 'loops PDC skipped due to external condition Line 4 (FLTMONR_NO_DTC_EVENT)'}
FM_RCA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_04', 'req': 36069664,
                'text': 'LOP Firing time limiter and wording configuration failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_OPEN = {'dtc': '0x92 0x09 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_05', 'req': 36069470,
               'text': 'LOP Open circuit failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_OPEN)'}
FM_LCA_S2G = {'dtc': '0x92 0x09 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_05', 'req': 36069370,
              'text': 'LOP Short to ground failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
FM_LCA_S2B = {'dtc': '0x92 0x09 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_05', 'req': 36069395,
              'text': ('LOP Short to battery failure Line 5 '
                       '(FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_SHORT_CIRCUIT_TO_BAT)')}
FM_LCA_LORES = {'dtc': '0x92 0x09 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_05', 'req': 36069420,
                'text': 'LOP Resistance too low Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_LOW_RES)'}
FM_LCA_HIRES = {'dtc': '0x92 0x09 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_05', 'req': 36069445,
                'text': 'LOP Resistance too high Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_HIGH_RES)'}
FM_LCA_XCONN = {'dtc': '0x92 0x09 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_05', 'req': 36069497,
                'text': 'LOP Cross connection failure Line 5 (FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_CROSS_CONNECT)'}
FM_LCA_UNEXPECTED = {'dtc': '0x92 0x09 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_05', 'req': 36069554,
                     'text': ('LOP Present but not configured Line 5 '
                              '(FLTMONR_LOP_E_LEFT_CURTAIN_AIRBAG_UNEXPECTED_SQUIB)')}
FM_LCA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_05', 'req': 36069175,
                   'text': 'LOP ASIC internal error Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_05', 'req': 36069207,
                         'text': 'LOP monitor current failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_05', 'req': 36069240,
                 'text': 'LOP supply voltage failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_05', 'req': 36069274,
                          'text': 'LOP Low side driver failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_05', 'req': 36069306,
                           'text': 'LOP High side driver failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_05', 'req': 36069338,
                      'text': 'LOP Loose of ground connection Low Side 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_05', 'req': 36069522,
                    'text': 'LOP DR Cross connection failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_05', 'req': 36069621,
                        'text': 'loops PDC skipped due to internal condition Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_LCA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_05', 'req': 36069589,
                        'text': 'loops PDC skipped due to external condition Line 5 (FLTMONR_NO_DTC_EVENT)'}
FM_LCA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_05', 'req': 36069665,
                'text': 'LOP Firing time limiter and wording configuration failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_OPEN = {'dtc': '0x80 0x01 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_06', 'req': 36069471,
               'text': 'LOP Open circuit failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_OPEN)'}
FM_DAB_S2G = {'dtc': '0x80 0x01 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_06', 'req': 36069371,
              'text': 'LOP Short to ground failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_GND)'}
FM_DAB_S2B = {'dtc': '0x80 0x01 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_06', 'req': 36069396,
              'text': ('LOP Short to battery failure Line 6 '
                       '(FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_DAB_LORES = {'dtc': '0x80 0x01 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_06', 'req': 36069421,
                'text': 'LOP Resistance too low Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_LOW_RES)'}
FM_DAB_HIRES = {'dtc': '0x80 0x01 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_06', 'req': 36069446,
                'text': 'LOP Resistance too high Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_HIGH_RES)'}
FM_DAB_XCONN = {'dtc': '0x80 0x01 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_06', 'req': 36069498,
                'text': 'LOP Cross connection failure Line 6 (FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_CROSS_CONNECT)'}
FM_DAB_UNEXPECTED = {'dtc': '0x80 0x01 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_06', 'req': 36069555,
                     'text': ('LOP Present but not configured Line 6 '
                              '(FLTMONR_LOP_E_DRIVER_AIRBAG_SQUIB_UNEXPECTED_SQUIB)')}
FM_DAB_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_06', 'req': 36069176,
                   'text': 'LOP ASIC internal error Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_06', 'req': 36069208,
                         'text': 'LOP monitor current failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_06', 'req': 36069243,
                 'text': 'LOP supply voltage failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_06', 'req': 36069275,
                          'text': 'LOP Low side driver failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_06', 'req': 36069307,
                           'text': 'LOP High side driver failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_06', 'req': 36069339,
                      'text': 'LOP Loose of ground connection Low Side 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_06', 'req': 36069523,
                    'text': 'LOP DR Cross connection failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_06', 'req': 36069622,
                        'text': 'loops PDC skipped due to internal condition Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_DAB_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_06', 'req': 36069590,
                        'text': 'loops PDC skipped due to external condition Line 6 (FLTMONR_NO_DTC_EVENT)'}
FM_DAB_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_06', 'req': 36069666,
                'text': 'LOP Firing time limiter and wording configuration failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_OPEN = {'dtc': '0x80 0x10 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_07', 'req': 36069472,
               'text': 'LOP Open circuit failure Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_OPEN)'}
FM_PAB_S2G = {'dtc': '0x80 0x10 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_07', 'req': 36069372,
              'text': ('LOP Short to ground failure Line 7 '
                       '(FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_PAB_S2B = {'dtc': '0x80 0x10 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_07', 'req': 36069397,
              'text': ('LOP Short to battery failure Line 7 '
                       '(FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_PAB_LORES = {'dtc': '0x80 0x10 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_07', 'req': 36069422,
                'text': 'LOP Resistance too low Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_LOW_RES)'}
FM_PAB_HIRES = {'dtc': '0x80 0x10 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_07', 'req': 36069447,
                'text': 'LOP Resistance too high Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_HIGH_RES)'}
FM_PAB_XCONN = {'dtc': '0x80 0x10 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_07', 'req': 36069499,
                'text': 'LOP Cross connection failure Line 7 (FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_CROSS_CONNECT)'}
FM_PAB_UNEXPECTED = {'dtc': '0x80 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_07', 'req': 36069556,
                     'text': ('LOP Present but not configured Line 7 '
                              '(FLTMONR_LOP_E_PASSENGER_AIRBAG_SQUIB_UNEXPECTED_SQUIB)')}
FM_PAB_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_07', 'req': 36069177,
                   'text': 'LOP ASIC internal error Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_07', 'req': 36069209,
                         'text': 'LOP monitor current failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_07', 'req': 36069244,
                 'text': 'LOP supply voltage failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_07', 'req': 36069276,
                          'text': 'LOP Low side driver failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_07', 'req': 36069308,
                           'text': 'LOP High side driver failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_07', 'req': 36069340,
                      'text': 'LOP Loose of ground connection Low Side 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_07', 'req': 36069524,
                    'text': 'LOP DR Cross connection failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_07', 'req': 36069623,
                        'text': 'loops PDC skipped due to internal condition Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_07', 'req': 36069591,
                        'text': 'loops PDC skipped due to external condition Line 7 (FLTMONR_NO_DTC_EVENT)'}
FM_PAB_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_07', 'req': 36069667,
                'text': 'LOP Firing time limiter and wording configuration failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_OPEN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_OPEN_08', 'req': 36069473,
                  'text': ('LOP Open circuit failure Line 8 '
                           '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE08_S2G = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_08', 'req': 36069373,
                 'text': ('LOP Short to ground failure Line 8 '
                          '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE08_S2B = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_BATT_08', 'req': 36069398,
                 'text': ('LOP Short to battery failure Line 8 '
                          '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE08_LORES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_LOW_RES_08', 'req': 36069423,
                   'text': 'LOP Resistance too low Line 8 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
FM_LINE08_HIRES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_HIGH_RES_08', 'req': 36069448,
                   'text': ('LOP Resistance too high Line 8 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE08_XCONN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_CROSS_CONNECT_08', 'req': 36069500,
                   'text': ('LOP Cross connection failure Line 8 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE08_UNEXPECTED = {'dtc': '0x92 0x60 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                   'Within PDC(2 sec)'),
                        'latched': False, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_08', 'req': 36069557,
                        'text': ('LOP Present but not configured Line 8 '
                                 '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE08_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                                 'definition PDC: n/a DRIVE: 4'),
                      'latched': False, 'monitor': 'LOOP_F_INTERNAL_08', 'req': 36069178,
                      'text': 'LOP ASIC internal error Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_ISRC_08', 'req': 36069210,
                            'text': 'LOP monitor current failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                    'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_08', 'req': 36069245,
                    'text': 'LOP supply voltage failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_LS_TRANS_08', 'req': 36069277,
                             'text': 'LOP Low side driver failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                              'latched': True, 'monitor': 'LOOP_F_HS_TRANS_08', 'req': 36069309,
                              'text': 'LOP High side driver failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_08', 'req': 36069341,
                         'text': 'LOP Loose of ground connection Low Side 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                  'Platform: PDC: NA / DRIVE: 4'),
                       'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_08', 'req': 36069525,
                       'text': 'LOP DR Cross connection failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_08', 'req': 36069624,
                           'text': 'loops PDC skipped due to internal condition Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE08_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                           'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_08', 'req': 36069592,
                           'text': 'loops PDC skipped due to external condition Line 8 (FLTMONR_NO_DTC_EVENT)'}
FM_LINE08_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_08', 'req': 36069668,
                   'text': ('LOP Firing time limiter and wording configuration failure Line 8 '
                            '(FLTMONR_E_ECU_INTERNAL)')}
FM_LINE09_OPEN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_OPEN_09', 'req': 36069474,
                  'text': ('LOP Open circuit failure Line 9 '
                           '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE09_S2G = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_09', 'req': 36069374,
                 'text': ('LOP Short to ground failure Line 9 '
                          '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE09_S2B = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_BATT_09', 'req': 36069399,
                 'text': ('LOP Short to battery failure Line 9 '
                          '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE09_LORES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_LOW_RES_09', 'req': 36069424,
                   'text': 'LOP Resistance too low Line 9 (FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)'}
FM_LINE09_HIRES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_HIGH_RES_09', 'req': 36069449,
                   'text': ('LOP Resistance too high Line 9 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE09_XCONN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_CROSS_CONNECT_09', 'req': 36069501,
                   'text': ('LOP Cross connection failure Line 9 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE09_UNEXPECTED = {'dtc': '0x92 0x60 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                   'Within PDC(2 sec)'),
                        'latched': False, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_09', 'req': 36069558,
                        'text': ('LOP Present but not configured Line 9 '
                                 '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE09_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                                 'definition PDC: n/a DRIVE: 4'),
                      'latched': False, 'monitor': 'LOOP_F_INTERNAL_09', 'req': 36069179,
                      'text': 'LOP ASIC internal error Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_ISRC_09', 'req': 36069211,
                            'text': 'LOP monitor current failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                    'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_09', 'req': 36069246,
                    'text': 'LOP supply voltage failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_LS_TRANS_09', 'req': 36069278,
                             'text': 'LOP Low side driver failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                              'latched': True, 'monitor': 'LOOP_F_HS_TRANS_09', 'req': 36069310,
                              'text': 'LOP High side driver failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_09', 'req': 36069342,
                         'text': 'LOP Loose of ground connection Low Side 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                  'Platform: PDC: NA / DRIVE: 4'),
                       'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_09', 'req': 36069526,
                       'text': 'LOP DR Cross connection failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_09', 'req': 36069625,
                           'text': 'loops PDC skipped due to internal condition Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE09_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                           'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_09', 'req': 36069593,
                           'text': 'loops PDC skipped due to external condition Line 9 (FLTMONR_NO_DTC_EVENT)'}
FM_LINE09_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_09', 'req': 36069669,
                   'text': ('LOP Firing time limiter and wording configuration failure Line 9 '
                            '(FLTMONR_E_ECU_INTERNAL)')}
FM_LINE10_OPEN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_OPEN_10', 'req': 36069475,
                  'text': ('LOP Open circuit failure Line 10 '
                           '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_S2G = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_10', 'req': 36069375,
                 'text': ('LOP Short to ground failure Line 10 '
                          '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_S2B = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_BATT_10', 'req': 36069400,
                 'text': ('LOP Short to battery failure Line 10 '
                          '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_LORES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_LOW_RES_10', 'req': 36069425,
                   'text': ('LOP Resistance too low Line 10 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_HIRES = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_HIGH_RES_10', 'req': 36069450,
                   'text': ('LOP Resistance too high Line 10 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_XCONN = {'dtc': '0x92 0x60 0x00', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'LOOP_F_CROSS_CONNECT_10', 'req': 36069502,
                   'text': ('LOP Cross connection failure Line 10 '
                            '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_UNEXPECTED = {'dtc': '0x92 0x60 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                   'Within PDC(2 sec)'),
                        'latched': False, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_10', 'req': 36069559,
                        'text': ('LOP Present but not configured Line 10 '
                                 '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_LOOP)')}
FM_LINE10_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                                 'definition PDC: n/a DRIVE: 4'),
                      'latched': False, 'monitor': 'LOOP_F_INTERNAL_10', 'req': 36069180,
                      'text': 'LOP ASIC internal error Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_ISRC_10', 'req': 36069212,
                            'text': 'LOP monitor current failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                    'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_10', 'req': 36069247,
                    'text': 'LOP supply voltage failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_LS_TRANS_10', 'req': 36069279,
                             'text': 'LOP Low side driver failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                              'latched': True, 'monitor': 'LOOP_F_HS_TRANS_10', 'req': 36069311,
                              'text': 'LOP High side driver failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_10', 'req': 36069343,
                         'text': 'LOP Loose of ground connection Low Side 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                  'Platform: PDC: NA / DRIVE: 4'),
                       'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_10', 'req': 36069527,
                       'text': 'LOP DR Cross connection failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_10', 'req': 36069626,
                           'text': 'loops PDC skipped due to internal condition Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE10_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                           'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_10', 'req': 36069594,
                           'text': 'loops PDC skipped due to external condition Line 10 (FLTMONR_NO_DTC_EVENT)'}
FM_LINE10_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                   'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_10', 'req': 36069670,
                   'text': ('LOP Firing time limiter and wording configuration failure Line 10 '
                            '(FLTMONR_E_ECU_INTERNAL)')}
FM_DKA_OPEN = {'dtc': '0x92 0x11 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_11', 'req': 36069476,
               'text': 'LOP Open circuit failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_OPEN)'}
FM_DKA_S2G = {'dtc': '0x92 0x11 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_11', 'req': 36069376,
              'text': 'LOP Short to ground failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_SHORT_CIRCUIT_TO_GND)'}
FM_DKA_S2B = {'dtc': '0x92 0x11 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_11', 'req': 36069401,
              'text': ('LOP Short to battery failure Line 11 '
                       '(FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_SHORT_CIRCUIT_TO_BAT)')}
FM_DKA_LORES = {'dtc': '0x92 0x11 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_11', 'req': 36069426,
                'text': 'LOP Resistance too low Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_LOW_RES)'}
FM_DKA_HIRES = {'dtc': '0x92 0x11 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_11', 'req': 36069451,
                'text': 'LOP Resistance too high Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_HIGH_RES)'}
FM_DKA_XCONN = {'dtc': '0x92 0x11 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_11', 'req': 36069503,
                'text': 'LOP Cross connection failure Line 11 (FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_CROSS_CONNECT)'}
FM_DKA_UNEXPECTED = {'dtc': '0x92 0x11 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_11', 'req': 36069560,
                     'text': ('LOP Present but not configured Line 11 '
                              '(FLTMONR_LOP_E_DRIVER_KNEE_AIRBAG_UNEXPECTED_SQUIB)')}
FM_DKA_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_11', 'req': 36069181,
                   'text': 'LOP ASIC internal error Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_11', 'req': 36069213,
                         'text': 'LOP monitor current failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_11', 'req': 36069248,
                 'text': 'LOP supply voltage failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_11', 'req': 36069280,
                          'text': 'LOP Low side driver failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_11', 'req': 36069312,
                           'text': 'LOP High side driver failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_11', 'req': 36069344,
                      'text': 'LOP Loose of ground connection Low Side 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_11', 'req': 36069528,
                    'text': 'LOP DR Cross connection failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_11', 'req': 36069627,
                        'text': 'loops PDC skipped due to internal condition Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_DKA_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_11', 'req': 36069595,
                        'text': 'loops PDC skipped due to external condition Line 11 (FLTMONR_NO_DTC_EVENT)'}
FM_DKA_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_11', 'req': 36069671,
                'text': ('LOP Firing time limiter and wording configuration failure Line 11 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_RLPT_OPEN = {'dtc': '0x92 0x03 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_OPEN_12', 'req': 36069477,
                'text': 'LOP Open circuit failure Line 12 (FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_OPEN)'}
FM_RLPT_S2G = {'dtc': '0x92 0x03 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_GND_12', 'req': 36069377,
               'text': ('LOP Short to ground failure Line 12 '
                        '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_RLPT_S2B = {'dtc': '0x92 0x03 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_BATT_12', 'req': 36069402,
               'text': ('LOP Short to battery failure Line 12 '
                        '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_RLPT_LORES = {'dtc': '0x92 0x03 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_LOW_RES_12', 'req': 36069427,
                 'text': 'LOP Resistance too low Line 12 (FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_LOW_RES)'}
FM_RLPT_HIRES = {'dtc': '0x92 0x03 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_HIGH_RES_12', 'req': 36069452,
                 'text': 'LOP Resistance too high Line 12 (FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_HIGH_RES)'}
FM_RLPT_XCONN = {'dtc': '0x92 0x03 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_CROSS_CONNECT_12', 'req': 36069504,
                 'text': ('LOP Cross connection failure Line 12 '
                          '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_CROSS_CONNECT)')}
FM_RLPT_UNEXPECTED = {'dtc': '0x92 0x03 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_12', 'req': 36069561,
                      'text': ('LOP Present but not configured Line 12 '
                               '(FLTMONR_LOP_E_DRIVER_LAP_PRETENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
FM_RLPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                               'definition PDC: n/a DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_INTERNAL_12', 'req': 36069182,
                    'text': 'LOP ASIC internal error Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_ISRC_12', 'req': 36069214,
                          'text': 'LOP monitor current failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                  'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_12', 'req': 36069249,
                  'text': 'LOP supply voltage failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_LS_TRANS_12', 'req': 36069281,
                           'text': 'LOP Low side driver failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_HS_TRANS_12', 'req': 36069313,
                            'text': 'LOP High side driver failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_12', 'req': 36069345,
                       'text': 'LOP Loose of ground connection Low Side 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                'Platform: PDC: NA / DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_12', 'req': 36069529,
                     'text': 'LOP DR Cross connection failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_12', 'req': 36069628,
                         'text': 'loops PDC skipped due to internal condition Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_RLPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                         'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_12', 'req': 36069596,
                         'text': 'loops PDC skipped due to external condition Line 12 (FLTMONR_NO_DTC_EVENT)'}
FM_RLPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                 'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_12', 'req': 36069672,
                 'text': ('LOP Firing time limiter and wording configuration failure Line 12 '
                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_LLPT_OPEN = {'dtc': '0x92 0x04 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_OPEN_13', 'req': 36069478,
                'text': 'LOP Open circuit failure Line 13 (FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_OPEN)'}
FM_LLPT_S2G = {'dtc': '0x92 0x04 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_GND_13', 'req': 36069378,
               'text': ('LOP Short to ground failure Line 13 '
                        '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_LLPT_S2B = {'dtc': '0x92 0x04 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_BATT_13', 'req': 36069403,
               'text': ('LOP Short to battery failure Line 13 '
                        '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_LLPT_LORES = {'dtc': '0x92 0x04 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_LOW_RES_13', 'req': 36069428,
                 'text': 'LOP Resistance too low Line 13 (FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_LOW_RES)'}
FM_LLPT_HIRES = {'dtc': '0x92 0x04 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_HIGH_RES_13', 'req': 36069453,
                 'text': ('LOP Resistance too high Line 13 '
                          '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_HIGH_RES)')}
FM_LLPT_XCONN = {'dtc': '0x92 0x04 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_CROSS_CONNECT_13', 'req': 36069505,
                 'text': ('LOP Cross connection failure Line 13 '
                          '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_CROSS_CONNECT)')}
FM_LLPT_UNEXPECTED = {'dtc': '0x92 0x04 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_13', 'req': 36069562,
                      'text': ('LOP Present but not configured Line 13 '
                               '(FLTMONR_LOP_E_PASSENGER_LAP_PRETENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
FM_LLPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                               'definition PDC: n/a DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_INTERNAL_13', 'req': 36069183,
                    'text': 'LOP ASIC internal error Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_ISRC_13', 'req': 36069216,
                          'text': 'LOP monitor current failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                  'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_13', 'req': 36069250,
                  'text': 'LOP supply voltage failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_LS_TRANS_13', 'req': 36069282,
                           'text': 'LOP Low side driver failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_HS_TRANS_13', 'req': 36069314,
                            'text': 'LOP High side driver failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_13', 'req': 36069346,
                       'text': 'LOP Loose of ground connection Low Side 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                'Platform: PDC: NA / DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_13', 'req': 36069530,
                     'text': 'LOP DR Cross connection failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_13', 'req': 36069629,
                         'text': 'loops PDC skipped due to internal condition Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_LLPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                         'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_13', 'req': 36069597,
                         'text': 'loops PDC skipped due to external condition Line 13 (FLTMONR_NO_DTC_EVENT)'}
FM_LLPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                 'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_13', 'req': 36069673,
                 'text': ('LOP Firing time limiter and wording configuration failure Line 13 '
                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_DFV_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_14', 'req': 36069184,
                   'text': 'LOP ASIC internal error Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_14', 'req': 36069217,
                         'text': 'LOP monitor current failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_14', 'req': 36069251,
                 'text': 'LOP supply voltage failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_14', 'req': 36069283,
                          'text': 'LOP Low side driver failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_14', 'req': 36069315,
                           'text': 'LOP High side driver failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_14', 'req': 36069347,
                      'text': 'LOP Loose of ground connection Low Side 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_14', 'req': 36069531,
                    'text': 'LOP DR Cross connection failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_14', 'req': 36069630,
                        'text': 'loops PDC skipped due to internal condition Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_DFV_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_14', 'req': 36069598,
                        'text': 'loops PDC skipped due to external condition Line 14 (FLTMONR_NO_DTC_EVENT)'}
FM_DFV_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_14', 'req': 36069674,
                'text': ('LOP Firing time limiter and wording configuration failure Line 14 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_PFV_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_15', 'req': 36069185,
                   'text': 'LOP ASIC internal error Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_15', 'req': 36069218,
                         'text': 'LOP monitor current failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_15', 'req': 36069252,
                 'text': 'LOP supply voltage failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_15', 'req': 36069284,
                          'text': 'LOP Low side driver failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_15', 'req': 36069316,
                           'text': 'LOP High side driver failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_15', 'req': 36069348,
                      'text': 'LOP Loose of ground connection Low Side 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_15', 'req': 36069532,
                    'text': 'LOP DR Cross connection failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_15', 'req': 36069631,
                        'text': 'loops PDC skipped due to internal condition Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_PFV_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_15', 'req': 36069599,
                        'text': 'loops PDC skipped due to external condition Line 15 (FLTMONR_NO_DTC_EVENT)'}
FM_PFV_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_15', 'req': 36069675,
                'text': ('LOP Firing time limiter and wording configuration failure Line 15 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_R2RPT_OPEN = {'dtc': '0x99 0x0F 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_OPEN_16', 'req': 36073791,
                 'text': 'LOP Open circuit failure Line 16 (FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_OPEN)'}
FM_R2RPT_S2G = {'dtc': '0x99 0x0F 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_SHORT_TO_GND_16', 'req': 36073765,
                'text': ('LOP Short to ground failure Line 16 '
                         '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_R2RPT_S2B = {'dtc': '0x99 0x0F 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_SHORT_TO_BATT_16', 'req': 36073772,
                'text': ('LOP Short to battery failure Line 16 '
                         '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_R2RPT_LORES = {'dtc': '0x99 0x0F 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_LOW_RES_16', 'req': 36073779,
                  'text': ('LOP Resistance too low Line 16 '
                           '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_LOW_RES)')}
FM_R2RPT_HIRES = {'dtc': '0x99 0x0F 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_HIGH_RES_16', 'req': 36073786,
                  'text': ('LOP Resistance too high Line 16 '
                           '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_HIGH_RES)')}
FM_R2RPT_XCONN = {'dtc': '0x99 0x0F 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_CROSS_CONNECT_16', 'req': 36073798,
                  'text': ('LOP Cross connection failure Line 16 '
                           '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
FM_R2RPT_UNEXPECTED = {'dtc': '0x99 0x0F 0x64', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': True,
                       'monitor': 'LOOP_F_UNEXPECTED_LOAD_16', 'req': 36073803,
                       'text': ('LOP Present but not configured Line 16 '
                                '(FLTMONR_LOP_E_2ND_ROW_RIGHT_PRE_TENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
FM_R2RPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                                'definition PDC: n/a DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_INTERNAL_16', 'req': 36069186,
                     'text': 'LOP ASIC internal error Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_ISRC_16', 'req': 36069219,
                           'text': 'LOP monitor current failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                   'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_16', 'req': 36069253,
                   'text': 'LOP supply voltage failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_LS_TRANS_16', 'req': 36069285,
                            'text': 'LOP Low side driver failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_HS_TRANS_16', 'req': 36069317,
                             'text': 'LOP High side driver failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_16', 'req': 36069349,
                        'text': 'LOP Loose of ground connection Low Side 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                 'Platform: PDC: NA / DRIVE: 4'),
                      'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_16', 'req': 36069533,
                      'text': 'LOP DR Cross connection failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_16', 'req': 36069632,
                          'text': 'loops PDC skipped due to internal condition Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2RPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                          'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_16', 'req': 36069600,
                          'text': 'loops PDC skipped due to external condition Line 16 (FLTMONR_NO_DTC_EVENT)'}
FM_R2RPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                  'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_16', 'req': 36069676,
                  'text': ('LOP Firing time limiter and wording configuration failure Line 16 '
                           '(FLTMONR_E_ECU_INTERNAL)')}
FM_CAB_OPEN = {'dtc': '0x92 0x33 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_17', 'req': 36069481,
               'text': 'LOP Open circuit failure Line 17 (FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_OPEN)'}
FM_CAB_S2G = {'dtc': '0x92 0x33 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_17', 'req': 36069379,
              'text': ('LOP Short to ground failure Line 17 '
                       '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_CAB_S2B = {'dtc': '0x92 0x33 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_17', 'req': 36069404,
              'text': ('LOP Short to battery failure Line 17 '
                       '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_CAB_LORES = {'dtc': '0x92 0x33 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_17', 'req': 36069429,
                'text': 'LOP Resistance too low Line 17 (FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_LOW_RES)'}
FM_CAB_HIRES = {'dtc': '0x92 0x33 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_17', 'req': 36069454,
                'text': ('LOP Resistance too high Line 17 '
                         '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_HIGH_RES)')}
FM_CAB_XCONN = {'dtc': '0x92 0x33 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_17', 'req': 36069506,
                'text': ('LOP Cross connection failure Line 17 '
                         '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_CROSS_CONNECT)')}
FM_CAB_UNEXPECTED = {'dtc': '0x92 0x33 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_17', 'req': 36069565,
                     'text': ('LOP Present but not configured Line 17 '
                              '(FLTMONR_LOP_E_SEATBAG_CENTER_FAR_SIDE_SEAT_SQUIB_UNEXPECTED_SQUIB)')}
FM_CAB_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_17', 'req': 36069187,
                   'text': 'LOP ASIC internal error Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_17', 'req': 36069220,
                         'text': 'LOP monitor current failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_17', 'req': 36069254,
                 'text': 'LOP supply voltage failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_17', 'req': 36069286,
                          'text': 'LOP Low side driver failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_17', 'req': 36069318,
                           'text': 'LOP High side driver failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_17', 'req': 36069350,
                      'text': 'LOP Loose of ground connection Low Side 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_17', 'req': 36069534,
                    'text': 'LOP DR Cross connection failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_17', 'req': 36069633,
                        'text': 'loops PDC skipped due to internal condition Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_CAB_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_17', 'req': 36069601,
                        'text': 'loops PDC skipped due to external condition Line 17 (FLTMONR_NO_DTC_EVENT)'}
FM_CAB_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_17', 'req': 36069677,
                'text': ('LOP Firing time limiter and wording configuration failure Line 17 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_R2LPT_OPEN = {'dtc': '0x99 0x14 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_OPEN_18', 'req': 36073792,
                 'text': 'LOP Open circuit failure Line 18 (FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_OPEN)'}
FM_R2LPT_S2G = {'dtc': '0x99 0x14 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_SHORT_TO_GND_18', 'req': 36073766,
                'text': ('LOP Short to ground failure Line 18 '
                         '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_R2LPT_S2B = {'dtc': '0x99 0x14 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_SHORT_TO_BATT_18', 'req': 36073773,
                'text': ('LOP Short to battery failure Line 18 '
                         '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_R2LPT_LORES = {'dtc': '0x99 0x14 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_LOW_RES_18', 'req': 36073780,
                  'text': 'LOP Resistance too low Line 18 (FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_LOW_RES)'}
FM_R2LPT_HIRES = {'dtc': '0x99 0x14 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_HIGH_RES_18', 'req': 36073787,
                  'text': ('LOP Resistance too high Line 18 '
                           '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_HIGH_RES)')}
FM_R2LPT_XCONN = {'dtc': '0x99 0x14 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'LOOP_F_CROSS_CONNECT_18', 'req': 36073799,
                  'text': ('LOP Cross connection failure Line 18 '
                           '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_CROSS_CONNECT)')}
FM_R2LPT_UNEXPECTED = {'dtc': '0x99 0x14 0x64', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': True,
                       'monitor': 'LOOP_F_UNEXPECTED_LOAD_18', 'req': 36073804,
                       'text': ('LOP Present but not configured Line 18 '
                                '(FLTMONR_LOP_E_2ND_ROW_LEFT_PRE_TENSIONER_SQUIB_UNEXPECTED_SQUIB)')}
FM_R2LPT_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                                'definition PDC: n/a DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_INTERNAL_18', 'req': 36069188,
                     'text': 'LOP ASIC internal error Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_ISRC_18', 'req': 36069221,
                           'text': 'LOP monitor current failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                   'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_18', 'req': 36069255,
                   'text': 'LOP supply voltage failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_LS_TRANS_18', 'req': 36069287,
                            'text': 'LOP Low side driver failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                             'latched': True, 'monitor': 'LOOP_F_HS_TRANS_18', 'req': 36069319,
                             'text': 'LOP High side driver failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_18', 'req': 36069351,
                        'text': 'LOP Loose of ground connection Low Side 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                 'Platform: PDC: NA / DRIVE: 4'),
                      'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_18', 'req': 36069535,
                      'text': 'LOP DR Cross connection failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_18', 'req': 36069634,
                          'text': 'loops PDC skipped due to internal condition Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_R2LPT_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                          'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_18', 'req': 36069602,
                          'text': 'loops PDC skipped due to external condition Line 18 (FLTMONR_NO_DTC_EVENT)'}
FM_R2LPT_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                  'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_18', 'req': 36069678,
                  'text': ('LOP Firing time limiter and wording configuration failure Line 18 '
                           '(FLTMONR_E_ECU_INTERNAL)')}
FM_DBFL_OPEN = {'dtc': '0x92 0x63 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_OPEN_19', 'req': 36069482,
                'text': 'LOP Open circuit failure Line 19 (FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_OPEN)'}
FM_DBFL_S2G = {'dtc': '0x92 0x63 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_GND_19', 'req': 36069380,
               'text': ('LOP Short to ground failure Line 19 '
                        '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_DBFL_S2B = {'dtc': '0x92 0x63 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_BATT_19', 'req': 36069405,
               'text': ('LOP Short to battery failure Line 19 '
                        '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_DBFL_LORES = {'dtc': '0x92 0x63 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_LOW_RES_19', 'req': 36069430,
                 'text': 'LOP Resistance too low Line 19 (FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_LOW_RES)'}
FM_DBFL_HIRES = {'dtc': '0x92 0x63 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_HIGH_RES_19', 'req': 36069455,
                 'text': 'LOP Resistance too high Line 19 (FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_HIGH_RES)'}
FM_DBFL_XCONN = {'dtc': '0x92 0x63 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_CROSS_CONNECT_19', 'req': 36069507,
                 'text': ('LOP Cross connection failure Line 19 '
                          '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_CROSS_CONNECT)')}
FM_DBFL_UNEXPECTED = {'dtc': '0x92 0x63 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_19', 'req': 36069566,
                      'text': ('LOP Present but not configured Line 19 '
                               '(FLTMONR_LOP_E_BELTFORCE_LIMITER_DRIVER_SQUIB_UNEXPECTED_SQUIB)')}
FM_DBFL_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                               'definition PDC: n/a DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_INTERNAL_19', 'req': 36069189,
                    'text': 'LOP ASIC internal error Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_ISRC_19', 'req': 36069222,
                          'text': 'LOP monitor current failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                  'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_19', 'req': 36069256,
                  'text': 'LOP supply voltage failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_LS_TRANS_19', 'req': 36069288,
                           'text': 'LOP Low side driver failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_HS_TRANS_19', 'req': 36069320,
                            'text': 'LOP High side driver failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_19', 'req': 36069352,
                       'text': 'LOP Loose of ground connection Low Side 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                'Platform: PDC: NA / DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_19', 'req': 36069536,
                     'text': 'LOP DR Cross connection failure Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_19', 'req': 36069635,
                         'text': 'loops PDC skipped due to internal condition Line 19 (FLTMONR_E_ECU_INTERNAL)'}
FM_DBFL_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                         'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_19', 'req': 36069603,
                         'text': 'loops PDC skipped due to external condition Line 19 (FLTMONR_NO_DTC_EVENT)'}
FM_DBFL_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                 'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_19', 'req': 36069679,
                 'text': ('LOP Firing time limiter and wording configuration failure Line 19 '
                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_PBFL_OPEN = {'dtc': '0x92 0x64 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_OPEN_20', 'req': 36069483,
                'text': 'LOP Open circuit failure Line 20 (FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_OPEN)'}
FM_PBFL_S2G = {'dtc': '0x92 0x64 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_GND_20', 'req': 36069381,
               'text': ('LOP Short to ground failure Line 20 '
                        '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_PBFL_S2B = {'dtc': '0x92 0x64 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_BATT_20', 'req': 36069406,
               'text': ('LOP Short to battery failure Line 20 '
                        '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_PBFL_LORES = {'dtc': '0x92 0x64 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_LOW_RES_20', 'req': 36069431,
                 'text': 'LOP Resistance too low Line 20 (FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_LOW_RES)'}
FM_PBFL_HIRES = {'dtc': '0x92 0x64 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_HIGH_RES_20', 'req': 36069456,
                 'text': ('LOP Resistance too high Line 20 '
                          '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_HIGH_RES)')}
FM_PBFL_XCONN = {'dtc': '0x92 0x64 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_CROSS_CONNECT_20', 'req': 36069508,
                 'text': ('LOP Cross connection failure Line 20 '
                          '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_CROSS_CONNECT)')}
FM_PBFL_UNEXPECTED = {'dtc': '0x92 0x64 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_20', 'req': 36069567,
                      'text': ('LOP Present but not configured Line 20 '
                               '(FLTMONR_LOP_E_BELTFORCE_LIMITER_PASSENGER_SQUIB_UNEXPECTED_SQUIB)')}
FM_PBFL_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                               'definition PDC: n/a DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_INTERNAL_20', 'req': 36069190,
                    'text': 'LOP ASIC internal error Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_ISRC_20', 'req': 36069223,
                          'text': 'LOP monitor current failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                  'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_20', 'req': 36069257,
                  'text': 'LOP supply voltage failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_LS_TRANS_20', 'req': 36069289,
                           'text': 'LOP Low side driver failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_HS_TRANS_20', 'req': 36069321,
                            'text': 'LOP High side driver failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_20', 'req': 36069353,
                       'text': 'LOP Loose of ground connection Low Side 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                'Platform: PDC: NA / DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_20', 'req': 36069537,
                     'text': 'LOP DR Cross connection failure Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_20', 'req': 36069636,
                         'text': 'loops PDC skipped due to internal condition Line 20 (FLTMONR_E_ECU_INTERNAL)'}
FM_PBFL_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                         'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_20', 'req': 36069604,
                         'text': 'loops PDC skipped due to external condition Line 20 (FLTMONR_NO_DTC_EVENT)'}
FM_PBFL_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                 'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_20', 'req': 36069680,
                 'text': ('LOP Firing time limiter and wording configuration failure Line 20 '
                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_HVBD_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                               'definition PDC: n/a DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_INTERNAL_21', 'req': 36069191,
                    'text': 'LOP ASIC internal error Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_ISRC_21', 'req': 36069224,
                          'text': 'LOP monitor current failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                  'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_21', 'req': 36069258,
                  'text': 'LOP supply voltage failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_LS_TRANS_21', 'req': 36069290,
                           'text': 'LOP Low side driver failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_HS_TRANS_21', 'req': 36069322,
                            'text': 'LOP High side driver failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                       'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_21', 'req': 36069354,
                       'text': 'LOP Loose of ground connection Low Side 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                                'Platform: PDC: NA / DRIVE: 4'),
                     'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_21', 'req': 36069538,
                     'text': 'LOP DR Cross connection failure Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_21', 'req': 36069637,
                         'text': 'loops PDC skipped due to internal condition Line 21 (FLTMONR_E_ECU_INTERNAL)'}
FM_HVBD_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                         'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_21', 'req': 36069605,
                         'text': 'loops PDC skipped due to external condition Line 21 (FLTMONR_NO_DTC_EVENT)'}
FM_HVBD_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                 'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_21', 'req': 36069681,
                 'text': ('LOP Firing time limiter and wording configuration failure Line 21 '
                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_PPC_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_22', 'req': 36069192,
                   'text': 'LOP ASIC internal error Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_22', 'req': 36069225,
                         'text': 'LOP monitor current failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_22', 'req': 36069259,
                 'text': 'LOP supply voltage failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_22', 'req': 36069291,
                          'text': 'LOP Low side driver failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_22', 'req': 36069323,
                           'text': 'LOP High side driver failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_22', 'req': 36069355,
                      'text': 'LOP Loose of ground connection Low Side 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_22', 'req': 36069539,
                    'text': 'LOP DR Cross connection failure Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_22', 'req': 36069638,
                        'text': 'loops PDC skipped due to internal condition Line 22 (FLTMONR_E_ECU_INTERNAL)'}
FM_PPC_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_22', 'req': 36069606,
                        'text': 'loops PDC skipped due to external condition Line 22 (FLTMONR_NO_DTC_EVENT)'}
FM_PPC_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_22', 'req': 36069682,
                'text': ('LOP Firing time limiter and wording configuration failure Line 22 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_DPC_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: Platform PDC: 4 consecutive retries DRIVE: 2; dematuration: Platform '
                              'definition PDC: n/a DRIVE: 4'),
                   'latched': False, 'monitor': 'LOOP_F_INTERNAL_23', 'req': 36069193,
                   'text': 'LOP ASIC internal error Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_CURRENT_SOURCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': True, 'monitor': 'LOOP_F_ISRC_23', 'req': 36069226,
                         'text': 'LOP monitor current failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: 4',
                 'latched': False, 'monitor': 'LOOP_F_SQUIB_SUPPLY_23', 'req': 36069260,
                 'text': 'LOP supply voltage failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_LOW_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                          'latched': True, 'monitor': 'LOOP_F_LS_TRANS_23', 'req': 36069292,
                          'text': 'LOP Low side driver failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_HIGH_SIDE_SWITCH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                           'latched': True, 'monitor': 'LOOP_F_HS_TRANS_23', 'req': 36069324,
                           'text': 'LOP High side driver failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_GROUND_LOSS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_GROUND_LOSS_23', 'req': 36069356,
                      'text': 'LOP Loose of ground connection Low Side 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_CSR_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: Platform: PDC: 3 consecutive retries / DRIVE: 2; dematuration: '
                               'Platform: PDC: NA / DRIVE: 4'),
                    'latched': False, 'monitor': 'LOOP_F_CSR_CROSS_CONNECT_23', 'req': 36069540,
                    'text': 'LOP DR Cross connection failure Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_PDC_ABORT_INT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': True, 'monitor': 'LOOP_F_PDC_ABORTED_INTERNAL_23', 'req': 36069639,
                        'text': 'loops PDC skipped due to internal condition Line 23 (FLTMONR_E_ECU_INTERNAL)'}
FM_DPC_PDC_ABORT_EXT = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': False,
                        'monitor': 'LOOP_F_PDC_ABORTED_EXTERNAL_23', 'req': 36069607,
                        'text': 'loops PDC skipped due to external condition Line 23 (FLTMONR_NO_DTC_EVENT)'}
FM_DPC_DWELL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                'latched': True, 'monitor': 'LOOP_F_DWELL_FTL_23', 'req': 36069683,
                'text': ('LOP Firing time limiter and wording configuration failure Line 23 '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_LINE24_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_24', 'req': 36069382,
                 'text': 'LOP Short to ground failure Line 24 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE25_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_25', 'req': 36069383,
                 'text': 'LOP Short to ground failure Line 25 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE26_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_26', 'req': 36069384,
                 'text': 'LOP Short to ground failure Line 26 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE27_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_27', 'req': 36069385,
                 'text': 'LOP Short to ground failure Line 27 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE28_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_28', 'req': 36069386,
                 'text': 'LOP Short to ground failure Line 28 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE29_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_29', 'req': 36069387,
                 'text': 'LOP Short to ground failure Line 29 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE30_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_30', 'req': 36069388,
                 'text': 'LOP Short to ground failure Line 30 (FLTMONR_E_ECU_INTERNAL)'}
FM_LINE31_S2G = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_SHORT_TO_GND_31', 'req': 36069389,
                 'text': 'LOP Short to ground failure Line 31 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP0_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_CMT_00', 'req': 36069700,
                            'text': 'Current Monitor Counter failure Line 00 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP1_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_CMT_01', 'req': 36069701,
                            'text': 'Current Monitor Counter failure Line 01 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP2_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_CMT_02', 'req': 36069702,
                            'text': 'Current Monitor Counter failure Line 02 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP3_CURRENT_MONITOR = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                            'latched': True, 'monitor': 'LOOP_F_CMT_03', 'req': 36069703,
                            'text': 'Current Monitor Counter failure Line 03 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC0_VRCM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_ASIC_VRCM_00', 'req': 36069648,
                      'text': 'LOOP ASIC VRCM&OXI failure SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC1_VRCM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_ASIC_VRCM_01', 'req': 36069649,
                      'text': 'LOOP ASIC VRCM&OXI failure SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC2_VRCM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                      'latched': False, 'monitor': 'LOOP_F_ASIC_VRCM_02', 'req': 36069650,
                      'text': 'LOOP ASIC VRCM&OXI failure EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC0_LOCKING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': False, 'monitor': 'LOOP_F_ASIC_LOCKING_00', 'req': 36069652,
                         'text': 'LOP Lock/UnLock failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC1_LOCKING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': False, 'monitor': 'LOOP_F_ASIC_LOCKING_01', 'req': 36069653,
                         'text': 'LOP Lock/UnLock failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC2_LOCKING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                         'latched': False, 'monitor': 'LOOP_F_ASIC_LOCKING_02', 'req': 36069654,
                         'text': 'LOP Lock/UnLock failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC0_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': False, 'monitor': 'LOOP_F_ASIC_CONFIG_00', 'req': 36069656,
                        'text': 'LOP Configuration failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC1_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': False, 'monitor': 'LOOP_F_ASIC_CONFIG_01', 'req': 36069657,
                        'text': 'LOP Configuration failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC2_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Platform: 4 Consecutive Retries; dematuration: Platform: n/a',
                        'latched': False, 'monitor': 'LOOP_F_ASIC_CONFIG_02', 'req': 36069658,
                        'text': 'LOP Configuration failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC0_DEPLOY_COMMAND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Platform: 4 Consecutive Retries; dematuration: Platform: '
                                           'n/a'),
                                'latched': True, 'monitor': 'LOOP_F_DEP_COMMAND_00', 'req': 36069692,
                                'text': 'Deployment Command Register failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC1_DEPLOY_COMMAND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Platform: 4 Consecutive Retries; dematuration: Platform: '
                                           'n/a'),
                                'latched': True, 'monitor': 'LOOP_F_DEP_COMMAND_01', 'req': 36069693,
                                'text': 'Deployment Command Register failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC2_DEPLOY_COMMAND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Platform: 4 Consecutive Retries; dematuration: Platform: '
                                           'n/a'),
                                'latched': True, 'monitor': 'LOOP_F_DEP_COMMAND_02', 'req': 36069694,
                                'text': 'Deployment Command Register failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC0_DEPLOY_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Platform: 4 Consecutive Retries; dematuration: Platform: '
                                           'n/a'),
                                'latched': True, 'monitor': 'LOOP_F_DEP_CMP_00', 'req': 36069696,
                                'text': 'Comparator register deployment failure ASIC 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC1_DEPLOY_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Platform: 4 Consecutive Retries; dematuration: Platform: '
                                           'n/a'),
                                'latched': True, 'monitor': 'LOOP_F_DEP_CMP_01', 'req': 36069697,
                                'text': 'Comparator register deployment failure ASIC 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_LOOP_ASIC2_DEPLOY_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Platform: 4 Consecutive Retries; dematuration: Platform: '
                                           'n/a'),
                                'latched': True, 'monitor': 'LOOP_F_DEP_CMP_02', 'req': 36069698,
                                'text': 'Comparator register deployment failure ASIC 2 (FLTMONR_E_ECU_INTERNAL)'}

LOOP_FAULTS = {
    'RPT_OPEN': FM_RPT_OPEN,
    'RPT_S2G': FM_RPT_S2G,
    'RPT_S2B': FM_RPT_S2B,
    'RPT_LORES': FM_RPT_LORES,
    'RPT_HIRES': FM_RPT_HIRES,
    'RPT_XCONN': FM_RPT_XCONN,
    'RPT_UNEXPECTED': FM_RPT_UNEXPECTED,
    'RPT_INTERNAL': FM_RPT_INTERNAL,
    'RPT_CURRENT_SOURCE': FM_RPT_CURRENT_SOURCE,
    'RPT_SUPPLY': FM_RPT_SUPPLY,
    'RPT_LOW_SIDE_SWITCH': FM_RPT_LOW_SIDE_SWITCH,
    'RPT_HIGH_SIDE_SWITCH': FM_RPT_HIGH_SIDE_SWITCH,
    'RPT_GROUND_LOSS': FM_RPT_GROUND_LOSS,
    'RPT_CSR_XCONN': FM_RPT_CSR_XCONN,
    'RPT_PDC_ABORT_INT': FM_RPT_PDC_ABORT_INT,
    'RPT_PDC_ABORT_EXT': FM_RPT_PDC_ABORT_EXT,
    'RPT_DWELL': FM_RPT_DWELL,
    'LPT_OPEN': FM_LPT_OPEN,
    'LPT_S2G': FM_LPT_S2G,
    'LPT_S2B': FM_LPT_S2B,
    'LPT_LORES': FM_LPT_LORES,
    'LPT_HIRES': FM_LPT_HIRES,
    'LPT_XCONN': FM_LPT_XCONN,
    'LPT_UNEXPECTED': FM_LPT_UNEXPECTED,
    'LPT_INTERNAL': FM_LPT_INTERNAL,
    'LPT_CURRENT_SOURCE': FM_LPT_CURRENT_SOURCE,
    'LPT_SUPPLY': FM_LPT_SUPPLY,
    'LPT_LOW_SIDE_SWITCH': FM_LPT_LOW_SIDE_SWITCH,
    'LPT_HIGH_SIDE_SWITCH': FM_LPT_HIGH_SIDE_SWITCH,
    'LPT_GROUND_LOSS': FM_LPT_GROUND_LOSS,
    'LPT_CSR_XCONN': FM_LPT_CSR_XCONN,
    'LPT_PDC_ABORT_INT': FM_LPT_PDC_ABORT_INT,
    'LPT_PDC_ABORT_EXT': FM_LPT_PDC_ABORT_EXT,
    'LPT_DWELL': FM_LPT_DWELL,
    'RSA_OPEN': FM_RSA_OPEN,
    'RSA_S2G': FM_RSA_S2G,
    'RSA_S2B': FM_RSA_S2B,
    'RSA_LORES': FM_RSA_LORES,
    'RSA_HIRES': FM_RSA_HIRES,
    'RSA_XCONN': FM_RSA_XCONN,
    'RSA_UNEXPECTED': FM_RSA_UNEXPECTED,
    'RSA_INTERNAL': FM_RSA_INTERNAL,
    'RSA_CURRENT_SOURCE': FM_RSA_CURRENT_SOURCE,
    'RSA_SUPPLY': FM_RSA_SUPPLY,
    'RSA_LOW_SIDE_SWITCH': FM_RSA_LOW_SIDE_SWITCH,
    'RSA_HIGH_SIDE_SWITCH': FM_RSA_HIGH_SIDE_SWITCH,
    'RSA_GROUND_LOSS': FM_RSA_GROUND_LOSS,
    'RSA_CSR_XCONN': FM_RSA_CSR_XCONN,
    'RSA_PDC_ABORT_INT': FM_RSA_PDC_ABORT_INT,
    'RSA_PDC_ABORT_EXT': FM_RSA_PDC_ABORT_EXT,
    'RSA_DWELL': FM_RSA_DWELL,
    'LSA_OPEN': FM_LSA_OPEN,
    'LSA_S2G': FM_LSA_S2G,
    'LSA_S2B': FM_LSA_S2B,
    'LSA_LORES': FM_LSA_LORES,
    'LSA_HIRES': FM_LSA_HIRES,
    'LSA_XCONN': FM_LSA_XCONN,
    'LSA_UNEXPECTED': FM_LSA_UNEXPECTED,
    'LSA_INTERNAL': FM_LSA_INTERNAL,
    'LSA_CURRENT_SOURCE': FM_LSA_CURRENT_SOURCE,
    'LSA_SUPPLY': FM_LSA_SUPPLY,
    'LSA_LOW_SIDE_SWITCH': FM_LSA_LOW_SIDE_SWITCH,
    'LSA_HIGH_SIDE_SWITCH': FM_LSA_HIGH_SIDE_SWITCH,
    'LSA_GROUND_LOSS': FM_LSA_GROUND_LOSS,
    'LSA_CSR_XCONN': FM_LSA_CSR_XCONN,
    'LSA_PDC_ABORT_INT': FM_LSA_PDC_ABORT_INT,
    'LSA_PDC_ABORT_EXT': FM_LSA_PDC_ABORT_EXT,
    'LSA_DWELL': FM_LSA_DWELL,
    'RCA_OPEN': FM_RCA_OPEN,
    'RCA_S2G': FM_RCA_S2G,
    'RCA_S2B': FM_RCA_S2B,
    'RCA_LORES': FM_RCA_LORES,
    'RCA_HIRES': FM_RCA_HIRES,
    'RCA_XCONN': FM_RCA_XCONN,
    'RCA_UNEXPECTED': FM_RCA_UNEXPECTED,
    'RCA_INTERNAL': FM_RCA_INTERNAL,
    'RCA_CURRENT_SOURCE': FM_RCA_CURRENT_SOURCE,
    'RCA_SUPPLY': FM_RCA_SUPPLY,
    'RCA_LOW_SIDE_SWITCH': FM_RCA_LOW_SIDE_SWITCH,
    'RCA_HIGH_SIDE_SWITCH': FM_RCA_HIGH_SIDE_SWITCH,
    'RCA_GROUND_LOSS': FM_RCA_GROUND_LOSS,
    'RCA_CSR_XCONN': FM_RCA_CSR_XCONN,
    'RCA_PDC_ABORT_INT': FM_RCA_PDC_ABORT_INT,
    'RCA_PDC_ABORT_EXT': FM_RCA_PDC_ABORT_EXT,
    'RCA_DWELL': FM_RCA_DWELL,
    'LCA_OPEN': FM_LCA_OPEN,
    'LCA_S2G': FM_LCA_S2G,
    'LCA_S2B': FM_LCA_S2B,
    'LCA_LORES': FM_LCA_LORES,
    'LCA_HIRES': FM_LCA_HIRES,
    'LCA_XCONN': FM_LCA_XCONN,
    'LCA_UNEXPECTED': FM_LCA_UNEXPECTED,
    'LCA_INTERNAL': FM_LCA_INTERNAL,
    'LCA_CURRENT_SOURCE': FM_LCA_CURRENT_SOURCE,
    'LCA_SUPPLY': FM_LCA_SUPPLY,
    'LCA_LOW_SIDE_SWITCH': FM_LCA_LOW_SIDE_SWITCH,
    'LCA_HIGH_SIDE_SWITCH': FM_LCA_HIGH_SIDE_SWITCH,
    'LCA_GROUND_LOSS': FM_LCA_GROUND_LOSS,
    'LCA_CSR_XCONN': FM_LCA_CSR_XCONN,
    'LCA_PDC_ABORT_INT': FM_LCA_PDC_ABORT_INT,
    'LCA_PDC_ABORT_EXT': FM_LCA_PDC_ABORT_EXT,
    'LCA_DWELL': FM_LCA_DWELL,
    'DAB_OPEN': FM_DAB_OPEN,
    'DAB_S2G': FM_DAB_S2G,
    'DAB_S2B': FM_DAB_S2B,
    'DAB_LORES': FM_DAB_LORES,
    'DAB_HIRES': FM_DAB_HIRES,
    'DAB_XCONN': FM_DAB_XCONN,
    'DAB_UNEXPECTED': FM_DAB_UNEXPECTED,
    'DAB_INTERNAL': FM_DAB_INTERNAL,
    'DAB_CURRENT_SOURCE': FM_DAB_CURRENT_SOURCE,
    'DAB_SUPPLY': FM_DAB_SUPPLY,
    'DAB_LOW_SIDE_SWITCH': FM_DAB_LOW_SIDE_SWITCH,
    'DAB_HIGH_SIDE_SWITCH': FM_DAB_HIGH_SIDE_SWITCH,
    'DAB_GROUND_LOSS': FM_DAB_GROUND_LOSS,
    'DAB_CSR_XCONN': FM_DAB_CSR_XCONN,
    'DAB_PDC_ABORT_INT': FM_DAB_PDC_ABORT_INT,
    'DAB_PDC_ABORT_EXT': FM_DAB_PDC_ABORT_EXT,
    'DAB_DWELL': FM_DAB_DWELL,
    'PAB_OPEN': FM_PAB_OPEN,
    'PAB_S2G': FM_PAB_S2G,
    'PAB_S2B': FM_PAB_S2B,
    'PAB_LORES': FM_PAB_LORES,
    'PAB_HIRES': FM_PAB_HIRES,
    'PAB_XCONN': FM_PAB_XCONN,
    'PAB_UNEXPECTED': FM_PAB_UNEXPECTED,
    'PAB_INTERNAL': FM_PAB_INTERNAL,
    'PAB_CURRENT_SOURCE': FM_PAB_CURRENT_SOURCE,
    'PAB_SUPPLY': FM_PAB_SUPPLY,
    'PAB_LOW_SIDE_SWITCH': FM_PAB_LOW_SIDE_SWITCH,
    'PAB_HIGH_SIDE_SWITCH': FM_PAB_HIGH_SIDE_SWITCH,
    'PAB_GROUND_LOSS': FM_PAB_GROUND_LOSS,
    'PAB_CSR_XCONN': FM_PAB_CSR_XCONN,
    'PAB_PDC_ABORT_INT': FM_PAB_PDC_ABORT_INT,
    'PAB_PDC_ABORT_EXT': FM_PAB_PDC_ABORT_EXT,
    'PAB_DWELL': FM_PAB_DWELL,
    'LINE08_OPEN': FM_LINE08_OPEN,
    'LINE08_S2G': FM_LINE08_S2G,
    'LINE08_S2B': FM_LINE08_S2B,
    'LINE08_LORES': FM_LINE08_LORES,
    'LINE08_HIRES': FM_LINE08_HIRES,
    'LINE08_XCONN': FM_LINE08_XCONN,
    'LINE08_UNEXPECTED': FM_LINE08_UNEXPECTED,
    'LINE08_INTERNAL': FM_LINE08_INTERNAL,
    'LINE08_CURRENT_SOURCE': FM_LINE08_CURRENT_SOURCE,
    'LINE08_SUPPLY': FM_LINE08_SUPPLY,
    'LINE08_LOW_SIDE_SWITCH': FM_LINE08_LOW_SIDE_SWITCH,
    'LINE08_HIGH_SIDE_SWITCH': FM_LINE08_HIGH_SIDE_SWITCH,
    'LINE08_GROUND_LOSS': FM_LINE08_GROUND_LOSS,
    'LINE08_CSR_XCONN': FM_LINE08_CSR_XCONN,
    'LINE08_PDC_ABORT_INT': FM_LINE08_PDC_ABORT_INT,
    'LINE08_PDC_ABORT_EXT': FM_LINE08_PDC_ABORT_EXT,
    'LINE08_DWELL': FM_LINE08_DWELL,
    'LINE09_OPEN': FM_LINE09_OPEN,
    'LINE09_S2G': FM_LINE09_S2G,
    'LINE09_S2B': FM_LINE09_S2B,
    'LINE09_LORES': FM_LINE09_LORES,
    'LINE09_HIRES': FM_LINE09_HIRES,
    'LINE09_XCONN': FM_LINE09_XCONN,
    'LINE09_UNEXPECTED': FM_LINE09_UNEXPECTED,
    'LINE09_INTERNAL': FM_LINE09_INTERNAL,
    'LINE09_CURRENT_SOURCE': FM_LINE09_CURRENT_SOURCE,
    'LINE09_SUPPLY': FM_LINE09_SUPPLY,
    'LINE09_LOW_SIDE_SWITCH': FM_LINE09_LOW_SIDE_SWITCH,
    'LINE09_HIGH_SIDE_SWITCH': FM_LINE09_HIGH_SIDE_SWITCH,
    'LINE09_GROUND_LOSS': FM_LINE09_GROUND_LOSS,
    'LINE09_CSR_XCONN': FM_LINE09_CSR_XCONN,
    'LINE09_PDC_ABORT_INT': FM_LINE09_PDC_ABORT_INT,
    'LINE09_PDC_ABORT_EXT': FM_LINE09_PDC_ABORT_EXT,
    'LINE09_DWELL': FM_LINE09_DWELL,
    'LINE10_OPEN': FM_LINE10_OPEN,
    'LINE10_S2G': FM_LINE10_S2G,
    'LINE10_S2B': FM_LINE10_S2B,
    'LINE10_LORES': FM_LINE10_LORES,
    'LINE10_HIRES': FM_LINE10_HIRES,
    'LINE10_XCONN': FM_LINE10_XCONN,
    'LINE10_UNEXPECTED': FM_LINE10_UNEXPECTED,
    'LINE10_INTERNAL': FM_LINE10_INTERNAL,
    'LINE10_CURRENT_SOURCE': FM_LINE10_CURRENT_SOURCE,
    'LINE10_SUPPLY': FM_LINE10_SUPPLY,
    'LINE10_LOW_SIDE_SWITCH': FM_LINE10_LOW_SIDE_SWITCH,
    'LINE10_HIGH_SIDE_SWITCH': FM_LINE10_HIGH_SIDE_SWITCH,
    'LINE10_GROUND_LOSS': FM_LINE10_GROUND_LOSS,
    'LINE10_CSR_XCONN': FM_LINE10_CSR_XCONN,
    'LINE10_PDC_ABORT_INT': FM_LINE10_PDC_ABORT_INT,
    'LINE10_PDC_ABORT_EXT': FM_LINE10_PDC_ABORT_EXT,
    'LINE10_DWELL': FM_LINE10_DWELL,
    'DKA_OPEN': FM_DKA_OPEN,
    'DKA_S2G': FM_DKA_S2G,
    'DKA_S2B': FM_DKA_S2B,
    'DKA_LORES': FM_DKA_LORES,
    'DKA_HIRES': FM_DKA_HIRES,
    'DKA_XCONN': FM_DKA_XCONN,
    'DKA_UNEXPECTED': FM_DKA_UNEXPECTED,
    'DKA_INTERNAL': FM_DKA_INTERNAL,
    'DKA_CURRENT_SOURCE': FM_DKA_CURRENT_SOURCE,
    'DKA_SUPPLY': FM_DKA_SUPPLY,
    'DKA_LOW_SIDE_SWITCH': FM_DKA_LOW_SIDE_SWITCH,
    'DKA_HIGH_SIDE_SWITCH': FM_DKA_HIGH_SIDE_SWITCH,
    'DKA_GROUND_LOSS': FM_DKA_GROUND_LOSS,
    'DKA_CSR_XCONN': FM_DKA_CSR_XCONN,
    'DKA_PDC_ABORT_INT': FM_DKA_PDC_ABORT_INT,
    'DKA_PDC_ABORT_EXT': FM_DKA_PDC_ABORT_EXT,
    'DKA_DWELL': FM_DKA_DWELL,
    'RLPT_OPEN': FM_RLPT_OPEN,
    'RLPT_S2G': FM_RLPT_S2G,
    'RLPT_S2B': FM_RLPT_S2B,
    'RLPT_LORES': FM_RLPT_LORES,
    'RLPT_HIRES': FM_RLPT_HIRES,
    'RLPT_XCONN': FM_RLPT_XCONN,
    'RLPT_UNEXPECTED': FM_RLPT_UNEXPECTED,
    'RLPT_INTERNAL': FM_RLPT_INTERNAL,
    'RLPT_CURRENT_SOURCE': FM_RLPT_CURRENT_SOURCE,
    'RLPT_SUPPLY': FM_RLPT_SUPPLY,
    'RLPT_LOW_SIDE_SWITCH': FM_RLPT_LOW_SIDE_SWITCH,
    'RLPT_HIGH_SIDE_SWITCH': FM_RLPT_HIGH_SIDE_SWITCH,
    'RLPT_GROUND_LOSS': FM_RLPT_GROUND_LOSS,
    'RLPT_CSR_XCONN': FM_RLPT_CSR_XCONN,
    'RLPT_PDC_ABORT_INT': FM_RLPT_PDC_ABORT_INT,
    'RLPT_PDC_ABORT_EXT': FM_RLPT_PDC_ABORT_EXT,
    'RLPT_DWELL': FM_RLPT_DWELL,
    'LLPT_OPEN': FM_LLPT_OPEN,
    'LLPT_S2G': FM_LLPT_S2G,
    'LLPT_S2B': FM_LLPT_S2B,
    'LLPT_LORES': FM_LLPT_LORES,
    'LLPT_HIRES': FM_LLPT_HIRES,
    'LLPT_XCONN': FM_LLPT_XCONN,
    'LLPT_UNEXPECTED': FM_LLPT_UNEXPECTED,
    'LLPT_INTERNAL': FM_LLPT_INTERNAL,
    'LLPT_CURRENT_SOURCE': FM_LLPT_CURRENT_SOURCE,
    'LLPT_SUPPLY': FM_LLPT_SUPPLY,
    'LLPT_LOW_SIDE_SWITCH': FM_LLPT_LOW_SIDE_SWITCH,
    'LLPT_HIGH_SIDE_SWITCH': FM_LLPT_HIGH_SIDE_SWITCH,
    'LLPT_GROUND_LOSS': FM_LLPT_GROUND_LOSS,
    'LLPT_CSR_XCONN': FM_LLPT_CSR_XCONN,
    'LLPT_PDC_ABORT_INT': FM_LLPT_PDC_ABORT_INT,
    'LLPT_PDC_ABORT_EXT': FM_LLPT_PDC_ABORT_EXT,
    'LLPT_DWELL': FM_LLPT_DWELL,
    'DFV_INTERNAL': FM_DFV_INTERNAL,
    'DFV_CURRENT_SOURCE': FM_DFV_CURRENT_SOURCE,
    'DFV_SUPPLY': FM_DFV_SUPPLY,
    'DFV_LOW_SIDE_SWITCH': FM_DFV_LOW_SIDE_SWITCH,
    'DFV_HIGH_SIDE_SWITCH': FM_DFV_HIGH_SIDE_SWITCH,
    'DFV_GROUND_LOSS': FM_DFV_GROUND_LOSS,
    'DFV_CSR_XCONN': FM_DFV_CSR_XCONN,
    'DFV_PDC_ABORT_INT': FM_DFV_PDC_ABORT_INT,
    'DFV_PDC_ABORT_EXT': FM_DFV_PDC_ABORT_EXT,
    'DFV_DWELL': FM_DFV_DWELL,
    'PFV_INTERNAL': FM_PFV_INTERNAL,
    'PFV_CURRENT_SOURCE': FM_PFV_CURRENT_SOURCE,
    'PFV_SUPPLY': FM_PFV_SUPPLY,
    'PFV_LOW_SIDE_SWITCH': FM_PFV_LOW_SIDE_SWITCH,
    'PFV_HIGH_SIDE_SWITCH': FM_PFV_HIGH_SIDE_SWITCH,
    'PFV_GROUND_LOSS': FM_PFV_GROUND_LOSS,
    'PFV_CSR_XCONN': FM_PFV_CSR_XCONN,
    'PFV_PDC_ABORT_INT': FM_PFV_PDC_ABORT_INT,
    'PFV_PDC_ABORT_EXT': FM_PFV_PDC_ABORT_EXT,
    'PFV_DWELL': FM_PFV_DWELL,
    'R2RPT_OPEN': FM_R2RPT_OPEN,
    'R2RPT_S2G': FM_R2RPT_S2G,
    'R2RPT_S2B': FM_R2RPT_S2B,
    'R2RPT_LORES': FM_R2RPT_LORES,
    'R2RPT_HIRES': FM_R2RPT_HIRES,
    'R2RPT_XCONN': FM_R2RPT_XCONN,
    'R2RPT_UNEXPECTED': FM_R2RPT_UNEXPECTED,
    'R2RPT_INTERNAL': FM_R2RPT_INTERNAL,
    'R2RPT_CURRENT_SOURCE': FM_R2RPT_CURRENT_SOURCE,
    'R2RPT_SUPPLY': FM_R2RPT_SUPPLY,
    'R2RPT_LOW_SIDE_SWITCH': FM_R2RPT_LOW_SIDE_SWITCH,
    'R2RPT_HIGH_SIDE_SWITCH': FM_R2RPT_HIGH_SIDE_SWITCH,
    'R2RPT_GROUND_LOSS': FM_R2RPT_GROUND_LOSS,
    'R2RPT_CSR_XCONN': FM_R2RPT_CSR_XCONN,
    'R2RPT_PDC_ABORT_INT': FM_R2RPT_PDC_ABORT_INT,
    'R2RPT_PDC_ABORT_EXT': FM_R2RPT_PDC_ABORT_EXT,
    'R2RPT_DWELL': FM_R2RPT_DWELL,
    'CAB_OPEN': FM_CAB_OPEN,
    'CAB_S2G': FM_CAB_S2G,
    'CAB_S2B': FM_CAB_S2B,
    'CAB_LORES': FM_CAB_LORES,
    'CAB_HIRES': FM_CAB_HIRES,
    'CAB_XCONN': FM_CAB_XCONN,
    'CAB_UNEXPECTED': FM_CAB_UNEXPECTED,
    'CAB_INTERNAL': FM_CAB_INTERNAL,
    'CAB_CURRENT_SOURCE': FM_CAB_CURRENT_SOURCE,
    'CAB_SUPPLY': FM_CAB_SUPPLY,
    'CAB_LOW_SIDE_SWITCH': FM_CAB_LOW_SIDE_SWITCH,
    'CAB_HIGH_SIDE_SWITCH': FM_CAB_HIGH_SIDE_SWITCH,
    'CAB_GROUND_LOSS': FM_CAB_GROUND_LOSS,
    'CAB_CSR_XCONN': FM_CAB_CSR_XCONN,
    'CAB_PDC_ABORT_INT': FM_CAB_PDC_ABORT_INT,
    'CAB_PDC_ABORT_EXT': FM_CAB_PDC_ABORT_EXT,
    'CAB_DWELL': FM_CAB_DWELL,
    'R2LPT_OPEN': FM_R2LPT_OPEN,
    'R2LPT_S2G': FM_R2LPT_S2G,
    'R2LPT_S2B': FM_R2LPT_S2B,
    'R2LPT_LORES': FM_R2LPT_LORES,
    'R2LPT_HIRES': FM_R2LPT_HIRES,
    'R2LPT_XCONN': FM_R2LPT_XCONN,
    'R2LPT_UNEXPECTED': FM_R2LPT_UNEXPECTED,
    'R2LPT_INTERNAL': FM_R2LPT_INTERNAL,
    'R2LPT_CURRENT_SOURCE': FM_R2LPT_CURRENT_SOURCE,
    'R2LPT_SUPPLY': FM_R2LPT_SUPPLY,
    'R2LPT_LOW_SIDE_SWITCH': FM_R2LPT_LOW_SIDE_SWITCH,
    'R2LPT_HIGH_SIDE_SWITCH': FM_R2LPT_HIGH_SIDE_SWITCH,
    'R2LPT_GROUND_LOSS': FM_R2LPT_GROUND_LOSS,
    'R2LPT_CSR_XCONN': FM_R2LPT_CSR_XCONN,
    'R2LPT_PDC_ABORT_INT': FM_R2LPT_PDC_ABORT_INT,
    'R2LPT_PDC_ABORT_EXT': FM_R2LPT_PDC_ABORT_EXT,
    'R2LPT_DWELL': FM_R2LPT_DWELL,
    'DBFL_OPEN': FM_DBFL_OPEN,
    'DBFL_S2G': FM_DBFL_S2G,
    'DBFL_S2B': FM_DBFL_S2B,
    'DBFL_LORES': FM_DBFL_LORES,
    'DBFL_HIRES': FM_DBFL_HIRES,
    'DBFL_XCONN': FM_DBFL_XCONN,
    'DBFL_UNEXPECTED': FM_DBFL_UNEXPECTED,
    'DBFL_INTERNAL': FM_DBFL_INTERNAL,
    'DBFL_CURRENT_SOURCE': FM_DBFL_CURRENT_SOURCE,
    'DBFL_SUPPLY': FM_DBFL_SUPPLY,
    'DBFL_LOW_SIDE_SWITCH': FM_DBFL_LOW_SIDE_SWITCH,
    'DBFL_HIGH_SIDE_SWITCH': FM_DBFL_HIGH_SIDE_SWITCH,
    'DBFL_GROUND_LOSS': FM_DBFL_GROUND_LOSS,
    'DBFL_CSR_XCONN': FM_DBFL_CSR_XCONN,
    'DBFL_PDC_ABORT_INT': FM_DBFL_PDC_ABORT_INT,
    'DBFL_PDC_ABORT_EXT': FM_DBFL_PDC_ABORT_EXT,
    'DBFL_DWELL': FM_DBFL_DWELL,
    'PBFL_OPEN': FM_PBFL_OPEN,
    'PBFL_S2G': FM_PBFL_S2G,
    'PBFL_S2B': FM_PBFL_S2B,
    'PBFL_LORES': FM_PBFL_LORES,
    'PBFL_HIRES': FM_PBFL_HIRES,
    'PBFL_XCONN': FM_PBFL_XCONN,
    'PBFL_UNEXPECTED': FM_PBFL_UNEXPECTED,
    'PBFL_INTERNAL': FM_PBFL_INTERNAL,
    'PBFL_CURRENT_SOURCE': FM_PBFL_CURRENT_SOURCE,
    'PBFL_SUPPLY': FM_PBFL_SUPPLY,
    'PBFL_LOW_SIDE_SWITCH': FM_PBFL_LOW_SIDE_SWITCH,
    'PBFL_HIGH_SIDE_SWITCH': FM_PBFL_HIGH_SIDE_SWITCH,
    'PBFL_GROUND_LOSS': FM_PBFL_GROUND_LOSS,
    'PBFL_CSR_XCONN': FM_PBFL_CSR_XCONN,
    'PBFL_PDC_ABORT_INT': FM_PBFL_PDC_ABORT_INT,
    'PBFL_PDC_ABORT_EXT': FM_PBFL_PDC_ABORT_EXT,
    'PBFL_DWELL': FM_PBFL_DWELL,
    'HVBD_INTERNAL': FM_HVBD_INTERNAL,
    'HVBD_CURRENT_SOURCE': FM_HVBD_CURRENT_SOURCE,
    'HVBD_SUPPLY': FM_HVBD_SUPPLY,
    'HVBD_LOW_SIDE_SWITCH': FM_HVBD_LOW_SIDE_SWITCH,
    'HVBD_HIGH_SIDE_SWITCH': FM_HVBD_HIGH_SIDE_SWITCH,
    'HVBD_GROUND_LOSS': FM_HVBD_GROUND_LOSS,
    'HVBD_CSR_XCONN': FM_HVBD_CSR_XCONN,
    'HVBD_PDC_ABORT_INT': FM_HVBD_PDC_ABORT_INT,
    'HVBD_PDC_ABORT_EXT': FM_HVBD_PDC_ABORT_EXT,
    'HVBD_DWELL': FM_HVBD_DWELL,
    'PPC_INTERNAL': FM_PPC_INTERNAL,
    'PPC_CURRENT_SOURCE': FM_PPC_CURRENT_SOURCE,
    'PPC_SUPPLY': FM_PPC_SUPPLY,
    'PPC_LOW_SIDE_SWITCH': FM_PPC_LOW_SIDE_SWITCH,
    'PPC_HIGH_SIDE_SWITCH': FM_PPC_HIGH_SIDE_SWITCH,
    'PPC_GROUND_LOSS': FM_PPC_GROUND_LOSS,
    'PPC_CSR_XCONN': FM_PPC_CSR_XCONN,
    'PPC_PDC_ABORT_INT': FM_PPC_PDC_ABORT_INT,
    'PPC_PDC_ABORT_EXT': FM_PPC_PDC_ABORT_EXT,
    'PPC_DWELL': FM_PPC_DWELL,
    'DPC_INTERNAL': FM_DPC_INTERNAL,
    'DPC_CURRENT_SOURCE': FM_DPC_CURRENT_SOURCE,
    'DPC_SUPPLY': FM_DPC_SUPPLY,
    'DPC_LOW_SIDE_SWITCH': FM_DPC_LOW_SIDE_SWITCH,
    'DPC_HIGH_SIDE_SWITCH': FM_DPC_HIGH_SIDE_SWITCH,
    'DPC_GROUND_LOSS': FM_DPC_GROUND_LOSS,
    'DPC_CSR_XCONN': FM_DPC_CSR_XCONN,
    'DPC_PDC_ABORT_INT': FM_DPC_PDC_ABORT_INT,
    'DPC_PDC_ABORT_EXT': FM_DPC_PDC_ABORT_EXT,
    'DPC_DWELL': FM_DPC_DWELL,
    'LINE24_S2G': FM_LINE24_S2G,
    'LINE25_S2G': FM_LINE25_S2G,
    'LINE26_S2G': FM_LINE26_S2G,
    'LINE27_S2G': FM_LINE27_S2G,
    'LINE28_S2G': FM_LINE28_S2G,
    'LINE29_S2G': FM_LINE29_S2G,
    'LINE30_S2G': FM_LINE30_S2G,
    'LINE31_S2G': FM_LINE31_S2G,
    'LOOP0_CURRENT_MONITOR': FM_LOOP0_CURRENT_MONITOR,
    'LOOP1_CURRENT_MONITOR': FM_LOOP1_CURRENT_MONITOR,
    'LOOP2_CURRENT_MONITOR': FM_LOOP2_CURRENT_MONITOR,
    'LOOP3_CURRENT_MONITOR': FM_LOOP3_CURRENT_MONITOR,
    'LOOP_ASIC0_VRCM': FM_LOOP_ASIC0_VRCM,
    'LOOP_ASIC1_VRCM': FM_LOOP_ASIC1_VRCM,
    'LOOP_ASIC2_VRCM': FM_LOOP_ASIC2_VRCM,
    'LOOP_ASIC0_LOCKING': FM_LOOP_ASIC0_LOCKING,
    'LOOP_ASIC1_LOCKING': FM_LOOP_ASIC1_LOCKING,
    'LOOP_ASIC2_LOCKING': FM_LOOP_ASIC2_LOCKING,
    'LOOP_ASIC0_CONFIG': FM_LOOP_ASIC0_CONFIG,
    'LOOP_ASIC1_CONFIG': FM_LOOP_ASIC1_CONFIG,
    'LOOP_ASIC2_CONFIG': FM_LOOP_ASIC2_CONFIG,
    'LOOP_ASIC0_DEPLOY_COMMAND': FM_LOOP_ASIC0_DEPLOY_COMMAND,
    'LOOP_ASIC1_DEPLOY_COMMAND': FM_LOOP_ASIC1_DEPLOY_COMMAND,
    'LOOP_ASIC2_DEPLOY_COMMAND': FM_LOOP_ASIC2_DEPLOY_COMMAND,
    'LOOP_ASIC0_DEPLOY_COMPARE': FM_LOOP_ASIC0_DEPLOY_COMPARE,
    'LOOP_ASIC1_DEPLOY_COMPARE': FM_LOOP_ASIC1_DEPLOY_COMPARE,
    'LOOP_ASIC2_DEPLOY_COMPARE': FM_LOOP_ASIC2_DEPLOY_COMPARE,
}


# ====================================================================================================
# General purpose outputs (32)
# <output>_<fault>: PAB_OFF (driver 0, passenger airbag OFF lamp), PAB_ON (driver 1, PAB ON lamp),
# ENS (driver 2, crash output) and ECALL (driver 3, E-Call output; not in gpo_config).
# ====================================================================================================
FM_PAB_OFF_S2G = {'dtc': '0x92 0x10 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'GPO_F_SHORT_GND_0', 'req': 36068901,
                  'text': ('GPO Driver 0 short to ground '
                           '(FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_SHORT_TO_GND)')}
FM_PAB_OFF_S2B = {'dtc': '0x92 0x10 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'GPO_F_SHORT_BAT_0', 'req': 36073723,
                  'text': ('GPO Driver 0 short to battery '
                           '(FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_SHORT_TO_BAT)')}
FM_PAB_OFF_OPEN = {'dtc': '0x92 0x10 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                   'monitor': 'GPO_F_OPEN_0', 'req': 36068910,
                   'text': 'GPO Driver 0 open circuit (FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_OPEN)'}
FM_PAB_OFF_CONFIG = {'dtc': '0x92 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_0',
                     'req': 36068915,
                     'text': ('GPO Driver 0 configuration missmatch '
                              '(FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_CONFIGURATION_ERROR)')}
FM_PAB_OFF_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                                 '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                      'latched': True, 'monitor': 'GPO_F_THERMAL_0', 'req': 36068920,
                      'text': 'GPO Driver 0 over temperature (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_OFF_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                                  '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                       'latched': False, 'monitor': 'GPO_F_INTERNAL_0', 'req': 36068925,
                       'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                                'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to '
                                'change the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
FM_PAB_OFF_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_0',
                  'req': 36068930, 'text': 'GPO Driver 0 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_OFF_UNEXPECTED = {'dtc': '0x92 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                    'Value: Within PDC(2 sec)'),
                         'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_0', 'req': 36068935,
                         'text': ('GPO Driver 0 configuration missmatch '
                                  '(FLTMONR_LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_CONFIGURATION_ERROR)')}
FM_PAB_ON_S2G = {'dtc': '0x90 0x24 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'GPO_F_SHORT_GND_1', 'req': 36068902,
                 'text': 'GPO Driver 1 short to ground (FLTMONR_GPO_E_PAB_ON_LED_LINE_SHORT_TO_GND)'}
FM_PAB_ON_S2B = {'dtc': '0x90 0x24 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'GPO_F_SHORT_BAT_1', 'req': 36068906,
                 'text': 'GPO Driver 1 short to battery (FLTMONR_GPO_E_PAB_ON_LED_LINE_SHORT_TO_BAT)'}
FM_PAB_ON_OPEN = {'dtc': '0x90 0x24 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                  'monitor': 'GPO_F_OPEN_1', 'req': 36068911,
                  'text': 'GPO Driver 1 open circuit (FLTMONR_GPO_E_PAB_ON_LED_LINE_OPEN)'}
FM_PAB_ON_CONFIG = {'dtc': '0x90 0x24 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_1',
                    'req': 36068916,
                    'text': ('GPO Driver 1 configuration missmatch '
                             '(FLTMONR_GPO_E_PAB_ON_LED_LINE_CONFIGURATION_ERROR)')}
FM_PAB_ON_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                                '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                     'latched': True, 'monitor': 'GPO_F_THERMAL_1', 'req': 36068921,
                     'text': 'GPO Driver 1 over temperature (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_ON_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                                 '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                      'latched': False, 'monitor': 'GPO_F_INTERNAL_1', 'req': 36068926,
                      'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                               'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to '
                               'change the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
FM_PAB_ON_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_1',
                 'req': 36068931, 'text': 'GPO Driver 1 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PAB_ON_UNEXPECTED = {'dtc': '0x90 0x24 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                   'Within PDC(2 sec)'),
                        'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_1', 'req': 36068936,
                        'text': ('GPO Driver 1 configuration missmatch '
                                 '(FLTMONR_GPO_E_PAB_ON_LED_LINE_CONFIGURATION_ERROR)')}
FM_ENS_S2G = {'dtc': '0x92 0x18 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'GPO_F_SHORT_GND_2', 'req': 36068903,
              'text': 'GPO Driver 2 short to ground (FLTMONR_GPO_CRASH_OUTPUT_E_SHORT_TO_GND)'}
FM_ENS_S2B = {'dtc': '0x92 0x18 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'GPO_F_SHORT_BAT_2', 'req': 36068907,
              'text': 'GPO Driver 2 short to battery (FLTMONR_GPO_CRASH_OUTPUT_E_SHORT_TO_BAT)'}
FM_ENS_OPEN = {'dtc': '0x92 0x18 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'GPO_F_OPEN_2', 'req': 36068912,
               'text': 'GPO Driver 2 open circuit (FLTMONR_GPO_CRASH_OUTPUT_E_OPEN)'}
FM_ENS_CONFIG = {'dtc': '0x92 0x18 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_2',
                 'req': 36068917,
                 'text': 'GPO Driver 2 configuration missmatch (FLTMONR_GPO_CRASH_OUTPUT_E_CONFIGURATION_ERROR)'}
FM_ENS_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                             '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                  'latched': True, 'monitor': 'GPO_F_THERMAL_2', 'req': 36068922,
                  'text': 'GPO Driver 2 over temperature (FLTMONR_E_ECU_INTERNAL)'}
FM_ENS_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: 2.2 '
                              '(PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                   'latched': False, 'monitor': 'GPO_F_INTERNAL_2', 'req': 36068927,
                   'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                            'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to change '
                            'the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
FM_ENS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
              'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_2',
              'req': 36068932, 'text': 'GPO Driver 2 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_ENS_UNEXPECTED = {'dtc': '0x92 0x18 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_2', 'req': 36068937,
                     'text': ('GPO Driver 2 configuration missmatch '
                              '(FLTMONR_GPO_CRASH_OUTPUT_E_CONFIGURATION_ERROR)')}
FM_ECALL_S2G = {'dtc': '0x99 0x0E 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'GPO_F_SHORT_GND_3', 'req': 36068904,
                'text': 'GPO Driver 3 short to ground (FLTMONR_GPO_ECALL_E_SHORT_TO_GND)'}
FM_ECALL_S2B = {'dtc': '0x99 0x0E 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'GPO_F_SHORT_BAT_3', 'req': 36068908,
                'text': 'GPO Driver 3 short to battery (FLTMONR_GPO_ECALL_E_SHORT_TO_BAT)'}
FM_ECALL_OPEN = {'dtc': '0x99 0x0E 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'GPO_F_OPEN_3', 'req': 36068913,
                 'text': 'GPO Driver 3 open circuit (FLTMONR_GPO_ECALL_E_OPEN)'}
FM_ECALL_CONFIG = {'dtc': '0x99 0x0E 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: 2.2; dematuration: n/a', 'latched': True, 'monitor': 'GPO_F_CFG_3',
                   'req': 36068918,
                   'text': 'GPO Driver 3 configuration missmatch (FLTMONR_GPO_ECALL_E_CONFIGURATION_ERROR)'}
FM_ECALL_THERMAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                               '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                    'latched': True, 'monitor': 'GPO_F_THERMAL_3', 'req': 36068923,
                    'text': 'GPO Driver 3 over temperature (FLTMONR_E_ECU_INTERNAL)'}
FM_ECALL_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: 2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output); dematuration: '
                                '2.2 (PDC) 6.4 (Drive Lamp) 12.8 (Drive Crash_Output)'),
                     'latched': False, 'monitor': 'GPO_F_INTERNAL_3', 'req': 36068928,
                     'text': ('GPO Driver internal fault GPO Driver Error Bit(mismatch on the bits combinations '
                              'during AND/ORED Bits acquisition and process) and GPO Control Error(unable to '
                              'change the duty cycle) (FLTMONR_E_ECU_INTERNAL)')}
FM_ECALL_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: 0.005; dematuration: 0.0005', 'latched': False, 'monitor': 'GPO_F_SPI_3',
                'req': 36068933, 'text': 'GPO Driver 3 SPI Communication Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_ECALL_UNEXPECTED = {'dtc': '0x99 0x0E 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                  'Within PDC(2 sec)'),
                       'latched': True, 'monitor': 'GPO_F_UNEXPECTED_LOAD_3', 'req': 36068938,
                       'text': 'GPO Load Unexpected Load EX3_0 CH3 (FLTMONR_GPO_ECALL_E_CONFIGURATION_ERROR)'}

GPO_FAULTS = {
    'PAB_OFF_S2G': FM_PAB_OFF_S2G,
    'PAB_OFF_S2B': FM_PAB_OFF_S2B,
    'PAB_OFF_OPEN': FM_PAB_OFF_OPEN,
    'PAB_OFF_CONFIG': FM_PAB_OFF_CONFIG,
    'PAB_OFF_THERMAL': FM_PAB_OFF_THERMAL,
    'PAB_OFF_INTERNAL': FM_PAB_OFF_INTERNAL,
    'PAB_OFF_SPI': FM_PAB_OFF_SPI,
    'PAB_OFF_UNEXPECTED': FM_PAB_OFF_UNEXPECTED,
    'PAB_ON_S2G': FM_PAB_ON_S2G,
    'PAB_ON_S2B': FM_PAB_ON_S2B,
    'PAB_ON_OPEN': FM_PAB_ON_OPEN,
    'PAB_ON_CONFIG': FM_PAB_ON_CONFIG,
    'PAB_ON_THERMAL': FM_PAB_ON_THERMAL,
    'PAB_ON_INTERNAL': FM_PAB_ON_INTERNAL,
    'PAB_ON_SPI': FM_PAB_ON_SPI,
    'PAB_ON_UNEXPECTED': FM_PAB_ON_UNEXPECTED,
    'ENS_S2G': FM_ENS_S2G,
    'ENS_S2B': FM_ENS_S2B,
    'ENS_OPEN': FM_ENS_OPEN,
    'ENS_CONFIG': FM_ENS_CONFIG,
    'ENS_THERMAL': FM_ENS_THERMAL,
    'ENS_INTERNAL': FM_ENS_INTERNAL,
    'ENS_SPI': FM_ENS_SPI,
    'ENS_UNEXPECTED': FM_ENS_UNEXPECTED,
    'ECALL_S2G': FM_ECALL_S2G,
    'ECALL_S2B': FM_ECALL_S2B,
    'ECALL_OPEN': FM_ECALL_OPEN,
    'ECALL_CONFIG': FM_ECALL_CONFIG,
    'ECALL_THERMAL': FM_ECALL_THERMAL,
    'ECALL_INTERNAL': FM_ECALL_INTERNAL,
    'ECALL_SPI': FM_ECALL_SPI,
    'ECALL_UNEXPECTED': FM_ECALL_UNEXPECTED,
}


# ====================================================================================================
# Belt buckles, seat track sensors and ODS (DCS channels) (72)
# <seat>_<fault>: DRV / PSGR = front seats, R2L / R2M / R2R = second row left / middle / right, R3L
# / R3R = third row; BELT = buckle switch, STPS1/2 = seat track position switch, ODS = occupant
# switch; ASIC = sensor ASIC failure. DCS16 is the unassigned sensor 16.
# ====================================================================================================
FM_R2R_BELT_S2B = {'dtc': '0x92 0x43 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_SHORT_PLUS_0', 'req': 36069087,
                   'text': ('DCS Sensor 0 short to battery '
                            '(FLTMONR_DCS_E_SECOND_ROW_RIGHT_BUCKLE_SWITCH_LEAK_TO_PLUS)')}
FM_R2R_BELT_XCONN = {'dtc': '0x92 0x55 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_CROSS_CONNECT_0', 'req': 36068976,
                     'text': ('DCS Sensor 0 cross connected '
                              '(FLTMONR_DCS_E_SECOND_ROW_RIGHT_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_R2R_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_INTERNAL_0', 'req': 36069107,
                    'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2R_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_SPI_0', 'req': 36069129,
                   'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DRV_BELT_S2B = {'dtc': '0x90 0x33 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_SHORT_PLUS_1', 'req': 36069088,
                   'text': 'DCS Sensor 1 short to battery (FLTMONR_DCS_E_DRIVER_SEAT_BELT_LEAK_TO_PLUS)'}
FM_DRV_BELT_XCONN = {'dtc': '0x92 0x53 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_CROSS_CONNECT_1', 'req': 36068977,
                     'text': ('DCS Sensor 1 cross connected '
                              '(FLTMONR_DCS_E_DRIVER_SEAT_BELT_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_DRV_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_INTERNAL_1', 'req': 36069108,
                    'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DRV_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_SPI_1', 'req': 36069130,
                   'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PSGR_BELT_S2B = {'dtc': '0x90 0x32 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                    'monitor': 'DCS_F_SHORT_PLUS_2', 'req': 36069089,
                    'text': 'DCS Sensor 2 short to battery (FLTMONR_DCS_E_PASSENGER_SEAT_BELT_LEAK_TO_PLUS)'}
FM_PSGR_BELT_XCONN = {'dtc': '0x92 0x54 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                      'monitor': 'DCS_F_CROSS_CONNECT_2', 'req': 36068978,
                      'text': ('DCS Sensor 2 cross connected '
                               '(FLTMONR_DCS_E_PASSENGER_SEAT_BELT_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_PSGR_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                     'monitor': 'DCS_F_INTERNAL_2', 'req': 36069109,
                     'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PSGR_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_SPI_2', 'req': 36069131,
                    'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2L_BELT_S2B = {'dtc': '0x92 0x42 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_SHORT_PLUS_3', 'req': 36069090,
                   'text': ('DCS Sensor 3 short to battery '
                            '(FLTMONR_DCS_E_SECOND_ROW_LEFT_BUCKLE_SWITCH_LEAK_TO_PLUS)')}
FM_R2L_BELT_XCONN = {'dtc': '0x92 0x57 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_CROSS_CONNECT_3', 'req': 36068979,
                     'text': ('DCS Sensor 3 cross connected '
                              '(FLTMONR_DCS_E_SECOND_ROW_LEFT_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_R2L_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_INTERNAL_3', 'req': 36069110,
                    'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2L_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_SPI_3', 'req': 36069132,
                   'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2M_BELT_S2B = {'dtc': '0x92 0x44 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_SHORT_PLUS_4', 'req': 36069091,
                   'text': ('DCS Sensor 4 short to battery '
                            '(FLTMONR_DCS_E_SECOND_ROW_MIDDLE_BUCKLE_SWITCH_LEAK_TO_PLUS)')}
FM_R2M_BELT_XCONN = {'dtc': '0x92 0x56 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_CROSS_CONNECT_4', 'req': 36068980,
                     'text': ('DCS Sensor 4 cross connected '
                              '(FLTMONR_DCS_E_SECOND_ROW_MIDDLE_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_R2M_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_INTERNAL_4', 'req': 36069111,
                    'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2M_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_SPI_4', 'req': 36069133,
                   'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DRV_STPS1_S2B = {'dtc': '0x98 0xF9 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                    'monitor': 'DCS_F_SHORT_PLUS_5', 'req': 36069092,
                    'text': 'DCS Sensor 5 short to battery (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_LEAK_TO_PLUS)'}
FM_DRV_STPS1_S2G = {'dtc': '0x98 0xF9 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                    'monitor': 'DCS_F_SHORT_GND_5', 'req': 36069077,
                    'text': 'DCS Sensor 5 short to ground (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_LEAK_TO_GND)'}
FM_DRV_STPS1_OPEN = {'dtc': '0x98 0xF9 0x13', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                     'monitor': 'DCS_F_OPEN_5', 'req': 36069062,
                     'text': 'DCS Sensor 5 open circuit (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_OPEN)'}
FM_DRV_STPS1_XCONN = {'dtc': '0x98 0xF9 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                      'monitor': 'DCS_F_CROSS_CONNECT_5', 'req': 36068981,
                      'text': 'DCS Sensor 5 cross connected (FLTMONR_DCS_E_DRIVER_STPS1_SWITCH_CROSS_CONNECTED)'}
FM_DRV_STPS1_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                      'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                           'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_5', 'req': 36073729,
                           'text': ('DCS Sensor 5 wrong configuration '
                                    '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
FM_DRV_STPS1_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                     'monitor': 'DCS_F_INTERNAL_5', 'req': 36069112,
                     'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DRV_STPS1_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_SPI_5', 'req': 36069134,
                    'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DRV_STPS2_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                      'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                           'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_6', 'req': 36073730,
                           'text': ('DCS Sensor 6 wrong configuration '
                                    '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
FM_DRV_STPS2_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                     'monitor': 'DCS_F_INTERNAL_6', 'req': 36069113,
                     'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DRV_STPS2_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_SPI_6', 'req': 36069135,
                    'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PSGR_STPS1_S2B = {'dtc': '0x98 0xFB 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                     'monitor': 'DCS_F_SHORT_PLUS_7', 'req': 36069093,
                     'text': 'DCS Sensor 7 short to battery (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_LEAK_TO_PLUS)'}
FM_PSGR_STPS1_S2G = {'dtc': '0x98 0xFB 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                     'monitor': 'DCS_F_SHORT_GND_7', 'req': 36069078,
                     'text': 'DCS Sensor 7 short to ground (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_LEAK_TO_GND)'}
FM_PSGR_STPS1_OPEN = {'dtc': '0x98 0xFB 0x13', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                      'monitor': 'DCS_F_OPEN_7', 'req': 36069063,
                      'text': 'DCS Sensor 7 open circuit (FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_OPEN)'}
FM_PSGR_STPS1_XCONN = {'dtc': '0x98 0xFB 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                       'monitor': 'DCS_F_CROSS_CONNECT_7', 'req': 36068982,
                       'text': ('DCS Sensor 7 cross connected '
                                '(FLTMONR_DCS_E_PASSENGER_STPS1_SWITCH_CROSS_CONNECTED)')}
FM_PSGR_STPS1_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                       'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                            'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_7', 'req': 36073731,
                            'text': ('DCS Sensor 7 wrong configuration '
                                     '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
FM_PSGR_STPS1_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                      'monitor': 'DCS_F_INTERNAL_7', 'req': 36069114,
                      'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PSGR_STPS1_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                     'monitor': 'DCS_F_SPI_7', 'req': 36069136,
                     'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PSGR_STPS2_UNEXPECTED = {'dtc': '0x92 0x61 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': ('maturation: Current Value: 3200 ms Practical Value: Within PDC( 2 sec); '
                                       'dematuration: Current Value: 3200 ms Practical Value: Within PDC( 2 sec)'),
                            'latched': False, 'monitor': 'DCS_F_UNEXPECTED_LOAD_8', 'req': 36073732,
                            'text': ('DCS Sensor 8 wrong configuration '
                                     '(FLTMONR_UNEXPECTED_LOAD_CONNECTED_TO_UNCONFIGURED_DCS)')}
FM_PSGR_STPS2_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                      'monitor': 'DCS_F_INTERNAL_8', 'req': 36069115,
                      'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_PSGR_STPS2_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                     'monitor': 'DCS_F_SPI_8', 'req': 36069137,
                     'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2R_ODS_S2B = {'dtc': '0x98 0xF5 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_9', 'req': 36069094,
                  'text': 'DCS Sensor 9 short to battery (FLTMONR_DCS_E_SECOND_ROW_RIGHT_ODS_SWITCH_LEAK_TO_PLUS)'}
FM_R2R_ODS_XCONN = {'dtc': '0x98 0xF5 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_9', 'req': 36068983,
                    'text': ('DCS Sensor 9 cross connected '
                             '(FLTMONR_DCS_E_SECOND_ROW_RIGHT_ODS_SWITCH_CROSS_CONNECT)')}
FM_R2R_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_9', 'req': 36069116,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2R_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_9', 'req': 36069138,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2L_ODS_S2B = {'dtc': '0x98 0xF4 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_10', 'req': 36069095,
                  'text': 'DCS Sensor 10 short to battery (FLTMONR_DCS_E_SECOND_ROW_LEFT_ODS_SWITCH_LEAK_TO_PLUS)'}
FM_R2L_ODS_XCONN = {'dtc': '0x98 0xF4 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_10', 'req': 36068984,
                    'text': ('DCS Sensor 10 cross connected '
                             '(FLTMONR_DCS_E_SECOND_ROW_LEFT_ODS_SWITCH_CROSS_CONNECT)')}
FM_R2L_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_10', 'req': 36069117,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2L_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_10', 'req': 36069139,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2M_ODS_S2B = {'dtc': '0x98 0xF6 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_11', 'req': 36069096,
                  'text': ('DCS Sensor 11 short to battery '
                           '(FLTMONR_DCS_E_SECOND_ROW_MIDDLE_ODS_SWITCH_LEAK_TO_PLUS)')}
FM_R2M_ODS_XCONN = {'dtc': '0x98 0xF6 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_11', 'req': 36068985,
                    'text': ('DCS Sensor 11 cross connected '
                             '(FLTMONR_DCS_E_SECOND_ROW_MIDDLE_ODS_SWITCH_CROSS_CONNECT)')}
FM_R2M_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_11', 'req': 36069118,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R2M_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_11', 'req': 36069140,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3R_BELT_S2B = {'dtc': '0x92 0x46 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_SHORT_PLUS_12', 'req': 36069097,
                   'text': ('DCS Sensor 12 short to battery '
                            '(FLTMONR_DCS_E_THIRD_ROW_RIGHT_BUCKLE_SWITCH_LEAK_TO_PLUS)')}
FM_R3R_BELT_XCONN = {'dtc': '0x92 0x58 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_CROSS_CONNECT_12', 'req': 36068986,
                     'text': ('DCS Sensor 12 cross connected '
                              '(FLTMONR_DCS_E_THIRD_ROW_RIGHT_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_R3R_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_INTERNAL_12', 'req': 36069119,
                    'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3R_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_SPI_12', 'req': 36069141,
                   'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3L_BELT_S2B = {'dtc': '0x92 0x45 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                   'monitor': 'DCS_F_SHORT_PLUS_13', 'req': 36069098,
                   'text': ('DCS Sensor 13 short to battery '
                            '(FLTMONR_DCS_E_THIRD_ROW_LEFT_BUCKLE_SWITCH_LEAK_TO_PLUS)')}
FM_R3L_BELT_XCONN = {'dtc': '0x92 0x59 0x2B', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_CROSS_CONNECT_13', 'req': 36068987,
                     'text': ('DCS Sensor 13 cross connected '
                              '(FLTMONR_DCS_E_THIRD_ROW_LEFT_BUCKLE_SWITCH_CROSS_CONNECT)')}
FM_R3L_BELT_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                    'monitor': 'DCS_F_INTERNAL_13', 'req': 36069120,
                    'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3L_BELT_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_SPI_13', 'req': 36069142,
                   'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3R_ODS_S2B = {'dtc': '0x98 0xF8 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_14', 'req': 36069099,
                  'text': 'DCS Sensor 14 short to battery (FLTMONR_DCS_E_THIRD_ROW_RIGHT_ODS_SWITCH_LEAK_TO_PLUS)'}
FM_R3R_ODS_XCONN = {'dtc': '0x98 0xF8 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_14', 'req': 36068988,
                    'text': ('DCS Sensor 14 cross connected '
                             '(FLTMONR_DCS_E_THIRD_ROW_RIGHT_ODS_SWITCH_CROSS_CONNECT)')}
FM_R3R_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_14', 'req': 36069121,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3R_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_14', 'req': 36069143,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3L_ODS_S2B = {'dtc': '0x98 0xF7 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                  'monitor': 'DCS_F_SHORT_PLUS_15', 'req': 36069100,
                  'text': 'DCS Sensor 15 short to battery (FLTMONR_DCS_E_THIRD_ROW_LEFT_ODS_SWITCH_LEAK_TO_PLUS)'}
FM_R3L_ODS_XCONN = {'dtc': '0x98 0xF7 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                    'monitor': 'DCS_F_CROSS_CONNECT_15', 'req': 36068989,
                    'text': 'DCS Sensor 15 cross connected (FLTMONR_DCS_E_THIRD_ROW_LEFT_ODS_SWITCH_CROSS_CONNECT)'}
FM_R3L_ODS_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                   'monitor': 'DCS_F_INTERNAL_15', 'req': 36069122,
                   'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_R3L_ODS_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                  'monitor': 'DCS_F_SPI_15', 'req': 36069144,
                  'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DCS16_S2B = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                'monitor': 'DCS_F_SHORT_PLUS_16', 'req': 36069101,
                'text': 'DCS Sensor 16 short to battery (FLTMONR_E_ECU_INTERNAL)'}
FM_DCS16_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                  'monitor': 'DCS_F_CROSS_CONNECT_16', 'req': 36068990,
                  'text': 'DCS Sensor 16 cross connected (FLTMONR_E_ECU_INTERNAL)'}
FM_DCS16_ASIC = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                 'monitor': 'DCS_F_INTERNAL_16', 'req': 36069123,
                 'text': 'DCS Sensor ASIC failure (FLTMONR_E_ECU_INTERNAL)'}
FM_DCS16_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Platform: 0.2; dematuration: Platform: 0.2', 'latched': True,
                'monitor': 'DCS_F_SPI_16', 'req': 36069145,
                'text': 'DCS Sensors SPI failure (FLTMONR_E_ECU_INTERNAL)'}

DCS_FAULTS = {
    'R2R_BELT_S2B': FM_R2R_BELT_S2B,
    'R2R_BELT_XCONN': FM_R2R_BELT_XCONN,
    'R2R_BELT_ASIC': FM_R2R_BELT_ASIC,
    'R2R_BELT_SPI': FM_R2R_BELT_SPI,
    'DRV_BELT_S2B': FM_DRV_BELT_S2B,
    'DRV_BELT_XCONN': FM_DRV_BELT_XCONN,
    'DRV_BELT_ASIC': FM_DRV_BELT_ASIC,
    'DRV_BELT_SPI': FM_DRV_BELT_SPI,
    'PSGR_BELT_S2B': FM_PSGR_BELT_S2B,
    'PSGR_BELT_XCONN': FM_PSGR_BELT_XCONN,
    'PSGR_BELT_ASIC': FM_PSGR_BELT_ASIC,
    'PSGR_BELT_SPI': FM_PSGR_BELT_SPI,
    'R2L_BELT_S2B': FM_R2L_BELT_S2B,
    'R2L_BELT_XCONN': FM_R2L_BELT_XCONN,
    'R2L_BELT_ASIC': FM_R2L_BELT_ASIC,
    'R2L_BELT_SPI': FM_R2L_BELT_SPI,
    'R2M_BELT_S2B': FM_R2M_BELT_S2B,
    'R2M_BELT_XCONN': FM_R2M_BELT_XCONN,
    'R2M_BELT_ASIC': FM_R2M_BELT_ASIC,
    'R2M_BELT_SPI': FM_R2M_BELT_SPI,
    'DRV_STPS1_S2B': FM_DRV_STPS1_S2B,
    'DRV_STPS1_S2G': FM_DRV_STPS1_S2G,
    'DRV_STPS1_OPEN': FM_DRV_STPS1_OPEN,
    'DRV_STPS1_XCONN': FM_DRV_STPS1_XCONN,
    'DRV_STPS1_UNEXPECTED': FM_DRV_STPS1_UNEXPECTED,
    'DRV_STPS1_ASIC': FM_DRV_STPS1_ASIC,
    'DRV_STPS1_SPI': FM_DRV_STPS1_SPI,
    'DRV_STPS2_UNEXPECTED': FM_DRV_STPS2_UNEXPECTED,
    'DRV_STPS2_ASIC': FM_DRV_STPS2_ASIC,
    'DRV_STPS2_SPI': FM_DRV_STPS2_SPI,
    'PSGR_STPS1_S2B': FM_PSGR_STPS1_S2B,
    'PSGR_STPS1_S2G': FM_PSGR_STPS1_S2G,
    'PSGR_STPS1_OPEN': FM_PSGR_STPS1_OPEN,
    'PSGR_STPS1_XCONN': FM_PSGR_STPS1_XCONN,
    'PSGR_STPS1_UNEXPECTED': FM_PSGR_STPS1_UNEXPECTED,
    'PSGR_STPS1_ASIC': FM_PSGR_STPS1_ASIC,
    'PSGR_STPS1_SPI': FM_PSGR_STPS1_SPI,
    'PSGR_STPS2_UNEXPECTED': FM_PSGR_STPS2_UNEXPECTED,
    'PSGR_STPS2_ASIC': FM_PSGR_STPS2_ASIC,
    'PSGR_STPS2_SPI': FM_PSGR_STPS2_SPI,
    'R2R_ODS_S2B': FM_R2R_ODS_S2B,
    'R2R_ODS_XCONN': FM_R2R_ODS_XCONN,
    'R2R_ODS_ASIC': FM_R2R_ODS_ASIC,
    'R2R_ODS_SPI': FM_R2R_ODS_SPI,
    'R2L_ODS_S2B': FM_R2L_ODS_S2B,
    'R2L_ODS_XCONN': FM_R2L_ODS_XCONN,
    'R2L_ODS_ASIC': FM_R2L_ODS_ASIC,
    'R2L_ODS_SPI': FM_R2L_ODS_SPI,
    'R2M_ODS_S2B': FM_R2M_ODS_S2B,
    'R2M_ODS_XCONN': FM_R2M_ODS_XCONN,
    'R2M_ODS_ASIC': FM_R2M_ODS_ASIC,
    'R2M_ODS_SPI': FM_R2M_ODS_SPI,
    'R3R_BELT_S2B': FM_R3R_BELT_S2B,
    'R3R_BELT_XCONN': FM_R3R_BELT_XCONN,
    'R3R_BELT_ASIC': FM_R3R_BELT_ASIC,
    'R3R_BELT_SPI': FM_R3R_BELT_SPI,
    'R3L_BELT_S2B': FM_R3L_BELT_S2B,
    'R3L_BELT_XCONN': FM_R3L_BELT_XCONN,
    'R3L_BELT_ASIC': FM_R3L_BELT_ASIC,
    'R3L_BELT_SPI': FM_R3L_BELT_SPI,
    'R3R_ODS_S2B': FM_R3R_ODS_S2B,
    'R3R_ODS_XCONN': FM_R3R_ODS_XCONN,
    'R3R_ODS_ASIC': FM_R3R_ODS_ASIC,
    'R3R_ODS_SPI': FM_R3R_ODS_SPI,
    'R3L_ODS_S2B': FM_R3L_ODS_S2B,
    'R3L_ODS_XCONN': FM_R3L_ODS_XCONN,
    'R3L_ODS_ASIC': FM_R3L_ODS_ASIC,
    'R3L_ODS_SPI': FM_R3L_ODS_SPI,
    'DCS16_S2B': FM_DCS16_S2B,
    'DCS16_XCONN': FM_DCS16_XCONN,
    'DCS16_ASIC': FM_DCS16_ASIC,
    'DCS16_SPI': FM_DCS16_SPI,
}


# ====================================================================================================
# Remote sensing units (217)
# <satellite>_S<slot>_<fault>, the satellite named as rsu_config names its side and pillar (right-
# hand drive: driver = right), S1/S2/S3 its sensor slot on the ASIC channel; RSU_CHANNEL<n>_* are
# per ASIC channel; OPS_RSU_* are algorithm checks of RSU line <n>.
# ====================================================================================================
FM_A_PILLAR_LEFT_S1_OPEN = {'dtc': '0x92 0x36 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_0', 'req': 36069932,
                            'text': ('RSU Open Circuit on Sensor 0 SB3_M CH0 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_OPEN)')}
FM_A_PILLAR_LEFT_S1_S2G = {'dtc': '0x92 0x36 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_0', 'req': 36069980,
                           'text': ('RSU Short to Ground Sensor 0 SB3_M CH0 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_GND)')}
FM_A_PILLAR_LEFT_S1_S2B = {'dtc': '0x92 0x36 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_0', 'req': 36070028,
                           'text': ('RSU Short to Battery Sensor 0 SB3_M CH0 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_BAT)')}
FM_A_PILLAR_LEFT_S1_COMM = {'dtc': '0x92 0x36 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_0', 'req': 36069788,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH0 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_COMMUNICATION_ERROR)')}
FM_A_PILLAR_LEFT_S1_INTERNAL = {'dtc': '0x92 0x36 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_0', 'req': 36069884,
                                'text': ('RSU Internal error Sensor 0 SB3_M CH0 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_INTERNAL_ERROR)')}
FM_A_PILLAR_LEFT_S1_CONFIG = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_0', 'req': 36070076,
                              'text': ('RSU Configuration error Sensor 0 SB3_M CH0 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_LEFT_S1_UNEXPECTED = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_0', 'req': 36069836,
                                  'text': ('RSU Configuration error Sensor 0 SB3_M CH0 S1 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_LEFT_S2_OPEN = {'dtc': '0x92 0x36 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_1', 'req': 36069933,
                            'text': ('RSU Open Circuit on Sensor 1 SB3_M CH0 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_OPEN)')}
FM_A_PILLAR_LEFT_S2_S2G = {'dtc': '0x92 0x36 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_1', 'req': 36069981,
                           'text': ('RSU Short to Ground Sensor 1 SB3_M CH0 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_GND)')}
FM_A_PILLAR_LEFT_S2_S2B = {'dtc': '0x92 0x36 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_1', 'req': 36070029,
                           'text': ('RSU Short to Battery Sensor 1 SB3_M CH0 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_SHORT_TO_BAT)')}
FM_A_PILLAR_LEFT_S2_COMM = {'dtc': '0x92 0x36 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_1', 'req': 36069789,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH0 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_COMMUNICATION_ERROR)')}
FM_A_PILLAR_LEFT_S2_INTERNAL = {'dtc': '0x92 0x36 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_1', 'req': 36069885,
                                'text': ('RSU Internal error Sensor 1 SB3_M CH0 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_INTERNAL_ERROR)')}
FM_A_PILLAR_LEFT_S2_CONFIG = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_1', 'req': 36070077,
                              'text': ('RSU Configuration error Sensor 1 SB3_M CH0 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_LEFT_S2_UNEXPECTED = {'dtc': '0x92 0x36 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_1', 'req': 36069837,
                                  'text': ('RSU Configuration error Sensor 1 SB3_M CH0 S2 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_RIGHT_S1_OPEN = {'dtc': '0x92 0x37 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_4', 'req': 36069936,
                             'text': ('RSU Open Circuit on Sensor 4 SB3_M CH1 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_OPEN)')}
FM_A_PILLAR_RIGHT_S1_S2G = {'dtc': '0x92 0x37 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_4', 'req': 36069984,
                            'text': ('RSU Short to Ground Sensor 4 SB3_M CH1 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_GND)')}
FM_A_PILLAR_RIGHT_S1_S2B = {'dtc': '0x92 0x37 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_4', 'req': 36070032,
                            'text': ('RSU Short to Battery Sensor 4 SB3_M CH1 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_BAT)')}
FM_A_PILLAR_RIGHT_S1_COMM = {'dtc': '0x92 0x37 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_4', 'req': 36069792,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH1 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_COMMUNICATION_ERROR)')}
FM_A_PILLAR_RIGHT_S1_INTERNAL = {'dtc': '0x92 0x37 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_4', 'req': 36069888,
                                 'text': ('RSU Internal error Sensor 4 SB3_M CH1 S1 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_INTERNAL_ERROR)')}
FM_A_PILLAR_RIGHT_S1_CONFIG = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_4', 'req': 36070080,
                               'text': ('RSU Configuration error Sensor 4 SB3_M CH1 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_RIGHT_S1_UNEXPECTED = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_4', 'req': 36069840,
                                   'text': ('RSU Configuration error Sensor 4 SB3_M CH1 S1 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_RIGHT_S2_OPEN = {'dtc': '0x92 0x37 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_5', 'req': 36069937,
                             'text': ('RSU Open Circuit on Sensor 5 SB3_M CH1 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_OPEN)')}
FM_A_PILLAR_RIGHT_S2_S2G = {'dtc': '0x92 0x37 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_5', 'req': 36069985,
                            'text': ('RSU Short to Ground Sensor 5 SB3_M CH1 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_GND)')}
FM_A_PILLAR_RIGHT_S2_S2B = {'dtc': '0x92 0x37 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_5', 'req': 36070033,
                            'text': ('RSU Short to Battery Sensor 5 SB3_M CH1 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_SHORT_TO_BAT)')}
FM_A_PILLAR_RIGHT_S2_COMM = {'dtc': '0x92 0x37 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_5', 'req': 36069793,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH1 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_COMMUNICATION_ERROR)')}
FM_A_PILLAR_RIGHT_S2_INTERNAL = {'dtc': '0x92 0x37 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_5', 'req': 36069889,
                                 'text': ('RSU Internal error Sensor 5 SB3_M CH1 S2 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_INTERNAL_ERROR)')}
FM_A_PILLAR_RIGHT_S2_CONFIG = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_5', 'req': 36070081,
                               'text': ('RSU Configuration error Sensor 5 SB3_M CH1 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_A_PILLAR_RIGHT_S2_UNEXPECTED = {'dtc': '0x92 0x37 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_5', 'req': 36069841,
                                   'text': ('RSU Configuration error Sensor 5 SB3_M CH1 S2 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_APIL_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_LEFT_S1_OPEN = {'dtc': '0x92 0x0A 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_8', 'req': 36069940,
                            'text': ('RSU Open Circuit on Sensor 8 SB3_M CH2 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_OPEN)')}
FM_B_PILLAR_LEFT_S1_S2G = {'dtc': '0x92 0x0A 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_8', 'req': 36069988,
                           'text': ('RSU Short to Ground Sensor 8 SB3_M CH2 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_GND)')}
FM_B_PILLAR_LEFT_S1_S2B = {'dtc': '0x92 0x0A 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_8', 'req': 36070036,
                           'text': ('RSU Short to Battery Sensor 8 SB3_M CH2 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_BAT)')}
FM_B_PILLAR_LEFT_S1_COMM = {'dtc': '0x92 0x0A 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_8', 'req': 36069796,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH2 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_COMMUNICATION_ERROR)')}
FM_B_PILLAR_LEFT_S1_INTERNAL = {'dtc': '0x92 0x0A 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_8', 'req': 36069892,
                                'text': ('RSU Internal error Sensor 8 SB3_M CH2 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_INTERNAL_ERROR)')}
FM_B_PILLAR_LEFT_S1_CONFIG = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_8', 'req': 36070084,
                              'text': ('RSU Configuration error Sensor 8 SB3_M CH2 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_LEFT_S1_UNEXPECTED = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_8', 'req': 36069844,
                                  'text': ('RSU Configuration error Sensor 8 SB3_M CH2 S1 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_LEFT_S2_OPEN = {'dtc': '0x92 0x0A 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_9', 'req': 36069941,
                            'text': ('RSU Open Circuit on Sensor 9 SB3_M CH2 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_OPEN)')}
FM_B_PILLAR_LEFT_S2_S2G = {'dtc': '0x92 0x0A 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_9', 'req': 36069989,
                           'text': ('RSU Short to Ground Sensor 9 SB3_M CH2 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_GND)')}
FM_B_PILLAR_LEFT_S2_S2B = {'dtc': '0x92 0x0A 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_9', 'req': 36070037,
                           'text': ('RSU Short to Battery Sensor 9 SB3_M CH2 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_SHORT_TO_BAT)')}
FM_B_PILLAR_LEFT_S2_COMM = {'dtc': '0x92 0x0A 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_9', 'req': 36069797,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH2 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_COMMUNICATION_ERROR)')}
FM_B_PILLAR_LEFT_S2_INTERNAL = {'dtc': '0x92 0x0A 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_9', 'req': 36069893,
                                'text': ('RSU Internal error Sensor 9 SB3_M CH2 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_INTERNAL_ERROR)')}
FM_B_PILLAR_LEFT_S2_CONFIG = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_9', 'req': 36070085,
                              'text': ('RSU Configuration error Sensor 9 SB3_M CH2 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_LEFT_S2_UNEXPECTED = {'dtc': '0x92 0x0A 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_9', 'req': 36069845,
                                  'text': ('RSU Configuration error Sensor 9 SB3_M CH2 S2 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_RIGHT_S1_OPEN = {'dtc': '0x92 0x0B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_12', 'req': 36069944,
                             'text': ('RSU Open Circuit on Sensor 12 SB3_M CH3 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_OPEN)')}
FM_B_PILLAR_RIGHT_S1_S2G = {'dtc': '0x92 0x0B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_12', 'req': 36069992,
                            'text': ('RSU Short to Ground Sensor 12 SB3_M CH3 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_GND)')}
FM_B_PILLAR_RIGHT_S1_S2B = {'dtc': '0x92 0x0B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_12', 'req': 36070040,
                            'text': ('RSU Short to Battery Sensor 12 SB3_M CH3 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_BAT)')}
FM_B_PILLAR_RIGHT_S1_COMM = {'dtc': '0x92 0x0B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_12', 'req': 36069800,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH3 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_COMMUNICATION_ERROR)')}
FM_B_PILLAR_RIGHT_S1_INTERNAL = {'dtc': '0x92 0x0B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_12', 'req': 36069896,
                                 'text': ('RSU Internal error Sensor 12 SB3_M CH3 S1 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_INTERNAL_ERROR)')}
FM_B_PILLAR_RIGHT_S1_CONFIG = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_12', 'req': 36070088,
                               'text': ('RSU Configuration error Sensor 12 SB3_M CH3 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_RIGHT_S1_UNEXPECTED = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_12', 'req': 36069848,
                                   'text': ('RSU Configuration error Sensor 12 SB3_M CH3 S1 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_RIGHT_S2_OPEN = {'dtc': '0x92 0x0B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_13', 'req': 36069945,
                             'text': ('RSU Open Circuit on Sensor 13 SB3_M CH3 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_OPEN)')}
FM_B_PILLAR_RIGHT_S2_S2G = {'dtc': '0x92 0x0B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_13', 'req': 36069993,
                            'text': ('RSU Short to Ground Sensor 13 SB3_M CH3 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_GND)')}
FM_B_PILLAR_RIGHT_S2_S2B = {'dtc': '0x92 0x0B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_13', 'req': 36070041,
                            'text': ('RSU Short to Battery Sensor 13 SB3_M CH3 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_SHORT_TO_BAT)')}
FM_B_PILLAR_RIGHT_S2_COMM = {'dtc': '0x92 0x0B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_13', 'req': 36069801,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH3 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_COMMUNICATION_ERROR)')}
FM_B_PILLAR_RIGHT_S2_INTERNAL = {'dtc': '0x92 0x0B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_13', 'req': 36069897,
                                 'text': ('RSU Internal error Sensor 13 SB3_M CH3 S2 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_INTERNAL_ERROR)')}
FM_B_PILLAR_RIGHT_S2_CONFIG = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_13', 'req': 36070089,
                               'text': ('RSU Configuration error Sensor 13 SB3_M CH3 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
FM_B_PILLAR_RIGHT_S2_UNEXPECTED = {'dtc': '0x92 0x0B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_13', 'req': 36069849,
                                   'text': ('RSU Configuration error Sensor 13 SB3_M CH3 S2 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_SRSU_CONFIGURATION_ERROR)')}
FM_FRONT_LEFT_S1_OPEN = {'dtc': '0x80 0x90 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_16', 'req': 36069948,
                         'text': ('RSU Open Circuit on Sensor 16 SB3_M CH4 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_OPEN)')}
FM_FRONT_LEFT_S1_S2G = {'dtc': '0x80 0x90 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_16', 'req': 36069996,
                        'text': ('RSU Short to Ground Sensor 16 SB3_M CH4 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_GND)')}
FM_FRONT_LEFT_S1_S2B = {'dtc': '0x80 0x90 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_16', 'req': 36070044,
                        'text': ('RSU Short to Battery Sensor 16 SB3_M CH4 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_BAT)')}
FM_FRONT_LEFT_S1_COMM = {'dtc': '0x80 0x90 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_16', 'req': 36069804,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH4 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_COMMUNICATION_ERROR)')}
FM_FRONT_LEFT_S1_INTERNAL = {'dtc': '0x80 0x90 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_16', 'req': 36069900,
                             'text': ('RSU Internal error Sensor 16 SB3_M CH4 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_INTERNAL_ERROR)')}
FM_FRONT_LEFT_S1_CONFIG = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_16', 'req': 36070092,
                           'text': ('RSU Configuration error Sensor 16 SB3_M CH4 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_LEFT_S1_UNEXPECTED = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_16', 'req': 36069852,
                               'text': ('RSU Configuration error Sensor 16 SB3_M CH4 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_LEFT_S2_OPEN = {'dtc': '0x80 0x90 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_OPEN_17', 'req': 36069949,
                         'text': ('RSU Open Circuit on Sensor 17 SB3_M CH4 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_OPEN)')}
FM_FRONT_LEFT_S2_S2G = {'dtc': '0x80 0x90 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_GND_17', 'req': 36069997,
                        'text': ('RSU Short to Ground Sensor 17 SB3_M CH4 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_GND)')}
FM_FRONT_LEFT_S2_S2B = {'dtc': '0x80 0x90 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_SHORT_BAT_17', 'req': 36070045,
                        'text': ('RSU Short to Battery Sensor 17 SB3_M CH4 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_SHORT_TO_BAT)')}
FM_FRONT_LEFT_S2_COMM = {'dtc': '0x80 0x90 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_COMM_17', 'req': 36069805,
                         'text': ('Satellite Manchester Data Communication Fault SB3_M CH4 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_COMMUNICATION_ERROR)')}
FM_FRONT_LEFT_S2_INTERNAL = {'dtc': '0x80 0x90 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                        'Cycle'),
                             'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_17', 'req': 36069901,
                             'text': ('RSU Internal error Sensor 17 SB3_M CH4 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_INTERNAL_ERROR)')}
FM_FRONT_LEFT_S2_CONFIG = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_CFG_17', 'req': 36070093,
                           'text': ('RSU Configuration error Sensor 17 SB3_M CH4 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_LEFT_S2_UNEXPECTED = {'dtc': '0x80 0x90 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                          'Value: Within PDC(2 sec)'),
                               'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_17', 'req': 36069853,
                               'text': ('RSU Configuration error Sensor 17 SB3_M CH4 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_RIGHT_S1_OPEN = {'dtc': '0x80 0x95 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_20', 'req': 36069952,
                          'text': ('RSU Open Circuit on Sensor 20 SB3_M CH5 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_OPEN)')}
FM_FRONT_RIGHT_S1_S2G = {'dtc': '0x80 0x95 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_20', 'req': 36070000,
                         'text': ('RSU Short to Ground Sensor 20 SB3_M CH5 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_GND)')}
FM_FRONT_RIGHT_S1_S2B = {'dtc': '0x80 0x95 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_20', 'req': 36070048,
                         'text': ('RSU Short to Battery Sensor 20 SB3_M CH5 S1 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_BAT)')}
FM_FRONT_RIGHT_S1_COMM = {'dtc': '0x80 0x95 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_20', 'req': 36069808,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH5 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_COMMUNICATION_ERROR)')}
FM_FRONT_RIGHT_S1_INTERNAL = {'dtc': '0x80 0x95 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_20', 'req': 36069904,
                              'text': ('RSU Internal error Sensor 20 SB3_M CH5 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_INTERNAL_ERROR)')}
FM_FRONT_RIGHT_S1_CONFIG = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_20', 'req': 36070096,
                            'text': ('RSU Configuration error Sensor 20 SB3_M CH5 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_RIGHT_S1_UNEXPECTED = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_20', 'req': 36069856,
                                'text': ('RSU Configuration error Sensor 20 SB3_M CH5 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_RIGHT_S2_OPEN = {'dtc': '0x80 0x95 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                          'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_OPEN_21', 'req': 36069953,
                          'text': ('RSU Open Circuit on Sensor 21 SB3_M CH5 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_OPEN)')}
FM_FRONT_RIGHT_S2_S2G = {'dtc': '0x80 0x95 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_GND_21', 'req': 36070001,
                         'text': ('RSU Short to Ground Sensor 21 SB3_M CH5 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_GND)')}
FM_FRONT_RIGHT_S2_S2B = {'dtc': '0x80 0x95 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                         'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                         'monitor': 'RSU_F_SAT_SHORT_BAT_21', 'req': 36070049,
                         'text': ('RSU Short to Battery Sensor 21 SB3_M CH5 S2 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_SHORT_TO_BAT)')}
FM_FRONT_RIGHT_S2_COMM = {'dtc': '0x80 0x95 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_COMM_21', 'req': 36069809,
                          'text': ('Satellite Manchester Data Communication Fault SB3_M CH5 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_COMMUNICATION_ERROR)')}
FM_FRONT_RIGHT_S2_INTERNAL = {'dtc': '0x80 0x95 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                         'Cycle'),
                              'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_21', 'req': 36069905,
                              'text': ('RSU Internal error Sensor 21 SB3_M CH5 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_INTERNAL_ERROR)')}
FM_FRONT_RIGHT_S2_CONFIG = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_CFG_21', 'req': 36070097,
                            'text': ('RSU Configuration error Sensor 21 SB3_M CH5 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FM_FRONT_RIGHT_S2_UNEXPECTED = {'dtc': '0x80 0x95 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                           'Practical Value: Within PDC(2 sec)'),
                                'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_21', 'req': 36069857,
                                'text': ('RSU Configuration error Sensor 21 SB3_M CH5 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_FRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_LEFT_S1_OPEN = {'dtc': '0x92 0x1B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_24', 'req': 36069956,
                            'text': ('RSU Open Circuit on Sensor 24 SB3_M CH6 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_OPEN)')}
FM_C_PILLAR_LEFT_S1_S2G = {'dtc': '0x92 0x1B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_24', 'req': 36070004,
                           'text': ('RSU Short to Ground Sensor 24 SB3_M CH6 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_GND)')}
FM_C_PILLAR_LEFT_S1_S2B = {'dtc': '0x92 0x1B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_24', 'req': 36070052,
                           'text': ('RSU Short to Battery Sensor 24 SB3_M CH6 S1 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_BAT)')}
FM_C_PILLAR_LEFT_S1_COMM = {'dtc': '0x92 0x1B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_24', 'req': 36069812,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH6 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_COMMUNICATION_ERROR)')}
FM_C_PILLAR_LEFT_S1_INTERNAL = {'dtc': '0x92 0x1B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_24', 'req': 36069908,
                                'text': ('RSU Internal error Sensor 24 SB3_M CH6 S1 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_INTERNAL_ERROR)')}
FM_C_PILLAR_LEFT_S1_CONFIG = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_24', 'req': 36070100,
                              'text': ('RSU Configuration error Sensor 24 SB3_M CH6 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_LEFT_S1_UNEXPECTED = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_24', 'req': 36069860,
                                  'text': ('RSU Configuration error Sensor 24 SB3_M CH6 S1 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_LEFT_S2_OPEN = {'dtc': '0x92 0x1B 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_25', 'req': 36069957,
                            'text': ('RSU Open Circuit on Sensor 25 SB3_M CH6 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_OPEN)')}
FM_C_PILLAR_LEFT_S2_S2G = {'dtc': '0x92 0x1B 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_25', 'req': 36070005,
                           'text': ('RSU Short to Ground Sensor 25 SB3_M CH6 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_GND)')}
FM_C_PILLAR_LEFT_S2_S2B = {'dtc': '0x92 0x1B 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_25', 'req': 36070053,
                           'text': ('RSU Short to Battery Sensor 25 SB3_M CH6 S2 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_SHORT_TO_BAT)')}
FM_C_PILLAR_LEFT_S2_COMM = {'dtc': '0x92 0x1B 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_25', 'req': 36069813,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH6 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_COMMUNICATION_ERROR)')}
FM_C_PILLAR_LEFT_S2_INTERNAL = {'dtc': '0x92 0x1B 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_25', 'req': 36069909,
                                'text': ('RSU Internal error Sensor 25 SB3_M CH6 S2 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_INTERNAL_ERROR)')}
FM_C_PILLAR_LEFT_S2_CONFIG = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_25', 'req': 36070101,
                              'text': ('RSU Configuration error Sensor 25 SB3_M CH6 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_LEFT_S2_UNEXPECTED = {'dtc': '0x92 0x1B 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_25', 'req': 36069861,
                                  'text': ('RSU Configuration error Sensor 25 SB3_M CH6 S2 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_RIGHT_S1_OPEN = {'dtc': '0x92 0x1C 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_28', 'req': 36069960,
                             'text': ('RSU Open Circuit on Sensor 28 SB3_M CH7 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_OPEN)')}
FM_C_PILLAR_RIGHT_S1_S2G = {'dtc': '0x92 0x1C 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_28', 'req': 36070008,
                            'text': ('RSU Short to Ground Sensor 28 SB3_M CH7 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_GND)')}
FM_C_PILLAR_RIGHT_S1_S2B = {'dtc': '0x92 0x1C 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_28', 'req': 36070056,
                            'text': ('RSU Short to Battery Sensor 28 SB3_M CH7 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_BAT)')}
FM_C_PILLAR_RIGHT_S1_COMM = {'dtc': '0x92 0x1C 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_28', 'req': 36069816,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH7 S1 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_COMMUNICATION_ERROR)')}
FM_C_PILLAR_RIGHT_S1_INTERNAL = {'dtc': '0x92 0x1C 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_28', 'req': 36069912,
                                 'text': ('RSU Internal error Sensor 28 SB3_M CH7 S1 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_INTERNAL_ERROR)')}
FM_C_PILLAR_RIGHT_S1_CONFIG = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_28', 'req': 36070104,
                               'text': ('RSU Configuration error Sensor 28 SB3_M CH7 S1 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_RIGHT_S1_UNEXPECTED = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_28', 'req': 36069864,
                                   'text': ('RSU Configuration error Sensor 28 SB3_M CH7 S1 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_RIGHT_S2_OPEN = {'dtc': '0x92 0x1C 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_29', 'req': 36069961,
                             'text': ('RSU Open Circuit on Sensor 29 SB3_M CH7 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_OPEN)')}
FM_C_PILLAR_RIGHT_S2_S2G = {'dtc': '0x92 0x1C 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_29', 'req': 36070009,
                            'text': ('RSU Short to Ground Sensor 29 SB3_M CH7 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_GND)')}
FM_C_PILLAR_RIGHT_S2_S2B = {'dtc': '0x92 0x1C 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_29', 'req': 36070057,
                            'text': ('RSU Short to Battery Sensor 29 SB3_M CH7 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_SHORT_TO_BAT)')}
FM_C_PILLAR_RIGHT_S2_COMM = {'dtc': '0x92 0x1C 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_29', 'req': 36069817,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH7 S2 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_COMMUNICATION_ERROR)')}
FM_C_PILLAR_RIGHT_S2_INTERNAL = {'dtc': '0x92 0x1C 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_29', 'req': 36069913,
                                 'text': ('RSU Internal error Sensor 29 SB3_M CH7 S2 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_INTERNAL_ERROR)')}
FM_C_PILLAR_RIGHT_S2_CONFIG = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_29', 'req': 36070105,
                               'text': ('RSU Configuration error Sensor 29 SB3_M CH7 S2 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_C_PILLAR_RIGHT_S2_UNEXPECTED = {'dtc': '0x92 0x1C 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_29', 'req': 36069865,
                                   'text': ('RSU Configuration error Sensor 29 SB3_M CH7 S2 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_CPIL_SRSU_CONFIGURATION_ERROR)')}
FM_UNDERBODY_S1_OPEN = {'dtc': '0x92 0x52 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_OPEN_32', 'req': 36069964,
                        'text': ('RSU Open Circuit on Sensor 32 EX3_0 CH0 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_OPEN)')}
FM_UNDERBODY_S1_S2G = {'dtc': '0x92 0x52 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                       'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_SHORT_GND_32', 'req': 36070012,
                       'text': ('RSU Short to Ground Sensor 32 EX3_0 CH0 S1 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_GND)')}
FM_UNDERBODY_S1_S2B = {'dtc': '0x92 0x52 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                       'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_SHORT_BAT_32', 'req': 36070060,
                       'text': ('RSU Short to Battery Sensor 32 EX3_0 CH0 S1 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_BAT)')}
FM_UNDERBODY_S1_COMM = {'dtc': '0x92 0x52 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_COMM_32', 'req': 36069820,
                        'text': ('Satellite Manchester Data Communication Fault EX3_0 CH0 S1 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_COMMUNICATION_ERROR)')}
FM_UNDERBODY_S1_INTERNAL = {'dtc': '0x92 0x52 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                            'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_32', 'req': 36069916,
                            'text': ('RSU Internal error Sensor 32 EX3_0 CH0 S1 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_INTERNAL_ERROR)')}
FM_UNDERBODY_S1_CONFIG = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_CFG_32', 'req': 36070108,
                          'text': ('RSU Configuration error Sensor 32 EX3_0 CH0 S1 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
FM_UNDERBODY_S1_UNEXPECTED = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                         'Value: Within PDC(2 sec)'),
                              'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_32', 'req': 36069868,
                              'text': ('Unexpected Satellite on EX3_0 CH0 S1 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
FM_UNDERBODY_S2_OPEN = {'dtc': '0x92 0x52 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                        'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_OPEN_33', 'req': 36069965,
                        'text': ('RSU Open Circuit on Sensor 33 EX3_0 CH0 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_OPEN)')}
FM_UNDERBODY_S2_S2G = {'dtc': '0x92 0x52 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                       'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_SHORT_GND_33', 'req': 36070013,
                       'text': ('RSU Short to Ground Sensor 33 EX3_0 CH0 S2 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_GND)')}
FM_UNDERBODY_S2_S2B = {'dtc': '0x92 0x52 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                       'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                       'monitor': 'RSU_F_SAT_SHORT_BAT_33', 'req': 36070061,
                       'text': ('RSU Short to Battery Sensor 33 EX3_0 CH0 S2 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_SHORT_TO_BAT)')}
FM_UNDERBODY_S2_COMM = {'dtc': '0x92 0x52 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                        'monitor': 'RSU_F_SAT_COMM_33', 'req': 36069821,
                        'text': ('Satellite Manchester Data Communication Fault EX3_0 CH0 S2 '
                                 '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_COMMUNICATION_ERROR)')}
FM_UNDERBODY_S2_INTERNAL = {'dtc': '0x92 0x52 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                            'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_33', 'req': 36069917,
                            'text': ('RSU Internal error Sensor 33 EX3_0 CH0 S2 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_INTERNAL_ERROR)')}
FM_UNDERBODY_S2_CONFIG = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                          'monitor': 'RSU_F_SAT_CFG_33', 'req': 36070109,
                          'text': ('RSU Configuration error Sensor 33 EX3_0 CH0 S2 '
                                   '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
FM_UNDERBODY_S2_UNEXPECTED = {'dtc': '0x92 0x52 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                         'Value: Within PDC(2 sec)'),
                              'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_33', 'req': 36069869,
                              'text': ('Unexpected Satellite on EX3_0 CH0 S2 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_UNDER_BODY_SENSOR_CONFIGURATION_ERROR)')}
FM_PRESSURE_RIGHT_S3_OPEN = {'dtc': '0x92 0x16 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                             'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_OPEN_2', 'req': 36069934,
                             'text': ('RSU Open Circuit on Sensor 2 SB3_M CH0 S3 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_OPEN)')}
FM_PRESSURE_RIGHT_S3_S2G = {'dtc': '0x92 0x16 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_GND_2', 'req': 36069982,
                            'text': ('RSU Short to Ground Sensor 2 SB3_M CH0 S3 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_SHORT_TO_GND)')}
FM_PRESSURE_RIGHT_S3_S2B = {'dtc': '0x92 0x16 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_SHORT_BAT_2', 'req': 36070030,
                            'text': ('RSU Short to Battery Sensor 2 SB3_M CH0 S3 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_SHORT_TO_BAT)')}
FM_PRESSURE_RIGHT_S3_COMM = {'dtc': '0x92 0x16 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                             'monitor': 'RSU_F_SAT_COMM_2', 'req': 36069790,
                             'text': ('Satellite Manchester Data Communication Fault SB3_M CH0 S3 '
                                      '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_COMMUNICATION_ERROR)')}
FM_PRESSURE_RIGHT_S3_INTERNAL = {'dtc': '0x92 0x16 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                            'Cycle'),
                                 'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_2', 'req': 36069886,
                                 'text': ('RSU Internal error Sensor 2 SB3_M CH0 S3 '
                                          '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_INTERNAL_ERROR)')}
FM_PRESSURE_RIGHT_S3_CONFIG = {'dtc': '0x92 0x16 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                               'monitor': 'RSU_F_SAT_CFG_2', 'req': 36070078,
                               'text': ('RSU Configuration error Sensor 2 SB3_M CH0 S3 '
                                        '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_CONFIGURATION_ERROR)')}
FM_PRESSURE_RIGHT_S3_UNEXPECTED = {'dtc': '0x92 0x16 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                              'Practical Value: Within PDC(2 sec)'),
                                   'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_2', 'req': 36069838,
                                   'text': ('RSU Configuration error Sensor 2 SB3_M CH0 S3 '
                                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_DRIVER_PRSU_CONFIGURATION_ERROR)')}
FM_PRESSURE_LEFT_S3_OPEN = {'dtc': '0x92 0x12 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                            'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_OPEN_6', 'req': 36069938,
                            'text': ('RSU Open Circuit on Sensor 6 SB3_M CH1 S3 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_OPEN)')}
FM_PRESSURE_LEFT_S3_S2G = {'dtc': '0x92 0x12 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_GND_6', 'req': 36069986,
                           'text': ('RSU Short to Ground Sensor 6 SB3_M CH1 S3 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_SHORT_TO_GND)')}
FM_PRESSURE_LEFT_S3_S2B = {'dtc': '0x92 0x12 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                           'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_SAT_SHORT_BAT_6', 'req': 36070034,
                           'text': ('RSU Short to Battery Sensor 6 SB3_M CH1 S3 '
                                    '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_SHORT_TO_BAT)')}
FM_PRESSURE_LEFT_S3_COMM = {'dtc': '0x92 0x12 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                            'monitor': 'RSU_F_SAT_COMM_6', 'req': 36069794,
                            'text': ('Satellite Manchester Data Communication Fault SB3_M CH1 S3 '
                                     '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_COMMUNICATION_ERROR)')}
FM_PRESSURE_LEFT_S3_INTERNAL = {'dtc': '0x92 0x12 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next '
                                           'Cycle'),
                                'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_6', 'req': 36069890,
                                'text': ('RSU Internal error Sensor 6 SB3_M CH1 S3 '
                                         '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_INTERNAL_ERROR)')}
FM_PRESSURE_LEFT_S3_CONFIG = {'dtc': '0x92 0x12 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                              'monitor': 'RSU_F_SAT_CFG_6', 'req': 36070082,
                              'text': ('RSU Configuration error Sensor 6 SB3_M CH1 S3 '
                                       '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_CONFIGURATION_ERROR)')}
FM_PRESSURE_LEFT_S3_UNEXPECTED = {'dtc': '0x92 0x12 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: '
                                             'Practical Value: Within PDC(2 sec)'),
                                  'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_6', 'req': 36069842,
                                  'text': ('RSU Configuration error Sensor 6 SB3_M CH1 S3 '
                                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_PASSENGER_PRSU_CONFIGURATION_ERROR)')}
FM_REAR_S3_OPEN = {'dtc': '0x92 0x38 0x13', 'qualify_ms': 1500, 'dequalify_ms': None,
                   'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                   'monitor': 'RSU_F_SAT_OPEN_38', 'req': 36069970,
                   'text': ('RSU Open Circuit on Sensor 38 EX3_0 CH1 S3 '
                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_OPEN)')}
FM_REAR_S3_S2G = {'dtc': '0x92 0x38 0x11', 'qualify_ms': 1500, 'dequalify_ms': None,
                  'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                  'monitor': 'RSU_F_SAT_SHORT_GND_38', 'req': 36070018,
                  'text': ('RSU Short to Ground Sensor 38 EX3_0 CH1 S3 '
                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_SHORT_TO_GND)')}
FM_REAR_S3_S2B = {'dtc': '0x92 0x38 0x12', 'qualify_ms': 1500, 'dequalify_ms': None,
                  'timing': 'maturation: 1500 ms; dematuration: Next Cycle', 'latched': True,
                  'monitor': 'RSU_F_SAT_SHORT_BAT_38', 'req': 36070066,
                  'text': ('RSU Short to Battery Sensor 38 EX3_0 CH1 S3 '
                           '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_SHORT_TO_BAT)')}
FM_REAR_S3_COMM = {'dtc': '0x92 0x38 0x81', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: 2.051 2.134; dematuration: Next Cycle', 'latched': True,
                   'monitor': 'RSU_F_SAT_COMM_38', 'req': 36069826,
                   'text': ('Satellite Manchester Data Communication Fault EX3_0 CH1 S3 '
                            '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_COMMUNICATION_ERROR)')}
FM_REAR_S3_INTERNAL = {'dtc': '0x92 0x38 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 2.179 2.262 2.179 3.065 (Sensor Busy); dematuration: Next Cycle',
                       'latched': True, 'monitor': 'RSU_F_SAT_INTERNAL_38', 'req': 36069922,
                       'text': ('RSU Internal error Sensor 38 EX3_0 CH1 S3 '
                                '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_INTERNAL_ERROR)')}
FM_REAR_S3_CONFIG = {'dtc': '0x92 0x38 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 2.174 2.257; dematuration: Next Cycle', 'latched': True,
                     'monitor': 'RSU_F_SAT_CFG_38', 'req': 36070114,
                     'text': ('RSU Configuration error Sensor 38 EX3_0 CH1 S3 '
                              '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_CONFIGURATION_ERROR)')}
FM_REAR_S3_UNEXPECTED = {'dtc': '0x92 0x38 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical '
                                    'Value: Within PDC(2 sec)'),
                         'latched': True, 'monitor': 'RSU_F_SAT_UNEXPECTED_LOAD_38', 'req': 36069874,
                         'text': ('Unexpected Satellite on EX3_0 CH1 S3 '
                                  '(FLTMONR_SB3EX3RSUDRVR_E_RSU_SAT_REAR_RSU_CONFIGURATION_ERROR)')}
FM_RSU_CHANNEL00_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_0', 'req': 36069764,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL00_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_0', 'req': 36069776,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 00 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL00_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_0', 'req': 36069752,
                        'text': 'RSU SPI communication error SB3_M Ch00 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL01_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_1', 'req': 36069765,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL01_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_1', 'req': 36069777,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 01 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL01_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_1', 'req': 36069753,
                        'text': 'RSU SPI communication error SB3_M Ch01 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL02_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_2', 'req': 36069766,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL02_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_2', 'req': 36069778,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 02 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL02_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_2', 'req': 36069754,
                        'text': 'RSU SPI communication error SB3_M Ch02 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL03_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_3', 'req': 36069767,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL03_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_3', 'req': 36069779,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 03 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL03_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_3', 'req': 36069755,
                        'text': 'RSU SPI communication error SB3_M Ch03 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL04_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_4', 'req': 36069768,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL04_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_4', 'req': 36069780,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 04 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL04_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_4', 'req': 36069756,
                        'text': 'RSU SPI communication error SB3_M Ch04 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL05_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_5', 'req': 36069769,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL05_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_5', 'req': 36069781,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 05 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL05_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_5', 'req': 36069757,
                        'text': 'RSU SPI communication error SB3_M Ch05 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL06_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_6', 'req': 36069770,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL06_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_6', 'req': 36069782,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 06 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL06_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_6', 'req': 36069758,
                        'text': 'RSU SPI communication error SB3_M Ch06 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL07_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_7', 'req': 36069771,
                           'text': 'RSU ASIC Channel Configuration Fault SB3_M CH 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL07_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_7', 'req': 36069783,
                                'text': 'RSU ASIC Channel SPI Fault SB3_M CH 07 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL07_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_7', 'req': 36069759,
                        'text': 'RSU SPI communication error SB3_M Ch07 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL08_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_8', 'req': 36069772,
                           'text': 'RSU ASIC Channel Configuration Fault EX3_0 CH 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL08_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_8', 'req': 36069784,
                                'text': 'RSU ASIC Channel SPI Fault EX3_0 CH 00 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL08_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_8', 'req': 36069760,
                        'text': 'RSU SPI communication error EX3_0 Ch00 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL09_CONFIG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0055; dematuration: Next Cycle', 'latched': True,
                           'monitor': 'RSU_F_ASIC_CHANNEL_CONFIG_9', 'req': 36069773,
                           'text': 'RSU ASIC Channel Configuration Fault EX3_0 CH 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL09_CRC_CHECKER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.006; dematuration: Next Cycle', 'latched': False,
                                'monitor': 'RSU_F_ASIC_CHANNEL_CRC_CHECKER_9', 'req': 36069785,
                                'text': 'RSU ASIC Channel SPI Fault EX3_0 CH 01 (FLTMONR_E_ECU_INTERNAL)'}
FM_RSU_CHANNEL09_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.422 0.485; dematuration: Next Cycle', 'latched': False,
                        'monitor': 'RSU_F_ASIC_CHANNEL_SPI_9', 'req': 36069761,
                        'text': 'RSU SPI communication error EX3_0 Ch01 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_0', 'req': 36070228,
                       'text': 'OPS RSU Offset Failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_1', 'req': 36070229,
                       'text': 'OPS RSU Offset Failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_10 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_10', 'req': 36070238,
                        'text': 'OPS RSU Offset Failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_11 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_11', 'req': 36070239,
                        'text': 'OPS RSU Offset Failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_12 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_12', 'req': 36070240,
                        'text': 'OPS RSU Offset Failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_13 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_13', 'req': 36070241,
                        'text': 'OPS RSU Offset Failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_14 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_14', 'req': 36070242,
                        'text': 'OPS RSU Offset Failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_15 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_15', 'req': 36070243,
                        'text': 'OPS RSU Offset Failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_16 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_16', 'req': 36070244,
                        'text': 'OPS RSU Offset Failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_17 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_17', 'req': 36070245,
                        'text': 'OPS RSU Offset Failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_18 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                   'Cycle'),
                        'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_18', 'req': 36070246,
                        'text': 'OPS RSU Offset Failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_2', 'req': 36070230,
                       'text': 'OPS RSU Offset Failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_3', 'req': 36070231,
                       'text': 'OPS RSU Offset Failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_4 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_4', 'req': 36070232,
                       'text': 'OPS RSU Offset Failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_5 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_5', 'req': 36070233,
                       'text': 'OPS RSU Offset Failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_6 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_6', 'req': 36070234,
                       'text': 'OPS RSU Offset Failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_7 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_7', 'req': 36070235,
                       'text': 'OPS RSU Offset Failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_8 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_8', 'req': 36070236,
                       'text': 'OPS RSU Offset Failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_OFFSET_9 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : N/A. APPRISe: 2.05s after Power On for FOC.; dematuration: Next '
                                  'Cycle'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_OCR_9', 'req': 36070237,
                       'text': 'OPS RSU Offset Failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_0', 'req': 36070173,
                           'text': 'OPS RSU Saturation Failure Line 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_1', 'req': 36070174,
                           'text': 'OPS RSU Saturation Failure Line 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_10 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_10', 'req': 36070183,
                            'text': 'OPS RSU Saturation Failure Line 10 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_11 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_11', 'req': 36070184,
                            'text': 'OPS RSU Saturation Failure Line 11 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_12 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_12', 'req': 36070185,
                            'text': 'OPS RSU Saturation Failure Line 12 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_13 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_13', 'req': 36070186,
                            'text': 'OPS RSU Saturation Failure Line 13 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_14 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_14', 'req': 36070187,
                            'text': 'OPS RSU Saturation Failure Line 14 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_15 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_15', 'req': 36070188,
                            'text': 'OPS RSU Saturation Failure Line 15 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_16 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_16', 'req': 36070189,
                            'text': 'OPS RSU Saturation Failure Line 16 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_17 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_17', 'req': 36070190,
                            'text': 'OPS RSU Saturation Failure Line 17 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_18 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                            'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_18', 'req': 36070191,
                            'text': 'OPS RSU Saturation Failure Line 18 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_2', 'req': 36070175,
                           'text': 'OPS RSU Saturation Failure Line 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_3', 'req': 36070176,
                           'text': 'OPS RSU Saturation Failure Line 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_4 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_4', 'req': 36070177,
                           'text': 'OPS RSU Saturation Failure Line 4 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_5 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_5', 'req': 36070178,
                           'text': 'OPS RSU Saturation Failure Line 5 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_6 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_6', 'req': 36070179,
                           'text': 'OPS RSU Saturation Failure Line 6 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_7 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_7', 'req': 36070180,
                           'text': 'OPS RSU Saturation Failure Line 7 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_8 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_8', 'req': 36070181,
                           'text': 'OPS RSU Saturation Failure Line 8 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_RSU_SATURATION_9 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5 (5 for PedPRSU); dematuration: Next Cycle', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_RSU_DEC_9', 'req': 36070182,
                           'text': 'OPS RSU Saturation Failure Line 9 (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_RSUSUPPLY_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 1075, 'dequalify_ms': 1075, 'latched': False,
                          'monitor': 'PWR_F_RSUSUPPLY_TOO_LOW_0', 'req': 36069726,
                          'text': 'RSU SUPPLY is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_RSUSUPPLY_LOW_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': 1075, 'dequalify_ms': 1075, 'latched': False,
                          'monitor': 'PWR_F_RSUSUPPLY_TOO_LOW_1', 'req': 36069739,
                          'text': 'RSU SUPPLY is too low EX3_0 (FLTMONR_E_ECU_INTERNAL)'}

RSU_FAULTS = {
    'A_PILLAR_LEFT_S1_OPEN': FM_A_PILLAR_LEFT_S1_OPEN,
    'A_PILLAR_LEFT_S1_S2G': FM_A_PILLAR_LEFT_S1_S2G,
    'A_PILLAR_LEFT_S1_S2B': FM_A_PILLAR_LEFT_S1_S2B,
    'A_PILLAR_LEFT_S1_COMM': FM_A_PILLAR_LEFT_S1_COMM,
    'A_PILLAR_LEFT_S1_INTERNAL': FM_A_PILLAR_LEFT_S1_INTERNAL,
    'A_PILLAR_LEFT_S1_CONFIG': FM_A_PILLAR_LEFT_S1_CONFIG,
    'A_PILLAR_LEFT_S1_UNEXPECTED': FM_A_PILLAR_LEFT_S1_UNEXPECTED,
    'A_PILLAR_LEFT_S2_OPEN': FM_A_PILLAR_LEFT_S2_OPEN,
    'A_PILLAR_LEFT_S2_S2G': FM_A_PILLAR_LEFT_S2_S2G,
    'A_PILLAR_LEFT_S2_S2B': FM_A_PILLAR_LEFT_S2_S2B,
    'A_PILLAR_LEFT_S2_COMM': FM_A_PILLAR_LEFT_S2_COMM,
    'A_PILLAR_LEFT_S2_INTERNAL': FM_A_PILLAR_LEFT_S2_INTERNAL,
    'A_PILLAR_LEFT_S2_CONFIG': FM_A_PILLAR_LEFT_S2_CONFIG,
    'A_PILLAR_LEFT_S2_UNEXPECTED': FM_A_PILLAR_LEFT_S2_UNEXPECTED,
    'A_PILLAR_RIGHT_S1_OPEN': FM_A_PILLAR_RIGHT_S1_OPEN,
    'A_PILLAR_RIGHT_S1_S2G': FM_A_PILLAR_RIGHT_S1_S2G,
    'A_PILLAR_RIGHT_S1_S2B': FM_A_PILLAR_RIGHT_S1_S2B,
    'A_PILLAR_RIGHT_S1_COMM': FM_A_PILLAR_RIGHT_S1_COMM,
    'A_PILLAR_RIGHT_S1_INTERNAL': FM_A_PILLAR_RIGHT_S1_INTERNAL,
    'A_PILLAR_RIGHT_S1_CONFIG': FM_A_PILLAR_RIGHT_S1_CONFIG,
    'A_PILLAR_RIGHT_S1_UNEXPECTED': FM_A_PILLAR_RIGHT_S1_UNEXPECTED,
    'A_PILLAR_RIGHT_S2_OPEN': FM_A_PILLAR_RIGHT_S2_OPEN,
    'A_PILLAR_RIGHT_S2_S2G': FM_A_PILLAR_RIGHT_S2_S2G,
    'A_PILLAR_RIGHT_S2_S2B': FM_A_PILLAR_RIGHT_S2_S2B,
    'A_PILLAR_RIGHT_S2_COMM': FM_A_PILLAR_RIGHT_S2_COMM,
    'A_PILLAR_RIGHT_S2_INTERNAL': FM_A_PILLAR_RIGHT_S2_INTERNAL,
    'A_PILLAR_RIGHT_S2_CONFIG': FM_A_PILLAR_RIGHT_S2_CONFIG,
    'A_PILLAR_RIGHT_S2_UNEXPECTED': FM_A_PILLAR_RIGHT_S2_UNEXPECTED,
    'B_PILLAR_LEFT_S1_OPEN': FM_B_PILLAR_LEFT_S1_OPEN,
    'B_PILLAR_LEFT_S1_S2G': FM_B_PILLAR_LEFT_S1_S2G,
    'B_PILLAR_LEFT_S1_S2B': FM_B_PILLAR_LEFT_S1_S2B,
    'B_PILLAR_LEFT_S1_COMM': FM_B_PILLAR_LEFT_S1_COMM,
    'B_PILLAR_LEFT_S1_INTERNAL': FM_B_PILLAR_LEFT_S1_INTERNAL,
    'B_PILLAR_LEFT_S1_CONFIG': FM_B_PILLAR_LEFT_S1_CONFIG,
    'B_PILLAR_LEFT_S1_UNEXPECTED': FM_B_PILLAR_LEFT_S1_UNEXPECTED,
    'B_PILLAR_LEFT_S2_OPEN': FM_B_PILLAR_LEFT_S2_OPEN,
    'B_PILLAR_LEFT_S2_S2G': FM_B_PILLAR_LEFT_S2_S2G,
    'B_PILLAR_LEFT_S2_S2B': FM_B_PILLAR_LEFT_S2_S2B,
    'B_PILLAR_LEFT_S2_COMM': FM_B_PILLAR_LEFT_S2_COMM,
    'B_PILLAR_LEFT_S2_INTERNAL': FM_B_PILLAR_LEFT_S2_INTERNAL,
    'B_PILLAR_LEFT_S2_CONFIG': FM_B_PILLAR_LEFT_S2_CONFIG,
    'B_PILLAR_LEFT_S2_UNEXPECTED': FM_B_PILLAR_LEFT_S2_UNEXPECTED,
    'B_PILLAR_RIGHT_S1_OPEN': FM_B_PILLAR_RIGHT_S1_OPEN,
    'B_PILLAR_RIGHT_S1_S2G': FM_B_PILLAR_RIGHT_S1_S2G,
    'B_PILLAR_RIGHT_S1_S2B': FM_B_PILLAR_RIGHT_S1_S2B,
    'B_PILLAR_RIGHT_S1_COMM': FM_B_PILLAR_RIGHT_S1_COMM,
    'B_PILLAR_RIGHT_S1_INTERNAL': FM_B_PILLAR_RIGHT_S1_INTERNAL,
    'B_PILLAR_RIGHT_S1_CONFIG': FM_B_PILLAR_RIGHT_S1_CONFIG,
    'B_PILLAR_RIGHT_S1_UNEXPECTED': FM_B_PILLAR_RIGHT_S1_UNEXPECTED,
    'B_PILLAR_RIGHT_S2_OPEN': FM_B_PILLAR_RIGHT_S2_OPEN,
    'B_PILLAR_RIGHT_S2_S2G': FM_B_PILLAR_RIGHT_S2_S2G,
    'B_PILLAR_RIGHT_S2_S2B': FM_B_PILLAR_RIGHT_S2_S2B,
    'B_PILLAR_RIGHT_S2_COMM': FM_B_PILLAR_RIGHT_S2_COMM,
    'B_PILLAR_RIGHT_S2_INTERNAL': FM_B_PILLAR_RIGHT_S2_INTERNAL,
    'B_PILLAR_RIGHT_S2_CONFIG': FM_B_PILLAR_RIGHT_S2_CONFIG,
    'B_PILLAR_RIGHT_S2_UNEXPECTED': FM_B_PILLAR_RIGHT_S2_UNEXPECTED,
    'FRONT_LEFT_S1_OPEN': FM_FRONT_LEFT_S1_OPEN,
    'FRONT_LEFT_S1_S2G': FM_FRONT_LEFT_S1_S2G,
    'FRONT_LEFT_S1_S2B': FM_FRONT_LEFT_S1_S2B,
    'FRONT_LEFT_S1_COMM': FM_FRONT_LEFT_S1_COMM,
    'FRONT_LEFT_S1_INTERNAL': FM_FRONT_LEFT_S1_INTERNAL,
    'FRONT_LEFT_S1_CONFIG': FM_FRONT_LEFT_S1_CONFIG,
    'FRONT_LEFT_S1_UNEXPECTED': FM_FRONT_LEFT_S1_UNEXPECTED,
    'FRONT_LEFT_S2_OPEN': FM_FRONT_LEFT_S2_OPEN,
    'FRONT_LEFT_S2_S2G': FM_FRONT_LEFT_S2_S2G,
    'FRONT_LEFT_S2_S2B': FM_FRONT_LEFT_S2_S2B,
    'FRONT_LEFT_S2_COMM': FM_FRONT_LEFT_S2_COMM,
    'FRONT_LEFT_S2_INTERNAL': FM_FRONT_LEFT_S2_INTERNAL,
    'FRONT_LEFT_S2_CONFIG': FM_FRONT_LEFT_S2_CONFIG,
    'FRONT_LEFT_S2_UNEXPECTED': FM_FRONT_LEFT_S2_UNEXPECTED,
    'FRONT_RIGHT_S1_OPEN': FM_FRONT_RIGHT_S1_OPEN,
    'FRONT_RIGHT_S1_S2G': FM_FRONT_RIGHT_S1_S2G,
    'FRONT_RIGHT_S1_S2B': FM_FRONT_RIGHT_S1_S2B,
    'FRONT_RIGHT_S1_COMM': FM_FRONT_RIGHT_S1_COMM,
    'FRONT_RIGHT_S1_INTERNAL': FM_FRONT_RIGHT_S1_INTERNAL,
    'FRONT_RIGHT_S1_CONFIG': FM_FRONT_RIGHT_S1_CONFIG,
    'FRONT_RIGHT_S1_UNEXPECTED': FM_FRONT_RIGHT_S1_UNEXPECTED,
    'FRONT_RIGHT_S2_OPEN': FM_FRONT_RIGHT_S2_OPEN,
    'FRONT_RIGHT_S2_S2G': FM_FRONT_RIGHT_S2_S2G,
    'FRONT_RIGHT_S2_S2B': FM_FRONT_RIGHT_S2_S2B,
    'FRONT_RIGHT_S2_COMM': FM_FRONT_RIGHT_S2_COMM,
    'FRONT_RIGHT_S2_INTERNAL': FM_FRONT_RIGHT_S2_INTERNAL,
    'FRONT_RIGHT_S2_CONFIG': FM_FRONT_RIGHT_S2_CONFIG,
    'FRONT_RIGHT_S2_UNEXPECTED': FM_FRONT_RIGHT_S2_UNEXPECTED,
    'C_PILLAR_LEFT_S1_OPEN': FM_C_PILLAR_LEFT_S1_OPEN,
    'C_PILLAR_LEFT_S1_S2G': FM_C_PILLAR_LEFT_S1_S2G,
    'C_PILLAR_LEFT_S1_S2B': FM_C_PILLAR_LEFT_S1_S2B,
    'C_PILLAR_LEFT_S1_COMM': FM_C_PILLAR_LEFT_S1_COMM,
    'C_PILLAR_LEFT_S1_INTERNAL': FM_C_PILLAR_LEFT_S1_INTERNAL,
    'C_PILLAR_LEFT_S1_CONFIG': FM_C_PILLAR_LEFT_S1_CONFIG,
    'C_PILLAR_LEFT_S1_UNEXPECTED': FM_C_PILLAR_LEFT_S1_UNEXPECTED,
    'C_PILLAR_LEFT_S2_OPEN': FM_C_PILLAR_LEFT_S2_OPEN,
    'C_PILLAR_LEFT_S2_S2G': FM_C_PILLAR_LEFT_S2_S2G,
    'C_PILLAR_LEFT_S2_S2B': FM_C_PILLAR_LEFT_S2_S2B,
    'C_PILLAR_LEFT_S2_COMM': FM_C_PILLAR_LEFT_S2_COMM,
    'C_PILLAR_LEFT_S2_INTERNAL': FM_C_PILLAR_LEFT_S2_INTERNAL,
    'C_PILLAR_LEFT_S2_CONFIG': FM_C_PILLAR_LEFT_S2_CONFIG,
    'C_PILLAR_LEFT_S2_UNEXPECTED': FM_C_PILLAR_LEFT_S2_UNEXPECTED,
    'C_PILLAR_RIGHT_S1_OPEN': FM_C_PILLAR_RIGHT_S1_OPEN,
    'C_PILLAR_RIGHT_S1_S2G': FM_C_PILLAR_RIGHT_S1_S2G,
    'C_PILLAR_RIGHT_S1_S2B': FM_C_PILLAR_RIGHT_S1_S2B,
    'C_PILLAR_RIGHT_S1_COMM': FM_C_PILLAR_RIGHT_S1_COMM,
    'C_PILLAR_RIGHT_S1_INTERNAL': FM_C_PILLAR_RIGHT_S1_INTERNAL,
    'C_PILLAR_RIGHT_S1_CONFIG': FM_C_PILLAR_RIGHT_S1_CONFIG,
    'C_PILLAR_RIGHT_S1_UNEXPECTED': FM_C_PILLAR_RIGHT_S1_UNEXPECTED,
    'C_PILLAR_RIGHT_S2_OPEN': FM_C_PILLAR_RIGHT_S2_OPEN,
    'C_PILLAR_RIGHT_S2_S2G': FM_C_PILLAR_RIGHT_S2_S2G,
    'C_PILLAR_RIGHT_S2_S2B': FM_C_PILLAR_RIGHT_S2_S2B,
    'C_PILLAR_RIGHT_S2_COMM': FM_C_PILLAR_RIGHT_S2_COMM,
    'C_PILLAR_RIGHT_S2_INTERNAL': FM_C_PILLAR_RIGHT_S2_INTERNAL,
    'C_PILLAR_RIGHT_S2_CONFIG': FM_C_PILLAR_RIGHT_S2_CONFIG,
    'C_PILLAR_RIGHT_S2_UNEXPECTED': FM_C_PILLAR_RIGHT_S2_UNEXPECTED,
    'UNDERBODY_S1_OPEN': FM_UNDERBODY_S1_OPEN,
    'UNDERBODY_S1_S2G': FM_UNDERBODY_S1_S2G,
    'UNDERBODY_S1_S2B': FM_UNDERBODY_S1_S2B,
    'UNDERBODY_S1_COMM': FM_UNDERBODY_S1_COMM,
    'UNDERBODY_S1_INTERNAL': FM_UNDERBODY_S1_INTERNAL,
    'UNDERBODY_S1_CONFIG': FM_UNDERBODY_S1_CONFIG,
    'UNDERBODY_S1_UNEXPECTED': FM_UNDERBODY_S1_UNEXPECTED,
    'UNDERBODY_S2_OPEN': FM_UNDERBODY_S2_OPEN,
    'UNDERBODY_S2_S2G': FM_UNDERBODY_S2_S2G,
    'UNDERBODY_S2_S2B': FM_UNDERBODY_S2_S2B,
    'UNDERBODY_S2_COMM': FM_UNDERBODY_S2_COMM,
    'UNDERBODY_S2_INTERNAL': FM_UNDERBODY_S2_INTERNAL,
    'UNDERBODY_S2_CONFIG': FM_UNDERBODY_S2_CONFIG,
    'UNDERBODY_S2_UNEXPECTED': FM_UNDERBODY_S2_UNEXPECTED,
    'PRESSURE_RIGHT_S3_OPEN': FM_PRESSURE_RIGHT_S3_OPEN,
    'PRESSURE_RIGHT_S3_S2G': FM_PRESSURE_RIGHT_S3_S2G,
    'PRESSURE_RIGHT_S3_S2B': FM_PRESSURE_RIGHT_S3_S2B,
    'PRESSURE_RIGHT_S3_COMM': FM_PRESSURE_RIGHT_S3_COMM,
    'PRESSURE_RIGHT_S3_INTERNAL': FM_PRESSURE_RIGHT_S3_INTERNAL,
    'PRESSURE_RIGHT_S3_CONFIG': FM_PRESSURE_RIGHT_S3_CONFIG,
    'PRESSURE_RIGHT_S3_UNEXPECTED': FM_PRESSURE_RIGHT_S3_UNEXPECTED,
    'PRESSURE_LEFT_S3_OPEN': FM_PRESSURE_LEFT_S3_OPEN,
    'PRESSURE_LEFT_S3_S2G': FM_PRESSURE_LEFT_S3_S2G,
    'PRESSURE_LEFT_S3_S2B': FM_PRESSURE_LEFT_S3_S2B,
    'PRESSURE_LEFT_S3_COMM': FM_PRESSURE_LEFT_S3_COMM,
    'PRESSURE_LEFT_S3_INTERNAL': FM_PRESSURE_LEFT_S3_INTERNAL,
    'PRESSURE_LEFT_S3_CONFIG': FM_PRESSURE_LEFT_S3_CONFIG,
    'PRESSURE_LEFT_S3_UNEXPECTED': FM_PRESSURE_LEFT_S3_UNEXPECTED,
    'REAR_S3_OPEN': FM_REAR_S3_OPEN,
    'REAR_S3_S2G': FM_REAR_S3_S2G,
    'REAR_S3_S2B': FM_REAR_S3_S2B,
    'REAR_S3_COMM': FM_REAR_S3_COMM,
    'REAR_S3_INTERNAL': FM_REAR_S3_INTERNAL,
    'REAR_S3_CONFIG': FM_REAR_S3_CONFIG,
    'REAR_S3_UNEXPECTED': FM_REAR_S3_UNEXPECTED,
    'RSU_CHANNEL00_CONFIG': FM_RSU_CHANNEL00_CONFIG,
    'RSU_CHANNEL00_CRC_CHECKER': FM_RSU_CHANNEL00_CRC_CHECKER,
    'RSU_CHANNEL00_SPI': FM_RSU_CHANNEL00_SPI,
    'RSU_CHANNEL01_CONFIG': FM_RSU_CHANNEL01_CONFIG,
    'RSU_CHANNEL01_CRC_CHECKER': FM_RSU_CHANNEL01_CRC_CHECKER,
    'RSU_CHANNEL01_SPI': FM_RSU_CHANNEL01_SPI,
    'RSU_CHANNEL02_CONFIG': FM_RSU_CHANNEL02_CONFIG,
    'RSU_CHANNEL02_CRC_CHECKER': FM_RSU_CHANNEL02_CRC_CHECKER,
    'RSU_CHANNEL02_SPI': FM_RSU_CHANNEL02_SPI,
    'RSU_CHANNEL03_CONFIG': FM_RSU_CHANNEL03_CONFIG,
    'RSU_CHANNEL03_CRC_CHECKER': FM_RSU_CHANNEL03_CRC_CHECKER,
    'RSU_CHANNEL03_SPI': FM_RSU_CHANNEL03_SPI,
    'RSU_CHANNEL04_CONFIG': FM_RSU_CHANNEL04_CONFIG,
    'RSU_CHANNEL04_CRC_CHECKER': FM_RSU_CHANNEL04_CRC_CHECKER,
    'RSU_CHANNEL04_SPI': FM_RSU_CHANNEL04_SPI,
    'RSU_CHANNEL05_CONFIG': FM_RSU_CHANNEL05_CONFIG,
    'RSU_CHANNEL05_CRC_CHECKER': FM_RSU_CHANNEL05_CRC_CHECKER,
    'RSU_CHANNEL05_SPI': FM_RSU_CHANNEL05_SPI,
    'RSU_CHANNEL06_CONFIG': FM_RSU_CHANNEL06_CONFIG,
    'RSU_CHANNEL06_CRC_CHECKER': FM_RSU_CHANNEL06_CRC_CHECKER,
    'RSU_CHANNEL06_SPI': FM_RSU_CHANNEL06_SPI,
    'RSU_CHANNEL07_CONFIG': FM_RSU_CHANNEL07_CONFIG,
    'RSU_CHANNEL07_CRC_CHECKER': FM_RSU_CHANNEL07_CRC_CHECKER,
    'RSU_CHANNEL07_SPI': FM_RSU_CHANNEL07_SPI,
    'RSU_CHANNEL08_CONFIG': FM_RSU_CHANNEL08_CONFIG,
    'RSU_CHANNEL08_CRC_CHECKER': FM_RSU_CHANNEL08_CRC_CHECKER,
    'RSU_CHANNEL08_SPI': FM_RSU_CHANNEL08_SPI,
    'RSU_CHANNEL09_CONFIG': FM_RSU_CHANNEL09_CONFIG,
    'RSU_CHANNEL09_CRC_CHECKER': FM_RSU_CHANNEL09_CRC_CHECKER,
    'RSU_CHANNEL09_SPI': FM_RSU_CHANNEL09_SPI,
    'OPS_RSU_OFFSET_0': FM_OPS_RSU_OFFSET_0,
    'OPS_RSU_OFFSET_1': FM_OPS_RSU_OFFSET_1,
    'OPS_RSU_OFFSET_10': FM_OPS_RSU_OFFSET_10,
    'OPS_RSU_OFFSET_11': FM_OPS_RSU_OFFSET_11,
    'OPS_RSU_OFFSET_12': FM_OPS_RSU_OFFSET_12,
    'OPS_RSU_OFFSET_13': FM_OPS_RSU_OFFSET_13,
    'OPS_RSU_OFFSET_14': FM_OPS_RSU_OFFSET_14,
    'OPS_RSU_OFFSET_15': FM_OPS_RSU_OFFSET_15,
    'OPS_RSU_OFFSET_16': FM_OPS_RSU_OFFSET_16,
    'OPS_RSU_OFFSET_17': FM_OPS_RSU_OFFSET_17,
    'OPS_RSU_OFFSET_18': FM_OPS_RSU_OFFSET_18,
    'OPS_RSU_OFFSET_2': FM_OPS_RSU_OFFSET_2,
    'OPS_RSU_OFFSET_3': FM_OPS_RSU_OFFSET_3,
    'OPS_RSU_OFFSET_4': FM_OPS_RSU_OFFSET_4,
    'OPS_RSU_OFFSET_5': FM_OPS_RSU_OFFSET_5,
    'OPS_RSU_OFFSET_6': FM_OPS_RSU_OFFSET_6,
    'OPS_RSU_OFFSET_7': FM_OPS_RSU_OFFSET_7,
    'OPS_RSU_OFFSET_8': FM_OPS_RSU_OFFSET_8,
    'OPS_RSU_OFFSET_9': FM_OPS_RSU_OFFSET_9,
    'OPS_RSU_SATURATION_0': FM_OPS_RSU_SATURATION_0,
    'OPS_RSU_SATURATION_1': FM_OPS_RSU_SATURATION_1,
    'OPS_RSU_SATURATION_10': FM_OPS_RSU_SATURATION_10,
    'OPS_RSU_SATURATION_11': FM_OPS_RSU_SATURATION_11,
    'OPS_RSU_SATURATION_12': FM_OPS_RSU_SATURATION_12,
    'OPS_RSU_SATURATION_13': FM_OPS_RSU_SATURATION_13,
    'OPS_RSU_SATURATION_14': FM_OPS_RSU_SATURATION_14,
    'OPS_RSU_SATURATION_15': FM_OPS_RSU_SATURATION_15,
    'OPS_RSU_SATURATION_16': FM_OPS_RSU_SATURATION_16,
    'OPS_RSU_SATURATION_17': FM_OPS_RSU_SATURATION_17,
    'OPS_RSU_SATURATION_18': FM_OPS_RSU_SATURATION_18,
    'OPS_RSU_SATURATION_2': FM_OPS_RSU_SATURATION_2,
    'OPS_RSU_SATURATION_3': FM_OPS_RSU_SATURATION_3,
    'OPS_RSU_SATURATION_4': FM_OPS_RSU_SATURATION_4,
    'OPS_RSU_SATURATION_5': FM_OPS_RSU_SATURATION_5,
    'OPS_RSU_SATURATION_6': FM_OPS_RSU_SATURATION_6,
    'OPS_RSU_SATURATION_7': FM_OPS_RSU_SATURATION_7,
    'OPS_RSU_SATURATION_8': FM_OPS_RSU_SATURATION_8,
    'OPS_RSU_SATURATION_9': FM_OPS_RSU_SATURATION_9,
    'PWR_RSUSUPPLY_LOW_0': FM_PWR_RSUSUPPLY_LOW_0,
    'PWR_RSUSUPPLY_LOW_1': FM_PWR_RSUSUPPLY_LOW_1,
}


# ====================================================================================================
# CAN supervision (68)
# <node>_NODE_ABSENT, <frame>_TIMEOUT, <frame>_CRC / _DLC / _COUNTER (message content failure: all
# three share the frame's DTC), <signal>_SCF (signal content failure). Times are in frame counts.
# ====================================================================================================
FM_ECALL_NODE_ABSENT = {'dtc': '0xD1 0x73 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'ECALL_NODE_ABSENT', 'req': 36070404,
                        'text': 'ECALL Node Absent (FLTMONR_E_ECALL_NODE_ABSENT)'}
FM_EPS_NODE_ABSENT = {'dtc': '0xD1 0x11 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'EPS_NODE_ABSENT', 'req': 36070334,
                      'text': 'EPS Node Absent (FLTMONR_E_EPS_NODE_ABSENT)'}
FM_FR_ZONE_NODE_ABSENT = {'dtc': '0xD1 0x04 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                          'monitor': 'FR_ZONE_NODE_ABSENT', 'req': 36070333,
                          'text': 'FR_ZONE Node Absent (FLTMONR_E_FR_ZONE_NODE_ABSENT)'}
FM_HPCAD_NODE_ABSENT = {'dtc': '0xD1 0x61 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'HPCAD_NODE_ABSENT', 'req': 36070360,
                        'text': 'HPCAD Node Absent (FLTMONR_E_HPCAD_NODE_ABSENT)'}
FM_HPCC_NODE_ABSENT = {'dtc': '0xD1 0x60 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                       'monitor': 'HPCC_NODE_ABSENT', 'req': 36070335,
                       'text': 'HPCC Node Absent (FLTMONR_E_HPCC_NODE_ABSENT)'}
FM_IEB_NODE_ABSENT = {'dtc': '0xD1 0x03 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'IEB_NODE_ABSENT', 'req': 36070332,
                      'text': 'IEB Node Absent (FLTMONR_E_IEB_NODE_ABSENT)'}
FM_OCS_NODE_ABSENT = {'dtc': '0xD1 0x70 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'OCS_NODE_ABSENT', 'req': 36070401,
                      'text': 'OCS1_500 Node Absent (FLTMONR_E_OCS_NODE_ABSENT)'}
FM_VCU_NODE_ABSENT = {'dtc': '0xD1 0x54 0x00', 'qualify_counts': 50, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'VCU_NODE_ABSENT', 'req': 36070330,
                      'text': 'VCU Node Absent (FLTMONR_E_VCU_NODE_ABSENT)'}
FM_FR_ZONE_TIMEOUT = {'dtc': '0xD0 0x04 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'FRZONE_MESSAGE_TIMEOUT', 'req': 36070373,
                      'text': 'FRZONE Message Timeout (FLTMONR_E_FRZONE_MESSAGE_TIMEOUT)'}
FM_HPCAD2_TIMEOUT = {'dtc': '0xD0 0x5B 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD2_MESSAGE_TIMEOUT', 'req': 36070371,
                     'text': 'HPCAD Message Timeout (FLTMONR_E_HPCAD_MESSAGE_TIMEOUT)'}
FM_HPCAD3_TIMEOUT = {'dtc': '0xD0 0x5B 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD3_MESSAGE_TIMEOUT', 'req': 36070391,
                     'text': 'HPCAD Message Timeout (FLTMONR_E_HPCAD_MESSAGE_TIMEOUT)'}
FM_HPCAD4_TIMEOUT = {'dtc': '0xD0 0x5B 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD4_MESSAGE_TIMEOUT', 'req': 36070392,
                     'text': 'HPCAD Message Timeout (FLTMONR_E_HPCAD_MESSAGE_TIMEOUT)'}
FM_SYNC_F_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 3; dematuration: 1', 'latched': False,
                     'monitor': 'SYNC_F_MESSAGE_TIMEOUT', 'req': 36069749,
                     'text': ('Missing message for Sync_Message (TripResetSyncMessage frame). '
                              '(FLTMONR_E_ECU_INTERNAL)')}
FM_VCU1_TIMEOUT = {'dtc': '0xD0 0x54 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'VCU1_MESSAGE_TIMEOUT', 'req': 36070331,
                   'text': 'VCU Message Timeout (FLTMONR_E_VCU_MESSAGE_TIMEOUT)'}
FM_VCU2_TIMEOUT = {'dtc': '0xD0 0x54 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'VCU2_MESSAGE_TIMEOUT', 'req': 36070393,
                   'text': 'VCU Message Timeout (FLTMONR_E_VCU_MESSAGE_TIMEOUT)'}
FM_E2E_PIB_CRC = {'dtc': '0x90 0x13 0x49', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': True,
                  'monitor': 'F_E2E_PIB_CRC_MISMATCH', 'req': 36069751,
                  'text': ('Error detected due to mismatch between CRC received via E2E frame and the CRC '
                           'calcualted based on E2E payload data. (FLTMONR_E_ECU_INTERNAL)')}
FM_EPS1_CRC = {'dtc': '0xE7 0x25 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'EPS1_FD_CRC_MISMATCH', 'req': 36070345,
               'text': 'EPS1_FD_10(0x13A) CRC mismatch (FLTMONR_E_EPS1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FM_FR_ZONE2_CRC = {'dtc': '0xE7 0x1C 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'FR_ZONE2_CRC_MISMATCH', 'req': 36070387,
                   'text': 'FR_ZONE2_100(0x319) CRC mismatch (FLTMONR_E_FR_ZONE2_100_MESSAGE_CONTENT_FAILURE)'}
FM_FR_ZONE3_CRC = {'dtc': '0xE7 0x24 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'FR_ZONE3_CRC_MISMATCH', 'req': 36070337,
                   'text': 'FR_ZONE3_100(0x31A) CRC mismatch (FLTMONR_E_FR_ZONE3_100_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD1_CRC = {'dtc': '0xE7 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_1_FD_CRC_MISMATCH', 'req': 36070374,
                 'text': 'HPCAD1_FD_10 (0x13E) CRC mismatch (FLTMONR_E_HPCAD_1_10_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD2_CRC = {'dtc': '0xE7 0x32 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_2_FD_CRC_MISMATCH', 'req': 36070376,
                 'text': 'HPCAD2_FD_50 (0x2AF) CRC mismatch (FLTMONR_E_HPCAD_2_50_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD3_CRC = {'dtc': '0xE7 0x1E 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_3_FD_CRC_MISMATCH', 'req': 36070378,
                 'text': 'HPCAD3_FD_50 (0x2B1) CRC mismatch (FLTMONR_E_HPCAD_3_50_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD4_CRC = {'dtc': '0xE7 0x29 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_4_FD_CRC_MISMATCH', 'req': 36070380,
                 'text': 'HPCAD4_FD_10 (0x13F) CRC mismatch (FLTMONR_E_HPCAD_4_10_MESSAGE_CONTENT_FAILURE)'}
FM_HPCC1_CRC = {'dtc': '0xE7 0x1F 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'HPCC_1_CRC_MISMATCH', 'req': 36070384,
                'text': 'HPCC_1_100 (0x318) DLC mismatch (FLTMONR_E_HPCC_1_100_MESSAGE_CONTENT_FAILURE)'}
FM_IEB1_CRC = {'dtc': '0xE7 0x20 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'IEB1_FD_CRC_MISMATCH', 'req': 36070342,
               'text': 'IEB1_FD_10 (0x13B) CRC mismatch (FLTMONR_E_IEB1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FM_OCS1_CRC = {'dtc': '0xE7 0x61 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'OCS1_CRC_MISMATCH', 'req': 36070399,
               'text': 'OCS1_500(0x5FF) CRC mismatch (FLTMONR_E_OCS1_500_MESSAGE_CONTENT_FAILURE)'}
FM_VCU11_CRC = {'dtc': '0xE7 0x26 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'VCU11_FD_CRC_MISMATCH', 'req': 36070382,
                'text': 'VCU11_FD_10(0x16E) CRC mismatch (FLTMONR_E_VCU11_FD_10_MESSAGE_CONTENT_FAILURE)'}
FM_VCU1_CRC = {'dtc': '0xE7 0x22 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'VCU1_FD_CRC_MISMATCH', 'req': 36070348,
               'text': 'VCU1_FD_20 (0x207) CRC mismatch (FLTMONR_E_VCU1_FD_20_MESSAGE_CONTENT_FAILURE)'}
FM_VCU2_CRC = {'dtc': '0xE7 0x23 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'VCU2_FD_CRC_MISMATCH', 'req': 36070351,
               'text': 'VCU2_FD_100 (0x30E) CRC mismatch (FLTMONR_E_VCU2_FD_100_MESSAGE_CONTENT_FAILURE)'}
FM_EPS1_DLC = {'dtc': '0xE7 0x25 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'EPS1_FD_DLC_MISMATCH', 'req': 36070344,
               'text': 'EPS1_FD_10(0x13A) DLC mismatch (FLTMONR_E_EPS1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FM_FR_ZONE2_DLC = {'dtc': '0xE7 0x1C 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'FR_ZONE2_DLC_MISMATCH', 'req': 36070386,
                   'text': 'FR_ZONE2_100(0x319) DLC mismatch (FLTMONR_E_FR_ZONE2_100_MESSAGE_CONTENT_FAILURE)'}
FM_FR_ZONE3_DLC = {'dtc': '0xE7 0x24 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'FR_ZONE3_DLC_MISMATCH', 'req': 36070336,
                   'text': 'FR_ZONE3_100(0x31A) DLC mismatch (FLTMONR_E_FR_ZONE3_100_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD1_DLC = {'dtc': '0xE7 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_1_FD_DLC_MISMATCH', 'req': 36070356,
                 'text': 'HPCAD1_FD_10 (0x13E) DLC mismatch (FLTMONR_E_HPCAD_1_10_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD2_DLC = {'dtc': '0xE7 0x32 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_2_FD_DLC_MISMATCH', 'req': 36070357,
                 'text': 'HPCAD2_FD_50 (0x2AF) DLC mismatch (FLTMONR_E_HPCAD_2_50_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD3_DLC = {'dtc': '0xE7 0x1E 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_3_FD_DLC_MISMATCH', 'req': 36070358,
                 'text': 'HPCAD3_FD_50 (0x2B1) DLC mismatch (FLTMONR_E_HPCAD_3_50_MESSAGE_CONTENT_FAILURE)'}
FM_HPCAD4_DLC = {'dtc': '0xE7 0x29 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                 'monitor': 'HPCAD_4_FD_DLC_MISMATCH', 'req': 36070359,
                 'text': 'HPCAD4_FD_10 (0x13F) DLC mismatch (FLTMONR_E_HPCAD_4_10_MESSAGE_CONTENT_FAILURE)'}
FM_HPCC1_DLC = {'dtc': '0xE7 0x1F 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'HPCC_1_DLC_MISMATCH', 'req': 36070340,
                'text': 'HPCC_1_100 (0x318) DLC mismatch (FLTMONR_E_HPCC_1_100_MESSAGE_CONTENT_FAILURE)'}
FM_IEB1_DLC = {'dtc': '0xE7 0x20 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'IEB1_FD_DLC_MISMATCH', 'req': 36070341,
               'text': 'IEB1_FD_10 (0x13B) DLC mismatch (FLTMONR_E_IEB1_FD_10_MESSAGE_CONTENT_FAILURE)'}
FM_OCS1_DLC = {'dtc': '0xE7 0x61 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'OCS1_DLC_MISMATCH', 'req': 36070398,
               'text': 'OCS1_500(0x5FF) DLC mismatch (FLTMONR_E_OCS1_500_MESSAGE_CONTENT_FAILURE)'}
FM_VCU11_DLC = {'dtc': '0xE7 0x26 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                'monitor': 'VCU11_FD_DLC_MISMATCH', 'req': 36070339,
                'text': 'VCU11_FD_10(0x16E) DLC mismatch (FLTMONR_E_VCU11_FD_10_MESSAGE_CONTENT_FAILURE)'}
FM_VCU1_DLC = {'dtc': '0xE7 0x22 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'VCU1_FD_DLC_MISMATCH', 'req': 36070347,
               'text': 'VCU1_FD_20 (0x207) DLC mismatch (FLTMONR_E_VCU1_FD_20_MESSAGE_CONTENT_FAILURE)'}
FM_VCU2_DLC = {'dtc': '0xE7 0x23 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'VCU2_FD_DLC_MISMATCH', 'req': 36070350,
               'text': 'VCU2_FD_100 (0x30E) DLC mismatch (FLTMONR_E_VCU2_FD_100_MESSAGE_CONTENT_FAILURE)'}
FM_VCU4_DLC = {'dtc': '0xE7 0x27 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
               'monitor': 'VCU4_FD_DLC_MISMATCH', 'req': 36070389,
               'text': 'VCU4_FD_100 (0x30E) DLC mismatch (FLTMONR_E_VCU4_FD_100_MESSAGE_CONTENT_FAILURE)'}
FM_EPS1_COUNTER = {'dtc': '0xE7 0x25 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'EPS1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070346,
                   'text': ('EPS1_FD_10(0x13A) Alive counter mismatch '
                            '(FLTMONR_E_EPS1_FD_10_MESSAGE_CONTENT_FAILURE)')}
FM_FR_ZONE2_COUNTER = {'dtc': '0xE7 0x1C 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                       'monitor': 'FR_ZONE2_ALIVECOUNTER_MISMATCH', 'req': 36070388,
                       'text': ('FR_ZONE2_100(0x319) Alive counter mismatch '
                                '(FLTMONR_E_FR_ZONE2_100_MESSAGE_CONTENT_FAILURE)')}
FM_FR_ZONE3_COUNTER = {'dtc': '0xE7 0x24 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                       'monitor': 'FR_ZONE3_ALIVECOUNTER_MISMATCH', 'req': 36070338,
                       'text': ('FR_ZONE3_100(0x31A) Alive counter mismatch '
                                '(FLTMONR_E_FR_ZONE3_100_MESSAGE_CONTENT_FAILURE)')}
FM_HPCAD1_COUNTER = {'dtc': '0xE7 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD_1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070375,
                     'text': ('HPCAD1_FD_10 (0x13E) ALIVECOUNTER mismatch '
                              '(FLTMONR_E_HPCAD_1_10_MESSAGE_CONTENT_FAILURE)')}
FM_HPCAD2_COUNTER = {'dtc': '0xE7 0x32 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD_2_FD_ALIVECOUNTER_MISMATCH', 'req': 36070377,
                     'text': ('HPCAD2_FD_50 (0x2AF) ALIVECOUNTER mismatch '
                              '(FLTMONR_E_HPCAD_2_50_MESSAGE_CONTENT_FAILURE)')}
FM_HPCAD3_COUNTER = {'dtc': '0xE7 0x1E 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD_3_FD_ALIVECOUNTER_MISMATCH', 'req': 36070379,
                     'text': ('HPCAD3_FD_50 (0x2B1) ALIVECOUNTER mismatch '
                              '(FLTMONR_E_HPCAD_3_50_MESSAGE_CONTENT_FAILURE)')}
FM_HPCAD4_COUNTER = {'dtc': '0xE7 0x29 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                     'monitor': 'HPCAD_4_FD_ALIVECOUNTER_MISMATCH', 'req': 36070381,
                     'text': ('HPCAD4_FD_10 (0x13F) ALIVECOUNTER mismatch '
                              '(FLTMONR_E_HPCAD_4_10_MESSAGE_CONTENT_FAILURE)')}
FM_HPCC1_COUNTER = {'dtc': '0xE7 0x1F 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                    'monitor': 'HPCC_1_ALIVECOUNTER_MISMATCH', 'req': 36070385,
                    'text': 'HPCC_1_100 (0x318) DLC mismatch (FLTMONR_E_HPCC_1_100_MESSAGE_CONTENT_FAILURE)'}
FM_IEB1_COUNTER = {'dtc': '0xE7 0x20 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'IEB1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070343,
                   'text': ('IEB1_FD_10 (0x13B) Alive counter mismatch '
                            '(FLTMONR_E_IEB1_FD_10_MESSAGE_CONTENT_FAILURE)')}
FM_OCS1_COUNTER = {'dtc': '0xE7 0x61 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'OCS1_ALIVECOUNTER_MISMATCH', 'req': 36070400,
                   'text': 'OCS1_500(0x5FF) Alive counter mismatch (FLTMONR_E_OCS1_500_MESSAGE_CONTENT_FAILURE)'}
FM_VCU11_COUNTER = {'dtc': '0xE7 0x26 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                    'monitor': 'VCU11_FD_ALIVECOUNTER_MISMATCH', 'req': 36070383,
                    'text': ('VCU11_FD_10(0x16E) ALIVECOUNTER mismatch '
                             '(FLTMONR_E_VCU11_FD_10_MESSAGE_CONTENT_FAILURE)')}
FM_VCU1_COUNTER = {'dtc': '0xE7 0x22 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'VCU1_FD_ALIVECOUNTER_MISMATCH', 'req': 36070349,
                   'text': ('VCU1_FD_20 (0x207) Alive counter mismatch '
                            '(FLTMONR_E_VCU1_FD_20_MESSAGE_CONTENT_FAILURE)')}
FM_VCU2_COUNTER = {'dtc': '0xE7 0x23 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'VCU2_FD_ALIVECOUNTER_MISMATCH', 'req': 36070352,
                   'text': ('VCU2_FD_100 (0x30E) Alive counter mismatch '
                            '(FLTMONR_E_VCU2_FD_100_MESSAGE_CONTENT_FAILURE)')}
FM_FL_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD6 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                           'monitor': 'FL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070365,
                           'text': ('FL Tyre pressure Signal Content Error '
                                    '(FLTMONR_E_FL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
FM_FR_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD7 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                           'monitor': 'FR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070368,
                           'text': ('FR Tyre Pressure Signal Content Error '
                                    '(FLTMONR_E_FR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
FM_GEAR_ACTUAL_SCF = {'dtc': '0xE1 0x1D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                      'monitor': 'GEAR_ACTUAL_SIGNAL_CONTENT_FAILURE', 'req': 36070362,
                      'text': 'GEAR_ACTUAL signal Content Failure (FLTMONR_E_GEAR_ACTUAL_SIGNAL_CONTENT_FAILURE)'}
FM_MASTER_CYL_PRESSURE_SCF = {'dtc': '0xE1 0x8D 0x00', 'qualify_counts': 60, 'dequalify_counts': 10,
                              'latched': False, 'monitor': 'MASTER_CYL_PRESSURE_SIGNAL_CONTENT_FAILURE',
                              'req': 36070364,
                              'text': ('Master cycle pressure Signal Content Error '
                                       '(FLTMONR_E_MASTER_CYL_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
FM_MOTOR_SPEED_SCF = {'dtc': '0xE1 0x5F 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: NA; dematuration: NA', 'latched': False,
                      'monitor': 'MOTOR_SPD_SIGNAL_CONTENT_FAILURE', 'req': 36073809,
                      'text': 'MOTOR_SPD Signal Content Failure (FLTMONR_E_MOTOR_SPD_SIGNAL_CONTENT_FAILURE)'}
FM_ODOMETER_SCF = {'dtc': '0xE0 0x12 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                   'monitor': 'ODOMTR_READING_IS_SIGNAL_CONTENT_FAILURE', 'req': 36070363,
                   'text': ('ODOMTR_READING_IS Signal Content Failure '
                            '(FLTMONR_E_ODOMTR_READING_IS_SIGNAL_CONTENT_FAILURE)')}
FM_RL_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD8 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                           'monitor': 'RL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070366,
                           'text': ('RL Tyre Pressure Signal Content Error '
                                    '(FLTMONR_E_RL_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
FM_RR_TYRE_PRESSURE_SCF = {'dtc': '0xE0 0xD9 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                           'monitor': 'RR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE', 'req': 36070367,
                           'text': ('RR Tyre Pressure Signal Content Error '
                                    '(FLTMONR_E_RR_TYRE_PRESSURE_SIGNAL_CONTENT_FAILURE)')}
FM_STEERING_ANGLE_SCF = {'dtc': '0xE0 0x58 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                         'monitor': 'STEERING_ABSOLUTE_ANGLE_SIGNAL_CONTENT_FAILURE', 'req': 36070369,
                         'text': ('Steering Absolute Angle Signal Content Error '
                                  '(FLTMONR_E_STEERING_ABSOLUTE_ANGLE_SIGNAL_CONTENT_FAILURE)')}
FM_STEER_ANGLE_CMD_SCF = {'dtc': '0xE1 0x77 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                          'monitor': 'ADAS_DES_STRWHL_ANGLE_CMD_SIGNAL_CONTENT_FAILURE', 'req': 36070361,
                          'text': ('ADAS_DES_STRWHL_ANGLE_CMD Signal Content Error '
                                   '(FLTMONR_E_ADAS_DES_STRWHL_ANGLE_SIGNAL_CONTENT_FAILURE)')}
FM_VEHICLE_SPEED_SCF = {'dtc': '0xE0 0x13 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'VEHICLE_SPEED_SIGNAL_CONTENT_FAILURE', 'req': 36070327,
                        'text': ('Vehicle Speed Signal Content Error '
                                 '(FLTMONR_E_VEHICLE_SPEED_SIGNAL_CONTENT_FAILURE)')}
FM_VEHICLE_STATE_SCF = {'dtc': '0xE1 0x79 0x00', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': False,
                        'monitor': 'VEHICLE_STATE_SIGNAL_CONTENT_FAILURE', 'req': 36070370,
                        'text': ('Vehicle state Signal Content Error '
                                 '(FLTMONR_E_VEHICLE_STATE_SIGNAL_CONTENT_FAILURE)')}

CAN_FAULTS = {
    'ECALL_NODE_ABSENT': FM_ECALL_NODE_ABSENT,
    'EPS_NODE_ABSENT': FM_EPS_NODE_ABSENT,
    'FR_ZONE_NODE_ABSENT': FM_FR_ZONE_NODE_ABSENT,
    'HPCAD_NODE_ABSENT': FM_HPCAD_NODE_ABSENT,
    'HPCC_NODE_ABSENT': FM_HPCC_NODE_ABSENT,
    'IEB_NODE_ABSENT': FM_IEB_NODE_ABSENT,
    'OCS_NODE_ABSENT': FM_OCS_NODE_ABSENT,
    'VCU_NODE_ABSENT': FM_VCU_NODE_ABSENT,
    'FR_ZONE_TIMEOUT': FM_FR_ZONE_TIMEOUT,
    'HPCAD2_TIMEOUT': FM_HPCAD2_TIMEOUT,
    'HPCAD3_TIMEOUT': FM_HPCAD3_TIMEOUT,
    'HPCAD4_TIMEOUT': FM_HPCAD4_TIMEOUT,
    'SYNC_F_TIMEOUT': FM_SYNC_F_TIMEOUT,
    'VCU1_TIMEOUT': FM_VCU1_TIMEOUT,
    'VCU2_TIMEOUT': FM_VCU2_TIMEOUT,
    'E2E_PIB_CRC': FM_E2E_PIB_CRC,
    'EPS1_CRC': FM_EPS1_CRC,
    'FR_ZONE2_CRC': FM_FR_ZONE2_CRC,
    'FR_ZONE3_CRC': FM_FR_ZONE3_CRC,
    'HPCAD1_CRC': FM_HPCAD1_CRC,
    'HPCAD2_CRC': FM_HPCAD2_CRC,
    'HPCAD3_CRC': FM_HPCAD3_CRC,
    'HPCAD4_CRC': FM_HPCAD4_CRC,
    'HPCC1_CRC': FM_HPCC1_CRC,
    'IEB1_CRC': FM_IEB1_CRC,
    'OCS1_CRC': FM_OCS1_CRC,
    'VCU11_CRC': FM_VCU11_CRC,
    'VCU1_CRC': FM_VCU1_CRC,
    'VCU2_CRC': FM_VCU2_CRC,
    'EPS1_DLC': FM_EPS1_DLC,
    'FR_ZONE2_DLC': FM_FR_ZONE2_DLC,
    'FR_ZONE3_DLC': FM_FR_ZONE3_DLC,
    'HPCAD1_DLC': FM_HPCAD1_DLC,
    'HPCAD2_DLC': FM_HPCAD2_DLC,
    'HPCAD3_DLC': FM_HPCAD3_DLC,
    'HPCAD4_DLC': FM_HPCAD4_DLC,
    'HPCC1_DLC': FM_HPCC1_DLC,
    'IEB1_DLC': FM_IEB1_DLC,
    'OCS1_DLC': FM_OCS1_DLC,
    'VCU11_DLC': FM_VCU11_DLC,
    'VCU1_DLC': FM_VCU1_DLC,
    'VCU2_DLC': FM_VCU2_DLC,
    'VCU4_DLC': FM_VCU4_DLC,
    'EPS1_COUNTER': FM_EPS1_COUNTER,
    'FR_ZONE2_COUNTER': FM_FR_ZONE2_COUNTER,
    'FR_ZONE3_COUNTER': FM_FR_ZONE3_COUNTER,
    'HPCAD1_COUNTER': FM_HPCAD1_COUNTER,
    'HPCAD2_COUNTER': FM_HPCAD2_COUNTER,
    'HPCAD3_COUNTER': FM_HPCAD3_COUNTER,
    'HPCAD4_COUNTER': FM_HPCAD4_COUNTER,
    'HPCC1_COUNTER': FM_HPCC1_COUNTER,
    'IEB1_COUNTER': FM_IEB1_COUNTER,
    'OCS1_COUNTER': FM_OCS1_COUNTER,
    'VCU11_COUNTER': FM_VCU11_COUNTER,
    'VCU1_COUNTER': FM_VCU1_COUNTER,
    'VCU2_COUNTER': FM_VCU2_COUNTER,
    'FL_TYRE_PRESSURE_SCF': FM_FL_TYRE_PRESSURE_SCF,
    'FR_TYRE_PRESSURE_SCF': FM_FR_TYRE_PRESSURE_SCF,
    'GEAR_ACTUAL_SCF': FM_GEAR_ACTUAL_SCF,
    'MASTER_CYL_PRESSURE_SCF': FM_MASTER_CYL_PRESSURE_SCF,
    'MOTOR_SPEED_SCF': FM_MOTOR_SPEED_SCF,
    'ODOMETER_SCF': FM_ODOMETER_SCF,
    'RL_TYRE_PRESSURE_SCF': FM_RL_TYRE_PRESSURE_SCF,
    'RR_TYRE_PRESSURE_SCF': FM_RR_TYRE_PRESSURE_SCF,
    'STEERING_ANGLE_SCF': FM_STEERING_ANGLE_SCF,
    'STEER_ANGLE_CMD_SCF': FM_STEER_ANGLE_CMD_SCF,
    'VEHICLE_SPEED_SCF': FM_VEHICLE_SPEED_SCF,
    'VEHICLE_STATE_SCF': FM_VEHICLE_STATE_SCF,
}


# ====================================================================================================
# Power, ECU and internal faults (158)
# Supply, VIN, variant code, bus-off, plant mode and every internal fault monitor (most share DTC
# 0x90 0x13 0x49, ECU internal), named <module>_<monitor>.
# ====================================================================================================
FM_ALGO_FRONT_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                            'monitor': 'OPSCSHMGR_F_OPS_FRNTALG_SUPPRESSED', 'req': 36070217,
                            'text': 'OPS Front Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_FRONT_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                   'monitor': 'OPSCSHMGR_F_OPS_FRNTALG_UNCONFIRMED_CRASH', 'req': 36070211,
                                   'text': 'OPS Front Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_PEDESTRIAN_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                                 'monitor': 'OPSCSHMGR_F_OPS_PEDALG_SUPPRESSED', 'req': 36070222,
                                 'text': ('OPS Pedestrian Algorithm Critical Error Detected '
                                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_ALGO_PEDESTRIAN_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                        'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                        'monitor': 'OPSCSHMGR_F_OPS_PEDALG_UNCONFIRMED_CRASH', 'req': 36070216,
                                        'text': ('OPS Pedestrian Algorithm Unconfirmed Crash '
                                                 '(FLTMONR_E_ECU_INTERNAL)')}
FM_ALGO_REAR_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                           'monitor': 'OPSCSHMGR_F_OPS_REALG_SUPPRESSED', 'req': 36070218,
                           'text': 'OPS Rear Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_REAR_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                  'monitor': 'OPSCSHMGR_F_OPS_REALG_UNCONFIRMED_CRASH', 'req': 36070212,
                                  'text': 'OPS Rear Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_ROLL_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                           'monitor': 'OPSCSHMGR_F_OPS_ROLLALG_SUPPRESSED', 'req': 36070221,
                           'text': 'OPS Roll Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_ROLL_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                  'monitor': 'OPSCSHMGR_F_OPS_ROLLALG_UNCONFIRMED_CRASH', 'req': 36070215,
                                  'text': 'OPS Roll Algorithm Unconfirmed Crash (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_SIDE_LEFT_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                                'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_LEFT_SUPPRESSED', 'req': 36070219,
                                'text': 'OPS Side Left Algorithm Critical Error Detected (FLTMONR_E_ECU_INTERNAL)'}
FM_ALGO_SIDE_LEFT_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                       'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                       'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_LEFT_UNCONFIRMED_CRASH', 'req': 36070213,
                                       'text': ('OPS Side Left Part Algorithm Unconfirmed Crash '
                                                '(FLTMONR_E_ECU_INTERNAL)')}
FM_ALGO_SIDE_RIGHT_SUPPRESSED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 0.0005; dematuration: 0.0005', 'latched': True,
                                 'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_RIGHT_SUPPRESSED', 'req': 36070220,
                                 'text': ('OPS Side Right Algorithm Critical Error Detected '
                                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_ALGO_SIDE_RIGHT_UNCONFIRMED_CRASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                        'timing': 'maturation: 0.0005; dematuration: NA', 'latched': True,
                                        'monitor': 'OPSCSHMGR_F_OPS_SIDEALG_RIGHT_UNCONFIRMED_CRASH',
                                        'req': 36070214,
                                        'text': ('OPS Side Right Part Algorithm Unconfirmed Crash '
                                                 '(FLTMONR_E_ECU_INTERNAL)')}
FM_ASIC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': ('maturation: 127 retries (NVM CRC not ok or NVM_Ready bit is not completed) 15 retries '
                        '(NVM USER CRC fails or NVM USER DATA from ASIC_NVM is different than the programmed NVM '
                        'USER DATA); dematuration: n/a'),
             'latched': True, 'monitor': 'ASICCTRL_F_ASIC_NVM_0', 'req': 36068941,
             'text': 'ASICCTRLL NVM Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
             'timing': ('maturation: 127 retries (NVM CRC not ok or NVM_Ready bit is not completed) 15 retries '
                        '(NVM USER CRC fails or NVM USER DATA from ASIC_NVM is different than the programmed NVM '
                        'USER DATA); dematuration: n/a'),
             'latched': True, 'monitor': 'ASICCTRL_F_ASIC_NVM_1', 'req': 36068951,
             'text': 'ASICCTRLL NVM Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_BACKGROUND_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 3.175; dematuration: n/a', 'latched': True,
                        'monitor': 'ASICCTRL_F_ASIC_BACKGROUND_0', 'req': 36068942,
                        'text': 'ASICCTRLL Background Monitor Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_BACKGROUND_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 3.175; dematuration: n/a', 'latched': True,
                        'monitor': 'ASICCTRL_F_ASIC_BACKGROUND_1', 'req': 36068952,
                        'text': 'ASICCTRLL Background Monitor Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_BIST_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                  'monitor': 'ASICCTRL_F_ASIC_BIST_0', 'req': 36068943,
                  'text': 'ASICCTRLL BIST Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_BIST_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                  'monitor': 'ASICCTRL_F_ASIC_BIST_1', 'req': 36068953,
                  'text': 'ASICCTRLL BIST Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_CLK_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 127 retries (IDLE); dematuration: n/a',
                 'latched': True, 'monitor': 'ASICCTRL_F_ASIC_CLK_0', 'req': 36068948,
                 'text': 'ASICCTRLL Either FLL or CLKERR Failure SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_CLK_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 127 retries (IDLE); dematuration: n/a',
                 'latched': True, 'monitor': 'ASICCTRL_F_ASIC_CLK_1', 'req': 36068958,
                 'text': 'ASICCTRLL Either FLL or CLKERR Failure SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_CONFIG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                    'monitor': 'ASICCTRL_F_ASIC_CONFG_0', 'req': 36068949,
                    'text': ('ASICCTRLL Either DEVICE_CTRL or CLK_CTRL config failure SB3_M '
                             '(FLTMONR_E_ECU_INTERNAL)')}
FM_ASIC_CONFIG_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                    'monitor': 'ASICCTRL_F_ASIC_CONFG_1', 'req': 36068959,
                    'text': ('ASICCTRLL Either DEVICE_CTRL or CLK_CTRL config failure SB3_S '
                             '(FLTMONR_E_ECU_INTERNAL)')}
FM_ASIC_SAFETY_ECHO_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.075; dematuration: n/a', 'latched': True,
                         'monitor': 'ASICCTRL_F_SAFETY_ECHO_0', 'req': 36068947,
                         'text': ('ASICCTRLL Safety Echo deployment is disabled in the ASIC SB3_M '
                                  '(FLTMONR_E_ECU_INTERNAL)')}
FM_ASIC_SAFETY_ECHO_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 0.075; dematuration: n/a', 'latched': True,
                         'monitor': 'ASICCTRL_F_SAFETY_ECHO_1', 'req': 36068957,
                         'text': ('ASICCTRLL Safety Echo deployment is disabled in the ASIC SB3_S '
                                  '(FLTMONR_E_ECU_INTERNAL)')}
FM_ASIC_SERIAL_NO_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                       'monitor': 'ASICCTRL_F_ASIC_SERIAL_NO_0', 'req': 36068946,
                       'text': 'ASICCTRLL ASIC Serial Number Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_SERIAL_NO_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                       'monitor': 'ASICCTRL_F_ASIC_SERIAL_NO_1', 'req': 36068956,
                       'text': 'ASICCTRLL ASIC Serial Number Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 0.0635 (IDLE) 3.175 (PDC, Drive); '
                            'dematuration: n/a'),
                 'latched': True, 'monitor': 'ASICCTRL_F_ASIC_SPI_0', 'req': 36068940,
                 'text': 'ASICCTRLL SPI Communication Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_SPI_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: immediate (Sb3Ex3AsicCtrlDrvr_Init) 0.0635 (IDLE) 3.175 (PDC, Drive); '
                            'dematuration: n/a'),
                 'latched': True, 'monitor': 'ASICCTRL_F_ASIC_SPI_1', 'req': 36068950,
                 'text': 'ASICCTRLL SPI Communication Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_SSM_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 127 retries (IDLE) 3.175 (PDC, Drive); dematuration: n/a', 'latched': True,
                 'monitor': 'ASICCTRL_F_ASIC_SSM_0', 'req': 36068944,
                 'text': 'ASICCTRLL ASIC SYSTEM STATE Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_SSM_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: 127 retries (IDLE) 3.175 (PDC, Drive); dematuration: n/a', 'latched': True,
                 'monitor': 'ASICCTRL_F_ASIC_SSM_1', 'req': 36068954,
                 'text': 'ASICCTRLL ASIC SYSTEM STATE Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_VERSION_ID_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                        'monitor': 'ASICCTRL_F_ASIC_VERSION_ID_0', 'req': 36068945,
                        'text': 'ASICCTRLL ASIC Veresion ID Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_ASIC_VERSION_ID_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 127 retries; dematuration: n/a', 'latched': True,
                        'monitor': 'ASICCTRL_F_ASIC_VERSION_ID_1', 'req': 36068955,
                        'text': 'ASICCTRLL ASIC Veresion ID Fault SB3_S (FLTMONR_E_ECU_INTERNAL)'}
FM_BATT_OVERVOLTAGE = {'dtc': '0x94 0x2A 0x17', 'qualify_ms': 3175, 'dequalify_ms': 3200, 'latched': False,
                       'monitor': 'SYSCHAR_F_PWR_BATT_OVER', 'req': 36069748,
                       'text': 'Battery Overvoltage (FLTMONR_E_BATTERY_VOLTAGE_HIGH)'}
FM_BATT_UNDERVOLTAGE = {'dtc': '0x94 0x2A 0x16', 'qualify_ms': 3175, 'dequalify_ms': 3200, 'latched': False,
                        'monitor': 'SYSCHAR_F_PWR_BATT_UNDER', 'req': 36069747,
                        'text': 'Battery Undervoltage (FLTMONR_E_BATTERY_VOLTAGE_LOW)'}
FM_CYBER_HSM_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.5; dematuration: n/a', 'latched': True,
                        'monitor': 'CYBER_F_HSM_TIMEOUT', 'req': 36070301,
                        'text': 'The maximum waiting time for the HSM response. (FLTMONR_E_ECU_INTERNAL)'}
FM_DEPLOY_OPS_EVENT_WITHOUT_SAFING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                      'timing': 'maturation: 0.04; dematuration: NA', 'latched': True,
                                      'monitor': 'DPLMTMGR_F_OPS_EVENT_WITHOUT_SAFING', 'req': 36070295,
                                      'text': 'Crash event occured without safing (FLTMONR_E_ECU_INTERNAL)'}
FM_DEVICE_CFG_CFG_NO_STEER_WHEEL_POS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                        'timing': 'maturation: 1; dematuration: 1', 'latched': False,
                                        'monitor': 'DEVICECFGMGR_F_CFG_NO_STEER_WHEEL_POS', 'req': 36070198,
                                        'text': ('Steering Wheel Position not received (NVM read) '
                                                 '(FLTMONR_E_ECU_INTERNAL)')}
FM_E2E_PIB_COUNTER = {'dtc': '0x90 0x13 0x49', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': True,
                      'monitor': 'F_E2E_PIB_ALIVE_COUNTER', 'req': 36069750,
                      'text': ('Alive counter sync errors due to high delta difference between stored value and '
                               'received value of E2E alive counter (FLTMONR_E_ECU_INTERNAL)')}
FM_ECU_CONFIG_ERROR = {'dtc': '0x92 0x02 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 0.0025; dematuration: N/A', 'latched': False,
                       'monitor': 'ECU_CONFIGURATION_ERROR', 'req': 36070324,
                       'text': 'ECU Configuration Error related fault (FLTMONR_E_ECU_CONFIGURATION_ERROR)'}
FM_EDR_LOCKED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: N/A; dematuration: N/A', 'latched': False,
                 'monitor': 'RSTEDR_F_EDR_LOCKED_EVENT', 'req': 36070256,
                 'text': 'A locked Event Data Record is located in NVM (FLTMONR_NO_DTC_EVENT)'}
FM_EVENT_TRAP = {'dtc': '0xFF 0xFF 0xFF', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Qualification time; dematuration: Infinite', 'latched': False,
                 'monitor': 'FLTMONR_E_EVENT_0_TRAP', 'req': 36068900, 'text': '(DEM_EVENT_INVALID)'}
FM_EXT_FLASH_BROKEN_POLLING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: Calibration specific; dematuration: NA', 'latched': True,
                               'monitor': 'EXTFLS_F_BROKEN_POLLING', 'req': 36070156,
                               'text': 'Job timeout nonrecoverable (FLTMONR_E_ECU_INTERNAL)'}
FM_EXT_FLASH_COMPARE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: immediate; dematuration: immediate', 'latched': True,
                        'monitor': 'EXTFLS_F_COMPARE', 'req': 36070158,
                        'text': 'Write Integrity check failed (if check enabled) (FLTMONR_E_ECU_INTERNAL)'}
FM_EXT_FLASH_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                         'monitor': 'EXTFLS_F_INTERNAL', 'req': 36070155,
                         'text': ('Init write capability test failed, device busy at power on, SPI request '
                                  'rejected (FLTMONR_E_ECU_INTERNAL)')}
FM_EXT_FLASH_INVALID_DEVICE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                               'monitor': 'EXTFLS_F_INVALID_DEVICE', 'req': 36070154,
                               'text': 'Init wrong device identification (calib vs read) (FLTMONR_E_ECU_INTERNAL)'}
FM_EXT_FLASH_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': ('maturation: 0.001 (Write Timeout) 0.3 (Sector Erase Timeout) 0.5 (Block Erase '
                                   'Timeout) 24 (Chip Erase Timeout); dematuration: immediate'),
                        'latched': True, 'monitor': 'EXTFLS_F_TIMEOUT', 'req': 36070157,
                        'text': 'Job timeout recoverable (write/erase) (FLTMONR_E_ECU_INTERNAL)'}
FM_FD_BUS_OFF = {'dtc': '0xD2 0x06 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Immediate; dematuration: Busoff fast recovery: 100 ms Bus off Slow '
                            'recovery: 500 ms'),
                 'latched': False, 'monitor': 'CAN_BUS_OFF_FAULT', 'req': 36070326,
                 'text': 'SRS CAN Bus off fault (FLTMONR_E_CAN_BUS_OFF_FAULT)'}
FM_FEE_ADMIN_BLK_NOT_FOUND = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                              'monitor': 'FEE_F_NVM_ADMIN_BLK_NOT_FOUND', 'req': 36070201,
                              'text': 'Header blocks are not programed (FLTMONR_E_ECU_INTERNAL)'}
FM_FEE_CORRUPTED_FLASH = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                          'monitor': 'FEE_F_NVM_CORRUPTED_FLASH', 'req': 36070202,
                          'text': 'Data sector is corrupted (ECC failure) (FLTMONR_E_ECU_INTERNAL)'}
FM_FEE_ENDURANCE_LIMIT_EXCEED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                 'monitor': 'FEE_F_NVM_ENDURANCE_LIMIT_EXCEED', 'req': 36070204,
                                 'text': 'Flash Programming limit exceeded failure (FLTMONR_E_ECU_INTERNAL)'}
FM_FEE_ERASE_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0015; dematuration: Successful "Erase" Routine', 'latched': True,
                        'monitor': 'FEE_F_NVM_ERASE_FAILURE', 'req': 36070205,
                        'text': 'Flash Erase Block failure (FLTMONR_E_ECU_INTERNAL)'}
FM_FEE_OUT_OF_OPERATING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0015; dematuration: NA', 'latched': True,
                           'monitor': 'FEE_F_NVM_OUT_OF_OPERATING', 'req': 36070203,
                           'text': 'Word Line corruption (3 consecutive attempts) (FLTMONR_E_ECU_INTERNAL)'}
FM_FEE_OUT_OF_ORDER = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                       'monitor': 'FEE_F_NVM_OUT_OF_ORDER', 'req': 36070200,
                       'text': ('Fee general failure (multiple operations e.g. WL failures) '
                                '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_ENTER_PAGE_MODE_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                     'monitor': 'FLS_F_MEM_ENTER_PAGE_MODE_SEQUENCE', 'req': 36070137,
                                     'text': 'Wrong sequence order (access operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ENTER_PAGE_MODE_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                    'timing': 'maturation: 0.00001; dematuration: NA', 'latched': True,
                                    'monitor': 'FLS_F_MEM_ENTER_PAGE_MODE_TIMEOUT', 'req': 36070138,
                                    'text': ('Response was not acknowledged (access operations) '
                                             '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_ERASE_FINISH_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 4.233; dematuration: NA', 'latched': True,
                                 'monitor': 'FLS_F_MEM_ERASE_FINISH_TIMEOUT', 'req': 36070152,
                                 'text': ('Response was not acknowledged (erase operations) '
                                          '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_ERASE_PROTECTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'FLS_F_MEM_ERASE_PROTECTION', 'req': 36070144,
                             'text': ('Operations on protected flash sectors (erase operation) '
                                      '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_ERASE_RESUME_PROTECTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                    'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                    'monitor': 'FLS_F_MEM_ERASE_RESUME_PROTECTION', 'req': 36070151,
                                    'text': ('Operations on protected flash sectors (resume erase operation) '
                                             '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_ERASE_RESUME_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                  'monitor': 'FLS_F_MEM_ERASE_RESUME_SEQUENCE', 'req': 36070150,
                                  'text': 'Wrong sequence order (suspend operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ERASE_RESUME_WRONG_STATE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                     'monitor': 'FLS_F_MEM_ERASE_RESUME_WRONG_DRIVER_STATE', 'req': 36070149,
                                     'text': 'Other operation ongoing (Start/Suspend) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ERASE_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                           'monitor': 'FLS_F_MEM_ERASE_SEQUENCE', 'req': 36070143,
                           'text': 'Wrong sequence order (erase operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ERASE_START_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 0.00001; dematuration: NA', 'latched': True,
                                'monitor': 'FLS_F_MEM_ERASE_START_TIMEOUT', 'req': 36070145,
                                'text': 'Response was not acknowledged (erase operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ERASE_START_WRONG_STATE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                    'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                    'monitor': 'FLS_F_MEM_ERASE_START_WRONG_DRIVER_STATE', 'req': 36070142,
                                    'text': 'Other operation ongoing (Suspend/Resume) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ERASE_SUSPEND_ERROR_FLAG = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                     'monitor': 'FLS_F_MEM_ERASE_SUSPEND_ERROR_FLAG', 'req': 36070147,
                                     'text': 'Access failure (erase suspend operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_ERASE_SUSPEND_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 0.000375; dematuration: NA', 'latched': True,
                                  'monitor': 'FLS_F_MEM_ERASE_SUSPEND_TIMEOUT', 'req': 36070148,
                                  'text': ('Response was not acknowledged (suspend operations) '
                                           '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_ERASE_SUSPEND_WRONG_STATE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                      'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                      'monitor': 'FLS_F_MEM_ERASE_SUSPEND_WRONG_DRIVER_STATE', 'req': 36070146,
                                      'text': 'Other operation ongoing (Start/Resume) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_MICROCODE_OPERATION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                'monitor': 'FLS_F_MEM_MICROCODE_OPERATION', 'req': 36070153,
                                'text': ('Flash microcode failure (read/write/suspend/resume operations) '
                                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_WRITE_PAGE_PROTECTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                  'monitor': 'FLS_F_MEM_WRITE_PAGE_PROTECTION', 'req': 36070140,
                                  'text': ('Operations on protected flash sectors (write operation) '
                                           '(FLTMONR_E_ECU_INTERNAL)')}
FM_FLASH_WRITE_PAGE_SEQUENCE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                'monitor': 'FLS_F_MEM_WRITE_PAGE_SEQUENCE', 'req': 36070139,
                                'text': 'Wrong sequence order (write operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_FLASH_WRITE_PAGE_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.000426; dematuration: NA', 'latched': True,
                               'monitor': 'FLS_F_MEM_WRITE_PAGE_TIMEOUT', 'req': 36070141,
                               'text': 'Response was not acknowledged (write operations) (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_ASIC_ADC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                     'monitor': 'HSS_F_ASIC_ADC_0', 'req': 36069158,
                     'text': 'HSS ADC Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_ASIC_ADC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                     'monitor': 'HSS_F_ASIC_ADC_1', 'req': 36069159,
                     'text': 'HSS ADC Fault HSS1 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                     'monitor': 'HSS_F_ASIC_SPI_0', 'req': 36069156,
                     'text': 'HSS Spi Communication Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_ASIC_SPI_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                     'monitor': 'HSS_F_ASIC_SPI_1', 'req': 36069157,
                     'text': 'HSS Spi Communication Fault HSS1 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_DIODE_SHORT_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                        'monitor': 'HSS_F_DIODE_SHORT_0', 'req': 36069169,
                        'text': 'ER Diode is Shorted SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_DRIVE_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: PDC: 4 consecutive retries DRIVE: 2; dematuration: PDC: n/a DRIVE: 4',
                  'latched': False, 'monitor': 'HSS_F_DRIVE_0', 'req': 36069162,
                  'text': 'HSS Failed During DRIVE HSS0 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_DRIVE_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: PDC: 3 consecutive retries / DRIVE: 2; dematuration: PDC: n/a DRIVE: 4',
                  'latched': False, 'monitor': 'HSS_F_DRIVE_1', 'req': 36069163,
                  'text': 'HSS Failed During DRIVE HSS1 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_ER_DIODE_OPEN_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                          'monitor': 'HSS_F_ER_DIODE_OPEN_0', 'req': 36069166,
                          'text': 'HSS ER Diode Open Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_ER_DIODE_OPEN_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                          'monitor': 'HSS_F_ER_DIODE_OPEN_1', 'req': 36069167,
                          'text': 'HSS ER Diode Open Fault HSS (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_PDC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                'monitor': 'HSS_F_PDC_0', 'req': 36069160,
                'text': 'HSS Failed During PDC HSS0 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_PDC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                'monitor': 'HSS_F_PDC_1', 'req': 36069161,
                'text': 'HSS Failed During PDC HSS1 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_VBAT_DIODE_OPEN_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 4 consecutive retries; dematuration: n/a', 'latched': False,
                            'monitor': 'HSS_F_VBAT_DIODE_OPEN_0', 'req': 36069164,
                            'text': 'HSS VBAT Diode Open Fault HSS0 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_VBAT_DIODE_OPEN_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                            'monitor': 'HSS_F_VBAT_DIODE_OPEN_1', 'req': 36069165,
                            'text': 'HSS VBAT Diode Open Fault HSS1 (FLTMONR_E_ECU_INTERNAL)'}
FM_HSS_XCONN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: 3 consecutive retries; dematuration: n/a', 'latched': False,
                'monitor': 'HSS_F_XCONN', 'req': 36069168,
                'text': 'HSS Both HS0/HSS1 Switches Are Cross Connexted (FLTMONR_E_ECU_INTERNAL)'}
FM_HS_BUS_OFF = {'dtc': '0xD2 0x71 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': ('maturation: Immediate; dematuration: Busoff fast recovery: 100 ms Bus off Slow '
                            'recovery: 500 ms'),
                 'latched': False, 'monitor': 'HSCAN_BUS_OFF_FAULT', 'req': 36070372,
                 'text': 'SRS HSCAN Bus off fault (FLTMONR_E_HSCAN_BUS_OFF_FAULT)'}
FM_MANUFACTURING_DATA_MISSING = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: N/A; dematuration: N/A', 'latched': True,
                                 'monitor': 'MANUDATA_F_MANUFACTURING_DATA_MISSING', 'req': 36070306,
                                 'text': 'Manufacturing Data is missing (FLTMONR_E_ECU_INTERNAL)'}
FM_MCAL_ADC_NOT_OPERATIONAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                               'monitor': 'MCAL_F_MCAL_ADC_NOT_OPERATIONAL', 'req': 36070127,
                               'text': 'ADC is Not Operational (FLTMONR_E_ECU_INTERNAL)'}
FM_MCAL_SPI_POLLING_TIMEOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                               'monitor': 'MCAL_F_MCAL_SPI_POLLING_TIMEOUT', 'req': 36070126,
                               'text': 'SPI pooling timeout failure (FLTMONR_E_ECU_INTERNAL)'}
FM_MCAL_SPI_RECEIVE_FIFO_OVERFLOW = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                     'monitor': 'MCAL_F_MCAL_SPI_RECEIVE_FIFO_OVERFLOW', 'req': 36070125,
                                     'text': 'SPI reception failure (overflow) (FLTMONR_E_ECU_INTERNAL)'}
FM_MCAL_SPI_TRANSMIT_BUSY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'MCAL_F_MCAL_SPI_TRANSMIT_BUSY', 'req': 36070124,
                             'text': 'SPI transmission failure (busy) (FLTMONR_E_ECU_INTERNAL)'}
FM_MCU_LBIST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: Immediate; dematuration: n/a', 'latched': True,
                'monitor': 'F_MCU_PRERUN_TEST_FAILED_LBIST', 'req': 36070302,
                'text': 'Fault to report the identified MCU logic path Failures. (FLTMONR_E_ECU_INTERNAL)'}
FM_MCU_MBIST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: not given; dematuration: n/a', 'latched': True,
                'monitor': 'F_MCU_PRERUN_TEST_FAILED_MBIST', 'req': 36070304,
                'text': ('Fault to indicate the Failures detected during the last MBIST test run. '
                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_MCU_MONBIST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: not given; dematuration: n/a', 'latched': True,
                  'monitor': 'F_MCU_PRERUN_TEST_FAILED_MONBIST', 'req': 36070303,
                  'text': ('Fault to indicate the Failures detected during the last MONBIST test run. '
                           '(FLTMONR_E_ECU_INTERNAL)')}
FM_NVM_BLOCK_BLOCK_INTEGRITY_FAILED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                       'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                       'monitor': 'NVMBLKMGR_F_BLOCK_INTEGRITY_FAILED', 'req': 36070210,
                                       'text': 'NVM Block Manager Integrity check Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_NVM_INTEGRITY = {'dtc': '0x90 0x13 0x49', 'qualify_counts': 60, 'dequalify_counts': 10, 'latched': True,
                    'monitor': 'NVM_F_NVM_INTEGRITY_FAILED', 'req': 36070209,
                    'text': 'Stored CRC does not match the computed CRC for the user data (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_ROLL_MUTED_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: N/A; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_ROLL_MUTED_0', 'req': 36070253,
                       'text': 'OPS ARS invalid Roll data Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_PLANT_MODE = {'dtc': '0x92 0x00 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: immediate/less than 1 sec; dematuration: 30s', 'latched': False,
                 'monitor': 'ECU_IN_PLANT_MODE', 'req': 36070328,
                 'text': 'ECU in plant mode (FLTMONR_E_ECU_IN_PLANT_MODE)'}
FM_PWR_ASIC_ADC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_ADC_0',
                     'req': 36069718,
                     'text': "Any SB3_M ADC Read that doesn't contain new data (FLTMONR_E_ECU_INTERNAL)"}
FM_PWR_ASIC_ADC_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_ADC_1',
                     'req': 36069736,
                     'text': "Any EX3_0 ADC Read that doesn't contain new data (FLTMONR_E_ECU_INTERNAL)"}
FM_PWR_ASIC_CONFIG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.1; dematuration: n/a', 'latched': True,
                        'monitor': 'PWR_F_ASIC_CONFIG_0', 'req': 36070278,
                        'text': 'PWR ASIC Configuration Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ASIC_CONFIG_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.1; dematuration: n/a', 'latched': True,
                        'monitor': 'PWR_F_ASIC_CONFIG_1', 'req': 36070287,
                        'text': 'PWR ASIC Configuration Fault EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_SPI_0',
                     'req': 36069717,
                     'text': 'PWR ASIC SPI Communication Fault (Parity error) SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ASIC_SPI_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.2; dematuration: n/a', 'latched': True, 'monitor': 'PWR_F_ASIC_SPI_1',
                     'req': 36069735,
                     'text': 'PWR ASIC SPI Communication Fault (Parity error) EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_CRITICAL_CONDITION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.0005; dematuration: n/a', 'latched': True,
                               'monitor': 'PWR_F_CRITICAL_CONDITION_0', 'req': 36070284,
                               'text': 'Power Critical Error Condition present SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ERBST_DIODE_LOST_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.025; dematuration: 0.025', 'latched': True,
                             'monitor': 'PWR_F_ERBST_DIODE_LOST_0', 'req': 36069734,
                             'text': 'ER Boost Diode Lost SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ERBST_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 1.075; dematuration: 0.025', 'latched': True,
                       'monitor': 'PWR_F_ERBST_TOO_HIGH_0', 'req': 36069720,
                       'text': 'ERBST is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ERBST_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 1.075; dematuration: 0.025', 'latched': True,
                      'monitor': 'PWR_F_ERBST_TOO_LOW_0', 'req': 36069719,
                      'text': 'ERBST is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_CAPACITANCE_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 15 Drive; dematuration: 5', 'latched': True,
                               'monitor': 'PWR_F_ER_CAPACITANCE_TOO_LOW_0', 'req': 36069730,
                               'text': 'ER Capacitance is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_CAPACITANCE_TEST_FAILED_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                       'timing': 'maturation: 15; dematuration: 5', 'latched': True,
                                       'monitor': 'PWR_F_ER_CAPACITANCE_TEST_FAILED_0', 'req': 36070286,
                                       'text': ('ER Capacitance value cannot be computed SB3_M. '
                                                '(FLTMONR_E_ECU_INTERNAL)')}
FM_PWR_ER_CAP_OPEN_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.05 PDC 3 to 8 Drive; dematuration: NA PDC 1 Drive',
                        'latched': True, 'monitor': 'PWR_F_ER_CAP_OPEN_0', 'req': 36069727,
                        'text': 'ER CAP is Open SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_CHARGE_SWITCH_SHORTED_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 0.075; dematuration: 0.025', 'latched': True,
                                     'monitor': 'PWR_F_ER_CHARGE_SWITCH_SHORTED_0', 'req': 36070281,
                                     'text': 'ER Charge Switch shorted SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_CHARGE_TIME_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 8.3; dematuration: n/a', 'latched': True,
                           'monitor': 'PWR_F_ER_CHARGE_TIME_0', 'req': 36070282,
                           'text': 'ER Charge Up Time is Exceeded SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_ESR_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 15 Drive; dematuration: 5', 'latched': False,
                        'monitor': 'PWR_F_ER_ESR_TOO_HIGH_0', 'req': 36069731,
                        'text': 'ER ESR is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_SHORT_GND_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': ('maturation: 0.06 to 0.08; dematuration: 0.06 to 0.08 when failure is absent '
                                    'just before the test 0.08 to 2 when failure is absent just after the test'),
                         'latched': True, 'monitor': 'PWR_F_ER_SHORT_GND_0', 'req': 36070283,
                         'text': 'ER Cap is Shorted to GND SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_SWITCH_NOT_OPERATIONAL_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                      'timing': 'maturation: 0.15; dematuration: n/a', 'latched': True,
                                      'monitor': 'PWR_F_ER_SWITCH_NOT_OPERATIONAL_0', 'req': 36070280,
                                      'text': 'ER Switch Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_VOLTAGE_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.2; dematuration: 0.2', 'latched': True,
                            'monitor': 'PWR_F_ER_VOLTAGE_TOO_HIGH_0', 'req': 36069729,
                            'text': 'ER Voltage is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_ER_VOLTAGE_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.2; dematuration: 0.2', 'latched': True,
                           'monitor': 'PWR_F_ER_VOLTAGE_TOO_LOW_0', 'req': 36069728,
                           'text': 'ER Voltage is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_EX3_VIN_DISCONNECTED_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                                 'monitor': 'PWR_F_EX3_VIN_DISCONNECTED_1', 'req': 36069740,
                                 'text': 'VIN Disconnected EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_GROUND_LOSS_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.075; dematuration: 0.05', 'latched': True,
                        'monitor': 'PWR_F_GROUND_LOSS_0', 'req': 36069732,
                        'text': 'Ground Loss(VCC, SatBuck and ERBoost Ground Loss) SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_REDUNDANT_VER_FAILURE_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                                  'monitor': 'PWR_F_REDUNDANT_VER_FAILURE_0', 'req': 36069733,
                                  'text': ('Redundant VER (PWR / DCS) is inconsistent SB3_M '
                                           '(FLTMONR_E_ECU_INTERNAL)')}
FM_PWR_SATBUCK_HIGH_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                         'monitor': 'PWR_F_SATBUCK_TOO_HIGH_0', 'req': 36069723,
                         'text': 'SATBUCK is too high SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_SATBUCK_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                        'monitor': 'PWR_F_SATBUCK_TOO_LOW_0', 'req': 36069722,
                        'text': 'SATBUCK is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_SYSBST_DIODE_SHORT_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.15; dematuration: n/a', 'latched': True,
                               'monitor': 'PWR_F_SYSBST_DIODE_SHORT_0', 'req': 36070279,
                               'text': 'SYSBST Diode is in Short_Circuit mode SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_SYSBST_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': True,
                       'monitor': 'PWR_F_SYSBST_TOO_LOW_0', 'req': 36069721,
                       'text': 'SYSBST is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_SYSBST_LOW_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                       'monitor': 'PWR_F_SYSBST_TOO_LOW_1', 'req': 36069737,
                       'text': 'SYSBST is too low EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_V5_OUT_RANGE_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                         'monitor': 'PWR_F_V5_OUT_RANGE_0', 'req': 36069724,
                         'text': 'V5 Supply is Out Of Range SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_VSYNC_LOW_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                      'monitor': 'PWR_F_VSYNC_TOO_LOW_0', 'req': 36069725,
                      'text': 'VSYNC is too low SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_PWR_VSYNC_LOW_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: 1.075; dematuration: 1.075', 'latched': False,
                      'monitor': 'PWR_F_VSYNC_TOO_LOW_1', 'req': 36069738,
                      'text': 'VSYNC is too low EX3_0 (FLTMONR_E_ECU_INTERNAL)'}
FM_RESET_UNEXPECTED_RESET = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: Immediate; dematuration: n/a', 'latched': True,
                             'monitor': 'RESETDRVR_F_ECU_UNEXPECTED_RESET', 'req': 36070289,
                             'text': 'Unexpected reset occured (FLTMONR_E_ECU_INTERNAL)'}
FM_SAFING_ARMING_LONG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 30; dematuration: n/a', 'latched': True,
                           'monitor': 'SAF_F_ARMING_TOO_LONG_0', 'req': 36069710,
                           'text': 'SAFING System is armed for too long SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_SAFING_ASIC_CC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                       'monitor': 'SAF_F_ASIC_CC_0', 'req': 36069706,
                       'text': 'SAFING ASIC CC (Compare Complete) Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_SAFING_ASIC_CONFIG_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                           'monitor': 'SAF_F_ASIC_CONFIG_0', 'req': 36069707,
                           'text': 'SAFING Programming ASIC registers failed SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_SAFING_ASIC_CONFIG_ENABLES_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                   'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                                   'monitor': 'SAF_F_ASIC_CONFIG_ENABLES_0', 'req': 36069709,
                                   'text': ('SAFING Programming ASIC registers failed (Enable registers) SB3_M '
                                            '(FLTMONR_E_ECU_INTERNAL)')}
FM_SAFING_ASIC_CONFIG_FOC_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                               'monitor': 'SAF_F_ASIC_CONFIG_FOC_0', 'req': 36069708,
                               'text': ('SAFING Programming ASIC registers failed (FOC registers) SB3_M '
                                        '(FLTMONR_E_ECU_INTERNAL)')}
FM_SAFING_ASIC_INTERNAL_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                             'monitor': 'SAF_F_ASIC_INTERNAL_0', 'req': 36069713,
                             'text': ('SAFING ASIC Internal faut for incorrect communications (SA and D bits not '
                                      'correct in response) SB3_M (FLTMONR_E_ECU_INTERNAL)')}
FM_SAFING_ASIC_SPI_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': True,
                        'monitor': 'SAF_F_ASIC_SPI_0', 'req': 36069705,
                        'text': 'SAFING ASIC SPI Communication Fault SB3_M (FLTMONR_E_ECU_INTERNAL)'}
FM_SAFING_SNOOPING_SB3_EX3_TEST_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                     'timing': 'maturation: 0.0015; dematuration: n/a', 'latched': False,
                                     'monitor': 'SAF_F_SNOOPING_SB3_EX3_TEST_0', 'req': 36069712,
                                     'text': ('SAFING Snoop Test betweeen SB3 and EX3 Failed SB3_M '
                                              '(FLTMONR_E_ECU_INTERNAL)')}
FM_SCRAP_DEPLOYED = {'dtc': '0x92 0x13 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                     'monitor': 'SCRAPMGR_F_SCRAP_DEPLOYED_BY_SCRAP', 'req': 36073808,
                     'text': ('At least one loop was deployed by scrap '
                              '(FLTMONR_E_LOOP_ENABLED_DUE_TO_VEHICLE_SCRAP)')}
FM_SCRAP_ENTERED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                    'monitor': 'SCRAPMGR_F_SCRAP_ENTERED_SCRAP', 'req': 36070208,
                    'text': 'Scrap was entered at least once during ECU lifetime (FLTMONR_E_ECU_INTERNAL)'}
FM_SMU_ALARM = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': 'maturation: not given; dematuration: n/a', 'latched': True,
                'monitor': 'F_SMU_ALARM_OCCURRED', 'req': 36070305,
                'text': ('Fault to report that atleast one SMU_Alarm was active in the last Reset_Cycle which had '
                         'the NMI reaction. (FLTMONR_E_ECU_INTERNAL)')}
FM_SYS_CFG_BLOCK_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.001; dematuration: NA', 'latched': True,
                            'monitor': 'SYSCHAR_F_ECU_CFG_BLOCK_FAILURE', 'req': 36070292,
                            'text': ('System Configuration Monitor Failure (Memory corruption) '
                                     '(FLTMONR_E_ECU_INTERNAL)')}
FM_SYS_CONTROL_SHUTDOWN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.001; dematuration: NA', 'latched': True,
                           'monitor': 'SYSCHAR_F_ECU_CONTROL_SHUTDOWN', 'req': 36070290,
                           'text': 'Controlled Shutdown Monitor Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_SYS_MANUFACTURING_MODE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                             'monitor': 'SYSCHAR_F_ECU_MANUFACTURING_MODE', 'req': 36070294,
                             'text': 'ECU is in manufacturing mode (FLTMONR_E_ECU_INTERNAL)'}
FM_SYS_MODE_POSTRUN_POWER_CONDITIONS = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                        'timing': 'maturation: 30; dematuration: NA', 'latched': True,
                                        'monitor': 'SYSMODMGR_F_ECU_POSTRUN_POWER_CONDITIONS', 'req': 36070297,
                                        'text': 'POST_RUN state time exceeded (FLTMONR_E_ECU_INTERNAL)'}
FM_SYS_MODE_SHUTDOWN_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: On event, not time based.; dematuration: On event, not '
                                           'time based.'),
                                'latched': True, 'monitor': 'SYSMODMGR_F_ECU_SHUTDOWN_FAILURE', 'req': 36070298,
                                'text': 'Shutdown Failure module can not shutdown (FLTMONR_E_ECU_INTERNAL)'}
FM_SYS_PHASE_OF_LIFE_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                'monitor': 'SYSCHAR_F_ECU_PHASE_OF_LIFE_FAILURE', 'req': 36070293,
                                'text': ('Mismatch between the two NVM blocks storing the ECU phase of life OR IP '
                                         'cals (IP and Algo Var 3 in SC2 case) not present while in Manufacturing '
                                         '(FLTMONR_E_ECU_INTERNAL)')}
FM_SYS_PROVEOUT_TIME_FAILURE = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 1; dematuration: 1', 'latched': True,
                                'monitor': 'SYSCHAR_F_ECU_PROVEOUT_TIME_FAILURE', 'req': 36070291,
                                'text': 'Proveout Monitor Failure (FLTMONR_E_ECU_INTERNAL)'}
FM_TASK_STACK_LOW = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.075; dematuration: 0.075', 'latched': True,
                     'monitor': 'TASKMONR_F_TASK_STACK_TOO_LOW', 'req': 36069704,
                     'text': 'Any monitored stack is less than configurable minimum (FLTMONR_E_ECU_INTERNAL)'}
FM_TASK_UNDERRUN = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                    'monitor': 'TASKMONR_F_TASK_UNDERRUN', 'req': 36070199,
                    'text': 'Task did not run (FLTMONR_E_ECU_INTERNAL)'}
FM_TRAP_EVENT_OCCURRED = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                          'monitor': 'TRAPSMGR_F_TRAP_EVENT_OCCURRED', 'req': 36070206,
                          'text': 'SW event trap (FLTMONR_E_ECU_INTERNAL)'}
FM_TRAP_UNEXPECTED_EXCEPTION = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: 1; dematuration: NA', 'latched': True,
                                'monitor': 'TRAPSMGR_F_TRAP_UNEXPECTED_EXCEPTION', 'req': 36070207,
                                'text': 'SW unexpected exception (FLTMONR_E_ECU_INTERNAL)'}
FM_UNDERSTRIKE_CRASH = {'dtc': '0x92 0x52 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: Immediate', 'latched': True,
                        'monitor': 'UNDERSTRIKE_CRASH_EVENT', 'req': 36070390,
                        'text': 'UnderStrike Crash Event (FLTMONR_E_CRASH_DETECT_UNDERSTRIKE)'}
FM_VARIANT_CODE_ERROR = {'dtc': '0xD5 0x06 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': ('maturation: Based on network management Identifiers; dematuration: Based on '
                                    'network management Identifiers'),
                         'latched': False, 'monitor': 'SRS_VARIANT_CODE_ERROR', 'req': 36070329,
                         'text': 'Variant Code Error (FLTMONR_E_SRS_VARIANT_CODE_ERROR)'}
FM_VIN_MISMATCH = {'dtc': '0xD3 0x06 0x00', 'qualify_ms': 6500, 'dequalify_ms': 3500, 'latched': True,
                   'monitor': 'VIN_MISMATCH_ERROR', 'req': 36070325,
                   'text': 'SRS VIN Mismatch (FLTMONR_E_VIN_MISMATCH_ERROR)'}
FM_WATCHDOG_ASIC_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 0.0015; dematuration: 0.0015', 'latched': True,
                             'monitor': 'WDG_F_ASIC_INTERNAL', 'req': 36069155,
                             'text': 'Watchdog internal fault (FLTMONR_E_ECU_INTERNAL)'}
FM_WATCHDOG_ASIC_LOCKOUT = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 0.0035; dematuration: 0.0035', 'latched': True,
                            'monitor': 'WDG_F_ASIC_LOCKOUT', 'req': 36069153,
                            'text': 'External Watchdog LO Test Failed (TBU) (FLTMONR_E_ECU_INTERNAL)'}
FM_WATCHDOG_ASIC_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.0635; dematuration: 0.064', 'latched': True,
                        'monitor': 'WDG_F_ASIC_SPI', 'req': 36069154,
                        'text': 'External Watchdog SPI Test Failed (TBU) (FLTMONR_E_ECU_INTERNAL)'}
FM_WATCHDOG_TEST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': 'maturation: Immediate; dematuration: n/a', 'latched': True,
                    'monitor': 'WDG_F_WATCHDOG_TEST', 'req': 36070128,
                    'text': 'External Watchdog Test Failed (FLTMONR_E_ECU_INTERNAL)'}

SYSTEM_FAULTS = {
    'ALGO_FRONT_SUPPRESSED': FM_ALGO_FRONT_SUPPRESSED,
    'ALGO_FRONT_UNCONFIRMED_CRASH': FM_ALGO_FRONT_UNCONFIRMED_CRASH,
    'ALGO_PEDESTRIAN_SUPPRESSED': FM_ALGO_PEDESTRIAN_SUPPRESSED,
    'ALGO_PEDESTRIAN_UNCONFIRMED_CRASH': FM_ALGO_PEDESTRIAN_UNCONFIRMED_CRASH,
    'ALGO_REAR_SUPPRESSED': FM_ALGO_REAR_SUPPRESSED,
    'ALGO_REAR_UNCONFIRMED_CRASH': FM_ALGO_REAR_UNCONFIRMED_CRASH,
    'ALGO_ROLL_SUPPRESSED': FM_ALGO_ROLL_SUPPRESSED,
    'ALGO_ROLL_UNCONFIRMED_CRASH': FM_ALGO_ROLL_UNCONFIRMED_CRASH,
    'ALGO_SIDE_LEFT_SUPPRESSED': FM_ALGO_SIDE_LEFT_SUPPRESSED,
    'ALGO_SIDE_LEFT_UNCONFIRMED_CRASH': FM_ALGO_SIDE_LEFT_UNCONFIRMED_CRASH,
    'ALGO_SIDE_RIGHT_SUPPRESSED': FM_ALGO_SIDE_RIGHT_SUPPRESSED,
    'ALGO_SIDE_RIGHT_UNCONFIRMED_CRASH': FM_ALGO_SIDE_RIGHT_UNCONFIRMED_CRASH,
    'ASIC_0': FM_ASIC_0,
    'ASIC_1': FM_ASIC_1,
    'ASIC_BACKGROUND_0': FM_ASIC_BACKGROUND_0,
    'ASIC_BACKGROUND_1': FM_ASIC_BACKGROUND_1,
    'ASIC_BIST_0': FM_ASIC_BIST_0,
    'ASIC_BIST_1': FM_ASIC_BIST_1,
    'ASIC_CLK_0': FM_ASIC_CLK_0,
    'ASIC_CLK_1': FM_ASIC_CLK_1,
    'ASIC_CONFIG_0': FM_ASIC_CONFIG_0,
    'ASIC_CONFIG_1': FM_ASIC_CONFIG_1,
    'ASIC_SAFETY_ECHO_0': FM_ASIC_SAFETY_ECHO_0,
    'ASIC_SAFETY_ECHO_1': FM_ASIC_SAFETY_ECHO_1,
    'ASIC_SERIAL_NO_0': FM_ASIC_SERIAL_NO_0,
    'ASIC_SERIAL_NO_1': FM_ASIC_SERIAL_NO_1,
    'ASIC_SPI_0': FM_ASIC_SPI_0,
    'ASIC_SPI_1': FM_ASIC_SPI_1,
    'ASIC_SSM_0': FM_ASIC_SSM_0,
    'ASIC_SSM_1': FM_ASIC_SSM_1,
    'ASIC_VERSION_ID_0': FM_ASIC_VERSION_ID_0,
    'ASIC_VERSION_ID_1': FM_ASIC_VERSION_ID_1,
    'BATT_OVERVOLTAGE': FM_BATT_OVERVOLTAGE,
    'BATT_UNDERVOLTAGE': FM_BATT_UNDERVOLTAGE,
    'CYBER_HSM_TIMEOUT': FM_CYBER_HSM_TIMEOUT,
    'DEPLOY_OPS_EVENT_WITHOUT_SAFING': FM_DEPLOY_OPS_EVENT_WITHOUT_SAFING,
    'DEVICE_CFG_CFG_NO_STEER_WHEEL_POS': FM_DEVICE_CFG_CFG_NO_STEER_WHEEL_POS,
    'E2E_PIB_COUNTER': FM_E2E_PIB_COUNTER,
    'ECU_CONFIG_ERROR': FM_ECU_CONFIG_ERROR,
    'EDR_LOCKED': FM_EDR_LOCKED,
    'EVENT_TRAP': FM_EVENT_TRAP,
    'EXT_FLASH_BROKEN_POLLING': FM_EXT_FLASH_BROKEN_POLLING,
    'EXT_FLASH_COMPARE': FM_EXT_FLASH_COMPARE,
    'EXT_FLASH_INTERNAL': FM_EXT_FLASH_INTERNAL,
    'EXT_FLASH_INVALID_DEVICE': FM_EXT_FLASH_INVALID_DEVICE,
    'EXT_FLASH_TIMEOUT': FM_EXT_FLASH_TIMEOUT,
    'FD_BUS_OFF': FM_FD_BUS_OFF,
    'FEE_ADMIN_BLK_NOT_FOUND': FM_FEE_ADMIN_BLK_NOT_FOUND,
    'FEE_CORRUPTED_FLASH': FM_FEE_CORRUPTED_FLASH,
    'FEE_ENDURANCE_LIMIT_EXCEED': FM_FEE_ENDURANCE_LIMIT_EXCEED,
    'FEE_ERASE_FAILURE': FM_FEE_ERASE_FAILURE,
    'FEE_OUT_OF_OPERATING': FM_FEE_OUT_OF_OPERATING,
    'FEE_OUT_OF_ORDER': FM_FEE_OUT_OF_ORDER,
    'FLASH_ENTER_PAGE_MODE_SEQUENCE': FM_FLASH_ENTER_PAGE_MODE_SEQUENCE,
    'FLASH_ENTER_PAGE_MODE_TIMEOUT': FM_FLASH_ENTER_PAGE_MODE_TIMEOUT,
    'FLASH_ERASE_FINISH_TIMEOUT': FM_FLASH_ERASE_FINISH_TIMEOUT,
    'FLASH_ERASE_PROTECTION': FM_FLASH_ERASE_PROTECTION,
    'FLASH_ERASE_RESUME_PROTECTION': FM_FLASH_ERASE_RESUME_PROTECTION,
    'FLASH_ERASE_RESUME_SEQUENCE': FM_FLASH_ERASE_RESUME_SEQUENCE,
    'FLASH_ERASE_RESUME_WRONG_STATE': FM_FLASH_ERASE_RESUME_WRONG_STATE,
    'FLASH_ERASE_SEQUENCE': FM_FLASH_ERASE_SEQUENCE,
    'FLASH_ERASE_START_TIMEOUT': FM_FLASH_ERASE_START_TIMEOUT,
    'FLASH_ERASE_START_WRONG_STATE': FM_FLASH_ERASE_START_WRONG_STATE,
    'FLASH_ERASE_SUSPEND_ERROR_FLAG': FM_FLASH_ERASE_SUSPEND_ERROR_FLAG,
    'FLASH_ERASE_SUSPEND_TIMEOUT': FM_FLASH_ERASE_SUSPEND_TIMEOUT,
    'FLASH_ERASE_SUSPEND_WRONG_STATE': FM_FLASH_ERASE_SUSPEND_WRONG_STATE,
    'FLASH_MICROCODE_OPERATION': FM_FLASH_MICROCODE_OPERATION,
    'FLASH_WRITE_PAGE_PROTECTION': FM_FLASH_WRITE_PAGE_PROTECTION,
    'FLASH_WRITE_PAGE_SEQUENCE': FM_FLASH_WRITE_PAGE_SEQUENCE,
    'FLASH_WRITE_PAGE_TIMEOUT': FM_FLASH_WRITE_PAGE_TIMEOUT,
    'HSS_ASIC_ADC_0': FM_HSS_ASIC_ADC_0,
    'HSS_ASIC_ADC_1': FM_HSS_ASIC_ADC_1,
    'HSS_ASIC_SPI_0': FM_HSS_ASIC_SPI_0,
    'HSS_ASIC_SPI_1': FM_HSS_ASIC_SPI_1,
    'HSS_DIODE_SHORT_0': FM_HSS_DIODE_SHORT_0,
    'HSS_DRIVE_0': FM_HSS_DRIVE_0,
    'HSS_DRIVE_1': FM_HSS_DRIVE_1,
    'HSS_ER_DIODE_OPEN_0': FM_HSS_ER_DIODE_OPEN_0,
    'HSS_ER_DIODE_OPEN_1': FM_HSS_ER_DIODE_OPEN_1,
    'HSS_PDC_0': FM_HSS_PDC_0,
    'HSS_PDC_1': FM_HSS_PDC_1,
    'HSS_VBAT_DIODE_OPEN_0': FM_HSS_VBAT_DIODE_OPEN_0,
    'HSS_VBAT_DIODE_OPEN_1': FM_HSS_VBAT_DIODE_OPEN_1,
    'HSS_XCONN': FM_HSS_XCONN,
    'HS_BUS_OFF': FM_HS_BUS_OFF,
    'MANUFACTURING_DATA_MISSING': FM_MANUFACTURING_DATA_MISSING,
    'MCAL_ADC_NOT_OPERATIONAL': FM_MCAL_ADC_NOT_OPERATIONAL,
    'MCAL_SPI_POLLING_TIMEOUT': FM_MCAL_SPI_POLLING_TIMEOUT,
    'MCAL_SPI_RECEIVE_FIFO_OVERFLOW': FM_MCAL_SPI_RECEIVE_FIFO_OVERFLOW,
    'MCAL_SPI_TRANSMIT_BUSY': FM_MCAL_SPI_TRANSMIT_BUSY,
    'MCU_LBIST': FM_MCU_LBIST,
    'MCU_MBIST': FM_MCU_MBIST,
    'MCU_MONBIST': FM_MCU_MONBIST,
    'NVM_BLOCK_BLOCK_INTEGRITY_FAILED': FM_NVM_BLOCK_BLOCK_INTEGRITY_FAILED,
    'NVM_INTEGRITY': FM_NVM_INTEGRITY,
    'OPS_ROLL_MUTED_0': FM_OPS_ROLL_MUTED_0,
    'PLANT_MODE': FM_PLANT_MODE,
    'PWR_ASIC_ADC_0': FM_PWR_ASIC_ADC_0,
    'PWR_ASIC_ADC_1': FM_PWR_ASIC_ADC_1,
    'PWR_ASIC_CONFIG_0': FM_PWR_ASIC_CONFIG_0,
    'PWR_ASIC_CONFIG_1': FM_PWR_ASIC_CONFIG_1,
    'PWR_ASIC_SPI_0': FM_PWR_ASIC_SPI_0,
    'PWR_ASIC_SPI_1': FM_PWR_ASIC_SPI_1,
    'PWR_CRITICAL_CONDITION_0': FM_PWR_CRITICAL_CONDITION_0,
    'PWR_ERBST_DIODE_LOST_0': FM_PWR_ERBST_DIODE_LOST_0,
    'PWR_ERBST_HIGH_0': FM_PWR_ERBST_HIGH_0,
    'PWR_ERBST_LOW_0': FM_PWR_ERBST_LOW_0,
    'PWR_ER_CAPACITANCE_LOW_0': FM_PWR_ER_CAPACITANCE_LOW_0,
    'PWR_ER_CAPACITANCE_TEST_FAILED_0': FM_PWR_ER_CAPACITANCE_TEST_FAILED_0,
    'PWR_ER_CAP_OPEN_0': FM_PWR_ER_CAP_OPEN_0,
    'PWR_ER_CHARGE_SWITCH_SHORTED_0': FM_PWR_ER_CHARGE_SWITCH_SHORTED_0,
    'PWR_ER_CHARGE_TIME_0': FM_PWR_ER_CHARGE_TIME_0,
    'PWR_ER_ESR_HIGH_0': FM_PWR_ER_ESR_HIGH_0,
    'PWR_ER_SHORT_GND_0': FM_PWR_ER_SHORT_GND_0,
    'PWR_ER_SWITCH_NOT_OPERATIONAL_0': FM_PWR_ER_SWITCH_NOT_OPERATIONAL_0,
    'PWR_ER_VOLTAGE_HIGH_0': FM_PWR_ER_VOLTAGE_HIGH_0,
    'PWR_ER_VOLTAGE_LOW_0': FM_PWR_ER_VOLTAGE_LOW_0,
    'PWR_EX3_VIN_DISCONNECTED_1': FM_PWR_EX3_VIN_DISCONNECTED_1,
    'PWR_GROUND_LOSS_0': FM_PWR_GROUND_LOSS_0,
    'PWR_REDUNDANT_VER_FAILURE_0': FM_PWR_REDUNDANT_VER_FAILURE_0,
    'PWR_SATBUCK_HIGH_0': FM_PWR_SATBUCK_HIGH_0,
    'PWR_SATBUCK_LOW_0': FM_PWR_SATBUCK_LOW_0,
    'PWR_SYSBST_DIODE_SHORT_0': FM_PWR_SYSBST_DIODE_SHORT_0,
    'PWR_SYSBST_LOW_0': FM_PWR_SYSBST_LOW_0,
    'PWR_SYSBST_LOW_1': FM_PWR_SYSBST_LOW_1,
    'PWR_V5_OUT_RANGE_0': FM_PWR_V5_OUT_RANGE_0,
    'PWR_VSYNC_LOW_0': FM_PWR_VSYNC_LOW_0,
    'PWR_VSYNC_LOW_1': FM_PWR_VSYNC_LOW_1,
    'RESET_UNEXPECTED_RESET': FM_RESET_UNEXPECTED_RESET,
    'SAFING_ARMING_LONG_0': FM_SAFING_ARMING_LONG_0,
    'SAFING_ASIC_CC_0': FM_SAFING_ASIC_CC_0,
    'SAFING_ASIC_CONFIG_0': FM_SAFING_ASIC_CONFIG_0,
    'SAFING_ASIC_CONFIG_ENABLES_0': FM_SAFING_ASIC_CONFIG_ENABLES_0,
    'SAFING_ASIC_CONFIG_FOC_0': FM_SAFING_ASIC_CONFIG_FOC_0,
    'SAFING_ASIC_INTERNAL_0': FM_SAFING_ASIC_INTERNAL_0,
    'SAFING_ASIC_SPI_0': FM_SAFING_ASIC_SPI_0,
    'SAFING_SNOOPING_SB3_EX3_TEST_0': FM_SAFING_SNOOPING_SB3_EX3_TEST_0,
    'SCRAP_DEPLOYED': FM_SCRAP_DEPLOYED,
    'SCRAP_ENTERED': FM_SCRAP_ENTERED,
    'SMU_ALARM': FM_SMU_ALARM,
    'SYS_CFG_BLOCK_FAILURE': FM_SYS_CFG_BLOCK_FAILURE,
    'SYS_CONTROL_SHUTDOWN': FM_SYS_CONTROL_SHUTDOWN,
    'SYS_MANUFACTURING_MODE': FM_SYS_MANUFACTURING_MODE,
    'SYS_MODE_POSTRUN_POWER_CONDITIONS': FM_SYS_MODE_POSTRUN_POWER_CONDITIONS,
    'SYS_MODE_SHUTDOWN_FAILURE': FM_SYS_MODE_SHUTDOWN_FAILURE,
    'SYS_PHASE_OF_LIFE_FAILURE': FM_SYS_PHASE_OF_LIFE_FAILURE,
    'SYS_PROVEOUT_TIME_FAILURE': FM_SYS_PROVEOUT_TIME_FAILURE,
    'TASK_STACK_LOW': FM_TASK_STACK_LOW,
    'TASK_UNDERRUN': FM_TASK_UNDERRUN,
    'TRAP_EVENT_OCCURRED': FM_TRAP_EVENT_OCCURRED,
    'TRAP_UNEXPECTED_EXCEPTION': FM_TRAP_UNEXPECTED_EXCEPTION,
    'UNDERSTRIKE_CRASH': FM_UNDERSTRIKE_CRASH,
    'VARIANT_CODE_ERROR': FM_VARIANT_CODE_ERROR,
    'VIN_MISMATCH': FM_VIN_MISMATCH,
    'WATCHDOG_ASIC_INTERNAL': FM_WATCHDOG_ASIC_INTERNAL,
    'WATCHDOG_ASIC_LOCKOUT': FM_WATCHDOG_ASIC_LOCKOUT,
    'WATCHDOG_ASIC_SPI': FM_WATCHDOG_ASIC_SPI,
    'WATCHDOG_TEST': FM_WATCHDOG_TEST,
}


# ====================================================================================================
# IMU (34)
# Inertial measurement unit faults and its OPS plausibility checks.
# ====================================================================================================
FM_IMU0_COMM = {'dtc': '0x92 0x1F 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: 0.01 (SMI8) 0.01 (SMI9) 0.01 (Panasonic); dematuration: 0.02 (SMI8) 0.02 '
                           '(SMI9) 0.02 (Panasonic)'),
                'latched': True, 'monitor': 'DRVR_F_LOGARS_COMM_0', 'req': 36070159,
                'text': 'IMU CRC Error Counter Instance 1 (FLTMONR_IMU_E_CRC_Error_Counter_Instance_1)'}
FM_IMU0_INTERNAL = {'dtc': '0x92 0x22 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: 0.003 (SMI8FG1) 0.03 (SMI8FG4) 0.003 (SMI9FG1) 0.03 (SMI9FG4) 0.003 '
                               '(Panasonic); dematuration: 0.006 (SMI8FG1) 0.06 (SMI8FG4) 0.006 (SMI9FG1) 0.06 '
                               '(SMI9FG4) 0.006 (Panasonic)'),
                    'latched': True, 'monitor': 'DRVR_F_LOGARS_INTERNAL_0', 'req': 36070165,
                    'text': 'IMU Internal Failure Instance 1 (FLTMONR_IMU_E_Internal_Failure_Instance_1)'}
FM_IMU0_INTERNAL_RECOVERABLE = {'dtc': '0x92 0x23 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': ('maturation: 0.25 (SMI8FG2) 0.03 (SMI8FG3) 0.25 (SMI9FG2) 0.03 '
                                           '(SMI9FG3) 0.003 (Panasonic); dematuration: 0.5 (SMI8FG2) 0.06 '
                                           '(SMI8FG3) 0.5 (SMI9FG2) 0.06 (SMI9FG3) 0.006 (Panasonic)'),
                                'latched': True, 'monitor': 'DRVR_F_LOGARS_INTERNAL_RECOV_0', 'req': 36070167,
                                'text': ('IMU Internal Recoverable Failure Instance 1 '
                                         '(FLTMONR_IMU_E_Internal_Recoverable_Failure_Instance_1)')}
FM_IMU0_SELF_TEST = {'dtc': '0x92 0x21 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: 0.003 (SMI8) 0.003 (SMI9) 0.003 (Panasonic); dematuration: 0.006 '
                                '(SMI8) 0.006 (SMI9) 0.006 (Panasonic)'),
                     'latched': True, 'monitor': 'DRVR_F_LOGARS_SELF_TEST_0', 'req': 36070163,
                     'text': 'IMU SelfTest Failure Instance 1 (FLTMONR_IMU_E_Self_Test_Failure_Instance_1)'}
FM_IMU0_SPI = {'dtc': '0x92 0x20 0x00', 'qualify_ms': None, 'dequalify_ms': None,
               'timing': ('maturation: 0.003 (SMI8) 0.003 (SMI9) 0.003 (Panasonic); dematuration: 0.006 (SMI8) '
                          '0.006 (SMI9) 0.006 (Panasonic)'),
               'latched': True, 'monitor': 'DRVR_F_LOGARS_SPI_0', 'req': 36070161,
               'text': 'IMU SPI Error Counter Instance 1 (FLTMONR_IMU_E_SPI_Error_Counter_Instance_1)'}
FM_IMU_ARS_PITCH = {'dtc': '0x92 0x2A 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                    'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, '
                               'SEV2) 0.2 (IMU SEV3)'),
                    'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_PITCH', 'req': 36070263,
                    'text': 'IMU SEV1 or 2 failure on PITCH direction (FLTMONR_IMU_E_SEV123_failure_on_PITCH)'}
FM_IMU_ARS_PITCH_OUT_RANGE = {'dtc': '0x92 0x31 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                              'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_PITCH_OUT_RANGE', 'req': 36070273,
                              'text': ('IMU Out of Range failure on PITCH direction '
                                       '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_PITCH)')}
FM_IMU_ARS_ROLL = {'dtc': '0x92 0x29 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, '
                              'SEV2) 0.2 (IMU SEV3)'),
                   'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_ROLL', 'req': 36070262,
                   'text': 'IMU SEV1 or 2 failure on ROLL direction (FLTMONR_IMU_E_SEV123_failure_on_ROLL)'}
FM_IMU_ARS_ROLL_OUT_RANGE = {'dtc': '0x92 0x30 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                             'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                             'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_ROLL_OUT_RANGE', 'req': 36070272,
                             'text': ('IMU Out of Range failure on ROLL direction '
                                      '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_ROLL)')}
FM_IMU_ARS_TEMP = {'dtc': '0x92 0x2B 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                   'timing': 'maturation: NA(TBD); dematuration: NA(TBD)', 'latched': False,
                   'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_TEMP', 'req': 36070267,
                   'text': 'IMU SEV1 or 2 failure for Temperature (FLTMONR_IMU_E_SEV123_failure_for_TEMPERATURE)'}
FM_IMU_ARS_YAW = {'dtc': '0x92 0x28 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, '
                             'SEV2) 0.2 (IMU SEV3)'),
                  'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_YAW', 'req': 36070261,
                  'text': 'IMU SEV1 or 2 failure on YAW direction (FLTMONR_IMU_E_SEV123_failure_on_YAW)'}
FM_IMU_ARS_YAW_OUT_RANGE = {'dtc': '0x92 0x2F 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                            'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                            'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_YAW_OUT_RANGE', 'req': 36070271,
                            'text': ('IMU Out of Range failure on YAW direction '
                                     '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_YAW)')}
FM_IMU_ARS_YAW_TEMP_OUT_RANGE = {'dtc': '0x92 0x32 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: NA(TBD); dematuration: NA(TBD)', 'latched': False,
                                 'monitor': 'IMUSGPOOLMGR_F_IMU_ARS_YAW_TEMP_OUT_RANGE', 'req': 36070277,
                                 'text': ('IMU Out of Range failure on YAW Temperature '
                                          '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_YAW_TEMPERATURE)')}
FM_IMU_EXT_CAL_FAIL = {'dtc': '0x92 0x48 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                       'monitor': 'IMUMGR_F_IMU_EXT_CAL_FAIL', 'req': 36070354,
                       'text': 'Incorrect calibration (FLTMONR_IMU_EXT_CAL_FAIL)'}
FM_IMU_EXT_CAL_MISSING = {'dtc': '0x92 0x47 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: NA; dematuration: NA', 'latched': True,
                          'monitor': 'IMUMGR_F_IMU_EXT_CAL_MISSING', 'req': 36070353,
                          'text': 'Missing calibration (FLTMONR_IMU_EXT_CAL_MISSING)'}
FM_IMU_LOG_X = {'dtc': '0x92 0x25 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                           '0.2 (IMU SEV3)'),
                'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_X', 'req': 36070258,
                'text': 'IMU SEV1 or 2 failure on X direction (FLTMONR_IMU_E_SEV123_failure_on_X)'}
FM_IMU_LOG_X_OUT_RANGE = {'dtc': '0x92 0x2C 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                          'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_X_OUT_RANGE', 'req': 36070268,
                          'text': ('IMU Out of Range failure on X direction '
                                   '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_X)')}
FM_IMU_LOG_Y = {'dtc': '0x92 0x26 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                           '0.2 (IMU SEV3)'),
                'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Y', 'req': 36070259,
                'text': 'IMU SEV1 or 2 failure on Y direction (FLTMONR_IMU_E_SEV123_failure_on_Y)'}
FM_IMU_LOG_Y_OUT_RANGE = {'dtc': '0x92 0x2D 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                          'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Y_OUT_RANGE', 'req': 36070269,
                          'text': ('IMU Out of Range failure on Y direction '
                                   '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_Y)')}
FM_IMU_LOG_Z = {'dtc': '0x92 0x27 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                'timing': ('maturation: 0.05 (IMU SEV1, SEV2) 30.03 (IMU SEV3); dematuration: 0.2 (IMU SEV1, SEV2) '
                           '0.2 (IMU SEV3)'),
                'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Z', 'req': 36070260,
                'text': 'IMU SEV1 or 2 failure on Z direction (FLTMONR_IMU_E_SEV123_failure_on_Z)'}
FM_IMU_LOG_Z_OUT_RANGE = {'dtc': '0x92 0x2E 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: 30.03; dematuration: 0.001', 'latched': False,
                          'monitor': 'IMUSGPOOLMGR_F_IMU_LOG_Z_OUT_RANGE', 'req': 36070270,
                          'text': ('IMU Out of Range failure on Z direction '
                                   '(FLTMONR_IMU_E_OUT_OF_RANGE_FAILURE_ON_Z)')}
FM_IMU_VEONEER_CHKSUM_FAIL = {'dtc': '0x92 0x24 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                              'timing': 'maturation: 1; dematuration: Send write DID request with correct checksum',
                              'latched': False, 'monitor': 'IMUSGPOOLMGR_F_IMU_VEONEER_CHKSUM_FAIL',
                              'req': 36070257,
                              'text': ('Veoneer Manufacturing IMU Calibration data integrity check failure on at '
                                       'least one of the channel (FLTMONR_IMUSGPOOLMGR_E_VEONEER_CHKSUM_FAIL)')}
FM_OPS_ARS_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_OCR_0', 'req': 36070250,
                       'text': 'OPS ARS Offset Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_ARS_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_OCR_1', 'req': 36070251,
                       'text': 'OPS ARS Offset Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_ARS_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_OCR_2', 'req': 36070252,
                       'text': 'OPS ARS Offset Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_ARS_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 10; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_DEC_0', 'req': 36070195,
                           'text': 'OPS ARS Saturation Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_ARS_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_DEC_1', 'req': 36070196,
                           'text': 'OPS ARS Saturation Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_ARS_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: TBD; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_ARS_DEC_2', 'req': 36070197,
                           'text': 'OPS ARS Saturation Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_LOG_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : FOC and SOC: 2.05s for FOC and 2500s for SOC. APPRISe: FOC and '
                                  'SOC: 2.05s for FOC and 2500s for SOC.; dematuration: N/A'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_OCR_0', 'req': 36070247,
                       'text': 'OPS LowG Offset Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_LOG_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : FOC and SOC: 2.05s for FOC and 2500s for SOC. APPRISe: FOC and '
                                  'SOC: 2.05s for FOC and 2500s for SOC.; dematuration: N/A'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_OCR_1', 'req': 36070248,
                       'text': 'OPS LowG Offset Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_LOG_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': ('maturation: : FOC and SOC: 2.05s for FOC and 2500s for SOC. APPRISe: FOC and '
                                  'SOC: 2.05s for FOC and 2500s for SOC.; dematuration: N/A'),
                       'latched': False, 'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_OCR_2', 'req': 36070249,
                       'text': 'OPS LowG Offset Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_LOG_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_DEC_0', 'req': 36070192,
                           'text': 'OPS LowG Saturation Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_LOG_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_DEC_1', 'req': 36070193,
                           'text': 'OPS LowG Saturation Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_LOG_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 3; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_LOG_DEC_2', 'req': 36070194,
                           'text': 'OPS LowG Saturation Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}

IMU_FAULTS = {
    'IMU0_COMM': FM_IMU0_COMM,
    'IMU0_INTERNAL': FM_IMU0_INTERNAL,
    'IMU0_INTERNAL_RECOVERABLE': FM_IMU0_INTERNAL_RECOVERABLE,
    'IMU0_SELF_TEST': FM_IMU0_SELF_TEST,
    'IMU0_SPI': FM_IMU0_SPI,
    'IMU_ARS_PITCH': FM_IMU_ARS_PITCH,
    'IMU_ARS_PITCH_OUT_RANGE': FM_IMU_ARS_PITCH_OUT_RANGE,
    'IMU_ARS_ROLL': FM_IMU_ARS_ROLL,
    'IMU_ARS_ROLL_OUT_RANGE': FM_IMU_ARS_ROLL_OUT_RANGE,
    'IMU_ARS_TEMP': FM_IMU_ARS_TEMP,
    'IMU_ARS_YAW': FM_IMU_ARS_YAW,
    'IMU_ARS_YAW_OUT_RANGE': FM_IMU_ARS_YAW_OUT_RANGE,
    'IMU_ARS_YAW_TEMP_OUT_RANGE': FM_IMU_ARS_YAW_TEMP_OUT_RANGE,
    'IMU_EXT_CAL_FAIL': FM_IMU_EXT_CAL_FAIL,
    'IMU_EXT_CAL_MISSING': FM_IMU_EXT_CAL_MISSING,
    'IMU_LOG_X': FM_IMU_LOG_X,
    'IMU_LOG_X_OUT_RANGE': FM_IMU_LOG_X_OUT_RANGE,
    'IMU_LOG_Y': FM_IMU_LOG_Y,
    'IMU_LOG_Y_OUT_RANGE': FM_IMU_LOG_Y_OUT_RANGE,
    'IMU_LOG_Z': FM_IMU_LOG_Z,
    'IMU_LOG_Z_OUT_RANGE': FM_IMU_LOG_Z_OUT_RANGE,
    'IMU_VEONEER_CHKSUM_FAIL': FM_IMU_VEONEER_CHKSUM_FAIL,
    'OPS_ARS_OFFSET_0': FM_OPS_ARS_OFFSET_0,
    'OPS_ARS_OFFSET_1': FM_OPS_ARS_OFFSET_1,
    'OPS_ARS_OFFSET_2': FM_OPS_ARS_OFFSET_2,
    'OPS_ARS_SATURATION_0': FM_OPS_ARS_SATURATION_0,
    'OPS_ARS_SATURATION_1': FM_OPS_ARS_SATURATION_1,
    'OPS_ARS_SATURATION_2': FM_OPS_ARS_SATURATION_2,
    'OPS_LOG_OFFSET_0': FM_OPS_LOG_OFFSET_0,
    'OPS_LOG_OFFSET_1': FM_OPS_LOG_OFFSET_1,
    'OPS_LOG_OFFSET_2': FM_OPS_LOG_OFFSET_2,
    'OPS_LOG_SATURATION_0': FM_OPS_LOG_SATURATION_0,
    'OPS_LOG_SATURATION_1': FM_OPS_LOG_SATURATION_1,
    'OPS_LOG_SATURATION_2': FM_OPS_LOG_SATURATION_2,
}


# ====================================================================================================
# High-g sensors (16)
# Central high-g sensor faults and its OPS checks.
# ====================================================================================================
FM_HIGH_G0_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                       'monitor': 'DRVR_F_HIG_INTERNAL_0', 'req': 36070130,
                       'text': 'SMA&GEN6 sensor internal (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G0_SELF_TEST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                        'monitor': 'DRVR_F_HIG_SELF_TEST_0', 'req': 36070131,
                        'text': 'SMA&GEN6 sensor selftest (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G0_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.3; dematuration: 0.6', 'latched': False, 'monitor': 'DRVR_F_HIG_SPI_0',
                  'req': 36070129, 'text': 'SMA&GEN6 sensor SPI bus (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G0_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                     'monitor': 'DRVR_F_HIG_SUPPLY_0', 'req': 36070132,
                     'text': 'SMA&GEN6 sensor supply (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G1_INTERNAL = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                       'monitor': 'DRVR_F_HIG_INTERNAL_1', 'req': 36070134,
                       'text': 'SMA&GEN6 sensor internal (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G1_SELF_TEST = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                        'monitor': 'DRVR_F_HIG_SELF_TEST_1', 'req': 36070135,
                        'text': 'SMA&GEN6 sensor selftest (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G1_SPI = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: 0.3; dematuration: 0.6', 'latched': True, 'monitor': 'DRVR_F_HIG_SPI_1',
                  'req': 36070133, 'text': 'SMA&GEN6 sensor SPI bus (FLTMONR_E_ECU_INTERNAL)'}
FM_HIGH_G1_SUPPLY = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: 0.05; dematuration: 0.1', 'latched': True,
                     'monitor': 'DRVR_F_HIG_SUPPLY_1', 'req': 36070136,
                     'text': 'SMA&GEN6 sensor supply (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_OFFSET_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_0', 'req': 36070224,
                       'text': 'OPS HighG Offset Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_OFFSET_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_1', 'req': 36070225,
                       'text': 'OPS HighG Offset Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_OFFSET_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_2', 'req': 36070226,
                       'text': 'OPS HighG Offset Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_OFFSET_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: .; dematuration: N/A', 'latched': False,
                       'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_OCR_3', 'req': 36070227,
                       'text': 'OPS HighG Offset Failure Axis 3 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_SATURATION_0 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_0', 'req': 36070169,
                           'text': 'OPS HighG Saturation Failure Axis 0 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_SATURATION_1 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_1', 'req': 36070170,
                           'text': 'OPS HighG Saturation Failure Axis 1 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_SATURATION_2 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_2', 'req': 36070171,
                           'text': 'OPS HighG Saturation Failure Axis 2 (FLTMONR_E_ECU_INTERNAL)'}
FM_OPS_HIG_SATURATION_3 = {'dtc': '0x90 0x13 0x49', 'qualify_ms': None, 'dequalify_ms': None,
                           'timing': 'maturation: 0.5; dematuration: NA', 'latched': True,
                           'monitor': 'OPSSGPOOLMGR_F_OPS_HIG_DEC_3', 'req': 36070172,
                           'text': 'OPS HighG Saturation Failure Axis 3 (FLTMONR_E_ECU_INTERNAL)'}

HIGH_G_FAULTS = {
    'HIGH_G0_INTERNAL': FM_HIGH_G0_INTERNAL,
    'HIGH_G0_SELF_TEST': FM_HIGH_G0_SELF_TEST,
    'HIGH_G0_SPI': FM_HIGH_G0_SPI,
    'HIGH_G0_SUPPLY': FM_HIGH_G0_SUPPLY,
    'HIGH_G1_INTERNAL': FM_HIGH_G1_INTERNAL,
    'HIGH_G1_SELF_TEST': FM_HIGH_G1_SELF_TEST,
    'HIGH_G1_SPI': FM_HIGH_G1_SPI,
    'HIGH_G1_SUPPLY': FM_HIGH_G1_SUPPLY,
    'OPS_HIG_OFFSET_0': FM_OPS_HIG_OFFSET_0,
    'OPS_HIG_OFFSET_1': FM_OPS_HIG_OFFSET_1,
    'OPS_HIG_OFFSET_2': FM_OPS_HIG_OFFSET_2,
    'OPS_HIG_OFFSET_3': FM_OPS_HIG_OFFSET_3,
    'OPS_HIG_SATURATION_0': FM_OPS_HIG_SATURATION_0,
    'OPS_HIG_SATURATION_1': FM_OPS_HIG_SATURATION_1,
    'OPS_HIG_SATURATION_2': FM_OPS_HIG_SATURATION_2,
    'OPS_HIG_SATURATION_3': FM_OPS_HIG_SATURATION_3,
}


# ====================================================================================================
# Loops fired (10)
# Records of fired loops (no DTC for the airbag groups).
# ====================================================================================================
FM_KNEE_BAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                      'monitor': 'OPS_E_KNEE_BAGS_FIRED', 'req': 36070310,
                      'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_FRONTAL_BAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                         'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                         'monitor': 'OPS_E_FRONTAL_BAGS_FIRED', 'req': 36070311,
                         'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_FRONTAL_BAGS_FIRED_PASS_INHIBITED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                                        'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                                        'monitor': 'OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBITED', 'req': 36070312,
                                        'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_BACK_IMPACT_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                        'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                        'monitor': 'OPS_E_BACK_IMPACT_FIRED', 'req': 36070318,
                        'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_LEFT_LATERAL_AIRBAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                                 'monitor': 'OPS_E_LEFT_LATERAL_AIRBAGS_FIRED', 'req': 36070313,
                                 'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_RIGHT_LATERAL_AIRBAGS_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                                  'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                                  'monitor': 'OPS_E_RIGHT_LATERAL_AIRBAGS_FIRED', 'req': 36070314,
                                  'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_LEFT_CURTAIN_AIRBAG_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                                'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                                'monitor': 'OPS_E_LEFT_CURTAIN_AIRBAG_FIRED', 'req': 36070315,
                                'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_RIGHT_CURTAIN_AIRBAG_FIRED = {'dtc': None, 'qualify_ms': None, 'dequalify_ms': None,
                                 'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                                 'monitor': 'OPS_E_RIGHT_CURTAIN_AIRBAG_FIRED', 'req': 36070316,
                                 'text': 'This Fault records the DTC Logged when respective Loop is fired'}
FM_PRETENSIONERS_FIRED = {'dtc': '0x92 0x1A 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                          'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                          'monitor': 'OPS_E_PRETENSIONERS_FIRED', 'req': 36070307,
                          'text': 'Crash related fault (FLTMONR_E_ECU_LOCKED_DUE_TO_PT_DEPLOYMENT)'}
FM_STRAP_PRETENSIONER_FIRED = {'dtc': '0x92 0x1A 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                               'timing': 'maturation: Immediate; dematuration: NA', 'latched': True,
                               'monitor': 'OPS_E_STRAP_RETURN_PRETENSIONER_FIRED', 'req': 36070309,
                               'text': 'Crash related fault (FLTMONR_E_ECU_LOCKED_DUE_TO_PT_DEPLOYMENT)'}

FIRED_FAULTS = {
    'KNEE_BAGS_FIRED': FM_KNEE_BAGS_FIRED,
    'FRONTAL_BAGS_FIRED': FM_FRONTAL_BAGS_FIRED,
    'FRONTAL_BAGS_FIRED_PASS_INHIBITED': FM_FRONTAL_BAGS_FIRED_PASS_INHIBITED,
    'BACK_IMPACT_FIRED': FM_BACK_IMPACT_FIRED,
    'LEFT_LATERAL_AIRBAGS_FIRED': FM_LEFT_LATERAL_AIRBAGS_FIRED,
    'RIGHT_LATERAL_AIRBAGS_FIRED': FM_RIGHT_LATERAL_AIRBAGS_FIRED,
    'LEFT_CURTAIN_AIRBAG_FIRED': FM_LEFT_CURTAIN_AIRBAG_FIRED,
    'RIGHT_CURTAIN_AIRBAG_FIRED': FM_RIGHT_CURTAIN_AIRBAG_FIRED,
    'PRETENSIONERS_FIRED': FM_PRETENSIONERS_FIRED,
    'STRAP_PRETENSIONER_FIRED': FM_STRAP_PRETENSIONER_FIRED,
}


# ====================================================================================================
# Crash records (5)
# Crash DTCs, set at once and kept (warning lamp ON).
# ====================================================================================================
FM_ROLLOVER_CRASH = {'dtc': '0x99 0x15 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': 'maturation: Immediate; dematuration: NA', 'latched': None,
                     'monitor': 'ROLLOVER_CRASH', 'req': 36141136,
                     'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
FM_FRONT_CRASH = {'dtc': '0x90 0x61 0x96', 'qualify_ms': None, 'dequalify_ms': None,
                  'timing': 'maturation: Immediate; dematuration: NA', 'latched': None, 'monitor': 'FRONT_CRASH',
                  'req': 36153766, 'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
FM_REAR_CRASH = {'dtc': '0x92 0x1E 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                 'timing': 'maturation: Immediate; dematuration: NA', 'latched': None, 'monitor': 'REAR_CRASH',
                 'req': 36153767, 'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
FM_RIGHT_SIDE_CRASH = {'dtc': '0x99 0x16 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                       'timing': 'maturation: Immediate; dematuration: NA', 'latched': None,
                       'monitor': 'RIGHT_SIDE_CRASH', 'req': 36153768,
                       'text': 'Note: During this failure active the Warning LAMP status shall be ON'}
FM_LEFT_SIDE_CRASH = {'dtc': '0x92 0x01 0x00', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': 'maturation: Immediate; dematuration: NA', 'latched': None,
                      'monitor': 'LEFT_SIDE_CRASH', 'req': 36153769,
                      'text': '! Note: During this failure active the Warning LAMP status shall be ON'}

CRASH_FAULTS = {
    'ROLLOVER_CRASH': FM_ROLLOVER_CRASH,
    'FRONT_CRASH': FM_FRONT_CRASH,
    'REAR_CRASH': FM_REAR_CRASH,
    'RIGHT_SIDE_CRASH': FM_RIGHT_SIDE_CRASH,
    'LEFT_SIDE_CRASH': FM_LEFT_SIDE_CRASH,
}


# ====================================================================================================
# Struck out by the customer (43)
# Faults the customer struck out of the fault list (heading 'Customer StrikeOut DTC'): kept for
# reference, not part of the project's fault set (not in FAULT_LIST).
# ====================================================================================================
FM_DRV_STPS2_S2B = {'dtc': '0x98 0xFA 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                    'monitor': 'DCS_F_SHORT_PLUS_6', 'req': 36073761,
                    'text': 'DCS Sensor 6 short to battery (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_LEAK_TO_PLUS)'}
FM_DRV_STPS2_S2G = {'dtc': '0x98 0xFA 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                    'monitor': 'DCS_F_SHORT_GND_6', 'req': 36073754,
                    'text': 'DCS Sensor 6 short to ground (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_LEAK_TO_GND)'}
FM_DRV_STPS2_OPEN = {'dtc': '0x98 0xFA 0x13', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                     'monitor': 'DCS_F_OPEN_6', 'req': 36073747,
                     'text': 'DCS Sensor 6 open circuit (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_OPEN)'}
FM_DRV_STPS2_XCONN = {'dtc': '0x98 0xFA 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                      'monitor': 'DCS_F_CROSS_CONNECT_6', 'req': 36073740,
                      'text': 'DCS Sensor 6 cross connected (FLTMONR_DCS_E_DRIVER_STPS2_SWITCH_CROSS_CONNECTED)'}
FM_PSGR_STPS2_S2B = {'dtc': '0x98 0xFC 0x12', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                     'monitor': 'DCS_F_SHORT_PLUS_8', 'req': 36073762,
                     'text': 'DCS Sensor 8 short to battery (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_LEAK_TO_PLUS)'}
FM_PSGR_STPS2_S2G = {'dtc': '0x98 0xFC 0x11', 'qualify_ms': 3200, 'dequalify_ms': 3200, 'latched': False,
                     'monitor': 'DCS_F_SHORT_GND_8', 'req': 36073755,
                     'text': 'DCS Sensor 8 short to ground (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_LEAK_TO_GND)'}
FM_PSGR_STPS2_OPEN = {'dtc': '0x98 0xFC 0x13', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                      'monitor': 'DCS_F_OPEN_8', 'req': 36073748,
                      'text': 'DCS Sensor 8 open circuit (FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_OPEN)'}
FM_PSGR_STPS2_XCONN = {'dtc': '0x98 0xFC 0x01', 'qualify_ms': 1900, 'dequalify_ms': 1900, 'latched': False,
                       'monitor': 'DCS_F_CROSS_CONNECT_8', 'req': 36073741,
                       'text': ('DCS Sensor 8 cross connected '
                                '(FLTMONR_DCS_E_PASSENGER_STPS2_SWITCH_CROSS_CONNECTED)')}
FM_DFV_OPEN = {'dtc': '0x92 0x61 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_14', 'req': 36069479,
               'text': 'LOP Open circuit failure Line 14 (FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_OPEN)'}
FM_DFV_S2G = {'dtc': '0x92 0x61 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_14', 'req': 36073763,
              'text': ('LOP Short to ground failure Line 14 '
                       '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_DFV_S2B = {'dtc': '0x92 0x61 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_14', 'req': 36073770,
              'text': ('LOP Short to battery failure Line 14 '
                       '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_DFV_LORES = {'dtc': '0x92 0x61 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_14', 'req': 36073777,
                'text': 'LOP Resistance too low Line 14 (FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_LOW_RES)'}
FM_DFV_HIRES = {'dtc': '0x92 0x61 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_14', 'req': 36073784,
                'text': 'LOP Resistance too high Line 14 (FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_HIGH_RES)'}
FM_DFV_XCONN = {'dtc': '0x92 0x61 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_14', 'req': 36073796,
                'text': ('LOP Cross connection failure Line 14 '
                         '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_CROSS_CONNECT)')}
FM_DFV_UNEXPECTED = {'dtc': '0x92 0x61 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_14', 'req': 36069563,
                     'text': ('LOP Present but not configured Line 14 '
                              '(FLTMONR_LOP_E_AIRBAG_DRIVER_FRONTAL_VENT_SQUIB_UNEXPECTED_SQUIB)')}
FM_PFV_OPEN = {'dtc': '0x92 0x62 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_15', 'req': 36069480,
               'text': 'LOP Open circuit failure Line 15 (FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_OPEN)'}
FM_PFV_S2G = {'dtc': '0x92 0x62 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_15', 'req': 36073764,
              'text': ('LOP Short to ground failure Line 15 '
                       '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_PFV_S2B = {'dtc': '0x92 0x62 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_15', 'req': 36073771,
              'text': ('LOP Short to battery failure Line 15 '
                       '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_PFV_LORES = {'dtc': '0x92 0x62 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_15', 'req': 36073778,
                'text': ('LOP Resistance too low Line 15 '
                         '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_LOW_RES)')}
FM_PFV_HIRES = {'dtc': '0x92 0x62 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_15', 'req': 36073785,
                'text': ('LOP Resistance too high Line 15 '
                         '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_HIGH_RES)')}
FM_PFV_XCONN = {'dtc': '0x92 0x62 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_15', 'req': 36073797,
                'text': ('LOP Cross connection failure Line 15 '
                         '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_CROSS_CONNECT)')}
FM_PFV_UNEXPECTED = {'dtc': '0x92 0x62 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_15', 'req': 36069564,
                     'text': ('LOP Present but not configured Line 15 '
                              '(FLTMONR_LOP_E_AIRBAG_PASSENGER_FRONTAL_VENT_SQUIB_UNEXPECTED_SQUIB)')}
FM_HVBD_OPEN = {'dtc': '0x99 0x12 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_OPEN_21', 'req': 36073793,
                'text': ('LOP Open circuit failure Line 21 '
                         '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_OPEN)')}
FM_HVBD_S2G = {'dtc': '0x99 0x12 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_GND_21', 'req': 36073767,
               'text': ('LOP Short to ground failure Line 21 '
                        '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_HVBD_S2B = {'dtc': '0x99 0x12 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_SHORT_TO_BATT_21', 'req': 36073774,
               'text': ('LOP Short to battery failure Line 21 '
                        '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_HVBD_LORES = {'dtc': '0x99 0x12 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_LOW_RES_21', 'req': 36073781,
                 'text': ('LOP Resistance too low Line 21 '
                          '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_LOW_RES)')}
FM_HVBD_HIRES = {'dtc': '0x99 0x12 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_HIGH_RES_21', 'req': 36073788,
                 'text': ('LOP Resistance too high Line 21 '
                          '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_HIGH_RES)')}
FM_HVBD_XCONN = {'dtc': '0x99 0x12 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                 'monitor': 'LOOP_F_CROSS_CONNECT_21', 'req': 36073800,
                 'text': ('LOP Cross connection failure Line 21 '
                          '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_CROSS_CONNECT)')}
FM_HVBD_UNEXPECTED = {'dtc': '0x99 0x12 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                      'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                 'Within PDC(2 sec)'),
                      'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_21', 'req': 36073805,
                      'text': ('LOP Present but not configured Line 21 '
                               '(FLTMONR_LOP_E_HIGH_VOLTAGE_OR_BATTERY_DISABLE_SQUIB_UNEXPECTED_SQUIB)')}
FM_PPC_OPEN = {'dtc': '0x99 0x11 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_22', 'req': 36073794,
               'text': 'LOP Open circuit failure Line 22 (FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_OPEN)'}
FM_PPC_S2G = {'dtc': '0x99 0x11 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_22', 'req': 36073768,
              'text': ('LOP Short to ground failure Line 22 '
                       '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_PPC_S2B = {'dtc': '0x99 0x11 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_22', 'req': 36073775,
              'text': ('LOP Short to battery failure Line 22 '
                       '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_PPC_LORES = {'dtc': '0x99 0x11 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_22', 'req': 36073782,
                'text': 'LOP Resistance too low Line 22 (FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_LOW_RES)'}
FM_PPC_HIRES = {'dtc': '0x99 0x11 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_22', 'req': 36073789,
                'text': 'LOP Resistance too high Line 22 (FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_HIGH_RES)'}
FM_PPC_XCONN = {'dtc': '0x99 0x11 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_22', 'req': 36073801,
                'text': ('LOP Cross connection failure Line 22 '
                         '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_CROSS_CONNECT)')}
FM_PPC_UNEXPECTED = {'dtc': '0x99 0x11 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_22', 'req': 36073806,
                     'text': ('LOP Present but not configured Line 22 '
                              '(FLTMONR_LOP_E_PASSENGER_PELVIS_CUSHION_SQUIB_UNEXPECTED_SQUIB)')}
FM_DPC_OPEN = {'dtc': '0x99 0x10 0x13', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
               'monitor': 'LOOP_F_OPEN_23', 'req': 36073795,
               'text': 'LOP Open circuit failure Line 23 (FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_OPEN)'}
FM_DPC_S2G = {'dtc': '0x99 0x10 0x11', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_GND_23', 'req': 36073769,
              'text': ('LOP Short to ground failure Line 23 '
                       '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_GND)')}
FM_DPC_S2B = {'dtc': '0x99 0x10 0x12', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
              'monitor': 'LOOP_F_SHORT_TO_BATT_23', 'req': 36073776,
              'text': ('LOP Short to battery failure Line 23 '
                       '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_SHORT_CIRCUIT_TO_BAT)')}
FM_DPC_LORES = {'dtc': '0x99 0x10 0x1A', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_LOW_RES_23', 'req': 36073783,
                'text': 'LOP Resistance too low Line 23 (FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_LOW_RES)'}
FM_DPC_HIRES = {'dtc': '0x99 0x10 0x1B', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_HIGH_RES_23', 'req': 36073790,
                'text': 'LOP Resistance too high Line 23 (FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_HIGH_RES)'}
FM_DPC_XCONN = {'dtc': '0x99 0x10 0x01', 'qualify_ms': 2000, 'dequalify_ms': 4000, 'latched': False,
                'monitor': 'LOOP_F_CROSS_CONNECT_23', 'req': 36073802,
                'text': ('LOP Cross connection failure Line 23 '
                         '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_CROSS_CONNECT)')}
FM_DPC_UNEXPECTED = {'dtc': '0x99 0x10 0x64', 'qualify_ms': None, 'dequalify_ms': None,
                     'timing': ('maturation: Practical Value: Within PDC(2 sec); dematuration: Practical Value: '
                                'Within PDC(2 sec)'),
                     'latched': True, 'monitor': 'LOOP_F_UNEXPECTED_LOAD_23', 'req': 36073807,
                     'text': ('LOP Present but not configured Line 23 '
                              '(FLTMONR_LOP_E_DRIVER_PELVIS_CUSHION_SQUIB_UNEXPECTED_SQUIB)')}

STRUCK_OUT_FAULTS = {
    'DRV_STPS2_S2B': FM_DRV_STPS2_S2B,
    'DRV_STPS2_S2G': FM_DRV_STPS2_S2G,
    'DRV_STPS2_OPEN': FM_DRV_STPS2_OPEN,
    'DRV_STPS2_XCONN': FM_DRV_STPS2_XCONN,
    'PSGR_STPS2_S2B': FM_PSGR_STPS2_S2B,
    'PSGR_STPS2_S2G': FM_PSGR_STPS2_S2G,
    'PSGR_STPS2_OPEN': FM_PSGR_STPS2_OPEN,
    'PSGR_STPS2_XCONN': FM_PSGR_STPS2_XCONN,
    'DFV_OPEN': FM_DFV_OPEN,
    'DFV_S2G': FM_DFV_S2G,
    'DFV_S2B': FM_DFV_S2B,
    'DFV_LORES': FM_DFV_LORES,
    'DFV_HIRES': FM_DFV_HIRES,
    'DFV_XCONN': FM_DFV_XCONN,
    'DFV_UNEXPECTED': FM_DFV_UNEXPECTED,
    'PFV_OPEN': FM_PFV_OPEN,
    'PFV_S2G': FM_PFV_S2G,
    'PFV_S2B': FM_PFV_S2B,
    'PFV_LORES': FM_PFV_LORES,
    'PFV_HIRES': FM_PFV_HIRES,
    'PFV_XCONN': FM_PFV_XCONN,
    'PFV_UNEXPECTED': FM_PFV_UNEXPECTED,
    'HVBD_OPEN': FM_HVBD_OPEN,
    'HVBD_S2G': FM_HVBD_S2G,
    'HVBD_S2B': FM_HVBD_S2B,
    'HVBD_LORES': FM_HVBD_LORES,
    'HVBD_HIRES': FM_HVBD_HIRES,
    'HVBD_XCONN': FM_HVBD_XCONN,
    'HVBD_UNEXPECTED': FM_HVBD_UNEXPECTED,
    'PPC_OPEN': FM_PPC_OPEN,
    'PPC_S2G': FM_PPC_S2G,
    'PPC_S2B': FM_PPC_S2B,
    'PPC_LORES': FM_PPC_LORES,
    'PPC_HIRES': FM_PPC_HIRES,
    'PPC_XCONN': FM_PPC_XCONN,
    'PPC_UNEXPECTED': FM_PPC_UNEXPECTED,
    'DPC_OPEN': FM_DPC_OPEN,
    'DPC_S2G': FM_DPC_S2G,
    'DPC_S2B': FM_DPC_S2B,
    'DPC_LORES': FM_DPC_LORES,
    'DPC_HIRES': FM_DPC_HIRES,
    'DPC_XCONN': FM_DPC_XCONN,
    'DPC_UNEXPECTED': FM_DPC_UNEXPECTED,
}


# ====================================================================================================
# Every fault of the project's fault set (the struck-out ones are not in it)
# ====================================================================================================
FAULT_LIST = {
    **LOOP_FAULTS,
    **GPO_FAULTS,
    **DCS_FAULTS,
    **RSU_FAULTS,
    **CAN_FAULTS,
    **SYSTEM_FAULTS,
    **IMU_FAULTS,
    **HIGH_G_FAULTS,
    **FIRED_FAULTS,
    **CRASH_FAULTS,
}

# Squib (squibs_config name) -> fault type (Squib_FaultTypeCode key) -> fault.
LOOP_FAULT_BY_SQUIB = {
    'RPT': {'Open': FM_RPT_OPEN, 'S2G': FM_RPT_S2G, 'S2B': FM_RPT_S2B, 'LoRes': FM_RPT_LORES, 'HiRes': FM_RPT_HIRES,
            'CrossConnect': FM_RPT_XCONN, 'UNEX': FM_RPT_UNEXPECTED, 'Internal': FM_RPT_INTERNAL,
            'CurrentSource': FM_RPT_CURRENT_SOURCE, 'Supply': FM_RPT_SUPPLY,
            'LowSideSwitch': FM_RPT_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_RPT_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_RPT_GROUND_LOSS, 'CsrCrossConnect': FM_RPT_CSR_XCONN,
            'PdcAbortInternal': FM_RPT_PDC_ABORT_INT, 'PdcAbortExternal': FM_RPT_PDC_ABORT_EXT,
            'Dwell': FM_RPT_DWELL},
    'LPT': {'Open': FM_LPT_OPEN, 'S2G': FM_LPT_S2G, 'S2B': FM_LPT_S2B, 'LoRes': FM_LPT_LORES, 'HiRes': FM_LPT_HIRES,
            'CrossConnect': FM_LPT_XCONN, 'UNEX': FM_LPT_UNEXPECTED, 'Internal': FM_LPT_INTERNAL,
            'CurrentSource': FM_LPT_CURRENT_SOURCE, 'Supply': FM_LPT_SUPPLY,
            'LowSideSwitch': FM_LPT_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_LPT_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_LPT_GROUND_LOSS, 'CsrCrossConnect': FM_LPT_CSR_XCONN,
            'PdcAbortInternal': FM_LPT_PDC_ABORT_INT, 'PdcAbortExternal': FM_LPT_PDC_ABORT_EXT,
            'Dwell': FM_LPT_DWELL},
    'RSA': {'Open': FM_RSA_OPEN, 'S2G': FM_RSA_S2G, 'S2B': FM_RSA_S2B, 'LoRes': FM_RSA_LORES, 'HiRes': FM_RSA_HIRES,
            'CrossConnect': FM_RSA_XCONN, 'UNEX': FM_RSA_UNEXPECTED, 'Internal': FM_RSA_INTERNAL,
            'CurrentSource': FM_RSA_CURRENT_SOURCE, 'Supply': FM_RSA_SUPPLY,
            'LowSideSwitch': FM_RSA_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_RSA_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_RSA_GROUND_LOSS, 'CsrCrossConnect': FM_RSA_CSR_XCONN,
            'PdcAbortInternal': FM_RSA_PDC_ABORT_INT, 'PdcAbortExternal': FM_RSA_PDC_ABORT_EXT,
            'Dwell': FM_RSA_DWELL},
    'LSA': {'Open': FM_LSA_OPEN, 'S2G': FM_LSA_S2G, 'S2B': FM_LSA_S2B, 'LoRes': FM_LSA_LORES, 'HiRes': FM_LSA_HIRES,
            'CrossConnect': FM_LSA_XCONN, 'UNEX': FM_LSA_UNEXPECTED, 'Internal': FM_LSA_INTERNAL,
            'CurrentSource': FM_LSA_CURRENT_SOURCE, 'Supply': FM_LSA_SUPPLY,
            'LowSideSwitch': FM_LSA_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_LSA_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_LSA_GROUND_LOSS, 'CsrCrossConnect': FM_LSA_CSR_XCONN,
            'PdcAbortInternal': FM_LSA_PDC_ABORT_INT, 'PdcAbortExternal': FM_LSA_PDC_ABORT_EXT,
            'Dwell': FM_LSA_DWELL},
    'RCA': {'Open': FM_RCA_OPEN, 'S2G': FM_RCA_S2G, 'S2B': FM_RCA_S2B, 'LoRes': FM_RCA_LORES, 'HiRes': FM_RCA_HIRES,
            'CrossConnect': FM_RCA_XCONN, 'UNEX': FM_RCA_UNEXPECTED, 'Internal': FM_RCA_INTERNAL,
            'CurrentSource': FM_RCA_CURRENT_SOURCE, 'Supply': FM_RCA_SUPPLY,
            'LowSideSwitch': FM_RCA_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_RCA_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_RCA_GROUND_LOSS, 'CsrCrossConnect': FM_RCA_CSR_XCONN,
            'PdcAbortInternal': FM_RCA_PDC_ABORT_INT, 'PdcAbortExternal': FM_RCA_PDC_ABORT_EXT,
            'Dwell': FM_RCA_DWELL},
    'LCA': {'Open': FM_LCA_OPEN, 'S2G': FM_LCA_S2G, 'S2B': FM_LCA_S2B, 'LoRes': FM_LCA_LORES, 'HiRes': FM_LCA_HIRES,
            'CrossConnect': FM_LCA_XCONN, 'UNEX': FM_LCA_UNEXPECTED, 'Internal': FM_LCA_INTERNAL,
            'CurrentSource': FM_LCA_CURRENT_SOURCE, 'Supply': FM_LCA_SUPPLY,
            'LowSideSwitch': FM_LCA_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_LCA_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_LCA_GROUND_LOSS, 'CsrCrossConnect': FM_LCA_CSR_XCONN,
            'PdcAbortInternal': FM_LCA_PDC_ABORT_INT, 'PdcAbortExternal': FM_LCA_PDC_ABORT_EXT,
            'Dwell': FM_LCA_DWELL},
    'LLPT': {'Open': FM_LLPT_OPEN, 'S2G': FM_LLPT_S2G, 'S2B': FM_LLPT_S2B, 'LoRes': FM_LLPT_LORES,
             'HiRes': FM_LLPT_HIRES, 'CrossConnect': FM_LLPT_XCONN, 'UNEX': FM_LLPT_UNEXPECTED,
             'Internal': FM_LLPT_INTERNAL, 'CurrentSource': FM_LLPT_CURRENT_SOURCE, 'Supply': FM_LLPT_SUPPLY,
             'LowSideSwitch': FM_LLPT_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_LLPT_HIGH_SIDE_SWITCH,
             'GroundLoss': FM_LLPT_GROUND_LOSS, 'CsrCrossConnect': FM_LLPT_CSR_XCONN,
             'PdcAbortInternal': FM_LLPT_PDC_ABORT_INT, 'PdcAbortExternal': FM_LLPT_PDC_ABORT_EXT,
             'Dwell': FM_LLPT_DWELL},
    'RLPT': {'Open': FM_RLPT_OPEN, 'S2G': FM_RLPT_S2G, 'S2B': FM_RLPT_S2B, 'LoRes': FM_RLPT_LORES,
             'HiRes': FM_RLPT_HIRES, 'CrossConnect': FM_RLPT_XCONN, 'UNEX': FM_RLPT_UNEXPECTED,
             'Internal': FM_RLPT_INTERNAL, 'CurrentSource': FM_RLPT_CURRENT_SOURCE, 'Supply': FM_RLPT_SUPPLY,
             'LowSideSwitch': FM_RLPT_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_RLPT_HIGH_SIDE_SWITCH,
             'GroundLoss': FM_RLPT_GROUND_LOSS, 'CsrCrossConnect': FM_RLPT_CSR_XCONN,
             'PdcAbortInternal': FM_RLPT_PDC_ABORT_INT, 'PdcAbortExternal': FM_RLPT_PDC_ABORT_EXT,
             'Dwell': FM_RLPT_DWELL},
    'DKA': {'Open': FM_DKA_OPEN, 'S2G': FM_DKA_S2G, 'S2B': FM_DKA_S2B, 'LoRes': FM_DKA_LORES, 'HiRes': FM_DKA_HIRES,
            'CrossConnect': FM_DKA_XCONN, 'UNEX': FM_DKA_UNEXPECTED, 'Internal': FM_DKA_INTERNAL,
            'CurrentSource': FM_DKA_CURRENT_SOURCE, 'Supply': FM_DKA_SUPPLY,
            'LowSideSwitch': FM_DKA_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_DKA_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_DKA_GROUND_LOSS, 'CsrCrossConnect': FM_DKA_CSR_XCONN,
            'PdcAbortInternal': FM_DKA_PDC_ABORT_INT, 'PdcAbortExternal': FM_DKA_PDC_ABORT_EXT,
            'Dwell': FM_DKA_DWELL},
    'DAB': {'Open': FM_DAB_OPEN, 'S2G': FM_DAB_S2G, 'S2B': FM_DAB_S2B, 'LoRes': FM_DAB_LORES, 'HiRes': FM_DAB_HIRES,
            'CrossConnect': FM_DAB_XCONN, 'UNEX': FM_DAB_UNEXPECTED, 'Internal': FM_DAB_INTERNAL,
            'CurrentSource': FM_DAB_CURRENT_SOURCE, 'Supply': FM_DAB_SUPPLY,
            'LowSideSwitch': FM_DAB_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_DAB_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_DAB_GROUND_LOSS, 'CsrCrossConnect': FM_DAB_CSR_XCONN,
            'PdcAbortInternal': FM_DAB_PDC_ABORT_INT, 'PdcAbortExternal': FM_DAB_PDC_ABORT_EXT,
            'Dwell': FM_DAB_DWELL},
    'PAB': {'Open': FM_PAB_OPEN, 'S2G': FM_PAB_S2G, 'S2B': FM_PAB_S2B, 'LoRes': FM_PAB_LORES, 'HiRes': FM_PAB_HIRES,
            'CrossConnect': FM_PAB_XCONN, 'UNEX': FM_PAB_UNEXPECTED, 'Internal': FM_PAB_INTERNAL,
            'CurrentSource': FM_PAB_CURRENT_SOURCE, 'Supply': FM_PAB_SUPPLY,
            'LowSideSwitch': FM_PAB_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_PAB_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_PAB_GROUND_LOSS, 'CsrCrossConnect': FM_PAB_CSR_XCONN,
            'PdcAbortInternal': FM_PAB_PDC_ABORT_INT, 'PdcAbortExternal': FM_PAB_PDC_ABORT_EXT,
            'Dwell': FM_PAB_DWELL},
    'CAB': {'Open': FM_CAB_OPEN, 'S2G': FM_CAB_S2G, 'S2B': FM_CAB_S2B, 'LoRes': FM_CAB_LORES, 'HiRes': FM_CAB_HIRES,
            'CrossConnect': FM_CAB_XCONN, 'UNEX': FM_CAB_UNEXPECTED, 'Internal': FM_CAB_INTERNAL,
            'CurrentSource': FM_CAB_CURRENT_SOURCE, 'Supply': FM_CAB_SUPPLY,
            'LowSideSwitch': FM_CAB_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_CAB_HIGH_SIDE_SWITCH,
            'GroundLoss': FM_CAB_GROUND_LOSS, 'CsrCrossConnect': FM_CAB_CSR_XCONN,
            'PdcAbortInternal': FM_CAB_PDC_ABORT_INT, 'PdcAbortExternal': FM_CAB_PDC_ABORT_EXT,
            'Dwell': FM_CAB_DWELL},
    'R2LPT': {'Open': FM_R2LPT_OPEN, 'S2G': FM_R2LPT_S2G, 'S2B': FM_R2LPT_S2B, 'LoRes': FM_R2LPT_LORES,
              'HiRes': FM_R2LPT_HIRES, 'CrossConnect': FM_R2LPT_XCONN, 'UNEX': FM_R2LPT_UNEXPECTED,
              'Internal': FM_R2LPT_INTERNAL, 'CurrentSource': FM_R2LPT_CURRENT_SOURCE, 'Supply': FM_R2LPT_SUPPLY,
              'LowSideSwitch': FM_R2LPT_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_R2LPT_HIGH_SIDE_SWITCH,
              'GroundLoss': FM_R2LPT_GROUND_LOSS, 'CsrCrossConnect': FM_R2LPT_CSR_XCONN,
              'PdcAbortInternal': FM_R2LPT_PDC_ABORT_INT, 'PdcAbortExternal': FM_R2LPT_PDC_ABORT_EXT,
              'Dwell': FM_R2LPT_DWELL},
    'R2RPT': {'Open': FM_R2RPT_OPEN, 'S2G': FM_R2RPT_S2G, 'S2B': FM_R2RPT_S2B, 'LoRes': FM_R2RPT_LORES,
              'HiRes': FM_R2RPT_HIRES, 'CrossConnect': FM_R2RPT_XCONN, 'UNEX': FM_R2RPT_UNEXPECTED,
              'Internal': FM_R2RPT_INTERNAL, 'CurrentSource': FM_R2RPT_CURRENT_SOURCE, 'Supply': FM_R2RPT_SUPPLY,
              'LowSideSwitch': FM_R2RPT_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_R2RPT_HIGH_SIDE_SWITCH,
              'GroundLoss': FM_R2RPT_GROUND_LOSS, 'CsrCrossConnect': FM_R2RPT_CSR_XCONN,
              'PdcAbortInternal': FM_R2RPT_PDC_ABORT_INT, 'PdcAbortExternal': FM_R2RPT_PDC_ABORT_EXT,
              'Dwell': FM_R2RPT_DWELL},
    'DBFL': {'Open': FM_DBFL_OPEN, 'S2G': FM_DBFL_S2G, 'S2B': FM_DBFL_S2B, 'LoRes': FM_DBFL_LORES,
             'HiRes': FM_DBFL_HIRES, 'CrossConnect': FM_DBFL_XCONN, 'UNEX': FM_DBFL_UNEXPECTED,
             'Internal': FM_DBFL_INTERNAL, 'CurrentSource': FM_DBFL_CURRENT_SOURCE, 'Supply': FM_DBFL_SUPPLY,
             'LowSideSwitch': FM_DBFL_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_DBFL_HIGH_SIDE_SWITCH,
             'GroundLoss': FM_DBFL_GROUND_LOSS, 'CsrCrossConnect': FM_DBFL_CSR_XCONN,
             'PdcAbortInternal': FM_DBFL_PDC_ABORT_INT, 'PdcAbortExternal': FM_DBFL_PDC_ABORT_EXT,
             'Dwell': FM_DBFL_DWELL},
    'PBFL': {'Open': FM_PBFL_OPEN, 'S2G': FM_PBFL_S2G, 'S2B': FM_PBFL_S2B, 'LoRes': FM_PBFL_LORES,
             'HiRes': FM_PBFL_HIRES, 'CrossConnect': FM_PBFL_XCONN, 'UNEX': FM_PBFL_UNEXPECTED,
             'Internal': FM_PBFL_INTERNAL, 'CurrentSource': FM_PBFL_CURRENT_SOURCE, 'Supply': FM_PBFL_SUPPLY,
             'LowSideSwitch': FM_PBFL_LOW_SIDE_SWITCH, 'HighSideSwitch': FM_PBFL_HIGH_SIDE_SWITCH,
             'GroundLoss': FM_PBFL_GROUND_LOSS, 'CsrCrossConnect': FM_PBFL_CSR_XCONN,
             'PdcAbortInternal': FM_PBFL_PDC_ABORT_INT, 'PdcAbortExternal': FM_PBFL_PDC_ABORT_EXT,
             'Dwell': FM_PBFL_DWELL},
}

# DCS channel (dcs_config / ods_config name) -> fault type -> fault.
DCS_FAULT_BY_CHANNEL = {
    'DCS_Second_Row_Right': {'S2B': FM_R2R_BELT_S2B, 'CrossConnect': FM_R2R_BELT_XCONN,
                             'Internal': FM_R2R_BELT_ASIC, 'SPI': FM_R2R_BELT_SPI},
    'DCS_DRVR': {'S2B': FM_DRV_BELT_S2B, 'CrossConnect': FM_DRV_BELT_XCONN, 'Internal': FM_DRV_BELT_ASIC,
                 'SPI': FM_DRV_BELT_SPI},
    'DCS_PSGR': {'S2B': FM_PSGR_BELT_S2B, 'CrossConnect': FM_PSGR_BELT_XCONN, 'Internal': FM_PSGR_BELT_ASIC,
                 'SPI': FM_PSGR_BELT_SPI},
    'DCS_Second_Row_Left': {'S2B': FM_R2L_BELT_S2B, 'CrossConnect': FM_R2L_BELT_XCONN, 'Internal': FM_R2L_BELT_ASIC,
                            'SPI': FM_R2L_BELT_SPI},
    'DCS_Second_Row_Middle': {'S2B': FM_R2M_BELT_S2B, 'CrossConnect': FM_R2M_BELT_XCONN,
                              'Internal': FM_R2M_BELT_ASIC, 'SPI': FM_R2M_BELT_SPI},
    'DCS_Driver_Seat_Track_Sensor_1': {'S2B': FM_DRV_STPS1_S2B, 'S2G': FM_DRV_STPS1_S2G, 'Open': FM_DRV_STPS1_OPEN,
                                       'CrossConnect': FM_DRV_STPS1_XCONN, 'UNEX': FM_DRV_STPS1_UNEXPECTED,
                                       'Internal': FM_DRV_STPS1_ASIC, 'SPI': FM_DRV_STPS1_SPI},
    'DCS_Driver_Seat_Track_Sensor_2': {'UNEX': FM_DRV_STPS2_UNEXPECTED, 'Internal': FM_DRV_STPS2_ASIC,
                                       'SPI': FM_DRV_STPS2_SPI},
    'DCS_Passenger_Seat_Track_Sensor_1': {'S2B': FM_PSGR_STPS1_S2B, 'S2G': FM_PSGR_STPS1_S2G,
                                          'Open': FM_PSGR_STPS1_OPEN, 'CrossConnect': FM_PSGR_STPS1_XCONN,
                                          'UNEX': FM_PSGR_STPS1_UNEXPECTED, 'Internal': FM_PSGR_STPS1_ASIC,
                                          'SPI': FM_PSGR_STPS1_SPI},
    'DCS_Passenger_Seat_Track_Sensor_2': {'UNEX': FM_PSGR_STPS2_UNEXPECTED, 'Internal': FM_PSGR_STPS2_ASIC,
                                          'SPI': FM_PSGR_STPS2_SPI},
    'DCS_Second_Row_Right_ODS': {'S2B': FM_R2R_ODS_S2B, 'CrossConnect': FM_R2R_ODS_XCONN,
                                 'Internal': FM_R2R_ODS_ASIC, 'SPI': FM_R2R_ODS_SPI},
    'DCS_Second_Row_Left_ODS': {'S2B': FM_R2L_ODS_S2B, 'CrossConnect': FM_R2L_ODS_XCONN,
                                'Internal': FM_R2L_ODS_ASIC, 'SPI': FM_R2L_ODS_SPI},
    'DCS_Second_Row_Middle_ODS': {'S2B': FM_R2M_ODS_S2B, 'CrossConnect': FM_R2M_ODS_XCONN,
                                  'Internal': FM_R2M_ODS_ASIC, 'SPI': FM_R2M_ODS_SPI},
    'DCS_Third_Row_Right': {'S2B': FM_R3R_BELT_S2B, 'CrossConnect': FM_R3R_BELT_XCONN, 'Internal': FM_R3R_BELT_ASIC,
                            'SPI': FM_R3R_BELT_SPI},
    'DCS_Third_Row_Left': {'S2B': FM_R3L_BELT_S2B, 'CrossConnect': FM_R3L_BELT_XCONN, 'Internal': FM_R3L_BELT_ASIC,
                           'SPI': FM_R3L_BELT_SPI},
    'DCS_Third_Row_Right_ODS': {'S2B': FM_R3R_ODS_S2B, 'CrossConnect': FM_R3R_ODS_XCONN,
                                'Internal': FM_R3R_ODS_ASIC, 'SPI': FM_R3R_ODS_SPI},
    'DCS_Third_Row_Left_ODS': {'S2B': FM_R3L_ODS_S2B, 'CrossConnect': FM_R3L_ODS_XCONN, 'Internal': FM_R3L_ODS_ASIC,
                               'SPI': FM_R3L_ODS_SPI},
}

# GPO output (gpo_config name, plus ECALL) -> fault type -> fault.
GPO_FAULT_BY_OUTPUT = {
    'PAB_OFF': {'S2G': FM_PAB_OFF_S2G, 'S2B': FM_PAB_OFF_S2B, 'OPEN': FM_PAB_OFF_OPEN, 'CONFIG': FM_PAB_OFF_CONFIG,
                'THERMAL': FM_PAB_OFF_THERMAL, 'INTERNAL': FM_PAB_OFF_INTERNAL, 'SPI': FM_PAB_OFF_SPI,
                'UNEX': FM_PAB_OFF_UNEXPECTED},
    'PAB_ON': {'S2G': FM_PAB_ON_S2G, 'S2B': FM_PAB_ON_S2B, 'OPEN': FM_PAB_ON_OPEN, 'CONFIG': FM_PAB_ON_CONFIG,
               'THERMAL': FM_PAB_ON_THERMAL, 'INTERNAL': FM_PAB_ON_INTERNAL, 'SPI': FM_PAB_ON_SPI,
               'UNEX': FM_PAB_ON_UNEXPECTED},
    'ENS': {'S2G': FM_ENS_S2G, 'S2B': FM_ENS_S2B, 'OPEN': FM_ENS_OPEN, 'CONFIG': FM_ENS_CONFIG,
            'THERMAL': FM_ENS_THERMAL, 'INTERNAL': FM_ENS_INTERNAL, 'SPI': FM_ENS_SPI, 'UNEX': FM_ENS_UNEXPECTED},
    'ECALL': {'S2G': FM_ECALL_S2G, 'S2B': FM_ECALL_S2B, 'OPEN': FM_ECALL_OPEN, 'CONFIG': FM_ECALL_CONFIG,
              'THERMAL': FM_ECALL_THERMAL, 'INTERNAL': FM_ECALL_INTERNAL, 'SPI': FM_ECALL_SPI,
              'UNEX': FM_ECALL_UNEXPECTED},
}

# RSU satellite sensor -> fault type (rsu_fault_code key) -> fault.
RSU_FAULT_BY_SATELLITE = {
    'A_PILLAR_LEFT_S1': {'Open': FM_A_PILLAR_LEFT_S1_OPEN, 'S2G': FM_A_PILLAR_LEFT_S1_S2G,
                         'S2B': FM_A_PILLAR_LEFT_S1_S2B, 'Communication_Error': FM_A_PILLAR_LEFT_S1_COMM,
                         'Internal_Error': FM_A_PILLAR_LEFT_S1_INTERNAL, 'Config': FM_A_PILLAR_LEFT_S1_CONFIG,
                         'UNEX': FM_A_PILLAR_LEFT_S1_UNEXPECTED},
    'A_PILLAR_LEFT_S2': {'Open': FM_A_PILLAR_LEFT_S2_OPEN, 'S2G': FM_A_PILLAR_LEFT_S2_S2G,
                         'S2B': FM_A_PILLAR_LEFT_S2_S2B, 'Communication_Error': FM_A_PILLAR_LEFT_S2_COMM,
                         'Internal_Error': FM_A_PILLAR_LEFT_S2_INTERNAL, 'Config': FM_A_PILLAR_LEFT_S2_CONFIG,
                         'UNEX': FM_A_PILLAR_LEFT_S2_UNEXPECTED},
    'PRESSURE_RIGHT_S3': {'Open': FM_PRESSURE_RIGHT_S3_OPEN, 'S2G': FM_PRESSURE_RIGHT_S3_S2G,
                          'S2B': FM_PRESSURE_RIGHT_S3_S2B, 'Communication_Error': FM_PRESSURE_RIGHT_S3_COMM,
                          'Internal_Error': FM_PRESSURE_RIGHT_S3_INTERNAL, 'Config': FM_PRESSURE_RIGHT_S3_CONFIG,
                          'UNEX': FM_PRESSURE_RIGHT_S3_UNEXPECTED},
    'A_PILLAR_RIGHT_S1': {'Open': FM_A_PILLAR_RIGHT_S1_OPEN, 'S2G': FM_A_PILLAR_RIGHT_S1_S2G,
                          'S2B': FM_A_PILLAR_RIGHT_S1_S2B, 'Communication_Error': FM_A_PILLAR_RIGHT_S1_COMM,
                          'Internal_Error': FM_A_PILLAR_RIGHT_S1_INTERNAL, 'Config': FM_A_PILLAR_RIGHT_S1_CONFIG,
                          'UNEX': FM_A_PILLAR_RIGHT_S1_UNEXPECTED},
    'A_PILLAR_RIGHT_S2': {'Open': FM_A_PILLAR_RIGHT_S2_OPEN, 'S2G': FM_A_PILLAR_RIGHT_S2_S2G,
                          'S2B': FM_A_PILLAR_RIGHT_S2_S2B, 'Communication_Error': FM_A_PILLAR_RIGHT_S2_COMM,
                          'Internal_Error': FM_A_PILLAR_RIGHT_S2_INTERNAL, 'Config': FM_A_PILLAR_RIGHT_S2_CONFIG,
                          'UNEX': FM_A_PILLAR_RIGHT_S2_UNEXPECTED},
    'PRESSURE_LEFT_S3': {'Open': FM_PRESSURE_LEFT_S3_OPEN, 'S2G': FM_PRESSURE_LEFT_S3_S2G,
                         'S2B': FM_PRESSURE_LEFT_S3_S2B, 'Communication_Error': FM_PRESSURE_LEFT_S3_COMM,
                         'Internal_Error': FM_PRESSURE_LEFT_S3_INTERNAL, 'Config': FM_PRESSURE_LEFT_S3_CONFIG,
                         'UNEX': FM_PRESSURE_LEFT_S3_UNEXPECTED},
    'B_PILLAR_LEFT_S1': {'Open': FM_B_PILLAR_LEFT_S1_OPEN, 'S2G': FM_B_PILLAR_LEFT_S1_S2G,
                         'S2B': FM_B_PILLAR_LEFT_S1_S2B, 'Communication_Error': FM_B_PILLAR_LEFT_S1_COMM,
                         'Internal_Error': FM_B_PILLAR_LEFT_S1_INTERNAL, 'Config': FM_B_PILLAR_LEFT_S1_CONFIG,
                         'UNEX': FM_B_PILLAR_LEFT_S1_UNEXPECTED},
    'B_PILLAR_LEFT_S2': {'Open': FM_B_PILLAR_LEFT_S2_OPEN, 'S2G': FM_B_PILLAR_LEFT_S2_S2G,
                         'S2B': FM_B_PILLAR_LEFT_S2_S2B, 'Communication_Error': FM_B_PILLAR_LEFT_S2_COMM,
                         'Internal_Error': FM_B_PILLAR_LEFT_S2_INTERNAL, 'Config': FM_B_PILLAR_LEFT_S2_CONFIG,
                         'UNEX': FM_B_PILLAR_LEFT_S2_UNEXPECTED},
    'B_PILLAR_RIGHT_S1': {'Open': FM_B_PILLAR_RIGHT_S1_OPEN, 'S2G': FM_B_PILLAR_RIGHT_S1_S2G,
                          'S2B': FM_B_PILLAR_RIGHT_S1_S2B, 'Communication_Error': FM_B_PILLAR_RIGHT_S1_COMM,
                          'Internal_Error': FM_B_PILLAR_RIGHT_S1_INTERNAL, 'Config': FM_B_PILLAR_RIGHT_S1_CONFIG,
                          'UNEX': FM_B_PILLAR_RIGHT_S1_UNEXPECTED},
    'B_PILLAR_RIGHT_S2': {'Open': FM_B_PILLAR_RIGHT_S2_OPEN, 'S2G': FM_B_PILLAR_RIGHT_S2_S2G,
                          'S2B': FM_B_PILLAR_RIGHT_S2_S2B, 'Communication_Error': FM_B_PILLAR_RIGHT_S2_COMM,
                          'Internal_Error': FM_B_PILLAR_RIGHT_S2_INTERNAL, 'Config': FM_B_PILLAR_RIGHT_S2_CONFIG,
                          'UNEX': FM_B_PILLAR_RIGHT_S2_UNEXPECTED},
    'FRONT_LEFT_S1': {'Open': FM_FRONT_LEFT_S1_OPEN, 'S2G': FM_FRONT_LEFT_S1_S2G, 'S2B': FM_FRONT_LEFT_S1_S2B,
                      'Communication_Error': FM_FRONT_LEFT_S1_COMM, 'Internal_Error': FM_FRONT_LEFT_S1_INTERNAL,
                      'Config': FM_FRONT_LEFT_S1_CONFIG, 'UNEX': FM_FRONT_LEFT_S1_UNEXPECTED},
    'FRONT_LEFT_S2': {'Open': FM_FRONT_LEFT_S2_OPEN, 'S2G': FM_FRONT_LEFT_S2_S2G, 'S2B': FM_FRONT_LEFT_S2_S2B,
                      'Communication_Error': FM_FRONT_LEFT_S2_COMM, 'Internal_Error': FM_FRONT_LEFT_S2_INTERNAL,
                      'Config': FM_FRONT_LEFT_S2_CONFIG, 'UNEX': FM_FRONT_LEFT_S2_UNEXPECTED},
    'FRONT_RIGHT_S1': {'Open': FM_FRONT_RIGHT_S1_OPEN, 'S2G': FM_FRONT_RIGHT_S1_S2G, 'S2B': FM_FRONT_RIGHT_S1_S2B,
                       'Communication_Error': FM_FRONT_RIGHT_S1_COMM, 'Internal_Error': FM_FRONT_RIGHT_S1_INTERNAL,
                       'Config': FM_FRONT_RIGHT_S1_CONFIG, 'UNEX': FM_FRONT_RIGHT_S1_UNEXPECTED},
    'FRONT_RIGHT_S2': {'Open': FM_FRONT_RIGHT_S2_OPEN, 'S2G': FM_FRONT_RIGHT_S2_S2G, 'S2B': FM_FRONT_RIGHT_S2_S2B,
                       'Communication_Error': FM_FRONT_RIGHT_S2_COMM, 'Internal_Error': FM_FRONT_RIGHT_S2_INTERNAL,
                       'Config': FM_FRONT_RIGHT_S2_CONFIG, 'UNEX': FM_FRONT_RIGHT_S2_UNEXPECTED},
    'C_PILLAR_LEFT_S1': {'Open': FM_C_PILLAR_LEFT_S1_OPEN, 'S2G': FM_C_PILLAR_LEFT_S1_S2G,
                         'S2B': FM_C_PILLAR_LEFT_S1_S2B, 'Communication_Error': FM_C_PILLAR_LEFT_S1_COMM,
                         'Internal_Error': FM_C_PILLAR_LEFT_S1_INTERNAL, 'Config': FM_C_PILLAR_LEFT_S1_CONFIG,
                         'UNEX': FM_C_PILLAR_LEFT_S1_UNEXPECTED},
    'C_PILLAR_LEFT_S2': {'Open': FM_C_PILLAR_LEFT_S2_OPEN, 'S2G': FM_C_PILLAR_LEFT_S2_S2G,
                         'S2B': FM_C_PILLAR_LEFT_S2_S2B, 'Communication_Error': FM_C_PILLAR_LEFT_S2_COMM,
                         'Internal_Error': FM_C_PILLAR_LEFT_S2_INTERNAL, 'Config': FM_C_PILLAR_LEFT_S2_CONFIG,
                         'UNEX': FM_C_PILLAR_LEFT_S2_UNEXPECTED},
    'C_PILLAR_RIGHT_S1': {'Open': FM_C_PILLAR_RIGHT_S1_OPEN, 'S2G': FM_C_PILLAR_RIGHT_S1_S2G,
                          'S2B': FM_C_PILLAR_RIGHT_S1_S2B, 'Communication_Error': FM_C_PILLAR_RIGHT_S1_COMM,
                          'Internal_Error': FM_C_PILLAR_RIGHT_S1_INTERNAL, 'Config': FM_C_PILLAR_RIGHT_S1_CONFIG,
                          'UNEX': FM_C_PILLAR_RIGHT_S1_UNEXPECTED},
    'C_PILLAR_RIGHT_S2': {'Open': FM_C_PILLAR_RIGHT_S2_OPEN, 'S2G': FM_C_PILLAR_RIGHT_S2_S2G,
                          'S2B': FM_C_PILLAR_RIGHT_S2_S2B, 'Communication_Error': FM_C_PILLAR_RIGHT_S2_COMM,
                          'Internal_Error': FM_C_PILLAR_RIGHT_S2_INTERNAL, 'Config': FM_C_PILLAR_RIGHT_S2_CONFIG,
                          'UNEX': FM_C_PILLAR_RIGHT_S2_UNEXPECTED},
    'UNDERBODY_S1': {'Open': FM_UNDERBODY_S1_OPEN, 'S2G': FM_UNDERBODY_S1_S2G, 'S2B': FM_UNDERBODY_S1_S2B,
                     'Communication_Error': FM_UNDERBODY_S1_COMM, 'Internal_Error': FM_UNDERBODY_S1_INTERNAL,
                     'Config': FM_UNDERBODY_S1_CONFIG, 'UNEX': FM_UNDERBODY_S1_UNEXPECTED},
    'UNDERBODY_S2': {'Open': FM_UNDERBODY_S2_OPEN, 'S2G': FM_UNDERBODY_S2_S2G, 'S2B': FM_UNDERBODY_S2_S2B,
                     'Communication_Error': FM_UNDERBODY_S2_COMM, 'Internal_Error': FM_UNDERBODY_S2_INTERNAL,
                     'Config': FM_UNDERBODY_S2_CONFIG, 'UNEX': FM_UNDERBODY_S2_UNEXPECTED},
    'REAR_S3': {'Open': FM_REAR_S3_OPEN, 'S2G': FM_REAR_S3_S2G, 'S2B': FM_REAR_S3_S2B,
                'Communication_Error': FM_REAR_S3_COMM, 'Internal_Error': FM_REAR_S3_INTERNAL,
                'Config': FM_REAR_S3_CONFIG, 'UNEX': FM_REAR_S3_UNEXPECTED},
}


# ====================================================================================================
# Fault_List settings of the per-DTC scripts
# ====================================================================================================
# Vehicle type: the per-DTC scripts cover faults_for(VEHICLE_TYPE).
VEHICLE_TYPE = "EV"
# IGN OFF time of one ignition cycle (PS.IGN_OFF, wait, PS.IGN_ON) - the 4 s of PS.Power_Cycle.
IGN_OFF_TIME_MS = 4000
# Read interval while waiting for the warning lamp to change.
LAMP_POLL_INTERVAL_MS = 10
# faultTimeMeasurement sees a DTC change at most this late (not measured on this bench: the upper timing limit gets no lag allowance).
FAULT_TIME_MEASUREMENT_LAG_MS = 0


# ====================================================================================================
# Common EV / ICE DTC list: one dict per DTC, named by the DTC's mnemonic
# ====================================================================================================
# Sources: docs/project_documents/Common_DTC_List/EV_DTC_LIST/EV_DTC.xlsx (sheet 'DTC List EV'); docs/project_documents/Common_DTC_List/ICE_DTC_LIST/ICE_DTC.xlsx (sheet ' DTC List')
# Built with tools/build_common_dtc_dictionary.py; rebuild it there rather than edit by hand. What each
# DTC is and how to create it: docs/project_documents/Common_DTC_List/common_dtc_dictionary.py;
# workbook conflicts: docs/project_documents/Common_DTC_List/DTC_LIST_CONFLICTS.md.
# 431 DTCs: 317 for EV and ICE, 0 EV only, 114 ICE only.
#
# Fields of each DTC:
#   dtc_hex             3-byte DTC as ISO 14229-1 reports it (e.g. 0x800111)
#   applicable_to       ('EV', 'ICE'), ('EV',) or ('ICE',)
#   mnemonic            the dict's own name (naming rules below)
#   short_notation      SAE J2012 five-character DTC, '-', failure type byte (e.g. B0001-11)
#   dtc_type            SAE J2012 system letter: B (Body), C (Chassis), P (Powertrain), U (Network)
#   ftb                 failure type byte, SAE J2012-DA (e.g. 0x11)
#   fault_type          what fails, in words
#   set_condition, heal_condition, precondition: the workbook's text
#   memory              where the DTC is stored (workbook RAM / EEPROM / Other)
#   time_tolerance_pct  mature / demature time tolerance in percent (None: '-' or blank)
#   mature_time, demature_time: the workbook's text; mature_time_ms / demature_time_ms the same in ms,
#                       None where the workbook gives no plain time (NA, Immediate, 1 IGN Cycle,
#                       within PDC(...), network management sheet, a number without unit)
#   ageing_cycles       IGN cycles a healed DTC stays stored before it ages out (None: NA or blank)
#   warning_lamp        airbag warning lamp while the DTC is active: 'ON', 'OFF', 'FLASHING_1HZ'
#                       (None: NA or blank in the workbook)
#   group               device group
#   description         workbook description, for traceability
# A field where the EV and ICE lists disagree holds {'EV': ..., 'ICE': ...}.
#
# Naming rules (ISO 26262-6 asks for naming conventions in the coding guidelines but prescribes no DTC
# names; these are the ones applied and checked by the build):
# - Mnemonic = <LOCATION>_<COMPONENT>_<FAULT>, e.g. R2_LH_PT_STB: location and component from the
#   workbook description, fault from the DTC's failure type (SAE J2012-DA FTB names where the workbook
#   uses the FTB that way). CAN DTCs: <NODE>_NODE_ABSENT, <NODE>_MTO, <FRAME>_MCF, <SIGNAL>_SCF with the
#   workbook's (DBC) node, frame or signal name.
# - Upper-case words joined by '_', letters and digits only, at most 31 characters (MISRA C:2012
#   rule 5.1), unique: usable unchanged as a C symbol or AUTOSAR SHORT-NAME (e.g. a DEM event).
# - Every word comes from MNEMONIC_GLOSSARY (CAN frame and signal names excepted); every location word
#   (DRV, PSG, LH, RH, R2, R3, MID, CTR) is backed by the description, or explained in NAMING_NOTES.
# - Two DTCs for the same fault: the one of the device's main DTC base keeps the name, the other gets its
#   DTC base appended (NAMING_NOTES).
# - Field names are lower-case snake_case and carry their unit when numeric (_ms, _pct, ageing_cycles).
# ====================================================================================================

MNEMONIC_GLOSSARY = {
    "DRV": "driver side, front row (workbook DRIVER)",
    "PSG": "passenger side, front row (workbook PASSENGER / CO-DRIVER)",
    "LH": "left-hand side (workbook LEFT)",
    "RH": "right-hand side (workbook RIGHT)",
    "CTR": "centre (workbook CENTER)",
    "MID": "middle seat (workbook MIDDLE)",
    "R2": "second seat row",
    "R3": "third seat row",
    "FRONT": "front",
    "REAR": "rear",
    "SIDE": "side",
    "UB": "under body",
    "APLR": "A-pillar",
    "BPLR": "B-pillar",
    "CPLR": "C-pillar",
    "DAB": "driver airbag",
    "PAB": "passenger airbag",
    "AV": "dual active vent squib of the airbag",
    "SAB": "side (thorax) airbag",
    "IC": "inflatable curtain airbag (workbook CURTAIN AIRBAG)",
    "KAB": "knee airbag",
    "FSAB": "far-side airbag",
    "PT": "belt pretensioner",
    "LAP": "lap belt",
    "BFL": "belt force limiter (workbook PRE-TENSIONER ADAPTIVE LOAD LIMITER; bench squibs_config DBFL / PBFL)",
    "PRC": "pelvis restraint cushion",
    "PYRO": "pyrotechnic",
    "SW": "switch",
    "DIS": "disable",
    "EN": "enable / enabled",
    "FRSU": "front remote sensing unit (crash satellite)",
    "SRSU": "side remote sensing unit (crash satellite)",
    "RSU": "remote sensing unit (crash satellite)",
    "PRES": "pressure",
    "SNS": "sensor",
    "BKL": "seat belt buckle switch (DCS channel)",
    "ODS": "occupant detection sensor",
    "STPS1": "seat track position sensor 1",
    "STPS2": "seat track position sensor 2",
    "OFF": "off",
    "ON": "on",
    "LMP": "lamp",
    "LED": "light-emitting diode output",
    "CRASH": "crash",
    "OUT": "hardwired output line",
    "ECALL": "emergency call (eCall)",
    "SBR": "seat belt reminder",
    "ACN": "automatic crash notification",
    "LOOP": "deployment (squib) loop",
    "DCS": "buckle switch input (DCS)",
    "GPO": "general purpose output",
    "AWL": "airbag warning lamp",
    "FAIL": "failure",
    "VBAT": "battery supply voltage",
    "UV": "under-voltage",
    "OV": "over-voltage",
    "ECU": "airbag control unit",
    "LOCK": "ECU locked after a crash (permanent)",
    "ROLLOVER": "roll-over",
    "UNDERSTRIKE": "under-body strike",
    "DEPLOY": "deployment",
    "PLANT": "plant (production)",
    "MODE": "mode",
    "SCRAP": "vehicle scrapping",
    "SVD": "SVD function (workbook term; its expansion is not given)",
    "EDR": "event data recorder",
    "RECORD": "record",
    "FULL": "full",
    "CAL": "calibration",
    "MISSING": "missing",
    "INCORRECT": "incorrect",
    "IMU": "inertial measurement unit (on-board)",
    "CRC": "cyclic redundancy check",
    "SPI": "serial peripheral interface",
    "ERR": "error",
    "CNT": "counter",
    "SELF": "self",
    "TEST": "test",
    "RECOV": "recoverable",
    "INTEGRITY": "data integrity check",
    "SEV": "SEV1 / SEV2 / SEV3 failure",
    "OOR": "out of range",
    "X": "X axis",
    "Y": "Y axis",
    "Z": "Z axis",
    "YAW": "yaw",
    "ROLL": "roll",
    "PITCH": "pitch",
    "TEMP": "temperature",
    "STG": "short circuit to ground (SAE J2012-DA FTB 0x11)",
    "STB": "short circuit to battery (FTB 0x12)",
    "OPEN": "open circuit (FTB 0x13)",
    "RES": "circuit resistance: RES_LOW below threshold (FTB 0x1A), RES_HIGH above threshold (FTB 0x1B), RES_OOR out of range (FTB 0x1E)",
    "LOW": "low / below threshold",
    "HIGH": "high / above threshold",
    "XCONN": "cross connection with another channel or sensor (FTB 0x2B signal cross coupled; the workbook uses 0x01 for squib loops)",
    "UNEXPECTED": "connected although the configuration says not fitted (workbook FTB 0x64)",
    "LOAD": "load",
    "CONFIG": "configuration error: device and EOL configuration disagree (workbook FTB 0x64)",
    "COMM": "communication error: invalid serial data received (FTB 0x81)",
    "INTERNAL": "internal failure (FTB 0x96 component internal failure; 0x49 for the ECU)",
    "SAMPLE": "sampling",
    "RATE": "rate",
    "RAILED": "output railed: stuck at its limit (workbook FTB 0x87)",
    "UNCONF": "unconfirmed",
    "NODE": "CAN node",
    "ABSENT": "absent: its key message is missing",
    "MTO": "message timeout: a non-key message is missing",
    "MCF": "message content failure: wrong DLC, CRC or alive counter",
    "SCF": "signal content failure: invalid signal value",
    "SRS": "the SRS ECU itself",
    "HSCAN": "high-speed CAN",
    "BUS": "bus",
    "VIN": "vehicle identification number",
    "MISMATCH": "mismatch",
    "VARIANT": "variant",
    "CODE": "code",
    "FEATURE": "feature",
}

NAMING_NOTES = {
    "LH_FRSU_UNCONF_CRASH": "Description reads 'UNCONFIRMED CRASH CoRIGHT FRSU'; named LH from its DTC base B0090, which the lists use for the LEFT FRSU (inference).",
    "LH_SRSU_UNCONF_CRASH": "Description reads 'UNCONFIRMED CRASH CoRIGHT SRSU' and B120D has no other DTC; named LH like B009097 'CoRIGHT FRSU' of the LEFT FRSU base (inference). No pillar given.",
    "RH_SRSU_UNCONF_CRASH": "No pillar given in the description; B120E has no other DTC.",
    "PAB_EN_SW_RES_HIGH": "Description reads 'PASSENGER AIRBAG SWITCH-HIGH RESISTANCE' without ENABLE; named from its DTC base B1241, the PAB enable switch.",
    "PAB_DIS_SW_RES_LOW": "DTC base B120C; named with the B1205 PAB (disable) switch, both 'PASSENGER AIRBAG SWITCH'.",
    "PAB_DIS_SW_RES_HIGH": "DTC base B120C; named with the B1205 PAB (disable) switch, both 'PASSENGER AIRBAG SWITCH'.",
    "PAB_DIS_SW_RES_OOR": "DTC base B120C; named with the B1205 PAB (disable) switch, both 'PASSENGER AIRBAG SWITCH'.",
    "RH_APLR_SRSU_XCONN": "DTC base B1239, not B1237 like the other A-pillar right SRSU DTCs; same satellite by its description.",
    "LH_APLR_SRSU_XCONN": "DTC base B1240, not B1236 like the other A-pillar left SRSU DTCs; same satellite by its description.",
    "IMU_OOR_TEMP": "Description reads 'Out of Range failure on YAW Temperature'; named for temperature like B122B00 (inference).",
    "DAB_AV_OPEN_B18F1": "Same fault as B126113 (DAB_AV_OPEN); named with its DTC base added. See DTC_LIST_CONFLICTS.md.",
}

# B code - Body: B1013-49
ECU_INTERNAL = {
    "dtc_hex": "0x901349",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_INTERNAL",
    "short_notation": "B1013-49",
    "dtc_type": "B (Body)",
    "ftb": "0x49",
    "fault_type": "Internal error",
    "set_condition": "Multiple Conditions due to internal faults",
    "heal_condition": "NA",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "1) IGN ON",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "ECU internal / configuration",
    "description": "SRS ECU INTERNAL ERROR",
}

# B code - Body: B1261-11
DAB_AV_STG = {
    "dtc_hex": "0x926111",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_STG",
    "short_notation": "B1261-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Dr. Sq. Shorted to GND",
    "heal_condition": "Dr. Sq. Recovered from Short to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B0001-11
DAB_STG = {
    "dtc_hex": "0x800111",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_STG",
    "short_notation": "B0001-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Dr. Sq. Shorted to GND",
    "heal_condition": "Dr. Sq. Recovered from Short to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1262-11
PAB_AV_STG = {
    "dtc_hex": "0x926211",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_AV_STG",
    "short_notation": "B1262-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG DUAL ACTIVE VENT SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B0010-11
PAB_STG = {
    "dtc_hex": "0x801011",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_STG",
    "short_notation": "B0010-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1263-11
RH_BFL_STG = {
    "dtc_hex": "0x926311",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_STG",
    "short_notation": "B1263-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B0070-11
RH_PT_STG = {
    "dtc_hex": "0x807011",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_STG",
    "short_notation": "B0070-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1264-11
LH_BFL_STG = {
    "dtc_hex": "0x926411",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_STG",
    "short_notation": "B1264-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B0072-11
LH_PT_STG = {
    "dtc_hex": "0x807211",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_STG",
    "short_notation": "B0072-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1261-12
DAB_AV_STB = {
    "dtc_hex": "0x926112",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_STB",
    "short_notation": "B1261-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1261-13
DAB_AV_OPEN = {
    "dtc_hex": "0x926113",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_AV_OPEN",
    "short_notation": "B1261-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": {
        "EV": "1) IGN ON; 2) Voltage should be normal.",
        "ICE": None,
    },
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT SQUIB OPEN CIRCUIT",
}

# B code - Body: B0001-12
DAB_STB = {
    "dtc_hex": "0x800112",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_STB",
    "short_notation": "B0001-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1262-12
PAB_AV_STB = {
    "dtc_hex": "0x926212",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_AV_STB",
    "short_notation": "B1262-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG DUAL ACTIVE VENT SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B0010-12
PAB_STB = {
    "dtc_hex": "0x801012",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_STB",
    "short_notation": "B0010-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1263-12
RH_BFL_STB = {
    "dtc_hex": "0x926312",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_STB",
    "short_notation": "B1263-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B0070-12
RH_PT_STB = {
    "dtc_hex": "0x807012",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_STB",
    "short_notation": "B0070-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1264-12
LH_BFL_STB = {
    "dtc_hex": "0x926412",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_STB",
    "short_notation": "B1264-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B0072-12
LH_PT_STB = {
    "dtc_hex": "0x807212",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_STB",
    "short_notation": "B0072-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1261-1A
DAB_AV_RES_LOW = {
    "dtc_hex": "0x92611A",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_RES_LOW",
    "short_notation": "B1261-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT SQUIB LOW RES",
}

# B code - Body: B0001-1A
DAB_RES_LOW = {
    "dtc_hex": "0x80011A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_RES_LOW",
    "short_notation": "B0001-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG SQUIB LOW RES",
}

# B code - Body: B1262-1A
PAB_AV_RES_LOW = {
    "dtc_hex": "0x92621A",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_AV_RES_LOW",
    "short_notation": "B1262-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG DUAL ACTIVE VENT SQUIB LOW RES",
}

# B code - Body: B0010-1A
PAB_RES_LOW = {
    "dtc_hex": "0x80101A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_RES_LOW",
    "short_notation": "B0010-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG SQUIB LOW RES",
}

# B code - Body: B1263-1A
RH_BFL_RES_LOW = {
    "dtc_hex": "0x92631A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_RES_LOW",
    "short_notation": "B1263-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB LOW RES",
}

# B code - Body: B0070-1A
RH_PT_RES_LOW = {
    "dtc_hex": "0x80701A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_RES_LOW",
    "short_notation": "B0070-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER SQUIB LOW RES",
}

# B code - Body: B1264-1A
LH_BFL_RES_LOW = {
    "dtc_hex": "0x92641A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_RES_LOW",
    "short_notation": "B1264-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB LOW RES",
}

# B code - Body: B0072-1A
LH_PT_RES_LOW = {
    "dtc_hex": "0x80721A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_RES_LOW",
    "short_notation": "B0072-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER SQUIB LOW RES",
}

# B code - Body: B1261-1B
DAB_AV_RES_HIGH = {
    "dtc_hex": "0x92611B",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_RES_HIGH",
    "short_notation": "B1261-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT SQUIB HIGH RES",
}

# B code - Body: B0001-1B
DAB_RES_HIGH = {
    "dtc_hex": "0x80011B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_RES_HIGH",
    "short_notation": "B0001-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG SQUIB HIGH RES",
}

# B code - Body: B1262-1B
PAB_AV_RES_HIGH = {
    "dtc_hex": "0x92621B",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_AV_RES_HIGH",
    "short_notation": "B1262-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG DUAL ACTIVE VENT SQUIB HIGH RES",
}

# B code - Body: B0010-1B
PAB_RES_HIGH = {
    "dtc_hex": "0x80101B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_RES_HIGH",
    "short_notation": "B0010-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG SQUIB HIGH RES",
}

# B code - Body: B1263-1B
RH_BFL_RES_HIGH = {
    "dtc_hex": "0x92631B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_RES_HIGH",
    "short_notation": "B1263-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB HIGH RES",
}

# B code - Body: B0070-1B
RH_PT_RES_HIGH = {
    "dtc_hex": "0x80701B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_RES_HIGH",
    "short_notation": "B0070-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER SQUIB HIGH RES",
}

# B code - Body: B1264-1B
LH_BFL_RES_HIGH = {
    "dtc_hex": "0x92641B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_RES_HIGH",
    "short_notation": "B1264-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB HIGH RES",
}

# B code - Body: B0072-1B
LH_PT_RES_HIGH = {
    "dtc_hex": "0x80721B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_RES_HIGH",
    "short_notation": "B0072-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER SQUIB HIGH RES",
}

# B code - Body: B1261-01
DAB_AV_XCONN = {
    "dtc_hex": "0x926101",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_XCONN",
    "short_notation": "B1261-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT SQUIB CROSS CONNECT",
}

# B code - Body: B0001-01
DAB_XCONN = {
    "dtc_hex": "0x800101",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_XCONN",
    "short_notation": "B0001-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG SQUIB CROSS CONNECT",
}

# B code - Body: B1262-01
PAB_AV_XCONN = {
    "dtc_hex": "0x926201",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_AV_XCONN",
    "short_notation": "B1262-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG ACTIVE VENT SQUIB CROSS CONNECT",
}

# B code - Body: B0010-01
PAB_XCONN = {
    "dtc_hex": "0x801001",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_XCONN",
    "short_notation": "B0010-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG SQUIB CROSS CONNECT",
}

# B code - Body: B1263-01
RH_BFL_XCONN = {
    "dtc_hex": "0x926301",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_XCONN",
    "short_notation": "B1263-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB CROSS CONNECT",
}

# B code - Body: B0070-01
RH_PT_XCONN = {
    "dtc_hex": "0x807001",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_XCONN",
    "short_notation": "B0070-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRE-TENSIONER SQUIB CROSS CONNECT",
}

# B code - Body: B1264-01
LH_BFL_XCONN = {
    "dtc_hex": "0x926401",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_XCONN",
    "short_notation": "B1264-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER ADAPTIVE LOAD LIMITER SQUIB CROSS CONNECT",
}

# B code - Body: B0072-01
LH_PT_XCONN = {
    "dtc_hex": "0x807201",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_XCONN",
    "short_notation": "B0072-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRE-TENSIONER SQUIB CROSS CONNECT",
}

# B code - Body: B142A-16
VBAT_UV = {
    "dtc_hex": "0x942A16",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VBAT_UV",
    "short_notation": "B142A-16",
    "dtc_type": "B (Body)",
    "ftb": "0x16",
    "fault_type": "Supply voltage low",
    "set_condition": "The measured voltage is below 9V. Qualification: The measured voltage is below threshold for low supply voltage",
    "heal_condition": "The measured voltage is above threshold for high supply voltage",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3175ms",
    "mature_time_ms": 3175,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Power supply",
    "description": "BATTERY VOLTAGE LOW",
}

# B code - Body: B142A-17
VBAT_OV = {
    "dtc_hex": "0x942A17",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VBAT_OV",
    "short_notation": "B142A-17",
    "dtc_type": "B (Body)",
    "ftb": "0x17",
    "fault_type": "Supply voltage high",
    "set_condition": "The measured voltage is above 16V. qualification: The measured voltage is above threshold for high supply voltage.",
    "heal_condition": "The measured voltage is below threshold for high supply voltage",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3175ms",
    "mature_time_ms": 3175,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Power supply",
    "description": "BATTERY VOLTAGE HIGH",
}

# B code - Body: B1061-96
ECU_LOCK_FRONT = {
    "dtc_hex": "0x906196",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_FRONT",
    "short_notation": "B1061-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "ECU locked after a crash",
    "set_condition": "The DTC is stored After the FRONT Crash Detection",
    "heal_condition": "No criteria",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": None,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "ECU LOCKED DUE TO FRONT CRASH",
}

# B code - Body: B0090-13
LH_FRSU_OPEN = {
    "dtc_hex": "0x809013",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_FRSU_OPEN",
    "short_notation": "B0090-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that; Electrical connection open.",
    "heal_condition": "RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU OPEN",
}

# B code - Body: B0095-13
RH_FRSU_OPEN = {
    "dtc_hex": "0x809513",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_FRSU_OPEN",
    "short_notation": "B0095-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that; Electrical connection open.",
    "heal_condition": "RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU OPEN",
}

# B code - Body: B0090-81
LH_FRSU_COMM = {
    "dtc_hex": "0x809081",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_FRSU_COMM",
    "short_notation": "B0090-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "The DTC is stored if the control module detects that; Sensor Wrong SN .",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU COMMUNICATION ERROR",
}

# B code - Body: B0095-81
RH_FRSU_COMM = {
    "dtc_hex": "0x809581",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_FRSU_COMM",
    "short_notation": "B0095-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "The DTC is stored if the control module detects that; Sensor Wrong SN .",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU COMMUNICATION ERROR",
}

# B code - Body: B0090-11
LH_FRSU_STG = {
    "dtc_hex": "0x809011",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_FRSU_STG",
    "short_notation": "B0090-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that; Electrical connection to ground",
    "heal_condition": "RSU recover from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU SHORT TO GROUND",
}

# B code - Body: B0095-11
RH_FRSU_STG = {
    "dtc_hex": "0x809511",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_FRSU_STG",
    "short_notation": "B0095-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that; Electrical connection to ground",
    "heal_condition": "RSU recover from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU SHORT TO GROUND",
}

# B code - Body: B0090-96
LH_FRSU_INTERNAL = {
    "dtc_hex": "0x809096",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_FRSU_INTERNAL",
    "short_notation": "B0090-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "The DTC is stored if the control module detects that; Sensor has an internal fault",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU INTERNAL ERROR",
}

# B code - Body: B0095-96
RH_FRSU_INTERNAL = {
    "dtc_hex": "0x809596",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_FRSU_INTERNAL",
    "short_notation": "B0095-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "The DTC is stored if the control module detects that; Sensor has an internal fault",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU INTERNAL ERROR",
}

# B code - Body: B0090-64
LH_FRSU_CONFIG = {
    "dtc_hex": "0x809064",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_FRSU_CONFIG",
    "short_notation": "B0090-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "The DTC is stored if the control module detects that; Not configured sensor's data is received.",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU CONFIGURATION ERROR",
}

# B code - Body: B0095-64
RH_FRSU_CONFIG = {
    "dtc_hex": "0x809564",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_FRSU_CONFIG",
    "short_notation": "B0095-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "The DTC is stored if the control module detects that; Not configured sensor's data is received.",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU CONFIGURATION ERROR",
}

# B code - Body: B0090-99
LH_FRSU_SAMPLE_RATE = {
    "dtc_hex": "0x809099",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_FRSU_SAMPLE_RATE",
    "short_notation": "B0090-99",
    "dtc_type": "B (Body)",
    "ftb": "0x99",
    "fault_type": "Sampling rate fault",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU SAMPLING RATE FAULT",
}

# B code - Body: B0095-99
RH_FRSU_SAMPLE_RATE = {
    "dtc_hex": "0x809599",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_FRSU_SAMPLE_RATE",
    "short_notation": "B0095-99",
    "dtc_type": "B (Body)",
    "ftb": "0x99",
    "fault_type": "Sampling rate fault",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU SAMPLING RATE FAULT",
}

# B code - Body: B00D2-00
AWL_FAIL = {
    "dtc_hex": "0x80D200",
    "applicable_to": ("ICE",),
    "mnemonic": "AWL_FAIL",
    "short_notation": "B00D2-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "Lamp failure",
    "set_condition": "The DTC is stored if the control module detects that; Lamp Failure signal from IP",
    "heal_condition": "No Lamp Failure signal from IP",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "2200ms",
    "demature_time_ms": 2200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "Airbag warning lamp (reported over CAN)",
    "description": "AIRBAG WARNING LAMP FAILURE",
}

# B code - Body: B0090-97
LH_FRSU_UNCONF_CRASH = {
    "dtc_hex": "0x809097",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_FRSU_UNCONF_CRASH",
    "short_notation": "B0090-97",
    "dtc_type": "B (Body)",
    "ftb": "0x97",
    "fault_type": "Unconfirmed crash",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "UNCONFIRMED CRASH CoRIGHT FRSU",
}

# B code - Body: B0095-97
RH_FRSU_UNCONF_CRASH = {
    "dtc_hex": "0x809597",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_FRSU_UNCONF_CRASH",
    "short_notation": "B0095-97",
    "dtc_type": "B (Body)",
    "ftb": "0x97",
    "fault_type": "Unconfirmed crash",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "UNCONFIRMED CRASH RIGHT FRSU",
}

# B code - Body: B120D-97
LH_SRSU_UNCONF_CRASH = {
    "dtc_hex": "0x920D97",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_SRSU_UNCONF_CRASH",
    "short_notation": "B120D-97",
    "dtc_type": "B (Body)",
    "ftb": "0x97",
    "fault_type": "Unconfirmed crash",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "UNCONFIRMED CRASH CoRIGHT SRSU",
}

# B code - Body: B120E-97
RH_SRSU_UNCONF_CRASH = {
    "dtc_hex": "0x920E97",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_SRSU_UNCONF_CRASH",
    "short_notation": "B120E-97",
    "dtc_type": "B (Body)",
    "ftb": "0x97",
    "fault_type": "Unconfirmed crash",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "UNCONFIRMED CRASH RIGHT SRSU",
}

# B code - Body: B1200-00
ECU_PLANT_MODE = {
    "dtc_hex": "0x920000",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_PLANT_MODE",
    "short_notation": "B1200-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU in plant mode",
    "set_condition": "The DTC is stored if the control module detects that; Faults Present at 1st time IGN ON",
    "heal_condition": "ACU shall be error free for 30s",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "lessthan 1Sec",
    "mature_time_ms": None,
    "demature_time": "30s",
    "demature_time_ms": 30000,
    "precondition": "Faults Present at 1st time IGN ON",
    "ageing_cycles": 40,
    "warning_lamp": "FLASHING_1HZ",
    "group": "ECU internal / configuration",
    "description": "ECU IN PLANT MODE",
}

# B code - Body: B121A-00
ECU_LOCK_PT_DEPLOY = {
    "dtc_hex": "0x921A00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_PT_DEPLOY",
    "short_notation": "B121A-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU locked after a crash",
    "set_condition": "The DTC is stored After the deployment of any Pretensioners",
    "heal_condition": "No criteria",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": None,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "ECU LOCKED DUE TO PRETENSIONER DEPLOYMENT",
}

# B code - Body: B1916-00
ECU_LOCK_RH_SIDE = {
    "dtc_hex": "0x991600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_RH_SIDE",
    "short_notation": "B1916-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU locked after a crash",
    "set_condition": "The DTC is stored After the SIDE Crash Detection; Note: The DTC is latched only if SIDE Airbags are configured. Else the DTC will go to historic in next ignition cycle.",
    "heal_condition": "No criteria",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "After the Crash Detection",
    "ageing_cycles": None,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "ECU LOCKED DUE TO RIGHT SIDE CRASH",
}

# B code - Body: B1201-00
ECU_LOCK_LH_SIDE = {
    "dtc_hex": "0x920100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_LH_SIDE",
    "short_notation": "B1201-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU locked after a crash",
    "set_condition": "The DTC is stored After the SIDE Crash Detection; Note: The DTC is latched only if SIDE Airbags are configured. Else the DTC will go to historic in next ignition cycle.",
    "heal_condition": "No criteria",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "After the Crash Detection",
    "ageing_cycles": None,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "ECU LOCKED DUE TO LEFT SIDE CRASH",
}

# B code - Body: B1202-00
ECU_CONFIG = {
    "dtc_hex": "0x920200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_CONFIG",
    "short_notation": "B1202-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU configuration error",
    "set_condition": "The DTC is stored if the control module detects that-; If any EOL Config faults is present(DCS config falult,RSU config falult,Loops config falult,Lamps config falult)",
    "heal_condition": "No EOL Config fault is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "lessthan 1Sec",
    "mature_time_ms": None,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "If any EOL Config faults is present(DCS config falult,RSU config falult,Loops config falult,Lamps config falult)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "ECU internal / configuration",
    "description": "ECU CONFIGURATION ERROR",
}

# B code - Body: B1203-11
RH_LAP_PT_STG = {
    "dtc_hex": "0x920311",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_STG",
    "short_notation": "B1203-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Dr.Pretensioner.2. Shorted to GND",
    "heal_condition": "Dr.Pretensioner.2. removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER SQUIB - SHORT TO GROUND",
}

# B code - Body: B1203-12
RH_LAP_PT_STB = {
    "dtc_hex": "0x920312",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_STB",
    "short_notation": "B1203-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Dr.Pretensioner.2. Shorted to STB",
    "heal_condition": "Dr.Pretensioner.2. removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER SQUIB - SHORT TO BATTERY",
}

# B code - Body: B1203-1A
RH_LAP_PT_RES_LOW = {
    "dtc_hex": "0x92031A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_RES_LOW",
    "short_notation": "B1203-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Dr.Pretensioner.2. resistance < 1 .66 ohms",
    "heal_condition": "Dr.Pretensioner.2. resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER SQUIB - LOW RESISTANCE",
}

# B code - Body: B1203-1B
RH_LAP_PT_RES_HIGH = {
    "dtc_hex": "0x92031B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_RES_HIGH",
    "short_notation": "B1203-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Dr.Pretensioner.2. resistance > 5.54 ohms",
    "heal_condition": "Dr.Pretensioner.2. resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER SQUIB - HIGH RESISTANCE",
}

# B code - Body: B1203-01
RH_LAP_PT_XCONN = {
    "dtc_hex": "0x920301",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_XCONN",
    "short_notation": "B1203-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER SQUIB - CROSS CONNECT",
}

# B code - Body: B1204-11
LH_LAP_PT_STG = {
    "dtc_hex": "0x920411",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_STG",
    "short_notation": "B1204-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Pas.Pretensioner.2. Shorted to GND",
    "heal_condition": "Pas.Pretensioner.2. removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER SQUIB - SHORT TO GROUND",
}

# B code - Body: B1204-12
LH_LAP_PT_STB = {
    "dtc_hex": "0x920412",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_STB",
    "short_notation": "B1204-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Pas.Pretensioner.2. Shorted to STB",
    "heal_condition": "Pas.Pretensioner.2. removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER SQUIB - SHORT TO BATTERY",
}

# B code - Body: B1204-1A
LH_LAP_PT_RES_LOW = {
    "dtc_hex": "0x92041A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_RES_LOW",
    "short_notation": "B1204-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Pas.Pretensioner.2. resistance < 1 .66 ohms",
    "heal_condition": "Pas.Pretensioner.2. resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER SQUIB - LOW RESISTANCE",
}

# B code - Body: B1204-1B
LH_LAP_PT_RES_HIGH = {
    "dtc_hex": "0x92041B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_RES_HIGH",
    "short_notation": "B1204-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Pas.Pretensioner.2. resistance > 5.54 ohms",
    "heal_condition": "Pas.Pretensioner.2. resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER SQUIB - HIGH RESISTANCE",
}

# B code - Body: B1204-01
LH_LAP_PT_XCONN = {
    "dtc_hex": "0x920401",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_XCONN",
    "short_notation": "B1204-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER SQUIB - CROSS CONNECT",
}

# B code - Body: B1205-11
PAB_DIS_SW_STG = {
    "dtc_hex": "0x920511",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_STG",
    "short_notation": "B1205-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "PAB switch shorted to GND (R<52 ohms)",
    "heal_condition": "PAB switch removed from shorted to GND ( not in - R<52 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH - SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1205-12
PAB_DIS_SW_STB = {
    "dtc_hex": "0x920512",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_STB",
    "short_notation": "B1205-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "PAB switch shorted to STB",
    "heal_condition": "PAB switch removed from shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH - SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1205-13
PAB_DIS_SW_OPEN = {
    "dtc_hex": "0x920513",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_OPEN",
    "short_notation": "B1205-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "PAB switch resistance (605 ohms < R)",
    "heal_condition": "PAB switch resistance is not (605 ohms < R)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH - OPEN CIRCUIT",
}

# B code - Body: B120C-1A
PAB_DIS_SW_RES_LOW = {
    "dtc_hex": "0x920C1A",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_RES_LOW",
    "short_notation": "B120C-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "PAB switch resistance (52 ohms < R < 72 ohms)",
    "heal_condition": "PAB switch resistance is out of (52 ohms < R < 72 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH-LOW RESISTANCE",
}

# B code - Body: B120C-1B
PAB_DIS_SW_RES_HIGH = {
    "dtc_hex": "0x920C1B",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_RES_HIGH",
    "short_notation": "B120C-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "PAB switch resistance (520 ohms < R < 605 ohms)",
    "heal_condition": "PAB switch resistance is out of (520 ohms < R < 605 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH-HIGH RESISTANCE",
}

# B code - Body: B120C-1E
PAB_DIS_SW_RES_OOR = {
    "dtc_hex": "0x920C1E",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_RES_OOR",
    "short_notation": "B120C-1E",
    "dtc_type": "B (Body)",
    "ftb": "0x1E",
    "fault_type": "Resistance in the invalid window",
    "set_condition": "PAB switch resistance (139 ohms < R < 313 ohms)",
    "heal_condition": "PAB switch resistance is out of (139 ohms < R < 313 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH-INVALID RESISTANCE",
}

# B code - Body: B1206-11
RH_SAB_STG = {
    "dtc_hex": "0x920611",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_STG",
    "short_notation": "B1206-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Dr side airbag Shorted to GND",
    "heal_condition": "Dr side airbag removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG - SHORT TO GROUND",
}

# B code - Body: B1206-12
RH_SAB_STB = {
    "dtc_hex": "0x920612",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_STB",
    "short_notation": "B1206-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Dr side airbag Shorted to STB",
    "heal_condition": "Dr side airbag removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG - SHORT TO BATTERY",
}

# B code - Body: B1206-1A
RH_SAB_RES_LOW = {
    "dtc_hex": "0x92061A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_RES_LOW",
    "short_notation": "B1206-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Dr side airbag resistance < 1 .66 ohms",
    "heal_condition": "Dr side airbag resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG - LOW RESISTANCE",
}

# B code - Body: B1206-1B
RH_SAB_RES_HIGH = {
    "dtc_hex": "0x92061B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_RES_HIGH",
    "short_notation": "B1206-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Dr side airbag resistance > 5.54 ohms",
    "heal_condition": "Dr side airbag resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG - HIGH RESISTANCE",
}

# B code - Body: B1206-01
RH_SAB_XCONN = {
    "dtc_hex": "0x920601",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_XCONN",
    "short_notation": "B1206-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG - CROSS CONNECT",
}

# B code - Body: B1207-11
RH_IC_STG = {
    "dtc_hex": "0x920711",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_STG",
    "short_notation": "B1207-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Dr curtain airbag Shorted to GND",
    "heal_condition": "Dr curtain airbag removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT CURTAIN AIRBAG - SHORT TO GROUND",
}

# B code - Body: B1207-12
RH_IC_STB = {
    "dtc_hex": "0x920712",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_STB",
    "short_notation": "B1207-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Dr curtain airbag Shorted to STB",
    "heal_condition": "Dr curtain airbag removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT CURTAIN AIRBAG - SHORT TO BATTERY",
}

# B code - Body: B1207-1A
RH_IC_RES_LOW = {
    "dtc_hex": "0x92071A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_RES_LOW",
    "short_notation": "B1207-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Dr curtain airbag resistance < 1 .66 ohms",
    "heal_condition": "Dr curtain airbag resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT CURTAIN AIRBAG - LOW RESISTANCE",
}

# B code - Body: B1207-1B
RH_IC_RES_HIGH = {
    "dtc_hex": "0x92071B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_RES_HIGH",
    "short_notation": "B1207-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Dr curtain airbag resistance > 5.54 ohms",
    "heal_condition": "Dr curtain airbag resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT CURTAIN AIRBAG - HIGH RESISTANCE",
}

# B code - Body: B1207-01
RH_IC_XCONN = {
    "dtc_hex": "0x920701",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_XCONN",
    "short_notation": "B1207-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT CURTAIN AIRBAG - CROSS CONNECT",
}

# B code - Body: B1208-11
LH_SAB_STG = {
    "dtc_hex": "0x920811",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_STG",
    "short_notation": "B1208-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Pas side airbag Shorted to GND",
    "heal_condition": "Pas side airbag removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG - SHORT TO GROUND",
}

# B code - Body: B1208-12
LH_SAB_STB = {
    "dtc_hex": "0x920812",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_STB",
    "short_notation": "B1208-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Pas side airbag Shorted to STB",
    "heal_condition": "Pas side airbag removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG - SHORT TO BATTERY",
}

# B code - Body: B1208-1A
LH_SAB_RES_LOW = {
    "dtc_hex": "0x92081A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_RES_LOW",
    "short_notation": "B1208-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Pas side airbag resistance < 1 .66 ohms",
    "heal_condition": "Pas side airbag resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG - LOW RESISTANCE",
}

# B code - Body: B1208-1B
LH_SAB_RES_HIGH = {
    "dtc_hex": "0x92081B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_RES_HIGH",
    "short_notation": "B1208-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Pas side airbag resistance > 5.54 ohms",
    "heal_condition": "Pas side airbag resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG - HIGH RESISTANCE",
}

# B code - Body: B1208-01
LH_SAB_XCONN = {
    "dtc_hex": "0x920801",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_XCONN",
    "short_notation": "B1208-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG - CROSS CONNECT",
}

# B code - Body: B1209-11
LH_IC_STG = {
    "dtc_hex": "0x920911",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_STG",
    "short_notation": "B1209-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Pas curtain airbag Shorted to GND",
    "heal_condition": "Pas curtain airbag removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT CURTAIN AIRBAG - SHORT TO GROUND",
}

# B code - Body: B1209-12
LH_IC_STB = {
    "dtc_hex": "0x920912",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_STB",
    "short_notation": "B1209-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Pas curtain airbag Shorted to STB",
    "heal_condition": "Pas curtain airbag removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT CURTAIN AIRBAG - SHORT TO BATTERY",
}

# B code - Body: B1209-1A
LH_IC_RES_LOW = {
    "dtc_hex": "0x92091A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_RES_LOW",
    "short_notation": "B1209-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Pas curtain airbag resistance < 1 .66 ohms",
    "heal_condition": "Pas curtain airbag resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT CURTAIN AIRBAG - LOW RESISTANCE",
}

# B code - Body: B1209-1B
LH_IC_RES_HIGH = {
    "dtc_hex": "0x92091B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_RES_HIGH",
    "short_notation": "B1209-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Pas curtain airbag resistance > 5.54 ohms",
    "heal_condition": "Pas curtain airbag resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT CURTAIN AIRBAG - HIGH RESISTANCE",
}

# B code - Body: B1209-01
LH_IC_XCONN = {
    "dtc_hex": "0x920901",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_XCONN",
    "short_notation": "B1209-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT CURTAIN AIRBAG - CROSS CONNECT",
}

# B code - Body: B120A-13
LH_BPLR_SRSU_OPEN = {
    "dtc_hex": "0x920A13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BPLR_SRSU_OPEN",
    "short_notation": "B120A-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Pas.Side RSU is not connected to the harness",
    "heal_condition": "Pas.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU OPEN",
}

# B code - Body: B120B-13
RH_BPLR_SRSU_OPEN = {
    "dtc_hex": "0x920B13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BPLR_SRSU_OPEN",
    "short_notation": "B120B-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Dr.Side RSU is not connected to the harness",
    "heal_condition": "Dr.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU OPEN",
}

# B code - Body: B120A-81
LH_BPLR_SRSU_COMM = {
    "dtc_hex": "0x920A81",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BPLR_SRSU_COMM",
    "short_notation": "B120A-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU COMMUNICATION ERROR",
}

# B code - Body: B120B-81
RH_BPLR_SRSU_COMM = {
    "dtc_hex": "0x920B81",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BPLR_SRSU_COMM",
    "short_notation": "B120B-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU COMMUNICATION ERROR",
}

# B code - Body: B120A-11
LH_BPLR_SRSU_STG = {
    "dtc_hex": "0x920A11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BPLR_SRSU_STG",
    "short_notation": "B120A-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU SHORT TO GROUND",
}

# B code - Body: B120B-11
RH_BPLR_SRSU_STG = {
    "dtc_hex": "0x920B11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BPLR_SRSU_STG",
    "short_notation": "B120B-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU SHORT TO GROUND",
}

# B code - Body: B120A-96
LH_BPLR_SRSU_INTERNAL = {
    "dtc_hex": "0x920A96",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BPLR_SRSU_INTERNAL",
    "short_notation": "B120A-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU INTERNAL ERROR",
}

# B code - Body: B120B-96
RH_BPLR_SRSU_INTERNAL = {
    "dtc_hex": "0x920B96",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BPLR_SRSU_INTERNAL",
    "short_notation": "B120B-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU INTERNAL ERROR",
}

# B code - Body: B120A-64
LH_BPLR_SRSU_CONFIG = {
    "dtc_hex": "0x920A64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BPLR_SRSU_CONFIG",
    "short_notation": "B120A-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Wrong sensor configuration",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU CONFIGURATION ERROR",
}

# B code - Body: B120B-64
RH_BPLR_SRSU_CONFIG = {
    "dtc_hex": "0x920B64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BPLR_SRSU_CONFIG",
    "short_notation": "B120B-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Wrong sensor configuration",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU CONFIGURATION ERROR",
}

# B code - Body: B120A-99
LH_BPLR_SRSU_SAMPLE_RATE = {
    "dtc_hex": "0x920A99",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_BPLR_SRSU_SAMPLE_RATE",
    "short_notation": "B120A-99",
    "dtc_type": "B (Body)",
    "ftb": "0x99",
    "fault_type": "Sampling rate fault",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU SAMPLING RATE FAULT",
}

# B code - Body: B120B-99
RH_BPLR_SRSU_SAMPLE_RATE = {
    "dtc_hex": "0x920B99",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_BPLR_SRSU_SAMPLE_RATE",
    "short_notation": "B120B-99",
    "dtc_type": "B (Body)",
    "ftb": "0x99",
    "fault_type": "Sampling rate fault",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU SAMPLING RATE FAULT",
}

# B code - Body: B120F-12
PSG_SBR_LMP_STB = {
    "dtc_hex": "0x920F12",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_SBR_LMP_STB",
    "short_notation": "B120F-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Hardwired output / lamp",
    "description": "PASSENGER SEATBELT WARNING LAMP - SHORT TO BATTERY",
}

# B code - Body: B120F-11
PSG_SBR_LMP_STG = {
    "dtc_hex": "0x920F11",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_SBR_LMP_STG",
    "short_notation": "B120F-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Hardwired output / lamp",
    "description": "PASSENGER SEATBELT WARNING LAMP - SHORT TO GROUND",
}

# B code - Body: B120F-13
PSG_SBR_LMP_OPEN = {
    "dtc_hex": "0x920F13",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_SBR_LMP_OPEN",
    "short_notation": "B120F-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Hardwired output / lamp",
    "description": "PASSENGER SEATBELT WARNING LAMP - OPEN CIRCUIT",
}

# B code - Body: B1210-12
PAB_OFF_LMP_STB = {
    "dtc_hex": "0x921012",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_OFF_LMP_STB",
    "short_notation": "B1210-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Restraints System Lamp -Short to Battery",
    "heal_condition": "Restraints System Lamp removed from Short to Battery",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PASSENGER AIRBAG DISABLE LAMP - SHORT TO BATTERY",
}

# B code - Body: B1210-11
PAB_OFF_LMP_STG = {
    "dtc_hex": "0x921011",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_OFF_LMP_STG",
    "short_notation": "B1210-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Restraints System Lamp -Short to ground",
    "heal_condition": "Restraints System Lamp removed from Short to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PASSENGER AIRBAG DISABLE LAMP - SHORT TO GROUND",
}

# B code - Body: B1210-13
PAB_OFF_LMP_OPEN = {
    "dtc_hex": "0x921013",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_OFF_LMP_OPEN",
    "short_notation": "B1210-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Restraints System Lamp -open",
    "heal_condition": "Restraints System Lamp connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PASSENGER AIRBAG DISABLE LAMP - OPEN CIRCUIT",
}

# B code - Body: B1261-64
DAB_AV_UNEXPECTED = {
    "dtc_hex": "0x926164",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_UNEXPECTED",
    "short_notation": "B1261-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Dr airbag sq is not configured but physically connected",
    "heal_condition": "Dr airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT UNEXPECTED SQUIB",
}

# B code - Body: B0001-64
DAB_UNEXPECTED = {
    "dtc_hex": "0x800164",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_UNEXPECTED",
    "short_notation": "B0001-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Dr airbag sq is not configured but physically connected",
    "heal_condition": "Dr airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B0010-64
PAB_UNEXPECTED = {
    "dtc_hex": "0x801064",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_UNEXPECTED",
    "short_notation": "B0010-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pas airbag sq is not configured but physically connected",
    "heal_condition": "Pas airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B18FD-64
PAB_AV_UNEXPECTED = {
    "dtc_hex": "0x98FD64",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_AV_UNEXPECTED",
    "short_notation": "B18FD-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pas airbag sq is not configured but physically connected",
    "heal_condition": "Pas airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "Passenger Airbag Active Vent Squib Unexpected",
}

# B code - Body: B1263-64
RH_BFL_UNEXPECTED = {
    "dtc_hex": "0x926364",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_UNEXPECTED",
    "short_notation": "B1263-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRETENSIONER ADAPTIVE LOAD LIMITER UNEXPECTED SQUIB",
}

# B code - Body: B0070-64
RH_PT_UNEXPECTED = {
    "dtc_hex": "0x807064",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_UNEXPECTED",
    "short_notation": "B0070-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRETENSIONER UNEXPECTED SQUIB",
}

# B code - Body: B1264-64
LH_BFL_UNEXPECTED = {
    "dtc_hex": "0x926464",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_UNEXPECTED",
    "short_notation": "B1264-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRETENSIONER ADAPTIVE LOAD LIMITER UNEXPECTED SQUIB",
}

# B code - Body: B0072-64
LH_PT_UNEXPECTED = {
    "dtc_hex": "0x807264",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_UNEXPECTED",
    "short_notation": "B0072-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRETENSIONER UNEXPECTED SQUIB",
}

# B code - Body: B1203-64
RH_LAP_PT_UNEXPECTED = {
    "dtc_hex": "0x920364",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_UNEXPECTED",
    "short_notation": "B1203-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER UNEXPECTED SQUIB",
}

# B code - Body: B1204-64
LH_LAP_PT_UNEXPECTED = {
    "dtc_hex": "0x920464",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_UNEXPECTED",
    "short_notation": "B1204-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER UNEXPECTED SQUIB",
}

# B code - Body: B1206-64
RH_SAB_UNEXPECTED = {
    "dtc_hex": "0x920664",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_UNEXPECTED",
    "short_notation": "B1206-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "RS airbag sq is not configured but physically connected",
    "heal_condition": "RS airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B1208-64
LH_SAB_UNEXPECTED = {
    "dtc_hex": "0x920864",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_UNEXPECTED",
    "short_notation": "B1208-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "LS airbag sq is not configured but physically connected",
    "heal_condition": "LS airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B1207-64
RH_IC_UNEXPECTED = {
    "dtc_hex": "0x920764",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_UNEXPECTED",
    "short_notation": "B1207-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "RSC airbag sq is not configured but physically connected",
    "heal_condition": "RSC airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE CURTAIN AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B1209-64
LH_IC_UNEXPECTED = {
    "dtc_hex": "0x920964",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_UNEXPECTED",
    "short_notation": "B1209-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "LSC airbag sq is not configured but physically connected",
    "heal_condition": "LSC airbag sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE CURTAIN AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B1032-12
PSG_BKL_STB = {
    "dtc_hex": "0x903212",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_BKL_STB",
    "short_notation": "B1032-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "PASSENGER SEAT BELT Short to PLUS",
    "heal_condition": "PASSENGER SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "PASSENGER SEAT BELT LEAK TO PLUS",
}

# B code - Body: B1033-12
DRV_BKL_STB = {
    "dtc_hex": "0x903312",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_BKL_STB",
    "short_notation": "B1033-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "DRIVER SEAT BELT Short to PLUS",
    "heal_condition": "DRIVER SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "DRIVER SEAT BELT LEAK TO PLUS",
}

# B code - Body: B1205-64
PAB_DIS_SW_CONFIG = {
    "dtc_hex": "0x920564",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_DIS_SW_CONFIG",
    "short_notation": "B1205-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "PAB Disable switch is disabled by EOL and is in connected state",
    "heal_condition": "Configuration of PAB Disable switch is correct",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG DISABLE SWITCH CONFIGURATION ERROR",
}

# B code - Body: B1210-64
PAB_OFF_LMP_CONFIG = {
    "dtc_hex": "0x921064",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_OFF_LMP_CONFIG",
    "short_notation": "B1210-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Configuration of Lamp connection type is not correct",
    "heal_condition": "Configuration of Lamp connection type is correct",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PASSENGER AIRBAG DISABLE LAMP CONFIGURATION ERROR",
}

# B code - Body: B120F-64
PSG_SBR_LMP_CONFIG = {
    "dtc_hex": "0x920F64",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_SBR_LMP_CONFIG",
    "short_notation": "B120F-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "2200ms",
    "demature_time_ms": 2200,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Hardwired output / lamp",
    "description": "PASSENGER SEAT BELT LAMP CONFIGURATION ERROR",
}

# B code - Body: B0095-2B
RH_FRSU_XCONN = {
    "dtc_hex": "0x80952B",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_FRSU_XCONN",
    "short_notation": "B0095-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU SHORT TO ANOTHER REMOTE SENSOR",
}

# B code - Body: B0090-2B
LH_FRSU_XCONN = {
    "dtc_hex": "0x80902B",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_FRSU_XCONN",
    "short_notation": "B0090-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU SHORT TO ANOTHER REMOTE SENSOR",
}

# B code - Body: B120B-2B
RH_BPLR_SRSU_XCONN = {
    "dtc_hex": "0x920B2B",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_BPLR_SRSU_XCONN",
    "short_notation": "B120B-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU SHORT TO ANOTHER REMOTE SENSOR",
}

# B code - Body: B120A-2B
LH_BPLR_SRSU_XCONN = {
    "dtc_hex": "0x920A2B",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_BPLR_SRSU_XCONN",
    "short_notation": "B120A-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU SHORT TO ANOTHER REMOTE SENSOR",
}

# B code - Body: B0095-87
RH_FRSU_RAILED = {
    "dtc_hex": "0x809587",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_FRSU_RAILED",
    "short_notation": "B0095-87",
    "dtc_type": "B (Body)",
    "ftb": "0x87",
    "fault_type": "Output railed",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU OUTPUT RAILED",
}

# B code - Body: B0090-87
LH_FRSU_RAILED = {
    "dtc_hex": "0x809087",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_FRSU_RAILED",
    "short_notation": "B0090-87",
    "dtc_type": "B (Body)",
    "ftb": "0x87",
    "fault_type": "Output railed",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU OUTPUT RAILED",
}

# B code - Body: B120B-87
RH_BPLR_SRSU_RAILED = {
    "dtc_hex": "0x920B87",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_BPLR_SRSU_RAILED",
    "short_notation": "B120B-87",
    "dtc_type": "B (Body)",
    "ftb": "0x87",
    "fault_type": "Output railed",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU OUTPUT RAILED",
}

# B code - Body: B120A-87
LH_BPLR_SRSU_RAILED = {
    "dtc_hex": "0x920A87",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_BPLR_SRSU_RAILED",
    "short_notation": "B120A-87",
    "dtc_type": "B (Body)",
    "ftb": "0x87",
    "fault_type": "Output railed",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU OUTPUT RAILED",
}

# B code - Body: B0095-12
RH_FRSU_STB = {
    "dtc_hex": "0x809512",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_FRSU_STB",
    "short_notation": "B0095-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT FRSU SHORT TO BATTERY",
}

# B code - Body: B0090-12
LH_FRSU_STB = {
    "dtc_hex": "0x809012",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_FRSU_STB",
    "short_notation": "B0090-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT FRSU SHORT TO BATTERY",
}

# B code - Body: B120B-12
RH_BPLR_SRSU_STB = {
    "dtc_hex": "0x920B12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BPLR_SRSU_STB",
    "short_notation": "B120B-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR RIGHT SRSU SHORT TO BATTERY",
}

# B code - Body: B120A-12
LH_BPLR_SRSU_STB = {
    "dtc_hex": "0x920A12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BPLR_SRSU_STB",
    "short_notation": "B120A-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "B-PILLAR LEFT SRSU SHORT TO BATTERY",
}

# B code - Body: B1213-12
ACN_OUT_STB = {
    "dtc_hex": "0x921312",
    "applicable_to": ("ICE",),
    "mnemonic": "ACN_OUT_STB",
    "short_notation": "B1213-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Hardwired output / lamp",
    "description": "ACN Battery",
}

# B code - Body: B1213-14
ACN_OUT_STG_OPEN = {
    "dtc_hex": "0x921314",
    "applicable_to": ("ICE",),
    "mnemonic": "ACN_OUT_STG_OPEN",
    "short_notation": "B1213-14",
    "dtc_type": "B (Body)",
    "ftb": "0x14",
    "fault_type": "Short to ground or open circuit",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Hardwired output / lamp",
    "description": "ACN GROUND OR OPEN",
}

# B code - Body: B1214-00
LOOP_SVD_DEPLOY = {
    "dtc_hex": "0x921400",
    "applicable_to": ("ICE",),
    "mnemonic": "LOOP_SVD_DEPLOY",
    "short_notation": "B1214-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "Loops deployed by the SVD function",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "ECU internal / configuration",
    "description": "LOOPS DEPLOYED BY SVD FUNCTION",
}

# B code - Body: B1216-13
RH_PRES_SNS_OPEN = {
    "dtc_hex": "0x921613",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PRES_SNS_OPEN",
    "short_notation": "B1216-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Dr. SIDE PRESSURE is not connected to the harness",
    "heal_condition": "Dr. SIDE PRESSURE properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR OPEN",
}

# B code - Body: B1212-13
LH_PRES_SNS_OPEN = {
    "dtc_hex": "0x921213",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PRES_SNS_OPEN",
    "short_notation": "B1212-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "PAS. SIDE PRESSURE is not connected to the harness",
    "heal_condition": "Pas. SIDE PRESSURE properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR OPEN",
}

# B code - Body: B1216-2B
RH_PRES_SNS_XCONN = {
    "dtc_hex": "0x92162B",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_PRES_SNS_XCONN",
    "short_notation": "B1216-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR SHORT TO ANOTHER REMOTE SENSOR",
}

# B code - Body: B1212-2B
LH_PRES_SNS_XCONN = {
    "dtc_hex": "0x92122B",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_PRES_SNS_XCONN",
    "short_notation": "B1212-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR SHORT TO ANOTHER REMOTE SENSOR",
}

# B code - Body: B1216-87
RH_PRES_SNS_RAILED = {
    "dtc_hex": "0x921687",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_PRES_SNS_RAILED",
    "short_notation": "B1216-87",
    "dtc_type": "B (Body)",
    "ftb": "0x87",
    "fault_type": "Output railed",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR OUTPUT RAILED",
}

# B code - Body: B1212-87
LH_PRES_SNS_RAILED = {
    "dtc_hex": "0x921287",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_PRES_SNS_RAILED",
    "short_notation": "B1212-87",
    "dtc_type": "B (Body)",
    "ftb": "0x87",
    "fault_type": "Output railed",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR OUTPUT RAILED",
}

# B code - Body: B1216-96
RH_PRES_SNS_INTERNAL = {
    "dtc_hex": "0x921696",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PRES_SNS_INTERNAL",
    "short_notation": "B1216-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "SIDE PRESSURE Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR INTERNAL ERROR",
}

# B code - Body: B1212-96
LH_PRES_SNS_INTERNAL = {
    "dtc_hex": "0x921296",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PRES_SNS_INTERNAL",
    "short_notation": "B1212-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "SIDE PRESSURE Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR INTERNAL ERROR",
}

# B code - Body: B1216-64
RH_PRES_SNS_CONFIG = {
    "dtc_hex": "0x921664",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PRES_SNS_CONFIG",
    "short_notation": "B1216-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Wrong sensor configuration",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR CONFIGURATION ERROR",
}

# B code - Body: B1212-64
LH_PRES_SNS_CONFIG = {
    "dtc_hex": "0x921264",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PRES_SNS_CONFIG",
    "short_notation": "B1212-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Wrong sensor configuration",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR CONFIGURATION ERROR",
}

# B code - Body: B1216-81
RH_PRES_SNS_COMM = {
    "dtc_hex": "0x921681",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PRES_SNS_COMM",
    "short_notation": "B1216-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR COMMUNICATION ERROR",
}

# B code - Body: B1212-81
LH_PRES_SNS_COMM = {
    "dtc_hex": "0x921281",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PRES_SNS_COMM",
    "short_notation": "B1212-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR COMMUNICATION ERROR",
}

# B code - Body: B1216-12
RH_PRES_SNS_STB = {
    "dtc_hex": "0x921612",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PRES_SNS_STB",
    "short_notation": "B1216-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "SIDE PRESSURE terminal SC to Battery",
    "heal_condition": "SIDE PRESSURE terminal removed from SC to Battery",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR SHORT TO BATTERY",
}

# B code - Body: B1212-12
LH_PRES_SNS_STB = {
    "dtc_hex": "0x921212",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PRES_SNS_STB",
    "short_notation": "B1212-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "SIDE PRESSURE terminal SC to Battery",
    "heal_condition": "SIDE PRESSURE terminal removed from SC to Battery",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR SHORT TO BATTERY",
}

# B code - Body: B1216-11
RH_PRES_SNS_STG = {
    "dtc_hex": "0x921611",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PRES_SNS_STG",
    "short_notation": "B1216-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "SIDE PRESSURE terminal SC to GND",
    "heal_condition": "SIDE PRESSURE terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "RIGHT SIDE PRESSURE SENSOR SHORT TO GROUND",
}

# B code - Body: B1212-11
LH_PRES_SNS_STG = {
    "dtc_hex": "0x921211",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PRES_SNS_STG",
    "short_notation": "B1212-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "SIDE PRESSURE terminal SC to GND",
    "heal_condition": "SIDE PRESSURE terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "LEFT SIDE PRESSURE SENSOR SHORT TO GROUND",
}

# B code - Body: B1213-00
LOOP_SCRAP_EN = {
    "dtc_hex": "0x921300",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LOOP_SCRAP_EN",
    "short_notation": "B1213-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "Loops enabled for vehicle scrapping",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "ECU internal / configuration",
    "description": "Loop Enabled due to vehicle Scrap",
}

# B code - Body: B1215-00
EDR_RECORD_FULL = {
    "dtc_hex": "0x921500",
    "applicable_to": ("ICE",),
    "mnemonic": "EDR_RECORD_FULL",
    "short_notation": "B1215-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "EDR deployment record full",
    "set_condition": "NA",
    "heal_condition": "NA",
    "memory": "NA",
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "NA",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "ECU internal / configuration",
    "description": "Deployment Data Record Full (EDR Data)",
}

# B code - Body: B1211-64
DRV_KAB_UNEXPECTED = {
    "dtc_hex": "0x921164",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_UNEXPECTED",
    "short_notation": "B1211-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "The DTC is stored if the control module detects that: Deployment loop configured to be not present but resistance on the deployment loop is in the valid range indicating that restraint is connected for more than 2400ms.",
    "heal_condition": "DTC cannot Passed in the current Ignition cycle. It can be passed when the Unconfigured loops is High resistance, Low resistance and Open in the next cycle.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag UNEXPECTED SQUIB",
}

# B code - Body: B1211-11
DRV_KAB_STG = {
    "dtc_hex": "0x921111",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_STG",
    "short_notation": "B1211-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Dr knee airbag Shorted to GND",
    "heal_condition": "Dr knee airbag removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag - SHORT TO GROUND",
}

# B code - Body: B1211-12
DRV_KAB_STB = {
    "dtc_hex": "0x921112",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_STB",
    "short_notation": "B1211-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Dr knee airbag Shorted to STB",
    "heal_condition": "Dr knee airbag removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag - SHORT TO BATTERY",
}

# B code - Body: B1211-1A
DRV_KAB_RES_LOW = {
    "dtc_hex": "0x92111A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_RES_LOW",
    "short_notation": "B1211-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Dr knee airbag resistance < 1 .66 ohms",
    "heal_condition": "Dr knee airbag resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag - LOW RESISTANCE",
}

# B code - Body: B1211-1B
DRV_KAB_RES_HIGH = {
    "dtc_hex": "0x92111B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_RES_HIGH",
    "short_notation": "B1211-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Dr knee airbag resistance > 5.54 ohms",
    "heal_condition": "Dr knee airbag resistance > 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag - HIGH RESISTANCE",
}

# B code - Body: B1211-01
DRV_KAB_XCONN = {
    "dtc_hex": "0x921101",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_XCONN",
    "short_notation": "B1211-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag - CROSS CONNECT",
}

# B code - Body: B18F1-13
DAB_AV_OPEN_B18F1 = {
    "dtc_hex": "0x98F113",
    "applicable_to": ("ICE",),
    "mnemonic": "DAB_AV_OPEN_B18F1",
    "short_notation": "B18F1-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG DUAL ACTIVE VENT OPEN",
}

# B code - Body: B0001-13
DAB_OPEN = {
    "dtc_hex": "0x800113",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DAB_OPEN",
    "short_notation": "B0001-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER AIRBAG OPEN",
}

# B code - Body: B0010-13
PAB_OPEN = {
    "dtc_hex": "0x801013",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_OPEN",
    "short_notation": "B0010-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PASSENGER AIRBAG OPEN",
}

# B code - Body: B1263-13
RH_BFL_OPEN = {
    "dtc_hex": "0x926313",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_BFL_OPEN",
    "short_notation": "B1263-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRETENSIONER ADAPTIVE LOAD LIMITER OPEN",
}

# B code - Body: B0070-13
RH_PT_OPEN = {
    "dtc_hex": "0x807013",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_PT_OPEN",
    "short_notation": "B0070-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT PRETENSIONER OPEN",
}

# B code - Body: B1264-13
LH_BFL_OPEN = {
    "dtc_hex": "0x926413",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_BFL_OPEN",
    "short_notation": "B1264-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRETENSIONER ADAPTIVE LOAD LIMITER OPEN",
}

# B code - Body: B0072-13
LH_PT_OPEN = {
    "dtc_hex": "0x807213",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_PT_OPEN",
    "short_notation": "B0072-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT PRETENSIONER OPEN",
}

# B code - Body: B1203-13
RH_LAP_PT_OPEN = {
    "dtc_hex": "0x920313",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_LAP_PT_OPEN",
    "short_notation": "B1203-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT LAP PRETENSIONER OPEN",
}

# B code - Body: B1204-13
LH_LAP_PT_OPEN = {
    "dtc_hex": "0x920413",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_LAP_PT_OPEN",
    "short_notation": "B1204-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT LAP PRETENSIONER OPEN",
}

# B code - Body: B1206-13
RH_SAB_OPEN = {
    "dtc_hex": "0x920613",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_SAB_OPEN",
    "short_notation": "B1206-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE AIRBAG OPEN",
}

# B code - Body: B1208-13
LH_SAB_OPEN = {
    "dtc_hex": "0x920813",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_SAB_OPEN",
    "short_notation": "B1208-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE AIRBAG OPEN",
}

# B code - Body: B1207-13
RH_IC_OPEN = {
    "dtc_hex": "0x920713",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_IC_OPEN",
    "short_notation": "B1207-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "RIGHT SIDE CURTAIN AIRBAG OPEN",
}

# B code - Body: B1209-13
LH_IC_OPEN = {
    "dtc_hex": "0x920913",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_IC_OPEN",
    "short_notation": "B1209-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "LEFT SIDE CURTAIN AIRBAG OPEN",
}

# B code - Body: B1211-13
DRV_KAB_OPEN = {
    "dtc_hex": "0x921113",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_KAB_OPEN",
    "short_notation": "B1211-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER Knee Airbag OPEN",
}

# B code - Body: B1218-11
CRASH_OUT_STG = {
    "dtc_hex": "0x921811",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CRASH_OUT_STG",
    "short_notation": "B1218-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Restraints System Crash Output Lamp -Short to Ground",
    "heal_condition": "Restraints System Crash Output Lamp removed from Short to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT LINE SHORT TO GROUND",
}

# B code - Body: B1218-12
CRASH_OUT_STB = {
    "dtc_hex": "0x921812",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CRASH_OUT_STB",
    "short_notation": "B1218-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Restraints System Crash Output Lamp -Short to Battery",
    "heal_condition": "Restraints System Crash Output Lamp removed from Short to Battery",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT LINE SHORT TO BATTERY",
}

# B code - Body: B1218-13
CRASH_OUT_OPEN = {
    "dtc_hex": "0x921813",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CRASH_OUT_OPEN",
    "short_notation": "B1218-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Restraints System Crash Output Lamp -Open",
    "heal_condition": "Restraints System Crash Output Lamp removed from Open",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT LINE OPEN CIRCUIT",
}

# B code - Body: B1218-64
CRASH_OUT_CONFIG = {
    "dtc_hex": "0x921864",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CRASH_OUT_CONFIG",
    "short_notation": "B1218-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Restraints System Crash Output Lamp -configuration Error",
    "heal_condition": "Restraints System Crash Output Lamp removed from Configuration Error",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT LINE CONFIGURATION ERROR",
}

# B code - Body: B190E-11
ECALL_OUT_STG = {
    "dtc_hex": "0x990E11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECALL_OUT_STG",
    "short_notation": "B190E-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Restraints System Crash Output Lamp -Short to Ground",
    "heal_condition": "Restraints System Crash Output Lamp removed from Short to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT ECALL HW LINE SHORT TO GROUND",
}

# B code - Body: B190E-12
ECALL_OUT_STB = {
    "dtc_hex": "0x990E12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECALL_OUT_STB",
    "short_notation": "B190E-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Restraints System Crash Output Lamp -Short to Battery",
    "heal_condition": "Restraints System Crash Output Lamp removed from Short to Battery",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT ECALL HW LINE SHORT TO BATTERY",
}

# B code - Body: B190E-13
ECALL_OUT_OPEN = {
    "dtc_hex": "0x990E13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECALL_OUT_OPEN",
    "short_notation": "B190E-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Restraints System Crash Output Lamp -Open",
    "heal_condition": "Restraints System Crash Output Lamp removed from Open",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT ECALL HW LINE OPEN CIRCUIT",
}

# B code - Body: B190E-64
ECALL_OUT_CONFIG = {
    "dtc_hex": "0x990E64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECALL_OUT_CONFIG",
    "short_notation": "B190E-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Restraints System Crash Output Lamp -configuration Error",
    "heal_condition": "Restraints System Crash Output Lamp removed from Configuration Error",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "CRASH OUTPUT ECALL HW LINE CONFIGURATION ERROR",
}

# B code - Body: B121B-96
LH_CPLR_SRSU_INTERNAL = {
    "dtc_hex": "0x921B96",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_CPLR_SRSU_INTERNAL",
    "short_notation": "B121B-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR LEFT SRSU INTERNAL ERROR",
}

# B code - Body: B121B-64
LH_CPLR_SRSU_CONFIG = {
    "dtc_hex": "0x921B64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_CPLR_SRSU_CONFIG",
    "short_notation": "B121B-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Wrong sensor configuration",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR LEFT SRSU CONFIGURATION ERROR",
}

# B code - Body: B121B-12
LH_CPLR_SRSU_STB = {
    "dtc_hex": "0x921B12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_CPLR_SRSU_STB",
    "short_notation": "B121B-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR LEFT SRSU SHORT TO BATTERY",
}

# B code - Body: B121C-13
RH_CPLR_SRSU_OPEN = {
    "dtc_hex": "0x921C13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_CPLR_SRSU_OPEN",
    "short_notation": "B121C-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "C-Pillar Dr.Side RSU is not connected to the harness",
    "heal_condition": "C - Pillar Dr .Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR RIGHT SRSU OPEN",
}

# B code - Body: B121B-13
LH_CPLR_SRSU_OPEN = {
    "dtc_hex": "0x921B13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_CPLR_SRSU_OPEN",
    "short_notation": "B121B-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Pas.Side RSU is not connected to the harness",
    "heal_condition": "Pas.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR LEFT SRSU OPEN",
}

# B code - Body: B121C-81
RH_CPLR_SRSU_COMM = {
    "dtc_hex": "0x921C81",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_CPLR_SRSU_COMM",
    "short_notation": "B121C-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR RIGHT SRSU COMMUNICATION ERROR",
}

# B code - Body: B121B-81
LH_CPLR_SRSU_COMM = {
    "dtc_hex": "0x921B81",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_CPLR_SRSU_COMM",
    "short_notation": "B121B-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR LEFT SRSU COMMUNICATION ERROR",
}

# B code - Body: B121C-11
RH_CPLR_SRSU_STG = {
    "dtc_hex": "0x921C11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_CPLR_SRSU_STG",
    "short_notation": "B121C-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR RIGHT SRSU SHORT TO GROUND",
}

# B code - Body: B121B-11
LH_CPLR_SRSU_STG = {
    "dtc_hex": "0x921B11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_CPLR_SRSU_STG",
    "short_notation": "B121B-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR LEFT SRSU SHORT TO GROUND",
}

# B code - Body: B121C-96
RH_CPLR_SRSU_INTERNAL = {
    "dtc_hex": "0x921C96",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_CPLR_SRSU_INTERNAL",
    "short_notation": "B121C-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR RIGHT SRSU INTERNAL ERROR",
}

# B code - Body: B121C-64
RH_CPLR_SRSU_CONFIG = {
    "dtc_hex": "0x921C64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_CPLR_SRSU_CONFIG",
    "short_notation": "B121C-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Wrong sensor configuration",
    "heal_condition": "Proper sensor connection",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR RIGHT SRSU CONFIGURATION ERROR",
}

# B code - Body: B121C-12
RH_CPLR_SRSU_STB = {
    "dtc_hex": "0x921C12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_CPLR_SRSU_STB",
    "short_notation": "B121C-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "C-PILLAR RIGHT SRSU SHORT TO BATTERY",
}

# B code - Body: B121E-00
ECU_LOCK_REAR = {
    "dtc_hex": "0x921E00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_REAR",
    "short_notation": "B121E-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU locked after a crash",
    "set_condition": "The DTC is stored After the REAR Crash Detection",
    "heal_condition": "No criteria",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": None,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "ECU LOCKED DUE REAR CRASH",
}

# B code - Body: B1024-11
PAB_ON_LED_STG = {
    "dtc_hex": "0x902411",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_ON_LED_STG",
    "short_notation": "B1024-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Restraints System Crash Output Lamp -Short to Ground",
    "heal_condition": "Restraints System Crash Output Lamp removed from Short to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PAB ON LED ( GPO-1) LINE SHORT TO GROUND",
}

# B code - Body: B1024-12
PAB_ON_LED_STB = {
    "dtc_hex": "0x902412",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_ON_LED_STB",
    "short_notation": "B1024-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Restraints System Crash Output Lamp -Short to Battery",
    "heal_condition": "Restraints System Crash Output Lamp removed from Short to Battery",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PAB ON LED ( GPO-1) LINE SHORT TO BATTERY",
}

# B code - Body: B1024-13
PAB_ON_LED_OPEN = {
    "dtc_hex": "0x902413",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_ON_LED_OPEN",
    "short_notation": "B1024-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Restraints System Crash Output Lamp -Open",
    "heal_condition": "Restraints System Crash Output Lamp removed from Open",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PAB ON LED ( GPO-1) LINE OPEN CIRCUIT",
}

# B code - Body: B1024-64
PAB_ON_LED_CONFIG = {
    "dtc_hex": "0x902464",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PAB_ON_LED_CONFIG",
    "short_notation": "B1024-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Restraints System PAB ON LED ( GPO-1) -configuration Error",
    "heal_condition": "Restraints System PAB ON LED ( GPO-1) removed from Configuration Error",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Hardwired output / lamp",
    "description": "PAB ON LED ( GPO-1) LINE CONFIGURATION ERROR",
}

# B code - Body: B121F-00
IMU_CRC_ERR_CNT = {
    "dtc_hex": "0x921F00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_CRC_ERR_CNT",
    "short_notation": "B121F-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU CRC Error Counter - Instance 1",
}

# B code - Body: B1220-00
IMU_SPI_ERR_CNT = {
    "dtc_hex": "0x922000",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SPI_ERR_CNT",
    "short_notation": "B1220-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SPI Error Counter - Instance 1",
}

# B code - Body: B1221-00
IMU_SELF_TEST = {
    "dtc_hex": "0x922100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SELF_TEST",
    "short_notation": "B1221-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SelfTest Failure - Instance 1",
}

# B code - Body: B1222-00
IMU_INTERNAL = {
    "dtc_hex": "0x922200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_INTERNAL",
    "short_notation": "B1222-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Internal Failure - Instance 1 (i.e. Serial Number, Overload , Supply failures)",
}

# B code - Body: B1223-00
IMU_INTERNAL_RECOV = {
    "dtc_hex": "0x922300",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_INTERNAL_RECOV",
    "short_notation": "B1223-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Internal Recoverable Failure - Instance 1 (i.e. EMC, Supply failures, Temperature, Overload failures)",
}

# B code - Body: B1224-00
IMU_CAL_INTEGRITY = {
    "dtc_hex": "0x922400",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_CAL_INTEGRITY",
    "short_notation": "B1224-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "Veoneer Manufacturing IMU Calibration data integrity check failure on at least one of the channel",
}

# B code - Body: B1225-00
IMU_SEV_X = {
    "dtc_hex": "0x922500",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_X",
    "short_notation": "B1225-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1, 2 or 3 failure on X direction",
}

# B code - Body: B1226-00
IMU_SEV_Y = {
    "dtc_hex": "0x922600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_Y",
    "short_notation": "B1226-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1, 2 or 3 failure on Y direction",
}

# B code - Body: B1227-00
IMU_SEV_Z = {
    "dtc_hex": "0x922700",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_Z",
    "short_notation": "B1227-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1, 2 or 3 failure on Z direction",
}

# B code - Body: B1228-00
IMU_SEV_YAW = {
    "dtc_hex": "0x922800",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_YAW",
    "short_notation": "B1228-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1, 2 or 3 failure on YAW direction",
}

# B code - Body: B1229-00
IMU_SEV_ROLL = {
    "dtc_hex": "0x922900",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_ROLL",
    "short_notation": "B1229-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1, 2 or 3 failure on ROLL direction",
}

# B code - Body: B122A-00
IMU_SEV_PITCH = {
    "dtc_hex": "0x922A00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_PITCH",
    "short_notation": "B122A-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1,2 or 3 failure on PITCH direction",
}

# B code - Body: B122B-00
IMU_SEV_TEMP = {
    "dtc_hex": "0x922B00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_SEV_TEMP",
    "short_notation": "B122B-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU SEV1,2 or 3 failure for Temperature",
}

# B code - Body: B122C-00
IMU_OOR_X = {
    "dtc_hex": "0x922C00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_X",
    "short_notation": "B122C-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on X direction",
}

# B code - Body: B122D-00
IMU_OOR_Y = {
    "dtc_hex": "0x922D00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_Y",
    "short_notation": "B122D-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on Y direction",
}

# B code - Body: B122E-00
IMU_OOR_Z = {
    "dtc_hex": "0x922E00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_Z",
    "short_notation": "B122E-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on Z direction",
}

# B code - Body: B122F-00
IMU_OOR_YAW = {
    "dtc_hex": "0x922F00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_YAW",
    "short_notation": "B122F-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on YAW direction",
}

# B code - Body: B1230-00
IMU_OOR_ROLL = {
    "dtc_hex": "0x923000",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_ROLL",
    "short_notation": "B1230-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on ROLL direction",
}

# B code - Body: B1231-00
IMU_OOR_PITCH = {
    "dtc_hex": "0x923100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_PITCH",
    "short_notation": "B1231-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on PITCH direction",
}

# B code - Body: B1232-00
IMU_OOR_TEMP = {
    "dtc_hex": "0x923200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IMU_OOR_TEMP",
    "short_notation": "B1232-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "IMU fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "On-board IMU",
    "description": "IMU Out of Range failure on YAW Temperature",
}

# B code - Body: B1233-11
CTR_FSAB_STG = {
    "dtc_hex": "0x923311",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_STG",
    "short_notation": "B1233-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "Center airbag Shorted to GND",
    "heal_condition": "Center airbag removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG - SHORT TO GROUND",
}

# B code - Body: B1233-12
CTR_FSAB_STB = {
    "dtc_hex": "0x923312",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_STB",
    "short_notation": "B1233-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Center airbag Shorted to STB",
    "heal_condition": "Center airbag removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG - SHORT TO BATTERY",
}

# B code - Body: B1233-1A
CTR_FSAB_RES_LOW = {
    "dtc_hex": "0x92331A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_RES_LOW",
    "short_notation": "B1233-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "Center airbag resistance < 1 .66 ohms",
    "heal_condition": "Center airbag resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG - LOW RESISTANCE",
}

# B code - Body: B1233-1B
CTR_FSAB_RES_HIGH = {
    "dtc_hex": "0x92331B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_RES_HIGH",
    "short_notation": "B1233-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "Center airbag resistance > 5.54 ohms",
    "heal_condition": "Center airbag resistance < 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG - HIGH RESISTANCE",
}

# B code - Body: B1233-01
CTR_FSAB_XCONN = {
    "dtc_hex": "0x923301",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_XCONN",
    "short_notation": "B1233-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG - CROSS CONNECT",
}

# B code - Body: B1233-64
CTR_FSAB_UNEXPECTED = {
    "dtc_hex": "0x923364",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_UNEXPECTED",
    "short_notation": "B1233-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Center airbag sq is not configured but physically connected",
    "heal_condition": "cwnter sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG UNEXPECTED SQUIB",
}

# B code - Body: B1233-13
CTR_FSAB_OPEN = {
    "dtc_hex": "0x923313",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CTR_FSAB_OPEN",
    "short_notation": "B1233-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CENTER FAR SIDE AIRBAG OPEN",
}

# B code - Body: B1236-13
LH_APLR_SRSU_OPEN = {
    "dtc_hex": "0x923613",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_APLR_SRSU_OPEN",
    "short_notation": "B1236-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Pas.Side RSU is not connected to the harness",
    "heal_condition": "Pas.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR LEFT SRSU OPEN",
}

# B code - Body: B1236-81
LH_APLR_SRSU_COMM = {
    "dtc_hex": "0x923681",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_APLR_SRSU_COMM",
    "short_notation": "B1236-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR LEFT SRSU COMMUNICATION ERROR",
}

# B code - Body: B1236-11
LH_APLR_SRSU_STG = {
    "dtc_hex": "0x923611",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_APLR_SRSU_STG",
    "short_notation": "B1236-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR LEFT SRSU SHORT TO GROUND",
}

# B code - Body: B1236-12
LH_APLR_SRSU_STB = {
    "dtc_hex": "0x923612",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_APLR_SRSU_STB",
    "short_notation": "B1236-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR LEFT SRSU SHORT TO BATTERY",
}

# B code - Body: B1236-96
LH_APLR_SRSU_INTERNAL = {
    "dtc_hex": "0x923696",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_APLR_SRSU_INTERNAL",
    "short_notation": "B1236-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR LEFT SRSU INTERNAL ERROR",
}

# B code - Body: B1236-64
LH_APLR_SRSU_CONFIG = {
    "dtc_hex": "0x923664",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LH_APLR_SRSU_CONFIG",
    "short_notation": "B1236-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Pas.Side RSU is not connected to the harness",
    "heal_condition": "Pas.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR LEFT SRSU CONFIGURATION ERROR",
}

# B code - Body: B1237-13
RH_APLR_SRSU_OPEN = {
    "dtc_hex": "0x923713",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_APLR_SRSU_OPEN",
    "short_notation": "B1237-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR RIGHT SRSU OPEN",
}

# B code - Body: B1237-81
RH_APLR_SRSU_COMM = {
    "dtc_hex": "0x923781",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_APLR_SRSU_COMM",
    "short_notation": "B1237-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR RIGHT SRSU COMMUNICATION ERROR",
}

# B code - Body: B1237-11
RH_APLR_SRSU_STG = {
    "dtc_hex": "0x923711",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_APLR_SRSU_STG",
    "short_notation": "B1237-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR RIGHT SRSU SHORT TO GROUND",
}

# B code - Body: B1237-12
RH_APLR_SRSU_STB = {
    "dtc_hex": "0x923712",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_APLR_SRSU_STB",
    "short_notation": "B1237-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR RIGHT SRSU SHORT TO BATTERY",
}

# B code - Body: B1237-96
RH_APLR_SRSU_INTERNAL = {
    "dtc_hex": "0x923796",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_APLR_SRSU_INTERNAL",
    "short_notation": "B1237-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR RIGHT SRSU INTERNAL ERROR",
}

# B code - Body: B1237-64
RH_APLR_SRSU_CONFIG = {
    "dtc_hex": "0x923764",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RH_APLR_SRSU_CONFIG",
    "short_notation": "B1237-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Drv.Side RSU is not connected to the harness",
    "heal_condition": "Drv.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-PILLAR RIGHT SRSU CONFIGURATION ERROR",
}

# B code - Body: B1238-13
REAR_RSU_OPEN = {
    "dtc_hex": "0x923813",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "REAR_RSU_OPEN",
    "short_notation": "B1238-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Rear RSU SRSU OPEN",
}

# B code - Body: B1238-81
REAR_RSU_COMM = {
    "dtc_hex": "0x923881",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "REAR_RSU_COMM",
    "short_notation": "B1238-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Rear RSU COMMUNICATION ERROR",
}

# B code - Body: B1238-11
REAR_RSU_STG = {
    "dtc_hex": "0x923811",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "REAR_RSU_STG",
    "short_notation": "B1238-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Rear RSU SHORT TO GROUND",
}

# B code - Body: B1238-12
REAR_RSU_STB = {
    "dtc_hex": "0x923812",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "REAR_RSU_STB",
    "short_notation": "B1238-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Rear RSU SHORT TO BATTERY",
}

# B code - Body: B1238-96
REAR_RSU_INTERNAL = {
    "dtc_hex": "0x923896",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "REAR_RSU_INTERNAL",
    "short_notation": "B1238-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Rear RSU INTERNAL ERROR",
}

# B code - Body: B1238-64
REAR_RSU_CONFIG = {
    "dtc_hex": "0x923864",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "REAR_RSU_CONFIG",
    "short_notation": "B1238-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Rear Side RSU is not connected to the harness",
    "heal_condition": "Rear Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Rear RSU CONFIGURATION ERROR",
}

# B code - Body: B1238-2B
REAR_RSU_XCONN = {
    "dtc_hex": "0x92382B",
    "applicable_to": ("ICE",),
    "mnemonic": "REAR_RSU_XCONN",
    "short_notation": "B1238-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "REAR RSU short with another remote sensor",
    "heal_condition": "Rear RSU has no short circuit with any other remote sensor.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "REAR RSU short to another remote sensor",
}

# B code - Body: B1239-2B
RH_APLR_SRSU_XCONN = {
    "dtc_hex": "0x92392B",
    "applicable_to": ("ICE",),
    "mnemonic": "RH_APLR_SRSU_XCONN",
    "short_notation": "B1239-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "A-pillar right SRSU short with another remote sensor",
    "heal_condition": "A-pillar right SRSU has no short circuit with any other remote sensor.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-pillar right SRSU short to another remote sensor",
}

# B code - Body: B1240-2B
LH_APLR_SRSU_XCONN = {
    "dtc_hex": "0x92402B",
    "applicable_to": ("ICE",),
    "mnemonic": "LH_APLR_SRSU_XCONN",
    "short_notation": "B1240-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Short to another remote sensor",
    "set_condition": "A-pillar left SRSU short with another remote sensor",
    "heal_condition": "A-pillar left SRSU has no short circuit with any other remote sensor.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "1 IGN Cycle",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "A-pillar left SRSU short to another remote sensor",
}

# B code - Body: B1241-14
PAB_EN_SW_STG = {
    "dtc_hex": "0x924114",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_EN_SW_STG",
    "short_notation": "B1241-14",
    "dtc_type": "B (Body)",
    "ftb": "0x14",
    "fault_type": "Short circuit to ground",
    "set_condition": "PAB switch shorted to GND (R<52 ohms)",
    "heal_condition": "PAB switch removed from shorted to GND ( not in - R<52 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG ENABLE SWITCH - SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1241-15
PAB_EN_SW_STB = {
    "dtc_hex": "0x924115",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_EN_SW_STB",
    "short_notation": "B1241-15",
    "dtc_type": "B (Body)",
    "ftb": "0x15",
    "fault_type": "Short circuit to battery",
    "set_condition": "PAB switch shorted to STB",
    "heal_condition": "PAB switch removed from shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG ENABLE SWITCH - SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1241-13
PAB_EN_SW_OPEN = {
    "dtc_hex": "0x924113",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_EN_SW_OPEN",
    "short_notation": "B1241-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "PAB switch resistance (605 ohms < R)",
    "heal_condition": "PAB switch resistance is not (605 ohms < R)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG ENABLE SWITCH - OPEN CIRCUIT",
}

# B code - Body: B1241-1A
PAB_EN_SW_RES_LOW = {
    "dtc_hex": "0x92411A",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_EN_SW_RES_LOW",
    "short_notation": "B1241-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "PAB switch resistance (52 ohms < R < 72 ohms)",
    "heal_condition": "PAB switch resistance is out of (52 ohms < R < 72 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG ENABLE SWITCH-LOW RESISTANCE",
}

# B code - Body: B1241-1B
PAB_EN_SW_RES_HIGH = {
    "dtc_hex": "0x92411B",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_EN_SW_RES_HIGH",
    "short_notation": "B1241-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "PAB switch resistance (520 ohms < R < 605 ohms)",
    "heal_condition": "PAB switch resistance is out of (520 ohms < R < 605 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG SWITCH-HIGH RESISTANCE",
}

# B code - Body: B1241-1E
PAB_EN_SW_RES_OOR = {
    "dtc_hex": "0x92411E",
    "applicable_to": ("ICE",),
    "mnemonic": "PAB_EN_SW_RES_OOR",
    "short_notation": "B1241-1E",
    "dtc_type": "B (Body)",
    "ftb": "0x1E",
    "fault_type": "Resistance in the invalid window",
    "set_condition": "PAB switch resistance (139 ohms < R < 313 ohms)",
    "heal_condition": "PAB switch resistance is out of (139 ohms < R < 313 ohms)",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Passenger airbag (PAB) switch",
    "description": "PASSENGER AIRBAG ENABLE SWITCH-INVALID RESISTANCE",
}

# U code - Network: U1054-00
VCU_MTO = {
    "dtc_hex": "0xD05400",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VCU_MTO",
    "short_notation": "U1054-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message timeout",
    "set_condition": "Atleast one NON KEY message is missing from VCU node",
    "heal_condition": "All non-key messages are available from VCU node.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)VCU Node should be present in variant coding and \"SRS Variant Code Error\" should not be active. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "VCU Message Timeout",
}

# U code - Network: U1103-00
IEB_NODE_ABSENT = {
    "dtc_hex": "0xD10300",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IEB_NODE_ABSENT",
    "short_notation": "U1103-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "IEB KEY MSG (0x13B) is absent",
    "heal_condition": "IEB KEY MSG is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)IEB Node should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "IEB Node Absent",
}

# U code - Network: U1104-00
FR_ZONE_NODE_ABSENT = {
    "dtc_hex": "0xD10400",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "FR_ZONE_NODE_ABSENT",
    "short_notation": "U1104-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "FR_ZONE2_100 message is absent",
    "heal_condition": "FR_ZONE2_100 message is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front zone Node should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "FR_ZONE Node Absent",
}

# U code - Network: U1111-00
EPS_NODE_ABSENT = {
    "dtc_hex": "0xD11100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "EPS_NODE_ABSENT",
    "short_notation": "U1111-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "EPS1_FD_10 is absent",
    "heal_condition": "EPS1_FD_10 is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)EPS Node should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "EPS Node Absent",
}

# U code - Network: U1154-00
VCU_NODE_ABSENT = {
    "dtc_hex": "0xD15400",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VCU_NODE_ABSENT",
    "short_notation": "U1154-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "VCU11_FD_10 is absent",
    "heal_condition": "VCU11_FD_10 is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)VCU Node should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "VCU Node Absent",
}

# U code - Network: U1160-00
HPCC_NODE_ABSENT = {
    "dtc_hex": "0xD16000",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCC_NODE_ABSENT",
    "short_notation": "U1160-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "HPCC_1_100 is absent",
    "heal_condition": "HPCC_1_100 is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_C Node should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCC Node Absent",
}

# U code - Network: U1206-00
SRS_BUS_OFF = {
    "dtc_hex": "0xD20600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "SRS_BUS_OFF",
    "short_notation": "U1206-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "CAN bus off",
    "set_condition": "CAN BUS OFF",
    "heal_condition": "CAN BUS OFF Recovery",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "CAN communication",
    "description": "SRS Bus Off",
}

# U code - Network: U1306-00
SRS_VIN_MISMATCH = {
    "dtc_hex": "0xD30600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "SRS_VIN_MISMATCH",
    "short_notation": "U1306-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "VIN mismatch",
    "set_condition": "VIN Data is not received/wrongly received or HPC_Ad5_500 message missing or HPC_Ad5_500 message is received with incorrect DLC",
    "heal_condition": "VIN Data is received properly",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet; 6500ms",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet; 3500ms",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2).Node should be present in variant coding and variant Error should not be present. 3)Voltage should be normal. 4)No BUS off; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "CAN communication",
    "description": "SRS VIN Mismatch",
}

# U code - Network: U1506-00
SRS_VARIANT_CODE_ERR = {
    "dtc_hex": "0xD50600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "SRS_VARIANT_CODE_ERR",
    "short_notation": "U1506-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Variant code error",
    "set_condition": "Variant Code status bit is not set.",
    "heal_condition": "DTC cannot Passed in the current Ignition cycle. It can be passed whenVariant Code status bit is set",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal. 3) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "CAN communication",
    "description": "SRS Variant Code Error",
}

# U code - Network: U2724-00
FR_ZONE3_100_MCF = {
    "dtc_hex": "0xE72400",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "FR_ZONE3_100_MCF",
    "short_notation": "U2724-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message FR_ZONE3_100 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "FR_ZONE3_100 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front zone Node should be present in variant coding and variant Error should not be present. 3)Front zone Node Absent fault should not be active; 4)Front zone Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "FR_ZONE3_100(0x31A) Message Contenet Failure",
}

# U code - Network: U2726-00
VCU11_FD_10_MCF = {
    "dtc_hex": "0xE72600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VCU11_FD_10_MCF",
    "short_notation": "U2726-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message VCU11_FD_10 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "VCU11_FD_10 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)VCU Node should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "VCU11_FD_10(0x16E) Message Content failure",
}

# U code - Network: U105A-00
HPCC_MTO = {
    "dtc_hex": "0xD05A00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCC_MTO",
    "short_notation": "U105A-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message timeout",
    "set_condition": "Atleast one NON KEY message is missing from HPCC node",
    "heal_condition": "All non-key messages are available from HPCC node.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPCC Node should be present in variant coding and \"SRS Variant Code Error\" should not be active. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCC Message Time Out",
}

# U code - Network: U271F-00
HPCC_1_100_MCF = {
    "dtc_hex": "0xE71F00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCC_1_100_MCF",
    "short_notation": "U271F-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message HPCC_1_100 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "HPCC_1_100 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_C Node should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCC_1_100 (0x318) Message Contenet Failure",
}

# U code - Network: U2720-00
IEB1_FD_10_MCF = {
    "dtc_hex": "0xE72000",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "IEB1_FD_10_MCF",
    "short_notation": "U2720-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message IEB1_FD_10 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "IEB1_FD_10 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)IEB Node should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "IEB1_FD_10 (0x13B) Message Contenet Failure",
}

# U code - Network: U2725-00
EPS1_FD_10_MCF = {
    "dtc_hex": "0xE72500",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "EPS1_FD_10_MCF",
    "short_notation": "U2725-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message EPS1_FD_10 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "EPS1_FD_10 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)EPS Node should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "EPS1_FD_10(0x13A) Message Content failure",
}

# U code - Network: U2722-00
VCU1_FD_20_MCF = {
    "dtc_hex": "0xE72200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VCU1_FD_20_MCF",
    "short_notation": "U2722-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message VCU1_FD_20 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "VCU1_FD_20 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)VCU Node should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "VCU1_FD_20 (0x207) Message Contenet Failure",
}

# U code - Network: U2723-00
VCU2_FD_100_MCF = {
    "dtc_hex": "0xE72300",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VCU2_FD_100_MCF",
    "short_notation": "U2723-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message VCU2_FD_100 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "VCU2_FD_100 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)VCU Node should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "VCU2_FD_100 (0x30E) Message Contenet Failure",
}

# U code - Network: U2806-00
SRS_FEATURE_CODE_ERR = {
    "dtc_hex": "0xE80600",
    "applicable_to": ("ICE",),
    "mnemonic": "SRS_FEATURE_CODE_ERR",
    "short_notation": "U2806-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Feature code error",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "CAN communication",
    "description": "SRS Feature Code Error",
}

# U code - Network: U2013-00
VEHICLE_SPEED_SCF = {
    "dtc_hex": "0xE01300",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VEHICLE_SPEED_SCF",
    "short_notation": "U2013-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "VEHICLE_SPEED signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "VEHICLE_SPEED signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)IEB Node should be present in variant coding and variant Error should not be present. 3)IEB Node Absent fault and IEB message content failure should not be active; 4)Voltage should be normal. 5)No BUS off; 6) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "Vehicle Speed Signal Content Error",
}

# U code - Network: U215F-00
MOTOR_SPEED_SCF = {
    "dtc_hex": "0xE15F00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "MOTOR_SPEED_SCF",
    "short_notation": "U215F-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "CAN communication",
    "description": "Motor Speed signal content failure",
}

# B code - Body: B18F4-01
R2_LH_ODS_XCONN = {
    "dtc_hex": "0x98F401",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_ODS_XCONN",
    "short_notation": "B18F4-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "ODS Cross connected",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW LEFT ODS CROSS CONNECTED",
}

# B code - Body: B18F4-1B
R2_LH_ODS_RES_HIGH = {
    "dtc_hex": "0x98F41B",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_LH_ODS_RES_HIGH",
    "short_notation": "B18F4-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "ODS Resistance >400 ohm",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW LEFT ODS HIGH RESISTANCE",
}

# B code - Body: B18F4-1A
R2_LH_ODS_RES_LOW = {
    "dtc_hex": "0x98F41A",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_LH_ODS_RES_LOW",
    "short_notation": "B18F4-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": None,
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW LEFT ODS LOW RESISTANCE",
}

# B code - Body: B18F4-11
R2_LH_ODS_STG = {
    "dtc_hex": "0x98F411",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_LH_ODS_STG",
    "short_notation": "B18F4-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "ODS Short with ground",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW LEFT ODS SHORT TO GROUND",
}

# B code - Body: B18F4-13
R2_LH_ODS_OPEN = {
    "dtc_hex": "0x98F413",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_LH_ODS_OPEN",
    "short_notation": "B18F4-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "ODS connector open",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW LEFT ODS CONNECTOR OPEN",
}

# B code - Body: B18F4-12
R2_LH_ODS_STB = {
    "dtc_hex": "0x98F412",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_ODS_STB",
    "short_notation": "B18F4-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "ODS Short with Battery",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW LEFT ODS SHORT TO BATTERY",
}

# B code - Body: B1242-12
R2_LH_BKL_STB = {
    "dtc_hex": "0x924212",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_BKL_STB",
    "short_notation": "B1242-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Second Row LEFT SEAT BELT LEAK TO PLUS",
    "heal_condition": "Second Row LEFT SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "SECOND ROW LEFT SEAT BELT LEAK TO PLUS",
}

# B code - Body: B18F5-01
R2_RH_ODS_XCONN = {
    "dtc_hex": "0x98F501",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_ODS_XCONN",
    "short_notation": "B18F5-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "ODS Cross connected",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW RIGHT ODS CROSS CONNECTED",
}

# B code - Body: B18F5-1B
R2_RH_ODS_RES_HIGH = {
    "dtc_hex": "0x98F51B",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_RH_ODS_RES_HIGH",
    "short_notation": "B18F5-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "ODS Resistance >400 ohm",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW RIGHT ODS HIGH RESISTANCE",
}

# B code - Body: B18F5-1A
R2_RH_ODS_RES_LOW = {
    "dtc_hex": "0x98F51A",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_RH_ODS_RES_LOW",
    "short_notation": "B18F5-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": None,
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW RIGHT ODS LOW RESISTANCE",
}

# B code - Body: B18F5-11
R2_RH_ODS_STG = {
    "dtc_hex": "0x98F511",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_RH_ODS_STG",
    "short_notation": "B18F5-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "ODS Short with ground",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW RIGHT ODS SHORT TO GROUND",
}

# B code - Body: B18F5-13
R2_RH_ODS_OPEN = {
    "dtc_hex": "0x98F513",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_RH_ODS_OPEN",
    "short_notation": "B18F5-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "ODS connector open",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW RIGHT ODS CONNECTOR OPEN",
}

# B code - Body: B18F5-12
R2_RH_ODS_STB = {
    "dtc_hex": "0x98F512",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_ODS_STB",
    "short_notation": "B18F5-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "ODS Short with Battery",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW RIGHT ODS SHORT TO BATTERY",
}

# B code - Body: B1243-12
R2_RH_BKL_STB = {
    "dtc_hex": "0x924312",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_BKL_STB",
    "short_notation": "B1243-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Second Row RIGHT SEAT BELT LEAK TO PLUS",
    "heal_condition": "Second Row RIGHT SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "Second Row RIGHT SEAT BELT LEAK TO PLUS",
}

# B code - Body: B18F6-01
R2_MID_ODS_XCONN = {
    "dtc_hex": "0x98F601",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_MID_ODS_XCONN",
    "short_notation": "B18F6-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "ODS Cross connected",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW MIDDLE ODS CROSS CONNECTED",
}

# B code - Body: B18F6-1B
R2_MID_ODS_RES_HIGH = {
    "dtc_hex": "0x98F61B",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_MID_ODS_RES_HIGH",
    "short_notation": "B18F6-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "ODS Resistance >400 ohm",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW MIDDLE ODS HIGH RESISTANCE",
}

# B code - Body: B18F6-1A
R2_MID_ODS_RES_LOW = {
    "dtc_hex": "0x98F61A",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_MID_ODS_RES_LOW",
    "short_notation": "B18F6-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": None,
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW MIDDLE ODS LOW RESISTANCE",
}

# B code - Body: B18F6-11
R2_MID_ODS_STG = {
    "dtc_hex": "0x98F611",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_MID_ODS_STG",
    "short_notation": "B18F6-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "ODS Short with ground",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW MIDDLE ODS SHORT TO GROUND",
}

# B code - Body: B18F6-13
R2_MID_ODS_OPEN = {
    "dtc_hex": "0x98F613",
    "applicable_to": ("ICE",),
    "mnemonic": "R2_MID_ODS_OPEN",
    "short_notation": "B18F6-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "ODS connector open",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW MIDDLE ODS CONNECTOR OPEN",
}

# B code - Body: B18F6-12
R2_MID_ODS_STB = {
    "dtc_hex": "0x98F612",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_MID_ODS_STB",
    "short_notation": "B18F6-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "ODS Short with Battery",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "SECOND ROW MIDDLE ODS SHORT TO BATTERY",
}

# B code - Body: B1244-12
R2_MID_BKL_STB = {
    "dtc_hex": "0x924412",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_MID_BKL_STB",
    "short_notation": "B1244-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Second Row MIDDLE SEAT BELT LEAK TO PLUS",
    "heal_condition": "Second Row MIDDLE SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "Second Row MIDDLE SEAT BELT LEAK TO PLUS",
}

# B code - Body: B18F7-01
R3_LH_ODS_XCONN = {
    "dtc_hex": "0x98F701",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_LH_ODS_XCONN",
    "short_notation": "B18F7-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "ODS Cross connected",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW LEFT ODS CROSS CONNECTED",
}

# B code - Body: B18F7-1B
R3_LH_ODS_RES_HIGH = {
    "dtc_hex": "0x98F71B",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_LH_ODS_RES_HIGH",
    "short_notation": "B18F7-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "ODS Resistance >400 ohm",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW LEFT ODS HIGH RESISTANCE",
}

# B code - Body: B18F7-1A
R3_LH_ODS_RES_LOW = {
    "dtc_hex": "0x98F71A",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_LH_ODS_RES_LOW",
    "short_notation": "B18F7-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": None,
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW LEFT ODS LOW RESISTANCE",
}

# B code - Body: B18F7-11
R3_LH_ODS_STG = {
    "dtc_hex": "0x98F711",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_LH_ODS_STG",
    "short_notation": "B18F7-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "ODS Short with ground",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW LEFT ODS SHORT TO GROUND",
}

# B code - Body: B18F7-13
R3_LH_ODS_OPEN = {
    "dtc_hex": "0x98F713",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_LH_ODS_OPEN",
    "short_notation": "B18F7-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "ODS connector open",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW LEFT ODS CONNECTOR OPEN",
}

# B code - Body: B18F7-12
R3_LH_ODS_STB = {
    "dtc_hex": "0x98F712",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_LH_ODS_STB",
    "short_notation": "B18F7-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "ODS Short with Battery",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW LEFT ODS SHORT TO BATTERY",
}

# B code - Body: B1245-12
R3_LH_BKL_STB = {
    "dtc_hex": "0x924512",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_LH_BKL_STB",
    "short_notation": "B1245-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Third Row LEFT SEAT BELT LEAK TO PLUS",
    "heal_condition": "Third Row LEFT SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "Third Row LEFT SEAT BELT LEAK TO PLUS",
}

# B code - Body: B18F8-01
R3_RH_ODS_XCONN = {
    "dtc_hex": "0x98F801",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_RH_ODS_XCONN",
    "short_notation": "B18F8-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "ODS Cross connected",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW RIGHT ODS CROSS CONNECTED",
}

# B code - Body: B18F8-1B
R3_RH_ODS_RES_HIGH = {
    "dtc_hex": "0x98F81B",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_RH_ODS_RES_HIGH",
    "short_notation": "B18F8-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "ODS Resistance >400 ohm",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW RIGHT ODS HIGH RESISTANCE",
}

# B code - Body: B18F8-1A
R3_RH_ODS_RES_LOW = {
    "dtc_hex": "0x98F81A",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_RH_ODS_RES_LOW",
    "short_notation": "B18F8-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": None,
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW RIGHT ODS LOW RESISTANCE",
}

# B code - Body: B18F8-11
R3_RH_ODS_STG = {
    "dtc_hex": "0x98F811",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_RH_ODS_STG",
    "short_notation": "B18F8-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "ODS Short with ground",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW RIGHT ODS SHORT TO GROUND",
}

# B code - Body: B18F8-13
R3_RH_ODS_OPEN = {
    "dtc_hex": "0x98F813",
    "applicable_to": ("ICE",),
    "mnemonic": "R3_RH_ODS_OPEN",
    "short_notation": "B18F8-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "ODS connector open",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW RIGHT ODS CONNECTOR OPEN",
}

# B code - Body: B18F8-12
R3_RH_ODS_STB = {
    "dtc_hex": "0x98F812",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_RH_ODS_STB",
    "short_notation": "B18F8-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "ODS Short with Battery",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "THIRD ROW RIGHT ODS SHORT TO BATTERY",
}

# B code - Body: B1246-12
R3_RH_BKL_STB = {
    "dtc_hex": "0x924612",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_RH_BKL_STB",
    "short_notation": "B1246-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "Third Row RIGHT SEAT BELT LEAK TO PLUS",
    "heal_condition": "Third Row RIGHT SEAT BELT Short to PLUS is removed",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "Third Row RIGHT SEAT BELT LEAK TO PLUS",
}

# B code - Body: B1247-00
CAL_MISSING = {
    "dtc_hex": "0x924700",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CAL_MISSING",
    "short_notation": "B1247-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "Calibration fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "ECU internal / configuration",
    "description": "Missing calibration",
}

# B code - Body: B1248-00
CAL_INCORRECT = {
    "dtc_hex": "0x924800",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "CAL_INCORRECT",
    "short_notation": "B1248-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "Calibration fault",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": "NA",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "ECU internal / configuration",
    "description": "Incorrect calibration.",
}

# B code - Body: B1252-13
UB_SNS_OPEN = {
    "dtc_hex": "0x925213",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "UB_SNS_OPEN",
    "short_notation": "B1252-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "Sensor with Wrong SN",
    "heal_condition": "Sensor with correct SN",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Under Body Sensor OPEN",
}

# B code - Body: B1252-81
UB_SNS_COMM = {
    "dtc_hex": "0x925281",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "UB_SNS_COMM",
    "short_notation": "B1252-81",
    "dtc_type": "B (Body)",
    "ftb": "0x81",
    "fault_type": "Communication error",
    "set_condition": "RSU terminal SC to GND",
    "heal_condition": "RSU terminal removed from SC to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Under Body Sensor COMMUNICATION ERROR",
}

# B code - Body: B1252-11
UB_SNS_STG = {
    "dtc_hex": "0x925211",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "UB_SNS_STG",
    "short_notation": "B1252-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "RSU terminal SC to BATTERY",
    "heal_condition": "RSU terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Under Body Sensor SHORT TO GROUND",
}

# B code - Body: B1252-12
UB_SNS_STB = {
    "dtc_hex": "0x925212",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "UB_SNS_STB",
    "short_notation": "B1252-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Under Body Sensor SHORT TO BATTERY",
}

# B code - Body: B1252-96
UB_SNS_INTERNAL = {
    "dtc_hex": "0x925296",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "UB_SNS_INTERNAL",
    "short_notation": "B1252-96",
    "dtc_type": "B (Body)",
    "ftb": "0x96",
    "fault_type": "Internal error",
    "set_condition": "RSU Internal Failure",
    "heal_condition": "Based on severity",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1500ms",
    "mature_time_ms": 1500,
    "demature_time": "lessthan 1Sec",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Under Body Sensor INTERNAL ERROR",
}

# B code - Body: B1252-64
UB_SNS_CONFIG = {
    "dtc_hex": "0x925264",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "UB_SNS_CONFIG",
    "short_notation": "B1252-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Drv.Side RSU is not connected to the harness",
    "heal_condition": "Drv.Side RSU properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Remote crash sensor (PSI5 satellite)",
    "description": "Under Body Sensor CONFIGURATION ERROR",
}

# U code - Network: U1161-00
HPCAD_NODE_ABSENT = {
    "dtc_hex": "0xD16100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCAD_NODE_ABSENT",
    "short_notation": "U1161-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "HPCAd_1_10 is absent",
    "heal_condition": "HPCAd_1_10 is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCAd Node Absent",
}

# U code - Network: U271D-00
HPCAD_1_10_MCF = {
    "dtc_hex": "0xE71D00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCAD_1_10_MCF",
    "short_notation": "U271D-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message HPCAd_1_10 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "HPCAd_1_10 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and variant Error should not be present. 3)HPC_Ad Node Absent fault should not be active; 4)HPC_Ad Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCAd_1_10(0x13E) Message Content failure",
}

# U code - Network: U2732-00
HPCAD_2_50_MCF = {
    "dtc_hex": "0xE73200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCAD_2_50_MCF",
    "short_notation": "U2732-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message HPCAd_2_50 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "HPCAd_2_50 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and variant Error should not be present. 3)HPC_Ad Node Absent fault should not be active; 4)HPC_Ad Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCAd_2_50(0x2AF) Message Content failure",
}

# U code - Network: U271E-00
HPCAD_3_50_MCF = {
    "dtc_hex": "0xE71E00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCAD_3_50_MCF",
    "short_notation": "U271E-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message HPCAd_3_50 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "HPCAd_3_50 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and variant Error should not be present. 3)HPC_Ad Node Absent fault should not be active; 4)HPC_Ad Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCAd_3_50(0x2B1) Message Content failure",
}

# U code - Network: U2729-00
HPCAD_4_10_MCF = {
    "dtc_hex": "0xE72900",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCAD_4_10_MCF",
    "short_notation": "U2729-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message HPCAd_4_10 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "HPCAd_4_10 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and variant Error should not be present. 3)HPC_Ad Node Absent fault should not be active; 4)HPC_Ad Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCAd_4_10(0x13F) Message Content failure",
}

# U code - Network: U2177-00
ADAS_DES_STRWHL_ANGLE_CMD_SCF = {
    "dtc_hex": "0xE17700",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ADAS_DES_STRWHL_ANGLE_CMD_SCF",
    "short_notation": "U2177-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "ADAS_DES_STRWHL_ANGLE_CMD signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "ADAS_DES_STRWHL_ANGLE_CMD signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and variant Error should not be present. 3)HPC_Ad Node Absent fault should not be active; 4)HPC_Ad Message Timeout fault due to HPC_Ad36_10 missing should not be active; 5) HPC_Ad_1_10 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "ADAS_DES_STRWHL_ANGLE_CMD Signal Content Failure",
}

# U code - Network: U20D6-00
FL_TYRE_PRESSURE_SCF = {
    "dtc_hex": "0xE0D600",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "FL_TYRE_PRESSURE_SCF",
    "short_notation": "U20D6-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "FL_TYRE_PRESSURE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "FL_TYRE_PRESSURE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front Zone Node should be present in variant coding and variant Error should not be present. 3)Front zone Node Absent fault should not be active; 4)Front zone Message Timeout fault due to FR_ZONE3_100 missing should not be active; 5) FR_ZONE3_100 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "FL_TYRE_PRESSURE Signal Content Failure",
}

# U code - Network: U20D7-00
FR_TYRE_PRESSURE_SCF = {
    "dtc_hex": "0xE0D700",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "FR_TYRE_PRESSURE_SCF",
    "short_notation": "U20D7-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "FR_TYRE_PRESSURE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "FR_TYRE_PRESSURE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front Zone Node should be present in variant coding and variant Error should not be present. 3)Front zone Node Absent fault should not be active; 4)Front zone Message Timeout fault due to FR_ZONE3_100 missing should not be active; 5) FR_ZONE3_100 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "FR_TYRE_PRESSURE Signal Content Failure",
}

# U code - Network: U20D8-00
RL_TYRE_PRESSURE_SCF = {
    "dtc_hex": "0xE0D800",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RL_TYRE_PRESSURE_SCF",
    "short_notation": "U20D8-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "RL_TYRE_PRESSURE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "RL_TYRE_PRESSURE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front Zone Node should be present in variant coding and variant Error should not be present. 3)Front zone Node Absent fault should not be active; 4)Front zone Message Timeout fault due to FR_ZONE3_100 missing should not be active; 5) FR_ZONE3_100 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "RL_TYRE_PRESSURE Signal Content Failure",
}

# U code - Network: U20D9-00
RR_TYRE_PRESSURE_SCF = {
    "dtc_hex": "0xE0D900",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RR_TYRE_PRESSURE_SCF",
    "short_notation": "U20D9-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "RR_TYRE_PRESSURE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "RR_TYRE_PRESSURE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front Zone Node should be present in variant coding and variant Error should not be present. 3)Front zone Node Absent fault should not be active; 4)Front zone Message Timeout fault due to FR_ZONE3_100 missing should not be active; 5) FR_ZONE3_100 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "RR_TYRE_PRESSURE Signal Content Failure",
}

# U code - Network: U211D-00
GEAR_ACTUAL_SCF = {
    "dtc_hex": "0xE11D00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "GEAR_ACTUAL_SCF",
    "short_notation": "U211D-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "GEAR_ACTUAL signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "GEAR_ACTUAL signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) VCU should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault due to VCU_2_FD_100 missing should not be active; 5) VCU_2_FD_100 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "GEAR_ACTUAL signal Content Failure",
}

# U code - Network: U218D-00
MASTER_CYL_PRESSURE_SCF = {
    "dtc_hex": "0xE18D00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "MASTER_CYL_PRESSURE_SCF",
    "short_notation": "U218D-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "MASTER_CYL_PRESSURE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "MASTER_CYL_PRESSURE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)IEB Node should be present in variant coding and variant Error should not be present. 3)IEB Node Absent fault and IEB message content failure should not be active; 4)Voltage should be normal. 5)No BUS off; 6) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "MASTER_CYL_PRESSURE Signal Content Failure",
}

# U code - Network: U2012-00
ODOMTR_READING_IS_SCF = {
    "dtc_hex": "0xE01200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ODOMTR_READING_IS_SCF",
    "short_notation": "U2012-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "ODOMTR_READING_IS Signal Content Failure signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "ODOMTR_READING_IS Signal Content Failure signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) HPC_C should be present in variant coding and variant Error should not be present. 3)HPC_C Node Absent fault should not be active; 5) HPCC_1_100 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "ODOMTR_READING_IS Signal Content Failure",
}

# U code - Network: U2058-00
STEERING_ABSOLUTE_ANGLE_SCF = {
    "dtc_hex": "0xE05800",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "STEERING_ABSOLUTE_ANGLE_SCF",
    "short_notation": "U2058-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "STEERING_ABSOLUTE_ANGLE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "STEERING_ABSOLUTE_ANGLE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)EPS Node should be present in variant coding and variant Error should not be present. 3)EPS Node Absent fault and EPS message content failure should not be active; 4)Voltage should be normal. 5)No BUS off; 6) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "STEERING_ABSOLUTE_ANGLE signal content failure",
}

# U code - Network: U2179-00
VEHICLE_STATE_SCF = {
    "dtc_hex": "0xE17900",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "VEHICLE_STATE_SCF",
    "short_notation": "U2179-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Signal content failure",
    "set_condition": "VEHICLE_STATE signal is received with invalid value for \"Signal Content Fail Detect Count\" times",
    "heal_condition": "VEHICLE_STATE signal is received with valid value for for \"Signal Content Recov Detect Count\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) VCU should be present in variant coding and variant Error should not be present. 3)VCU Node Absent fault should not be active; 4)VCU Message Timeout fault due to VCU1_FD_20 missing should not be active; 5) VCU1_FD_20 Message Content Failure should not be active. 6)Voltage should be normal. 7)No BUS off; 8) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "VEHICLE_STATE Signal Content Failure",
}

# B code - Body: B1252-00
ECU_LOCK_UNDERSTRIKE = {
    "dtc_hex": "0x925200",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_UNDERSTRIKE",
    "short_notation": "B1252-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU locked after a crash",
    "set_condition": "Under body sensor, need to impacted with Certain force and cross the thresold value and ECU will lock",
    "heal_condition": "ECU Need to replace",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "Immediate",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "Under strike Event Crash",
}

# U code - Network: U1271-00
HSCAN_BUS_OFF = {
    "dtc_hex": "0xD27100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HSCAN_BUS_OFF",
    "short_notation": "U1271-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "CAN bus off",
    "set_condition": "CAN BUS OFF",
    "heal_condition": "CAN BUS OFF Recovery",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HSCAN_BUS_OFF_FAULT",
}

# U code - Network: U1004-00
FR_ZONE_MTO = {
    "dtc_hex": "0xD00400",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "FR_ZONE_MTO",
    "short_notation": "U1004-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message timeout",
    "set_condition": "Atleast one NON KEY message is missing from Front zone node",
    "heal_condition": "All non-key messages are available from front zone node.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front Zone Node should be present in variant coding and \"SRS Variant Code Error\" should not be active. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "FR_ZONE Message Timeout",
}

# U code - Network: U105B-00
HPCAD_MTO = {
    "dtc_hex": "0xD05B00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "HPCAD_MTO",
    "short_notation": "U105B-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message timeout",
    "set_condition": "Atleast one NON KEY message is missing from HPC_Ad node",
    "heal_condition": "All non-key messages are available from HPC_Ad node.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)HPC_Ad Node should be present in variant coding and \"SRS Variant Code Error\" should not be active. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "HPCAd Message Time Out",
}

# U code - Network: U271C-00
FR_ZONE2_100_MCF = {
    "dtc_hex": "0xE71C00",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "FR_ZONE2_100_MCF",
    "short_notation": "U271C-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message FR_ZONE2_100 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "FR_ZONE2_100 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "As per network management identifier sheet",
    "mature_time_ms": None,
    "demature_time": "As per network management identifier sheet",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)Front zone Node should be present in variant coding and variant Error should not be present. 3)Front zone Node Absent fault should not be active; 4)Front zone Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": 40,
    "warning_lamp": "OFF",
    "group": "CAN communication",
    "description": "FR_ZONE2_100(0x319) Message Contenet Failure",
}

# B code - Body: B1253-2B
DRV_BKL_XCONN = {
    "dtc_hex": "0x92532B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_BKL_XCONN",
    "short_notation": "B1253-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "DRIVER DC'S crossconnect",
}

# B code - Body: B1254-2B
PSG_BKL_XCONN = {
    "dtc_hex": "0x92542B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_BKL_XCONN",
    "short_notation": "B1254-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "CO-DRIVER DC cross connect",
}

# B code - Body: B1255-2B
R2_RH_BKL_XCONN = {
    "dtc_hex": "0x92552B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_BKL_XCONN",
    "short_notation": "B1255-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "2nd ROW RIGHT DC CROSS CONNECT",
}

# B code - Body: B1256-2B
R2_MID_BKL_XCONN = {
    "dtc_hex": "0x92562B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_MID_BKL_XCONN",
    "short_notation": "B1256-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "2nd ROW MIDDLE DC CROSS CONNECT",
}

# B code - Body: B1257-2B
R2_LH_BKL_XCONN = {
    "dtc_hex": "0x92572B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_BKL_XCONN",
    "short_notation": "B1257-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "2nd ROW LEFT DC CROSS CONNECT",
}

# B code - Body: B1258-2B
R3_RH_BKL_XCONN = {
    "dtc_hex": "0x92582B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_RH_BKL_XCONN",
    "short_notation": "B1258-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "3RD ROW RIGHT DC CROSS CONNECT",
}

# B code - Body: B1259-2B
R3_LH_BKL_XCONN = {
    "dtc_hex": "0x92592B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R3_LH_BKL_XCONN",
    "short_notation": "B1259-2B",
    "dtc_type": "B (Body)",
    "ftb": "0x2B",
    "fault_type": "Cross connection",
    "set_condition": "DCS Cross connected",
    "heal_condition": "DCS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat belt buckle switch (DCS)",
    "description": "3RD ROW LEFT DC CROSS CONNECT",
}

# B code - Body: B18F9-64
DRV_STPS1_CONFIG = {
    "dtc_hex": "0x98F964",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_STPS1_CONFIG",
    "short_notation": "B18F9-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Drv.Side STPS is not connected to the harness",
    "heal_condition": "Drv.Side STPS properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS1 CONFIGURATION ERROR",
}

# B code - Body: B18F9-01
DRV_STPS1_XCONN = {
    "dtc_hex": "0x98F901",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_STPS1_XCONN",
    "short_notation": "B18F9-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "STPS Cross connected",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS1 CROSS CONNECTED",
}

# B code - Body: B18F9-13
DRV_STPS1_OPEN = {
    "dtc_hex": "0x98F913",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_STPS1_OPEN",
    "short_notation": "B18F9-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "STPS connector open",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS1 CONNETOR OPEN",
}

# B code - Body: B18F9-12
DRV_STPS1_STB = {
    "dtc_hex": "0x98F912",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_STPS1_STB",
    "short_notation": "B18F9-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "STPS terminal SC to BATTERY",
    "heal_condition": "STPS terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS1 SHORT TO BATTERY",
}

# B code - Body: B18F9-11
DRV_STPS1_STG = {
    "dtc_hex": "0x98F911",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_STPS1_STG",
    "short_notation": "B18F9-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "STPS terminal SC to Ground",
    "heal_condition": "STPS terminal removed from SC to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS1 SHORT TO GROUND",
}

# B code - Body: B18FA-01
DRV_STPS2_XCONN = {
    "dtc_hex": "0x98FA01",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_STPS2_XCONN",
    "short_notation": "B18FA-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "STPS Cross connected",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS2 CROSS CONNECTED",
}

# B code - Body: B18FA-13
DRV_STPS2_OPEN = {
    "dtc_hex": "0x98FA13",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_STPS2_OPEN",
    "short_notation": "B18FA-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "STPS connector open",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS2 CONNETOR OPEN",
}

# B code - Body: B18FA-12
DRV_STPS2_STB = {
    "dtc_hex": "0x98FA12",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_STPS2_STB",
    "short_notation": "B18FA-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "STPS terminal SC to BATTERY",
    "heal_condition": "STPS terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS2 SHORT TO BATTERY",
}

# B code - Body: B18FA-11
DRV_STPS2_STG = {
    "dtc_hex": "0x98FA11",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_STPS2_STG",
    "short_notation": "B18FA-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "STPS terminal SC to Ground",
    "heal_condition": "STPS terminal removed from SC to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS2 SHORT TO GROUND",
}

# B code - Body: B18FA-64
DRV_STPS2_CONFIG = {
    "dtc_hex": "0x98FA64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DRV_STPS2_CONFIG",
    "short_notation": "B18FA-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Seat track position sensor (STPS)",
    "description": "DRIVER STPS2 CONFIGURATION ERROR",
}

# B code - Body: B18FB-64
PSG_STPS1_CONFIG = {
    "dtc_hex": "0x98FB64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_STPS1_CONFIG",
    "short_notation": "B18FB-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": "Passanger side STPS is not connected to the harness",
    "heal_condition": "Passanger side STPS properly connected to harness",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS1 CONFIGURATION ERROR",
}

# B code - Body: B18FB-01
PSG_STPS1_XCONN = {
    "dtc_hex": "0x98FB01",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_STPS1_XCONN",
    "short_notation": "B18FB-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "STPS Cross connected",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS1 CROSS CONNECTED",
}

# B code - Body: B18FB-13
PSG_STPS1_OPEN = {
    "dtc_hex": "0x98FB13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_STPS1_OPEN",
    "short_notation": "B18FB-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "STPS connector open",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS1 CONNETOR OPEN",
}

# B code - Body: B18FB-12
PSG_STPS1_STB = {
    "dtc_hex": "0x98FB12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_STPS1_STB",
    "short_notation": "B18FB-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "STPS terminal SC to BATTERY",
    "heal_condition": "STPS terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS1 SHORT TO BATTERY",
}

# B code - Body: B18FB-11
PSG_STPS1_STG = {
    "dtc_hex": "0x98FB11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_STPS1_STG",
    "short_notation": "B18FB-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "STPS terminal SC to Ground",
    "heal_condition": "STPS terminal removed from SC to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS1 SHORT TO GROUND",
}

# B code - Body: B18FC-01
PSG_STPS2_XCONN = {
    "dtc_hex": "0x98FC01",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_STPS2_XCONN",
    "short_notation": "B18FC-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "STPS Cross connected",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS2 CROSS CONNECTED",
}

# B code - Body: B18FC-13
PSG_STPS2_OPEN = {
    "dtc_hex": "0x98FC13",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_STPS2_OPEN",
    "short_notation": "B18FC-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "STPS connector open",
    "heal_condition": "STPS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "1900ms",
    "mature_time_ms": 1900,
    "demature_time": "1900ms",
    "demature_time_ms": 1900,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS2 CONNETOR OPEN",
}

# B code - Body: B18FC-12
PSG_STPS2_STB = {
    "dtc_hex": "0x98FC12",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_STPS2_STB",
    "short_notation": "B18FC-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "STPS terminal SC to BATTERY",
    "heal_condition": "STPS terminal removed from SC to BATTERY",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS2 SHORT TO BATTERY",
}

# B code - Body: B18FC-11
PSG_STPS2_STG = {
    "dtc_hex": "0x98FC11",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_STPS2_STG",
    "short_notation": "B18FC-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "STPS terminal SC to Ground",
    "heal_condition": "STPS terminal removed from SC to Ground",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS2 SHORT TO GROUND",
}

# B code - Body: B18FC-64
PSG_STPS2_CONFIG = {
    "dtc_hex": "0x98FC64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "PSG_STPS2_CONFIG",
    "short_notation": "B18FC-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Configuration error",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Seat track position sensor (STPS)",
    "description": "CO-DRIVER STPS2 CONFIGURATION ERROR",
}

# B code - Body: B1914-11
R2_LH_PT_STG = {
    "dtc_hex": "0x991411",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_STG",
    "short_notation": "B1914-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRE-TENSIONER SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1914-12
R2_LH_PT_STB = {
    "dtc_hex": "0x991412",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_STB",
    "short_notation": "B1914-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRE-TENSIONER SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1914-1A
R2_LH_PT_RES_LOW = {
    "dtc_hex": "0x99141A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_RES_LOW",
    "short_notation": "B1914-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRE-TENSIONER SQUIB LOW RES",
}

# B code - Body: B1914-1B
R2_LH_PT_RES_HIGH = {
    "dtc_hex": "0x99141B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_RES_HIGH",
    "short_notation": "B1914-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRE-TENSIONER SQUIB HIGH RES",
}

# B code - Body: B1914-01
R2_LH_PT_XCONN = {
    "dtc_hex": "0x991401",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_XCONN",
    "short_notation": "B1914-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRE-TENSIONER SQUIB CROSS CONNECT",
}

# B code - Body: B1914-64
R2_LH_PT_UNEXPECTED = {
    "dtc_hex": "0x991464",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_UNEXPECTED",
    "short_notation": "B1914-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRETENSIONER UNEXPECTED SQUIB",
}

# B code - Body: B1914-13
R2_LH_PT_OPEN = {
    "dtc_hex": "0x991413",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_LH_PT_OPEN",
    "short_notation": "B1914-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW LEFT PRETENSIONER OPEN",
}

# B code - Body: B190F-11
R2_RH_PT_STG = {
    "dtc_hex": "0x990F11",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_STG",
    "short_notation": "B190F-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRE-TENSIONER SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B190F-12
R2_RH_PT_STB = {
    "dtc_hex": "0x990F12",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_STB",
    "short_notation": "B190F-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRE-TENSIONER SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B190F-1A
R2_RH_PT_RES_LOW = {
    "dtc_hex": "0x990F1A",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_RES_LOW",
    "short_notation": "B190F-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRE-TENSIONER SQUIB LOW RES",
}

# B code - Body: B190F-1B
R2_RH_PT_RES_HIGH = {
    "dtc_hex": "0x990F1B",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_RES_HIGH",
    "short_notation": "B190F-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRE-TENSIONER SQUIB HIGH RES",
}

# B code - Body: B190F-01
R2_RH_PT_XCONN = {
    "dtc_hex": "0x990F01",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_XCONN",
    "short_notation": "B190F-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRE-TENSIONER SQUIB CROSS CONNECT",
}

# B code - Body: B190F-64
R2_RH_PT_UNEXPECTED = {
    "dtc_hex": "0x990F64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_UNEXPECTED",
    "short_notation": "B190F-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRETENSIONER UNEXPECTED SQUIB",
}

# B code - Body: B190F-13
R2_RH_PT_OPEN = {
    "dtc_hex": "0x990F13",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "R2_RH_PT_OPEN",
    "short_notation": "B190F-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "2nd ROW RIGHT PRETENSIONER OPEN",
}

# B code - Body: B1910-11
DRV_PRC_STG = {
    "dtc_hex": "0x991011",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_STG",
    "short_notation": "B1910-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1910-12
DRV_PRC_STB = {
    "dtc_hex": "0x991012",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_STB",
    "short_notation": "B1910-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1910-1A
DRV_PRC_RES_LOW = {
    "dtc_hex": "0x99101A",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_RES_LOW",
    "short_notation": "B1910-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION SQUIB LOW RES",
}

# B code - Body: B1910-1B
DRV_PRC_RES_HIGH = {
    "dtc_hex": "0x99101B",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_RES_HIGH",
    "short_notation": "B1910-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION SQUIB HIGH RES",
}

# B code - Body: B1910-01
DRV_PRC_XCONN = {
    "dtc_hex": "0x991001",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_XCONN",
    "short_notation": "B1910-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION SQUIB CROSS CONNECT",
}

# B code - Body: B1910-64
DRV_PRC_UNEXPECTED = {
    "dtc_hex": "0x991064",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_UNEXPECTED",
    "short_notation": "B1910-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION UNEXPECTED SQUIB",
}

# B code - Body: B1910-13
DRV_PRC_OPEN = {
    "dtc_hex": "0x991013",
    "applicable_to": ("ICE",),
    "mnemonic": "DRV_PRC_OPEN",
    "short_notation": "B1910-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": "4000ms",
    "demature_time_ms": 4000,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "DRIVER PELVIS RESTRAIN CUSHION OPEN",
}

# B code - Body: B1911-11
PSG_PRC_STG = {
    "dtc_hex": "0x991111",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_STG",
    "short_notation": "B1911-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "The DTC is stored if the control module detects that: squib short to ground is detected for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION SQUIB SHORT CIRCUIT TO GROUND",
}

# B code - Body: B1911-12
PSG_PRC_STB = {
    "dtc_hex": "0x991112",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_STB",
    "short_notation": "B1911-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "The DTC is stored if the control module detects that: squib short to battery for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION SQUIB SHORT CIRCUIT TO BATTERY",
}

# B code - Body: B1911-1A
PSG_PRC_RES_LOW = {
    "dtc_hex": "0x99111A",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_RES_LOW",
    "short_notation": "B1911-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too low for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION SQUIB LOW RES",
}

# B code - Body: B1911-1B
PSG_PRC_RES_HIGH = {
    "dtc_hex": "0x99111B",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_RES_HIGH",
    "short_notation": "B1911-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed high threshold for more than 2000ms",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION SQUIB HIGH RES",
}

# B code - Body: B1911-01
PSG_PRC_XCONN = {
    "dtc_hex": "0x991101",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_XCONN",
    "short_notation": "B1911-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "The DTC is stored if the control module detects that: Cross connection (short circuit) with other deployment loop",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION SQUIB CROSS CONNECT",
}

# B code - Body: B1911-64
PSG_PRC_UNEXPECTED = {
    "dtc_hex": "0x991164",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_UNEXPECTED",
    "short_notation": "B1911-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "Pretensioner sq is not configured but physically connected",
    "heal_condition": "Pretensioner sq is not configured and not connected",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION UNEXPECTED SQUIB",
}

# B code - Body: B1911-13
PSG_PRC_OPEN = {
    "dtc_hex": "0x991113",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_PRC_OPEN",
    "short_notation": "B1911-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000ms",
    "mature_time_ms": 2000,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "CO DRIVER PELVIS RESTRAIN CUSHION OPEN",
}

# B code - Body: B1912-64
PYRO_SW_UNEXPECTED = {
    "dtc_hex": "0x991264",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_UNEXPECTED",
    "short_notation": "B1912-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected squib",
    "set_condition": "The DTC is stored if the control module detects that: Deployment loop configured to be not present but resistance on the deployment loop is in the valid range indicating that restraint is connected for more than 2400ms.",
    "heal_condition": "DTC cannot Passed in the current Ignition cycle. It can be passed when the Unconfigured loops is High resistance, Low resistance and Open in the next cycle.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "within PDC(2000ms)",
    "mature_time_ms": None,
    "demature_time": "within PDC(2000ms)",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH UNEXPECTED SQUIB",
}

# B code - Body: B1912-11
PYRO_SW_STG = {
    "dtc_hex": "0x991211",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_STG",
    "short_notation": "B1912-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "PYROTECHNIC SWITCH Shorted to GND",
    "heal_condition": "PYROTECHNIC SWITCH removed from Shorted to GND",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000",
    "mature_time_ms": None,
    "demature_time": "1.5 Sec",
    "demature_time_ms": 1500,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH - SHORT TO GROUND",
}

# B code - Body: B1912-12
PYRO_SW_STB = {
    "dtc_hex": "0x991212",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_STB",
    "short_notation": "B1912-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "PYROTECHNIC SWITCH Shorted to STB",
    "heal_condition": "PYROTECHNIC SWITCH removed from Shorted to STB",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000",
    "mature_time_ms": None,
    "demature_time": "1.5 Sec",
    "demature_time_ms": 1500,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH - SHORT TO BATTERY",
}

# B code - Body: B1912-1A
PYRO_SW_RES_LOW = {
    "dtc_hex": "0x99121A",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_RES_LOW",
    "short_notation": "B1912-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": "PYROTECHNIC SWITCH resistance < 1 .66 ohms",
    "heal_condition": "PYROTECHNIC SWITCH resistance > 1 .66 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000",
    "mature_time_ms": None,
    "demature_time": "1.5 Sec",
    "demature_time_ms": 1500,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH - LOW RESISTANCE",
}

# B code - Body: B1912-1B
PYRO_SW_RES_HIGH = {
    "dtc_hex": "0x99121B",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_RES_HIGH",
    "short_notation": "B1912-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "PYROTECHNIC SWITCH > 5.54 ohms",
    "heal_condition": "PYROTECHNIC SWITCH resistance > 5.54 ohms",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000",
    "mature_time_ms": None,
    "demature_time": "1.5 Sec",
    "demature_time_ms": 1500,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH - HIGH RESISTANCE",
}

# B code - Body: B1912-01
PYRO_SW_XCONN = {
    "dtc_hex": "0x991201",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_XCONN",
    "short_notation": "B1912-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "Dr.Sq , Pas.Sq, DPT or PPT are cross connected",
    "heal_condition": "Dr.Sq , Pas.Sq, DPT or PPT are normal",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000",
    "mature_time_ms": None,
    "demature_time": "1.5 Sec",
    "demature_time_ms": 1500,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH - CROSS CONNECT",
}

# B code - Body: B1912-13
PYRO_SW_OPEN = {
    "dtc_hex": "0x991213",
    "applicable_to": ("ICE",),
    "mnemonic": "PYRO_SW_OPEN",
    "short_notation": "B1912-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "The DTC is stored if the control module detects that: Resistance in deployment loop too high exceed open threshold for more than 2000ms.",
    "heal_condition": "If the External Fault condition is removed, the DTC shall be passed.",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "2000",
    "mature_time_ms": None,
    "demature_time": "1.5 Sec",
    "demature_time_ms": 1500,
    "precondition": "1) IGN ON; 2) Volatge should be normal. 3)No Violent Crash(FLTMONR_CONDITION_PERMLOCK should not be active)",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Squib / deployment loop",
    "description": "PYROTECHNIC SWITCH OPEN",
}

# B code - Body: B1913-01
PSG_ODS_XCONN = {
    "dtc_hex": "0x991301",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_ODS_XCONN",
    "short_notation": "B1913-01",
    "dtc_type": "B (Body)",
    "ftb": "0x01",
    "fault_type": "Cross connection",
    "set_condition": "ODS Cross connected",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "CO-DRIVER ODS CROSS CONNECTED",
}

# B code - Body: B1913-1B
PSG_ODS_RES_HIGH = {
    "dtc_hex": "0x99131B",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_ODS_RES_HIGH",
    "short_notation": "B1913-1B",
    "dtc_type": "B (Body)",
    "ftb": "0x1B",
    "fault_type": "Resistance too high",
    "set_condition": "ODS Resistance >400 ohm",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "CO-DRIVER ODS HIGH RESISTANCE",
}

# B code - Body: B1913-1A
PSG_ODS_RES_LOW = {
    "dtc_hex": "0x99131A",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_ODS_RES_LOW",
    "short_notation": "B1913-1A",
    "dtc_type": "B (Body)",
    "ftb": "0x1A",
    "fault_type": "Resistance too low",
    "set_condition": None,
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "CO-DRIVER ODS LOW RESISTANCE",
}

# B code - Body: B1913-11
PSG_ODS_STG = {
    "dtc_hex": "0x991311",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_ODS_STG",
    "short_notation": "B1913-11",
    "dtc_type": "B (Body)",
    "ftb": "0x11",
    "fault_type": "Short circuit to ground",
    "set_condition": "ODS Short with ground",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "CO-DRIVER ODS SHORT TO GROUND",
}

# B code - Body: B1913-13
PSG_ODS_OPEN = {
    "dtc_hex": "0x991313",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_ODS_OPEN",
    "short_notation": "B1913-13",
    "dtc_type": "B (Body)",
    "ftb": "0x13",
    "fault_type": "Open circuit",
    "set_condition": "ODS connector open",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "CO-DRIVER ODS CONNECTOR OPEN",
}

# B code - Body: B1913-12
PSG_ODS_STB = {
    "dtc_hex": "0x991312",
    "applicable_to": ("ICE",),
    "mnemonic": "PSG_ODS_STB",
    "short_notation": "B1913-12",
    "dtc_type": "B (Body)",
    "ftb": "0x12",
    "fault_type": "Short circuit to battery",
    "set_condition": "ODS Short with Battery",
    "heal_condition": "ODS normal",
    "memory": "EEPROM",
    "time_tolerance_pct": 10,
    "mature_time": "3200ms",
    "mature_time_ms": 3200,
    "demature_time": "3200ms",
    "demature_time_ms": 3200,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": 40,
    "warning_lamp": "ON",
    "group": "Occupant detection sensor (ODS)",
    "description": "CO-DRIVER ODS SHORT TO BATTERY",
}

# B code - Body: B1915-00
ECU_LOCK_ROLLOVER = {
    "dtc_hex": "0x991500",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECU_LOCK_ROLLOVER",
    "short_notation": "B1915-00",
    "dtc_type": "B (Body)",
    "ftb": "0x00",
    "fault_type": "ECU locked after a crash",
    "set_condition": "The DTC is stored After the REAR Crash Detection",
    "heal_condition": "No criteria",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": "Immediate",
    "mature_time_ms": None,
    "demature_time": "NA",
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2) Voltage should be normal.",
    "ageing_cycles": None,
    "warning_lamp": "ON",
    "group": "Crash lock",
    "description": "ECU LOCKED DUE TO ROLL OVER",
}

# U code - Network: U1173-00
ECALL_NODE_ABSENT = {
    "dtc_hex": "0xD17300",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "ECALL_NODE_ABSENT",
    "short_notation": "U1173-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "CAN communication",
    "description": "E-CALL Node absent",
}

# U code - Network: U1170-00
OCS_NODE_ABSENT = {
    "dtc_hex": "0xD17000",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "OCS_NODE_ABSENT",
    "short_notation": "U1170-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Node absent",
    "set_condition": "OCS1_500 is absent",
    "heal_condition": "OCS1_500 is present",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)OCS should be present in variant coding and \"SRS Variant Code Error\" should not be active.. 3)Voltage should be normal. 4)No BUS off condition; 5) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "CAN communication",
    "description": "OCS Node absent",
}

# U code - Network: U2761-00
OCS1_500_MCF = {
    "dtc_hex": "0xE76100",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "OCS1_500_MCF",
    "short_notation": "U2761-00",
    "dtc_type": "U (Network)",
    "ftb": "0x00",
    "fault_type": "Message content failure",
    "set_condition": "Incorrect DLC or Incorrect CRC or Incorrect Alive counter is received for the message OCS1_500 for \"Message Content Error Detection Threshold\" times",
    "heal_condition": "OCS1_500 Message is received with correct DLC, correct CRC, correct Alive counter for \"Message Content Error Recovery Threshold\" times",
    "memory": "EEPROM",
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": "1) IGN ON; 2)OCS Node should be present in variant coding and variant Error should not be present. 3)OCS Node Absent fault should not be active; 4)OCS Message Timeout fault should not be active; 5)Voltage should be normal. 6)No BUS off; 7) NM IGN On Startup Delay time should be completed.",
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "CAN communication",
    "description": "OCS1_500 - (0x5FF) Message Content Failure",
}

# B code - Body: B1919-64
LOOP_UNEXPECTED_LOAD = {
    "dtc_hex": "0x991964",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "LOOP_UNEXPECTED_LOAD",
    "short_notation": "B1919-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected load",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Unexpected load",
    "description": "Unexpected load connected to LOOP",
}

# B code - Body: B191A-64
DCS_UNEXPECTED_LOAD = {
    "dtc_hex": "0x991A64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "DCS_UNEXPECTED_LOAD",
    "short_notation": "B191A-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected load",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Unexpected load",
    "description": "Unexpected load connected to DCS",
}

# B code - Body: B191B-64
RSU_UNEXPECTED_LOAD = {
    "dtc_hex": "0x991B64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "RSU_UNEXPECTED_LOAD",
    "short_notation": "B191B-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected load",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Unexpected load",
    "description": "Unexpected load connected to RSU",
}

# B code - Body: B191C-64
GPO_UNEXPECTED_LOAD = {
    "dtc_hex": "0x991C64",
    "applicable_to": ("EV", "ICE"),
    "mnemonic": "GPO_UNEXPECTED_LOAD",
    "short_notation": "B191C-64",
    "dtc_type": "B (Body)",
    "ftb": "0x64",
    "fault_type": "Unexpected load",
    "set_condition": None,
    "heal_condition": None,
    "memory": None,
    "time_tolerance_pct": None,
    "mature_time": None,
    "mature_time_ms": None,
    "demature_time": None,
    "demature_time_ms": None,
    "precondition": None,
    "ageing_cycles": None,
    "warning_lamp": None,
    "group": "Unexpected load",
    "description": "Unexpected load connected to GPO",
}

COMMON_FAULT_LIST = (
    ECU_INTERNAL,
    DAB_AV_STG,
    DAB_STG,
    PAB_AV_STG,
    PAB_STG,
    RH_BFL_STG,
    RH_PT_STG,
    LH_BFL_STG,
    LH_PT_STG,
    DAB_AV_STB,
    DAB_AV_OPEN,
    DAB_STB,
    PAB_AV_STB,
    PAB_STB,
    RH_BFL_STB,
    RH_PT_STB,
    LH_BFL_STB,
    LH_PT_STB,
    DAB_AV_RES_LOW,
    DAB_RES_LOW,
    PAB_AV_RES_LOW,
    PAB_RES_LOW,
    RH_BFL_RES_LOW,
    RH_PT_RES_LOW,
    LH_BFL_RES_LOW,
    LH_PT_RES_LOW,
    DAB_AV_RES_HIGH,
    DAB_RES_HIGH,
    PAB_AV_RES_HIGH,
    PAB_RES_HIGH,
    RH_BFL_RES_HIGH,
    RH_PT_RES_HIGH,
    LH_BFL_RES_HIGH,
    LH_PT_RES_HIGH,
    DAB_AV_XCONN,
    DAB_XCONN,
    PAB_AV_XCONN,
    PAB_XCONN,
    RH_BFL_XCONN,
    RH_PT_XCONN,
    LH_BFL_XCONN,
    LH_PT_XCONN,
    VBAT_UV,
    VBAT_OV,
    ECU_LOCK_FRONT,
    LH_FRSU_OPEN,
    RH_FRSU_OPEN,
    LH_FRSU_COMM,
    RH_FRSU_COMM,
    LH_FRSU_STG,
    RH_FRSU_STG,
    LH_FRSU_INTERNAL,
    RH_FRSU_INTERNAL,
    LH_FRSU_CONFIG,
    RH_FRSU_CONFIG,
    LH_FRSU_SAMPLE_RATE,
    RH_FRSU_SAMPLE_RATE,
    AWL_FAIL,
    LH_FRSU_UNCONF_CRASH,
    RH_FRSU_UNCONF_CRASH,
    LH_SRSU_UNCONF_CRASH,
    RH_SRSU_UNCONF_CRASH,
    ECU_PLANT_MODE,
    ECU_LOCK_PT_DEPLOY,
    ECU_LOCK_RH_SIDE,
    ECU_LOCK_LH_SIDE,
    ECU_CONFIG,
    RH_LAP_PT_STG,
    RH_LAP_PT_STB,
    RH_LAP_PT_RES_LOW,
    RH_LAP_PT_RES_HIGH,
    RH_LAP_PT_XCONN,
    LH_LAP_PT_STG,
    LH_LAP_PT_STB,
    LH_LAP_PT_RES_LOW,
    LH_LAP_PT_RES_HIGH,
    LH_LAP_PT_XCONN,
    PAB_DIS_SW_STG,
    PAB_DIS_SW_STB,
    PAB_DIS_SW_OPEN,
    PAB_DIS_SW_RES_LOW,
    PAB_DIS_SW_RES_HIGH,
    PAB_DIS_SW_RES_OOR,
    RH_SAB_STG,
    RH_SAB_STB,
    RH_SAB_RES_LOW,
    RH_SAB_RES_HIGH,
    RH_SAB_XCONN,
    RH_IC_STG,
    RH_IC_STB,
    RH_IC_RES_LOW,
    RH_IC_RES_HIGH,
    RH_IC_XCONN,
    LH_SAB_STG,
    LH_SAB_STB,
    LH_SAB_RES_LOW,
    LH_SAB_RES_HIGH,
    LH_SAB_XCONN,
    LH_IC_STG,
    LH_IC_STB,
    LH_IC_RES_LOW,
    LH_IC_RES_HIGH,
    LH_IC_XCONN,
    LH_BPLR_SRSU_OPEN,
    RH_BPLR_SRSU_OPEN,
    LH_BPLR_SRSU_COMM,
    RH_BPLR_SRSU_COMM,
    LH_BPLR_SRSU_STG,
    RH_BPLR_SRSU_STG,
    LH_BPLR_SRSU_INTERNAL,
    RH_BPLR_SRSU_INTERNAL,
    LH_BPLR_SRSU_CONFIG,
    RH_BPLR_SRSU_CONFIG,
    LH_BPLR_SRSU_SAMPLE_RATE,
    RH_BPLR_SRSU_SAMPLE_RATE,
    PSG_SBR_LMP_STB,
    PSG_SBR_LMP_STG,
    PSG_SBR_LMP_OPEN,
    PAB_OFF_LMP_STB,
    PAB_OFF_LMP_STG,
    PAB_OFF_LMP_OPEN,
    DAB_AV_UNEXPECTED,
    DAB_UNEXPECTED,
    PAB_UNEXPECTED,
    PAB_AV_UNEXPECTED,
    RH_BFL_UNEXPECTED,
    RH_PT_UNEXPECTED,
    LH_BFL_UNEXPECTED,
    LH_PT_UNEXPECTED,
    RH_LAP_PT_UNEXPECTED,
    LH_LAP_PT_UNEXPECTED,
    RH_SAB_UNEXPECTED,
    LH_SAB_UNEXPECTED,
    RH_IC_UNEXPECTED,
    LH_IC_UNEXPECTED,
    PSG_BKL_STB,
    DRV_BKL_STB,
    PAB_DIS_SW_CONFIG,
    PAB_OFF_LMP_CONFIG,
    PSG_SBR_LMP_CONFIG,
    RH_FRSU_XCONN,
    LH_FRSU_XCONN,
    RH_BPLR_SRSU_XCONN,
    LH_BPLR_SRSU_XCONN,
    RH_FRSU_RAILED,
    LH_FRSU_RAILED,
    RH_BPLR_SRSU_RAILED,
    LH_BPLR_SRSU_RAILED,
    RH_FRSU_STB,
    LH_FRSU_STB,
    RH_BPLR_SRSU_STB,
    LH_BPLR_SRSU_STB,
    ACN_OUT_STB,
    ACN_OUT_STG_OPEN,
    LOOP_SVD_DEPLOY,
    RH_PRES_SNS_OPEN,
    LH_PRES_SNS_OPEN,
    RH_PRES_SNS_XCONN,
    LH_PRES_SNS_XCONN,
    RH_PRES_SNS_RAILED,
    LH_PRES_SNS_RAILED,
    RH_PRES_SNS_INTERNAL,
    LH_PRES_SNS_INTERNAL,
    RH_PRES_SNS_CONFIG,
    LH_PRES_SNS_CONFIG,
    RH_PRES_SNS_COMM,
    LH_PRES_SNS_COMM,
    RH_PRES_SNS_STB,
    LH_PRES_SNS_STB,
    RH_PRES_SNS_STG,
    LH_PRES_SNS_STG,
    LOOP_SCRAP_EN,
    EDR_RECORD_FULL,
    DRV_KAB_UNEXPECTED,
    DRV_KAB_STG,
    DRV_KAB_STB,
    DRV_KAB_RES_LOW,
    DRV_KAB_RES_HIGH,
    DRV_KAB_XCONN,
    DAB_AV_OPEN_B18F1,
    DAB_OPEN,
    PAB_OPEN,
    RH_BFL_OPEN,
    RH_PT_OPEN,
    LH_BFL_OPEN,
    LH_PT_OPEN,
    RH_LAP_PT_OPEN,
    LH_LAP_PT_OPEN,
    RH_SAB_OPEN,
    LH_SAB_OPEN,
    RH_IC_OPEN,
    LH_IC_OPEN,
    DRV_KAB_OPEN,
    CRASH_OUT_STG,
    CRASH_OUT_STB,
    CRASH_OUT_OPEN,
    CRASH_OUT_CONFIG,
    ECALL_OUT_STG,
    ECALL_OUT_STB,
    ECALL_OUT_OPEN,
    ECALL_OUT_CONFIG,
    LH_CPLR_SRSU_INTERNAL,
    LH_CPLR_SRSU_CONFIG,
    LH_CPLR_SRSU_STB,
    RH_CPLR_SRSU_OPEN,
    LH_CPLR_SRSU_OPEN,
    RH_CPLR_SRSU_COMM,
    LH_CPLR_SRSU_COMM,
    RH_CPLR_SRSU_STG,
    LH_CPLR_SRSU_STG,
    RH_CPLR_SRSU_INTERNAL,
    RH_CPLR_SRSU_CONFIG,
    RH_CPLR_SRSU_STB,
    ECU_LOCK_REAR,
    PAB_ON_LED_STG,
    PAB_ON_LED_STB,
    PAB_ON_LED_OPEN,
    PAB_ON_LED_CONFIG,
    IMU_CRC_ERR_CNT,
    IMU_SPI_ERR_CNT,
    IMU_SELF_TEST,
    IMU_INTERNAL,
    IMU_INTERNAL_RECOV,
    IMU_CAL_INTEGRITY,
    IMU_SEV_X,
    IMU_SEV_Y,
    IMU_SEV_Z,
    IMU_SEV_YAW,
    IMU_SEV_ROLL,
    IMU_SEV_PITCH,
    IMU_SEV_TEMP,
    IMU_OOR_X,
    IMU_OOR_Y,
    IMU_OOR_Z,
    IMU_OOR_YAW,
    IMU_OOR_ROLL,
    IMU_OOR_PITCH,
    IMU_OOR_TEMP,
    CTR_FSAB_STG,
    CTR_FSAB_STB,
    CTR_FSAB_RES_LOW,
    CTR_FSAB_RES_HIGH,
    CTR_FSAB_XCONN,
    CTR_FSAB_UNEXPECTED,
    CTR_FSAB_OPEN,
    LH_APLR_SRSU_OPEN,
    LH_APLR_SRSU_COMM,
    LH_APLR_SRSU_STG,
    LH_APLR_SRSU_STB,
    LH_APLR_SRSU_INTERNAL,
    LH_APLR_SRSU_CONFIG,
    RH_APLR_SRSU_OPEN,
    RH_APLR_SRSU_COMM,
    RH_APLR_SRSU_STG,
    RH_APLR_SRSU_STB,
    RH_APLR_SRSU_INTERNAL,
    RH_APLR_SRSU_CONFIG,
    REAR_RSU_OPEN,
    REAR_RSU_COMM,
    REAR_RSU_STG,
    REAR_RSU_STB,
    REAR_RSU_INTERNAL,
    REAR_RSU_CONFIG,
    REAR_RSU_XCONN,
    RH_APLR_SRSU_XCONN,
    LH_APLR_SRSU_XCONN,
    PAB_EN_SW_STG,
    PAB_EN_SW_STB,
    PAB_EN_SW_OPEN,
    PAB_EN_SW_RES_LOW,
    PAB_EN_SW_RES_HIGH,
    PAB_EN_SW_RES_OOR,
    VCU_MTO,
    IEB_NODE_ABSENT,
    FR_ZONE_NODE_ABSENT,
    EPS_NODE_ABSENT,
    VCU_NODE_ABSENT,
    HPCC_NODE_ABSENT,
    SRS_BUS_OFF,
    SRS_VIN_MISMATCH,
    SRS_VARIANT_CODE_ERR,
    FR_ZONE3_100_MCF,
    VCU11_FD_10_MCF,
    HPCC_MTO,
    HPCC_1_100_MCF,
    IEB1_FD_10_MCF,
    EPS1_FD_10_MCF,
    VCU1_FD_20_MCF,
    VCU2_FD_100_MCF,
    SRS_FEATURE_CODE_ERR,
    VEHICLE_SPEED_SCF,
    MOTOR_SPEED_SCF,
    R2_LH_ODS_XCONN,
    R2_LH_ODS_RES_HIGH,
    R2_LH_ODS_RES_LOW,
    R2_LH_ODS_STG,
    R2_LH_ODS_OPEN,
    R2_LH_ODS_STB,
    R2_LH_BKL_STB,
    R2_RH_ODS_XCONN,
    R2_RH_ODS_RES_HIGH,
    R2_RH_ODS_RES_LOW,
    R2_RH_ODS_STG,
    R2_RH_ODS_OPEN,
    R2_RH_ODS_STB,
    R2_RH_BKL_STB,
    R2_MID_ODS_XCONN,
    R2_MID_ODS_RES_HIGH,
    R2_MID_ODS_RES_LOW,
    R2_MID_ODS_STG,
    R2_MID_ODS_OPEN,
    R2_MID_ODS_STB,
    R2_MID_BKL_STB,
    R3_LH_ODS_XCONN,
    R3_LH_ODS_RES_HIGH,
    R3_LH_ODS_RES_LOW,
    R3_LH_ODS_STG,
    R3_LH_ODS_OPEN,
    R3_LH_ODS_STB,
    R3_LH_BKL_STB,
    R3_RH_ODS_XCONN,
    R3_RH_ODS_RES_HIGH,
    R3_RH_ODS_RES_LOW,
    R3_RH_ODS_STG,
    R3_RH_ODS_OPEN,
    R3_RH_ODS_STB,
    R3_RH_BKL_STB,
    CAL_MISSING,
    CAL_INCORRECT,
    UB_SNS_OPEN,
    UB_SNS_COMM,
    UB_SNS_STG,
    UB_SNS_STB,
    UB_SNS_INTERNAL,
    UB_SNS_CONFIG,
    HPCAD_NODE_ABSENT,
    HPCAD_1_10_MCF,
    HPCAD_2_50_MCF,
    HPCAD_3_50_MCF,
    HPCAD_4_10_MCF,
    ADAS_DES_STRWHL_ANGLE_CMD_SCF,
    FL_TYRE_PRESSURE_SCF,
    FR_TYRE_PRESSURE_SCF,
    RL_TYRE_PRESSURE_SCF,
    RR_TYRE_PRESSURE_SCF,
    GEAR_ACTUAL_SCF,
    MASTER_CYL_PRESSURE_SCF,
    ODOMTR_READING_IS_SCF,
    STEERING_ABSOLUTE_ANGLE_SCF,
    VEHICLE_STATE_SCF,
    ECU_LOCK_UNDERSTRIKE,
    HSCAN_BUS_OFF,
    FR_ZONE_MTO,
    HPCAD_MTO,
    FR_ZONE2_100_MCF,
    DRV_BKL_XCONN,
    PSG_BKL_XCONN,
    R2_RH_BKL_XCONN,
    R2_MID_BKL_XCONN,
    R2_LH_BKL_XCONN,
    R3_RH_BKL_XCONN,
    R3_LH_BKL_XCONN,
    DRV_STPS1_CONFIG,
    DRV_STPS1_XCONN,
    DRV_STPS1_OPEN,
    DRV_STPS1_STB,
    DRV_STPS1_STG,
    DRV_STPS2_XCONN,
    DRV_STPS2_OPEN,
    DRV_STPS2_STB,
    DRV_STPS2_STG,
    DRV_STPS2_CONFIG,
    PSG_STPS1_CONFIG,
    PSG_STPS1_XCONN,
    PSG_STPS1_OPEN,
    PSG_STPS1_STB,
    PSG_STPS1_STG,
    PSG_STPS2_XCONN,
    PSG_STPS2_OPEN,
    PSG_STPS2_STB,
    PSG_STPS2_STG,
    PSG_STPS2_CONFIG,
    R2_LH_PT_STG,
    R2_LH_PT_STB,
    R2_LH_PT_RES_LOW,
    R2_LH_PT_RES_HIGH,
    R2_LH_PT_XCONN,
    R2_LH_PT_UNEXPECTED,
    R2_LH_PT_OPEN,
    R2_RH_PT_STG,
    R2_RH_PT_STB,
    R2_RH_PT_RES_LOW,
    R2_RH_PT_RES_HIGH,
    R2_RH_PT_XCONN,
    R2_RH_PT_UNEXPECTED,
    R2_RH_PT_OPEN,
    DRV_PRC_STG,
    DRV_PRC_STB,
    DRV_PRC_RES_LOW,
    DRV_PRC_RES_HIGH,
    DRV_PRC_XCONN,
    DRV_PRC_UNEXPECTED,
    DRV_PRC_OPEN,
    PSG_PRC_STG,
    PSG_PRC_STB,
    PSG_PRC_RES_LOW,
    PSG_PRC_RES_HIGH,
    PSG_PRC_XCONN,
    PSG_PRC_UNEXPECTED,
    PSG_PRC_OPEN,
    PYRO_SW_UNEXPECTED,
    PYRO_SW_STG,
    PYRO_SW_STB,
    PYRO_SW_RES_LOW,
    PYRO_SW_RES_HIGH,
    PYRO_SW_XCONN,
    PYRO_SW_OPEN,
    PSG_ODS_XCONN,
    PSG_ODS_RES_HIGH,
    PSG_ODS_RES_LOW,
    PSG_ODS_STG,
    PSG_ODS_OPEN,
    PSG_ODS_STB,
    ECU_LOCK_ROLLOVER,
    ECALL_NODE_ABSENT,
    OCS_NODE_ABSENT,
    OCS1_500_MCF,
    LOOP_UNEXPECTED_LOAD,
    DCS_UNEXPECTED_LOAD,
    RSU_UNEXPECTED_LOAD,
    GPO_UNEXPECTED_LOAD,
)

FAULT_BY_DTC_HEX = {fault["dtc_hex"]: fault for fault in COMMON_FAULT_LIST}


def faults_for(vehicle):
    """Faults that apply to vehicle 'EV' or 'ICE' (its own list plus the common ones)."""
    vehicle = vehicle.upper()
    if vehicle not in ("EV", "ICE"):
        raise ValueError(f"vehicle must be 'EV' or 'ICE', not {vehicle!r}")
    return [fault for fault in COMMON_FAULT_LIST if vehicle in fault["applicable_to"]]
