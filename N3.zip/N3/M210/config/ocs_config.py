"""
Module Configuration: OCS
Project: M210
============================================================

Location: projects/M210/config/ocs_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "OCS"

# ── OCS Settings ──

CLASSIFICATION_MAP = {
    0x00: "Empty",
    0x01: "Child Seat (RF)",
    0x02: "Child Seat (FF)",
    0x03: "Adult Small",
    0x04: "Adult Average",
    0x05: "Adult Large",
}

