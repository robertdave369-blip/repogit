"""
Module Configuration: DCS
Project: M210
============================================================

Location: projects/M210/config/dcs_config.py

"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.
# 2026-10-27 (user: ODS, STPS and DCS each in its own config): the STPS channels moved
# to stps_config.py, and the belt settings of canc_config.py moved here, values unchanged.

PROJECT_NAME = "M210"
MODULE_NAME = "DCS"



# ── DCS Settings ──


# List of seat logical names
# Seat Belt Buckles (SLS)
SLSName = [
    "DCS_Second_Row_Right",
    "DCS_DRVR",
    "DCS_PSGR",
    "DCS_Second_Row_Left",
    "DCS_Second_Row_Middle",
    "DCS_Third_Row_Right",
    "DCS_Third_Row_Left"
]

SLSNumber = {
    "DCS_Second_Row_Right": 0,
    "DCS_DRVR": 1,
    "DCS_PSGR": 2,
    "DCS_Second_Row_Left": 3,
    "DCS_Second_Row_Middle": 4,
    "DCS_Third_Row_Right": 12,
    "DCS_Third_Row_Left": 13
}


# Mapping: logical name -> software channel name
DCSName = {
    "DCS_DRVR": "SW_Channel_DCS_1",
    "DCS_PSGR": "SW_Channel_DCS_2",
    "DCS_Second_Row_Right": "SW_Channel_DCS_0",
    "DCS_Second_Row_Left": "SW_Channel_DCS_3",
    "DCS_Second_Row_Middle": "SW_Channel_DCS_4",
    "DCS_Third_Row_Right": "SW_Channel_DCS_12",
    "DCS_Third_Row_Left": "SW_Channel_DCS_13"
}

# Mapping: logical name -> CAN signal name (for front seats)
DCSSignal = {
    "DCS_DRVR": "STS_SEAT_BLT_DRV",
    "DCS_PSGR": "STS_SEAT_BLT_PSGR"
}

# Mapping: logical name -> DTC code for DCS fault
DTC_DCS_fault = {
    "PAB_Switch": "0x92 0x05",
    "DCS_DRVR": "0x90 0x33",
    "DCS_PSGR": "0x90 0x32",
    "DCS_Second_Row_Right": "0x92 0x43",
    "DCS_Second_Row_Middle": "0x92 0x44",
    "DCS_Second_Row_Left": "0x92 0x42",
    "DCS_Third_Row_Left": "0x92 0x45",
    "DCS_Third_Row_Right": "0x92 0x46",
    "ENS": "0x92 0x18"
}

# Mapping: logical name -> DTC code for DCS cross-connect fault
DTC_DCS_CC_fault = {
    "DCS_DRVR": "0x92 0x53",
    "DCS_PSGR": "0x92 0x54"
}

# Mapping: fault type -> code
DCS_FaultTypeCode = {
    "HiRes": "0x1B",
    "Open": "0x13",
    "LowRes": "0x1A",
    "S2B": "0x12",
    "S2G": "0x11",
    "Invalid_Res": "0x1E",
    "CrossConnect": "0x2B",
    "UNEX": "0x64"
}

# Mapping: fault type -> description
DCS_Fault_Description = {
    "S2B": "BUSS_HI_ON",
    "CrossConnect": "BUSS_HI_ON",
    "buckle": "800R",
    "unbuckle": "200R",
    "PAB_unbuckle": "100R",
    "PAB_buckle": "400R",
    # The open-circuit preset of the ARIA DCS / STPS card (.github/agents/aria_agent.md 5.1),
    # used by the Fault_List open-circuit scripts (2026-10-22).
    "Open": "OPEN",
}

# Fault timing configuration
DCS_fault_time = {
    "Qualification": 3200,
    "Qualification_CC": 1900,
    "Qualification_Tolerance": 10,
    "Dequalification": 3200,
    "Dequalification_CC": 1900,
    "Dequalification_Tolerance": 10,
    "dcs_faultcounter_offset": 10
}
# Bit mapping for rear/third row seats in PSGR_REAR_SEAT_BELT
REAR_SEAT_BIT_INDEX = {
    "DCS_Second_Row_Left": 0,
    "DCS_Second_Row_Middle": 1,
    "DCS_Second_Row_Right": 2,
    "DCS_Third_Row_Left": 3,
    "DCS_Third_Row_Middle": 4,
    "DCS_Third_Row_Right": 5,
}

# ── Belt settings (from canc_config.py, 2026-10-27) ──
# Seat-belt status reads Reserved (0x3) only in this window after IGN ON (the
# cases allow 500 ms; the bench note gives less than 300 ms).
CANC_SEAT_BELT_INIT_WINDOW_MS = 500
# Settle time of a DCS / ODS / STPS load change before its CAN status is read (the
# ODS and STPS channels are on the DCS card too).
CANC_DCS_STATE_SETTLE_MS = 1000
# Occupant sensing loads: project_reuirements/project_feature-context/dcs_ocs_stps_prompt.md.
# A belt or ODS is made faulty with the bus load (DCS_Fault_Description 'S2B') plus
# Leakage VBAT Bus High.
# DCSName channel behind each CAN belt status signal.
CANC_BELT_CHANNEL = {
    'STS_SEAT_BLT_DRV': 'DCS_DRVR', 'STS_SEAT_BLT_PSGR': 'DCS_PSGR',
    'STS_SEC_ROW_LEFT_BLT': 'DCS_Second_Row_Left', 'STS_SEC_ROW_MIDDLE_BLT': 'DCS_Second_Row_Middle',
    'STS_SEC_ROW_RIGHT_BLT': 'DCS_Second_Row_Right', 'STS_TRD_ROW_LEFT_BLT': 'DCS_Third_Row_Left',
    'STS_TRD_ROW_RIGHT_BLT': 'DCS_Third_Row_Right',
}
# The seat ODS (ods_config CANC_ODS_CHANNEL) that must read Present before a rear belt
# status is valid.
CANC_BELT_ODS = {
    'STS_SEC_ROW_LEFT_BLT': 'STS_SEAT_ODS_SEC_ROW_LEFT', 'STS_SEC_ROW_MIDDLE_BLT': 'STS_SEAT_ODS_SEC_ROW_MIDDLE',
    'STS_SEC_ROW_RIGHT_BLT': 'STS_SEAT_ODS_SEC_ROW_RIGHT', 'STS_TRD_ROW_LEFT_BLT': 'STS_SEAT_ODS_TRD_ROW_LEFT',
    'STS_TRD_ROW_RIGHT_BLT': 'STS_SEAT_ODS_TRD_ROW_RIGHT',
}
# Belt a cross-connect fault is wired to (the cases name only the front pair).
CANC_BELT_CROSS_CONNECT_PARTNER = {
    'STS_SEAT_BLT_DRV': 'STS_SEAT_BLT_PSGR', 'STS_SEAT_BLT_PSGR': 'STS_SEAT_BLT_DRV',
    'STS_SEC_ROW_LEFT_BLT': 'STS_SEC_ROW_RIGHT_BLT', 'STS_SEC_ROW_RIGHT_BLT': 'STS_SEC_ROW_LEFT_BLT',
    'STS_SEC_ROW_MIDDLE_BLT': 'STS_SEC_ROW_LEFT_BLT', 'STS_TRD_ROW_LEFT_BLT': 'STS_TRD_ROW_RIGHT_BLT',
    'STS_TRD_ROW_RIGHT_BLT': 'STS_TRD_ROW_LEFT_BLT',
}
# Load-card preset a faulty belt or ODS channel is set to, together with Leakage
# VBAT Bus High on the power card (bench note and the DCS seat-system check). Two
# belt channels both on this preset, without the leakage, are cross-connected.
CANC_DCS_FAULT_LOAD = 'BUS'
