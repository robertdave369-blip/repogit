"""Crash curves of M210.

The shared crash_configuration table (PROJECT_CRASH_CURVE_CONFIGS) has no M210 entry, and the
crash-curve resolver of core_functions reads CRASH_CURVE_CONFIG from this module before it
falls back to that table. M314 value: M210 uses the EV curve set (crash_data/m310_m314_m110)
until its own curves are supplied.
"""
from Framework_IOEM_Py.shared_libraries.crash_configuration import M310_M314_M110_CRASH_CURVE_CONFIG

PROJECT_NAME = "M210"
CRASH_CURVE_CONFIG = M310_M314_M110_CRASH_CURVE_CONFIG
