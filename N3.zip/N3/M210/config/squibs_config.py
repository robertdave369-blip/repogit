"""
Module Configuration: SQUIBS
Project: M210
============================================================

Location: projects/M210/config/squibs_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "SQUIBS"

SquibName = [
    "RPT",           # LOP_DRIVER_PRE_TENSIONER_SQUIB
    "LPT",           # LOP_PASSENGER_PRE_TENSIONER_SQUIB
    "RSA",           # LOP_DRIVER_SIDE_AIRBAG
    "LSA",           # LOP_PASSENGER_SIDE_AB_SQUIB
    "RCA",           # LOP_RIGHT_CURTAIN_AB_SQUIB
    "LCA",           # LOP_LEFT_CURTAIN_AB_SQUIB
    "LLPT",          # LOP_PASSENGER_LAP_PRETENSIONER_SQUIB
    "RLPT",          # LOP_DRIVER_LAP_PRETENSIONER_SQUIB
    "DKA",           # LOP_DRIVER_KNEE_AIRBAG_SQUIB
    "DAB",           # LOP_DRIVER_AIRBAG_SQUIB
    "PAB",           # LOP_PASSENGER_AB_SQUIB
    "CAB",           # LOP_SEATBAG_CENTRE_FAR_SIDE_SEAT_SQUIB
    "R2LPT",         # LOP_2ND_ROW_LEFT_PRETENSIONER_SQUIB
    "R2RPT",         # LOP_2ND_ROW_RIGHT_PRETENSIONER_SQUIB
    "DBFL",          # LOP_BELT_FORCE_LIMITER_DRIVER_SQUIB
    "PBFL",          # LOP_BELT_FORCE_LIMITER_PASSENGER_SQUIB
]

# Variant control: active loops for current M314 mapping.
# Keep the legacy key names below for compatibility with existing scripts, but
# use the explicit loop mapping from the bench/project definition.
ACTIVE_SQUIB_LOOPS = {0, 1, 2, 3, 4, 5, 9, 10, 11, 12, 13, 14, 15, 16, 19, 23}

# Simulator Loop number to which the ECU O/P is connected in ARiA/NeeVA.
# Historical short names are preserved, but the comments below are the
# authoritative M314 loop meanings.
SquibNumber = {
    "RPT": 0,            # LOP_DRIVER_PRE_TENSIONER_SQUIB
    "LPT": 1,            # LOP_PASSENGER_PRE_TENSIONER_SQUIB
    "RSA": 2,            # LOP_DRIVER_SIDE_AIRBAG
    "LSA": 3,            # LOP_PASSENGER_SIDE_AB_SQUIB
    "RCA": 4,            # LOP_RIGHT_CURTAIN_AB_SQUIB
    "LCA": 5,            # LOP_LEFT_CURTAIN_AB_SQUIB
    "LLPT": 9,           # LOP_PASSENGER_LAP_PRETENSIONER_SQUIB
    "RLPT": 10,          # LOP_DRIVER_LAP_PRETENSIONER_SQUIB
    "DKA": 11,           # LOP_DRIVER_KNEE_AIRBAG_SQUIB
    "DAB": 12,           # LOP_DRIVER_AIRBAG_SQUIB
    "PAB": 13,           # LOP_PASSENGER_AB_SQUIB
    "CAB": 14,           # LOP_SEATBAG_CENTRE_FAR_SIDE_SEAT_SQUIB
    "R2LPT": 15,         # LOP_2ND_ROW_LEFT_PRETENSIONER_SQUIB
    "R2RPT": 16,         # LOP_2ND_ROW_RIGHT_PRETENSIONER_SQUIB
    "DBFL": 19,          # LOP_BELT_FORCE_LIMITER_DRIVER_SQUIB
    "PBFL": 23,          # LOP_BELT_FORCE_LIMITER_PASSENGER_SQUIB
}

# Derived active squib names for current variant (use in tests)
ActiveSquibName = [name for name, loop in SquibNumber.items() if loop in ACTIVE_SQUIB_LOOPS]

# SquibName to Byte Index mapping
Squib_DID_0446_ByteIndex = {
    "RPT": 0,    # Driver Pretensioner
    "DAB": 1,    # Driver Airbag
    "LPT": 2,    # Passenger Pretensioner
    "PAB": 3,    # Passenger Airbag
    "RLPT": 4,   # Driver Lap Pretensioner
    "LLPT": 5,   # Passenger Lap Pretensioner
    "RSA": 6,    # Driver Side Airbag
    "LSA": 7,    # Passenger Side Airbag
    "RCA": 8,    # Right Curtain Airbag
    "LCA": 9,    # Left Curtain Airbag
    "DKA": 10,   # Driver Knee Airbag
    # "Battery_CutOFF": 11,  # Battery Cutoff switch
    # Additional active M314 loops below are mapped at the ARIA/loadbox level,
    # but their DID 0x0446 byte positions are not verified in the current source.
    "R2RPT": None,
    "CAB": None,
    "R2LPT": None,
    "DBFL": None,
    "PBFL": None,
}

# Fault type codes
Squib_FaultTypeCode = {
    "HiRes": "0x1B",
    "Open": "0x13",
    "LoRes": "0x1A",
    "S2B": "0x12",
    "S2G": "0x11",
    "CrossConnect": "0x01",
    "UNEX": "0x64"
}

# DTC Squib Fault Codes
DTC_Squib_FaultCode = {
    "RPT": "0x80 0x70",   # Driver Pretensioner
    "LPT": "0x80 0x72",   # Passenger Pretensioner
    "RSA": "0x92 0x06",   # Driver Side Airbag
    "LSA": "0x92 0x08",   # Passenger Side Airbag
    "RCA": "0x92 0x07",   # Right Curtain Airbag
    "LCA": "0x92 0x09",   # Left Curtain Airbag
    "DAB": "0x80 0x01",   # Driver Airbag
    "PAB": "0x80 0x10",   # Passenger Airbag
    "DKA": "0x92 0x11",   # Driver Knee Airbag
    # "Battery_CutOFF": "0x92 0x1D", # Battery Cutoff
    "RLPT": "0x92 0x03",  # Driver Lap Pretensioner
    "LLPT": "0x92 0x04",  # Passenger Lap Pretensioner
    # Additional active M314 loops below are mapped at the ARIA/loadbox level,
    # but their DTC base codes are not verified in the current source.
    "R2RPT": None,
    "CAB": None,
    "R2LPT": None,
    "DBFL": None,
    "PBFL": None,
}

# Squib fault timing parameters
squib_fault_time = {
    "Qualification_Time": 2000,
    "Qualification_Tolerance": 10,
    "Dequalification_Time": 4000,
    "Dequalification_Tolerance": 20
}

Squib_Fault_Description = {
    "HiRes": "HRES_FAULT",
    "LoRes": "SHORT",
    "Open": "OPEN",
    "S2B": "BUSS_HI_ON",
    "S2G": "BUSS_Lo_ON",
    "CrossConnect": "BUSS_HI_ON",
    "NoFault": "INHERENT",
    "UNEX": "UNEXPECTED"
}

# Expected DID 0x0446 status codes for specific squib states
Squib_DID_0446_ExpectedCode = {
    "NoFault": 0x00,
    "Open": 0x01,
    "S2G": 0x02,
    "S2B": 0x03,
    "LoRes": 0x04,
    "HiRes": 0x05,
    "CrossConnect": 0x06,
    "Not_Configured": 0x07
}

# DID 0x0446 code-to-description mapping for squib fault status bytes
Squib_DID_0446_CodeMap = {
    0x00: "No Fault",
    0x01: "Open fault",
    0x02: "Short to Ground",
    0x03: "Short to Battery",
    0x04: "Low Resistance",
    0x05: "High Resistance",
    0x06: "Cross Connect",
    0x07: "Not_Configured",
}


# Add expected squib deployment mapping for each crash type - W610
EXPECTED_SQUIB_DEPLOYMENT = {
    "front": {"Driver Airbag": 1, "Passenger Airbag": 1, "Left pretensioner": 1, "Right pretensioner": 1, "Driver Knee Airbag": 1, "Left lap pretensioner": 1, "Right lap pretensioner": 1},
    "left": {"Left Curtain airbag": 1, "Left Side airbag": 1, "Left pretensioner": 1, "Left lap pretensioner": 1},
    "right": {"Right curtain airbag": 1, "Right Side airbag": 1, "Right pretensioner": 1, "Right lap pretensioner": 1},
    "rear": {"Left pretensioner": 1, "Right pretensioner": 1, "Left lap pretensioner": 1, "Right lap pretensioner": 1},
    "near": {},
    "understrike": {},
}