"""Configuration package for M210.

Contains project_config.py and ALL module configs.
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.
