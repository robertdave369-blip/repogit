"""
Module Configuration: VARIANTCODE
Project: M210
============================================================

Location: projects/M210/config/variantcode_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "VARIANTCODE"


# ── VARIANTCODE Settings ──
VARIANTCODE_DID = 0x0101
vc_positive_res = "0x6E 0x01 0x01"
# The project's default variant code, the same bytes as project_config.DEFAULT_VARIANT_CODE
# (what fault_free_profile() writes). enabled_nodes names the set bits by the node map of
# shared core_functions.manage_variant_code, which writes from variant_bytes.
project_defaults = {
    "M210": {
        "enabled_nodes": [
            "VARIANT_STATUS",
            "ESC",
            "EPS",
            "MBFM",
            "HPC_C",
            "FR_ZONE",
            "HPCAD",
            "VCU",
        ],
        "variant_bytes": [0x19, 0x00, 0x00, 0x02, 0x00, 0x14, 0x00, 0x04,
                          0x00, 0x00, 0x00, 0x04, 0x01, 0x00, 0x00, 0x00,
                          0x00, 0x00, 0x00, 0x00],
        "description": "M210 default variant code (M314 value) (19 00 00 02 00 14 00 04 00 00 00 04 01 00 00 00 00 00 00 00); set bits outside manage_variant_code's node map: byte 11 bit 2",
    },
}
