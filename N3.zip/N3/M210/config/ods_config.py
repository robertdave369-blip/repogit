"""
Module Configuration: ODS
Project: M210
============================================================

Location: projects/M210/config/ods_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.
# 2026-10-27 (user: ODS, STPS and DCS each in its own config): the ODS settings of
# canc_config.py moved here, values unchanged.

PROJECT_NAME = "M210"
MODULE_NAME = "ODS"

ENABLED = True

# ── ODS Settings ──
# ODS_STATUS_DID = 0x0450
# ODS_WEIGHT_DID = 0x0451
# ODS_CLASSIFICATION_DID = 0x0452

# ODS seat logical names
ODSName = [
    "DCS_Second_Row_Right_ODS",
    "DCS_Second_Row_Left_ODS",
    "DCS_Second_Row_Middle_ODS",
    "DCS_Third_Row_Right_ODS",
    "DCS_Third_Row_Left_ODS"
]

# ODS logical name -> DCS channel index
ODSNumber = {
    "DCS_Second_Row_Right_ODS": 9,
    "DCS_Second_Row_Left_ODS": 10,
    "DCS_Second_Row_Middle_ODS": 11,
    "DCS_Third_Row_Right_ODS": 14,
    "DCS_Third_Row_Left_ODS": 15
}

# ODS logical name -> software channel
ODSChannelName = {
    "DCS_Second_Row_Right_ODS": "SW_Channel_DCS_9",
    "DCS_Second_Row_Left_ODS": "SW_Channel_DCS_10",
    "DCS_Second_Row_Middle_ODS": "SW_Channel_DCS_11",
    "DCS_Third_Row_Right_ODS": "SW_Channel_DCS_14",
    "DCS_Third_Row_Left_ODS": "SW_Channel_DCS_15"
}

# ── ODS loads and channels (from canc_config.py, 2026-10-27) ──
# Sources: project_reuirements/project_feature-context/dcs_ocs_stps_prompt.md and the ODS
# ranges of 13C cases 83-87. ODS: 200R present, 800R not present; the 13C cases give adult
# 0-100 ohm and child 120-440 ohm. A faulty ODS takes dcs_config CANC_DCS_FAULT_LOAD plus
# Leakage VBAT Bus High; a load change settles in dcs_config CANC_DCS_STATE_SETTLE_MS.
CANC_ODS_LOADS = {'PRESENT': '200R', 'PRESENT_ADULT': '100R', 'PRESENT_CHILD': '200R', 'NOT_PRESENT': '800R'}
# ODSChannelName channel behind each CAN seat ODS status signal.
CANC_ODS_CHANNEL = {
    'STS_SEAT_ODS_SEC_ROW_LEFT': 'DCS_Second_Row_Left_ODS', 'STS_SEAT_ODS_SEC_ROW_MIDDLE': 'DCS_Second_Row_Middle_ODS',
    'STS_SEAT_ODS_SEC_ROW_RIGHT': 'DCS_Second_Row_Right_ODS', 'STS_SEAT_ODS_TRD_ROW_LEFT': 'DCS_Third_Row_Left_ODS',
    'STS_SEAT_ODS_TRD_ROW_RIGHT': 'DCS_Third_Row_Right_ODS',
}
