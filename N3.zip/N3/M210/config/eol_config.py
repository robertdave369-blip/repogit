"""
Module Configuration: EOL
Project: M210
============================================================

Location: projects/M210/config/eol_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "EOL"

# M314 applicability default. Driver load limiter remains enabled; PAB lamps
# and PAB mode remain enabled although the PABD switch is not applicable.
# The ECU readback after an ignition cycle clears OCS (byte 6 bit 4), so OCS
# is not part of this unit's accepted EOL baseline.
EOL_DEFAULT_BYTES = [
     0xFF, 0xBF, 0xFF, 0xAF, 0xFE, 0x1F, 0x31, 0x14, 0x03, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

]
EOL_DID = 0x0102
EOL_POSITIVE_RESPONSE = "0x6E 0x01 0x02"
eol_positive_res = EOL_POSITIVE_RESPONSE

M210_FEATURE_MAP = {
    "PASSENGER_AIRBAG": (0, 0),
    "DRIVER_AIRBAG": (0, 1),
    "LEFT_SIDE_AIRBAG": (0, 2),
    "RIGHT_SIDE_AIRBAG": (0, 3),
    "LEFT_CURTAIN_AIRBAG": (0, 4),
    "RIGHT_CURTAIN_AIRBAG": (0, 5),
    "DRIVER_KNEE_AIRBAG": (0, 6),
    "CENTER_FARSIDE_AIRBAG": (0, 7),
    "LEFT_PRETENSIONER_1_BELT": (1, 0),
    "RIGHT_PRETENSIONER_1_BELT": (1, 1),
    "LEFT_PRETENSIONER_2_LAP": (1, 2),
    "RIGHT_PRETENSIONER_2_LAP": (1, 3),
    "LEFT_PRETENSIONER_LOAD_LIMITER_1_BELT": (1, 4),
    "RIGHT_PRETENSIONER_LOAD_LIMITER_1_BELT": (1, 5),
    "UNDERBODY_RSU": (1, 7),
    "LEFT_FRSU": (2, 0),
    "RIGHT_FRSU": (2, 1),
    "LEFT_SRSU": (2, 2),
    "RIGHT_SRSU": (2, 3),
    "RIGHT_SIDE_PRESSURE_RSU": (2, 4),
    "LEFT_SIDE_PRESSURE_RSU": (2, 5),
    "C_PILLAR_RIGHT_SRSU": (2, 6),
    "C_PILLAR_LEFT_SRSU": (2, 7),
    "A_PILLAR_RIGHT_SRSU": (3, 0),
    "A_PILLAR_LEFT_SRSU": (3, 1),
    "REAR_RSU": (3, 2),
    "PABD_SWITCH": (3, 3),
    "DRIVER_ODS": (3, 4),
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH": (3, 5),
    "CO_DRIVER_ODS": (3, 6),
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH": (3, 7),
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH": (4, 1),
    "SECOND_ROW_RIGHT_ODS": (4, 2),
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH": (4, 3),
    "SECOND_ROW_MIDDLE_ODS": (4, 4),
    "SECOND_ROW_LEFT_BUCKLE_SWITCH": (4, 5),
    "SECOND_ROW_LEFT_ODS": (4, 6),
    "THIRD_ROW_RIGHT_BUCKLE_SWITCH": (4, 7),
    "THIRD_ROW_RIGHT_ODS": (5, 0),
    "THIRD_ROW_LEFT_BUCKLE_SWITCH": (5, 1),
    "THIRD_ROW_LEFT_ODS": (5, 2),
    "PABD_LAMP_HW": (5, 3),
    "PAB_ENABLE": (5, 4),
    "PAB_MODE": (5, 5),
    "CRASH_OUTPUT_HW_LINE": (6, 0),
    "NM_TEST_MESSAGE": (6, 1),
    "ALIVE_COUNTER": (6, 2),
    "DOMS": (6, 3),
    "OCS": (6, 4),
    "E_CALL_CRASH_OUTPUT_LINE": (6, 5),
    "BATTERY_CUTOFF_SWITCH": (6, 6),
    "DRIVER_AIRBAG_ACTIVE_VENT": (7, 0),
    "PASSENGER_AIRBAG_ACTIVE_VENT": (7, 1),
    "DRIVER_STPS_ZONE_ONE": (7, 2),
    "DRIVER_STPS_ZONE_TWO": (7, 3),
    "PASSENGER_STPS_ZONE_ONE": (7, 4),
    "PASSENGER_STPS_ZONE_TWO": (7, 5),
    "SECOND_ROW_RIGHT_PRETENSIONER": (8, 0),
    "SECOND_ROW_LEFT_PRETENSIONER": (8, 1),
    "PASSENGER_PELVIS_RESTRAINT_CUSHION": (8, 2),
    "DRIVER_PELVIS_RESTRAINT_CUSHION": (8, 3),
}

M210_ENABLED_FEATURES = [
    "PASSENGER_AIRBAG",
    "DRIVER_AIRBAG",
    "LEFT_SIDE_AIRBAG",
    "RIGHT_SIDE_AIRBAG",
    "LEFT_CURTAIN_AIRBAG",
    "RIGHT_CURTAIN_AIRBAG",
    "DRIVER_KNEE_AIRBAG",
    "CENTER_FARSIDE_AIRBAG",
    "LEFT_PRETENSIONER_1_BELT",
    "RIGHT_PRETENSIONER_1_BELT",
    "LEFT_PRETENSIONER_2_LAP",
    "RIGHT_PRETENSIONER_2_LAP",
    "LEFT_PRETENSIONER_LOAD_LIMITER_1_BELT",
    "RIGHT_PRETENSIONER_LOAD_LIMITER_1_BELT",
    "UNDERBODY_RSU",
    "LEFT_FRSU",
    "RIGHT_FRSU",
    "LEFT_SRSU",
    "RIGHT_SRSU",
    "RIGHT_SIDE_PRESSURE_RSU",
    "LEFT_SIDE_PRESSURE_RSU",
    "C_PILLAR_RIGHT_SRSU",
    "C_PILLAR_LEFT_SRSU",
    "A_PILLAR_RIGHT_SRSU",
    "A_PILLAR_LEFT_SRSU",
    "REAR_RSU",
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH",
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH",
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH",
    "SECOND_ROW_RIGHT_ODS",
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH",
    "SECOND_ROW_MIDDLE_ODS",
    "SECOND_ROW_LEFT_BUCKLE_SWITCH",
    "SECOND_ROW_LEFT_ODS",
    "THIRD_ROW_RIGHT_BUCKLE_SWITCH",
    "THIRD_ROW_RIGHT_ODS",
    "THIRD_ROW_LEFT_BUCKLE_SWITCH",
    "THIRD_ROW_LEFT_ODS",
    "PABD_LAMP_HW",
    "PAB_ENABLE",
    "PAB_MODE",
    "CRASH_OUTPUT_HW_LINE",
    "ALIVE_COUNTER",
    "DOMS",
    "E_CALL_CRASH_OUTPUT_LINE",
    "DRIVER_STPS_ZONE_ONE",
    "PASSENGER_STPS_ZONE_ONE",
    "SECOND_ROW_RIGHT_PRETENSIONER",
    "SECOND_ROW_LEFT_PRETENSIONER",
]

EOL_LOOP_FEATURES = [
    # "PASSENGER_AIRBAG",
    "DRIVER_AIRBAG",
    # "LEFT_SIDE_AIRBAG",
    # "RIGHT_SIDE_AIRBAG",
    # "LEFT_CURTAIN_AIRBAG",
    # "RIGHT_CURTAIN_AIRBAG",
    # "DRIVER_KNEE_AIRBAG",
    # "CENTER_FARSIDE_AIRBAG",
    # "LEFT_PRETENSIONER_1_BELT",
    # "RIGHT_PRETENSIONER_1_BELT",
    # "LEFT_PRETENSIONER_2_LAP",
    # "RIGHT_PRETENSIONER_2_LAP",
    # "LEFT_PRETENSIONER_LOAD_LIMITER_1_BELT",
    # "RIGHT_PRETENSIONER_LOAD_LIMITER_1_BELT",
    # "SECOND_ROW_RIGHT_PRETENSIONER",
    # "SECOND_ROW_LEFT_PRETENSIONER",
]
EOL_LOOP_SQUIB_NAMES = {
    "PASSENGER_AIRBAG": "PAB",
    "DRIVER_AIRBAG": "DAB",
    "LEFT_SIDE_AIRBAG": "LSA",
    "RIGHT_SIDE_AIRBAG": "RSA",
    "LEFT_CURTAIN_AIRBAG": "LCA",
    "RIGHT_CURTAIN_AIRBAG": "RCA",
    "DRIVER_KNEE_AIRBAG": "DKA",
    "CENTER_FARSIDE_AIRBAG": "CAB",
    "LEFT_PRETENSIONER_1_BELT": "LPT",
    "RIGHT_PRETENSIONER_1_BELT": "RPT",
    "LEFT_PRETENSIONER_2_LAP": "LLPT",
    "RIGHT_PRETENSIONER_2_LAP": "RLPT",
    "LEFT_PRETENSIONER_LOAD_LIMITER_1_BELT": "PBFL",
    "RIGHT_PRETENSIONER_LOAD_LIMITER_1_BELT": "DBFL",
    "SECOND_ROW_LEFT_PRETENSIONER": "R2LPT",
    "SECOND_ROW_RIGHT_PRETENSIONER": "R2RPT",
}
EOL_PAB_Dependencies = ["PASSENGER_AIRBAG", "PABD_LAMP_HW", "PAB_ENABLE", "PAB_MODE"]
EOL_RSU_FEATURES = [
    "UNDERBODY_RSU",
    "LEFT_FRSU",
    "RIGHT_FRSU",
    "LEFT_SRSU",
    "RIGHT_SRSU",
    "RIGHT_SIDE_PRESSURE_RSU",
    "LEFT_SIDE_PRESSURE_RSU",
    "C_PILLAR_RIGHT_SRSU",
    "C_PILLAR_LEFT_SRSU",
    "A_PILLAR_RIGHT_SRSU",
    "A_PILLAR_LEFT_SRSU",
    "REAR_RSU",
]
EOL_GPO_FEATURES = ["PABD_LAMP_HW", "PAB_ENABLE", "CRASH_OUTPUT_HW_LINE", "E_CALL_CRASH_OUTPUT_LINE"]
EOL_SWITCH_DCS_FEATURES = [
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH",
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH",
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH",
    "SECOND_ROW_RIGHT_ODS",
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH",
    "SECOND_ROW_MIDDLE_ODS",
    "SECOND_ROW_LEFT_BUCKLE_SWITCH",
    "SECOND_ROW_LEFT_ODS",
    "THIRD_ROW_RIGHT_BUCKLE_SWITCH",
    "THIRD_ROW_RIGHT_ODS",
    "THIRD_ROW_LEFT_BUCKLE_SWITCH",
    "THIRD_ROW_LEFT_ODS",
    "DOMS",
    "DRIVER_STPS_ZONE_ONE",
    "PASSENGER_STPS_ZONE_ONE",
]
# Each entry stores the DTC base bytes and the M310/M314 configuration-error
# type byte. Test scripts append the current UDS DTC status byte at runtime.
M210_FEATURE_AVAILABLE_DTCS = {
    "LEFT_FRSU": [{"dtc": "8090", "status_byte": "64", "description": "LEFT FRSU CONFIGURATION ERROR"}],
    "RIGHT_FRSU": [{"dtc": "8095", "status_byte": "64", "description": "RIGHT FRSU CONFIGURATION ERROR"}],
    "LEFT_SRSU": [{"dtc": "920A", "status_byte": "64", "description": "B-PILLAR LEFT SRSU CONFIGURATION ERROR"}],
    "RIGHT_SRSU": [{"dtc": "920B", "status_byte": "64", "description": "B-PILLAR RIGHT SRSU CONFIGURATION ERROR"}],
    "DRIVER_AIRBAG": [{"dtc": "8001", "status_byte": "64", "description": "DRIVER AIRBAG UNEXPECTED SQUIB"}],
    "PASSENGER_AIRBAG": [{"dtc": "8010", "status_byte": "64", "description": "PASSENGER AIRBAG UNEXPECTED SQUIB"}],
    "PASSENGER_AIRBAG_ACTIVE_VENT": [{"dtc": "98FD", "status_byte": "64", "description": "PASSENGER AIRBAG ACTIVE VENT SQUIB UNEXPECTED"}],
    "RIGHT_PRETENSIONER_LOAD_LIMITER_1_BELT": [{"dtc": "9263", "status_byte": "64", "description": "RIGHT PRETENSIONER ADAPTIVE LOAD LIMITER UNEXPECTED SQUIB"}],
    "RIGHT_PRETENSIONER_1_BELT": [{"dtc": "8070", "status_byte": "64", "description": "RIGHT PRETENSIONER UNEXPECTED SQUIB"}],
    "LEFT_PRETENSIONER_LOAD_LIMITER_1_BELT": [{"dtc": "9264", "status_byte": "64", "description": "LEFT PRETENSIONER ADAPTIVE LOAD LIMITER UNEXPECTED SQUIB"}],
    "LEFT_PRETENSIONER_1_BELT": [{"dtc": "8072", "status_byte": "64", "description": "LEFT PRETENSIONER UNEXPECTED SQUIB"}],
    "RIGHT_PRETENSIONER_2_LAP": [{"dtc": "9203", "status_byte": "64", "description": "RIGHT LAP PRETENSIONER UNEXPECTED SQUIB"}],
    "LEFT_PRETENSIONER_2_LAP": [{"dtc": "9204", "status_byte": "64", "description": "LEFT LAP PRETENSIONER UNEXPECTED SQUIB"}],
    "RIGHT_SIDE_AIRBAG": [{"dtc": "9206", "status_byte": "64", "description": "RIGHT SIDE AIRBAG UNEXPECTED SQUIB"}],
    "LEFT_SIDE_AIRBAG": [{"dtc": "9208", "status_byte": "64", "description": "LEFT SIDE AIRBAG UNEXPECTED SQUIB"}],
    "RIGHT_CURTAIN_AIRBAG": [{"dtc": "9207", "status_byte": "64", "description": "RIGHT SIDE CURTAIN AIRBAG UNEXPECTED SQUIB"}],
    "LEFT_CURTAIN_AIRBAG": [{"dtc": "9209", "status_byte": "64", "description": "LEFT SIDE CURTAIN AIRBAG UNEXPECTED SQUIB"}],
    "PABD_SWITCH": [{"dtc": "9205", "status_byte": "64", "description": "PASSENGER AIRBAG DISABLE SWITCH CONFIGURATION ERROR"}],
    "PABD_LAMP_HW": [{"dtc": "9210", "status_byte": "64", "description": "PASSENGER AIRBAG DISABLE LAMP CONFIGURATION ERROR"}],
    "RIGHT_SIDE_PRESSURE_RSU": [{"dtc": "9216", "status_byte": "64", "description": "RIGHT SIDE PRESSURE SENSOR CONFIGURATION ERROR"}],
    "LEFT_SIDE_PRESSURE_RSU": [{"dtc": "9212", "status_byte": "64", "description": "LEFT SIDE PRESSURE SENSOR CONFIGURATION ERROR"}],
    "DRIVER_KNEE_AIRBAG": [{"dtc": "9211", "status_byte": "64", "description": "DRIVER KNEE AIRBAG UNEXPECTED SQUIB"}],
    "CRASH_OUTPUT_HW_LINE": [{"dtc": "9218", "status_byte": "64", "description": "CRASH OUTPUT LINE CONFIGURATION ERROR"}],
    "E_CALL_CRASH_OUTPUT_LINE": [{"dtc": "9990", "status_byte": "64", "description": "CRASH OUTPUT ECALL HW LINE CONFIGURATION ERROR"}],
    "C_PILLAR_LEFT_SRSU": [{"dtc": "921B", "status_byte": "64", "description": "C-PILLAR LEFT SRSU CONFIGURATION ERROR"}],
    "C_PILLAR_RIGHT_SRSU": [{"dtc": "921C", "status_byte": "64", "description": "C-PILLAR RIGHT SRSU CONFIGURATION ERROR"}],
    "PAB_ENABLE": [{"dtc": "9024", "status_byte": "64", "description": "PAB ON LED (GPO-1) LINE CONFIGURATION ERROR"}],
    "CENTER_FARSIDE_AIRBAG": [{"dtc": "9233", "status_byte": "64", "description": "CENTER FAR SIDE AIRBAG UNEXPECTED SQUIB"}],
    "A_PILLAR_LEFT_SRSU": [{"dtc": "9236", "status_byte": "64", "description": "A-PILLAR LEFT SRSU CONFIGURATION ERROR"}],
    "A_PILLAR_RIGHT_SRSU": [{"dtc": "9237", "status_byte": "64", "description": "A-PILLAR RIGHT SRSU CONFIGURATION ERROR"}],
    "REAR_RSU": [{"dtc": "9238", "status_byte": "64", "description": "REAR RSU CONFIGURATION ERROR"}],
    "UNDERBODY_RSU": [{"dtc": "9252", "status_byte": "64", "description": "UNDER BODY SENSOR CONFIGURATION ERROR"}],
    "DRIVER_STPS_ZONE_ONE": [{"dtc": "98F9", "status_byte": "64", "description": "DRIVER STPS1 CONFIGURATION ERROR"}],
    "PASSENGER_STPS_ZONE_ONE": [{"dtc": "98FB", "status_byte": "64", "description": "CO-DRIVER STPS1 CONFIGURATION ERROR"}],
    "SECOND_ROW_LEFT_PRETENSIONER": [{"dtc": "9914", "status_byte": "64", "description": "2ND ROW LEFT PRETENSIONER UNEXPECTED SQUIB"}],
    "SECOND_ROW_RIGHT_PRETENSIONER": [{"dtc": "990F", "status_byte": "64", "description": "2ND ROW RIGHT PRETENSIONER UNEXPECTED SQUIB"}],
}

# Common configuration DTC used by EOL validation scripts.
EOL_CONFIG_ERROR_DTC = {
    "dtc": "9202",
    "status_byte": "00",
    "description": "ECU CONFIGURATION ERROR",
}

EOL_EVT_CONFIG = {}

EOL_OTHER_FEATURES = ["ALIVE_COUNTER", "PAB_MODE"]
EOL_NOT_APPLICABLE_FEATURES = [
    "DRIVER_AIRBAG_ACTIVE_VENT",
    "PASSENGER_AIRBAG_ACTIVE_VENT",
    "PASSENGER_PELVIS_RESTRAINT_CUSHION",
    "DRIVER_PELVIS_RESTRAINT_CUSHION",
    "BATTERY_CUTOFF_SWITCH",
    "NM_TEST_MESSAGE",
    "PABD_SWITCH",
    "DRIVER_ODS",
    "CO_DRIVER_ODS",
    "DRIVER_STPS_ZONE_TWO",
    "PASSENGER_STPS_ZONE_TWO",
    "OCS",
]
EOL_RESERVED_BITS = [
    {"name": "BYTE1_BIT6_RESERVED", "byte_index": 1, "bit_index": 6},
    {"name": "BYTE4_BIT0_RESERVED", "byte_index": 4, "bit_index": 0},
    {"name": "BYTE5_BIT6_RESERVED", "byte_index": 5, "bit_index": 6},
    {"name": "BYTE5_BIT7_RESERVED", "byte_index": 5, "bit_index": 7},
    {"name": "BYTE6_BIT7_RESERVED", "byte_index": 6, "bit_index": 7},
    {"name": "BYTE7_BIT6_RESERVED", "byte_index": 7, "bit_index": 6},
    {"name": "BYTE7_BIT7_RESERVED", "byte_index": 7, "bit_index": 7},
    {"name": "BYTE8_BIT4_RESERVED", "byte_index": 8, "bit_index": 4},
    {"name": "BYTE8_BIT5_RESERVED", "byte_index": 8, "bit_index": 5},
    {"name": "BYTE8_BIT6_RESERVED", "byte_index": 8, "bit_index": 6},
    {"name": "BYTE8_BIT7_RESERVED", "byte_index": 8, "bit_index": 7},
    *[
        {"name": f"BYTE{byte_index}_BIT{bit_index}_RESERVED", "byte_index": byte_index, "bit_index": bit_index}
        for byte_index in (9, 10)
        for bit_index in range(8)
    ],
]
# Explicitly non-applicable features from eol_W613_M314.txt. No RSU feature
# is identified as non-applicable in that source, so the RSU NRC test remains
# unconfigured until a released requirement identifies one.
EOL_NRC13_NOT_APPLICABLE_FEATURES = {
    "loop": {
        "feature": "BATTERY_CUTOFF_SWITCH",
        "description": "HV Cutoff",
    },
    "dcs": {
        "feature": "PABD_SWITCH",
        "description": "Airbag Cut Off Switch",
    },
}



# Generic aliases and metadata shared by all project EOL configurations.
EOL_FEATURE_MAP = M210_FEATURE_MAP
EOL_PAYLOAD_LENGTH = 20
EOL_DEFAULT_HEX_SPACED = " ".join(f"{value:02X}" for value in EOL_DEFAULT_BYTES)
EOL_DEFAULT_HEX = "".join(f"{value:02X}" for value in EOL_DEFAULT_BYTES)
EOL_FEATURE_AVAILABLE_DTCS = M210_FEATURE_AVAILABLE_DTCS

def _build_eol_tests(features, include_without_dtc=False):
    tests = []
    for feature in features:
        byte_index, bit_index = EOL_FEATURE_MAP[feature]
        dtcs = EOL_FEATURE_AVAILABLE_DTCS.get(feature, [])
        if not dtcs and not include_without_dtc:
            continue
        dtc = dtcs[0] if dtcs else {}
        tests.append(
            {
                "feature": feature,
                "byte": byte_index,
                "bit": bit_index,
                "dtc": dtc.get("dtc"),
                "status_byte": dtc.get("status_byte"),
            }
        )
    return tests

EOL_LOOP_TESTS = _build_eol_tests(EOL_LOOP_FEATURES)
EOL_RSU_TESTS = _build_eol_tests(EOL_RSU_FEATURES)
EOL_GPO_TESTS = _build_eol_tests(EOL_GPO_FEATURES)
EOL_SWITCH_DCS_TESTS = _build_eol_tests(EOL_SWITCH_DCS_FEATURES, include_without_dtc=True)
EOL_OTHER_TESTS = _build_eol_tests(EOL_OTHER_FEATURES)

# Keeping eol_bytes tied to EOL_DEFAULT_BYTES makes an incomplete default
# payload fail validation instead of writing an inferred value to the ECU.
project_defaults = {
    "M210": {
        "description": "M210 feature-code configuration (M314 value)",
        "feature_map": EOL_FEATURE_MAP,
        "enabled_features": M210_ENABLED_FEATURES,
        "eol_bytes": EOL_DEFAULT_BYTES,
        "payload_length": EOL_PAYLOAD_LENGTH,
        "nrc13_not_applicable_features": EOL_NRC13_NOT_APPLICABLE_FEATURES,
        "reserved_bits": EOL_RESERVED_BITS,
        "feature_available_dtcs": EOL_FEATURE_AVAILABLE_DTCS,
        "loop_features": EOL_LOOP_FEATURES,
        "loop_squib_names": EOL_LOOP_SQUIB_NAMES,
        "rsu_features": EOL_RSU_FEATURES,
        "gpo_features": EOL_GPO_FEATURES,
        "switch_dcs_features": EOL_SWITCH_DCS_FEATURES,
        "other_features": EOL_OTHER_FEATURES,
        "pab_dependencies": EOL_PAB_Dependencies,
        "evt_config": EOL_EVT_CONFIG,
    },
}

