"""
Module Configuration: IMU
Project: M210
============================================================

Location: projects/M210/config/imu_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "IMU"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── IMU Settings ──
ACCELEROMETER_RANGE = 200
GYROSCOPE_RANGE = 300
SAMPLE_RATE = 1000

ACCEL_OFFSET = {"x": 0.0, "y": 0.0, "z": 0.0}
GYRO_OFFSET = {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}

# -- EDR IMU recording (V1.8_DES_SW_EDR_SwQTS_EV_IMU.xlsx, series 20-22) ------------------
# EV records YAW_RATE, LATERAL_ACCEL and LONG_ACCEL from the on-board IMU, not from CAN, so
# these are the physical values the IMU is to be stimulated with through EVT: the sweep is
# one value per sample (-5 s to +3 s every 0.5 s, each held for the window ending at its
# sample), the range limits one value per crash (EDR1 0x0455, then EDR2 0x045B). The EDR
# scripts that use them (modules/EDR_CANC/scripts_wip) are work in progress: the shared
# library has no function that drives an IMU value profile through EVT (user decision C8,
# 2026-10-22).
EDR_IMU_STIMULUS = {
    "YAW_RATE": {
        "source": "on-board IMU, yaw rate (gyroscope, z axis)", "unit": "deg/sec",
        "sweep": [-300, -262.5, -225, -187.5, -150, -112.5, -75, -37.5, 0,
                  37.5, 75, 112.5, 150, 187.5, 225, 262.5, 300],
        "range_limits": [-300, 300],
    },
    "LATERAL_ACCEL": {
        "source": "on-board IMU, lateral acceleration (accelerometer, y axis)", "unit": "g",
        "sweep": [-8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8],
        "range_limits": [-8, 8],
    },
    "LONG_ACCEL": {
        "source": "on-board IMU, longitudinal acceleration (accelerometer, x axis)", "unit": "g",
        "sweep": [-8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8],
        "range_limits": [-8, 8],
    },
}
