"""
Module Configuration: CANNM
Project: M210
============================================================

Location: projects/M210/config/cannm_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "CANNM"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CANNM Settings ──
NM_CHANNEL = 0
NM_BASE_ID = 0x500
NM_REPEAT_MESSAGE_TIME = 1.5
NM_WAIT_BUS_Sleep_TIME = 5.0
NM_TIMEOUT_TIME = 6.0
