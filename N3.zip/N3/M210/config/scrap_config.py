"""
Module Configuration: Scrap
Project: M210
============================================================

Location: projects/M210/config/scrap_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "Scrap"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── Scrap Settings ──
SCRAP_MODE_DID = 0xF1D0
SCRAP_STATUS_DID = 0xF1D1
SCRAP_COUNTER_DID = 0xF1D2

SCRAP_MODE_STATES = {
    0x00: "Normal",
    0x01: "Scrap_Requested",
    0x02: "Scrap_Active",
    0x03: "Scrap_Irreversible",
}

SECURITY_LEVEL_REQUIRED = 0x03
CONFIRMATION_SEQUENCE = [0xDE, 0xAD, 0xBE, 0xEF]

SCRAP_ACTIONS = [
    "deploy_all_squibs",
    "clear_all_data",
    "set_scrap_flag",
    "disable_communication",
]

IRREVERSIBLE_TIMEOUT = 10
