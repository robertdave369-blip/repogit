"""
Module Configuration: VIN
Project: M210
============================================================

Location: projects/M210/config/vin_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "VIN"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── VIN Settings ──
VIN_DID = 0xF190
VIN_LENGTH = 17
# TEST_VIN = "WBA00000000000001"

SECURITY_ACCESS_LEVEL = 0x01
SECURITY_SEED_DID = 0x27

# VIN strategy configuration (17 bytes)
# Use with SendDiagByValues():
# - Read VIN: "22 F1 90"
# - Write VIN: "2E F1 90" + VIN_STRATEGY_BYTES



VIN_STRATEGY_OPTIONS = {
"zeros_17": "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00",
"default_39": "39 39 39 39 39 39 39 39 39 39 39 39 39 39 39 39 39",
"sample_mixed": "31 32 33 34 35 36 37 38 39 30 41 42 43 44 45 46 47",
"sample_32":"32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32",
"out_of_range": "FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF",
"wrong_vin_for_comparison":"34 35 30 30 32 33 38 37 36 4A 48 50 36 34 32 33 45"
}
# Select the desired VIN strategy here
VIN_STRATEGY_KEY = "sample_32"
VIN_STRATEGY_BYTES = VIN_STRATEGY_OPTIONS[VIN_STRATEGY_KEY]


VIN_DID = "F1 90"
VIN_READ_REQUEST = f"{READ_SID} {VIN_DID}"
VIN_WRITE_REQUEST = f"{WRITE_SID} {VIN_DID} {VIN_STRATEGY_BYTES}"

# VIN simulation values for CAN signals (VCU5_500)
# VIN_DATA_2 is 24 bits, VIN_DATA_0/1 are 56 bits
# VIN_SIMULATION_FRAME_NAME = "VCU5_500"  #UPP
VIN_SIMULATION_FRAME_NAME = "EMS5_500"   #U171
VIN_SIMULATION_VALUES = {
"VIN_DATA_2": "0x323232",
"VIN_DATA_1": "0x32323232323232",
"VIN_DATA_0": "0x32323232323232",
}

# VIN simulation signal map (signal -> multiplexor)
VIN_SIMULATION_SIGNAL_MAP = {
"VIN_DATA_2": "VCU5_500PduMultiplexor2",
"VIN_DATA_1": "VCU5_500PduMultiplexor1",
"VIN_DATA_0": "VCU5_500PduMultiplexor0",
}

# CAN FD VIN frame/signal (high variants)
VIN_FD_FRAME_NAME = "VCU4_FD_1500"
VIN_FD_SIGNAL_NAME = "VIN_NUMBER"
