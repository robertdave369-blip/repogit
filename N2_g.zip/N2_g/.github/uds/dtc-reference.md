# DTC reference — status byte, formats, groups and records

> **Baseline:** ISO 14229-1:2020 + Amd 1:2022 (clause 12, Annex D) · **Status:** draft — record-number ranges,
> DTCFormatIdentifier and groupOfDTC values cross-checked against public references (see
> [service-catalogue.md](service-catalogue.md#verification-log)); status-bit behaviour written from engineering
> knowledge. Used by [0x14](services/0x14-clear-diagnostic-information.md),
> [0x19](services/0x19-read-dtc-information.md), [0x85](services/0x85-control-dtc-setting.md) and
> [0x86](services/0x86-response-on-event.md).

## 1. DTC number

A UDS DTC is 3 bytes: `DTCHighByte DTCMiddleByte DTCLowByte`. How those bytes map to a human-readable code
depends on the **DTCFormatIdentifier** the ECU reports (0x19 0x01, 0x07, 0x42, 0x55, 0x56):

| Value | Format | Typical use |
|---|---|---|
| 0x00 | SAE_J2012-DA_DTCFormat_00 | Emissions-style P/C/B/U codes with failure-type byte |
| 0x01 | ISO_14229-1_DTCFormat | Manufacturer-defined 3-byte DTC |
| 0x02 | SAE_J1939-73_DTCFormat | Heavy-duty (SPN/FMI) |
| 0x03 | ISO_11992-4_DTCFormat | Truck–trailer |
| 0x04 | SAE_J2012-DA_DTCFormat_04 | WWH-OBD (name per Amd 1:2022) |

For format 0x00 the first two bytes give the P/C/B/U code and the third byte is the failure type
(sub-cause). Example (illustrative): `C1 23 45` → bits 7–6 of `C1` = `11` → **U** (network), rest → `U0123`,
failure type `0x45`. The textual code and its meaning always come from the OEM DTC list.

Many OEMs use the same 2-byte code + failure-type layout under format 0x01 as well (e.g. `91 01 13` read as
B1101-13) [OEM-specific] — check the OEM DTC list before decoding.

## 2. DTC status byte

One byte per DTC, reported with each DTC in 0x19 responses.

| Bit | Mask | Name | Set when | Cleared when |
|---|---|---|---|---|
| 0 | 0x01 | testFailed | The most recent test result is "failed". | Most recent result is "passed", or a clear. |
| 1 | 0x02 | testFailedThisOperationCycle | Test failed at least once in the current operation cycle. | Start of a new operation cycle, or a clear. |
| 2 | 0x04 | pendingDTC | Failed in the current or previous operation cycle. Can be set together with confirmedDTC. | An operation cycle completes with the test run and no failure; clear. |
| 3 | 0x08 | confirmedDTC | Failure confirmed per the ECU's confirmation threshold (stored in fault memory). | Ageing completes, or a clear. |
| 4 | 0x10 | testNotCompletedSinceLastClear | Set after a clear; the test has not completed since. | Test completes (pass or fail). |
| 5 | 0x20 | testFailedSinceLastClear | Test failed at least once since the last clear. | Clear (and some ageing strategies). |
| 6 | 0x40 | testNotCompletedThisOperationCycle | Set at the start of each operation cycle. | Test completes in this cycle. |
| 7 | 0x80 | warningIndicatorRequested | ECU requests a warning lamp for this DTC. | Lamp request ends (OEM rules). |

Details of when each bit moves are governed by Annex D and the OEM's fault-handling spec (debounce,
operation-cycle definition, confirmation threshold, ageing counter). Amd 1:2022 changed the default
confirmation threshold for non-OBD use from 1 to 0 [edition-dependent].

### Status values seen in practice (illustrative — always check the OEM's availability mask)

The same fault reads differently depending on which bits the ECU supports:

| Situation | ECU supports bits 0, 1, 3 (mask 0x0B) | ECU supports bits 0–3, 5 (mask 0x2F) |
|---|---|---|
| Failing now, confirmed → **active** | 0x0B | 0x2F |
| Failed earlier this cycle, passing now → **healed in this cycle** | 0x0A | 0x2E |
| After an ignition cycle, before the test passes a full cycle | 0x08 | 0x2C (pending still set from the previous cycle) |
| After a full fault-free cycle → **historic / stored** | 0x08 | 0x28 |
| Right after a clear | 0x00 | 0x00 |

Other values: 0x50 after a clear on ECUs that also support bits 4 and 6; 0x09 (bits 0, 3) = failing and
confirmed but bit 1 not set (bit 1 unsupported, or a new cycle); 0x80 added when the warning lamp is
requested.

Many ECUs do not support every bit. The **DTCStatusAvailabilityMask** shows which bits the ECU supports.
It is byte 3 of most 0x19 responses (right after `59 <sub-function>`), byte 4 when a MemorySelection or
FunctionalGroupIdentifier comes first (0x17, 0x42, 0x55, 0x56), and absent in 0x03–0x06, 0x14, 0x16, 0x18
and 0x19 responses. Unsupported bits always read 0. Compare status bytes in tests only on supported bits:
`(actual & availMask) == (expected & availMask)`, taking `availMask` from the ECU's response rather than a
constant in the script.

### Status mask filtering (0x19 0x01 / 0x02 / 0x17 …)

The server reports a DTC when `(DTCStatus & DTCStatusMask) != 0`. Examples:

| Mask | Returns |
|---|---|
| 0x01 | DTCs failing right now |
| 0x08 | All confirmed (stored) DTCs |
| 0x09 | Failing now **or** confirmed |
| 0x04 | Pending DTCs |
| 0xFF | Every DTC that has any supported bit set |

Right after a clear, `19 02 FF` returns an empty list on an ECU that does not support bits 4 and 6
(all supported bits are 0).

To list every DTC the ECU supports regardless of status, use 0x19 0x0A (reportSupportedDTC).

## 3. groupOfDTC (0x14; also used in the 0x85 option record [OEM-specific])

| Value | Group |
|---|---|
| 0xFFFF33 | Emissions-system group |
| 0xFFFFD0 | Safety-system group (relevant to restraint / airbag ECUs) |
| 0xFFFFFE | VOBD system group |
| 0xFFFFFF | All groups (all DTCs) |
| other | A single DTC number, or an OEM-defined functional group |

ISO 14229-1:2020 adds an optional **MemorySelection** byte to 0x14 for user-defined memories. Amd 1:2022:
NRC 0x31 also when the MemorySelection is not supported.

## 4. Snapshot, stored-data and extended-data records

| Record type | Sub-functions | What it holds | Who defines the content |
|---|---|---|---|
| Snapshot (freeze frame) | 0x19 03, 04, 18 | DIDs captured when the DTC status changed (e.g. voltage, speed, time) | OEM / ECU diagnostic description |
| Stored data | 0x19 05 | Snapshot-like data organised by record number | OEM / ECU |
| Extended data | 0x19 06, 16, 19, 1A | Counters and extra info per DTC (occurrence counter, ageing counter, FDC history…) | OEM / ECU (some ranges legislated) |

Record-number ranges (Amd 1:2022):

| Parameter | 0x00 | 0x01–0xEF | 0xF0 | 0xF1–0xFE | 0xFF |
|---|---|---|---|---|---|
| DTCSnapshotRecordNumber | reserved (legislated) | manufacturer | reserved (legislated) | manufacturer | all records |
| UserDefDTCSnapshotRecordNumber | manufacturer | manufacturer | manufacturer | manufacturer | all records |

Further ranges, from the py-uds knowledge base (secondary source; Annex D.8 of the ISO text not yet read)
[unverified against ISO]:

| Parameter | Manufacturer-specific | Legislated / reserved | All records |
|---|---|---|---|
| DTCExtDataRecordNumber | 0x01–0x8F | 0x90–0x9F regulated emissions OBD, 0xA0–0xEF regulated; 0x00 and 0xF0–0xFD reserved | 0xFF all; 0xFE all regulated emissions OBD records |
| DTCStoredDataRecordNumber | 0x01–0xFE | 0x00 legislated | 0xFF |

The same table, with usage notes, is in the [0x19 entry](services/0x19-read-dtc-information.md).

**Never decode record contents by guessing.** Use the project's ODX/CDD/DID list. If no description is
available, report the raw bytes and say the layout is unknown.

## 5. Fault detection counter (0x19 0x14)

Signed 8-bit value per DTC: increases toward +127 (0x7F) while the test fails (fault about to qualify),
decreases toward −128 (0x80) while it passes. 0x19 0x14 reports DTCs whose counter is above 0 but not yet
at the failed threshold (pre-failed); py-uds words it as "positive counter, not yet reported or confirmed"
[unverified — confirm the exact inclusion rule and when the counter resets]. The debounce algorithm and
steps are OEM-defined.

## 5a. DTC severity (0x19 0x07, 0x08, 0x09, 0x42)

A DTCSeverity byte combines one severity bit (bit 7 checkImmediately, bit 6 checkAtNextHalt, bit 5
maintenanceOnly) with one DTC class bit (bits 4–0, WWH-OBD classes) — names per py-uds (secondary)
[unverified against ISO]. Full table and examples: [0x19 entry](services/0x19-read-dtc-information.md),
sub-functions 0x07–0x09.

## 6. Interactions to keep in mind

- **0x85 ControlDTCSetting off** stops status-bit updates; DTCs do not set while it is off. Re-enable (or
  change session/reset) before checking fault reactions.
- **0x14** resets status bits (typically to 0x50 if bits 4 and 6 are supported) and erases associated records
  per OEM rules.
- **Operation cycle** start (often ignition on) clears bit 1 and sets bit 6 (if supported) per Annex D.
  Pending (bit 2) stays set until a full cycle completes without failure. So an ignition cycle between a
  healed fault and the read turns 0x0A into 0x08 on an ECU with mask 0x0B; with full bit support it reads
  0x6C until the test completes, then 0x2C, then 0x28 after a fault-free cycle.
- **Qualification time:** an injected fault only sets bits 0/3 after the ECU's debounce / detection time.
  Read DTCs after that time, not immediately after injecting.
