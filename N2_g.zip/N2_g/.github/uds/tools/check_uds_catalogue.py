#!/usr/bin/env python3
"""Consistency checker for the UDS agent profile and the .github/uds catalogue.

Checks (structure and hex consistency only -- it cannot verify ISO accuracy):
  * agent profile: frontmatter has name + description, body under 30,000 chars,
    every .github/uds/ path it mentions exists
  * catalogue: every service listed in the inventory table has a file, and every
    service file is listed
  * service files: frontmatter keys, SID matches file name, response SID = SID + 0x40,
    allowed status value, the eight template headings in order
  * ```uds example blocks: REQ / POS / NEG / PER / EVT lines are well-formed hex,
    POS = REQ SID + 0x40, NEG = 7F <REQ SID> <known NRC>, sub-function echoed in POS,
    no positive response after a request with suppressPosRspMsgIndicationBit set
    (unless a 0x78 response-pending came first)

Usage:
  python .github/uds/tools/check_uds_catalogue.py            # check everything (run from repo root)
  python .github/uds/tools/check_uds_catalogue.py FILE.md    # check one service file
Exit code 0 = no errors, 1 = errors found. Warnings never fail the run.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]  # repo root (.github/uds/tools/ -> repo)
AGENT = ROOT / ".github" / "agents" / "uds-protocol-engineer.agent.md"
DOCS = ROOT / ".github" / "uds"
SERVICES = DOCS / "services"
CATALOGUE = DOCS / "service-catalogue.md"

AGENT_BODY_LIMIT = 30_000  # GitHub custom-agent prompt body limit (characters)

ALLOWED_STATUS = {"draft", "cross-checked", "verified", "oem", "withdrawn"}
REQUIRED_KEYS = {"sid", "name", "response_sid", "has_sub_function",
                 "baseline_edition", "status", "last_reviewed"}
HEADINGS = [
    r"## 1\. What is it\?",
    r"## 2\. Why is it needed\?",
    r"## 3\. What is its purpose\?",
    r"## 4\. When is it used\?",
    r"## 5\. How does it work\?",
    r"## 6\. Request and response formats",
    r"## 7\. Implementation and testing",
    r"## 8\. Standards and limitations",
]

# Services whose first request byte after the SID is a sub-function
# (bit 7 = suppressPosRspMsgIndicationBit, echoed without bit 7 in the response).
SUB_FUNCTION_SIDS = {0x10, 0x11, 0x19, 0x27, 0x28, 0x29, 0x2C, 0x31,
                     0x3E, 0x83, 0x85, 0x86, 0x87}

KNOWN_NRCS = (
    {0x10, 0x11, 0x12, 0x13, 0x14, 0x21, 0x22, 0x24, 0x25, 0x26, 0x31, 0x33,
     0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x70, 0x71, 0x72, 0x73, 0x78, 0x7E, 0x7F,
     0x8F, 0x90, 0x91, 0x92, 0x93, 0x94}
    | set(range(0x50, 0x5E))   # authentication NRCs (2020)
    | set(range(0x81, 0x8E))   # specific conditions not correct
    | set(range(0xF0, 0xFF))   # vehicle-manufacturer specific
)

HEX_TOKEN = re.compile(r"^[0-9A-F]{2}$")
PLACEHOLDER = re.compile(r"^(\.\.|…|[A-Z]{2}|xx|nn)$")


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def err(self, where: str, msg: str) -> None:
        self.errors.append(f"ERROR   {where}: {msg}")

    def warn(self, where: str, msg: str) -> None:
        self.warnings.append(f"WARNING {where}: {msg}")


def parse_frontmatter(text: str) -> tuple[dict[str, str], str] | None:
    if not text.startswith("---"):
        return None
    end = text.find("\n---", 3)
    if end == -1:
        return None
    meta: dict[str, str] = {}
    for line in text[3:end].strip().splitlines():
        if ":" in line and not line.startswith((" ", "-")):
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip().strip('"').strip("'")
    return meta, text[end + 4:]


def to_int(value: str) -> int | None:
    try:
        return int(value, 16) if value.lower().startswith("0x") else int(value)
    except ValueError:
        return None


def check_agent(rep: Report) -> None:
    where = str(AGENT.relative_to(ROOT))
    if not AGENT.exists():
        rep.err(where, "agent profile missing")
        return
    text = AGENT.read_text(encoding="utf-8")
    parsed = parse_frontmatter(text)
    if parsed is None:
        rep.err(where, "missing YAML frontmatter")
        return
    meta, body = parsed
    for key in ("name", "description"):
        if not meta.get(key):
            rep.err(where, f"frontmatter '{key}' missing or empty")
    if meta.get("name") and meta["name"] != "uds-protocol-engineer":
        rep.warn(where, f"name is '{meta['name']}', expected 'uds-protocol-engineer'")
    if len(body) > AGENT_BODY_LIMIT:
        rep.err(where, f"body is {len(body)} chars, limit {AGENT_BODY_LIMIT}")
    for ref in sorted(set(re.findall(r"(\.github/uds/[\w./-]+\.(?:md|py))", body))):
        if not (ROOT / ref).exists():
            rep.err(where, f"references missing file {ref}")
    print(f"agent body: {len(body)} / {AGENT_BODY_LIMIT} chars")


def check_uds_blocks(rep: Report, where: str, body: str, file_sid: int) -> None:
    blocks = re.findall(r"```uds\n(.*?)```", body, flags=re.S)
    if not blocks:
        rep.err(where, "no ```uds example blocks found")
        return
    saw_own_request = False
    for b_index, block in enumerate(blocks, 1):
        last_req: list[str] | None = None
        pending_seen = False
        for raw in block.splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            tag, _, rest = line.partition(" ")
            tokens = rest.split()
            loc = f"{where} block {b_index}: '{raw.strip()}'"
            if tag in ("NOTE", "PER", "EVT", "CAN", "DOIP"):
                continue
            if tag not in ("REQ", "POS", "NEG"):
                rep.err(loc, "line must start with REQ, POS, NEG, PER, EVT, CAN, DOIP or NOTE")
                continue
            if not tokens:
                rep.err(loc, "no bytes")
                continue
            for i, tok in enumerate(tokens):
                if HEX_TOKEN.match(tok):
                    continue
                if i >= 1 and PLACEHOLDER.match(tok):
                    continue
                rep.err(loc, f"token '{tok}' is not an uppercase two-digit hex byte or placeholder")
                break
            first = int(tokens[0], 16) if HEX_TOKEN.match(tokens[0]) else None
            if tag == "REQ":
                last_req = tokens
                pending_seen = False
                if first == file_sid:
                    saw_own_request = True
                continue
            if last_req is None or not HEX_TOKEN.match(last_req[0]):
                rep.err(loc, f"{tag} without a preceding REQ in the same block")
                continue
            req_sid = int(last_req[0], 16)
            if tag == "NEG":
                if len(tokens) != 3 or tokens[0] != "7F":
                    rep.err(loc, "negative response must be exactly: 7F <SID> <NRC>")
                    continue
                if tokens[1] != last_req[0]:
                    rep.err(loc, f"NEG echoes SID {tokens[1]}, request SID is {last_req[0]}")
                if HEX_TOKEN.match(tokens[2]) and int(tokens[2], 16) not in KNOWN_NRCS:
                    rep.err(loc, f"NRC {tokens[2]} not in the known NRC set")
                if tokens[2] == "78":
                    pending_seen = True
                continue
            # POS
            if first != (req_sid + 0x40) & 0xFF:
                rep.err(loc, f"positive response SID should be {req_sid + 0x40:02X}")
            if req_sid in SUB_FUNCTION_SIDS and len(last_req) > 1 and len(tokens) > 1 \
                    and HEX_TOKEN.match(last_req[1]) and HEX_TOKEN.match(tokens[1]):
                req_sf = int(last_req[1], 16)
                if int(tokens[1], 16) != req_sf & 0x7F:
                    rep.err(loc, f"sub-function echo should be {req_sf & 0x7F:02X}")
                if req_sf & 0x80 and not pending_seen:
                    rep.err(loc, "positive response shown after a request with "
                                 "suppressPosRspMsgIndicationBit set (no 0x78 first)")
    if not saw_own_request:
        rep.err(where, f"no REQ line uses this file's SID {file_sid:02X}")


def check_service(rep: Report, path: Path) -> int | None:
    where = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    text = path.read_text(encoding="utf-8")
    parsed = parse_frontmatter(text)
    if parsed is None:
        rep.err(where, "missing YAML frontmatter")
        return None
    meta, body = parsed
    missing = REQUIRED_KEYS - meta.keys()
    if missing:
        rep.err(where, f"frontmatter missing keys: {', '.join(sorted(missing))}")
    sid = to_int(meta.get("sid", ""))
    rsid = to_int(meta.get("response_sid", ""))
    m = re.match(r"0x([0-9A-F]{2})-", path.name)
    if not m:
        rep.err(where, "file name must start with 0xNN- (uppercase hex)")
    elif sid is not None and int(m.group(1), 16) != sid:
        rep.err(where, f"file name SID {m.group(1)} does not match frontmatter sid")
    if sid is not None and rsid is not None and rsid != sid + 0x40:
        rep.err(where, f"response_sid should be 0x{sid + 0x40:02X}")
    status = meta.get("status", "")
    if status not in ALLOWED_STATUS:
        rep.err(where, f"status '{status}' not in {sorted(ALLOWED_STATUS)}")
    if status == "verified" and not re.search(r"Verified by", body):
        rep.err(where, "status 'verified' requires a 'Verified by' line (reviewer, ISO clause, date)")
    hsf = meta.get("has_sub_function", "").lower()
    if sid is not None and hsf in ("true", "false"):
        if (hsf == "true") != (sid in SUB_FUNCTION_SIDS):
            rep.err(where, "has_sub_function disagrees with the checker's sub-function SID list")
    pos = 0
    for pattern in HEADINGS:
        found = re.search(rf"^{pattern}.*$", body[pos:], flags=re.M)
        if not found:
            rep.err(where, f"missing or out-of-order heading matching '{pattern}'")
            continue
        pos += found.end()
    if sid is not None:
        check_uds_blocks(rep, where, body, sid)
    return sid


def check_catalogue(rep: Report, files: dict[int, Path]) -> None:
    where = str(CATALOGUE.relative_to(ROOT))
    if not CATALOGUE.exists():
        rep.err(where, "service catalogue missing")
        return
    text = CATALOGUE.read_text(encoding="utf-8")
    linked = set()
    for link in re.findall(r"\]\((services/[^)]+\.md)\)", text):
        target = DOCS / link
        if not target.exists():
            rep.err(where, f"links to missing file {link}")
        else:
            linked.add(target.resolve())
    for sid, path in sorted(files.items()):
        if path.resolve() not in linked:
            rep.err(where, f"service file {path.name} is not linked from the catalogue")
    # inventory rows: "| 0xNN | ... | [0xNN](services/file.md) | status |" must match the file's status
    for line in text.splitlines():
        row = re.match(r"^\|.*\]\((services/[^)]+\.md)\)\s*\|\s*([\w-]+)\s*\|\s*$", line)
        if not row or not (DOCS / row.group(1)).exists():
            continue
        parsed = parse_frontmatter((DOCS / row.group(1)).read_text(encoding="utf-8"))
        file_status = parsed[0].get("status") if parsed else None
        if file_status and row.group(2) != file_status:
            rep.err(where, f"inventory says '{row.group(2)}' for {row.group(1)}, file says '{file_status}'")
    for ref in sorted(set(re.findall(r"\]\(([\w.-]+\.md)\)", text))):
        if not (DOCS / ref).exists():
            rep.err(where, f"links to missing file {ref}")


def check_relative_links(rep: Report, path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    for link in re.findall(r"\]\(((?:\.\./|\./)?[\w./-]+\.md)(?:#[\w-]*)?\)", text):
        if not (path.parent / link).resolve().exists():
            rep.err(str(path.relative_to(ROOT)), f"broken link {link}")


def main(argv: list[str]) -> int:
    rep = Report()
    if len(argv) > 1:
        for arg in argv[1:]:
            check_service(rep, Path(arg).resolve())
    else:
        check_agent(rep)
        files: dict[int, Path] = {}
        for path in sorted(SERVICES.glob("0x*.md")):
            sid = check_service(rep, path)
            if sid is not None:
                if sid in files:
                    rep.err(path.name, f"duplicate SID with {files[sid].name}")
                files[sid] = path
        check_catalogue(rep, files)
        for path in sorted(DOCS.rglob("*.md")):
            if path.name != "entry-template.md":  # its links are written for services/
                check_relative_links(rep, path)
        print(f"service files checked: {len(files)}")
    for line in rep.warnings + rep.errors:
        print(line)
    print(f"{len(rep.errors)} error(s), {len(rep.warnings)} warning(s)")
    return 1 if rep.errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
