---
sid: 0xNN
name: ServiceName
response_sid: 0xNN            # SID + 0x40
has_sub_function: true        # true only if byte 2 of the request is a sub-function (SPRMIB in bit 7)
functional_unit: "<ISO functional unit>"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "<clause, only if confirmed>"
status: draft                 # draft | cross-checked | verified | oem | withdrawn
last_reviewed: YYYY-MM-DD
sources:
  - "<reference used to cross-check, e.g. ISO 14229-1:2020 preview TOC>"
---

<!--
Copy this file to .github/uds/services/0xNN-service-name.md (uppercase hex, kebab-case name).
Keep the eight numbered headings exactly as written; tools/check_uds_catalogue.py checks them.
Write in your own words. Do not paste text or tables from ISO documents.
Inline flags for single statements: [unverified] [edition-dependent] [OEM-specific] [illustrative]
Link shared material instead of repeating it:
  ../nrc-reference.md  ../dtc-reference.md  ../protocol-fundamentals.md
Then add or update the row in ../service-catalogue.md.
-->

# 0xNN — ServiceName

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0xNN
> One-line summary of what the service does.

## 1. What is it?

Plain-language description: standardized name, SID, core behaviour, main objective, the data or action involved.
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

The diagnostic problem it solves, why other services are not enough, and who gets value from it
(ECU, tester, vehicle engineer, production line, workshop, validation team).
<!-- catalogue field 3 -->

## 3. What is its purpose?

Its role in the full diagnostic workflow: what it enables, what it changes or returns, what it does not do.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| | | |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

For each use case:

### Use case: <short title>
- **Scenario:**
- **Engineer's objective:**
- **Why this service:**
- **Tester sends:**
- **ECU is expected to:**
- **Engineer obtains:**
- **Test on success / failure:**
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

Request → processing → response sequence, state changes, sequencing rules.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | | |
| Security / authentication | | |
| ECU operating conditions | | |
| Timing (P2 / P2* / S3) | | |

**Depends on:** other services, transport layer behaviour.
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|

(Services without a sub-function: state "No sub-function; suppressPosRspMsgIndicationBit does not apply.")

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 22 F1 90                 # comment: what is being asked
POS 62 F1 90 ..              # comment: decoded meaning
```

Byte-by-byte decoding table for each example.
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:** request builder inputs and validation, response parser, error handling, timeouts, edge cases.
Adapt names and structure to the repository's existing conventions.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | |
| Edition differences | |
| OEM / ECU-specific | |
| Verification status | |
| Open questions | |
<!-- catalogue field 15 -->
