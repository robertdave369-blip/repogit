# UDS protocol fundamentals

> **Baseline:** ISO 14229-1:2020 + Amd 1:2022, ISO 14229-2 (session layer timing), ISO 15765-2 (DoCAN),
> ISO 13400-2 (DoIP) · **Status:** draft — written from engineering knowledge in this repository's own words.
> Items marked [unverified] must be confirmed against the edition and OEM spec used by the project.
> Shared by all service entries in [services/](service-catalogue.md#service-inventory).

## Where each standard fits

| Layer | Standard | What it defines |
|---|---|---|
| Application | ISO 14229-1 | Services, parameters, NRCs, DTC model, DID/RID ranges |
| Session | ISO 14229-2 | P2 / P2* / S3 timing and session-layer behaviour |
| Implementation on a bus | ISO 14229-3 (CAN), -4 (FlexRay), -5 (IP), -6 (K-Line), -7 (LIN) [unverified part numbering] | How UDS maps onto that network |
| Transport on CAN | ISO 15765-2 (DoCAN / ISO-TP) | Segmentation, flow control, addressing |
| Transport on Ethernet | ISO 13400-2 (DoIP) | Vehicle discovery, routing activation, diagnostic messages over TCP/UDP |
| OEM | OEM diagnostic spec, ODX/CDD | Which services/DIDs/RIDs/DTCs exist, sessions, security levels, preconditions |
| ECU / project | Requirements, test spec, config | Actual implemented behaviour |

A service existing in ISO 14229-1 says nothing about whether a given ECU supports it.

## Message structure

```
Request:            SID [sub-function] [parameters…]
Positive response:  SID+0x40 [echoed sub-function] [parameters…]
Negative response:  7F SID NRC
```

- Response SID = request SID + 0x40 (0x10 → 0x50, 0x3E → 0x7E, 0x85 → 0xC5).
- `0x7F` is reserved for negative responses.

### Sub-function byte and SPRMIB

For services with a sub-function (0x10, 0x11, 0x19, 0x27, 0x28, 0x29, 0x2C, 0x31, 0x3E, 0x85, 0x86, 0x87;
0x83 in 2013), byte 2 is:

| Bit 7 | Bits 6–0 |
|---|---|
| suppressPosRspMsgIndicationBit (SPRMIB) | sub-function value |

- SPRMIB = 1 → the server must not send a **positive** response. Negative responses are still sent
  (subject to functional-addressing suppression below).
- If the server first sends `7F SID 78` (response pending), it must later send the final response even
  when SPRMIB was set [verify exact rule in the edition used].
- The positive response echoes the sub-function **without** bit 7.
- Services without a sub-function (0x14, 0x22, 0x23, 0x24, 0x2A, 0x2E, 0x2F, 0x34–0x38, 0x3D, 0x84) have no
  SPRMIB; setting bit 7 of their first parameter byte changes the parameter, not the response behaviour.

```uds
REQ 3E 80          # TesterPresent, SPRMIB set → no positive response expected
REQ 10 83          # extendedDiagnosticSession with SPRMIB → no 50 03 … expected
REQ 3E 00          # TesterPresent without SPRMIB
POS 7E 00
```

## Functional vs physical addressing

| | Physical | Functional |
|---|---|---|
| Target | One ECU | All ECUs on the network that listen to the functional ID |
| Typical use | Almost all diagnostics | TesterPresent keep-alive, session/comm control during flashing, OBD requests |
| Multi-frame request | Allowed | Single frame only on DoCAN |
| NRC behaviour | All NRCs sent | Server stays silent for 0x11, 0x12, 0x31, 0x7E, 0x7F [verify full list for the edition] |

CAN identifier examples (illustrative — OEM-defined):

| Scheme | Physical request | Functional request |
|---|---|---|
| 11-bit OEM | e.g. 0x7xx per ECU | e.g. 0x7DF (also used by legacy OBD) |
| 29-bit normal fixed | 0x18DA`TA``SA` | 0x18DB`TA``SA` |

## Diagnostic sessions

| Session | Value | Purpose |
|---|---|---|
| defaultSession | 0x01 | Always active after power-up/reset; limited services. |
| programmingSession | 0x02 | Flashing; often only bootloader services. |
| extendedDiagnosticSession | 0x03 | Writes, IO control, routines, DTC control. |
| safetySystemDiagnosticSession | 0x04 | Safety-related systems (e.g. restraint systems, ISO 26021 deployment). |
| OEM / supplier | 0x40–0x5F / 0x60–0x7E | Manufacturer or supplier-specific. |

- Any non-default session falls back to default if no request (or TesterPresent) arrives within **S3server**.
- Any session change re-locks SecurityAccess (0x27). Temporary states (DTC setting, communication control,
  IO control, periodic DIDs, ROE) reset on a change to the default session; between two non-default
  sessions they are usually kept [unverified — check the OEM spec]. Authentication (0x29) state does not
  necessarily follow the 0x27 re-lock rule. Details per transition: [0x10 entry](services/0x10-diagnostic-session-control.md).
- Which services are allowed in which session is OEM-defined. Do not assume the "typical" matrix.

## Timing

| Parameter | Meaning | Common default | Where it comes from |
|---|---|---|---|
| P2server_max | Max time from end of request to start of response | 50 ms | 0x10 positive response (1 ms resolution) |
| P2*server_max | Max time between 0x78 and the next response | 5000 ms | 0x10 positive response (10 ms resolution) |
| S3server | Session timeout without activity | 5000 ms | ISO 14229-2 / OEM |
| P2client / P2*client | Tester waits — must exceed server values plus transport delay | OEM tester spec | Tester configuration |
| TesterPresent period | Keep-alive interval | ~2000 ms (must be < S3) | Tester configuration |

Default values are the ones commonly used; confirm against ISO 14229-2 and the OEM spec [unverified].

```uds
REQ 10 03
POS 50 03 00 32 01 F4   # P2server_max = 0x0032 = 50 ms; P2*server_max = 0x01F4 × 10 ms = 5000 ms
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 50 | | Positive response to 0x10 |
| 03 | | extendedDiagnosticSession echoed |
| 00 32 | 50 | P2server_max in ms |
| 01 F4 | 500 | P2*server_max in units of 10 ms → 5000 ms |

## Response pending (0x78)

When the server cannot answer within P2server_max it sends `7F SID 78`. The client then waits up to
P2*server_max for the next message, which may be another 0x78. Rules worth testing:

- A 0x78 must arrive within P2server_max of the request; each further 0x78 within P2*server_max.
- The final response follows (positive or another NRC).
- Testers must not resend the request while 0x78 is outstanding.
- Implementation bugs to look for: tester timing out after the first 0x78; ECU never sending the final
  response; ECU sending 0x78 forever (watchdog/routine stuck).

```uds
REQ 31 01 FF 00 ..        # start erase routine (parameters illustrative)
NEG 7F 31 78              # accepted, still working
NEG 7F 31 78              # still working (within P2*)
POS 71 01 FF 00 ..        # finished
```

## NRC evaluation order

ISO 14229-1 defines a general order of checks so that, when several conditions fail, the NRC is
predictable. Commonly cited order (verify against the general server response behaviour figure of the
edition in use — 2020 inserted authentication checks) [unverified]:

1. SID supported? → 0x11
2. SID supported in active session? → 0x7F
3. SID authentication / security requirement met? → 0x34 / 0x33
4. Minimum length correct? → 0x13
5. Sub-function supported? → 0x12
6. Sub-function supported in active session? → 0x7E
7. Sub-function authentication / security met? → 0x34 / 0x33
8. Request sequence correct? → 0x24
9. Service-specific checks: length, parameter range (0x31), conditions (0x22 or 0x81–0x93), …

Each service clause adds its own detailed order. When a test expects a specific NRC with two failing
conditions, cite the order used.

## Security and authentication

| Mechanism | Service | Model |
|---|---|---|
| Seed and key | 0x27 SecurityAccess | Odd sub-function requests seed, even sends key; OEM algorithm; attempt counter and delay |
| Certificate / PKI | 0x29 Authentication (2020) | Certificate exchange, proof of ownership, session keys; or authenticationConfiguration-based flow |
| Protected messages | 0x84 SecuredDataTransmission | Security sub-layer around a diagnostic request/response |

Never invent or reproduce a seed/key algorithm. Use the project's security DLL/library or a stub.

## Identifier ranges (overview)

Ranges follow ISO 14229-1 Annex C (DIDs) and Annex F (RIDs). Only the commonly used ones are listed; the
project's spec decides what exists [unverified unless stated].

| Range / value | Use |
|---|---|
| 0xF180–0xF19F | ECU identification (e.g. 0xF186 active session, 0xF187 spare part no., 0xF188 SW no., 0xF18C serial no., 0xF190 VIN, 0xF191 HW no.) |
| 0xF1A0–0xF1FF | Identification option ranges (OEM / supplier) [unverified bounds] |
| 0xF200–0xF2FF | Periodic data identifiers (0x2A uses the low byte) |
| 0xF300–0xF3FF | Dynamically defined data identifiers (0x2C) |
| 0xF400–0xF8FF | OBD-related identifiers |
| 0xFA00–0xFA0F | Airbag deployment (ISO 26021) |
| 0xFD00–0xFEFF | System-supplier specific |
| 0xFF00 | UDS version |
| 0xFF01 | TransportLayerSegmentationSupport (renamed by Amd 1:2022) |
| RID 0xFF00 / 0xFF01 | eraseMemory / checkProgrammingDependencies (0xFF02 eraseMirrorMemoryDTCs in 2013 only) [unverified] |
| RID 0xE200–0xE2FF | Safety-system routines (ISO 26021 end-of-life activation; exact assignments per Annex F) [unverified] |
| everything else | Usually OEM-defined — take from the OEM spec, never guess |

## ISO-TP (ISO 15765-2) essentials

| Frame | First byte(s) | Meaning |
|---|---|---|
| Single Frame (SF) | `0L` (L = length 1–7), CAN FD: `00 LL` | Whole message in one frame |
| First Frame (FF) | `1L LL` (12-bit length), >4095: `10 00` + 4-byte length | Start of a multi-frame message |
| Consecutive Frame (CF) | `2N` (N = 1…F, then 0…) | Continuation |
| Flow Control (FC) | `3S BS ST` | S: 0 continue, 1 wait, 2 overflow; BS block size; ST = STmin |

- STmin: 0x00–0x7F = 0–127 ms; 0xF1–0xF9 = 100–900 µs; other values reserved.
- Timeouts N_As, N_Ar, N_Bs, N_Cr (commonly 1000 ms) [unverified].
- Padding byte (e.g. 0xCC, 0x55, 0xAA) is OEM-defined; DLC 8 often required on classical CAN.
- Addressing modes: normal, normal fixed (29-bit), extended (target address in byte 1), mixed.

```uds
CAN 7E0  03 22 F1 90 CC CC CC CC      # SF: 3 bytes, ReadDataByIdentifier VIN (ID and padding illustrative)
CAN 7E8  10 14 62 F1 90 57 30 4C      # FF: total 0x014 = 20 bytes
CAN 7E0  30 00 00 CC CC CC CC CC      # FC: continue, no block limit, STmin 0
CAN 7E8  21 .. ..                     # CF 1
CAN 7E8  22 .. ..                     # CF 2
```

Typical transport-level faults: no Flow Control (tester or ECU missing the FC ID), wrong STmin respected,
block size exhaustion, sequence-number gaps, padding/DLC rejected by the ECU.

## DoIP (ISO 13400-2) essentials

| Item | Value |
|---|---|
| Port | 13400 (UDP discovery, TCP data) |
| Generic header | protocol version, inverse version, payload type (2 bytes), payload length (4 bytes) |
| Protocol version | 0x02 (2012), 0x03 (2019) [unverified] |
| Vehicle identification | request 0x0001 → announcement/response 0x0004 |
| Routing activation | request 0x0005 → response 0x0006 (must succeed before diagnostics) |
| Alive check | 0x0007 / 0x0008 |
| Diagnostic message | 0x8001 (source address, target address, UDS bytes) |
| Diagnostic ack / nack | 0x8002 / 0x8003 |

UDS bytes inside a 0x8001 message are identical to CAN; only the transport changes. DoIP acks are not UDS
responses — a 0x8002 ack does not mean the service succeeded.

## Troubleshooting matrix

| Symptom | Likely causes | Check |
|---|---|---|
| No response at all | Wrong request/response CAN ID, functional request with an NRC the ECU suppresses, SPRMIB set, ECU asleep, DoIP routing not active | Trace, IDs, SPRMIB, routing activation |
| Timeout after First Frame | Tester or ECU not sending Flow Control | FC ID, tester ISO-TP config |
| 7F xx 13 | Wrong length, wrong ALFID, DID data length mismatch | Count bytes against the spec |
| 7F xx 7F / 7E | Wrong session | Send 0x10 first; check S3 expiry |
| 7F xx 33 | Security locked (or re-locked by session change) | 0x27 sequence after the last session change |
| 7F xx 22 | Preconditions (speed, voltage, ignition, active fault) | OEM precondition table |
| 7F xx 24 | Order: key before seed, transfer before download | Sequence |
| 7F xx 31 | Unsupported DID/RID/record/address | OEM identifier list |
| 7F 27 37 | Delay timer after power-up or lockout | Wait time from OEM spec |
| Endless 7F xx 78 | Routine stuck, missing final response | ECU logs, P2* handling |
| Session drops back to default | TesterPresent missing or > S3 | Keep-alive period |
| DTC status not as expected | Read too early (before qualification), ControlDTCSetting off, operation cycle changed bits | [dtc-reference.md](dtc-reference.md) |
