# Negative Response Codes (NRC) reference

> **Baseline:** ISO 14229-1:2020 + Amd 1:2022 (Annex A) · **Status:** cross-checked — codes and names match
> py-uds and python-udsoncan (secondary sources, not the ISO text); meanings are written in this repository's own words.
> Service entries list only the NRCs relevant to that service and *when* that service returns them.

A negative response is always three bytes:

```
7F <request SID> <NRC>
```

The client must treat `0x78` as "not finished yet", not as a failure (see
[protocol-fundamentals.md](protocol-fundamentals.md#response-pending-0x78)).

## 1. General NRCs

| NRC | Name | Meaning in practice | Typical first thing to check |
|---|---|---|---|
| 0x10 | generalReject | Server rejected the request and no more specific code applies. | ECU log / OEM spec; often an implementation gap. |
| 0x11 | serviceNotSupported | SID not implemented at all in this server. | Is the service in the OEM diagnostic spec for this ECU? |
| 0x12 | subFunctionNotSupported | SID known, sub-function value not implemented. | Sub-function value, SPRMIB bit masking in the tester. |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length or format does not match the service definition. | Byte count, DID data length, ALFID vs actual address/size bytes. |
| 0x14 | responseTooLong | Response would exceed what the transport can carry. | Too many DIDs in one 0x22; transport buffer size. |
| 0x21 | busyRepeatRequest | Server busy with another request; try again later. | Parallel testers, gateway routing. |
| 0x22 | conditionsNotCorrect | A precondition outside the request is not met. | Vehicle state (speed, ignition, voltage), OEM preconditions. |
| 0x24 | requestSequenceError | Request arrived in the wrong order. | sendKey before requestSeed, TransferData without RequestDownload. |
| 0x25 | noResponseFromSubnetComponent | Gateway could not get an answer from the sub-network node. | Gateway routing, target node powered/awake. |
| 0x26 | failurePreventsExecutionOfRequestedAction | An active fault in the server blocks the action. | Active DTCs that inhibit the function. |
| 0x31 | requestOutOfRange | A parameter value is not supported or out of range. | DID/RID/address/record number, MemorySelection. |
| 0x33 | securityAccessDenied | Required security level not unlocked. | 0x27 state, session change re-locked the ECU. |
| 0x34 | authenticationRequired *(2020)* | Required authentication state not reached. | 0x29 flow; ECU may require authentication instead of 0x27. |
| 0x35 | invalidKey | Key sent with 0x27 does not match. | Seed/key algorithm, byte order, security level pair. |
| 0x36 | exceedNumberOfAttempts | Too many wrong keys; lockout started. | Attempt counter; wait for delay timer. |
| 0x37 | requiredTimeDelayNotExpired | Security delay timer still running. | Delay after power-up or after lockout (OEM-defined). |
| 0x38 | secureDataTransmissionRequired *(2020)* | Service must be sent inside 0x84 SecuredDataTransmission. | Wrap the request in 0x84. |
| 0x39 | secureDataTransmissionNotAllowed *(2020)* | Service must not be sent inside 0x84. | Send it plain. |
| 0x3A | secureDataVerificationFailed *(2020)* | Security sub-layer could not verify protected data. | 0x84 signature / counters. |
| 0x70 | uploadDownloadNotAccepted | Server refuses to start the download/upload. | Address range, memory state, dataFormatIdentifier. |
| 0x71 | transferDataSuspended | Transfer stopped by the server. | Previous errors in the transfer; restart sequence. |
| 0x72 | generalProgrammingFailure | Memory erase/write/verify failed. | Flash hardware, voltage, erased-before-write. |
| 0x73 | wrongBlockSequenceCounter | TransferData counter does not match expectation. | Counter start value (01) and wrap (FF→00). |
| 0x78 | requestCorrectlyReceived-ResponsePending | Request accepted, final answer will come later. | Client must switch to P2* timing and keep waiting. |
| 0x7E | subFunctionNotSupportedInActiveSession | Sub-function exists but not in the current session. | Switch session with 0x10 first. |
| 0x7F | serviceNotSupportedInActiveSession | Service exists but not in the current session. | Switch session with 0x10 first. |

## 2. Authentication NRCs (0x50–0x5D, introduced in 2020)

Names cross-checked against py-uds (secondary source); confirm against Annex A of the edition in use.

| NRC | Name |
|---|---|
| 0x50 | certificateVerificationFailed_InvalidTimePeriod |
| 0x51 | certificateVerificationFailed_InvalidSignature |
| 0x52 | certificateVerificationFailed_InvalidChainOfTrust |
| 0x53 | certificateVerificationFailed_InvalidType |
| 0x54 | certificateVerificationFailed_InvalidFormat |
| 0x55 | certificateVerificationFailed_InvalidContent |
| 0x56 | certificateVerificationFailed_InvalidScope |
| 0x57 | certificateVerificationFailed_InvalidCertificate (revoked) |
| 0x58 | ownershipVerificationFailed |
| 0x59 | challengeCalculationFailed |
| 0x5A | settingAccessRightsFailed |
| 0x5B | sessionKeyCreationOrDerivationFailed |
| 0x5C | configurationDataUsageFailed |
| 0x5D | deAuthenticationFailed |

## 3. Condition-specific NRCs (conditions not correct, more precise)

Servers may return one of these instead of 0x22 when the failing condition is known.

| NRC | Name |
|---|---|
| 0x81 | rpmTooHigh |
| 0x82 | rpmTooLow |
| 0x83 | engineIsRunning |
| 0x84 | engineIsNotRunning |
| 0x85 | engineRunTimeTooLow |
| 0x86 | temperatureTooHigh |
| 0x87 | temperatureTooLow |
| 0x88 | vehicleSpeedTooHigh |
| 0x89 | vehicleSpeedTooLow |
| 0x8A | throttle/PedalTooHigh |
| 0x8B | throttle/PedalTooLow |
| 0x8C | transmissionRangeNotInNeutral |
| 0x8D | transmissionRangeNotInGear |
| 0x8F | brakeSwitch(es)NotClosed |
| 0x90 | shifterLeverNotInPark |
| 0x91 | torqueConverterClutchLocked |
| 0x92 | voltageTooHigh |
| 0x93 | voltageTooLow |
| 0x94 | resourceTemporarilyNotAvailable *(2020)* |

## 4. Reserved and manufacturer ranges

| Range | Use |
|---|---|
| 0x00 | positiveResponse — never sent inside a 0x7F message |
| 0x3B–0x4F | reserved by the extended data link security document (2020; in 2013 the range was 0x38–0x4F) [edition-dependent] |
| 0xF0–0xFE | vehicle-manufacturer-specific "conditions not correct" codes — meaning comes from the OEM spec |
| everything else | reserved by ISO — treat as a defect or a newer edition |

## 5. Which NRC wins when several apply

The standard defines a general evaluation order (and per-service orders). Summary and caveats are in
[protocol-fundamentals.md](protocol-fundamentals.md#nrc-evaluation-order). Tests that expect one NRC when
two conditions fail at once must use the order of the edition and OEM spec in force.

## 6. Functional addressing

For functionally addressed requests, servers suppress some NRCs (notably 0x11, 0x12, 0x31, 0x7E, 0x7F) so
that unsupported nodes stay silent. Details: [protocol-fundamentals.md](protocol-fundamentals.md#functional-vs-physical-addressing).
