# UDS service catalogue

The persistent UDS reference for this repository. The `uds-protocol-engineer` agent
(`.github/agents/uds-protocol-engineer.agent.md`) reads it before working on any service, and updates it
when new behaviour is investigated or implemented.

**Baseline edition:** ISO 14229-1:2020 + Amd 1:2022 · **Last reviewed:** 2026-10-26

> Nothing in this catalogue has been checked against the full ISO text yet. Entries are `draft` or
> `cross-checked` against public references (see [Verification log](#verification-log)). Treat specific
> values marked `[unverified]` accordingly, and always prefer the project's OEM specification for what a
> given ECU actually supports.

## Contents

- [Editions](#editions)
- [Verification status](#verification-status)
- [Service inventory](#service-inventory)
- [ReadDTCInformation (0x19) sub-function index](#readdtcinformation-0x19-sub-function-index)
- [Shared references](#shared-references)
- [Adding or updating an entry](#adding-or-updating-an-entry)
- [Verification log](#verification-log)
- [Open items](#open-items)

## Editions

| Edition | Status | Notes for this catalogue |
|---|---|---|
| ISO 14229-1:2013 (2nd ed.) | Withdrawn, still common in ECUs | Has AccessTimingParameter (0x83) and mirror-memory / OBD 0x19 sub-functions; no Authentication (0x29). |
| **ISO 14229-1:2020 (3rd ed.) + Amd 1:2022** | **Baseline** | Adds Authentication (0x29) and the security sub-layer clause (0x84 moved there); removes unused 0x19 sub-functions (mirror memory, emissions OBD 0x12/0x13); adds 0x19 0x1A and 0x56; updates ReadDataByPeriodicIdentifier; adds optional MemorySelection to 0x14; adds RequestFileTransfer mode 0x06 ResumeFile. Amd 1:2022 renames/corrects several 0x19 parameters and record-number ranges. |
| ISO 14229-1:2026 (4th ed.) | Published June 2026, not yet reviewed here | Replaces 2020 + Amd 1. Secondary reporting says no services were added or removed and the main change is corrections to ResponseOnEvent (0x86). Review before relying on it. |

Each project must state which edition its OEM specification references. If it is not stated, assume the
baseline and flag the difference.

## Verification status

| Status | Meaning | Who may set it |
|---|---|---|
| `verified` | Checked against the ISO text of the stated edition. Entry carries a "Verified by" line (reviewer, edition, clause, date). | Only a person with access to the standard |
| `cross-checked` | Core structure confirmed by named public references (ISO previews, AUTOSAR DCM SWS, established open-source stacks). | Agent or engineer, listing the sources |
| `draft` | Written from engineering knowledge; structure believed correct but not checked. | Anyone |
| `oem` | Content comes from an OEM or project specification (document and version named). | Anyone |
| `withdrawn` | Not part of the baseline edition; kept for legacy ECUs. | Anyone |

Inline flags inside entries: `[unverified]`, `[edition-dependent]`, `[OEM-specific]`, `[illustrative]`.

## Service inventory

"Sub-fn" = the request carries a sub-function byte with the suppressPosRspMsgIndicationBit (bit 7).
Clause numbers are from the ISO 14229-1:2020 table of contents.

### Diagnostic and communication management (clause 10)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x10 | DiagnosticSessionControl | 0x50 | yes | 10.2 | ✓ | ✓ | [0x10](services/0x10-diagnostic-session-control.md) | cross-checked |
| 0x11 | ECUReset | 0x51 | yes | 10.3 | ✓ | ✓ | [0x11](services/0x11-ecu-reset.md) | cross-checked |
| 0x27 | SecurityAccess | 0x67 | yes | 10.4 | ✓ | ✓ | [0x27](services/0x27-security-access.md) | cross-checked |
| 0x28 | CommunicationControl | 0x68 | yes | 10.5 | ✓ | ✓ | [0x28](services/0x28-communication-control.md) | cross-checked |
| 0x29 | Authentication | 0x69 | yes | 10.6 | — | ✓ | [0x29](services/0x29-authentication.md) | cross-checked |
| 0x3E | TesterPresent | 0x7E | yes | 10.7 | ✓ | ✓ | [0x3E](services/0x3E-tester-present.md) | cross-checked |
| 0x83 | AccessTimingParameter | 0xC3 | yes | — | ✓ | withdrawn | [0x83](services/0x83-access-timing-parameter.md) | withdrawn |
| 0x85 | ControlDTCSetting | 0xC5 | yes | 10.8 | ✓ | ✓ | [0x85](services/0x85-control-dtc-setting.md) | cross-checked |
| 0x86 | ResponseOnEvent | 0xC6 | yes | 10.9 | ✓ | ✓ (changed) | [0x86](services/0x86-response-on-event.md) | draft |
| 0x87 | LinkControl | 0xC7 | yes | 10.10 | ✓ | ✓ | [0x87](services/0x87-link-control.md) | cross-checked |

### Data transmission (clause 11)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x22 | ReadDataByIdentifier | 0x62 | no | 11.2 | ✓ | ✓ | [0x22](services/0x22-read-data-by-identifier.md) | draft |
| 0x23 | ReadMemoryByAddress | 0x63 | no | 11.3 | ✓ | ✓ | [0x23](services/0x23-read-memory-by-address.md) | cross-checked |
| 0x24 | ReadScalingDataByIdentifier | 0x64 | no | 11.4 | ✓ | ✓ | [0x24](services/0x24-read-scaling-data-by-identifier.md) | draft |
| 0x2A | ReadDataByPeriodicIdentifier | 0x6A | no | 11.5 | ✓ | ✓ (updated) | [0x2A](services/0x2A-read-data-by-periodic-identifier.md) | draft |
| 0x2C | DynamicallyDefineDataIdentifier | 0x6C | yes | 11.6 | ✓ | ✓ | [0x2C](services/0x2C-dynamically-define-data-identifier.md) | cross-checked |
| 0x2E | WriteDataByIdentifier | 0x6E | no | 11.7 | ✓ | ✓ | [0x2E](services/0x2E-write-data-by-identifier.md) | draft |
| 0x3D | WriteMemoryByAddress | 0x7D | no | 11.8 | ✓ | ✓ | [0x3D](services/0x3D-write-memory-by-address.md) | cross-checked |

### Stored data transmission (clause 12)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x14 | ClearDiagnosticInformation | 0x54 | no | 12.2 | ✓ | ✓ (+MemorySelection) | [0x14](services/0x14-clear-diagnostic-information.md) | cross-checked |
| 0x19 | ReadDTCInformation | 0x59 | yes | 12.3 | ✓ | ✓ (changed) | [0x19](services/0x19-read-dtc-information.md) | draft |

### Input/output control (clause 13)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x2F | InputOutputControlByIdentifier | 0x6F | no | 13.2 | ✓ | ✓ | [0x2F](services/0x2F-input-output-control-by-identifier.md) | draft |

### Remote activation of routine (clause 14)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x31 | RoutineControl | 0x71 | yes | 14.2 | ✓ | ✓ | [0x31](services/0x31-routine-control.md) | draft |

### Upload / download (clause 15)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x34 | RequestDownload | 0x74 | no | 15.2 | ✓ | ✓ | [0x34](services/0x34-request-download.md) | draft |
| 0x35 | RequestUpload | 0x75 | no | 15.3 | ✓ | ✓ | [0x35](services/0x35-request-upload.md) | draft |
| 0x36 | TransferData | 0x76 | no | 15.4 | ✓ | ✓ | [0x36](services/0x36-transfer-data.md) | draft |
| 0x37 | RequestTransferExit | 0x77 | no | 15.5 | ✓ | ✓ | [0x37](services/0x37-request-transfer-exit.md) | draft |
| 0x38 | RequestFileTransfer | 0x78 | no | 15.6 | ✓ | ✓ | [0x38](services/0x38-request-file-transfer.md) | cross-checked |

### Security sub-layer (clause 16)

| SID | Service | Resp. | Sub-fn | Clause | 2013 | 2020 | Entry | Status |
|---|---|---|---|---|---|---|---|---|
| 0x84 | SecuredDataTransmission | 0xC4 | no | 16.2 | ✓ | ✓ (redefined) | [0x84](services/0x84-secured-data-transmission.md) | cross-checked |

### SID ranges outside UDS services

| Range | Use |
|---|---|
| 0x00–0x0F | OBD services (ISO 15031-5 / SAE J1979) — not UDS |
| 0x7F | Negative response SID |
| 0xBA–0xBE | System-supplier specific [unverified] |
| others | Reserved |

## ReadDTCInformation (0x19) sub-function index

Full detail in the [0x19 entry](services/0x19-read-dtc-information.md).

| Value | Name | 2013 | 2020 |
|---|---|---|---|
| 0x01 | reportNumberOfDTCByStatusMask | ✓ | ✓ |
| 0x02 | reportDTCByStatusMask | ✓ | ✓ |
| 0x03 | reportDTCSnapshotIdentification | ✓ | ✓ |
| 0x04 | reportDTCSnapshotRecordByDTCNumber | ✓ | ✓ |
| 0x05 | reportDTCStoredDataByRecordNumber | ✓ | ✓ |
| 0x06 | reportDTCExtDataRecordByDTCNumber | ✓ | ✓ |
| 0x07 | reportNumberOfDTCBySeverityMaskRecord | ✓ | ✓ |
| 0x08 | reportDTCBySeverityMaskRecord | ✓ | ✓ |
| 0x09 | reportSeverityInformationOfDTC | ✓ | ✓ |
| 0x0A | reportSupportedDTC | ✓ | ✓ |
| 0x0B | reportFirstTestFailedDTC | ✓ | ✓ |
| 0x0C | reportFirstConfirmedDTC | ✓ | ✓ |
| 0x0D | reportMostRecentTestFailedDTC | ✓ | ✓ |
| 0x0E | reportMostRecentConfirmedDTC | ✓ | ✓ |
| 0x0F | reportMirrorMemoryDTCByStatusMask | ✓ | withdrawn |
| 0x10 | reportMirrorMemoryDTCExtDataRecordByDTCNumber | ✓ | withdrawn |
| 0x11 | reportNumberOfMirrorMemoryDTCByStatusMask | ✓ | withdrawn |
| 0x12 | reportNumberOfEmissionsOBDDTCByStatusMask | ✓ | withdrawn |
| 0x13 | reportEmissionsOBDDTCByStatusMask | ✓ | withdrawn |
| 0x14 | reportDTCFaultDetectionCounter | ✓ | ✓ |
| 0x15 | reportDTCWithPermanentStatus | ✓ | ✓ |
| 0x16 | reportDTCExtDataRecordByRecordNumber | ✓ | ✓ (name per Amd 1:2022) |
| 0x17 | reportUserDefMemoryDTCByStatusMask | ✓ | ✓ |
| 0x18 | reportUserDefMemoryDTCSnapshotRecordByDTCNumber | ✓ | ✓ |
| 0x19 | reportUserDefMemoryDTCExtDataRecordByDTCNumber | ✓ | ✓ |
| 0x1A | reportSupportedDTCExtDataRecord | — | ✓ (new) |
| 0x42 | reportWWHOBDDTCByMaskRecord | ✓ | ✓ |
| 0x55 | reportWWHOBDDTCWithPermanentStatus | ✓ | ✓ |
| 0x56 | reportDTCInformationByDTCReadinessGroupIdentifier | — | ✓ (new) |

## Shared references

| File | Contents |
|---|---|
| [protocol-fundamentals.md](protocol-fundamentals.md) | Message structure, SPRMIB, addressing, sessions, timing, response pending, NRC evaluation order, security models, identifier ranges, ISO-TP, DoIP, troubleshooting matrix |
| [nrc-reference.md](nrc-reference.md) | All negative response codes with practical meaning |
| [dtc-reference.md](dtc-reference.md) | DTC formats, status byte, masks, groupOfDTC, snapshot/extended records, fault detection counter |
| [entry-template.md](entry-template.md) | Template for new entries |

## Adding or updating an entry

1. Read the current entry (or copy [entry-template.md](entry-template.md) to
   `services/0xNN-service-name.md`, uppercase hex, kebab-case name).
2. Keep the frontmatter keys and the eight numbered headings: what / why / purpose / use cases / how /
   formats / implementation and testing / standards and limitations.
3. Write in your own words; never paste ISO text or tables.
4. Mark single statements `[unverified]`, `[edition-dependent]`, `[OEM-specific]` or `[illustrative]`.
5. Do not replace `verified` or `cross-checked` content with unverified content; add it alongside and flag the
   conflict.
6. Put project or OEM facts under a "Project notes" heading with the source document and version.
7. Update the inventory row and status here; add a [verification log](#verification-log) row for anything you
   cross-checked.
8. Run `python .github/uds/tools/check_uds_catalogue.py` and fix all errors.

## Verification log

| Date | Item | Result | Source |
|---|---|---|---|
| 2026-10-26 | 2020 service list and clause numbers | Matches the inventory above; 0x83 absent from the 2020 TOC | ISO 14229-1:2020 preview (Foreword + TOC), standards.iteh.ai sample 72439 |
| 2026-10-26 | 2013→2020 changes (Authentication added, security sub-layer clause, unused 0x19 sub-functions removed, 0x2A updated) | Confirmed | ISO 14229-1:2020 preview Foreword |
| 2026-10-26 | 0x83 withdrawn in 2020; 0x19 0x0F–0x13 withdrawn; 0x1A and 0x56 new in 2020 | Confirmed | py-uds knowledge base (uds.readthedocs.io) |
| 2026-10-26 | 0x29 sub-function values 0x00–0x08 | Confirmed | py-uds knowledge base |
| 2026-10-26 | 0x14 MemorySelection (2020) and groupOfDTC values FFFF33 / FFFFD0 / FFFFFE / FFFFFF | Confirmed | py-uds knowledge base; Amd 1:2022 preview (NRC 0x31 for unsupported MemorySelection) |
| 2026-10-26 | DTCFormatIdentifier 0x00–0x04 | Confirmed | py-uds knowledge base; Amd 1:2022 preview (0x04 name) |
| 2026-10-26 | 0x19 0x16 name, snapshot record-number ranges, paged-buffer padding, DID 0xFF01 name | Confirmed | ISO 14229-1:2020/Amd 1:2022 preview, standards.iteh.ai sample 81380 |
| 2026-10-26 | ISO 14229-1:2026 published (4th ed., June 2026) | Confirmed | iso.org/standard/87962 |
| 2026-10-26 | 2026 changes: no services added/removed, ResponseOnEvent corrected | Secondary only | diadrom.com article on ISO 14229-1:2026 |
| 2026-10-26 | Field layouts of 0x23, 0x2C, 0x38, 0x3D (ALFID nibble order, 0x3D echo, 0x2C per-sub-function layouts, 0x38 mode fields incl. ResumeFile in 2020) | Consistent across implementations → entries set to cross-checked | py-uds source (github.com/mdabrowski1990/uds, separate 2013/2020 definitions), python-udsoncan, ArcCore AUTOSAR Dcm |
| 2026-10-26 | 0x19 request/response field order for 0x05, 0x09, 0x14, 0x16–0x1A, 0x42, 0x55, 0x56; DTCSeverity bits; FunctionalGroupIdentifier values; extended/stored-data record ranges | Secondary only (0x55 record size disputed between libraries) | py-uds source and knowledge base, python-udsoncan |
| 2026-10-26 | 0x2A transmissionMode 01 slow / 02 medium / 03 fast / 04 stop | Consistent | py-uds, ArcCore Dcm_Types.h |
| 2026-10-26 | 0x24 scalingByte types: 0x2 bitMappedReportedWithOutMask carries a mask extension, 0x3 does not | Corrected in entry | py-uds source |
| 2026-10-26 | maxNumberOfBlockLength counts SID + block counter | Secondary only (one walkthrough of the ISO message-flow example) | damodev.csdn.net |
| 2026-10-26 | 2013 and 2020 annex letters (C data identifiers, E IO control, F routine identifiers, G upload/download, H ALFID examples) | From preview TOCs | ISO 14229-1:2013 / 2020 previews (webstore.ansi.org) |
| 2026-10-26 | Request/response layouts of 0x10, 0x11, 0x27, 0x28, 0x29, 0x3E, 0x84, 0x85, 0x87 (incl. 0x27 sub-function ranges, 0x29 field order and return values, 0x84 envelope sizes, 0x87 mode identifiers) | Consistent → entries set to cross-checked; 0x28 bit order and 0x29 certificateEvaluationId size disputed between libraries | py-uds translator source, python-udsoncan source |
| 2026-10-26 | 0x86 in 2020: 0x02 onTimerInterrupt removed, 0x08 / 0x09 added, eventWindowTime kept on control requests | Secondary only; entry stays draft | py-uds constants and test vectors |
| 2026-10-26 | NRC names incl. 0x36 exceedNumberOfAttempts, 0x38–0x3A secure data transmission NRCs, 0x50–0x5D, 0x94 | Consistent | py-uds NRC list, python-udsoncan |

**Do not use pyudskit.readthedocs.io as a source.** Review found at least four errors there (0x2A mode 01
shown as stop, reversed ALFID nibbles, missing 0x3D echo, 0x38 modes limited to 01–04).

## Open items

- Review ISO 14229-1:2026 against this catalogue, starting with ResponseOnEvent (0x86).
- Confirm with the full 2020 text: NRC evaluation order figure, functional-addressing NRC suppression list,
  0x19 extended-data record-number ranges (Annex D.8 — secondary source found, ISO text still needed),
  0x19 0x55 record size, 0x2A initial response and type 1 / type 2 periodic formats, 0x86 control-request
  format and end-of-window response, 0x28 communicationType bit order, 0x29 certificateEvaluationId size,
  0x84 administrative-parameter bit numbering and inner negative responses, whether 0x71 carries a
  routineInfo byte, maxNumberOfBlockLength definition, 0x2F controlEnableMask presence with parameters
  00–02, which states each session transition resets (0x10 table).
- Add a "Project notes" subsection to each entry used by a project, linking the OEM spec version.
