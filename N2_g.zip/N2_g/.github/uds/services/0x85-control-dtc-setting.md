---
sid: 0x85
name: ControlDTCSetting
response_sid: 0xC5
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.8 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview TOC (cdn.standards.iteh.ai sample 72439) — clause number and functional unit only"
  - "py-uds translator source (github.com/mdabrowski1990/uds: service_definitions/control_dtc_setting.py, utilities/constants/subfunctions.py, data_record_definitions/other.py) — DTCSettingType 01 on / 02 off, optional DTCSettingControlOptionRecord of 0..n raw bytes, response = echo only"
  - "udsoncan documentation (udsoncan.readthedocs.io) — setting_type on (1) / off (2), optional DTCSettingControlOptionRecord"
  - "Engineering knowledge — OEM/supplier ranges, option record content, session behaviour (not cross-checked)"
---

# 0x85 — ControlDTCSetting

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0xC5
> Tells the server to stop (off) or resume (on) updating DTC status bits, so that planned disturbances do not
> fill the fault memory.

## 1. What is it?

ControlDTCSetting (SID 0x85) switches DTC status-bit updating in the server on or off. The sub-function is the
**DTCSettingType**: `0x01` on, `0x02` off. An optional **DTCSettingControlOptionRecord** can follow; when the
server supports it, it usually holds a 3-byte groupOfDTC that limits the request to one DTC group.

While setting is off, the server's fault monitors may keep running, but the DTC status bits (and the records
that depend on status changes) are not updated. DTCs neither set nor heal. The service changes nothing that is
already stored. The DTC status model is in [../dtc-reference.md](../dtc-reference.md).

## 2. Why is it needed?

Some diagnostic work disturbs the vehicle in ways the ECUs read as faults:

- During **flashing**, ECUs in the bootloader stop sending their network messages. Every other ECU would log
  lost-communication DTCs (U-codes).
- During **validation tests** that drive undervoltage, bus-off, sensor disconnection or actuator tests, the
  side effects would set DTCs that are not part of the test.
- On the **production line**, stations power ECUs in partial configurations (some nodes missing).

Clearing DTCs afterwards (0x14) is not enough. The fault memory loses evidence of real faults, occurrence and
ageing counters change, and some ECUs (safety, emissions) restrict clearing. ControlDTCSetting prevents the
entries from appearing in the first place. Value: production line, flashing tools, HIL/validation teams.

## 3. What is its purpose?

It suspends and resumes the DTC status update process, globally or for one group. It does not clear DTCs, does
not stop fault reactions (warning lamps, degraded modes, deployment inhibition in a restraint ECU) unless the
OEM ties them to DTC status [OEM-specific], and does not stop the ECU from transmitting.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| The test checks that a DTC is set or healed | Leave DTC setting on | Off hides exactly what you want to observe |
| DTC memory must be emptied | ClearDiagnosticInformation (0x14) | 0x85 never removes entries |
| Stop network messages of other ECUs during flashing | CommunicationControl (0x28) | 0x85 does not affect communication |
| Read what is stored | ReadDTCInformation (0x19) | 0x85 has no read function |
| Be told when a DTC changes | ResponseOnEvent ([0x86](0x86-response-on-event.md)) | Note: no event fires while setting is off |

<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Network flashing with a restraint ECU on the bus
- **Scenario:** A body ECU is flashed over CAN. The airbag control unit (ACU) stays in its application and
  would log a lost-communication DTC for the body ECU. Restraint ECUs often restrict clearing of such codes.
- **Engineer's objective:** Flash without leaving DTCs in non-target ECUs.
- **Why this service:** One functional request suppresses DTC setting on all ECUs at once.
- **Tester sends:** Functional `10 83`, then `85 82` (off, SPRMIB set), then `28 83 01` (illustrative
  CommunicationControl), then the physical programming sequence to the target.
- **ECU is expected to:** Accept silently, stop status updates until it returns to the default session or
  resets.
- **Engineer obtains:** A clean fault memory in all ECUs after the flash.
- **Test on success / failure:** After the post-flash `11 01` and functional `85 81` / `10 81`, read
  `19 02 FF` on the ACU. No new U-code = pass. A new U-code means the ACU ignored the functional request or
  re-enabled setting too early.

### Use case: HIL undervoltage profile test on a non-restraint ECU
- **Scenario:** A validation engineer tests a feature's behaviour during an engine-crank voltage dip. The
  dip is expected to set undervoltage DTCs that are covered by a different test case.
- **Engineer's objective:** Keep the fault memory free of known side effects so later checks in the same
  test run are not polluted.
- **Why this service:** It stops DTC updates for the duration of the stimulus only.
- **Tester sends:** `10 03`, `85 02`, voltage profile, `85 01`.
- **ECU is expected to:** Answer `C5 02` and `C5 01`; no status bit changes while off.
- **Engineer obtains:** Feature behaviour without new DTCs.
- **Test on success / failure:** `19 02 FF` before and after shows identical status bytes. Remember that
  turning setting back on lets monitors that still see a fault set the DTC immediately.

### Use case: Group-selective suppression (if the ECU supports the option record)
- **Scenario:** Development ECU whose spec supports the groupOfDTC option record.
- **Engineer's objective:** Suppress only one DTC group during a stimulus and keep all others live.
- **Why this service:** The option record narrows the effect; 0x14 or a global off would hide too much.
- **Tester sends:** `85 02 FF FF D0` (illustrative: safety-system group only).
- **ECU is expected to:** Stop updates for that group only, or reject with `7F 85 31` / `7F 85 13` if the
  record is not supported.
- **Engineer obtains:** Proof of which groups the record really covers.
- **Test on success / failure:** A DTC outside the group still sets while the group is suppressed.

<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. Tester sends `85 <DTCSettingType> [option record]`.
2. Server checks session, sub-function, length, option record and conditions.
3. Server stops or resumes updating DTC status bits and replies `C5 <DTCSettingType>` unless SPRMIB is set.
4. The off state is volatile. It ends with `85 01`, an ECUReset, power loss, or a transition to the default
   session (including S3 timeout) [unverified — confirm the exact rule in the edition and OEM spec]. Between two
   non-default sessions (e.g. extended → programming) it is commonly kept, which is what flash sequences rely
   on; some stacks re-enable it when the new session does not support 0x85 [unverified].
5. When setting resumes, monitors evaluate normally again. A fault that is still present will set its DTC.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Non-default (extended); rejected in default session | Typical; OEM confirms |
| Security / authentication | Usually none | OEM |
| ECU operating conditions | Usually none; some OEMs block it while driving | OEM |
| Timing (P2 / P2* / S3) | Fast service; no 0x78 expected. S3 expiry ends the off state | ISO 14229-2 / OEM |

**Depends on:** DiagnosticSessionControl (0x10) for the session; TesterPresent (0x3E) to hold the session;
functional addressing on the transport ([../protocol-fundamentals.md](../protocol-fundamentals.md#functional-vs-physical-addressing)).
In AUTOSAR stacks the Dcm calls the Dem to disable/enable DTC setting; re-enabling on session change is done by
the Dcm [unverified].

<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x85 |
| 2 | DTCSettingType (sub-function) | 1 | bit 7 = SPRMIB, bits 6–0 = type (table below) |
| 3… | DTCSettingControlOptionRecord | 0 or n | Optional raw bytes (py-uds, udsoncan). Content and support are OEM-defined; a 3-byte groupOfDTC is one common use [unverified] |

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | reserved | — | — | Expect 0x12 |
| 0x01 | on | Resume DTC status updating | End of flashing, end of disturbing test | Also implicit on reset / return to default session [unverified] |
| 0x02 | off | Stop DTC status updating | Before flashing, before planned disturbances | Volatile state |
| 0x03–0x3F | reserved | — | — | Expect 0x12 [unverified range] |
| 0x40–0x5F | vehicleManufacturerSpecific | OEM-defined | — | [unverified range] |
| 0x60–0x7E | systemSupplierSpecific | Supplier-defined | — | [unverified range] |
| 0x7F | reserved | — | — | Expect 0x12 |

Values 0x01 / 0x02 cross-checked (py-uds translator, udsoncan docs); range boundaries are engineering knowledge.

SPRMIB is commonly set (`85 81`, `85 82`) when the request is sent functionally. See
[../protocol-fundamentals.md](../protocol-fundamentals.md#sub-function-byte-and-sprmib).

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0xC5 |
| 2 | DTCSettingType | 1 | Echo of request byte 2 with bit 7 cleared |

No option record is echoed.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | DTCSettingType not implemented (e.g. 0x03) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request shorter than 2 bytes, or option record length wrong / present when the server does not accept one |
| 0x22 | conditionsNotCorrect | OEM precondition fails (e.g. vehicle moving) |
| 0x31 | requestOutOfRange | Option record value not supported (unknown group) |
| 0x33 | securityAccessDenied | Only if the OEM protects the service |
| 0x34 | authenticationRequired | Only on 2020 ECUs that gate the service with Authentication (0x29) |
| 0x7E | subFunctionNotSupportedInActiveSession | Type supported, but not in this session |
| 0x7F | serviceNotSupportedInActiveSession | Service called in the default session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 10 03                    # extendedDiagnosticSession
POS 50 03 00 32 01 F4        # P2 50 ms, P2* 5000 ms (illustrative)
REQ 85 02                    # DTC setting off
POS C5 02                    # accepted
REQ 85 01                    # DTC setting on
POS C5 01                    # accepted
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ | 85 | ControlDTCSetting |
| REQ | 02 | DTCSettingType off, SPRMIB 0 → response expected |
| POS | C5 | Positive response (0x85 + 0x40) |
| POS | 02 | Echo of off |
| REQ/POS | 85 01 / C5 01 | Same for on |

```uds
NOTE functionally addressed, pre-programming sequence
REQ 85 82                    # off with SPRMIB: no positive response from any ECU
NOTE silence is the expected result; only NRCs that are not suppressed for functional requests may appear
```

| Byte | Value | Meaning |
|---|---|---|
| 1 | 85 | ControlDTCSetting |
| 2 | 82 | SPRMIB (bit 7) = 1, type = 0x02 off |

```uds
REQ 85 02 FF FF D0           # off for the safety-system group only (option record support is OEM-specific)
POS C5 02
REQ 85 02 FF FF              # option record one byte short
NEG 7F 85 13                 # length / format wrong
REQ 10 01                    # back to default session
POS 50 01 00 32 01 F4        # (illustrative timing)
REQ 85 02                    # not allowed in default session
NEG 7F 85 7F
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 1 | 85 02 | off |
| REQ 1 | FF FF D0 | groupOfDTC 0xFFFFD0 safety-system group ([../dtc-reference.md](../dtc-reference.md)) |
| POS 1 | C5 02 | Accepted |
| REQ 2 | 85 02 FF FF | Two-byte record, invalid |
| NEG | 7F 85 13 | incorrectMessageLengthOrInvalidFormat |
| REQ 3/POS | 10 01 / 50 01 … | Default session; DTC setting returns to on [unverified] |
| NEG | 7F 85 7F | serviceNotSupportedInActiveSession |

<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- Builder: `control_dtc_setting(setting: on|off|int, option_record: bytes = b"", suppress: bool = False)`.
  Reject values above 0x7F. Do not add an option record unless the ECU spec defines one.
- Parser: check `C5`, check echo equals `setting & 0x7F`. Accept exactly 2 bytes; flag extra bytes.
- Flash tools: send the off request functionally with SPRMIB and do not wait for responses. Always send `on`
  in a `finally` path, plus return to default session, so an aborted run does not leave DTC setting off.
- Test frameworks: wrap disturbing stimuli in a context manager (off on entry, on on exit). Log the state.
- Edge cases: S3 expiry silently re-enables DTC setting [unverified]; re-enabling while a fault is still active
  sets the DTC at once; ROE onDTCStatusChange does not fire while off.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive off/on | Extended session, `85 02`, `85 01` | `C5 02`, `C5 01` |
| 2 | Off really stops updates | `85 02`, inject a fault for longer than its qualification time, `19 02 FF` | No new DTC / no status change |
| 3 | On resumes | Then `85 01`, keep fault | DTC qualifies after its normal debounce time |
| 4 | Unsupported type | `85 00`, `85 03`, `85 7F` | `7F 85 12` |
| 5 | Session matrix | `85 02` in default / extended / programming / OEM sessions | `7F 85 7F` in default; per OEM matrix elsewhere |
| 6 | Session fallback | `85 02`, let S3 expire (no TesterPresent), inject fault | DTC sets (off ended) [unverified rule] |
| 7 | Reset | `85 02`, `11 01`, inject fault | DTC sets |
| 8 | Non-default to non-default | `85 02` in extended, `10 02` (or OEM session) | Behaviour as per OEM spec; record it [unverified] |
| 9 | Security / authentication matrix | `85 02` locked and unlocked; on 2020 ECUs authenticated / not | Usually positive in all; `7F 85 33` / `7F 85 34` only if OEM requires |
| 10 | Length min-1 | `85` | `7F 85 13` |
| 11 | Length min | `85 02` | `C5 02` |
| 12 | Length max (option record) | `85 02 FF FF FF` | `C5 02` if supported, else `7F 85 13` / `7F 85 31` per spec |
| 13 | Length max+1 | `85 02 FF FF FF 00` | `7F 85 13` |
| 14 | Option record value | `85 02 12 34 56` (illustrative, unknown group) | `7F 85 31` if records supported |
| 15 | SPRMIB physical | `85 82` physical | No response; state is off (verify with test 2) |
| 16 | SPRMIB + NRC | `85 83` physical | `7F 85 12` still sent |
| 17 | Functional | `85 82` functional | No response; all ECUs off |
| 18 | Functional unsupported type | `85 83` functional | No response (0x12 suppressed functionally) |
| 19 | Conditions | `85 02` with OEM precondition false | `7F 85 22` if defined |
| 20 | Interaction 0x14 | `85 02`, `14 FF FF FF` | Clear still works [unverified]; status reset to post-clear value |
| 21 | Interaction 0x19 | `85 02`, `19 02 FF` | Reads work; status frozen |

Response pending and multi-frame do not apply (2–5 byte messages, fast processing).

<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.8 (functional unit: diagnostic and communication management) |
| Edition differences | No 2013 ↔ 2020 change known to this entry [unverified] [edition-dependent]. 2026 edition not yet reviewed |
| OEM / ECU-specific | Session matrix, option record support and content, preconditions, whether fault reactions (lamps, inhibition) follow DTC status, behaviour across non-default session changes |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: clause number and functional unit (2020 preview TOC); DTCSettingType 0x01 on / 0x02 off, optional raw DTCSettingControlOptionRecord, echo-only response (py-uds translator source, udsoncan docs). Not cross-checked: reserved / OEM / supplier range boundaries, option record content, reset rules on session change |
| Open questions | Exact rule for re-enabling on session transitions; whether fault detection counters keep running while off; whether 0x14 is accepted while off on the target ECU |

<!-- catalogue field 15 -->
