---
sid: 0x2E
name: WriteDataByIdentifier
response_sid: 0x6E
has_sub_function: false
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.7 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number and functional unit"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x2E, response SID 0x6E, writes data into the server at a location given by a DID"
---

# 0x2E — WriteDataByIdentifier

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x6E
> Writes one data record into the ECU under a 2-byte data identifier (DID).

## 1. What is it?

WriteDataByIdentifier (WDBI), SID 0x2E, is the write counterpart of 0x22. The tester sends one DID and its
complete new data record. The ECU checks it, stores it (in RAM, EEPROM or data flash, depending on the DID) and
confirms with the DID echo.

Exactly one DID per request. The record length is fixed by the ECU's DID definition; partial writes are not
part of the service.

## 2. Why is it needed?

- ECUs leave the supplier generic. The vehicle-specific data (VIN, variant coding, configuration, calibration
  selectors) must be written on the line or in the workshop.
- A DID-based write keeps the tester independent of memory layout, unlike 0x3D.
- The ECU can check the value (range, checksum, plausibility) before accepting it, which a raw memory write
  does not do.

Who benefits: production lines (VIN, coding, fingerprint), workshops (coding after ECU replacement), validation
teams (setting variants and configurations on a HIL bench), development teams.

## 3. What is its purpose?

It changes stored data. It returns no data except the DID echo. It does not execute actions (use 0x31), does
not control outputs (use 0x2F), and does not flash software (use 0x34/0x36/0x37).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Read a value | [0x22 ReadDataByIdentifier](0x22-read-data-by-identifier.md) | Read-only |
| Start an action (self-test, erase, learn) | 0x31 RoutineControl | Actions are routines, not data |
| Drive an actuator temporarily | 0x2F InputOutputControlByIdentifier | Temporary override, returned to ECU control |
| Write raw memory without a DID (development) | [0x3D WriteMemoryByAddress](0x3D-write-memory-by-address.md) | Address-based |
| Write a software or large data image | 0x34 RequestDownload, 0x36, 0x37 | Block transfer, flash handling |

## 4. When is it used? — Real use cases

### Use case: Writing the VIN at end of line
- **Scenario:** Production line, after the ECU is fitted in the vehicle.
- **Engineer's objective:** Store the vehicle's VIN in the ECU and confirm it.
- **Why this service:** 0xF190 is the ISO VIN DID; writing it is a standard EOL step.
- **Tester sends:** `10 03`, security unlock (OEM-defined level), `2E F1 90` + 17 ASCII bytes, then `22 F1 90`.
- **ECU is expected to:** Possibly send `7F 2E 78` while writing to EEPROM, then `6E F1 90`.
- **Engineer obtains:** Confirmation and a read-back for the production record.
- **Test on success / failure:** Pass if the read-back equals the written VIN, also after a reset. Many OEMs
  allow the VIN to be written once only or only in a specific session [OEM-specific].

### Use case: Variant coding of an airbag ECU on a HIL bench
- **Scenario:** Restraint ECU validation; the same ECU is tested in several vehicle variants (with or without
  passenger airbag deactivation, number of squib loops, network configuration).
- **Engineer's objective:** Put the ECU into the variant under test before each test suite.
- **Why this service:** The variant coding record is an OEM DID written with 0x2E.
- **Tester sends:** `10 03`, unlock, `2E 47 20` + coding record (DID and content illustrative), `11 01`,
  then `22 47 20`.
- **ECU is expected to:** Accept the record, apply it after reset, show matching content on read-back, and set or
  clear configuration-related DTCs accordingly.
- **Engineer obtains:** ECU configured for the variant.
- **Test on success / failure:** Pass if read-back matches and no configuration-mismatch DTC is present. NRC 0x31
  means the record content is rejected (invalid bit combination or checksum).

Note: some restraint projects use DID **0x0103** for a network-management (NM) configuration record. That DID
and its layout are **OEM-specific**, not defined by ISO 14229-1 [OEM-specific]. Do not treat 0x0103 as an ISO
DID or assume its meaning on another project.

## 5. How does it work?

1. Tester sends `2E`, a DID and the full record.
2. ECU checks the length (minimum 4 bytes; must equal 3 + DID record length), DID support for writing in the
   active session, security, conditions, then the record content. General NRC order:
   [../protocol-fundamentals.md](../protocol-fundamentals.md).
3. ECU writes the record. RAM writes finish at once. EEPROM / data-flash writes may take longer than P2.
4. ECU sends `6E` + DID echo once the write is complete [unverified: some ECUs confirm before the NVM commit].

**EEPROM write latency and 0x78.** Writing NVM can take tens to hundreds of milliseconds, depending on size,
erase needs and the NVM manager's queue. If the write cannot finish within P2, the ECU must send
`7F 2E 78` and then the final response within P2* (and further 0x78s if needed). Testers that time out on P2
only will report false failures. Values: [../protocol-fundamentals.md](../protocol-fundamentals.md).

**When does the value take effect?** Some DIDs apply at once; configuration and coding DIDs often apply only
after ECU reset (0x11) [OEM-specific]. A write may also be lost if power is removed before the NVM manager
commits it.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Extended or programming; almost never default | OEM |
| Security / authentication | 0x27 unlock (level per DID) or 0x29 role in 2020 ECUs | OEM |
| ECU operating conditions | Vehicle stationary, voltage in range, engine off, sometimes write-once flags | OEM |
| Timing (P2 / P2* / S3) | 0x78 + P2* for NVM writes | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** 0x10, 0x27/0x29, 0x22 for read-back, 0x11 when the DID applies after reset, ISO-TP for records
longer than one frame.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x2E |
| 2–3 | dataIdentifier | 2 | Big-endian DID |
| 4 … | dataRecord | DID-defined | Complete new record |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the high byte of the DID.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x6E |
| 2–3 | dataIdentifier | 2 | Echo of the written DID |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Fewer than 4 bytes, or record length differs from the DID definition |
| 0x22 | conditionsNotCorrect | OEM conditions not met (speed, voltage, engine running, write-once already used) |
| 0x31 | requestOutOfRange | DID not writable or not supported in session; record content invalid (range, checksum, enumeration) |
| 0x33 | securityAccessDenied | Required security level not unlocked |
| 0x34 | authenticationRequired | 2020 ECUs requiring 0x29 [edition-dependent] [unverified] |
| 0x72 | generalProgrammingFailure | NVM write failed (EEPROM error, verify failure) |
| 0x78 | requestCorrectlyReceived-ResponsePending | Write takes longer than P2 |
| 0x7F | serviceNotSupportedInActiveSession | Service not allowed in the current session (default) |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

VIN write with response pending.

```uds
REQ 2E F1 90 58 58 54 45 53 54 30 30 30 30 30 30 30 30 30 30 31   # VIN "XXTEST00000000001" (illustrative)
NEG 7F 2E 78            # EEPROM write in progress
POS 6E F1 90            # written
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 1 | 2E | WriteDataByIdentifier |
| REQ 2–3 | F1 90 | DID VIN |
| REQ 4–20 | 58 … 31 | 17 ASCII bytes (illustrative VIN) |
| NEG | 7F 2E 78 | Response pending; tester switches to P2* |
| POS 1 | 6E | Positive response (0x2E + 0x40) |
| POS 2–3 | F1 90 | DID echo |

Variant coding record. DID 0x4720 and contents are (illustrative).

```uds
REQ 2E 47 20 03 01 00 A5   # coding record (illustrative)
POS 6E 47 20
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 2–3 | 47 20 | OEM coding DID (illustrative) |
| REQ 4 | 03 | e.g. variant index (illustrative) |
| REQ 5 | 01 | e.g. passenger airbag deactivation fitted (illustrative) |
| REQ 6 | 00 | reserved (illustrative) |
| REQ 7 | A5 | e.g. checksum byte (illustrative) |
| POS | 6E 47 20 | Accepted |

Negative responses.

```uds
REQ 2E F1 90 58 58 54   # VIN too short
NEG 7F 2E 13
REQ 2E 47 20 07 01 00 A5   # variant index invalid (illustrative)
NEG 7F 2E 31
REQ 2E F1 88 ..         # read-only DID
NEG 7F 2E 31
REQ 2E 47 20 03 01 00 A5   # not unlocked
NEG 7F 2E 33
REQ 2E 47 20 03 01 00 A5   # vehicle moving (illustrative OEM condition)
NEG 7F 2E 22
REQ 2E 47 20 03 01 00 A5   # NVM write fails
NEG 7F 2E 78
NEG 7F 2E 72
```

| Exchange | Problem | NRC |
|---|---|---|
| 1 | 6 bytes instead of 20 | 13 |
| 2 | Content outside allowed values | 31 |
| 3 | DID 0xF188 not writable | 31 |
| 4 | Security locked | 33 |
| 5 | OEM condition not met | 22 |
| 6 | Pending, then NVM failure | 78 then 72 |

## 7. Implementation and testing

**Implementation:**
- Builder: DID plus bytes; validate the length against the DID table before sending. Use typed encoders per
  DID (ASCII for VIN, bit fields for coding) instead of raw byte strings in tests.
- Timeout: P2 for the first answer; after each 0x78 restart with P2*. Count 0x78s and fail above a sane limit.
- Always read back with 0x22 and compare. For DIDs that apply after reset, read back after the reset too.
- Keep a copy of the original value and restore it in teardown, especially VIN and coding on shared benches.
- Write-once DIDs: never run destructive tests on the only sample; check the OEM rules first.
- Functional addressing: writes are normally physical only. Do not broadcast coding.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive write + read-back | Valid record | `6E` + DID; 0x22 returns the record |
| 2 | Persistence | Write, `11 01`, read | Value survives reset |
| 3 | Power loss after positive response | Write, cut power at once, read | Value retained (checks commit before response) |
| 4 | Length min-1 | `2E F1 90` (no data) | `7F 2E 13` |
| 5 | Length record-1 | 16-byte VIN | `7F 2E 13` |
| 6 | Length record | 17-byte VIN | Positive |
| 7 | Length record+1 | 18-byte VIN | `7F 2E 13` |
| 8 | Content range | Each invalid value, checksum wrong | `7F 2E 31` |
| 9 | Read-only DID | `2E F1 88 ..` | `7F 2E 31` |
| 10 | Unsupported DID | Unknown DID | `7F 2E 31` |
| 11 | Session matrix | Default, extended, programming | Default `7F 2E 7F`; others per OEM spec |
| 12 | Security matrix | Locked, wrong level, correct level | `7F 2E 33`, `7F 2E 33`, positive |
| 13 | Authentication (2020) | Not authenticated | `7F 2E 34` [edition-dependent] |
| 14 | Conditions | Each OEM condition violated | `7F 2E 22` |
| 15 | Write-once | Second VIN write (if OEM rule) | `7F 2E 22` or `7F 2E 31` per OEM spec |
| 16 | Response pending | NVM DID | `7F 2E 78` then positive within P2* |
| 17 | NVM failure | Fault-inject NVM error (if bench allows) | `7F 2E 72` |
| 18 | Multi-frame | Record longer than 7 bytes on classic CAN | ISO-TP segmented request accepted |
| 19 | Functional addressing | Write to functional ID | Ignored or rejected per OEM spec |
| 20 | Effect | Coding DID, then reset | ECU behaviour and DTCs match the new configuration |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.7 (data transmission functional unit). |
| Edition differences | No layout change between 2013 and 2020 known [unverified]. 2020 authentication may add NRC 0x34 [edition-dependent] [unverified]. 2026 edition not yet reviewed. |
| OEM / ECU-specific | Writable DIDs and record layouts (coding, configuration, NM configuration such as 0x0103 on some restraint projects); sessions; security levels; write-once rules; when values take effect; NVM timing. |
| Verification status | draft. Cross-checked: clause number, SID/response SID, purpose (py-uds). NRC list, 0x78 handling and practice from engineering knowledge. |
| Open questions | Whether ISO requires the positive response only after the NVM commit; exact NRC for write-once violations; whether 0x72 is listed for this service in 2020 or only commonly used. |
