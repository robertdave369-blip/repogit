---
sid: 0x19
name: ReadDTCInformation
response_sid: 0x59
has_sub_function: true
functional_unit: "Stored data transmission (clause 12)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "12.3 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause 12.3, functional unit, removal of unused 0x19 sub-functions"
  - "py-uds knowledge base (uds.readthedocs.io): SID 0x19 / 0x59, 2020 sub-function list, 0x0F-0x13 withdrawn, 0x1A and 0x56 new in 2020"
  - "ISO 14229-1:2020/Amd 1:2022 preview (sample 81380): 0x16 name, DTCSnapshotRecordNumber and UserDefDTCSnapshotRecordNumber ranges, DTCFormatIdentifier 0x04 name, paged-buffer padding rule, Annex D confirmation threshold default"
  - "py-uds source (github.com/mdabrowski1990/uds, uds/translator/data_record_definitions/conditional.py and dtc.py; uds/utilities/constants/dtc.py), secondary: 2020 request/response field order for 0x05, 0x09, 0x14, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x42, 0x55, 0x56"
  - "py-uds knowledge base (uds.readthedocs.io, DTC and Diagnostic Service pages), secondary: DTCSeverity bit names, FunctionalGroupIdentifier values, DTCExtDataRecordNumber and DTCStoredDataRecordNumber ranges, 0x05 / 0x09 / 0x0B-0x0E / 0x14 record presence conditions"
  - "python-udsoncan (github.com/pylessard/python-udsoncan, udsoncan/services/ReadDTCInformation.py), secondary: field order for 0x17, 0x18, 0x19, 0x42, 0x55; 0x16 record number limited to 0xEF; 0xFF FunctionalGroupIdentifier comment"
---

# 0x19 — ReadDTCInformation

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x59
> Reads the ECU's fault memory: which DTCs exist, their status bits, and the snapshot, stored and extended data
> recorded with them.

## 1. What is it?

ReadDTCInformation, SID 0x19, is the UDS service for reading fault memory. The tester picks a **report type**
with the sub-function byte. Each report type answers a different question about diagnostic trouble codes (DTCs):

- **How many / which DTCs** match a status mask (0x01, 0x02, 0x0A, 0x15, 0x17).
- **Which data was captured** with a DTC: snapshot (freeze-frame) records (0x03, 0x04, 0x18), stored-data
  records (0x05), extended data records such as counters (0x06, 0x16, 0x19, 0x1A).
- **How severe** a DTC is (0x07, 0x08, 0x09) and, for WWH-OBD, which functional group or readiness group it
  belongs to (0x42, 0x55, 0x56).
- **Ordering and debouncing**: first / most recent failed or confirmed DTC (0x0B–0x0E), and the fault
  detection counter of DTCs that are failing but not yet qualified (0x14).

Every DTC is a 3-byte number plus a 1-byte status. Status bit definitions, DTC formats and record-number ranges
live in [../dtc-reference.md](../dtc-reference.md); this entry explains how 0x19 uses them. The service only
reads: clearing is [0x14](0x14-clear-diagnostic-information.md), freezing DTC updates is
[0x85](0x85-control-dtc-setting.md).

## 2. Why is it needed?

ECU monitors detect, debounce and qualify faults, store DTCs and capture the conditions at that moment. 0x19 is
the standard way to read all of that back.

- **Why not 0x22?** A DID returns one fixed record. Fault memory is a run-time, variable-length list that needs
  filtering (status, severity, memory) and links each DTC to its own records (DTC + record number).
- **Why so many sub-functions?** Each user asks a different question: production wants a count, a workshop wants
  confirmed DTCs and freeze frames, validation wants faults still debouncing, OBD inspection wants emissions
  DTCs only. One report type per question keeps responses small and unambiguous.
- **Who gets value:** ECU developers (debounce tuning), validation/HIL teams (fault-injection verdicts),
  production lines (fault-free check), workshops (repair), inspection tools (legislated OBD data).

## 3. What is its purpose?

0x19 is the read side of the diagnostic fault-handling model. It tells the tester whether a fault is present
now (bit 0), failed this cycle (bit 1), is pending (bit 2) or confirmed/stored (bit 3), and whether it requests
a warning lamp (bit 7). It returns the context of a fault (snapshot DIDs, counters, OEM data), the DTC
configuration (0x0A, 0x1A) and debouncing in progress (0x14). It does **not** clear DTCs, start monitors,
change thresholds, trigger a self-test, or read the live value of the faulty signal.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Erase DTCs and their records | [0x14 ClearDiagnosticInformation](0x14-clear-diagnostic-information.md) | 0x19 is read-only |
| Stop DTCs from setting during flashing or a provoking test | [0x85 ControlDTCSetting](0x85-control-dtc-setting.md) | Freezes status updates |
| Get told when a DTC status changes instead of polling | [0x86 ResponseOnEvent](0x86-response-on-event.md) (onDTCStatusChange) | Event-driven; ECU support is rare |
| Read the live value behind a DTC (loop resistance, voltage) | [0x22 ReadDataByIdentifier](0x22-read-data-by-identifier.md) | 0x19 gives captured values, not live ones |
| Run the self-test that sets or heals a DTC | [0x31 RoutineControl](0x31-routine-control.md) (OEM routine) | 0x19 cannot trigger monitors |
| Read crash / event data recorder content | 0x22 with OEM EDR DIDs [OEM-specific] | EDR data is not part of the DTC model |
| Legislated OBD on non-UDS OBD (ISO 15031 / SAE J1979 modes) | OBD modes 0x03 / 0x07 / 0x0A | Different protocol; outside this catalogue |
| Mirror memory on a 2020 ECU | 0x17–0x19 with an OEM MemorySelection | Mirror-memory sub-functions withdrawn in 2020 |

## 4. When is it used? — Real use cases

### Use case: End-of-line fault memory check
- **Scenario:** Production line, after flashing, coding and the electrical function test of an ECU or vehicle.
- **Engineer's objective:** Ship no vehicle with a stored or active fault, except a known allowed list (for
  example network DTCs caused by nodes not yet fitted at the station).
- **Why this service:** `19 01` gives a single-frame count for a fast pass/fail. `19 02` then names the DTCs
  only if the count is not zero. `19 0A` confirms that the coded variant has the expected DTC set.
- **Tester sends:** `19 01 09` → if count > 0: `19 02 09` → compare with allowed list → `14 FF FF FF` →
  `19 02 09` again.
- **ECU is expected to:** Return availability mask, DTC format and count; then the list; empty after the clear.
- **Engineer obtains:** Count, DTC list, availability mask (a fingerprint of the variant's fault handling).
- **Test on success / failure:** Pass if no DTC outside the allowed list has bit 0 or bit 3 set. Fail on any
  other DTC, a changed availability mask, or a `19 0A` list that does not match the coded variant (for an
  airbag ECU, for example, a squib DTC present for a squib position the vehicle does not have) [illustrative].

### Use case: Workshop repair of an intermittent fault
- **Scenario:** Customer complaint: warning lamp came on and went off. The workshop tester is connected.
- **Engineer's objective:** Find the DTC, decide whether the fault is real and where it happened.
- **Why this service:** `19 02` finds confirmed DTCs. `19 04` returns the freeze frame (odometer, voltage,
  time). `19 06` returns counters that show how often it happened. No other service links data to a DTC.
- **Tester sends:** `19 02 08` → `19 04 <DTC> FF` → `19 06 <DTC> FF`.
- **ECU is expected to:** List the DTC (for example status `0x28`, historic), then its snapshot and extended records.
- **Engineer obtains:** A low supply voltage in the snapshot plus occurrence counter 1 points to a one-off
  voltage dip, not a broken component [illustrative interpretation].
- **Test on success / failure:** After repair: `14 FF FF FF`, drive cycle, `19 02 08` empty → repair verified.

### Use case: HIL fault injection on an airbag ECU (squib open circuit)
- **Scenario:** HIL bench, restraint control ECU, squib loops replaced by resistor decades or a fault insertion
  unit. The test opens the driver stage-1 loop. DTC `9A 11 13` = B1A11-13 and availability mask `0xFF` are
  (illustrative); the qualification and healing times come from the OEM fault-handling spec.
- **Engineer's objective:** Prove that the DTC qualifies within the specified time, reports the right status
  bits while active, heals correctly, and stays as a historic DTC after the fault is removed.
- **Why this service:** Only 0x19 shows the status bits. `19 14` shows the debounce in progress. `19 06`
  shows the occurrence counter.
- **Tester sends:** `14 FF FF FF` → ignition cycle → open loop → `19 14` during debounce → wait qualification
  time + margin → `19 02 FF` → close loop → wait healing time → `19 02 FF` → ignition cycle → `19 02 FF`.
- **ECU is expected to:** Follow the status sequence below (typical Annex D behaviour, confirmation threshold 0;
  [unverified] — OEM strategies for bits 2, 5 and 7 differ).

  | Step | Bench state | Expected status (avail 0xFF) | Bits | Same step, avail 0x0B (bits 0,1,3 only) | Reading |
  |---|---|---|---|---|---|
  | 0 | After clear, cycle started, monitor ran, loop OK | `0x00` (DTC only in `19 0A`) | — | `0x00` | No fault |
  | 1 | Loop open, before qualification time | `0x00`; `19 14` lists the DTC with FDC 0x01–0x7E | — | `0x00`; `19 14` as for 0xFF | Pre-failed |
  | 2 | Loop open, after qualification time | `0xAF` | 0,1,2,3,5,7 | `0x0B` | **Active**, lamp requested |
  | 3 | Loop closed, after healing time | `0x2E` (`0xAE` if the lamp stays on) | 1,2,3,5 (+7) | `0x0A` | **Healed** this cycle |
  | 4 | Next ignition cycle, monitor ran and passed | `0x2C` (`0x6C` before the monitor completes) | 2,3,5 (+6) | `0x08` | Historic, still pending |
  | 5 | One more fault-free cycle | `0x28` | 3,5 | `0x08` | **Historic** (stored) |
  | 6 | Ageing threshold reached [OEM-specific] | `0x20` or DTC no longer confirmed | 5 | `0x00` (DTC only in `19 0A`) | Aged |

  **Reduced-bit ECUs (illustrative, OEM-specific).** Many restraint ECUs support fewer status bits. The
  0x0B column shows the same bench sequence on an ECU whose DTCStatusAvailabilityMask is `0x0B`: active `0x0B`,
  healed in the same operation cycle `0x0A`, after an ignition cycle `0x08` (the same values as the "seen in
  practice" table in [../dtc-reference.md](../dtc-reference.md#2-dtc-status-byte)). Every value in that column is the
  0xFF value ANDed with `0x0B`, so one expected table plus the masked comparison in section 7
  (`(actual & avail) == (expected & avail)`) covers both ECUs. What the 0x0B ECU cannot show: pending vs
  historic (steps 4 and 5 look the same), "failed since clear" after ageing, and the lamp request (bit 7) —
  check the lamp on its output or bus signal instead. After a clear, `19 02 FF` on this ECU returns an empty
  list, not every DTC with `0x50`. As on any ECU, take the step-2 read only after the maximum qualification
  time plus margin (or poll `19 02 01` until it appears, bounded by that time); a read inside the
  qualification window can legitimately show `0x00` and is not a verdict.

- **Engineer obtains:** Time-to-qualify, status per step, FDC behaviour, occurrence counter from `19 06`.
- **Test on success / failure:** Compare only on supported and specified bits (see section 7). Fail if bit 0 is
  set before the minimum qualification time, not set after the maximum, if bit 3 is lost after healing, or if
  bit 0 remains set after the healing time. A read at step 2 taken *before* qualification is a test-design
  error, not an ECU defect.

### Use case: Nightly regression on a HIL rack
- **Scenario:** Automated test suite (Python framework or CANoe test units) running hundreds of test cases.
- **Engineer's objective:** Catch any unexpected DTC a test case leaves behind; keep test cases independent.
- **Why this service:** `19 02 FF` (or `19 0A`) after each test case gives a full status picture that can be
  diffed against an expected set. `19 01 FF` is a cheap pre-check.
- **Tester sends:** Setup: `14 FF FF FF`. After each test: `19 02 FF`. On failure: `19 04 <DTC> FF` and
  `19 06 <DTC> FF` for the log.
- **ECU is expected to:** Report only the DTCs the test case provoked, plus known rest-bus DTCs.
- **Engineer obtains:** A per-test DTC diff, raw and decoded records attached to the report.
- **Test on success / failure:** Fail the test case on any DTC not in its expected set (ignoring a configured
  allow list); fail the run on parser errors (unknown record length, leftover bytes).

## 5. How does it work?

1. Tester sends `19 <reportType> <parameters>`; parameter count depends on the report type (section 6).
2. ECU checks session, sub-function, length, parameter values (DTC, record number, MemorySelection, group) and
   conditions. General NRC order: [../protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order).
3. ECU filters its fault memory and answers `59 <reportType>` + a fixed header + zero or more records. Nothing in
   fault memory changes.
4. The transport layer segments large responses; some ECUs fill them page by page while sending (see below).

### Status mask logic

For the mask-based reports (0x01, 0x02, 0x07, 0x08, 0x17, 0x42; withdrawn 0x0F, 0x11, 0x12, 0x13), the ECU reports a
DTC when `(statusOfDTC & DTCStatusMask) != 0`. Bits the ECU does not support are always 0 in `statusOfDTC`, so
in effect the filter is `statusOfDTC & (DTCStatusMask & DTCStatusAvailabilityMask)`.

Consequences:

- A mask that only contains unsupported bits returns an **empty positive** response, not an NRC.
- The response carries the **DTCStatusAvailabilityMask**: byte 3 for 0x01, 0x02, 0x07–0x0E, 0x15 and 0x1A;
  byte 4 for 0x17, 0x42, 0x55 and 0x56 (after MemorySelection or FunctionalGroupIdentifier); not present in
  0x03–0x06, 0x14, 0x16, 0x18 and 0x19. Read it first and use it to choose masks and to compare status bytes.
- `0xFF` is **not** "all DTCs". It returns every DTC that has at least one supported bit set. A DTC whose
  status is `0x00` (tested, passed, never failed) is not reported. Use `19 0A` for every supported DTC.
- Right after a clear, bits 4 and 6 are set on every DTC (if supported), so `19 02 FF` returns the whole DTC
  list with status `0x50`. This surprises many first-time test writers. On an ECU without bits 4 and 6 (for
  example avail `0x0B`) the same read returns an empty list.

| Mask | Bits | Returns | Typical user |
|---|---|---|---|
| `0x01` | testFailed | DTCs failing right now (active) | HIL verdict "fault active", live monitoring |
| `0x04` | pendingDTC | Failed this or last cycle, not necessarily confirmed | Emissions-style pending check |
| `0x08` | confirmedDTC | Stored DTCs (active or historic) | Workshop, EOL |
| `0x09` | testFailed or confirmedDTC | Active or stored | EOL, OEM tester default on many ECUs |
| `0x20` | testFailedSinceLastClear | Anything that failed since the last clear, even if aged (unless the OEM ageing strategy also clears bit 5) | Regression "did anything happen?" |
| `0x80` | warningIndicatorRequested | DTCs requesting a lamp | Lamp-logic tests (airbag warning lamp) |
| `0xFF` | all | Any DTC with any supported bit set | Full picture in regression logs |
| `0x00` | none | By the filter rule nothing matches → empty positive `59 02 <avail>` [unverified]. Some ECUs answer NRC 0x31. Some AUTOSAR-style Dem implementations use 0x00 internally as "no status filter" (e.g. Arctic Core `DEM_DTC_STATUS_MASK_ALL`), so a stack that passes 0x00 through may return every DTC [unverified] — record which | Boundary test only |

Full bit definitions and set/clear rules: [../dtc-reference.md](../dtc-reference.md#2-dtc-status-byte).

### Record types: snapshot, stored data, extended data

| | Snapshot (freeze frame) | Stored data | Extended data |
|---|---|---|---|
| Sub-functions | 0x03, 0x04, 0x18 | 0x05 | 0x06, 0x16, 0x19, 0x1A |
| Keyed by | DTC + DTCSnapshotRecordNumber | DTCStoredDataRecordNumber (record holds its own DTC) | DTC + DTCExtDataRecordNumber |
| Captured | On a status event the OEM chooses (first failure, most recent failure, confirmation…) | Same kind of event; records form a list not tied to one DTC | Maintained over time (counters updated on each event or cycle) |
| Wire layout | Record number, number of identifiers, then DID + data per identifier | Record number, DTC + status, number of identifiers, DID + data | Record number, then raw bytes — **no DID, no length** |
| Self-describing? | Partly: DIDs are visible, but each DID's data length comes from the description | Same as snapshot | No: the record length must come from the description |
| Content defined by | OEM / ECU diagnostic description | OEM / ECU | OEM / ECU (some record numbers reserved for legislated use) |

Record-number ranges (Amd 1:2022, cross-checked; also in
[../dtc-reference.md](../dtc-reference.md#4-snapshot-stored-data-and-extended-data-records)):

| Parameter | Manufacturer-specific | Legislated / reserved | All records |
|---|---|---|---|
| DTCSnapshotRecordNumber | 0x01–0xEF, 0xF1–0xFE | 0x00, 0xF0 legislated | 0xFF |
| UserDefDTCSnapshotRecordNumber | 0x00–0xFE | — | 0xFF |
| DTCExtDataRecordNumber | 0x01–0x8F | 0x90–0x9F regulated emissions OBD, 0xA0–0xEF regulated; 0x00 and 0xF0–0xFD reserved | 0xFF all; 0xFE all regulated emissions OBD records |
| DTCStoredDataRecordNumber | 0x01–0xFE (a specific record) | 0x00 legislated | 0xFF |

The two lower rows follow the py-uds knowledge base (secondary source, not the ISO text); the Annex D.8
ranges were not read directly [unverified against ISO]. They agree with
[../dtc-reference.md](../dtc-reference.md#4-snapshot-stored-data-and-extended-data-records) where that file gives
values (0xFE, 0xFF).

**Decode records with the project's diagnostic description, never by guessing.**

- CANoe/CANalyzer: the CDD (or imported ODX/PDX) defines per DTC the snapshot DIDs and the extended records with
  lengths and scaling; the diagnostic console and CAPL diagnostic objects decode from it.
- ODX: snapshot content is environment data linked to the DTCs; extended records have their own data object
  definitions [unverified element names].
- Python: build `record number → length/codec` and `DID → length/codec` tables from the same description;
  without them a 0x19 parser can only return raw bytes.
- No description: report raw bytes, say the layout is unknown, and do not split extended records — one wrong
  length shifts every following record.

### Fault detection counter (0x14)

The fault detection counter (FDC) is a signed 8-bit value per DTC that shows debounce progress:

| FDC (hex) | Signed | Meaning |
|---|---|---|
| `0x7F` | +127 | Failed: debounce complete, testFailed (bit 0) set |
| `0x01`–`0x7E` | +1…+126 | **Pre-failed**: failing condition seen, not yet qualified |
| `0x00` | 0 | Neutral (typical after clear or operation-cycle start [unverified]) |
| `0x81`–`0xFF` | −127…−1 | Pre-passed: passing condition seen, not yet fully passed |
| `0x80` | −128 | Passed: debounce complete in the passing direction |

Which DTCs `19 14` lists is not settled here. Secondary sources describe it as DTCs with a **positive** FDC
(py-uds) that are not yet reported or confirmed; a common reading is "pre-failed only, 0x01–0x7E", so a DTC
appears while it debounces and leaves once it qualifies (it then shows bit 0 in `19 02 01`). Whether a DTC
at +127 (failed) or a confirmed DTC that is debouncing again is still listed differs between
implementations [unverified; see [../dtc-reference.md](../dtc-reference.md#5-fault-detection-counter-0x19-0x14)].
Write tests that accept the OEM's stated rule. Counter-based or time-based debounce, step sizes and
jump-to-zero behaviour are OEM-defined. Monitors that qualify in one step (no debounce) never show up in
`19 14`.

### Permanent DTCs (0x15)

An OBD concept: a confirmed emissions-relevant DTC that 0x14 cannot erase; the ECU removes it itself once the
monitor has passed under the required conditions. Non-OBD ECUs (most restraint ECUs) usually answer `19 15`
with 0x12 [OEM-specific].

### User-defined memory (0x17–0x19)

Besides the primary memory, an ECU may keep secondary, development or supplier memories. The 1-byte
**MemorySelection** picks one; values and meaning are OEM-defined [OEM-specific]; an unsupported value gives
NRC 0x31. It replaces the mirror-memory report types withdrawn in 2020 (0x0F–0x11). 0x14 gained an optional
MemorySelection in 2020 for the same memories.

### WWH-OBD: functional group, severity, readiness (0x42, 0x55, 0x56)

These serve world-wide harmonised OBD (WWH-OBD; also OBD on UDS per SAE J1979-2 [unverified]). They filter by
a **FunctionalGroupIdentifier** — `0x33` emissions-system group, `0xD0` safety-system group, `0xFE` VOBD
system; per py-uds also `0xD1`–`0xDF` legislative system groups and the rest reserved (secondary source). These
match the low byte of the 0x14 groupOfDTC values. `0xFF` is reserved in ISO 14229-1 but defined as "all
functional system groups" in ISO 27145-3 (python-udsoncan comment) [unverified] — do not send it to a
UDS-only ECU except as a negative test. The responses report the DTC format, so a generic scan tool can read
any ECU. **Severity** (0x07–0x09, 0x42) carries urgency and class per DTC. **Readiness groups** (0x56, new in
2020) group DTCs by monitor family; their identifiers come from the OBD standards (SAE J1979-DA per py-uds),
not ISO 14229-1.

### Large responses and the paged buffer

- 4 bytes per DTC: `19 0A` with 300 DTCs is 3 + 1200 = 1203 bytes. Classic ISO-TP carries up to 4095 bytes; more
  needs the escape First Frame or DoIP ([../protocol-fundamentals.md](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials)).
  If the ECU cannot buffer or send the whole response it answers NRC 0x14.
- **Paged buffer:** the ECU announces the total length in the First Frame, then fills the frames from fault
  memory while sending. If DTCs disappear during sending (for example another client clears them), the ECU
  cannot shorten the message. Amd 1:2022 states that it pads the remaining space with DTC `00 00 00` and status
  `00` (cross-checked). Where the padding sits (at the end vs in place of the removed record) was not
  cross-checked; parse padding records anywhere in the list [unverified]. The tester must drop them. DTCs that
  appear during sending are not in this response; the next read shows them [unverified].

### Preconditions

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Default and extended; often not in programming session (bootloader); some OEMs restrict report types 0x14 and 0x17–0x19 to extended | Service: ISO. Per-sub-function list: OEM |
| Security / authentication | Normally none; user-defined or supplier memories sometimes secured | OEM |
| ECU operating conditions | Usually none; some ECUs answer 0x22 while fault memory is still loading from NVM after start-up, or at low voltage | OEM [unverified] |
| Timing (P2 / P2* / S3) | First frame within P2; snapshot/extended reads from external NVM may use 0x78 and P2* | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md#timing) |
| Fault-handling state | Results depend on operation cycle, ControlDTCSetting state, time since fault injection | OEM fault-handling spec |

**Depends on:** ISO-TP / DoIP segmentation for most responses; 0x10 for session-restricted report types;
0x14 and 0x85 for test set-up; the ECU's diagnostic description (ODX/CDD) to decode records; the OEM
fault-handling spec (qualification, healing, ageing, operation-cycle definition) to interpret status changes.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x19 |
| 2 | reportType (sub-function) | 1 | Bits 6–0: report type (table below). Bit 7: SPRMIB — the 0x19 sub-function byte carries it like any sub-function (py-uds lists it in the 0x19 request formats); suppressing a read is pointless, see examples |
| 3 … | Report-type parameters | 0–5 | Depends on report type; total length per report type in the "Len" note below |

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x01 | reportNumberOfDTCByStatusMask | Count of DTCs matching a status mask | EOL quick check, polling | Len 3. Single frame; includes DTC format |
| 0x02 | reportDTCByStatusMask | List of DTCs + status matching a mask | Workshop, HIL, regression | Len 3. Most used report type |
| 0x03 | reportDTCSnapshotIdentification | All (DTC, snapshot record number) pairs stored | Find which freeze frames exist | Len 2. No status in response |
| 0x04 | reportDTCSnapshotRecordByDTCNumber | Snapshot records of one DTC | Freeze-frame analysis | Len 6. DID-based content |
| 0x05 | reportDTCStoredDataByRecordNumber | Stored-data records by record number | Event lists, legislated freeze frame | Len 3. Rare outside OBD |
| 0x06 | reportDTCExtDataRecordByDTCNumber | Extended data records of one DTC | Counters (occurrence, ageing) | Len 6. Lengths from description |
| 0x07 | reportNumberOfDTCBySeverityMaskRecord | Count by severity and status | Severity-based dashboards | Len 4. Rare |
| 0x08 | reportDTCBySeverityMaskRecord | DTCs + severity + functional unit by masks | Prioritised repair lists | Len 4. Rare |
| 0x09 | reportSeverityInformationOfDTC | Severity + functional unit of one DTC | Tester UI detail | Len 5. Rare |
| 0x0A | reportSupportedDTC | Every supported DTC with status | Configuration check, regression | Len 2. Can be long |
| 0x0B | reportFirstTestFailedDTC | Earliest failed DTC since clear | Root-cause ordering | Len 2. 0 or 1 DTC |
| 0x0C | reportFirstConfirmedDTC | Earliest confirmed DTC since clear | Root-cause ordering | Len 2. 0 or 1 DTC |
| 0x0D | reportMostRecentTestFailedDTC | Latest failed DTC | "What just happened?" | Len 2. 0 or 1 DTC |
| 0x0E | reportMostRecentConfirmedDTC | Latest confirmed DTC | "What just got stored?" | Len 2. 0 or 1 DTC |
| 0x14 | reportDTCFaultDetectionCounter | Pre-failed DTCs with their FDC | Debounce tuning, glitch tests | Len 2. No availability mask |
| 0x15 | reportDTCWithPermanentStatus | Permanent DTCs | OBD inspection | Len 2. Usually OBD ECUs only |
| 0x16 | reportDTCExtDataRecordByRecordNumber | One extended record across all DTCs | Fleet-style counter dump | Len 3. Name per Amd 1:2022 |
| 0x17 | reportUserDefMemoryDTCByStatusMask | Like 0x02 for a user-defined memory | Secondary / supplier memory | Len 4. MemorySelection OEM-defined |
| 0x18 | reportUserDefMemoryDTCSnapshotRecordByDTCNumber | Like 0x04 for a user-defined memory | Secondary memory freeze frames | Len 7 |
| 0x19 | reportUserDefMemoryDTCExtDataRecordByDTCNumber | Like 0x06 for a user-defined memory | Secondary memory counters | Len 7 |
| 0x1A | reportSupportedDTCExtDataRecord | DTCs that support a given extended record | Configuration check | Len 3. New in 2020 |
| 0x42 | reportWWHOBDDTCByMaskRecord | WWH-OBD DTCs by group, status, severity | OBD scan tools | Len 5. WWH-OBD / OBDonUDS |
| 0x55 | reportWWHOBDDTCWithPermanentStatus | WWH-OBD permanent DTCs by group | OBD inspection | Len 3 |
| 0x56 | reportDTCInformationByDTCReadinessGroupIdentifier | DTCs of one readiness group | OBD readiness checks | Len 4. New in 2020 |

"Len" = total request length in bytes including SID; any other length gives NRC 0x13. All other report-type
values are reserved (or withdrawn, see below) and give NRC 0x12. Values and names are as listed in the 2020
edition (cross-checked). Request and response field order in the subsections was compared with two
open-source implementations (py-uds, python-udsoncan; secondary sources, see section 8) and agrees with them
unless a disagreement is marked; it was not checked against the ISO text.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x59 |
| 2 | reportType | 1 | Echo of the sub-function, bit 7 cleared |
| 3 … | Fixed header | 0–4 | Report-type specific: DTCStatusAvailabilityMask, DTCFormatIdentifier, MemorySelection, FunctionalGroupIdentifier, record number |
| … | Records | n × record | Zero or more; length depends on the report type and on the description |

Building blocks used below:

| Block | Bytes | Content | Used by |
|---|---|---|---|
| DTCAndStatusRecord | 4 | DTC (3, high byte first) + statusOfDTC | 02, 0A–0E, 15, 17, 1A, 55, 56; inside 04, 05, 06, 09, 16, 18, 19 |
| DTCCount | 2 | Number of matching DTCs, big-endian | 01, 07 |
| DTCAndSeverityRecord | 6 | DTCSeverity, DTCFunctionalUnit, DTC (3), statusOfDTC | 08, 09 |
| WWH-OBD DTC record | 5 | DTCSeverity, DTC (3), statusOfDTC | 42 (55 too in python-udsoncan; py-uds uses 4-byte records for 55) |
| DTCFaultDetectionCounterRecord | 4 | DTC (3) + FDC | 14 |
| Snapshot record | variable | Record number, number of identifiers, then (DID 2 bytes + data) per identifier | 04, 18 |
| Stored-data record | variable | Record number, DTCAndStatusRecord, number of identifiers, (DID + data)… | 05 |
| Extended data record | variable | Record number + OEM-defined bytes | 06, 19 (16 carries the number once in the header) |

### Sub-function details

All examples use one illustrative ECU unless stated: availability mask `0xFF`, DTCFormatIdentifier `0x01`,
DTC `9A 11 13` = B1A11-13 (driver squib stage 1, circuit open — illustrative; failure type 0x13 "circuit open"
per SAE J2012-DA [unverified]), DTC `91 01 13` = B1101-13 (illustrative, historic). Snapshot DIDs `0x4721`
(supply voltage, 1 byte, 0.1 V/bit) and `0x4722` (odometer, 4 bytes, km) are (illustrative). Extended records
`0x01` occurrence counter (1 byte), `0x02` ageing counter (1 byte), `0x10` minutes since first failure
(2 bytes) are (illustrative).

#### 0x01 — reportNumberOfDTCByStatusMask

- **Returns:** the number of DTCs matching the status mask, plus the availability mask and the DTC format.
- **Question answered:** "Is there anything, and how much?" — without transferring the list.
- **Use case:** EOL station checks `19 01 09` in a few milliseconds per ECU; only on a non-zero count does it ask
  for the list. Not 0x02, because a single frame is faster and easier to judge.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 01` |
| 3 | DTCStatusMask | Bits to match |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 01` |
| 3 | DTCStatusAvailabilityMask | Supported status bits |
| 4 | DTCFormatIdentifier | 0x00–0x04, see [../dtc-reference.md](../dtc-reference.md#1-dtc-number) |
| 5–6 | DTCCount | Big-endian |

```uds
REQ 19 01 08            # count confirmed DTCs
POS 59 01 FF 01 00 02   # 2 confirmed DTCs (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 3 | 08 | Mask: confirmedDTC |
| POS 3 | FF | All 8 status bits supported (illustrative) |
| POS 4 | 01 | ISO_14229-1_DTCFormat |
| POS 5–6 | 00 02 | Count = 2 |

- **Notes and test points:** The count must equal the number of records `19 02` returns for the same mask (unless
  fault memory changed in between). A count of 0 is a positive response, not an NRC. Response length is fixed
  at 6 bytes. This is also the cheapest way to learn the availability mask and DTC format before any other read.
- **Edition notes:** No layout change known between 2013 and 2020 [unverified].

#### 0x02 — reportDTCByStatusMask

- **Returns:** every DTC whose status matches the mask, each with its status byte.
- **Question answered:** "Which faults are active / stored / pending?"
- **Use case:** Workshop tester lists confirmed DTCs (`19 02 08`); HIL test checks the active fault
  (`19 02 01`) after its qualification time. Not 0x0A, because 0x02 filters out irrelevant DTCs and keeps the
  response short.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 02` |
| 3 | DTCStatusMask | Bits to match |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 02` |
| 3 | DTCStatusAvailabilityMask | Supported bits |
| 4 … | DTCAndStatusRecord × n | 4 bytes each; n may be 0 |

```uds
REQ 19 02 08                          # confirmed DTCs
POS 59 02 FF 9A 11 13 AF 91 01 13 28  # one active, one historic (illustrative)
REQ 19 02 01                          # active only
POS 59 02 FF 9A 11 13 AF
REQ 19 02 10                          # bit 4: monitors not completed since clear
POS 59 02 FF                          # empty list: availability mask only
NOTE second ECU (illustrative) that supports only bits 0 and 3
REQ 19 02 FF
POS 59 02 09 9A 11 13 09 91 01 13 08  # only bits 0 and 3 can ever be set
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4–6 | 9A 11 13 | B1A11-13 (illustrative) |
| POS 7 | AF | 1010 1111: bits 0,1,2,3,5,7 — active, confirmed, lamp requested |
| POS 8–10 | 91 01 13 | B1101-13 (illustrative) |
| POS 11 | 28 | 0010 1000: bits 3,5 — historic |
| 3rd POS | 59 02 FF | No DTC with bit 4 set; still a positive response |
| 4th POS 3 | 09 | Second ECU: only testFailed and confirmedDTC supported |
| 4th POS 7 | 09 | Active and confirmed — the equivalent of `0xAF` on the first ECU |
| 4th POS 11 | 08 | Confirmed, not failing — historic |

- **Notes and test points:** Response length must be 3 + 4n. DTC order is not defined by the standard —
  compare as a set [unverified]. The same DTC must not appear twice. Status of each DTC must match the one
  `19 0A` reports at the same time. Mask with only unsupported bits → empty positive.
- **Edition notes:** No layout change known [unverified]. Paged-buffer padding (Amd 1:2022) applies to long lists.

#### 0x03 — reportDTCSnapshotIdentification

- **Returns:** a list of (DTC, DTCSnapshotRecordNumber) pairs for every snapshot record currently stored.
- **Question answered:** "Which freeze frames exist, for which DTCs?"
- **Use case:** A tester or test script first discovers which snapshot records exist, then fetches only those
  with 0x04. Not 0x04 with `FF` for every DTC, because that needs one request per DTC.

Request: `19 03` — no parameters.

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 03` |
| 3 … | (DTC 3 bytes + DTCSnapshotRecordNumber 1 byte) × n | 4 bytes each; n may be 0 |

```uds
REQ 19 03
POS 59 03 9A 11 13 01 9A 11 13 02 91 01 13 01   # three records stored (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3–6 | 9A 11 13 01 | B1A11-13 has snapshot record 0x01 (e.g. first occurrence, OEM convention) |
| POS 7–10 | 9A 11 13 02 | B1A11-13 has snapshot record 0x02 (e.g. most recent occurrence) |
| POS 11–14 | 91 01 13 01 | B1101-13 has snapshot record 0x01 |

- **Notes and test points:** No availability mask and no status in this response. Empty response is `59 03`.
  After `14 FF FF FF` the list must be empty. A DTC that confirms must add its pairs here. Record numbers 0x00
  and 0xF0 indicate legislated records (Amd 1:2022).
- **Edition notes:** Record-number meanings per Amd 1:2022 (see section 5). Layout unchanged [unverified].

#### 0x04 — reportDTCSnapshotRecordByDTCNumber

- **Returns:** for one DTC, its status and one or all snapshot records, each with the DIDs captured.
- **Question answered:** "Under which conditions did this fault occur?"
- **Use case:** Workshop technician sees B1A11-13 and checks the supply voltage and odometer in the freeze frame
  to tell a wiring fault from a voltage dip. HIL test checks that the snapshot really captured the injected
  condition (e.g. voltage set to 9.0 V on the bench). Not 0x05, because 0x04 is keyed by the DTC the
  technician already has.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 04` |
| 3–5 | DTCMaskRecord | The DTC number |
| 6 | DTCSnapshotRecordNumber | One record, or `FF` = all |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 04` |
| 3–6 | DTCAndStatusRecord | DTC echo + current status |
| 7 | DTCSnapshotRecordNumber | First record |
| 8 | DTCSnapshotRecordNumberOfIdentifiers | Number of DIDs in this record |
| 9 … | DID (2) + data (DID-defined) | Repeated per identifier |
| … | Further records | Same structure, when `FF` was requested |

```uds
REQ 19 04 9A 11 13 FF
POS 59 04 9A 11 13 AF 01 02 47 21 7C 47 22 00 01 2C 3A 02 02 47 21 79 47 22 00 01 2C 41
REQ 19 04 91 01 13 FF      # DTC supported, but no snapshot stored (illustrative)
POS 59 04 91 01 13 28      # DTC and status only, no records
REQ 19 04 12 34 56 FF      # DTC not supported by this ECU (illustrative)
NEG 7F 19 31
REQ 19 04 9A 11 13 05      # record number not defined for this DTC (illustrative)
NEG 7F 19 31
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3–5 | 9A 11 13 | DTC echo |
| POS 6 | AF | Current status (not the status at capture time) |
| POS 7 | 01 | Snapshot record 0x01 |
| POS 8 | 02 | Two DIDs follow |
| POS 9–10 | 47 21 | DID 0x4721 supply voltage (illustrative) |
| POS 11 | 7C | 124 × 0.1 V = 12.4 V (illustrative scaling) |
| POS 12–13 | 47 22 | DID 0x4722 odometer (illustrative) |
| POS 14–17 | 00 01 2C 3A | 76858 km (illustrative) |
| POS 18 | 02 | Snapshot record 0x02 |
| POS 19 | 02 | Two DIDs follow |
| POS 20–21, 22 | 47 21, 79 | 12.1 V |
| POS 23–24, 25–28 | 47 22, 00 01 2C 41 | 76865 km |
| 2nd POS | 59 04 91 01 13 28 | Valid DTC, nothing captured (after clear, or OEM stores no snapshot for it) |
| 3rd, 4th NEG | 7F 19 31 | Unknown DTC number; record number not supported for this DTC |

- **Notes and test points:** The number-of-identifiers byte lets a parser count DIDs, but it still needs each
  DID's data length from the description. What `0x00` means there is not settled: some engineers read it as
  "count not given / more than 255 DIDs" [unverified], while python-udsoncan rejects a zero count as a
  malformed record. If it occurs, fall back to description-driven parsing and log it. Records may come in any order [unverified]. Check that
  snapshot values match the bench conditions at the moment of capture, and that capture happens at the OEM's
  trigger (first failure vs confirmation).
- **Edition notes:** Amd 1:2022 reserves 0x00 and 0xF0 for legislated use; 0x01–0xEF and 0xF1–0xFE are
  manufacturer-specific; 0xFF = all (cross-checked). 2013 ranges may differ [edition-dependent] [unverified].

#### 0x05 — reportDTCStoredDataByRecordNumber

- **Returns:** stored-data records selected by record number; each record names its own DTC and status, followed
  by DIDs and data.
- **Question answered:** "What did stored-data record N capture, and for which DTC?"
- **Use case:** An ECU keeps a small ring of event records independent of which DTC caused them; a developer reads
  record `FF` to see the last few events in order. Also used for legislated freeze-frame records [unverified]. Not
  0x04, because the tester does not know the DTC in advance.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 05` |
| 3 | DTCStoredDataRecordNumber | One record (0x01–0xFE; 0x00 legislated), or `FF` = all (py-uds, secondary) |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 05` |
| 3 | DTCStoredDataRecordNumber | Record number |
| 4–7 | DTCAndStatusRecord | DTC that triggered the record + current status |
| 8 | DTCStoredDataRecordNumberOfIdentifiers | Number of DIDs |
| 9 … | DID (2) + data | Repeated per identifier |
| … | Further records | When `FF` was requested |

```uds
REQ 19 05 01
POS 59 05 01 9A 11 13 AF 01 47 21 7C   # record 1 was triggered by B1A11-13 (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | 01 | Record number |
| POS 4–7 | 9A 11 13 AF | DTC and its current status |
| POS 8 | 01 | One DID |
| POS 9–11 | 47 21 7C | Supply voltage 12.4 V (illustrative) |

- **Notes and test points:** An empty but supported record is answered with only the record number
  (`59 05 01`): py-uds shows DTC and status as present only when a record is stored, and python-udsoncan accepts
  the record number without a DTC (both secondary; not checked against the ISO text). Unsupported record
  number → 0x31. Few non-OBD ECUs implement 0x05; expect 0x12.
- **Edition notes:** No layout change known [unverified]. Older tools (python-udsoncan) use the older name
  reportDTCSnapshotRecordByRecordNumber for 0x05 [edition-dependent]; same value, same layout.

#### 0x06 — reportDTCExtDataRecordByDTCNumber

- **Returns:** for one DTC, its status and one or all extended data records.
- **Question answered:** "How often, how long ago, how close to ageing?" — whatever counters the OEM defined.
- **Use case:** HIL test opens a squib loop three times and checks that the occurrence counter reads 3 and the
  ageing counter resets on each new failure. Workshop uses the occurrence counter to judge an intermittent
  fault. Not 0x16, because the question is about one DTC, not one counter across all DTCs.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 06` |
| 3–5 | DTCMaskRecord | The DTC number |
| 6 | DTCExtDataRecordNumber | One record; `FF` all; `FE` all regulated emissions OBD records (ranges in section 5) |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 06` |
| 3–6 | DTCAndStatusRecord | DTC echo + current status |
| 7 | DTCExtDataRecordNumber | First record number |
| 8 … | DTCExtDataRecord | OEM-defined bytes, **no length field** |
| … | Further (number + data) pairs | When `FF`/`FE` was requested |

```uds
REQ 19 06 9A 11 13 FF
POS 59 06 9A 11 13 AF 01 03 02 00 10 00 5A   # three records of different length (illustrative)
REQ 19 06 9A 11 13 01
POS 59 06 9A 11 13 AF 01 03                  # occurrence counter only
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3–6 | 9A 11 13 AF | DTC and status |
| POS 7–8 | 01 03 | Record 0x01, occurrence counter = 3 (1 byte, illustrative) |
| POS 9–10 | 02 00 | Record 0x02, ageing counter = 0 (1 byte, illustrative) |
| POS 11–13 | 10 00 5A | Record 0x10, 90 minutes since first failure (2 bytes, illustrative) |

- **Notes and test points:** Without the record length table the parser cannot know that record 0x10 is 2 bytes —
  a guess shifts everything after it. Records defined but not yet stored may be left out of an `FF` response or
  filled with initial values [unverified, OEM-specific]. Unknown DTC or unsupported record number → 0x31. `FE` on
  a non-OBD ECU → 0x31 or empty [unverified]. Counter tests: increment per new failure (not per frame), saturation
  value, reset on 0x14.
- **Edition notes:** Extended record-number ranges (section 5) come from py-uds, not from the ISO annex
  [unverified against ISO].

#### 0x07 — reportNumberOfDTCBySeverityMaskRecord

- **Returns:** count of DTCs matching both a severity mask and a status mask, with availability mask and format.
- **Question answered:** "How many urgent faults are stored?"
- **Use case:** A fleet or service tool shows "2 faults need immediate attention" before downloading details.
  Rarely implemented on passenger-car ECUs [OEM-specific].

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 07` |
| 3 | DTCSeverityMask | Severity bits to match |
| 4 | DTCStatusMask | Status bits to match |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 07` |
| 3 | DTCStatusAvailabilityMask | |
| 4 | DTCFormatIdentifier | |
| 5–6 | DTCCount | Big-endian |

A DTC counts when `(status & DTCStatusMask) != 0` **and** `(severity & DTCSeverityMask) != 0` [unverified].

DTCSeverityMask / DTCSeverity / DTCSeverityAvailabilityMask bits (py-uds knowledge base and source,
secondary; not checked against the ISO text):

| Bit | Mask | Meaning |
|---|---|---|
| 7 | 0x80 | checkImmediately |
| 6 | 0x40 | checkAtNextHalt |
| 5 | 0x20 | maintenanceOnly |
| 4 | 0x10 | DTCClass_4 (GTR WWH-OBD class C) |
| 3 | 0x08 | DTCClass_3 (class B2) |
| 2 | 0x04 | DTCClass_2 (class B1) |
| 1 | 0x02 | DTCClass_1 (class A) |
| 0 | 0x01 | DTCClass_0 (unclassified) |

py-uds treats a valid DTCSeverity as one class bit (0–4) plus one severity bit (5–7). The class bits were
reserved in the oldest edition (2006) [edition-dependent] [unverified].

```uds
REQ 19 07 C0 FF          # checkImmediately or checkAtNextHalt, any status bit
POS 59 07 FF 01 00 01    # one DTC (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 3 | C0 | Severity mask: bits 7 and 6 (checkImmediately, checkAtNextHalt) |
| REQ 4 | FF | Any supported status bit |
| POS 3–4 | FF 01 | Availability mask, ISO_14229-1_DTCFormat |
| POS 5–6 | 00 01 | Count = 1 |

- **Notes and test points:** Count must equal the record count of `19 08` with the same masks. Unsupported → 0x12.
- **Edition notes:** Class bits 0–4 not defined in the 2006 edition [edition-dependent] [unverified].

#### 0x08 — reportDTCBySeverityMaskRecord

- **Returns:** DTCs matching severity and status masks, each with severity, functional unit, DTC and status.
- **Question answered:** "Which faults are urgent, and which function do they belong to?"
- **Use case:** A tester sorts the repair list by urgency. Not 0x02, because 0x02 carries no severity.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 08` |
| 3 | DTCSeverityMask | |
| 4 | DTCStatusMask | |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 08` |
| 3 | DTCStatusAvailabilityMask | |
| 4 … | DTCAndSeverityRecord × n | DTCSeverity, DTCFunctionalUnit, DTC (3), status — 6 bytes each |

```uds
REQ 19 08 C0 FF
POS 59 08 FF 80 05 9A 11 13 AF
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4 | 80 | Severity: checkImmediately; no class bit (non-OBD ECU, illustrative) |
| POS 5 | 05 | DTCFunctionalUnit 0x05 — OEM-defined (illustrative) |
| POS 6–9 | 9A 11 13 AF | DTC and status |

- **Notes and test points:** Response length 3 + 6n. Severity of each DTC must match the OEM DTC list.
- **Edition notes:** As 0x07.

#### 0x09 — reportSeverityInformationOfDTC

- **Returns:** severity and functional unit of one given DTC, with its status.
- **Question answered:** "How severe is this specific DTC?"
- **Use case:** A tester UI shows details for a DTC the user clicked. Not 0x08, which needs masks and returns many.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 09` |
| 3–5 | DTCMaskRecord | The DTC |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 09` |
| 3 | DTCStatusAvailabilityMask | |
| 4–9 | DTCAndSeverityRecord | 6 bytes, as 0x08 |

```uds
REQ 19 09 9A 11 13
POS 59 09 FF 80 05 9A 11 13 AF
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4–5 | 80 05 | Severity, functional unit (illustrative) |
| POS 6–9 | 9A 11 13 AF | DTC and status |

- **Notes and test points:** Unknown DTC: py-uds shows the severity record as present only when the DTC is
  supported, i.e. `59 09 <avail>` with no record (secondary source). Many ECUs answer 0x31 instead
  [unverified which one the standard requires]; record the behaviour and accept the OEM's rule.
- **Edition notes:** As 0x07.

#### 0x0A — reportSupportedDTC

- **Returns:** every DTC the ECU supports, with its current status, regardless of status.
- **Question answered:** "Which DTCs exist in this ECU (in this variant), and what is each one's state?"
- **Use case:** Regression framework reads `19 0A` at test start to check the DTC set against the OEM DTC list for
  the coded variant, and after a clear to check every status is `0x50` masked by the availability mask (`0x00`
  on an ECU without bits 4 and 6). Not `19 02 FF`, because that omits DTCs with status `0x00`.

Request: `19 0A` — no parameters.

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 0A` |
| 3 | DTCStatusAvailabilityMask | |
| 4 … | DTCAndStatusRecord × n | Every supported DTC |

```uds
REQ 19 0A
POS 59 0A FF 9A 11 13 AF 91 01 13 28 C1 23 45 00   # three supported DTCs (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4–7 | 9A 11 13 AF | Active DTC |
| POS 8–11 | 91 01 13 28 | Historic DTC |
| POS 12–15 | C1 23 45 00 | U0123-45 (illustrative): supported, tested, never failed |

- **Notes and test points:** Usually the longest response of the service — the main multi-frame and P2 test case
  (see the trace in the examples). Its DTC count does not change on a clear, so test paged-buffer padding with a
  mask-based report instead. The DTC set may legitimately depend on variant coding
  [OEM-specific]. Compare with the OEM DTC list both ways (missing and extra DTCs).
- **Edition notes:** No layout change known [unverified].

#### 0x0B — reportFirstTestFailedDTC

- **Returns:** the first DTC that failed (bit 0 set at least once) since the last clear, with its current status.
- **Question answered:** "What failed first?" — often the root cause when one fault triggers follow-up DTCs.
- **Use case:** A supply-voltage dip makes several ECU monitors fail. The analyst asks which DTC came first. Not
  0x02, which carries no time order.

Request: `19 0B` — no parameters.

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 0B` |
| 3 | DTCStatusAvailabilityMask | |
| 4–7 | DTCAndStatusRecord | Absent when no DTC failed since clear |

```uds
REQ 19 0B
POS 59 0B FF 91 01 13 28   # B1101-13 failed first; now historic (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4–7 | 91 01 13 28 | First failed DTC and its *current* status |

- **Notes and test points:** The status is the current one, so the DTC may be healed. Only a clear resets the
  record; behaviour when the referenced DTC ages out is not cross-checked [unverified]. Test: inject fault A, then
  B; expect A here and B in 0x0D.
- **Edition notes:** No change known [unverified].

#### 0x0C — reportFirstConfirmedDTC

- **Returns:** the first DTC that became confirmed since the last clear, with its current status.
- **Question answered:** "What was stored first?"
- **Use case:** Same as 0x0B when only confirmed DTCs matter (workshop view). Differs from 0x0B when a DTC failed
  but never confirmed.

Request: `19 0C` — no parameters.

Response: `59 0C`, availability mask, then one DTCAndStatusRecord (same layout as 0x0B; absent when no
DTC qualifies since the last clear).

```uds
REQ 19 0C
POS 59 0C FF 91 01 13 28
```

| Byte | Value | Meaning |
|---|---|---|
| POS 4–7 | 91 01 13 28 | First confirmed DTC, current status historic |

- **Notes and test points:** With confirmation threshold 0 (Amd 1:2022 default for non-OBD) first failed and first
  confirmed are usually the same DTC [edition-dependent]. Test a fault that fails but never confirms (if the OEM
  uses a threshold > 0): it appears in 0x0B but not here.
- **Edition notes:** Confirmation threshold default changed in Amd 1:2022 (Annex D); affects expectations.

#### 0x0D — reportMostRecentTestFailedDTC

- **Returns:** the most recent DTC that failed, with its current status.
- **Question answered:** "What just failed?"
- **Use case:** HIL step injects a fault and confirms that the DTC the ECU registered last is the injected one, not
  a side effect. Not 0x02, because a full list hides which DTC is newest.

Request: `19 0D` — no parameters.

Response: `59 0D`, availability mask, then one DTCAndStatusRecord (same layout as 0x0B; absent when no
DTC qualifies since the last clear).

```uds
REQ 19 0D
POS 59 0D FF 9A 11 13 AF   # the squib DTC failed last (illustrative)
REQ 19 0D                  # after 14 FF FF FF
POS 59 0D FF               # empty
```

| Byte | Value | Meaning |
|---|---|---|
| 1st POS 4–7 | 9A 11 13 AF | Most recent failure |
| 2nd POS | 59 0D FF | Nothing failed since the clear |

- **Notes and test points:** Updates on every new failure event; repeated failures of the same DTC keep it here.
- **Edition notes:** No change known [unverified].

#### 0x0E — reportMostRecentConfirmedDTC

- **Returns:** the most recently confirmed DTC, with its current status.
- **Question answered:** "What was stored last?"
- **Use case:** Workshop tester highlights the newest stored fault after a test drive.

Request: `19 0E` — no parameters.

Response: `59 0E`, availability mask, then one DTCAndStatusRecord (same layout as 0x0B; absent when no
DTC qualifies since the last clear).

```uds
REQ 19 0E
POS 59 0E FF 9A 11 13 AF
```

| Byte | Value | Meaning |
|---|---|---|
| POS 4–7 | 9A 11 13 AF | Most recently confirmed DTC |

- **Notes and test points:** Consistency: the DTC here must have bit 3 set in `19 02 08` unless it aged out.
- **Edition notes:** No change known [unverified].

#### 0x14 — reportDTCFaultDetectionCounter

- **Returns:** DTCs whose fault detection counter is in the pre-failed range, each with its FDC.
- **Question answered:** "Which monitors are seeing a failing condition that has not qualified yet?"
- **Use case:** Validation engineer checks that a 20 ms squib-resistance glitch (illustrative) raises the FDC but
  never sets the DTC. Developer tunes debounce steps. Not 0x02, which shows nothing until qualification.

Request: `19 14` — no parameters.

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 14` |
| 3 … | DTCFaultDetectionCounterRecord × n | DTC (3) + FDC (1); **no availability mask** |

```uds
REQ 19 14
POS 59 14 9A 11 13 40 91 01 13 05   # two DTCs debouncing (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3–5 | 9A 11 13 | DTC |
| POS 6 | 40 | FDC +64: about half-way to failed (if threshold is +127) |
| POS 7–9 | 91 01 13 | DTC — historic (confirmed) and debouncing again; whether such a DTC is listed is one of the open points in section 5 [unverified] |
| POS 10 | 05 | FDC +5: failing condition just seen |

- **Notes and test points:** Read cyclically for the trend; interpret FDC as signed. A DTC at +127 is failed and
  should not be listed [unverified]. Clear and cycle start usually reset FDC to 0 [unverified]. With 0x85 off, FDC
  may still move while status is frozen [unverified] — record it. Some OEMs allow `19 14` only in extended session.
- **Edition notes:** No change known [unverified]. Semantics: [../dtc-reference.md](../dtc-reference.md#5-fault-detection-counter-0x19-0x14).

#### 0x15 — reportDTCWithPermanentStatus

- **Returns:** all DTCs with permanent status, each with its status byte.
- **Question answered:** "Which emissions faults remain even after a clear?"
- **Use case:** An emissions inspection checks for permanent DTCs to detect that someone cleared DTCs just before
  the test. Not 0x02, because permanent status is not a status bit.

Request: `19 15` — no parameters.

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 15` |
| 3 | DTCStatusAvailabilityMask | |
| 4 … | DTCAndStatusRecord × n | |

```uds
REQ 19 15                     # emissions-relevant ECU (illustrative)
POS 59 15 FF 01 23 45 08      # P0123-45 permanent (illustrative)
REQ 19 15                     # restraint ECU without OBD relevance (illustrative)
NEG 7F 19 12
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4–7 | 01 23 45 08 | Permanent DTC, currently confirmed and not failing |
| NEG 3 | 12 | Report type not implemented on the non-OBD ECU |

- **Notes and test points:** `14 FF FF FF` must not remove it; it leaves only after the self-healing conditions.
- **Edition notes:** No change known [unverified]. For WWH-OBD use 0x55.

#### 0x16 — reportDTCExtDataRecordByRecordNumber

- **Returns:** one extended data record (by number) for every DTC that has it stored.
- **Question answered:** "What is counter X for all DTCs?"
- **Use case:** End-of-line or fleet analysis dumps the occurrence counter of every stored DTC in one request.
  Not 0x06, which needs one request per DTC.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 16` |
| 3 | DTCExtDataRecordNumber | One record number, at most 0xEF (python-udsoncan, citing 2020); 0xF0–0xFF incl. the "all" values → 0x31 [unverified] |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 16` |
| 3 | DTCExtDataRecordNumber | Echo, once |
| 4 … | (DTCAndStatusRecord + DTCExtDataRecord) × n | Record bytes without the record number |

```uds
REQ 19 16 01                              # occurrence counter of all DTCs
POS 59 16 01 9A 11 13 AF 03 91 01 13 28 01
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | 01 | Record 0x01 (occurrence counter, illustrative) |
| POS 4–7, 8 | 9A 11 13 AF, 03 | B1A11-13 failed 3 times |
| POS 9–12, 13 | 91 01 13 28, 01 | B1101-13 failed once |

- **Notes and test points:** Record length is the same for every DTC only if the description says so — parse per
  DTC with the description. Empty response is `59 16 01` (py-uds: DTC records optional; secondary). Unsupported
  record number → 0x31.
- **Edition notes:** Name as given in Amd 1:2022 (cross-checked); older texts and tools may spell it differently.

#### 0x17 — reportUserDefMemoryDTCByStatusMask

- **Returns:** like 0x02, but from the user-defined memory chosen by MemorySelection.
- **Question answered:** "Which DTCs are in secondary / development / supplier memory N?"
- **Use case:** A supplier engineer reads a development memory that keeps DTCs the OEM's primary memory filters out
  (e.g. DTCs suppressed during crank or low voltage) [illustrative]. Not 0x02, which reads primary memory only.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 17` |
| 3 | DTCStatusMask | |
| 4 | MemorySelection | OEM-defined |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 17` |
| 3 | MemorySelection | Echo |
| 4 | DTCStatusAvailabilityMask | For this memory |
| 5 … | DTCAndStatusRecord × n | |

```uds
REQ 19 17 FF 01          # MemorySelection 0x01 (illustrative)
POS 59 17 01 FF 9A 11 13 AF
REQ 19 17 FF 7A          # memory not defined (illustrative)
NEG 7F 19 31
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | 01 | Memory 0x01 echoed |
| POS 4 | FF | Availability mask of that memory |
| POS 5–8 | 9A 11 13 AF | DTC and status |
| NEG 3 | 31 | MemorySelection not supported |

- **Notes and test points:** Check that `14 FF FF FF <sel>` (2020) clears only that memory, and that DTCs in it
  follow its own storage rules. Some OEMs secure supplier memories (0x33) [OEM-specific].
- **Edition notes:** Present in 2013 and 2020; replaces mirror memory (0x0F) for new designs.

#### 0x18 — reportUserDefMemoryDTCSnapshotRecordByDTCNumber

- **Returns:** like 0x04, for a DTC in the selected user-defined memory.
- **Question answered:** "Under which conditions was this DTC stored in memory N?"
- **Use case:** Development memory freeze frames during a validation drive. Not 0x04, which reads primary memory.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 18` |
| 3–5 | DTCMaskRecord | |
| 6 | UserDefDTCSnapshotRecordNumber | 0x00–0xFE one record, `FF` all (Amd 1:2022) |
| 7 | MemorySelection | OEM-defined |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 18` |
| 3 | MemorySelection | Echo |
| 4–7 | DTCAndStatusRecord | |
| 8 … | Snapshot records | As 0x04: record number, number of identifiers, DID + data |

```uds
REQ 19 18 9A 11 13 FF 01
POS 59 18 01 9A 11 13 AF 01 01 47 21 7C
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | 01 | Memory 0x01 (illustrative) |
| POS 4–7 | 9A 11 13 AF | DTC and status |
| POS 8–9 | 01 01 | Record 0x01, one DID |
| POS 10–12 | 47 21 7C | Supply voltage 12.4 V (illustrative) |

- **Notes and test points:** Unlike the primary memory, all of 0x00–0xFE is manufacturer-specific here. Unknown
  DTC, record or memory → 0x31.
- **Edition notes:** Record-number range per Amd 1:2022 (cross-checked).

#### 0x19 — reportUserDefMemoryDTCExtDataRecordByDTCNumber

- **Returns:** like 0x06, for a DTC in the selected user-defined memory.
- **Question answered:** "What are the counters of this DTC in memory N?"
- **Use case:** Supplier analysis of occurrence counters in a secondary memory. Not 0x06 (primary memory only).

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 19` |
| 3–5 | DTCMaskRecord | |
| 6 | DTCExtDataRecordNumber | One record or `FF` all |
| 7 | MemorySelection | OEM-defined |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 19` |
| 3 | MemorySelection | Echo |
| 4–7 | DTCAndStatusRecord | |
| 8 … | (record number + data) pairs | As 0x06 |

```uds
REQ 19 19 9A 11 13 FF 01
POS 59 19 01 9A 11 13 AF 01 03
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | 01 | Memory 0x01 (illustrative) |
| POS 4–7 | 9A 11 13 AF | DTC and status |
| POS 8–9 | 01 03 | Record 0x01 = 3 (illustrative) |

- **Notes and test points:** Same parsing rules as 0x06. Note the name clash: sub-function 0x19 of service 0x19 —
  log it as `19 19`, not "service 19".
- **Edition notes:** Present in 2013 and 2020 [unverified for 2013 layout].

#### 0x1A — reportSupportedDTCExtDataRecord

- **Returns:** all DTCs that support a given extended data record number, with their status.
- **Question answered:** "Which DTCs have record X defined?" — a configuration question, independent of whether data
  is stored.
- **Use case:** Test generator builds the list of DTCs whose occurrence counter must be checked, straight from the
  ECU, and compares it with the description. Not 0x16, which returns only DTCs with data stored.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 1A` |
| 3 | DTCExtDataRecordNumber | Record number; allowed range not cross-checked [unverified] |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 1A` |
| 3 | DTCStatusAvailabilityMask | Order of bytes 3–4 as in py-uds (secondary) |
| 4 | DTCExtDataRecordNumber | Echo; optional in py-uds — likely omitted when no DTC supports the record [unverified] |
| 5 … | DTCAndStatusRecord × n | |

```uds
REQ 19 1A 10                              # which DTCs support record 0x10? (illustrative)
POS 59 1A FF 10 9A 11 13 AF 91 01 13 28
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | FF | Availability mask |
| POS 4 | 10 | Record 0x10 echoed |
| POS 5–12 | 9A 11 13 AF, 91 01 13 28 | Two DTCs support record 0x10 |

- **Notes and test points:** 2013 ECU: expect 0x12. Result must not change after a clear (configuration, not
  content). Empty result may be `59 1A <avail>` without the record-number echo [unverified]; accept both
  `59 1A <avail>` and `59 1A <avail> <rec>`.
- **Edition notes:** New in 2020 (cross-checked). Field order matches py-uds (secondary); not checked against
  the ISO text.

#### 0x42 — reportWWHOBDDTCByMaskRecord

- **Returns:** DTCs of one functional group matching status and severity masks, with severity, plus the DTC format
  and severity availability.
- **Question answered:** "Which emissions-relevant (or safety-relevant) DTCs are present, and how severe?" — in a
  form any WWH-OBD scan tool understands.
- **Use case:** Generic OBD scan tool in an inspection lane, often sent functionally to all emissions ECUs. Not 0x02,
  which is not filtered by functional group and carries no format or severity.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 42` |
| 3 | FunctionalGroupIdentifier | e.g. `33` emissions-system group (values in section 5) |
| 4 | DTCStatusMask | Order 3–4–5 agreed by py-uds and python-udsoncan (secondary) |
| 5 | DTCSeverityMask | Bits as in 0x07 |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 42` |
| 3 | FunctionalGroupIdentifier | Echo |
| 4 | DTCStatusAvailabilityMask | |
| 5 | DTCSeverityAvailabilityMask | |
| 6 | DTCFormatIdentifier | Typically 0x04 SAE_J2012-DA_DTCFormat_04 (0x02 J1939-73 on heavy duty) |
| 7 … | (DTCSeverity + DTC (3) + status) × n | 5 bytes each; header and record order agreed by py-uds and python-udsoncan (secondary) |

```uds
REQ 19 42 33 08 FF
POS 59 42 33 FF FF 04 82 01 23 45 08   # one confirmed emissions DTC (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3 | 33 | Emissions-system group |
| POS 4–5 | FF FF | Status and severity availability (illustrative) |
| POS 6 | 04 | SAE_J2012-DA_DTCFormat_04 |
| POS 7 | 82 | DTCSeverity: checkImmediately + DTCClass_1 (class A) — one severity bit plus one class bit (illustrative) |
| POS 8–11 | 01 23 45 08 | P0123-45 (illustrative), confirmed |

- **Notes and test points:** Non-OBD ECUs: 0x12 (physical) or silence (functional). Unsupported group → 0x31.
  Empty result is the 6-byte header only (`59 42 33 FF FF 04`). Records: remaining length must be a multiple
  of 5.
- **Edition notes:** DTCFormatIdentifier 0x04 name per Amd 1:2022 (cross-checked). Field order from two
  open-source implementations, not from the ISO text.

#### 0x55 — reportWWHOBDDTCWithPermanentStatus

- **Returns:** WWH-OBD permanent DTCs of one functional group, with format.
- **Question answered:** "Which permanent emissions DTCs does this group hold?"
- **Use case:** Inspection check for cleared-before-test vehicles on WWH-OBD / OBDonUDS ECUs. Not 0x15, which has
  no functional group and no format byte.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 55` |
| 3 | FunctionalGroupIdentifier | |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 55` |
| 3 | FunctionalGroupIdentifier | Echo |
| 4 | DTCStatusAvailabilityMask | |
| 5 | DTCFormatIdentifier | |
| 6 … | DTCAndStatusRecord × n | 4 bytes each per py-uds; python-udsoncan parses 5-byte records with severity, as 0x42 — sources disagree [unverified] |

```uds
REQ 19 55 33
POS 59 55 33 FF 04 01 23 45 08
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3–5 | 33 FF 04 | Group, availability mask, format 0x04 |
| POS 6–9 | 01 23 45 08 | Permanent DTC (illustrative) |

- **Notes and test points:** As 0x15. Empty response is the header only, `59 55 33 FF 04` (follows from the
  header order both open-source sources agree on). Parser: if the record area is a multiple of 5 but not of
  4, suspect the severity variant and check with the OEM.
- **Edition notes:** No change known [unverified].

#### 0x56 — reportDTCInformationByDTCReadinessGroupIdentifier

- **Returns:** DTCs of one functional group that belong to one readiness group.
- **Question answered:** "Which DTCs belong to readiness group G, and what is their state?" — used to judge monitor
  readiness.
- **Use case:** OBDonUDS scan tool checks readiness of one monitor family before an inspection [unverified]. Not
  0x42, which does not filter by readiness group.

| Request byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `19 56` |
| 3 | FunctionalGroupIdentifier | |
| 4 | DTCReadinessGroupIdentifier | Values defined by SAE J1979-DA (per py-uds), not ISO 14229-1 |

| Response byte | Parameter | Value |
|---|---|---|
| 1–2 | SID, SF | `59 56` |
| 3 | FunctionalGroupIdentifier | Echo |
| 4 | DTCStatusAvailabilityMask | |
| 5 | DTCFormatIdentifier | |
| 6 | DTCReadinessGroupIdentifier | Echo, after the format byte (py-uds order, secondary) |
| 7 … | DTCAndStatusRecord × n | |

```uds
REQ 19 56 33 01                         # readiness group 0x01 (illustrative)
POS 59 56 33 FF 04 01 01 23 45 50       # one DTC, monitor not completed since clear
```

| Byte | Value | Meaning |
|---|---|---|
| POS 3–5 | 33 FF 04 | Group, availability mask, format |
| POS 6 | 01 | Readiness group echoed (illustrative) |
| POS 7–10 | 01 23 45 50 | DTC (illustrative), bits 4 and 6: not yet tested → group not ready |

- **Notes and test points:** Readiness is derived from bits 4/6 of the group's DTCs [unverified]. Expect 0x12 on 2013
  ECUs and non-OBD ECUs.
- **Edition notes:** New in 2020 (cross-checked). Field order matches py-uds (secondary); python-udsoncan does
  not implement 0x56; not checked against the ISO text.

### Withdrawn in 2020 (legacy 2013 ECUs)

[edition-dependent] These report types exist in ISO 14229-1:2013 and were removed in 2020 (cross-checked: 2020
Foreword and py-uds). A 2020-conformant ECU answers them with NRC 0x12. Many 2013-based ECUs still in production
implement them.

| Value | Name | Purpose (2013) | 2013 request [unverified] | 2020 replacement |
|---|---|---|---|---|
| 0x0F | reportMirrorMemoryDTCByStatusMask | Like 0x02, for the mirror (backup/secondary) memory | `19 0F <mask>` | 0x17 with an OEM MemorySelection |
| 0x10 | reportMirrorMemoryDTCExtDataRecordByDTCNumber | Like 0x06, for the mirror memory | `19 10 <DTC> <rec>` | 0x19 |
| 0x11 | reportNumberOfMirrorMemoryDTCByStatusMask | Like 0x01, for the mirror memory | `19 11 <mask>` | 0x17 (count the records) |
| 0x12 | reportNumberOfEmissionsOBDDTCByStatusMask | Count of emissions-related OBD DTCs by mask | `19 12 <mask>` | 0x42 (group 0x33) |
| 0x13 | reportEmissionsOBDDTCByStatusMask | List of emissions-related OBD DTCs by mask | `19 13 <mask>` | 0x42 (group 0x33) |

```uds
REQ 19 0F FF                  # 2020-conformant ECU
NEG 7F 19 12                  # withdrawn report type
REQ 19 0F FF                  # legacy 2013 ECU (illustrative)
POS 59 0F FF 9A 11 13 28      # mirror memory holds B1A11-13, historic
```

| Byte | Value | Meaning |
|---|---|---|
| NEG 3 | 12 | Not supported in a 2020 ECU |
| POS 3 | FF | Availability mask (legacy ECU) |
| POS 4–7 | 9A 11 13 28 | Mirror-memory DTC and status (illustrative) |

A test suite shared across 2013 and 2020 ECUs must select expectations by the ECU's edition, not by tool default.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Report type not implemented; withdrawn 0x0F–0x13 on a 2020 ECU; 0x1A / 0x56 on a 2013 ECU; OBD report types on a non-OBD ECU |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request length differs from the "Len" value of that report type in the sub-function index; bare `19` |
| 0x14 | responseTooLong | Report (typically 0x0A, 0x02 FF, 0x04 FF) does not fit the ECU buffer or transport, and no paged buffer |
| 0x22 | conditionsNotCorrect | OEM condition: e.g. fault memory not yet initialised after start-up, low voltage [OEM-specific] |
| 0x31 | requestOutOfRange | Unknown DTC number (0x04, 0x06, 0x09, 0x18, 0x19); record number not supported for that DTC or reserved; unsupported MemorySelection (0x17–0x19); unsupported FunctionalGroupIdentifier or readiness group |
| 0x33 | securityAccessDenied | Secured user-defined / supplier memory [OEM-specific] |
| 0x34 | authenticationRequired | 2020 ECUs where the OEM puts a report type or memory behind 0x29 [OEM-specific] [edition-dependent] |
| 0x78 | requestCorrectlyReceived-ResponsePending | Snapshot or extended data read from slow NVM, or long list assembly |
| 0x7E | subFunctionNotSupportedInActiveSession | Report type exists but not in this session (e.g. `19 14` or `19 17` only in extended) [OEM-specific] |
| 0x7F | serviceNotSupportedInActiveSession | 0x19 not available in this session (commonly programming session / bootloader) |

No DTC matching a mask (or no record stored) is an empty positive response, never an NRC. Meanings of all
NRCs: [../nrc-reference.md](../nrc-reference.md). Evaluation order:
[../protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order) [unverified for 0x19 detail].

### Examples

Values marked (illustrative) are not universal. Sub-function-specific examples are in the subsections above.

Negative responses:

```uds
REQ 19                  # sub-function missing
NEG 7F 19 13
REQ 19 02               # mask missing
NEG 7F 19 13
REQ 19 02 08 00         # one byte too many
NEG 7F 19 13
REQ 19 2F               # reserved report type
NEG 7F 19 12
REQ 19 14               # default session; OEM allows 0x14 only in extended (illustrative)
NEG 7F 19 7E
REQ 19 02 08            # programming session (bootloader)
NEG 7F 19 7F
REQ 19 0A               # too many DTCs for the buffer (illustrative)
NEG 7F 19 14
REQ 19 02 08            # shortly after power-up, memory not loaded (illustrative)
NEG 7F 19 22
REQ 19 17 08 02         # supplier memory needs security (illustrative)
NEG 7F 19 33
```

| Exchange | Request | NRC | Reason |
|---|---|---|---|
| 1 | `19` | 13 | Length 1 |
| 2 | `19 02` | 13 | 0x02 needs 3 bytes |
| 3 | `19 02 08 00` | 13 | 0x02 allows exactly 3 bytes |
| 4 | `19 2F` | 12 | Value not defined |
| 5 | `19 14` | 7E | Session restriction (OEM) |
| 6 | `19 02 08` | 7F | Service not in programming session |
| 7 | `19 0A` | 14 | Response exceeds buffer |
| 8 | `19 02 08` | 22 | OEM start-up condition |
| 9 | `19 17 08 02` | 33 | Secured memory (OEM) |

Response pending while snapshot data is fetched from external EEPROM (illustrative):

```uds
REQ 19 04 9A 11 13 FF
NEG 7F 19 78
POS 59 04 9A 11 13 AF 01 02 47 21 7C 47 22 00 01 2C 3A ..
```

| Message | Meaning |
|---|---|
| `7F 19 78`, then `59 04 …` | Accepted; tester switches to P2* and waits; final response has the same content as without 0x78 |

SPRMIB set (bit 7 of the sub-function):

```uds
REQ 19 82 08            # reportDTCByStatusMask with SPRMIB
NOTE no positive response expected; the DTC list is lost
REQ 19 82               # SPRMIB set and mask missing
NEG 7F 19 13            # negative responses are still sent
```

| Exchange | Meaning |
|---|---|
| 1 | Positive response suppressed, so the read is useless; some ECUs reject it with 0x12 instead [unverified] — record behaviour, never use in production |
| 2 | NRCs are still sent with SPRMIB set (physical addressing) |

Functional addressing (CAN IDs illustrative):

```uds
REQ 19 02 08            # to functional ID 0x7DF (illustrative)
POS 59 02 FF 9A 11 13 AF   # ECU A, physical response ID
POS 59 02 09               # ECU B: no confirmed DTCs, still answers
NOTE ECUs without 0x19 or the report type stay silent (0x11/0x12/0x31/0x7E/0x7F suppressed for functional requests)
```

| Response | Meaning |
|---|---|
| ECU A / ECU B | One active DTC / empty list with its own availability mask 0x09 |
| silence | Expected from ECUs that would answer 0x11, 0x12, 0x31, 0x7E or 0x7F (list per [../protocol-fundamentals.md](../protocol-fundamentals.md#functional-vs-physical-addressing)) |

Multi-frame `19 0A` on classical CAN (IDs 0x7xx and padding 0xCC illustrative):

```uds
REQ 19 0A
POS 59 0A FF 9A 11 13 AF 91 01 13 28 C1 23 45 00
CAN 02 19 0A CC CC CC CC CC   # tester -> ECU: Single Frame, 2 bytes
CAN 10 0F 59 0A FF 9A 11 13   # ECU -> tester: First Frame, total 15 bytes
CAN 30 00 00 CC CC CC CC CC   # tester -> ECU: Flow Control, continue, BS 0, STmin 0
CAN 21 AF 91 01 13 28 C1 23   # ECU -> tester: Consecutive Frame 1
CAN 22 45 00 CC CC CC CC CC   # ECU -> tester: Consecutive Frame 2, padded
```

| Frame / byte | Value | Meaning |
|---|---|---|
| SF 1 | 02 | Single frame, 2 bytes |
| FF 1–2 | 10 0F | First frame, length 0x00F = 15 |
| FF 3–8 | 59 0A FF 9A 11 13 | SID, SF, availability mask, first DTC |
| FC 1–3 | 30 00 00 | ContinueToSend, no block limit, STmin 0 |
| CF1 1 | 21 | Sequence 1 |
| CF1 2–8 | AF 91 01 13 28 C1 23 | Status of DTC 1, DTC 2 + status, start of DTC 3 |
| CF2 1–3 | 22 45 00 | Sequence 2, end of DTC 3 and its status |

On CAN FD the same 15-byte response fits one single frame (SF_DL escape byte); see
[../protocol-fundamentals.md](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials).

Paged buffer: three confirmed DTCs are announced (15 bytes); a second client clears B1101-13 before its record
is sent. A mask-based report is used because clearing changes which DTCs match the mask; with `19 0A` the DTC
set is fixed by configuration and only status bytes change.

```uds
REQ 19 02 08
POS 59 02 FF 9A 11 13 AF C1 23 45 08 00 00 00 00   # last 4 bytes: padding record (Amd 1:2022)
```

| Bytes | Value | Meaning |
|---|---|---|
| 4–7 | 9A 11 13 AF | Still present |
| 8–11 | C1 23 45 08 | U0123-45 (illustrative), confirmed, still present |
| 12–15 | 00 00 00 00 | DTC 000000, status 00: padding to keep the announced length — drop it |

Position of the padding (end of the message vs in place of the removed record) is not cross-checked [unverified].

## 7. Implementation and testing

**Implementation — request builder:**
- One builder per report type, driven by the "Len" values in the section 6 index. Inputs: status mask (1 byte), DTC (24-bit
  integer, encoded high byte first), record number, MemorySelection, severity mask, group identifiers.
- Reject wrong parameter counts in normal mode; allow a raw mode for negative tests (min-1, max+1).
- Never set SPRMIB on 0x19 by default.
- Know the ECU's edition: refuse 0x0F–0x13 for a 2020 ECU and 0x1A / 0x56 for a 2013 ECU unless testing NRCs.

**Implementation — response parser (rules):**
1. Check `59` and the echoed report type. Anything else, or `7F 19 xx`, goes to NRC handling (0x78: keep
   waiting with P2*; accept repeated 0x78).
2. Parse the fixed header for the report type (availability mask, format, MemorySelection, group, record
   number). Header length is fixed per report type; only the records after it vary.
3. **DTC lists** (02, 0A–0E, 15, 17, 1A, 56): remaining length must be a multiple of 4. 08/09: multiple of 6.
   14: multiple of 4 (DTC + FDC). 42: multiple of 5 (severity + DTC + status). 55: 4 per py-uds, 5 per
   python-udsoncan — configure per OEM [unverified]. A remainder is a defect — report it, do not truncate
   silently.
4. **Empty is valid.** `59 02 FF`, `59 03`, `59 14`, `59 04 <DTC> <status>`, `59 05 <rec>`, `59 16 <rec>`,
   `59 1A <avail>` (with or without the record echo), `59 42 <grp> <avail> <sev avail> <fmt>` are positive
   results with zero records.
5. **Snapshot records** (04, 05, 18): loop record number → identifier count → per identifier: DID, then the
   DID's data length from the description. Unknown DID: stop and return the rest as raw bytes with an error.
6. **Extended records** (06, 16, 19): loop record number → length from the description (may differ per DTC).
   Unknown record number: stop and return raw remainder with an error. Never guess a length.
7. **DTC format:** read DTCFormatIdentifier from 0x01 / 0x07 / 0x42 / 0x55 / 0x56; for other report types use the
   value learnt from a previous 0x01 or from the description. Convert to P/C/B/U text for formats 0x00 / 0x04,
   and for 0x01 only where the OEM uses the same mapping (common, as in this entry's examples) [OEM-specific].
8. **Padding records** (`00 00 00` + status `00`): drop and log (Amd 1:2022 paged buffer). DTC 0x000000 is not
   used as a real DTC [unverified].
9. **Duplicates:** a DTC listed twice is an ECU defect; flag it.
10. **Order:** do not rely on DTC order; return a map DTC → status (and records).
11. **Multi-frame:** the transport layer reassembles. Check that the reassembled length equals the length in
    the First Frame; handle the ISO-TP escape First Frame (> 4095 bytes) and CAN FD single frames up to 62 bytes.
12. **Status interpretation:** keep the availability mask with every result. Unsupported bits are "unknown",
    not "false".

**Comparing status bytes:** compare only bits that are both supported and specified for the test step.

```python
def status_matches(actual: int, expected: int, avail_mask: int, care_mask: int = 0xFF) -> bool:
    """True if actual equals expected on bits the ECU supports and the test cares about."""
    m = avail_mask & care_mask
    return (actual & m) == (expected & m)

# HIL step 3 (healed): ignore bit 7 (lamp rule OEM-specific) and bit 2 (pending strategy)
assert status_matches(actual=0xAE, expected=0x2E, avail_mask=0xFF, care_mask=0xFF & ~0x84)

# Same expected table on an ECU with avail 0x0B (bits 0, 1, 3 only; illustrative)
assert status_matches(actual=0x0B, expected=0xAF, avail_mask=0x0B)  # step 2, active
assert status_matches(actual=0x0A, expected=0x2E, avail_mask=0x0B)  # step 3, healed this cycle
assert status_matches(actual=0x08, expected=0x2C, avail_mask=0x0B)  # step 4, after ignition cycle
```

Take `avail_mask` from the ECU's response (and check it against the OEM spec once, test 9), never from a
constant in the test script.

Log the raw status, the availability mask and the care mask together, so a reviewer can see what was ignored.

**Timing for fault-injection tests:**
- Never read immediately after injecting. Poll `19 02 01` every 50–100 ms (illustrative) until the DTC appears or
  max qualification time + margin (bus latency, tester scheduling, DoIP routing) expires.
- Assert the measured time to qualify is within [min, max] of the OEM spec; setting too early is also a defect.
- For healing, poll until bit 0 clears (bounded by max healing time + margin), then check bit 3 is still set.
- Make sure DTC setting is on (0x85 resets on session change or reset); log the operation-cycle count, since an
  ignition cycle changes bits 1, 2 and 6. Keep an extended session alive with TesterPresent.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Count, positive | `19 01 08` | `59 01` + avail mask + format + 2-byte count |
| 2 | Count vs list | `19 01 m` and `19 02 m` for m = 01, 08, 09, FF | Count equals number of records |
| 3 | List, no DTCs | `19 02 08` on clean ECU | `59 02 <avail>` only, no NRC |
| 4 | List after clear | `14 FF FF FF`, `19 02 FF` | All DTCs `0x50` (masked by avail) |
| 5 | Unsupported bits only | `19 02 <~avail>` | Empty positive |
| 6 | Mask 0x00 | `19 02 00` | Empty positive [unverified]; record if `7F 19 31` or a full list (stack treats 0x00 as "no filter") |
| 7 | Supported DTC set | `19 0A` | Equals OEM DTC list for the coded variant (both directions) |
| 8 | Status consistency | `19 0A` vs `19 02 FF` vs `19 04`/`19 06` | Same status per DTC |
| 9 | Availability mask consistency | All report types with an avail mask | Same value everywhere (per memory for 0x17) |
| 10 | Snapshot identification | Inject fault, `19 03` | Pairs for the DTC appear; empty after clear |
| 11 | Snapshot content | `19 04 <DTC> FF` | Records decode with the description; values match bench conditions at capture |
| 12 | Snapshot, none stored | `19 04 <DTC> FF` after clear | `59 04 <DTC> <status>` only |
| 13 | Snapshot, unknown DTC / record | `19 04 12 34 56 FF` (illustrative); `19 04 <DTC> <bad rec>` | `7F 19 31` each |
| 14 | Stored data | `19 05 FF` / single record | Records decode; unsupported record → `7F 19 31` |
| 15 | Extended data | `19 06 <DTC> FF` | All records, lengths per description, no leftover bytes |
| 16 | Occurrence counter | Fail the DTC n times | Counter = n (saturation per OEM) |
| 17 | Ageing counter | Fault-free operation cycles | Counter moves per OEM; DTC ages at threshold |
| 18 | Extended data, OBD records on non-OBD ECU | `19 06 <DTC> FE` | `7F 19 31` or empty [unverified] |
| 19 | Severity | `19 07`, `19 08`, `19 09` | Count = list size; values match OEM DTC list; or `7F 19 12` if unsupported |
| 20 | First / most recent | Fail DTC A, then B; then `14 FF FF FF` | 0x0B/0x0C → A; 0x0D/0x0E → B; after clear each `59 0x <avail>` empty |
| 21 | FDC | Fault shorter than qualification time, then held | First in `19 14` with FDC 0x01–0x7E and not in `19 02 01`; once qualified, leaves `19 14` and appears in `19 02 01` |
| 22 | Qualification time boundaries | Fault held for min-δ and max+δ | Not set at min-δ; set by max+δ |
| 23 | Active status | Fault held past max qualification | Status = expected active value on care mask (e.g. `0xAF`; `0x0B` on an avail-`0x0B` ECU) |
| 24 | Healed status | Fault removed, wait healing time | Bit 0 cleared, bit 3 kept, bit 1 kept this cycle (e.g. `0x2E`; `0x0A`) |
| 25 | Historic after ignition cycle | Ignition off/on, monitor completes | Bit 1 cleared; bit 6 set until monitor completes; e.g. `0x2C` then `0x28`; `0x08` on an avail-`0x0B` ECU |
| 26 | Warning lamp bit | Active fault on restraint ECU | Bit 7 set; clears per OEM lamp rule |
| 27 | DTC setting off | `85 02`, inject fault past qualification | No status change; `85 01` then status updates |
| 28 | Permanent DTC | OBD ECU: confirm DTC, `14 FF FF FF`, `19 15` | DTC still listed; non-OBD ECU `7F 19 12` |
| 29 | Ext record by number | `19 16 <rec>`; `19 16 F0` / `19 16 FF` | Every DTC with the record stored; unsupported record and values above 0xEF `7F 19 31` [unverified] |
| 30 | User memory | `19 17 FF <sel>`; `19 17 FF <bad sel>` | `59 17 <sel> <avail> …`; `7F 19 31` |
| 31 | User memory snapshot / ext | `19 18 …`, `19 19 …` | Decode per description; unknown DTC / record / memory `7F 19 31` |
| 32 | User memory clear (2020) | `14 FF FF FF <sel>`, then 0x17 for each memory | Only selected memory empty |
| 33 | Supported ext record | `19 1A <rec>` | DTC list matches description; unchanged by clear; 2013 ECU `7F 19 12` |
| 34 | WWH-OBD | `19 42 33 08 FF`, `19 55 33`, `19 56 33 <rg>` | Format 0x04, group echoed; non-OBD ECU `7F 19 12` |
| 35 | Withdrawn on 2020 ECU | `19 0F FF`, `19 10 …`, `19 11 FF`, `19 12 FF`, `19 13 FF` | `7F 19 12` each |
| 36 | Length min-1 | Each report type with one parameter byte missing | `7F 19 13` |
| 37 | Length min = max | Each report type with exact length | Positive (or a parameter NRC) |
| 38 | Length max+1 | Each report type with one extra byte | `7F 19 13` |
| 39 | Bare SID | `19` | `7F 19 13` |
| 40 | Reserved report type | `19 2F`, `19 7F` | `7F 19 12` |
| 41 | Session matrix | Each report type in default, extended, programming, safety-system (0x04) session | Per OEM table; `7F 19 7E` / `7F 19 7F` where not allowed |
| 42 | Session loss | Let S3 expire, use an extended-only report type | `7F 19 7E` |
| 43 | Security matrix | Each report type locked and unlocked | Identical results unless OEM secures a memory (`7F 19 33` when locked) |
| 44 | Authentication (2020 ECUs) | Report type needing 0x29, not authenticated | `7F 19 34` [OEM-specific] [edition-dependent] |
| 45 | Conditions | Read during start-up / low voltage | Positive or `7F 19 22` per OEM |
| 46 | SPRMIB | `19 82 08` | No positive response (or `7F 19 12`) — record behaviour |
| 47 | SPRMIB + error | `19 82` | `7F 19 13` still sent |
| 48 | SPRMIB + pending | `19 84 <DTC> FF` on slow NVM | After `7F 19 78`, final response follows [unverified] |
| 49 | Functional addressing | `19 02 08` functional | Each supporting ECU answers physically; others silent |
| 50 | Functional, unsupported | `19 0F FF` functional to 2020 ECUs | No responses (0x12 suppressed) |
| 51 | Response pending | `19 04 <DTC> FF` on ECU using 0x78 | `7F 19 78` within P2, final response within P2* |
| 52 | P2 on long list | `19 0A` with many DTCs | First Frame within P2server_max |
| 53 | Multi-frame | `19 0A` > 7 bytes on CAN | FF length correct, CF sequence correct, padding per OEM |
| 54 | Flow control variations | FC with BS = 1 and STmin = 20 ms | ECU respects BS and STmin |
| 55 | Very long response | Fill fault memory to the maximum | Correct escape FF or `7F 19 14` |
| 56 | Response too long | ECU without paged buffer, response above buffer | `7F 19 14` |
| 57 | Paged buffer | Second client clears a DTC / a new DTC qualifies during a long `19 02 <mask>` | Removed: announced length kept, padding `00 00 00 00`. Added: in the next read [unverified] |
| 58 | Parser robustness | Responses with leftover bytes, duplicate DTC, unknown record | Parser reports an error, keeps raw bytes |
| 59 | Edition switch | Same suite on a 2013 ECU | 0x0F–0x13 positive (if implemented), 0x1A / 0x56 `7F 19 12` |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 12.3 (stored data transmission functional unit). DTC status bits, fault-handling model and record definitions are in the DTC annex (Annex D). Related: 12.2 ClearDiagnosticInformation, 10.8 ControlDTCSetting, 10.9 ResponseOnEvent. |
| Edition differences | 2013 → 2020: 0x0F, 0x10, 0x11 (mirror memory) and 0x12, 0x13 (emissions OBD) withdrawn; 0x1A reportSupportedDTCExtDataRecord and 0x56 reportDTCInformationByDTCReadinessGroupIdentifier added (cross-checked). Amd 1:2022: 0x16 named reportDTCExtDataRecordByRecordNumber; DTCSnapshotRecordNumber 0x00 / 0xF0 legislated, 0x01–0xEF / 0xF1–0xFE manufacturer, 0xFF all; UserDefDTCSnapshotRecordNumber 0x00–0xFE manufacturer, 0xFF all; DTCFormatIdentifier 0x04 named SAE_J2012-DA_DTCFormat_04; paged-buffer padding with DTC 000000 status 00; Annex D non-OBD confirmation threshold default 1 → 0 (all cross-checked). Severity bit assignments and extended record ranges may differ between editions [unverified]. ISO 14229-1:2026 (June 2026): not yet reviewed for this service. |
| OEM / ECU-specific | Supported report types per session; availability mask; DTC list and its dependency on variant coding; DTC format used; snapshot triggers, record numbers, DIDs and lengths; extended record numbers, lengths and meanings; debounce, qualification, healing, ageing, lamp rules; operation-cycle definition; MemorySelection values; DTCFunctionalUnit and severity values; buffer size and paged-buffer support; 0x22 / 0x33 conditions; CAN IDs and padding. |
| Verification status | draft. Cross-checked (ISO previews, py-uds knowledge base): SID / response SID, clause 12.3 and functional unit, 2020 sub-function list and names, withdrawn and new report types, 0x16 name, snapshot record ranges, DTCFormatIdentifier names, paged-buffer padding, confirmation threshold change. Compared with secondary open-source sources only (not ISO text) — py-uds source (github.com/mdabrowski1990/uds: translator/data_record_definitions conditional.py, dtc.py; utilities/constants/dtc.py), py-uds knowledge base DTC and service pages, python-udsoncan (github.com/pylessard/python-udsoncan, services/ReadDTCInformation.py): field order of the 0x05, 0x09, 0x14, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x42, 0x55, 0x56 requests and responses (0x42 order FunctionalGroupIdentifier, DTCStatusMask, DTCSeverityMask; 0x42 response header group, status avail, severity avail, format; 5-byte severity + DTC + status records; 0x1A avail before record echo; 0x56 readiness-group echo after the format byte); DTCSeverity bit names; FunctionalGroupIdentifier values 0x33 / 0xD0 / 0xFE; DTCExtDataRecordNumber and DTCStoredDataRecordNumber ranges; record presence conditions for 0x05, 0x09, 0x0B–0x0E, 0x14, 0x16; 0x16 record number ≤ 0xEF. Engineering knowledge only: NRC triggers, FDC inclusion detail, status sequences in the HIL use case (both columns are illustrative). |
| Open questions | 0x55 record size (4 bytes per py-uds vs 5 with severity per python-udsoncan); whether `19 14` lists confirmed DTCs that debounce again or DTCs at FDC +127, and FDC reset points; whether 0x1A omits the record-number echo when empty; 0x1A allowed record-number range; `19 02 00` empty positive vs 0x31; `19 09` with unknown DTC: empty positive vs 0x31; meaning of identifier count 0x00 in snapshot records; whether SPRMIB is honoured or rejected for 0x19; position of paged-buffer padding; 0x19 NRC evaluation order; all secondary-source layouts against the ISO 14229-1:2020 text; effect of the 2026 edition. |
