---
sid: 0x2C
name: DynamicallyDefineDataIdentifier
response_sid: 0x6C
has_sub_function: true
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.6 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number and functional unit"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x2C, response SID 0x6C, DID defined in the server then read with ReadDataByIdentifier"
  - "py-uds source (github.com/mdabrowski1990/uds, data_record_definitions/conditional.py, did.py, formula.py) and python-udsoncan DynamicallyDefineDataIdentifier.py: per sub-function request layout (DDDID + 4-byte groups DID/position/size; DDDID + one ALFID + address/size pairs; optional DDDID for clear), response = sub-function echo + DDDID (optional for clear) (reviewer, 2026-10-26)"
  - "ArcCore AUTOSAR Dcm (rtime.ciirc.cvut.cz arc.git, include/Dcm_Types.h): sub-function codes 01/02/03 (reviewer, 2026-10-26)"
---

# 0x2C — DynamicallyDefineDataIdentifier

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x6C
> Builds a new DID at run time from parts of existing DIDs or from memory ranges, so it can be read with 0x22 or 0x2A.

## 1. What is it?

DynamicallyDefineDataIdentifier (DDDI), SID 0x2C, lets the tester create a temporary DID inside the ECU. The
new DID, called a dynamically defined data identifier (DDDID), is a list of source elements. Each element is
either a slice of an existing DID's record (start position + length) or a memory range (address + size).

Once defined, the DDDID can be read like any other DID: with 0x22 once, or with 0x2A periodically. Reading it
returns the concatenation of its source elements, in definition order.

Three sub-functions:

| Value | Name | Short meaning |
|---|---|---|
| 0x01 | defineByIdentifier | Add slices of existing DIDs to the DDDID |
| 0x02 | defineByMemoryAddress | Add memory ranges to the DDDID |
| 0x03 | clearDynamicallyDefinedDataIdentifier | Delete one DDDID, or all of them |

## 2. Why is it needed?

- Testers often need a few bytes from many DIDs. Reading all of them every cycle wastes bandwidth.
- 0x2A only schedules 0xF2xx DIDs. 0x2C is how arbitrary data gets into a schedulable DID.
- Values from different DIDs come from one ECU snapshot, so they are consistent in time.
- Development teams can expose RAM variables (by address) under a DID without a new software build.

Who benefits: validation and HIL engineers building compact logging sets; workshop tools that build a
live-data page; development teams.

## 3. What is its purpose?

It defines and clears DID compositions. It returns no data and changes no application data. It does not
create persistent DIDs: definitions are volatile (see section 5).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| One or two whole DIDs, occasionally | [0x22](0x22-read-data-by-identifier.md) with several DIDs | No definition state to manage |
| One memory range, once | [0x23](0x23-read-memory-by-address.md) | Simpler; same security issue either way |
| Data is already in a 0xF2xx DID | [0x2A](0x2A-read-data-by-periodic-identifier.md) directly | No need to define |
| Production/after-sales with a fixed set | OEM-predefined DID | Stable, documented, no run-time setup |
| Large or fast measurement sets | XCP DAQ lists | Better suited and faster |

## 4. When is it used? — Real use cases

### Use case: Compact periodic logging on a restraint ECU HIL bench
- **Scenario:** Crash-sensor plausibility test. The engineer needs 2 bytes from each of three status DIDs at
  the fast rate.
- **Engineer's objective:** One periodic message carrying all six bytes, sampled together.
- **Why this service:** 0x2A can only schedule 0xF2xx DIDs; 0x2C composes one from the three sources.
- **Tester sends:** `10 03`, `2C 01 F2 01 47 11 01 02 47 12 03 02 47 13 01 02` (sources illustrative), then
  `2A 03 01`. At the end: `2A 04 01`, `2C 03 F2 01`.
- **ECU is expected to:** Accept the definition, then send PDID 0x01 with 6 bytes at the fast rate.
- **Engineer obtains:** Time-aligned values in one stream.
- **Test on success / failure:** Pass if every periodic message has exactly 6 data bytes and matches 0x22
  reads of the sources. NRC 0x31 at definition means a source DID, position or size is invalid.
- **Transport check:** 6 data bytes fit a type 2 periodic frame (PDID + 7) on classic CAN, but not a type 1
  frame (`6A` + PDID + 5). On an ECU that uses type 1 over classic CAN, expect `7F 2A 31` when scheduling,
  and split the data over two DDDIDs [unverified] — see [0x2A](0x2A-read-data-by-periodic-identifier.md#5-how-does-it-work).

### Use case: Exposing a RAM variable under a DID during development
- **Scenario:** Development ECU; the engineer wants a RAM word in a CANoe diagnostic console without new
  software.
- **Engineer's objective:** Read the variable by DID, repeatedly, with the existing 0x22 tooling.
- **Why this service:** defineByMemoryAddress wraps an address range in a DID.
- **Tester sends:** Security unlock, then `2C 02 F3 01 14 20 00 4A 10 04`, then `22 F3 01` as needed.
- **ECU is expected to:** Accept, then return 4 bytes from that address on each read.
- **Engineer obtains:** The variable through normal DID reads.
- **Test on success / failure:** Values must equal a 0x23 read of the same address.

## 5. How does it work?

1. Tester sends `2C` + sub-function + parameters.
2. ECU checks length, sub-function, DDDID range, each source (DID supported, position and size inside its
   record; or address range allowed), total length, security and session.
3. On success, the ECU stores the definition and replies with the sub-function echo and the DDDID.
4. Later reads of the DDDID assemble the data from the sources at read time.

**Rules:**
- **DDDID range:** 0xF300–0xF3FF. For use with 0x2A, the DDDID must be a periodic DID in 0xF200–0xF2FF; ECUs
  differ on whether 0x2C may define those [unverified] [OEM-specific].
- **Appending:** a second define request for the same DDDID adds its elements after the existing ones; it does
  not replace them [unverified]. To redefine, clear first.
- **Mixing:** one DDDID may combine elements from 0x01 and 0x02 requests [unverified].
- **positionInSourceDataRecord** is 1-based: 0x01 = first byte of the source record [unverified].
- **Volatile:** definitions are lost on ECU reset, power cycle and on return to the default session
  [unverified for the session rule]. Never assume a DDDID survives a test step that changes session.
- **Read-time checks:** security and session of the sources are checked again when the DDDID is read
  [unverified]. A DDDID does not bypass protection.
- **Limits:** maximum number of DDDIDs, elements per DDDID and total length are ECU-specific.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Extended (non-default) | OEM |
| Security / authentication | None for DID sources in many ECUs; 0x27 for 0x02 (memory) | OEM |
| ECU operating conditions | Free DDDID slots | OEM |
| Timing (P2 / P2* / S3) | Answer within P2; definitions lost if S3 expires | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** 0x10 (session), 0x3E (keep it), 0x27/0x29 (memory sources), 0x22 and 0x2A for reading.

## 6. Request and response formats

### Request

Common part:

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x2C |
| 2 | sub-function | 1 | Bit 7 = SPRMIB; bits 6–0 = 0x01, 0x02 or 0x03 |

0x01 defineByIdentifier:

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 3–4 | dynamicallyDefinedDataIdentifier | 2 | Target DDDID |
| 5–6 | sourceDataIdentifier #1 | 2 | Existing DID |
| 7 | positionInSourceDataRecord #1 | 1 | 1-based start byte in the source record |
| 8 | memorySize #1 | 1 | Number of bytes to take |
| 9 … | further (source DID, position, size) groups | 4 each | Optional |

0x02 defineByMemoryAddress:

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 3–4 | dynamicallyDefinedDataIdentifier | 2 | Target DDDID |
| 5 | addressAndLengthFormatIdentifier | 1 | Same as [0x23](0x23-read-memory-by-address.md): high nibble size length, low nibble address length; applies to all groups |
| 6 … | memoryAddress #1, memorySize #1 | per ALFID | Big-endian |
| … | further (address, size) groups | per ALFID | Optional |

0x03 clearDynamicallyDefinedDataIdentifier:

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 3–4 | dynamicallyDefinedDataIdentifier | 2 | Optional. Present: clear that DDDID. Absent: clear all DDDIDs |

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x01 | defineByIdentifier | Appends slices of existing DID records | Compact logging sets, 0x2A input | Sources must be readable in the active session |
| 0x02 | defineByMemoryAddress | Appends memory ranges | Development, RAM inspection | Usually secured; often absent in series software |
| 0x03 | clearDynamicallyDefinedDataIdentifier | Deletes one or all definitions | Test teardown | Clearing an undefined DDDID: positive or 0x31, ECU-dependent [unverified] |
| 0x81–0x83 | same with SPRMIB set | As above, no positive response | Fast setup sequences | NRCs are still sent |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x6C |
| 2 | sub-function | 1 | Echo, bit 7 cleared |
| 3–4 | dynamicallyDefinedDataIdentifier | 2 | Echo; absent after `2C 03` without a DDDID |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Sub-function other than 0x01–0x03, or 0x02 not implemented |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Incomplete source group; length does not match the ALFID |
| 0x22 | conditionsNotCorrect | OEM conditions not met |
| 0x31 | requestOutOfRange | DDDID outside allowed range; source DID unsupported; position 0 or beyond the record; size runs past the record end; invalid ALFID or address range; total DDDID length or element count exceeded |
| 0x33 | securityAccessDenied | Memory source or secured source DID requires unlock |
| 0x7F | serviceNotSupportedInActiveSession | Service not allowed in the current session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Source DIDs 0x4711–0x4713, addresses and data are illustrative.

defineByIdentifier, then read with 0x22.

```uds
REQ 2C 01 F3 00 F1 90 0A 08 47 11 01 02   # F300 = VIN bytes 10..17 + 0x4711 bytes 1..2
POS 6C 01 F3 00
REQ 22 F3 00
POS 62 F3 00 30 30 30 30 30 30 30 31 01 F4   # 8 VIN bytes + 2 bytes of 0x4711
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 2 | 01 | defineByIdentifier |
| REQ 3–4 | F3 00 | Target DDDID 0xF300 |
| REQ 5–6 | F1 90 | Source DID VIN |
| REQ 7 | 0A | Start at byte 10 (1-based) |
| REQ 8 | 08 | Take 8 bytes (bytes 10–17) |
| REQ 9–10 | 47 11 | Source DID 0x4711 (illustrative) |
| REQ 11–12 | 01 02 | Start at byte 1, take 2 bytes |
| POS | 6C 01 F3 00 | Response SID, sub-function echo, DDDID echo |
| 0x22 POS 4–11 | 30 … 31 | VIN bytes 10–17 (illustrative VIN) |
| 0x22 POS 12–13 | 01 F4 | First 2 bytes of 0x4711 (illustrative) |

defineByMemoryAddress, then clear.

```uds
REQ 2C 02 F3 01 14 20 00 4A 10 04   # F301 = 4 bytes at 0x20004A10 (illustrative)
POS 6C 02 F3 01
REQ 22 F3 01
POS 62 F3 01 00 00 01 2C
REQ 2C 03 F3 01         # clear F301
POS 6C 03 F3 01
REQ 2C 03               # clear all
POS 6C 03
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 2 | 02 | defineByMemoryAddress |
| REQ 3–4 | F3 01 | Target DDDID |
| REQ 5 | 14 | ALFID: 1-byte size, 4-byte address |
| REQ 6–9 | 20 00 4A 10 | Address (illustrative) |
| REQ 10 | 04 | 4 bytes |
| `2C 03 F3 01` | | Clear one DDDID; response echoes it |
| `2C 03` | | Clear all; response has no DDDID |

Combining with 0x2A: define a periodic DID, schedule it, stop and clear.

```uds
REQ 2C 01 F2 01 47 11 01 02 47 12 03 02   # F201 = 2 bytes of 0x4711 + 2 bytes of 0x4712 (illustrative)
POS 6C 01 F2 01
REQ 2A 03 01            # PDID 01 = DID F201, fast rate
POS 6A
PER 6A 01 01 F4 00 03   # type 1 periodic message (illustrative data)
REQ 2A 04 01
POS 6A
REQ 2C 03 F2 01
POS 6C 03 F2 01
```

| Line | Bytes | Meaning |
|---|---|---|
| REQ 3–4 | F2 01 | DDDID in the periodic range, so 0x2A can schedule it [unverified ECU support] |
| PER 2 | 01 | PDID = low byte of 0xF201 |
| PER 3–6 | 01 F4 00 03 | 0x4711 bytes 1–2, then 0x4712 bytes 3–4 |

Suppressed positive response, then negative responses.

```uds
REQ 2C 81 F3 00 F1 90 01 11   # SPRMIB set: define F300 = full VIN
NOTE no positive response is sent; the definition is stored
REQ 2C 04 F3 00         # unknown sub-function
NEG 7F 2C 12
REQ 2C 01 F3 00 F1 90 01      # group missing memorySize
NEG 7F 2C 13
REQ 2C 01 12 34 F1 90 01 11   # target outside DDDID range
NEG 7F 2C 31
REQ 2C 01 F3 00 F1 90 12 01   # position 18 beyond 17-byte VIN
NEG 7F 2C 31
REQ 2C 02 F3 01 14 20 00 4A 10 04   # locked
NEG 7F 2C 33
```

| Exchange | Problem | NRC |
|---|---|---|
| SPRMIB | Bit 7 set (0x81) | None on success |
| 2 | Sub-function 0x04 | 12 |
| 3 | 7 bytes; group needs 4 bytes after DDDID | 13 |
| 4 | DDDID 0x1234 not dynamic | 31 |
| 5 | Position 0x12 = 18 > VIN length 17 | 31 |
| 6 | Memory source without unlock | 33 |

## 7. Implementation and testing

**Implementation:**
- Builder: separate functions per sub-function. For 0x01 take a list of (DID, position, size); validate
  position ≥ 1 and size ≥ 1 locally when the source length is known. For 0x02 reuse the 0x23 ALFID builder; one
  ALFID covers all groups.
- Keep a local model of each DDDID's layout (list of sources and lengths) so the 0x22/0x2A parser can split the
  data. Update it on append and clear.
- Always clear in teardown (`2C 03`), and redefine after any session change, reset or S3 loss.
- With SPRMIB, confirm success by reading the DDDID with 0x22.
- Check the total length against the ECU limit and, for 0x2A, against the periodic message size.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Define by DID | Valid 0x01 request | `6C 01` + DDDID; 0x22 returns concatenation |
| 2 | Define by memory | Valid 0x02 request, unlocked | `6C 02` + DDDID; matches 0x23 read |
| 3 | Append | Second 0x01 on same DDDID | Data = old elements + new elements [unverified] |
| 4 | Clear one | `2C 03 F3 00` | `6C 03 F3 00`; `22 F3 00` → `7F 22 31` |
| 5 | Clear all | `2C 03` | `6C 03`; all DDDIDs undefined |
| 6 | Clear undefined | `2C 03` on unused DDDID | Record: positive or `7F 2C 31` |
| 7 | SPRMIB | `2C 81 …`, `2C 83 …` | No response; definition effective |
| 8 | SPRMIB with error | `2C 81` with invalid source | `7F 2C 31` still sent |
| 9 | Unknown sub-function | `2C 00`, `2C 04` | `7F 2C 12` |
| 10 | Length min-1 | `2C 01 F3 00 F1 90 01` | `7F 2C 13` |
| 11 | Length min | One complete group | Positive |
| 12 | Max elements / max total length | ECU limit | Positive |
| 13 | Max+1 | One element or byte over | `7F 2C 31` |
| 14 | Position/size boundaries | Position 0; last byte; one past end | `7F 2C 31`, positive, `7F 2C 31` |
| 15 | DDDID range | 0xF2FF/0xF300/0xF3FF/0xF400 | Per ECU spec; 0xF400 → `7F 2C 31` |
| 16 | Session matrix | Define in default, extended | Default usually `7F 2C 7F` |
| 17 | Volatility | Define, then `10 01` / `11 01` / S3 expiry | DDDID gone [unverified for session rule] |
| 18 | Security at read time | DDDID from secured DID, then relock | 0x22 on DDDID → `7F 22 33` [unverified] |
| 19 | 0x2A combination | Define 0xF2xx, schedule | Periodic data = defined content |
| 20 | Functional addressing | Define request functional | Record behaviour; usually physical only |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.6 (data transmission functional unit). |
| Edition differences | No layout change between 2013 and 2020 known [unverified]. 2020 authentication may add NRC 0x34 for memory sources [edition-dependent] [unverified]. 2026 edition not yet reviewed. |
| OEM / ECU-specific | Allowed DDDID range (0xF2xx usable or not); maximum DDDIDs, elements and length; whether 0x02 exists; session and security; behaviour when clearing an undefined DDDID. |
| Verification status | cross-checked. Reviewer 2026-10-26: status raised to cross-checked — sub-function codes and per-sub-function request/response layout confirmed by py-uds, python-udsoncan and ArcCore Dcm source. Previously draft. Cross-checked: clause number, SID/response SID, purpose and link to 0x22 (py-uds docs); sub-function codes and names (pyudskit, ArcCore Dcm). Reviewer 2026-10-26: request layouts per sub-function, one ALFID for all memory groups, and response layout (DDDID absent after clear-all) match py-uds and python-udsoncan source (open-source, not normative). Append rule, 1-based position, volatility and read-time checks remain engineering knowledge. |
| Open questions | Append vs replace on redefinition (append is the widely implemented behaviour; ISO text not checked); 1-based position (neither open-source library documents it — python-udsoncan even accepts 0); session-change clearing; read-time security checks; whether 0x2C may target 0xF2xx in the 2020 text. |
