---
sid: 0x10
name: DiagnosticSessionControl
response_sid: 0x50
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.2 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (standards.iteh.ai sample 72439): clause 10.2"
  - "py-uds knowledge base (uds.readthedocs.io, latest; service.rst source): request/response layout, diagnosticSessionType ranges, P2/P2* resolutions"
  - "udsoncan documentation (udsoncan.readthedocs.io): session values 01-04; P2/P2* are for the activated session; record manufacturer-specific in 2006, P2/P2* from 2013"
  - "py-uds knowledge base states page (uds.readthedocs.io): unlocked security level cleared on any session change or reset"
---

# 0x10 — DiagnosticSessionControl

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x50
> Switches the server into a diagnostic session and reports the response timing that applies in that session.

## 1. What is it?

DiagnosticSessionControl (SID 0x10) selects the diagnostic session of a server. A session is an operating
mode that decides which services, sub-functions, DIDs and routines are available, which security levels can
be unlocked, and which timing applies. The request has one sub-function byte (the session type). The positive
response echoes it and returns the session parameter record: P2server_max and P2*server_max of the session
that is now active.

Every server is in defaultSession after power-up or reset. Every other session is temporary. It ends when the
client requests another session, when the server resets, or when S3server expires without diagnostic activity.

## 2. Why is it needed?

- Risky functions (flash erase, actuator override, calibration writes, pyrotechnic deployment) must not be
  reachable during normal driving or by accident. The session is the first gate; security (0x27 / 0x29) is
  the second.
- The server needs to know that a tester is actively working with it before it relaxes normal behaviour
  (communication control, DTC setting off, IO overrides).
- The bootloader needs a defined entry point: programmingSession.
- The response tells the client the server's real P2 / P2* values, so the tester sets its timeouts from the
  ECU instead of guessing.

Who gets value: flash tools and testers (first step of nearly every sequence), validation teams (session
matrix and timeout tests), production line (EOL coding in extended session), workshops.

## 3. What is its purpose?

It enables session-restricted services, flashing and safety-system procedures. It changes the active session,
re-locks security and resets temporary states of other services (see transitions in section 5). It returns
the session timing. It does not unlock security, keep the session alive, or report the current session
without changing it.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Find out which session is active | 0x22 with DID 0xF186 ActiveDiagnosticSession | Reading does not change state; re-requesting a session does |
| Keep the current session alive | [0x3E TesterPresent](0x3E-tester-present.md) | Re-sending 0x10 re-locks security and resets temporary states |
| Unlock protected services | [0x27 SecurityAccess](0x27-security-access.md) or 0x29 Authentication | The session only makes the unlock possible |
| Restart the ECU | [0x11 ECUReset](0x11-ecu-reset.md) | 10 01 resets session states, not the ECU |
| Change P2/P2* at runtime on a 2013 ECU | [0x83 AccessTimingParameter](0x83-access-timing-parameter.md) (withdrawn in 2020) | 0x10 reports timing; it cannot set it |

## 4. When is it used? — Real use cases

### Use case: Entering the bootloader for flashing
- **Scenario:** Workshop or end-of-line reflash of an ECU application over CAN.
- **Engineer's objective:** Get the target ECU into its bootloader while the rest of the network is quiet.
- **Why this service:** Download services (0x34/0x36/0x37) and the erase routine are normally available only in
  programmingSession.
- **Tester sends:** `10 83` functional, `85 82` and `28 83 01` functional (see
  [0x28](0x28-communication-control.md)), then `10 02` physical to the target, then 0x27.
- **ECU is expected to:** Accept 10 02 only from extendedDiagnosticSession and only if preconditions hold
  [OEM-specific]; possibly answer `7F 10 78` while it jumps to the bootloader, then `50 02` with bootloader timing.
- **Engineer obtains:** Confirmation that the bootloader is running and the P2* to use for erase and write.
- **Test on success / failure:** Success: `50 02 ..` and `22 F1 86` returns 02 (if the DID is supported).
  Failure: `7F 10 22` (voltage, speed, engine running) or `7F 10 7E` (requested from default session).

### Use case: Session matrix and S3 validation on a HIL bench
- **Scenario:** Validation of an airbag control unit on a HIL bench with squib simulators.
- **Engineer's objective:** Prove each service is accepted only in the sessions the OEM spec allows, and that
  the ECU falls back to default after S3server.
- **Why this service:** It is the only way to enter each session under test.
- **Tester sends:** Each supported session in turn, then the service list for that session; then no traffic
  for longer than S3server.
- **ECU is expected to:** Return 0x7F / 0x7E outside the allowed sessions; after S3 expiry report session 01
  and be locked again.
- **Engineer obtains:** A filled session matrix and the measured S3 timeout.
- **Test on success / failure:** Any service answering positively in a session the spec forbids is a defect;
  a session that survives longer than S3server + tolerance is a defect.

### Use case: safetySystemDiagnosticSession on a restraint ECU
- **Scenario:** End-of-life deployment of pyrotechnic devices (ISO 26021-2) or an OEM safety-related procedure
  on a restraint control unit.
- **Engineer's objective:** Check that the ECU enters session 04 only under the specified vehicle conditions and
  that leaving the session (request, S3 or reset) drops any prepared state.
- **Why this service:** 0x04 is the ISO session reserved for safety systems; restraint ECUs commonly gate
  deployment-related functions behind it [OEM-specific].
- **Tester sends:** `10 04` with the vehicle stationary and conditions met; repeat with each condition violated.
- **ECU is expected to:** Return `50 04 ..` when allowed; `7F 10 22` or a specific NRC such as 0x88
  vehicleSpeedTooHigh when not; return to default on S3 expiry.
- **Engineer obtains:** Evidence that the safety session cannot be entered or kept outside its conditions.
- **Test on success / failure:** On a bench, squib outputs must go to squib simulators or resistive loads,
  never live inflators. Exact ISO 26021-2 service sequence: check that standard [unverified].

## 5. How does it work?

1. Client sends `10 <sessionType>`.
2. Server checks length (0x13), sub-function support (0x12), whether the session can be entered from the active
   one (0x7E, or 0x22 on some ECUs), then conditions (0x22 or 0x81–0x93). General order:
   [protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order).
3. If accepted, the server sends `50 <sessionType> P2 P2*` (unless SPRMIB is set) and the new session is active.
   The timing values are those of the newly activated session (udsoncan docs: "for the activated diagnostic
   session"). Which timing the server uses to send this response itself (old or new P2) is not settled here
   [unverified].
4. For programmingSession many ECUs store a flag and reset into the bootloader. They send `7F 10 78` first and
   the bootloader sends the final `50 02 ..` after start-up [OEM-specific].
5. In any non-default session the server restarts S3server after each completed request (including 0x3E). If
   S3server (commonly 5000 ms) elapses with no request, the server returns to defaultSession. There is no S3
   in defaultSession. Timing details: [protocol-fundamentals.md](../protocol-fundamentals.md#timing).

**Session transitions — what is reset.** Summary in this repository's words; every row is [unverified] until
checked against clause 10.2 of the edition in use.

| Transition | Security (0x27) | 0x28 / 0x85 states | ROE (0x86), periodic DIDs (0x2A), IO control (0x2F) |
|---|---|---|---|
| default → default | stays locked | stay at defaults | default session re-initialised; temporary changes undone; NVM writes kept |
| default → non-default | stays locked | unchanged | ROE events set up in default stopped [unverified] |
| non-default → same or other non-default | re-locked | **kept** (this is why a flash sequence can switch 03 → 02 without the bus waking up). Some stacks (e.g. AUTOSAR Dcm configurations) re-enable them when the new session does not support 0x28 / 0x85 [unverified] | ROE stopped; periodic DIDs and IO control kept only where the new session supports them [unverified] |
| non-default → default (10 01 or S3 expiry) | re-locked | reset: comm enableRxAndTx, DTC setting on | ROE stopped, periodic transmission stopped, IO control returned to ECU; dynamically defined DIDs may be cleared [unverified] |
| any → default by reset or power cycle | locked | reset | as power-up |

Open point: whether an Authentication (0x29) state survives a session change is not covered here [unverified].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | 0x10 itself is accepted in every session; target session must be reachable from the active one | Reachability OEM |
| Security / authentication | None for 01/03; some ECUs require security before 02 or supplier sessions | OEM |
| ECU operating conditions | 02 and 04: vehicle stationary, engine off, voltage in range, no crash in progress | OEM |
| Timing (P2 / P2* / S3) | Response within P2server_max of the current session; S3 applies once in non-default | ISO 14229-2 + OEM values |

**Depends on:** 0x3E to keep non-default sessions alive; 0x27 / 0x29 after every session change; ISO-TP
single frame both ways; on DoIP, routing activation first (and again if the ECU resets into the bootloader
[unverified]).

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x10 |
| 2 | sub-function: SPRMIB (bit 7) + diagnosticSessionType (bits 6–0) | 1 | see table below |

Total length is exactly 2 bytes.

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | reserved | — | — | 0x12 expected |
| 0x01 | defaultSession | Returns to normal operation; resets temporary states | End of every diagnostic job | Active after power-up |
| 0x02 | programmingSession | Enables flash download services; often runs in the bootloader | Reflash | Often only reachable from 0x03 [OEM-specific] |
| 0x03 | extendedDiagnosticSession | Enables writes, IO control, routines, DTC/comm control | Workshop, EOL, validation | Most common non-default session |
| 0x04 | safetySystemDiagnosticSession | Enables safety-system functions | Restraint systems, ISO 26021 deployment | Strict preconditions [OEM-specific] |
| 0x05–0x3F | reserved | — | — | 0x12 expected |
| 0x40–0x5F | vehicleManufacturerSpecific | OEM session (e.g. EOL or development) | Production, development | Meaning from OEM spec only |
| 0x60–0x7E | systemSupplierSpecific | Supplier session (e.g. debug) | Supplier development | Usually disabled in series |
| 0x7F | reserved | — | — | 0x12 expected |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | 0x50 |
| 2 | diagnosticSessionType | 1 | Echo of the request, bit 7 = 0 |
| 3–4 | P2server_max | 2 | Unsigned, big-endian, 1 ms per bit → 0 … 65 535 ms |
| 5–6 | P2*server_max | 2 | Unsigned, big-endian, 10 ms per bit → 0 … 655 350 ms |

**Decoding the session parameter record.** Read bytes 3–4 as one 16-bit number in milliseconds. Read bytes 5–6
as one 16-bit number and multiply by 10 to get milliseconds. Set the tester's P2client and P2*client to these
values plus a transport margin (OEM tester spec).

```python
p2_ms = int.from_bytes(rsp[2:4], "big")            # 1 ms resolution
p2_star_ms = int.from_bytes(rsp[4:6], "big") * 10  # 10 ms resolution
```

ECUs built to ISO 14229-1:2006 may return a session parameter record with manufacturer-specific content
(udsoncan docs) or none at all [edition-dependent]. A parser should accept a 2-byte response or a raw record
when configured for such ECUs.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Reserved value, or a session this ECU does not implement |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request is not exactly 2 bytes |
| 0x22 | conditionsNotCorrect | Target session blocked by vehicle state (speed, ignition, voltage, crash in progress) |
| 0x33 | securityAccessDenied | ECU requires prior unlock to enter this session [OEM-specific] |
| 0x34 | authenticationRequired | 2020 ECU requires Authentication (0x29) before this session [OEM-specific] |
| 0x78 | requestCorrectlyReceived-ResponsePending | Switching to the bootloader or preparing the session takes longer than P2 |
| 0x7E | subFunctionNotSupportedInActiveSession | Target session not reachable from the active session (e.g. 02 from 01) |
| 0x81–0x93 | specific conditions | Used instead of 0x22 when the failing condition is known (e.g. 0x88, 0x93) [OEM-specific] |

0x11 and 0x7F should never appear: 0x10 must be supported in every session.
Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 10 03                    # extendedDiagnosticSession, physical
POS 50 03 00 32 01 F4        # P2 = 50 ms, P2* = 5000 ms (illustrative values)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 10 | SID | DiagnosticSessionControl |
| 03 | sub-function | extendedDiagnosticSession, SPRMIB = 0 |
| 50 | RSID | 0x10 + 0x40 |
| 03 | echo | Session now active |
| 00 32 | 50 | P2server_max = 50 ms |
| 01 F4 | 500 | P2*server_max = 500 × 10 ms = 5000 ms |

```uds
REQ 10 02                    # programmingSession, physical, from extended session
NEG 7F 10 78                 # ECU is resetting into its bootloader (OEM-specific behaviour)
POS 50 02 00 19 0B B8        # sent by the bootloader (timing illustrative)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 10 02 | request | programmingSession |
| 7F 10 78 | NRC 0x78 | Accepted, final answer later; tester switches to P2* timing |
| 50 02 | RSID + echo | programmingSession active |
| 00 19 | 25 | P2server_max = 25 ms (illustrative) |
| 0B B8 | 3000 | P2*server_max = 3000 × 10 ms = 30 000 ms (illustrative) |

```uds
REQ 10 02                    # programmingSession requested while in defaultSession
NEG 7F 10 7E                 # not reachable from the active session (some ECUs use 22)
REQ 10 05                    # reserved session type
NEG 7F 10 12
REQ 10 03 00                 # one byte too long
NEG 7F 10 13
REQ 10 04                    # safetySystemDiagnosticSession with vehicle moving
NEG 7F 10 22                 # conditionsNotCorrect (or 88 vehicleSpeedTooHigh)
```

| Request | Response | Why |
|---|---|---|
| 10 02 | 7F 10 7E | Transition 01 → 02 not allowed by the OEM session model |
| 10 05 | 7F 10 12 | 0x05 is reserved |
| 10 03 00 | 7F 10 13 | Length 3, must be 2 |
| 10 04 | 7F 10 22 | Precondition (vehicle stationary) not met |

```uds
REQ 10 83                    # extendedDiagnosticSession, SPRMIB set, functional
NOTE no positive response from any ECU; an ECU may still send 22 (not 12 or 7E, which are suppressed)
REQ 10 81                    # back to defaultSession, SPRMIB set, functional
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 10 83 | 0x83 = 0x80 + 0x03 | SPRMIB + extendedDiagnosticSession |
| 10 81 | 0x81 = 0x80 + 0x01 | SPRMIB + defaultSession |

```uds
REQ 10 03
POS 50 03 00 32 01 F4
NOTE no diagnostic request for longer than S3server (5000 ms typical)
REQ 22 F1 86                 # ReadDataByIdentifier ActiveDiagnosticSession
POS 62 F1 86 01              # server fell back to defaultSession
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 22 F1 86 | DID 0xF186 | ActiveDiagnosticSession |
| 62 F1 86 | RSID + DID | Positive response |
| 01 | session | defaultSession — S3 expiry worked |

## 7. Implementation and testing

**Implementation:**

- Request builder: input session type (0x01–0x7E) and an SPRMIB flag. Refuse 0x00 and 0x7F unless the caller
  asks for a negative test.
- Response parser: check RSID 0x50, echo, length 6 (or 2 for configured legacy ECUs); decode P2 and P2* as in
  section 6; update the tester's P2client / P2*client.
- State model in the tester: after any session change, mark security locked. After a change to default, mark
  communication enabled and DTC setting on.
- Start the TesterPresent scheduler when entering a non-default session; stop it on return to default.
- programmingSession: accept 0x78 and allow for bootloader start-up time. Re-establish DoIP routing if the
  ECU resets.
- Edge cases: ECU replies with the old session's timing before switching; bootloader answers on different CAN
  IDs [OEM-specific]; requesting the already active session still resets states.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path per session | 10 01 / 03 / 02 / 04 from the allowed source session | 50 xx + 4 timing bytes |
| 2 | Timing values | Decode P2 / P2* for each session | Equal to OEM spec values |
| 3 | Reserved values | 10 00, 10 05, 10 3F, 10 7F | 7F 10 12 |
| 4 | Unsupported OEM / supplier values | 10 40 … 10 7E not in spec | 7F 10 12 |
| 5 | Length min-1 | 10 | 7F 10 13 |
| 6 | Length min = max | 10 03 | Positive |
| 7 | Length max+1 | 10 03 00 | 7F 10 13 |
| 8 | Forbidden transition | 10 02 from default | 7F 10 7E (or 22 per spec) |
| 9 | Preconditions | 10 02 / 10 04 with speed > 0, low voltage, engine on | 7F 10 22 or specific NRC 0x81–0x93 |
| 10 | Session matrix | Each service of the ECU in each session | Matches OEM matrix; 0x7F / 0x7E elsewhere |
| 11 | Security re-lock | Unlock in 03, send 10 03 again, call protected service | 7F xx 33 |
| 12 | States kept 03 → 02 | 85 82 + 28 03 01, then 10 02 | DTC setting and comm stay disabled [unverified] |
| 13 | States reset on default | Same setup, then 10 01 | Comm enabled, DTC setting on, IO control released, 0x2A stopped |
| 14 | S3 expiry | Enter 03, no traffic for S3server + 10 % | 22 F1 86 → 01; security locked |
| 15 | S3 kept alive | Enter 03, 3E 80 every 2 s for 60 s | Session stays 03 |
| 16 | S3 boundary | Silence for S3server − 10 % | Session stays 03 |
| 17 | SPRMIB | 10 83 | No response; 22 F1 86 → 03 |
| 18 | SPRMIB with error | 10 85 physical | 7F 10 12 still sent |
| 19 | Functional | 10 03 functional | Every supporting ECU answers 50 03 .. |
| 20 | Functional with unsupported value | 10 05 functional | No response (0x12 suppressed) |
| 21 | Response pending | 10 02 into bootloader | First 0x78 within P2server_max; final within P2*server_max |
| 22 | Reset | In 03, send 11 01 | After restart 22 F1 86 → 01 |
| 23 | Safety session (restraint ECU) | 10 04 with each precondition violated | Rejected; S3 expiry or 10 01 drops any prepared state |
| 24 | Multi-frame | — | Not applicable: request and response are single frames |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.2 (preview TOC). Timing parameters: ISO 14229-2. Safety-system deployment: ISO 26021-2. |
| Edition differences | No 2013 ↔ 2020 change known for 0x10 [unverified]. ISO 14229-1:2006 ECUs may use a manufacturer-specific session parameter record (udsoncan docs) [edition-dependent]. ISO 14229-1:2026 not yet reviewed. |
| OEM / ECU-specific | Session reachability, preconditions, timing values, security before 02, use of 0x40–0x7E, bootloader 0x78 behaviour, which states are kept between non-default sessions. |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: request layout, sub-function values and ranges, response layout with P2 (1 ms) / P2* (10 ms) (py-uds knowledge base service.rst); P2/P2* belong to the activated session and the record is manufacturer-specific before 2013 (udsoncan docs); security re-locked on any session change (py-uds states page); clause number (ISO 2020 preview TOC). Session transition table not checked against ISO text and stays [unverified]. |
| Open questions | Exact reset list per transition (ROE, 0x2A, 0x2C, 0x2F) in clause 10.2; whether 0x29 authentication survives a session change; whether the server sends the 0x50 response itself under old or new session timing. |
