---
sid: 0x2F
name: InputOutputControlByIdentifier
response_sid: 0x6F
has_sub_function: false
functional_unit: "Input/output control"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "13.2 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview TOC (cdn.standards.iteh.ai sample 72439): clause 13.2, functional unit 13 input/output control"
  - "py-uds knowledge base (uds.readthedocs.io): SID 0x2F / response SID 0x6F only"
  - "py-uds source (github.com/mdabrowski1990/uds: constants/other.py INPUT_OUTPUT_CONTROL_PARAMETER_MAPPING 00-03; data_record_definitions/conditional.py: controlState and optional controlEnableMask only after 03; response carries controlState for 00-03) (reviewer, 2026-10-26)"
  - "python-udsoncan InputOutputControlByIdentifier.py: ControlParam 0-3, request order DID + control param + values + mask, control param optional, response = DID echo + control param echo + decoded state (reviewer, 2026-10-26)"
  - "ArcCore AUTOSAR Dcm (include/Dcm_Types.h): returnControlToECU 0x00, resetToDefault 0x01, freezeCurrentState 0x02, shortTermAdjustment 0x03 (reviewer, 2026-10-26)"
---

# 0x2F — InputOutputControlByIdentifier

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x6F
> Lets the tester temporarily take over an ECU input or output, identified by a DID, and hand it back.

## 1. What is it?

InputOutputControlByIdentifier (SID 0x2F) lets a client override what the ECU application would do with an
input signal or an output (lamp, relay, motor, valve, PWM output, internal signal). The signal is addressed by a
2-byte data identifier (DID). An **inputOutputControlParameter** byte says what to do with it: give control back
to the ECU, apply the default value, freeze the current value, or apply a value the tester supplies. For DIDs
that hold several signals, a **controlEnableMaskRecord** selects which of them the request affects.

The positive response echoes the DID and the control parameter and reports the signal state that is now in
effect. Control is temporary: it ends on request, on a session change to default, or on reset.

## 2. Why is it needed?

Normal operation never lets an outside tool drive an actuator; the application software owns every output.
Engineers still need to:

- **Production line:** prove each actuator and its wiring work (lamp lights, motor turns, valve clicks) before
  the vehicle leaves the line, without the conditions that would normally trigger them.
- **Workshop:** isolate a fault — is the motor broken, the wiring, or the ECU logic? Driving the output directly
  answers that.
- **Validation / HIL:** put an output into a known state, or hold a signal still, to test downstream ECUs or
  reactions in isolation.
- **Development:** freeze an output while measuring, or apply a test value without reflashing.

0x2E WriteDataByIdentifier changes stored data (often NVM) and does not take an output away from the
application. 0x31 RoutineControl runs a defined sequence; 0x2F sets one state and holds it.

## 3. What is its purpose?

It gives the tester a short-lived, explicitly released override of individual signals. It changes the live
value of an input or output. It does not change calibration or NVM, and it does not survive a session change
or reset [unverified for every ECU]. It is not a way to bypass safety functions: the ECU decides which signals
are controllable at all, and under which conditions.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| You need a persistent configuration or calibration change | 0x2E WriteDataByIdentifier | 0x2F overrides are temporary |
| The action is a sequence with a result (self-test, calibration, erase) | 0x31 RoutineControl | Routines have start / stop / results |
| You only want to read the signal's current value | 0x22 ReadDataByIdentifier | No override needed |
| You want to stop the ECU sending messages | 0x28 CommunicationControl | Not a signal override |
| You want to test a pyrotechnic / firing-loop output of a restraint ECU | Not available | Firing loops must never be IO-controllable; out of scope here |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: End-of-line check of the passenger-airbag-off indicator
- **Scenario:** Restraint ECU with an output that drives the "passenger airbag off" indicator lamp. EOL station
  with a camera or operator check.
- **Engineer's objective:** Prove lamp, wiring and driver stage work in both states.
- **Why this service:** The lamp normally follows occupant classification; the station cannot create those
  conditions on the line.
- **Tester sends:** `10 03` → (`27` if required) → `2F 47 11 03 01` (on) → `2F 47 11 03 00` (off) →
  `2F 47 11 00` (return control). DID `0x4711` is illustrative.
- **ECU is expected to:** Drive the lamp to each commanded state, answer `6F 47 11 03 ..`, and resume normal lamp
  logic after `00`.
- **Engineer obtains:** Visual confirmation plus the ECU's echoed state for each step.
- **Test on success / failure:** Success = lamp state matches each command and normal state resumes. Failure =
  lamp does not change (wiring / driver fault) or stays forced after `00` (ECU defect).

### Use case: Workshop actuator test of an EV coolant pump
- **Scenario:** Battery over-temperature complaint. The thermal-management ECU controls an electric coolant pump.
- **Engineer's objective:** Decide whether the pump, its wiring, or the control logic is at fault.
- **Why this service:** Commanding a duty cycle directly takes the control logic out of the loop.
- **Tester sends:** `2F 47 12 03 32 00 80` — DID `0x4712` (illustrative) with pump duty and fan duty; mask
  selects only the pump; `0x32` = 50 % (illustrative scaling).
- **ECU is expected to:** Run the pump at 50 %, leave the fan under ECU control, answer with both current values.
- **Engineer obtains:** Pump speed or flow at a known duty; current fan value for reference.
- **Test on success / failure:** Success = flow/current in the expected range. Failure = no flow at a commanded
  duty → pump or wiring; `7F 2F 22` → preconditions (e.g. HV not ready) not met.

### Use case: HIL validation of the restraint-ECU safety interlock
- **Scenario:** HIL bench with squib substitute loads and current measurement on every firing loop.
- **Engineer's objective:** Show that no diagnostic IO control can energise a firing loop, in any session or
  security state.
- **Why this service:** 0x2F is the standard way to override outputs, so it is the first path to close.
- **Tester sends:** For every session and security level: `2F <DID> 03 <data>` for every DID in the range,
  including all DIDs in the ECU's IO-control list and all DIDs not in it.
- **ECU is expected to:** Accept only its released IO DIDs (lamps, indicators). Reject every other DID with
  `7F 2F 31`. Never route any request to a firing-loop driver.
- **Engineer obtains:** A complete accept/reject map plus loop-current logs.
- **Test on success / failure:** Success = only listed DIDs accepted and zero current pulses on all loops.
  Failure = any unlisted DID accepted, or any current pulse on a loop → safety defect, stop the release.

### Use case: Freezing an output during development measurement
- **Scenario:** An engineer measures an actuator's current while the application keeps changing the PWM.
- **Engineer's objective:** Hold the output steady during the measurement.
- **Why this service:** `freezeCurrentState` keeps whatever value the application last set.
- **Tester sends:** `2F 47 12 02 C0`, measure, then `2F 47 12 00 C0`.
- **ECU is expected to:** Hold both signals at their current values until `00`.
- **Engineer obtains:** A stable operating point without knowing the value in advance.
- **Test on success / failure:** Success = value constant during the hold, normal behaviour after release.
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. The server checks that 0x2F is allowed in the active session and security state.
2. It checks the length against the DID definition (see section 6).
3. It checks that the DID is IO-controllable and that the control parameter is supported for it.
4. It checks controlState values (range) and the mask (no undefined bits).
5. It checks preconditions (OEM): vehicle speed, voltage, engine/HV state, active faults.
6. It applies the override to the selected signals and answers `6F` with the state now in effect.
7. The override stays until `returnControlToECU`, a session change to default (including S3 timeout), or
   reset. Application logic stays in control of signals not selected by the mask.

State per signal: **ECU-controlled** → (01, 02, 03) → **tester-controlled** → (00, session to default, S3
timeout, reset) → **ECU-controlled**. Whether a change between two non-default sessions also ends control is
OEM-defined [unverified]. Some ECUs also end control after a timeout or when a precondition is lost (e.g. vehicle
starts moving) [OEM-specific].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Extended session; not available in default session | OEM (common practice) |
| Security / authentication | Usually 0x27 unlock or 0x29 authentication for actuator control | OEM |
| ECU operating conditions | Vehicle stationary, voltage in range, engine off or HV ready (depends on output), no blocking fault | OEM |
| Timing (P2 / P2* / S3) | Response within P2server_max; keep S3 alive with 0x3E, or control ends | ISO 14229-2 + ECU |

**Depends on:** 0x10 (session), 0x27 / 0x29 (security), 0x3E (keep the session, and the override, alive),
0x22 (read back the state). DID definitions (ODX/CDD) define controlState size, scaling and mask layout.
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | `0x2F` |
| 2–3 | dataIdentifier | 2 | IO-controllable DID from the OEM spec, e.g. `0x4711` (illustrative) |
| 4 | inputOutputControlParameter | 1 | `00` returnControlToECU · `01` resetToDefault · `02` freezeCurrentState · `03` shortTermAdjustment (values cross-checked: py-uds, python-udsoncan, ArcCore Dcm) · `04`–`FF` ISO reserved [unverified]. Some DIDs are defined without this byte (controlState only); python-udsoncan treats it as optional [OEM-specific] |
| 5… | controlState | n | Only with `03`: the values to apply, laid out like the DID's data record. Absent for `00`/`01`/`02` (matches py-uds) |
| … | controlEnableMaskRecord | m | Only for DIDs with more than one signal: one bit per signal, 1 = affected. **Open point:** this entry shows the mask with every control parameter on such DIDs (AUTOSAR-style), while py-uds models it only after `03`. Check the OEM spec / ODX for each DID [unverified]. First signal = most significant bit of the first mask byte [unverified] |

These two byte groups together are often called the controlOptionRecord (control parameter + controlState).

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 4 is a parameter, not a sub-function:
`2F 47 11 83` is an invalid control parameter (`7F 2F 31` [unverified NRC]), not a suppressed `03`. The
server always sends a response.

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 00 | returnControlToECU | Ends the override; the application owns the signal again | End every test step | Must also work when nothing is overridden [unverified] |
| 01 | resetToDefault | Applies the default value defined for the signal | Safe known state | Default value is OEM-defined |
| 02 | freezeCurrentState | Holds the value the application last set | Stable measurement | Value is whatever it was |
| 03 | shortTermAdjustment | Applies controlState from the request | Actuator tests, EOL | Range checks apply (0x31) |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | `0x6F` |
| 2–3 | dataIdentifier | 2 | Echo of the request DID |
| 4 | inputOutputControlParameter | 1 | Echo (absent if the DID has no control-parameter byte) |
| 5… | controlState | n | State of **all** signals of the DID after the request, including those not selected by the mask [unverified]. Some ECUs return the commanded value, others a measured value [OEM-specific]. No mask in the response [unverified] |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length does not fit the DID definition for this control parameter (missing controlState, missing or extra mask bytes) |
| 0x22 | conditionsNotCorrect | OEM preconditions not met: vehicle moving, voltage, HV/engine state, output already controlled by another function |
| 0x26 | failurePreventsExecutionOfRequestedAction | An active fault on the output (open / short) blocks control [OEM-specific] |
| 0x31 | requestOutOfRange | DID not IO-controllable; control parameter not supported for this DID; controlState out of range; mask selects undefined signals |
| 0x33 | securityAccessDenied | Security level not unlocked |
| 0x34 | authenticationRequired | 2020 ECUs using 0x29 instead of 0x27 |
| 0x7F | serviceNotSupportedInActiveSession | Request in default session (common) |
| 0x81–0x93 | e.g. 0x88 vehicleSpeedTooHigh, 0x93 voltageTooLow | Instead of 0x22, when the server names the failing condition |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md). Evaluation order:
[../protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order).

### Examples

Values marked (illustrative) are not universal. DID `0x4711` = one 1-byte lamp signal (00 off, 01 on).
DID `0x4712` = two 1-byte signals: pump duty, fan duty (1 % per bit). Both DIDs are illustrative.

```uds
REQ 2F 47 11 03 01           # shortTermAdjustment: lamp on
POS 6F 47 11 03 01           # lamp is now on
REQ 2F 47 11 00              # returnControlToECU
POS 6F 47 11 00 00           # ECU controls the lamp again; current state off
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 2F / 6F | | Request / positive response SID |
| 47 11 | | DID (illustrative) |
| 03 | | shortTermAdjustment |
| 01 | | controlState: lamp on (illustrative encoding) |
| 00 (byte 4) | | returnControlToECU; no controlState in request |
| 00 (byte 5) | | Current lamp state reported by the ECU |

```uds
REQ 2F 47 12 03 32 00 80     # pump to 50 %, fan byte ignored (fan's mask bit not set)
POS 6F 47 12 03 32 1E        # pump 50 %, fan still under ECU control at 30 %
REQ 2F 47 12 02 C0           # freeze both signals
POS 6F 47 12 02 32 1E
REQ 2F 47 12 00 C0           # return both signals to the ECU
POS 6F 47 12 00 30 1E
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 32 00 | 50, 0 | controlState for pump and fan; fan value has no effect because its mask bit is 0 |
| 80 | 1000 0000 | Mask: first signal (pump) only [unverified bit order] |
| C0 | 1100 0000 | Mask: pump and fan. Sending a mask with `02` / `00` follows the AUTOSAR-style reading; some ECUs expect no mask there (see section 6) [unverified] |
| 32 1E | 50 %, 30 % | Response: state of both signals |
| 30 1E | 48 %, 30 % | After return: values chosen by the application (illustrative) |

```uds
REQ 2F 47 11 03 01           # in default session
NEG 7F 2F 7F
REQ 2F 47 11 03 01           # extended session, security locked
NEG 7F 2F 33
REQ 2F F1 90 03 00           # VIN DID is not IO-controllable
NEG 7F 2F 31
REQ 2F 47 11 03 05           # controlState 05 out of range (illustrative)
NEG 7F 2F 31
REQ 2F 47 11 03              # shortTermAdjustment without controlState
NEG 7F 2F 13
REQ 2F 47 12 03 32 00 80     # vehicle moving (illustrative precondition)
NEG 7F 2F 22
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 7F 2F 7F | | Service not allowed in default session |
| 7F 2F 33 | | Security not unlocked |
| F1 90 | | VIN DID: readable, not controllable → 0x31 |
| 7F 2F 13 | | 4 bytes: controlState missing for `03` |
| 7F 2F 22 | | Precondition failed; output unchanged |

Session exit ends the override (S3 timeout has the same effect):

```uds
REQ 2F 47 11 03 01           # lamp forced on
POS 6F 47 11 03 01
REQ 10 01                    # back to default session
POS 50 01 00 32 01 F4
REQ 22 47 11                 # read the lamp DID
POS 62 47 11 00              # lamp back under ECU control (off)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 50 01 | | Default session active |
| 00 32 01 F4 | | P2 50 ms, P2* 5000 ms (illustrative) |
| 62 47 11 00 | | Lamp state now set by the application |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- **Builder:** inputs `did`, `control_parameter` (enum 00–03), optional `control_state` bytes, optional
  `enable_mask` bytes. Look up the DID definition: signal count, controlState size, mask size, whether the
  control-parameter byte exists. Reject at build time: `03` without controlState, controlState with `00`–`02`,
  mask on a single-signal DID, wrong byte counts.
- **Parser:** check `6F`, the DID echo and the control-parameter echo. Decode controlState with the DID's data
  definition. Do not expect a mask in the response.
- **Cleanup is mandatory:** every test step that sends `01`/`02`/`03` must send `00` in a `finally` block (or
  end the session). Keep 0x3E running while an override must last; stop it, or send `10 01`, to make the ECU
  release everything.
- **Timeouts:** normal P2 handling; 0x78 is unusual for 0x2F but must be handled.
- **Restraint ECUs:** the IO-control DID list must contain only non-pyrotechnic outputs (warning lamp,
  indicators). Firing-loop drivers must be unreachable from 0x2F in every session and security level. This
  catalogue does not describe any deployment procedure.
- **Edge cases:** two overrides on the same DID with different masks; `00` for a signal that is not overridden;
  override active when the ECU detects a fault on that output; precondition lost while overridden (vehicle
  starts moving) [OEM-specific]; physical request while a functional `10 01` is sent by another tester.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive, short-term adjustment | `2F 47 11 03 01` | `6F 47 11 03 01`; output measured on |
| 2 | Return control | `2F 47 11 00` | `6F 47 11 00 ..`; application resumes |
| 3 | Reset to default | `2F 47 11 01` | Output at OEM default value |
| 4 | Freeze | `2F 47 12 02 C0` | Values held while the application would change them |
| 5 | Mask selects subset | `2F 47 12 03 32 00 80` | Only pump overridden; fan follows application |
| 6 | Mask with undefined bit | `2F 47 12 03 32 00 A0` | `7F 2F 31` [unverified, may be 0x13] |
| 7 | DID not controllable | `2F F1 90 03 00` | `7F 2F 31` |
| 8 | Unsupported control parameter | `2F 47 11 04` and `2F 47 11 83` | `7F 2F 31` |
| 9 | controlState out of range | `2F 47 11 03 05` (illustrative) | `7F 2F 31`; output unchanged |
| 10 | Length min-1 | `2F 47 11` | `7F 2F 13` |
| 11 | Length min | `2F 47 11 00` | `6F 47 11 00 ..` |
| 12 | Length max | `2F 47 12 03 32 00 80` (7 bytes) | `6F 47 12 03 ..` |
| 13 | Length max+1 | `2F 47 12 03 32 00 80 00` | `7F 2F 13` |
| 14 | Session matrix | Same request in default / extended / programming / OEM sessions | Accepted only where the OEM allows; else `7F 2F 7F` |
| 15 | Security matrix | Locked, wrong level, correct level (or 0x29 states) | `7F 2F 33` / `7F 2F 34` until correct |
| 16 | Conditions | Vehicle speed > threshold, voltage low/high | `7F 2F 22` or 0x88 / 0x92 / 0x93 |
| 17 | Session exit releases control | Override, then `10 01` | Output back under application control |
| 18 | S3 timeout releases control | Override, stop 0x3E, wait > S3 | Output released; `22` shows application value |
| 19 | Reset releases control | Override, then `11 01` | Output released after restart |
| 20 | Restraint interlock sweep | `2F <DID> 03 <data>` over all DIDs, all sessions and security levels | Only released IO DIDs accepted; zero current on all firing loops |
| 21 | Functional addressing | `2F 47 11 03 01` on functional ID | Per OEM: usually not supported; no 0x31 sent on functional ID |
| 22 | Multi-frame | DID whose request exceeds 7 bytes on classical CAN | Accepted over ISO-TP; same result as single frame |
| 23 | SPRMIB | n/a: no sub-function; byte 4 bit 7 is an invalid parameter (test 8) | — |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 13.2 (functional unit 13, input/output control) |
| Edition differences | No 2013 ↔ 2020 differences known for 0x2F [unverified]. 2026 edition not yet reviewed |
| OEM / ECU-specific | Which DIDs are controllable; control parameters per DID; controlState layout and scaling; mask layout; default values; session/security/precondition rules; whether control ends on non-default session change or on a timeout; what controlState the response reports |
| Verification status | draft. Cross-checked: SID 0x2F, response SID 0x6F, clause 13.2, functional unit. Reviewer 2026-10-26: control-parameter values 00–03, controlState only with 03, and response = DID + parameter echo + controlState checked against py-uds, python-udsoncan and ArcCore Dcm source (open-source, not normative). Engineering knowledge only: mask presence for 00–02, mask bit order, NRC usage |
| Open questions | Whether controlEnableMaskRecord is sent with 00/01/02 on multi-signal DIDs (implementations disagree). Mask bit order. Whether the control-parameter byte may be omitted by DID definition. Exact list of events that end control in 2020. Reserved range of control-parameter values |
<!-- catalogue field 15 -->
