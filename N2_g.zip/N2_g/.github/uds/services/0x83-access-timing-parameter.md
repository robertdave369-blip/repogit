---
sid: 0x83
name: AccessTimingParameter
response_sid: 0xC3
has_sub_function: true
functional_unit: "Diagnostic and communication management (2013 edition)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "not in 2020 edition"
status: withdrawn
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview TOC (cdn.standards.iteh.ai sample 72439) — service absent from clause 10"
  - "py-uds knowledge base (uds.readthedocs.io) — 0x83 marked withdrawn in ISO 14229-1:2020, response SID 0xC3"
  - "py-uds translator source (github.com/mdabrowski1990/uds, utilities/constants/subfunctions.py, data_record_definitions/other.py) — 2013 timingParameterAccessType names 0x01–0x04; request/response records are raw bytes"
  - "Engineering knowledge of ISO 14229-1:2013 behaviour — record content and session rules (not cross-checked)"
---

# 0x83 — AccessTimingParameter

> **Status:** withdrawn · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0xC3
> Legacy service to read or change the server's communication timing parameters. Not part of ISO 14229-1:2020;
> documented here only for ECUs built to the 2013 edition (or earlier).

## 1. What is it?

AccessTimingParameter (SID 0x83) let a tester read the server's timing parameters, reset them to defaults or
set new values for the active session. The sub-function is the **timingParameterAccessType**.

**On a 2020-baseline ECU this service does not exist.** Expect `7F 83 11` (serviceNotSupported) on a physical
request and silence on a functional one. The timing that applies is the one the server reports in the
DiagnosticSessionControl (0x10) positive response, plus the transport configuration. See
[../protocol-fundamentals.md](../protocol-fundamentals.md#timing).

Everything below about sub-functions and records describes the **2013 behaviour** [edition-dependent].

## 2. Why is it needed?

Historically, testers needed a way to stretch server timing for slow links (K-Line, gateways with long
routing delays) or to tighten it for faster sequences. 0x83 gave a standard request for that.

In practice it was rarely implemented. The 0x10 response already reports P2server_max and P2*server_max, and
transport timing is fixed in the network configuration. The 2020 edition removed it. You still meet it when:

- testing a legacy ECU whose diagnostic spec was written against 2013 or 2006;
- a test tool (old CDD/ODX, CAPL library) still contains 0x83 requests;
- an ECU is being migrated to 2020 and the old service must now be rejected.

## 3. What is its purpose?

On a 2013 ECU: inspect and adjust application timing for the current session. On a 2020 ECU: none — the
purpose of a 0x83 test is to confirm that the server rejects it cleanly.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| ECU built to ISO 14229-1:2020 or later | Read P2/P2* from the 0x10 positive response | 0x83 withdrawn |
| Need to know the current session | ReadDataByIdentifier 0xF186 ActiveDiagnosticSession | Direct read |
| Need longer processing time for one request | Server-side 0x78 response pending | Standard mechanism, see [../protocol-fundamentals.md](../protocol-fundamentals.md#response-pending-0x78) |
| Transport timing (STmin, block size, N_x timeouts) | ISO-TP / DoIP configuration | Never controlled by 0x83 |
| Faster bit rate for flashing | LinkControl ([0x87](0x87-link-control.md)) | Link layer, not application timing |

<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Regression test after migrating an ECU stack from 2013 to 2020
- **Scenario:** A supplier moves a restraint-system ECU from a 2013-based diagnostic stack to a 2020-based one.
  The old test suite still contains 0x83 cases.
- **Engineer's objective:** Confirm the service was removed and that removal causes no side effects.
- **Why this service:** The requirement "service not supported" must be tested like any other.
- **Tester sends:** `83 03` physically in default and extended session; `83 03` functionally.
- **ECU is expected to:** Reply `7F 83 11` physically in every session; stay silent functionally.
- **Engineer obtains:** Evidence for the migration review; old 0x83 test cases replaced by a 0x10 timing check.
- **Test on success / failure:** `7F 83 11` = pass. `7F 83 7F` suggests the service is still in the session
  table. A positive `C3 ..` means the old implementation is still linked in.

### Use case: Reading active timing on a legacy (2013) gateway in the workshop
- **Scenario:** An older gateway ECU spec lists 0x83. A tester sees intermittent timeouts through the gateway.
- **Engineer's objective:** Compare the timing the gateway thinks is active with what the tester uses.
- **Why this service:** On that ECU, 0x83 03 is the documented way to read the active values.
- **Tester sends:** `10 03`, then `83 03`.
- **ECU is expected to:** Return `C3 03` followed by its timing record.
- **Engineer obtains:** Server P2 values to set the tester's P2client above them.
- **Test on success / failure:** Values consistent with the 0x10 response; inconsistent values are a defect.

<!-- catalogue fields 5, 6 -->

## 5. How does it work?

**2020 ECU:** the general service check fails first. Physical → `7F 83 11`. Functional → no response
(0x11 is suppressed for functional requests).

**2013 ECU** [edition-dependent] [unverified details]:

1. Tester switches to a non-default session (setting was normally not allowed in default session).
2. `83 01` reads the extended timing parameter set the server supports; `83 03` reads the currently active set.
3. `83 04 <record>` requests new values; the server checks them, sends the positive response using the **old**
   timing, then applies the new values.
4. `83 02` restores the defaults.
5. Values are tied to the session. A session change or reset restores the defaults.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | 2020: none (service absent). 2013: non-default for 02/04; reads possibly any | 2013 ISO / OEM [unverified] |
| Security / authentication | Usually none | OEM |
| ECU operating conditions | None known | OEM |
| Timing (P2 / P2* / S3) | 2013: new values become active after the positive response [unverified] | ISO 14229-1:2013 |

**Depends on:** DiagnosticSessionControl (0x10). On 2013 ECUs the content of the timing record was left to the
data-link-specific implementation [unverified].

<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

All layouts in this section are 2013 behaviour [edition-dependent]. On a 2020 ECU only the NRC table
row for 0x11 applies.

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x83 |
| 2 | timingParameterAccessType (sub-function) | 1 | bit 7 = SPRMIB, bits 6–0 = type |
| 3… | TimingParameterRequestRecord | n | Only for 0x04. Content data-link / OEM-defined [unverified] |

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x01 | readExtendedTimingParameterSet | Returns the extended timing set the server offers | Discover what can be set | Response carries a record |
| 0x02 | setTimingParametersToDefaultValues | Restores default timing | Clean up after tuning | No record |
| 0x03 | readCurrentlyActiveTimingParameters | Returns active timing | Debug timeouts | Response carries a record |
| 0x04 | setTimingParametersToGivenValues | Applies values from the request record | Slow links | Record in request, none in response |

Values 0x00 and 0x05–0x7F: reserved or OEM-specific in 2013 [unverified].

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0xC3 |
| 2 | timingParameterAccessType | 1 | Echo with bit 7 cleared |
| 3… | TimingParameterResponseRecord | n | Only for 0x01 and 0x03. Content not defined by the open-source stacks checked (raw bytes in py-uds); left to the data-link / OEM spec. Some ECUs reuse the 0x10 layout, P2server_max (2 bytes, 1 ms) and P2*server_max (2 bytes, 10 ms), but do not assume it [unverified] |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x11 | serviceNotSupported | **Any 2020-baseline ECU.** Also 2013 ECUs that never implemented it |
| 0x12 | subFunctionNotSupported | 2013: type not implemented |
| 0x13 | incorrectMessageLengthOrInvalidFormat | 2013: record missing for 0x04, or extra bytes for 01/02/03 |
| 0x22 | conditionsNotCorrect | 2013: OEM conditions not met |
| 0x31 | requestOutOfRange | 2013: requested values outside what the server supports |
| 0x7E | subFunctionNotSupportedInActiveSession | 2013: e.g. 0x04 in default session |
| 0x7F | serviceNotSupportedInActiveSession | 2013: service not allowed in this session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
NOTE ISO 14229-1:2020 ECU
REQ 83 03                    # readCurrentlyActiveTimingParameters
NEG 7F 83 11                 # serviceNotSupported: 0x83 withdrawn in 2020
REQ 10 03                    # get timing the 2020 way
POS 50 03 00 32 01 F4        # P2 50 ms, P2* 5000 ms (illustrative)
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 1 | 83 03 | AccessTimingParameter, readCurrentlyActive (2013 meaning) |
| NEG | 7F 83 11 | Service does not exist in this server |
| POS 2 | 00 32 | P2server_max = 50 ms |
| POS 2 | 01 F4 | P2*server_max = 500 × 10 ms = 5000 ms |

```uds
NOTE ISO 14229-1:2013 ECU [edition-dependent]; record layout [unverified]
REQ 10 03
POS 50 03 00 32 01 F4
REQ 83 03                    # read active timing
POS C3 03 00 32 01 F4        # same P2 / P2* as above (illustrative)
REQ 83 04 00 64 03 E8        # set P2 100 ms, P2* 10000 ms (illustrative values and layout)
POS C3 04                    # sent with old timing; new timing active afterwards
REQ 83 82                    # back to defaults, SPRMIB set
NOTE no positive response expected
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 2 | 83 03 | readCurrentlyActiveTimingParameters |
| POS 2 | C3 03 | Echo |
| POS 2 | 00 32 01 F4 | Record: 50 ms / 5000 ms (illustrative) |
| REQ 3 | 83 04 | setTimingParametersToGivenValues |
| REQ 3 | 00 64 03 E8 | 100 ms; 1000 × 10 ms (illustrative) |
| POS 3 | C3 04 | Accepted; no record |
| REQ 4 | 83 82 | SPRMIB = 1, type 0x02 setTimingParametersToDefaultValues |

<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- Default for a 2020-baseline tool: do **not** offer 0x83. If kept for legacy ECUs, gate it behind an
  edition flag (`edition="2013"`) and say so in the API docs.
- Timing source on 2020 ECUs: parse P2/P2* from every 0x10 positive response and update the client's
  P2client/P2*client margins from it.
- Server side (2020 stack): make sure 0x83 is not in any session table, so the general check returns 0x11
  (not 0x7F or 0x12).
- Legacy parser: echo check, record length per the OEM spec; treat an unknown record layout as raw bytes.
- Edge case (2013): after `83 04` the tester must switch its own P2client before sending the next request.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | 2020: not supported (physical) | `83 01`, `83 02`, `83 03`, `83 04 ..` | `7F 83 11` each |
| 2 | 2020: session matrix | `83 03` in default / extended / programming / safety | `7F 83 11` in all (not 0x7F) |
| 3 | 2020: security / authentication | `83 03` locked/unlocked, authenticated or not | `7F 83 11` (0x11 checked before 0x33/0x34) |
| 4 | 2020: SPRMIB | `83 83` physical | `7F 83 11` still sent |
| 5 | 2020: functional | `83 03` functional | No response |
| 6 | 2020: length | `83` alone, `83 03 00` | `7F 83 11` (SID check before length) |
| 7 | 2020: replacement | `10 03` | P2/P2* in response match the ECU spec |
| 8 | 2013: read active | `83 03` in extended | `C3 03` + record |
| 9 | 2013: set + effect | `83 04 <record>`, then a slow routine | Server uses new P2 [unverified] |
| 10 | 2013: defaults | `83 02` | `C3 02`; values back to default |
| 11 | 2013: session reset | Set values, `10 01`, `10 03`, `83 03` | Defaults reported |
| 12 | 2013: length min-1 / max+1 | `83`, `83 03 00`, `83 04` without record | `7F 83 13` |
| 13 | 2013: out of range | `83 04` with unsupported values | `7F 83 31` |
| 14 | 2013: unsupported type | `83 05` | `7F 83 12` |
| 15 | 2013: SPRMIB | `83 82` | No response; defaults applied |

<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | Not in ISO 14229-1:2020 (absent from the clause 10 TOC). Defined in ISO 14229-1:2013 (clause number not recorded here) |
| Edition differences | 2013: present with sub-functions 01–04 [edition-dependent]. 2020: withdrawn (cross-checked: 2020 TOC, py-uds). 2026: not yet reviewed; secondary source says no services added or removed |
| OEM / ECU-specific | Whether a legacy ECU implemented it at all; timing record layout; session rules |
| Verification status | withdrawn. Cross-checked: absence from 2020 TOC; py-uds withdrawn flag and response SID; 2013 sub-function names 0x01–0x04 and raw-byte records (py-uds translator source, reviewer 2026-10-26). Not cross-checked: 2013 sub-function semantics in detail, record content, session rules |
| Open questions | Exact 2013 record content per data link; whether 2013 allowed reads in default session |

<!-- catalogue field 15 -->
