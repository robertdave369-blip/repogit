---
sid: 0x14
name: ClearDiagnosticInformation
response_sid: 0x54
has_sub_function: false
functional_unit: "Stored data transmission"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "12.2 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause 12.2, functional unit 12"
  - "ISO 14229-1:2020/Amd 1:2022 preview (sample 81380): NRC 0x31 also for unsupported MemorySelection"
  - "py-uds knowledge base (uds.readthedocs.io): 2020 request = SID + groupOfDTC (3) + optional MemorySelection (1); 2013 request without MemorySelection; positive response = 0x54 only; groupOfDTC special values"
---

# 0x14 — ClearDiagnosticInformation

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x54
> Erases stored fault information (DTC status and the data attached to each DTC) for one DTC group, in one DTC memory.

## 1. What is it?

ClearDiagnosticInformation (SID 0x14) tells the server to erase its fault memory for a selected group of DTCs.
The request carries a 3-byte **groupOfDTC** and, from the 2020 edition, an optional 1-byte **MemorySelection**
that picks a user-defined DTC memory. The positive response is the single byte `0x54`; it carries no data.

What "clear" means in practice:

- Each affected DTC's status byte returns to its after-clear value. With bits 4 and 6 supported this is `0x50`
  (testNotCompletedSinceLastClear + testNotCompletedThisOperationCycle); all other bits are 0. See
  [../dtc-reference.md](../dtc-reference.md#2-dtc-status-byte).
- Snapshot, stored-data and extended-data records for those DTCs are removed (occurrence counters, ageing
  counters, freeze frames). Exactly which records and counters go is defined by the OEM fault-handling spec
  [OEM-specific].
- The service has no sub-function.
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

Fault memory is non-volatile on purpose: historic faults survive power cycles so a workshop can see them. That
same property means old entries hide new information after a repair, after assembly, or between test cases.

- **0x19 ReadDTCInformation** only reads. **0x85 ControlDTCSetting** only stops status updates; it deletes
  nothing. **0x11 ECUReset** does not touch stored DTCs. Ageing removes a DTC only after many fault-free
  operation cycles.
- **Workshop:** confirms a repair by clearing and checking that the DTC does not come back.
- **Production line:** ships the vehicle with empty fault memory after DTCs set during assembly (unplugged
  connectors, nodes not yet configured).
- **Validation / HIL:** gives every test case a known starting state, so a DTC seen afterwards was caused by
  that test case.
- **ECU developer:** resets monitors to "not completed" to exercise first-run and readiness logic.
<!-- catalogue field 3 -->

## 3. What is its purpose?

It resets the fault-memory part of the ECU state machine. It enables a fresh fault-detection cycle and makes
readiness information (bit 4, testNotCompletedSinceLastClear) meaningful. It changes NVM content. It does not
repair anything: a fault that is still present re-qualifies after its normal debounce time. It does not read,
stop or configure fault detection.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| You need the stored DTCs or freeze frames | 0x19 (0x02, 0x04, 0x06) **before** clearing | Clearing is irreversible; save the evidence first |
| You want no new DTCs during flashing or a fault-injection setup | 0x85 ControlDTCSetting off | Suppresses new entries without deleting old ones |
| You want to restart the ECU software | 0x11 ECUReset | Reset does not clear stored DTCs |
| You want to remove crash / EDR records in a restraint ECU | OEM service procedure or ECU replacement | Crash records are normally locked and not part of 0x14 [OEM-specific] |
| You want to remove OBD permanent DTCs | Not possible with 0x14 | Legislated; they clear only after the monitor passes [unverified] |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Workshop repair of a restraint-system fault
- **Scenario:** The airbag warning lamp is on. 0x19 shows a confirmed squib-loop open DTC `91 01 13`
  (B1101-13, illustrative). The technician repairs the steering-wheel clockspring connector.
- **Engineer's objective:** Confirm the repair and turn off the warning lamp.
- **Why this service:** The DTC stays confirmed until cleared or aged out; the lamp logic follows it.
- **Tester sends:** `19 02 08` (save result), then `14 FF FF FF`, then `19 02 08` again after the ECU's
  loop-check time.
- **ECU is expected to:** Answer `54`, set all supported DTCs to `0x50`, re-run the loop monitor, and not
  re-set the DTC because the loop is now in range.
- **Engineer obtains:** Empty confirmed-DTC list; lamp off after the ECU's self-test.
- **Test on success / failure:** Success = no DTC with bit 0 or 3 after the qualification time. Failure = the
  DTC returns as `0x2F` (failing, pending, confirmed, failed since clear) → repair not effective.

### Use case: HIL baseline before each fault-injection test case
- **Scenario:** A HIL bench with a fault-insertion unit runs a restraint-ECU test suite: open/short loops,
  sensor faults, CAN timeouts.
- **Engineer's objective:** Each test case must start with no stored DTCs and every monitor "not completed".
- **Why this service:** It is the only standard way to return the fault memory to a known state.
- **Tester sends:** `14 FF FF FF` → `19 02 FF` → `19 0A` at test-case start.
- **ECU is expected to:** Answer `54`; `19 02 FF` lists only DTCs whose monitors have not run yet (status
  `0x50`); `19 0A` lists every supported DTC with `0x50` until its monitor runs.
- **Engineer obtains:** A clean baseline and proof that bit 4 behaves as specified.
- **Test on success / failure:** Success = no DTC with bit 0 or bit 3 set before the injection.
  Failure = such a DTC exists → the previous test case leaked, or the clear failed.

### Use case: End-of-line clear of all ECUs
- **Scenario:** After flashing and configuration, DTCs from assembly (missing nodes, unplugged connectors) are
  stored in many ECUs.
- **Engineer's objective:** Ship with empty fault memory, then verify nothing re-sets.
- **Why this service:** One functionally addressed request reaches every ECU.
- **Tester sends:** `14 FF FF FF` on the functional request ID, then `19 02 08` per ECU, physically addressed.
- **ECU is expected to:** Each ECU answers `54` (0x14 has no SPRMIB, so positive responses are sent).
- **Engineer obtains:** A list of ECUs that responded, then a per-ECU confirmed-DTC check.
- **Test on success / failure:** Success = every expected ECU answered `54` and has no confirmed DTC
  afterwards. Failure = an ECU missing from the responses or a DTC that re-sets → station rejects the vehicle.

### Use case: Validation that crash records survive a clear
- **Scenario:** A bench restraint ECU already holds a stored crash record (from a crash test, or written by the
  supplier's tool).
- **Engineer's objective:** Prove that a workshop clear cannot erase crash / EDR data.
- **Why this service:** 0x14 is what a workshop tester will send; the ECU must not let it touch locked data.
- **Tester sends:** Read the crash-record DID (OEM DID, e.g. `0x4730` illustrative) → `14 FF FF FF` → read again.
- **ECU is expected to:** Either `54` with crash data unchanged, or `7F 14 22` if the OEM spec forbids any clear
  in crash-locked state [OEM-specific].
- **Engineer obtains:** Evidence for the EDR retention requirement (e.g. 49 CFR Part 563, UN R160) [unverified
  which clauses apply].
- **Test on success / failure:** Success = crash record byte-identical before and after. Failure = any change.
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. The server checks the request length: 4 bytes, or 5 bytes if it supports MemorySelection (2020).
2. It checks that groupOfDTC is supported (`0xFFFFFF`, a supported functional group, or a single supported DTC).
3. If present, it checks MemorySelection. Amd 1:2022: unsupported value → NRC 0x31.
4. It checks OEM preconditions (vehicle speed, ignition, voltage, crash-locked state).
5. It erases the selected data in NVM. If this takes longer than P2server_max it sends `7F 14 78` and
   continues ([../protocol-fundamentals.md](../protocol-fundamentals.md#response-pending-0x78)).
6. It sends `54` once the clear is done. A failed NVM write gives NRC 0x72 instead.

After the clear, monitors run again. A fault that is still present re-qualifies after its debounce time, with
bit 5 (testFailedSinceLastClear) set again. Clearing an already empty memory still returns `54`.

Check order above is typical; the normative order is in clause 12.2 [unverified] —
[../protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order).

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Often allowed in default and extended session; some OEMs restrict to extended | OEM |
| Security / authentication | Usually none; some safety ECUs require 0x27 or 0x29 first | OEM |
| ECU operating conditions | Ignition on, voltage in range, vehicle stationary, no crash recording in progress | OEM |
| Timing (P2 / P2* / S3) | `54` within P2server_max, or `7F 14 78` then the final response within P2*server_max | ISO 14229-2 + ECU |

**Depends on:** 0x19 to verify the result (0x02, 0x0A; 0x17 for a user-defined memory); 0x10 for the session;
0x85 for interaction with DTC setting (see section 7). Transport: always a single frame (≤ 5 bytes).
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | `0x14` |
| 2–4 | groupOfDTC | 3 | `0xFFFFFF` all groups · `0xFFFFD0` safety-system group · `0xFFFF33` emissions-system group · `0xFFFFFE` VOBD system group · any other value = one DTC number or an OEM functional group. See [../dtc-reference.md](../dtc-reference.md#3-groupofdtc-0x14-0x85-option-record) |
| 5 | MemorySelection | 1, optional (2020) | Selects a user-defined DTC memory. Values are OEM-defined. Not part of the 2013 request [edition-dependent]. When absent the server clears its primary memory [unverified] |

Restraint ECUs: whether `0xFFFFD0` is supported, and whether it equals `0xFFFFFF` on that ECU, is OEM-defined.
Many restraint ECUs support only `0xFFFFFF` [OEM-specific].

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Bit 7 of byte 2 is part of groupOfDTC
(`14 7F FF FF` is a different group, not a suppressed `14 FF FF FF`).

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | `0x54`. No further bytes; groupOfDTC is not echoed |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length is not 4 bytes (2013 server), or not 4–5 bytes (2020 server with MemorySelection) |
| 0x22 | conditionsNotCorrect | OEM preconditions fail: vehicle moving, ignition state, crash-locked restraint ECU, NVM busy |
| 0x31 | requestOutOfRange | groupOfDTC not supported; MemorySelection not supported (Amd 1:2022) |
| 0x72 | generalProgrammingFailure | The NVM erase or write of the fault memory failed |
| 0x78 | requestCorrectlyReceived-ResponsePending | The clear takes longer than P2server_max |
| 0x7F | serviceNotSupportedInActiveSession | The OEM does not allow clearing in the current session |
| 0x33 / 0x34 | securityAccessDenied / authenticationRequired | Only if the OEM protects 0x14 |
| 0x81–0x93 | e.g. 0x88 vehicleSpeedTooHigh, 0x93 voltageTooLow | Instead of 0x22, when the server names the failing condition |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 14 FF FF FF              # clear all groups, primary memory
POS 54                       # clear finished
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 14 | | ClearDiagnosticInformation |
| FF FF FF | | groupOfDTC = all groups |
| 54 | | Positive response; no parameters |

```uds
REQ 14 FF FF D0              # safety-system group (restraint ECU)
NEG 7F 14 78                 # NVM erase in progress (illustrative)
POS 54                       # final response within P2*server_max
```

| Byte(s) | Value | Meaning |
|---|---|---|
| FF FF D0 | | groupOfDTC = safety-system group |
| 7F 14 78 | | Response pending; tester switches to P2* timing |
| 54 | | Clear finished |

```uds
REQ 14 FF FF FF 01           # 2020: MemorySelection 0x01 (illustrative)
NEG 7F 14 31                 # this memory is not supported (Amd 1:2022 rule)
REQ 14 FF FF FF 01           # same request to a 2013-only ECU
NEG 7F 14 13                 # 5 bytes is not a valid 2013 length [edition-dependent]
```

| Byte(s) | Value | Meaning |
|---|---|---|
| FF FF FF | | groupOfDTC = all groups |
| 01 | | MemorySelection (illustrative user-defined memory) |
| 7F 14 31 | | requestOutOfRange: MemorySelection unsupported |
| 7F 14 13 | | Wrong length for a server without MemorySelection |

```uds
REQ 14 FF FF FF
NEG 7F 14 22                 # e.g. vehicle moving, or crash-locked (illustrative)
REQ 14 12 34 56              # single DTC 0x123456 (illustrative), not supported as a group
NEG 7F 14 31
REQ 14 FF FF                 # one byte short
NEG 7F 14 13
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 7F 14 22 | | Preconditions not met; nothing cleared |
| 12 34 56 | | groupOfDTC = a single DTC number (illustrative) |
| 7F 14 31 | | Group / DTC not supported for clearing |
| 14 FF FF | | 3 bytes: below minimum length → 0x13 |

Clear-and-verify sequence (availability mask `7F` and DTC `91 01 13` = B1101-13 illustrative):

```uds
REQ 19 02 08                 # confirmed DTCs before the clear
POS 59 02 7F 91 01 13 2F     # failing, pending, confirmed, failed since clear
REQ 14 FF FF FF
POS 54
REQ 19 0A                    # all supported DTCs
POS 59 0A 7F 91 01 13 50 ..  # every DTC 0x50 until its monitor runs
REQ 19 02 10                 # mask bit 4: monitor not completed since clear
POS 59 02 7F 91 01 13 50 ..
NOTE fault repaired: after the monitor runs, status becomes 00
REQ 19 0A
POS 59 0A 7F 91 01 13 00 ..
NOTE fault still present: after debounce, status is 2F again
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 59 02 / 59 0A | | Positive response to 0x19 0x02 / 0x0A |
| 7F | | DTCStatusAvailabilityMask: bits 0–6 supported (illustrative) |
| 91 01 13 | | DTC B1101-13 (illustrative) |
| 2F | 0010 1111 | bits 0, 1, 2, 3, 5 |
| 50 | 0101 0000 | bits 4 and 6: after-clear value |
| 00 | | Monitor ran and passed; no bits set |

Functionally addressed clear at end of line (CAN IDs illustrative):

```uds
CAN 7DF  04 14 FF FF FF CC CC CC   # functional request, single frame
CAN 7E8  01 54 CC CC CC CC CC CC   # ECU A
CAN 7E9  01 54 CC CC CC CC CC CC   # ECU B
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 04 | | ISO-TP single frame, 4 data bytes |
| 14 FF FF FF | | Clear all groups |
| 01 54 | | Single frame, 1 byte: positive response |
| CC | | Padding (OEM-defined) |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- **Builder:** inputs `group_of_dtc` (0x000000–0xFFFFFF, 3 bytes big-endian) and optional `memory_selection`
  (0x00–0xFF). Emit MemorySelection only when given, and refuse it when the target is configured as a 2013
  ECU. Named constants for `0xFFFFFF`, `0xFFFFD0`, `0xFFFF33`, `0xFFFFFE`.
- **Parser:** a valid positive response is exactly `54`. Extra bytes are a server defect: log a warning.
- **Timing:** on `7F 14 78` extend the wait to P2*client and keep waiting; do not resend. Some ECUs need
  several seconds for a full NVM clear (illustrative).
- **Functional addressing:** collect all responses within the P2client window; compare against the expected
  ECU list. With a functional request the servers stay silent for 0x31 ([../nrc-reference.md](../nrc-reference.md#6-functional-addressing)),
  so a missing response can mean "group not supported".
- **Verification helper:** after a clear, compare statuses with the availability mask:
  `(status & mask) == (0x50 & mask)` for monitors that have not run.
- **Edge cases:**
  - DTC count changes while a paged 0x19 response is being sent (e.g. a clear from a second client on another
    channel). Amd 1:2022: the server pads the response with DTC `000000` status `00` (cross-checked).
  - Clear while DTC setting is off (0x85 02): whether the clear still happens is not confirmed here
    [unverified]. Test it on the ECU.
  - Power loss during the clear: after restart, fault memory must be consistent (all old or all cleared)
    [OEM-specific]. Some ECUs also log a clear counter or timestamp in a DID [OEM-specific].

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive, all groups | `14 FF FF FF` with stored DTCs | `54`; `19 02 08` empty |
| 2 | Positive, empty memory | `14 FF FF FF` with nothing stored | `54` |
| 3 | Status after clear | `19 0A` after test 1 | Every supported DTC `0x50` (masked by availability) |
| 4 | Bit 4 cleared by monitor run | Let monitors run, `19 02 10` | DTCs drop out once their monitor completes |
| 5 | Re-qualification | Clear with fault still injected | `54`; DTC returns after debounce with bits 0, 3, 5 |
| 6 | Records erased | `19 04` / `19 06` for a cleared DTC | No snapshot / extended data (or OEM-defined reset values) |
| 7 | Safety-system group | `14 FF FF D0` | `54` if supported, else `7F 14 31` [OEM-specific] |
| 8 | Unsupported group | `14 12 34 56` (illustrative) | `7F 14 31` |
| 9 | MemorySelection supported (2020) | `14 FF FF FF <sel>`, then `19 17 <mask> <sel>` | `54`; only that memory empty |
| 10 | MemorySelection unsupported | `14 FF FF FF 01` (illustrative) | `7F 14 31` (Amd 1:2022) |
| 11 | Length min-1 | `14 FF FF` | `7F 14 13` |
| 12 | Length min | `14 FF FF FF` | `54` |
| 13 | Length max | 2020: `14 FF FF FF <sel>`; 2013: same as min | `54` |
| 14 | Length max+1 | 2020: 6 bytes; 2013: 5 bytes | `7F 14 13` |
| 15 | Conditions | Vehicle speed > threshold, low voltage, crash-locked | `7F 14 22` or 0x88 / 0x93; nothing cleared |
| 16 | NVM failure | HIL / debugger forces NVM write error | `7F 14 72` |
| 17 | Response pending | Large fault memory | `7F 14 78` within P2, `54` within P2*; tester does not resend |
| 18 | Session matrix | Default, extended, programming, safety-system (0x04) | Per OEM matrix; not allowed → `7F 14 7F` |
| 19 | Security / authentication | Locked vs unlocked, if OEM protects 0x14 | Locked → `7F 14 33` / `7F 14 34` |
| 20 | Functional addressing | `14 FF FF FF` on functional ID | All supporting ECUs `54`; no 0x31 from ECUs without the group |
| 21 | Crash records retained | Restraint ECU with stored crash record | Crash data unchanged (or `7F 14 22`) |
| 22 | Paged-buffer interaction | Second client clears during a long `19 0A` | 0x19 response padded as Amd 1:2022 describes |
| 23 | SPRMIB / multi-frame | n/a: no sub-function; request always fits a single frame | — |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 12.2 (functional unit 12, stored data transmission), as amended by Amd 1:2022 |
| Edition differences | 2013: request = SID + groupOfDTC only. 2020: optional MemorySelection byte added [edition-dependent]. Amd 1:2022: NRC 0x31 also when MemorySelection is not supported; paged-buffer padding rule for 0x19 when the DTC count changes. 2026 edition not yet reviewed |
| OEM / ECU-specific | Which groups are supported (often only `0xFFFFFF`); session and security requirements; preconditions; which records and counters are erased; MemorySelection values; crash / EDR record handling; clear duration |
| Verification status | cross-checked: SID, response SID 0x54, request layout (2013 vs 2020), groupOfDTC special values, NRC 0x31 for MemorySelection (Amd 1), paged-buffer rule. Engineering knowledge only: precondition examples, after-clear status `0x50`, NRC evaluation order, 0x72 / 0x78 usage |
| Open questions | Exact per-service NRC evaluation order in clause 12.2. Supported-NRC list for 0x14 (commonly cited as 0x13, 0x22, 0x31, 0x72; pyudskit lists only 0x22 and 0x31) [unverified]. Behaviour of 0x14 while 0x85 DTC setting is off. Whether "no MemorySelection" is defined as "primary memory". Whether OBD permanent DTCs are explicitly excluded in 14229-1 or only in OBD standards |
<!-- catalogue field 15 -->
