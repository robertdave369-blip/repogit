---
sid: 0x2A
name: ReadDataByPeriodicIdentifier
response_sid: 0x6A
has_sub_function: false
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.5 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number, functional unit, Foreword note that this service was updated in 2020"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x2A, response SID 0x6A, 'periodic transmission of data record values ... identified by one or more periodicDataIdentifiers'"
  - "py-uds source (github.com/mdabrowski1990/uds, uds/utilities/constants/other.py TRANSMISSION_MODE_MAPPING; constants/did.py PERIODIC_DID_OFFSET 0xF200, 8-bit PDID; data_record_definitions/conditional.py): transmissionMode 01 slow, 02 medium, 03 fast, 04 stop; at least one PDID for 01-03, zero or more for 04; PDID optional in the positive response (reviewer, 2026-10-26)"
  - "ArcCore AUTOSAR Dcm (rtime.ciirc.cvut.cz arc.git, include/Dcm_Types.h, diagnostic/Dcm/Dcm_Dsp.c): same transmissionMode codes 0x01-0x04; positive response to a scheduling request is the SID only (reviewer, 2026-10-26)"
---

# 0x2A — ReadDataByPeriodicIdentifier

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x6A
> Asks the ECU to send selected data records on its own, repeatedly, at a slow, medium or fast rate, until stopped.

## 1. What is it?

ReadDataByPeriodicIdentifier (RDBPI), SID 0x2A, starts or stops periodic transmission of data records.
The tester names one or more **periodicDataIdentifiers** (PDIDs) and a **transmissionMode**. After a short
positive response, the ECU keeps sending the records on its own at the chosen rate, without further
requests.

A PDID is one byte. It is the low byte of a DID in the range **0xF200–0xF2FF**: PDID `0x01` means DID
`0xF201`. The 0xF2xx DIDs can be fixed in the ECU's software or created at run time with
[0x2C](0x2C-dynamically-define-data-identifier.md) [unverified].

## 2. Why is it needed?

- Polling with 0x22 costs one request per sample, adds tester-side jitter and loads the bus with requests.
- With 0x2A the ECU's own scheduler sets the sample time. Spacing is more regular and the bus carries half
  the traffic.
- A tester can log several values over time (warm-up, crash-sensor plausibility, voltage dips) without a
  separate measurement protocol such as XCP.

Who benefits: validation and HIL teams logging behaviour over a test, development teams, workshop tools with
live-data screens. Production lines use it less, since single reads are enough there.

## 3. What is its purpose?

Scheduled, ECU-driven reading of data records. It returns values only; it does not change ECU behaviour.
It does not guarantee real-time accuracy; rates are best effort and OEM-defined.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| A single or occasional value | [0x22 ReadDataByIdentifier](0x22-read-data-by-identifier.md) | No scheduler state to manage |
| High-rate, many-signal measurement (ms range) | XCP/CCP DAQ | Built for measurement; UDS periodic rates are coarse |
| React to a change, not a time base | 0x86 ResponseOnEvent | Event-driven instead of cyclic |
| Value has no 0xF2xx DID | [0x2C](0x2C-dynamically-define-data-identifier.md) first, then 0x2A | Build a periodic DID from existing DIDs or memory |
| Value is already on the application CAN bus | Read the bus signal | No diagnostic load at all |

## 4. When is it used? — Real use cases

### Use case: Logging airbag ECU supply voltage during a cranking profile
- **Scenario:** HIL bench runs a battery cranking pulse (voltage dip) on a restraint ECU.
- **Engineer's objective:** Log the ECU's own measured supply voltage and its internal energy-reserve state
  through the dip, to check the undervoltage reaction.
- **Why this service:** The ECU samples at its own rate while the tester only receives; no request traffic
  disturbs the timing during the dip.
- **Tester sends:** `10 03`, then `2A 03 01 02` (fast rate, PDIDs 0x01 and 0x02 = DIDs 0xF201, 0xF202,
  contents illustrative). After the profile: `2A 04 01 02`.
- **ECU is expected to:** Answer `6A`, then send PDID 0x01 and 0x02 records at the fast rate until stopped.
- **Engineer obtains:** A time series of the two values, timestamped by the tester.
- **Test on success / failure:** Pass if the energy-reserve state switches within spec when voltage drops
  below the threshold, and the sample spacing stays within the OEM tolerance. Gaps in the log mean the
  scheduler was overloaded or the session dropped.

### Use case: Workshop live-data screen
- **Scenario:** After-sales tester shows engine or battery values that refresh every second.
- **Engineer's objective:** Give the technician live values without flooding the bus.
- **Why this service:** One request per screen instead of one per value per refresh.
- **Tester sends:** `2A 01 10 11 12` (slow rate, illustrative PDIDs).
- **ECU is expected to:** Send the three records at the slow rate.
- **Engineer obtains:** Continuous values for display.
- **Test on success / failure:** On leaving the screen, the tester sends `2A 04` and checks that the
  periodic messages stop.

## 5. How does it work?

1. Tester sends `2A`, a transmissionMode, and the PDIDs (none for "stop all").
2. ECU checks length, transmissionMode, each PDID's support in the active session, security, and whether its
   scheduler can take the extra load.
3. ECU sends a positive response, then adds the PDIDs to the scheduler at the requested rate (or removes them).
4. The ECU sends periodic messages until a stop request, a session change or a reset.

**transmissionMode values** (cross-checked against two open-source implementations, py-uds and ArcCore
Dcm — see section 8; not yet against the ISO text):

| Value | Name | Meaning |
|---|---|---|
| 0x00 | reserved | — |
| 0x01 | sendAtSlowRate | Cyclic at the ECU's slow rate |
| 0x02 | sendAtMediumRate | Cyclic at the medium rate |
| 0x03 | sendAtFastRate | Cyclic at the fast rate |
| 0x04 | stopSending | Remove the listed PDIDs; with no PDIDs, stop all |
| 0x05–0xFF | reserved | — |

The actual period of each rate is OEM-defined [OEM-specific]. Requesting an already scheduled PDID at a new
rate changes its rate.

**Periodic message formats.** ISO describes two types of periodic message. Both are sent by the ECU without
a matching request and are shown as `PER` lines in this catalogue.

| Type | Carries | Transport | Constraint |
|---|---|---|---|
| Type 1 | Response SID 0x6A + PDID + data record | Same response address as normal diagnostics | Must fit in one frame on CAN (single frame): on classic CAN that is `6A` + PDID + at most 5 data bytes [unverified for 2020] |
| Type 2 | PDID + data record, no SID | Separate CAN identifier reserved for periodic data (unsegmented) | Must fit in one CAN frame: PDID + up to 7 data bytes on classic CAN [unverified] |

Which type is used is ECU- and OEM-specific [OEM-specific]. Over DoIP, periodic messages are ordinary
diagnostic messages; the single-frame limit does not apply in the same way [unverified].

**2020 changes.** The 2020 Foreword states that this service was updated. This entry has not confirmed what
changed. Areas to check against the standard: how periodic messages are carried on transports other than CAN,
whether multi-frame periodic records are allowed, and the scheduler/timing rules [edition-dependent]
[unverified]. The 2026 edition has not been reviewed.

**Stopping.** Periodic transmission ends on `2A 04`, on ECU reset, and on a session change. A move to the
default session always stops it. Whether a change between two non-default sessions also stops it is
edition- and ECU-dependent [edition-dependent] [unverified]. Periodic messages from the ECU do not reset the
S3 timer; the tester must keep sending TesterPresent (`3E 80`) [unverified].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Usually extended; not in default for most ECUs | OEM |
| Security / authentication | Follows the read protection of the underlying data | OEM |
| ECU operating conditions | Scheduler capacity; maximum number of scheduled PDIDs | OEM |
| Timing (P2 / P2* / S3) | Positive response within P2; S3 kept alive by TesterPresent | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** 0x10 (session), 0x3E (keep session), 0x2C (if PDIDs are built at run time), transport layer
configuration for type 2 messages.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x2A |
| 2 | transmissionMode | 1 | 0x01–0x04 (see table) |
| 3 … | periodicDataIdentifier #1 … #m | 1 each | Low byte of 0xF2xx. At least one, except with stopSending |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. transmissionMode is a plain parameter; bit 7
has no suppress meaning.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x6A. No echo of transmissionMode or PDIDs. ArcCore Dcm sends only `6A` for a scheduling request; py-uds models the PDID as optional in the positive response (absent in the initial response, present in the periodic ones). Not yet confirmed against the ISO text [unverified] |

Periodic messages (type 1): `6A` + PDID + data record. Periodic messages (type 2): PDID + data record.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Missing transmissionMode; no PDID with modes 0x01–0x03; more PDIDs in one request than the ECU accepts [unverified] |
| 0x22 | conditionsNotCorrect | OEM conditions not met; some ECUs also use it when the scheduler is full [unverified] |
| 0x31 | requestOutOfRange | Unsupported transmissionMode; PDID unsupported in session; record too long for the periodic message type; maximum number of concurrently scheduled PDIDs exceeded (commonly implemented this way) [unverified] |
| 0x33 | securityAccessDenied | A PDID's data needs an unlocked level |
| 0x7F | serviceNotSupportedInActiveSession | 0x2A not allowed in the current session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. PDID contents and data are illustrative; the order and
spacing of periodic messages depend on the ECU scheduler.

Start at fast rate, type 1 periodic messages, then stop.

```uds
REQ 2A 03 01 02         # fast rate, PDIDs 0x01 (DID F201) and 0x02 (DID F202)
POS 6A                  # accepted
PER 6A 01 04 D2         # type 1: PDID 01, value 0x04D2 (illustrative)
PER 6A 02 01            # type 1: PDID 02, state 0x01 (illustrative)
PER 6A 01 04 CF
PER 6A 02 01
REQ 2A 04 01 02         # stop both
POS 6A
```

| Line | Bytes | Meaning |
|---|---|---|
| REQ 2 | 03 | sendAtFastRate |
| REQ 3–4 | 01 02 | PDIDs = DIDs 0xF201, 0xF202 |
| POS | 6A | Positive response (0x2A + 0x40), scheduler started |
| PER 1 | 6A | Type 1 messages carry the response SID |
| PER 2 | 01 / 02 | PDID |
| PER 3… | 04 D2 / 01 | Data record of DID 0xF201 / 0xF202, layout per OEM spec |
| 2nd REQ 2 | 04 | stopSending for the listed PDIDs |

Type 2 periodic messages on a separate CAN ID (illustrative IDs).

```uds
REQ 2A 02 10            # medium rate, PDID 0x10 (DID F210)
POS 6A
PER 10 0C 80 00 00 00 00 00   # type 2 on its own CAN ID: PDID + 7 data bytes (illustrative)
PER 10 0C 7F 00 00 00 00 00
REQ 2A 04               # stop all
POS 6A
```

| Line | Bytes | Meaning |
|---|---|---|
| REQ 2 | 02 | sendAtMediumRate |
| REQ 3 | 10 | PDID 0x10 = DID 0xF210 |
| PER 1 | 10 | PDID (no SID in type 2) |
| PER 2–8 | 0C 80 00 … | Up to 7 data bytes per frame on classic CAN |
| 2nd REQ | 2A 04 | stopSending, no PDID = stop all |

Negative responses.

```uds
REQ 2A 03               # rate given but no PDID
NEG 7F 2A 13
REQ 2A 05 01            # reserved transmissionMode
NEG 7F 2A 31
REQ 2A 03 7E            # PDID 0x7E not supported (illustrative)
NEG 7F 2A 31
REQ 2A 03 01 02 03 04 05 06   # scheduler full (illustrative limit)
NEG 7F 2A 31
```

| Exchange | Problem | NRC |
|---|---|---|
| 1 | No PDID with a start mode | 13 |
| 2 | transmissionMode 0x05 reserved | 31 |
| 3 | PDID not defined | 31 |
| 4 | Too many PDIDs for the scheduler | 31 (some ECUs: 22 or 13) [unverified] |

## 7. Implementation and testing

**Implementation:**
- Builder: transmissionMode as an enum; PDIDs as 1-byte values or as 0xF2xx DIDs converted to their low byte.
  Reject DIDs outside 0xF200–0xF2FF.
- Receiver: periodic messages arrive at any time, interleaved with normal responses. Route type 1 messages
  (`6A` + PDID) away from the request/response matcher, or the next `6A` may be taken for a periodic message.
  Type 2 needs a listener on the extra CAN ID.
- Timestamp every periodic message at reception; check the spacing against the OEM rate with a tolerance.
- Keep the session with `3E 80` at less than S3; check periodic messages stop when you stop TesterPresent.
- Always send `2A 04` in test teardown and after failures, so the next test starts clean.
- Parse records with the 0xF2xx DID definition; length is fixed per DID.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Start each rate | `2A 01 xx`, `2A 02 xx`, `2A 03 xx` | `6A`, then messages at slow/medium/fast period ± tolerance |
| 2 | Stop listed | `2A 04 xx` | `6A`; messages for xx stop within one period |
| 3 | Stop all | `2A 04` | `6A`; all periodic messages stop |
| 4 | Change rate | Start slow, then `2A 03` same PDID | Rate changes, no duplicate schedule |
| 5 | Reserved mode | `2A 00 xx`, `2A 05 xx` | `7F 2A 31` |
| 6 | Unsupported PDID | Undefined PDID | `7F 2A 31` |
| 7 | Length min-1 | `2A` | `7F 2A 13` |
| 8 | Start with no PDID | `2A 03` | `7F 2A 13` |
| 9 | Max PDIDs | Exactly the ECU's maximum | `6A`, all scheduled |
| 10 | Max+1 PDIDs | One more | NRC per ECU spec (0x22/0x31/0x13) — record which |
| 11 | Record too long for type 1/2 | PDID whose record exceeds one frame | `7F 2A 31` [unverified] |
| 12 | Session matrix | Default, extended, programming | Matches OEM spec; default usually `7F 2A 7F` |
| 13 | Session change stops | Running, then `10 01` | Periodic messages stop |
| 14 | Non-default to non-default | Running in extended, then other non-default session | Record whether it stops [edition-dependent] |
| 15 | S3 timeout | Stop TesterPresent | Session drops after S3, periodic messages stop |
| 16 | ECU reset | `11 01` while running | No periodic messages after restart |
| 17 | Security matrix | Secured PDID data, locked/unlocked | `7F 2A 33`, then `6A` |
| 18 | Interleaving | Send `22 F1 90` while periodic messages run | Correct `62` response; periodic messages continue |
| 19 | Functional addressing | `2A 03 xx` functional | Record behaviour; usually not supported [unverified] |
| 20 | 0x2C-defined PDID | Define 0xF2xx via 0x2C, then schedule | Periodic messages carry the defined content |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.5 (data transmission functional unit). Periodic message transport details also involve ISO 14229-2 and the transport-specific parts [unverified]. |
| Edition differences | 2020 Foreword: service updated; specifics not confirmed here [edition-dependent] [unverified]. Session-change stopping rules may differ between 2013 and 2020 [unverified]. 2026 edition not yet reviewed. |
| OEM / ECU-specific | Period of each rate; type 1 vs type 2; CAN ID for type 2; maximum scheduled PDIDs; available PDIDs and their contents; sessions. |
| Verification status | draft. Cross-checked: clause number, SID/response SID, "updated in 2020" statement, general purpose (ISO preview, py-uds docs). Reviewer 2026-10-26: transmissionMode codes 0x01 slow / 0x02 medium / 0x03 fast / 0x04 stop, PDID = low byte of 0xF2xx (offset 0xF200, 1 byte), PDID count rules per mode, and "initial positive response = 6A only" checked against py-uds source and ArcCore Dcm source (open-source implementations, not normative). Type 1 / type 2 message constraints, stopping rules and NRC choices remain engineering knowledge. |
| Open questions | transmissionMode codes: pyudskit.readthedocs.io lists 0x01 = stopSending, but py-uds source, ArcCore Dcm and a CSDN blog example all use 0x01 slow … 0x04 stop; pyudskit is treated as wrong here. Still to confirm against ISO: initial positive response content; what exactly changed in 2020 (likely periodic message transport); type 1 single-frame rule in 2020; NRC for a full scheduler (0x31 vs 0x22); whether 0x2C may define DIDs in 0xF2xx. |
