---
sid: 0x35
name: RequestUpload
response_sid: 0x75
has_sub_function: false
functional_unit: "upload/download"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "15.3 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) - clause number and functional unit only"
  - "python-udsoncan RequestUpload implementation (github.com/pylessard/python-udsoncan, read 2026-10-26) - field order compared, not normative"
  - "py-uds source (github.com/mdabrowski1990/uds, service_definitions/request_upload.py): same request/response structure as RequestDownload (reviewer, 2026-10-26)"
  - "damodev.csdn.net/6a435957662f9a54cb866add.html: upload maxNumberOfBlockLength 0x0081 = SID + blockSequenceCounter + 127 data bytes in the 0x76 response - secondary (reviewer, 2026-10-26)"
---

# 0x35 — RequestUpload

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x75
> Opens an upload (ECU → tester) of a memory range; the data then comes back in TransferData responses.

Related entries in this functional unit: [0x34 RequestDownload](0x34-request-download.md) ·
[0x36 TransferData](0x36-transfer-data.md) · [0x37 RequestTransferExit](0x37-request-transfer-exit.md) ·
[0x38 RequestFileTransfer](0x38-request-file-transfer.md)

## 1. What is it?

RequestUpload (SID 0x35) is the mirror of [0x34 RequestDownload](0x34-request-download.md): it starts a
transfer **from** the ECU **to** the tester. The tester names the memory range (memoryAddress, memorySize)
and the encoding it wants (dataFormatIdentifier). The ECU answers with maxNumberOfBlockLength, the largest
TransferData message it will send. The tester then pulls the data with
[0x36 TransferData](0x36-transfer-data.md) requests that carry only the block counter; each positive response
carries one block. [0x37 RequestTransferExit](0x37-request-transfer-exit.md) closes the transfer.

The request and response layouts are the same as 0x34; only the direction of the data and the SID differ.
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

- Reading a large memory area (kilobytes to megabytes) with
  [0x23 ReadMemoryByAddress](0x23-read-memory-by-address.md) means hundreds of independent requests, each
  limited by the response length, with no sequence control. 0x35 gives one transfer with a block counter.
- The ECU can apply compression or encryption to the uploaded data (DFI), which 0x23 cannot.
- It gives development and failure-analysis teams a controlled, security-gated way to extract memory
  contents without a debugger connection.

Who benefits: development (memory dumps, calibration readback), failure analysis (returned parts), validation
(compare flash content after download), and — for event data recorders — crash data retrieval tools
[OEM-specific].
<!-- catalogue field 3 -->

## 3. What is its purpose?

It **opens** an upload state for one range and negotiates block length. It does not read anything by itself,
does not decode data and does not change ECU memory.

Many production ECUs **do not support 0x35 at all**, or only for specific ranges, because it can expose
software and secrets. Expect 0x11 or 0x7F on production software and treat that as normal.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Read a few bytes or one variable | [0x23 ReadMemoryByAddress](0x23-read-memory-by-address.md) | Single message, no transfer state |
| Read identified data (part numbers, fault records) | [0x22 ReadDataByIdentifier](0x22-read-data-by-identifier.md) / [0x19 ReadDTCInformation](0x19-read-dtc-information.md) | Stable interface, no memory map needed |
| Read a file from a file-system ECU | [0x38 RequestFileTransfer](0x38-request-file-transfer.md) mode 04 ReadFile | Path-based |
| Verify flashed content | Checksum/signature routine via [0x31](0x31-routine-control.md) | Faster and does not expose the image |
| Write memory | [0x34 RequestDownload](0x34-request-download.md) | Opposite direction |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Development memory dump after a field issue
- **Scenario:** A development ECU shows an intermittent fault; the team wants the RAM log buffer and a
  calibration area.
- **Engineer's objective:** Copy the area to the PC for offline analysis without a debugger.
- **Why this service:** Range is tens of kilobytes; 0x23 would need hundreds of requests.
- **Tester sends:** `35 00 44 <address> <size>` in extended or programming session after security unlock.
- **ECU is expected to:** Accept the range and return a block length; answer each 0x36 with data.
- **Engineer obtains:** A binary file of exactly memorySize bytes.
- **Test on success / failure:** Success = byte count matches, and a repeat dump of a static area gives the
  same hash. Failure = 0x31 (range not uploadable), 0x33 (security), 0x70 (refused).

### Use case: Event data extraction from a restraint control module
- **Scenario:** After a crash test, the lab retrieves the stored event records from the airbag ECU. Many
  OEMs provide EDR data via 0x22 DIDs instead; some development or supplier tools use an upload of the
  event memory area [OEM-specific].
- **Engineer's objective:** Retrieve the complete, unmodified event record for correlation with the crash
  test instrumentation.
- **Why this service:** Event memory is a contiguous block; upload preserves it bit for bit.
- **Tester sends:** Programming or supplier session, supplier security level, then `35 00 44 <event area>
  <size>` (values from the supplier's spec).
- **ECU is expected to:** Upload without modifying or clearing the records; refuse the range without the
  correct security level.
- **Engineer obtains:** Raw event records plus proof (byte count, checksum) that the transfer was complete.
- **Test on success / failure:** Upload twice; both images identical. Event record count read via 0x22 is
  unchanged after the upload.

### Use case: Flash readback in bootloader validation
- **Scenario:** Validation of a bootloader whose OEM permits upload of the application area in a test build.
- **Engineer's objective:** Compare the flashed image with the source file.
- **Why this service:** Byte-level comparison finds gaps a checksum routine could hide (e.g. wrong padding).
- **Tester sends:** Download sequence ([0x34](0x34-request-download.md)), reset, then 0x35 on the same range.
- **ECU is expected to:** Return the same bytes that were downloaded.
- **Engineer obtains:** Binary diff = empty.
- **Test on success / failure:** Any differing byte is a bug in tester block splitting or ECU write logic.
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. Tester sends `35 DFI ALFID memoryAddress memorySize`.
2. ECU checks session, security, length vs ALFID, DFI/ALFID support, range readable, preconditions.
3. ECU enters the upload state, expects block counter 0x01 next, replies `75 LFID maxNumberOfBlockLength`.
4. Tester sends `36 01`, `36 02`, … (no data in the request). Each positive response is `76 <counter> <data>`.
5. Tester stops when it has received memorySize bytes (or the compressed size) and sends `37`.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Programming or extended, or a supplier session | OEM |
| Security / authentication | Usually a dedicated (often supplier/development) security level, or 0x29 role | OEM |
| ECU operating conditions | Vehicle stationary; no transfer active | OEM |
| Timing (P2 / P2* / S3) | 0x35 normally answered within P2; each 0x36 response may need 0x78 if data is read from slow external memory | Standard timing, OEM values |

**Depends on:** [0x10](0x10-diagnostic-session-control.md), [0x27](0x27-security-access.md) or
[0x29](0x29-authentication.md), then [0x36](0x36-transfer-data.md) and
[0x37](0x37-request-transfer-exit.md). Uploaded blocks of more than 7 bytes arrive as multi-frame responses on
classic CAN; the tester must send Flow Control quickly. See
[ISO-TP essentials](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials).
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x35 |
| 2 | dataFormatIdentifier (DFI) | 1 | Bits 7–4 compressionMethod, bits 3–0 encryptingMethod requested for the uploaded data. 0x00 = raw |
| 3 | addressAndLengthFormatIdentifier (ALFID) | 1 | Bits 7–4 = byte count of memorySize, bits 3–0 = byte count of memoryAddress |
| 4 … 3+a | memoryAddress | a | Big-endian start address |
| … | memorySize | s | Big-endian number of bytes to upload (uncompressed) [unverified for compressed uploads] |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x75 |
| 2 | lengthFormatIdentifier | 1 | Bits 7–4 = byte count k of maxNumberOfBlockLength; bits 3–0 reserved |
| 3 … | maxNumberOfBlockLength | k | Largest TransferData **positive response** the ECU will send, including SID 0x76 and the counter byte. Data per block = value − 2. Supported by a secondary reproduction of the ISO upload example; ISO text not checked here |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x11 | serviceNotSupported | Upload not implemented (common on production software) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length does not match the ALFID |
| 0x22 | conditionsNotCorrect | OEM preconditions fail, or a transfer is already active [unverified] |
| 0x31 | requestOutOfRange | DFI/ALFID unsupported, or range not uploadable (protected keys, bootloader, unmapped memory) |
| 0x33 | securityAccessDenied | Required security level not unlocked |
| 0x34 | authenticationRequired | 0x29 role missing [edition-dependent, 2020] |
| 0x70 | uploadDownloadNotAccepted | Range valid but upload refused (e.g. data being written, memory fault) [OEM-specific] |
| 0x7F | serviceNotSupportedInActiveSession | Wrong session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Range: 4 KiB at 0x20001000 (illustrative).

**Example 1 — 4 KiB upload in four blocks:**

```uds
REQ 35 00 44 20 00 10 00 00 00 10 00   # raw data, 4-byte address 0x20001000, 4-byte size 0x1000
POS 75 20 04 02                        # max 0x0402 per TransferData response (illustrative)
REQ 36 01                              # pull block 1
POS 76 01 ..                           # 1024 data bytes
REQ 36 02
POS 76 02 ..
REQ 36 03
POS 76 03 ..
REQ 36 04
POS 76 04 ..                           # 4 × 1024 = 4096 bytes received
REQ 37
POS 77
```

| Bytes | Field | Decoded |
|---|---|---|
| 35 | SID | RequestUpload |
| 00 | DFI | no compression, no encryption |
| 44 | ALFID | 4-byte size, 4-byte address |
| 20 00 10 00 | memoryAddress | 0x20001000 (illustrative) |
| 00 00 10 00 | memorySize | 4096 bytes |
| 75 20 04 02 | Response | LFID 2 bytes; maxNumberOfBlockLength 1026 → 1024 data bytes per block |
| 36 0N / 76 0N .. | TransferData | Request carries only the counter; response echoes it plus data |
| 37 / 77 | RequestTransferExit | Upload closed |

**Example 2 — refusals:**

```uds
REQ 35 00 44 00 00 00 00 00 00 80 00   # bootloader area, protected (illustrative)
NEG 7F 35 31
REQ 35 00 44 20 00 10 00 00 00 10 00   # security not unlocked
NEG 7F 35 33
REQ 35 00 44 20 00 10 00 00 00 10 00   # production software without upload
NEG 7F 35 11
```

| Bytes | Decoded |
|---|---|
| 7F 35 31 | Range not uploadable |
| 7F 35 33 | Security level missing |
| 7F 35 11 | Service not implemented |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**
- Builder: same as [0x34](0x34-request-download.md#7-implementation-and-testing); share one memory-location
  encoder for 0x23, 0x34, 0x35 and 0x3D.
- Transfer loop: blocks = ceil(memorySize / (maxNumberOfBlockLength − 2)); last block may be shorter.
  Stop when the received byte count equals memorySize; do not request an extra block. With compression, stop
  when the ECU's data ends — define the rule with the OEM [OEM-specific].
- Validate each 0x76 response: echoed counter equals the one sent; data length ≤ announced maximum − 2.
- Write the output file only after 0x37 succeeds; keep partial files clearly marked.
- Security: never log uploaded content that may contain keys; store dumps under access control.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path | Example 1 | 0x75, four blocks, 0x77; 4096 bytes |
| 2 | Length min-1 / min / max+1 | ALFID 0x44 with 10 / 11 / 12 bytes | 0x13 / 0x75 / 0x13 |
| 3 | Invalid ALFID / DFI | ALFID 0x40; DFI 0x11 | 0x31 |
| 4 | Range checks | Start outside, end outside, protected area | 0x31 |
| 5 | Session matrix | Default / extended / programming | Per OEM; at least default → 0x7F |
| 6 | Security matrix | Locked / correct level / wrong level | 0x33 / 0x75 / 0x33 |
| 7 | Authentication (2020 ECU) | No role / development role | 0x34 / 0x75 |
| 8 | Not implemented | Production software | 0x11 (physical) |
| 9 | Functional addressing | 0x35 functional | No response [OEM-specific] |
| 10 | Bit 7 of DFI | DFI 0x80 | Response always sent (0x31 if unsupported) — no SPRMIB semantics |
| 11 | Block size | Response length per block | ≤ maxNumberOfBlockLength |
| 12 | Extra block | 0x36 after all data received | 0x24 or 0x31 [unverified] |
| 13 | Second 0x35 during upload | 0x35 after block 2 | 0x22 or restart [OEM-specific] |
| 14 | Multi-frame | 1026-byte responses on classic CAN | FC sent in time; no N_Bs timeout |
| 15 | Response pending | Slow external memory | 0x78 handled within P2* |
| 16 | Data integrity | Upload static area twice | Identical hashes |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 15.3 (upload/download functional unit), from the preview TOC |
| Edition differences | No structural change between 2013 and 2020 known to the author [unverified]. NRC 0x34 possible with 0x29 in 2020 [edition-dependent]. 2026 not yet reviewed |
| OEM / ECU-specific | Whether the service exists at all; uploadable ranges; security level; session; DFI support; how compressed uploads end |
| Verification status | draft. Clause number cross-checked (preview TOC). Field order compared with python-udsoncan and py-uds (not normative). Reviewer 2026-10-26: meaning of maxNumberOfBlockLength for uploads supported by a secondary source (damodev.csdn.net). Not checked against the ISO text |
| Open questions | Confirm that maxNumberOfBlockLength for uploads limits the 0x76 response and includes SID and counter; NRC for a 0x36 after the last block |
<!-- catalogue field 15 -->
