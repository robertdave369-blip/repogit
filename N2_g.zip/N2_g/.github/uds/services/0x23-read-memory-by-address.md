---
sid: 0x23
name: ReadMemoryByAddress
response_sid: 0x63
has_sub_function: false
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.3 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number and functional unit"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x23, response SID 0x63"
  - "py-uds source (github.com/mdabrowski1990/uds: data_record_definitions/other.py ADDRESS_AND_LENGTH_FORMAT_IDENTIFIER = memorySizeLength (high nibble) + memoryAddressLength (low nibble); formula.py get_data_from_memory: memoryAddress before memorySize, zero nibble invalid; service_definitions/read_memory_by_address.py: response = data only) (reviewer, 2026-10-26)"
  - "python-udsoncan AddressAndLengthFormatIdentifier.py: (memsize_len << 4) | address_len (reviewer, 2026-10-26)"
  - "ISO 14229-1:2020 preview TOC (webstore.ansi.org): Annex H (informative) gives addressAndLengthFormatIdentifier examples (reviewer, 2026-10-26)"
---

# 0x23 — ReadMemoryByAddress

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x63
> Reads a block of ECU memory given a start address and a size, both with tester-chosen byte widths.

## 1. What is it?

ReadMemoryByAddress (RMBA), SID 0x23, returns raw bytes from the ECU's memory map. The tester gives a start
address and a length. A format byte, the addressAndLengthFormatIdentifier (ALFID), tells the ECU how many
bytes each of those two fields uses.

The ECU returns the memory content as is. It adds no echo of the address and no length field. The meaning
of the bytes depends entirely on the software build (map file, A2L).

## 2. Why is it needed?

- Not every variable has a DID. During development, engineers need to look at RAM, calibration data or
  NVM mirrors that were never published as DIDs.
- It works with the map/A2L of a given build, without changing the diagnostic specification.
- It lets a tester verify calibration or NVM content byte for byte after a write (0x3D) or a flash.
- It supplies a block-read primitive for 0x2C defineByMemoryAddress, which uses the same ALFID scheme.

Who benefits: software and calibration developers, validation teams debugging a failure, suppliers analysing
returned parts. Production and workshop tools rarely use it, and most production ECUs lock or remove it.

## 3. What is its purpose?

Raw memory inspection. It returns bytes; it does not interpret, scale or check them. It must not change
memory. It does not make an address stable across builds.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Value has a DID | [0x22 ReadDataByIdentifier](0x22-read-data-by-identifier.md) | Stable across builds, no address knowledge needed |
| Large upload of a memory region (whole flash bank, crash log) | 0x35 RequestUpload + 0x36 TransferData | Block transfer with sequence counter, sized for bulk data |
| Recurring read of the same RAM values | [0x2C](0x2C-dynamically-define-data-identifier.md) defineByMemoryAddress, then 0x22 or [0x2A](0x2A-read-data-by-periodic-identifier.md) | Defined once, then read by DID |
| Production or after-sales tool | DID-based services | Address access is usually disabled in series software |
| Full calibration measurement (many signals, fast) | XCP/CCP | Designed for measurement and calibration; UDS is not |

## 4. When is it used? — Real use cases

### Use case: Inspecting a RAM variable during HIL debugging
- **Scenario:** Validation bench; a restraint ECU logs an unexpected internal fault. The variable that holds
  the fault reason has no DID.
- **Engineer's objective:** Read the variable directly while the bench reproduces the fault.
- **Why this service:** The address is known from the map file of the build under test; no DID exists.
- **Tester sends:** `10 03`, `27` unlock with the development level, then `23 14 20 00 4A 10 04`
  (address 0x20004A10, 4 bytes — illustrative).
- **ECU is expected to:** Return the 4 bytes at that address.
- **Engineer obtains:** The raw fault-reason word, decoded with the map/A2L type information.
- **Test on success / failure:** Success if 4 bytes come back and match the expected type range. NRC 0x31
  means the address is outside the ECU's allowed read regions (check the map file version).

### Use case: Checking calibration content after a write
- **Scenario:** Development ECU, calibration engineer has written a parameter block with 0x3D.
- **Engineer's objective:** Read back the block and compare with the intended values.
- **Why this service:** Byte-exact read of the same region, same ALFID scheme as the write.
- **Tester sends:** `23 24 00 08 10 00 00 20` (address 0x00081000, 32 bytes — illustrative).
- **ECU is expected to:** Return the 32 bytes.
- **Engineer obtains:** The actual content to diff against the write.
- **Test on success / failure:** Pass if identical. A difference after an ECU reset suggests the write
  reached RAM only and was not committed to NVM.

## 5. How does it work?

1. Tester sends `23`, the ALFID, the address and the size.
2. ECU checks length against the ALFID, then checks the ALFID itself, then the address range, then security
   and conditions. General NRC order: [../protocol-fundamentals.md](../protocol-fundamentals.md).
3. ECU copies `memorySize` bytes from `memoryAddress` into the response.

**ALFID nibbles:**

| Bits | Name | Meaning |
|---|---|---|
| 7–4 (high nibble) | memorySize length | Number of bytes of the memorySize field (1–4 in practice) |
| 3–0 (low nibble) | memoryAddress length | Number of bytes of the memoryAddress field (1–5 in practice) |

So ALFID `0x14` = 1-byte size, 4-byte address; `0x24` = 2-byte size, 4-byte address. A nibble of 0 is
invalid. Which combinations an ECU accepts is ECU-specific [OEM-specific]. Address and size are big-endian.
Nibble order and field order cross-checked against py-uds and python-udsoncan source; ISO 14229-1 Annex H
(informative) has worked ALFID examples. Note: pyudskit.readthedocs.io shows the ALFID as `addrLen << 4`,
which is the wrong way round — do not copy it.

The ALFID field order is a common source of bugs: the high nibble is the **size** length and the low nibble
is the **address** length, but in the message the **address** comes first.

**Size limit.** The response is 1 + memorySize bytes, so memorySize is bounded by the transport and ECU buffer.
Above that, expect NRC 0x31 or 0x14 depending on the ECU [unverified which one ISO specifies].

**Security.** RMBA is a classic way to leak keys, seeds, secure counters or IP. Typical production policy:
service disabled, or only open after a supplier-level 0x27 unlock in a non-default session, with
address regions whitelisted. Regions holding cryptographic material should never be readable [OEM-specific].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Extended or a supplier/development session; not default | OEM |
| Security / authentication | 0x27 development/supplier level, or 0x29 role in 2020 ECUs | OEM |
| ECU operating conditions | Usually none; may be blocked while the vehicle moves | OEM |
| Timing (P2 / P2* / S3) | Answer within P2; large reads from slow memory may use 0x78 | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** 0x10, 0x27/0x29, ISO-TP for responses over one frame, the build's map/A2L for addresses.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x23 |
| 2 | addressAndLengthFormatIdentifier | 1 | High nibble = size length, low nibble = address length |
| 3 … | memoryAddress | low nibble bytes | Big-endian start address |
| … | memorySize | high nibble bytes | Big-endian number of bytes to read |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the ALFID.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x63 |
| 2 … | dataRecord | memorySize | Memory content from memoryAddress upwards |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Total length does not match 2 + address bytes + size bytes from the ALFID |
| 0x14 | responseTooLong | Requested size exceeds the response buffer [unverified vs 0x31] |
| 0x22 | conditionsNotCorrect | OEM conditions not met (for example vehicle speed) |
| 0x31 | requestOutOfRange | ALFID nibble unsupported or zero; address or address+size outside allowed regions; size 0 |
| 0x33 | securityAccessDenied | Region or service requires an unlocked security level |
| 0x34 | authenticationRequired | 2020 ECUs using 0x29 role checks [edition-dependent] [unverified] |
| 0x7F | serviceNotSupportedInActiveSession | Service not available in the current session |
| 0x11 | serviceNotSupported | Service removed from series software |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Addresses and data come from a hypothetical map file.

```uds
REQ 23 14 20 00 4A 10 04        # 4 bytes at 0x20004A10 (illustrative)
POS 63 00 00 01 2C              # raw content (illustrative)
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 1 | 23 | ReadMemoryByAddress |
| REQ 2 | 14 | ALFID: size field 1 byte, address field 4 bytes |
| REQ 3–6 | 20 00 4A 10 | memoryAddress 0x20004A10 (illustrative) |
| REQ 7 | 04 | memorySize 4 bytes |
| POS 1 | 63 | Positive response (0x23 + 0x40) |
| POS 2–5 | 00 00 01 2C | Content; as uint32 big-endian = 300 (the ECU's own byte order applies) |

```uds
REQ 23 24 00 08 10 00 00 20     # 32 bytes at 0x00081000 (illustrative)
POS 63 ..                       # 32 data bytes
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 2 | 24 | ALFID: size 2 bytes, address 4 bytes |
| REQ 3–6 | 00 08 10 00 | Address 0x00081000 (illustrative) |
| REQ 7–8 | 00 20 | Size 0x0020 = 32 bytes |
| POS 2–33 | .. | 32 bytes of calibration data; multi-frame on classic CAN |

Negative responses.

```uds
REQ 23 14 20 00 4A 10           # size byte missing
NEG 7F 23 13
REQ 23 04 20 00 4A 10           # size nibble = 0
NEG 7F 23 31
REQ 23 14 FF FF FF F0 20        # range not readable (illustrative)
NEG 7F 23 31
REQ 23 14 20 00 4A 10 04        # locked
NEG 7F 23 33
```

| Exchange | Problem | NRC |
|---|---|---|
| 1 | 6 bytes, ALFID says 7 | 13 length |
| 2 | ALFID high nibble 0 | 31 out of range (some ECUs may answer 13 [unverified]) |
| 3 | Address+size outside readable map | 31 out of range |
| 4 | Security not unlocked | 33 |

## 7. Implementation and testing

**Implementation:**
- Builder inputs: address, size, address width, size width. Derive ALFID as `(size_len << 4) | addr_len`.
  Reject values that do not fit the chosen widths. Allow forcing widths, since ECUs often accept only one ALFID.
- Parser: check `len(response) == 1 + size`. Return raw bytes; interpret with the map/A2L, not in the
  UDS layer. Endianness of the data is the ECU CPU's, not UDS's.
- Large regions: split into chunks below the ECU limit; or use 0x35 RequestUpload.
- Keep address tables per software build; a stale map gives silent garbage, not an NRC.
- Never put RMBA addresses into production test sequences unless the OEM specifies them.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive | Valid ALFID, address, size in allowed region | `63` + size bytes |
| 2 | Each supported ALFID | 0x12, 0x14, 0x24, 0x44 … as the ECU spec lists | Positive for listed, `7F 23 31` for others |
| 3 | Length min-1 | One byte short of ALFID-implied length | `7F 23 13` |
| 4 | Length min | Exact length with size 1 | Positive |
| 5 | Length max+1 | One extra byte | `7F 23 13` |
| 6 | Size 0 | Size field 0 | `7F 23 31` [unverified] |
| 7 | Size max | Largest size the ECU allows | Positive, multi-frame |
| 8 | Size max+1 | One byte more | `7F 23 31` or `7F 23 14` — record which |
| 9 | Range edges | Start at region start; end exactly at region end; one byte beyond | Positive, positive, `7F 23 31` |
| 10 | Protected region | Key/seed storage address | `7F 23 31` or `7F 23 33`, never data |
| 11 | Session matrix | Default, extended, programming | Matches OEM spec; default usually `7F 23 7F` |
| 12 | Security matrix | Locked, wrong level, correct level | `7F 23 33`, `7F 23 33`, positive |
| 13 | Functional addressing | Request on functional ID | Not answered or rejected per OEM spec [unverified] |
| 14 | Multi-frame | 32-byte read on classic CAN | Correct FF/FC/CF sequence |
| 15 | Response pending | Read from slow external memory (if any) | `7F 23 78` then positive within P2* |
| 16 | Series software | Service in production build | `7F 23 11` if removed |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.3 (data transmission functional unit). The ALFID format is shared with 0x2C, 0x34, 0x35 and 0x3D; Annex H (informative) gives ALFID examples. |
| Edition differences | No change to the message layout between 2013 and 2020 is known [unverified]. 2020 adds authentication, so 0x34 may appear [edition-dependent]. 2026 edition not yet reviewed. |
| OEM / ECU-specific | Accepted ALFIDs, readable regions, maximum size, sessions, security level, whether the service exists at all in series software. |
| Verification status | cross-checked. Reviewer 2026-10-26: status raised to cross-checked — core structure (ALFID nibbles, address-before-size, data-only response) confirmed by py-uds and python-udsoncan source. Previously draft. Cross-checked: clause number, SID/response SID. Reviewer 2026-10-26: ALFID nibble layout (high = size length, low = address length), address-before-size order and data-only response checked against py-uds and python-udsoncan source (open-source, not normative). NRC list and security practice from engineering knowledge. |
| Open questions | Whether ISO specifies 0x14 or 0x31 for an oversized read; whether functional addressing is excluded; maximum nibble values ISO allows. |
