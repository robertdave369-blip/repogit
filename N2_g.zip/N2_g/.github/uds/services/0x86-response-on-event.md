---
sid: 0x86
name: ResponseOnEvent
response_sid: 0xC6
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.9 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview TOC (cdn.standards.iteh.ai sample 72439) — clause number and functional unit only"
  - "py-uds knowledge base (uds.readthedocs.io) — response SID 0xC6; separate 2013 and 2020 request formats; reportActivatedEvents = 0x04"
  - "py-uds translator source (github.com/mdabrowski1990/uds: utilities/constants/subfunctions.py and other.py, data_record_definitions/conditional.py, formula.py, other.py; tests/.../test_response_on_event.py) — eventType lists 2013 vs 2020, storageState bit, eventWindowTime values, eventTypeRecord contents and sizes, request/response field order"
  - "diadrom.com (secondary) — ISO 14229-1:2026 lists corrections to ResponseOnEvent; not yet reviewed"
  - "Engineering knowledge — session/reset rules, end-of-window response, NRC choices (not cross-checked)"
---

# 0x86 — ResponseOnEvent

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0xC6
> Tells the server to watch for an event (DTC status change, DID value change, value comparison …) and, each
> time it happens, to run a stored diagnostic request and send its response without being asked.
> **This service changed in 2020 and again in 2026. Check the edition before trusting any byte layout here.**

## 1. What is it?

ResponseOnEvent (ROE, SID 0x86) turns the normal request/response pattern around. The tester sends a set-up
request that defines:

- the **event** to watch (eventType + eventTypeRecord, e.g. "any DTC whose confirmedDTC bit changes");
- the **eventWindowTime** — how long the event logic stays active;
- the **serviceToRespondToRecord** — a complete diagnostic request (e.g. `19 0E`, `22 <DID>`) the server
  executes each time the event fires.

After a start request, the server sends the response to the stored request on every event. These event
responses carry the stored service's SID + 0x40 (e.g. `59 …`, `62 …`), not 0xC6. In examples they appear as
`EVT` lines.

The sub-function byte (eventType) has three parts:

| Bit 7 | Bit 6 | Bits 5–0 |
|---|---|---|
| SPRMIB — suppress the positive response to *this* request | storageState: 0 = doNotStoreEvent, 1 = storeEvent | eventType value |

storageState = storeEvent asks the server to keep the event definition in non-volatile memory so it survives a
reset or power cycle [unverified — exact persistence and auto-restart rules are edition- and OEM-dependent].

## 2. Why is it needed?

Polling is costly and slow. A tester (or an on-board client such as a telematics unit) that wants to know when a
DTC confirms, or when a value crosses a threshold, would otherwise send `19 02 ..` or `22 ..` every few hundred
milliseconds. That loads the bus, adds latency equal to the poll period, and can miss short changes.

ROE moves the detection into the server, which sees every change at its own task rate, and only sends
traffic when something happens. Value: development and validation engineers (event-driven fault monitoring),
OEM on-board diagnostic clients, data loggers.

Few production ECUs implement ROE; many OEM specs forbid it [OEM-specific]. Always check the ECU spec first.

## 3. What is its purpose?

It configures, starts, stops, lists and clears event-triggered diagnostic responses. It does not create new
data: the event response is exactly what the stored service would have returned. It does not replace
periodic reading at a fixed rate (that is ReadDataByPeriodicIdentifier 0x2A).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Need values at a fixed rate | ReadDataByPeriodicIdentifier (0x2A) | Time-driven, simpler, widely supported |
| One-off reading | ReadDataByIdentifier (0x22) / ReadDTCInformation (0x19) | No set-up overhead |
| DTC setting is off (0x85 02) | Turn it on first ([0x85](0x85-control-dtc-setting.md)) | No status change → no event |
| ECU spec does not list 0x86 | Polling | Expect `7F 86 11` |
| Precise timestamps of changes | ECU logging / measurement (XCP) | Event responses have no time stamp |

<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Event-driven DTC monitoring during HIL fault injection (development ECU)
- **Scenario:** A development airbag control unit on a HIL bench supports ROE. The test injects a squib
  open-circuit on one loop and must record the moment the DTC confirms, while other test steps keep using the
  diagnostic channel.
- **Engineer's objective:** Capture the confirmation without polling and measure fault-to-DTC latency from the
  bus trace.
- **Why this service:** The server pushes `59 0E …` as soon as the confirmedDTC bit changes.
- **Tester sends:** `10 03`, `86 01 02 08 19 0E` (onDTCStatusChange, mask 0x08, respond with
  reportMostRecentConfirmedDTC), `86 05 02` (start), then injects the fault.
- **ECU is expected to:** Answer `C6 01 00 ..`, `C6 05 00 ..`, then send `59 0E <mask> <DTC> <status>` once the
  fault qualifies.
- **Engineer obtains:** The DTC number and the trace time of the event response.
- **Test on success / failure:** Event response within the specified qualification time = pass. No event:
  check that DTC setting is on, the session is still active (S3), and the ECU supports the mask.

### Use case: Value-change notification for a development DID
- **Scenario:** An engineer validates a state-machine DID (0x4711, illustrative) during a long drive-cycle
  replay on a HIL. The state changes rarely.
- **Engineer's objective:** Log every state transition without polling every 100 ms.
- **Why this service:** onChangeOfDataIdentifier sends `62 47 11 <value>` only on change.
- **Tester sends:** `86 03 02 47 11 22 47 11`, then `86 85 02` (start, SPRMIB set).
- **ECU is expected to:** Send `C6 03 00 ..`, no response to the start, then one `62 47 11 ..` per change.
- **Engineer obtains:** A sparse, complete log of transitions.
- **Test on success / failure:** Number of event responses equals the number of transitions in the replay
  script. Missing events point to a server sampling rate slower than the state changes.

<!-- catalogue fields 5, 6 -->

## 5. How does it work?

**Set-up → control → events → end.**

1. **Set-up** (eventType 0x01, 0x03, 0x07; 0x02 in 2013; 0x08, 0x09 in 2020): server validates eventTypeRecord and
   serviceToRespondToRecord (the stored service must be supported, e.g. the DID must exist) and stores the
   event. Positive response echoes the set-up with numberOfIdentifiedEvents = 0. Several events may be set up
   [unverified limit; OEM-defined].
2. **Start** (0x05): event logic becomes active for the eventWindowTime.
3. **Events:** each time the condition is met, the server executes the stored request and sends its response
   (positive or negative) on the response ID of the original set-up request. The event response is not a
   response to any pending request; the tester must be able to receive it at any time.
4. **Stop** (0x00): event logic paused, definitions kept. **Clear** (0x06): definitions deleted.
   **Report** (0x04): server lists the active events.
5. **End of window:** for a finite eventWindowTime, the server stops and sends a final `C6` response with
   numberOfIdentifiedEvents [unverified]. 0x02 = infinite window.

**Session / reset rules** [unverified — edition- and OEM-dependent]: a reset or a session change stops ROE
(the [0x10 transition table](0x10-diagnostic-session-control.md#5-how-does-it-work) assumes any session
change, including non-default → non-default); doNotStore events are then lost; storeEvent events may be kept
and, in some implementations, restarted. Event responses do not keep the session alive — keep sending
TesterPresent.

**Edition changes** [edition-dependent] — checked against the py-uds translator (one open-source stack), not
against ISO text:

| Edition | What changed |
|---|---|
| 2013 | eventTypes 0x00–0x07, including 0x02 onTimerInterrupt. Every request carries eventWindowTime (1 byte) after the sub-function; set-up types add eventTypeRecord and serviceToRespondToRecord. Only eventWindowTime 0x02 (infinite) is named; other values OEM-defined |
| 2020 | onTimerInterrupt (0x02) removed. Added 0x08 reportMostRecentDtcOnStatusChange and 0x09 reportDTCRecordInformationOnDtcStatusChange; both carry a 0x19 reportType in the eventTypeRecord and **no** serviceToRespondToRecord. Named eventWindowTime values 0x03–0x08 added. py-uds keeps the same field order as 2013 for the other types, **including eventWindowTime on control requests** (stop/report/start/clear). Some descriptions mention a separate, shorter 2020 control-request format; py-uds does not implement one [unverified] |
| 2026 | Corrections to ResponseOnEvent listed as the main change (secondary source). Not yet reviewed |

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Usually non-default (extended) | OEM |
| Security / authentication | Usually none; OEM may protect it | OEM |
| ECU operating conditions | Resources free for event slots; DTC setting on for DTC events | ECU / OEM |
| Timing (P2 / P2* / S3) | Set-up/control answered within P2. Event responses are unsolicited — no P2 window; S3 still needs TesterPresent | ISO 14229-2 / OEM |

**Depends on:** the stored service (0x19, 0x22, …), DTC status processing ([../dtc-reference.md](../dtc-reference.md)),
ControlDTCSetting ([0x85](0x85-control-dtc-setting.md)), session handling, and a tester that receives
unsolicited frames ([../protocol-fundamentals.md](../protocol-fundamentals.md#timing)).

<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

Layouts below are cross-checked against the py-uds translator for 2013 and 2020 (not against ISO text).
The 2026 layout is not reviewed. [edition-dependent]

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x86 |
| 2 | eventType (sub-function) | 1 | bit 7 SPRMIB, bit 6 storageState (0 doNotStoreEvent, 1 storeEvent), bits 5–0 eventType |
| 3 | eventWindowTime | 1 | Present for every eventType in py-uds (both editions). 0x02 infiniteTimeToResponse; 2020 adds 0x03 short, 0x04 medium, 0x05 long, 0x06 power, 0x07 ignition, 0x08 manufacturerTrigger; other values OEM-defined [unverified] |
| 4… | eventTypeRecord | 0–10 | Depends on eventType (table below) |
| … | serviceToRespondToRecord | n | SID + parameters of the request to execute on each event. Only for 0x01, 0x02 (2013), 0x03, 0x07 |

### Sub-functions

| Value | Name | What it does | eventTypeRecord (py-uds) | Edition (py-uds) [edition-dependent] |
|---|---|---|---|---|
| 0x00 | stopResponseOnEvent | Pause event logic, keep definitions | — | 2013, 2020 |
| 0x01 | onDTCStatusChange | Fire when a DTC status bit selected by the mask changes | DTCStatusMask (1) | 2013, 2020 |
| 0x02 | onTimerInterrupt | Fire on a server timer | timer schedule (1), OEM rates | 2013 only; removed in 2020 |
| 0x03 | onChangeOfDataIdentifier | Fire when the DID value changes | DID (2) | 2013, 2020 |
| 0x04 | reportActivatedEvents | List active events | — | 2013, 2020 |
| 0x05 | startResponseOnEvent | Activate event logic | — | 2013, 2020 |
| 0x06 | clearResponseOnEvent | Delete definitions | — | 2013, 2020 |
| 0x07 | onComparisonOfValues | Fire when a DID value compared with a reference meets a condition | DID (2), comparison logic (1: 01 <, 02 >, 03 =, 04 ≠), compare value (4), hysteresis (1), localization (2: sign bit, bit count 5 bits, bit offset 10 bits) | 2013, 2020 |
| 0x08 | reportMostRecentDtcOnStatusChange | On a DTC status change, send the 0x19 report named in the record | reserved bit + 0x19 reportType (1); no serviceToRespondToRecord | 2020 only |
| 0x09 | reportDTCRecordInformationOnDtcStatusChange | On a status change matching the mask, send DTC record data | DTCStatusMask (1), reserved bit + 0x19 reportType (1), then record number (1) for reportType 0x04 / 0x06, or record number (1) + MemorySelection (1) for 0x18 / 0x19; no serviceToRespondToRecord | 2020 only |

Bit 6 storageState and bit 7 SPRMIB can be combined with any value: `0x41` = onDTCStatusChange + storeEvent;
`0x85` = start + SPRMIB.

### Positive response

| Request type | Layout after `C6 <eventType echo>` (py-uds, both editions) |
|---|---|
| Set-up (01, 03, 07; 02 in 2013; 08, 09 in 2020) | numberOfIdentifiedEvents (1, = 0 initially), eventWindowTime (1), eventTypeRecord, serviceToRespondToRecord (not for 08 / 09) |
| Stop / start / clear (00, 05, 06) | numberOfIdentifiedEvents (1), eventWindowTime (1) |
| Report (04) | numberOfActivatedEvents (1), then per event: eventType of active event (1), eventWindowTime (1), eventTypeRecord, serviceToRespondToRecord (where the type has one) |
| Event response | Not `C6`: the response of the stored service (e.g. `59 0E …`, `62 <DID> …`) or its `7F`; for 08 / 09 the matching 0x19 response [unverified] |

The echo keeps bit 6 (storageState); only bit 7 is cleared.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | eventType not implemented (e.g. 0x07 or 0x02 on a 2020 ECU) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | eventTypeRecord length wrong for the eventType; serviceToRespondToRecord missing |
| 0x22 | conditionsNotCorrect | No free event slot; OEM conditions [unverified] |
| 0x24 | requestSequenceError | Start with no event set up [unverified — some ECUs answer 0x22] |
| 0x31 | requestOutOfRange | Unknown DID, unsupported mask, unsupported eventWindowTime, stored service not allowed in ROE |
| 0x33 / 0x34 | securityAccessDenied / authenticationRequired | Only if the OEM protects ROE |
| 0x7E / 0x7F | …NotSupportedInActiveSession | Not allowed in this session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. The examples use only event types and fields common to the
2013 and 2020 layouts (py-uds) [edition-dependent].

```uds
REQ 10 03
POS 50 03 00 32 01 F4                 # timing illustrative
REQ 86 01 02 08 19 0E                 # onDTCStatusChange, doNotStore, window infinite, mask 08 (confirmedDTC), respond with 19 0E
POS C6 01 00 02 08 19 0E              # 0 events so far, set-up echoed
REQ 86 05 02                          # startResponseOnEvent
POS C6 05 00 02
NOTE squib loop 1 open circuit injected on HIL; fault qualifies
EVT 59 0E FF 91 23 45 09              # reportMostRecentConfirmedDTC: mask FF, DTC 0x912345 (illustrative), status 09
REQ 86 00 02                          # stopResponseOnEvent
POS C6 00 01 02                       # 1 event identified
REQ 86 06 02                          # clearResponseOnEvent
POS C6 06 01 02
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 2 | 86 01 | ROE, eventType 0x01, storageState 0, SPRMIB 0 |
| REQ 2 | 02 | eventWindowTime infinite |
| REQ 2 | 08 | DTCStatusMask: bit 3 confirmedDTC ([../dtc-reference.md](../dtc-reference.md)) |
| REQ 2 | 19 0E | serviceToRespondToRecord: ReadDTCInformation reportMostRecentConfirmedDTC |
| POS 2 | C6 01 00 02 08 19 0E | Echo, numberOfIdentifiedEvents 0 |
| REQ/POS 3 | 86 05 02 / C6 05 00 02 | Start; 0 events |
| EVT | 59 0E FF 91 23 45 09 | Stored service response: availability mask, DTC, status 0x09 (testFailed + confirmedDTC) |
| POS 4 | C6 00 01 02 | Stopped; 1 event identified |
| POS 5 | C6 06 01 02 | Cleared |

```uds
REQ 86 43 02 47 11 22 47 11           # onChangeOfDataIdentifier + storeEvent, DID 0x4711 (illustrative), respond with 22 47 11
POS C6 43 00 02 47 11 22 47 11        # bit 6 kept in the echo
REQ 86 85 02                          # start with SPRMIB: no positive response
EVT 62 47 11 03                       # value changed to 03 (illustrative)
EVT 62 47 11 04                       # value changed to 04
REQ 86 04 02                          # reportActivatedEvents (eventWindowTime byte present, per py-uds)
POS C6 04 01 43 02 47 11 22 47 11     # 1 active event, its definition
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 1 | 43 | 0x40 storeEvent + 0x03 onChangeOfDataIdentifier |
| REQ 1 | 47 11 / 22 47 11 | eventTypeRecord DID; stored request ReadDataByIdentifier 0x4711 |
| REQ 2 | 85 | SPRMIB + 0x05 start |
| EVT | 62 47 11 .. | Unsolicited ReadDataByIdentifier responses |
| REQ 3 | 86 04 02 | reportActivatedEvents; some ECUs may expect it without the window byte [unverified] |
| POS 3 | 01 / 43 02 47 11 22 47 11 | numberOfActivatedEvents 1; eventType 43, window 02, DID 0x4711, stored request 22 47 11 |

```uds
REQ 86 03 02 12 34 22 12 34           # DID 0x1234 not supported (illustrative)
NEG 7F 86 31
REQ 86 01 02                          # mask and serviceToRespondToRecord missing
NEG 7F 86 13
REQ 86 0A 02                          # undefined eventType
NEG 7F 86 12
REQ 86 05 02                          # start with nothing set up
NEG 7F 86 24                          # [unverified NRC choice]
```

| Line | NRC | Reason |
|---|---|---|
| 1 | 31 | DID in eventTypeRecord unknown |
| 2 | 13 | Record incomplete |
| 3 | 12 | eventType 0x0A not supported |
| 4 | 24 | No event defined before start |

<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- Make the edition a required parameter of the builder (`edition="2013"|"2020"`); the layouts differ.
- Builder: `roe_setup(event_type, record, service_to_respond, window, store=False, suppress=False)` sets bits 6
  and 7; `roe_control(kind)` for 00/04/05/06.
- Receiver: run a background listener on the physical response ID. Classify each incoming message:
  `C6` = response to an ROE request; anything else while ROE is active and no request is pending = event
  response. A request in flight can coincide with an event response — match by SID, not by order.
- Keep the session alive with TesterPresent; re-run set-up after any reset or session drop.
- In CAPL, handle event responses in the diagnostic response handler; in Python, use a queue fed by the
  receive thread.
- Clean up with stop + clear at the end of each test, also on failure.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Set-up DTC event | `86 01 02 08 19 0E` | `C6 01 00 02 08 19 0E` |
| 2 | Event fires | Start, inject fault | One `59 0E …` per status change matching the mask |
| 3 | Mask filter | Change a status bit outside the mask | No event response |
| 4 | DID change | `86 03 ..`, start, change value | `62 <DID> …` per change |
| 5 | Comparison | `86 07 ..` with threshold, cross it with hysteresis | One event per crossing, none inside hysteresis |
| 6 | Stop / start | Stop, inject, start | No event while stopped |
| 7 | Clear | Clear, start | `7F 86 24` or `C6 05 00 ..` with no events (per spec) |
| 8 | Report | `86 04 02` with 0, 1, n events | Count and definitions match |
| 9 | storeEvent | Set-up with bit 6, `11 01`, report | Definition kept [unverified rule]; doNotStore lost |
| 10 | Session matrix | Set-up in default / extended / programming | Per OEM; `7F 86 7F` where not allowed |
| 11 | Session drop | Active ROE, let S3 expire | Event logic stops [unverified] |
| 12 | Security / authentication | Set-up locked / unlocked | Per OEM; `7F 86 33` / `34` if protected |
| 13 | Length min-1 | `86` | `7F 86 13` |
| 14 | Record length | eventTypeRecord one byte short / long for each type | `7F 86 13` |
| 15 | Length max | Longest supported serviceToRespondToRecord | Accepted |
| 16 | Unsupported stored service | serviceToRespondToRecord `2E ..` | `7F 86 31` [unverified] |
| 17 | SPRMIB | `86 81 ..` set-up, `86 85 02` start | No `C6`; events still sent |
| 18 | SPRMIB + NRC | `86 8A 02` | `7F 86 12` still sent |
| 19 | Functional | Set-up sent functionally | Usually not supported; unsupported nodes silent |
| 20 | Event during request | Event fires while a `22 ..` is pending | Both responses arrive; tester matches correctly |
| 21 | Multi-frame event | Stored service with long response | Event response segmented correctly; tester sends Flow Control |
| 22 | DTC setting off | `85 02`, inject fault | No event; `85 01` → event |
| 23 | Edition check | `86 02 ..` (onTimerInterrupt) on a 2020 ECU; `86 08 ..` / `86 09 ..` on a 2013 ECU | `7F 86 12` |
| 24 | 2020 DTC events | `86 08 02 <reportType>` / `86 09 02 <mask> <reportType> ..`, start, inject fault | 0x19 response of that reportType per event [unverified] |

Response pending (0x78) is not normally used by ROE set-up or control requests.

<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.9 (functional unit: diagnostic and communication management) |
| Edition differences | 2013 → 2020: 0x02 removed, 0x08 / 0x09 added, eventWindowTime values 0x03–0x08 named (py-uds) [edition-dependent]. Whether 2020 also shortened control requests is not supported by py-uds [unverified]. 2026: corrections to ROE (secondary source), not yet reviewed |
| OEM / ECU-specific | Whether ROE exists at all; supported event types; number of event slots; window time values; storeEvent persistence; session rules; allowed stored services |
| Verification status | draft (kept: one open-source stack only, 2026 corrections unreviewed). Cross-checked: SID, response SID, clause 10.9; 2013 and 2020 eventType lists, storageState bit, eventWindowTime values, eventTypeRecord contents and sizes, request and response field order (py-uds translator source and test vectors, reviewer 2026-10-26). Not cross-checked: session/reset rules, storeEvent persistence, end-of-window response, NRC choices |
| Open questions | Whether ISO 2020 really keeps eventWindowTime on control requests and on reportActivatedEvents (py-uds does); final response at end of a finite window; exact event response for 0x08 / 0x09; 2026 corrections |

<!-- catalogue field 15 -->
