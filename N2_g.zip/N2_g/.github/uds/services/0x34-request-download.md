---
sid: 0x34
name: RequestDownload
response_sid: 0x74
has_sub_function: false
functional_unit: "upload/download"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "15.2 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) - clause number and functional unit only"
  - "python-udsoncan RequestDownload implementation (github.com/pylessard/python-udsoncan, read 2026-10-26) - field order compared, not normative"
  - "py-uds source (github.com/mdabrowski1990/uds, service_definitions/request_download.py, data_record_definitions/other.py): request DFI + ALFID + address/size; response LFID (high nibble = byte count, low nibble reserved) + maxNumberOfBlockLength (reviewer, 2026-10-26)"
  - "damodev.csdn.net/6a435957662f9a54cb866add.html (Chinese walkthrough of the ISO message-flow example): maxNumberOfBlockLength 0x0081 = SID + blockSequenceCounter + 127 data bytes, for download and upload - secondary (reviewer, 2026-10-26)"
---

# 0x34 — RequestDownload

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x74
> Opens a download (tester → ECU) of a memory range and tells the tester how large each TransferData block may be.

Related entries in this functional unit: [0x35 RequestUpload](0x35-request-upload.md) ·
[0x36 TransferData](0x36-transfer-data.md) · [0x37 RequestTransferExit](0x37-request-transfer-exit.md) ·
[0x38 RequestFileTransfer](0x38-request-file-transfer.md)

## 1. What is it?

RequestDownload (SID 0x34) is the first step of a data transfer from the tester (client) to the ECU (server).
The tester states **where** the data goes (memoryAddress), **how much** will come (memorySize) and **how it
is encoded** (dataFormatIdentifier: compression and encryption method). The ECU checks the request, prepares
its memory driver and answers with **maxNumberOfBlockLength**: the largest TransferData request it will
accept. The data itself is not in this message; it follows in [0x36 TransferData](0x36-transfer-data.md)
blocks, and the transfer is closed with [0x37 RequestTransferExit](0x37-request-transfer-exit.md).

It is the core of ECU reprogramming (flashing): application software, calibration data, and sometimes
configuration blocks.
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

- A software image is far larger than one diagnostic message. The ECU needs to know the target range and
  total size **before** the first byte arrives, so it can check the range is programmable, erased and
  allowed, and set up its flash driver.
- The ECU, not the tester, knows its buffer size. maxNumberOfBlockLength lets each ECU set the block size
  that fits its RAM buffer and flash page handling.
- It creates a defined transfer state. TransferData outside that state is rejected (0x24), which protects
  memory from stray writes.
- [0x3D WriteMemoryByAddress](0x3D-write-memory-by-address.md) has no block counter, no size announcement
  and no exit step; it does not scale to megabytes and gives no integrity hook.

Who benefits: production line (EOL flashing), workshop (software updates), validation teams (reflashing
samples and HIL benches), bootloader developers (robustness testing of the download state machine).
<!-- catalogue field 3 -->

## 3. What is its purpose?

It **opens** the download state for one memory range and **negotiates** the block length. It does not
write data, erase memory, check signatures or activate the new software. Erasing is normally a separate
[0x31 RoutineControl](0x31-routine-control.md) routine; integrity and compatibility checks come after
[0x37](0x37-request-transfer-exit.md).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Write a few bytes at a known address (RAM patch, test variable) | [0x3D WriteMemoryByAddress](0x3D-write-memory-by-address.md) | Single message, no transfer state |
| Write a coding/configuration value | [0x2E WriteDataByIdentifier](0x2E-write-data-by-identifier.md) | Identifier-based; memory map stays hidden |
| Read memory out of the ECU | [0x35 RequestUpload](0x35-request-upload.md) or [0x23 ReadMemoryByAddress](0x23-read-memory-by-address.md) | Opposite direction |
| ECU has a file system (infotainment, gateway, HPC) | [0x38 RequestFileTransfer](0x38-request-file-transfer.md) | Path-based instead of address-based |
| Erase flash | [0x31 RoutineControl](0x31-routine-control.md), RID 0xFF00 eraseMemory [unverified] | 0x34 does not erase (unless the OEM bootloader does it implicitly) |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: End-of-line flashing of application software
- **Scenario:** ECU assembled with bootloader only; the EOL station flashes application and calibration.
- **Engineer's objective:** Program each logical block reliably within the station cycle time.
- **Why this service:** Standard way to open a block download that every UDS bootloader supports.
- **Tester sends:** `34 00 44 <address> <size>` once per logical block, after session 02, security and erase.
- **ECU is expected to:** Accept the range and return a block length that fits its buffer.
- **Engineer obtains:** maxNumberOfBlockLength, used to size every following 0x36 block.
- **Test on success / failure:** Success = 0x74 then all blocks accepted. Failure = 0x31 (range/format),
  0x70 (not erased or refused), 0x33 (security), 0x22 (preconditions) — the station logs the NRC and retries
  or rejects the part.

### Use case: Reflashing a restraint control module on a HIL bench
- **Scenario:** A new airbag ECU software drop must be loaded on a HIL bench before a test campaign. The
  squib loops are on the HIL's resistive loads, not real igniters.
- **Engineer's objective:** Flash reproducibly, and prove the bootloader rejects downloads when preconditions
  are not met.
- **Why this service:** Same path the production tester uses; it exercises the real bootloader.
- **Tester sends:** The generic sequence in section 5; plus negative cases (vehicle speed signal > 0 on the
  HIL, supply 9 V, security not unlocked).
- **ECU is expected to:** Accept only in programming session with security unlocked and valid
  preconditions. Some restraint ECUs refuse reprogramming after a stored deployment event [OEM-specific].
- **Engineer obtains:** A flashed ECU plus evidence of the refusal NRCs (0x22 or 0x88/0x93, 0x33, 0x7F).
- **Test on success / failure:** After reset, 0x22 0xF188 / 0xF195 shows the new software number; no
  deployment-related DTCs are set by the flash itself.

### Use case: Bootloader robustness — interrupted download
- **Scenario:** Validation of a new bootloader release.
- **Engineer's objective:** Show the ECU stays recoverable if power is lost mid-download.
- **Why this service:** Every recovery test starts by opening a new download after the failure.
- **Tester sends:** Full sequence, cuts power after block N, power up, repeats from session 02.
- **ECU is expected to:** Start in the bootloader (application marked invalid) and accept a fresh 0x34.
- **Engineer obtains:** Proof that no partial image is ever executed.
- **Test on success / failure:** Dependency check ([0x31](0x31-routine-control.md) RID 0xFF01) fails before
  the reflash and passes after it.
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. Tester sends `34 DFI ALFID memoryAddress memorySize`.
2. ECU checks, in roughly this order (exact order: [NRC evaluation order](../protocol-fundamentals.md#nrc-evaluation-order)
   and the edition in use): session, security/authentication, length vs ALFID, ALFID and DFI supported,
   address/size inside a downloadable area, preconditions, memory state.
3. On success the ECU enters the download state for that range, resets its expected block counter to 0x01
   and replies `74 LFID maxNumberOfBlockLength`.
4. Tester sends [0x36](0x36-transfer-data.md) blocks, then [0x37](0x37-request-transfer-exit.md).
5. For several logical blocks, the tester repeats erase → 0x34 → 0x36… → 0x37 per block.

**Typical flashing sequence (generic, not any OEM's bootloader spec):**

| Step | Service | Purpose |
|---|---|---|
| 1 | [0x10](0x10-diagnostic-session-control.md) 03 | Extended session for pre-programming checks (optional) |
| 2 | [0x85](0x85-control-dtc-setting.md) 82 / [0x28](0x28-communication-control.md) 83 01 | Stop DTC storage and normal communication, usually functional with SPRMIB (optional) |
| 3 | [0x10](0x10-diagnostic-session-control.md) 02 | Programming session (often a jump into the bootloader) |
| 4 | [0x27](0x27-security-access.md) or [0x29](0x29-authentication.md) | Unlock the programming security level |
| 5 | [0x2E](0x2E-write-data-by-identifier.md) | Write tester fingerprint (OEM-specific DID; skip if not required) |
| 6 | [0x31](0x31-routine-control.md) 01 FF00 | Erase the target range (RID 0xFF00 [unverified]; parameters OEM-specific) |
| 7 | **0x34** | Open download for the range |
| 8 | [0x36](0x36-transfer-data.md) × n | Transfer blocks |
| 9 | [0x37](0x37-request-transfer-exit.md) | Close transfer (optional checksum) |
| 10 | [0x31](0x31-routine-control.md) 01 FF01 | Check programming dependencies (RID 0xFF01 [unverified]) |
| 11 | [0x11](0x11-ecu-reset.md) 01 | Reset; ECU starts the new application |

OEM flash specs add steps (signature check routine, per-block CRC routine, pre-condition routine). Take them
from the project's bootloader specification.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | programmingSession (0x02); some ECUs allow calibration download in extended | OEM |
| Security / authentication | Programming security level unlocked (0x27) or authenticated role (0x29, 2020) | OEM level; mechanism standard |
| ECU operating conditions | Vehicle stationary, engine off, supply in programming range, target range erased | OEM |
| Timing (P2 / P2* / S3) | Normally answered within P2; ECUs that erase on 0x34 send 0x78 and need P2*. TesterPresent keeps S3 alive | Standard timing, OEM values |

**Depends on:** 0x10, 0x27/0x29, 0x31 (erase), then 0x36 and 0x37. Transport: an ALFID 0x44 request is 11
bytes, so it is **multi-frame on classic CAN** (single frame carries 7). See
[ISO-TP essentials](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials).
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x34 |
| 2 | dataFormatIdentifier (DFI) | 1 | Bits 7–4 compressionMethod, bits 3–0 encryptingMethod. 0x00 = neither. Other values OEM-specific |
| 3 | addressAndLengthFormatIdentifier (ALFID) | 1 | Bits 7–4 = byte count of memorySize, bits 3–0 = byte count of memoryAddress. 0 in either nibble is invalid |
| 4 … 3+a | memoryAddress | a (low nibble) | Big-endian. Physical start address, or a logical block number in some bootloaders [OEM-specific] |
| … | memorySize | s (high nibble) | Big-endian. Number of bytes to download. With compression, the widely quoted ISO definition is the **uncompressed** size, which the server compares with the data it received [unverified]; some OEM bootloaders use the compressed size instead [OEM-specific]. Check the bootloader spec |

Request length = 3 + a + s. Common ALFIDs: 0x44 (4-byte address, 4-byte size), 0x24, 0x33.

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the DFI; bit 7 set means
compression method 8–F, not "suppress response".

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x74 |
| 2 | lengthFormatIdentifier (LFID) | 1 | Bits 7–4 = byte count of maxNumberOfBlockLength; bits 3–0 reserved (0) |
| 3 … | maxNumberOfBlockLength | k (high nibble) | Big-endian. Largest TransferData **request** the ECU accepts, counting the SID byte and the blockSequenceCounter byte as well as the data. Data per block = value − 2. Supported by a secondary reproduction of the ISO message-flow example (0x0081 = SID + counter + 127 data bytes); ISO text not checked here |

Pitfall: some tools and ECUs treat the value as data bytes only. If blocks of exactly the announced size are
rejected with 0x13 or 0x31, check this first.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length does not equal 3 + a + s for the ALFID sent |
| 0x22 | conditionsNotCorrect | OEM preconditions fail (speed, ignition, voltage); also commonly a 0x34 while a transfer is already active [unverified] |
| 0x31 | requestOutOfRange | DFI not supported, ALFID invalid or unsupported, address or size outside a downloadable area |
| 0x33 | securityAccessDenied | Programming security level not unlocked |
| 0x34 | authenticationRequired | ECU uses 0x29 and the tester has no suitable role [edition-dependent, 2020] |
| 0x70 | uploadDownloadNotAccepted | Range valid, but the ECU refuses for another reason: not erased, memory fault, programming attempt limit reached [OEM-specific] |
| 0x78 | requestCorrectlyReceived-ResponsePending | ECU needs longer than P2 (e.g. erases on 0x34) [OEM-specific] |
| 0x7F | serviceNotSupportedInActiveSession | Not in programming session (or other allowed session) |
| 0x88 / 0x92 / 0x93 | vehicleSpeedTooHigh / voltageTooHigh / voltageTooLow | Specific precondition codes some ECUs use instead of 0x22 |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. The address, size and block length below are the shared
example used in [0x36](0x36-transfer-data.md#examples) and [0x37](0x37-request-transfer-exit.md#examples):
memoryAddress 0x00080000, memorySize 0x00040000 (256 KiB), maxNumberOfBlockLength 0x0402 (all illustrative).

**Example 1 — open the download:**

```uds
REQ 34 00 44 00 08 00 00 00 04 00 00   # no compression/encryption, 4-byte address, 4-byte size
POS 74 20 04 02                        # 2-byte maxNumberOfBlockLength = 0x0402 (illustrative)
```

| Bytes | Field | Decoded |
|---|---|---|
| 34 | SID | RequestDownload |
| 00 | DFI | compressionMethod 0, encryptingMethod 0 |
| 44 | ALFID | memorySize 4 bytes, memoryAddress 4 bytes |
| 00 08 00 00 | memoryAddress | 0x00080000 (illustrative) |
| 00 04 00 00 | memorySize | 0x00040000 = 262 144 bytes (illustrative) |
| 74 | Response SID | 0x34 + 0x40 |
| 20 | LFID | maxNumberOfBlockLength is 2 bytes |
| 04 02 | maxNumberOfBlockLength | 1026 → 1024 data bytes per 0x36 block → 256 blocks |

**Example 2 — complete generic flashing sequence (all values illustrative):**

```uds
REQ 10 03                                    # 1 extended session
POS 50 03 00 32 01 F4
REQ 85 82                                    # 2 DTC setting off, SPRMIB set, usually functional
REQ 28 83 01                                 # 2 disableRxAndTx, normal communication, SPRMIB set
REQ 10 02                                    # 3 programming session
POS 50 02 00 32 01 F4
REQ 27 11                                    # 4 requestSeed, programming level (illustrative)
POS 67 11 XX XX XX XX                        #   seed
REQ 27 12 YY YY YY YY                        #   sendKey
POS 67 12
NOTE 5 fingerprint write (0x2E, OEM-specific DID) skipped in this example
REQ 31 01 FF 00 44 00 08 00 00 00 04 00 00   # 6 eraseMemory for the target range
NEG 7F 31 78                                 #   erase running
POS 71 01 FF 00 00                           #   erase done (status byte illustrative)
REQ 34 00 44 00 08 00 00 00 04 00 00         # 7 RequestDownload
POS 74 20 04 02
REQ 36 01 ..                                 # 8 block 1, 1024 data bytes
POS 76 01
NOTE blocks 02 … FF, then the counter wraps to 00 for block 256
REQ 36 00 ..                                 #   block 256 (last)
POS 76 00
REQ 37                                       # 9 RequestTransferExit
POS 77
REQ 31 01 FF 01                              # 10 checkProgrammingDependencies
POS 71 01 FF 01 00                           #   result (illustrative)
REQ 11 01                                    # 11 hardReset
POS 51 01
```

| Step | Bytes | Decoded |
|---|---|---|
| 1 | 10 03 / 50 03 00 32 01 F4 | Extended session; P2 = 50 ms, P2* = 5000 ms (illustrative) |
| 2 | 85 82 | ControlDTCSetting off (0x02) with SPRMIB → no response |
| 2 | 28 83 01 | CommunicationControl disableRxAndTx (0x03) with SPRMIB, communicationType 0x01 normal |
| 3 | 10 02 / 50 02 … | Programming session |
| 4 | 27 11 / 67 11 XX… / 27 12 YY… / 67 12 | Seed and key at level 0x11 (illustrative; level is OEM-defined) |
| 6 | 31 01 FF 00 44 … | startRoutine eraseMemory; option record ALFID + address + size (layout OEM-specific) |
| 6 | 7F 31 78 / 71 01 FF 00 00 | Pending, then routine finished |
| 7 | 34 … / 74 20 04 02 | See example 1 |
| 8 | 36 01 … 36 00 | 256 blocks, counter 01…FF then 00; see [0x36](0x36-transfer-data.md) |
| 9 | 37 / 77 | Transfer closed; see [0x37](0x37-request-transfer-exit.md) |
| 10 | 31 01 FF 01 / 71 01 FF 01 00 | Dependency check; result byte meaning OEM-specific |
| 11 | 11 01 / 51 01 | hardReset; new application starts |

**Example 3 — refusals:**

```uds
REQ 34 11 44 00 08 00 00 00 04 00 00   # compression 1 + encryption 1, not supported by this ECU
NEG 7F 34 31
REQ 34 00 44 00 08 00 00 00 04 00      # one size byte missing
NEG 7F 34 13
REQ 34 00 44 00 08 00 00 00 04 00 00   # range not erased (behaviour OEM-specific)
NEG 7F 34 70
```

| Bytes | Decoded |
|---|---|
| 34 11 … / 7F 34 31 | DFI 0x11 unsupported → requestOutOfRange |
| 34 00 44 + 7 bytes / 7F 34 13 | ALFID 0x44 needs 8 bytes after it; 7 sent → wrong length |
| 34 00 44 … / 7F 34 70 | Erase step skipped; this ECU refuses with uploadDownloadNotAccepted (some return 0x22) |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**
- Builder inputs: DFI (default 0x00), address, size, ALFID (derive the smallest width or take it from the
  OEM spec — many bootloaders accept only one ALFID). Reject address/size values that do not fit the chosen
  widths; reject nibble 0.
- Parser: LFID high nibble = k; check response length = 2 + k; reject k = 0. Libraries often cap k at 8.
- Block size: data per block = min(maxNumberOfBlockLength, tester transport limit) − 2. Never send more than
  the ECU announced. Some bootloaders require every block except the last to be full size [OEM-specific].
- State: store address, size and block length per transfer; reset the counter to 0x01; clear state on
  0x37, session change, reset or any NRC from 0x36 that aborts the transfer.
- Timeouts: handle 0x78 (P2*) on 0x34; keep TesterPresent running if the tester pauses between blocks.
- Logging: log the raw 0x74 bytes; block-size bugs are the most common flashing failure.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path | Full sequence, example 2 | 0x74 with valid LFID; all blocks accepted; new SW after reset |
| 2 | Length min-1 | ALFID 0x44, 10 bytes | 7F 34 13 |
| 3 | Length min = max | ALFID 0x44, 11 bytes | 0x74 |
| 4 | Length max+1 | ALFID 0x44, 12 bytes | 7F 34 13 |
| 5 | Invalid ALFID | 0x00, 0x40, 0x04 | 7F 34 31 (some ECUs 0x13) [unverified] |
| 6 | Unsupported ALFID | e.g. 0x33 when only 0x44 is supported | 7F 34 31 |
| 7 | Unsupported DFI | 0x11, 0x80 | 7F 34 31 |
| 8 | Address out of range | Start outside any downloadable block | 7F 34 31 |
| 9 | Size out of range | Start valid, end beyond block | 7F 34 31 |
| 10 | Not erased | Skip erase routine | 7F 34 70 or 0x22 [OEM-specific] |
| 11 | Security matrix | Locked / unlocked / re-locked after session change | 0x33 / 0x74 / 0x33 |
| 12 | Authentication (2020 ECU) | No role / programming role | 0x34 / 0x74 |
| 13 | Session matrix | Default / extended / programming | 0x7F / 0x7F or OEM / 0x74 |
| 14 | Preconditions | Speed > 0, voltage low/high, ignition state | 0x22 or 0x88/0x93/0x92 |
| 15 | Second 0x34 during active transfer | 0x34 after block 10 | 0x22 or abort-and-accept [OEM-specific] |
| 16 | Next logical block | 0x34 after a completed 0x37 | 0x74 |
| 17 | Session change during transfer | 10 01 after block 10, then 0x36 | Transfer aborted; 0x36 → 0x7F or 0x24 |
| 18 | Functional addressing | 0x34 on the functional ID | No response (not supported functionally) [OEM-specific] |
| 19 | SPRMIB not applicable | DFI 0x80 | Response always sent (0x31 if unsupported); never silent |
| 20 | Response pending | ECU that erases on 0x34 | 0x78 within P2, final within P2* |
| 21 | Multi-frame | 11-byte request on classic CAN | FF/FC/CF handled; STmin respected |
| 22 | Power loss mid-download | Cut supply after block N | ECU in bootloader, accepts fresh sequence |
| 23 | Block length honoured | Send blocks of maxNumberOfBlockLength and +1 | Accepted / rejected (see [0x36](0x36-transfer-data.md)) |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 15.2 (upload/download functional unit, clause 15), from the preview TOC |
| Edition differences | No structural change between 2013 and 2020 known to the author [unverified]. 2020 adds Authentication (0x29), so NRC 0x34 can apply [edition-dependent]. ISO 14229-1:2026 not yet reviewed |
| OEM / ECU-specific | Supported DFI and ALFID values; meaning of memoryAddress (physical vs logical block); compressed vs uncompressed memorySize; implicit erase; allowed sessions; security level; block length; preconditions; full flash sequence (fingerprint, signature, CRC routines) |
| Verification status | draft. Clause number cross-checked (ISO 14229-1:2020 preview TOC). Request/response field order and LFID nibble layout compared with python-udsoncan and py-uds source (open-source, not normative). Reviewer 2026-10-26: "maxNumberOfBlockLength includes SID and counter" supported by a secondary source (damodev.csdn.net). Shared example (0x00080000 / 0x00040000 / 0x0402 → 256 × 1024 bytes) checked for consistency with 0x31, 0x36 and 0x37. Not checked against the ISO text |
| Open questions | Confirm in the ISO text that maxNumberOfBlockLength counts SID and counter, and the memorySize definition for compressed data; confirm the 2020 NRC list and its order for 15.2; confirm whether a 0x34 during an active transfer is 0x22 or 0x70 |
<!-- catalogue field 15 -->
