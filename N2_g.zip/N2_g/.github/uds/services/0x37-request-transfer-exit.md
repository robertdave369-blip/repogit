---
sid: 0x37
name: RequestTransferExit
response_sid: 0x77
has_sub_function: false
functional_unit: "upload/download"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "15.5 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) - clause number and functional unit only"
  - "python-udsoncan RequestTransferExit implementation (github.com/pylessard/python-udsoncan, read 2026-10-26) - optional parameter records and NRC list compared, not normative"
---

# 0x37 — RequestTransferExit

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x77
> Closes the active download or upload; optionally exchanges a checksum or status record.

Related entries in this functional unit: [0x34 RequestDownload](0x34-request-download.md) ·
[0x35 RequestUpload](0x35-request-upload.md) · [0x36 TransferData](0x36-transfer-data.md) ·
[0x38 RequestFileTransfer](0x38-request-file-transfer.md)

## 1. What is it?

RequestTransferExit (SID 0x37) ends the transfer that was opened with
[0x34 RequestDownload](0x34-request-download.md), [0x35 RequestUpload](0x35-request-upload.md) or
[0x38 RequestFileTransfer](0x38-request-file-transfer.md) and fed with
[0x36 TransferData](0x36-transfer-data.md). After a positive response the ECU has left the transfer state:
it has flushed any buffered data to memory and no further 0x36 is accepted.

Both request and response may carry an optional parameter record whose content the standard leaves to the
manufacturer. Typical uses: a checksum or CRC of the transferred data from the tester, or a checksum/status
from the ECU [OEM-specific].
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

- The ECU cannot always tell when the last block has arrived (compressed data, a tester that stopped early).
  An explicit exit tells it to flush buffers and finalise the write.
- It is a clean point to report problems found only at the end: final flash write, length mismatch,
  optional checksum mismatch.
- It releases the transfer state so the next logical block can be opened with a new 0x34.

Who benefits: bootloader developers (defined end of transfer), flash tools (a single place to check the
result per block), validation (a clear checkpoint in traces).
<!-- catalogue field 3 -->

## 3. What is its purpose?

It closes the transfer and, optionally, carries an integrity record. It does **not** replace the
signature/CRC/dependency check routines that most flash processes run afterwards via
[0x31 RoutineControl](0x31-routine-control.md), and it does not activate the new software (the ECU reset
does that).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Verify signature or CRC of the whole image | [0x31](0x31-routine-control.md) check routine (OEM RID) | Standard flow keeps verification separate and returns a detailed result |
| Check that all blocks are consistent | [0x31](0x31-routine-control.md) RID 0xFF01 checkProgrammingDependencies [unverified] | Cross-block check |
| Abort a transfer after an error | Session change or [0x11 ECUReset](0x11-ecu-reset.md), then restart | 0x37 is meant for a completed transfer; some ECUs reject it after an aborted one |
| Activate the new software | [0x11 ECUReset](0x11-ecu-reset.md) | 0x37 does not start the application |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: End of each logical block during flashing
- **Scenario:** The 256 KiB block from the shared example has been transferred.
- **Engineer's objective:** Confirm the ECU has stored everything before the next block or the dependency
  check.
- **Why this service:** Mandatory close of the transfer state.
- **Tester sends:** `37` (or `37 <CRC>` if the OEM flow requires it).
- **ECU is expected to:** Flush the last data, close the transfer, answer `77` (possibly with a record).
- **Engineer obtains:** Positive response; transfer state cleared.
- **Test on success / failure:** Success = 0x77 and a following 0x34 for the next block is accepted.
  Failure = 0x72 (final write or OEM check failed), 0x24 (no transfer active), 0x13 (record length wrong).

### Use case: Integrity check at the end of an airbag ECU calibration download
- **Scenario:** A restraint control module bootloader requires the tester to send a CRC of the calibration
  data with 0x37 [OEM-specific]. Validation must prove a corrupted download is caught before the ECU leaves
  the bootloader.
- **Engineer's objective:** Show the ECU rejects a mismatching CRC and does not mark the block valid.
- **Why this service:** In this OEM flow, 0x37 is where the CRC is compared.
- **Tester sends:** Normal download, then `37 <wrong CRC>`; then a clean run with the right CRC.
- **ECU is expected to:** Return 0x72 (or the OEM's specified NRC) for the wrong CRC; 0x77 for the right one.
- **Engineer obtains:** Evidence that a corrupted calibration cannot become active; the dependency check fails
  after the bad run.
- **Test on success / failure:** After the bad run and reset, the ECU stays in the bootloader (or keeps the
  old calibration) and reports the expected DTC/status [OEM-specific].
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. Tester sends `37 [transferRequestParameterRecord]` after the last 0x36 positive response.
2. ECU checks a transfer is active, the record length, and (if defined) whether all announced bytes arrived.
3. ECU writes remaining buffered data and runs any OEM end-of-transfer check. This can take longer than P2,
   so 0x78 is common.
4. Positive response `77 [transferResponseParameterRecord]`; the transfer state is closed whatever the
   tester does next.
5. On a negative response, whether the transfer state is closed or still open is OEM-specific; most flash
   tools restart the logical block from erase [unverified].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Same session as the transfer | OEM |
| Security / authentication | Inherited from the open step | OEM |
| ECU operating conditions | Transfer active; supply within programming limits | Standard (transfer) / OEM (voltage) |
| Timing (P2 / P2* / S3) | 0x78 then P2* while flushing or checking | Standard timing, OEM values |

**Depends on:** a positive 0x74 / 0x75 / 0x78 and the 0x36 blocks. What comes next in a flash sequence is
described in [0x34 section 5](0x34-request-download.md#5-how-does-it-work).
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x37 |
| 2 … | transferRequestParameterRecord | 0 … n | Optional. Content and length OEM-specific (e.g. 4-byte CRC32 of the transferred data) |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. If a record is sent, its first byte is
data, not a sub-function.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x77 |
| 2 … | transferResponseParameterRecord | 0 … n | Optional. OEM-specific (e.g. ECU-calculated checksum, status). Empty in most bootloaders |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Record length differs from what the ECU expects |
| 0x24 | requestSequenceError | No transfer is active (never opened, already closed, or aborted by an earlier error); some ECUs also when not all announced bytes have been transferred [unverified] |
| 0x31 | requestOutOfRange | Record content invalid [unverified] |
| 0x72 | generalProgrammingFailure | Final write or OEM end-of-transfer verification failed (e.g. checksum mismatch) [OEM-specific] |
| 0x78 | requestCorrectlyReceived-ResponsePending | Flushing or checking takes longer than P2 |
| 0x7F | serviceNotSupportedInActiveSession | Session changed; transfer gone |
| 0x92 / 0x93 | voltageTooHigh / voltageTooLow | Supply outside programming limits during the final write [OEM-specific] |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Shared download example with
[0x34](0x34-request-download.md#examples) and [0x36](0x36-transfer-data.md#examples): memoryAddress
0x00080000, memorySize 0x00040000, maxNumberOfBlockLength 0x0402, 256 blocks (all illustrative).

**Example 1 — close the shared download, no record:**

```uds
REQ 34 00 44 00 08 00 00 00 04 00 00   # open (see 0x34)
POS 74 20 04 02
NOTE 256 × TransferData, counters 01 … FF, 00 (see 0x36)
REQ 36 00 ..                           # last block
POS 76 00
REQ 37                                 # exit, no parameter record
NEG 7F 37 78                           # flushing the last page
POS 77                                 # transfer closed
```

| Bytes | Field | Decoded |
|---|---|---|
| 37 | SID | RequestTransferExit, no record |
| 7F 37 78 | NEG | Response pending; tester switches to P2* |
| 77 | Response SID | Transfer closed, no response record |

**Example 2 — OEM flow with a CRC record (CRC values illustrative):**

```uds
REQ 37 1A 2B 3C 4D        # tester sends CRC32 of the 256 KiB block (illustrative, OEM-specific)
POS 77 1A 2B 3C 4D        # ECU echoes its own CRC (illustrative, OEM-specific)
```

| Bytes | Field | Decoded |
|---|---|---|
| 1A 2B 3C 4D | transferRequestParameterRecord | Tester's CRC (OEM-defined algorithm and byte order) |
| 77 1A 2B 3C 4D | Response | ECU's CRC matches; transfer closed |

**Example 3 — failures:**

```uds
REQ 37                    # no transfer active (0x34 never sent, or second 0x37)
NEG 7F 37 24
REQ 37 00 00 00 00        # wrong CRC in an OEM flow that checks it
NEG 7F 37 72
REQ 37 1A 2B              # record too short for an ECU expecting 4 bytes
NEG 7F 37 13
```

| Bytes | Decoded |
|---|---|
| 7F 37 24 | requestSequenceError — nothing to close |
| 7F 37 72 | generalProgrammingFailure — verification failed [OEM-specific] |
| 7F 37 13 | Wrong record length |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**
- Builder: optional record bytes (default empty). Algorithm, byte order and coverage of any CRC come from the
  OEM spec; never guess.
- Parser: record = response[1:]; compare with the expected value only if the OEM flow defines it.
- Sequencing: send only after the last 0x36 positive response; send exactly once per transfer; clear tester
  transfer state on a positive response.
- Error handling: on 0x72, treat the logical block as invalid and restart from erase; on 0x24, check whether
  an earlier NRC or a session change aborted the transfer.
- Timing: allow 0x78 and P2*; the final flash flush can take hundreds of ms.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path | Shared example then `37` | 0x77; next 0x34 accepted |
| 2 | No transfer active | `37` without 0x34/0x35 | 0x24 |
| 3 | Double exit | Second `37` | 0x24 |
| 4 | Incomplete transfer | `37` after block 100 of 256 | 0x24, 0x72 or accept [OEM-specific] |
| 5 | Record min-1 / min / max+1 | OEM record length −1 / exact / +1 | 0x13 / 0x77 / 0x13 |
| 6 | Record on ECU without record | `37 00` | 0x13 or accepted [OEM-specific] |
| 7 | Wrong checksum | OEM flow with CRC, corrupted value | 0x72 (or OEM NRC); block not marked valid |
| 8 | 0x36 after exit | `36 01` after 0x77 | 0x24 |
| 9 | Session matrix | Session change before 0x37 | 0x7F or 0x24 |
| 10 | Security matrix | Re-lock before 0x37 (session change) | Transfer aborted; 0x24/0x7F |
| 11 | Functional addressing | `37` functional | No response [OEM-specific] |
| 12 | Response pending | Large last page | 0x78 then 0x77 within P2* |
| 13 | Voltage | Low supply during final write | 0x93 [OEM-specific] |
| 14 | Upload close | 0x35 flow then `37` | 0x77 |
| 15 | Multi-frame | Record longer than 7 bytes on classic CAN | Handled by ISO-TP |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 15.5 (upload/download functional unit), from the preview TOC |
| Edition differences | No change between 2013 and 2020 known to the author [unverified]. 2026 not yet reviewed |
| OEM / ECU-specific | Content and length of both parameter records; checksum algorithm; NRC for a failed check; behaviour after a partial transfer; whether the transfer stays open after an NRC |
| Verification status | draft. Clause number cross-checked (preview TOC). Optional request/response records and NRC set compared with python-udsoncan (not normative). Not checked against the ISO text |
| Open questions | Which NRC the standard specifies for a failed end-of-transfer check (0x72 assumed); whether 0x24 or 0x31 for an incomplete transfer; 0x31 is in python-udsoncan's list for this service, but its trigger condition is not confirmed |
<!-- catalogue field 15 -->
