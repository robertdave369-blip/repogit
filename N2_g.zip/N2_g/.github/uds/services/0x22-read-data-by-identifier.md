---
sid: 0x22
name: ReadDataByIdentifier
response_sid: 0x62
has_sub_function: false
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.2 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number and functional unit"
  - "ISO 14229-1:2020/Amd 1:2022 preview (sample 81380): name of DID 0xFF01 TransportLayerSegmentationSupport"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x22, response SID 0x62"
  - "ISO 14229-1:2020 preview TOC (webstore.ansi.org preview): Annex C = data-parameter definitions for the data transmission functional unit (reviewer, 2026-10-26)"
  - "py-uds source (github.com/mdabrowski1990/uds, uds/utilities/constants/did.py): ISO names mapped for 0xF180-0xF19F; 0xF18F only in the 2020 mapping (reviewer, 2026-10-26)"
---

# 0x22 — ReadDataByIdentifier

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x62
> Reads the current value of one or more data records, each addressed by a 2-byte data identifier (DID).

## 1. What is it?

ReadDataByIdentifier (RDBI), SID 0x22, is the general read service of UDS. The tester sends one or more
16-bit data identifiers (DIDs). The ECU answers with the data record behind each DID, in one response.

A DID can stand for any value the ECU chooses to expose: identification strings (VIN, part numbers,
software versions), live measurements (supply voltage, a sensor value, a squib loop resistance), internal
status, configuration or coding records, counters.

The message carries no sub-function and no length fields. The length and layout of each DID's record are
fixed by the ECU's diagnostic specification (ODX/CDD or an OEM DID list). Tester and ECU must agree on them.

## 2. Why is it needed?

- One uniform way to read any exposed value without knowing memory addresses. 0x23 ReadMemoryByAddress is
  address-based, changes with every software build and is usually locked.
- DIDs stay stable across software releases even when the variables behind them move in memory.
- ISO-defined identification DIDs give every tester a common way to ask "which ECU, which software, which
  hardware" before it knows anything else about the ECU.
- Several DIDs per request cut round trips when a tester needs a consistent snapshot of several values.

Who benefits: production lines (VIN and part number checks), workshop tools (identification, live data),
validation and HIL teams (state checks around each test step), developers (internal status DIDs).

## 3. What is its purpose?

It returns values and nothing else. It should not change ECU state. It does not write data, schedule periodic
transmission, or report DTCs.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Value must be changed | [0x2E WriteDataByIdentifier](0x2E-write-data-by-identifier.md) | 0x22 is read-only |
| Value is needed continuously at a fixed rate | [0x2A ReadDataByPeriodicIdentifier](0x2A-read-data-by-periodic-identifier.md) | Avoids polling load and jitter |
| Value has no DID, development only | [0x23 ReadMemoryByAddress](0x23-read-memory-by-address.md) | Address-based access, usually secured |
| Several scattered values wanted under one DID | [0x2C DynamicallyDefineDataIdentifier](0x2C-dynamically-define-data-identifier.md), then 0x22 | One short request instead of many DIDs |
| Fault memory content | 0x19 ReadDTCInformation | DTCs, status and snapshots have their own service |
| Physical meaning / scaling of a DID | ODX/CDD; rarely [0x24](0x24-read-scaling-data-by-identifier.md) | 0x22 returns raw bytes only |

### ISO-defined vs OEM-defined DIDs

| DID / range | Owner | Content |
|---|---|---|
| 0xF186 | ISO | ActiveDiagnosticSession, 1 byte (01 default, 02 programming, 03 extended) |
| 0xF187 | ISO | Vehicle manufacturer spare part number |
| 0xF188 | ISO | Vehicle manufacturer ECU software number |
| 0xF18C | ISO | ECU serial number |
| 0xF190 | ISO | VIN, 17 ASCII bytes |
| 0xF191 | ISO | Vehicle manufacturer ECU hardware number |
| 0xF195 | ISO | System supplier ECU software version |
| 0xF180–0xF19F | ISO | Identification DIDs (the ones above are part of this block). py-uds maps an ISO name to each DID in this block; 0xF18F appears only in its 2020 mapping [edition-dependent]. 0xF1A0–0xF1EF / 0xF1F0–0xF1FF are commonly cited as VM- / supplier-specific identification options [unverified] |
| 0xF200–0xF2FF | ISO | Periodic DIDs, used with 0x2A |
| 0xF300–0xF3FF | ISO | Dynamically defined DIDs, created with 0x2C |
| 0xFF00 | ISO | UDS version |
| 0xFF01 | ISO | TransportLayerSegmentationSupport (name per Amd 1:2022; py-uds lists it as reserved for ISO 15765-5 in the unamended 2020 text) |
| most of 0x0100–0xEFFF | OEM | Vehicle-manufacturer-specific, with some blocks reserved for legislated use [unverified] |

The ISO DIDs fix the meaning. The exact length and character set of most of them (except the VIN) are
still set by the OEM. Everything else, including measurements and coding records, is OEM-defined
[OEM-specific]. Examples below use `0x4711`, `0x4712`, `0x4713` as obviously illustrative OEM DIDs.

## 4. When is it used? — Real use cases

### Use case: End-of-line identification check
- **Scenario:** Production line, after flashing and coding the ECU.
- **Engineer's objective:** Confirm the ECU carries the right software, hardware and VIN before it leaves the station.
- **Why this service:** The identification DIDs are readable in the default session, without security.
- **Tester sends:** `22 F1 88 F1 91` then `22 F1 90`.
- **ECU is expected to:** Return both records in one response, then the 17-byte VIN.
- **Engineer obtains:** Software number, hardware number and VIN to compare against the build order.
- **Test on success / failure:** Pass if all match the order. Any mismatch or NRC stops the part at the station.

### Use case: HIL snapshot around fault injection on an airbag ECU
- **Scenario:** HIL bench with squib loops replaced by resistor decades; the test opens one loop.
- **Engineer's objective:** Check the ECU's measured loop resistance and loop status before and after the fault.
- **Why this service:** One request returns a consistent snapshot of several DIDs.
- **Tester sends:** `22 47 11 47 12` (0x4711 loop resistance, 0x4712 loop status, both illustrative).
- **ECU is expected to:** Return both records, values changing once the fault is injected and debounced.
- **Engineer obtains:** Raw values, scaled with the OEM DID definition.
- **Test on success / failure:** Pass if the resistance moves out of the valid window and the status flags the
  loop as faulty within the specified debounce time. Fail on a missing response, an NRC or a wrong value.

### Use case: Confirming the active session in a test framework
- **Scenario:** Python or CAPL test step after `10 03`, before writing coding data.
- **Engineer's objective:** Make sure the ECU really is in the extended session (and has not fallen back on S3 timeout).
- **Why this service:** DID 0xF186 reports the active session directly.
- **Tester sends:** `22 F1 86`.
- **ECU is expected to:** Return `62 F1 86 03`.
- **Engineer obtains:** Proof of session state, for the test log.
- **Test on success / failure:** Pass on `03`. `01` means the session was lost; check TesterPresent timing.

## 5. How does it work?

1. Tester sends `22` followed by one or more 2-byte DIDs.
2. ECU checks the message length (see below), then which DIDs it supports in the active session, then security
   and authentication, then operating conditions. NRC evaluation order in general:
   [../protocol-fundamentals.md](../protocol-fundamentals.md).
3. ECU builds one response: `62`, then for each returned DID the DID echo followed by its data record, in
   the order of the request [unverified: ordering rule].
4. If the response does not fit a single frame, the transport layer segments it (ISO-TP on CAN, DoIP on
   Ethernet). The application layer sees one message.

**Length rules.** Minimum request is 3 bytes. Request length minus 1 must be even. The ECU may limit the
number of DIDs per request; exceeding it gives NRC 0x13 [unverified]. The limit is ECU-specific.

**Partial support when several DIDs are requested [unverified]:**

| Case | Expected ECU behaviour |
|---|---|
| All DIDs supported in active session | Positive response with all records |
| Some supported, some not | Positive response with only the supported records; unsupported DIDs are left out without an error |
| None supported in active session | NRC 0x31 |
| A supported DID is secured and the ECU is locked | NRC 0x33 for the whole request (not omission); the ISO NRC condition is commonly cited as "at least one requested DID is secured" |
| Total response longer than the transport or ECU buffer allows | NRC 0x14 |

Because unsupported DIDs are dropped silently, a parser must walk the response by DID, not by position.

**Response too long.** Classic ISO-TP (12-bit length) carries at most 4095 bytes. ISO-TP with the escape
sequence (ISO 15765-2:2016) and DoIP carry more, but the ECU's own buffer is usually the real limit
[ECU-specific]. If the concatenated response exceeds what the ECU can send, it answers NRC 0x14.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | 0x22 supported in all sessions; each DID has its own session list | Service: ISO. Per-DID list: OEM |
| Security / authentication | None for identification DIDs; OEM-chosen DIDs need 0x27 or 0x29 | OEM |
| ECU operating conditions | Usually none; some measurement DIDs need, for example, ignition on | OEM |
| Timing (P2 / P2* / S3) | Answer within P2; a slow DID may send 0x78 and use P2* | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** ISO-TP flow control for multi-frame responses; 0x10 for session-restricted DIDs; 0x27/0x29
for secured DIDs; 0x2C for dynamically defined DIDs.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x22 |
| 2–3 | dataIdentifier #1 | 2 | Big-endian DID |
| 4–5 … | dataIdentifier #2 … #m | 2 each | Optional; m limited by the ECU |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the high byte of the first DID.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x62 |
| 2–3 | dataIdentifier #1 | 2 | Echo of the first returned DID |
| 4 … | dataRecord #1 | DID-defined | Raw value, no length byte |
| … | dataIdentifier #2, dataRecord #2 … | | Repeated for each further returned DID |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Fewer than 3 bytes, odd number of DID bytes, or more DIDs than the ECU accepts |
| 0x14 | responseTooLong | Concatenated response exceeds the transport or ECU buffer |
| 0x22 | conditionsNotCorrect | A DID can be read only under conditions not met now (OEM rule) |
| 0x31 | requestOutOfRange | None of the requested DIDs is supported in the active session; a requested dynamically defined DID (0xF2xx/0xF3xx) is not currently defined |
| 0x33 | securityAccessDenied | A requested DID is secured and the security level is not unlocked |
| 0x34 | authenticationRequired | 2020: DID requires authentication via 0x29 [edition-dependent] [unverified] |
| 0x78 | requestCorrectlyReceived-ResponsePending | Record takes longer than P2 to assemble |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 22 F1 86            # read active session
POS 62 F1 86 03         # extended session
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 1 | 22 | ReadDataByIdentifier |
| REQ 2–3 | F1 86 | DID ActiveDiagnosticSession |
| POS 1 | 62 | Positive response (0x22 + 0x40) |
| POS 2–3 | F1 86 | DID echo |
| POS 4 | 03 | Extended diagnostic session |

VIN read on classic CAN, showing ISO-TP segmentation. VIN, CAN IDs and padding byte are (illustrative).

```uds
REQ 22 F1 90
POS 62 F1 90 58 58 54 45 53 54 30 30 30 30 30 30 30 30 30 30 31   # VIN "XXTEST00000000001" (illustrative)
CAN 7E0  03 22 F1 90 CC CC CC CC   # tester -> ECU (ID illustrative): Single Frame, 3 bytes
CAN 7E8  10 14 62 F1 90 58 58 54   # ECU -> tester (ID illustrative): First Frame, 20 bytes total
CAN 7E0  30 00 00 CC CC CC CC CC   # tester -> ECU: Flow Control, continue, no block limit, STmin 0
CAN 7E8  21 45 53 54 30 30 30 30   # ECU -> tester: Consecutive Frame 1
CAN 7E8  22 30 30 30 30 30 30 31   # ECU -> tester: Consecutive Frame 2
```

| Frame / byte | Value | Meaning |
|---|---|---|
| SF byte 1 | 03 | PCI: single frame, 3 payload bytes |
| SF bytes 2–4 | 22 F1 90 | Request |
| FF bytes 1–2 | 10 14 | PCI: first frame, total length 0x014 = 20 bytes |
| FF bytes 3–8 | 62 F1 90 58 58 54 | Response SID, DID echo, VIN bytes 1–3 ("XXT") |
| FC bytes 1–3 | 30 00 00 | ContinueToSend, BlockSize 0, STmin 0 ms |
| CF1 byte 1 | 21 | Consecutive frame, sequence number 1 |
| CF1 bytes 2–8 | 45 53 54 30 30 30 30 | VIN bytes 4–10 ("EST0000") |
| CF2 byte 1 | 22 | Consecutive frame, sequence number 2 |
| CF2 bytes 2–8 | 30 30 30 30 30 30 31 | VIN bytes 11–17 ("0000001") |
| — | CC | Padding byte (OEM-specific value) |

Two DIDs in one request, then partial support. Software number and record contents are (illustrative).

```uds
REQ 22 F1 88 47 11      # SW number + loop resistance 0x4711 (illustrative)
POS 62 F1 88 .. 47 11 01 F4   # F188 record, then 0x4711 = 0x01F4
REQ 22 F1 90 47 13      # 0x4713 not supported in this session (illustrative)
POS 62 F1 90 ..         # only the VIN comes back [unverified]
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 2–3 | F1 88 | DID #1: VM ECU software number |
| REQ 4–5 | 47 11 | DID #2: OEM DID (illustrative) |
| POS 2–3 | F1 88 | Echo DID #1, followed by its record (`..`, length per OEM spec) |
| POS n…n+1 | 47 11 | Echo DID #2 |
| POS n+2…n+3 | 01 F4 | Raw value 500; scaling from OEM spec, e.g. 0.01 Ω/bit = 5.00 Ω (illustrative) |
| 2nd REQ 4–5 | 47 13 | Unsupported DID |
| 2nd POS | 62 F1 90 .. | VIN only; no entry and no error for 0x4713 [unverified] |

Negative responses.

```uds
REQ 22 F1               # one DID byte only
NEG 7F 22 13            # length invalid
REQ 22 47 13            # only an unsupported DID (illustrative)
NEG 7F 22 31            # none supported
REQ 22 47 12            # secured DID, ECU locked (illustrative)
NEG 7F 22 33
REQ 22 47 11 47 12 F1 90   # sum exceeds ECU buffer (illustrative)
NEG 7F 22 14
```

| Exchange | Request bytes | NRC | Reason |
|---|---|---|---|
| 1 | 22 F1 | 13 | Request length 2: below minimum 3 |
| 2 | 22 47 13 | 31 | No requested DID supported in active session |
| 3 | 22 47 12 | 33 | DID needs 0x27 unlock first |
| 4 | 22 47 11 47 12 F1 90 | 14 | Response would exceed buffer (illustrative ECU limit) |

## 7. Implementation and testing

**Implementation:**
- Request builder: take a list of DIDs (0x0000–0xFFFF), reject an empty list, warn above the ECU's known
  maximum DID count. Encode big-endian.
- Response parser: needs a DID length table (from ODX/CDD/OEM list). Walk the response: read 2 bytes DID, look
  up its length, slice the record, repeat. Fail loudly on an unknown DID or a leftover byte count. Do not map
  records by request position, because unsupported DIDs may be skipped.
- Variable-length DIDs (some ASCII identification DIDs) can only be parsed safely when requested alone or
  last.
- Handle 0x78 by extending the timeout to P2* and keep waiting; accept repeated 0x78.
- Functionally addressed requests: ECUs that support none of the DIDs stay silent (NRC 0x31 is suppressed
  for functional requests; see [../protocol-fundamentals.md](../protocol-fundamentals.md)). Collect responses
  until P2 expires instead of waiting for a fixed count.
- CAPL/CANoe: diagnostic layer handles segmentation; raw CAN tests should still check FF length and flow control.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive, single DID | `22 F1 90` | `62 F1 90` + 17 bytes |
| 2 | Positive, several DIDs | `22 F1 88 F1 91 F1 95` | Records in request order |
| 3 | Partial support | Supported + unsupported DID | Only supported record returned [unverified] |
| 4 | None supported | `22 47 13` (illustrative) | `7F 22 31` |
| 5 | Length min-1 | `22 F1` | `7F 22 13` |
| 6 | Length min | `22 F1 90` | Positive |
| 7 | Odd DID bytes | `22 F1 90 F1` | `7F 22 13` |
| 8 | Max DIDs | Exactly the ECU's max count | Positive |
| 9 | Max+1 DIDs | One DID more than max | `7F 22 13` [unverified] |
| 10 | Response too long | DIDs summing above buffer | `7F 22 14` |
| 11 | Session matrix | Each DID in default, extended, programming | Matches OEM DID/session table; `7F 22 31` where not allowed |
| 12 | Security matrix | Secured DID locked, then after 0x27 unlock | `7F 22 33`, then positive |
| 13 | Mixed secured + open DID, locked | One secured, one open DID | `7F 22 33` expected; record actual behaviour (some stacks omit the secured DID instead) [unverified] |
| 14 | Authentication (2020 ECUs) | DID needing 0x29, not authenticated | `7F 22 34` [edition-dependent] |
| 15 | Conditions | Measurement DID with ignition off (OEM rule) | `7F 22 22` |
| 16 | Functional addressing | `22 F1 90` to functional ID | Each supporting ECU answers; others stay silent |
| 17 | Multi-frame | VIN read on classic CAN | FF/FC/CF sequence correct, length 20 |
| 18 | Flow control abuse | Tester delays FC beyond N_Bs | ECU aborts transmission (transport timeout) |
| 19 | Response pending | Slow DID (if any) | `7F 22 78` then positive within P2* |
| 20 | Duplicate DID | `22 F1 90 F1 90` | Record actual behaviour (two copies or NRC) [unverified] |
| 21 | Session loss | Let S3 expire, read extended-only DID | `7F 22 31` |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.2 (data transmission functional unit). DID ranges and ISO-defined DIDs are in Annex C (data-parameter definitions for the data transmission functional unit, per the 2020 preview TOC). |
| Edition differences | 2013 → 2020: authentication added to the standard, so NRC 0x34 can appear [edition-dependent] [unverified]. No other change to the request/response layout known. Amd 1:2022 renamed DID 0xFF01 to TransportLayerSegmentationSupport. ISO 14229-1:2026 published June 2026: not yet reviewed for this service. |
| OEM / ECU-specific | Almost all DIDs, their lengths, scaling, session and security lists; maximum DIDs per request; buffer size; padding byte; CAN IDs. |
| Verification status | draft. Cross-checked: clause number and functional unit (2020 preview TOC), SID and response SID (py-uds), name of 0xFF01 (Amd 1 preview). Reviewer 2026-10-26: Annex C location (2020 preview TOC); identification block 0xF180–0xF19F (py-uds DID mapping). Message layout, NRC list and partial-support rules come from engineering knowledge. |
| Open questions | Exact ISO wording of the partial-support rule; whether one secured DID rejects the whole request; ordering rule; ISO bounds of the identification DID range; effect of the 2026 edition. |
