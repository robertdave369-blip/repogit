---
sid: 0x29
name: Authentication
response_sid: 0x69
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.6 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) — service added in 2020, clause 10.6"
  - "py-uds knowledge base (uds.readthedocs.io) — sub-function values and names 0x00–0x08, response SID 0x69"
  - "py-uds translator source (github.com/mdabrowski1990/uds: data_record_definitions/conditional.py, other.py; utilities/constants/other.py; message/nrc.py) — field order per sub-function, 2-byte length fields, 16-byte algorithmIndicator, authenticationReturnParameter values, NRC 0x50–0x5D names"
  - "udsoncan source and docs (github.com/pylessard/python-udsoncan, services/Authentication.py) — 2-byte big-endian length fields, algorithmIndicator 16 bytes (BER-encoded OID), certificateEvaluationId 2 bytes, return parameter values"
  - "Engineering knowledge — state rules (session change, timeout), NRC mapping per defect (not cross-checked)"
---

# 0x29 — Authentication

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x69
> Proves the identity and access rights of the tester (and optionally the server) with certificates or a
> challenge-response, and puts the server into an authenticated state. Added in ISO 14229-1:2020.

## 1. What is it?

Authentication (SID 0x29) is the 2020 replacement-or-complement for seed and key. Instead of a shared secret
per ECU type, the tester shows a **certificate** (or a cryptographic response to a challenge) that says who it
is and which **role / access rights** it holds. The server verifies it, checks that the tester owns the matching
private key (**proof of ownership**), and then unlocks the services that role may use.

Two approaches exist. The server tells the tester which one it uses through sub-function 0x08:

| Approach | Short name | Sub-functions | Idea |
|---|---|---|---|
| Authentication with PKI Certificate Exchange | APCE | 01 or 02, then 03; 04 optional | Tester sends a certificate signed by an OEM CA; server checks chain, validity, role; tester then signs the server's challenge |
| Authentication with Challenge-Response | ACR | 05, then 06 or 07 | Server sends a challenge; tester returns a proof computed with asymmetric or symmetric keys known to both sides |

Each step answers with an **authenticationReturnParameter** byte that tells the tester what happened and what
comes next. `0x00` deAuthenticate leaves the authenticated state.

## 2. Why is it needed?

Seed and key (0x27) has known limits:

- One secret per ECU variant. If it leaks (e.g. from one tester DLL), every vehicle of that type is open.
- No identity: the ECU cannot tell a dealer tool from a production tool from a hacker.
- No fine-grained rights: a level is unlocked or not.
- No revocation or expiry.

Regulation (UN R155 cybersecurity) and OEM security policies push for per-user, revocable, role-based access.
0x29 gives a standardized message flow for that. Value: OEM security teams, production line (factory roles),
workshops (dealer roles), validation teams (development certificates), suppliers (engineering roles).

## 3. What is its purpose?

It establishes and ends an authenticated state on the server, tied to a role and its access rights. It can also
create session key material for later protected communication [unverified]. It does not itself protect the
following messages; protection of messages is a job of the security sub-layer
([0x84](0x84-secured-data-transmission.md)) or of the transport (e.g. TLS on DoIP) [OEM-specific].

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| ECU spec uses seed and key | SecurityAccess (0x27) | 0x29 not implemented on 2013-based ECUs |
| Only a session change is needed | DiagnosticSessionControl (0x10) | No access rights involved |
| Protect a single request/response end to end | SecuredDataTransmission ([0x84](0x84-secured-data-transmission.md)) | 0x29 grants rights; it does not wrap messages |
| Read who is authenticated | OEM DID [OEM-specific] | 0x29 has no "status read" sub-function except 0x08 for the approach |

**Relation to SecurityAccess (0x27):** both gate services. An OEM may use only 0x27, only 0x29, or both (for
example 0x29 for role rights and 0x27 for a legacy flashing level). A service gated by authentication answers
`7F <SID> 34` when the role is missing; a service gated by security level answers `7F <SID> 33`. Which services
need which, and whether one implies the other, is OEM-defined. Evaluation order:
[../protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order).

<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Workshop tool unlocking restraint-system configuration
- **Scenario:** A dealer replaces an airbag control unit (ACU) and must write variant coding. The OEM grants
  the "workshop" role the right to write coding DIDs, but not to flash or to reset crash data.
- **Engineer's objective:** Write coding with a personal, revocable workshop certificate.
- **Why this service:** The ACU only accepts coding writes in an authenticated state with that role.
- **Tester sends:** `10 03`, `29 08`, `29 01 ..` (certificate + client challenge), `29 03 ..` (proof of
  ownership), then `2E 4711 ..` (illustrative coding DID).
- **ECU is expected to:** Report APCE, verify the certificate chain (`69 01 11 ..`), verify the signature
  (`69 03 12 ..`), accept the write.
- **Engineer obtains:** Coding written; ACU logs the certificate identity [OEM-specific].
- **Test on success / failure:** With the workshop certificate, a request needing an engineering role (e.g.
  clearing an EDR-locked record) must still fail with `7F <SID> 34` or `7F <SID> 33` per OEM spec.

### Use case: HIL negative testing of certificate checks
- **Scenario:** Validation of a new ECU's 0x29 implementation on a HIL bench with a test PKI.
- **Engineer's objective:** Show that every certificate defect is rejected with the right NRC and leaves the
  ECU unauthenticated.
- **Why this service:** The checks are the security requirement.
- **Tester sends:** `29 01 ..` with an expired certificate, a wrong signature, a wrong CA, a revoked
  certificate, a truncated certificate; then `29 03 ..` with a wrong proof.
- **ECU is expected to:** `7F 29 50`, `7F 29 51`, `7F 29 52`, `7F 29 57`, `7F 29 13`/`7F 29 54`,
  `7F 29 58` respectively [NRC choice per OEM spec].
- **Engineer obtains:** A coverage record for each check.
- **Test on success / failure:** After each failure, a protected service still answers `7F <SID> 34`.

End-of-line programming with a factory role typically uses the ACR flow (`29 08`, `29 05`, `29 06`) with
keys from the plant HSM; see the third example in section 6.

<!-- catalogue fields 5, 6 -->

## 5. How does it work?

**APCE, unidirectional (tester proves itself only):**

1. `29 08` → server returns the approach (APCE).
2. `29 01` with communicationConfiguration, client certificate, client challenge. Server verifies the
   certificate (format, signature, chain to a trusted root, validity time, scope/target, revocation) and
   returns `0x11` CertificateVerified-OwnershipVerificationNecessary plus a server challenge.
3. `29 03` with proof of ownership (tester signs the server challenge with its private key) and optional
   ephemeral public key. Server verifies and returns `0x12` OwnershipVerified-AuthenticationComplete, plus
   session key info if requested.
4. Server sets the role's access rights. Protected services now succeed.

**APCE, bidirectional:** `29 02` instead of `29 01`. The server also returns its own certificate and its proof
of ownership over the client challenge; the tester verifies the server before step 3.

**transmitCertificate (`29 04`):** sends an extra certificate (e.g. an intermediate CA or a certificate that
adds rights) with a certificateEvaluationId telling the server how to use it (OEM-defined values). The
response carries only the return parameter.

**ACR:** `29 05` requests a challenge for a given algorithm; `29 06` (unidirectional) or `29 07`
(bidirectional, server also proves itself) returns the proof. Keys are pre-shared or pre-installed.

**Leaving the state:** `29 00` deAuthenticate. The authenticated state is also lost on ECUReset and power
cycle. Do not assume it follows the 0x27 rule (re-lock on every session change): some stacks keep the
authenticated state across session changes and drop it only after an inactivity timeout in the default
session [unverified — the exact rule and any authentication timeout are edition-, stack- and OEM-dependent;
test it, see test 12].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Often allowed in default and extended; OEM matrix decides | OEM |
| Security / authentication | None to start; sequence rules between sub-functions | ISO (sequence) / OEM |
| ECU operating conditions | Valid time source for certificate validity check (if used); trusted root installed | OEM |
| Timing (P2 / P2* / S3) | Signature checks on small MCUs can exceed P2 → expect `7F 29 78` and P2* waits | ISO 14229-2 / ECU |

**Depends on:** OEM PKI (root and intermediate CAs, certificate profile — often X.509 or a compact
card-verifiable format [OEM-specific]); ECU crypto (HSM/SHE); a time source; transport that supports long
messages (ISO-TP multi-frame, CAN FD, DoIP — [../protocol-fundamentals.md](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials)).

<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

Sub-function values and names are cross-checked. Field order per sub-function, 2-byte MSB-first length
fields and the 16-byte algorithmIndicator are cross-checked against two open-source stacks (py-uds translator,
udsoncan), not against the ISO text. Confirm against clause 10.6 of the edition in use before building
production parsers.

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x29 |
| 2 | authenticationTask (sub-function) | 1 | bit 7 = SPRMIB, bits 6–0 = 0x00–0x08 |
| 3… | Sub-function parameters | n | See table below |

| Sub-function | Request parameters after byte 2 (cross-checked: py-uds, udsoncan) |
|---|---|
| 00 | none |
| 01, 02 | communicationConfiguration (1), lengthOfCertificateClient (2), certificateClient (n), lengthOfChallengeClient (2), challengeClient (n; may be 0 for 01, needed for 02) |
| 03 | lengthOfProofOfOwnershipClient (2), proofOfOwnershipClient (n), lengthOfEphemeralPublicKeyClient (2), ephemeralPublicKeyClient (n, may be 0) |
| 04 | certificateEvaluationId (2 in udsoncan; py-uds decodes 1 byte — [unverified]), lengthOfCertificateData (2), certificateData (n) |
| 05 | communicationConfiguration (1), algorithmIndicator (16, BER-encoded OID, no length prefix) |
| 06, 07 | algorithmIndicator (16), lengthOfProofOfOwnershipClient (2), proofOfOwnershipClient (n), lengthOfChallengeClient (2), challengeClient (n; may be 0 for 06, needed for 07), lengthOfAdditionalParameter (2), additionalParameter (n, may be 0) |
| 08 | none |

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | deAuthenticate | Ends the authenticated state | End of job; tests | Return parameter `0x10` DeAuthentication successful |
| 0x01 | verifyCertificateUnidirectional | Server verifies the client certificate | APCE start | Most common APCE entry |
| 0x02 | verifyCertificateBidirectional | Both sides exchange and verify certificates | APCE when the tester must trust the ECU | Larger response |
| 0x03 | proofOfOwnership | Client proves it holds the private key | Completes APCE | Sequence after 01/02 |
| 0x04 | transmitCertificate | Sends an additional certificate | Extra rights or chain elements | Rare |
| 0x05 | requestChallengeForAuthentication | Server issues a challenge | ACR start | |
| 0x06 | verifyProofOfOwnershipUnidirectional | Server checks client proof | ACR completion | |
| 0x07 | verifyProofOfOwnershipBidirectional | Server checks client proof and proves itself | ACR, mutual | |
| 0x08 | authenticationConfiguration | Server reports APCE or ACR | First request of any flow | No parameters |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x69 |
| 2 | authenticationTask | 1 | Echo with bit 7 cleared |
| 3 | authenticationReturnParameter | 1 | Result / next step (table below) |
| 4… | Sub-function data | n | Length-prefixed (2 bytes) fields in this order: 00, 04, 08 → none; 01 → challengeServer, ephemeralPublicKeyServer; 02 → challengeServer, certificateServer, proofOfOwnershipServer, ephemeralPublicKeyServer; 03 → sessionKeyInfo; 05 → algorithmIndicator (16, no prefix), challengeServer, neededAdditionalParameter; 06 → algorithmIndicator, sessionKeyInfo; 07 → algorithmIndicator, proofOfOwnershipServer, sessionKeyInfo (cross-checked: py-uds translator) |

**authenticationReturnParameter** (values 0x00–0x13 cross-checked: py-uds translator and udsoncan; ranges
0xA0–0xFE [unverified]):

| Value | Meaning |
|---|---|
| 0x00 | RequestAccepted |
| 0x01 | GeneralReject |
| 0x02 | AuthenticationConfiguration APCE |
| 0x03 | AuthenticationConfiguration ACR with asymmetric cryptography |
| 0x04 | AuthenticationConfiguration ACR with symmetric cryptography |
| 0x10 | DeAuthentication successful |
| 0x11 | CertificateVerified, OwnershipVerificationNecessary |
| 0x12 | OwnershipVerified, AuthenticationComplete |
| 0x13 | CertificateVerified |
| 0xA0–0xCF / 0xD0–0xFE | Vehicle-manufacturer / system-supplier specific [unverified ranges] |
| other | Reserved |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Approach not implemented (e.g. 0x05 on an APCE-only ECU) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length fields do not match the bytes received; truncated certificate |
| 0x22 | conditionsNotCorrect | No valid time / trust anchor; OEM preconditions |
| 0x24 | requestSequenceError | 0x03 without a successful 0x01/0x02; 0x06/0x07 without 0x05 |
| 0x31 | requestOutOfRange | Unsupported communicationConfiguration, algorithmIndicator or certificateEvaluationId |
| 0x7E / 0x7F | …NotSupportedInActiveSession | Sub-function / service not allowed in this session |
| 0x50 | certificateVerificationFailed_InvalidTimePeriod | Certificate expired or not yet valid |
| 0x51 | …_InvalidSignature | Certificate signature wrong |
| 0x52 | …_InvalidChainOfTrust | Not issued by a trusted CA |
| 0x53 | …_InvalidType | Wrong certificate type for this step |
| 0x54 | …_InvalidFormat | Cannot be parsed |
| 0x55 | …_InvalidContent | Parsed, but fields invalid |
| 0x56 | …_InvalidScope | Not valid for this ECU / vehicle (target mismatch) |
| 0x57 | …_InvalidCertificate | Revoked or otherwise invalid |
| 0x58 | ownershipVerificationFailed | Proof of ownership wrong |
| 0x59 | challengeCalculationFailed | Server could not create a challenge |
| 0x5A | settingAccessRightsFailed | Rights from the certificate could not be applied |
| 0x5B | sessionKeyCreationOrDerivationFailed | Session key could not be created |
| 0x5C | configurationDataUsageFailed | Configuration data (e.g. from 0x04) unusable |
| 0x5D | deAuthenticationFailed | Server could not leave the authenticated state |
| 0x78 | requestCorrectlyReceived-ResponsePending | Crypto takes longer than P2 |

Services protected by authentication answer **0x34 authenticationRequired** while the role is missing. Names of
0x50–0x5D match the py-uds NRC list (secondary source; see [../nrc-reference.md](../nrc-reference.md)). Exact
mapping of each defect to an NRC is ECU-defined; many implementations return a subset.

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Certificates, challenges and signatures are shown as `..`.
Field order follows the cross-checked layout above; the communicationConfiguration value 00 is [unverified].

```uds
REQ 29 08                    # authenticationConfiguration
POS 69 08 02                 # APCE
REQ 29 01 00 01 C2 .. 00 20 ..   # commConfig 00, certificate 450 bytes, client challenge 32 bytes (illustrative)
NEG 7F 29 78                 # signature check takes longer than P2
POS 69 01 11 00 20 .. 00 00  # CertificateVerified-OwnershipVerificationNecessary, server challenge 32 bytes, no ephemeral key
REQ 29 03 00 40 .. 00 00     # proof of ownership 64 bytes (e.g. ECDSA P-256 signature, illustrative), no ephemeral key
POS 69 03 12 00 00           # OwnershipVerified-AuthenticationComplete, no session key info
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 1 / POS 1 | 29 08 / 69 08 02 | Approach = APCE |
| REQ 2 | 29 01 | verifyCertificateUnidirectional |
| REQ 2 | 00 | communicationConfiguration: no secure channel requested [unverified coding] |
| REQ 2 | 01 C2 .. | lengthOfCertificateClient 450, then certificate (multi-frame on CAN) |
| REQ 2 | 00 20 .. | lengthOfChallengeClient 32, then challenge |
| NEG | 7F 29 78 | Response pending; tester switches to P2* |
| POS 2 | 11 | CertificateVerified, OwnershipVerificationNecessary |
| POS 2 | 00 20 .. / 00 00 | Server challenge (32 bytes); ephemeral key length 0 |
| REQ 3 | 00 40 .. / 00 00 | Proof length 64 + proof; ephemeral key length 0 |
| POS 3 | 12 / 00 00 | Authentication complete; session key info length 0 |

```uds
REQ 2E 47 11 01              # write coding DID 0x4711 (illustrative) before authentication
NEG 7F 2E 34                 # authenticationRequired
REQ 29 03 00 40 ..           # proofOfOwnership without a verified certificate
NEG 7F 29 24                 # requestSequenceError
REQ 29 01 00 01 C2 .. 00 20 ..   # expired certificate (illustrative)
NEG 7F 29 50                 # certificateVerificationFailed_InvalidTimePeriod
REQ 29 00                    # deAuthenticate
POS 69 00 10                 # DeAuthentication successful
```

| Line | Byte(s) | Meaning |
|---|---|---|
| NEG 1 | 7F 2E 34 | WriteDataByIdentifier refused: no authenticated role |
| NEG 2 | 7F 29 24 | Step 03 before 01/02 |
| NEG 3 | 7F 29 50 | Certificate outside validity period |
| REQ 4 / POS 4 | 29 00 / 69 00 10 | Leave authenticated state; return parameter 0x10 |

```uds
REQ 29 08
POS 69 08 04                 # ACR with symmetric cryptography
REQ 29 05 00 ..              # commConfig 00, algorithmIndicator 16 bytes (illustrative)
POS 69 05 00 .. 00 10 .. 00 00   # accepted, algorithmIndicator, server challenge 16 bytes, no additional parameter
REQ 29 06 .. 00 10 .. 00 00 00 00   # algorithmIndicator, proof 16 bytes (e.g. CMAC), no client challenge, no additional parameter
POS 69 06 12 .. 00 00        # authentication complete, algorithmIndicator, no session key info
```

| Line | Byte(s) | Meaning |
|---|---|---|
| POS 1 | 69 08 04 | ACR, symmetric |
| REQ 2 | 29 05 00 .. | requestChallengeForAuthentication, commConfig, 16-byte algorithm OID field |
| POS 2 | 00 / .. / 00 10 .. / 00 00 | RequestAccepted; algorithmIndicator (16 bytes); challenge length 16 + challenge; needed additional parameter length 0 |
| REQ 3 | 29 06 | verifyProofOfOwnershipUnidirectional |
| POS 3 | 12 | Authentication complete |

<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- Builder: one function per sub-function; compute every 2-byte length from the actual data, never accept
  a caller-supplied length. Validate algorithmIndicator is exactly 16 bytes. Make the certificateEvaluationId
  width configurable (1 or 2 bytes) until confirmed against the ISO text.
- Parser: read return parameter first; branch on it (`0x11` → proof needed, `0x12` → done). Parse
  length-prefixed fields in order; fail if lengths overrun the message.
- Crypto: never embed private keys or algorithms in test code. Call the project's PKI / HSM service or a
  test-PKI stub with clearly marked test keys.
- Timing: allow 0x78 and long P2* on every 0x29 request. Use CAN FD or DoIP for certificate transfer when
  available; on classical CAN expect several hundred consecutive frames.
- Keep the authenticated state alive with TesterPresent; re-authenticate after any reset or session drop.
- Record which certificate (subject, serial) was used in test logs. Never log private key material.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Configuration | `29 08` | `69 08 02/03/04` per ECU spec |
| 2 | APCE positive (uni) | `29 01` valid cert, `29 03` valid proof | `69 01 11 ..`, `69 03 12 ..`; protected service positive |
| 3 | APCE positive (bi) | `29 02`, verify server cert in tester, `29 03` | `69 02 11 ..` with server cert + proof; `69 03 12 ..` |
| 4 | ACR positive | `29 05`, `29 06` (or `07`) | Challenge; `69 06 12 ..` |
| 5 | Before auth | Protected service | `7F <SID> 34` |
| 6 | Each cert defect | Expired, bad signature, unknown CA, wrong type, garbage, wrong content, wrong target, revoked | `7F 29 50` … `7F 29 57` per OEM mapping; still unauthenticated |
| 7 | Bad proof | Wrong signature in `29 03` | `7F 29 58` |
| 8 | Sequence | `29 03` first; `29 06` without `29 05`; `29 03` twice | `7F 29 24` |
| 9 | Challenge reuse | Replay a previous proof | `7F 29 58` (fresh challenge each time) |
| 10 | Role limits | Workshop cert, then engineering-only service | `7F <SID> 34` or `33` per OEM |
| 11 | deAuthenticate | `29 00` then protected service | `69 00 10`; then `7F <SID> 34` |
| 12 | State loss | Authenticate, then `11 01` / S3 timeout / `10 01` / `10 03` → `10 02` | After reset: `7F <SID> 34`. After session changes: record the behaviour and compare with the OEM spec [session rule unverified] |
| 13 | Session matrix | `29 08`, `29 01` in each session | Per OEM; `7F 29 7F` / `7E` where not allowed |
| 14 | Security interaction | Authenticated but 0x27 locked (and vice versa) on a service needing both | NRC per OEM evaluation order |
| 15 | Length min-1 | `29` | `7F 29 13` |
| 16 | Length fields | Certificate length field 1 byte longer / shorter than data | `7F 29 13` |
| 17 | Max length | Largest certificate the ECU supports; +1 byte | Accepted; then `7F 29 13` or `7F 29 54` |
| 18 | SPRMIB | `29 80` | No positive response; state left. On data-carrying steps (`29 81`) behaviour per spec [unverified] |
| 19 | Unsupported sub-function | `29 09`, and the other approach's sub-functions | `7F 29 12` |
| 20 | Functional | `29 08` functional | Per OEM; usually physical only. Unsupported nodes silent |
| 21 | Response pending | Slow crypto | `7F 29 78` within P2, final response within P2* |
| 22 | Multi-frame | Certificate on classical CAN with BS/STmin variations | Complete transfer; no N_Cr/N_Bs timeouts |

<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.6 (functional unit: diagnostic and communication management) |
| Edition differences | Added in 2020 (cross-checked, Foreword). Not present in 2013: a 2013 ECU answers `7F 29 11` [edition-dependent]. NRC 0x34 and 0x50–0x5D introduced with it. 2026 edition not yet reviewed |
| OEM / ECU-specific | Approach (APCE/ACR), certificate profile and size, CA hierarchy, role → service mapping, revocation method, time source, session rules, NRC mapping per defect, communicationConfiguration and algorithmIndicator values |
| Verification status | cross-checked (reviewer, 2026-10-26). Cross-checked: SID, response SID, clause 10.6, sub-function values/names 0x00–0x08, added in 2020 (ISO preview, py-uds KB); request and response field order per sub-function, 2-byte length fields, 16-byte algorithmIndicator, return parameter values 0x00–0x13, NRC names 0x50–0x5D (py-uds translator source, udsoncan source). Not cross-checked: communicationConfiguration coding, size of certificateEvaluationId (udsoncan 2 bytes vs py-uds 1 byte), return parameter manufacturer/supplier ranges, state-loss rules, NRC mapping per defect |
| Open questions | Size of certificateEvaluationId; communicationConfiguration coding; whether SPRMIB is permitted on each sub-function; whether a session change de-authenticates; authentication timeout rules; how session keys feed 0x84 |

<!-- catalogue field 15 -->
