---
sid: 0x31
name: RoutineControl
response_sid: 0x71
has_sub_function: true
functional_unit: "Remote activation of routine"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "14.2 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview TOC (cdn.standards.iteh.ai sample 72439): clause 14.2, functional unit 14 remote activation of routine"
  - "py-uds knowledge base (uds.readthedocs.io): SID 0x31 / response SID 0x71 only"
  - "py-uds source (github.com/mdabrowski1990/uds: data_record_definitions/conditional.py, rid.py; constants/rid.py RID_MAPPING): response = sub-function echo + RID + routineStatus bytes (optional for 01/02, at least one byte for 03), no separate routineInfo field; RIDs 0xE200, 0xE201, 0xFF00 eraseMemory, 0xFF01 checkProgrammingDependencies (reviewer, 2026-10-26)"
  - "python-udsoncan RoutineControl documentation: response = routine_id_echo + routine_status_record, no routineInfo (reviewer, 2026-10-26)"
---

# 0x31 — RoutineControl

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x71
> Starts, stops and reads the results of a server-side routine identified by a 2-byte routine identifier (RID).

## 1. What is it?

RoutineControl (SID 0x31) runs a function inside the server that is more than a data read or write: erase a
flash area, check a downloaded software's dependencies, run a self-test, learn or calibrate a sensor, bleed a
brake circuit. Each routine has a 2-byte **routineIdentifier (RID)**. The sub-function
(**routineControlType**) says what to do with it:

- `01` startRoutine — start it, optionally with input parameters (**routineControlOptionRecord**).
- `02` stopRoutine — stop a running routine.
- `03` requestRoutineResults — get the outcome or progress.

The positive response echoes sub-function and RID and may carry a **routineStatusRecord** (results, progress,
pass/fail). Its content is defined per RID, almost always by the OEM.

## 2. Why is it needed?

Many diagnostic and production tasks are actions with a duration and a result, not a value to read or set.
0x2E stores data without running an algorithm; 0x2F holds a signal in a state without running a sequence;
0x34–0x37 move data but do not erase flash or check the result.

- **Flashing:** bootloader erase and post-download checks (eraseMemory, checkProgrammingDependencies).
- **Production line:** sensor calibration, actuator self-tests, configuration checks.
- **Workshop:** guided procedures (e.g. adaptation reset, bleeding, learning a new part).
- **Validation / HIL:** trigger self-tests and confirm results and error handling.

## 3. What is its purpose?

It is the generic "do this job" entry point of UDS. It starts server functions, controls their life cycle and
returns their results. It may change ECU state heavily (erased flash, new calibration values in NVM).
It does not define what any OEM routine does; the RID definition does. It is not a data transfer service.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| You want to hold an output in a state | 0x2F InputOutputControlByIdentifier | Override with explicit return of control |
| You want to store a value | 0x2E WriteDataByIdentifier | No routine needed |
| You want to read a value the ECU already has | 0x22 ReadDataByIdentifier | Results that exist as DIDs are read with 0x22 |
| You want to transfer a software block | 0x34 / 0x36 / 0x37 | Erase and checks are routines; the transfer is not |
| You want to clear fault memory | 0x14 ClearDiagnosticInformation | Standard service exists |
| Pyrotechnic deployment routines of a restraint ECU (end-of-life, ISO 26021) | Out of scope | Not described in this catalogue |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Flash sequence in the bootloader
- **Scenario:** Reprogramming an application block over CAN.
- **Engineer's objective:** Erase the target area, download, then confirm the software set is consistent.
- **Why this service:** Erase and dependency check are defined as ISO routines (0xFF00, 0xFF01 [unverified]).
- **Tester sends:** `10 02` → `27 ..` → `31 01 FF 00 <option record>` → `34` / `36` / `37` →
  `31 01 FF 01` → `11 01`.
- **ECU is expected to:** Send `7F 31 78` while erasing, then `71 01 FF 00 ..`; after download, check
  signatures/compatibility and report the result in the status record.
- **Engineer obtains:** Erase success; dependency check pass/fail.
- **Test on success / failure:** Success = both routines report OK (status value per OEM spec) and the ECU
  starts the new software after reset. Failure = `7F 31 72` on erase, or a "dependencies not OK" status →
  the ECU stays in the bootloader.

### Use case: End-of-line empty-seat calibration of an occupant classification sensor
- **Scenario:** Restraint ECU with seat occupant classification; the line calibrates the empty-seat offset.
- **Engineer's objective:** Store a valid zero point so that the passenger airbag enable logic works.
- **Why this service:** Calibration is a sequence (sample, filter, plausibility check, NVM write) with a result.
- **Tester sends:** `10 03` → `27 ..` → `31 01 02 10` (RID `0x0210` illustrative) → poll `31 03 02 10`.
- **ECU is expected to:** Start, report "running", then "finished OK" with the measured offset, or "failed" with a
  reason code (all status values illustrative).
- **Engineer obtains:** Pass/fail plus the offset for traceability.
- **Test on success / failure:** Success = status OK and offset inside the OEM window. Failure = status failed,
  `7F 31 22` (seat not empty / voltage), or timeout → seat rejected to rework.

### Use case: HIL test of a self-test routine with sequence errors
- **Scenario:** HIL bench for a body ECU self-test RID `0x0203` (illustrative), asynchronous.
- **Engineer's objective:** Show start / poll / stop behaviour and sequence-error handling match the spec.
- **Why this service:** The routine life cycle is part of the diagnostic requirements.
- **Tester sends:** `31 03 02 03` (results before start), `31 01 02 03`, `31 01 02 03` (start again),
  `31 03 02 03` (poll), `31 02 02 03` (stop).
- **ECU is expected to:** `7F 31 24` for results before start; accept start; second start per OEM rule;
  poll returns "running"; stop accepted.
- **Engineer obtains:** Evidence for each life-cycle requirement.
- **Test on success / failure:** Any response that differs from the OEM life-cycle table is a defect.
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. The server checks the service in the active session, the length, and the sub-function (`01`–`03`).
2. It checks that the RID exists and is supported in the active session and security state.
3. It checks that the sub-function is valid for this RID (not all routines can be stopped or report results).
4. It checks the option record (length and values per RID) and the preconditions.
5. It checks the sequence: results or stop before start → 0x24.
6. It runs the requested action and answers.

**Synchronous vs asynchronous routines** (defined per RID by the OEM):

| Type | Start response | Results | Typical examples |
|---|---|---|---|
| Synchronous | Sent when the routine has finished; uses `7F 31 78` if longer than P2server_max | In the start response's status record | eraseMemory, checkProgrammingDependencies |
| Asynchronous | Sent as soon as the routine has started | Poll with `03`; optional stop with `02` | Calibrations, long self-tests, bleeding |

For long synchronous routines the server sends `7F 31 78` within P2server_max and then repeats it within each
P2*server_max until it is done ([../protocol-fundamentals.md](../protocol-fundamentals.md#response-pending-0x78)).
The tester must not resend `31 01` during that time. A routine stuck in 0x78 is a classic defect.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Programming session for flash routines; extended session for most others | OEM |
| Security / authentication | Unlock (0x27) or authentication (0x29) for anything that changes NVM or flash | OEM |
| ECU operating conditions | Vehicle stationary, voltage in range, routine-specific (seat empty, engine off, HV off) | OEM |
| Timing (P2 / P2* / S3) | 0x78 for long routines; keep S3 alive with 0x3E during asynchronous routines | ISO 14229-2 + ECU |

**Depends on:** 0x10, 0x27 / 0x29, 0x3E; 0x34–0x37 in the flash sequence; 0x22 if results are also published as
DIDs. Transport: option records often exceed 7 bytes → multi-frame on classical CAN.
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | `0x31` |
| 2 | routineControlType (sub-function) | 1 | Bit 7 = SPRMIB, bits 6–0: `01`, `02`, `03`; `00` and `04`–`7F` ISO reserved [unverified] |
| 3–4 | routineIdentifier | 2 | RID, big-endian (ranges below) |
| 5… | routineControlOptionRecord | n, optional | Input parameters, layout defined per RID and sub-function |

RID ranges (Annex F) [unverified boundaries — check the edition in use]:

| Range | Use |
|---|---|
| 0x0000–0x01FF | ISO reserved (0x0100–0x01FF tachograph test IDs in some editions) [unverified] |
| 0x0200–0xDFFF | Vehicle-manufacturer-specific |
| 0xE000–0xE1FF | OBD test identifiers |
| 0xE200–0xE2FF | Safety-system routines (ISO 26021 end-of-life; py-uds maps 0xE200 and 0xE201). Out of scope for this catalogue [unverified range bounds] |
| 0xE300–0xEFFF | ISO reserved [unverified] |
| 0xF000–0xFEFF | System-supplier-specific |
| 0xFF00 | eraseMemory (in py-uds RID mapping; ISO text not checked) |
| 0xFF01 | checkProgrammingDependencies (in py-uds RID mapping; ISO text not checked) |
| 0xFF02 | eraseMirrorMemoryDTCs in 2013 [edition-dependent] [unverified]; mirror memory was removed in 2020 |
| other | ISO reserved — see [../protocol-fundamentals.md](../protocol-fundamentals.md#identifier-ranges-overview) |

Even for 0xFF00 / 0xFF01 the option and status records are OEM-defined. A common eraseMemory option record is
`addressAndLengthFormatIdentifier + memoryAddress + memorySize`, like 0x34 [OEM-specific].

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 01 | startRoutine | Starts the routine with the given options | Every routine | Synchronous routines answer only when done |
| 02 | stopRoutine | Stops a running routine; may return a status | Abort calibration / self-test | Not every RID supports it |
| 03 | requestRoutineResults | Returns results or progress | Polling asynchronous routines | Before start → 0x24 |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | `0x71` |
| 2 | routineControlType | 1 | Echo of the sub-function, bit 7 cleared |
| 3–4 | routineIdentifier | 2 | Echo of the RID |
| 5 | routineInfo | 1, conditional | See note below [edition-dependent][unverified] |
| 5 (or 6)… | routineStatusRecord | n, optional | Results / progress / status, layout per RID |

**routineInfo note [edition-dependent][unverified]:** some descriptions of the 2013 and 2020 editions show an
extra `routineInfo` byte right after the RID, with OEM-defined meaning, possibly required only for certain
RIDs (e.g. OBD routines). Public secondary sources checked for this entry (pyudskit, py-uds summary, py-uds
source, python-udsoncan) show only `RID + status record`; py-uds requires at least one status byte for `03`.
Absence in open-source libraries does not prove absence in the ISO text. Until the edition text is checked: parse everything after the RID as the RID's status
record, and let the RID definition say whether its first byte is a routineInfo/status byte.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Sub-function not `01`–`03`, or not supported by this server. For a RID that cannot be stopped: 0x12 or 0x31 [unverified] |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Shorter than 4 bytes, or option record length wrong for this RID |
| 0x22 | conditionsNotCorrect | Routine preconditions not met (vehicle moving, voltage, seat occupied, HV on); also some ECUs for "already running" [OEM-specific] |
| 0x24 | requestSequenceError | `02` or `03` without a prior `01` for that RID; some ECUs for `01` while already running [OEM-specific] |
| 0x26 | failurePreventsExecutionOfRequestedAction | An active fault blocks the routine |
| 0x31 | requestOutOfRange | RID not supported (in this session / state); option record values invalid |
| 0x33 | securityAccessDenied | Routine needs an unlocked security level |
| 0x34 | authenticationRequired | 2020 ECUs using 0x29 instead of 0x27 |
| 0x72 | generalProgrammingFailure | Erase / NVM write inside the routine failed |
| 0x78 | requestCorrectlyReceived-ResponsePending | Routine needs longer than P2server_max |
| 0x7E | subFunctionNotSupportedInActiveSession | Sub-function exists, not in this session |
| 0x7F | serviceNotSupportedInActiveSession | 0x31 not allowed in this session (often default) |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md). Evaluation order:
[../protocol-fundamentals.md](../protocol-fundamentals.md#nrc-evaluation-order).

### Examples

Values marked (illustrative) are not universal. Status value `00` = OK is an OEM convention, not ISO.

```uds
REQ 31 01 FF 00 44 00 08 00 00 00 04 00 00  # eraseMemory, ALFID 44, addr 0x00080000, size 0x00040000 (illustrative)
NEG 7F 31 78                                # erase running
NEG 7F 31 78                                # still running, within P2*server_max
POS 71 01 FF 00 00                          # done; status 00 = OK (illustrative)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 31 01 FF 00 | | RoutineControl, startRoutine, RID eraseMemory [unverified] |
| 44 | | ALFID: 4-byte size, 4-byte address [OEM-specific record] |
| 00 08 00 00 / 00 04 00 00 | | memoryAddress / memorySize 256 KiB — same range as the shared flashing example in [0x34](0x34-request-download.md#examples) (illustrative) |
| 7F 31 78 | | Response pending |
| 71 01 FF 00 00 | | Echo of sub-function and RID; routineStatusRecord `00` = OK (illustrative) |

```uds
REQ 31 01 FF 01              # checkProgrammingDependencies after download
POS 71 01 FF 01 00           # 00 = dependencies OK (illustrative)
REQ 31 01 FF 01
POS 71 01 FF 01 01           # 01 = failed, e.g. signature or version mismatch (illustrative)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| FF 01 | | RID checkProgrammingDependencies [unverified]; status `00` / `01` OEM-defined |

Asynchronous routine life cycle (RID `0x0203` and all status bytes illustrative):

```uds
REQ 31 03 02 03              # results before start
NEG 7F 31 24
REQ 31 01 02 03              # start self-test
POS 71 01 02 03
REQ 31 03 02 03              # poll
POS 71 03 02 03 01           # 01 = running
REQ 31 03 02 03
POS 71 03 02 03 00 12 34     # 00 = finished OK, result data 12 34
REQ 31 02 02 03              # stop after completion
NEG 7F 31 24                 # not running any more [OEM-specific]
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 31 03 / 31 02 | | requestRoutineResults / stopRoutine |
| 7F 31 24 | | Sequence error: no start for this RID yet |
| 71 01 02 03 | | Started; asynchronous, so no result yet |
| 01 / 00 12 34 | | Status running / status OK + result value (illustrative) |

SPRMIB with a short and a long routine:

```uds
REQ 31 81 02 03              # start, positive response suppressed
NOTE no response expected
REQ 31 81 FF 00 ..           # start erase, SPRMIB set
NEG 7F 31 78                 # pending: final response must follow
POS 71 01 FF 00 00           # final response sent despite SPRMIB
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 81 | 1000 0001 | SPRMIB set + startRoutine |
| 71 01 | | Echo with bit 7 cleared |

Negative cases (RID `0x4711` illustrative, unsupported):

```uds
REQ 31 04 02 03              # reserved sub-function
NEG 7F 31 12
REQ 31 01 47 11              # unsupported RID
NEG 7F 31 31
REQ 31 01 02                 # RID incomplete
NEG 7F 31 13
REQ 31 01 FF 00 ..           # erase while security locked
NEG 7F 31 33
REQ 31 01 02 10              # seat calibration with seat occupied (illustrative)
NEG 7F 31 22
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 7F 31 12 / 31 | | Sub-function not supported / RID not supported |
| 7F 31 13 | | 3 bytes: below minimum length |
| 7F 31 33 / 22 | | Security not unlocked / routine preconditions not met |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- **Builder:** inputs `control_type` (01–03), `rid` (0x0000–0xFFFF, big-endian), `option_record` bytes,
  `suppress_positive` flag. Validate option record length against the RID definition when one exists.
- **Parser:** check `71`, sub-function echo (bit 7 cleared), RID echo. Hand the remaining bytes to a per-RID
  decoder; treat them as raw bytes when no definition exists. Do not hard-code a routineInfo byte (section 6).
- **Timing:** per-RID timeout for synchronous routines (seconds for large erases, illustrative). Handle any
  number of `7F 31 78`. For asynchronous routines: poll interval, overall timeout, and 0x3E keep-alive.
- **Flash flows:** treat `7F 31 72` and any non-OK status as fatal; leave the ECU in programming session for a
  retry.
- **Cleanup:** stop asynchronous routines a test started (`31 02`), or end the session.
- **Edge cases:** session change or S3 timeout while a routine runs (does it abort? OEM-specific); power loss
  during erase; second tester starting the same routine; results requested long after completion (still
  available?); routine started with SPRMIB that later fails (NRC is still sent).

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive start (sync) | `31 01 FF 01` | `71 01 FF 01 <status>` |
| 2 | Positive start (async) | `31 01 02 03` | `71 01 02 03` immediately |
| 3 | Poll results | `31 03 02 03` during and after run | Running status, then final status |
| 4 | Stop | `31 02 02 03` while running | `71 02 02 03 ..`; routine stopped |
| 5 | Results before start | `31 03 02 03` after reset | `7F 31 24` |
| 6 | Stop when not running | `31 02 02 03` | `7F 31 24` [OEM-specific] |
| 7 | Start while running | `31 01 02 03` twice | Per OEM: restart, `7F 31 24` or `7F 31 22` |
| 8 | Unsupported sub-function | `31 00 ..`, `31 04 ..`, `31 7F ..` | `7F 31 12` |
| 9 | Sub-function not valid for RID | `31 02` on a RID without stop | `7F 31 12` or `7F 31 31` [unverified] |
| 10 | Unsupported RID | `31 01 47 11` | `7F 31 31` |
| 11 | Invalid option record | Wrong values / length for the RID | `7F 31 31` / `7F 31 13` |
| 12 | Length min-1 | `31 01 02` | `7F 31 13` |
| 13 | Length min | `31 01 FF 01` | Positive |
| 14 | Length max / max+1 | Option record at its defined max, then one byte more | Positive / `7F 31 13` |
| 15 | Conditions | Each precondition violated in turn | `7F 31 22` or 0x81–0x93 |
| 16 | Response pending | Large erase | `7F 31 78` within P2, final within P2*; no resend |
| 17 | Programming failure | Force erase failure (HIL / debugger) | `7F 31 72` |
| 18 | Session matrix | Each RID in default / extended / programming / OEM sessions | Per OEM; else `7F 31 7F` / `7F 31 31` / `7F 31 7E` |
| 19 | Security / authentication | Locked, wrong level, correct level | `7F 31 33` / `7F 31 34` until correct |
| 20 | SPRMIB short routine | `31 81 02 03` | No positive response; routine runs |
| 21 | SPRMIB long routine | `31 81 FF 00 ..` | `7F 31 78` then final positive response |
| 22 | SPRMIB with error | `31 81 47 11` | `7F 31 31` still sent |
| 23 | Functional addressing | `31 01 <rid>` on functional ID | Per OEM (usually physical only); no 0x12/0x31 on functional ID |
| 24 | Multi-frame | eraseMemory with 13-byte request on classical CAN | Accepted via ISO-TP FF/FC/CF |
| 25 | Session loss during routine | Async routine, then `10 01` or S3 timeout | Routine aborted or completed per OEM spec |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 14.2 (functional unit 14, remote activation of routine); RID ranges in Annex F |
| Edition differences | Presence and rules of the `routineInfo` byte in the positive response [edition-dependent][unverified]. Otherwise no 2013 ↔ 2020 differences known [unverified]. 2026 edition not yet reviewed |
| OEM / ECU-specific | Almost everything per RID: option and status record layouts, status values, sync vs async, stop/results support, sessions, security, preconditions, behaviour on session loss, timeouts |
| Verification status | draft. Cross-checked: SID 0x31, response SID 0x71, clause 14.2, functional unit. Reviewer 2026-10-26: response layout without a routineInfo field and RIDs 0xFF00 / 0xFF01 checked against py-uds and python-udsoncan (open-source, not normative). Engineering knowledge only: RID range bounds, NRC usage |
| Open questions | routineInfo byte: which edition, mandatory or conditional, for which RIDs. Exact Annex F range boundaries and full list of ISO-defined RIDs. Normative NRC for a sub-function a RID does not support (0x12 vs 0x31). Whether a final response is mandatory after 0x78 when SPRMIB was set |
<!-- catalogue field 15 -->
