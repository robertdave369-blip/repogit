---
sid: 0x28
name: CommunicationControl
response_sid: 0x68
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.5 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (standards.iteh.ai sample 72439): clause 10.5"
  - "udsoncan documentation (udsoncan.readthedocs.io): controlType 00-05, node ID only for 04/05 (introduced 2013), communicationType = subnet 0-0xF + normal / NM message flags"
  - "udsoncan source (github.com/pylessard/python-udsoncan, common/CommunicationType.py): bit 0 normal, bit 1 NM, bits 7-4 subnet"
  - "py-uds translator source (github.com/mdabrowski1990/uds): controlType 00-05 names, node ID only for 04/05, response = echo only, messagesType 0-3 meanings, networks 0x0 = all connected networks, 0xF = network on which the request is received"
  - "NI Automotive Diagnostic Command Set API reference (ni.com): controlType 00-03, communicationType 01 application / 02 network management"
---

# 0x28 — CommunicationControl

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x68
> Switches the server's transmission and/or reception of non-diagnostic messages on or off.

## 1. What is it?

CommunicationControl (SID 0x28) tells a server to stop or resume sending and/or receiving its normal
communication: application messages (signals, PDUs) and/or network management (NM) messages. Diagnostic
messages are never affected; the server keeps answering the tester. The sub-function (controlType) chooses
which direction is switched. The communicationType byte chooses the message types and the sub-network.
Two controlTypes add a 2-byte nodeIdentificationNumber, so a gateway can switch one specific node behind it.

## 2. Why is it needed?

- During flashing, application traffic from other ECUs costs bus bandwidth and CPU time. Silencing it speeds
  up the download and avoids timing problems.
- An ECU in its bootloader no longer sends its messages. Other ECUs would set "lost communication" DTCs or
  react to missing signals. Silencing the whole network together (with
  [0x85 ControlDTCSetting](0x85-control-dtc-setting.md) off) keeps the
  behaviour controlled.
- In development and validation, switching one ECU's Tx off lets the team test how the rest of the network
  reacts to its absence, without pulling a connector.

Who gets value: flash tools and workshops (network-wide reprogramming), validation teams (signal-loss and
timeout tests), gateway developers (sub-network control).

## 3. What is its purpose?

It changes a volatile communication state in the server. It returns only the echo. The state ends when the
client restores it, when the server goes back to defaultSession, or when it resets. It does not stop
diagnostic communication, does not stop DTC recording (that is [0x85](0x85-control-dtc-setting.md)), and does
not make an ECU sleep.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Stop DTC recording during flashing or tests | [0x85 ControlDTCSetting](0x85-control-dtc-setting.md) | 0x28 only stops traffic; missing-message DTCs are still recorded |
| Change the CAN baud rate for flashing | 0x87 LinkControl | 0x28 does not change the link |
| Override a single signal or output | 0x2F InputOutputControlByIdentifier | 0x28 is all-or-nothing per message type |
| Simulate a missing ECU on a HIL | Remove it in the restbus simulation | No diagnostic session needed, no side effects on the ECU |

## 4. When is it used? — Real use cases

### Use case: Network silence before flashing
- **Scenario:** Reflash of one ECU on a shared CAN network.
- **Engineer's objective:** Stop normal traffic from all ECUs so the download is fast and no ECU reacts to the
  target's absence.
- **Why this service:** 0x28 is the ISO way to silence application messages without affecting diagnostics.
- **Tester sends:** functional `10 83`, `85 82`, `28 83 01` (or `28 81 01`, or `28 83 03` including NM
  [OEM-specific]); `3E 80` functional every ~2 s; then physical 0x10 02 / 0x27 / download to the target.
  At the end: `11 01` to the target, then functional `28 80 01` (or `28 80 03`), `85 81`, `10 81`.
- **ECU is expected to:** Stop sending the selected messages within a short time and keep answering
  diagnostics; resume them on enableRxAndTx or on return to default.
- **Engineer obtains:** A quiet bus with only diagnostic traffic.
- **Test on success / failure:** Trace shows no application frames from the silenced ECUs; no
  lost-communication DTCs after the flash.

### Use case: Signal-loss reaction test on a HIL bench
- **Scenario:** An airbag control unit consumes vehicle speed and door signals from other ECUs. The team wants
  to see what happens when the airbag ECU itself stops sending its crash and status messages.
- **Engineer's objective:** Verify that receivers (e.g. body controller, telematics) detect the loss and react
  as specified, and that the airbag ECU still answers diagnostics.
- **Why this service:** Physically addressed `28 01 01` stops only that ECU's Tx in a controlled, reversible way.
- **Tester sends:** `10 03`, `28 01 01` physical; later `28 00 01`.
- **ECU is expected to:** Stop transmitting its application messages while still receiving; resume on 28 00.
- **Engineer obtains:** Timing of the receivers' timeout reactions and DTCs.
- **Test on success / failure:** Receivers react within spec. A restraint ECU must not lose crash detection
  because of 0x28; whether 0x28 is even allowed on a restraint ECU is an OEM safety decision [OEM-specific].

## 5. How does it work?

1. Client sends `28 <controlType> <communicationType> [nodeIdentificationNumber]`.
2. Server checks length (depends on controlType), sub-function, session, conditions, then the
   communicationType and node ID values (0x31).
3. Server applies the new Rx/Tx state to the selected message types and sub-network and sends
   `68 <controlType>` (unless SPRMIB).
4. The state stays until another 0x28 request changes it, the session goes back to default (request or S3
   expiry), or the server resets. A change between non-default sessions (e.g. 03 → 02) usually keeps it
   [unverified].

**communicationType byte layout:**

| Bits | Field | Values |
|---|---|---|
| 7–4 | subnet number | 0x0 = all connected networks; 0x1–0xE = the sub-network with that number [OEM-specific numbering]; 0xF = the network on which this request is received |
| 3–2 | reserved | 0 |
| 1–0 | message type | 01 = normal communication messages; 10 = network management messages; 11 = both; 00 = reserved |

So `01` = normal messages on all networks, `03` = normal + NM on all networks, `F1` = normal messages on the
receiving network only, `21` = normal messages on subnet 2.

Source note: the bit positions above follow the udsoncan implementation and the near-universal use of
`28 03 01` / `28 03 03` in flash sequences. The py-uds translator places messagesType in bits 7–6 and the
network number in bits 3–0 (its test vector decodes `0x40` as normal messages, all networks). The two open-source
stacks disagree; this entry keeps the udsoncan layout. Confirm against the ISO annex before relying on it
[unverified].

**Disabling NM messages** affects network wake-up and sleep coordination. Whether the network still stays awake
during flashing depends on the NM implementation (diagnostic activity often keeps nodes awake) [OEM-specific].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Non-default (extended or programming); 0x7F in default | OEM |
| Security / authentication | Usually none | OEM |
| ECU operating conditions | Vehicle stationary; some ECUs refuse while driving functions are active | OEM |
| Timing (P2 / P2* / S3) | Normal P2; S3 must be kept alive with 0x3E or the state is lost | ISO + OEM |

**Depends on:** [0x10](0x10-diagnostic-session-control.md) (session), [0x3E](0x3E-tester-present.md)
(keep-alive), [0x85](0x85-control-dtc-setting.md) (DTC setting off first), functional addressing in
[protocol-fundamentals.md](../protocol-fundamentals.md#functional-vs-physical-addressing).

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x28 |
| 2 | sub-function: SPRMIB (bit 7) + controlType (bits 6–0) | 1 | see table below |
| 3 | communicationType | 1 | see bit layout in section 5 |
| 4–5 | nodeIdentificationNumber | 2 | Only for controlType 0x04 and 0x05; big-endian; OEM-defined node number |

Length: 3 bytes for controlType 00–03; 5 bytes for 04 and 05.

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | enableRxAndTx | Normal reception and transmission | End of flashing or test | Default state |
| 0x01 | enableRxAndDisableTx | Keeps receiving, stops sending | Flashing (non-target ECUs), signal-loss tests | Common choice |
| 0x02 | disableRxAndEnableTx | Stops receiving, keeps sending | Rare; receive-path tests | — |
| 0x03 | disableRxAndTx | Stops both | Flashing | Common choice |
| 0x04 | enableRxAndDisableTxWithEnhancedAddressInformation | As 01, for the node given by nodeIdentificationNumber | Gateway controls one node on a sub-network | Needs bytes 4–5 [edition-dependent] |
| 0x05 | enableRxAndTxWithEnhancedAddressInformation | As 00, for the node given by nodeIdentificationNumber | Re-enable that node | Needs bytes 4–5 [edition-dependent] |
| 0x06–0x3F | reserved | — | — | 0x12 expected |
| 0x40–0x5F | vehicleManufacturerSpecific | OEM control types | — | Meaning from OEM spec only [unverified range] |
| 0x60–0x7E | systemSupplierSpecific | Supplier control types | — | [unverified range] |
| 0x7F | reserved | — | — | 0x12 expected |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | 0x68 |
| 2 | controlType | 1 | Echo of the request, bit 7 = 0 |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | controlType reserved or not implemented |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length not 3 (00–03) or 5 (04/05) |
| 0x22 | conditionsNotCorrect | Vehicle or ECU state blocks the change [OEM-specific] |
| 0x31 | requestOutOfRange | communicationType reserved bits set, message type 00, unknown subnet, or unknown nodeIdentificationNumber |
| 0x7E | subFunctionNotSupportedInActiveSession | controlType not allowed in this session |
| 0x7F | serviceNotSupportedInActiveSession | 0x28 requested in defaultSession |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 10 03                    # physical, extended session
POS 50 03 00 32 01 F4
REQ 28 03 01                 # disableRxAndTx, normal messages, all networks
POS 68 03
REQ 28 00 01                 # enableRxAndTx, normal messages
POS 68 00
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 28 03 | request | disableRxAndTx, SPRMIB = 0 |
| 01 | communicationType | subnet 0 (all), message type 01 = normal messages |
| 68 03 | response | Accepted |
| 28 00 01 → 68 00 | request / response | Normal communication restored |

```uds
NOTE functional flash preparation (CAN IDs OEM-specific)
REQ 10 83                    # extended session, no positive responses
REQ 85 82                    # ControlDTCSetting off, no positive responses
REQ 28 83 03                 # disableRxAndTx, normal + NM messages, no positive responses
REQ 3E 80                    # keep-alive every ~2 s while flashing
NOTE ... download to the target ECU (physical) ...
REQ 28 80 03                 # enableRxAndTx again (functional, SPRMIB)
REQ 85 81                    # DTC setting on
REQ 10 81                    # back to default; this alone would also restore communication
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 28 83 | 0x80 + 0x03 | SPRMIB + disableRxAndTx |
| 03 | communicationType | subnet 0, message types 11 = normal + NM |
| 28 80 03 | 0x80 + 0x00 | SPRMIB + enableRxAndTx, same message types |

```uds
REQ 28 01 F1                 # enableRxAndDisableTx, normal messages, only on the receiving network
POS 68 01
REQ 28 04 01 00 0A           # gateway: stop Tx of node 0x000A on its sub-network (illustrative node)
POS 68 04
REQ 28 05 01 00 0A           # re-enable node 0x000A (illustrative)
POS 68 05
```

| Byte(s) | Value | Meaning |
|---|---|---|
| F1 | communicationType | subnet 0xF (network of this request), normal messages |
| 28 04 | request | enableRxAndDisableTxWithEnhancedAddressInformation |
| 01 | communicationType | Normal messages |
| 00 0A | nodeIdentificationNumber | Node 0x000A (illustrative, OEM-defined) |
| 68 04 / 68 05 | response | Accepted |

```uds
REQ 28 03 01                 # in defaultSession
NEG 7F 28 7F
REQ 28 03                    # communicationType missing
NEG 7F 28 13
REQ 28 04 01                 # nodeIdentificationNumber missing
NEG 7F 28 13
REQ 28 03 00                 # message type 00 is reserved
NEG 7F 28 31
REQ 28 06 01                 # reserved controlType
NEG 7F 28 12
```

| Request | Response | Why |
|---|---|---|
| 28 03 01 | 7F 28 7F | Default session |
| 28 03 | 7F 28 13 | Length 2, needs 3 |
| 28 04 01 | 7F 28 13 | Length 3, 04 needs 5 |
| 28 03 00 | 7F 28 31 | Invalid communicationType |
| 28 06 01 | 7F 28 12 | Reserved controlType |

## 7. Implementation and testing

**Implementation:**

- Request builder: controlType, message-type flags (normal / NM), subnet (0–0xF), optional node ID; enforce
  node ID presence exactly for 04/05; build communicationType as `(subnet << 4) | (nm << 1) | normal`
  (udsoncan layout). Also accept a raw communicationType byte, so a project can follow its OEM spec if that
  spec uses another bit order.
- Parser: length 2, echo check.
- Tester state: track per ECU (or per functional group) which types are disabled; restore them in a
  `finally`-style cleanup at the end of every flash or test, even after errors.
- Order: ControlDTCSetting off **before** disabling communication; communication on **before** DTC setting on
  [OEM-specific but common].
- Keep TesterPresent running functionally; losing the session silently re-enables communication.
- Edge cases: gateways that forward functional 0x28 to sub-networks; subnet numbers mapping; ECUs that need
  a few hundred ms before they really stop sending [OEM-specific]; NM disabled → network may sleep after the
  session ends.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path 00–03 | Each controlType with 01 | 68 xx; trace shows the selected Rx/Tx state |
| 2 | Message types | communicationType 01, 02, 03 | Only the selected message types stop |
| 3 | Subnets | 0x01, 0xF1, unknown subnet | Per spec; unknown → 7F 28 31 |
| 4 | Node ID variants | 04 / 05 with valid and unknown node ID | 68 04 / 68 05; unknown → 7F 28 31 |
| 5 | Diagnostics stay up | 28 03 03, then 22 F1 90 | Diagnostic response still sent |
| 6 | Rx really disabled | 28 02 01 or 28 03 01; send a signal the ECU uses | ECU ignores it (e.g. timeout DTC if DTC setting on) |
| 7 | Reserved values | 28 06 01, 28 3F 01, 28 7F 01 | 7F 28 12 |
| 8 | Invalid communicationType | 00 (message type 00), 0D (reserved bits 3–2 set) | 7F 28 31 |
| 9 | Length min-1 | 28 03 | 7F 28 13 |
| 10 | Length min / max | 28 03 01; 28 04 01 00 0A | Positive |
| 11 | Length max+1 | 28 03 01 00; 28 04 01 00 0A 00 | 7F 28 13 |
| 12 | Session matrix | 28 03 01 in 01 / 02 / 03 / 04 | 7F 28 7F in default; others per spec |
| 13 | Security matrix | Locked vs unlocked | Normally no difference; per spec |
| 14 | Restore on default | 28 03 01, then 10 01 | Normal traffic resumes |
| 15 | Restore on S3 | 28 03 01, silence > S3 | Normal traffic resumes |
| 16 | Restore on reset | 28 03 01, 11 01 | Normal traffic after start-up |
| 17 | Kept 03 → 02 | 28 03 01 in 03, then 10 02 | Still silent [unverified] |
| 18 | SPRMIB | 28 83 01 | No response; traffic stops |
| 19 | SPRMIB with error | 28 83 00 physical | 7F 28 31 still sent |
| 20 | Functional | 28 83 01 functional | All supporting ECUs stop; none answer |
| 21 | Functional unsupported | 28 86 01 functional | No response (0x12 suppressed) |
| 22 | Response pending | — | Not expected |
| 23 | Multi-frame | — | Not applicable: single frames |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.5 (preview TOC). communicationType layout in an ISO annex (not checked against ISO text). |
| Edition differences | controlTypes 04/05 with nodeIdentificationNumber reported as introduced in 2013 (udsoncan docs) [edition-dependent]; 2006-based ECUs may not support them. No 2013 ↔ 2020 change known [unverified]. ISO 14229-1:2026 not yet reviewed. |
| OEM / ECU-specific | Allowed sessions; which controlType / communicationType the flash sequence uses; subnet numbering; node IDs; whether NM is disabled; whether restraint ECUs accept 0x28 at all. |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: clause number (ISO 2020 preview TOC); controlType 00–05 names, node ID only for 04/05, 2-byte node ID, echo-only response (udsoncan docs, py-uds translator source); message type values 0–3 and subnet 0x0 = all connected networks / 0xF = receiving network (py-uds); bit 0 normal / bit 1 NM / bits 7–4 subnet (udsoncan source). py-uds uses a different bit order — see section 5. OEM / supplier ranges from engineering knowledge. |
| Open questions | Bit order of communicationType (udsoncan vs py-uds disagree; check ISO annex); whether the state survives non-default → non-default transitions; whether 0x31 or 0x13 is required when node ID is sent with controlType 00–03. |
