---
sid: 0x27
name: SecurityAccess
response_sid: 0x67
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.4 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (standards.iteh.ai sample 72439): clause 10.4; Authentication added in 2020"
  - "udsoncan documentation (udsoncan.readthedocs.io): odd = requestSeed, even = sendKey; securityAccessDataRecord optional; seed only in requestSeed response"
  - "py-uds knowledge base (uds.readthedocs.io): SID 0x27 / RSID 0x67; states page: unlocked level cleared on session change or reset"
  - "py-uds translator source (github.com/mdabrowski1990/uds, utilities/constants/subfunctions.py): securityAccessType pairs 0x01-0x42, 0x5F/0x60 end of life (ISO 26021-2), supplier pairs 0x61-0x7E"
---

# 0x27 — SecurityAccess

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x67
> Unlocks a security level with a seed-and-key challenge so that protected services become available.

## 1. What is it?

SecurityAccess (SID 0x27) is a challenge-response unlock. The client asks for a seed with an odd sub-function.
The server returns a random seed. The client computes a key from the seed with a secret algorithm and sends it
with the next even sub-function. If the key matches, the server unlocks that security level. Each odd/even pair
is one security level: 01/02, 03/04, and so on. The algorithm, the seed and key lengths and the meaning of each
level are defined by the vehicle manufacturer, never by ISO.

This entry uses illustrative seeds and keys only. No example key is computed from its seed by any real
algorithm.

## 2. Why is it needed?

- Writing VIN or coding, flashing, IO overrides, calibration and deployment functions can damage the vehicle or
  defeat safety and emission functions. They must not be reachable by anyone who just knows UDS.
- A session alone is not protection: any tester can send `10 03`.
- Seed-and-key gives a cheap per-ECU unlock that works on small microcontrollers without PKI.
- Attempt counting and delay timers slow down brute-force attacks.

Who gets value: OEMs (protect functions), flash tools and EOL stations (they hold the algorithm or a security
DLL/HSM), workshops (online unlock via OEM backend), validation teams (security and lockout tests).

## 3. What is its purpose?

It changes the security state of the server from locked to one unlocked level. It returns a seed and accepts
or rejects a key. It does not open any service by itself: the OEM access matrix says which services, DIDs and
routines need which level in which session. It does not encrypt or authenticate later messages.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| ECU uses certificate-based access (2020 onwards) | 0x29 Authentication | ECU answers 0x34 authenticationRequired instead of accepting 0x27 [OEM-specific] |
| Messages must be protected end-to-end | 0x84 SecuredDataTransmission | 0x27 unlocks; it does not protect the data that follows |
| Service only needs a session | [0x10](0x10-diagnostic-session-control.md) | Do not unlock more than the task needs |
| Check whether already unlocked | `27 <odd>` and look for a zero seed | Seed of all 0x00 means "this level is already unlocked" |

## 4. When is it used? — Real use cases

### Use case: Unlocking the bootloader before flashing
- **Scenario:** Reflash of an ECU in programmingSession.
- **Engineer's objective:** Get access to erase and download services.
- **Why this service:** The bootloader rejects 0x31 erase and 0x34 with `7F xx 33` until the programming level
  is unlocked.
- **Tester sends:** `10 02`, then `27 <odd level>` → seed, key from the OEM security DLL or HSM, `27 <even level> <key>`.
- **ECU is expected to:** Return a fresh non-zero seed; accept the correct key with `67 <even>`.
- **Engineer obtains:** Unlocked programming level for the rest of the session.
- **Test on success / failure:** Success: erase routine accepted. Failure: `7F 27 35` (wrong algorithm or byte
  order), `7F 27 37` (delay timer after power-up still running).

### Use case: Lockout and delay-timer validation (HIL)
- **Scenario:** Security requirement test of a restraint control unit on a HIL bench.
- **Engineer's objective:** Prove that brute force is limited: N wrong keys cause lockout; lockout lasts the
  specified time; a reset or power cycle does not clear it.
- **Why this service:** The attempt counter and delay timer belong to 0x27.
- **Tester sends:** `10 03`; then repeated `27 01` / `27 02 <wrong key>`; then `27 01` during the delay; then
  power cycle and `27 01` again.
- **ECU is expected to:** `7F 27 35` for each wrong key below the limit; `7F 27 36` at the limit; `7F 27 37` to
  seed requests while the delay runs, including after a power cycle [OEM-specific].
- **Engineer obtains:** Measured attempt limit and delay time.
- **Test on success / failure:** Limit or delay different from the OEM security spec, or lockout cleared by a
  reset, is a defect.

### Use case: EOL coding in extended session
- **Scenario:** Production line writes variant coding and VIN.
- **Engineer's objective:** Unlock the coding level, write, verify, re-lock.
- **Why this service:** 0x2E on the coding DIDs needs the level [OEM-specific].
- **Tester sends:** `10 03`, `27 <odd>`, `27 <even> <key>`, writes, `10 01` (re-locks).
- **ECU is expected to:** Accept the writes only while unlocked.
- **Engineer obtains:** Coded ECU; the station's log shows each unlock.
- **Test on success / failure:** Write after `10 01` must fail with `7F 2E 33` or `7F 2E 7F`.

## 5. How does it work?

1. Client sends `27 <odd>` with an optional securityAccessDataRecord.
2. Server checks length, sub-function, session (0x7E / 0x7F), conditions (0x22), delay timer (0x37).
3. If the level is locked, the server generates a seed, stores it, and returns `67 <odd> <seed>`.
   If the level is already unlocked, it returns a seed with all bytes 0x00 (normally of the usual seed length
   [unverified]). This rule is from engineering knowledge; no public source was checked.
4. Client sends `27 <odd + 1> <key>`.
5. Server checks that this follows a seed request for the same level (0x24 otherwise) and compares the key.
   - Match: level unlocked, attempt counter cleared [unverified: some ECUs clear only on reset], `67 <even>`.
   - Mismatch: attempt counter + 1; `7F 27 35`; the seed is invalid and a new requestSeed is needed
     [unverified].
   - Mismatch that reaches the limit: `7F 27 36`; delay timer starts.
6. While the delay timer runs, requestSeed gets `7F 27 37`.

**Rules worth knowing** (engineering knowledge; check the edition and OEM spec):

| Rule | Detail |
|---|---|
| One level at a time | Commonly implemented as one active level; unlocking another replaces it [unverified]. The py-uds knowledge base says a client may unlock "one or more" levels, so do not hard-code either model |
| Session change | Any session change and S3 expiry re-lock the server (py-uds states page). Whether `10 03` while already in 03 counts as a change is [unverified]; most stacks re-lock |
| Reset | 0x11 or power cycle re-locks |
| Default session | Commonly listed as available in non-default sessions only; expect 0x7F in defaultSession [unverified] |
| Power-up delay | Many ECUs start the delay timer at power-up, or only if a lockout was active before [OEM-specific] |
| Counter in NVM | Attempt counter often kept in NVM so a power cycle does not reset it [OEM-specific] |
| Seed quality | New random seed per request; never constant, never predictable |
| Repeated requestSeed | Same seed or new seed: OEM choice [OEM-specific] |

**Relation to Authentication (0x29, new in 2020).** The 2020 edition adds certificate-based authentication.
An ECU may support 0x27 only, 0x29 only, or both with different rights. A server that needs authentication
rejects protected requests with 0x34 authenticationRequired instead of 0x33. Where both exist, the OEM spec
says which one guards which function.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Non-default session; each level tied to one or more sessions | OEM |
| Security / authentication | Not applicable (this service sets it); some ECUs need 0x29 first | OEM |
| ECU operating conditions | Vehicle stationary, voltage in range for programming levels | OEM |
| Timing (P2 / P2* / S3) | Normal P2; key calculation in an HSM may need 0x78 on the server side | ISO + OEM |

**Depends on:** [0x10](0x10-diagnostic-session-control.md) for the session; [0x3E](0x3E-tester-present.md) to stay
in session (losing the session re-locks); ISO-TP multi-frame for long seeds or keys; security DLL, HSM or
backend on the tester side.

## 6. Request and response formats

### Request

**requestSeed (odd sub-function):**

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x27 |
| 2 | sub-function: SPRMIB (bit 7) + securityAccessType (odd) | 1 | 0x01, 0x03, … |
| 3…n | securityAccessDataRecord | 0…n | Optional; OEM-defined (e.g. tester or session identifier) |

**sendKey (even sub-function):**

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x27 |
| 2 | sub-function: SPRMIB (bit 7) + securityAccessType (even) | 1 | requestSeed value + 1 |
| 3…n | securityKey | OEM | Result of the OEM algorithm |

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | reserved | — | — | 0x12 expected |
| 0x01, 0x03 … 0x41 (odd) | requestSeed | Returns a seed for level (n + 1) / 2 | Start of an unlock | Pairs with n + 1 |
| 0x02, 0x04 … 0x42 (even) | sendKey | Sends the key for level n / 2 | Finish an unlock | Must follow its odd value |
| 0x43–0x5E | reserved | — | — | 0x12 expected |
| 0x5F / 0x60 | requestSeed / sendKey for ISO 26021-2 | End-of-life security level | Restraint ECUs | Identifier only; any procedure is defined in ISO 26021-2, not here |
| 0x61–0x7E | systemSupplierSpecific | Supplier levels (odd/even pairs 61/62 … 7D/7E) | Supplier development | Usually disabled in series |
| 0x7F | reserved | — | — | 0x12 expected |

Ranges cross-checked against the py-uds translator source (2026-10-26).

Which levels exist and what they unlock is OEM-specific. Do not assume 01/02 means "extended" or that a
programming level uses a particular pair.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | 0x67 |
| 2 | securityAccessType | 1 | Echo of the request, bit 7 = 0 |
| 3…n | securitySeed | OEM | requestSeed only: random seed; all 0x00 = level already unlocked. Absent for sendKey |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Level not implemented |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Key length wrong; missing key; record length invalid |
| 0x22 | conditionsNotCorrect | Vehicle state blocks unlock (speed, voltage) [OEM-specific] |
| 0x24 | requestSequenceError | sendKey without a preceding requestSeed of the same level; key for a different level than the seed |
| 0x31 | requestOutOfRange | securityAccessDataRecord content not accepted [unverified] |
| 0x34 | authenticationRequired | ECU requires 0x29 before 0x27 (2020) [OEM-specific] |
| 0x35 | invalidKey | Key does not match; attempt counter incremented |
| 0x36 | exceedNumberOfAttempts | Wrong key that reached the attempt limit; delay timer started |
| 0x37 | requiredTimeDelayNotExpired | requestSeed while the delay timer runs (after lockout or power-up) |
| 0x7E | subFunctionNotSupportedInActiveSession | Level not available in the active session |
| 0x7F | serviceNotSupportedInActiveSession | 0x27 not available in the active session (typically default) |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

All seeds and keys below are (illustrative). They are not related by any algorithm.

```uds
REQ 10 03                    # extendedDiagnosticSession
POS 50 03 00 32 01 F4
REQ 27 01                    # requestSeed, level 1
POS 67 01 3A 7C 91 E4        # seed (illustrative, 4 bytes)
REQ 27 02 5B 02 C8 1F        # sendKey, key (illustrative)
POS 67 02                    # level 1 unlocked
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 27 01 | request | requestSeed for level 1 |
| 67 01 | RSID + echo | Seed follows |
| 3A 7C 91 E4 | seed | Random, OEM length (illustrative) |
| 27 02 | request | sendKey for level 1 |
| 5B 02 C8 1F | key | Tester result (illustrative) |
| 67 02 | RSID + echo | Unlocked; no data |

```uds
REQ 27 01                    # requestSeed again while level 1 is unlocked
POS 67 01 00 00 00 00        # zero seed: already unlocked, no key needed
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 67 01 | RSID + echo | Seed response |
| 00 00 00 00 | zero seed | Level already unlocked; seed length unchanged |

```uds
REQ 27 01
POS 67 01 9E 21 5D 07        # seed (illustrative)
REQ 27 02 11 22 33 44        # wrong key (illustrative), attempt 1
NEG 7F 27 35                 # invalidKey
REQ 27 01
POS 67 01 C4 88 0B 6A        # new seed (illustrative)
REQ 27 02 11 22 33 44        # wrong key, attempt reaches limit (limit OEM-specific)
NEG 7F 27 36                 # exceedNumberOfAttempts, delay timer starts
REQ 27 01                    # during delay
NEG 7F 27 37                 # requiredTimeDelayNotExpired
```

| Request | Response | Meaning |
|---|---|---|
| 27 02 + wrong key | 7F 27 35 | Counter + 1; new seed needed |
| 27 02 + wrong key at limit | 7F 27 36 | Lockout; delay timer starts (duration OEM-specific, e.g. 10 s illustrative) |
| 27 01 during delay | 7F 27 37 | No seed until the timer expires |

```uds
REQ 27 02 5B 02 C8 1F        # sendKey without a prior requestSeed
NEG 7F 27 24                 # requestSequenceError
REQ 27 01                    # in defaultSession
NEG 7F 27 7F                 # service not supported in active session (typical)
REQ 27 05                    # level 3 not implemented
NEG 7F 27 12
REQ 27 02 5B 02              # key too short (expected 4 bytes, illustrative)
NEG 7F 27 13
```

| Request | Response | Why |
|---|---|---|
| 27 02 … | 7F 27 24 | No outstanding seed for level 1 |
| 27 01 | 7F 27 7F | Default session |
| 27 05 | 7F 27 12 | Level not implemented |
| 27 02 5B 02 | 7F 27 13 | Key length wrong; some ECUs count this as a failed attempt [OEM-specific] |

```uds
REQ 27 01                    # requestSeed on an ECU that requires Authentication first (2020)
NEG 7F 27 34                 # authenticationRequired (OEM-specific behaviour)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 7F 27 34 | NRC 0x34 | Authenticate with 0x29 before using 0x27 |

## 7. Implementation and testing

**Implementation:**

- Request builder: level number → odd and even sub-function (2n − 1, 2n); optional data record; key bytes from
  an injected key provider (security DLL, HSM client, backend call, or a test stub). Never hard-code or log a
  production algorithm or secret.
- Parser: check echo; seed length per ECU config; detect zero seed and skip sendKey.
- State: track unlocked level; clear it on any 0x10, 0x11, S3 expiry, or `7F xx 33` seen later.
- Errors: on 0x35 request a new seed before retrying; on 0x36 / 0x37 wait the configured delay, do not hammer
  the ECU; never retry automatically past the limit (it extends lockout on some ECUs).
- Edge cases: seed or key longer than 7 bytes needs ISO-TP multi-frame; byte order of the key; ECUs that also
  count requestSeed as an attempt; HSM-based ECUs that answer requestSeed with 0x78.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path per level | 27 odd → 27 even + correct key | 67 odd + seed; 67 even |
| 2 | Seed randomness | 100 × requestSeed (after re-lock) | No repeats, no visible pattern |
| 3 | Zero seed | requestSeed while unlocked | 67 odd + all 0x00, normal length |
| 4 | Invalid key | Wrong key | 7F 27 35 |
| 5 | Attempt limit | Wrong keys up to the limit | 7F 27 36 at limit |
| 6 | Delay timer | requestSeed during delay; after delay | 7F 27 37; then seed |
| 7 | Lockout across reset | Limit reached, 11 01 or power cycle, requestSeed | 7F 27 37 if spec says so |
| 8 | Power-up delay | requestSeed right after power-up | Per OEM spec (0x37 or seed) |
| 9 | Sequence | sendKey first; sendKey for level 2 after seed for level 1 | 7F 27 24 |
| 10 | Seed reuse | Correct key for an old seed after a new seed was issued | 7F 27 35 or 24 |
| 11 | Session matrix | 27 01 in 01 / 02 / 03 / 04 | Per spec; 7F 27 7F or 7E elsewhere |
| 12 | Re-lock on session change | Unlock, 10 03, protected service | 7F xx 33 |
| 13 | Re-lock on S3 | Unlock, silence > S3, protected service | 7F xx 7F or 33 |
| 14 | Authentication interplay | 27 01 before / after 0x29 on a 2020 ECU | Per spec; 0x34 when required |
| 15 | Length min-1 | 27 | 7F 27 13 |
| 16 | Length requestSeed | 27 01 (min); 27 01 + max record; max + 1 | Positive; positive; 7F 27 13 |
| 17 | Length sendKey | key length − 1, exact, + 1 | 7F 27 13; positive; 7F 27 13 |
| 18 | Reserved values | 27 00, 27 43, 27 7F | 7F 27 12 |
| 19 | SPRMIB on sendKey | 27 82 + correct key | No response; protected service now accepted |
| 20 | SPRMIB on requestSeed | 27 81 | Per spec; seed cannot be delivered [unverified] |
| 21 | Functional | 27 01 functional | Not supported by most OEMs; no response or per spec |
| 22 | Multi-frame | Seed or key > 7 bytes on classical CAN | FF / FC / CF correct both ways |
| 23 | Response pending | HSM-based seed generation | 0x78 then 67 odd within P2* |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.4 (preview TOC). Authentication 0x29: clause 10.6. ISO 26021-2 for the deployment levels. |
| Edition differences | 2020 adds Authentication (0x29) and NRC 0x34 (cross-checked: Foreword lists Authentication as new). No change to the 0x27 message layout is known [unverified]. ISO 14229-1:2026 not yet reviewed. |
| OEM / ECU-specific | Levels and what they unlock; algorithm; seed/key length; data record content; attempt limit; delay time; power-up delay; NVM storage of the counter; repeated-seed behaviour. |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: clause number and Authentication new in 2020 (ISO 2020 preview); odd = requestSeed / even = sendKey, optional securityAccessDataRecord, seed only in the requestSeed response (udsoncan docs); full sub-function map 0x01–0x42 pairs, 0x43–0x5E reserved, 0x5F/0x60 ISO 26021-2, 0x61–0x7E supplier (py-uds translator source); re-lock on session change / reset (py-uds states page). Zero-seed rule, attempt counter and delay behaviour and NRC triggers are engineering knowledge, not checked against a public source. |
| Open questions | Whether one-level-at-a-time is mandatory; whether a correct key clears the attempt counter; ISO rule for SPRMIB on requestSeed; whether 0x37 also applies to sendKey; whether a same-session 0x10 request re-locks. |
