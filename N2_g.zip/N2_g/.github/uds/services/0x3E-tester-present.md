---
sid: 0x3E
name: TesterPresent
response_sid: 0x7E
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.7 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (standards.iteh.ai sample 72439): clause 10.7"
  - "py-uds knowledge base (uds.readthedocs.io): SID 0x3E / RSID 0x7E, purpose (client still connected)"
  - "py-uds translator source (github.com/mdabrowski1990/uds): request and response = sub-function byte only; single zeroSubFunction value"
  - "udsoncan documentation (udsoncan.readthedocs.io): sub-function always 0x00, echo 0x00"
---

# 0x3E — TesterPresent

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x7E
> Tells one or more servers that a tester is still connected, so non-default sessions do not time out.

## 1. What is it?

TesterPresent (SID 0x3E) is the keep-alive of UDS. It carries no data and changes nothing. Its only effect is
that the server sees a diagnostic request and restarts its S3server timer. The only defined sub-function value
is 0x00 (zeroSubFunction). In practice it is almost always sent as `3E 80`: zeroSubFunction with the
suppressPosRspMsgIndicationBit set, so the server does not answer.

## 2. Why is it needed?

- Every non-default session ends on its own if the server sees no request for S3server (commonly 5000 ms).
  Long operations on the tester side (waiting for a user, computing a key, preparing a flash block, running a
  long HIL step) would otherwise lose the session, the security unlock and all temporary states.
- During flashing, all other ECUs were put into extended session with communication and DTC setting disabled.
  They must be kept there for the whole download, without sending them real requests.
- It is cheap: two bytes, no state change, works functionally.

Who gets value: every tester and flash tool, HIL test frameworks (background keep-alive task), gateways.

## 3. What is its purpose?

It keeps the active session and everything tied to it (security level, 0x28 / 0x85 states, IO control) alive.
It can also be used as a harmless "are you there?" ping with `3E 00`. It does not enter a session, does not
extend P2 / P2*, does not keep an ECU or the network awake on its own (that is NM), and has no effect in
defaultSession apart from the answer.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Server is answering a long request with 0x78 | Nothing — wait | 0x78 keeps the client waiting; S3 is not running while a request is in progress [unverified wording] |
| Find the active session | 0x22 DID 0xF186 | 3E 00 says only "alive" |
| Stop the network from sleeping | NM / ignition | TesterPresent is not an NM message [OEM-specific: some NM stacks treat diagnostic activity as a wake reason] |
| Re-enter a session after it was lost | [0x10](0x10-diagnostic-session-control.md) | 0x3E cannot restore a lost session |

## 4. When is it used? — Real use cases

### Use case: Functional keep-alive during network flashing
- **Scenario:** Reflash of one ECU; all other ECUs silenced with 0x85 / 0x28 in extended session.
- **Engineer's objective:** Keep every ECU in its non-default session for the full download (minutes).
- **Why this service:** One functional `3E 80` frame keeps all ECUs alive without any responses on the bus.
- **Tester sends:** `3E 80` on the functional ID every ~2000 ms, from the moment `10 83` is sent until the
  final `10 81`.
- **ECU is expected to:** Restart S3 on each frame; send nothing.
- **Engineer obtains:** No ECU drops back to default (which would silently re-enable communication and DTC
  setting).
- **Test on success / failure:** Trace: no application frames from silenced ECUs for the whole flash; no
  lost-communication DTCs afterwards.

### Use case: Long HIL test step in extended session
- **Scenario:** Crash-pulse injection on an airbag ECU HIL bench. Squib outputs go to squib simulators. The
  test framework holds extended session with a security unlock while the simulator runs a 30 s scenario.
- **Engineer's objective:** Read deployment-related DIDs and DTCs right after the scenario without re-unlocking.
- **Why this service:** The scenario takes longer than S3; a background `3E 80` keeps the unlocked session.
- **Tester sends:** `3E 80` physical every 2 s from a background task.
- **ECU is expected to:** Stay in extended session, unlocked.
- **Engineer obtains:** Post-crash data read in the same session.
- **Test on success / failure:** `22 F1 86` → 03 after the scenario; protected reads succeed.

### Use case: S3 timeout validation
- **Scenario:** Validation of the session timeout requirement.
- **Engineer's objective:** Measure S3server and prove that TesterPresent restarts it.
- **Why this service:** It is the cleanest stimulus that restarts S3 without other side effects.
- **Tester sends:** `10 03`, then `3E 80` with growing gaps (e.g. 4.5 s, 5.5 s).
- **ECU is expected to:** Stay in session below S3server, fall back above it.
- **Engineer obtains:** S3server with its tolerance.
- **Test on success / failure:** Fallback time outside the spec tolerance is a defect.

## 5. How does it work?

1. Client sends `3E 00` or `3E 80`, physical or functional.
2. Server checks length (0x13) and sub-function (0x12). 0x3E is accepted in every session.
3. Server restarts S3server (in non-default sessions) and sends `7E 00`, or nothing if SPRMIB is set.
4. Any other completed diagnostic request also restarts S3. TesterPresent is needed only when the tester has
   nothing else to send.

**S3 rules** (details in [protocol-fundamentals.md](../protocol-fundamentals.md#timing)):

| Item | Typical value | Note |
|---|---|---|
| S3server | 5000 ms | Fixed by ISO 14229-2 in many projects; check OEM spec [unverified] |
| TesterPresent period | ~2000 ms | Must stay safely below S3server, allowing for tester jitter and bus load |
| Effect in defaultSession | none (no S3) | Answer only |

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | All sessions | ISO |
| Security / authentication | None | ISO |
| ECU operating conditions | None | ISO |
| Timing (P2 / P2* / S3) | Answer within P2server_max; restarts S3 | ISO 14229-2 |

**Depends on:** S3 handling in the server's session layer; on DoCAN a functional request ID; on DoIP the TCP
connection and routing activation. DoIP alive check (0x0007 / 0x0008) is a separate transport mechanism, not
a replacement.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x3E |
| 2 | sub-function: SPRMIB (bit 7) + zeroSubFunction (bits 6–0) | 1 | 0x00 or 0x80 |

Total length is exactly 2 bytes.

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | zeroSubFunction | Keep-alive; positive response expected | Ping, physical check that an ECU is alive | Response `7E 00` |
| 0x80 | zeroSubFunction + SPRMIB | Keep-alive, no positive response | Periodic keep-alive, functional broadcast | Most common form |
| 0x01–0x7F | reserved | — | — | 0x12 expected (with SPRMIB: 0x81–0xFF) |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | 0x7E |
| 2 | zeroSubFunction | 1 | 0x00 |

Parser pitfall: 0x7E is both this service's response SID and the NRC value
subFunctionNotSupportedInActiveSession. They cannot be confused if the parser checks byte 1 first: a positive
response starts with 0x7E, an NRC only ever appears as byte 3 of `7F <SID> 7E`.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Sub-function other than 0x00 (after masking SPRMIB) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request is not exactly 2 bytes |

0x7E and 0x7F must not occur: the service is available in every session. With functional addressing 0x12 is
suppressed. Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 3E 00                    # physical ping
POS 7E 00                    # server alive
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 3E | SID | TesterPresent |
| 00 | sub-function | zeroSubFunction, SPRMIB = 0 |
| 7E | RSID | 0x3E + 0x40 |
| 00 | echo | zeroSubFunction |

```uds
REQ 10 83                    # functional: all ECUs to extended session, no responses
REQ 3E 80                    # functional keep-alive, t = 2.0 s
REQ 3E 80                    # t = 4.0 s
REQ 3E 80                    # t = 6.0 s (period illustrative, must stay below S3server)
NOTE no ECU answers; each frame restarts S3server in every ECU
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 3E 80 | 0x80 + 0x00 | zeroSubFunction with SPRMIB |
| (none) | — | No response is a pass, not a timeout |

```uds
CAN 7DF  02 3E 80 CC CC CC CC CC    # functional single frame on DoCAN (ID and padding illustrative)
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 7DF | CAN ID | Functional request ID (illustrative, OEM-defined) |
| 02 | ISO-TP PCI | Single frame, 2 data bytes |
| 3E 80 | UDS | TesterPresent, SPRMIB |
| CC … | padding | OEM padding byte (illustrative) |

```uds
REQ 3E 01                    # reserved sub-function, physical
NEG 7F 3E 12
REQ 3E                       # too short
NEG 7F 3E 13
REQ 3E 00 00                 # too long
NEG 7F 3E 13
REQ 3E 81                    # reserved sub-function with SPRMIB, physical
NEG 7F 3E 12                 # negative responses are not suppressed by SPRMIB
```

| Request | Response | Why |
|---|---|---|
| 3E 01 | 7F 3E 12 | Only 0x00 is defined |
| 3E | 7F 3E 13 | Missing sub-function |
| 3E 00 00 | 7F 3E 13 | Length 3 |
| 3E 81 | 7F 3E 12 | SPRMIB suppresses positive responses only |

```uds
REQ 10 03
POS 50 03 00 32 01 F4
NOTE no traffic for 6 s (> S3server)
REQ 3E 00                    # too late: session already back to default
POS 7E 00                    # still answers; the session is NOT restored
REQ 22 F1 86
POS 62 F1 86 01              # defaultSession
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 7E 00 | response | TesterPresent works in every session |
| 62 F1 86 01 | DID 0xF186 | Session was lost before the keep-alive arrived |

## 7. Implementation and testing

**Implementation:**

- Run TesterPresent as a background scheduler per channel (physical per ECU, or one functional), started on
  entering a non-default session and stopped on return to default or reset.
- Default form `3E 80`; offer `3E 00` for alive checks. Make the period configurable (default 2000 ms) and
  check it is below the configured S3server minus a margin.
- Do not send TesterPresent while waiting for a response to another request on the same channel: on DoCAN it
  can collide with an ongoing multi-frame transfer, and some servers answer 0x21 busy [unverified]. Many tools
  pause the scheduler during a request and restart the period afterwards.
- Do not treat "no response" to `3E 80` as an error; do treat a NEG as one.
- Edge cases: period drift on a loaded Windows tester; gateways that need their own TesterPresent per
  sub-network [OEM-specific]; a scheduler that keeps running after the ECU reset (harmless but misleading).

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path | 3E 00 physical in each session | 7E 00 |
| 2 | SPRMIB | 3E 80 physical | No response |
| 3 | Keep-alive works | 10 03, then 3E 80 every 2 s for 60 s | 22 F1 86 → 03 at the end |
| 4 | Security kept | Unlock, keep-alive 60 s, protected service | Accepted (no 7F xx 33) |
| 5 | S3 boundary below | Gap S3server − 10 % | Session kept |
| 6 | S3 boundary above | Gap S3server + 10 % | Back to default; security locked |
| 7 | Late keep-alive | 3E 00 after S3 expiry | 7E 00; session stays default |
| 8 | Reserved sub-functions | 3E 01, 3E 7F | 7F 3E 12 |
| 9 | SPRMIB with error | 3E 81 physical | 7F 3E 12 |
| 10 | Length min-1 | 3E | 7F 3E 13 |
| 11 | Length min = max | 3E 00 | Positive |
| 12 | Length max+1 | 3E 00 00 | 7F 3E 13 |
| 13 | Session matrix | 3E 00 in 01 / 02 / 03 / 04 / OEM sessions | 7E 00 everywhere; never 7F / 7E NRC |
| 14 | Security matrix | Locked vs unlocked | Same behaviour |
| 15 | Functional | 3E 80 functional during flash | No responses; all ECUs stay in session |
| 16 | Functional without SPRMIB | 3E 00 functional | One 7E 00 per supporting ECU |
| 17 | Functional reserved | 3E 01 functional | No response (0x12 suppressed) |
| 18 | Interleaving | 3E 80 during a long 0x78 sequence of another service | No disturbance of the pending request [unverified] |
| 19 | Response pending | — | Not expected for 0x3E |
| 20 | Multi-frame | — | Not applicable: single frames |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.7 (preview TOC). S3 timing: ISO 14229-2. |
| Edition differences | None known for 0x3E between 2013 and 2020 [unverified]. ISO 14229-1:2026 not yet reviewed. |
| OEM / ECU-specific | S3server value; tester period; physical vs functional keep-alive; gateway forwarding; whether NM treats diagnostic activity as a reason to stay awake. |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: clause number (ISO 2020 preview TOC); SID 0x3E / RSID 0x7E and purpose (py-uds knowledge base); request and response contain only the sub-function byte, only value 0x00 (py-uds translator source, udsoncan docs). S3 values, period and interleaving behaviour from engineering knowledge. |
| Open questions | Whether S3 is stopped or only restarted while a request is in progress; ISO rule for TesterPresent received during a pending request; S3server value in ISO 14229-2 vs OEM override. |
