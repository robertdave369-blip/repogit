---
sid: 0x24
name: ReadScalingDataByIdentifier
response_sid: 0x64
has_sub_function: false
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.4 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number and functional unit"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x24, response SID 0x64; scaling data may carry type, formula/coefficients and unit"
  - "py-uds source (github.com/mdabrowski1990/uds: constants/other.py SCALING_BYTE_TYPE_MAPPING, EXPONENT/MANTISSA_BIT_LENGTH; translator/service_definitions/read_scaling_data_by_identifier.py; data_record_definitions/formula.py get_scaling_byte_extension): single-DID request, type codes 0x0-0xB, which types carry an extension (reviewer, 2026-10-26)"
  - "ISO 14229-1:2013 preview TOC (webstore.ansi.org): Annex C.2 scalingByte, C.3 scalingByteExtension (reviewer, 2026-10-26)"
---

# 0x24 — ReadScalingDataByIdentifier

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x64
> Asks the ECU to describe how the data record of one DID is encoded: data type, length, formula, unit.

## 1. What is it?

ReadScalingDataByIdentifier, SID 0x24, returns metadata about a DID instead of its value. For one DID, the
ECU answers with a sequence of **scalingByte** entries. Each describes one part of the DID's data record:
its data type and its length. Some types are followed by a **scalingByteExtension**, which carries extra
detail such as a conversion formula with coefficients, a physical unit, or a bit mask.

The idea is that a generic tester could display a DID in physical units without an ODX/CDD file.

## 2. Why is it needed?

- A tester without the ECU's description file can still learn how to decode a DID.
- The ECU becomes self-describing for the DIDs it chooses to cover.
- Useful for generic or scan tools that meet many unknown ECUs.

**In practice it is rarely used.** OEMs and suppliers ship ODX/CDD/A2L data with every software release, and
testers read scaling from there. Many ECUs do not implement 0x24 at all, and those that do often cover only
a few DIDs. Expect `7F 24 11` on a typical body or chassis ECU. Treat any 0x24 support as OEM-specific
[OEM-specific].

## 3. What is its purpose?

Self-description of DID encoding. It returns no measurement value and changes nothing. It does not tell the
tester which DIDs exist, nor their session or security rules.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Need the value itself | [0x22 ReadDataByIdentifier](0x22-read-data-by-identifier.md) | 0x24 returns encoding only |
| ODX/CDD/A2L for the software build is available | The description file | Complete, versioned, covers all DIDs |
| ECU replies `7F 24 11` | Description file or OEM DID list | Service not implemented |
| Need to check that ECU scaling matches the description file | 0x24 (if supported) | One of the few practical uses |

## 4. When is it used? — Real use cases

### Use case: Cross-checking the ODX scaling of a measurement DID
- **Scenario:** Validation of a supplier ECU that claims 0x24 support for its measurement DIDs.
- **Engineer's objective:** Confirm the ECU's own scaling description matches the ODX/CDD used by the test tools.
- **Why this service:** It is the only way to get the ECU's own view of its encoding.
- **Tester sends:** `22 47 11` to read the value, then `24 47 11` (0x4711 illustrative).
- **ECU is expected to:** Return scalingBytes for 0x4711, for example unsigned 2 bytes plus a formula and a unit.
- **Engineer obtains:** Type, length, formula and unit, to compare against the ODX entry.
- **Test on success / failure:** Pass if type, length, formula and unit match. A mismatch is a defect in either
  the ECU or the description file and must be raised with the supplier.

### Use case: Bring-up of an unknown ECU on the bench
- **Scenario:** Development bench with a prototype ECU and an incomplete DID list.
- **Engineer's objective:** Decode a few DIDs before the description file arrives.
- **Why this service:** If implemented, it gives length and type without documentation.
- **Tester sends:** `24 F1 90`, then `24` for each DID of interest.
- **ECU is expected to:** Return scaling for supported DIDs, NRC 0x31 for the rest, or 0x11 if not implemented.
- **Engineer obtains:** Enough information to parse the response length of each DID.
- **Test on success / failure:** Only a stop-gap; the description file stays the reference.

## 5. How does it work?

1. Tester sends `24` and exactly one DID (unlike 0x22, which accepts several). py-uds models the request as a
   single DID.
2. ECU checks length, DID support in the active session, security, conditions.
3. ECU answers `64`, the DID echo, then one or more scalingBytes, each optionally followed by its
   scalingByteExtension. The entries follow the order of the fields in the DID's data record.

**scalingByte layout** (type codes cross-checked against py-uds source, not yet against the ISO text):

| Bits | Meaning |
|---|---|
| 7–4 (high nibble) | Data type of this part of the record |
| 3–0 (low nibble) | Number of bytes. For data types: the length of the value in the data record. For 0x9 / 0xA / 0xB: the length of the scalingByteExtension that follows. For 0x2: the length of the value **and** of its validity mask |

| Type nibble | ISO name (py-uds) | Meaning (own wording) | Extension follows? |
|---|---|---|---|
| 0x0 | unSignedNumeric | Unsigned number | No |
| 0x1 | signedNumeric | Signed number | No |
| 0x2 | bitMappedReportedWithOutMask | Bit-mapped; the data record carries no mask | Yes: a validity mask, low-nibble bytes long, saying which bits are valid |
| 0x3 | bitMappedReportedWithMask | Bit-mapped; the mask is reported inside the data record itself | No |
| 0x4 | BinaryCodedDecimal | BCD | No |
| 0x5 | stateEncodedVariable | Enumeration | No |
| 0x6 | ASCII | Text | No |
| 0x7 | signedFloatingPoint | Floating point | No |
| 0x8 | packet | Structured block | No |
| 0x9 | formula | Conversion formula | Yes: formula identifier (1 byte) + coefficients; coefficient count depends on the formula |
| 0xA | unit/format | Physical unit or display format | Yes: one unit/format code |
| 0xB | stateAndConnectionType | I/O state and connection type | Yes: one byte |
| 0xC–0xF | reserved | — | — |

Note the naming trap: "WithOutMask" (0x2) means the *data* comes without a mask, so the mask is in the extension;
"WithMask" (0x3) means the mask travels with the data, so there is no extension.

The formula identifiers, coefficient encoding and unit/format codes are in ISO 14229-1 Annex C (C.2 scalingByte,
C.3 scalingByteExtension in the 2013 TOC). They are not reproduced here. py-uds encodes each coefficient as
2 bytes: 4-bit exponent + 12-bit mantissa [unverified against ISO]. A parser should treat them as a lookup table built
from the standard, and must use the low nibble to skip extensions it does not understand.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Same session rules as reading the DID with 0x22 | OEM |
| Security / authentication | Usually none; follows the DID's read protection | OEM |
| ECU operating conditions | None expected | — |
| Timing (P2 / P2* / S3) | Answer within P2 | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** the DID being defined for 0x22; ISO-TP if the description exceeds one frame (rare).

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x24 |
| 2–3 | dataIdentifier | 2 | Big-endian DID |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x64 |
| 2–3 | dataIdentifier | 2 | Echo |
| 4 | scalingByte #1 | 1 | Type nibble + length nibble |
| 5 … | scalingByteExtension #1 | low nibble bytes | Only for types that carry one |
| … | scalingByte #2 [+ extension] … | | One entry per field of the data record |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x11 | serviceNotSupported | ECU does not implement 0x24 (common) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request is not exactly 3 bytes |
| 0x22 | conditionsNotCorrect | OEM-defined conditions not met (rare) |
| 0x31 | requestOutOfRange | DID unsupported, or no scaling information for it |
| 0x33 | securityAccessDenied | DID's read protection requires unlock |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 24 F1 90            # scaling of the VIN DID
POS 64 F1 90 6F 62      # ASCII 15 bytes + ASCII 2 bytes (illustrative split, see table)
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 1 | 24 | ReadScalingDataByIdentifier |
| REQ 2–3 | F1 90 | DID VIN |
| POS 1 | 64 | Positive response (0x24 + 0x40) |
| POS 2–3 | F1 90 | DID echo |
| POS 4 | 6F | Type 0x6 ASCII, 15 bytes (one nibble cannot hold 17) |
| POS 5 | 62 | Type 0x6 ASCII, 2 bytes; together 17 bytes. Splitting a long field over several scalingBytes of the same type is the usual approach [unverified] |

Measurement DID with formula and unit. Formula ID, coefficients and unit code are placeholders (illustrative).

```uds
REQ 24 47 11                        # DID 0x4711 (illustrative)
POS 64 47 11 02 95 XX XX XX XX XX A1 XX   # uint16, formula (5 ext. bytes), unit (1 ext. byte)
```

| Byte | Value | Meaning |
|---|---|---|
| POS 2–3 | 47 11 | DID echo (illustrative OEM DID) |
| POS 4 | 02 | Type 0x0 unsigned, 2 bytes: the value in the 0x22 record is a uint16 |
| POS 5 | 95 | Type 0x9 formula, 5 extension bytes follow |
| POS 6–10 | XX × 5 | Formula identifier (1 byte) + two 2-byte coefficients, e.g. a linear formula with C0 and C1 (exponent/mantissa encoding per Annex C) [unverified] |
| POS 11 | A1 | Type 0xA unit/format, 1 extension byte follows |
| POS 12 | XX | Unit code from the ISO unit table (placeholder) |

Negative responses.

```uds
REQ 24 47 11 47 12      # two DIDs: not allowed
NEG 7F 24 13
REQ 24 47 13            # no scaling info (illustrative)
NEG 7F 24 31
REQ 24 F1 90            # ECU without 0x24
NEG 7F 24 11
```

| Exchange | Problem | NRC |
|---|---|---|
| 1 | 5 bytes instead of 3 | 13 [unverified: some ECUs may accept or reject differently] |
| 2 | DID has no scaling record | 31 |
| 3 | Service not implemented | 11 |

## 7. Implementation and testing

**Implementation:**
- Builder: one DID, 3 bytes total.
- Parser: loop over scalingBytes. For types with an extension (0x2, 0x9, 0xA, 0xB), consume the number of
  bytes in the low nibble as the extension. For other types, record (type, length) and move on. Stop at the
  end of the message. Unknown type nibble: keep the raw byte and stop decoding rather than guessing.
- Cross-check: the sum of the low nibbles of the data types (0x0–0x8; not 0x9/0xA/0xB, which describe the
  preceding field) should equal the 0x22 record length for that DID [unverified]. A mismatch is a useful
  automated test.
- Formula and unit tables: build them from the ISO annex under licence; do not hard-code guesses.
- Default expectation in test frameworks: 0x24 may be absent. Make support a per-ECU flag.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Support check | `24 F1 90` | Positive, or `7F 24 11` if not implemented (document which) |
| 2 | Positive, measurement DID | `24` + DID with formula | Type, formula, unit consistent with ODX |
| 3 | Length consistency | 0x24 and 0x22 on the same DID | Sum of data-type lengths = 0x22 record length [unverified rule] |
| 3a | Bit-mapped DID | DID with a type 0x2 or 0x3 field | 0x2: mask in the extension; 0x3: no extension |
| 4 | Length min-1 | `24 F1` | `7F 24 13` |
| 5 | Length min = max | `24 F1 90` | Positive |
| 6 | Length max+1 | `24 F1 90 00` | `7F 24 13` |
| 7 | Unsupported DID | `24` + DID not in ECU | `7F 24 31` |
| 8 | Session matrix | Same DID in default, extended, programming | Same availability as 0x22 for that DID [OEM-specific] |
| 9 | Security matrix | Secured DID, locked then unlocked | `7F 24 33`, then positive |
| 10 | Functional addressing | `24 F1 90` functional | Supporting ECUs answer; NRC 0x11/0x31 suppressed |
| 11 | Multi-frame | DID with long description (if any) | Correct ISO-TP segmentation |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.4 (data transmission functional unit). scalingByte and scalingByteExtension definitions (type codes, formula identifiers, unit codes) are in Annex C (2013 TOC: C.2 and C.3; 2020 TOC: Annex C = data transmission parameter definitions). |
| Edition differences | None known between 2013 and 2020 [unverified]. 2026 edition not yet reviewed. |
| OEM / ECU-specific | Whether the service exists; which DIDs carry scaling; session and security rules. |
| Verification status | draft. Cross-checked: clause number, SID/response SID, general purpose (py-uds docs). Reviewer 2026-10-26: single-DID request, response layout, type codes 0x0–0xB and which types carry an extension checked against py-uds source (open-source, not normative). The writer's table had 0x2 and 0x3 swapped; corrected. Coefficient encoding and the length-consistency rule remain [unverified]. |
| Open questions | Exact type code list and extension rules in the 2020 text; how ISO intends a field longer than 15 bytes to be described (VIN example); whether 0xB's low nibble is always 1. |
