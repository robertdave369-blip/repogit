---
sid: 0x36
name: TransferData
response_sid: 0x76
has_sub_function: false
functional_unit: "upload/download"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "15.4 (ISO 14229-1:2020 preview TOC)"
status: draft
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) - clause number and functional unit only"
  - "python-udsoncan TransferData implementation (github.com/pylessard/python-udsoncan, read 2026-10-26) - field order and NRC list compared, not normative"
  - "NI Automotive Diagnostic Command Set C API reference, ndUDSTransferData (ni.com, read 2026-10-26) - counter starts at 01 and wraps FF to 00, secondary"
  - "damodev.csdn.net/6a435957662f9a54cb866add.html: maxNumberOfBlockLength counts SID + blockSequenceCounter + data - secondary (reviewer, 2026-10-26)"
---

# 0x36 — TransferData

> **Status:** draft · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x76
> Moves one numbered block of data inside a transfer opened by 0x34, 0x35 or 0x38.

Related entries in this functional unit: [0x34 RequestDownload](0x34-request-download.md) ·
[0x35 RequestUpload](0x35-request-upload.md) · [0x37 RequestTransferExit](0x37-request-transfer-exit.md) ·
[0x38 RequestFileTransfer](0x38-request-file-transfer.md)

## 1. What is it?

TransferData (SID 0x36) carries the actual bytes of a transfer, one block per request/response pair. Each
request has a one-byte **blockSequenceCounter** that the ECU echoes in its positive response.

- **Download** (after [0x34](0x34-request-download.md), or 0x38 AddFile/ReplaceFile/ResumeFile): the
  request carries the data (transferRequestParameterRecord); the response is normally just `76 <counter>`.
- **Upload** (after [0x35](0x35-request-upload.md), or 0x38 ReadFile/ReadDir): the request carries only
  the counter; the response carries the data (transferResponseParameterRecord).

The counter starts at **0x01** for the first block of a transfer, increments by one, and after **0xFF**
wraps to **0x00** (not to 0x01).
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

- A software image or memory dump does not fit into one message; ISO-TP on classic CAN carries at most 4095
  bytes per message without the escape length format, and ECU RAM buffers are often 1–4 KiB.
- The block counter lets both sides detect lost, duplicated or out-of-order blocks. Without it, a repeated
  request after a lost response would write the same data twice at the next address.
- Separating "open transfer" (0x34/0x35/0x38) from "move data" (0x36) lets the ECU validate the target once
  and then process blocks quickly.

Who benefits: anyone flashing or reading out ECUs — production, workshop, validation, development.
<!-- catalogue field 3 -->

## 3. What is its purpose?

It moves data inside an active transfer and nothing else. It does not choose the address (that came with
0x34/0x35/0x38), does not erase memory, and does not finish the transfer
([0x37](0x37-request-transfer-exit.md) does).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| No transfer has been opened | [0x34](0x34-request-download.md) / [0x35](0x35-request-upload.md) / [0x38](0x38-request-file-transfer.md) first | 0x36 alone returns 0x24 |
| Small single write | [0x3D WriteMemoryByAddress](0x3D-write-memory-by-address.md) | No transfer state needed |
| Small single read | [0x23 ReadMemoryByAddress](0x23-read-memory-by-address.md) | No transfer state needed |
| Closing the transfer / sending a checksum | [0x37 RequestTransferExit](0x37-request-transfer-exit.md) | Separate service |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Flashing an application block
- **Scenario:** 256 KiB application block after a successful 0x34 (shared example below).
- **Engineer's objective:** Write all data with the fewest possible blocks and no errors.
- **Why this service:** The only UDS service that carries data inside a download.
- **Tester sends:** `36 01 <1024 bytes>`, `36 02 …`, … `36 FF …`, `36 00 …` (256 blocks).
- **ECU is expected to:** Write each block, answer `76 <counter>`, use 0x78 when a flash write takes longer
  than P2.
- **Engineer obtains:** 256 positive responses; then 0x37.
- **Test on success / failure:** Success = every counter echoed. Failure = 0x73 (counter), 0x72 (flash
  write), 0x93 (supply dropped during programming), 0x71 (ECU aborted the transfer).

### Use case: Robustness test of block-counter handling on a HIL bench
- **Scenario:** Bootloader validation for a restraint control module on a HIL bench with a CAN disturbance
  node.
- **Engineer's objective:** Prove the bootloader handles a lost response, a duplicated block and a skipped
  block as specified.
- **Why this service:** Counter handling is defined on 0x36; bugs here corrupt flash silently.
- **Tester sends:** Block 5, response destroyed by the disturbance node; tester repeats block 5; later block
  8 is skipped (7 → 9).
- **ECU is expected to:** Accept the repeated block 5 without writing it twice [unverified]; reject block 9
  with 0x73.
- **Engineer obtains:** Trace evidence for both cases; a dependency check that still passes after the
  repeat, and fails or aborts after the skip.
- **Test on success / failure:** After the repeat test, readback or CRC routine matches the source file.

### Use case: Throughput tuning for EOL cycle time
- **Scenario:** EOL flashing takes too long.
- **Engineer's objective:** Reduce flash time without breaking robustness.
- **Why this service:** Block size and ISO-TP parameters of 0x36 dominate the transfer time.
- **Tester sends:** Same image with different tester settings (STmin, block size BS, CAN FD vs classic CAN).
- **ECU is expected to:** Keep up with STmin 0 or announce a larger STmin in its Flow Control.
- **Engineer obtains:** Time per block and per image for each configuration.
- **Test on success / failure:** No 0x73, no ISO-TP timeouts, image verified after each run.
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. A transfer is active after a positive 0x74, 0x75 or 0x78 (0x38). The ECU expects counter 0x01.
2. Tester sends `36 <counter> [data]`. ECU checks: transfer active, counter, length, voltage, memory bounds.
3. Download: ECU writes the block (or buffers it), replies `76 <counter>`. Upload: ECU reads the next part
   and replies `76 <counter> <data>`.
4. Counter rules:

| Received counter | ECU behaviour |
|---|---|
| Expected next value | Process block, respond positively, advance the expected value |
| Same as the last positively answered block | Tester is repeating after a lost response: respond positively again, do **not** write the data a second time (download) or send the same data again (upload) [unverified] |
| Anything else | 0x73 wrongBlockSequenceCounter; transfer usually stays active [unverified] |

5. After the final block the tester sends [0x37](0x37-request-transfer-exit.md).

**Block sizing.** maxNumberOfBlockLength from 0x74/0x75 limits the whole 0x36 message (download request or
upload response), counted including the SID and the counter byte (secondary source agrees; ISO text not
checked). So data per block =
maxNumberOfBlockLength − 2. The tester may also cap it to its own transport buffer. The last block holds the
remainder and may be shorter. Some bootloaders require all other blocks to be exactly full size
[OEM-specific].

**ISO-TP impact.** A 1026-byte message on classic CAN (8-byte frames) is one First Frame plus 146
Consecutive Frames (6 data bytes in the FF, 7 per CF). On CAN FD with 64-byte frames it is about 17 frames
[unverified frame overhead]. Classic ISO-TP lengths above 4095 need the escape First Frame (`10 00` + 4-byte
length) that not every tester or ECU supports. See
[ISO-TP essentials](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials).

**Throughput (rough, illustrative).** At 500 kbit/s classic CAN one 8-byte frame takes about 0.25 ms. With
STmin 0 and no block-size limit, a 147-frame block needs about 37 ms bus time, so the shared 256 KiB example
needs about 9–10 s of bus time. With STmin 1 ms it rises to about 38 s. The ECU's flash write time per block
(often several ms to tens of ms, sometimes via 0x78) adds to this. Larger blocks reduce the per-block
overhead (request/response turnaround, Flow Control) but need more ECU RAM.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Same session in which the transfer was opened (programming for flashing) | OEM |
| Security / authentication | Inherited from the open step; a session change re-locks and aborts | OEM |
| ECU operating conditions | Supply voltage within programming limits for the whole transfer | OEM |
| Timing (P2 / P2* / S3) | Each block within P2, or 0x78 then P2*. The block traffic keeps S3 alive; TesterPresent needed only in pauses | Standard timing, OEM values |

**Depends on:** [0x34](0x34-request-download.md), [0x35](0x35-request-upload.md) or
[0x38](0x38-request-file-transfer.md) before; [0x37](0x37-request-transfer-exit.md) after. Response pending:
[protocol-fundamentals.md](../protocol-fundamentals.md#response-pending-0x78).
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x36 |
| 2 | blockSequenceCounter | 1 | 0x01 for the first block, +1 per new block, 0xFF → 0x00 |
| 3 … | transferRequestParameterRecord | 0 … maxNumberOfBlockLength − 2 | Download: the data. Upload: normally empty; content OEM-specific if used |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the counter: 0x80 and above are
ordinary counter values, and every 0x36 request gets a response.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x76 |
| 2 | blockSequenceCounter | 1 | Echo of the request counter |
| 3 … | transferResponseParameterRecord | 0 … maxNumberOfBlockLength − 2 | Upload: the data. Download: normally empty; some ECUs return a status or checksum [OEM-specific] |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request shorter than 2 bytes, or longer than maxNumberOfBlockLength (some ECUs use 0x31 for this) [unverified] |
| 0x24 | requestSequenceError | No download/upload active (0x34/0x35/0x38 missing or already closed by 0x37), or transfer aborted by an earlier error [unverified for the second case] |
| 0x31 | requestOutOfRange | Block would go past the announced memorySize, or the parameter record is invalid [unverified] |
| 0x71 | transferDataSuspended | ECU has stopped the transfer because of an internal fault; tester must restart from 0x34/0x35 |
| 0x72 | generalProgrammingFailure | Writing (or verifying) the block in memory failed |
| 0x73 | wrongBlockSequenceCounter | Counter is neither the expected next value nor a repeat of the last one |
| 0x78 | requestCorrectlyReceived-ResponsePending | Block accepted; flash write takes longer than P2 |
| 0x7F | serviceNotSupportedInActiveSession | Session changed (often after S3 timeout); transfer is gone |
| 0x92 | voltageTooHigh | Supply above programming limit |
| 0x93 | voltageTooLow | Supply below programming limit |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Shared download example with
[0x34](0x34-request-download.md#examples) and [0x37](0x37-request-transfer-exit.md#examples):
memoryAddress 0x00080000, memorySize 0x00040000 (256 KiB), maxNumberOfBlockLength 0x0402 → 1024 data bytes
per block → 256 blocks (all illustrative).

**Example 1 — counter run and wrap:**

```uds
REQ 34 00 44 00 08 00 00 00 04 00 00   # open download (see 0x34)
POS 74 20 04 02                        # 0x0402 = 1026 → 1024 data bytes per block
REQ 36 01 ..                           # block 1, address 0x00080000, 1024 bytes
POS 76 01
REQ 36 02 ..                           # block 2, address 0x00080400
POS 76 02
NOTE blocks 03 … FE
REQ 36 FF ..                           # block 255, address 0x000BF800
POS 76 FF
REQ 36 00 ..                           # block 256, counter wrapped to 00, address 0x000BFC00
POS 76 00
REQ 37                                 # close (see 0x37)
POS 77
```

| Bytes | Field | Decoded |
|---|---|---|
| 36 01 .. | Request | Counter 01 = first block; 1024 data bytes; total 1026 bytes |
| 76 01 | Response | Counter echoed; no response record |
| 36 FF / 36 00 | Counter wrap | Block 255 uses FF; block 256 uses 00 (not 01) |
| 256 × 1024 | Data | = 0x40000 = memorySize; nothing left for a block 257 |

**Example 2 — lost response, skipped block, flash and voltage errors:**

```uds
REQ 36 05 ..        # block 5
NOTE positive response lost (disturbance); tester waits P2client, then repeats
REQ 36 05 ..        # same counter, same data
POS 76 05           # ECU recognises the repeat; data not written twice [unverified]
REQ 36 06 ..
POS 76 06
REQ 36 08 ..        # tester bug: block 7 skipped
NEG 7F 36 73
REQ 36 07 ..        # correct block
NEG 7F 36 78        # flash write slow
POS 76 07
REQ 36 08 ..
NEG 7F 36 72        # flash write failed (illustrative fault injection)
NOTE after 0x72 the logical block is restarted from erase; the next exchange is a separate run
REQ 36 09 ..        # separate run: supply dropped to 9 V during the transfer (illustrative)
NEG 7F 36 93
```

| Bytes | Decoded |
|---|---|
| 36 05 (twice) / 76 05 | Repeat of the last block after a lost response → positive, no second write |
| 36 08 / 7F 36 73 | Expected 07 or a repeat of 06 → wrongBlockSequenceCounter |
| 7F 36 78 then 76 07 | Pending, then success within P2* |
| 7F 36 72 | Memory programming failed; restart the logical block from erase |
| 7F 36 93 | voltageTooLow |

**Example 3 — upload direction and no active transfer:**

```uds
REQ 36 01           # no 0x34/0x35/0x38 before
NEG 7F 36 24
REQ 35 00 44 20 00 10 00 00 00 10 00   # open upload, 4 KiB (see 0x35, illustrative)
POS 75 20 04 02
REQ 36 01           # upload: request carries only the counter
POS 76 01 ..        # 1024 data bytes
```

| Bytes | Decoded |
|---|---|
| 7F 36 24 | requestSequenceError — no transfer active |
| 36 01 / 76 01 .. | Upload block 1; data is in the response |

**Example 4 — first block on classic CAN (ISO-TP view, IDs and padding illustrative):**

```uds
CAN 7E0  14 02 36 01 XX XX XX XX     # First Frame, length 0x402 = 1026
CAN 7E8  30 00 00 CC CC CC CC CC     # Flow Control from ECU: continue, BS 0, STmin 0
CAN 7E0  21 XX XX XX XX XX XX XX     # Consecutive Frame 1
NOTE … 146 Consecutive Frames in total (sequence numbers 1…F, 0…F, …)
CAN 7E8  02 76 01 CC CC CC CC CC     # Single Frame: positive response 76 01
```

| Frame | Decoded |
|---|---|
| 14 02 36 01 … | FF: length 0x402; payload starts with SID 0x36, counter 01 and 4 data bytes |
| 30 00 00 | FC: ContinueToSend, block size 0 (no limit), STmin 0 ms |
| 21 … | CF 1 with 7 data bytes |
| 02 76 01 | SF with 2-byte positive response |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**
- Inputs: data source, maxNumberOfBlockLength from 0x74/0x75/0x78, optional tester cap.
- Split: chunk = maxNumberOfBlockLength − 2; last chunk = remainder. Do not send an empty extra block.
- Counter: start 0x01, `next = (cur + 1) & 0xFF`. Unit-test the wrap with an image > 255 blocks.
- Retry policy: on a timeout without any response, resend the **same** counter and data once or twice; on
  0x73 stop and investigate (do not "search" for the right counter); on 0x71/0x72 abort the logical block and
  restart from erase; on 0x92/0x93 abort and fix the supply.
- Response check: echoed counter must equal the sent one; for uploads, data length ≤ chunk size.
- Timing: switch to P2* after 0x78; never send the next block before the final response.
- Progress: report bytes and blocks; log first/last block and every NRC with its counter.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path | Shared example, 256 blocks | All `76 <counter>`; 0x37 positive |
| 2 | Counter start | First block with 00 or 02 | 0x73 |
| 3 | Counter wrap | Block 256 with 00 | Positive |
| 4 | Wrong wrap | Block 256 with 01 | 0x73 |
| 5 | Repeat after lost response | Same counter twice | Positive, no double write (verify by CRC) [unverified] |
| 6 | Skipped block | 06 then 08 | 0x73 |
| 7 | No transfer active | 0x36 without 0x34/0x35, or after 0x37 | 0x24 |
| 8 | Length min-1 | `36` only | 0x13 |
| 9 | Length min (download) | `36 01` with no data | Positive or 0x13/0x31 [OEM-specific] |
| 10 | Length max | 1026-byte request | Positive |
| 11 | Length max+1 | 1027-byte request | 0x13 or 0x31 [unverified] |
| 12 | Beyond memorySize | Block 257 | 0x24 (commonly cited ISO condition: all data already received) or 0x31 [unverified] |
| 13 | Short last block | Image not a multiple of 1024 | Positive |
| 14 | Flash failure | Fault injection on write | 0x72; recovery from erase works |
| 15 | Voltage | 9 V and 16 V during transfer (limits OEM-specific) | 0x93 / 0x92 |
| 16 | Session matrix | S3 timeout or 10 01 during transfer | Next 0x36 → 0x7F or 0x24; transfer aborted |
| 17 | Security matrix | Re-lock (session change) mid-transfer | Transfer aborted; restart required |
| 18 | Functional addressing | 0x36 on functional ID | Ignored / no response [OEM-specific] |
| 19 | Counter ≥ 0x80 | Block 128 counter 80 | Normal positive response (no SPRMIB) |
| 20 | Response pending | Slow flash | 0x78 within P2, final within P2* |
| 21 | Multi-frame | STmin / BS from ECU Flow Control | Tester honours them; no N_Cr/N_Bs timeouts |
| 22 | Throughput | Classic CAN vs CAN FD, STmin 0 vs 1 ms | Times recorded; image verified |
| 23 | Upload direction | 0x35 then `36 01` | `76 01 <data>`, length ≤ max − 2 |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 15.4 (upload/download functional unit), from the preview TOC |
| Edition differences | No change between 2013 and 2020 known to the author [unverified]. 2026 not yet reviewed |
| OEM / ECU-specific | Block size; whether all blocks but the last must be full; response record content; voltage limits; retry policy expected by the bootloader; whether the transfer survives an NRC |
| Verification status | draft. Clause number cross-checked (preview TOC). Counter start 01 and wrap FF→00 stated by NI ADCS documentation (secondary). NRC list compared with python-udsoncan (not normative). Reviewer 2026-10-26: block length incl. SID + counter supported by a secondary source; throughput arithmetic (147 frames per 1026-byte block, ~37 ms at 500 kbit/s, ~9–10 s per 256 KiB, ~38 s with STmin 1 ms; ~17 frames on CAN FD 64) and shared-example addresses rechecked. Not checked against the ISO text |
| Open questions | Confirm repeat-block rule; confirm whether maxNumberOfBlockLength includes SID and counter; 0x13 vs 0x31 for oversize blocks; NRC for a block beyond memorySize; whether the transfer stays active after 0x73 |
<!-- catalogue field 15 -->
