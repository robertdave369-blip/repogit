---
sid: 0x84
name: SecuredDataTransmission
response_sid: 0xC4
has_sub_function: false
functional_unit: "Security sub-layer"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "16.2 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) — new clause 16 security sub-layer, 16.2 SecuredDataTransmission"
  - "py-uds knowledge base (uds.readthedocs.io) — response SID 0xC4; separate 2013 and 2020 request/response formats listed"
  - "py-uds translator source (github.com/mdabrowski1990/uds: service_definitions/secured_data_transmission.py, data_record_definitions/other.py and formula.py, message/nrc.py) — 2020 envelope field order and sizes, administrative parameter bits, 2013 raw securityDataRequest/ResponseRecord, NRC 0x38/0x39/0x3A names"
  - "Engineering knowledge — anti-replay rules, inner negative response handling, NRC choice per failure (not cross-checked)"
---

# 0x84 — SecuredDataTransmission

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0xC4
> Carries an ordinary diagnostic request (or response) inside a protected envelope: signed and/or encrypted,
> with an anti-replay counter, handled by the security sub-layer.

## 1. What is it?

SecuredDataTransmission (SID 0x84) is a container service. The tester takes a normal diagnostic request,
for example `2E <DID> <data>`, puts it inside a 0x84 message and adds security information. The server's
**security sub-layer** checks and unpacks it, passes the inner request to the normal service handler, then
packs the inner response into a 0x84 positive response (`C4 …`) protected the same way.

Concept of the 2020 envelope (field order cross-checked against the py-uds translator; not against ISO text):

| Part | Purpose |
|---|---|
| Administrative parameter | Flags: request or response, signed, encrypted, pre-established key used, signed response requested |
| Signature/encryption calculation | Which algorithm / key set protects this message (OEM-defined values) |
| Signature length | How many signature/MAC bytes are at the end |
| Anti-replay counter | Changes for each message so a captured message cannot be sent again |
| Internal message | Inner SID + parameters (plain or encrypted) |
| Signature / MAC | Over the protected content |

ISO 14229-1:2020 moved this service into the new clause 16 "security sub-layer definition" (cross-checked).

## 2. Why is it needed?

Plain UDS has no integrity or confidentiality. Anyone on the bus or behind a compromised gateway can read,
modify or replay messages. Unlocking with 0x27 or 0x29 proves who started the session, but it does not protect
each later message. Some data needs per-message protection:

- writing immobilizer, key or anti-theft data;
- writing odometer-related or legally relevant data;
- reading data that must not be readable in transit (keys, personal data);
- requests that must not be replayed (e.g. an actuator command captured once and sent again).

0x84 gives a standard envelope for that. Value: OEM security teams, key-programming tools, workshops
operating over remote/DoIP links, validation teams doing security testing.

## 3. What is its purpose?

It protects a single request/response pair. It does not grant access rights — that is SecurityAccess (0x27) or
Authentication ([0x29](0x29-authentication.md)). It does not change sessions. The inner service still applies
all its own checks (session, security, length, range).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Need to unlock services | SecurityAccess (0x27) / Authentication ([0x29](0x29-authentication.md)) | 0x84 does not grant rights |
| Whole link must be protected | TLS on DoIP / SecOC on CAN [OEM-specific] | Transport-level protection covers all messages |
| Data is not sensitive | The plain service | 0x84 adds latency, size and key management |
| ECU spec does not list 0x84 | Plain service | Few ECUs implement 0x84; expect `7F 84 11` |

<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Writing anti-theft data over a remote workshop link
- **Scenario:** A remote diagnostic session runs through a gateway and DoIP. The OEM requires that the
  immobilizer data DID (0x4711, illustrative) is only written inside a signed and encrypted 0x84 envelope.
- **Engineer's objective:** Write the data so that neither the gateway nor the network path can read or change it.
- **Why this service:** Protects the one message end to end, independent of the transport.
- **Tester sends:** `10 03`, authentication per OEM, then `84 <admin> <calc> <len> <counter> 2E 47 11 <data> <MAC>`
  (data encrypted).
- **ECU is expected to:** Verify MAC and counter, decrypt, execute `2E 47 11`, return `C4 … 6E 47 11 <MAC>`.
- **Engineer obtains:** Confirmed write, with a protected response proving it came from the ECU.
- **Test on success / failure:** Tester verifies the response MAC and counter. A plain `2E 47 11 ..` must be
  rejected by the ECU (the DID is only writable through 0x84) [OEM-specific].

### Use case: HIL security validation of the sub-layer
- **Scenario:** Validation of a new body ECU's security sub-layer before a cybersecurity audit.
- **Engineer's objective:** Show tampered, replayed and malformed envelopes are all rejected and do not
  execute the inner request.
- **Why this service:** The envelope checks are the security requirement.
- **Tester sends:** A valid envelope; the same envelope again (replay); one with a flipped bit in the MAC; one
  with a wrong signature length; one with an unknown algorithm value.
- **ECU is expected to:** Accept only the first; reject the others with an NRC and no side effects.
- **Engineer obtains:** Evidence per check; logs of the counter state.
- **Test on success / failure:** Reading the target DID after each rejected attempt shows it unchanged.

<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. Tester and ECU share key material: pre-installed keys, or session keys derived during Authentication
   (0x29) [unverified link between the two].
2. Tester builds the inner request, sets the anti-replay counter, encrypts if required, computes the
   signature/MAC, and sends `84 …`.
3. Server security sub-layer: checks length fields, algorithm value, counter freshness, signature; decrypts.
   If any check fails, it rejects the whole message and does not run the inner request.
4. Server runs the inner request through the normal dispatcher (same session/security rules as plain).
5. Server wraps the inner response — positive or negative — into `C4 …`, with its own counter and signature.
   An inner negative response travels inside a `C4` message (internal ID 0x7F), not as `7F 84 …`
   [unverified].

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Whatever the inner service needs; 0x84 itself often allowed in default and extended | OEM |
| Security / authentication | Keys must exist; often an authenticated role (0x29) or unlocked level first | OEM |
| ECU operating conditions | Crypto service (HSM) ready; counter state valid | ECU |
| Timing (P2 / P2* / S3) | Crypto can exceed P2 → `7F 84 78` then final response within P2* | ISO 14229-2 / ECU |

**Depends on:** key management (HSM/SHE), the inner service, ISO-TP multi-frame or DoIP for the larger
messages ([../protocol-fundamentals.md](../protocol-fundamentals.md#iso-tp-iso-15765-2-essentials)).

<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the start of the security
parameters, not a sub-function, so bit 7 of it has no SPRMIB meaning.

Field order and sizes below are cross-checked against the py-uds translator (one open-source stack), not
against the ISO text. Check clause 16 of the edition in use before building a production parser.

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x84 |
| 2–3 | Administrative parameter | 2 | Bit flags, see table below |
| 4 | Signature/encryption calculation | 1 | Algorithm / key identifier; OEM-defined |
| 5–6 | Signature length | 2 | Number of signature/MAC bytes at the end (0 = none) |
| 7–8 | Anti-replay counter | 2 | Freshness value; rules OEM-defined |
| 9 | Internal message service request ID | 1 | Inner SID, e.g. 0x2E (may be encrypted) |
| 10… | Service-specific parameters | n | Inner request parameters (may be encrypted) |
| last | Signature / MAC | per length | Over the protected content |

**Administrative parameter bits** (py-uds translator; bit 15 = MSB of byte 2) [unverified against ISO]:

| Bit(s) | Meaning when set |
|---|---|
| 15–7 | reserved |
| 6 | Signature on the response is requested |
| 5 | Message is signed |
| 4 | Message is encrypted |
| 3 | A pre-established key is used |
| 2–1 | reserved |
| 0 | Message is a request (0 in the server's response) |

Example: a signed request without encryption has administrative parameter `00 21` (bits 5 and 0)
[unverified].

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0xC4 (always, also when the inner response is negative [unverified]) |
| 2–3 | Administrative parameter | 2 | Flags for the response (bit 0 = 0) |
| 4 | Signature/encryption calculation | 1 | Algorithm used for the response |
| 5–6 | Signature length | 2 | |
| 7–8 | Anti-replay counter | 2 | Server's counter |
| 9 | Internal message service response ID | 1 | Inner response SID (e.g. 0x6E) or 0x7F for an inner negative response [unverified] |
| 10… | Response-specific parameters | n | Inner response parameters |
| last | Signature / MAC | per length | |

### Negative responses

Outer negative responses (`7F 84 xx`) mean the envelope itself was rejected; the inner request did not run.

| NRC | Name | When this service returns it |
|---|---|---|
| 0x11 | serviceNotSupported | ECU has no security sub-layer (most ECUs) |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Envelope shorter than the fixed fields; signature length does not match the bytes received |
| 0x22 | conditionsNotCorrect | Crypto service not ready; keys missing |
| 0x24 | requestSequenceError | Required prior step (e.g. authentication / key setup) not done [OEM-specific] |
| 0x31 | requestOutOfRange | Unsupported algorithm value or administrative flag combination |
| 0x3A | secureDataVerificationFailed | Signature/MAC wrong, counter stale (replay) or decryption failed (name per py-uds NRC list; NRC choice per failure [unverified]) |
| 0x7F | serviceNotSupportedInActiveSession | 0x84 not allowed in this session |
| 0x78 | requestCorrectlyReceived-ResponsePending | Crypto takes longer than P2 |

Related NRCs returned by **plain** (unwrapped) services, listed in the py-uds NRC list [unverified against ISO;
not yet in [../nrc-reference.md](../nrc-reference.md)]:

| NRC | Name | When |
|---|---|---|
| 0x38 | secureDataTransmissionRequired | A service that must be sent inside 0x84 arrives in plain form |
| 0x39 | secureDataTransmissionNotAllowed | A service that must not be wrapped arrives inside 0x84 |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. `XX XX` = administrative parameter, `YY` =
signature/encryption calculation (both OEM / edition-defined). `..` after the inner message = MAC.

```uds
REQ 84 XX XX YY 00 10 00 2A 2E 47 11 01 02 03 04 ..   # secured write of DID 0x4711 (illustrative), 16-byte MAC, counter 0x002A
NEG 7F 84 78                                           # MAC verification in HSM takes longer than P2
POS C4 XX XX YY 00 10 00 2B 6E 47 11 ..               # inner positive response 6E 47 11, server counter 0x002B, MAC
```

| Line | Byte(s) | Meaning [layout unverified] |
|---|---|---|
| REQ | 84 | SecuredDataTransmission |
| REQ | XX XX | Administrative parameter: request, signed (e.g. `00 21`, bit layout [unverified]) |
| REQ | YY | Signature/encryption calculation (e.g. AES-128-CMAC key set, illustrative) |
| REQ | 00 10 | Signature length = 16 |
| REQ | 00 2A | Anti-replay counter (illustrative) |
| REQ | 2E 47 11 01 02 03 04 | Inner request: WriteDataByIdentifier 0x4711, data 01 02 03 04 (illustrative, plain because not encrypted) |
| REQ | .. | 16-byte MAC |
| NEG | 7F 84 78 | Response pending |
| POS | C4 | Positive response to 0x84 |
| POS | XX XX YY 00 10 00 2B | Response administrative fields, server counter |
| POS | 6E 47 11 | Inner positive response to 0x2E |
| POS | .. | 16-byte MAC |

```uds
REQ 84 XX XX YY 00 10 00 2A 2E 47 11 01 02 03 04 ..   # exact replay of the message above
NEG 7F 84 3A                                           # rejected: counter already used [NRC choice unverified]
REQ 84 XX XX YY 00 10 00 2C 2E 47 11 ..               # valid envelope, inner write not allowed in this session
POS C4 XX XX YY 00 10 00 2D 7F 2E 7F ..               # envelope OK; inner negative response 7F 2E 7F carried inside [unverified]
REQ 84 XX XX                                           # truncated envelope
NEG 7F 84 13
```

| Line | Byte(s) | Meaning |
|---|---|---|
| NEG 1 | 7F 84 3A | Envelope rejected; DID 0x4711 not written |
| POS 2 | 7F 2E 7F | Inner response: WriteDataByIdentifier, serviceNotSupportedInActiveSession |
| NEG 3 | 7F 84 13 | Fixed fields incomplete |

**2013 vs 2020** [edition-dependent]: the 2013 edition defined 0x84 with a single securityDataRequestRecord /
securityDataResponseRecord whose content was left to the extended data link security document (ISO 15764)
[unverified]. 2020 defines the security sub-layer fields itself in clause 16. py-uds lists different formats for
the two editions. A 2013-based tool and a 2020 ECU will not interoperate on 0x84.

<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- Builder: take the inner request bytes, algorithm id, key handle, counter source; compute length fields from
  the data. Keep crypto in the project's security library/HSM stub; never hard-code keys.
- Counter: tester-side counter must persist across test steps; log every value. Decide (per OEM spec) whether
  it is per session, per key or global.
- Parser: verify response MAC and counter before trusting the inner response. Then parse the inner response
  with the normal parser for that SID. Treat inner `7F` as a normal negative result of the inner service.
- Edge cases: counter wrap-around; ECU reset resetting or keeping the counter [OEM-specific]; maximum envelope
  size versus ISO-TP buffer; P2* for slow crypto.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive signed | Valid envelope, inner `22 <DID>` | `C4 …` with inner `62 …`, valid MAC |
| 2 | Positive signed + encrypted | Valid encrypted inner `2E` | `C4 …`, inner `6E` after decryption |
| 3 | Not supported | `84 ..` on an ECU without sub-layer | `7F 84 11` |
| 4 | Tampered MAC | Flip one MAC bit | `7F 84 3A` (or OEM NRC); inner not executed |
| 5 | Tampered payload | Flip one inner byte | Same as 4 |
| 6 | Replay | Resend a previous valid envelope | Rejected; inner not executed |
| 7 | Counter jump / wrap | Counter far ahead; counter at maximum | Per OEM freshness rules |
| 8 | Unknown algorithm | Unsupported `YY` | `7F 84 31` [unverified] |
| 9 | Session matrix | Valid envelope in each session; inner service allowed / not allowed | Outer `7F 84 7F` if 0x84 not allowed; else inner NRC inside `C4` |
| 10 | Security / authentication | Envelope before and after 0x27 / 0x29 | Per OEM; inner `7F 2E 33` / `34` inside `C4` when inner service locked [unverified] |
| 11 | Length min-1 | Fixed fields one byte short | `7F 84 13` |
| 12 | Length min | Fixed fields + 1-byte inner SID + MAC | Inner service decides (e.g. inner `7F xx 13`) |
| 13 | Length max | Largest envelope the ECU buffer allows | Accepted |
| 14 | Length max+1 / mismatch | One byte over buffer; signature length ≠ bytes present | `7F 84 13` (buffer overflow may instead be rejected at ISO-TP level with FC overflow) |
| 15 | Bit 7 of byte 2 | Set bit 7 of byte 2 (a reserved bit of the administrative parameter) | Never treated as SPRMIB: a response is still sent; reserved bit set → `7F 84 31` or `13` per spec [unverified] |
| 16 | Functional | Envelope sent functionally | Usually not supported; no response / per OEM |
| 17 | Response pending | Slow crypto | `7F 84 78` within P2, final within P2* |
| 18 | Multi-frame | Envelope > 7 bytes on classical CAN | Correct ISO-TP segmentation both ways |
| 19 | Plain request for a wrapped-only DID | `2E 47 11 ..` (illustrative) without 0x84 | `7F 2E 38` or OEM NRC [unverified] |

<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 16.2, inside clause 16 "security sub-layer definition" (functional unit: security sub-layer) |
| Edition differences | 2013: envelope content delegated to the extended data link security document [edition-dependent] [unverified]. 2020: clause 16 security sub-layer defines the fields (cross-checked: clause exists). 2026 not yet reviewed |
| OEM / ECU-specific | Whether 0x84 exists at all; algorithms and key ids; counter rules; which DIDs/services must be wrapped; NRC per failure |
| Verification status | cross-checked (reviewer, 2026-10-26). Cross-checked: SID, response SID 0xC4, clause 16.2 and functional unit (ISO 2020 preview); 2013/2020 formats differ; 2020 envelope field order and sizes (admin 2, calc 1, signature length 2, counter 2, inner SID 1, params, MAC); administrative parameter flag names and positions; 2013 raw record format; NRC 0x3A name (all py-uds translator source — a single open-source stack). Not cross-checked: inner negative response handling, counter rules, NRC choice per failure, ISO bit numbering |
| Open questions | ISO bit numbering of the administrative parameter; whether an inner negative response is always carried inside `C4` (internal ID 0x7F); NRC used for replay; whether 0x38/0x39 are in the 2020 NRC table; how 0x29 session keys are bound to 0x84 |

<!-- catalogue field 15 -->
