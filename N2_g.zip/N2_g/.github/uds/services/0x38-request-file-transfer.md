---
sid: 0x38
name: RequestFileTransfer
response_sid: 0x78
has_sub_function: false
functional_unit: "upload/download"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "15.6 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439) - clause number and functional unit only"
  - "python-udsoncan RequestFileTransfer implementation (github.com/pylessard/python-udsoncan, read 2026-10-26) - modeOfOperation values 01-06, per-mode request/response fields, NRC list compared, not normative"
  - "py-uds source (github.com/mdabrowski1990/uds: constants/other.py MODE_OF_OPERATION_MAPPING_2013 = 01-05, _2020 adds 06 ResumeFile; data_record_definitions/conditional.py per-mode request/response; other.py lengthFormatIdentifier 8-bit count, fileSizeOrDirInfoParameterLength 16 bit, filePosition 64 bit) (reviewer, 2026-10-26)"
  - "ISO 14229-1:2013 preview TOC (webstore.ansi.org): RequestFileTransfer is clause 14.6, modeOfOperation in Annex G (reviewer, 2026-10-26)"
---

# 0x38 — RequestFileTransfer

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x78
> File-based counterpart of 0x34/0x35: add, delete, replace, read or resume a file, or read a directory, on an ECU with a file system.

Related entries in this functional unit: [0x34 RequestDownload](0x34-request-download.md) ·
[0x35 RequestUpload](0x35-request-upload.md) · [0x36 TransferData](0x36-transfer-data.md) ·
[0x37 RequestTransferExit](0x37-request-transfer-exit.md)

## 1. What is it?

RequestFileTransfer (SID 0x38) addresses data by **file path and name** instead of by memory address. The
first parameter, **modeOfOperation**, selects the action:

| Value | Mode | Data direction afterwards |
|---|---|---|
| 0x01 | AddFile | Tester → ECU (download via 0x36) |
| 0x02 | DeleteFile | None — complete with the 0x78 response |
| 0x03 | ReplaceFile | Tester → ECU (download via 0x36) |
| 0x04 | ReadFile | ECU → tester (upload via 0x36) |
| 0x05 | ReadDir | ECU → tester (directory information via 0x36) |
| 0x06 | ResumeFile — 2020 only per py-uds [edition-dependent] | Tester → ECU, continuing a suspended download at a file position |

For modes that move data, the ECU answers with maxNumberOfBlockLength, the data then flows in
[0x36 TransferData](0x36-transfer-data.md) blocks, and [0x37 RequestTransferExit](0x37-request-transfer-exit.md)
closes the transfer — the same mechanics as [0x34](0x34-request-download.md) and
[0x35](0x35-request-upload.md).

Pitfall: the positive response SID **0x78** has the same value as NRC 0x78 (response pending). They never
collide: a positive response starts with `78`, a pending response is `7F 38 78`.
<!-- catalogue fields 1, 2 -->

## 2. Why is it needed?

- Infotainment units, telematics units, central gateways and vehicle high-performance computers (HPCs)
  run operating systems with file systems. Their content (configuration files, logs, map or media data,
  update packages) has no fixed memory address.
- With 0x34/0x35 the tester would need to know the physical layout of the storage, which changes with every
  software build and is hidden behind the OS.
- File operations such as delete and directory listing have no equivalent in the address-based services.

Who benefits: infotainment and gateway developers, workshop tools retrieving log files, software-update
teams, validation teams that need log or trace files from an HPC after a test drive.
<!-- catalogue field 3 -->

## 3. What is its purpose?

It opens a file operation and, for data-moving modes, a transfer state. It does not move the file content
itself (0x36 does), does not define the file-system layout, path syntax or directory-information format
(all OEM-specific), and does not install or activate software contained in a file.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Classic microcontroller ECU with flat flash | [0x34](0x34-request-download.md) / [0x35](0x35-request-upload.md) | No file system; 0x38 usually not implemented |
| Small configuration value | [0x2E](0x2E-write-data-by-identifier.md) / [0x22](0x22-read-data-by-identifier.md) | Identifier-based, no transfer |
| Large OTA-style update on an HPC | OEM update framework (often outside UDS) | 0x38 may only be used for diagnostic files [OEM-specific] |
| Install / activate an update package after transfer | [0x31 RoutineControl](0x31-routine-control.md) (OEM routine) and [0x11](0x11-ecu-reset.md) | 0x38 only stores the file |
<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Retrieving log files from a central gateway or HPC
- **Scenario:** After a validation drive, the team needs the gateway's diagnostic log directory.
- **Engineer's objective:** List the log directory and copy selected files to the PC.
- **Why this service:** Logs live in a file system; their names and sizes change.
- **Tester sends:** `38 05 <path length> "/log"` (ReadDir), then `38 04 … "/log/trip.bin" 00` (ReadFile),
  each followed by 0x36 uploads and 0x37. Paths illustrative.
- **ECU is expected to:** Return directory information length or file size and a block length; upload the
  content.
- **Engineer obtains:** Directory listing (OEM-defined format) and the log file, size checked against the
  0x78 response.
- **Test on success / failure:** Received byte count equals fileSizeUncompressed (or dirInfoLength);
  non-existent path → 0x31 [unverified].

### Use case: Replacing a configuration file on an infotainment unit
- **Scenario:** A workshop tool updates a network configuration file on the head unit.
- **Engineer's objective:** Replace the file atomically and confirm it was stored.
- **Why this service:** ReplaceFile keeps the path and replaces the content in one operation.
- **Tester sends:** Extended or programming session, security, `38 03 <path> <DFI> <size fields>`, 0x36
  blocks, 0x37.
- **ECU is expected to:** Accept only with security unlocked; keep the old file until the transfer ends
  successfully [OEM-specific].
- **Engineer obtains:** Positive 0x77; ReadFile of the same path returns the new content.
- **Test on success / failure:** Interrupt the transfer halfway — the old file must still be valid.

### Use case: Resuming a large transfer over an unstable link
- **Scenario:** A large data file is added over DoIP; the connection drops at 60 %.
- **Engineer's objective:** Continue without restarting from zero.
- **Why this service:** ResumeFile returns the file position at which the ECU can continue
  (2020 edition; not in 2013 per py-uds) [edition-dependent].
- **Tester sends:** `38 06 <path> <DFI> <size fields>` after reconnecting (and re-establishing session and
  security).
- **ECU is expected to:** Return filePosition; accept 0x36 blocks from there.
- **Engineer obtains:** Complete file with only the missing part transferred.
- **Test on success / failure:** Final file hash equals the source; ResumeFile without a suspended transfer
  → 0x24 [unverified].
<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. Tester sends `38 <mode> <pathLength> <path> [DFI] [fileSizeParameterLength sizeUncompressed sizeCompressed]`.
2. ECU checks session, security, length consistency for the mode, mode supported, path valid, file state
   (exists / does not exist), free space, preconditions.
3. DeleteFile: the ECU deletes and answers `78 02`. Done.
4. Other modes: the ECU opens the file, enters a transfer state (counter expected 0x01 [unverified for
   ResumeFile]) and answers with the block length and mode-specific fields.
5. Data flows with [0x36](0x36-transfer-data.md) — data in the request for 01/03/06, in the response for
   04/05. Block sizing rules are the same as for 0x34/0x35.
6. [0x37](0x37-request-transfer-exit.md) closes the file.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Extended or programming for write modes; read modes sometimes in extended | OEM |
| Security / authentication | Write and delete modes need security (0x27) or an authenticated role (0x29) | OEM |
| ECU operating conditions | File system mounted and writable; enough free space; vehicle state | OEM |
| Timing (P2 / P2* / S3) | File open/delete can take longer than P2 → 0x78 and P2*; TesterPresent during pauses | Standard timing, OEM values |

**Depends on:** [0x10](0x10-diagnostic-session-control.md), [0x27](0x27-security-access.md) /
[0x29](0x29-authentication.md), then [0x36](0x36-transfer-data.md) and
[0x37](0x37-request-transfer-exit.md). File-system ECUs are often reached over DoIP; requests with long
paths are multi-frame on CAN. See [protocol-fundamentals.md](../protocol-fundamentals.md#doip-iso-13400-2-essentials).
<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Present for modes | Values / encoding |
|---|---|---|---|---|
| 1 | SID | 1 | all | 0x38 |
| 2 | modeOfOperation | 1 | all | 0x01–0x06 (table in section 1) |
| 3–4 | filePathAndNameLength | 2 | all | Big-endian byte count n of the path |
| 5 … 4+n | filePathAndName | n | all | Path and name; ASCII in practice; syntax OEM-specific |
| next | dataFormatIdentifier | 1 | 01, 03, 04, 06 | High nibble compression, low nibble encryption; 0x00 = raw |
| next | fileSizeParameterLength | 1 | 01, 03, 06 | Byte count k of each of the next two fields |
| next | fileSizeUncompressed | k | 01, 03, 06 | File size after decompression |
| next | fileSizeCompressed | k | 01, 03, 06 | Size of the data actually transferred (= uncompressed when DFI compression is 0) |

DeleteFile (02) and ReadDir (05) end after the path. Sending a DFI or size fields with them is a length error.

The field presence per mode above matches both python-udsoncan and py-uds; not yet confirmed against the ISO
text.

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. modeOfOperation is a parameter: every
request gets a response.

| Mode | What it does | Typical use | Request fields after path | Response fields after mode echo |
|---|---|---|---|---|
| 01 AddFile | Creates a new file and opens it for download | Store a new config, data or package file | DFI, size fields | LFID, maxNumberOfBlockLength, DFI |
| 02 DeleteFile | Deletes the file | Remove old logs or packages | — | — |
| 03 ReplaceFile | Overwrites an existing file (or creates it [OEM-specific]) | Update config files | DFI, size fields | LFID, maxNumberOfBlockLength, DFI |
| 04 ReadFile | Opens the file for upload | Retrieve logs, configs | DFI | LFID, maxNumberOfBlockLength, DFI, fileSizeOrDirInfoParameterLength, fileSizeUncompressed, fileSizeCompressed |
| 05 ReadDir | Opens a directory listing for upload | Discover file names and sizes | — | LFID, maxNumberOfBlockLength, DFI (0x00), fileSizeOrDirInfoParameterLength, dirInfoLength |
| 06 ResumeFile (2020) [edition-dependent] | Re-opens a suspended download | Continue after link loss | DFI, size fields | LFID, maxNumberOfBlockLength, DFI, filePosition |

### Positive response

| Byte | Parameter | Size | Present for modes | Meaning |
|---|---|---|---|---|
| 1 | Response SID | 1 | all | 0x78 |
| 2 | modeOfOperation | 1 | all | Echo |
| next | lengthFormatIdentifier | 1 | 01, 03, 04, 05, 06 | Byte count k of maxNumberOfBlockLength. Unlike 0x74/0x75, the whole byte is the count (e.g. 0x02), not the high nibble (python-udsoncan and py-uds agree) |
| next | maxNumberOfBlockLength | k | 01, 03, 04, 05, 06 | Largest 0x36 message, including SID and counter; same rules as [0x36](0x36-transfer-data.md#5-how-does-it-work) [unverified for 0x38] |
| next | dataFormatIdentifier | 1 | 01, 03, 04, 05, 06 | Format the ECU will use/accept; 0x00 for ReadDir |
| next | fileSizeOrDirInfoParameterLength | 2 | 04, 05 | Byte count m of the following size field(s) (2-byte width: python-udsoncan and py-uds agree) |
| next | fileSizeUncompressedOrDirInfoLength | m | 04, 05 | ReadFile: uncompressed file size. ReadDir: length of the directory information that will be uploaded |
| next | fileSizeCompressed | m | 04 | Number of bytes that will actually be uploaded |
| next | filePosition | 8 | 06 | Byte offset in the file at which the transfer continues (fixed 8 bytes: python-udsoncan and py-uds agree) |

DeleteFile response is only `78 02`.

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length does not match filePathAndNameLength, fileSizeParameterLength or the fields required by the mode |
| 0x22 | conditionsNotCorrect | File system not ready, file in use, vehicle preconditions fail |
| 0x24 | requestSequenceError | ResumeFile without a suspended transfer for that file [unverified] |
| 0x31 | requestOutOfRange | Mode not supported (00, ≥ 07, or 06 on an older ECU); path invalid or not found; DFI unsupported; size exceeds free space [unverified for the last two] |
| 0x33 | securityAccessDenied | Mode requires a security level that is not unlocked |
| 0x34 | authenticationRequired | 0x29 role missing [edition-dependent, 2020] |
| 0x70 | uploadDownloadNotAccepted | ECU refuses the file operation for another reason (e.g. AddFile on an existing file, write-protected path) [OEM-specific] |
| 0x72 | generalProgrammingFailure | Delete or file-system write failed [unverified] |
| 0x78 | requestCorrectlyReceived-ResponsePending | Opening, creating or deleting takes longer than P2 |
| 0x7F | serviceNotSupportedInActiveSession | Wrong session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Paths, sizes and block lengths are illustrative; the block
length 0x0402 matches the shared example in [0x34](0x34-request-download.md#examples).

**Example 1 — AddFile, 2 KiB, then two blocks:**

```uds
REQ 38 01 00 0C 2F 63 66 67 2F 6E 65 74 2E 62 69 6E 00 02 08 00 08 00   # AddFile "/cfg/net.bin"
POS 78 01 02 04 02 00                  # LFID 2, max 0x0402, DFI 00
REQ 36 01 ..                           # 1024 bytes of file data
POS 76 01
REQ 36 02 ..                           # last 1024 bytes
POS 76 02
REQ 37
POS 77
```

| Bytes | Field | Decoded |
|---|---|---|
| 01 | modeOfOperation | AddFile |
| 00 0C | filePathAndNameLength | 12 bytes |
| 2F 63 … 6E | filePathAndName | ASCII "/cfg/net.bin" (illustrative) |
| 00 | DFI | No compression, no encryption |
| 02 | fileSizeParameterLength | Size fields are 2 bytes each |
| 08 00 / 08 00 | fileSizeUncompressed / Compressed | 2048 / 2048 bytes |
| 78 01 | Response | Positive response, mode echo |
| 02 04 02 | LFID + maxNumberOfBlockLength | 2-byte value 0x0402 = 1026 → 1024 data bytes per block |
| 00 | DFI | Raw data accepted |

**Example 2 — ReadDir then ReadFile:**

```uds
REQ 38 05 00 04 2F 6C 6F 67            # ReadDir "/log"
POS 78 05 02 04 02 00 00 02 00 40      # dir info = 64 bytes
REQ 36 01
POS 76 01 ..                           # 64 bytes of directory information (format OEM-specific)
REQ 37
POS 77
REQ 38 04 00 0D 2F 6C 6F 67 2F 74 72 69 70 2E 62 69 6E 00   # ReadFile "/log/trip.bin", raw
POS 78 04 02 04 02 00 00 02 0C 00 0C 00                       # file size 3072 / 3072
REQ 36 01
POS 76 01 ..
REQ 36 02
POS 76 02 ..
REQ 36 03
POS 76 03 ..                           # 3 × 1024 = 3072 bytes
REQ 37
POS 77
```

| Bytes | Field | Decoded |
|---|---|---|
| 38 05 00 04 2F 6C 6F 67 | ReadDir | Path "/log" (4 bytes); no DFI, no size |
| 78 05 02 04 02 00 | Response head | LFID 2, max 0x0402, DFI 00 |
| 00 02 00 40 | Dir info | fileSizeOrDirInfoParameterLength 2; dirInfoLength 0x0040 = 64 |
| 38 04 … 00 | ReadFile | Path "/log/trip.bin" (13 bytes), DFI 00 |
| 00 02 0C 00 0C 00 | File size | Parameter length 2; uncompressed 0x0C00 = 3072; compressed 3072 |

**Example 3 — DeleteFile and ResumeFile:**

```uds
REQ 38 02 00 0D 2F 6C 6F 67 2F 74 72 69 70 2E 62 69 6E   # DeleteFile "/log/trip.bin"
NEG 7F 38 78                                              # deleting
POS 78 02                                                 # deleted
REQ 38 06 00 0C 2F 63 66 67 2F 6E 65 74 2E 62 69 6E 00 02 08 00 08 00   # ResumeFile [unverified]
POS 78 06 02 04 02 00 00 00 00 00 00 00 04 00                           # continue at byte 1024
REQ 36 01 ..                           # bytes 1024 … 2047; counter restart at 01 [unverified]
POS 76 01
REQ 37
POS 77
```

| Bytes | Field | Decoded |
|---|---|---|
| 38 02 00 0D … | DeleteFile | Path only |
| 7F 38 78 / 78 02 | Responses | Pending, then positive (mode echo only) |
| 38 06 … 00 02 08 00 08 00 | ResumeFile | Same fields as AddFile |
| 02 04 02 00 | Response head | LFID 2, max 0x0402, DFI 00 |
| 00 00 00 00 00 00 04 00 | filePosition | 8 bytes = 1024: first 1024 bytes already stored |

**Example 4 — refusals:**

```uds
REQ 38 07 00 04 2F 6C 6F 67            # mode 07 does not exist
NEG 7F 38 31
REQ 38 02 00 0D 2F 6C 6F 67            # path length says 13, only 4 path bytes sent
NEG 7F 38 13
REQ 38 04 00 08 2F 6E 6F 2F 66 69 6C 65 00   # ReadFile "/no/file" — not found (NRC choice unverified)
NEG 7F 38 31
REQ 38 06 00 0C 2F 63 66 67 2F 6E 65 74 2E 62 69 6E 00 02 08 00 08 00   # nothing to resume
NEG 7F 38 24
REQ 38 01 00 0C 2F 63 66 67 2F 6E 65 74 2E 62 69 6E 00 02 08 00 08 00   # security locked
NEG 7F 38 33
```

| Bytes | Decoded |
|---|---|
| 7F 38 31 (mode 07) | Unsupported modeOfOperation |
| 7F 38 13 | filePathAndNameLength inconsistent with the message length |
| 7F 38 31 (not found) | Path not found — some ECUs use 0x22 or 0x70 [unverified] |
| 7F 38 24 | ResumeFile without a suspended transfer [unverified] |
| 7F 38 33 | Write mode needs security |
<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**
- Builder: validate mode; encode path as ASCII (or the OEM's encoding) and its length on 2 bytes; add DFI
  only for 01/03/04/06 and size fields only for 01/03/06; choose fileSizeParameterLength as the smallest
  width that fits, unless the OEM fixes it.
- Parser: switch on the echoed mode; LFID is a full-byte count here (differs from 0x74/0x75 — easy bug);
  reject LFID 0; ReadDir DFI must be 0x00; filePosition is 8 bytes. Reject trailing bytes or allow zero
  padding explicitly.
- Transfer: reuse the 0x36/0x37 engine from [0x34](0x34-request-download.md#7-implementation-and-testing);
  stop uploads at fileSizeCompressed or dirInfoLength bytes.
- ResumeFile: seek the source to filePosition; restart the counter at 0x01 unless the OEM says otherwise
  [unverified].
- Do not interpret directory information without the OEM format definition.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path per mode | Examples 1–3 | Correct response fields per mode |
| 2 | Invalid mode | 00, 07, FF | 0x31 |
| 3 | ResumeFile support | 06 on 2013-era ECU | 0x31 or supported [edition-dependent] |
| 4 | Path length min-1 | pathLength one larger than the bytes sent | 0x13 |
| 5 | Path length 0 | `38 04 00 00 00` | 0x13 or 0x31 [unverified] |
| 6 | Extra fields | DFI added to DeleteFile / ReadDir | 0x13 |
| 7 | Missing fields | AddFile without size fields | 0x13 |
| 8 | Size field boundary | fileSizeParameterLength 0, or larger than ECU supports | 0x13 / 0x31 [unverified] |
| 9 | File state | AddFile on existing file; ReplaceFile/ReadFile/DeleteFile on missing file | OEM-defined NRC (0x70/0x31/0x22) |
| 10 | Free space | AddFile larger than free space | 0x70 or 0x31 [unverified] |
| 11 | Unsupported DFI | DFI 0x11 | 0x31 |
| 12 | Session matrix | Default / extended / programming per mode | 0x7F where not allowed |
| 13 | Security matrix | Write/delete modes locked vs unlocked; read modes | 0x33 / positive |
| 14 | Authentication (2020 ECU) | Missing role | 0x34 |
| 15 | Upload length | Bytes received vs fileSizeCompressed / dirInfoLength | Equal |
| 16 | Interrupted ReplaceFile | Abort after half the blocks | Old file still valid [OEM-specific] |
| 17 | Resume | Abort AddFile at 60 %, ResumeFile | filePosition matches stored bytes; final hash OK |
| 18 | Functional addressing | 0x38 functional | No response [OEM-specific] |
| 19 | Mode echo / no SPRMIB | Any mode | Response always sent, echoes the mode |
| 20 | Response pending | Delete large file | 0x78 then `78 02` within P2* |
| 21 | Multi-frame / DoIP | 200-byte path over CAN; same over DoIP | Correct segmentation; same UDS result |
| 22 | 0x78 disambiguation | Tester parser | `78 xx` = positive, `7F 38 78` = pending |
<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 15.6 (upload/download functional unit), from the preview TOC |
| Edition differences | 0x38 is present in 2013 (2013 preview TOC clause 14.6); not in the 2006 edition [unverified]. ResumeFile (0x06): py-uds keeps separate mappings and lists 01–05 for 2013 and 01–06 for 2020, so ResumeFile is a 2020 addition [edition-dependent]. python-udsoncan also lists 06 but cites 2013 Annex G only for the mode list as a whole. A 2013 ECU should answer `38 06 …` with 0x31. 2026 not yet reviewed |
| OEM / ECU-specific | Path syntax and encoding; directory information format; which modes exist; session/security per mode; NRC for file-state errors; atomic replace behaviour; maximum file size |
| Verification status | cross-checked. Reviewer 2026-10-26: status raised to cross-checked — modes, per-mode fields and field widths confirmed by py-uds and python-udsoncan source. Previously draft. Clause number cross-checked (preview TOC). Reviewer 2026-10-26: mode values, per-mode request/response fields, full-byte LFID, 2-byte fileSizeOrDirInfoParameterLength, 8-byte filePosition, ReadDir DFI 0x00 and ResumeFile = 2020 checked against python-udsoncan and py-uds source (two independent open-source implementations, not normative). All hex examples re-decoded (path lengths, size fields). Not checked against the ISO text |
| Open questions | NRC for "file not found"; block counter start for ResumeFile; whether maxNumberOfBlockLength has the same SID + counter meaning as for 0x34/0x35 |
<!-- catalogue field 15 -->
