---
sid: 0x11
name: ECUReset
response_sid: 0x51
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.3 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (standards.iteh.ai sample 72439): clause 10.3"
  - "py-uds knowledge base (uds.readthedocs.io, latest; service.rst source): request/response layout, resetType values and ranges, powerDownTime encoding"
  - "py-uds translator source (github.com/mdabrowski1990/uds, data_record_definitions/conditional.py): powerDownTime only in the 0x04 response"
  - "udsoncan documentation (udsoncan.readthedocs.io): reset types 01-05, powerdown_time only for 04"
---

# 0x11 — ECUReset

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x51
> Asks the server to perform a reset of a given type, or to enable/disable its rapid power shutdown function.

## 1. What is it?

ECUReset (SID 0x11) makes the server restart. The sub-function (resetType) says which kind of restart:
a full power-on style reset, a simulated ignition off/on, or an application restart. Two further values do not
reset at all: they switch the server's rapid power shutdown function on or off. The server answers **before**
it resets. After the reset it runs in defaultSession with security locked.

## 2. Why is it needed?

- After flashing or coding, new software or configuration only takes effect after a restart. A tester cannot
  cut ECU power on a sealed vehicle, but it can send 0x11.
- Validation needs repeatable resets to test start-up behaviour, NVM handling and initialisation DTCs without
  a programmable power supply.
- A tester can recover a server from a stuck state without removing a fuse.
- Rapid power shutdown lets a server go to sleep quickly after ignition off, e.g. to save battery during
  production or transport [OEM-specific].

Who gets value: flash tools (last step of every flash), EOL (activate coding), validation and HIL teams
(start-up tests), workshops (after repair or coding).

## 3. What is its purpose?

It triggers a defined restart and returns the server to its start-up state: defaultSession, security locked,
communication enabled, DTC setting on. What is kept in non-volatile memory depends on the reset type and the
implementation. It does not erase DTCs, change coding or switch sessions without resetting.

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Only leave a non-default session | [0x10](0x10-diagnostic-session-control.md) `10 01` | Resets session states without restarting the ECU |
| Clear fault memory | 0x14 ClearDiagnosticInformation | Reset does not clear stored DTCs |
| Real power-loss behaviour (brown-out, cranking) | Programmable power supply on the HIL | 0x11 cannot simulate supply profiles |
| Restore a factory default configuration | OEM routine (0x31) or 0x2E writes | No ISO reset type guarantees a defined NVM content |

## 4. When is it used? — Real use cases

### Use case: Activating new software at the end of flashing
- **Scenario:** Application download finished; checkProgrammingDependencies passed.
- **Engineer's objective:** Start the new application and confirm it runs.
- **Why this service:** The bootloader jumps to the application only after a reset [OEM-specific].
- **Tester sends:** `11 01` physical to the flashed ECU, then functional `28 80 01`, `85 81`, `10 81` to restore
  the rest of the network (`10 81` alone also restores communication and DTC setting).
- **ECU is expected to:** Reply `51 01` within P2server_max, then reset, validate the application and start it.
- **Engineer obtains:** A running ECU reporting the new software number (DID 0xF188 / 0xF195).
- **Test on success / failure:** Success: `22 F1 88` returns the new version after the start-up time.
  Failure: no answer after the reset (bootloader stuck on invalid application), or `7F 11 22`.

### Use case: Restraint ECU start-up and EDR retention test (HIL)
- **Scenario:** Airbag control unit on a HIL bench with squib simulators and a stored crash record.
- **Engineer's objective:** Check that a reset does not lose crash data (EDR) and that the unit is ready
  again within its specified start-up time.
- **Why this service:** Gives a repeatable reset without touching the bench supply.
- **Tester sends:** Read the EDR DIDs (OEM-defined), `11 01`, wait the start-up time, read again; repeat with
  `11 03`.
- **ECU is expected to:** Keep all locked crash records; run its self-test and warning lamp check; reject the
  reset with `7F 11 22` while it is still writing a crash record [OEM-specific].
- **Engineer obtains:** EDR content identical before and after reset; measured time to readiness.
- **Test on success / failure:** Any EDR difference or a readiness time above spec is a defect.

### Use case: Rapid power shutdown during production
- **Scenario:** Vehicle leaves the EOL line; ECUs should sleep immediately at key-off.
- **Engineer's objective:** Enable the shutdown function and read how long the ECU needs.
- **Why this service:** 0x04 / 0x05 are the ISO way to control this function.
- **Tester sends:** `11 04`; later `11 05`.
- **ECU is expected to:** Answer `51 04 <powerDownTime>`; at the next key-off power down fast. How long the
  function stays armed (until `11 05`, next key-on, or a reset) is [unverified] [OEM-specific].
- **Engineer obtains:** The minimum stand-by time in seconds (or 0xFF = not available).
- **Test on success / failure:** Measure the current draw after key-off against the returned time.

## 5. How does it work?

1. Client sends `11 <resetType>`.
2. Server checks length, sub-function, session and security, then conditions (vehicle speed, ignition state,
   flash or EEPROM write in progress, crash recording) [OEM-specific].
3. Server sends `51 <resetType> [powerDownTime]` and only then resets. With SPRMIB set it resets without
   a response. The reset must not start before the response has left the transport layer, otherwise the tester
   sees a timeout [unverified wording].
4. During the reset the server does not answer. Testers must wait an ECU-specific start-up time before the
   next request.
5. After the reset: defaultSession, security locked, CommunicationControl and ControlDTCSetting back to normal.
   On DoIP, when the reset ECU is the DoIP entity, the TCP connection is lost; the tester re-connects and
   repeats routing activation. An ECU behind a DoIP gateway resets without dropping the connection.

Response pending: this entry knows of no 0x11-specific exclusion from the general 0x78 mechanism. If a server
sends `7F 11 78` (e.g. it must finish an NVM write first), the final `51 xx` must still come before the reset,
and the tester must not count the 0x78 phase as start-up time. Most servers answer within P2 [unverified].
Stacks commonly trigger the reset only after the transmit confirmation of the positive response (e.g. AUTOSAR
Dcm) [unverified].

**Reset types and what they usually keep** ([OEM-specific]; ISO leaves the details to the implementation;
the whole table is [unverified] as a description of typical behaviour, not a rule):

| resetType | Typical behaviour | Volatile RAM | NVM (DTCs, coding, adaptations) |
|---|---|---|---|
| 01 hardReset | Like disconnecting and reconnecting the supply | Re-initialised | Usually kept; ISO allows re-initialising it [unverified] |
| 02 keyOffOnReset | Like ignition off then on | Re-initialised | Kept |
| 03 softReset | Restart of the application program only | Re-initialised (often partly) | Kept, including learned values |

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | 01 often allowed in all sessions; 02/03/04/05 often only in extended | OEM |
| Security / authentication | Usually none; some ECUs require it for 01 in extended | OEM |
| ECU operating conditions | Vehicle stationary, no NVM write in progress, no crash recording | OEM |
| Timing (P2 / P2* / S3) | Response within P2server_max of the current session, before the reset | ISO + OEM |

**Depends on:** ISO-TP single frame; tester logic to stop TesterPresent and wait for start-up; DoIP
re-connection after reset.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x11 |
| 2 | sub-function: SPRMIB (bit 7) + resetType (bits 6–0) | 1 | see table below |

Total length is exactly 2 bytes.

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x00 | reserved | — | — | 0x12 expected |
| 0x01 | hardReset | Full restart as after power-on | End of flashing, validation | Most widely supported |
| 0x02 | keyOffOnReset | Restart as after ignition off/on | Activate coding | NVM kept |
| 0x03 | softReset | Restart of the application only | Fast restart in development | Learned values kept |
| 0x04 | enableRapidPowerShutDown | Arms fast power-down at next key-off; no reset now | Production, transport mode | Response carries powerDownTime |
| 0x05 | disableRapidPowerShutDown | Disarms the function; no reset | Undo 0x04 | — |
| 0x06–0x3F | reserved | — | — | 0x12 expected |
| 0x40–0x5F | vehicleManufacturerSpecific | OEM reset types | e.g. reset to bootloader [OEM-specific] | Meaning from OEM spec only |
| 0x60–0x7E | systemSupplierSpecific | Supplier reset types | Supplier development | Usually disabled in series |
| 0x7F | reserved | — | — | 0x12 expected |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | RSID | 1 | 0x51 |
| 2 | resetType | 1 | Echo of the request, bit 7 = 0 |
| 3 | powerDownTime | 1 | Only for resetType 0x04. 0x00–0xFE = minimum stand-by time in seconds; 0xFF = failure or time not available |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | Reserved or unimplemented reset type |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Request is not exactly 2 bytes |
| 0x22 | conditionsNotCorrect | Vehicle moving, NVM write or crash recording in progress, ignition state wrong |
| 0x33 | securityAccessDenied | Reset type protected by a security level [OEM-specific] |
| 0x34 | authenticationRequired | 2020 ECU gates the reset type behind Authentication (0x29) [OEM-specific] |
| 0x78 | requestCorrectlyReceived-ResponsePending | Rare: server must finish pending work first; final `51 xx` still precedes the reset [unverified] |
| 0x7E | subFunctionNotSupportedInActiveSession | Reset type not allowed in the active session |
| 0x7F | serviceNotSupportedInActiveSession | 0x11 not allowed at all in the active session [OEM-specific] |
| 0x81–0x93 | specific conditions | Instead of 0x22 when the failing condition is known (e.g. 0x88) |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 11 01                    # hardReset, physical
POS 51 01                    # sent before the ECU resets
NOTE ECU silent during start-up (time is ECU-specific); then defaultSession, security locked
REQ 22 F1 86                 # ActiveDiagnosticSession
POS 62 F1 86 01              # defaultSession after reset
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 11 01 | request | ECUReset, hardReset, SPRMIB = 0 |
| 51 01 | response | 0x11 + 0x40, hardReset echoed |
| 62 F1 86 01 | DID 0xF186 = 01 | Server is in defaultSession |

```uds
REQ 11 04                    # enableRapidPowerShutDown
POS 51 04 0A                 # powerDownTime = 10 s (illustrative)
REQ 11 05                    # disableRapidPowerShutDown
POS 51 05
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 11 04 | request | Arm rapid power shutdown (no reset now) |
| 51 04 | RSID + echo | Accepted |
| 0A | 10 | Minimum stand-by time 10 s (illustrative); FF would mean failure / not available |
| 11 05 → 51 05 | request / response | Function disarmed; no powerDownTime byte |

```uds
REQ 11 81                    # hardReset with SPRMIB
NOTE no positive response; the ECU resets anyway
REQ 11 83                    # softReset with SPRMIB, functional, end of a flash sequence (OEM-specific)
NOTE all supporting ECUs reset silently
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 11 81 | 0x80 + 0x01 | SPRMIB + hardReset |
| 11 83 | 0x80 + 0x03 | SPRMIB + softReset |

```uds
REQ 11 01                    # vehicle speed above threshold
NEG 7F 11 22                 # conditionsNotCorrect (some ECUs use 88 vehicleSpeedTooHigh)
REQ 11 06                    # reserved
NEG 7F 11 12
REQ 11                       # too short
NEG 7F 11 13
REQ 11 02                    # keyOffOnReset requested in defaultSession on an ECU that allows it only in extended
NEG 7F 11 7E
```

| Request | Response | Why |
|---|---|---|
| 11 01 | 7F 11 22 | Precondition not met; no reset performed |
| 11 06 | 7F 11 12 | Reserved reset type |
| 11 | 7F 11 13 | Missing sub-function |
| 11 02 | 7F 11 7E | Reset type exists but not in this session [OEM-specific] |

## 7. Implementation and testing

**Implementation:**

- Request builder: reset type plus SPRMIB flag; warn when SPRMIB is set physically because the tester then
  cannot tell success from a lost frame.
- Response parser: length 2, or 3 for 0x04; decode powerDownTime (0xFF = not available).
- After a positive response (or after sending with SPRMIB): stop TesterPresent; mark session = default,
  security locked; wait the ECU start-up time; then poll with a harmless request (e.g. `22 F1 86` or `3E 00`)
  until it answers or a timeout expires.
- DoIP: expect the TCP connection to drop; re-connect and re-activate routing.
- Edge cases: response lost because the ECU reset too early; ECU answers the poll from the bootloader on other
  CAN IDs; repeated resets inside the start-up window.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive path per type | 11 01 / 02 / 03 in allowed sessions | 51 xx, then reset |
| 2 | Response before reset | Trace timing of 51 01 vs. loss of ECU messages | Response within P2server_max, before the ECU goes silent |
| 3 | State after reset | 22 F1 86; protected service | Session 01; 7F xx 33 or 7F xx 7F |
| 4 | Comm/DTC restored | 28 03 01 + 85 02, then 11 01 | Normal messages back; DTC setting on |
| 5 | NVM retention per type | Read coding/DTCs before and after 01/02/03 | Matches the OEM retention table |
| 6 | Rapid power shutdown | 11 04, key-off | 51 04 + powerDownTime; current drop as specified |
| 7 | Disable rapid shutdown | 11 05, key-off | Normal shutdown timing |
| 8 | Reserved values | 11 00, 11 06, 11 3F, 11 7F | 7F 11 12 |
| 9 | Length min-1 | 11 | 7F 11 13 |
| 10 | Length min = max | 11 01 | Positive |
| 11 | Length max+1 | 11 01 00 | 7F 11 13 |
| 12 | Session matrix | Each type in 01 / 02 / 03 / 04 | Per OEM spec; 7E / 7F elsewhere |
| 13 | Security matrix | Protected type locked vs unlocked | 7F 11 33 vs positive |
| 14 | Preconditions | Speed > 0, crash recording, NVM write | 7F 11 22 or 0x81–0x93; no reset |
| 15 | SPRMIB | 11 81 physical | No response; ECU resets |
| 16 | SPRMIB with error | 11 86 physical | 7F 11 12 still sent |
| 17 | Functional | 11 01 functional | Every supporting ECU answers 51 01 and resets |
| 18 | Functional unsupported | 11 06 functional | No response |
| 19 | Start-up time | Poll after 51 01 | First answer within the specified start-up time |
| 20 | Restraint ECU EDR | 11 01 with locked crash record | Record unchanged; lamp check and self-test run |
| 21 | Response pending | — | Not expected; if 7F 11 78 is seen, the final response must follow before reset |
| 22 | Multi-frame | — | Not applicable: single frames |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.3 (preview TOC). |
| Edition differences | No 2013 ↔ 2020 change known [unverified]. ISO 14229-1:2026 not yet reviewed. |
| OEM / ECU-specific | Which types exist; session and security rules; NVM retention per type; start-up time; use of 0x40–0x7E (e.g. jump to bootloader); whether functional reset is allowed. |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: request layout, resetType values and ranges, response layout with powerDownTime only for 0x04 and 0xFF = failure / not available (py-uds knowledge base service.rst and translator source; udsoncan docs); clause number (ISO 2020 preview TOC). Response-before-reset rule, 0x78 handling and retention table from engineering knowledge, not checked. |
| Open questions | Whether 0x78 before a reset is permitted; exact ISO wording on NVM handling for hardReset; whether 0x04 response is sent when the function is already armed. |
