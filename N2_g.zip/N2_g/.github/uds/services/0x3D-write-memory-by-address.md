---
sid: 0x3D
name: WriteMemoryByAddress
response_sid: 0x7D
has_sub_function: false
functional_unit: "Data transmission (clause 11)"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "11.8 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview Foreword + TOC (cdn.standards.iteh.ai sample 72439): clause number and functional unit"
  - "py-uds knowledge base (uds.readthedocs.io): service name, SID 0x3D, response SID 0x7D, writes into server memory at a given address"
  - "py-uds source (github.com/mdabrowski1990/uds, translator/service_definitions/write_memory_by_address.py; data_record_definitions/other.py, formula.py): request = ALFID + address + size + data, response = ALFID + address + size echo; ALFID high nibble = size length (reviewer, 2026-10-26)"
  - "python-udsoncan WriteMemoryByAddress.py: response parsed as alfid_echo + address echo + memorysize echo (reviewer, 2026-10-26)"
---

# 0x3D — WriteMemoryByAddress

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0x7D
> Writes a block of bytes into ECU memory at a given address; the response echoes the address and size.

## 1. What is it?

WriteMemoryByAddress (WMBA), SID 0x3D, is the write counterpart of 0x23. The tester sends an
addressAndLengthFormatIdentifier (ALFID), a start address, a size and exactly that many data bytes. The ECU
writes the bytes and answers with an echo of the ALFID, address and size.

It writes raw bytes. The ECU does not know what they mean; there is no type, range or checksum check unless
the ECU adds one for a specific region.

## 2. Why is it needed?

- Calibration and development work needs to change parameters that have no writable DID.
- It allows quick experiments (thresholds, filter constants, debug switches) without a new software build.
- Fault injection in development: corrupt a RAM value or NVM mirror on purpose to test error handling.

Who benefits: calibration and software developers, validation teams doing robustness tests. Series production
and workshops should not need it; most series ECUs disable it.

## 3. What is its purpose?

Raw memory writes in development and calibration. It changes memory and returns only the echo. It does not
erase or program flash (use the download services), and it does not validate content.

**Risks:**
- A wrong address or size can corrupt unrelated data, crash the ECU or put it in an unsafe state.
- Writes to calibration or NVM can survive reset and silently change ECU behaviour.
- On safety ECUs (airbag, braking, steering), a write can disable or trigger functions. A restraint ECU must
  never run WMBA tests with live squibs connected; use resistor loads.
- The map file must match the running software build exactly; addresses move between builds.
- An open WMBA in series software is a security hole (it can bypass coding checks or change secure counters).

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Data has a writable DID | [0x2E WriteDataByIdentifier](0x2E-write-data-by-identifier.md) | Checked by the ECU, stable across builds |
| Program flash or a large data set | 0x34 RequestDownload, 0x36, 0x37 | Erase, block transfer, integrity checks |
| Online calibration with many parameters | XCP/CCP calibration | Page switching, made for calibration |
| Temporary actuator override | 0x2F InputOutputControlByIdentifier | Returns control to the ECU automatically |
| Read back | [0x23 ReadMemoryByAddress](0x23-read-memory-by-address.md) | Same ALFID scheme |

## 4. When is it used? — Real use cases

### Use case: Tuning a calibration constant on a development ECU
- **Scenario:** Development bench; a filter time constant lives in a calibration RAM area.
- **Engineer's objective:** Try a new value without rebuilding software.
- **Why this service:** No DID exists for the parameter; the A2L gives its address.
- **Tester sends:** `10 03`, supplier-level 0x27 unlock, `3D 24 00 08 10 40 00 02 00 64`
  (address 0x00081040, 2 bytes, value 0x0064 — illustrative), then `23 24 00 08 10 40 00 02`.
- **ECU is expected to:** Write the 2 bytes, answer `7D 24 00 08 10 40 00 02`, return the new value on read-back.
- **Engineer obtains:** Changed behaviour to evaluate on the bench.
- **Test on success / failure:** Pass if echo and read-back match. A read-back that reverts after reset shows
  the area is RAM only.

### Use case: Fault injection in a restraint ECU robustness test
- **Scenario:** HIL bench with resistor squib loads. The test must check the ECU's reaction to a corrupted
  internal configuration mirror.
- **Engineer's objective:** Corrupt one byte of a RAM mirror and observe detection and the DTC.
- **Why this service:** Direct write to the mirror address from the map file; no other way to inject this fault.
- **Tester sends:** Unlock with development level, `3D 14 20 00 5C 00 01 FF` (address and value illustrative).
- **ECU is expected to:** Echo, then detect the inconsistency within its monitoring cycle and set the related
  DTC; the warning lamp request follows.
- **Engineer obtains:** Detection time and DTC, read with 0x19.
- **Test on success / failure:** Pass if detection happens within the specified time and the reaction is safe.
  Afterwards reset the ECU and confirm the mirror is restored.

## 5. How does it work?

1. Tester sends `3D`, ALFID, address, size, data.
2. ECU checks the length (it must be 2 + address bytes + size bytes + memorySize), the ALFID, the address range
   (writable region, inside limits), security and conditions. General NRC order:
   [../protocol-fundamentals.md](../protocol-fundamentals.md).
3. ECU writes the data. RAM is immediate. EEPROM/data flash may take longer than P2 and use 0x78.
4. ECU answers `7D` + ALFID + address + size (no data echo).

**ALFID:** high nibble = number of bytes of memorySize, low nibble = number of bytes of memoryAddress, same as
[0x23](0x23-read-memory-by-address.md). In the message the address comes before the size. Big-endian.

**The echo.** The response repeats ALFID, address and size. The tester should compare the echo with the request
byte for byte. A mismatch means the ECU wrote somewhere else or misparsed the request; stop the test.

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Extended or a development/supplier session; sometimes programming | OEM |
| Security / authentication | Highest development/supplier 0x27 level, or 0x29 role in 2020 ECUs | OEM |
| ECU operating conditions | Vehicle stationary, no active safety function, voltage in range | OEM |
| Timing (P2 / P2* / S3) | P2 for RAM; 0x78 + P2* for NVM regions | ISO; values in [../protocol-fundamentals.md](../protocol-fundamentals.md) |

**Depends on:** 0x10, 0x27/0x29, 0x23 for read-back, ISO-TP for writes longer than one frame, the build's
map/A2L.

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x3D |
| 2 | addressAndLengthFormatIdentifier | 1 | High nibble = size length, low nibble = address length |
| 3 … | memoryAddress | low nibble bytes | Big-endian |
| … | memorySize | high nibble bytes | Big-endian, number of data bytes |
| … | dataRecord | memorySize | Bytes to write |

### Sub-functions

No sub-function; suppressPosRspMsgIndicationBit does not apply. Byte 2 is the ALFID.

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0x7D |
| 2 | addressAndLengthFormatIdentifier | 1 | Echo |
| 3 … | memoryAddress | as request | Echo |
| … | memorySize | as request | Echo |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x13 | incorrectMessageLengthOrInvalidFormat | Length does not match ALFID + memorySize |
| 0x22 | conditionsNotCorrect | OEM conditions not met |
| 0x31 | requestOutOfRange | ALFID nibble invalid; address/size outside writable regions; size 0 |
| 0x33 | securityAccessDenied | Required level not unlocked |
| 0x34 | authenticationRequired | 2020 ECUs using 0x29 [edition-dependent] [unverified] |
| 0x72 | generalProgrammingFailure | Write to NVM failed or verify failed |
| 0x78 | requestCorrectlyReceived-ResponsePending | NVM write longer than P2 |
| 0x7F | serviceNotSupportedInActiveSession | Not available in the current session |
| 0x11 | serviceNotSupported | Removed from series software |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal. Addresses and data come from a hypothetical map file.

```uds
REQ 3D 24 00 08 10 40 00 02 00 64   # write 0x0064 at 0x00081040 (illustrative)
POS 7D 24 00 08 10 40 00 02         # echo ALFID, address, size
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 1 | 3D | WriteMemoryByAddress |
| REQ 2 | 24 | ALFID: size field 2 bytes, address field 4 bytes |
| REQ 3–6 | 00 08 10 40 | Address 0x00081040 (illustrative) |
| REQ 7–8 | 00 02 | Size 2 bytes |
| REQ 9–10 | 00 64 | Data (illustrative) |
| POS 1 | 7D | Positive response (0x3D + 0x40) |
| POS 2–8 | 24 … 00 02 | Echo of ALFID, address, size; no data echo |

Write to an NVM region with response pending.

```uds
REQ 3D 14 00 0E 00 20 04 11 22 33 44   # 4 bytes into an EEPROM-backed area (illustrative)
NEG 7F 3D 78
POS 7D 14 00 0E 00 20 04
```

| Byte | Value | Meaning |
|---|---|---|
| REQ 2 | 14 | 1-byte size, 4-byte address |
| REQ 3–6 | 00 0E 00 20 | Address (illustrative) |
| REQ 7 | 04 | 4 bytes |
| REQ 8–11 | 11 22 33 44 | Data (illustrative) |
| NEG | 7F 3D 78 | Pending; tester uses P2* |
| POS | 7D 14 00 0E 00 20 04 | Echo |

Negative responses.

```uds
REQ 3D 14 20 00 5C 00 02 FF          # size 2, only 1 data byte
NEG 7F 3D 13
REQ 3D 14 00 00 00 00 01 00          # address 0 not writable (illustrative)
NEG 7F 3D 31
REQ 3D 14 20 00 5C 00 01 FF          # locked
NEG 7F 3D 33
```

| Exchange | Problem | NRC |
|---|---|---|
| 1 | Data shorter than memorySize | 13 |
| 2 | Region not writable | 31 |
| 3 | Security locked | 33 |

## 7. Implementation and testing

**Implementation:**
- Builder: address, data, address width, size width. Size comes from the data length; never take it as a
  separate argument that can disagree. Validate widths and the ALFID nibbles.
- Response check: compare the echo with request bytes 2 … (2 + address bytes + size bytes − 1). Fail on any
  difference.
- Always read back with 0x23, and restore the original bytes in teardown (read them before writing).
- Keep a whitelist of allowed regions per software build in the test framework; refuse writes outside it
  before they reach the ECU.
- Timeouts: P2, then P2* after 0x78.
- Physical addressing only; never broadcast memory writes.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive RAM write | Valid request | Echo; 0x23 read-back matches |
| 2 | Positive NVM write | NVM region | `7F 3D 78` (maybe) then echo; persists after reset |
| 3 | Echo check | Each supported ALFID | Echo equals request header |
| 4 | Length min-1 | Data one byte short | `7F 3D 13` |
| 5 | Length exact | Data = memorySize | Positive |
| 6 | Length max+1 | One extra data byte | `7F 3D 13` |
| 7 | Size 0 | memorySize 0 | `7F 3D 31` [unverified] |
| 8 | Max size | Largest allowed write (multi-frame) | Positive |
| 9 | Max size+1 | One byte over | `7F 3D 31` |
| 10 | Region edges | Start of region; end exactly at region end; one byte past | Positive, positive, `7F 3D 31` |
| 11 | Protected region | Key storage, boot area | `7F 3D 31` or `7F 3D 33`; no change on read-back |
| 12 | Invalid ALFID | Nibble 0 or unsupported | `7F 3D 31` |
| 13 | Session matrix | Default, extended, programming | Per OEM spec; default `7F 3D 7F` |
| 14 | Security matrix | Locked, lower level, required level | `7F 3D 33`, `7F 3D 33`, positive |
| 15 | Conditions | Vehicle speed > 0 (simulated) | `7F 3D 22` |
| 16 | NVM failure | Fault-inject if bench allows | `7F 3D 72` |
| 17 | Functional addressing | Request on functional ID | Ignored or rejected |
| 18 | Series software | Production build | `7F 3D 11` |

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 11.8 (data transmission functional unit). ALFID shared with 0x23, 0x2C, 0x34, 0x35. |
| Edition differences | No layout change between 2013 and 2020 known [unverified]. 2020 authentication may add NRC 0x34 [edition-dependent] [unverified]. 2026 edition not yet reviewed. |
| OEM / ECU-specific | Writable regions, accepted ALFIDs, maximum size, sessions, security level, NVM timing, whether the service exists in series software. |
| Verification status | cross-checked. Reviewer 2026-10-26: status raised to cross-checked — core structure (request layout, ALFID + address + size echo) confirmed by py-uds and python-udsoncan source. Previously draft. Cross-checked: clause number, SID/response SID, purpose (py-uds docs). Reviewer 2026-10-26: request layout, ALFID nibble order and the ALFID + address + size echo checked against py-uds and python-udsoncan source (open-source, not normative). NRC list from engineering knowledge. Note: pyudskit.readthedocs.io shows the response as `7D` only, which conflicts with both libraries. |
| Open questions | Whether ISO lists 0x72 for this service; whether the positive response must wait for the NVM commit; NRC for size 0. |
