---
sid: 0x87
name: LinkControl
response_sid: 0xC7
has_sub_function: true
functional_unit: "Diagnostic and communication management"
baseline_edition: "ISO 14229-1:2020 + Amd 1:2022"
iso_clause: "10.10 (ISO 14229-1:2020 preview TOC)"
status: cross-checked
last_reviewed: 2026-10-26
sources:
  - "ISO 14229-1:2020 preview TOC (cdn.standards.iteh.ai sample 72439) — clause number and functional unit only"
  - "py-uds translator source (github.com/mdabrowski1990/uds: utilities/constants/subfunctions.py and other.py, data_record_definitions/conditional.py and other.py, service_definitions/link_control.py) — linkControlType 01–03 names, linkControlModeIdentifier table, linkRecord 24 bits, parameters per type, echo-only response"
  - "udsoncan source and docs (github.com/pylessard/python-udsoncan: common/Baudrate.py; udsoncan.readthedocs.io) — fixed baud rate identifiers 0x01–0x05 and 0x10–0x13, specific baud rate as 3 bytes big-endian"
  - "Engineering knowledge — fallback rules, response timing for physical 87 03, OEM ranges (not cross-checked)"
---

# 0x87 — LinkControl

> **Status:** cross-checked · **Baseline:** ISO 14229-1:2020 + Amd 1:2022 · **Positive response SID:** 0xC7
> Two-step switch of the diagnostic link to another bit rate: first check that the target rate is possible,
> then trigger the switch.

## 1. What is it?

LinkControl (SID 0x87) changes the communication parameters of the diagnostic link, in practice the bit rate.
The sub-function is the **linkControlType**:

- `0x01` verifyModeTransitionWithFixedParameter — ask "can you switch to this predefined mode?"
  (1-byte **linkControlModeIdentifier**, e.g. a baud rate identifier).
- `0x02` verifyModeTransitionWithSpecificParameter — same, with an explicit value (**linkRecord**, e.g. a
  3-byte bit rate).
- `0x03` transitionMode — perform the switch that was verified before.

The server answers the verify step at the current rate. After `transitionMode` it changes its controller to the
new rate. The tester must change its own rate at the same time.

## 2. Why is it needed?

Download speed matters in flashing. Large images over classical CAN at 500 kbit/s take a long time. If the
network and ECUs can run faster for the duration of the programming session, LinkControl provides a
standardized way to move all participants together and return them afterwards.

The two-step design is the point: verify first, so that every node that will switch has said yes. Switching a
single node alone on a shared bus causes error frames and bus-off on that segment. Value: flashing tools,
production line end-of-line programming, legacy K-Line testers.

Today it is less common. CAN FD, DoIP and fixed data-phase bit rates often make a run-time rate change
unnecessary [OEM-specific].

## 3. What is its purpose?

It verifies and then performs a link mode transition. It does not change the transport protocol, the CAN
identifiers, the addressing or the session. It does not persist: the link falls back to its default mode when
the session ends or the ECU resets [unverified — confirm in the edition and OEM spec].

**Do not use it when / alternatives:**

| Situation | Use instead | Why |
|---|---|---|
| Only quieter traffic is needed during flashing | CommunicationControl (0x28) | Stops normal messages without touching the bit rate |
| CAN FD network with a fixed data-phase rate | Nothing — use the configured rate | No transition needed |
| DoIP / Ethernet | Nothing | Link speed is not a diagnostic parameter |
| Adjust timing (P2/P2*) | Session response of 0x10 ([../protocol-fundamentals.md](../protocol-fundamentals.md#timing)) | 0x87 changes the link, not application timing |

<!-- catalogue fields 4, 7 -->

## 4. When is it used? — Real use cases

### Use case: Faster download on a classical CAN programming network
- **Scenario:** End-of-line programming station flashes several ECUs on a dedicated diagnostic CAN at 500 kbit/s.
  The OEM spec allows 1 Mbit/s in programmingSession.
- **Engineer's objective:** Cut programming time without changing the network for normal operation.
- **Why this service:** It moves all nodes to the new rate in a coordinated way.
- **Tester sends:** Functional `10 82` (or `10 83`, depending on which session the OEM allows 0x87 in),
  `85 82`, `28 83 01` (illustrative), then physical `87 01 13` to each node, then functional `87 83`
  [OEM-specific sequence].
- **ECU is expected to:** Answer `C7 01` at 500 kbit/s; after `87 83`, switch to 1 Mbit/s without responding.
- **Engineer obtains:** The flash sequence runs at the higher rate.
- **Test on success / failure:** First request at the new rate (e.g. `3E 00`) gets `7E 00`. Error frames,
  no answer or bus-off mean a node did not switch or switched without verifying.

### Use case: Validation of rate fallback after the session ends
- **Scenario:** HIL test of a gateway that supports LinkControl.
- **Engineer's objective:** Prove the ECU does not stay at the high rate when the tester disappears.
- **Why this service:** Only 0x87 can put the link into the non-default mode.
- **Tester sends:** `10 02`, `87 01 13`, `87 03`, switch tester rate, then stop TesterPresent.
- **ECU is expected to:** Fall back to the default rate after S3 expiry [unverified rule].
- **Engineer obtains:** Evidence that the node rejoins the normal network.
- **Test on success / failure:** At the default rate, `22 F1 86` returns `62 F1 86 01`. If the ECU only answers
  at the high rate, it is a defect (vehicle network would break after an aborted flash).

<!-- catalogue fields 5, 6 -->

## 5. How does it work?

1. **Verify.** Tester sends `87 01 <modeId>` or `87 02 <linkRecord>`. The server checks that it supports the
   mode and that conditions allow it, stores the pending transition and answers `C7 01` / `C7 02`.
2. **Transition.** Tester sends `87 03`, usually functionally addressed with SPRMIB (`87 83`), so that all
   verified nodes switch together and nobody answers at the old rate after others have switched. If sent
   physically without SPRMIB, the server answers `C7 03` at the **old** rate, then switches [unverified].
3. Tester switches its own rate. Wait a short settling time before the next request [OEM-specific].
4. **Return.** The link returns to its default mode on session exit (to default session or S3 timeout) or on
   reset [unverified].

`87 03` without a successful verify step is a sequence error (expect `7F 87 24`).

| Precondition | Typical requirement | Standard or OEM? |
|---|---|---|
| Diagnostic session | Non-default; often programmingSession only | OEM |
| Security / authentication | Usually none; some OEMs require unlock | OEM |
| ECU operating conditions | Vehicle stationary; communication already disabled with 0x28 | OEM |
| Timing (P2 / P2* / S3) | Fast service. S3 expiry also ends the new mode [unverified] | ISO 14229-2 / OEM |

**Depends on:** DiagnosticSessionControl (0x10), CommunicationControl (0x28), ControlDTCSetting
([0x85](0x85-control-dtc-setting.md)), transport configuration and CAN controller capability. Functional
addressing rules: [../protocol-fundamentals.md](../protocol-fundamentals.md#functional-vs-physical-addressing).

<!-- catalogue fields 11, 12 -->

## 6. Request and response formats

### Request

| Byte | Parameter | Size | Values / encoding |
|---|---|---|---|
| 1 | SID | 1 | 0x87 |
| 2 | linkControlType (sub-function) | 1 | bit 7 = SPRMIB, bits 6–0 = type |
| 3 | linkControlModeIdentifier | 1 | Only for 0x01. Table below |
| 3–5 | linkRecord | 3 | Only for 0x02. Bit rate in bit/s as a 24-bit unsigned value, MSB first (udsoncan encodes it this way; py-uds: 24-bit raw record) |

`0x03` has no parameter bytes.

### Sub-functions

| Value | Name | What it does | Typical use | Notes |
|---|---|---|---|---|
| 0x01 | verifyModeTransitionWithFixedParameter | Checks a predefined mode (modeId) | Standard CAN rates | Most common |
| 0x02 | verifyModeTransitionWithSpecificParameter | Checks an explicit bit rate (linkRecord) | Non-standard rates | Rare |
| 0x03 | transitionMode | Executes the verified transition | After all nodes verified | Usually functional + SPRMIB |
| 0x00, 0x04–0x3F, 0x7F | reserved | — | — | 0x12 expected [unverified range] |
| 0x40–0x5F | vehicleManufacturerSpecific | OEM-defined | — | [unverified range] |
| 0x60–0x7E | systemSupplierSpecific | Supplier-defined | — | [unverified range] |

**linkControlModeIdentifier values** — cross-checked against two open-source stacks (py-uds translator,
udsoncan `Baudrate`), not against the ISO table; py-uds names shown:

| Value | Mode |
|---|---|
| 0x01–0x05 | PC9600Baud … PC115200Baud: 9600, 19200, 38400, 57600, 115200 (K-Line / serial testers) |
| 0x10 | CAN125000Baud |
| 0x11 | CAN250000Baud |
| 0x12 | CAN500000Baud |
| 0x13 | CAN1000000Baud |
| 0x20 | ProgrammingSetup (py-uds only; meaning OEM-defined) |
| other | Reserved or OEM-defined — take from the OEM spec. No CAN FD identifiers in either stack |

### Positive response

| Byte | Parameter | Size | Meaning |
|---|---|---|---|
| 1 | Response SID | 1 | 0xC7 |
| 2 | linkControlType | 1 | Echo of request byte 2 with bit 7 cleared |

### Negative responses

| NRC | Name | When this service returns it |
|---|---|---|
| 0x12 | subFunctionNotSupported | linkControlType not implemented |
| 0x13 | incorrectMessageLengthOrInvalidFormat | Missing modeId (0x01), linkRecord not 3 bytes (0x02), extra bytes |
| 0x22 | conditionsNotCorrect | OEM preconditions not met (vehicle moving, communication not disabled) |
| 0x24 | requestSequenceError | `transitionMode` without a successful verify step |
| 0x31 | requestOutOfRange | modeId or linkRecord rate not supported |
| 0x33 | securityAccessDenied | OEM protects the service and ECU is locked |
| 0x34 | authenticationRequired | 2020 ECU requires Authentication (0x29) first [OEM-specific] |
| 0x7E | subFunctionNotSupportedInActiveSession | linkControlType not allowed in this session |
| 0x7F | serviceNotSupportedInActiveSession | Service called in default session |

Meanings of all NRCs: [../nrc-reference.md](../nrc-reference.md).

### Examples

Values marked (illustrative) are not universal.

```uds
REQ 10 02                    # programmingSession (physical)
POS 50 02 00 32 01 F4        # timing illustrative
REQ 87 01 13                 # verify fixed mode 0x13 = CAN 1 Mbit/s
POS C7 01                    # supported, transition pending
REQ 87 83                    # transitionMode, SPRMIB set (send functionally)
NOTE no positive response; ECU and tester switch to 1 Mbit/s
REQ 3E 00                    # first request at the new rate
POS 7E 00
```

| Line | Byte(s) | Meaning |
|---|---|---|
| REQ 2 | 87 01 13 | LinkControl, verifyModeTransitionWithFixedParameter, modeId 0x13 |
| POS 2 | C7 01 | Positive response, echo 0x01 |
| REQ 3 | 87 83 | SPRMIB = 1, type 0x03 transitionMode |
| REQ 4 / POS 4 | 3E 00 / 7E 00 | TesterPresent at the new rate proves the switch |

```uds
REQ 87 02 07 A1 20           # verify specific rate 0x07A120 = 500000 bit/s
POS C7 02
REQ 87 03                    # transitionMode, physical, SPRMIB not set
POS C7 03                    # sent at the old rate, then the ECU switches [unverified]
```

| Byte(s) | Value | Meaning |
|---|---|---|
| 87 02 | | verifyModeTransitionWithSpecificParameter |
| 07 A1 20 | 500000 | linkRecord, bit rate in bit/s |
| C7 02 | | Verified |
| 87 03 / C7 03 | | Transition, answered before the switch |

```uds
REQ 87 03                    # transitionMode without verify
NEG 7F 87 24                 # requestSequenceError
REQ 87 01 7A                 # unsupported mode identifier (illustrative)
NEG 7F 87 31
REQ 87 01                    # modeId missing
NEG 7F 87 13
```

| Line | Bytes | Meaning |
|---|---|---|
| NEG 1 | 7F 87 24 | Transition before verify |
| NEG 2 | 7F 87 31 | modeId 0x7A not supported |
| NEG 3 | 7F 87 13 | Length wrong |

<!-- catalogue fields 8, 9, 10, 13 -->

## 7. Implementation and testing

**Implementation:**

- Builder: `link_control_verify_fixed(mode_id)`, `link_control_verify_specific(bitrate)` (encode 3 bytes, reject
  values ≥ 2^24), `link_control_transition(suppress=True)`.
- Orchestration: verify every node physically, abort the whole switch if any node rejects, then send one
  functional `87 83`, then reconfigure the tester interface (in CANoe/CAPL: change the channel bit rate; in
  python-can: re-open the bus with the new bitrate). Add a settling delay, then a TesterPresent check.
- Recovery: if the check fails, switch the tester back to the old rate and send `10 01` / `11 01`.
  Always end the flash with a reset so all nodes return to the default rate.
- Parser: 2-byte response only, echo check with bit 7 cleared.
- Edge cases: a node that answered `C7 01` but missed the functional `87 83` stays at the old rate; bus errors
  follow. Hardware: transceivers and bus topology must support the higher rate.

**Test matrix:**

| # | Test | Stimulus | Expected |
|---|---|---|---|
| 1 | Positive fixed | `87 01 13` in allowed session | `C7 01` |
| 2 | Positive specific | `87 02 07 A1 20` | `C7 02` or `7F 87 12` if not implemented |
| 3 | Transition | `87 83` functional after verify | Silence; node answers at new rate only |
| 4 | Transition physical | `87 03` after verify | `C7 03` at old rate, then new rate |
| 5 | Sequence | `87 03` without verify | `7F 87 24` |
| 6 | Unsupported mode | `87 01 7A` | `7F 87 31` |
| 7 | Unsupported type | `87 04` | `7F 87 12` |
| 8 | Session matrix | `87 01 13` in default / extended / programming | `7F 87 7F` in default; others per OEM |
| 9 | Security / authentication | Locked vs unlocked; authenticated vs not | Per OEM; `7F 87 33` / `7F 87 34` if gated |
| 10 | Length min-1 (0x01) | `87 01` | `7F 87 13` |
| 11 | Length min / max (0x01) | `87 01 13` | `C7 01` |
| 12 | Length max+1 (0x01) | `87 01 13 00` | `7F 87 13` |
| 13 | Length (0x02) | `87 02 07 A1` and `87 02 07 A1 20 00` | `7F 87 13` |
| 14 | Length (0x03) | `87 03 00` | `7F 87 13` |
| 15 | SPRMIB on verify | `87 81 13` | No response; transition still allowed afterwards |
| 16 | SPRMIB + error | `87 83` without verify, physical | `7F 87 24` still sent |
| 17 | Functional verify | `87 81 13` functional | No response; unsupported nodes stay silent |
| 18 | Fallback on S3 | Switch, then no TesterPresent > S3 | Node back at default rate [unverified rule] |
| 19 | Fallback on reset | Switch, `11 01` at new rate | Node starts at default rate |
| 20 | Conditions | Verify with vehicle speed > 0 (HIL) | `7F 87 22` if OEM requires |
| 21 | Multi-frame at new rate | `36 ..` TransferData after switch | ISO-TP flow works with new STmin/BS |

Response pending (0x78) is not expected for this service.

<!-- catalogue field 14 -->

## 8. Standards and limitations

| Item | Detail |
|---|---|
| ISO reference | ISO 14229-1:2020 clause 10.10 (functional unit: diagnostic and communication management) |
| Edition differences | No structural 2013 ↔ 2020 change known to this entry [edition-dependent] [unverified]. 2026 edition not yet reviewed |
| OEM / ECU-specific | Supported modes, allowed sessions, settling time, whether the response to physical `87 03` is sent, CAN FD handling |
| Verification status | cross-checked (reviewer, 2026-10-26). Core structure checked: clause number and functional unit (2020 preview TOC); linkControlType 01–03 names, parameters per type, echo-only response, linkControlModeIdentifier 0x01–0x05 / 0x10–0x13 / 0x20, 3-byte big-endian linkRecord (py-uds translator source, udsoncan source). Not cross-checked: reserved / OEM / supplier ranges, fallback rules, whether a physical `87 03` gets a response and at which rate |
| Open questions | Whether CAN FD modes are defined in 2020; exact rule for return to default mode; whether the server answers `87 03` (without SPRMIB) at the old rate; timing between `87 03` and first request at the new rate |

<!-- catalogue field 15 -->
