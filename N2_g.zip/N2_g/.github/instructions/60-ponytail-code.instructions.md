---
name: 'Code writing (ponytail)'
description: 'Smallest complete, easy-to-read change on every code edit, per the ponytail agent'
applyTo: '**/*.{py,ts,js}'
---

# Code writing: ponytail

Before the first edit to a code file, read `.github/agents/ponytail.agent.md` and follow it.

- The smallest change that fully solves the task. Finish every caller, test and fixture it breaks.
- Reuse first: an existing wrapper, helper or pattern in this repository, then the standard library,
  then an installed dependency. Never add a dependency for a few lines.
- No abstraction, option, wrapper or "for later" code nobody asked for. Plain code a reader gets at a
  glance beats a clever one-liner.
- Comment only the why the code cannot show.
- On conflict the repository rules win: protected paths, config-driven values, no execution,
  generated files changed through their generator. See the agent's "In this repository" section.
