---
name: 'Generators and tools'
description: 'Rules for tools/*.py — the scripts that generate configs, test scripts and specs'
applyTo: 'tools/**/*.py'
---

# Generators

These produce the bulk of the repository: roughly 1,600 generated test scripts, several
project config modules, and the EDR specification workbooks. Editing a generator is how
you change hundreds of files correctly.

## Every generated file must announce itself

Emit this header into everything you generate, with a command that actually works when
pasted:

```python

# Rebuild with: py -3.14 tools/<this_generator>.py --project <NAME>
```

The `PreToolUse` hook reads that marker to stop anyone hand-editing the output, and the
rebuild line is what it tells them to run instead. A generator that omits the header
silently loses that protection.

## Generation must be deterministic

Same inputs, same bytes out. No timestamps, no `dict` iteration order that depends on
insertion from a set, no random ordering. A generator whose output churns makes every diff
unreviewable and hides the one real change.

## Source of truth, and proving you read it

Generators read DBCs, DRBFM sheets, diagnostic specs and CSVs. Two rules:

- Read the source completely — every sheet, every row, columns by header name.
- Report what you consumed: counts of rows in, files out, and anything skipped and why.
  A generator that silently drops 40 of 125 parameters looks identical to one that worked.

## Fail loudly

If an expected column, sheet, signal or config key is missing, raise with the name of what
was missing and where it was looked for. Do not fall back to a default and continue — that
produces plausible output that is wrong, which is the worst outcome here.

## Before you say it works

Run it, and report real numbers:

```
py -3.14 tools/<generator>.py --project <NAME>
```

Then check the output actually conforms:

```
py -3 .github/hooks/scripts/validate_script.py projects/<NAME>/modules/<M>/scripts/*.py
```

State how many files were written and confirm a sample compiles. "The generator was
updated" is not a result; "regenerated 503 scripts, all compile, 0 convention findings" is.

## The interpreter

`py -3.14` is the interpreter with `openpyxl` and `cantools` installed. The default
`python` is 3.11 and does not have them. Use `py -3.14` in rebuild commands.
