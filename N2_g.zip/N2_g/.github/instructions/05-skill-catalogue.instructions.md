---
name: 'Skill catalogue'
description: 'What each skill in .github/skills covers, so the right procedure gets used'
applyTo: '**'
---

# Skill catalogue

This repository ships procedures for its recurring tasks. They encode decisions already
made here — formats, safety gates, which artefact is authoritative — that general
knowledge will not reproduce.

**Before answering a request that matches one of these, open its `SKILL.md` and follow it.**
Working from memory instead is how a plausible but non-conforming answer gets produced.

| Skill | Use it when |
|---|---|
| [`aria-bench-configuration`](../skills/aria-bench-configuration/SKILL.md) | Creating, mapping, reviewing, or validating an ARIA safety ECU bench configuration, ZIF assignment, LDBX loadbox configuration, or fault-free profile from an SCD,… |
| [`aria-crash-simulation-xml`](../skills/aria-crash-simulation-xml/SKILL.md) | Generating or validating ARIA/Veoneer CrashSimulationSensors XML files from crash-pulse TXT files. |
| [`can-channel-agnostic-wrappers`](../skills/can-channel-agnostic-wrappers/SKILL.md) | Writing or reviewing a shared-library wrapper that touches a CAN channel, so it works on HSCAN, CAN-FD, Level 61 and any project without edits. |
| [`clean-exported-web-text-images-and-symbols`](../skills/clean-exported-web-text-images-and-symbols/SKILL.md) | Cleaning exported web text, image tags, symbols, and formatting artefacts from an Excel worksheet with the CleanExportedWebTextImagesAndSymbols VBA macro. |
| [`dbc-to-json`](../skills/dbc-to-json/SKILL.md) | Converting one or more CAN database (.dbc) files into JSON signal metadata. |
| [`edr-rsu-curve-generation`](../skills/edr-rsu-curve-generation/SKILL.md) | Generating, analysing or validating RSU / onboard acceleration crash curves for EDR recording tests: synthetic front, left, right, rear and near LSB curve sets (600… |
| [`failure-mode-analysis`](../skills/failure-mode-analysis/SKILL.md) | Designing or reviewing any test, specification, or change for an airbag ECU, to enumerate how it can fail rather than only how it works:… |
| [`python-test-automation`](../skills/python-test-automation/SKILL.md) | Designing, implementing, reviewing, or debugging Python automation, pytest, unittest, APYM/ARIA interactions, shared_libraries wrappers, reporting, logging,… |
| [`skill-portfolio-orchestration`](../skills/skill-portfolio-orchestration/SKILL.md) | A request spans multiple Framework_IOEM_Py Copilot skills, needs intent routing, evidence handoff, RAG or knowledge-graph retrieval, multi-agent review, cross-skill… |
| [`uds-diagnostics`](../skills/uds-diagnostics/SKILL.md) | Analyzing, implementing, reviewing, or testing UDS diagnostics under ISO 14229: Diagnostic Session Control, ECU identification DIDs, Read/Clear DTC Information,… |
| [`universal-document-understanding`](../skills/universal-document-understanding/SKILL.md) | Use BEFORE reading any Excel, PDF, scanned PDF, Word, PowerPoint, CSV, JSON, XML/ARXML, DBC, log, Markdown, HTML, email, ODT/ODS, EPUB, image, screenshot, or web… |
| [`uv-package-manager`](../skills/uv-package-manager/SKILL.md) | Monitoring, auditing, installing, upgrading, validating, rolling back, or governing Python dependencies with uv in Framework_IOEM_Py. |
| [`veoneer-test-spec-generator`](../skills/veoneer-test-spec-generator/SKILL.md) | Creating a test specification, generating a Veoneer spec, creating test cases from requirements, creating a Codebeamer import file, generating a test specification… |

Full text of each is in `.github/skills/<name>/SKILL.md`; several also ship runnable
scripts under `scripts/` which are preferable to reimplementing the logic in chat.

## Routing is also automatic

`.github/hooks/scripts/user_prompt_submit.py` matches your request against
`.github/hooks/scripts/routing.json` and names the files to open. If it points you at a
skill, read it — the match was made on the words you used. If it turns out not to apply,
say so and move on.

## Not everything is a skill

| Question | Read instead |
|---|---|
| ECU behaviour, requirements, protocols, test-design rules | `.github/agents/agent_sc3.md` |
| ARIA bench and project configuration | `.github/agents/aria_agent.md` |
| EDR CAN-C on-fail case validity | `.github/agents/canc_onfail.md` |
| Known gaps and deferred findings | `docs/improvements/README.md` |
| Specialist review personas | `.github/agents/*.agent.md` |

