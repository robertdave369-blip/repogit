---
name: 'Repository tests and written output'
description: 'Rules for tests/*.py and for Markdown deliverables'
applyTo: '{tests/**/*.py,**/*.md}'
---

# Repository tests (`tests/`)

These run offline, without a bench. Keep them that way — a test that needs hardware cannot
be run by anyone reviewing a change.

- Assert against **real artefacts in the repo** (a DBC, a spec workbook, a generated file),
  not against a mock that encodes the same assumption as the code.
- When a test and the code disagree, work out which is wrong before changing either. On
  this repository the test has been wrong at least as often as the code — a DTC test here
  once asserted `U1061` for a byte pattern that decodes to `B1061`.
- Name the test after the behaviour it protects, not the function it calls.

# Markdown deliverables

Reports, analyses and specifications are read by engineers who will act on them.

## State evidence inline

Every claim carries its source — file, sheet, row, or the command that produced it. Where
there is no evidence, write **"Evidence unavailable."** rather than softening the claim
into something that reads as established.

Separate clearly:

- **fact** — read from an artefact, with the artefact named;
- **inference** — derived, with the derivation shown;
- **assumption** — neither, flagged as such.

## Say what was not done

A report that lists only what worked is misleading. State explicitly:

- what was verified, and how;
- what was **not** verified, and why;
- anything skipped, truncated, sampled, or capped.

"Regenerated 503 scripts; all compile; not run against hardware" is useful. "Done" is not.

## Structure

- Lead with the answer or the outcome, then the supporting detail.
- Tables for anything with more than three parallel items.
- Keep code blocks runnable and paths copy-pasteable from the repo root.
- No filler: drop "it is important to note", "as we can see", and restatements of the
  heading.

## Where analyses go

Findings that were investigated but deliberately not applied belong in
`docs/improvements/`, with what was observed, how it was verified, why it was deferred, and
the options. Add a row to `docs/improvements/README.md` so it is discoverable.
