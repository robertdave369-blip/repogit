---
name: 'Shared libraries'
description: 'Rules for shared_libraries/*.py — the layer every project depends on'
applyTo: 'shared_libraries/**/*.py'
---

# Shared libraries

Every script in every project imports this layer through `import_list`. A regression here
is a regression everywhere, and it will not be caught by running one test.

## Star-import ordering decides which definition wins

`import_list.py` star-imports the modules in a fixed order; **later modules shadow earlier
ones**:

```
apym_imports → ascent_batch_lib → check_sequence → configuration_control → core_functions
→ crash_configuration → data_conversions → ... → jscript_translation → project_config_loader
→ winidea
```

Consequences you must respect:

- Adding a public name that already exists earlier in that order **silently replaces it**
  for every script. Before adding one, grep the whole layer for the name.
- `data_conversions` shadows `core_functions` for `raw_to_physical` / `physical_to_raw`.
  `jscript_translation` shadows `core_functions` for `Api` and `CurveData`.
- If you must shadow deliberately, keep the signature and default behaviour identical and
  say so in the docstring.

## Channel handling

A wrapper that touches a bus must work on HSCAN, CAN-FD and Level 61, in any project,
unedited.

```python
# wrong
channel_id = Api.Configuration.get_channel_id("HSCAN")

# right - optional channel, resolved through the existing helpers
def MyWrapper(channel_name: str | None = None, ...):
    resolved = _resolve_simulation_channel_id(channel_name)
```

Use the helpers already in `jscript_translation`: `_normalize_channel_name`,
`_find_matching_channel_name`, `_extract_optional_channel_arg`,
`_resolve_default_channel_name`, `_resolve_raw_can_channel_name`,
`_resolve_simulation_channel_id`, `_resolve_diag_channel_id`,
`_resolve_level61_diag_channel_id`. Never hardcode a bus, a project, or a channel index.

See `.github/skills/can-channel-agnostic-wrappers/SKILL.md` and its checker:

```
py -3 .github/skills/can-channel-agnostic-wrappers/scripts/check_channel_agnostic.py
```

## Wrappers must be real

Every bench-facing wrapper is backed by an actual `apym` call. If the operation has no apym
equivalent, **say so and do not write the function** — a stub that returns a success code
produces a test that passes without testing anything. Record the gap in
`docs/improvements/` instead. `docs/improvements/aria-pdf-unmapped-functions.md` is the
worked example.

## Do not break the existing surface

- Do not rename, re-signature or delete an existing public function. Scripts across every
  project call it, and `getattr(..., default)` callers will silently take a fallback path
  rather than error.
- Additions go in `__all__`, or the star-import will not export them.
- These files may be marked read-only on disk. Clear the attribute, edit, and restore it.

## Before you claim it works

```
py -3 -m py_compile shared_libraries/<file>.py
py -3 -c "from shared_libraries.import_list import *"
```

The second one is the test that matters: it proves the whole layer still imports in the
real order. Note that `configuration_control.py` currently fails to import for an unrelated
pre-existing reason recorded in `docs/improvements/shared-library-blockers.md` — read that
before concluding you broke something.
