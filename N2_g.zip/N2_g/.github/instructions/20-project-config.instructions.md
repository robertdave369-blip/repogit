---
name: 'Project config modules'
description: 'Rules for projects/*/config/*.py — the single source of project-variable values'
applyTo: 'projects/*/config/*.py'
---

# Project config modules

These files are the reason a script can be project-agnostic. Everything that differs
between M310/M314/M110, U171, ICE_01 and EV_01 lives here and nowhere else.

## What belongs here

Message and signal names, frame IDs and cycle times, sample intervals, EDR element routing,
DTC and DID numbers, fault-qualification counts, variant codes, power-line function names,
RSU attributes. If a value would change when the same test runs on another variant, it
belongs in config.

## What does not

Test logic, control flow, apym calls, bench actuation. A config module must be importable
without a bench attached and without side effects.

## Rules

**Every value needs a traceable source.** Add the source as a comment when it is not
obvious:

```python
# From ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx, sheet "DTC List", row 42
NODE_ABSENT_DETECTION_COUNT = 50
```

**Never copy a value from another project's config.** That is the single most common way a
wrong value enters this repository. Two projects having the same signal name does not mean
they share its encoding, its frame, or its cycle time. Open this project's DBC and spec.

**Follow the structure of the existing config for the same module.** Config modules are
read by generators and by `project_config_loader`; a renamed key silently breaks callers
that use `getattr(module, "NAME", default)` — they fall back rather than fail.

**Check whether the file is generated.** Several config modules are built by `tools/`, e.g.
`build_ice01_canc_config.py` and `build_edr_config.py`. Look for the generated header
before editing, and change the builder instead if it is there.

## Before you change an existing value

Changing a config value changes every script that reads it. Say which scripts are affected
and why the new value is right, with its source. If you cannot establish the source, do not
change it — ask.
