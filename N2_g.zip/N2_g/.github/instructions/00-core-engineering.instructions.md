---
name: 'Core engineering rules'
description: 'Evidence, verification and safety rules that apply to every file in this repository'
applyTo: '**'
---

# Core rules — these override your defaults

This is an airbag ECU (SRS/ACU) test framework. A wrong value here does not produce a
failing build; it produces a test that passes while the safety function is broken. Work
accordingly.

## 1. Verify. Never recall.

Signal names, frame IDs, factors, offsets, DIDs, DTCs, timings, pin mappings and channel
names are **project-specific and not portable**. A value that was right for M314 is
routinely wrong for U171 or ICE_01.

Before stating any such value, open the artefact that defines it:

| Value | Comes from |
|---|---|
| Signal / frame / factor / offset / receiver | the project's DBC in `project_dbc/` |
| DID, DTC, NRC, session, routine | that project's diagnostic spec workbook |
| Sample intervals, EDR layout | that project's `edr_config.py` and the DRBFM sheet |
| Fault qualification timings | the diagnostic spec's DTC List and NetworkManagement sheets |
| Bench wiring, slots, channels | the SCD / pinout / ARIA project config |

If you cannot open it, say **"Evidence unavailable."** and ask. Do not fill the gap from
another project, from the file name, or from what is plausible.

## 2. Label what you are saying

Every non-trivial claim carries:

- the **evidence** — file, sheet, line, or command output; and
- whether it is a **fact** (read from an artefact), an **inference** (derived, and from
  what), or an **assumption** (neither — say so explicitly).

"It should be X" is not acceptable unless you say it is an assumption.

## 3. Writing code is not running it

Never actuate hardware, flash an ECU, power a rail, fire a trigger, deploy a squib, or
persist irreversible state unless the user asked for it **in this turn**. Before any such
action, state exactly what will physically happen and get confirmation.

A `PreToolUse` hook refuses these commands. If it refuses you, do not look for another way
around — ask the user.

## 4. Read whole sources

- **Excel**: dump every sheet and every row with `openpyxl`. Resolve columns by header
  **name**, never by index. Decode Codebeamer escapes (strikethrough means deleted text).
  Never work from a preview, the first N rows, or memory of the file.
- **PDF / Word**: choose the parser that fits the document, keep tables and page references
  intact, and report extraction quality rather than guessing at what did not extract.

A partial read that looks complete is the most common cause of a wrong answer in this repo.

## 5. Scope

Do the task asked. If you find a real problem with it, say so in a sentence or two and then
deliver the work under stated assumptions. Do not silently widen, narrow, or substitute the
task. Do not refactor code you were not asked to touch.

## 6. When you are corrected

The user's correction wins. Apply it, do not re-litigate it, and cache it:

```
py -3 .github/hooks/scripts/cache.py fact "<what was corrected>" --evidence "<source>"
```

## 7. Work across the whole chain, not one file

Most failures and most wrong changes here cross layers: requirement → config/DBC → generator →
script → shared wrapper → ARIA bench → ECU state (power, NM, faults, crash lock, session) →
bus/UDS evidence → report verdict. Before you change or conclude anything:

1. Name the affected components and trace that chain end to end; say which links you verified.
2. Classify the behaviour against its sources — conformant, permitted configuration, OEM
   extension/deviation, inconsistency, unknown (`docs/compliance/deviation-index.md`). Keep approved
   OEM behaviour unless the task explicitly changes it.
3. Check the effect on neighbouring domains: timing and qualification, power and ignition cycles,
   NM/wake-up, DTC status, EDR and crash lock, NVM/EOL persistence, E2E/SecOC.
4. Find the existing tests first; add only the smallest set that covers the risk.
5. Report what ran, what did not, and what is still unverified.

When a task touches a specialist domain, read that specialist's agent file or knowledge base (index:
`.github/agents/AGENTS.md`). For a failure, start with `docs/engineering/known-failure-signatures.md`.

## Where the detail lives

- `.github/agents/agent_sc3.md` — ECU behaviour, requirements, protocols, test-design rules.
  §0 is the full version of this file; §3.1 holds discrepancy register **D-01…D-12** — never
  implement around a D-xx item without surfacing it.
- `.github/agents/aria_agent.md` — ARIA bench and project configuration.
- `.github/skills/<name>/SKILL.md` — task-specific procedures.
