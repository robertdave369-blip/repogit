---
name: 'Test scripts'
description: 'Rules for bench test scripts under projects/*/modules/*/scripts/'
applyTo: 'projects/*/modules/*/scripts/**/*.py'
---

# Test scripts

## First: is this file generated?

Most files here are. Check the first few lines for:

```

# Rebuild with: py -3.14 tools/<generator>.py --project <NAME>
```

If that marker is present, **stop editing this file**. Change the generator named in the
header and re-run it. A hand edit is discarded on the next rebuild, and the sibling files
generated from the same source stay inconsistent until then. A `PreToolUse` hook enforces
this; if it refuses your edit, go and open the generator.

Roughly 1,600 of the ~6,000 scripts here carry that marker, so check rather than assume in
either direction.

## Required shape

```python
# Author: <name>
#
# <what this case verifies, and against which requirement>

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

from Framework_IOEM_Py.projects.<PROJECT>.config import canc_config, edr_config


def run_test():
    ...
```

Two hard rules, both checked automatically after you write the file:

1. **Import through `import_list`.** `from Framework_IOEM_Py.shared_libraries.import_list import *`
   is the only supported entry point. Importing individual shared-library modules bypasses
   the star-import ordering, and a name can then resolve to the wrong implementation —
   `raw_to_physical` and `CurveData` both have more than one definition in the tree.
2. **All test code lives inside `def run_test():`.** Runners import the module and call
   `run_test()`. Anything at module level executes on import, which fires the test during
   collection.

## Values come from config, never from the script

```python
# wrong - ties the script to one bench and one variant
CAN.ChangeSignalValue("HSCAN", "VehSpd", "VehSpdLgt", 100)
sample_path = "C:\\Users\\me\\curves\\pulse.txt"

# right - the channel resolves itself, the value comes from config
CAN.ChangeSignalValue(frame_name="VehSpd", signal_name="VehSpdLgt",
                      value=canc_config.VEH_SPD_NOMINAL)
```

- No hardcoded absolute paths. Derive from `Path(__file__)` or read from config.
- No hardcoded channel names. Wrappers take an optional channel and resolve it.
- No hardcoded signal encodings. Factor and offset come from the DBC via config.

## Reporting and timing

- Use `RESULT.*` (`ResultStep`, `ExpectTestResult`, `LogAction`, `InterpretEqualResult`) —
  that is what lands in the report. A bare `print` is invisible to the result file.
- Use `Sleep(...)`, not `time.sleep(...)`.
- Never `except:` on its own. It swallows the very failure the test exists to detect, and
  catches `KeyboardInterrupt`. Catch `Exception` and report it through `RESULT`.

## Naming

Follow the convention already in the directory, e.g.
`SUBS_EDR_Element_ID_<Element>_TestCase_<group>_<n>.py`. Numbering is per element group.
Match the surrounding files rather than inventing a scheme.

## Writing is not running

Do not execute these scripts to "check they work". They drive real hardware — power rails,
squib loops, crash triggers. Offline, verify with `py -3 -m py_compile` and the convention
checker:

```
py -3 .github/hooks/scripts/validate_script.py <file>
```
