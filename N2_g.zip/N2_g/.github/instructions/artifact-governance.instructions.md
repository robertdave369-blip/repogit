---
description: "Use when creating, changing, moving, or retaining tests or tools artifacts so folder structure, README metadata, and logbooks remain clean."
applyTo: "{tests,tools}/**"
---

# Tests And Tools Artifact Governance

Apply this instruction to every agent and skill action affecting `tests/` or
`tools/`.

- Keep standalone executable test files at `tests/test_<feature>.py` as required
  by the repository policy. Put fixtures, generated workbooks, reports, JSON,
  and other supporting outputs in `tests/artifacts/<purpose>/` or the owning
  feature folder.
- Use `tools/<tool-name>/` for a multi-file utility and
  `tools/<tool-name>/runs/YYYY-MM-DD_<purpose>/` for retained tool output.
- Add a `README.md` to every new retained artifact folder before placing content
  inside it. It must state purpose, contents, provenance or inputs, validation,
  and retention decision. Update it when those facts change.
- Append a dated entry to `tests/logbook/YYYY-MM.md` or
  `tools/logbook/YYYY-MM.md` for each creation, validation, cleanup, archival,
  or structural change. Do not include credentials, sensitive data, or raw bench
  logs.
- Use descriptive lowercase, hyphenated folder names. Never use `new`, `final`,
  `copy`, or numbered-copy names. Do not retain `~$*` Office locks or
  `__pycache__/` content.
- Before moving or deleting an existing artifact, search its references and
  compare content where it has a duplicate-like name. Preserve the original if
  evidence is incomplete.
- Run `py -3.13 tools/audit_test_tool_artifacts.py` after a structural change.
  Review findings and record an explicit reason for every deferred item.