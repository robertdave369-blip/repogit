Correction or Verify whether these are present or not:

Normal Simulation: Make sure that there is valid values simulated for all the applicable signals of the CANC EDR recording, and also ensure that the recording interval is as per the edr_cofnig file which is defined already, refer dbc to verify that the particular signal values are as per that or not, sometimes spec might have wrong values as well which is why we need to verify against the dbc provided, also the values to be compared properly, if any offset with respect to physical values etc to be handled accurately and no sleep during the simulation as the simulation is in accordance with internval and Trigger happens at T0, so there should not be any sleep in any of the on fail or normal simulation cases, this needs to be verified properly.
The DTC to be read only after the recording interval simulation is done and also for normal simulation, there is no on fail can dtc, and can dtc status is 0B if active, this to be handled, and for over and under voltage, status remains 8 itself
Also the DTC to be read only after the Quali time or in some cases the fault is healed during post crash and if the wuali time is 100ms, then the status for that particular case of CAN dTC to be kept historic if there is an ignition cycle before read_Dtc, if not we need to keep healed status, this is an important thing to check for such post crash scenarios

for on fail cases:
Node Absent, this happens only when the key message is disabled or stopped, make sure that the node it is disabling is key node and is present correctly in canc_config or not

for Message timeout failures, we need to disable slave node which is the node other than key node of respective module, if no message other than key node is present,then no need of this case,
also one more  Caveat is that if the paramter node is not the node which is being used for making the message_timeout_failure, then these cases do not get last valid value instead they get consumed value, ony this is the thing to be handled as this is something which need to be kept in mind, only cases which are designed this way gets effected, so my suggestion is to create the message timeout by disabling the message with is responsible for the simulation, instead of disabling other node, disable this node, this to be handled in canc_confi as well.


for message content failure: this is only applicable for those which have crc/alive counter signal in their respective message/node, if not then this case is not valid for this failure

for signal content failure: this is only applicable if the particular message has invalid signal, please verify it in dbc as well as in config data and correct it if any wrong value is defined in config data

for signal never received and variant code erros, there is no pre or post crash scenarios, make sure that the can simulation and edr output simulation for these cases are handled properly 

for Reserved or out of range cases, if reserved values are presnt in dbc, those values to be considered, if not present, then out of value range values to be kept in config data, and also main thing is only if the value is able to fit in the data size, for example, if the valid value as per dbc for veh speed is 0 to 100, but the max possible value as per dbc if defined as 1000, then we can make out of range values, and out of range is to be applied for those cases which do not have reserved value and if the dbc max range allows it only

for UV/OV, make sure that the EDR verification expected and can simulation input verification is properly handled or not

Mainly make sure to correctly handle the comparision for pre/post crash scenarios as in that few values should come as simulated values and only when during fault it should have the last valid or whatever the value is specified as per spec to be kept for that duration of simulation

for signals/parameters like odometer,event date, time where there is no recording range, these to be handled properly and make sure these are correct and the output verification should be correct

one special case is for STS_ENG in U171/Z121 project, for other project with similar message, ask the user to specify the condition: Message timeout is only when the value of the signal is simulated with 0x5 or 0x1, so for this case this is how message timeout to qulify will take 10 seconds, so it is not possible to do pre/post for this parameter or signal



Here is some more detailed info of can faults:
#No code explanation:

1. Node Absent (NA) Fault

This fault is created by stopping key message (master message which is not slave) periodic message from simulating.
As a result, other slave nodes associated with the key message on the network no longer receive any communication from that node.
The system interprets this as the node being completely missing or offline and it gives node absent dtc as per the node which is disabled.


2. Message Time Out (MTO) Fault

This happens only when a specific slave message is not received within its expected time.
Typically created by stopping transmission of a particular slave message {note: key/master message can have n number of slave or sometimes no slave at all}, while the rest of the node may still be active.
The receiver detects that the message is delayed or missing beyond its deadline.


3. Wrong DLC (Data Length Code) Fault {This is Message content failure, which we can achieve in three ways:Wrong DLC, disable CRC / Alive Counter}

This fault is created by sending a message with an incorrect data length.
The receiver expects a fixed number of bytes but gets more or fewer bytes than expected.
This mismatch signals a message format/content error.


4. CRC / Alive Counter Fault {This is Message content failure: ony applicable if the message has crc / alive counter signal}

Created by breaking the integrity or sequencing information inside a message(simply what we do is to disable that crc/alive counter signal):

CRC fault: the error-checking value becomes incorrect.
Alive counter fault: the counter stops updating or gives wrong sequence values.


The receiver detects that the message is corrupted or not updating correctly over time.


5. Signal Content Fault (SCF)

This is created by sending an invalid value for a signal	{invalid value which is as per the DBC}.
The value is outside the allowed or defined range in the DBC (database).
The receiver identifies this as incorrect or unrealistic data content.

6. Variant Code error (VC Fault)

When the variant code which is a code which enables all the node and if vc bit is disabled in it is made 0, then all other nodes do not work as if it is not present)

🔹 What is the Variant Code (VC)?

The variant code is like a configuration switch in the system.
It tells the ECU which nodes/features should be active or enabled.
Think of it as a master control setting that decides what parts of the network are allowed to operate.


🔹 What happens when a VC bit is disabled (set to 0)?

Each bit in the variant code corresponds to a specific node or function.
When that bit is set to 0 (disabled):

The system treats that node as not required or not installed.
That node will not transmit messages or participate in communication.
Other nodes will also ignore it, as if it doesn't exist.




- Why does it look like the node is absent?

Since the node:

Does not send messages
Is not expected by the system


The rest of the network behaves as if the node is physically not present.

 So even though the node might physically exist, logically it is “removed” from the network.

VC bit ON (1) → Node is active and participates
VC bit OFF (0) → Node is treated as absent, even if it exists physically 

7. Signal never received is when node is disabled from Variantcode  

When does “Signal Never Received” happen?

The Variant Code (VC) is active, meaning the system expects the node to be present and working.
However, inside the VC configuration:

A specific byte/bit corresponding to that node is set to 0.




 What does this actually mean?

The overall VC says the feature/network is enabled 
But the specific node’s bit is turned OFF (0) 

So there is a conflict:

System expectation → Node should be sending signals
Actual configuration → Node is disabled internally



8. Key Idea Across All Faults

All faults are simulated by intentionally violating expected communication behavior:

No message → Node Absent
Late/missing specific message → Timeout
Wrong format → DLC fault
Corrupted integrity → CRC/Alive fault
Invalid data → Signal Content Fault



Key Node Identification and Node Absent Fault Logic

Within a CAN message network, the node associated with the lowest CAN Identifier (CAN ID) is designated as the Key Node. CAN bus arbitration is priority-based, where lower CAN IDs have higher priority and gain bus access before nodes with higher CAN IDs.

The Key Node is considered the primary node for the network because its messages will always win arbitration against messages from other nodes within the same network. Therefore, Node Absent Fault detection shall be based on the presence and availability of the Key Node.

All remaining nodes in the network shall be considered Slave Nodes with respect to the Key Node. The operational status of the network is determined using the Key Node, and a Node Absent Fault shall be raised if the Key Node message is not received within the configured timeout period.

Example: HPCad Network

Node Name      CAN ID      Priority      Classification
-------------------------------------------------------
HPCad_1_10     0x13E       Highest       Key Node
HPCad_4_10     0x13F       High          Slave Node
HPCad_2_50     0x2AF       Medium        Slave Node
HPCad_3_50     0x2B1       Lowest        Slave Node

Priority Order:
0x13E > 0x13F > 0x2AF > 0x2B1

Since HPCad_1_10 has the lowest CAN ID (0x13E), it has the highest bus priority and is designated as the Key Node for the HPCad network.
Sometimes, it might be dependent on the OEM, so this to be only followed if user do not specify the Key nodes by them 
Rule:
For any message network, whichever node has the highest CAN priority (lowest CAN ID) shall be designated as the Key Node. Node Absent Fault detection shall always be performed on this Key Node. All other nodes belonging to the same message network shall be treated as Slave Nodes.
Try to ask the user for key nodes before hand if only you do not get any response or the response is not clear, then only you should assume as said above about key node, else take users input
`