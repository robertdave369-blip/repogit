# ARIA Project Configuration — AI Agent Knowledge Base (`aria_agent.md`)

> **Purpose.** This is the expert knowledge base for **creating, validating, reviewing and
> maintaining complete ARIA project configurations** from scratch. It is written so an AI
> assistant (GitHub Copilot / copilot ai model / VS Code agents) can generate *every* file ARIA needs for a
> project — the `.accf` bundle, `.ldbx` loadbox, DBC-derived periodics, RSU sheets, SPI EVTs,
> diagnostic/event configs and the legacy JSON set — from a compact **project descriptor JSON**
> plus a **ZIF-connector ↔ ECU-connector pin map**.
>
> **Companion.** This file governs ARIA configuration only. For ECU behaviour, test authoring,
> scripting and the bench-runtime wrapper layer, `agent.md` (same repo) is authoritative; that
> file's § 25 describes the ARIA runtime, § 25.6 the loadbox electrical states, and § 28.10
> CRC/E2E. Operate under the § 0 core engineering principles of `agent.md` (quality over speed,
> trust-nothing verification, **every claim evidence-backed or "Evidence unavailable."**,
> confidence + fact/inference/assumption labelling). This document marks **[FACT]** (verified in
> the ARIA 5.20 install / M314 reference on this machine, 2026-07), **[INFERENCE]** (derived) and
> **[ASSUMPTION]** (unconfirmed) throughout.
>
> **Evidence base (verified 2026-07, ARIA 5.20).** Installation `C:\ARIA5.20`; reference project
> = the **M314** config in `C:\AriaConfigFiles_Generic\AriaConfigFiles\` (an `.accf` bundle whose
> diagnostic RequestId 1840 = `0x730` / ResponseId 1848 = `0x738` and DBCs
> `SRS_FD_SVNID_40060_06032026.dbc` match the SC3 2S ACU); generic RSU sheets in
> `C:\AriaConfigFiles_Generic\AriaConfigFiles\Config_folder\RSU\`; canonical clean template in
> `C:\ARIA5.20\ConfigExample\`.

---

## 0. How to use this agent + self-improvement protocol

### 0.1 What the agent produces
Given **(a)** a project descriptor JSON (§ 13) and **(b)** a ZIF↔ECU pin map (§ 6), generate a
complete, load-ready ARIA project: the `.accf` master + `_accdata/` tree (or the legacy JSON set,
or both), the `.ldbx` loadbox with correct slot/card/function/relay mapping, the DBC-derived
`.acpdf` periodics, the RSU `withMarkers` Excel + exported `.rsu` files, the SPI EVT references,
and the diagnostic/event/dynamic-library wiring — then validate it (§ 15).

### 0.2 Golden rules
1. **The descriptor is the single source of truth.** Every generated value comes from the
   project descriptor JSON (§ 13), the pin map, or the project's DBC — never a literal invented
   by the agent. If a required value is missing, **stop and ask the user** with a
   maintainability-oriented suggestion (mirrors `agent.md` § 18.2).
2. **Preserve conventions exactly.** RSU-sheet defined-name markers (§ 7.2), loadbox GUID
   cross-references (§ 5), decimal-vs-hex ID conventions (§ 2.2), and file-format `Version`
   attributes (§ 17) are load-bearing. Reproduce them verbatim; a renamed marker or a broken GUID
   ref makes ARIA silently mis-read or refuse the project.
3. **Never actuate hardware.** Generating/validating config files is always safe. Loading a
   profile, powering, flashing, or firing is **not** — that is the `agent.md` § 23 boundary and
   applies here too. Deliver files; do not launch ARIA against a bench uninvited.
4. **Version-check every file you touch.** Read the `Version` attribute first (§ 17) and adapt to
   it; do not assume 5.20 shapes on a newer install (§ 0.3).

### 0.3 Self-improvement / version-adaptation protocol (ARIA will evolve)
ARIA versions bump the on-disk `Version` of each format and add fields. To stay correct without a
rewrite:
1. **Re-survey on a new install.** Point at the new `ARIA<x>` root + its `ConfigExample` and any
   `_accdata` bundle; diff the format `Version` numbers (§ 17) and the element/field sets against
   this document.
2. **Learn by example, not by hard-coded schema.** Treat a *known-good project that the new ARIA
   loads cleanly* as the schema: parse it, record new elements/enums, and update the relevant
   section here + the descriptor schema (§ 13). New fields with defaults → add as optional;
   renamed/removed elements → note the migration.
3. **Record the delta in the changelog (§ 19)** with the ARIA version and evidence path. Keep old
   version notes (history matters — a bench may run an older ARIA).
4. **Confidence.** After a version bump, downgrade affected claims to **[ASSUMPTION]** until
   re-verified against the new install; never silently carry a 5.20 fact into 6.x.

---

## 1. ARIA ecosystem overview

**[FACT]** ARIA is Veoneer's HIL bench: chassis of simulator cards + PC software (`ARIA.exe`,
.NET/WPF) that fakes every ECU input/output (power, CAN/CAN-FD, squib loads, RSU/PSI5 satellites,
SPI sensors, lamps). See `agent.md` § 25 for the runtime; this file is about the **configuration
that tells ARIA what the bench and the DUT are**.

**[FACT] There are two coexisting configuration systems. A project usually carries both:**

| System | Master file | Consumed by | Human-facing format |
|---|---|---|---|
| **A — Modern unified bundle** | `AriaMain.accf` (+ `AriaMain_accdata/`) | ARIA.exe GUI (5.x native project) | XML `CoreConfiguration` + a folder of typed sub-files |
| **B — Legacy JSON set** | `AriaMain.json` (+ `Chassis/Can/Lin/Flexray/Sensors` JSON + `Config_folder/`) | AutomatedScripts / APYM / jscript test framework (per `AriaMain.ini`) | flat JSON + XML + Excel |

The M314 reference carries **both**: the `.accf` bundle is the interactive project; the JSON set
+ `Config_folder` feed the automated test framework. When generating, produce whichever the target
workflow needs — and keep them **consistent** (same DBCs, same diag IDs, same loadbox).

### 1.1 Installation map (what lives where) — [FACT]
```
C:\ARIA5.20\
  ARIA.exe, *.dll                      the application + card drivers
  ConfigExample\                       CLEAN canonical template project (best starting point)
    AriaMain.json + Can/Chassis/Sensors/Flexray/Lin JSON
    .accf + _accdata\                  (minimal modern bundle)
    Config_folder\                     CrashConfiguration.xml, RSU\, SPI\, *.rsu, project.pj
    DTCList.xml, Services.xml, *.dbc, error_definition_*.xlsm, EventMode\*.xlsm
  Documentation\  ARIA User Functions.pdf | Aria Documentation.pdf | Aria Apym Documentation.pdf
  Help\  Functional Commands\*.chm | Documentation\*.docx | ScriptStudio\*.chm | ReleaseNotes\ (empty in 5.20)
  Firmware\  per-card firmware (*.hex/*.cyacd/*.lvappimg) — reference only, never edit
  CardFirmwareVersion.xml              expected card firmware versions

C:\AriaConfigFiles_Generic\AriaConfigFiles\   the M314 reference bundle + generic library
  AriaMain.accf + AriaMain_accdata\    the modern M314 project (see § 2/§ 3)
  AriaMain.json + Can/Chassis/Sensors/Flexray/Lin JSON  the legacy M314 set
  AriaMain.ini                         path config for AutomatedScripts (Scripts/Results folders)
  Config_folder\RSU\                   RSU withMarkers Excel sheets (the marker convention, § 7)
  DBC\M314\                            SRS_FD_*.dbc + SRS_HSCAN_*.dbc (the project buses)
  Filter_Folder\*.flt/*.dft            sensor filter definitions
  FltMonr_Configurator*.xlsm           fault-monitor config (see agent.md § 2.11)
  error_definition_*.xls(m)/xml, DTCList.xml, *Services.xml   diagnostics tables
```

---

## 2. The modern bundle: `AriaMain.accf` (`CoreConfiguration`) — [FACT]

XML, root `<CoreConfiguration Version="33" FilesPath="AriaMain_accdata"
UserConfigurationFileName="<guid>">`. `FilesPath` names the sibling data folder. Every referenced
sub-file lives under `_accdata/<FilesPath-of-section>/`. Sections, in order, with the M314 values:

### 2.1 `<Assets FilesPath="Assets">`
Certificates/blobs. Each `<AssetsProperties Guid Name><Category>…</Category><FilePath>CA.crt</FilePath>`.
M314 uses one Clypeum CA cert.

### 2.2 `<Communication>` — the physical buses
One element per channel. **IDs elsewhere in `.accf` are DECIMAL** (0x730 → `1840`).
- `<VectorCanChannelProperties Guid Name ProtocolIndex IsEnabled Initialize AutoActivate>`
  `<DeviceChannelName>VN1610 Channel 1 (48714)</DeviceChannelName>` (the Vector hardware channel),
  `<Baudrate>500000</Baudrate>`, `<IsSpyMode>`, `<AutoRecoverFromBusOff>`.
- `<VectorCanFdChannelProperties …>` adds `<AbrTseg1/2><AbrSjw><ArbitrationBitRate>`,
  `<DbrTseg1/2><DbrSjw>`, `<Baudrate>` = data bitrate (M314: 2000000 data / 500000 arb).
- `ProtocolIndex` (1,2,3…) is the stable handle other sections reference indirectly via `Guid`.
  M314: **ARIA** (CAN1, 500k), **CANFD** (2M/500k), **HS CAN** (virtual, 500k).

### 2.3 `<Diagnostic><Channels>` — UDS endpoints
`<CanSwDiagnosticChannelProperties Guid Name>` each with:
`<CommunicationChannelIdentity>` (→ a Communication Guid), `<RequestId>`/`<ResponseId>` (decimal;
M314 physical-on-CAN2 = 1840/1848 = `0x730/0x738`), `<RequestFlowControlId>`/`<ResponseFlowControlId>`,
`<IsCanFd>`, `<PaddingByte>` (170 = `0xAA`), `<FrameSizes>` (space-separated allowed DLCs, e.g.
`08 40` for FD), `<ResponseTimeout>`/`<ResponsePendingTimeout>` (P2/P2\*), `<FlowControlStMin>`,
`<FlowControlBlockSize>`, and `<UdsProperties>` security: either
`<DllSecurityAccessProperties><SecurityFunctionName>SendSecurityAccess</SecurityFunctionName>
<LibraryIdentity><guid></>` (a DynamicLibrary, § 2.6) **or**
`<ServerSecurityAccessProperties><ServerIdentity><ServiceIdentity>` (a Clypeum server, § 2.7).
M314 defines physical/functional on CAN1 and CAN2, an HSCAN endpoint, and two Clypeum-backed
"Physical-DLL"/"Physical_Server" endpoints (Level-61 security-access server). Also
`<EcuErrors FilesPath="Faults">` (ErrorDefinitionFile / TroubleCodeReaders / InternalFaultReaders)
and `<DataIdentifiers/>`.

### 2.4 `<Hardware>` — chassis + loadbox
`<UseVdkSimulation>` (false = real chassis; true = virtual/offline). Then
`<ChassisChannelProperties Guid>`:
- `<CommunicationProperties>` → `<CanChannelIdentity>` (which CAN drives the chassis),
  `<DiagnosticIdentity>`, `<IsConnected>`, `<UseDiagnostic>`, `<UseDirectCanProtocol>`.
- **`<LoadboxProperties FilesPath="Loadbox">`** → `<LoadboxFile>M314.ldbx</LoadboxFile>` (§ 5),
  `<ProfileFile>M314_LoadBox_Profile.json</ProfileFile>` (§ 5.5), `<LoadProfile>true</>`,
  `<SystemReset>true</>`. **This is the link to the slot map.**
- `<SensorsProperties RsuSensorsFilesPath="Sensors/RsuSensors"/>`, `<RsuCurvesFiles FilesPath="Curves"/>`.
- `<ExternalPowerSupplyConfiguration>` (optional programmable supply).

### 2.5 `<Periodics FilesPath="Periodics">` — the simulated bus traffic
One `<CanPeriodicsSwSimulatorProperties Guid Name Description="<dbc filename>">` per simulation:
`<Dut>SRS_FD</Dut>`, `<CommunicationChannelIdentity>` (→ Communication Guid), `<IsEnabled>`,
`<Initialize>`, `<AutoStart>`, `<AutomaticUpdateBitCounter>`, `<CustomBehaviorProperties>`
(`<InitializeFunction>` + `<LibraryIdentity>` → a DynamicLibrary for CRC/counter behaviour), and
**`<DefinitionsFile>CANFD.acpdf</DefinitionsFile>`** (§ 9 — the DBC compiled to ARIA periodics).
M314: CANFD sim (enabled, autostart) + HSCAN sim (disabled).

### 2.6 `<DynamicLibraries FilesPath="DynamicLibraries">`
Customer `.dll`s implementing CRC/alive-counter/security/custom frame behaviour. Each
`<DynamicLibraryDefinition Guid Name><Path>SC3_Mahindra_W610 1.dll</Path><CustomProperties/>`.
Referenced by `LibraryIdentity` from diagnostics/periodics. **The bytes are opaque**; the agent
wires references, never authors the DLL (ask the user which DLL implements the project's protection).

### 2.7 `<ClypeumServers>` — cloud security access
`<ClypeumServerDefinition Guid Name><IamBaseUrl><IamClientId><IamRealm><CaCertificateGuid>
<CertificateThumbprint><ServicesDefinitions><ClypeumDiagnosticServiceDefinition …
<DiagnosticServiceType>SecurityAccess</>`. M314 uses `mahindra-sc3-2s` realm, "Level 61 SA". These
are **live external endpoints** — treat URLs/realms as project secrets; never invent them.

### 2.8 `<Events FilesPath="Events" DefinitionFile="EventsDefinition.acef"/>`
Points to the Event-Mode definition (§ 11).

---

## 3. The `_accdata/` folder — [FACT]
The `.accf`'s `FilesPath` folder. M314 (`AriaMain_accdata/`):
```
Assets/            CA.crt (+ Clypeum assets)
Communication/     (channel aux files, if any)
Curves/            RSU/SPI crash curves referenced by RsuCurvesFiles
DynamicLibraries/  SC3_Mahindra_W610*.dll, Mahindra*.dll, W610.dll, …  (customer protection DLLs)
Events/            EventsDefinition.acef (Version 6.0)
ExternalPowerSupply/
Faults/            Fault_Monitor_M314/FltMonr_Configurator_SC3*.xlsm
Loadbox/           M314.ldbx (Version 8) + M314_LoadBox_Profile.json  + M314/ subcopy
Periodics/         CANFD.acpdf, HSCAN.acpdf … (Version 7.0)  + SwSimulation_* raw dumps
Sensors/RsuSensors/  per-RSU-sensor definition files
```
Folder names must match the `FilesPath` attributes in the `.accf`. When generating, create the
folder tree first, then the master `.accf` referencing it.

---

## 4. The legacy JSON configuration set — [FACT]

Consumed by AutomatedScripts/APYM (paths set in `AriaMain.ini` → `[ScriptsFolder]`/`[ResultsFolder]`).

### 4.1 `AriaMain.json` — orchestrator
```json
{"Configuration":{"Chassis":"ChassisConfig.json","Can":"CanConfig.json","Lin":"LinConfig.json",
 "Flexray":"FlexrayConfig.json","Sensors":"SensorsConfig.json","EventMode":null,
 "Customer":"MAHINDRA\tSC3\tHIGH\tTrue"}}
```
`Customer` is **tab-separated**: `<OEM>\t<Platform>\t<Variant/Trim>\t<Enabled>` (M314:
`MAHINDRA  SC3  HIGH  True`). All the other keys are filenames resolved relative to `AriaMain.json`.

### 4.2 `ChassisConfig.json`
`ScriptsFolder`, `ResultsFolder` (paths — often `..\..` into the test framework), `ConfigFolder`
(`Config_folder`), `FilterFolder`, `CrashFolder` (`Crash_Data` or `IMU_Data_India\`), `UseWinIdea`,
`InitScript`, and an `Ods` block (`Status/T2/T3/Data/TriggerValue/N/FileParameters`, default `"default"`).

### 4.3 `CanConfig.json`
- `CanGlobalConfig`: `SymbolFile` (`.sym`), `MnemonicFile` (`.xml`).
- `CanChannelConfig[]` — one per bus:
  `Can` (1,2…), `CanCaseXlSerialNumber`, `ProductName`, `ProductLibrary` (customer `.dll`),
  `IsCanFd`, `CanProperties.BitRate`, `CanFdProperties` (Arb/Data bitrate + BusTiming Val1/Val2 +
  SampleJumpWidth), `CanPeriodic` (`Database` = periodic `.xml`, `Dut`, `Matrix` = CAN-matrix
  `.xlsx`, `UseMatrix`), and **`DiagProperties`**: `PhysicalRequestID`/`FunctionalRequestID`/
  `ResponseID` (**hex strings** here, e.g. `0x737`/`0x73F`), `PaddingByte` (`0xAA`), `ErrorCodes`
  (`error_definition.xlsm`), `ErrorCodesGeneralConfig` (`DTCList.xml`), `Services` (`Services.xml`),
  `IsCanIsoTp`, `CanIsoTpProperties` (`NAs/NAr/NBs/NBr/NCs/NCr/NwftMax` — ISO 15765-2 timeouts),
  and `CanIsoTpPropertiesPerCanId[]` (`RequestId/ResponseId/FlowControlRequestId/MType/NSa/NTa/
  NTaType/NAe/ProductName/Active`). **Note the ID-notation split**: legacy JSON = hex strings;
  `.accf` = decimal. Keep both consistent with the DBC.

### 4.4 `SensorsConfig.json`
- `RsuConfiguration`: `Path` (`Config_folder\RSU\XLS\`), `ConfigPath` (`Config.xml`),
  `RsuSensors[]` (`Name` + `Path` to a `<Sensor>_Sensor.xml`).
- `SpiConfiguration`: `EvtFolder` (`Config_folder\SPI\XLS\`), `WorkflowsFolder`, `SpiSensors[]`
  (`Name`: `SMA_660`, `SMI_710`, `ADXC_1500`, `Mesquite`, …).

### 4.5 `FlexrayConfig.json`, `LinConfig.json`
Present even when unused (null/empty channel lists). Populate only if the DUT uses those buses.

### 4.6 `Config_folder/`
`CrashConfiguration.xml`, `RSU/` (the withMarkers sheets + exported `XLS/`), `SPI/` (EVT sheets),
`*.rsu` (exported RSU streams, § 7.3), `project.pj`, `fault_free_*.xml`.

---

## 5. The loadbox `.ldbx` — the SLOT MAP (JSON, Version 8) — [FACT]

The single most important file for slot mapping. `{ "Version":8, "Content": { … } }`. `Content`:

### 5.1 `RelayMapGroups[]` — named electrical preset tables
`{Id (guid), GroupName, Presets:[{Name, BitMapValue, ActionType}]}`. A group is a reusable menu of
electrical states a function can be switched to. `BitMapValue` is the relay bit-pattern ARIA drives;
`ActionType` is the semantic (`OpenFeed`, `CloseFeed`, `CloseFeedClockSpring`, `FeedReturnShort`,
`LowResistanceFault`, `HighResistanceFault`, `Generic`). M314 groups (evidence):

| Group | Presets (Name → electrical meaning) |
|---|---|
| `LOOP0` (squib) | OPEN(0/OpenFeed), INHERENT(16384/CloseFeed=2 Ω), CLOCKSPRING(4096=2.4 Ω), SHORT(262144), LRES_FAULT(65536=1 Ω), HRES_FAULT(1024=10 Ω), BUSS_HI/LO_ON/OFF |
| `INHIBITION_SWITCH`, `STPS` | resistor ladder 0R/25R/50R/100R/200R/400R/800R + OPEN/BUS + current 6mA/14mA |
| `BATT` | SYS_PWR_OFF/ON, BATT_6.5/7.5/13.6/17.5/18/20/25, SET_*, EXT_BATT |
| `IGN` | IGN_OFF/IGN_ON/POWER2_ON/POWER1_OFF |
| `CAN1` | OPEN, CAN_BUSS_OFF, CAN_BUSS_HI/Lo_ON, INHERENT · `CAN2` OPEN/INHERENT |
| `LAMP`, `PSBR`, `ENS` | INHERENT + BUSS_HI/LO_ON/OFF + OPEN |
| `RSU_CH1` | OPEN/SHORT/INHERENT · `RSU_CH7` ESS combos (ESS1/2/3/12/13/23/123/OPEN/INHERENT) |
| `DEBUGGER` | ENABLE/DISABLE |

These correspond 1:1 to the loadbox actions in `agent.md` § 25.6 and to `SQUIB.SendRequest`/
`SetGpoFaultCondition` etc. **Reuse existing groups**; only add a preset if the DUT genuinely
needs a new electrical state (and confirm the `BitMapValue` against the card — a wrong bit-pattern
mis-drives relays).

### 5.2 `Cards[]` — physical slot → card
`{Slot (int), Type, Name, FunctionRefs:[guid…]}`. `Type` ∈ `LoadV1` (squib/DCS/lamp/ENS loops),
`PwrV2` (power), `Can`, `RsuV1`, `Spifpga`, (`RsuV2`, `Rd`…). `FunctionRefs` are the GUIDs of the
`Functions` this card hosts (usually 2 channels per LoadV1). M314 slot layout (evidence):

| Slots | Card `Type` | Role |
|---|---|---|
| 1–11 | LoadV1 | Squib loops (LOOP0…LOOP21, 2 loops/card) |
| 13–21 | LoadV1 | DCS buckle channels (SW_Channel_DCS_0…17) |
| 22 | PwrV2 | Power (BATT + IGN) |
| 23–24 | Can | CAN1+DEBUGGER, CAN2 |
| 26 | LoadV1 | LAMP card (PAB_ON_LAMP, PAB_OFF_LAMP) |
| 27 | LoadV1 | ENS card (ENS, E-Call) |
| 28–33 | RsuV1 | RSU channels (RSU_CH1…CH12) |
| 39, 41 | Spifpga | SPI FPGA sensor sim (GEN6_XY, Panasonic) |

### 5.3 `Functions[]` — the ECU-signal ↔ card-channel binding
`{Id (guid), Channel (1/2), Type, Name, Configuration:{ "$type", "RelayMapGroupRef", …type-specific }}`.
**`Name` is the ECU signal/loop the channel simulates** (`LOOP0`, `PAB_ON_LAMP`, `ENS`, `RSU_CH1`,
`SW_Channel_DCS_0`, `BATT`, `IGN`, `CAN1`). `Configuration.$type` + extra keys by function type:

| Function `Type` | `$type` | Type-specific config keys |
|---|---|---|
| `Squib` | `load` | `RelayMapGroupRef` (→ LOOP group) |
| `Dcs` | `dcs` | `Type` (`Resistive`), `VoltagePin`, `CurrentPin`, `RelayMapGroupRef` |
| `Pwrline` | `pwr` | `Type` (`Vbat`/`Ign`), `RelayMapGroupRef` |
| `Can` | `load` | `RelayMapGroupRef` (→ CAN1/CAN2) |
| `Lamp` | `lamp` | `DimmingFrequency`, `DimmingTolerance`, `FlashingOffTime`, `FlashingTolerance`, `IsHighSide`, `RelayMapGroupRef` |
| `Ens` | `lamp` | same as Lamp (`IsHighSide` true for ENS/E-Call) |
| `Rsu` | `rsu` | `ChannelName`, `Slot`, `Sensor`, `LogicalIndex`, `RelayMapGroupRef` |
| `Spifpga` | `spi` | `ChannelSensorIndex`, `SensorType` (`GEN6_XY`/`PANASONIC`), `EvtSourcePath`, `DefaultEvtFile`, `AxisLabels`, `RelayMapGroupRef` |
| `Rd` | (null) | Resistor decade (no load config) |

Each `Function.Id` must appear in exactly one `Card.FunctionRefs` to be *placed*. **[FACT]** M314
also contains **defined-but-unplaced** functions (RSU_CH13–18, LOOP22/23) whose Id is in no card —
harmless spares; do not treat as an error. **[FACT] observed data quirk**: RSU_CH13–18 all copy
`ChannelName:"RSU_CH12"` (a source copy-paste); when generating fresh, set `ChannelName` = the
function name.

### 5.4 `PresenceGroups[]` + `PresenceGroupRef`
`{Id, Name, PresentSlots:[…]}` — which slots ARIA expects populated (PDC check). `PresenceGroupRef`
selects the active group. Also `VdkConfiguration.DcsStates[]` (virtual DCS states for offline
simulation) and `RsuV1Configuration`/`RsuV2Configuration` (null unless RSU card-level config used).

### 5.5 `<Project>_LoadBox_Profile.json` — runtime default states
A **separate** list (referenced by `.accf` `ProfileFile`, loaded when `LoadProfile=true`):
`[{CardType, Slot, Channels:[{ChannelIndex, Functions:[{FunctionId, Status}]}]}]`. It sets each
channel's **startup preset** (e.g. every squib loop → `INHERENT`, i.e. healthy 2 Ω). `FunctionId`
is the per-channel index (0-based), `Status` is a preset `Name` from that function's RelayMapGroup.
The `.ldbx` defines *capability*; the profile defines the *initial state*.

---

## 6. Slot mapping: ZIF connector ↔ ECU connector → card/slot/channel/function — [FACT/INFERENCE]

**This is the agent's primary responsibility.** The user supplies the physical wiring; the agent
produces the loadbox.

### 6.1 The mapping chain
```
ECU function (e.g. driver squib)
  → ECU connector pin            (from the ECU pinout / requirement)
  → [harness]                    (given: ZIF↔ECU pin map)
  → ARIA ZIF connector pin
  → ARIA card + chassis Slot + Channel   (card capability: which pins each card channel drives)
  → Function.Name in the .ldbx   (named after the ECU function; e.g. LOOP0)
  → RelayMapGroupRef             (electrical preset menu appropriate to that function type)
```
**[FACT]** The `.ldbx` encodes the tail of this chain (Function→Card→Slot→Channel→RelayMapGroup).
DCS functions additionally carry the concrete `VoltagePin`/`CurrentPin` (the ZIF pins measured).
**[INFERENCE]** The ZIF-pin↔card-channel correspondence is fixed by each card's hardware design;
the agent needs a **card-channel→ZIF-pin table** per card type (from the ARIA card docs / bench
harness drawing) to resolve pins to slots. If that table is not supplied, **ask** — do not guess a
pin assignment.

### 6.2 Input the agent expects (the pin map)
Provide, in the project descriptor (§ 13, `slot_map`), a list of ECU functions each with: the ECU
signal name, ECU connector pin(s), the ARIA ZIF pin(s) they are harnessed to, the ARIA function
type (Squib/Dcs/Lamp/Ens/Rsu/Pwrline/Can/Spifpga), and (optional) an explicit slot/channel if the
bench is already wired. Example row:
`{"ecu_function":"Driver_Squib","ecu_pins":["A12","A13"],"zif_pins":["Z01","Z02"],
  "aria_type":"Squib","function_name":"LOOP0","relay_group":"LOOP0"}`.

### 6.3 Allocation algorithm (when slots aren't pre-assigned) — [INFERENCE]
1. Group functions by `aria_type`; each type maps to a card `Type` (Squib/Dcs/Lamp/Ens→LoadV1,
   Pwrline→PwrV2, Can→Can, Rsu→RsuV1, Spifpga→Spifpga).
2. Pack functions into cards **2 channels per LoadV1/RsuV1 card**, in signal order, assigning cards
   to free chassis slots (respect any reserved-slot convention the bench uses — M314 keeps squibs
   1–11, DCS 13–21, power 22, CAN 23–24, lamp 26, ENS 27, RSU 28–33, SPI 39/41).
3. Emit `Cards[]` (Slot, Type, Name, FunctionRefs), `Functions[]` (Name, Channel, Type,
   Configuration with the right `$type`, `RelayMapGroupRef`, and pins for DCS/RSU), and the
   `PresenceGroup` PresentSlots = all populated slots.
4. Emit the `_LoadBox_Profile.json` with every channel at its healthy default (INHERENT / IGN_OFF /
   BATT off, per the project's power-up convention).
5. **Validate** (§ 15): every Function.Id placed once, every RelayMapGroupRef resolves, ZIF pins
   unique, DCS/RSU pin fields populated.

> **Always confirm the card-channel→ZIF-pin table and the reserved-slot convention with the user
> for a new bench.** These are physical facts the descriptor must carry; the agent must not invent
> them (mirrors `agent.md` § 0.3 evidence rule).

---

## 7. RSU configuration — the marker convention — [FACT]

RSU (PSI5 satellite) config flows: **`withMarkers` Excel → ARIA RSU configurator → `.rsu` byte
streams + sensor XMLs**. See `agent.md` § 2.6 / § 4.2 for PSI5 behaviour; here is the file convention.

### 7.1 The withMarkers workbook (`C:\AriaConfigFiles_Generic\…\Config_folder\RSU\`)
Sheet `OR_Start` (+ empty `Sheet1`). Row 1 has two **merged, colour-coded section banners**:
`RSU Configuration` (fill `FF8B0000`, dark red) over the left column block, and `RSU Startup`
(fill `FF4169E1`, royal blue) over the right block. **Columns = RSU sensor channels/slots; rows =
register bytes** (hex tokens: `1F4`, `7D`, `7193`, `2C`/`B6`/`149`, …). The left block is the
**Config** stream (parameters sent to each satellite), the right block the **Startup** stream.

### 7.2 The MARKERS = Excel defined names (named ranges) — **preserve exactly**
ARIA locates each slot's data **by named range, not by fixed cell position.** For each slot `N`
(1…number-of-RSU-slots; generic sheet = 18, W610 = 12) the workbook defines:

| Marker (per slot N) | Meaning |
|---|---|
| `Present_SlotN` | slot/sensor present flag |
| `Type_SlotN` | sensor type |
| `Sensor_Status_SlotN` | sensor status word |
| `RSU_Mode_SlotN` | RSU mode |
| `Repetition_factor_SlotN` | repetition factor |
| `Config_StartN` / `Config_EndN` | config-stream byte-range boundaries |
| `Config_ParmcountN` | number of config parameters |
| `Value_SlotN_Start` / `Value_SlotN_End` | 16-bit value block range |
| `Value8_SlotN_Start` / `Value8_SlotN_End` | 8-bit value block range |

**Rules when generating/editing an RSU sheet:** (1) keep every defined name intact and pointing at
the right cells; (2) if you add slots, add the full marker set for each new N and extend the
banner merges/fills; (3) never rename a marker or shift a block without moving its named range;
(4) preserve the two section banners (text, merge, `FF8B0000`/`FF4169E1` fills). A missing or
misplaced marker makes ARIA read the wrong bytes for that satellite. Use openpyxl and copy the
generic sheet as the template (mirrors `agent.md` § 16.5 lossless-Excel discipline).

### 7.3 The exported `.rsu` files (`Config_folder/*.rsu`) — [FACT]
Per-byte hex dumps, **one byte (2 hex chars) per line**. Naming: `p_Timeslot_<n>.rsu` = parameter/
config timeslot streams; `s_<Sensor>_SN_<nn>.rsu` = per-sensor startup streams (e.g. `s_Oroya_SN_01`,
`s_KP200_SN1`). These are **generated from the withMarkers sheet** — regenerate them when the sheet
changes; do not hand-edit.

### 7.4 Sensor definition XMLs
`SensorsConfig.json` (§ 4.4) → `RsuSensors[].Path` → `<Sensor>_Sensor.xml` under
`Config_folder\RSU\XLS\` (legacy) or `_accdata/Sensors/RsuSensors/` (modern). Sensor names seen:
OROYA, SMB482, KP200, SMA682. Each RSU `Function` in the `.ldbx` (§ 5.3) references its logical
channel; the sensor XML + `.rsu` streams give its data.

---

## 8. SPI sensor configuration — [FACT]
- **Modern:** `.ldbx` `Spifpga` functions (§ 5.3) carry `SensorType` (`GEN6_XY`, `PANASONIC`),
  `EvtSourcePath`, `DefaultEvtFile`, `AxisLabels`. SPI cards sit in dedicated slots (M314: 39, 41).
- **Legacy:** `SensorsConfig.json` `SpiConfiguration` (`EvtFolder`, `SpiSensors[]`) + EVT Excel
  sheets under `Config_folder\SPI\XLS\`. The **EVT (Error Vector Table)** per sensor encodes the
  register bit-map + fault vectors (SMI7xy BADR-dependent, SMA660 SEN-bit, ADXC150x read/write) —
  see `agent.md` § 25.5 #15 and the ARIA `SPI_FPGA_Workflows` doc. When creating SPI faults, edit
  the EVT sheet, not the runtime; if the needed fault isn't in an EVT, **ask** (agent.md rule).

---

## 9. Periodics: DBC → `.acpdf` — [FACT]
`.acpdf` (ARIA Core Periodics Definition File, XML `Version="7.0"`) is the **DBC re-expressed in
ARIA's native periodic format**. Structure:
`<XmlAriaCorePeriodics><Frames><CanFrameDefinition Name Dlc Id>` (Id decimal) `→ <Transmitter>
<Receivers><Pdus><SignalPduDefinition StartBit Dlc Endian> → <Signals><SignalDefinition Name>`
with `<StartBit><BitLength><Endian><RawValueType><PhysicalValueType><InitialValue><TableValues>
<DynamicBehaviors><CustomAttributes>`. The `CustomAttributes` carry the DBC's `GenMsg*`/`GenSig*`
attributes (`GenMsgCycleTime`, `GenMsgSendType`, `NmMessage`, `GenSigTimeoutTime_<node>`,
`GenSigSendType`, …) — **preserve them**; they drive cyclic timing, timeout detection and NM.

**Generation:** parse the project DBC (use `tools\extract_dbc_signals.py` / cantools per `agent.md`
§ 16.8) and emit one `CanFrameDefinition` per message, one `SignalDefinition` per signal, mapping
byte order to `Intel`/`Motorola`, scaling to Raw/Physical value types, and copying attributes. The
`.accf` `<Periodics>` `Description` records the source DBC filename (traceability). Keep the
`.acpdf` and the DBC in lock-step; regenerate on any DBC revision (diff per `agent.md` § 22 pb 8).

---

## 10. DBC files — [FACT]
Standard Vector DBC (`DBC/M314/SRS_FD_SVNID_40060_06032026.dbc` = CAN-FD vehicle bus,
`SRS_HSCAN_…dbc` = HS-CAN diagnostic bus). The DBC is the **authority for IDs, DLC, byte order,
scaling, and CRC/counter signal placement**; the `.acpdf` and both diag-ID sets must agree with it
(`agent.md` § 18.2: DBC wins on conflict). Filenames encode SVN id + date — keep them and record
the revision in the descriptor.

---

## 11. Diagnostics, Events, Filters, Crash data — [FACT]
- **Diagnostics tables:** `error_definition_*.xlsm`/`.xml` (DTC/fault definitions), `DTCList.xml`
  (`ErrorCodesGeneralConfig`), `Services.xml`/`Diagnostic_Services.xml` (UDS service defs),
  `FltMonr_Configurator_*.xlsm` (fault-monitor config → `agent.md` § 2.11). Referenced from
  `CanConfig.json` `DiagProperties` (legacy) and `<Diagnostic>`/`<EcuErrors>` (modern).
- **Events / Event Mode:** `EventsDefinition.acef` (Version 6.0) in the bundle; `EventMode\*.xlsm`
  templates (per OEM) in ConfigExample. Event Mode drives crash-synchronous DID logging + RTSE
  fault injection (`agent.md` § 25.4).
- **Filters:** `Filter_Folder\*.flt`/`.dft` — per-sensor signal-conditioning filters (named by
  sensor, e.g. `SMB120_Lowpass.flt`); referenced by `FilterFolder`.
- **Crash data:** `Config_folder\Crash_Data\` / `IMU_Data_India\` curves + `CrashConfiguration.xml`;
  RSU/SPI crash curves under `_accdata/Curves`. Loaded power-off (`agent.md` § 25.2).

---

## 12. File-format version reference — [FACT, ARIA 5.20]
Check the `Version` first and adapt (§ 0.3).

| File | Format | Version (5.20) | Role |
|---|---|---|---|
| `.accf` | XML `CoreConfiguration` | **33** | modern project master |
| `.ldbx` | JSON | **8** | loadbox / slot map |
| `<proj>_LoadBox_Profile.json` | JSON | (unversioned list) | loadbox runtime default states |
| `.acpdf` | XML `XmlAriaCorePeriodics` | **7.0** | periodics (DBC-derived) |
| `.acef` | XML | **6.0** | event-mode definition |
| `AriaMain.json` + set | JSON | (unversioned) | legacy config for AutomatedScripts/APYM |
| `.rsu` | text (hex/line) | — | exported RSU byte streams |
| RSU `withMarkers` | XLSX + defined names | — | RSU source (marker convention § 7.2) |
| `.dbc` | Vector DBC | — | bus authority |
| `.sym`/Mnemonics.xml | Vector symbol / mnemonic | — | CAN symbol + mnemonic tables |

---

## 13. The project-descriptor JSON (the "project-specific JSON")

**Intent.** A single, human-authored JSON per project that **completely describes** the project so
the agent can regenerate every ARIA file. It lives in the project folder as
`<Project>.project.json`. The formal schema is `aria_projects/_schema/aria_project.schema.json`
(this repo) and a filled reference is `aria_projects/M314/M314.project.json`. Top-level shape:

```jsonc
{
  "project":     { "name","oem","platform","variant","aria_version","customer_tab" },
  "buses":       [ { "name","kind":"CAN|CANFD|HSCAN","device_channel","arb_bitrate",
                     "data_bitrate","fd_timings":{…},"dbc","acpdf" } ],
  "diagnostics": [ { "name","bus","request_id","response_id","fc_request_id","fc_response_id",
                     "is_can_fd","padding_byte","frame_sizes","p2","p2_star","isotp":{…},
                     "security":{"kind":"dll|clypeum|none","ref"} } ],
  "dynamic_libraries": [ { "name","path","role":"crc|security|behavior" } ],
  "clypeum":     [ { "name","realm","base_url","client_id","ca_cert","service":{…} } ],
  "loadbox":     { "reserved_slots":{…}, "relay_groups":[…override/extra…] },
  "slot_map":    [ { "ecu_function","ecu_pins":[…],"zif_pins":[…],"aria_type",
                     "function_name","relay_group","slot?","channel?","default_status",
                     "dcs":{"voltage_pin","current_pin"}?, "rsu":{"logical_index","sensor"}?,
                     "spi":{"sensor_type","evt_file","axis_labels"}? } ],
  "rsu":         { "sheet_template","slots":[ {"index","sensor","type","mode","status",
                     "repetition_factor","present","config_params":[…],"startup_params":[…] } ] },
  "spi":         { "evt_folder","sensors":[ {"name","evt_file"} ] },
  "sensors_filters": [ … ],
  "diagnostics_tables": { "error_definition","dtc_list","services","fault_monitor" },
  "events":      { "acef","event_mode_template" },
  "crash":       { "crash_folder","crash_config" },
  "outputs":     { "emit_accf":true, "emit_legacy_json":true, "accdata_dir","config_folder" }
}
```
Every field traces to a concrete ARIA artefact above. Unknown/absent values are **omitted and
flagged**, never defaulted silently. The descriptor is the thing the user edits per project; the
agent never hand-edits generated ARIA files — it edits the descriptor and regenerates (mirrors the
generator discipline in `agent.md` § 18.5 / § 23).

---

## 14. Generation workflow (descriptor + pin map → project) — [INFERENCE, from the reference]
1. **Validate the descriptor** against the schema; resolve the DBC and pin map; confirm the
   card-channel→ZIF-pin table and reserved-slot convention (§ 6). Missing input → ask.
2. **Buses → `<Communication>`** (`.accf`) + `CanChannelConfig[]` (legacy). Decimal IDs in `.accf`,
   hex-string IDs in legacy — derive both from the same descriptor values.
3. **DBC → `.acpdf`** per bus (§ 9); set `<Periodics>`/`CanPeriodic` to reference them.
4. **Slot map → `.ldbx`** (§ 5–6): RelayMapGroups (reuse standard set), Cards, Functions,
   PresenceGroup; then the `_LoadBox_Profile.json` at healthy defaults. Wire `<Hardware>
   <LoadboxProperties>` to both.
5. **Diagnostics** → `<Diagnostic><Channels>` + `DiagProperties`; wire security (DLL/Clypeum).
6. **RSU** → generate the `withMarkers` sheet from the template preserving all markers (§ 7.2),
   export `.rsu` streams, write sensor XMLs + `SensorsConfig` RSU block.
7. **SPI** → EVT references + `SpiConfiguration`/`Spifpga` functions.
8. **Diagnostics tables / Events / Filters / Crash** → copy/reference the project's tables; set
   `AriaMain.json` `Customer` tab and folder paths.
9. **Assemble** the `_accdata/` tree, write `AriaMain.accf`, and (if requested) the legacy JSON set.
10. **Validate & review** (§ 15). Deliver as files; do **not** load onto a bench (§ 0.2 rule 3).

---

## 15. Validation & review checklist — [INFERENCE]
Config-only, no hardware. Before delivering, verify:
- **Cross-references resolve:** every `.accf` `*Identity`/`Ref` GUID, every `LibraryIdentity`,
  every `RelayMapGroupRef`, every `FunctionRef` points at an existing element; no dangling GUIDs.
- **IDs consistent** across DBC ↔ `.acpdf` ↔ `.accf` (decimal) ↔ legacy JSON (hex): same
  request/response IDs, DLCs, byte order, bitrates.
- **Loadbox integrity:** every `Function.Id` placed in exactly one card (or intentionally spare);
  slots unique and within chassis range; DCS `VoltagePin`/`CurrentPin` and RSU `LogicalIndex`
  populated; profile covers every placed channel with a valid preset name.
- **RSU markers intact:** all `*_SlotN` defined names present, contiguous 1…N, ranges non-overlapping;
  section banners + fills preserved; `.rsu` exports regenerated from the current sheet.
- **Versions:** each generated file carries the correct `Version` for the target ARIA (§ 12).
- **Traceability:** DBC filenames recorded; descriptor ↔ generated files diffable; no orphan files.
- **Evidence log:** for every non-obvious value, cite the descriptor field / DBC / pin-map row it
  came from; anything unresolved is listed as an open question (not guessed).

---

## 16. Glossary (ARIA config vocabulary)
| Term | Meaning |
|---|---|
| `.accf` | ARIA Core Configuration — modern XML project master (`CoreConfiguration`) |
| `_accdata` | sibling folder holding the `.accf`'s typed sub-files |
| `.ldbx` | Loadbox file — slot/card/function/relay map (JSON, the slot map) |
| LoadBox Profile | JSON of each channel's runtime default preset (loaded with `LoadProfile`) |
| `.acpdf` | ARIA Core Periodics Definition File — DBC compiled to ARIA periodics (XML) |
| `.acef` | ARIA Event-mode definition file |
| RelayMapGroup | named table of electrical presets (BitMapValue + ActionType) a function can switch to |
| Function (loadbox) | one card channel bound to an ECU signal (LOOP0, PAB_ON_LAMP, RSU_CH1…) |
| Card / Slot / Channel | a plug-in simulator card, its chassis slot, and its 1–2 channels |
| ZIF connector | ARIA's zero-insertion-force DUT connector; its pins harness to ECU pins |
| Marker (RSU) | an Excel **defined name** (`Present_SlotN`, `Value_SlotN_Start`, …) ARIA reads by |
| `.rsu` | exported per-byte RSU register stream (p_Timeslot / s_Sensor) |
| EVT | SPI Error Vector Table (per-sensor register + fault map) |
| Clypeum | ARIA's cloud security-access service (Level-61 seed/key) |
| Customer tab | `OEM\tPlatform\tVariant\tEnabled` string in `AriaMain.json` |
| VDK | virtual/offline simulation mode (`UseVdkSimulation`) |

---

## 17. Maintaining this document
- **Update triggers:** a new ARIA version (re-run § 0.3, diff `Version` numbers, update § 12 + the
  affected sections + the descriptor schema); a new file format appears in a known-good project;
  the reference project changes; a new card type / function `$type` / RelayMapGroup convention.
- **Keep evidence-based:** every structural claim traces to a file under `C:\ARIA5.20` or
  `C:\AriaConfigFiles_Generic`; label new claims [FACT]/[INFERENCE]/[ASSUMPTION].
- **Companion sync:** ARIA runtime/behaviour facts belong in `agent.md` § 25 (link, don't
  duplicate). Slot-electrical states here (§ 5.1) mirror `agent.md` § 25.6 — keep them consistent.

---

**Changelog**
- 2026-07-15 — Initial version. Built from deep analysis of the ARIA 5.20 install
  (`C:\ARIA5.20`: ConfigExample, Documentation, Firmware, format versions) and the **M314**
  reference bundle (`C:\AriaConfigFiles_Generic\AriaConfigFiles`): decoded the `.accf`
  CoreConfiguration v33, the `.ldbx` v8 loadbox (RelayMapGroups/Cards/Functions/PresenceGroups +
  LoadBox Profile), the legacy JSON set, the `.acpdf` v7.0 periodics (DBC-derived), the RSU
  `withMarkers` **defined-name marker convention** + `.rsu` export, SPI EVT wiring, and the
  diagnostics/events/dynamic-library/Clypeum sections. Defined the project-descriptor JSON (§ 13)
  and the ZIF↔ECU-pin slot-mapping model (§ 6). Evidence verified on this machine — session with
  copilot ai model.
