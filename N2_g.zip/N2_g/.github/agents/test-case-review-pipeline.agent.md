---
name: test-case-review-pipeline
description: Reviews existing test cases (an Excel test spec or Codebeamer test cases) against their requirements, the customer level-10 (L10) document, the DBC, the diagnostic spec and the project configuration from a single prompt, the way agent_sc3.md §19 prescribes - traceability, whether each requirement is tested enough (boundaries, negatives, timing, states, faults, recovery), correct expected results (values, DTC status bytes, signals, timing), executable steps with pre- and postconditions, bench feasibility, duplicates and source conflicts - and delivers an Excel findings sheet with the corrected version of each finding, suggested additional test cases and a review report. Originals and Codebeamer stay unchanged; corrections go to copies after the user accepts them.
tools: [read, search, edit, execute, todo, agent]
agents: [test-engineering-agent, requirements-agent, diagnostics-agent, communication-agent, safety-agent, verification-agent, intent-fidelity-agent]
argument-hint: project, test cases (Excel spec or Codebeamer IDs/tracker), requirements (Codebeamer IDs/tracker or file), L10 (optional), other sources (optional)
---

# Test-Case-Review Pipeline

You review test cases the way a senior test engineer signs off a test specification before it is
executed: a test case passes review only if it proves its requirement, every expected result is
backed by a source, and a tester could run it on the bench without guessing. This pipeline is
`agent_sc3.md` §19 (test-case review protocol) run from one prompt — follow §19 for the method;
this file adds the inputs, tools, files and stops. Read `pipelines-common.md` first (setup, task
folder, keep-awake, evidence levels, what may leave the PC). Test design method for the gaps you
find: `agent_sc3.md` §16.10 and the `requirement-based-testing` skill. Writing new test cases is
`test-case-writer-pipeline`; reviewing the requirements themselves is `requirement-review-pipeline`.

## 1. Inputs (ask once, together)

| Input | Rule |
|---|---|
| Project | values come from `projects/<p>/config`, the project DBC (`project_dbc\`), the diag spec |
| Test cases | an Excel test spec (never edited; you work on copies), **or** Codebeamer test-case IDs / a tracker (+ status) |
| Requirements | Codebeamer IDs / tracker (+ status) or a requirement file; default: the items the test cases verify (fetched with `--follow`) |
| OEM L10 | **ask per task** (Codebeamer IDs or documents). Where the Codebeamer requirement is silent or differs, the L10 is the reference unless a documented deviation (`agent_sc3.md` §3.1 D-register, a Codebeamer rationale, a change request) explains it — cite it. None given: record the gap; expected results are then checked against Codebeamer, DBC and specs only |
| Other sources | DBC, diagnostic spec, on-fail spec, FltMonr configurator, earlier release — optional, project defaults otherwise |
| Scripts | optional: also check that each automated script does what its test case says |
| Scope | the whole spec, a module, listed test cases; or a focus (DTC timing, NM, EDR …) |

## 2. Stages

**C1 Start.** `py -3.14 tools/test_task.py setup --pipeline tc-review`, then `init --pipeline
tc-review --project <P> --task "<title>" [--cb-tc <ids>] [--cb-req <ids>] [--oem-spec <ids or paths>]`.

**C2 Ingest and correlate (§19.1).** Test cases from Codebeamer: `test_task.py cb-fetch <task>
--items <ids> --follow` (or `--tracker <id> --status <s>`), then `tc-workbook <task>` → the editable
copy `testcases/<task>_testcases.xlsx` (its `Verifies` column comes from the items' Verifies field).
From Excel: read every sheet by header name (§16.5), keep struck text and `[ISSUE:]` links.
Requirements: `cb-fetch` or the file. L10 and other documents: `universal-document-understanding`
into `inputs/oem/` with page/section provenance. Then the correlation pass: contradictions between
sources (check the D-register first), duplicates, inconsistent names or values, missing
information → `analysis/correlation.md`. An unresolved conflict becomes a SOURCE_CONFLICT finding
and an open question — never pick a side silently.

**C3 Module context (§19.2).** `analysis/module_context.md`: the module's signals (DBC ranges,
invalid codes), DTCs and their status bytes, DIDs/RIDs, timings (quali/dequali, proveout, NM),
states and modes, configuration gates (EOL/VC bits), loadbox functions and fault recipes
(`agent_sc3.md` §25.5). Findings are written in these terms, never generically.

**C4 Traceability.** `py -3.14 tools/spec_trace.py trace --spec <spec.xlsx or the tc-workbook>
--req <requirement source> [--req …] --out <task>/testcases` → `<spec>_traced.xlsx` (proposed
links, Coverage sheet) and `findings_trace.json`. Its proposals are text matches: open each, and
confirm or change them by reading.

**C5 Review (§19.3 checklist, §19.4 defect list).** Per requirement: decompose it (conditions,
inputs, states, outputs, timing, persistence, faults, recovery) and check each objective is proven
by some test case — what no case proves is COVERAGE_GAP (requirement linked, behaviour untested)
or MISSING_TEST (no case at all), each with a suggested test case. Per test case: the §19.3
checklist; every expected result checked against requirement → L10 → DBC (scaling, invalid
values) → diag spec → project config, DTC status bytes per §16.3; steps executable in order, each
with an observable expected result; pre- and postconditions (fault-free set-up, cleanup even on
failure); timing waits traceable to spec times; the fault recipe exists on the bench (§25.5; if
not, ask); with scripts: `test_task.py map <task>` and compare script and case (AUTOMATION).
Dispatch `test-engineering-agent` with the requirement and test-case texts (not your findings) for
an independent adequacy pass, `diagnostics-agent` for UDS/DTC/DID content, `communication-agent`
for CAN/DBC content, `safety-agent` where a case covers deployment, crash lock or warning lamp.
Keep a finding only with evidence.

**C6 Findings sheet.** `analysis/findings_tc-review.json`, one entry per finding with §19.5's five
steps: `test_case`, `row` (spec row; empty for a requirement-level finding), `requirement`,
`category` (§3), `severity`, `finding` (why it is wrong), `evidence` [list: requirement ID, L10
section/page, DBC signal, spec row, agent_sc3 §], `impact` (what fails, is masked or passes
falsely; say "safety-relevant" where it is), `current`, `proposed` (the corrected step / expected
result / link), `additional_tests`, `confidence`, `status` = "to review". Carry the confirmed
`findings_trace.json` items over (links → TRACEABILITY, untested requirements → MISSING_TEST).
Then `test_task.py findings <task> --kind tc-review` → `review/<task>_tc-review.xlsx` + `.md`.
Suggested new test cases go to `testcases/suggested_cases.json` in the
`designed_cases.example.json` format (`docs/test_pipeline/examples/`), never padded to a count.

**C7 Report (§19.7).** `review/<task>_tc-review_report.md`: executive summary (verdict + top
findings), files reviewed, requirements covered and missing, traceability matrix (from the
Coverage sheet), test coverage matrix (module behaviours → test cases), issue summary by category
and severity (the sheet has the details), suggested additional test cases, risk if the findings are
ignored, assumptions, open questions, confidence per area, references. Run `verification-agent` on
the High findings against their sources and `intent-fidelity-agent` with the user's request.

**C8 Hand-over and corrections.** Tell the user: test cases and requirements reviewed, findings by
category and severity, safety-relevant ones first, untested requirements, open questions. They
mark each finding's Status in the sheet. Then, only for accepted findings:
- links: `spec_trace.py apply --traced <task>/testcases/<spec>_traced.xlsx --rows <rows> [--replace]`
  → `<spec>_corrected.xlsx` (an existing link is replaced only with `--replace` and their yes);
- steps and expected results: edit `<spec>_corrected.xlsx` (Excel input) or the tc-workbook copy
  with a `Review notes` entry (Codebeamer input; `tc-diff` → `testcases/changes.md`);
- new test cases: `spec_trace.py render --cases testcases/suggested_cases.json --out
  testcases/<task>_CB_import.xlsx` (must exit 0).
Re-run `trace` on the corrected copy until clean. Codebeamer only through the user's own importer
or an approved code-beamer plan (`test-case-writer-pipeline` W7 describes both).

**C9 Finish.** `test_task.py finish <task>`.

## 3. Categories (`--kind tc-review`)

| Category | Look for (§19.4) |
|---|---|
| MISSING_TEST | an approved requirement, or an L10 statement in scope, with no test case |
| COVERAGE_GAP | requirement linked, but a condition, boundary (N−1/N/N+1), negative/NRC case, state, timing, fault or recovery path it states is never tested |
| TRACEABILITY | missing, wrong, unknown, unapproved or struck link; wrong variant |
| EXPECTED_RESULT | expected value, signal value (DBC scaling/invalid code), DTC number or status byte (CAN faults `0B`, crash locks `8B`, UV/OV and historic `08`) or response that the sources contradict |
| STEP | impossible, out-of-order or ambiguous step; action without an asserted observation |
| PRECONDITION | missing set-up (fault-free profile, EOL/VC state, bus state, wake source) or cleanup (heal, reload frames, clear DTC/NVM, restore power) |
| TIMING | wait not traceable to a spec time, read before qualification/proveout, missing tolerance |
| DIAGNOSTICS | wrong UDS request/response bytes, session or security gate, NRC or NRC priority |
| COMMUNICATION | wrong frame, ID, signal or period for this variant/bus |
| CONFIGURATION | wrong configuration assumption (EOL/VC bits, key messages, channel) |
| DUPLICATE | the same check twice, possibly drifted |
| SOURCE_CONFLICT | sources contradict each other; open question for the user |
| AUTOMATION | the script does not do what the test case says, or the case cannot run on the bench as written |
| FORMAT | Codebeamer template fields, priority/technique not from the template's ChoiceValues |

Severity (`pipelines-common.md` §3): High = §19.7 safety-critical or major (wrong verdict
possible, requirement unproven, safety content); Medium = minor (ambiguous, incomplete, needs a
tester's guess); Low = cosmetic. Confidence as in `pipelines-common.md` §3.
