# Agent instructions

The complete knowledge base and working rules for this repository are in **`agent_sc3.md`** (`.github/agents/agent_sc3.md`,
not the repo root). Read the relevant section before acting:

- **Core engineering principles & operational framework (governs everything)**: §0 — quality
  over speed; assume every artefact may be wrong and verify independently; every conclusion
  evidence-backed (else say "Evidence unavailable.") with a confidence level and
  fact/inference/assumption labelling; 13-stage workflow with quality gates; cross-document
  correlation + contradiction detection (→ D-register); change impact analysis;
  multi-perspective self-review; §0.15 success criteria define "complete"
- ECU modules, protocols, requirement analysis, D-01…D-12 discrepancy register: §1–§12, §3.1
- Test-case authoring (Veoneer Excel format, requirement-ID mapping, DTC status bytes — CAN
  faults active = `0B`, crash locks `8B` — and NRC rules): §16
- Test DESIGN methodology (mandatory for requirement-based test writing): §16.10 — minimal
  high-value suite, never pad test counts; analyse + decompose requirements and derive
  objectives before any case; equivalence/boundary/state/MC-DC/risk-based techniques; negative
  + fault-injection sweep; optimise (merge/deduplicate/parameterise); coverage report with
  uncovered behaviour listed; full traceability, no orphan cases; **priority/high-value cases
  first in the delivered spec**
- Reading Excel sources without content loss (full openpyxl dump, header-name column resolution,
  Codebeamer markup decoding, extraction verification): §16.5
- Reading PDFs/Word documents (library selection, table integrity, OCR with confidence flags,
  completeness cross-checks, extraction-quality reporting): §16.6
- Excel sanitization & normalization pipeline (strip presentation artifacts only, preserve all
  engineering tokens, `[STRUCK:]` markers, integrity verification gate before analysis): §16.7
- DBC & CAN/diagnostic log analysis (cantools/python-can/asammdf/polars, install-what-you-need
  mandate, `tools\extract_dbc_signals.py`, multi-GB streaming, signal/temporal checks, ISO-TP
  diagnostic timeline, requirement→signal→message→code→test→log correlation, root-cause
  format): §16.8
- Library manifest for every file format (`tools\analysis-requirements.txt`) + the four pipeline
  practices (fallback parser chains, extraction validation, common internal model, provenance on
  every extracted item): §16.9
- Multi-agent orchestration for batch tasks: §17 — workflow roles §17.1–17.2, the 13-specialist
  virtual team (incl. Cybersecurity) + independence/consensus rules §17.3–17.4, execution
  substrates (simulated passes
  / subagents / Copilot CLI terminal / cloud coding agent, with graceful fallback) §17.5,
  incremental execution §17.6, self-verification loop §17.7, unified report structure §17.8
- Python script authoring (module config + shared_libraries wrappers ONLY — never direct
  library/`Api.*` calls; new bench wrappers → `jscript_translation.py`, new user-defined
  functions → `core_functions.py`, both project-agnostic; scripts clean like the EDR scripts;
  config-driven with inform-and-suggest on gaps; timing/ignition-cycle discipline; legacy ARIA
  API porting rules): §18
- Test-case review & cross-document validation protocol (ingest-correlate first, module-aware,
  evidence-based findings, full report deliverables): §19
- AI behavioral rules: §20
- Environment, tooling & repository map + quick-reference card (interpreters, where every source
  lives, key constants): §21
- Task playbooks (question / test cases / script / JS port / review / batch / new variant): §22
- **Safety & permission boundaries — read before running anything**: §23 (writing code ≠ running
  it; never actuate bench/ECU, flash, or write EOL/VC/VIN/NVM without an explicit user request;
  never hand-edit generated artifacts)
- Glossary: §24
- ARIA 5.20 simulation environment (docs at `C:\ARIA5.20\`, bench/cards/APYM/RTSE, **§25.5
  fault-creation catalog — if a fault isn't there or you're doubtful, ask the user**, loadbox
  electrical states): §25
- Saleae / oscilloscope PWM verification (ENS 40 ms, 62.5 %/37.5 % duty; instrument settings):
  §26
- Electrical-engineering basics + communication protocols (SPI, PSI5, CAN/CAN FD, LIN/K-line,
  PWM) for hardware questions: §27
- **Cybersecurity, CRC & communication protection** (secure boot/flashing, secure UDS,
  SecOC/E2E, MAC/freshness/replay, CRC & alive/rolling counters, crypto/keys, debug-port
  security): §28 — senior-cybersecurity-engineer workflow, ISO/SAE 21434 & WP.29 R155 & AUTOSAR
  SecOC/Crypto awareness, **§28.10 CRC & E2E algorithm reference** (CRC-8/16/32/64 params +
  AUTOSAR E2E profiles P1–P7), E2E-vs-SecOC distinction, security tests, findings format;
  security weaknesses on actuation/flash/NVM paths are safety issues. UDS per ISO 14229 — deviate
  only for a documented OEM deviation or explicit user request (§4.3)
- Maintaining this document: §29
- **EDR specialist** (T0 / event logic, lock and overwrite, NHTSA Part 563 delta-V recording,
  AUTOSAR internal axis vs regulation reporting polarity): `edr-agent.agent.md`. Project EDR
  values still come from §2.7 / §2.8 and the project configs.
- **IMU specialist** (Panasonic 6-DoF IMU in the ACU: mounting and coordinate frames, SPI/CRC,
  raw-data conversion, plausibility and diagnostics, IMU test design and fault injection):
  `imu-airbag-validator.agent.md`.
- **UDS specialist** (ISO 14229 services, request/response formats, NRCs, DTC status and records,
  sessions/security, ISO-TP/DoIP, flashing sequences; implementing, testing, debugging and reviewing
  UDS code): `uds-protocol-engineer.agent.md`, with its per-service reference catalogue in
  `.github/uds/` (`service-catalogue.md`, `services/0x<SID>-*.md`, NRC / DTC / fundamentals
  references). Project UDS facts still come from §2.12, §4.3, §10, §16.3–§16.4 and the project configs.
- **CAN NM specialist** (network management: wake-up, keep-awake, sleep, NM PDUs `SRS_CANNM` /
  `VCU_CANNM`, NM timers, CAN wake-up test flows, AUTOSAR CanNm vs the OEM NM requirements, NM black-box
  tests and debugging): `can-network-management-engineer.agent.md`, with its knowledge base, OEM deviation
  matrix and test catalogue in `docs/can-network-management/` (checker `py -3 tools/check_cannm_docs.py`).
  Project CAN facts still come from §2.2–§2.3 and the project configs.
- **ARIA bench operator** (how the ARIA HIL bench works; checking, starting and stopping ARIA,
  switching its project, apym connection, logs, RSU sheets per sensor type, every bench input, ARIA
  troubleshooting, any ARIA version via `tools/aria_ctl.py versions|verify-internals|compat`):
  `aria-bench.agent.md`. ARIA configuration file formats: `aria_agent.md`.
- **Test execution from one prompt** (Codebeamer or manager task → requirements, test cases, OEM
  L10, ECU source review → alignment → ARIA run → logs/reports named per test case → failure
  triage, script fixes with backup + git commit, re-runs → bug list → zip and PTC push on the
  user's paths): `test-execution-pipeline.agent.md`, started with the `/run-test-task` prompt;
  mechanical steps in `tools/test_task.py`; user guide `docs/test_pipeline/USER_GUIDE.md`.
- **Requirement review from one prompt** (Codebeamer requirements vs the customer L10 and other
  documents → evidence-backed review comments in Excel): `requirement-review-pipeline.agent.md`,
  prompt `/review-requirements`.
- **Test-case writing / traceability from one prompt** (traceable test cases in the Codebeamer
  import format; missing traceability added to an existing Excel spec with documented
  corrections): `test-case-writer-pipeline.agent.md`, prompt `/write-test-cases`; tools
  `tools/spec_trace.py`.
- **Test-case review from one prompt** (existing Excel or Codebeamer test cases vs requirements,
  customer L10, DBC, diag spec and project config, per `agent_sc3.md` §19 → findings in Excel with
  the corrected version, suggested test cases, review report): `test-case-review-pipeline.agent.md`,
  prompt `/review-test-cases`.
- **Test-results review from one prompt** (HTML/XML reports + CAN logs vs test spec and
  requirements → findings in Excel): `report-review-pipeline.agent.md`, prompt
  `/review-test-results`; tool `tools/report_review.py`.
- All five pipelines share `pipelines-common.md` (setup with automatic installs, task folder,
  keep-awake while the screen is locked via `tools/keep_awake.py`, evidence levels, gates).
- **Root cause of one failure** (a failing test or wrong verdict, odd bench behaviour, unexpected ECU
  response, config/generator inconsistency — traced through every layer and domain, verdict in the
  pipeline's six categories, decisive experiment, regression test): `ecu-integration-debugger.agent.md`,
  starting from the failure register `docs/engineering/known-failure-signatures.md` (KFS-xx).
  Campaign-wide triage stays with the test-execution pipeline.
- **Requirements, standards and compliance** (which requirement / standard edition applies, coverage
  requirement → test case → script → result with `tools/trace_coverage.py`, compliance with graded
  evidence, cross-domain deviation classification A–E): `automotive-requirements-compliance.agent.md`,
  with `docs/compliance/` (standards register, deviation index, traceability state).
- **Interfaces, cables, pinouts, drivers, APIs and licences** (which CAN/CAN FD/LIN/Ethernet interface,
  cable and pins a task needs; Vector/PEAK/other vendor drivers, XL Driver Library, PCAN-Basic, python-can
  backends; licence entitlements; device/driver/wiring troubleshooting; bench today: Vector VN1610
  s/n 48714 through ARIA): `automotive-tools-hardware-engineer.agent.md`, with `docs/automotive-tools/`
  (inventory, verified pinouts, licensing, compatibility matrix). ARIA itself stays with `aria-bench`.
- **Code writing** (any new code or code change: scripts, generators, tools, tests, fixes,
  refactors, code review): `ponytail.agent.md`. Smallest complete change, reuse first, readable at a
  glance; the rules in this file and `agent_sc3.md` take precedence.

Non-negotiable: verify requirement IDs, DTC codes, and shared-library function signatures in
their source files before using them; all constants come from `projects\<project>\config\` or the
DBC (missing constant → inform the user and suggest a config placement, never inline); if a
needed wrapper function does not exist anywhere in `shared_libraries`, stop and suggest/ask
permission to create one (per agent_sc3.md §18.4/§18.6) instead of writing inline bench logic; if
unsure how to create a fault in a script, ask (agent_sc3.md §25.5).
