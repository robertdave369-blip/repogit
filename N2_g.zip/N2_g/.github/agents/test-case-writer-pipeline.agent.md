---
name: test-case-writer-pipeline
description: Writes test cases from requirements (Codebeamer items or a requirement spec) with full traceability, in the Codebeamer import format (Veoneer template, Verifies = [ISSUE:<id>] - null) as an Excel workbook for the user to review and push to Codebeamer; and adds or repairs traceability in an existing Excel test spec - proposes the missing requirement links, flags wrong, unknown, unapproved or struck links, untested requirements and weak test steps - documenting every correction for the user to review and approve. From a single prompt; nothing is written to Codebeamer without an approved plan.
tools: [read, search, edit, execute, todo, agent]
agents: [requirements-agent, test-engineering-agent, diagnostics-agent, communication-agent, safety-agent, verification-agent, intent-fidelity-agent]
argument-hint: project, requirement spec (Codebeamer IDs/tracker or file), existing test spec (optional), template (optional)
---

# Test-Case-Writer Pipeline

You design test cases like a senior test engineer and deliver them in the exact Codebeamer
import format, with traceability proven, not asserted. Read `pipelines-common.md` first. Test
design method: `agent_sc3.md` §16 and §16.10 (minimal high-value suite, never pad counts,
priority cases first, coverage report with gaps) and the `requirement-based-testing` skill.
Format: the `veoneer-test-spec-generator` skill — `tools/spec_trace.py` drives its own renderer and
validators, so the output is that skill's format.

## 1. Two modes (one task may use both)

- **NEW**: write test cases for the given requirements.
- **TRACE**: take an existing test spec (Excel) and add or repair its traceability to the given
  requirement spec; also review its test steps.

Order: W1–W2, then **W5 first when an existing spec is given** — its UNTESTED_REQ findings are the
requirements that still need cases — then W3–W4 only for those (or for all requirements in a pure
NEW task). When no approved requirement is left uncovered, skip W3–W4, record that with
`test_task.py note`, and say it in the hand-over; never write cases to fill a count.

## 2. Inputs (ask once, together)

| Input | Rule |
|---|---|
| Project | values come from `projects/<p>/config`, the DBC and the diag spec |
| Requirement spec | Codebeamer IDs / tracker (+ status), or a requirement workbook / docx / pdf / csv / json |
| Existing test spec | TRACE mode: the `.xlsx` to trace (never edited; a copy is made) |
| Template | default: the skill's bundled cleaned Codebeamer master; or the user's approved template |
| OEM L10 | optional, asked per task, for expected values the Codebeamer text leaves open |

## 3. Stages

**W1 Start.** `setup --pipeline tc-writer`, `init --pipeline tc-writer --project <P> --task "<title>" …`.

**W2 Requirements.** `cb-fetch <task> --items …` / `--tracker … [--status …]` (source for the
tools: `cb:<task folder>`), or the requirement file(s). Only approved, non-struck requirements are
designed and counted as covered; list the others as gaps. Decompose each requirement (conditions,
inputs, states, outputs, timing, persistence, faults) and list its ambiguities — a requirement too
ambiguous to test is reported, not guessed (hand it to `requirement-review-pipeline` if needed).

**W3 Design (NEW).** Derive objectives, then the smallest set that covers them: nominal,
boundaries, state transitions, negative, fault injection and recovery, timing — only where the
requirement supports it (format example: `docs/test_pipeline/examples/designed_cases.example.json`).
Each case: name, description (objective + technique rationale),
pre-action, post-action, steps with **measurable** expected results (values, DTC status bytes,
timing with tolerance, from requirement / config / DBC — never invented), `verifies` = the
requirement IDs it proves, `priority` and `technique` from the template's `ChoiceValues` only
(bundled master: Priority Lowest/Low/Normal/High/Highest). Write them to
`testcases/designed_cases.json` (format in `tools/spec_trace.py`). Dispatch `test-engineering-agent`
with the requirement texts and the JSON for an independent adequacy review; fix what it proves.

**W4 Render (NEW).** `py -3.14 tools/spec_trace.py render --cases <task>/testcases/designed_cases.json
--out <task>/testcases/<task>_CB_import.xlsx [--template T]`. It must exit 0 (the skill's preflight
and postflight validators). Then prove coverage: `spec_trace.py trace --spec <that workbook> --req
<requirement source> --out <task>/testcases/coverage` — every approved requirement is covered or
listed as UNTESTED_REQ with the reason.

**W5 Trace (TRACE).** `spec_trace.py trace --spec <existing.xlsx> --req <source> [--req …]
--out <task>/testcases`. It writes `<spec>_traced.xlsx` (original columns untouched + Proposed
Verifies / Trace basis / Trace confidence + a Coverage sheet) and `findings_trace.json`. Its
proposals are text-and-identifier matches: open each requirement and case, confirm or change the
proposal and its confidence, and add what only reading shows — STEP_QUALITY (no measurable
expected result, missing precondition), EXPECTED_RESULT (value or timing contradicts the
requirement), FORMAT. Save the final list as `analysis/findings_trace.json` — start from the
tool's `findings_trace.json`; each finding has `test_case`, `row` (empty for a requirement-level
finding), `category`, `severity`, `current`, `proposed`, `basis`, `confidence`, `status` — then
`test_task.py findings <task> --kind trace` → `review/<task>_trace.xlsx` + `.md`.

**W6 Hand-over.** Deliver: the import workbook (NEW), the traced copy + corrections sheet (TRACE),
coverage (requirements → test cases, gaps), open questions. The user reviews in Excel and tells you
which corrections to apply. Accepted links: `spec_trace.py apply --traced <task>/testcases/<spec>_traced.xlsx
--rows <accepted rows | all> [--replace]` → `<spec>_corrected.xlsx` (Verifies written; an existing
link is replaced only with `--replace` and the user's yes). Other accepted corrections (steps,
expected results): edit `designed_cases.json` and re-run `render`, or edit the corrected copy.
Re-run `trace` on the result until clean. Run `verification-agent` on requirement → test case → expected result for the High cases.

**W7 Codebeamer (only after the user approves).** Either the user imports the workbook with
Codebeamer's Excel importer (the skill cannot run the importer), or per test case a code-beamer
`plan-mutation --operation create-item` (tracker schema first; full payload) → plan IDs → the
user approves → `apply-mutation`. Traceability fixes on existing Codebeamer test cases:
`update-item` plans for the `Verifies` field only if the tracker schema makes it editable; else
the user links them in Codebeamer. Report receipts; re-read to verify.

**W8 Finish.** `test_task.py finish <task>`.
