# Framework Core and Debugging Guide

> Purpose: explain how this test framework is organised, why one framework can serve several ECU projects, and how to debug a problem without bypassing the framework or unintentionally operating a bench.
>
> Scope: this is an architectural guide, not an API catalogue. It explains the important files, execution path, Python syntax used in those files, and a safe debugging method. Function names, message names, DTCs, IDs and timing values must always be verified in the target project configuration, DBC and requirement sources.

## 1. The core idea in one minute

The framework separates **what a test wants to prove** from **how a particular bench and project perform the operation**.

```text
Test intent                       Generic implementation                   Project-specific facts
-----------                       ----------------------                   ----------------------
"send a CAN signal"      -->      CAN.ChangeSignalValue(...)       -->     frame, signal, bus, DBC
"read a DTC"             -->      Read_DTC(...) / CAN wrapper      -->     DTC, DID, request IDs
"record a report"        -->      create_report_and_logging(...)   -->     project output location
"make a load fault"      -->      approved shared wrapper           -->     loadbox/slot configuration
```

The test script should therefore be small and readable. It picks the **test data** and calls a shared function. The shared function hides the APYm/ARIA details. The active project configuration supplies the values that are different for M310/M314/M110, U171, W616, UPP_EV, and other projects.

**Do not cross the layers.** A test script must not call `Api.*` directly, hard-code a CAN-channel number, or reproduce bench logic. Those details belong to the shared wrapper layer.

## 2. Architecture map

```mermaid
flowchart TB
    T[Module test script\nprojects/<project>/modules/<module>/scripts] --> I[shared_libraries/import_list.py\ncompatibility import surface]
    T --> PC[projects/<project>/config/*.py\nproject and module facts]

    I --> CF[core_functions.py\ncommon test sequences, reports, conversion helpers]
    I --> JT[jscript_translation.py\nCAN, PS, RSU, SPI, SQUIB, LAMPS, RESULT wrappers]
    I --> DL[Domain libraries\nEDR, DCS, fault monitor, conversions]
    I --> PL[project_config_loader.py\nloads the active project's config]

    PL --> FR[framework_registry.py\nfinds framework root and project from path]
    JT --> AI[apym_imports.py\ncontrolled APYm availability and reporter access]
    AI --> APYM[Proprietary APYm SDK]
    APYM --> ARIA[ARIA HIL configuration and runtime]
    ARIA --> BENCH[Bench cards, loadbox, CAN, ECU]

    CF --> OUT[test_results/<project>/\nHTML report and CAN log]
```

### Read the diagram from left to right

1. A test script states the scenario and assertions.
2. It gets reusable capabilities from `shared_libraries`.
3. The shared layer determines the active project and loads that project's configuration.
4. Only the shared wrapper layer talks to APYm.
5. APYm talks to ARIA, which can operate real HIL hardware.

This is the safety boundary: **a successful Python import is not proof that the correct bench action happened**, and a direct APYm call in a test script makes the action hard to review and reuse.

## 3. Repository map: where to look first

```text
Framework_IOEM_Py/
|
|-- shared_libraries/                 reusable, project-independent behaviour
|   |-- framework_registry.py          find framework root and infer project
|   |-- project_config_loader.py       load config for the active project
|   |-- apym_imports.py                APYm SDK shim and safe import behaviour
|   |-- jscript_translation.py         ARIA-style wrapper classes: CAN, PS, RESULT...
|   |-- core_functions.py              higher-level common test sequences
|   |-- edr_*.py, dcs_library.py ...   module/domain-specific reusable logic
|   `-- import_list.py                 legacy-compatible single import surface
|
|-- projects/
|   |-- M310_M314_M110/
|   |-- U171/
|   |-- W616/
|   |-- UPP_EV/
|   `-- ...                            one folder per supported project/platform
|       |-- config/                    only project/module facts belong here
|       `-- modules/<MODULE>/scripts/  test procedures for that project and module
|
|-- aria_projects/                    ARIA project/configuration assets
|-- tests/                            offline framework tests
|-- test_results/<project>/           generated reports and logs
|-- tools/                            analysis and generation tooling
|-- agent.md                          engineering, authoring and safety rules
`-- aria_agent.md                     ARIA configuration knowledge base
```

### Ownership rule

| Change needed | Correct home | Wrong home |
|---|---|---|
| A project has a different CAN signal, DID, DTC, timing, feature or variant value | `projects/<project>/config/` | A test script or `shared_libraries` |
| A reusable operation is missing for every project | `shared_libraries/`, after wrapper approval | Copy/paste into each script |
| One test's sequence/objective changes | That module's script or its generator input | A global wrapper |
| ARIA loadbox, cards, CAN configuration or diagnostic channel changes | The correct ARIA project/configuration asset | A random Python literal |
| A generated IO/UDS script must change | Its generator/input, then regenerate | The generated `.py` file |

## 4. How project selection makes the framework generic

The most important generic mechanism is not a large `if project == ...` block. It is **project discovery plus project-local configuration**.

```mermaid
flowchart TD
    S[Shared function needs a config value] --> A{Explicit project override set?}
    A -- yes --> O[Use set_active_project value]
    A -- no --> E{IOEM_FRAMEWORK_PROJECT set?}
    E -- yes --> V[Use environment value]
    E -- no --> P{Is caller inside projects/<name>/?}
    P -- yes --> N[Infer <name> from script path]
    P -- no --> X[Raise clear error: active project unknown]
    O --> L[Import projects.<name>.config.<module>]
    V --> L
    N --> L
    L --> C[Cache module by project + config module name]
```

### The two small files that make this happen

#### `shared_libraries/framework_registry.py`

This file is deliberately simple. It has no bench calls and no project imports.

- `locate_framework_root()` walks from the caller's path upward until it finds `Framework_IOEM_Py/shared_libraries`.
- `infer_project_name()` finds the `projects/<PROJECT>/` part of the caller's path. If it cannot, it falls back to `IOEM_FRAMEWORK_PROJECT`.
- `list_available_projects()` lists folders below `projects/`.

This is why a script under:

```text
projects/U171/modules/EDR/scripts/example.py
```

can use the same shared code as a script under:

```text
projects/M310_M314_M110/modules/EDR/scripts/example.py
```

but receive different configuration values.

#### `shared_libraries/project_config_loader.py`

This file imports the requested configuration module for the active project.

```python
from shared_libraries.project_config_loader import (
    get_active_project,
    get_project_config_symbol,
)

signal_map = get_project_config_symbol("canc_config", "CAN_SIGNAL_Rx_MAP")
```

Meaning:

- `"canc_config"` selects `projects/<active project>/config/canc_config.py`.
- `"CAN_SIGNAL_Rx_MAP"` selects a named variable inside that file. It is an
  existing M310/M314/M110 CAN-signal mapping; another project can expose a
  different, project-appropriate structure.
- The loader uses `importlib`, which means Python imports a module by a constructed name instead of a fixed file path.
- The module is cached by `(project, module_name)`. Repeated lookups are fast and return the same imported module.
- `reset_project_config_cache()` is needed after editing a config file in a long-lived interactive Python session; otherwise Python can keep returning the old module object.

### Why a config is better than a literal

Bad pattern:

```python
CAN.ChangeSignalValue("CANFD", "SRS1_FD_10", "STS_CRASH", "1")
```

It ties the test to one variant, one bus, and one naming convention.

Better structure:

```python
signal_map = get_project_config_symbol("canc_config", "CAN_SIGNAL_Rx_MAP")
frame_name, signal_name = signal_map[get_active_project()]["STS_CRASH"]
# Use frame_name and signal_name only through the applicable shared wrapper.
```

The test still states its intent, but the project configuration owns the names. A different project can provide its own signal mapping without forking the test logic. This exact mapping shape is an M310/M314/M110 example; verify the target project's config before using it.

## 5. Shared library layers: what each layer is for

```mermaid
flowchart BT
    A[APYm / ARIA proprietary API] --> B[jscript_translation.py\nLow-level adapter]
    B --> C[core_functions.py and domain libraries\nReusable test operations]
    C --> D[Module test scripts\nScenario, test data, expected result]
```

### 5.1 `apym_imports.py`: keep proprietary SDK handling in one place

This file is an adapter around the proprietary APYm package.

- `ensure_apym_on_path()` looks for the APYm source tree and adds it to Python's import path when available.
- `init_aria()` attempts the APYm connection initialisation.
- `get_api()`, `get_reporter()` and `get_type()` expose the small APYm surface that wrappers need.
- With `strict=False`, unavailable APYm objects become `None` or no-operation reporter objects. This permits offline import/smoke testing of code that does not require a bench.

**Important:** a no-operation fallback makes an import possible; it does not simulate an ECU. Treat it as an import/testability aid, never as HIL test evidence.

### 5.2 `jscript_translation.py`: the bench adapter

This is the main compatibility layer between test scripts and APYm. It provides ARIA-style classes such as:

```text
CAN      simulated frames, signal values, diagnostics, CAN logging
PS       power-supply operations
RSU      PSI5/remote sensor operations
SPI      IMU/SPI stimulus operations
SQUIB    squib/loadbox operations
LAMPS    lamp and ENS measurement/configuration operations
RESULT   report actions and verdicts
```

The wrapper functions:

1. validate/normalise arguments;
2. resolve a named channel such as `CANFD`, `HSCAN` or `ARIA` to the current ARIA runtime ID;
3. call APYm internally; and
4. return a normal result or an error indication according to the wrapper's contract.

For example, `CAN.ChangeSignalValue(...)` resolves the simulation channel, builds a default PDU name from the frame when suitable, then calls the APYm simulation API. A test script should call this wrapper—not the APYm API—because the wrapper is where cross-project channel handling belongs.

### 5.3 `core_functions.py`: reusable test sequences

This file contains operations that are larger than one APYm call, for example report creation, power-cycle sequences, fault-free setup, DTC reading, signal conversions, EDR handling and project-aware helpers.

Example: `create_report_and_logging(...)`:

```text
caller script path
  -> infer project name
  -> build test_results/<project>/ and Log/ paths
  -> create APYm report
  -> start CAN logging
  -> return report path and log path
```

This is generic because it derives the project from the caller and sanitises the output name instead of embedding an output path in every script.

### 5.4 Domain libraries

Files such as `edr_decoding_functions.py`, `edr_did_library.py`, `dcs_library.py`, `fault_monitor.py`, `data_conversions.py` and `crash_configuration.py` hold reusable knowledge for one technical domain. Use them when the operation is not merely an APYm action but requires ECU-domain decoding, calculation or interpretation.

### 5.5 `import_list.py`: convenience, with a debugging cost

Many existing scripts use:

```python
from shared_libraries.import_list import *
```

`import_list.py` re-exports names from many shared-library files. This supports legacy scripts and makes test scripts short.

The cost is discoverability: when a name such as `Read_DTC` or `Sleep` is used, the import line alone does not show where it is defined. To debug it, search first:

```powershell
rg -n "def Read_DTC" shared_libraries
rg -n "class CAN|def ChangeSignalValue" shared_libraries
```

For new non-generated code, prefer explicit imports when the module's conventions allow them. For established scripts, preserve the local import pattern unless the refactoring is intentional and verified.

## 6. A complete execution trace: from one line in a test to the bench

Consider this conceptual line:

```python
CAN.ChangeSignalValue(frame_name, signal_name, raw_value)
```

```mermaid
sequenceDiagram
    participant TS as Test script
    participant CAN as CAN wrapper
    participant RT as Runtime resolver
    participant APYM as APYm API
    participant ARIA as ARIA simulation
    participant ECU as ECU / network

    TS->>CAN: ChangeSignalValue(frame, signal, raw value)
    CAN->>RT: require_runtime()
    RT->>APYM: obtain simulation and channel information
    RT-->>CAN: resolved simulation ID
    CAN->>APYM: change raw signal value
    APYM->>ARIA: update configured periodic frame
    ARIA->>ECU: transmit according to ARIA/DBC configuration
```

The same pattern applies to diagnostics:

```text
Test script -> CAN.SendDiagByValues -> payload formatter -> diagnostic channel resolver
            -> APYm UDS request -> ARIA diagnostic channel -> ECU -> response formatter
```

If the error occurs, identify the **last layer that was confirmed to work**. Do not start by changing the test case.

## 7. Python syntax you will repeatedly see

This section explains the syntax that matters when reading this framework.

| Syntax | Meaning in plain language | Framework example / debugging implication |
|---|---|---|
| `import module` | Load a module and keep its namespace. | `import importlib` allows the config loader to import a config dynamically. |
| `from x import y` | Import only a named symbol. | `from .framework_registry import infer_project_name` uses a sibling module. The leading `.` means “from this package.” |
| `from x import *` | Import names exported by another module. | Used by `import_list.py` for legacy convenience; search the source definition when debugging a name. |
| `def name(...):` | Define a function. | `def locate_framework_root(...)` defines reusable path logic. |
| `class Name:` | Define a namespace/object type. | `class CAN` groups CAN wrapper methods. |
| `@staticmethod` | Method belongs to a class namespace but receives no automatic `self` object. | `CAN.ChangeSignalValue(...)` can be called without creating `CAN()`. |
| `value: str` | Type hint: value is expected to be text. It documents intent and helps static tooling. | It does not convert runtime data by itself. |
| `str | None` | A type hint meaning text or no value. | Used for optional channel names. |
| `-> Any` | Return-type hint. `Any` means the exact type is not constrained. | Inspect the actual wrapper return contract before comparing it. |
| `*args`, `**kwargs` | Capture extra positional or named arguments. | Often used by compatibility wrappers; check the actual signature before calling. |
| `Path(__file__)` | The current source-file path as a path object. | Used to find the framework root or project folder without hard-coded locations. |
| `path / "child"` | `pathlib` path joining. | Safer and clearer than hand-building strings with `\\`. |
| `f"...{value}..."` | Format a string with a variable value. | Used in report titles and diagnostic error messages. |
| `dict["key"]` | Retrieve a named value from a dictionary. | Missing keys raise `KeyError`; inspect the configuration structure first. |
| `obj.attribute` | Retrieve a named attribute from an object/module. | `config.CAN_CHANNEL` reads a module-level config constant. |
| `getattr(obj, name)` | Read an attribute where the name is only known at runtime. | Used by the config loader to find a requested config symbol. |
| `try: ... except ...:` | Attempt an operation and handle an expected failure. | Good for boundary handling; dangerous when a broad `except` hides the root cause. Preserve/log the error. |
| `raise RuntimeError(...)` | Stop the current operation with an explanatory failure. | Used when active project detection is impossible. This is preferable to silently choosing a project. |
| `if __name__ == "__main__":` | Run code only when the file is executed as a program, not when imported. | The standard test-script entry point calls `run_test()`. |
| `__all__ = [...]` | List public names exported by `from module import *`. | Explains why some imported names are visible and others are not. |
| `global NAME` | Modify a module-level variable inside a function. | Used sparingly for active-project and runtime state; check lifecycle/caching effects. |

## 8. Test script anatomy: what belongs in a script

The intended clean pattern is:

```python
def run_test() -> None:
    """Execute one traceable test case."""

    # 1. Read test data and constants from the correct project config.
    # 2. Create report/logging.
    # 3. Establish documented preconditions with shared wrappers.
    # 4. Execute numbered test steps through shared wrappers.
    # 5. Record every observation with RESULT/report APIs.
    # 6. Restore the bench condition in cleanup.


if __name__ == "__main__":
    run_test()
```

| Part | Why it exists | Typical problem if absent |
|---|---|---|
| Config lookup | Makes values variant-aware and auditable. | Script works only on the author's project. |
| Report/log creation | Creates evidence and correlates observations to traffic. | A pass/fail result cannot be investigated later. |
| Fault-free precondition | Removes state left by an earlier script. | Intermittent or order-dependent failures. |
| Wrapper call | Centralises bench semantics. | Duplicate raw APYm logic and channel mistakes. |
| `RESULT` assertion | Converts an observation into recorded verdict evidence. | A comment says it passed but report does not prove it. |
| Cleanup | Restores frames, signals, faults, power and report groups. | The next test starts from an unknown state. |

### Important safety note

Some shared functions can operate power, loadboxes, fault injection, diagnostics, EOL/VC/VIN, crash stimulus or NVM. Their presence in a library does not authorise execution. Per `agent.md` section 23, writing or importing a script is not permission to operate the bench.

## 9. The generic design, shown by an example

Assume the test objective is identical for two projects: verify that an ECU reacts correctly when an input signal is changed.

```text
                    Same test intent
                           |
                           v
              +-------------------------+
              | shared test procedure   |
              | change -> wait -> read  |
              | -> record observation   |
              +-------------------------+
                    /               \\
                   v                 v
     +---------------------+  +---------------------+
     | M310_M314_M110 cfg  |  | U171 cfg            |
     | frame name          |  | frame name          |
     | signal name         |  | signal name         |
     | CAN FD channel      |  | classic CAN channel |
     | timing / DTC values |  | timing / DTC values |
     +---------------------+  +---------------------+
                   \\                 /
                    v               v
               same CAN wrapper and APYm adapter
```

The reusable part should not need to know the CAN identifier or whether the target is CAN FD versus classic CAN. The configuration and channel resolver decide that.

### Generic does **not** mean universal guesses

The framework must not “guess” a project value. If the config, DBC or wrapper does not contain the required item:

1. stop at the missing boundary;
2. identify the correct config/wrapper ownership;
3. propose the smallest reusable addition; and
4. verify it before use.

That protects against a script accidentally using an M314 message, DTC or duty cycle on a U171/W616 project.

## 10. Debugging playbook

Use this order. It finds the first failed layer and avoids unsafe trial-and-error.

```mermaid
flowchart TD
    A[Observe exact error, test step and report/log timestamp] --> B{Python syntax error?}
    B -- yes --> B1[Fix syntax/import spelling; run offline syntax check]
    B -- no --> C{Import or module-not-found error?}
    C -- yes --> C1[Check package root, sys.path, module filename and import style]
    C -- no --> D{Active project/config error?}
    D -- yes --> D1[Check script location, project inference, env override and config symbol]
    D -- no --> E{Wrapper returned error or wrong result?}
    E -- yes --> E1[Inspect wrapper signature, return contract, channel resolution and config]
    E -- no --> F{APYm/ARIA runtime unavailable?}
    F -- yes --> F1[Check ARIA/APYm setup and named channels; do not bypass wrapper]
    F -- no --> G{ECU behaviour differs?}
    G -- yes --> G1[Correlate report, CAN log, UDS trace, DBC/config and requirements]
```

### 10.1 Stage 1 — prove the Python file is valid

Safe checks do not touch the bench:

```powershell
# Parse/compile a script with the repository's configured Python interpreter.
& 'C:\Python 3.14.0\python.exe' -m py_compile '<script path>'
```

`py_compile` checks Python syntax. It does **not** prove imports, ARIA connectivity, APYm behaviour or ECU correctness. It may create `__pycache__`; do not commit those artifacts.

### 10.2 Stage 2 — import failures

Typical errors:

| Error | What it normally means | First safe check |
|---|---|---|
| `ModuleNotFoundError: apym` | APYm cannot be located by Python. | Inspect `apym_imports.py` and the APYm installation/path; do not add direct `sys.path` hacks to every script. |
| `ModuleNotFoundError: projects...` | Framework root/import context is wrong, or project package is missing. | Confirm the script lies under `projects/<project>/...` and the expected `__init__.py` files exist. |
| `ImportError` after `import_list` | A dependency inside one exported shared module failed. | Import/inspect the named module directly to find the first failure. |
| `NameError` for a helper | The symbol was not imported/exported, or its spelling changed. | `rg -n "def <name>|class <name>" shared_libraries`. |

### 10.3 Stage 3 — active-project and config failures

Symptoms:

```text
Active project could not be detected
ModuleNotFoundError for projects.<project>.config.<module>
AttributeError: config '<module>.py' has no symbol '<symbol>'
```

Debug in this exact order:

1. Confirm the script path has the expected `projects/<project>/` segment.
2. Confirm the project directory and `config/<module>.py` exist.
3. Search for the exact constant name, including case.
4. Check whether an interactive session has a stale configuration cache; reset only the config cache, then rerun the relevant offline check.
5. Do not copy a constant from another project's config just to make the import pass.

Useful searches:

```powershell
rg -n "CAN_SIGNAL_Rx_MAP" 'projects\<project>\config'
rg -n "get_project_config_symbol|set_active_project|reset_project_config_cache" shared_libraries
```

### 10.4 Stage 4 — wrapper failures

The wrappers in `jscript_translation.py` are not all identical. Some return strings, some return formatted diagnostic data, and legacy functions can return an exception object or a textual error instead of raising it.

Therefore, before writing an assertion or diagnosing a failure:

1. find the exact wrapper definition;
2. read its signature, argument compatibility handling and return statements;
3. check which internal APYm call it makes;
4. check whether it requires runtime initialisation; and
5. verify the channel name is resolved from configuration/ARIA, not assumed.

```powershell
rg -n "def ChangeSignalValue|def SendDiagByValues|def ReloadDefaultPeriodicFrame" shared_libraries\jscript_translation.py
```

Do not rely on a wrapper's name alone. For example, `ChangeSignalValue` expects raw signal values and derives a default PDU name; a project using a different PDU convention must use its documented configuration/argument form.

### 10.5 Stage 5 — APYm/ARIA runtime failures

`require_runtime()` triggers the wrapper runtime initialisation. It needs APYm and an ARIA runtime configuration with the expected simulation/diagnostic channels.

Check, in order:

1. Is APYm available to the intended interpreter?
2. Is ARIA running and configured for the correct project?
3. Does ARIA expose the expected named simulation channel (`CANFD`, `HSCAN`, or `ARIA`) and diagnostic channel?
4. Does the ARIA project use the correct DBC, diagnostic IDs, loadbox and project configuration?
5. Only after those checks, investigate ECU response/traffic.

Do not “fix” a channel problem by hard-coding the numeric simulation or diagnostic ID in a test script. The resolver exists specifically to avoid that project coupling.

### 10.6 Stage 6 — ECU behaviour / failed assertion

Use evidence, not just a failed assertion.

```text
Expected behaviour
  -> requirement / test objective
  -> project configuration value
  -> DBC encoding and message cycle
  -> test script's request/stimulus
  -> wrapper/API return
  -> CAN/UDS log and report observation
  -> ECU state and diagnostic status
```

Ask these questions:

- Was the correct project configuration loaded?
- Did the wrapper operate on the intended channel/frame/signal?
- Was the frame still enabled and its default state restored after an earlier test?
- Was the required ECU state, ignition cycle, session, security level and qualification time reached?
- Does the CAN/UDS log show the stimulus and the expected ECU response?
- Does the DBC decode match the raw value that was asserted?

## 11. A practical “find the owner” method

When you see a line you do not understand, trace it upward and downward.

Example:

```python
Read_DTC("Front Crash", expected_response, request)
```

| Question | How to find the answer |
|---|---|
| Where is `Read_DTC` defined? | `rg -n "def Read_DTC" shared_libraries` |
| What does it call? | Read the function body and note each wrapper/function call. |
| Where did its expected data originate? | Trace the variable assignment back to config/test data. |
| Which project is active? | Inspect caller path and `project_config_loader.py` logic. |
| Which CAN/UDS channel is used? | Inspect the invoked wrapper's channel resolver. |
| Which physical/ARIA asset governs it? | Follow the wrapper to APYm, then verify the ARIA project configuration. |

This turns debugging from “try a different value” into a repeatable dependency trace.

## 12. Current repository observations to know before debugging

The following are facts observed in this checkout. They are not changes made by this guide.

### 12.1 Canonical available project/config path

`framework_registry.py` and `project_config_loader.py` exist and form a complete project-aware loading path. Their documented/implemented model is:

```text
script location -> infer project -> import projects.<project>.config.<module>
```

Confidence: **Very High** (source inspected).

### 12.2 `FrameworkContext` scaffold is incomplete in this checkout

Some demonstration/test files import:

```python
from Framework_IOEM_Py.path_manager import FrameworkContext, bootstrap_framework_import
```

Examples include `projects/UPP_EV/modules/GPO/scripts/test_gpo_basic.py` and `projects/M310_M314_M110/modules/CANC/scripts/demo_framework_selective_imports.py`.

However, no `path_manager.py` or `FrameworkContext` definition was found in the repository during this guide's inspection. In this checkout, those files are therefore not a usable model for new scripts and will fail at import unless the missing module is supplied externally.

Confidence: **High** (source-path search and import references inspected). Recommended action: use the existing registry/config-loader approach for current work, or restore/complete the `path_manager` implementation as a deliberate, reviewed architecture change—not an ad-hoc script workaround.

### 12.3 Existing scripts are not automatically the current standard

Some existing scripts directly import APYm, use `print()`, or include broad exception handling. These are observed implementation patterns, while `agent.md` section 18 defines the standard for new/modified framework scripts: module config plus shared wrappers, report evidence, no direct `Api.*` calls, traceable timing and cleanup.

Confidence: **Very High** (source and repository rules inspected). When debugging legacy code, explain its current behaviour first; when authoring new code, follow the current standard instead of copying its weaknesses.

## 13. Safe debugging boundaries

The following are normally safe and useful:

- Read source/configuration/DBC/log files.
- Search for a function definition or constant.
- Run static/syntax checks with the configured interpreter.
- Review reports/logs already produced.
- Compare project configuration against source-controlled facts.

The following can affect the bench or ECU and require explicit execution authority:

- power, ignition, voltage, loadbox, squib, lamp, RSU or SPI actions;
- crash/curve triggering and fault injection;
- UDS writes, security access, EOL/variant/VIN/NVM writes or DTC clearing;
- flashing, programming or reset actions.

If the ownership or effect of a function is unclear, inspect its definition first. A name such as `POWER_CYCLE`, `TriggerCrash`, `SetGpoFaultCondition`, `manage_eol_code` or `Clear_DTC_Info` is a strong signal that it can change bench/ECU state.

## 14. Recommended learning path

Follow this order to become effective at framework debugging:

1. Read this guide and `agent.md` sections 18, 21, 22 and 23.
2. Read `framework_registry.py` and `project_config_loader.py` end to end. They are short and reveal project selection.
3. Read `apym_imports.py` to understand offline import versus real runtime availability.
4. Pick one wrapper from `jscript_translation.py`—for example `CAN.SendDiagByValues`—and trace it completely.
5. Pick one small, existing module script and trace every imported function to its source.
6. Open the matching project configuration and locate every constant used by the script.
7. Compare the report and CAN/UDS log generated by a previously authorised run with the script's steps.
8. Only then study domain libraries such as EDR, DCS, RSU or fault-monitor logic.

## 15. Before declaring a framework issue fixed

- [ ] The exact failing layer is known: Python, import, config, wrapper, APYm/ARIA, bus, ECU or expectation.
- [ ] The active project and config file were verified from the actual script path/loader.
- [ ] Every changed value comes from the correct project config or DBC, not a copied literal.
- [ ] Every used shared function's signature and return contract were read in source.
- [ ] The fix does not add direct APYm calls to a test script.
- [ ] The fix does not modify generated output by hand.
- [ ] The effect on other projects and generated scripts was considered.
- [ ] The result is supported by a report/log/trace or is explicitly marked “Evidence unavailable.”
- [ ] No bench-affecting command was run without explicit permission.

## 16. Quick reference: start here for common questions

| I need to know… | Start here |
|---|---|
| Which project is active? | `shared_libraries/framework_registry.py`, then `project_config_loader.py` |
| Why did a config value not update? | `project_config_loader.reset_project_config_cache()` and the target `projects/<project>/config/*.py` |
| Who owns a test constant? | The target project's module config or DBC |
| What does a `CAN`, `PS`, `RSU` or `RESULT` call do? | `shared_libraries/jscript_translation.py` |
| Which functions combine several test steps? | `shared_libraries/core_functions.py` and the relevant domain library |
| Why is APYm unavailable? | `shared_libraries/apym_imports.py`, then ARIA/APYm installation/configuration |
| Why does a script work on one project but not another? | Compare project configs, ARIA channel names, DBCs and project-specific test data—not the generic wrapper first |
| How are ARIA assets/configs organised? | `aria_agent.md` and `aria_projects/` |
| What may I run safely? | `agent.md` section 23 |

---

### Evidence basis

This guide is grounded in the currently present `shared_libraries/framework_registry.py`, `project_config_loader.py`, `apym_imports.py`, `jscript_translation.py`, `core_functions.py`, `import_list.py`, representative project configuration and script files, plus `agent.md` and `aria_agent.md`. It intentionally avoids asserting project-specific diagnostic, timing, CAN or safety values; those must be verified from the target project's sources for each task.
