# Rules shared by the task pipelines

Read by `test-execution-pipeline`, `requirement-review-pipeline`, `test-case-writer-pipeline`,
`test-case-review-pipeline` and `report-review-pipeline` before their own stages. `agent_sc3.md` §0 (evidence, fact / inference /
assumption, confidence) governs all of them.

## 1. Start, state, finish

1. `py -3.14 tools/test_task.py setup --pipeline <test|req-review|tc-writer|tc-review|report-review>` —
   pip-installs what that pipeline's skills need (the user asked for automatic installs) and checks
   the Codebeamer `.env` and, for bench runs, apym. Report what pip cannot fix.
2. `py -3.14 tools/test_task.py init --pipeline <kind> --project <P> --task "<title>" …` creates
   the task folder `test_campaigns/<P>/<YYYYMMDD>_<task>/` (git-ignored) with `manifest.json`,
   `issues.md`, `inputs/`, `analysis/`, `testcases/`, `review/` … and **starts the keep-awake
   hold** (§2). All state of the task lives there; to resume, read `manifest.json` and continue at
   the first unfinished stage.
3. Problems and gaps go to `issues.md` with `test_task.py note <task> --text "…" [--gap]`.
4. Post a one-line status after each stage. Ask for every missing input **once**, together.
5. At the end (hand-over done, or the user says stop): `py -3.14 tools/test_task.py finish <task>`
   — releases the hold and stamps the manifest.

Use `py -3.14` for every tool (`agent_sc3.md` §21.1); the bare `python` on this PC lacks the
packages.

## 2. Working while the screen is locked (keep-awake)

`init` runs `tools/keep_awake.py start --task <task folder name> --hours 12` (`--keep-awake-hours`
changes it, `0` disables it). One hidden holder serves all running tasks:

- Windows is asked to stay out of idle sleep (`SetThreadExecutionState`), so the PC, VS Code,
  Copilot and the network keep working while the screen is locked. The display may turn off.
- Every 30 s it checks the internet; after two failed checks it reconnects the Wi-Fi network that
  was in use at start, and logs it (`%LOCALAPPDATA%\test_pipelines\keep_awake.log`).
- It ends when the last task calls `finish` or its hours run out (within one 30 s check; measured
  26 s on 2026-10-26) — a forgotten hold cannot keep the PC up for ever. While the pipeline waits at a gate for the user, the hold stays.
- It cannot override: closing the lid (on this PC the lid action is **sleep**), the power button,
  a battery shutdown, a Windows Update restart, or closing VS Code. `py -3.14 tools/keep_awake.py
  status` shows the hold and warns about the lid and battery; tell the user those warnings at the
  start of a long task.

## 3. Evidence, severity, confidence

- Every finding names its evidence: Codebeamer item ID + field, document + page/section, file +
  row/line, report step, log line. No evidence → "Evidence unavailable." and confidence Low.
- **Severity**: High = wrong behaviour, wrong value, untestable or untraced safety/diagnostic
  content; Medium = incomplete or ambiguous so two readers would implement or test it
  differently; Low = wording, format, cosmetic.
- **Confidence**: High = sources agree and the evidence chain is complete (or reproduced);
  Medium = one clear source; Low = inferred from partial evidence — the user checks before acting.
- Label statements Fact / Inference / Assumption where it matters.
- Never invent an ID, value, signal, DTC, DID or path; verify it in its source or ask.

## 4. Where results go and what leaves the PC

- Review comments, corrections and new test cases are delivered as Excel (+ a Markdown summary)
  in the task folder for the user to review in VS Code. Originals are never edited: work on copies.
- Rendered review workbooks: `test_task.py findings <task> --kind requirement-review|trace|tc-review|report-review`
  from `analysis/findings_<kind>.json`; it refuses categories, severities or confidences outside
  the lists in `tools/test_task.py FINDING_KINDS`.
- **Codebeamer is read-only** except an approved plan: code-beamer skill `plan-mutation`, show the
  plan ID, `apply-mutation --approve <id> --apply` only after the user approves that ID. The skill
  cannot write comments, relations or run the importer — say so and hand those to the user.
- **PTC** only with the user's zip name, destination and PTC target (`test-execution-pipeline` S15).
- `req/` and other customer requirement exports are read-only. `shared_libraries\` and
  `projects\<p>\config\` are protected (`.github/copilot-instructions.md`); only
  `test-execution-pipeline` may correct test scripts, through its S11.

## 5. Delegation

Give a specialist the texts and file paths it needs, not your conclusion. Before the hand-over,
run `verification-agent` on the main chain of the pipeline and `intent-fidelity-agent` with the
user's verbatim request. If a specialist agent is not available in the environment, do that check
yourself, and record "independent review not done (agent unavailable)" with `test_task.py note`
and in the hand-over — never imply it was done.
