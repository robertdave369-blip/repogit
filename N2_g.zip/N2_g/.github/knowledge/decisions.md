---
scope: Append-only record of harness design decisions, with rationale and what each supersedes
sources: .github/ tree; VS Code 1.135.0 build 08d4889f9e; GitHub.copilot-chat 0.63.0
last_verified: 2026-08-29
fingerprint: workbench.desktop.main.js @ build 08d4889f9e; copilot ext package.json v0.63.0
---

# Decisions

Append only. Never rewrite an entry — supersede it with a new one and say so.

---

## D-2026-08-29-01 — Custom-agent budget raised from 3 to 12

**Decision.** The §9 budget of 3 custom agents is raised to **12**. The roster was
simultaneously consolidated from 15 to 12, so the increase buys specialist coverage
rather than sprawl.

**Rationale.** A multi-agent swarm and a 3-agent cap are incompatible; the cap was
written before the swarm requirement existed. The intent behind §9 — a bloated harness
is a failed harness — is preserved by requiring every agent to map to either a domain
with demonstrated repository evidence or a role §6.1 explicitly mandates. Three agents
were merged out on genuine overlap rather than the budget being quietly redefined.

**Merged away** (archived, not deleted, to `.github/knowledge/archive/agents/`):

| Agent | Folded into | Overlap |
|---|---|---|
| `software-design-agent` | `architecture-agent` | Both reviewed structure and design quality |
| `static-analysis-agent` | `architecture-agent` | Read-only code review once `execute` was withdrawn |
| `documentation-agent` | `swarm-orchestrator` | Report assembly is the conductor's step 8 |

**Final roster (12).** `swarm-orchestrator` · `requirements-agent` · `research-agent` ·
`architecture-agent` · `communication-agent` · `diagnostics-agent` · `autosar-agent` ·
`safety-agent` · `cybersecurity-agent` · `test-engineering-agent` · `verification-agent` ·
`intent-fidelity-agent`

**Supersedes.** §9's "Custom agents ≤ 3".

---

## D-2026-08-29-02 — Tool access is assigned by role, not inherited

**Decision.** Every agent declares `tools:` explicitly. Three roles:

| Role | Tools | Agents |
|---|---|---|
| verifier | `[read, search]` | `verification-agent`, `test-engineering-agent`, `intent-fidelity-agent` |
| analyst | `[read, search, edit]` | the 7 domain specialists |
| conductor | `[read, search, agent, todo]` | `swarm-orchestrator` |

**Rationale.** Before this, every agent inherited the full toolset. `verification-agent`
— described in its own file as "the mandatory final gate" — held `editFiles` and
`runCommand`. A verifier that can edit does not verify; it quietly fixes, and the fact
that the work was wrong never reaches the user. Withdrawing `edit` makes the integrity
property structural instead of a request the model may ignore under pressure.

**No agent holds `execute`.** `runCommand` is how a bench script is launched, and the
governing rule is that hardware is never actuated uninvited. Writing a script is not
running it. Consequence, accepted deliberately: `architecture-agent` cannot run a linter
and `test-engineering-agent` cannot run a test. Both report what should be run; the human
or the main agent runs it. Neither may claim a result it did not observe.

**Enforced by.** `.github/scripts/validate_agents.py` fails if an agent whose name or
description implies verification holds any mutating tool.

---

## D-2026-08-29-03 — Reconciliation is checked mechanically, not trusted

**Decision.** Specialists emit evidence-handoff objects carrying `sources[]`.
`.github/scripts/check_source_diversity.py` inspects the pool and fails on false
consensus. It reuses the schema already present at
`.github/skills/skill-portfolio-orchestration/references/evidence-handoff.schema.json`
rather than defining a second format.

**Rationale.** The failure mode is specific: several specialists agree, the orchestrator
reads that as corroboration, but all of them derived the claim from the same file. That
is one data point wearing several hats, and it is indistinguishable from real agreement
unless sources are compared. Instructing the orchestrator to watch for it is weaker than
computing it.

**Detects:** a specialist citing nothing; every specialist citing one identical source;
an identical source set across all specialists; a single source cited by everyone;
unanimous high confidence drawn from a thin pool. Contradictions are surfaced, never
averaged. An empty or unreadable input directory **fails** — a check that passes on no
input reads as a green light.

---

## D-2026-08-29-04 — Nested subagents stay disabled

**Decision.** `chat.subagents.allowInvocationsFromSubagents` stays at its default
`false`. Fan-out is one level, under a single conductor.

**Rationale.** Depth comes from the orchestrator's iterate step (dispatch → verify →
re-dispatch), which is auditable, rather than from nesting, which is not. Nesting is
flagged experimental in VS Code; each subagent bills separately, so recursive fan-out
multiplies cost without a ceiling — no `maxSubagent` or concurrency limit exists in the
product to catch a runaway. Decisively, a subagent's subagent's sources never reach the
orchestrator, so D-2026-08-29-03 could not be applied to them: enabling nesting would
disable the false-consensus check exactly where it matters most.

**Revisit when.** VS Code drops the experimental tag and exposes a concurrency cap, or a
task genuinely needs more than one level of decomposition.

---

## D-2026-08-29-05 — Agent knowledge-base path corrected

**Decision.** All agent files now reference `.github/agents/agent_sc3.md`. Section
citations read `agent_sc3.md section N`.

**Rationale.** Nine of twelve agents named `agent.md` "at the repo root" as their
knowledge base. **That file does not exist at the repo root** (verified 2026-08-29); the
knowledge base is `.github/agents/agent_sc3.md` (242,969 bytes), as
`copilot-instructions.md` already stated. Every specialist would have failed to find its
ground truth and then either fabricated or reported evidence-unavailable across the
board.

---

## D-2026-08-29-06 — Dead files archived, never deleted

**Decision.** 14 `.agent.md` files in `.github/prompts/` moved to
`.github/knowledge/archive/dead-prompt-agents/`.

**Rationale.** VS Code loads agents only from `chat.agentFilesLocations`
(`.github/agents`), so an `.agent.md` under `.github/prompts/` never loaded. All 13 with
a counterpart had already drifted from it — zero were identical — which is the §9
duplicate-drift defect, realised. They are archived rather than deleted because
`.github/` is entirely untracked in git: there is no safety net, and deletion would be
permanent.

---

## D-2026-08-29-07 — Skills consolidated 19 → 12

**Decision.** The skill portfolio is cut from 19 to 12 directories (11 registered plus
`skill-portfolio-orchestration`, which the registry does not list). This meets §9's
ceiling of 12 exactly.

**Archived** (moved to `.github/knowledge/archive/skills/`, not deleted):

| Skill | Reason |
|---|---|
| `canoe-automation` | No CANoe in this repository. The only hits are a document *about the skill portfolio* and generic ISO boilerplate — circular evidence. |
| `capl-programming` | Same. No `.capl` files, no CAPL in any source. |
| `can-protocol-automotive-networks` | Its description claimed CAN **and** CANoe **and** CAPL **and** UDS, overlapping three other skills and making routing ambiguous. Its genuinely repo-specific content (CRC, counters, NM timing) belongs in `knowledge/domain/canc.md` with citations, per §5.2 — not in a skill. |
| `windchill-ptc-project-automation` | PTC Windchill administration, not ECU test authoring. 182 KB of context cost for an unrelated routing target. |
| `embedded-systems-fundamentals` | Merged into `failure-mode-analysis`. |
| `functional-safety-iso26262` | Merged into `failure-mode-analysis`. |
| `requirement-based-testing` | Failure-analysis half merged into `failure-mode-analysis`; authoring half already routed to `veoneer-test-spec-generator` by `copilot-instructions.md`. |
| `agent-skills-multi-source-architecture` | Meta-skill about designing skill frameworks. That design work is done. |

**Added.** `failure-mode-analysis` — the §6.1 mandated skill, merging the three above.

**Corrected from the Phase 1 proposal.** Phase 1 proposed moving out
`clean-exported-web-text-images-and-symbols`. That was wrong:
`tests/test_excel_cleanup_preview.py` imports its script directly. It is load-bearing
and stays. Dependency check before archiving is now mandatory —
`veoneer-test-spec-generator` is referenced by 11 files, `dbc-to-json` by 3.

**§6.1 roles absorbed rather than added as new skills**, to hold the budget:
`test-spec-authoring` → `veoneer-test-spec-generator`; `api-discovery` →
`python-test-automation`; `hardware-safety` → `aria-bench-configuration`;
`large-file-analysis` → `pdf-document-intelligence`. Each absorbing skill's registry
`role` was updated to say so.

**`aria-bench-configuration` split.** 236 → 152 lines; the five-step workflow moved to
`references/configuration-workflow.md`, per §9's "push detail into bundled resources".
All 12 SKILL.md files are now within the 200-line cap.

---

## D-2026-08-29-08 — Skill registry drift fixed, and made regenerable

**Decision.** `skill-registry.json` rebuilt to match disk exactly. The catalogue
instructions file is now generated by `.github/scripts/build_skill_catalogue.py` from
SKILL.md frontmatter rather than hand-maintained. `routing.json` was repointed away from
the archived skills.

**Rationale — this was a pre-existing failure, not one the consolidation caused.**
Baseline before any change: `validate_portfolio.py --registry` reported
`Registry coverage mismatch: actual=[18 skills], registered=[14]`, and
`tests/test_skill_portfolio_orchestration.py` was **already failing**. Four skills
(`aria-crash-simulation-xml`, `can-channel-agnostic-wrappers`,
`veoneer-test-spec-generator`, `windchill-ptc-project-automation`) had never been
registered.

Hand-maintained indexes of a directory drift. Generating the catalogue removes the class
of defect rather than the instance.

**Test constant updated.** `test_skill_portfolio_orchestration.py` asserted
`skill_count == 12`, a stale value matching neither the 14 registry entries nor the 18
directories then on disk. Now 11, with the relationship to the §9 ceiling documented in
the test itself.

**Five surviving skills had dangling handoff targets** naming archived skills; all
remapped. Verified: no dangling skill reference remains in `.github/` outside the
archive, and nothing in `tests/` or `tools/` depends on an archived skill.

---

## D-2026-08-29-09 — Two patterns taken from Mira; Mira itself rejected

**Decision.** `github.com/miracodeai/mira` is **not** integrated. Two of its design
patterns are, reimplemented from scratch: the **noise filter** (`review_gate.py`) and
**learning from rejections** (`log_rejection.py`). No Mira code, container, service, or
dependency is used.

**Why Mira itself was rejected.** Fetched and read 2026-08-29. It is a self-hosted
**code-review service**: Docker container, webhook-driven PR review via GitHub App or
GitLab, SQLite/Postgres, a dashboard, OpenRouter for model access, config split across
`mira.yaml` and per-repo `.mira.yaml`. Two blockers:

1. §1 forbids "a hosted service, a separate agent runtime... or a vendored copy of any
   third-party framework". Mira is a hosted service in a container.
2. It reviews pull requests. This repository has no CI, no `.github/workflows`, and
   `.github/` is untracked in git. There is nothing for it to hook.

**Pattern 1 — noise filter → `review_gate.py`.** Mira gates output through confidence
thresholds, deduplication, and a self-critique pass. This matters *more* here than for
Mira because Terra is the weaker model: it produces more marginal findings, and volume
reads as thoroughness. Twenty findings of which four matter is worse than four, because
the reader cannot tell which four, and after the first wrong one they stop trusting all
twenty.

Implemented as five ordered checks: source diversity (delegated to
`check_source_diversity.py`), evidence integrity, self-critique, deduplication, confidence
clamp. **Nothing is silently dropped** — held findings are listed separately so a real
finding with weak evidence can still be chased. **A claim with no cited source never
surfaces regardless of its stated confidence**: high confidence on zero evidence is the
invention case, not a strong finding.

**Design bug caught by testing, and fixed.** The first config keyed self-critique off
`evidence_gaps` while also requiring `max_unresolved_gaps_for_completed: 0` — mutually
unsatisfiable, so no handoff could ever pass. Self-critique is now evidenced in
`validation`; empty `evidence_gaps` is the correct end state for finished work.

**Pattern 2 — learning from rejections → `log_rejection.py`.** Mira synthesises rules
from merged PRs *and rejected comments*. §7.7 already required folding corrections back;
Mira supplied the shape — a rejection is training data. Writes to
`.github/knowledge/rejections.md` with a self-regenerating rules index, so index and
entries cannot drift. Requires all three of proposed / why-wrong / rule: a half-recorded
rejection looks handled but teaches nothing. Seeded with four real corrections from this
session.

**Patterns deliberately not taken.** Model-agnostic provider abstraction (locked to
Terra); merge-conflict detection (no PRs); CVE scanning (no dependency manifest exists —
no `pyproject.toml`, no `requirements.txt`); the dashboard; cross-file indexing (graphify
already does this).

**Still open.** Mira's two-tier config (`mira.yaml` + per-repo `.mira.yaml`) maps to a
genuine gap: one `.github/` serves U171, M314, ICE_01 and EV_01, yet the governing rule is
never to carry project values between projects. A per-project harness override layer is
**not** implemented and is filed as an open question.

**Tier 2 references not fetched.** `spec-kit`, `superpowers`, `awesome-copilot`,
`anthropics/skills`, `deepagents` were **not** read — the fetches were declined. Per
Appendix A they are `UNKNOWN`, and nothing in this harness claims to derive from them.
Appendix A itself states their patterns are already stated as requirements in §5–§7, so
none was needed.

---

## D-2026-08-29-10 — copilot-instructions.md rewritten as a router

**Decision.** 212 → **131 lines**, within the §9 budget of 150. The 212-line version is
preserved at `.github/knowledge/archive/superseded/`.

**Rationale.** It had grown to restate `agent_sc3.md` in prose — which §9 itself calls a
defect: "duplicated guidance across two files is a defect; the second copy will drift and
then contradict." It is also the always-loaded file, so it is the most expensive place in
the harness to be verbose.

Rewritten as a router: non-negotiables, the constants that get misremembered inline
(DTC status bytes, ENS PWM duty), a task→section lookup table, guardrails, and the new
corrections and multi-agent sections. Every section pointer from the old version was
verified present after the rewrite; the detail now lives only in `agent_sc3.md` and the
path-scoped `instructions/*.instructions.md`, each with one owner.

---

## D-2026-08-29-11 — Test runs write bytecode into a protected path

**Finding.** Running `tests/test_crash_configuration.py` caused
`shared_libraries/__pycache__/crash_configuration.cpython-314.pyc` to change. The test
imports `shared_libraries/crash_configuration.py`, and CPython writes bytecode beside the
source. That is **inside a protected path**, so the verification run itself produced the
drift it was checking for.

**Resolution.** The file was restored with `git checkout` and protected paths re-verified
byte-identical to the pre-crash baseline. The standing rule is now recorded in
`rejections.md`: run tests that import from `shared_libraries/` or `projects/` with
`PYTHONDONTWRITEBYTECODE=1`, or re-check and restore afterwards. **Verified, not assumed**
— the suite was re-run with that variable set and produced zero drift.

**Why it matters beyond this session.** §1 asks for proof that protected paths are
untouched. Any future test run that imports the shared library will silently break that
proof unless bytecode writing is suppressed. §6.3's "targeted test run for the changed
area" guardrail must carry this flag.

---

## D-2026-08-29-12 — Copilot CLI installed; harness verified portable to the terminal

**Decision.** `@github/copilot` installed globally via npm (v**1.0.81**; the VS Code
bootstrapper requires ≥ 0.0.394). This is the second of the user's two surfaces.

**The harness needed no port, and this was verified rather than inferred.**
`copilot plugins list`, run from the repository root, reports:

- **12 repository skills**, all enabled — the exact consolidated set, `failure-mode-analysis`
  included
- **`.github/copilot-instructions.md`** loaded as repository instructions
- **all 7 `.github/instructions/*.instructions.md`** loaded
- the personal `~/.copilot/skills/graphify` skill

`copilot --help` confirms `--add-dir` "load its `.github/skills` and `.github/agents` as
trusted configuration", `--agent <agent>` for custom agents, `--model <model>`, and
`--no-custom-instructions` (so instructions load by default). One `.github/` therefore
serves both VS Code and the terminal.

**Not verified — stated as UNKNOWN rather than assumed.** Whether the CLI honours
`.github/hooks/` is unconfirmed; hooks are a VS Code **core** feature and the CLI exposes
no hook option. Treat the guardrails as manual script runs in the terminal. All four are
runnable by hand for exactly this reason. Whether the CLI exposes the **Terra** model
specifically was not confirmed — `--model` exists but the model list is served at runtime.

---

## D-2026-08-29-13 — Universal document extractor; PDF engine reused, not rewritten

**Decision.** `document_context.py` added under the `document-context` skill (renamed from
`pdf-document-intelligence`). One entry point, five escalating levels, cached, with
provenance on every node.

**§38 inspection first — and it changed the design.** `pdf_document_intelligence.py` is
1,590 lines of working, tested PDF extraction that already implements the requested
architecture: `_optional_module` lazy dependencies, an `ExtractionQuality` report,
SHA-256 fingerprinting, JSON + Markdown output. **Rewriting it would have been waste and
regression risk.** It is kept unchanged inside the skill and delegated to for deep PDF
work; `document_context.py` handles everything else and offers PDF metadata/outline.

Also inspected and correctly **not** reused: `shared_libraries/excel_handler.py` is COM
automation for the bench, not extraction (and sits in a protected path);
`workbook_codec.py` is Veoneer-template-specific, not a general reader.

**Skill renamed rather than added.** The portfolio was at the §9 ceiling of 12. A second
document-extraction skill would have created exactly the routing ambiguity that got
`can-protocol-automotive-networks` archived. Renaming keeps the count at 12 and leaves one
front door. Nine references updated (test, routing, registry ×3, uv manager, uv SKILL.md).

**Format coverage, verified against this machine rather than assumed.** Working with no
install: PDF, Excel, Word, CSV/TSV, JSON, XML/ARXML, DBC, Markdown, text/log, HTML, web
URLs, image metadata. Needs one install: PowerPoint (`python-pptx`).

**OCR is declared unavailable, not faked.** `pytesseract` additionally requires the native
tesseract binary, which is absent, and §1 says not to require native utilities. Images
yield dimensions, format and EXIF — never invented text. A test asserts the unsupported
entry is present.

**Measured saving** on a 502 KB EDR workbook (7,146 rows on one sheet):
inspect 886 B (**567× smaller**, ~221 tokens) · outline 2.0 KB (242×) · search 3.9 KB
(129×) · extract-one-sheet 10 KB (49×).

**Dependencies are never installed silently.** `deps` reports; `--install` is explicit and
prints the exact command before running it.

**Two bugs found by testing, both fixed.** Merged ranges were invisible because
`read_only` mode hides them — a merge is structure under §5, so read-only is now used only
above 25 MB. And `openpyxl.range_boundaries` can return `None`, which would have crashed
on an unbounded range; now guarded and reported as partial.

**Latent bug found and fixed in `review_gate.py`.** Its `_load_sibling` did not register
the module in `sys.modules` before `exec_module`. On Python 3.14 `@dataclass` resolves
`cls.__module__` through `sys.modules` and raises `AttributeError` on `None`. Harmless
today because `check_source_diversity.py` has no dataclass — it would have broken the
moment one was added.

**Tests.** `tests/test_document_context.py`, 22 tests, all passing: signature-beats-
extension detection, authority classification, merged-range preservation, covered-cell
marking, formula-plus-cached-value, search provenance and context, cache hit / content
invalidation / parser-version invalidation, unsupported-format explanation, invalid-JSON
line reporting, OCR-absence declaration, dependency policy.

**Routing.** A `document-analysis` rule was added **first** in `routing.json`, because the
point is to route before the model opens the file. The skill states the rule plainly: if
you are about to write a script to parse a supported format, run this instead.

**Not implemented, deliberately.** §18's domain relationship extraction (requirement → test
case → signal → CAN message) is domain inference, and §32 says the extractor stays generic
with interpretation in skills. Structural relationships (merges, sheet lists, links,
JSON paths, XML lines) are preserved; domain semantics are left to the consuming skills.

## D-2026-08-30-14 — Docling adopted; MinerU and Unstructured rejected

**Decision.** `docling-slim` with narrow `format-*` extras is the one upstream document
dependency. MinerU is rejected outright. Unstructured is rejected as a dependency, with two
of its algorithms reimplemented and credited.

**Why.** All three were cloned and read (`research/document-parsers/`).
MinerU cannot install on Python 3.14 — `requires-python >=3.10,<3.14`, confirmed by
`pip install --dry-run` returning *No matching distribution found* — and its licence is
Apache-2.0 **plus additional terms** requiring a separate commercial licence above USD 20 M
monthly revenue, with automatic termination on breach. Unstructured needs libmagic, poppler,
tesseract and LibreOffice, which §1 forbids where a Python equivalent exists; its Excel path
is `pd.read_excel`, weaker than what this repo already had. Docling is MIT, targets 3.14
explicitly, and `docling-slim[format-*]` installs with **no torch, no transformers, no model
downloads** (measured by dry-run) — the heavy stack is opt-in, not the price of entry.

**Cost accepted.** No math-formula recognition (MinerU's `mfr` was the only real option). It
is reported as unsupported, never guessed.

## D-2026-08-30-15 — Excel is never delegated upstream

**Decision.** `.xlsx` always takes the local openpyxl path, whatever else is installed.

**Why.** Docling opens workbooks `data_only=True` in both branches
(`msexcel_backend.py:334-340`); grepping `formula` across that 1,901-line file returns 11
hits, all inside chart data-source handling. Cell formulas are discarded entirely, so
`=SUM(B3:B10)` becomes `125000` and nothing else. Preserving both forms is a stated
requirement. Docling's merged-cell *design* (anchor vs shadow with explicit spans) is
adopted; none of its code is.

## D-2026-08-30-16 — One skill, seven bundled references, not eight new skills

**Decision.** The request named a top-level `universal-document-understanding` skill plus
seven sub-skills. The portfolio was at the §9 ceiling of 12. Rather than go to 20, the
existing `document-context` skill was **renamed** to `universal-document-understanding` and
absorbed, and the seven sub-topics became bundled `references/`.

**Why.** §9 caps skills at 12 and calls a bloated harness a failed harness; the request
itself says "do not overengineer", "create only the directories that make sense", and "if
the repository already has a `.github/skills` convention, follow it". Eight skills all
claiming document extraction is exactly the ambiguous routing that got
`can-protocol-automotive-networks` archived (D-07). Still 12 skills, one front door. This is
the same move as `pdf-document-intelligence` → `document-context` in D-13.

**Cost accepted.** The seven topics are not separately model-invocable. They are linked from
SKILL.md and loaded on demand, which is what §9 prescribes for detail.

## D-2026-08-30-17 — Document text is fenced and flagged, never rewritten

**Decision.** Instruction-shaped passages are detected, marked `injection_risk`, counted in
the safety block and fenced in Markdown — but the text is preserved **verbatim**. The only
transformation applied is neutralising forged copies of our own fence tokens.

**Why.** Sanitising would corrupt legitimate content: an OEM requirement saying "the ECU
shall ignore the message when the counter is stale" must survive intact. The scanner is
tested in both directions — it catches the four main injection shapes and does **not** fire
on ordinary engineering prose, because a flag that fires on every requirement document is
worthless.

## D-2026-10-25-18 — Ponytail agent governs code writing

**Decision.** `agents/ponytail.agent.md` is the upstream ponytail Copilot ruleset
(github.com/DietrichGebert/ponytail `.github/copilot-instructions.md`, v5.3.2, MIT) copied
verbatim, plus an "In this repository" section. `copilot-instructions.md` and
`instructions/60-ponytail-code.instructions.md` (applyTo `**/*.{py,ts,js}`) send every
code-writing request to it. Registered as `analyst` (read, search, edit; no execute).

**Why.** The user asked for code that is simple and easy to understand on every new-code
request. The upstream text is kept verbatim so it can be refreshed by re-copying; the
repository section resolves the three places it meets local rules: protected paths (its
"fix it in the shared code"), config-driven values, and no execution.

**Cost accepted.** No `/ponytail lite|ultra` levels or hooks in Copilot; it is
instruction-tier. No routing.json rule: code-writing phrases are too broad and would crowd
out the specific routes.

---

## D-2026-10-26-19 — Operator role: agents that may run commands

**Decision.** `agent_roles.json` gains a fourth role, `operator` (read, search, edit, execute,
todo, agent). `validate_agents.py` still rejects `execute` for every other role. Two agents hold
it: `aria-bench` (operates the ARIA tool: status, project switch, start/stop, apym, logs, RSU
inputs) and `test-execution-pipeline` (runs a test task end to end).

**Why.** The user asked for an agent that operates ARIA "as a real human does" and for a
hands-free test pipeline; both need to run tools and bench scripts. The original rule ("no agent
holds execute") protected against uninvited actuation. That protection now lives in the agents'
own text: action tiers (read-only / files and settings / hardware), plan-before-apply on every
state-changing tool (`--apply`), and explicit gates (bench "go", irreversible operations,
Codebeamer write-back, PTC push).

**Cost accepted.** The guard is instruction-tier plus tool flags, not a harness block; the
validator only checks the declared role.

## D-2026-10-26-20 — Test-execution pipeline and its correction policy

**Decision.** `agents/test-execution-pipeline.agent.md` + `prompts/run-test-task.prompt.md` +
`tools/test_task.py` (campaign folder per task under the git-ignored `test_campaigns/`). User
choices: OEM level-10 source asked per task; ECU source from a local folder per project
(read-only); the pipeline may correct **test scripts only**, after a git commit of the current
file and a `.bak-<time>` backup, keeping the file name; test cases are corrected in an Excel copy
and written back to Codebeamer only through an approved code-beamer plan; logs go to PTC only with
the user's zip name, destination and PTC target, through the Windchill skill's DryRun → Preflight
→ approved Apply. The user also approved one `shared_libraries` change: the apym API-level
fallback (`docs/improvements/apym-level-fallback.md`), because apym 2.6.7 handshakes at level 3
and ARIA 5.20 serves 1–2.

**Why.** One prompt per task, reasoning at every analysis step, and reversible corrections.

**Verified.** `tests/test_test_task.py` (whole flow in a throwaway repo: map, risk, plan-only and
applied run, collect with test-case names, triage hints, bug list validation, backup + commit,
zip refusal and creation, PTC refusal, Excel review loop) and `tests/test_aria_bench_tools.py`.

## D-2026-10-26-21 — Agent proposals scrutinised: two built, three rejected

**Decision.** From an external recommendation for five new agents (integration/root cause,
requirements compliance, test automation & HIL, embedded C code quality, memory/NVM) and a shared
`docs/` knowledge tree, two agents were built, three rejected, and the shared rule went into
`instructions/00-core-engineering.instructions.md` §7 instead of every agent file.

| Proposal | Outcome | Evidence |
|---|---|---|
| ECU integration & root-cause analysis | **Built** `agents/ecu-integration-debugger.agent.md` (analyst) + `docs/engineering/known-failure-signatures.md` (KFS-01..30) | No per-failure cross-layer analyst existed; the pipeline triages a whole campaign. Recurring causes were scattered over `review/Framework_Review_Points.md`, `agent_sc3.md` §13, `rejections.md`, aria-bench §21. Uses the pipeline's six categories so verdicts interoperate |
| Requirements & standards compliance | **Built** `agents/automotive-requirements-compliance.agent.md` (analyst) + `docs/compliance/` + `tools/trace_coverage.py` | Codebeamer exports carry `Verifies`; measured M310 coverage 288 of 617 Approved requirements, NM 0 of 60, EDR links by name. No standards register or cross-domain deviation index existed. `requirements-agent` (swarm reviewer) and `verification-agent` (gate) unchanged |
| Test automation & HIL | Rejected | Already `test-execution-pipeline` + `aria-bench` + `tools/test_task.py` (D-19, D-20) |
| Embedded C/C++ code quality | Rejected | No C/C++/ARXML in the repository; ECU source is external and read-only (pipeline source review) |
| Memory & NVM | Rejected | No NVM implementation here; black-box NVM behaviour (VIN, EOL, variant code, crash/EDR lock) is in `agent_sc3.md` and the EDR/UDS agents. Revisit if NVM failures recur (KFS-12) |
| `docs/architecture`, `docs/testing`, `docs/engineering/coding-conventions…` tree | Rejected except `docs/compliance/` and the failure register | Duplicates `agent_sc3.md`, `FRAMEWORK_CORE_AND_DEBUGGING_GUIDE.md`, `AGENTS.md` and this knowledge folder |

The recommendation's "seven existing agents" (VIN, power management, bootloader, end-of-life,
AUTOSAR reference, test strategy, OSI network) do not exist in this repository or the engineering kit;
none was created. "Scrap" here is the ISO end-of-life pyrotechnic deployment sequence (DIAG_RE sheet
`ISO_SCRAP_Flow_Chart`), not vehicle record handling.

**Verified.** `validate_agents.py`; `tests/test_trace_coverage.py` (3 tests); routing simulated.

## D-2026-10-26-22 — Tools/hardware agent built from the bench's real interface

**Decision.** `agents/automotive-tools-hardware-engineer.agent.md` (analyst) + `docs/automotive-tools/`
(10 files: inventory, Vector, PEAK, other vendors, licensing, connectors/pinouts/wiring, drivers/APIs,
compatibility matrix, tool selection, troubleshooting). The requested `wiring-and-electrical-safety.md`
and `test-bench-setups.md` were folded into the pinout and inventory files (no duplicates; the chassis
stays with `aria-bench`).

**Evidence base.** Bench interface = Vector VN1610 s/n 48714 (`AriaMain.accf`), HS-CAN on a disabled
virtual channel; ARIA 5.20 ships XL Driver Library 20.30.14.0 and PCAN-Basic 4.3.2.161. VN1610 pinout,
CANcable 2Y map and isolation from Vector's VN1600 manual v6.0 p.15–17, PCAN-USB FD pinout from PEAK's
manual 2.3.0 p.14 — both checked on the page image. Licence facts only in the vendors' wording.

**Corrected reading.** `agent_sc3.md` §29.4 ("CAN interface is a Vector CANcaseXL"; "S32K388 flashed with
J-Link") comes from ARIA's documentation examples, not this bench — recorded as a conflict in the
inventory, `agent_sc3.md` not edited.

**Not covered.** Kvaser, Intrepid, ETAS, NI, Lauterbach: no reference in the framework, not researched.

## D-2026-10-26-23 — Three review pipelines and keep-awake for all pipelines

**Decision.** Added `requirement-review-pipeline`, `test-case-writer-pipeline` and
`report-review-pipeline` (role `operator`, prompts `/review-requirements`, `/write-test-cases`,
`/review-test-results`), sharing `agents/pipelines-common.md` with `test-execution-pipeline`.
Tools: `tools/spec_trace.py` (renders agent-designed test cases through the
`veoneer-test-spec-generator` skill's own render/validate functions; traces an existing spec
without editing it), `tools/report_review.py` (HTML/apym and ARIA XML results + CAN logs),
`tools/test_task.py` (`setup --pipeline`, `init --pipeline`, `finish`, `findings`, `cb-fetch
--tracker`), `tools/keep_awake.py`.

**Why.** User request: reviews against the customer L10, test-case writing with Codebeamer-format
traceability (new and for existing specs), report/log review, and every pipeline working in the
background with the screen locked without losing the network.

**Keep-awake.** One hidden holder per PC: `SetThreadExecutionState(ES_CONTINUOUS |
ES_SYSTEM_REQUIRED)` (no admin), internet check every 30 s, Wi-Fi reconnect of the network in use
at start, self-expiry after the task's hours, released by `finish`. This PC has S3 sleep (no Modern
Standby), so a locked screen alone never stops work; the lid action is "sleep" and cannot be
overridden by a program — `status` warns. Wi-Fi name from `Get-NetConnectionProfile` because
`netsh wlan show interfaces` needs Location permission on Windows 11.

**Verified.** Tests: `test_keep_awake.py`, `test_spec_trace_report_review.py`, `test_test_task.py`
(findings validation, tracker fetch, finish). Live: a hold started, ran hidden, checked the
internet and expired by itself; `report_review.py scan` over 299 real reports + 507 logs + ARIA XML;
`spec_trace.py render` passed the skill's validators and `trace` re-found a removed trace.
(Numbered D-2026-10-26-21 when written; renumbered 2026-10-27 because another entry already had that ID.)

## D-2026-10-27-01 — Bench set-up and fault-free check before every test run

**Decision.** At the user's request ("if the aria is already open, it needs to make sure that the
ARIA is using the correct json profile and that the bench is fault free before test execution
unless the user say it is ok even if it is not, also ensure correct dbc files, rsu sheets are
loaded as per users input"), `test-execution-pipeline` checks the bench before the first test case
of every run:
- the user names the ARIA project, loadbox profile, RSU workbook and DBC(s) (`test_task.py init
  --aria-config --loadbox-profile --rsu-workbook --dbc`);
- `aria_ctl.py check-inputs` (read-only) compares ARIA with them: the active project by path, the
  profile and RSU workbook by path or content, each enabled CAN simulation's `.acpdf` (its
  `DatabaseSource` and frames/signals) with the DBC, files changed after ARIA started, and with
  `--live` the running ARIA's simulations, mapping and loadbox cards;
- `aria_ctl.py read-dtc` sends the framework's own `Read_DTC_Req` once: fault free = no DTC;
- any problem stops the run before a script starts (gate G2b); it goes on only with
  `run --accept-bench "<the user's words>"`, recorded in `runs/<n>/bench_check.json` and the manifest.
A wrong project is now overridable too (it was a hard stop): the user decides.

**Why these sources.** ARIA 5.20 keeps no record of loaded files in its ApplicationLog (only
telemetry noise), and no apym call reads the loaded RSU configuration back, so the files plus
their modification time against the ARIA process start are the evidence; ARIA did not rewrite
the M314 project files at its three starts after 2026-04-13. The DTC read reuses the framework's
definition of "bench fault free" (CANC scripts' step 1: `Read_DTC` with `Read_DTC_Req`).

**Found on first use (2026-10-27).** ARIA's M314 CANFD simulation was imported from
`SRS_FD_SVNID_40060_06032026.dbc`; the framework's DBC is `SRS_FD_SVNID_41243.dbc`. 7 differences,
e.g. `SRS1_FD_10.SRS_PAB_WARN_STS` at bit 183/1 in ARIA vs 208/2 in the DBC, `PIB_ACTIVE` and
`CTRL_BRAKE_LIGHT` (IEB1_FD_10) missing from ARIA.

**Verified.** `tests/test_aria_bench_tools.py` (DBC/acpdf comparison, check-inputs, DTC parsing),
`tests/test_test_task.py` (run stops on bench problems, goes on only with the user's words). Not run
against a live ARIA: `--live` and `read-dtc --apply` are untested on the bench.

## D-2026-10-27-02 — Test-case review pipeline; L10 named as the base of the requirement review

**Decision.** At the user's request ("add the /review-test-cases prompt as well as i hope
requirement review from l10 as base is also present"):
- New `test-case-review-pipeline` (operator, prompt `/review-test-cases`): `agent_sc3.md` §19 run
  from one prompt on an Excel spec or Codebeamer test cases. Reuses `spec_trace.py trace/apply/render`
  and `test_task.py cb-fetch/tc-workbook/tc-diff/findings`; new findings kind `tc-review` (categories
  from the §19.4 defect list, columns carrying the §19.5 five steps). `tc-workbook` now writes a
  Codebeamer `Verifies` reference field as `[ISSUE:<id>] - null` so the copy can be traced (field
  shape from the REST item JSON, not yet seen live).
- Separate from `test-case-writer-pipeline` (which writes cases and repairs links) because a review
  judges adequacy and correctness of existing cases and ends in a report, not new cases.
- `requirement-review-pipeline`: the L10 is stated as the base — L10 wins over Codebeamer unless a
  documented deviation explains the difference; `analysis/l10_coverage.md` in both directions; without
  an L10 the review says so and leaves customer correctness "not assessed".

**Verified.** `tests/test_test_task.py` (tc-review findings kind, Verifies column); `spec_trace.read_cases`
reads the tc-workbook copy's links. Not cold-run: no review of a real spec has been done with it yet.
