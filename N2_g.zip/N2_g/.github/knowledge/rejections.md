---
scope: Corrections the user has made, converted into rules the harness must not re-break
sources: user corrections during sessions; appended by .github/scripts/log_rejection.py
last_verified: 2026-08-29
fingerprint: append-only; each entry dated
---

# Rejections

Every entry is something the assistant proposed and the user rejected, plus the rule that
prevents it recurring. **Read the Rules index before proposing work in a listed scope.**

Append only, via `log_rejection.py`. Do not rewrite an entry -- add a new one that
supersedes it and say so.

## Rules index

<!-- RULES:START -->
- **harness** — grep tests/ and tools/ for a skill or module before archiving or deleting it
- **harness** — run a test to get its baseline BEFORE changing anything near it, so pre-existing failures are not mistaken for new ones
- **general** — declare classifications in a registry; never infer them from wording
- **shared-libraries** — verify a referenced file exists on disk before citing it as authoritative
- **harness** — after running any test that imports from shared_libraries/ or projects/, re-check protected paths and restore generated .pyc files, or set PYTHONDONTWRITEBYTECODE=1 before the run
- **harness** — invoke Python as 'py -3' in documentation and skills, never a hardcoded interpreter path
- **general** — confirm installability with 'pip install --dry-run <pkg>' before declaring a package incompatible; repo metadata describes HEAD, not the release you would consume
- **general** — when classifying spreadsheet header rows, treat years, quarters, halves, fiscal tags and month names as headers, and treat a horizontal merge as evidence of a header row
- **general** — key tabular data by column ADDRESS, never by header label; carry the label as a separate field
- **harness** — any CLI in this repo that emits non-ASCII must call sys.stdout.reconfigure(encoding='utf-8') at startup
- **projects** — For this M314 alignment, preserve existing M314 configuration content, add only missing common sections, and verify every project-specific value from M314 sources.
- **projects** — For this M314 CAN-C task, emit only Z121-style configuration dictionaries and helpers with M314-specific values and numbered fields; keep source evidence and reports out of the configuration.
- **projects** — For this Fault_List CAN refactor, reuse existing shared-library functions; do not add new helpers or infer permission to change protected shared libraries
- **projects** — Node-absent timing must collect per-node test failures, restore and save each report before continuing, and raise aggregate failure after all mapped nodes; unsafe restoration or reporting failure must still abort immediately.
- **projects** — In the six M310_M314_M110 CAN fault timing scripts, use the approved quiet standard-library sleep with ms_to_seconds conversion, preserve polling rounding/deadlines and verdicts, and keep shared Wait/Sleep signatures unchanged. Treat raw-sleep convention warnings as documented scoped exceptions, not hidden findings.
- **projects** — For the six M310_M314_M110 CAN fault timing scripts, render expected DTC bytes in uppercase including historic rows. Use the approved one-extra-nominal-duration observation period after the acceptance-window upper bound solely to capture late failed observations. Preserve the accepted range, conservative ambiguity checks, silent waits and cleanup policies. Report observed time or explicitly report not observed with actual elapsed time and last response; never invent a transition time or claim native-call cancellation.
- **projects** — For M314 Fault List CAN timing tests, retain FAILED observed or not-observed timing and continue only after restoration and report saving succeed. If qualification is observed outside the unchanged timing window, still measure recovery; if qualification is never observed, report dequalification as not measured rather than inventing a heal time. Only explicitly marked, fully reported timing summaries may continue across scripts. Cleanup, report, initialization, transport and other non-timing failures remain fatal. Preserve the accepted range, existing observation limit, silent waits, uppercase DTCs and final failed exit status. Creation or modification is not authorization for bench execution.
- **projects** — M314 IEB scripts must use existing canc_config and shared functions only; no parser or Excel/DBC file input in scripts. Add absent configuration data only when absolutely required.
- **projects** — Reuse canc_config.SIGNAL_CONTENT_DETECTION_COUNT and the existing frame periodicity for EPS qualification; do not introduce a duplicate EPS qualification setting. Reuse configuration_control Over_Voltage and Under_Voltage for voltage DTCs. Do not substitute DTC strings or power thresholds for the separate numeric PSU test levels without verified evidence.
- **can** — For this crc_check_log.txt screenshot comparison, use the user-approved initialization and byte sequence, preserve the exact previously sampled frames, and independently verify the supplied example. Explicitly disclose any appended CAN-ID/Data-ID bytes; never silently add them or claim an unverified matching result.
- **edr** — For Z121 EDR scripts and their generation templates, omit redundant raw-decimal result rows. Preserve existing raw-hex and physical-value checks and their required numeric calculations.
- **projects** — For the 62-case U171 EDR CAN-C UV/OV export, retain the standard Framework_IOEM_Py Path(__file__).resolve().parents[5] import bootstrap in project scripts and exported copies. Execution requires the files to reside in the U171 project scripts folder, not merely a changed shell working directory.
- **edr** — For this 62-case U171 EDR CAN-C UV/OV runner, follow the user-provided reference: editable SCRIPT_FILES and SCRIPT_FAULTS, --only/--fault/--nominal/--list filters, normal invocation executing the selected project-folder cases without --run or --framework-root, continuation after nonzero process exits, and a filename-to-integer-exit-code JSON summary. Do not execute the bench while preparing or validating it.
<!-- RULES:END -->

## Entries

### 2026-08-29 — harness

**Proposed:** archive clean-exported-web-text-images-and-symbols as unrelated to ECU testing

**Why it was wrong:** tests/test_excel_cleanup_preview.py imports its script directly; archiving it would have broken a passing test

**Rule:** grep tests/ and tools/ for a skill or module before archiving or deleting it

### 2026-08-29 — harness

**Proposed:** treat the failing portfolio test as damage caused by the consolidation

**Why it was wrong:** it was already failing beforehand: the registry listed 14 skills against 18 on disk

**Rule:** run a test to get its baseline BEFORE changing anything near it, so pre-existing failures are not mistaken for new ones

### 2026-08-29 — general

**Proposed:** classify an agent as a verifier by keyword-matching its description

**Why it was wrong:** architecture-agent's 'static review' scope tripped the match though it is an analyst, not a gate

**Rule:** declare classifications in a registry; never infer them from wording

### 2026-08-29 — shared-libraries

**Proposed:** reference agent.md at the repository root as the knowledge base

**Why it was wrong:** no agent.md exists at the repo root; it is .github/agents/agent_sc3.md

**Rule:** verify a referenced file exists on disk before citing it as authoritative

### 2026-08-29 — harness

**Proposed:** run the full test suite and then assert protected paths are unchanged

**Why it was wrong:** importing a module under shared_libraries/ writes a .pyc into shared_libraries/__pycache__/, which is inside a protected path; the run itself caused drift

**Rule:** after running any test that imports from shared_libraries/ or projects/, re-check protected paths and restore generated .pyc files, or set PYTHONDONTWRITEBYTECODE=1 before the run

### 2026-08-29 — harness

**Proposed:** invoke a skill script via a hardcoded interpreter path (`C:\Python3` + `.13.0\python.exe`)

**Why it was wrong:** that interpreter does not exist on this machine — the installed one is Python 3.14.0. Three SKILL.md files carried the dead path in copy-pasteable commands. (Written with the path split so the bulk-fix that repaired those files cannot rewrite this entry too.)

**Rule:** invoke Python as 'py -3' in documentation and skills, never a hardcoded interpreter path

### 2026-08-30 — general

**Proposed:** read a package's supported Python versions from its repo pyproject.toml

**Why it was wrong:** the dev branch metadata is not the published release: unstructured HEAD declares requires-python <3.14 yet release 0.18.32 installs fine on 3.14, while mineru genuinely cannot

**Rule:** confirm installability with 'pip install --dry-run <pkg>' before declaring a package incompatible; repo metadata describes HEAD, not the release you would consume

### 2026-08-30 — general

**Proposed:** detect a spreadsheet header band as the leading rows containing no numeric values

**Why it was wrong:** period labels are numeric: a 2025/2026 row over Q1/Q2 broke the band after one row and collapsed four distinct columns onto one ambiguous label, in output that looked well-formed

**Rule:** when classifying spreadsheet header rows, treat years, quarters, halves, fiscal tags and month names as headers, and treat a horizontal merge as evidence of a header row

### 2026-08-30 — general

**Proposed:** key a compiled table row by its column header label

**Why it was wrong:** header labels are not unique - two columns can both be 'Q1' - so the last column silently overwrote the others and every quarter reported Q4's number

**Rule:** key tabular data by column ADDRESS, never by header label; carry the label as a separate field

### 2026-08-30 — harness

**Proposed:** write tool output containing arrows and en-dashes to stdout on Windows

**Why it was wrong:** the console defaults to cp1252 and UnicodeEncodeError crashed the run when stdout was redirected to a file

**Rule:** any CLI in this repo that emits non-ASCII must call sys.stdout.reconfigure(encoding='utf-8') at startup

### 2026-10-12 — projects

**Proposed:** Build a M314 CAN-C configuration candidate

**Why it was wrong:** The user clarified that most M314 content already exists and only missing Z121-compatible structure should be added

**Rule:** For this M314 alignment, preserve existing M314 configuration content, add only missing common sections, and verify every project-specific value from M314 sources.

### 2026-10-12 — projects

**Proposed:** Embed generated value-patch and evidence dictionaries in M314 CAN-C configuration

**Why it was wrong:** The user requires the Z121 configuration structure and pure configuration without Excel/JSON references or report content

**Rule:** For this M314 CAN-C task, emit only Z121-style configuration dictionaries and helpers with M314-specific values and numbered fields; keep source evidence and reports out of the configuration.

### 2026-10-12 — projects

**Proposed:** Add a shared orchestration helper for six CAN fault timing scripts

**Why it was wrong:** User requires this refactor to reuse existing shared-library functions and add no helper functions in the scripts

**Rule:** For this Fault_List CAN refactor, reuse existing shared-library functions; do not add new helpers or infer permission to change protected shared libraries

### 2026-10-13 — projects

**Proposed:** Re-raise the first node timing failure and stop the node loop.

**Why it was wrong:** The user needs a saved report for every mapped node even when an individual timing test fails.

**Rule:** Node-absent timing must collect per-node test failures, restore and save each report before continuing, and raise aggregate failure after all mapped nodes; unsafe restoration or reporting failure must still abort immediately.

### 2026-10-13 — projects

**Proposed:** Use reported Wait calls inside every CAN fault polling and settling loop.

**Why it was wrong:** The user wants no wait rows in CAN fault HTML reports; thousands of routine wait comments obscure useful results.

**Rule:** In the six M310_M314_M110 CAN fault timing scripts, use the approved quiet standard-library sleep with ms_to_seconds conversion, preserve polling rounding/deadlines and verdicts, and keep shared Wait/Sleep signatures unchanged. Treat raw-sleep convention warnings as documented scoped exceptions, not hidden findings.

### 2026-10-13 — projects

**Proposed:** Stop CAN fault polling at the acceptance deadline and report lowercase DTC bytes with an anonymous timeout.

**Why it was wrong:** The user requires uppercase expected DTC bytes and the actual observed qualification or dequalification time, with out-of-range timing marked FAILED.

**Rule:** For the six M310_M314_M110 CAN fault timing scripts, render expected DTC bytes in uppercase including historic rows. Use the approved one-extra-nominal-duration observation period after the acceptance-window upper bound solely to capture late failed observations. Preserve the accepted range, conservative ambiguity checks, silent waits and cleanup policies. Report observed time or explicitly report not observed with actual elapsed time and last response; never invent a transition time or claim native-call cancellation.

### 2026-10-14 — projects

**Proposed:** Run the M314 CAN fault suite with fail-fast handling for qualification or dequalification timing failures.

**Why it was wrong:** The user requires failed obtained timing to be reported and execution to continue through remaining CAN fault targets and scripts.

**Rule:** For M314 Fault List CAN timing tests, retain FAILED observed or not-observed timing and continue only after restoration and report saving succeed. If qualification is observed outside the unchanged timing window, still measure recovery; if qualification is never observed, report dequalification as not measured rather than inventing a heal time. Only explicitly marked, fully reported timing summaries may continue across scripts. Cleanup, report, initialization, transport and other non-timing failures remain fatal. Preserve the accepted range, existing observation limit, silent waits, uppercase DTCs and final failed exit status. Creation or modification is not authorization for bench execution.

### 2026-10-14 — projects

**Proposed:** Read native DBC layouts with cantools inside the new M314 IEB scripts

**Why it was wrong:** User permits offline document parsing but forbids parser, Excel, or DBC inputs directly in the scripts

**Rule:** M314 IEB scripts must use existing canc_config and shared functions only; no parser or Excel/DBC file input in scripts. Add absent configuration data only when absolutely required.

### 2026-10-14 — projects

**Proposed:** Introduce EPS_SIGNAL_CONTENT_QUALIFICATION_COUNT in fault_list_config for EPS qualification.

**Why it was wrong:** The CAN-C configuration already owns signal-content detection and recovery timing. The user requested reusing it instead of an EPS-specific duplicate. Shared Over_Voltage and Under_Voltage are DTC codes, not numeric voltage stimulus levels.

**Rule:** Reuse canc_config.SIGNAL_CONTENT_DETECTION_COUNT and the existing frame periodicity for EPS qualification; do not introduce a duplicate EPS qualification setting. Reuse configuration_control Over_Voltage and Under_Voltage for voltage DTCs. Do not substitute DTC strings or power thresholds for the separate numeric PSU test levels without verified evidence.

### 2026-10-20 — can

**Proposed:** The previous offline screenshots used CRC16_CCIT_ZERO with initial value 0x0000.

**Why it was wrong:** On 2026-10-20 the user revised the required CRC initialization to 0xFFFF, keeping polynomial 0x1021 and final XOR 0x0000. The byte-input rule must be checked against the exact supplied example before replacing screenshots.

**Rule:** For this crc_check_log.txt screenshot comparison, use the user-approved initialization and byte sequence, preserve the exact previously sampled frames, and independently verify the supplied example. Explicitly disclose any appended CAN-ID/Data-ID bytes; never silently add them or claim an unverified matching result.

### 2026-10-20 — edr

**Proposed:** Include separate raw-decimal result rows alongside raw-hex and physical-value checks in Z121 EDR reports.

**Why it was wrong:** The user identified these as redundant direct hex-to-decimal conversions and requested their removal from every Z121 EDR script.

**Rule:** For Z121 EDR scripts and their generation templates, omit redundant raw-decimal result rows. Preserve existing raw-hex and physical-value checks and their required numeric calculations.

### 2026-10-20 — projects

**Proposed:** Remove the normal project-layout import bootstrap from the 62 exported U171 EDR CAN-C UV/OV cases and rely only on runner imports.

**Why it was wrong:** The user will run these copies from the U171 project scripts folder and explicitly requires the same bootstrap in the Downloads copies.

**Rule:** For the 62-case U171 EDR CAN-C UV/OV export, retain the standard Framework_IOEM_Py Path(__file__).resolve().parents[5] import bootstrap in project scripts and exported copies. Execution requires the files to reside in the U171 project scripts folder, not merely a changed shell working directory.

### 2026-10-21 — edr

**Proposed:** Use a U171 62-case runner that defaults to listing, requires --run and --framework-root, and stops after the first nonzero process exit.

**Why it was wrong:** The user supplied a read-only runner reference and requested that structure and command-line behavior instead.

**Rule:** For this 62-case U171 EDR CAN-C UV/OV runner, follow the user-provided reference: editable SCRIPT_FILES and SCRIPT_FAULTS, --only/--fault/--nominal/--list filters, normal invocation executing the selected project-folder cases without --run or --framework-root, continuation after nonzero process exits, and a filename-to-integer-exit-code JSON summary. Do not execute the bench while preparing or validating it.

