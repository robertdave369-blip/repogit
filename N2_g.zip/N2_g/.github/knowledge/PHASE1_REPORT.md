# Phase 1 — Audit and Capability Probe

**Scope:** `.github/` harness for GitHub Copilot (model Terra) in VS Code.
**Status:** Report only. Nothing was changed. Phase 2 not started.
**Probe basis:** VS Code **1.135.0** (build `08d4889f9e`), `GitHub.copilot-chat` **0.63.0**.

> VS Code updated from build `1b6a188127` to `08d4889f9e` between the crash and this session.
> Every capability finding below was re-derived against the **current** build.

Tags per §3: `REPO` = found in this repo · `TOOL` = found in installed product on disk ·
`INFERRED` = reasoned · `UNKNOWN` = needs confirmation.

---

## 4.1 Inventory of `.github/` — 142 files

| Group | Count | Verdict | Why |
|---|---|---|---|
| `copilot-instructions.md` (176 lines) | 1 | **rewrite** | Over the §9 150-line budget. Mixes always-on rules with routing detail that belongs in skills. `REPO` |
| `instructions/*.instructions.md` | 7 | **keep** | 50–104 lines each, all within the 120-line budget. `REPO` |
| `agents/*.agent.md` stubs | 13 | **merge to 3** | §9 allows 3 custom agents. Frontmatter (`name`, `description`) is valid. `REPO` |
| `agents/` large knowledge docs | 5 | **move** | `agent_sc3.md` (3084), `FRAMEWORK_CORE_AND_DEBUGGING_GUIDE.md` (641), `aria_agent.md` (619), `ARIA_TypeScript.md` (375), `canc_onfail.md` (170). These are **knowledge, not agents** — VS Code loads only `*.agent.md` from this folder, so they are inert here. Belong in `.github/knowledge/`. `TOOL`+`REPO` |
| `prompts/*.prompt.md` | 7 | **keep** | Within the 10-file budget. `REPO` |
| `prompts/*.agent.md` | 14 | **delete** | **Defect.** VS Code reads agents from `chat.agentFilesLocations` (`.github/agents`) only — an `.agent.md` in `.github/prompts` never loads as an agent. Worse, all 13 overlapping files have **already drifted** from their `agents/` counterparts (0 identical, 13 differing). The §9 "second copy will drift and then contradict" defect, already realised. `TOOL`+`REPO` |
| `prompts/implement_this_in_future_if_asked.md` (305) | 1 | **move** | A backlog note, not a prompt file. `REPO` |
| `hooks/` (config + 9 scripts + routing.json) | 11 | **keep, verify** | `framework-guardrails.json` is **schema-valid** against the real VS Code hook contract (see 4.3). `TOOL` |
| `skills/*/SKILL.md` | 19 | **prune to 12** | Over the §9 budget. `aria-bench-configuration` is 235 lines, over the 200-line cap. `REPO` |
| `cache/session.json` | 1 | **keep** | Written by `hooks/scripts/cache.py`. `REPO` |
| `README.md` (129) | 1 | **keep** | `REPO` |

### Budget position (§9)

| Item | Limit | Actual | Status |
|---|---|---|---|
| `copilot-instructions.md` | ≤150 | 176 | **over by 26** |
| Any instructions file | ≤120 | max 104 | ok |
| Any `SKILL.md` | ≤200 | max 235 | **1 over** |
| Skills, total | ≤12 | 19 | **over by 7** |
| Prompt files | ≤10 | 7 (+14 misplaced) | ok once misplaced removed |
| Custom agents | ≤3 | 13 | **over by 10** |

### What is measurably not working today

1. 14 `.agent.md` files in `.github/prompts/` are **never loaded** by any mechanism — dead weight
   that has already diverged from the live copies in `.github/agents/`. `TOOL`+`REPO`
2. Five large knowledge documents sit in `.github/agents/` where nothing loads them automatically.
   They are reachable only because `copilot-instructions.md` names `agent_sc3.md` by path. `INFERRED`
3. Skills and agents both exceed budget, so Terra pays context cost on descriptions for
   capabilities that will rarely route.

*Cross-check performed:* the skill catalogue in `05-skill-catalogue.instructions.md` matches the
skills on disk exactly — no drift in either direction. `REPO`

---

## 4.2 Repository map

**Top level:** `shared_libraries/`, `projects/`, `tools/`, `tests/`, `docs/`, `project_dbc/`,
`project_testcases/`, `project_reuirements/`, `aria_projects/`, `crash_data/`, `evt/`,
`graphify-out/`, `test_logs/`, `test_results/`, `pyrightconfig.json`. `REPO`

### Packaging — a conflict with §2 of your prompt

There is **no package named `framework_ioem_py`**. The importable root is the **repository
directory itself**, imported as `Framework_IOEM_Py`, made resolvable by `extraPaths: [".."]` in
`pyrightconfig.json`. Statement counts across `projects/`, `tools/`, `tests/`: `REPO`

```
from Framework_IOEM_Py.shared_libraries.apym_imports            3739
from Framework_IOEM_Py.shared_libraries.core_functions          3562
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions  3476
from Framework_IOEM_Py.shared_libraries.configuration_control   3469
...  44,486 Framework_IOEM_Py.* import statements in total
```

Per §0 the repository wins: the harness will document `Framework_IOEM_Py.shared_libraries.*`.

**`shared_libraries/` — 19 modules, ~18.9k lines.** Largest: `core_functions.py` (5204),
`jscript_translation.py` (4343), `data_conversions.py` (2876), `configuration_control.py` (919),
`edr_decoding_functions.py` (845), `can_library.py` (801), `winidea.py` (571). `REPO`

- **`tools/`** — 14 generator/builder scripts, no `__init__.py`, run as scripts. `REPO`
- **`tests/`** — 949 `.py` files; 16 top-level `test_*.py`. `REPO`
- **No dependency manifest** — no `pyproject.toml`, `setup.py`, `requirements.txt`, `uv.lock`. `REPO`
- **No CI** — no `.github/workflows/`. `REPO`

### Two defects in the workspace configuration `REPO`

1. `.vscode/settings.json` sets `python.defaultInterpreterPath` to `C:/Python 3.13.0/python.exe`
   — **that path does not exist.** The installed interpreter is `C:/Python 3.14.0/python.exe`.
2. `pyrightconfig.json` sets `extraPaths` to `C:/Python 3.13.0/Lib/apym-2.6.0/src` — **also
   missing.** The real APYM source is `C:/Python 3.14.0/Lib/apym-2.6.0/src` (confirmed present).
   `.vscode/settings.json` already points `python.analysis.extraPaths` at the 3.14 path, so the
   two config files **contradict each other**.

### Legacy import root that cannot resolve

`Test_Enviornment.Library.*` is imported **4,138 times** (`EDR_Parameters_UPP` 811, `CANLibrary`
793, `ConfigurationControl` 637, `ImportList` 635, `EDRDataReading_more_generic` 635,
`CoreFunctions` 635), but **no `Test_Enviornment` directory exists on disk**. Those scripts cannot
execute as-is. `REPO` Filed as an open question.

### Third-party reality check (drives Appendix A, Tier 1)

Imports across 8,068 `.py` files, against what is installed for `py -3.14`: `REPO`+`TOOL`

| Package | Imports in repo | Installed | Tier-1 verdict |
|---|---|---|---|
| `apym` | 9,622 | not on default path | **index — highest value** |
| `openpyxl` | 25 | yes | **index** |
| `cantools` | 5 | yes | **index** |
| `pandas` | 3 | yes | index (light) |
| `win32com` | 2 | no | defer |
| `python-can` | 0 | yes | **do not index** — nothing imports it |
| `can-isotp`, `udsoncan`, `odxtools`, `asammdf`, `logic2-automation`, `isystem.connect` | 0 | no | **do not index, do not install** |
| `pytest` | 0 | **no** | see below |

Appendix A's rule — index only packages the repository actually imports — cuts Tier 1 from 10
candidates to **4**. Large saving, evidence-driven rather than preference.

**Test runner is unresolved.** `pytest` is not installed, no manifest declares a runner, yet
`tests/` holds 949 Python files. How the suite actually runs is `UNKNOWN`, and it blocks the §6.3
"targeted test run" guardrail.

---

## 4.3 Copilot capability probe

All six mechanisms are **supported**. This corrects an intermediate reading I had mid-probe: the
`copilot-chat` extension declares no hook settings, but that is because **hooks are a VS Code core
feature**, not an extension feature.

| Mechanism | Supported | Evidence (`TOOL`) | Fallback needed |
|---|---|---|---|
| `.github/copilot-instructions.md` | **yes** | `github.copilot.chat.codeGeneration.useInstructionFiles` default `true`; core constant `copilot-instructions.md` | none |
| `.github/instructions/*.instructions.md` + `applyTo` | **yes** | `chat.instructionsFilesLocations` default `.github/instructions`; `chat.includeApplyingInstructions` default `true`; `.instructions.md` registered as language `instructions` | none |
| `.github/skills/<name>/SKILL.md` | **yes, on by default** | `chat.useAgentSkills` `default:true`, `restricted:true`; `chat.agentSkillsLocations` default includes `.github/skills`; `SKILL.md` registered as language `skill` | none |
| `.github/prompts/*.prompt.md` | **yes** | `chat.promptFilesLocations` default `.github/prompts` | none |
| Custom agents `.github/agents/*.agent.md` | **yes** | `chat.agentFilesLocations` default `.github/agents`; `.agent.md` / `.chatmode.md` registered as language `chatagent` | none |
| `.github/hooks/*.json` | **yes, but preview + policy-gated** | see below | **yes — see below** |

**Skill naming constraint** `TOOL` — skill directory names are validated against `/^[a-z0-9-]+$/`.
All 19 existing skill directories comply.

### Hooks — the §4.3 "plan requirement" question, answered

`chat.useHooks` is declared in VS Code core as:

```js
{ type:"boolean", default:true, restricted:true, tags:["preview","prompts","hooks","agent"],
  policy:{ name:"ChatHooks", category:"InteractiveSession", minimumVersion:"1.109",
           value: s => s.chat_preview_features_enabled === false ? false : undefined } }
```

Reading that precisely: `TOOL`

- Hooks are **on by default** and require **VS Code ≥ 1.109** — you are on 1.135.0. Satisfied.
- They are **preview-tagged** and gated by an **organisation/plan policy**: if your Copilot
  entitlement reports `chat_preview_features_enabled === false`, `chat.useHooks` is **forced to
  false** and cannot be overridden locally (`restricted: true`).
- `chat.hookFilesLocations` default includes `.github/hooks` — your location is correct.
- `chat.usecopilotHooks` defaults to **false**, so `.copilot/settings.json` hooks stay off. Irrelevant
  here, since your hooks live in `.github/hooks`.
- `chat.hooks.allowManagedOnly` exists and is policy-backed — an org can restrict hooks to
  org-managed ones only.

**Your existing `framework-guardrails.json` is schema-valid.** Its six event names —
`SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PreCompact`, `Stop` — all appear
in the core event map, and the entry shape (`type:"command"` plus `command` / `windows` variants
and `timeout`) matches the core validator, which accepts `command`, `bash`, `powershell`,
`windows`, `linux`, `osx`. `TOOL`

**What remains `UNKNOWN`:** whether *your account's* plan sets `chat_preview_features_enabled`.
That value arrives with the Copilot token at runtime and **cannot be determined from disk**.

To be exact rather than to overclaim: `.github/cache/session.json` exists and contains entries
stamped `2026-08-28 17:59 UTC`, but those were written by a **manual run** of `cache.py` during the
previous session. **That is not proof a hook fired.** `INFERRED`

**Check that settles it:** set `"chat.useHooks": true` explicitly, start a new Copilot chat session
in this workspace, and see whether the `updated` timestamp in `.github/cache/session.json` moves.
If it does, hooks are live. If it does not, they are policy-disabled.

**Fallback if hooks are policy-disabled:** every guardrail is already written as a standalone Python
script under `.github/hooks/scripts/`, so each stays runnable from the command line — which §6.3
requires regardless. The automated trigger would be lost; the enforcement rule then lives in
`copilot-instructions.md` as advisory text, and I will say so plainly rather than describing
automation that does not run.

### Related finding — VS Code protects these paths from AI edits by default

Core ships a default map marking `**/.github/agents/**` and `**/.github/hooks/**` as **not
auto-approvable**, alongside `**/.vscode/*.json` and the `.copilot/` settings files. `TOOL`
Useful: the guardrail files are already protected from casual self-modification.

### Auto-approve and auto-compaction — all verified real

Every setting written into `.vscode/settings.json` before the crash exists in the shipped
product: `chat.tools.global.autoApprove`, `chat.tools.terminal.enableAutoApprove`,
`chat.tools.terminal.autoApprove`, `chat.agent.maxRequests`, `chat.includeApplyingInstructions`,
`chat.usecopilotMdFile`, `chat.agentFilesLocations`, and
`github.copilot.chat.summarizeAgentConversationHistory.enabled` (default `true`). `TOOL`

Two cautions I will not soften:

1. `chat.tools.global.autoApprove: true` approves **every** tool call, including file writes and
   terminal commands. Its only remaining gate is the `PreToolUse` hook — **exactly the mechanism
   that may be policy-disabled.** If hooks are off, that setting is unguarded.
2. `chat.agentSkillsLocations` is set in the workspace file, but `chat.useAgentSkills` is not set
   explicitly. It defaults to `true`, so skills load — but pinning it makes the harness survive a
   settings reset.

---

## 4.4 Proposed architecture

Consolidation, not expansion. Net file count falls.

```
.github/
  copilot-instructions.md          rewrite -> <=150 lines: protected paths, the §3 no-invention
                                   rule, tag vocabulary, knowledge location, intake rule
  instructions/                    keep all 7 (in budget)
  agents/                          13 stubs -> 3:
                                     test-engineering-agent   (test spec + coverage)
                                     diagnostics-agent        (UDS / DTC / EDR / CAN)
                                     verification-agent       (review, evidence, contradictions)
  knowledge/                       NEW - the persistent memory (§5.2)
    repo-map.md                    directories, modules, entry points; references only
    api-index.md                   verified surface: shared_libraries + apym + openpyxl
                                   + cantools, each with path:line
    decisions.md                   append-only
    open-questions.md              everything UNKNOWN
    domain/                        ONLY where repo evidence exists (see below)
  prompts/                         7 .prompt.md kept; 14 misplaced .agent.md deleted
  skills/                          19 -> 12
  hooks/                           unchanged; enablement to be confirmed
  scripts/                         NEW - staleness check + manual guardrail runners
```

**Domain files justified by evidence** (§5.2: created only where repository evidence exists).
On the import and grep evidence above, these are supportable: `edr`, `canc` / CAN-FD, `uds`,
`dtc`, `nvm`, `aria-apym`, `winidea`, `crash`, `sensors/rsu`.

**Not yet supportable:** `psi5`, `bootloader`, `saleae`, `memtool`, `autosar-bsw` as first-class
files. Your §1–§29 list requests them, but §5.2 and §3 forbid writing them from general knowledge.
I will probe each specifically in Phase 2 and create only those that clear the bar, filing the rest
in `open-questions.md` with what I searched.

### Skill consolidation, 19 to 12

| Skill | Action | Reason |
|---|---|---|
| `windchill-ptc-project-automation` (2,000+ lines PowerShell) | **move out** | PTC Windchill administration, not ECU test authoring. Large context cost, unrelated routing. |
| `canoe-automation` + `capl-programming` | **merge to 1**, or drop | `win32com` appears twice in the entire repo; no CANoe automation in use. |
| `clean-exported-web-text-images-and-symbols` | **move out** | Document-cleanup utility, not test work. |
| `embedded-systems-fundamentals` + `functional-safety-iso26262` + `requirement-based-testing` | **merge to `failure-mode-analysis`** | Three generic checklists; §6.1 requires exactly this skill. |
| `aria-bench-configuration` (235 lines) | **split** | Over the 200-line cap; push detail into bundled references. |

**New skills required by §6.1** — `test-spec-authoring`, `failure-mode-analysis`, `api-discovery`,
`hardware-safety`, `large-file-analysis`. Two are partly covered by existing skills
(`veoneer-test-spec-generator`, `can-channel-agnostic-wrappers`), so I intend to **extend those
rather than add duplicates**, holding the total at 12.

**Estimated new files, Phase 2 + 3: ~22** — within the §9 budget of 40.

---

## Protected-path proof (§1)

```
git status --porcelain -- shared_libraries/ projects/   ->   4,527 entries (NOT empty)
```

Flagging this honestly rather than pasting a clean result I do not have. **These 4,527 entries
pre-date this task** — your own uncommitted work from the earlier EDR and shared-library sessions,
present before Phase 1 began.

What I can prove is **zero drift**. I captured the pre-crash baseline and re-ran the same command
now; the two are byte-identical — 4,527 entries before, 4,527 after:

```
diff protected_baseline.txt protected_now.txt   ->   (no output)
```

I changed nothing under `shared_libraries/` or `projects/`, and nothing changed there while I
worked. But the §1 acceptance criterion — an empty result is the only acceptable proof — **cannot
be met** until you commit or stash that pre-existing work. Until then, drift-against-baseline is
the strongest available proof, and I will use it at each phase boundary.

---

## Open questions

1. **Is `chat.useHooks` actually enabled on your Copilot plan?** Determines whether guardrails are
   enforced or advisory. Cannot be read from disk.
2. **How is the test suite run?** `pytest` is not installed and no manifest declares a runner, so
   the §6.3 targeted-test guardrail has nothing to call.
3. **`Test_Enviornment` (4,138 imports) does not exist on disk** — legacy reference, or expected
   only on the bench machine?
4. **Interpreter mismatch:** `.vscode/settings.json` and `pyrightconfig.json` both point at a
   non-existent `C:/Python 3.13.0`. Correct both to 3.14.0? (Outside protected paths, safe to fix.)
5. **`windchill-ptc-project-automation`** — genuinely part of your workflow, or can it move out of
   the harness?

---

## Decisions needed before Phase 2

1. Approve the architecture in 4.4 — in particular **19 skills to 12** and **13 agents to 3**.
2. Confirm the hook enablement check, or tell me to design guardrails as advisory-only.
3. Answer the runner question (2) so guardrails have something to invoke.
4. Confirm domain files stay gated on evidence — I will **not** write `psi5.md`, `bootloader.md`,
   `saleae.md` or `memtool.md` from general knowledge, even though §1–§29 lists them, unless
   repository or on-disk vendor evidence turns up in Phase 2.
