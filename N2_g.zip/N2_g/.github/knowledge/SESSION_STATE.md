# Session state — Copilot/Terra harness build

**Last working session:** `f096d2dc-3be2-4c2b-a982-8bc62b536fef` (2026-08-28 18:26 → 2026-08-29 08:18 UTC).
Ended when the laptop powered off. Reconstructed 2026-08-29 from the on-disk transcript.

**Lineage:** `628996b5` (crashed, VS Code) → `f096d2dc` (recovered it, did the work below) → current.

## Durable artifacts

| What | Where |
|---|---|
| Governing spec (54.5 KB: §1–§29 domain knowledge + §0–§12 plan + Appendix A) | `.github/knowledge/GOVERNING_SPEC.md` |
| Phase 1 audit report | `.github/knowledge/PHASE1_REPORT.md` |
| 13 decisions with rationale | `.github/knowledge/decisions.md` |
| 6 rejection-derived rules | `.github/knowledge/rejections.md` |
| Archived, never deleted: 8 skills, 3 agents, 14 dead prompt files, 1 superseded doc | `.github/knowledge/archive/` |
| Transcripts | `~/.copilot/projects/C--Framework-IOEM-Py/{628996b5,f096d2dc}*.jsonl` |
| Pre-crash protected-path baseline (4,527 entries) | `%LOCALAPPDATA%/Temp/copilot/C--Framework-IOEM-Py/628996b5-.../scratchpad/protected_baseline.txt` |

## Phase status

- **Phase 1 (audit only)** — DONE and reported.
- **Phase 2 (skeleton + evidence-gated knowledge)** — NOT started, NOT approved.
- **Phase 3 (skills + guardrails)** — largely done ahead of order, driven by direct user requests.

## What was built (all verified, not assumed)

**Multi-agent swarm — 12 agents in `.github/agents/*.agent.md`**
- `swarm-orchestrator` — holds `agent`/`todo`, deliberately **not** `edit`, so it must delegate.
- `verification-agent`, `intent-fidelity-agent` — read-only gates. Intent-fidelity requires the
  user's **verbatim** request and returns `UNVERIFIABLE` on a paraphrase.
- 9 analysts: architecture, autosar, communication, cybersecurity, diagnostics, requirements,
  research, safety, test-engineering.
- **No agent holds `execute`.** Writing a script ≠ running it; hardware is never actuated uninvited.
- Roles are **declared** in `.github/scripts/agent_roles.json`, never inferred from wording.
- Subagent depth is 1 (`chat.subagents.allowInvocationsFromSubagents` stays false) — a nested
  subagent's sources never reach the orchestrator, which would silently defeat the diversity check.

**Skills — 19 → 12 in `.github/skills/`** (§9 ceiling exactly)
aria-bench-configuration, aria-crash-simulation-xml, can-channel-agnostic-wrappers,
clean-exported-web-text-images-and-symbols, dbc-to-json, document-context, failure-mode-analysis,
python-test-automation, skill-portfolio-orchestration, uds-diagnostics, uv-package-manager,
veoneer-test-spec-generator.

**Guardrail scripts — `.github/scripts/`** (all runnable standalone, all negative-tested)
- `validate_agents.py` — fails if a verifier holds mutating tools; 12/12 clean.
- `check_source_diversity.py` — computes false consensus from `evidence-handoff.schema.json`
  `sources[]`; fails on zero input.
- `review_gate.py` + `review_gate.config.json` — 5 ordered checks: diversity, evidence integrity,
  self-critique, dedup, confidence clamp. High confidence with no cited source never surfaces.
- `log_rejection.py` — writes `rejections.md` with a self-regenerating rules index; requires all of
  proposed / why-wrong / rule.
- `build_skill_catalogue.py` — generates the catalogue from SKILL.md frontmatter (hand-maintained
  indexes drift; that drift is what broke the portfolio test).

**Universal document extractor — `.github/skills/document-context/scripts/document_context.py`**
- One entry point, five escalating levels, cached, provenance on every node.
- Reuses the existing 1,590-line `pdf_document_intelligence.py` rather than rewriting it; the skill
  was **renamed** `pdf-document-intelligence` → `document-context` to hold the 12-skill budget and
  keep one front door.
- Measured on the 502 KB EDR workbook: `inspect` 886 B = **567× smaller** than raw.
- Works with no install: PDF, Excel, Word, CSV/TSV, JSON, XML/ARXML, DBC, Markdown, text/log, HTML,
  URLs, image metadata. PPTX needs one install. Dependencies are never installed silently.
- **No OCR** — needs the native tesseract binary, which §1 forbids requiring. A test asserts that
  limitation is declared rather than papered over.
- 22 tests, all passing.

**Copilot CLI v1.0.81 installed** (`npm install -g @github/copilot`). From the repo root it reports
all 12 skills enabled, `copilot-instructions.md` loaded, all 7 instructions files loaded. **One
`.github/` serves both VS Code and the terminal — no port, no second copy.**

**`copilot-instructions.md`: 212 → 131 lines**, rewritten as a router (it had grown to restate
`agent_sc3.md` in prose, which §9 calls a defect). The 212-line version is archived.

## Mira (github.com/miracodeai/mira) — rejected as a dependency, two patterns taken

It is a self-hosted **code-review service** (Docker, webhooks, GitHub App, Postgres, dashboard).
§1 forbids hosted services and separate runtimes, and it reviews pull requests — this repo has no CI,
no workflows, and `.github/` is untracked. Reimplemented from scratch instead: its noise filter
(→ `review_gate.py`) and its learn-from-rejections loop (→ `log_rejection.py`).

## Open items

1. **Phase 2 approval** — still the hard stop the spec requires.
2. **Per-project config override layer** — one `.github/` currently serves U171, M314, ICE_01, EV_01,
   while the standing rule is *never carry project values between projects*. Mira's two-tier config
   maps onto this gap. Filed, not built. Most likely single cause of a wrong answer.
3. **Two pre-existing test failures, not caused by this work:**
   - `test_crash_configuration.py` — 2 real RSU channel-inversion mismatches in
     `shared_libraries/crash_configuration.py`. **A genuine defect in uncommitted work.**
   - `test_ice_common_edr_specification.py` — "NO TESTS RAN"; it is a generator script with an
     `argparse` main living in `tests/`, not a test module.
4. **§1 protected-path criterion is not met** — `git status --porcelain -- shared_libraries/ projects/`
   returns 4,527 entries. All pre-date this task (the uncommitted EDR work). Zero drift is proven
   byte-for-byte against the baseline, but §1 is only satisfied once that is committed or stashed.
5. **14 dead `.agent.md` files in `.github/prompts/`** — archived, not deleted, pending a word.

## UNKNOWN — recorded, never guessed

- Whether the Copilot **CLI honours `.github/hooks/`**. Hooks are a VS Code *core* feature; the CLI
  exposes no hook option. Treat terminal guardrails as manual script runs until confirmed.
- Whether **`chat.useHooks` is live on this account** — it is preview-tagged and gated by the org
  policy `chat_preview_features_enabled`, which arrives in the Copilot token at runtime and cannot
  be read from disk.
- Whether **`--model` offers Terra** specifically, and whether Terra accepts image input. The string
  "Terra" appears nowhere in the shipped manifest; models come from the service at runtime.
- The **Appendix A Tier 2 repos were never fetched** — those calls were declined. Nothing in the
  harness claims to derive from them.

---

## 2026-08-30 — Universal Document Understanding layer

`document-context` was **renamed** `universal-document-understanding` and extended into a
full document-understanding layer. Portfolio still **12 skills** (D-16).

**Upstream research** — MinerU, Docling and Unstructured were cloned and read on disk;
findings in `research/document-parsers/`.
- **MinerU rejected**: cannot install on Python 3.14 (proven by `pip install --dry-run`),
  and its licence adds a USD 20 M monthly-revenue commercial threshold (D-14).
- **Docling adopted** as an optional dependency via `docling-slim[format-*]` — MIT, runs on
  3.14, installs with no torch and no model downloads.
- **Unstructured rejected** as a dependency (needs libmagic/poppler/tesseract/LibreOffice);
  two algorithms reimplemented and credited.
- **Excel is never delegated** — docling discards cell formulas (D-15).

**Built** — `scripts/udu/`: `model.py` (canonical IR with `basis` + provenance on every
element), `security.py` (size/zip-bomb/traversal guards, injection scan + fencing),
`spreadsheet.py` (regions, row roles, hierarchical headers, column semantics, formula
dependencies), `adapters.py` (detection + one builder per format + docling bridge),
`compile.py` (AI context compiler + Markdown), `chunk.py` (structural chunking), plus the
`document_understand.py` CLI with 11 commands, a debug mode with 13 stages and a validation
gate. 7 bundled references, a JSON Schema, 5 docs, 3 research documents.

**Verified** — 53 new tests pass; the 34 pre-existing document/portfolio tests still pass;
full suite 143 tests with the same 2 pre-existing `test_crash_configuration` RSU-inversion
failures; agent validator 12/12; portfolio registry passed; all JSON parses; protected paths
**zero drift** (4,527 before and after). End-to-end on a real requirements workbook: 7,409
elements, 228 chunks, validation passed.

**Four defects found by testing, all fixed and logged as rules** — header band cut off by
numeric-looking year labels; compiled rows keyed by non-unique header labels (silently
reported the wrong number); text-only regions emitting only their anchor cell (dropped the
passage the injection scanner most needed); non-ASCII output crashing on Windows cp1252.

**Known gaps, reported not faked** — chart series extraction, math formula recognition, PDF
table cell structure, DOCX headers/footers/footnotes, legacy `.doc`/`.xls` without docling.
