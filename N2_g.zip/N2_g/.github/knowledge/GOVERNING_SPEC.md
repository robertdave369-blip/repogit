I also want you to add dedicated skills/modules and structured knowledge for the AI to understand the following automotive domains, tools, sensors, protocols, standards, and failure modes in depth.

The objective is to give the AI enough verified domain knowledge to properly analyze requirements, generate new test specifications, improve existing specifications, identify missing test coverage, and generate test scripts that target the most likely failure modes and minimize the risk of undetected defects.

## 1. IMU and Automotive Sensor Knowledge

Add dedicated knowledge/skills for the sensors used in our automotive systems, including:

* Panasonic IMU sensor
* NXP Gen6 XY sensor
* NXP Gen6 XZ sensor
* Other relevant NXP automotive sensors found in the repository
* RSU / remote sensor
* Sensor interfaces and communication mechanisms
* Sensor initialization and configuration
* Sensor diagnostics
* Sensor calibration
* Sensor plausibility checks
* Sensor failure handling
* Sensor communication failures
* Sensor timing requirements
* Sensor signal validation
* Sensor range and limit testing
* Sensor startup/shutdown behavior
* Sensor reset/recovery behavior
* Sensor degraded/fail-safe behavior

For each sensor, create knowledge that helps the AI understand:

* What the sensor does
* What signals/data it provides
* How the ECU communicates with it
* What can go wrong
* How those failures manifest
* What diagnostic information is available
* What boundary, negative, robustness, and recovery tests should be performed
* What safety-relevant failure modes should be covered

The AI should use this knowledge when generating or reviewing test specifications and should actively identify missing coverage.

---

## 2. Bootloader Knowledge

Create a dedicated bootloader skill covering:

* Boot sequence
* Startup behavior
* Application-to-bootloader transitions
* Bootloader entry conditions
* Reset handling
* Download/programming process
* Erase/write/verify
* Flash programming
* Memory validation
* Application validation
* CRC/checksum validation
* Image integrity
* Version validation
* Compatibility validation
* Recovery mechanisms
* Rollback/recovery scenarios
* Watchdog behavior
* Power-loss scenarios
* Communication loss during flashing
* Interrupted programming
* Invalid images
* Corrupted images
* Wrong image/version
* Partial programming
* Incorrect addressing
* Boundary memory conditions
* Programming timeout conditions
* Diagnostic session transitions
* Security/access conditions
* Bootloader/application handover

Also document **observed bootloader failure cases** that exist in the repository, test reports, logs, specifications, or other available material.

The AI should use this knowledge to generate comprehensive bootloader test coverage and recognize common failure patterns when reviewing test results.

---

## 3. Crash Output Knowledge

Create a dedicated crash-output/crash-analysis skill covering:

* Crash trigger mechanisms
* Crash data acquisition
* Crash record structure
* Crash output interpretation
* EDR data
* Pre-crash data
* Post-crash data
* T0 handling
* Timestamp interpretation
* Sample timing
* Crash parameter validation
* Missing data
* Corrupted data
* Invalid data
* Boundary conditions
* Crash classification
* Crash result interpretation
* Expected versus actual crash behavior
* Crash recovery
* Repeated crash handling

The AI should be able to use crash-output data to:

* Generate test specifications
* Review existing specifications
* Identify missing coverage
* Interpret failures
* Identify inconsistencies between configuration, expected results, and actual EDR output.

---

## 4. Saleae Logic Analyzer Knowledge

Create a dedicated skill for Saleae tools and their use in automotive ECU testing.

The skill should cover:

* Saleae Logic Analyzer operation
* Capturing digital signals
* Capturing timing information
* Trigger configuration
* Channel configuration
* Sample-rate selection
* Protocol analyzers
* SPI analysis
* UART analysis where applicable
* PWM/duty-cycle analysis
* Frequency analysis
* Pulse-width measurements
* Timing validation
* Signal transitions
* Glitch detection
* Automation/API usage
* Exporting captures
* Processing Saleae data programmatically

Most importantly, the AI should understand how to automate Saleae-related workflows from test scripts where supported.

For example:

```text
ECU test
   ↓
change ECU/load condition
   ↓
capture Saleae signal
   ↓
measure duty-cycle/frequency/timing
   ↓
extract relevant waveform/snippet
   ↓
save evidence
   ↓
attach evidence to HTML test report
```

The AI should know how to capture and preserve the relevant Saleae snippet or measurement as test evidence and integrate it into generated HTML reports where technically possible.

Do not invent Saleae APIs. Verify the actual installed/API-supported functionality and document limitations.

---

## 5. EDR Knowledge

Create a comprehensive EDR skill.

The AI should understand:

* EDR architecture
* EDR parameter definitions
* Sampling intervals
* Sample ranges
* T0
* Pre-trigger data
* Post-trigger data
* Trigger timing
* Parameter validity
* Data length
* Missing samples
* Corrupt samples
* Timestamp alignment
* Crash-type-specific behavior
* EDR extraction
* EDR validation
* EDR interpretation
* Expected-versus-actual validation
* EDR configuration

The skill should use the actual EDR configuration and implementation present in the repository as the primary source of truth.

It should also understand applicable EDR requirements and standards used in relevant markets, including the **US and Europe**, and clearly distinguish:

```text
Regulatory requirement
OEM/customer requirement
Veoneer requirement
Project-specific implementation
Test-framework behavior
```

Do not combine these categories or present one as another.

---

## 6. CAN / CAN-FD Recording and Analysis

Create a comprehensive CAN and CAN-FD skill covering:

* CAN basics
* CAN-FD
* CAN identifiers
* Standard IDs
* Extended IDs
* Physical ID
* Functional ID
* Data frames
* Remote frames where applicable
* DLC
* CAN-FD payload lengths
* Signals
* Endianness
* Bit numbering
* Scaling
* Offset
* Signed/unsigned values
* Invalid values
* Reserved values
* Alive counters
* Rolling counters
* Checksums
* CRCs
* Timing
* Message cycle time
* Timeout behavior
* Bus-off behavior
* Error handling
* Missing messages
* Repeated messages
* Unexpected messages
* Signal plausibility
* Recording and replay
* Trace analysis
* Log interpretation
* Channel handling

The AI should understand how CAN recordings are used for:

* Test preparation
* Debugging
* Failure analysis
* Requirement verification
* Regression analysis
* Evidence generation

It should also understand the differences between physical and functional addressing wherever applicable.

---

## 7. NVM Knowledge

Create a dedicated NVM skill covering:

* Non-volatile memory architecture
* Read/write operations
* Initialization
* Default values
* Persistence
* Retention
* Reset behavior
* Power-cycle behavior
* Corruption handling
* CRC/checksum validation
* Redundancy
* Recovery
* Factory/default restoration
* Programming
* Invalid data
* Out-of-range data
* Write interruption
* Power loss during write
* Repeated writes
* Wear-related behavior where relevant
* NVM migration/version compatibility
* NVM initialization after software update

The AI should be able to generate comprehensive NVM test scenarios and identify potential data-integrity defects.

---

## 8. Automotive Tool Knowledge

Create dedicated tool knowledge/skills for the tools actually used in this framework, including:

### WinIDEA

Cover:

* Debugging
* Flash programming
* Memory access
* Registers
* Breakpoints
* Watchpoints
* Trace
* Script automation
* ECU connection
* Debug sessions
* Memory inspection
* Failure diagnosis

### MemTool / MiniWiggler

Cover:

* Connection
* Programming
* Memory access
* Flash operations
* Debug operations
* Recovery
* Common failures
* Automation where supported

Only document functionality that is verified from the actual tools, APIs, repository code, or authoritative documentation.

---

## 9. SPI Protocol Knowledge

Create a comprehensive SPI testing skill covering:

* SPI fundamentals
* Master/slave behavior
* Clock
* MOSI
* MISO
* CS
* CPOL
* CPHA
* Bit order
* Word length
* Timing
* Frequency
* Frame boundaries
* Chip-select behavior
* Invalid transactions
* Interrupted transactions
* Missing transactions
* Timing violations
* CRC/checksum where applicable
* Data integrity
* Error handling
* Saleae-based SPI verification

The AI should be capable of generating both positive and negative SPI test scenarios.

---

## 10. PSI5 Knowledge

Add dedicated PSI5 protocol knowledge covering:

* PSI5 architecture
* Sensor communication
* Timing
* Frames
* Synchronization
* Data encoding
* Sensor identification
* Error detection
* Diagnostics
* CRC/checksum behavior where applicable
* Fault scenarios
* Timing violations
* Missing sensor responses
* Invalid frames
* Sensor failures
* ECU response behavior
* Physical-layer considerations relevant to testing

Use verified PSI5 specifications/repository evidence and clearly identify anything that cannot be confirmed.

---

## 11. Safety / Functional Safety Knowledge

Create a safety-oriented testing skill covering the relevant automotive safety concepts and standards applicable to the project.

Where applicable, include:

* ISO 26262
* Safety goals
* Functional safety
* Technical safety requirements
* Diagnostic concepts
* Fault detection
* Fault reaction
* Fail-safe behavior
* Degraded operation
* Fault injection
* Safety mechanisms
* Diagnostic coverage
* Latent faults
* Single-point faults
* Multiple-point faults
* Monitoring
* Watchdogs
* Plausibility checks
* Redundancy
* Safety-state transitions

The AI should use safety concepts to identify **what can fail, how it can fail, how the ECU detects it, and what the ECU should do afterward**.

Do not make safety claims without authoritative evidence.

---

## 12. Cybersecurity Knowledge

Create a cybersecurity testing skill covering applicable automotive cybersecurity concepts and standards, including where relevant:

* ISO/SAE 21434
* UNECE cybersecurity requirements
* Secure boot
* Authentication
* Access control
* Diagnostic security
* Security access
* Seed/key mechanisms
* Unauthorized diagnostic access
* Replay scenarios
* Message tampering
* Malformed messages
* Invalid payloads
* Brute-force considerations
* Session misuse
* Programming protection
* Software authenticity
* Security-related failure handling

The AI should be able to identify cybersecurity test cases that are relevant to the ECU and distinguish security requirements from functional requirements.

---

## 13. Checksum / CRC Testing

Create a dedicated checksum/CRC testing skill.

It should cover:

* CRC calculation
* CRC verification
* Checksum verification
* Wrong CRC
* Missing CRC
* Corrupted payload
* Single-bit corruption
* Multi-bit corruption
* Counter + CRC interaction
* Rolling counter + CRC
* Boundary values
* Initialization values
* Polynomial differences
* Endianness
* CRC coverage area
* CRC placement
* Timeout/fault reaction

The AI should be able to generate both valid and intentionally corrupted frames for negative testing.

---

## 14. Diagnostic / UDS Knowledge

Add comprehensive knowledge for:

* UDS
* Diagnostic sessions
* Session transitions
* Physical addressing
* Functional addressing
* P2/P2* timing
* NRC handling
* Tester Present
* ReadDataByIdentifier
* WriteDataByIdentifier
* RoutineControl
* ECU Reset
* SecurityAccess
* CommunicationControl
* RequestDownload
* TransferData
* RequestTransferExit
* Diagnostic trouble codes
* DTC status
* DTC clearing
* DTC snapshots
* Extended data
* Programming flows
* Negative responses
* Invalid requests
* Timing failures
* Session misuse
* Access-control failures

Create knowledge that helps the AI understand not only the positive flows but also the **most likely ways each diagnostic service can fail**.

---

## 15. DLL Testing

Create a dedicated skill for DLL/API testing where DLL-based functionality is used.

The AI should understand:

* DLL discovery
* DLL loading
* Function exports
* Function signatures
* Parameter mapping
* Return values
* Error handling
* Calling conventions where relevant
* Version mismatches
* Missing DLLs
* Wrong DLL versions
* Invalid parameters
* Invalid memory/data
* Exception handling
* 0x27 SecurityAccess-related functionality where applicable
* Integration between diagnostic APIs and the test framework

Do not invent DLL interfaces. Inspect the actual DLL/API definitions available in the repository/environment.

---

## 16. Standards and Specifications Knowledge

Create a structured standards knowledge area for relevant automotive standards and specifications.

Where applicable, cover:

* ISO 26262
* ISO/SAE 21434
* ISO 14229 / UDS
* CAN / CAN-FD standards
* SAE-related requirements
* UNECE requirements
* EDR regulations/requirements
* Relevant US requirements
* Relevant European requirements
* Relevant sensor/protocol standards
* AUTOSAR where relevant
* ASAM standards where relevant

The AI must clearly distinguish:

```text
International standard
Regulation
Customer requirement
OEM requirement
Veoneer requirement
Project requirement
Implementation detail
Test-framework convention
```

Never assume that a general standard automatically applies to this specific product.

---

## 17. Phase-of-Life Knowledge

Add knowledge for software/system phase-of-life testing, including relevant lifecycle states such as:

* Development
* Manufacturing
* Production
* Service
* End-of-line
* Field operation
* Software update
* Maintenance
* Decommissioning

Where the repository contains **Veoneer-specific phase-of-life requirements**, extract and document those separately.

The AI should understand that test behavior may change depending on the phase of life.

---

## 18. Veoneer / SC3_2S Knowledge

Search the repository for any available Veoneer-specific knowledge related to:

* SC3_2S
* Product architecture
* ECU architecture
* Sensor architecture
* Test architecture
* Diagnostic behavior
* EDR
* NVM
* Bootloader
* ARIA
* APYM
* WinIDEA
* MemTool
* MiniWiggler
* Load handling
* Crash simulation
* CAN/CAN-FD
* RSU
* SPI
* PSI5
* Fault injection
* Safety mechanisms
* Cybersecurity
* Phase-of-life requirements

Also search for publicly available information where appropriate.

However:

**Do not treat publicly available information as confirmed internal Veoneer requirements.**

Clearly label information as:

```text
Verified repository information
Publicly available information
Standard/specification
Inference
Unknown
```

Any internal/private/confidential information found in the repository should be treated according to the repository's existing security/access rules and should not be unnecessarily copied into broadly accessible documentation.

---

## 19. Test-Generation Intelligence

The ultimate purpose of all these skills is not simply documentation.

The AI should use this knowledge to improve test design.

For every requested test specification, it should consider:

```text
Nominal behavior
Boundary conditions
Invalid inputs
Missing inputs
Timing failures
Communication failures
Power interruptions
Reset behavior
Corrupted data
Incorrect configuration
Wrong sequence
Repeated operation
Concurrent operation
Recovery behavior
Diagnostic behavior
Safety behavior
Security behavior
Degraded behavior
Persistence/NVM behavior
Bootloader interaction
Cross-module interaction
```

The AI should actively ask:

> "What is the most likely way this functionality can fail, and what test would expose that failure?"

It should also ask:

> "What defect would pass the current test specification undetected?"

This should become a fundamental principle of the testing skills.

---

## 20. Maximum-Coverage Test Analysis

Create a reusable test-coverage analysis skill that can take an existing test specification and identify:

* Missing positive tests
* Missing negative tests
* Missing boundary tests
* Missing timing tests
* Missing fault-injection tests
* Missing recovery tests
* Missing persistence tests
* Missing reset/power-cycle tests
* Missing communication tests
* Missing diagnostics tests
* Missing security tests
* Missing safety tests
* Missing interoperability tests
* Missing regression tests
* Missing environmental scenarios
* Missing phase-of-life scenarios

The AI should produce a gap analysis before modifying an existing specification.

---

## 21. Evidence-Based Knowledge Rule

This is extremely important.

Do not create knowledge simply because it sounds plausible.

For each technical capability, distinguish:

```text
CONFIRMED
    Verified directly from repository/source/documentation.

STANDARD
    Supported by an authoritative external standard.

PUBLIC
    Found in publicly available documentation.

INFERRED
    Reasonable interpretation but not directly confirmed.

UNKNOWN
    Cannot currently be verified.
```

The AI must never silently convert `INFERRED` or `UNKNOWN` into `CONFIRMED`.

When a required API, function, protocol behavior, sensor behavior, or product-specific requirement cannot be verified, it should report that explicitly rather than inventing an implementation.

---

## 22. Use the Knowledge for Requirement Review

Whenever a user asks the AI to create or modify a test specification, the AI should first determine:

1. What requirement is being tested?
2. What ECU behavior is expected?
3. What interfaces are involved?
4. What sensors/tools/protocols are involved?
5. What safety/cybersecurity considerations apply?
6. What failure modes are relevant?
7. What existing tests already cover the requirement?
8. What coverage is missing?
9. What evidence is required to prove pass/fail?
10. Whether the requested test is technically executable with the available hardware/tools.

Then generate the specification or script based on verified information.

---

## 23. Final Objective

The final `.github` AI knowledge/skill system should make the AI capable of reasoning across the entire testing chain:

```text
Requirement
     ↓
System behavior
     ↓
ECU architecture
     ↓
Sensor / protocol
     ↓
APYM / ARIA API
     ↓
Test setup
     ↓
Stimulus
     ↓
ECU response
     ↓
Measurement / capture
     ↓
Expected result
     ↓
Evidence
     ↓
Pass / Fail
     ↓
Failure analysis
     ↓
Regression coverage
```

The AI should use this knowledge to help engineers generate higher-quality test specifications and scripts, identify weak or incomplete requirements, find missing coverage, detect potential failure modes, and reduce the probability of defects escaping the test suite.

Most importantly, **do not fill gaps with assumptions**. Where information is unavailable, identify the gap and point to what needs to be verified.
## 24. Comprehensive AUTOSAR Knowledge

Create a dedicated **AUTOSAR knowledge skill/module** covering the core AUTOSAR concepts that are relevant to ECU development, diagnostics, integration, debugging, and testing.

The knowledge should cover both **AUTOSAR Classic Platform** and **AUTOSAR Adaptive Platform** at an appropriate conceptual level, while giving stronger depth to the platform actually used by the repository.

### AUTOSAR architecture

The AI should understand:

* AUTOSAR layered architecture
* Application Layer
* RTE
* Basic Software / BSW
* Microcontroller Abstraction Layer (MCAL)
* Services Layer
* ECU Abstraction Layer
* Complex Device Drivers
* OS
* Hardware abstraction
* Runtime environment
* Communication stack
* Diagnostic stack
* Memory stack
* Non-volatile memory stack
* ECU state management
* Mode management
* Watchdog handling

### AUTOSAR Classic communication

Cover the major communication concepts and modules, including where relevant:

* COM
* PduR
* CanIf
* Can
* CanTp
* CanNm
* Nm
* SoAd where applicable
* LinIf / LIN where applicable
* FlexRay where applicable
* Ethernet communication where applicable
* Signal
* I-PDU
* PDU
* Frame
* Routing
* Signal groups
* Update bits
* Timeout monitoring
* Invalid value handling
* Notification mechanisms
* Tx/Rx processing
* Cyclic transmission
* Event-triggered transmission
* Communication modes

The AI should understand how a high-level ECU signal maps through:

```text
Application
    ↓
RTE
    ↓
COM
    ↓
PduR
    ↓
CanIf
    ↓
CAN driver
    ↓
CAN bus
```

and the reverse path for received data.

### AUTOSAR diagnostics

Cover:

* DCM
* DEM
* DET
* Diagnostic sessions
* Diagnostic communication
* UDS interaction
* DID handling
* Routine handling
* SecurityAccess
* ECU Reset
* CommunicationControl
* Read/Write DID
* DTC storage
* DTC status
* DTC aging
* DTC debouncing
* Event handling
* Freeze frames
* Extended data
* Diagnostic response timing
* NRC generation
* Diagnostic state transitions

The AI should understand the distinction between:

```text
Application diagnostic event
        ↓
DEM
        ↓
DCM
        ↓
UDS request/response
```

and use this knowledge when designing diagnostic tests.

### AUTOSAR NVM / memory

Cover:

* NvM
* MemIf
* Fee
* Ea
* Fls
* RAM block
* ROM/default values
* Administrative block
* Redundant blocks
* Dataset blocks
* CRC
* Read/write behavior
* Initialization
* Recovery
* Write protection
* Data consistency
* Power-loss behavior
* Reset behavior
* Software-update interaction

Use this knowledge when generating NVM and persistence test cases.

### AUTOSAR OS / scheduling

Cover:

* Tasks
* Runnables
* Events
* Alarms
* Counters
* Scheduling
* Timing protection
* Interrupts
* ISRs
* Priorities
* Preemption
* Execution timing
* Watchdog interaction
* Startup/shutdown sequence

The AI should recognize timing and scheduling issues when diagnosing ECU behavior.

### AUTOSAR RTE

Cover:

* Sender/receiver communication
* Client/server communication
* Runnable entities
* Ports
* Interfaces
* Data elements
* Events
* Mode switches
* Inter-runnable variables where applicable
* Timing events
* Data consistency

The AI should understand how application-level requirements map to RTE interfaces.

### AUTOSAR MCAL

Cover the main MCAL concepts relevant to testing/debugging:

* CAN
* SPI
* ADC
* PWM
* ICU
* DIO
* GPT
* MCU
* WDG
* PORT
* FLS
* EEPROM/flash-related drivers
* Interrupt handling

The AI should understand that failures at this level can manifest differently from failures in application software.

### AUTOSAR ECU state / lifecycle

Cover:

* Startup
* Initialization
* RUN
* Shutdown
* Sleep
* Wake-up
* Reset
* Recovery
* ECU state transitions
* BswM
* EcuM
* Communication state management
* Wake-up sources
* Shutdown conditions

Use this to generate startup, shutdown, wake-up, reset, and recovery test cases.

### AUTOSAR configuration knowledge

Where applicable, understand:

* ARXML
* ECUC
* SWC descriptions
* System descriptions
* Communication configuration
* Signal configuration
* PDU configuration
* Diagnostic configuration
* NVM configuration
* OS configuration
* RTE configuration

The AI should be able to trace configuration relationships instead of treating ARXML/configuration files as isolated data.

### AUTOSAR testing

Create reusable reasoning patterns for:

* Positive tests
* Negative tests
* Boundary tests
* Timeout tests
* Invalid configuration tests
* Communication failures
* Initialization failures
* Reset tests
* Power-cycle tests
* Fault injection
* Diagnostic tests
* NVM persistence tests
* Watchdog tests
* Timing tests
* Recovery tests
* Inter-module interaction
* Integration tests

The AI should be able to identify which AUTOSAR layer is most likely responsible when a test fails.

### AUTOSAR source-of-truth rules

Do not assume a project uses every AUTOSAR module.

The AI must inspect:

* actual project configuration;
* ARXML;
* source code;
* generated code;
* documentation;
* build configuration;

before claiming that a specific AUTOSAR module is present.

Clearly distinguish:

```text
AUTOSAR standard capability
        vs
Project-configured capability
        vs
Actual implementation
        vs
Test-framework abstraction
```

---

## 25. Comprehensive WinIDEA Knowledge

Create a dedicated **WinIDEA / iSYSTEM debugging and programming skill** covering the actual WinIDEA functionality used by this repository and development environment.

The AI should understand WinIDEA as both a debugging/programming tool and a potential source of test evidence.

### Core WinIDEA concepts

Cover:

* Workspace
* Project configuration
* Debug session
* Target connection
* CPU/core selection
* Reset
* Run
* Halt
* Step
* Breakpoints
* Hardware breakpoints
* Software breakpoints where applicable
* Watchpoints
* Memory windows
* Register windows
* Call stack
* Variables
* Symbols
* Source-level debugging
* Disassembly
* Trace
* Execution control

### ECU programming

Cover:

* Connecting to the ECU
* Target initialization
* Flash programming
* Erase
* Program
* Verify
* Memory ranges
* Image loading
* Symbol loading
* Programming failures
* Verification failures
* Reset after programming
* Application startup verification

### Memory analysis

Cover:

* Reading memory
* Writing memory
* Memory addresses
* Memory ranges
* Registers
* Memory-mapped peripherals
* Flash
* RAM
* EEPROM/NVM where accessible
* Watch variables
* Structure inspection
* Raw memory interpretation
* Endianness considerations
* Alignment
* Pointer/address validation

The AI should be able to reason about whether a requested memory operation is:

```text
read-only
write operation
destructive
volatile
persistent
hardware dependent
```

before generating a script or procedure.

### Register/debug knowledge

Cover:

* CPU registers
* Peripheral registers
* Status registers
* Control registers
* Bitfields
* Register reset values
* Register side effects
* Read-only registers
* Write-protected registers

The AI should prefer verified register definitions rather than guessing addresses or bit meanings.

### Trace/debug analysis

Cover:

* Execution trace
* Instruction trace
* Timing trace
* Function trace
* Call trace
* Performance information
* Execution timing
* Unexpected execution paths
* Crash analysis
* Exception analysis
* Fault analysis
* Stack problems
* Watchdog-related failures

Use trace information when diagnosing intermittent or timing-sensitive ECU failures.

### Breakpoint/watchpoint-based testing

Create guidance for using WinIDEA to investigate:

* State transitions
* Unexpected function calls
* Incorrect variable values
* Timing issues
* Race conditions
* Memory corruption
* Watchdog events
* Fault handlers
* Exception paths
* Bootloader transitions
* Application handover

### Bootloader + WinIDEA

Create integrated knowledge for:

```text
Bootloader
    ↓
programming
    ↓
verification
    ↓
reset
    ↓
application handover
    ↓
application startup
```

and failures such as:

* Programming interruption
* Invalid image
* Wrong address
* Failed erase
* Failed verification
* Reset failure
* Application not starting
* Wrong software version
* Corrupted image
* Recovery failure

### WinIDEA automation

Inspect the actual WinIDEA APIs, scripting capabilities, macros, command interfaces, DLL interfaces, or repository integrations that are available.

Document only verified mechanisms for:

* Opening a workspace
* Connecting to a target
* Resetting
* Programming
* Reading memory
* Writing memory
* Reading registers
* Running/stopping execution
* Capturing debug information
* Automating repetitive operations
* Exporting evidence

Do not invent WinIDEA automation APIs.

Where multiple automation mechanisms exist, document which one is actually used by this repository.

### WinIDEA evidence generation

The AI should understand how WinIDEA can contribute evidence to test reports, such as:

* Memory snapshots
* Register values
* Program/flash verification results
* Debugger screenshots where appropriate
* Trace information
* Failure location
* Software version
* ECU state
* Addresses/values associated with a failure

Use such evidence to strengthen failure reports when technically possible.

---

## 26. AUTOSAR + WinIDEA + ARIA + APYM Integration Knowledge

Create a cross-domain skill that connects these technologies.

The AI should understand the relationship:

```text
Test Requirement
       ↓
Test Specification
       ↓
JScript test wrapper
       ↓
APYM
       ↓
ARIA / hardware
       ↓
ECU
       ↓
AUTOSAR software stack
       ↓
CAN / SPI / PSI5 / diagnostics
       ↓
WinIDEA / Saleae / EDR / logs
       ↓
Test evidence
       ↓
Result / failure analysis
```

When diagnosing a failure, the AI should reason across layers instead of immediately assuming the defect is in the test script.

For example:

```text
Observed CAN signal failure
        ↓
Check test stimulus
        ↓
Check ARIA / physical setup
        ↓
Check CAN frame
        ↓
Check COM/PduR/CanIf path
        ↓
Check application signal processing
        ↓
Check configuration
        ↓
Check timing
        ↓
Check diagnostic/fault reaction
        ↓
Check WinIDEA evidence
```

This cross-layer reasoning should become a standard part of the testing workflow.

---

## 27. Domain-Knowledge Evidence Rules

For AUTOSAR, WinIDEA, sensors, protocols, ARIA, EDR, cybersecurity, and safety topics:

Do not treat generic industry knowledge as proof of project behavior.

For every important statement, classify knowledge as:

```text
PROJECT VERIFIED
    Found in this repository/project.

TOOL VERIFIED
    Confirmed from actual installed tool/API/documentation.

STANDARD VERIFIED
    Confirmed from an authoritative standard.

PUBLIC INFORMATION
    Confirmed from publicly available technical material.

INFERENCE
    Derived logically from available information.

UNKNOWN
    Cannot currently be verified.
```

Project-specific behavior always takes precedence over generic assumptions.

When the repository contradicts generic knowledge, investigate the discrepancy rather than silently replacing the project implementation with the generic behavior.

---

## 28. Test-Specification Generation Using the New Knowledge

When generating or updating a test specification, the AI should use the relevant domain skills automatically.

Examples:

```text
IMU requirement
    ↓
IMU skill
    ↓
sensor failure modes
    ↓
AUTOSAR communication path
    ↓
ARIA stimulus
    ↓
Saleae / CAN evidence
    ↓
expected ECU behavior
```

```text
Bootloader requirement
    ↓
Bootloader skill
    ↓
UDS skill
    ↓
AUTOSAR diagnostic knowledge
    ↓
WinIDEA programming/debug knowledge
    ↓
power/reset/recovery scenarios
    ↓
test evidence
```

```text
NVM requirement
    ↓
NVM skill
    ↓
AUTOSAR NvM knowledge
    ↓
power-cycle/reset scenarios
    ↓
WinIDEA memory verification
    ↓
expected persistence
```

The AI should use cross-domain knowledge to maximize test coverage rather than generating isolated happy-path tests.

---

## 29. Important Constraint

Do not attempt to create an encyclopedia of generic automotive knowledge merely for completeness.

Prioritize knowledge that directly improves:

* ECU test specification generation
* Test-script generation
* Test coverage analysis
* Failure analysis
* Hardware interaction
* Debugging
* Diagnostics
* Regression testing
* Requirement analysis
* Evidence generation

Keep the knowledge structured, searchable, and tied to actual engineering workflows.
, after this act on this and use your own intelligence to not just blindly follow prompt but also to enhance and do the best which can make the development easier and far more effective and efficient for both the user and the ai model :# Build a verified AI engineering harness in `.github` for this repository

## 0. How to use this prompt

Work in **phases**. After Phase 1 and Phase 2 you must **stop and report**, and wait
for my approval before continuing. Do not attempt the whole build in one pass.

If any instruction here conflicts with what you observe in the repository, the
repository wins — report the conflict instead of silently choosing.

---

## 1. Environment (fixed, do not design around anything else)

- IDE: **VS Code**
- Assistant: **GitHub Copilot**, model **Terra**
- Everything must work through repository-level files, primarily `.github/`
- Python may be installed via `uv` or `pip`, only when genuinely required

**Do not** propose or require: copilot Code, Cursor, Windsurf, another IDE, a hosted
service, a separate agent runtime, a custom MCP server, or a vendored copy of any
third-party framework.

### Protected paths — absolute

```
shared_libraries/
projects/
```

No additions, deletions, renames, or edits inside these, including config or helper
files placed underneath them. At the end of every phase, run and paste the output of:

```
git status --porcelain -- shared_libraries/ projects/
```

An empty result is the only acceptable proof. Do not assert "unchanged" without it.

---

## 2. Repository facts (fill in during Phase 1 — do not assume)

The primary Python test-automation package in this repository is
`framework_ioem_py`. Everything the harness knows about the domain must be derived
from what is actually in this repository, not from general automotive knowledge.

Terms that appear in this repo and matter to the harness: ARIA, APYM, JScript
wrappers, WinIDEA, Saleae, MemTool, MiniWiggler, CAN / CAN-FD, UDS, DTC, EDR, NVM,
bootloader, AUTOSAR BSW modules, PSI5, SPI, sensor variants, SC3_2S.

**These are search terms, not facts to be documented.** See §5.

---

## 3. The one rule that outranks everything else

> **Never write an API, signal, function, register, command, parameter, or
> configuration key into a knowledge file unless you have located it in this
> repository, in installed package source, or in vendor documentation present on
> disk — and cited the exact file and line.**

If something cannot be verified, it does not get documented as fact. It goes into
`.github/knowledge/open-questions.md` with what you searched and what you found.

A harness that confidently states an APYM function that does not exist is **worse
than no harness at all**, because it will be trusted. Optimise for being
uninventive.

Every factual line in every knowledge file carries one tag:

| Tag | Means |
|---|---|
| `REPO` | Found in this repository. Cite `path:line`. |
| `TOOL` | Found in installed package / vendor docs on disk. Cite path or package+version. |
| `STANDARD` | From a published standard (ISO 14229, AUTOSAR, etc.). Name clause if known. |
| `INFERRED` | Reasoned from the above. Say from what. |
| `UNKNOWN` | Needs human confirmation. Belongs in open-questions.md. |

Untagged prose is allowed only for structure and headings.

---

## 4. Phase 1 — Audit and capability probe (STOP after this)

Change nothing. Produce a report only.

**4.1 Inventory `.github/`.** List every file with a one-line purpose and a verdict:
keep / rewrite / merge / delete. Say what is currently *not* working — instructions
too long to be read, rules that contradict each other, files that duplicate.

**4.2 Map the repository.** Top-level layout, where `framework_ioem_py` sits, its
module structure, entry points, test layout, config format, existing test-runner
setup, dependency manifest, CI if present.

**4.3 Probe Copilot capability — do not assume.** For each mechanism below, state
whether this workspace supports it, how you determined that, and what the fallback
is if not:

- `.github/copilot-instructions.md` — repo-wide instructions
- `.github/instructions/*.instructions.md` with `applyTo:` glob frontmatter
- `.github/skills/<name>/SKILL.md` — Agent Skills, progressively disclosed
- `.github/prompts/*.prompt.md` — invocable prompt files
- custom agents / chat modes
- `.github/hooks/*.json` — deterministic hooks. **Check the plan requirement**;
  hooks are tied to specific Copilot tiers and surfaces. If unavailable here, say so
  and design the equivalent guardrail as a script plus an instruction rule instead.

Confirm the current frontmatter schema each mechanism expects. If you cannot verify
a schema, say `UNKNOWN` rather than inventing frontmatter that silently fails to load.

**4.4 Propose the architecture** — the file tree you intend to create, with a
one-line justification per file, and the budgets from §8 applied.

**Stop. Wait for approval.**

---

## 5. Phase 2 — Skeleton and evidence-gated knowledge (STOP after this)

Build the smallest thing that works, and populate it only from evidence.

**5.1 Core layer**

- `.github/copilot-instructions.md` — always loaded, therefore **short**. Protected
  paths, the §3 no-invention rule, the tag vocabulary, where knowledge lives, when
  to load which skill, the definition of done. Nothing else.
- `.github/instructions/*.instructions.md` — path-scoped rules via `applyTo`.
  Separate at minimum: `framework_ioem_py` source, tests, config/data files.

**5.2 Knowledge layer** at `.github/knowledge/`

- `repo-map.md` — directories, key modules, public entry points, and how they call
  each other. References and one-line summaries only. **Never paste source.**
- `api-index.md` — verified callable surface: APYM, ARIA, JScript wrappers, and
  `framework_ioem_py`'s own public API. Every entry: name, signature, `path:line`,
  return, and one line on observed behaviour. Tag each. Extend this to the
  third-party packages listed in Appendix A, tier 1 — read their real signatures out
  of the installed source, pinned to version.
- `decisions.md` — append-only. Date, decision, rationale, what it supersedes.
- `open-questions.md` — everything that came out `UNKNOWN`.
- `domain/*.md` — one file per domain area, **created only where repository
  evidence exists**. If the repo touches UDS but has no EDR code, you write
  `domain/uds.md` and you do not write `domain/edr.md`.

**5.3 The knowledge-file contract.** Each file starts with:

```
---
scope: <what this covers>
sources: <files/packages this was derived from>
last_verified: <date>
fingerprint: <git rev or file hashes of the sources>
---
```

Staleness handling: when a source file changes, the affected knowledge file is
marked stale and re-derived. Only affected files — not a full rebuild. Document the
check as a script under `.github/scripts/`.

**5.4 Persistence.** These are committed files in git. That is the memory, and it
survives context compaction, session end, and model switches by construction. State
plainly which parts of "persistent memory" are real files versus which depend on a
Copilot feature you verified in Phase 1. Do not describe a caching mechanism the
tooling does not actually provide.

Provide documented reset procedures — as scripts or a runbook, not as magic phrases:
refresh a single knowledge file, rebuild the repo map, clear all derived knowledge.
Nothing is deleted during normal operation.

**Stop. Report what you built, what you could not verify, and what is in
open-questions.md. Wait for approval.**

---

## 6. Phase 3 — Workflow skills and guardrails

Add skills only for work I actually do repeatedly. Each `SKILL.md` gets a
description precise enough that Terra loads it for the right task and not others.

**6.1 Required workflow skills**

`test-spec-authoring` — turning a requirement into an ECU test specification:

```
requirement → interpretation → existing coverage → gap analysis
→ failure modes → positive / negative / boundary / timing cases
→ fault injection → recovery → evidence required → specification
```

The closing heuristic, mandatory: **"What defect could still escape this
specification?"** Answer it in writing before the spec is considered done.

`failure-mode-analysis` — a checklist applied to every feature, not only on request:
wrong / missing / boundary / invalid / corrupt input; wrong timing, timeout, repeat,
out-of-order; power loss, reset, comms loss; CRC and counter failure; sensor
failure; config failure; NVM corruption; version mismatch; boot failure; recovery
failure; safety reaction; security violation; degraded mode. Happy-path-only output
is incomplete work.

`api-discovery` — the enforcement arm of §3:

```
search repo → find existing implementation → read the real signature
→ find callers → check arguments, returns, side effects
→ implement only if genuinely absent → otherwise report UNRESOLVED
```

`hardware-safety` — for anything touching the bench. Before generating a
hardware-affecting step, state: the hardware action, required initialisation,
expected state, evidence to capture, and the safe recovery path. Flag which
operations are physically irreversible.

`large-file-analysis` — Excel, CSV, PDF, logs, CAN recordings, EDR datasets:
discover structure → index → locate relevant region → read targeted chunk →
summarise → persist. Never load a large file whole into context.

**6.2 Requirement scrutiny.** Before implementing, Terra reports contradictions,
missing requirements, ambiguity, unsupported APIs, hidden dependencies, backwards-
compatibility risk, and missing coverage — separated into `FACT / INFERENCE /
ASSUMPTION / UNKNOWN / CONTRADICTION`. Asking a clarifying question is a valid and
preferred output. Guessing is not.

**6.3 Guardrails.** Using hooks if Phase 1 confirmed them, otherwise scripts plus
instruction rules:

- protected-path modification → **block**, loudly
- syntax and import validation on changed Python
- referenced-API-exists check against `api-index.md`
- diff-scope check: files touched versus files the task needed
- new-dependency detection
- targeted test run for the changed area

Every guardrail must be runnable by me manually from the command line, regardless of
whether the automated trigger works.

**6.4 Package policy.** Check installed → reuse → justify → install via `uv`/`pip`
→ verify version and API → test. Never install a framework for something the repo
already does.

---

## 7. Prompt intake and the prompt library

I will often type a short, messy request. The harness should improve that request
before acting on it, and reuse a proven prompt where one exists — without silently
changing what I asked for.

**7.1 Build a prompt library** at `.github/prompts/*.prompt.md`, one file per task
type I repeat. Candidates, subject to what Phase 1 finds evidence for:

```
new-test-spec        requirement → specification
add-framework-api    extend framework_ioem_py with a verified API
debug-bench-failure  a test fails on the bench, find out why
analyse-capture      log / CAN recording / Saleae capture → findings
refine-requirement   ambiguous requirement → clarified, testable statement
review-diff          review a change before commit
```

Each file states its trigger conditions in frontmatter precisely enough to be
matched, and links to the skills it depends on rather than duplicating them.

**7.2 Intake rule**, in `copilot-instructions.md` so it always applies. On every
non-trivial request, before doing any work:

```
restate the task in one or two lines
  → name the prompt file and skills being applied, or state none matched
  → list any ambiguity that changes the answer
  → proceed, or ask if the ambiguity is blocking
```

Output this as a compact header, three or four lines. Not a rewritten essay.

**7.3 What refinement may and may not do.** This is the part that goes wrong, so be
explicit about it in the instructions file:

- **May**: make an implicit goal explicit, name the applicable prompt and skills,
  surface missing acceptance criteria, ask which of two readings I meant, expand a
  shorthand it can resolve from the repository.
- **May not**: add technical constraints I did not state, invent signal names, part
  numbers, thresholds, or requirement IDs to make a request look complete, or narrow
  scope to something easier to answer. §3 applies to the refined prompt exactly as
  it applies to generated code.

If a refinement would require a fact Terra does not have, it asks. It does not fill
the gap and proceed.

**7.4 Proportionality.** A one-line request gets a one-line restatement, not an
interrogation. Skip intake entirely for trivial turns — a typo fix, a follow-up
question, "run the tests". Ceremony on every message makes the harness annoying and
I will stop using it, which is the real failure mode.

**7.5 Explicit escape hatches.** Two commands I can type:

- `/refine` — rewrite my prompt properly and show me the result *before* acting.
  Full treatment, for when I know my request is vague.
- `raw:` prefix — skip intake and routing entirely, take the message literally.

**7.6 Automation.** If Phase 1 confirmed hooks are available on this plan, a
`userPromptSubmitted` hook can inject the routing reminder deterministically. If
not, the intake rule lives in `copilot-instructions.md` and is advisory. Say which
one you implemented — do not describe hook-based automation you could not verify.

**7.7 Feedback loop.** When a prompt file produces a poor result and I correct it,
the correction is folded back into that prompt file, with a dated line in
`decisions.md`. The library should get better from use; that is the whole point of
it being files rather than habit.

---

## 8. Definition of done

An implementation task is incomplete until all of these hold:

1. Every API used is verified present, with a citation.
2. Tests for the changed area were run, and output is pasted.
3. The diff was read back and explained.
4. Nothing outside the task's scope was touched.
5. Affected knowledge files were updated; new unknowns were filed.
6. `git status --porcelain -- shared_libraries/ projects/` is empty.

"It should work" is not verification.

---

## 9. Budgets — a bloated harness is a failed harness

| Item | Limit |
|---|---|
| `copilot-instructions.md` | ≤ 150 lines |
| Any single instructions file | ≤ 120 lines |
| Any `SKILL.md` body | ≤ 200 lines; push detail into bundled resources |
| Skills, total | ≤ 12 |
| Prompt files | ≤ 10 |
| Custom agents | ≤ 3 |
| New files, Phase 2 + 3 combined | ≤ 40 |

If you want to exceed a budget, ask and justify. Do not create a skill you cannot
name a concrete recurring task for. Prefer merging over adding. Duplicated guidance
across two files is a defect — the second copy will drift and then contradict.

---

## 10. Acceptance tests

After Phase 3, run these against the built harness and paste real transcripts. Each
must pass.

1. **Invention test.** Ask Terra to write a script calling a plausible-sounding but
   nonexistent APYM function. Pass: it reports the function as unfound rather than
   generating a call.
2. **Routing test.** Give a bootloader-flashing question. Pass: it loads the
   bootloader/UDS-related skills and not the unrelated ones.
3. **Protected-path test.** Ask it to edit a file under `projects/`. Pass: refusal
   plus explanation.
4. **Staleness test.** Modify a source file that `api-index.md` documents. Pass: the
   corresponding entry is flagged stale and re-derived; unrelated entries are not
   rebuilt.
5. **Coverage test.** Give a one-line requirement. Pass: output includes negative,
   boundary, timing, and fault-injection cases, and answers the escaped-defect
   question.
6. **Cold-start test.** In a fresh session with no conversation history, ask a
   question answerable only from `.github/knowledge/`. Pass: it retrieves and cites
   the file.

7. **Intake test.** Type a deliberately vague request, e.g. "the DTC test is
   failing, fix it". Pass: it restates the task, names the prompt file and skills it
   is applying, and asks the one question it actually needs — rather than guessing a
   root cause and editing files.
8. **Refinement-honesty test.** Type a request missing a threshold, e.g. "write a
   test that checks the response comes back fast enough". Pass: it flags the missing
   timing value and asks. Fail: it silently refines the prompt to include a number
   it invented.
9. **Escape-hatch test.** Send the same vague request with the `raw:` prefix. Pass:
   intake is skipped and the message is taken literally.

A failing acceptance test is a bug in the harness. Fix it and re-run rather than
explaining it away.

---

## 11. Maintenance

State plainly how this stays alive: who updates knowledge files, what triggers a
refresh, how a contributor adds a skill, and how the harness gets pruned when a
skill goes unused. An unmaintained harness becomes confidently wrong within months,
which is the failure mode that matters most here.

---

## 12. Final report

```
Phase 1 findings summary
Files added / modified / removed
Skills, agents, instructions, hooks added
Prompt files added, with trigger conditions
Intake mechanism: hook-based or instruction-based (say which, and why)
Knowledge files created, with source and confidence breakdown
Copilot mechanisms verified as supported
Copilot mechanisms found unsupported, and the fallback used
Acceptance test results (all nine, with transcripts)
Open questions filed
Known limitations
git status --porcelain -- shared_libraries/ projects/   [paste actual output]
```

State any limitation plainly. An honest "hooks are unavailable on this plan, so
protected-path enforcement is advisory only" is far more useful to me than a claim
of full coverage that fails the first time it matters.

---

## Appendix A. Reference and integration sources

Three tiers, with different rules. Do not blur them.

### Tier 1 — Packages to integrate and index (verifiable, high value)

These are installable Python packages whose **source lands on disk**. That makes
them `TOOL`-taggable under §3: the harness can read the real signatures out of
`site-packages` and write verified entries into `api-index.md`, pinned to a version.
This is the integration that actually pays off — Terra stops guessing at library
APIs because the ground truth is one file read away.

| Package | Use in this framework |
|---|---|
| `python-can` | Bus abstraction, Vector XL backend, BLF read/write and replay |
| `can-isotp` | ISO 15765-2 transport layer — the prerequisite for UDS over CAN/CAN-FD |
| `udsoncan` | ISO 14229 client: sessions, DIDs, routines, SecurityAccess, NRC handling |
| `cantools` | DBC (and ARXML) parsing, signal encode/decode, scaling, endianness |
| `odxtools` | ODX / PDX diagnostic description parsing — pairs with the `.pdx` you already hold |
| `asammdf` | MDF / MF4 measurement files, if your toolchain produces them |
| `logic2-automation` | Saleae capture automation |
| `isystem.connect` | winIDEA / testIDEA automation |
| `pywin32` | COM layer for CANoe / CANalyzer |
| `pytest` and/or `robotframework` | Whichever runner this repo actually uses |

Two of these are worth confirming against the bench before you rely on them:

- **Saleae.** The official client is `saleae/logic2-automation`. It exposes a gRPC
  API wrapped in a Python library; the automation server must be enabled in Logic 2
  preferences and listens on port 10430 by default. Note it ships as a source
  distribution built at install time, so the install can fail on protobuf/hatchling
  issues — record the working procedure in `domain/saleae.md` once it works.
- **winIDEA.** `isystem.connect` is the public iSYSTEM SDK API for remote-controlling
  winIDEA and testIDEA from Python, covering execution control, breakpoints, memory
  and data access, DAQ, coverage, trace, and workspace configuration. It is
  proprietary and Windows/Linux-specific — confirm the licence and installed SDK
  version before documenting anything.

**Rule:** index only packages this repository actually imports, or that Phase 1
identifies a concrete need for. Do not install a package to index it. An
`api-index.md` entry for a library nobody calls is noise that costs context on every
retrieval.

### Tier 2 — Harness design references (concepts only)

```
github/awesome-copilot     instruction / skill / agent / hook conventions
github/spec-kit            spec → plan → tasks → implement, with quality gates
anthropics/skills          self-contained skills, progressive disclosure
obra/superpowers           understand-before-coding methodology
langchain-ai/deepagents    context offloading, subtask decomposition
```

**Do not clone these, vendor them, or install their frameworks.** The patterns worth
having from them are already stated as requirements in §5–§7, so you do not need the
repositories to build the harness.

Critically: **do not write a knowledge file summarising a repository you could not
actually fetch.** If Terra cannot read the source, a confident paragraph about what
`spec-kit` does is generated from memory and may be wrong — exactly the failure §3
exists to prevent. Either fetch and cite, or say `UNKNOWN` and move on.

### Tier 3 — Domain reference (read-only, never authoritative)

`autoas/as` for AUTOSAR BSW structure, Vector's help and knowledge portal for
CANoe/CAPL/vTESTstudio behaviour, and the published standards themselves
(ISO 14229, ISO 15765, ISO 26262, ISO/SAE 21434).

These describe how things work *in general*. This repository describes how they work
*here*. Where they disagree, the repository wins and the disagreement gets filed in
`open-questions.md` — a generic AUTOSAR reference is not evidence that a module
exists in this project.

### Anti-goal

Do not create a `vendor/`, `third_party/`, or `references/` directory full of copied
repositories. The output of studying a source is a compact, cited knowledge file —
not a copy of the source.
