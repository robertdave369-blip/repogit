---
name: embedded-systems-fundamentals
description: 'Use when analyzing or testing embedded airbag ECU behavior involving MCUs, interrupts, memory/NVM, watchdogs, bootloaders, RTOS scheduling, reset/startup, debugging, MiniWiggler or winIDEA-style debug/flash tooling, and flashing workflows in Framework_IOEM_Py. Requires project and tool-specific evidence before proposing actions that change ECU software or hardware state.'
argument-hint: 'Describe the ECU/project, embedded behavior or tool, available artefacts, and desired analysis or test outcome'
user-invocable: true
disable-model-invocation: false
---

# Embedded Systems Fundamentals

## Scope And Safety Boundary

Use this skill to reason about embedded ECU behavior and design safe validation work for MCU startup/reset, interrupts, memory/NVM, watchdog supervision, bootloaders, RTOS tasks, debugging, calibration, and flashing.

Writing or reviewing code is not authorization to attach a debugger, halt an ECU, erase/program memory, change NVM, reset/power-cycle hardware, or flash software. These actions can be irreversible or alter safety-relevant behavior. Do not execute them unless the user explicitly authorizes the specific operation and the target/tool/procedure is verified.

## Core Concepts To Establish

For the target ECU, identify rather than assume:

- MCU/device, cores, clocks, reset sources, startup sequence, linker/memory map, and debug interface.
- Interrupt source, priority, rate, execution budget, shared-state protection, and failure/overrun behavior.
- RAM/Flash/EEPROM or emulated-NVM ownership, integrity checks, initialization, persistence, wear/error handling, and reset behavior.
- Watchdog configuration, service owner, supervision window, fault reaction, reset propagation, diagnostic reporting, and recovery.
- Bootloader/application boundary, image format, compatibility checks, security/authentication, programming sequence, rollback/recovery, and post-flash verification.
- RTOS/static scheduler task priorities, periods, deadlines, resource sharing, latency, startup sequencing, and watchdog interactions.

## Analysis Workflow

1. Identify the target project, ECU hardware/software version, requested function, operating mode, supplied documentation/configuration, and permitted test environment.
2. Separate facts, inferences, and assumptions with provenance. Cross-check requirements, architecture, code, linker/configuration, diagnostic behavior, and logs.
3. Build the execution chain: input/interrupt -> task/handler -> state/memory -> output/network/diagnostic -> recovery. Include reset, power-cycle, and boot transitions when they affect the behavior.
4. For faults, define the fault model, detection method, timing/FTTI allocation if supplied, safety reaction, diagnostic evidence, recovery, and test restoration.
5. Propose the least invasive validation first: static review, configuration consistency check, offline decoder/analysis, simulator, trace/log review, then authorized target execution.
6. Report root cause or change impact only when the chain is supported by evidence; otherwise identify the smallest missing artefact or measurement.

## Debugging And Flashing Tools

`shared_libraries/winidea.py` and `shared_libraries/ascent_batch_lib.py` are framework anchors for existing debugging/flashing workflows. Inspect their current interfaces and project configuration before proposing changes.

For a MiniWiggler or other debug probe, first verify the exact device model, manufacturer documentation, driver/tool version, cable/pinout, target voltage/reference, debug protocol, firmware compatibility, ECU state, and approved project procedure. Do not assume that every tool named “MiniWiggler” has the same connection, reset, security, or flash sequence.

For any flash plan, require a verified image identity/checksum/signature as applicable, target compatibility, power stability, backup/recovery plan, programming log, readback or post-flash identity verification, and rollback/recovery behavior. Never substitute a generic bootloader or debug procedure for the project procedure.

## Portfolio Handoff

For a multi-skill workflow, preserve target hardware/software identity, execution chain, intrusive-action risk, tool/probe evidence, reset/memory/timing behavior, approved procedure, and authorization state. Hand safety impact to `functional-safety-iso26262`, requirement ambiguity to `requirement-based-testing`, and runnable automation boundaries to `python-test-automation`.

## Completion Criteria

The result is complete when the embedded execution chain is project-specific and evidence-backed, relevant reset/memory/timing/safety behavior is considered, tool actions are explicitly authorized and reproducible, and any unknown hardware or flashing detail is marked `Evidence unavailable.`