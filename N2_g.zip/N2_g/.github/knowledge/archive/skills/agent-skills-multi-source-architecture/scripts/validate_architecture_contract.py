"""Validate the documented multi-source Agent Skills architecture contract.

The validator checks this workspace's machine-readable architecture contract. It does not claim to
validate or execute a .NET runtime that is not present in Framework_IOEM_Py.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


CONTRACT_PATH = Path(__file__).resolve().parents[1] / "assets" / "architecture-contract.json"
EXPECTED_BASE_TYPES = {
    "AgentSkill",
    "AgentSkillResource",
    "AgentSkillScript",
    "AgentSkillsSource",
}
EXPECTED_SOURCE_KINDS = {"file", "inline", "class", "custom"}
EXPECTED_SECURITY_CONTROLS = {
    "allowed_extensions",
    "canonical_path_containment",
    "path_traversal_rejection",
    "symlink_containment",
}


def _read_contract(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return payload


def validate_contract(contract: dict[str, Any]) -> list[str]:
    errors: list[str] = []

    if contract.get("schema_version") != 1:
        errors.append("schema_version must be 1.")

    visibility = contract.get("visibility")
    if not isinstance(visibility, dict):
        errors.append("visibility must be an object.")
    else:
        if visibility.get("agent_skill_types") != "internal":
            errors.append("Agent Skill types must remain internal.")
        if visibility.get("public_entry_points") != ["AgentSkillsProvider", "AgentSkillsProviderBuilder"]:
            errors.append("Only AgentSkillsProvider and AgentSkillsProviderBuilder may be public entry points.")

    if set(contract.get("base_types", [])) != EXPECTED_BASE_TYPES:
        errors.append("base_types must contain the four required Agent Skill abstractions.")

    model_tools = contract.get("model_tools")
    if not isinstance(model_tools, dict):
        errors.append("model_tools must be an object.")
    else:
        if set(model_tools.get("required", [])) != {"load_skill", "read_skill_resource"}:
            errors.append("load_skill and read_skill_resource must be required model tools.")
        conditional = model_tools.get("conditional")
        if not isinstance(conditional, dict):
            errors.append("model_tools.conditional must be an object.")
        elif (
            conditional.get("name") != "run_skill_script"
            or conditional.get("when") != "at_least_one_resolved_skill_contains_scripts"
            or conditional.get("omit_instructions_when_unavailable") is not True
        ):
            errors.append("run_skill_script must be conditionally advertised with matching instructions.")

    if set(contract.get("source_kinds", [])) != EXPECTED_SOURCE_KINDS:
        errors.append("source_kinds must support file, inline, class, and custom sources.")

    script_execution = contract.get("script_execution")
    if not isinstance(script_execution, dict):
        errors.append("script_execution must be an object.")
    elif (
        script_execution.get("file_runner") != "external_opt_in_callback"
        or script_execution.get("default_scope") != "provider"
        or set(script_execution.get("override_scopes", [])) != {"file_source", "file_skill"}
        or set(script_execution.get("in_process_kinds", [])) != {"inline", "class"}
    ):
        errors.append("script_execution does not preserve the required file-runner and in-process boundaries.")

    provider = contract.get("provider")
    if not isinstance(provider, dict):
        errors.append("provider must be an object.")
    else:
        deduplicate = provider.get("deduplicate")
        if (
            provider.get("cache_scope") != "provider"
            or set(provider.get("cache_targets", [])) != {"tools", "instructions"}
            or provider.get("filter_scope") != "builder"
            or not isinstance(deduplicate, dict)
            or deduplicate.get("identity") != "frontmatter.name"
            or deduplicate.get("case_sensitive") is not False
            or deduplicate.get("policy") != "first_one_wins"
        ):
            errors.append("provider caching, filtering, or deduplication policy is invalid.")

    if set(contract.get("file_source_security", [])) != EXPECTED_SECURITY_CONTROLS:
        errors.append("file_source_security must include every required containment control.")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the multi-source Agent Skills architecture contract.")
    parser.add_argument("--contract", type=Path, default=CONTRACT_PATH, help="Path to architecture-contract.json")
    args = parser.parse_args()

    try:
        errors = validate_contract(_read_contract(args.contract))
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "failed", "errors": [str(error)]}, indent=2))
        return 1

    print(
        json.dumps(
            {
                "status": "passed" if not errors else "failed",
                "contract": str(args.contract),
                "errors": errors,
            },
            indent=2,
        )
    )
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())