# Multi-Source Agent Skills Contract

## Status And Scope

This is the accepted architecture contract for a future .NET Agent Skills runtime. The code
snippets describe the required implementation shape; they are not a claim that this Python
workspace already contains those assemblies.

**Verified fact:** this workspace exposes skills through filesystem `SKILL.md` packages under
`.github/skills/`.

**Evidence gap:** no C# project, `AgentSkillsProvider`, or `Microsoft.Extensions.AI` implementation
exists in the current workspace.

## Visibility Boundary

The illustrative API snippets may use `public` for readability. In the production implementation,
all Agent Skill model, source, resource, and script classes are `internal` while the feature
matures. The only public entry points are:

- `AgentSkillsProvider` for a single already-composed source without filtering.
- `AgentSkillsProviderBuilder` for mixing sources, filtering, script-runner configuration, approval,
  and prompt customization.

## Required Base Contracts

```csharp
internal abstract class AgentSkill
{
    public abstract AgentSkillFrontmatter Frontmatter { get; }
    public abstract string Content { get; }
    public abstract IReadOnlyList<AgentSkillResource>? Resources { get; }
    public abstract IReadOnlyList<AgentSkillScript>? Scripts { get; }
}

internal abstract class AgentSkillResource
{
    public string Name { get; }
    public string? Description { get; }
    public abstract Task<object?> ReadAsync(
        IServiceProvider? serviceProvider = null,
        CancellationToken cancellationToken = default);
}

internal abstract class AgentSkillScript
{
    public string Name { get; }
    public string? Description { get; }
    public abstract Task<object?> RunAsync(
        AgentSkill skill,
        AIFunctionArguments arguments,
        CancellationToken cancellationToken = default);
}

internal abstract class AgentSkillsSource
{
    public abstract Task<IList<AgentSkill>> GetSkillsAsync(
        CancellationToken cancellationToken = default);
}
```

`AgentSkillFrontmatter` carries `Name`, `Description`, optional `License`, `Compatibility`, and
`AllowedTools`, plus optional metadata. It is the canonical identity and discovery data for a skill.

## Concrete Types

| Concern | Required variants | Required behavior |
| --- | --- | --- |
| File skills | `AgentFileSkill`, `AgentFileSkillResource`, `AgentFileSkillScript`, `AgentFileSkillsSource` | Parse YAML frontmatter and raw Markdown body from `SKILL.md`; discover resources and scripts beneath the skill directory. |
| Programmatic skills | `AgentInlineSkill`, `AgentClassSkill`, `AgentInlineSkillResource`, `AgentInlineSkillScript`, `AgentInMemorySkillsSource` | Support static and delegate-backed resources plus delegate-backed scripts; class skills synthesize their content from metadata, instructions, resources, and scripts. |
| Extensibility | Custom `AgentSkill`, resource, script, and source subclasses | A custom source participates without provider special cases. |

`AgentFileSkillResource.ReadAsync` reads UTF-8 content from its contained `FullPath`.
`AgentFileSkillScript.RunAsync` calls an `AgentFileSkillScriptRunner` and throws
`NotSupportedException` when no executor is configured. The runner receives the owning file skill,
the file script, arguments, and cancellation token.

## Model-Facing Tools

| Tool | Availability | Required delegation |
| --- | --- | --- |
| `load_skill(skillName)` | Always when skills exist | Return the resolved skill body. |
| `read_skill_resource(skillName, resourceName)` | When the resolved skill contains the resource | Call `Resource.ReadAsync()`. |
| `run_skill_script(skillName, scriptName, arguments?)` | Only when at least one resolved skill has scripts | Call `Script.RunAsync(skill, arguments, cancellationToken)`. |

When no resolved skills have scripts, do not advertise `run_skill_script` and do not include
script-execution guidance in the default skills instructions.

## Composition And Lifecycle

`AgentSkillsProviderBuilder` owns multi-source assembly through `UseSource`, `UseFileSkill`,
`UseInlineSkills`, and `UseClassSkills`. It applies an optional filter and file-script runner before
building the provider. The provider resolves duplicate names case-insensitively, retains the first
skill, and logs a warning for each skipped later duplicate.

Cache generated model tools and instructions at provider scope. The historical source-decorator
approach is useful for comparison, but it is not the accepted caching mechanism because a decorator
outside the provider cannot efficiently cache provider-created tools and instructions.

## Security And Error Requirements

- Reject file discovery or resource/script lookup that escapes the configured skill root.
- Resolve canonical paths before checking containment and reject unsafe symlink traversal.
- Restrict resource and script discovery to configured allowed extensions.
- Preserve cancellation tokens through source loading, resource reads, and script execution.
- Report a missing skill, resource, or script deterministically without falling through to a
  similarly named item from another source.
- Keep external file-script runners opt-in; never execute an arbitrary file merely because it was
  discovered.

## Acceptance Matrix

| Scenario | Expected result |
| --- | --- |
| A provider resolves only skills without scripts | `run_skill_script` and script instructions are absent. |
| A resolved skill has an inline or file script | The script tool is present and invokes the owning skill's script. |
| A file, inline, class, and custom source are combined | Every result is addressable through the same model-facing paths. |
| Two sources return names differing only by case | The first source wins and a duplicate warning is logged. |
| A configured filter excludes a skill | It is absent from discovery, instructions, and all tools. |
| A resource/script attempts traversal or unsafe symlink escape | Discovery or execution is rejected before I/O or runner invocation. |
| A file script has no configured runner | Invocation fails with `NotSupportedException`; it does not execute implicitly. |
| Provider methods are called repeatedly | Cached tools and instructions are reused without changing resolution semantics. |

## Focused Test Plan

Test the provider with fake sources and a temporary skill directory. Assert tool schemas and default
instructions as well as outcomes, because tool presence is part of the model contract. Use a fake
file-script runner to prove default and override selection without spawning a process. Add traversal
and symlink cases on each supported platform, and run delegate resources/scripts with a service
provider plus a cancellation token.