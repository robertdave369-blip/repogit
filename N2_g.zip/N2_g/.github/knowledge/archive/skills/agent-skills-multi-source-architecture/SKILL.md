---
name: agent-skills-multi-source-architecture
description: 'Use when designing, implementing, reviewing, or validating a multi-source Agent Skills framework with filesystem, inline, class-library, or custom sources. Covers AgentSkill contracts, model-facing tools, source composition, filtering, file-script runners, security, caching, and acceptance checks.'
argument-hint: 'Describe the target runtime/project, source types, public API constraints, and desired provider behavior'
user-invocable: true
disable-model-invocation: false
---

# Multi-Source Agent Skills Architecture

## Purpose

Use this skill to turn a proposed Agent Skills design into an implementable, testable contract. It
covers file-based, inline, class-based, and custom skill sources while keeping resources and
scripts distinct from general model tools.

This workspace contains the Copilot customization surface for the Python framework, not a .NET
implementation of `AgentSkillsProvider`. Treat the bundled contract as an architecture and review
aid. Do not claim that the C# runtime exists here unless an owning .NET project is supplied.

## Workflow

1. Identify the owning runtime, source assemblies, and target public API. Record an evidence gap
   when the implementation project is unavailable.
2. Preserve the four internal base abstractions: `AgentSkill`, `AgentSkillResource`,
   `AgentSkillScript`, and `AgentSkillsSource`. Keep only `AgentSkillsProvider` and
   `AgentSkillsProviderBuilder` public while the feature matures.
3. Implement sources uniformly: `AgentFileSkillsSource` for `SKILL.md` discovery and
   `AgentInMemorySkillsSource` for inline, class-based, or other in-memory skills. Let the builder
   combine sources and apply filtering.
4. Expose `load_skill` and `read_skill_resource` to the model. Expose `run_skill_script` only when
   at least one resolved skill contains a script, and omit script-execution instructions otherwise.
5. Keep `AgentSkillResource` and `AgentSkillScript` as dedicated abstractions. Do not replace them
   with raw `AIFunction` values: resources have no model-advertised parameters, approval must work
   across invocations, and scripts need their owning `AgentSkill` at execution time.
6. Keep file-script execution external through an `AgentFileSkillScriptRunner`. Support a provider
   default and source or per-skill overrides; inline and class scripts execute in-process through
   delegates.
7. Enforce file-source boundaries before discovery or execution: allowed extensions, canonical
   paths, traversal rejection, and symlink containment checks.
8. Cache generated instructions and tools at the provider. Deduplicate names case-insensitively with
   first-one-wins behavior and log skipped duplicates. Run focused contract and provider tests.

## Contract And Validation

Read the detailed [architecture contract](./references/architecture-contract.md) before changing a
runtime implementation. The [machine-readable contract](./assets/architecture-contract.json) is
validated locally and deliberately describes architecture requirements rather than pretending to
run a missing .NET provider.

```powershell
py -3.13 .github\skills\agent-skills-multi-source-architecture\scripts\validate_architecture_contract.py
```

## Completion Criteria

- Every skill origin resolves to the same base `AgentSkill` shape.
- Resources and scripts remain separately addressable and executable through their own methods.
- Model-facing tool registration follows the conditional script rule.
- File discovery cannot escape an allowed skill root.
- Provider-level caching and builder-level composition/filtering have focused tests.
- Public API exposure is limited to the provider and builder until the feature is promoted.