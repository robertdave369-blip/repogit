---
name: functional-safety-iso26262
description: 'Use when analyzing or testing ISO 26262 functional safety for an airbag ECU: ASIL allocation, safety requirements, fault injection, diagnostic coverage, safety mechanisms, FTTI, safe states, fault tolerance, or safety-case evidence in Framework_IOEM_Py. Produces a traceable safety analysis or test approach without claiming an ASIL, timing, mechanism, or coverage value without evidence.'
argument-hint: 'Describe the safety goal, item/function, project artefacts, and requested analysis or test'
user-invocable: true
disable-model-invocation: false
---

# Functional Safety ISO 26262

## Scope And Guardrails

Use this skill for ISO 26262-oriented reasoning and verification work around airbag ECU software. Airbag functions can be safety critical, but do not assume every ECU or software component is ASIL-D. Verify the safety goal, allocated ASIL, decomposition, safety requirements, and verification obligations from the target safety artefacts.

Never claim a diagnostic coverage percentage, FTTI, safe state, hardware metric, or ASIL allocation without a cited project source. Never run a fault injection, deployment-related test, power operation, flash, or squib-affecting action without explicit authorization and a safe bench procedure.

## Workflow

1. Identify the item/function, operational situation, hazard/safety goal, allocated ASIL, safety requirement, architecture element, and target project/release.
2. Classify each statement as **Fact**, **Inference**, or **Assumption** with provenance and confidence. Surface disagreements between hazard analysis, safety requirements, design, code, configuration, and test evidence.
3. Build a fault-to-safety-mechanism chain: fault cause -> detection -> reaction -> safe/degraded state -> reporting -> recovery -> verification evidence.
4. Verify timing end to end: fault occurrence, detection/qualification, decision, actuation/inhibition, reporting, recovery, and the allocated FTTI. Do not substitute a generic timing expectation for an allocated one.
5. Design a minimal, risk-prioritized test set for nominal operation, fault detection, diagnostic reaction, fail-safe/degraded behavior, boundary timing, recovery/healing, and independent-monitor failure where evidence permits.
6. Assess residual risk and coverage gaps, including unavailable safety-case evidence or untestable conditions.

## Safety Mechanism Review

For each claimed mechanism, verify its monitored element, fault model, diagnostic method, detection latency, independence, enable conditions, failure mode, reaction, diagnostic observability, and reset/ignition-cycle behavior. Typical categories include watchdog supervision, plausibility/range checks, redundancy comparison, memory integrity, communication freshness/CRC/E2E, voltage monitoring, sensor diagnostics, and controlled fault handling; these are categories, not proof that the target ECU implements them.

## Fault Injection Discipline

Use only the project-approved fault-creation method. Define preconditions, injection point, expected safe reaction, time basis, monitoring evidence, restoration, and post-test checks before execution. If a needed fault method is undocumented or ambiguous, stop and request the approved bench procedure rather than improvising a physical or communication fault.

## Portfolio Handoff

For a multi-skill workflow, preserve the safety goal, allocated ASIL evidence, requirement and architecture links, fault hypothesis, mechanism/detection/reaction chain, timing/FTTI evidence, residual risk, and fault-injection authorization. Hand approved test objectives to `requirement-based-testing`, executable checks to `python-test-automation`, and target/tool feasibility to `embedded-systems-fundamentals`.

## Completion Criteria

Deliver a traceable safety argument or test design that links safety requirement -> architecture/mechanism -> fault model -> expected reaction -> observable evidence. List residual risks, contradictions, and unverified assumptions; include confidence and do not represent generic ISO 26262 knowledge as project evidence.