# Governance And Recovery

## Preflight Contract

A mutating request is ready only when all of the following are true:

1. The source root exists and does not resolve to the automation workspace unless that source was explicitly approved.
2. The RV&S client path exists.
3. `si sandboxinfo` recognizes the target sandbox and its configuration path matches the requested PTC project.
4. The requested change package exists and is `Open`.
5. The named-subproject plan has no ambiguous parent or unexpected target structure.
6. The file selection is an explicit allowlist and every staged file hash matches its source file.
7. Required member/permission capability profiles are enabled, marked verified, and successfully run their read-only access-validation command.
8. The execution plan and manifest are written to the audit directory.

## Apply Contract

`Apply` requires both of these controls:

- The command uses `-Approve`.
- The request contains `approval.approved: true` plus reviewer provenance.

The automation keeps the change package open by default. Submitting or closing a package is a separate reviewed action.

## Archive Conflict Policy

When a file was dropped from a prior generic project, adding it to a newly named project may encounter an archive collision. The default `newarchive` policy creates a fresh archive for the new named project rather than silently sharing a dropped generic-path archive.

Use `sharearchive` only when the project owner explicitly requires history sharing and has reviewed the archive path impact.

## Rollback Guidance

The skill does not automatically drop projects, members, roles, permissions, or files after an apply. A rollback report should identify:

- Change package and operation IDs.
- Created project paths and file members.
- Whether archives are new or shared.
- The exact RV&S drop/remove operation to review.
- Data-retention, branch, lock, and audit implications.

For access-management changes, capture the prior access state before applying a change. For files, retain the source hash and resulting member/project mapping.

## Audit Output

Each run writes a timestamped output folder containing:

```text
plan.json
preflight.json
manifest.json
audit.jsonl
apply-result.json
audit-report.json
rollback-guidance.md
```

A blocked capability is a successful governance result, not an execution failure to work around.
