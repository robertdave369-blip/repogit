# Natural-Language Routing

The skill uses natural language only to choose a draft operation. It never infers the physical source root, target sandbox, PTC configuration path, change package, user identity, role, permission, or archive policy.

| Example request | Draft operation | Required clarification/evidence |
| --- | --- | --- |
| "Create a new subproject under ALE Core Validation named Framework_IOEM_Py" | `CreateNamedSubprojects` | Parent PTC project, source hierarchy, sandbox, open change package. |
| "Create folders TestCases/UI/Login and TestCases/API/Auth" | `CreateFolders` | Target sandbox and open change package if server-side structure will be changed. |
| "Upload all __init__.py files from source tree" | `UploadInitializers` | Source root, sandbox, PTC project, change package, same-name rule. |
| "Upload these ZIP archives" | `AddArchives` | Explicit relative archive paths only; full recursive archive selection is rejected. |
| "Add John Smith and Jane Doe as Developers" | `AddProjectMembers` | Project, users, role, change package, verified access-validation and administration profile. |
| "Change user permissions" | `UpdateMemberPermissions` | Current access evidence, requested delta, verified external administration profile. |

After classification, convert the request to `assets/request-template.json`, run `DryRun`, then `Preflight`. Treat an incomplete draft as a question to resolve, not an authorization to act.
