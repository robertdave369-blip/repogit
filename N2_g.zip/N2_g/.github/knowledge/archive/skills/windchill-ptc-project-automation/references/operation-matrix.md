# Operation Matrix

| Operation | Built-in automation | Mutation gate | Evidence required | Notes |
| --- | --- | --- | --- | --- |
| `CreateSandbox` | Yes, when enabled in config | Preflight + approval + empty target | Parent project, sandbox path, mapping | Disabled by default because it changes local sandbox state. |
| `ValidateSandbox` | Yes | Read-only | Sandbox info and requested PTC configuration path | Stops on mapping mismatch. |
| `CreateNamedSubprojects` | Yes | Preflight + approval + open CP | Parent project hierarchy, same-name plan | Creates `<directory>/<directory-name>.pj` explicitly. |
| `CloneProjectStructure` | Yes | Preflight + approval + open CP | Source structure and target tree | Uses directory plan; does not copy files unless separately requested. |
| `ValidateProjectStructure` | Yes | Read-only | Project-tree query | Reports missing, duplicate, and unexpected subprojects. |
| `CreateFolders` | Yes | Preflight + approval | Sandbox root plus explicit folders or `templatePath` | Creates local sandbox folders only. |
| `ValidateFolderPaths` | Yes | Read-only | Sandbox root and requested relative folders | Reports every missing requested path. |
| `SynchronizeFolderTree` | Yes | Preflight + approval | Source and sandbox tree | Adds missing folders only; never removes folders automatically. |
| `CreateProjectTemplate` | Yes | Local evidence only | Source tree | Writes a reusable same-name project template JSON; no RV&S call. Feed it to `CreateFolders` through `templatePath`. |
| `UploadInitializers` | Yes | Preflight + approval + open CP | Source hashes, target projects, file allowlist | Only source `__init__.py` files are selected. |
| `AddFiles` | Yes | Preflight + approval + open CP | Explicit paths or approved all-files selection | All-file selection is disabled by default. |
| `AddArchives` | Yes | Preflight + approval + open CP | Explicit archive file list | `explicit-files` is mandatory; recursive archive upload is blocked. |
| `CompareFiles` | Yes | Read-only | Source/sandbox paths and SHA-256 hashes | Detects missing, changed, and unexpected files. |
| `ValidateChangePackage` | Yes | Read-only | Change package ID and state | Mutations require `Open`. |
| `AddProjectMembers` | Capability profile | Preflight + approval + verified profile | Users, role, permission evidence, access-validation result | No generic RV&S user-admin command is assumed. |
| `RemoveProjectMembers` | Capability profile | Preflight + approval + verified profile | Users, impact review, access-validation result | Rollback guidance is mandatory. |
| `UpdateMemberPermissions` | Capability profile | Preflight + approval + verified profile | Existing access, requested delta, access-validation result | Stop if a profile is absent or unverified. |
| `ChangeUserRoles` | Capability profile | Preflight + approval + verified profile | Existing roles, requested delta, access-validation result | Stop if a profile is absent or unverified. |

## Same-Name Project Rule

For each directory in the selected source hierarchy, create a project at the same directory with the same basename:

```text
projects\U171\modules\CANC
  -> projects/U171/modules/CANC/CANC.pj
```

Create parents before children. Do not use automatic `--createSubprojects` if the requested project file must not be `project.pj`.

## File Selection Modes

- `initializers-only`: Only source files whose basename is `__init__.py`.
- `explicit-files`: Only request-listed relative files inside `sourceRoot`.
- `all-files`: All eligible source files. Requires `fileSelection.allowAllFiles: true`, config permission, and an approved plan. Policy exclusions still apply.
