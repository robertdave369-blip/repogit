# Examples

- `create-named-subprojects.request.json`: Creates an explicit same-name `.pj` hierarchy.
- `upload-initializers.request.json`: Creates missing named subprojects and uploads only source `__init__.py` files.
- `create-folders.request.json`: Creates explicitly named local sandbox folders.
- `add-archives.request.json`: Adds an allowlisted archive file only.
- `add-members.request.json`: Shows the gated member-administration request shape.

Each example is intentionally unapproved. Review the target values and set the approval object only after a successful preflight.
