[CmdletBinding()]
param(
    [switch]$KeepTestData
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$modulePath = Join-Path $PSScriptRoot "WindchillPtc.Automation.psm1"
$configPath = Join-Path $PSScriptRoot "..\config\defaults.json"
Import-Module $modulePath -Force -ErrorAction Stop
$config = Get-WindchillConfig -ConfigPath $configPath

$testRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("windchill-ptc-skill-test-" + [Guid]::NewGuid().ToString("N"))
$sourceRoot = Join-Path $testRoot "source"
$sandboxRoot = Join-Path $testRoot "sandbox"

try {
    New-Item -ItemType Directory -Path (Join-Path $sourceRoot "projects\U171\modules\CANC\scripts") -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $sourceRoot "projects\U171\modules\CANC\__pycache__") -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $sourceRoot "shared_libraries") -Force | Out-Null
    New-Item -ItemType Directory -Path $sandboxRoot -Force | Out-Null

    Set-Content -LiteralPath (Join-Path $sourceRoot "projects\U171\modules\CANC\__init__.py") -Value "CANC_INIT" -Encoding utf8
    Set-Content -LiteralPath (Join-Path $sourceRoot "projects\U171\modules\CANC\scripts\__init__.py") -Value "CANC_SCRIPTS_INIT" -Encoding utf8
    Set-Content -LiteralPath (Join-Path $sourceRoot "shared_libraries\__init__.py") -Value "LIB_INIT" -Encoding utf8
    Set-Content -LiteralPath (Join-Path $sourceRoot "projects\U171\modules\CANC\module.py") -Value "print('not selected')" -Encoding utf8
    Set-Content -LiteralPath (Join-Path $sourceRoot "projects\U171\modules\CANC\__pycache__\module.pyc") -Value "generated" -Encoding utf8

    $filePolicy = Get-WindchillProperty -Object $config -Name "filePolicy"
    $excludedDirectories = ConvertTo-WindchillArray (Get-WindchillProperty -Object $filePolicy -Name "deniedDirectoryNames")
    $directories = Get-WindchillSourceDirectories -SourceRoot $sourceRoot -ExcludedDirectoryNames $excludedDirectories
    if (@($directories | Where-Object { $_.RelativePath -match "__pycache__" }).Count -ne 0) {
        throw "Generated directory exclusion failed."
    }

    $rootProjectPath = "e:/MKSProjects/Example/Framework/Framework.pj"
    $subprojectPlan = New-WindchillNamedSubprojectPlan -SourceDirectories $directories -SandboxRoot $sandboxRoot -RootProjectPath $rootProjectPath
    $cancProject = $subprojectPlan | Where-Object { $_.RelativePath -eq "projects\U171\modules\CANC" } | Select-Object -First 1
    if ($null -eq $cancProject -or $cancProject.RelativeProjectPath -ne "projects/U171/modules/CANC/CANC.pj") {
        throw "Same-name subproject planning failed."
    }

    $request = [PSCustomObject]@{
        operation = "UploadInitializers"
        sourceRoot = $sourceRoot
        sandboxRoot = $sandboxRoot
        fileSelection = [PSCustomObject]@{
            mode = "initializers-only"
            allowAllFiles = $false
            excludeDirectoryNames = @()
            excludeExtensions = @()
        }
    }
    $files = Get-WindchillFileSelection -Request $request -Config $config -SourceRoot $sourceRoot
    if ($files.Count -ne 3 -or @($files | Where-Object { $_.FileName -ne "__init__.py" }).Count -ne 0) {
        throw "Initializer-only selection failed."
    }

    $templatePlan = New-WindchillAutomationPlan -Request ([PSCustomObject]@{
        operation = "CreateProjectTemplate"
        sourceRoot = $sourceRoot
    }) -Config $config
    if ($templatePlan.sourceDirectories.Count -ne $directories.Count) {
        throw "Single-item-safe template planning failed."
    }

    $folderTemplatePath = Join-Path $testRoot "folder-template.json"
    [PSCustomObject]@{
        directories = @(
            [PSCustomObject]@{ RelativePath = "TestCases\UI\Login" },
            [PSCustomObject]@{ RelativePath = "TestCases\API\Auth" }
        )
    } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $folderTemplatePath -Encoding utf8
    $templateFolderPlan = New-WindchillFolderPlan -Request ([PSCustomObject]@{
        folders = @()
        templatePath = $folderTemplatePath
    }) -SandboxRoot $sandboxRoot
    if ($templateFolderPlan.Count -ne 2 -or @($templateFolderPlan | Where-Object { $_.SandboxPath -notlike "$sandboxRoot*" }).Count -ne 0) {
        throw "Template-backed folder planning failed."
    }

    $fileTargets = Resolve-WindchillFileTargets -FilePlan $files -SubprojectPlan $subprojectPlan -SandboxRoot $sandboxRoot -RootProjectPath $rootProjectPath
    $staged = Invoke-WindchillStageFiles -FileTargets $fileTargets -HashAlgorithm "SHA256" -OutputDirectory $testRoot
    if ($staged.Count -ne 3) {
        throw "Initializer staging failed."
    }
    $comparison = Compare-WindchillFileTrees -FileTargets $fileTargets -HashAlgorithm "SHA256"
    if (@($comparison | Where-Object { $_.Status -ne "equal" }).Count -ne 0) {
        throw "Hash comparison failed."
    }

    $intent = ConvertTo-WindchillIntentDraft -Intent "Upload all __init__.py files from the source tree"
    if ($intent.suggestedOperation -ne "UploadInitializers") {
        throw "Intent routing failed."
    }

    $archiveIntent = ConvertTo-WindchillIntentDraft -Intent "Upload approved ZIP archives to the named project folders"
    if ($archiveIntent.suggestedOperation -ne "AddArchives") {
        throw "Archive intent routing failed."
    }

    $folderIntent = ConvertTo-WindchillIntentDraft -Intent "Validate folder paths TestCases/UI/Login in the sandbox"
    if ($folderIntent.suggestedOperation -ne "ValidateFolderPaths") {
        throw "Folder validation intent routing failed."
    }

    $templateIntent = ConvertTo-WindchillIntentDraft -Intent "Create a project template from the current source structure"
    if ($templateIntent.suggestedOperation -ne "CreateProjectTemplate" -or @($templateIntent.requiredFields).Count -ne 1) {
        throw "Project-template intent routing failed."
    }

    $traversalRejected = $false
    try {
        Assert-WindchillSafeRelativePath -RelativePath "..\outside" -Label "Test path"
    }
    catch {
        $traversalRejected = $true
    }
    if (-not $traversalRejected) {
        throw "Relative-path traversal guard failed."
    }

    [PSCustomObject]@{
        Result = "Windchill PTC automation self-test passed"
        SourceDirectories = $directories.Count
        NamedSubprojects = $subprojectPlan.Count
        InitializerFiles = $files.Count
        GeneratedDirectoryExcluded = $true
        SameNameProject = $cancProject.RelativeProjectPath
        IntentOperation = $intent.suggestedOperation
        ArchiveIntentOperation = $archiveIntent.suggestedOperation
        FolderIntentOperation = $folderIntent.suggestedOperation
        TemplateIntentOperation = $templateIntent.suggestedOperation
        TemplateFolderPaths = $templateFolderPlan.RelativePath
    }
}
finally {
    if (-not $KeepTestData -and (Test-Path -LiteralPath $testRoot)) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
