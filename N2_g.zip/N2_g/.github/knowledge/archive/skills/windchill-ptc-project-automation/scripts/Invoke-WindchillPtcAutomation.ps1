[CmdletBinding(DefaultParameterSetName = "Request")]
param(
    [Parameter(ParameterSetName = "Request", Mandatory = $true)]
    [string]$RequestPath,
    [Parameter(ParameterSetName = "Intent", Mandatory = $true)]
    [string]$Intent,
    [ValidateSet("DryRun", "Preflight", "Apply")]
    [string]$Mode = "DryRun",
    [string]$ConfigPath = (Join-Path $PSScriptRoot "..\config\defaults.json"),
    [string]$OutputRoot,
    [switch]$Approve
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$modulePath = Join-Path $PSScriptRoot "WindchillPtc.Automation.psm1"
Import-Module $modulePath -Force -ErrorAction Stop

if ($PSCmdlet.ParameterSetName -eq "Intent") {
    $draft = ConvertTo-WindchillIntentDraft -Intent $Intent
    $draft | ConvertTo-Json -Depth 8
    return
}

$request = Read-WindchillJsonFile -Path $RequestPath
$config = Get-WindchillConfig -ConfigPath $ConfigPath
$plan = New-WindchillAutomationPlan -Request $request -Config $config
$outputDirectory = New-WindchillOutputDirectory -Request $request -Config $config -OutputRoot $OutputRoot

Write-WindchillJsonFile -Path (Join-Path $outputDirectory "request.json") -Value $request | Out-Null
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "plan.json") -Value $plan | Out-Null
Write-WindchillAuditRecord -OutputDirectory $outputDirectory -Stage "plan" -Status "created" -Data $plan | Out-Null
$runtimeManifest = [PSCustomObject]@{
    generatedAtUtc = [DateTime]::UtcNow.ToString("o")
    requestPath = (Resolve-Path -LiteralPath $RequestPath).ProviderPath
    configPath = (Resolve-Path -LiteralPath $ConfigPath).ProviderPath
    operation = $plan.operation
    requestHash = $plan.requestHash
    mode = $Mode
    plan = $plan
}
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "manifest.json") -Value $runtimeManifest | Out-Null

if ($Mode -eq "DryRun") {
    $result = [PSCustomObject]@{
        mode = $Mode
        status = "planned"
        auditDirectory = $outputDirectory
        operation = $plan.operation
        counts = $plan.counts
        nextStep = "Run Preflight and review the generated evidence before Apply."
    }
    Write-WindchillJsonFile -Path (Join-Path $outputDirectory "result.json") -Value $result | Out-Null
    Write-WindchillJsonFile -Path (Join-Path $outputDirectory "audit-report.json") -Value $result | Out-Null
    $result
    return
}

$preflight = Invoke-WindchillPreflight -Plan $plan -Request $request -Config $config -OutputDirectory $outputDirectory
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "preflight.json") -Value $preflight | Out-Null
$runtimeManifest | Add-Member -NotePropertyName preflight -NotePropertyValue $preflight -Force
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "manifest.json") -Value $runtimeManifest | Out-Null

if ($Mode -eq "Preflight") {
    $result = [PSCustomObject]@{
        mode = $Mode
        status = "preflight-passed"
        auditDirectory = $outputDirectory
        operation = $plan.operation
        preflight = $preflight
        nextStep = "Review preflight.json, set request.approval, then rerun with -Mode Apply -Approve."
    }
    Write-WindchillJsonFile -Path (Join-Path $outputDirectory "result.json") -Value $result | Out-Null
    Write-WindchillJsonFile -Path (Join-Path $outputDirectory "audit-report.json") -Value $result | Out-Null
    $result
    return
}

Assert-WindchillApplyAuthorization -Request $request -Config $config -Approve:$Approve
$siPath = if ($plan.operation -eq "CreateProjectTemplate") { "" } else { Resolve-WindchillSiPath -Request $request -Config $config }
$rvsConfig = Get-WindchillProperty -Object $config -Name "rvs" -Default $null
$filePolicy = Get-WindchillProperty -Object $config -Name "filePolicy" -Default $null
$hashAlgorithm = Get-WindchillProperty -Object $filePolicy -Name "hashAlgorithm" -Default "SHA256"
$archiveConflictPolicy = Get-WindchillProperty -Object $rvsConfig -Name "archiveConflictPolicy" -Default "newarchive"
$applyData = [ordered]@{
    foldersCreated = @()
    subprojectsCreated = @()
    filesStaged = @()
    filesAdded = @()
    comparison = @()
    unexpectedFiles = @()
    folderValidation = $null
    template = $null
    capability = $null
}

switch ($plan.operation) {
    "CreateProjectTemplate" {
        $template = [PSCustomObject]@{
            schemaVersion = "1.0"
            generatedAtUtc = [DateTime]::UtcNow.ToString("o")
            sourceRoot = $plan.sourceRoot
            namingRule = "<directory>/<directory-name>.pj"
            directories = @($plan.sourceDirectories | Select-Object RelativePath)
        }
        $templatePath = Join-Path $outputDirectory "project-template.json"
        Write-WindchillJsonFile -Path $templatePath -Value $template | Out-Null
        $applyData.template = $templatePath
    }
    "ValidateFolderPaths" {
        $applyData.folderValidation = [PSCustomObject]@{
            requested = $plan.folderPlan.Count
            missing = @($preflight.missingFolderPaths)
            valid = @($preflight.missingFolderPaths).Count -eq 0
        }
    }
    "CreateSandbox" {
        $execution = Get-WindchillProperty -Object $config -Name "execution" -Default $null
        if (-not [bool](Get-WindchillProperty -Object $execution -Name "allowSandboxCreation" -Default $false)) {
            throw "CreateSandbox is disabled by config execution.allowSandboxCreation. Enable it only after the destination and server policy are reviewed."
        }
        $ptcProject = Get-WindchillProperty -Object $request -Name "ptcProject" -Default ""
        if ([string]::IsNullOrWhiteSpace($ptcProject)) {
            throw "CreateSandbox requires request.ptcProject."
        }
        Invoke-WindchillSiCommand -Executable $siPath -Arguments @(
            "createsandbox",
            "--project=$ptcProject",
            "--failOnAmbiguousProject",
            "--populate",
            "--noopenView",
            "--batch",
            "--yes",
            $plan.sandboxRoot
        ) -OutputDirectory $outputDirectory | Out-Null
        $applyData.foldersCreated = @($plan.sandboxRoot)
    }
    "CreateFolders" {
        $applyData.foldersCreated = Invoke-WindchillCreateFolders -FolderPlan $plan.folderPlan -OutputDirectory $outputDirectory
    }
    "SynchronizeFolderTree" {
        $applyData.foldersCreated = Invoke-WindchillCreateFolders -FolderPlan $plan.folderPlan -OutputDirectory $outputDirectory
    }
    "CreateNamedSubprojects" {
        $applyData.subprojectsCreated = Invoke-WindchillCreateNamedSubprojects `
            -SubprojectPlan $preflight.subprojectPlan `
            -ExistingRelativeProjectPaths $preflight.existingSubprojectPaths `
            -Executable $siPath `
            -SandboxRoot $plan.sandboxRoot `
            -ChangePackageId $plan.changePackageId `
            -OutputDirectory $outputDirectory
    }
    "CloneProjectStructure" {
        $applyData.subprojectsCreated = Invoke-WindchillCreateNamedSubprojects `
            -SubprojectPlan $preflight.subprojectPlan `
            -ExistingRelativeProjectPaths $preflight.existingSubprojectPaths `
            -Executable $siPath `
            -SandboxRoot $plan.sandboxRoot `
            -ChangePackageId $plan.changePackageId `
            -OutputDirectory $outputDirectory
    }
    "UploadInitializers" {
        $applyData.subprojectsCreated = Invoke-WindchillCreateNamedSubprojects `
            -SubprojectPlan $preflight.subprojectPlan `
            -ExistingRelativeProjectPaths $preflight.existingSubprojectPaths `
            -Executable $siPath `
            -SandboxRoot $plan.sandboxRoot `
            -ChangePackageId $plan.changePackageId `
            -OutputDirectory $outputDirectory

        $rootProjectPath = Get-WindchillRootProjectPath -SandboxInfo $preflight.sandbox
        $fileTargets = Resolve-WindchillFileTargets `
            -FilePlan $plan.filePlan `
            -SubprojectPlan $preflight.subprojectPlan `
            -SandboxRoot $plan.sandboxRoot `
            -RootProjectPath $rootProjectPath
        $applyData.filesStaged = Invoke-WindchillStageFiles -FileTargets $fileTargets -HashAlgorithm $hashAlgorithm -OutputDirectory $outputDirectory
        $existingFiles = Get-WindchillExistingMemberRelativePaths -FilePlan $fileTargets -Executable $siPath
        $applyData.filesAdded = Invoke-WindchillAddFiles `
            -FileTargets $fileTargets `
            -ExistingRelativePaths @($existingFiles) `
            -Executable $siPath `
            -ChangePackageId $plan.changePackageId `
            -Description $plan.description `
            -ArchiveConflictPolicy $archiveConflictPolicy `
            -OutputDirectory $outputDirectory
    }
    "AddFiles" {
        $applyData.subprojectsCreated = Invoke-WindchillCreateNamedSubprojects `
            -SubprojectPlan $preflight.subprojectPlan `
            -ExistingRelativeProjectPaths $preflight.existingSubprojectPaths `
            -Executable $siPath `
            -SandboxRoot $plan.sandboxRoot `
            -ChangePackageId $plan.changePackageId `
            -OutputDirectory $outputDirectory

        $rootProjectPath = Get-WindchillRootProjectPath -SandboxInfo $preflight.sandbox
        $fileTargets = Resolve-WindchillFileTargets `
            -FilePlan $plan.filePlan `
            -SubprojectPlan $preflight.subprojectPlan `
            -SandboxRoot $plan.sandboxRoot `
            -RootProjectPath $rootProjectPath
        $applyData.filesStaged = Invoke-WindchillStageFiles -FileTargets $fileTargets -HashAlgorithm $hashAlgorithm -OutputDirectory $outputDirectory
        $existingFiles = Get-WindchillExistingMemberRelativePaths -FilePlan $fileTargets -Executable $siPath
        $applyData.filesAdded = Invoke-WindchillAddFiles `
            -FileTargets $fileTargets `
            -ExistingRelativePaths @($existingFiles) `
            -Executable $siPath `
            -ChangePackageId $plan.changePackageId `
            -Description $plan.description `
            -ArchiveConflictPolicy $archiveConflictPolicy `
            -OutputDirectory $outputDirectory
    }
    "AddArchives" {
        $applyData.subprojectsCreated = Invoke-WindchillCreateNamedSubprojects `
            -SubprojectPlan $preflight.subprojectPlan `
            -ExistingRelativeProjectPaths $preflight.existingSubprojectPaths `
            -Executable $siPath `
            -SandboxRoot $plan.sandboxRoot `
            -ChangePackageId $plan.changePackageId `
            -OutputDirectory $outputDirectory

        $rootProjectPath = Get-WindchillRootProjectPath -SandboxInfo $preflight.sandbox
        $fileTargets = Resolve-WindchillFileTargets `
            -FilePlan $plan.filePlan `
            -SubprojectPlan $preflight.subprojectPlan `
            -SandboxRoot $plan.sandboxRoot `
            -RootProjectPath $rootProjectPath
        $applyData.filesStaged = Invoke-WindchillStageFiles -FileTargets $fileTargets -HashAlgorithm $hashAlgorithm -OutputDirectory $outputDirectory
        $existingFiles = Get-WindchillExistingMemberRelativePaths -FilePlan $fileTargets -Executable $siPath
        $applyData.filesAdded = Invoke-WindchillAddFiles `
            -FileTargets $fileTargets `
            -ExistingRelativePaths @($existingFiles) `
            -Executable $siPath `
            -ChangePackageId $plan.changePackageId `
            -Description $plan.description `
            -ArchiveConflictPolicy $archiveConflictPolicy `
            -OutputDirectory $outputDirectory
    }
    "CompareFiles" {
        $rootProjectPath = Get-WindchillRootProjectPath -SandboxInfo $preflight.sandbox
        $fileTargets = Resolve-WindchillFileTargets `
            -FilePlan $plan.filePlan `
            -SubprojectPlan $preflight.subprojectPlan `
            -SandboxRoot $plan.sandboxRoot `
            -RootProjectPath $rootProjectPath
        $applyData.comparison = Compare-WindchillFileTrees -FileTargets $fileTargets -HashAlgorithm $hashAlgorithm
        $applyData.unexpectedFiles = Get-WindchillUnexpectedSandboxFiles -FileTargets $fileTargets -SandboxRoot $plan.sandboxRoot
    }
    "AddProjectMembers" {
        Invoke-WindchillMemberCapability -Capability $preflight.capability -RequestPath $RequestPath -OutputDirectory $outputDirectory
        $applyData.capability = $preflight.capability
    }
    "RemoveProjectMembers" {
        Invoke-WindchillMemberCapability -Capability $preflight.capability -RequestPath $RequestPath -OutputDirectory $outputDirectory
        $applyData.capability = $preflight.capability
    }
    "UpdateMemberPermissions" {
        Invoke-WindchillMemberCapability -Capability $preflight.capability -RequestPath $RequestPath -OutputDirectory $outputDirectory
        $applyData.capability = $preflight.capability
    }
    "ChangeUserRoles" {
        Invoke-WindchillMemberCapability -Capability $preflight.capability -RequestPath $RequestPath -OutputDirectory $outputDirectory
        $applyData.capability = $preflight.capability
    }
    default {
        # Validation operations have no mutation beyond evidence creation.
    }
}

$rollbackGuidance = New-WindchillRollbackGuidance -Plan $plan -Preflight $preflight
Set-Content -LiteralPath (Join-Path $outputDirectory "rollback-guidance.md") -Value $rollbackGuidance -Encoding utf8

$result = [PSCustomObject]@{
    mode = $Mode
    status = "applied"
    auditDirectory = $outputDirectory
    operation = $plan.operation
    apply = [PSCustomObject]$applyData
    nonInitializerFilesAdded = 0
    changePackageId = $plan.changePackageId
    changePackageClosed = $false
    changePackageSubmitted = $false
}
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "apply-result.json") -Value $result | Out-Null
Write-WindchillAuditRecord -OutputDirectory $outputDirectory -Stage "apply" -Status "completed" -Data $result | Out-Null
$runtimeManifest | Add-Member -NotePropertyName applyResult -NotePropertyValue $result -Force
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "manifest.json") -Value $runtimeManifest | Out-Null
Write-WindchillJsonFile -Path (Join-Path $outputDirectory "audit-report.json") -Value $result | Out-Null
$result
