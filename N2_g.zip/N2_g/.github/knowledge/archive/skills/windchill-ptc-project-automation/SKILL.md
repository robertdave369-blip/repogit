---
name: windchill-ptc-project-automation
description: "Use when creating, cloning, validating, or administering Windchill RV&S / PTC projects, sandboxes, named .pj subprojects, folder trees, change packages, project members, roles, permissions, file uploads, __init__.py uploads, archive checks, or audit manifests. Provides intent routing, dry-run, preflight, explicit apply approval, conflict detection, hash verification, and rollback guidance for enterprise RV&S automation."
argument-hint: "Describe the Windchill RV&S action, parent project or sandbox, source path, change package, naming convention, and whether you want a plan, preflight, or approved apply"
user-invocable: true
disable-model-invocation: false
---

# Windchill PTC Project Automation

## Purpose

Use this workspace skill for governed Windchill RV&S / PTC administration. It turns a natural-language request into a structured request, a reviewable plan, a preflight report, and only then an explicitly approved apply operation.

The package includes a reusable [PowerShell module](./scripts/WindchillPtc.Automation.psm1), a command entry point [Invoke-WindchillPtcAutomation.ps1](./scripts/Invoke-WindchillPtcAutomation.ps1), default policy [defaults.json](./config/defaults.json), request templates, examples, and a no-server self-test.

## When To Use

Use this skill when the user asks to:

- Create a project sandbox, a subproject, nested subprojects, or a same-name `.pj` hierarchy.
- Create, validate, clone, synchronize, or compare project folder trees.
- Upload `__init__.py` files, explicit files, archives, or an approved full file selection.
- Add or remove project members, change a role, update permissions, or validate user access.
- Check a change package, inspect a project tree, detect duplicates, compare hashes, create a manifest, or produce an RV&S audit report.

## Intent Routing

Normalize the request before touching RV&S. Use these action names in the request JSON:

| Natural-language intent | Operation |
| --- | --- |
| Create named/nested project folders | `CreateNamedSubprojects` |
| Copy a directory hierarchy as projects | `CloneProjectStructure` |
| Create or validate a sandbox | `CreateSandbox` or `ValidateSandbox` |
| Create local sandbox folders, including from a template | `CreateFolders` |
| Validate local sandbox folder paths | `ValidateFolderPaths` |
| Reconcile a source folder tree | `SynchronizeFolderTree` |
| Generate a reusable project structure template | `CreateProjectTemplate` |
| Upload package initializers | `UploadInitializers` |
| Upload specific or approved all files | `AddFiles` |
| Upload explicit archive files | `AddArchives` |
| Compare source and sandbox content | `CompareFiles` |
| Check the PTC tree | `ValidateProjectStructure` |
| Add/remove users, roles, or permissions | `AddProjectMembers`, `RemoveProjectMembers`, `UpdateMemberPermissions`, or `ChangeUserRoles` |
| Check the change package | `ValidateChangePackage` |

For free-form classification only, run:

```powershell
$entry = ".github\skills\windchill-ptc-project-automation\scripts\Invoke-WindchillPtcAutomation.ps1"
& $entry -Intent "Upload all __init__.py files from the source tree" -Mode DryRun
```

Use the resulting draft to complete a request file. The intent classifier does not invent paths, user identities, project IDs, change-package IDs, permissions, or RV&S commands.

## Mandatory Safety Rules

1. Start with `DryRun` or `Preflight`; never start with `Apply`.
2. `Apply` requires both `-Approve` and a request whose `approval.approved` value is `true`.
3. Every server-side modification requires an existing `Open` change package, except an explicitly approved sandbox creation workflow where the server configuration permits it.
4. Validate the sandbox against the requested PTC configuration path before changes.
5. Stop on an ambiguous parent project, sandbox mapping, change package, duplicate project, file collision, permission gap, or unexpected member.
6. Do not use RV&S automatic `--createSubprojects` when the user requires same-name projects. Create each project explicitly as `<directory>/<directory-name>.pj`, for example `CANC/CANC.pj`.
7. Default file selection is `initializers-only`. An all-file upload requires an explicit request opt-in and an approved plan.
8. User, role, and permission changes require a reviewed organization-specific member-administration capability profile. Do not fabricate an RV&S admin command or API.
9. Preserve evidence: request, plan, preflight, manifest, hashes, command outcomes, and rollback recommendations.
10. Never close or submit a change package unless the request explicitly authorizes that separate action.

## Required Workflow

1. Read [operation matrix](./references/operation-matrix.md) and [governance](./references/governance-and-recovery.md) for the selected operation.
2. Convert the user intent into the [request template](./assets/request-template.json). Resolve all required source paths, sandbox path, PTC project, and change package from evidence.
3. Run `DryRun` to generate a local plan and manifest without querying or mutating RV&S.
4. Run `Preflight` to validate the RV&S client, sandbox mapping, project tree, open change package, requested capabilities, duplicate state, hashes, and conflicts.
5. Present the plan to the user: target configuration, change package, named project count, file count and allowlist, conflicts, and rollback implications.
6. Apply only after the user explicitly authorizes it and the request contains approval evidence.
7. Run a post-apply preflight and compare the actual hierarchy and members with the requested plan.
8. Return the audit directory and a concise outcome. State clearly when a capability was blocked rather than claiming it executed.

## Named Subproject Contract

For a source hierarchy such as:

```text
projects\U171\modules\CANC
```

create this logical RV&S project location:

```text
projects/U171/modules/CANC/CANC.pj
```

The directory name and `.pj` basename must match. The automation module creates parent projects first, validates the hierarchy, and never substitutes `project.pj` for a same-name request.

## Folder Templates

`CreateProjectTemplate` writes `project-template.json` from a source hierarchy without calling RV&S. Supply that generated file as `templatePath` in a `CreateFolders` or `ValidateFolderPaths` request to create or validate the same relative folder paths. Every template path is revalidated as a non-rooted, traversal-free relative path before it is used.

## Files And Members

- `UploadInitializers` discovers only source `__init__.py` files, stages them in the matching sandbox paths, compares SHA-256 hashes, and adds only files absent from the named target projects.
- `AddFiles` supports explicit relative paths and a separately approved all-files selection. Excluded/generated paths remain governed by policy.
- Existing/dropped archive behavior must be explicit in the request. Default configuration uses `newarchive` so a new named project does not silently reuse a dropped generic-project history.
- Member and permission operations produce a blocked plan until `memberAdministration` is enabled in a reviewed capability profile with a working access-validation command. The validation command runs during preflight; the management command runs only during approved apply.

## Commands

```powershell
$skill = ".github\skills\windchill-ptc-project-automation"
$entry = Join-Path $skill "scripts\Invoke-WindchillPtcAutomation.ps1"
$request = Join-Path $skill "examples\upload-initializers.request.json"

# No RV&S calls or mutations; writes a local plan and manifest.
& $entry -RequestPath $request -Mode DryRun

# Queries RV&S and validates the full request. No mutation.
& $entry -RequestPath $request -Mode Preflight

# Requires both request approval and this explicit switch.
& $entry -RequestPath $request -Mode Apply -Approve

# Validate the package logic without using RV&S.
& (Join-Path $skill "scripts\Test-WindchillPtcAutomation.ps1")
```

## Completion Criteria

A task is complete only when the audit output shows:

- Intent and request provenance.
- Exact PTC project and sandbox mapping.
- Open change-package validation for each mutation.
- Planned versus actual named subprojects and members.
- Hash evidence for staged or compared files.
- Zero unexpected files or a documented exception.
- Command outcomes and any blocked capabilities.
- A rollback recommendation appropriate to the mutation.

Do not claim that a project, member, role, permission, or file was changed merely because a plan was produced.
