# Skill Documentation

Use [SKILL.md](../SKILL.md) for the agent workflow. Use [operation-matrix.md](../references/operation-matrix.md) to choose an operation and [governance-and-recovery.md](../references/governance-and-recovery.md) before any `Apply` run.

The scripts generate machine-readable manifests and JSONL audit records in the configured output directory.
