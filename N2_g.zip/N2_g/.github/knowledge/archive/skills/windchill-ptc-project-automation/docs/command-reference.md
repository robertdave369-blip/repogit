# Command Reference

## Intent Draft

```powershell
& .github\skills\windchill-ptc-project-automation\scripts\Invoke-WindchillPtcAutomation.ps1 `
  -Intent "Create a named subproject tree from C:\\Source" `
  -Mode DryRun
```

This command classifies the request only. It does not create a plan directory or call RV&S.

## Request Workflow

```powershell
$entry = ".github\skills\windchill-ptc-project-automation\scripts\Invoke-WindchillPtcAutomation.ps1"
$request = ".github\skills\windchill-ptc-project-automation\examples\upload-initializers.request.json"

& $entry -RequestPath $request -Mode DryRun
& $entry -RequestPath $request -Mode Preflight
& $entry -RequestPath $request -Mode Apply -Approve
```

`Apply` additionally requires `approval.approved` and `approval.approvedBy` in the request JSON.

## Audit Artifacts

Each request run creates a timestamped directory containing:

```text
request.json
plan.json
preflight.json
manifest.json
audit.jsonl
audit-report.json
apply-result.json
rollback-guidance.md
```

`DryRun` creates the plan, manifest, and result evidence. `Preflight` adds verified RV&S evidence. `Apply` creates the apply result only after all gates pass.

## Folder Templates

Run `CreateProjectTemplate` against a source tree to generate `project-template.json`. For a folder request, omit `folders` and set `templatePath` to that file. The skill reads only the template's `directories[].RelativePath` values and rejects absolute or traversal paths.

## Member Administration

Copy `assets/member-administration-profile.example.json` into reviewed organization configuration and populate verified command paths. The preflight validation command must be read-only and must exit nonzero when access is invalid. Until it is configured and verified, member, role, and permission operations stop safely.
