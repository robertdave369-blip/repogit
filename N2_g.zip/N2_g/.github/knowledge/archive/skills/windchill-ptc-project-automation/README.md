# Windchill PTC Project Automation

This workspace skill packages governed Windchill RV&S automation. It is deliberately plan-first and preflight-first.

## Package Contents

```text
SKILL.md                         Copilot workflow and guardrails
manifest.json                    Skill package inventory
config/defaults.json             Default policy and disabled admin profiles
scripts/WindchillPtc.Automation.psm1
                                 Reusable PowerShell functions
scripts/Invoke-WindchillPtcAutomation.ps1
                                 Command entry point
scripts/Test-WindchillPtcAutomation.ps1
                                 No-server self-test
assets/request-template.json     Structured request contract
assets/member-administration-profile.example.json
                                 Organization-specific admin profile template
examples/                        Ready-to-copy request examples
references/                      Operation and governance contracts
```

## Quick Start

```powershell
$skill = ".github\skills\windchill-ptc-project-automation"
$entry = Join-Path $skill "scripts\Invoke-WindchillPtcAutomation.ps1"
$request = Join-Path $skill "examples\upload-initializers.request.json"

& $entry -RequestPath $request -Mode DryRun
& $entry -RequestPath $request -Mode Preflight
```

Review `windchill-ptc-audit/<timestamp>/plan.json` and `preflight.json` before setting the request approval object and using `-Mode Apply -Approve`.

## Security Boundary

No default configuration can add users, remove users, change roles, or modify permissions. Those operations require a verified customer-specific external administration profile. This avoids inventing an RV&S administrative command where the installed client and server policy do not supply one.
