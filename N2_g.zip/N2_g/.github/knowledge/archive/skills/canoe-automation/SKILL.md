---
name: canoe-automation
description: 'Use when planning, implementing, reviewing, or troubleshooting Vector CANoe automation, CANoe configurations, restbus simulation, vTESTstudio tests, measurement control, trace analysis, DBC binding, or interoperability with ARIA/APYM in Framework_IOEM_Py. Requires proof of the installed Vector toolchain and project artefacts before asserting an integration exists.'
argument-hint: 'Describe the CANoe configuration, Vector artefacts, project, and desired automation or analysis'
user-invocable: true
disable-model-invocation: false
---

# CANoe Automation

## Scope

Use CANoe for verified configuration-based network simulation, stimulation, measurement, diagnostics, restbus behavior, and trace analysis. Use the separate `capl-programming` skill when authoring or reviewing CAPL.

The repository provides verified APYM/ARIA simulation and diagnostic wrappers. It does not by itself prove direct CANoe automation. Before proposing code or a workflow, verify the installed CANoe version/licence, configuration, DBCs, CAPL/vTESTstudio artefacts, Vector interface/API, channel mapping, and any existing bridge script.

## Workflow

1. Inventory the target CANoe configuration, Vector version, hardware interface, channel mapping, DBCs, restbus nodes, CAPL programs, test modules, vTESTstudio project, and automation entry point.
2. Confirm that each message, signal, diagnostic route, timing, and expected value comes from the target project source. Treat a display in CANoe as a decoded view, not proof of the underlying definition.
3. Choose one operating model:
   - CANoe performs simulation/testing; ARIA/APYM is absent.
   - ARIA/APYM performs the test; CANoe observes and records evidence.
   - A verified bridge controls both tools with explicit startup/shutdown and channel ownership.
4. Define deterministic setup, measurement start, ECU/bus readiness, stimulus, observation window, verdict criteria, log export, cleanup, and recovery.
5. Validate offline where possible, then review with traces showing message IDs, decoded signals, timestamps, diagnostic transactions, and test verdicts.

## Restbus And Test Design

Model only the nodes, frames, counters, CRC/E2E behavior, timing, and state transitions evidenced for the target test. Include startup, normal operation, relevant fault behavior, recovery, and shutdown. Avoid an overbroad restbus simulation that silently masks missing ECU behavior.

For vTESTstudio or CANoe test modules, require explicit preconditions, deterministic stimulus, measured expected values/tolerances, timeouts, traceable verdicts, cleanup, and requirement links. Keep test parameters configuration-driven and version control all project artefacts used in the result.

## Safety Boundary

Do not start a CANoe measurement, connect a Vector interface, transmit frames, invoke diagnostics, inject a fault, or interact with a physical ECU without explicit user authorization. If integration evidence is absent, report `Evidence unavailable.` and recommend ARIA/APYM testing plus CANoe observation, or a separately reviewed bridge proposal.

## Portfolio Handoff

For a multi-skill workflow, preserve the Vector version/license, configuration and DBC hashes, channel ownership model, bridge status, measurement lifecycle, generated traces, verdict artifacts, and live-execution authorization. Hand CAPL implementation to `capl-programming`, protocol evidence to `can-protocol-automotive-networks`, and diagnostic transactions to `uds-diagnostics`.

## Completion Criteria

The automation or analysis is complete when the toolchain and configuration are identified, channel ownership is unambiguous, inputs/outputs are traceable to project sources, logs preserve reproducible evidence, and authorization exists for any bench-affecting action.