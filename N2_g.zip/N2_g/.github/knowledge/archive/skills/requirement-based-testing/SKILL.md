---
name: requirement-based-testing
description: 'Use when analyzing requirements, creating or reviewing airbag ECU test cases, building traceability, planning execution, reporting defects, or working with Codebeamer, DOORS, Polarion, Jira, Excel exports, and requirement-to-test evidence in Framework_IOEM_Py. Produces a minimal high-value, traceable test suite without inventing requirement IDs or changing read-only requirement sources.'
argument-hint: 'Describe the project, requirement source, module, and desired test-design or review outcome'
user-invocable: true
disable-model-invocation: false
---

# Requirement-Based Testing

## Scope

Use this skill to transform verified product or software requirements into test objectives, a prioritized test suite, an execution plan, traceability, and evidence-backed defect findings. Treat requirement exports as evidence, not automatic truth; correlate them with design, configuration, DBC, code, and logs.

Requirement sources under `req/` are read-only. Use only approved target-variant requirements and never invent a Codebeamer, DOORS, Polarion, Jira, or local identifier.

## Workflow

1. Identify the project/variant, release, module, requirement source, approval/status, ASIL/priority where supplied, and intended verification method.
2. Extract the entire source with provenance. For Excel, read every worksheet and row, resolve columns by header name, preserve engineering tokens and struck/deleted content, and validate the extraction. For other trackers, preserve item IDs, version/status, links, and source location.
3. Decompose each approved requirement into conditions, inputs, states, interfaces, outputs, timing, persistence, fault behavior, and constraints. List ambiguities and contradictions before designing tests.
4. Derive test objectives, then select a minimal high-value set using equivalence partitioning, boundaries, state transitions, decision coverage where meaningful, negative testing, fault injection, temporal checks, recovery, and risk/ASIL priority.
5. Build forward and backward traceability: requirement -> test objective -> test case -> script/manual procedure -> result/log -> defect or closure. Do not create orphan cases or unverified links.
6. Execute only when authorized and evidence-ready. Report actual versus expected behavior, source artefacts, reproduction conditions, severity/risk, scope, and confidence.

## Test Case Quality

Each case needs a unique intent, verified requirement reference, priority, preconditions, configuration/variant, controlled stimulus, measurable expected result, timing/tolerance, evidence to capture, cleanup/recovery, and an unambiguous pass criterion. Place safety-critical and highest-value cases first.

Do not create superficial tests simply to raise coverage counts. Explicitly report uncovered or untestable behavior, missing requirements, missing configuration, unavailable fault methods, and test-environment limitations.

## Generated Test Location

When requirement analysis produces an executable test file, create it as
`tests/test_<feature>.py`. Place generated test support folders, fixtures, and traceability
artifacts within `tests/`; do not create a separate top-level test-output directory. Existing
project scripts and runtime result/log locations remain unchanged unless explicitly migrated.

## Defect Reporting

State the requirement or evidence source, observed behavior, expected behavior, reproducible procedure, project/software/configuration identity, captured logs, impact, suspected scope, and confidence. Separate fact from inference and avoid assigning root cause without correlated evidence.

## Portfolio Handoff

For a multi-skill workflow, preserve approved requirement IDs/status, source provenance, decomposition results, contradiction disposition, objectives, traceability links, coverage gaps, and defect evidence. Hand safety-critical objectives to `functional-safety-iso26262`, implementation-ready objectives to `python-test-automation`, and target execution constraints to `embedded-systems-fundamentals`.

## Completion Criteria

The work is complete when all included cases map to valid target-variant requirements, the suite addresses the requirement's state, boundary, negative, and timing risks, results have reproducible evidence, and coverage gaps or contradictions are visible.