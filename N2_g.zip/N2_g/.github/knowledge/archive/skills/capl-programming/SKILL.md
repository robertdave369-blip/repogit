---
name: capl-programming
description: 'Use when learning, designing, implementing, reviewing, or debugging CAPL for Vector CANoe/CANalyzer: event handlers, messages, signals, timers, diagnostics, restbus simulation, test modules, logging, and DBC-bound behavior. Keeps CAPL configuration-driven and does not assume CANoe/CANalyzer artefacts or hardware access exist in Framework_IOEM_Py.'
argument-hint: 'Describe the CANoe/CANalyzer version, configuration artefacts, CAPL role, and requested behavior'
user-invocable: true
disable-model-invocation: false
---

# CAPL Programming

## Scope

Use CAPL for event-driven behavior in a verified Vector CANoe/CANalyzer configuration: frame/signal observation, restbus simulation, timed behavior, diagnostics, logging, and test-module checks. This skill covers CAPL logic; use `canoe-automation` for CANoe lifecycle and integration planning.

Do not assume a CAPL source, CANoe/CANalyzer version, Vector interface, DBC, or test configuration exists in this repository. Inspect the supplied project artefacts first and report `Evidence unavailable.` when they are absent.

## Workflow

1. Identify the configuration, CANoe/CANalyzer version, CAPL program type, assigned network/channel, database binding, intended node/test role, and interface to other tools.
2. Verify every message, signal, ID, direction, cycle time, counter, CRC/E2E field, diagnostic route, and timeout from the active target configuration/DBC.
3. Choose the appropriate event model: startup/shutdown, message reception, signal update, timer, diagnostic callback, user/test event, or error condition. Avoid polling where a deterministic event exists.
4. Define state explicitly. Initialize it at measurement start, handle missing/late/repeated messages, bound all timers/retries, and clean up on measurement end.
5. For restbus simulation, model only the verified node/frame behavior needed by the test, including counter/CRC/E2E and fault/recovery semantics where specified.
6. Validate with compilation plus an offline/configuration review before a live measurement. Correlate CAPL log output with decoded trace evidence.

## CAPL Design Rules

- Use DBC-bound symbolic messages and signals whenever the active configuration provides them; avoid duplicated literal identifiers and bit decoding.
- Keep signal conversion, counter/CRC/E2E, and timing aligned with project configuration. Do not guess a checksum algorithm or timing threshold.
- Write diagnostic logic only after verifying the ISO-TP route, UDS session/security preconditions, request format, and response/NRC contract.
- Create deterministic logs and verdicts that name the observed frame/signal/transaction and expected condition.
- Keep hardware-specific startup, channel mapping, and external-tool interaction outside reusable CAPL logic unless the project proves the interface.

## Safety Boundary

CAPL can transmit messages and stimulate a physical ECU. Do not compile-and-run against a connected bench, invoke diagnostics, or inject faults without explicit user authorization. Review generated behavior for accidental frame transmission and unsafe default values.

## Portfolio Handoff

For a multi-skill workflow, preserve the active configuration, DBC binding, event model, state/timer bounds, message/signal names, test verdict/log schema, compile result, and bench authorization. Hand measurement lifecycle to `canoe-automation`, protocol checks to `can-protocol-automotive-networks`, and UDS behavior to `uds-diagnostics`.

## Completion Criteria

The CAPL result is complete when its event model and state handling are deterministic, all communication values are source-backed, configuration dependencies are documented, logs give reproducible evidence, and live execution remains authorization-gated.