---
name: can-protocol-automotive-networks
description: 'Use when analyzing, implementing, reviewing, or testing CAN, CAN FD, DBC files, signals, CANoe, CANalyzer, CAPL, ISO-TP, UDS, network management, CRC/E2E, SecOC, diagnostic DTCs, ARIA configuration, or CAN logs in Framework_IOEM_Py. Produces an evidence-grounded, project-scoped conclusion, change, or test design without inventing protocol values or operating bench hardware.'
argument-hint: 'Describe the project, artefacts, and desired CAN or diagnostic outcome'
user-invocable: true
disable-model-invocation: false
---

# CAN Protocol And Automotive Networks

## When To Use

Use this skill for a CAN or CAN FD communication question, DBC/matrix or log analysis, ISO-TP or UDS diagnosis, network-management behavior, CAN fault/DTC mapping, E2E/CRC/SecOC review, ARIA CAN configuration, or a test/script change that sends, suppresses, or observes CAN traffic.

Use project-specific sources rather than applying values from another ECU variant. If the request only needs a generic explanation, state that it is generic and do not imply it describes the target ECU.

## Safety And Evidence Rules

1. Identify the target project, ECU variant, bus/channel, intended operation, and supplied artefacts before drawing a conclusion. Load the root `agent.md` when it is available; if it is unavailable, report that evidence gap.
2. Treat requirements, DBCs, code, configurations, and logs as independently fallible. Record each important conclusion as **Fact**, **Inference**, or **Assumption**, with source provenance and a confidence level.
3. Do not invent CAN IDs, signal names, scaling, bit layout, byte order, cycle times, DTCs, UDS routes, security algorithms, timing limits, requirement IDs, or shared-library APIs. Mark missing information as `Evidence unavailable.`
4. Never execute a test, transmit a frame, create a network fault, flash an ECU, cycle hardware power, or perform an irreversible write merely because a script can do so. Deliver bench-affecting code unexecuted unless the user explicitly requests execution.
5. Preserve project isolation. Resolve constants, channels, IDs, timing, DBC assets, service catalogs, and DTC catalogs from the target project configuration or verified source only.

## Workflow

### 1. Classify The Request

Choose the primary path and keep secondary paths only where they affect the result:

| Request | Primary path |
| --- | --- |
| Explain or investigate a behavior | Requirements, configuration, DBC, code, then decoded evidence |
| Analyze a DBC, matrix, or CAN log | Source inventory, native parser, decode, temporal checks, conclusion |
| Diagnose UDS/ISO-TP traffic | Route reconstruction, transport timeline, service/NRC analysis |
| Add or change framework code | Project configuration, existing wrappers, smallest change, focused validation |
| Design or review tests | Requirement decomposition, fault model/state model, traceable coverage |
| Assess CRC, E2E, SecOC, or replay protection | Security architecture, verified parameters, attack/failure separation |

### 2. Establish The Evidence Set

1. Inventory the target project configuration, relevant DBC/matrix, service and DTC catalog, requirement source, shared-library wrapper, test script, and capture/log.
2. Capture provenance for every extracted item: file, sheet/page/row or message/signal, and relevant timestamp or frame position.
3. Record contradictions immediately. Do not silently choose one source; determine which source is authoritative for the question or leave the conflict unresolved.
4. For spreadsheets, extract every sheet and row, resolve fields by header name, preserve engineering tokens and deleted/struck content, and validate the extraction against the workbook.

### 3. Verify The Network Definition

For each affected message or route, establish:

- CAN versus CAN FD, bus/channel, arbitration ID, addressing mode, DLC/payload length, sender, receiver, direction, and cycle/event behavior.
- Signal start bit, length, byte order, signedness, scaling, offset, units, valid range, invalid encoding, mux condition, alive counter, CRC/E2E fields, and required freshness semantics.
- Network-management/wake/sleep prerequisites and state transitions where applicable.
- Diagnostic physical and functional request IDs, response ID, ISO-TP addressing, padding, block size, `STmin`, timeout parameters, session, security, and expected positive/negative response behavior.

Use `cantools`, `canmatrix`, `python-can`, or `asammdf` when the supplied format supports it. For large logs, stream or query in chunks; do not load multi-gigabyte captures wholesale. Cross-check parser output with a source record or known decoded frame before relying on it.

### 4. Analyze The Applicable Protocol Layer

**Frame/signal behavior:** Decode raw bytes to engineering values. Check identifier format, DLC, endianness, scaling, enumerations, counter progression, CRC/E2E calculation, multiplexing, timing, jitter, timeout, and cross-signal plausibility.

**ISO-TP/UDS:** Reconstruct the full ISO-TP transaction timeline: request, flow control, consecutive frames, response, timing, and errors. Confirm service/session/security preconditions before judging a response. Follow ISO 14229 unless a verified project/OEM deviation applies; distinguish an observed `NRC` from an assumption.

**CAN faults and DTCs:** Separate node absence, message timeout, message content failure, signal range/content failure, counter failure, CRC/E2E failure, and physical bus fault. Verify qualification, healing, storage, reporting, and status-byte behavior from project evidence. Do not equate a generic timeout with a node-absence fault.

**Security and integrity:** Verify CRC/E2E parameters from the project DBC/E2E configuration before calculation. Distinguish E2E protection against accidental corruption/basic replay from SecOC authentication against a deliberate attacker; never call an unauthenticated frame secure.

### 5. Implement Or Design Tests Safely

1. Trace the behavior through requirement -> message/signal/route -> configuration -> wrapper/code -> test -> expected log evidence.
2. For Python framework scripts, use target-project configuration values and verified `shared_libraries` wrappers only. Do not call underlying `Api.*` or ARIA internals directly, hard-code a channel/ID/timing value, or alter a shared-library signature.
3. If an appropriate wrapper does not exist, stop before adding direct bench calls. Propose the project-agnostic wrapper location and signature, and ask for approval where required.
4. Derive a minimal high-value test set using equivalence classes, boundaries, state transitions, negative tests, fault injection, temporal conditions, and recovery/healing checks. Include only verified requirement IDs.
5. Tie every wait to an evidenced protocol, requirement, or configuration timing value. Include ignition-cycle or power-cycle behavior only where the verified behavior requires next-cycle semantics.

### 6. Validate And Report

Before closing, check:

- The project variant and all protocol values were resolved from cited evidence.
- DBC decoding, configuration, code, and log observations agree, or every conflict is reported.
- Timing covers both nominal and failure/recovery paths.
- Any DTC expectation differentiates activation, qualification, status, healing, and clearing behavior.
- The change uses existing abstraction boundaries and has focused validation evidence.
- No bench-affecting action was executed without explicit user authorization.

Report the result in this order: scope and artefacts; verified facts; inferences and assumptions; contradictions/evidence gaps; impact or root cause; recommended code/test/configuration action; validation; confidence and residual risk.

## Framework Anchors

- `shared_libraries/can_library.py`: CAN message, signal, and DTC mapping helpers.
- `shared_libraries/jscript_translation.py`: ARIA-facing CAN and bench wrapper surface; inspect names and signatures before use.
- `shared_libraries/core_functions.py`: protocol/test orchestration helpers, including diagnostic session and fault-frame handling.
- `projects/<project>/config/`: authoritative project-scoped configuration location.
- `docs/aria_config_assistant/`: ARIA package and CAN/ISO-TP configuration relationships.

## CANoe, CANalyzer, And CAPL

Treat Vector tooling and ARIA/APYM as separate execution environments unless a version-controlled integration artefact proves otherwise. Before proposing integration, inspect the target machine and project for a CANoe/CANalyzer configuration, DBC binding, CAPL node or test module, vTESTstudio project, Vector API/COM interface, and bus-interface/channel mapping.

- **CANoe:** use it to configure, simulate, stimulate, trace, and validate a network only from the target project's verified configuration. Map each simulated frame/signal and diagnostic route to the same DBC/configuration source used by the framework.
- **CANalyzer:** use it for passive capture, decoding, timing, counter/CRC, and diagnostic timeline analysis. Preserve the original capture and identify the active DBC and filter set used for decoding.
- **CAPL:** use it for CANoe-side event-driven simulation, checks, and restbus behavior. Keep CAPL's configuration-controlled values aligned with the source DBC; do not duplicate unverified IDs, signal layouts, or timeout values.
- **ARIA/APYM:** this framework's verified path is through `shared_libraries` wrappers and APYM. It can simulate and change configured CAN frames/signals and issue diagnostics through ARIA, but this alone is not evidence of CANoe/CANalyzer control.

If no connector is found, report `Evidence unavailable.` and choose one validated approach: run the ARIA/APYM test independently while using CANoe/CANalyzer for observation, or propose a reviewed adapter with explicit ownership, version compatibility, channel mapping, startup/shutdown, error handling, and offline validation. Never start a Vector tool, connect hardware, or transmit traffic without explicit user authorization.

## Portfolio Handoff

For a multi-skill workflow, emit the evidence-envelope fields for the verified project/variant, bus/channel, message/signal/route map, timing values, DBC/configuration sources, decoded observations, contradictions, and bench authorization state. Hand off UDS service questions to `uds-diagnostics`, measurement ownership to `canoe-automation`, CAPL logic to `capl-programming`, and executable test realization to `python-test-automation`.

## Completion Criteria

The task is complete only when the stated result is reproducible from its sources, protocol values and routes are project-specific or explicitly unavailable, contradictions are visible, the implementation/test respects the wrapper boundary, and validation evidence supports the conclusion at its stated confidence.