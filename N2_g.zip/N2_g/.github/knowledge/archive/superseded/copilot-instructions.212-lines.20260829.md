# Copilot instructions — Framework_IOEM_Py (Mahindra SC3 2S Airbag ECU test framework)

**The definitive knowledge base for this repository is `.github/agents/agent_sc3.md`.**
(It is *not* at the repo root, despite older references. `.copilot/agent_sc3.md` is an
older, shorter copy - do not use it. ARIA configuration is `.github/agents/aria_agent.md`.)
Before answering ECU-behavior questions, writing test cases, mapping requirements, or generating
framework scripts, open and follow `agent_sc3.md`. Its rules override your defaults. Key entry points:

- **Operate under `agent_sc3.md` §0 at all times** (Core Engineering Principles): engineering
  quality over speed; assume requirements/tests/code/docs/DBC/diagnostics may be wrong — verify
  independently, never trust a document because it exists; every conclusion needs evidence or
  the explicit statement "Evidence unavailable.", a confidence level (Very High…Unknown), and
  clear fact vs inference vs assumption labelling; follow the §0.4 workflow, correlate across
  all documents (never analyse in isolation), report every contradiction with evidence, run
  change-impact analysis on any artefact change, pass the §0.11 quality gates, self-review from
  the §0.13 engineering perspectives, and treat a task as complete only per §0.15.

- ECU behavior / requirements / protocols: `agent_sc3.md` §1–§12 (modules, CAN-C, NM, UDS, EDR,
  FltMonr, GPO/ENS, RSU, EOL/VC/VIN) and §3.1 discrepancy register **D-01…D-12** — never implement
  around a D-xx item without surfacing it.
- Writing test cases: `agent_sc3.md` §16 (Veoneer Excel format, **mandatory**) + §16.10 (test-design
  methodology, **mandatory**): never generate cases just to satisfy requirements or raise
  counts — analyse and decompose each requirement, derive objectives, then design a minimal
  high-value suite (equivalence/boundary/state-transition/MC-DC/risk-based + negative and
  fault-injection sweeps), merged/deduplicated, with a coverage report listing uncovered
  behaviour and full traceability (no orphan cases) — and **order the spec priority-first
  (safety-critical/high-value cases at the top)**. Every test case must carry correct Codebeamer
  requirement IDs mapped per §16.2 (search the correct variant's tracker, Approved rows only,
  never invent IDs). DTC status bytes per §16.3: **CAN faults active = `0B`**, crash locks `8B`,
  UV/OV stays `08`. NRC expectations per §16.4. Project-variable facts (ENS PWM duty 62.5/37.5
  vs 60/40, PAB-lamp input signal name) must be confirmed from that project's config/tracker or
  asked — PAB-ON lamp is ON by default in Mahindra projects; ENS and PAB lamps are low-side
  driven (agent_sc3.md §2.5/§26.1).
- Test-specification routing: whenever a user asks to create a test specification, generate a
  Veoneer spec, create test cases from requirements, create a Codebeamer import file, or generate
  a specification from Excel, Word, PDF, Codebeamer-exported, textual, or mixed requirement
  sources, load and use `.github/skills/veoneer-test-spec-generator/SKILL.md` as the preferred
  generation workflow. Its template-profile validation does not replace the §16 evidence,
  traceability, approval-status, or project-variant rules above.
- **Capability-first source ingestion (mandatory)**: before reading any Excel, PDF, Word,
  PowerPoint, Markdown, HTML, CSV, JSON, XML, or tabular source, inspect available Python
  packages and select the highest-fidelity parser(s) available rather than minimizing
  dependencies. Prefer semantic and layout-aware extraction; use PyMuPDF, pdfplumber,
  unstructured, Polars, PandasAI, LangChain document loaders, and LlamaIndex readers where
  suitable and available. Use multiple extraction engines when that improves accuracy; preserve
  document structure, tables, relationships, metadata, page hierarchy, and contextual
  information. State the selected libraries and rationale in the solution. Accuracy and context
  preservation take priority over dependency minimization, while the required project-specific
  source workflows below remain mandatory.
- Reading any Excel/requirement source: `agent_sc3.md` §16.5 — dump the whole workbook with openpyxl
  (every sheet, every row), resolve columns by header NAME not index, decode Codebeamer
  escapes/markup (strikethrough = deleted text), verify the extraction, and never work from a
  partial read, preview, or memory of the file.
- Reading PDFs/Word docs: `agent_sc3.md` §16.6 — pick the right library per document
  (pymupdf/pdfplumber/camelot; OCR via ocrmypdf/pytesseract for scanned pages with confidence
  flagged; python-docx for Word), keep tables and page references intact, cross-check
  completeness, and report extraction quality instead of guessing missing content.
- Reviewing test cases/implementations: `agent_sc3.md` §19 — ingest and correlate all sources first,
  build module-aware context, apply the §19.3/19.4 checklists, back every finding with evidence
  (§19.6: requirement ID / DBC / code / standard clause — say "information unavailable" instead
  of assuming), and deliver the §19.7 report (severity, RTM, coverage matrix, risk, confidence).
- Large/batch tasks: orchestrate per `agent_sc3.md` §17 (planner → parallel specialized workers →
  single integration → mandatory verifier gate). Instantiate the applicable §17.3 domain
  specialists (Requirements, Architecture, Design, Safety, AUTOSAR, Communication, Diagnostics,
  Test, Static-Analysis, Documentation, Verification, Research, Cybersecurity) with §17.4
  independence rules;
  pick the execution substrate per §17.5 — simulated passes in one chat (always works), in-IDE
  subagents/custom agents (`.github/agents/*.agent_sc3.md`), parallel Copilot CLI terminal instances,
  or delegation to the cloud coding agent for self-contained repo tasks returning a PR — falling
  back gracefully when a substrate is unavailable; work incrementally (§17.6), run the §17.7
  self-verification loop, and deliver the §17.8 unified report.
- Excel analysis additionally requires the §16.7 sanitization pipeline (strip presentation
  artifacts only, preserve every engineering token, `[STRUCK:]` markers for deleted text,
  integrity verification) before any requirement extraction or test generation.
- DBC and CAN/diagnostic log analysis: `agent_sc3.md` §16.8 — highest-fidelity parser per format
  (cantools/canmatrix/python-can/asammdf; polars/pyarrow for large data; install any needed
  library into the correct interpreter instead of lossy manual parsing), DBC extraction via
  `tools\extract_dbc_signals.py`, stream multi-GB logs (never load whole), decode frames to
  engineering values, run signal-level/temporal/intelligent-DBC checks, build the ISO-TP
  diagnostic timeline, and verify the requirement→signal→message→code→test→log chain with
  evidence-based root-cause findings.
- Any file format: `agent_sc3.md` §16.9 — approved library manifest in
  `tools\analysis-requirements.txt` (install on demand; note external binaries), fallback parser
  chains that switch on quality signals (not just exceptions), extraction validated against the
  source's own page/sheet/row counts, everything normalized into one common internal model, and
  provenance (file + sheet/page + row/cell/XML path) recorded on every extracted item.
- Writing Python test scripts: `agent_sc3.md` §18 — module scripts use module config files +
  `shared_libraries\` wrappers ONLY (verify name + signature in source first; never call the
  underlying library internals / `Api.*` directly — §18.1 layering rule), all constants from
  `projects\<project>\config\` or the DBC (missing constant → inform the user + suggest a
  maintainable config placement, §18.2), every Sleep/Wait traceable to a spec time, no sleeps in
  T0-relative EDR sequences, ignition cycle where next-cycle semantics apply, and every script
  as clean as the EDR scripts (§18.5 gold standard — one `run_test()`, no local helpers, no
  hard-coding). If a wrapper exists nowhere in `shared_libraries`: STOP and suggest/ask
  permission to create one, only if genuinely required, with a §18.4 proposal (bench wrappers →
  `jscript_translation.py`, user-defined functions → `core_functions.py`, both project-agnostic);
  for legacy ARIA JS functions follow §18.6 (same ARIA name/prototype, config-resolved channel
  like `CAN.SendDiagByValues`, `["0000", …]` return contract).
- ARIA bench environment, fault creation, instruments & hardware: `agent_sc3.md` §25 (ARIA 5.20
  system — canonical docs at `C:\ARIA5.20\`; bench/config model, APYM, RTSE, loadbox load
  states) — create every fault strictly per the **§25.5 fault-creation catalog; if the fault
  isn't covered or you're in any doubt how to create it in a script, ask the user for
  suggestions instead of guessing**. Saleae/oscilloscope PWM setup per §26 (ENS: 40 ms period,
  62.5 % normal / 37.5 % crash duty). Electrical and protocol questions (connections,
  shorts/opens/leakage, terminations, SPI CPOL/CPHA, PSI5 current modulation, CAN/CAN FD
  physical, LIN/K-line, PWM) answered from §27 only as defined there.
- Cybersecurity / CRC / communication protection: `agent_sc3.md` §28 — for any task touching secure
  boot/flashing, secure diagnostics, SecOC, AUTOSAR E2E, MAC/freshness/replay, CRC, or alive/
  rolling counters, work as a senior automotive cybersecurity engineer: understand the security
  architecture before implementation; run the §28.2 review workflow; take CRC/E2E parameters
  from the §28.10 reference (CRC-8 J1850/8H2F, CRC-16 CCITT/ARC, CRC-32/32P4, CRC-64; AUTOSAR
  E2E P1–P7) but **verify against the project DBC/E2E config**; distinguish E2E (accidental
  corruption/basic replay) from SecOC/MAC (deliberate attacker) — never call an unauthenticated
  message "secure"; treat weaknesses on deployment/flash/NVM-identity paths as safety issues;
  report findings in the §28.12 format with confidence and safety impact. **Follow UDS per
  ISO 14229 (§4.3) — deviate only for a documented OEM deviation or an explicit user request.**
- Full behavioral rules for the AI: `agent_sc3.md` §20 (Copilot Instructions).
- Environment map, interpreter paths and the constants quick-reference card: `agent_sc3.md` §21.
  Task playbooks (which sections to follow per task type): §22. Glossary: §24.
- **Safety boundaries (`agent_sc3.md` §23, non-negotiable)**: this repo's scripts actuate real
  hardware (power, squib deployment, flashing, irreversible NVM writes). Writing code is NOT
  permission to run it — never execute anything that reaches the bench/ECU unless the user
  explicitly asked to run it; deliver scripts as unexecuted files and say so.

Hard rules even without opening agent_sc3.md: never invent requirement IDs, DTC codes, or
shared-library function names — verify each in the source tracker/file first; never hard-code
channel numbers, message IDs, or timing values in scripts (config-driven only; missing config →
inform user + suggest placement); never modify existing shared-library function signatures;
scripts call shared-library wrappers only, never library internals; new bench wrappers go in
`jscript_translation.py`, new user-defined functions in `core_functions.py`, both working across
all projects; unsure how to create a fault → ask; requirement sources under `req\` are read-only.

**Generated artifact location policy**: new test-related source files generated by any skill go
directly under `tests\` using `test_<feature>.py`; generated test support folders and validation
artifacts also stay within `tests\` (including `tests\dependency_management\`). Do not relocate
existing project scripts or configuration-controlled runtime `test_results\` and `test_logs\`
paths without an explicit migration request. Original customer documents remain under `docs\`;
only extracted or processed document artifacts go under
`docs\processed_Documents\<source-document-stem>\`, preserving source-stem casing after
filesystem-safe sanitization.

---

## Automated guardrails in this workspace (read this)

This repository does not rely on you remembering the rules above. Four mechanisms enforce
them, and they will interrupt you:

1. **`.github/instructions/*.instructions.md`** attach automatically based on the file in
   context — test scripts, project configs, shared libraries, generators, tests and docs
   each get their own rules. Follow them; they are more specific than this file.

2. **`.github/hooks/`** runs on every turn:
   - *SessionStart* injects the framework briefing and the persistent cache;
   - *UserPromptSubmit* matches your request against `.github/hooks/scripts/routing.json`
     and names the skill or document to open — do open it;
   - *PreToolUse* **refuses** edits to generated files, destructive git/filesystem commands,
     and anything that runs a bench script. If it refuses you, do not route around it: read
     the reason, and either fix your approach or ask the user;
   - *PostToolUse* checks every Python file you write and hands back the specific violations
     — fix them in the same turn;
   - *PreCompact* preserves verified values across automatic summarization.

3. **Persistent cache** at `.github/cache/session.json`, injected at session start and
   cleared only by `/cache-clear`. When you verify something durable, bank it:
   `py -3 .github/hooks/scripts/cache.py fact "<what>" --evidence "<source>"`.
   Cache only what you verified — a wrong cached fact is worse than an empty cache.

4. **Slash commands** in `.github/prompts/`: `/new-test-script`, `/regenerate`,
   `/verify-claim`, `/review-change`, `/cache-save`, `/cache-clear`. They encode the
   step order for these tasks; prefer them over improvising.

Tool calls are auto-approved in this workspace, so the user is not confirming each step.
That makes the PreToolUse hook the only thing between you and an irreversible action —
and it makes it your responsibility to state clearly what you are about to do before doing
anything that reaches hardware, rewrites history, or deletes work.

## Corrections are durable

`.github/knowledge/rejections.md` holds every correction the user has made, converted
into a rule. **Read its rules index before proposing work in a scope that has rules.**
Re-breaking a rule the user already corrected is the most expensive failure here: it
proves the memory does not work, and it costs the trust that makes the rest useful.

When the user corrects you, record it in the same turn — do not leave it in scrollback:

```
py -3 .github/scripts/log_rejection.py --scope <scope> \
    --proposed "<what you proposed>" --wrong "<why it was wrong>" --rule "<the rule>"
```

## Multi-agent work

For a task spanning more than one domain, or where being wrong is expensive, use the
`swarm-orchestrator` agent. It dispatches specialists, then gates the result through an
independent verifier and an intent-fidelity check before anything is reported.

Specialists return evidence-handoff objects; the orchestrator runs
`py -3 .github/scripts/review_gate.py <dir>` and reports only what the gate surfaces.
Held findings are open threads, never conclusions.

**No agent holds `execute`.** Writing a script is not running it. Agents report what
should be run; the user or the main agent runs it.

Harness guards, all runnable by hand:

| Command | Checks |
|---|---|
| `py -3 .github/scripts/validate_agents.py` | agent frontmatter, roles, tool restrictions |
| `py -3 .github/scripts/review_gate.py <dir>` | evidence, self-critique, dedup, confidence |
| `py -3 .github/scripts/check_source_diversity.py <dir>` | false consensus |
| `py -3 .github/scripts/build_skill_catalogue.py` | regenerates the skill catalogue |
