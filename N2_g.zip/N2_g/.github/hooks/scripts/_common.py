"""Shared plumbing for the Framework_IOEM_Py agent hooks.

Hooks run on every agent turn, so the rules here are strict:

* never raise — a crashing hook degrades or stalls the session;
* never block on I/O — no network, no heavy parsing;
* always exit 0. A hook refuses a tool by *printing* a deny decision, not by
  failing (see ``deny``).

VS Code passes the event payload as JSON on stdin and reads a JSON object from
stdout. Field names follow the gpt / Copilot CLI hook format.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

# .github/hooks/scripts/_common.py -> repo root is four levels up.
REPO_ROOT = Path(__file__).resolve().parents[3]
GITHUB_DIR = REPO_ROOT / ".github"
CACHE_DIR = GITHUB_DIR / "cache"

# Keys different tools use for "the file this touches" and "the command to run".
_PATH_KEYS = ("filePath", "file_path", "path", "uri", "targetFile", "target_file")
_COMMAND_KEYS = ("command", "commandLine", "command_line", "script", "input")


def read_event() -> dict[str, Any]:
    """Read the hook payload from stdin. Returns {} if there is nothing usable."""
    try:
        raw = sys.stdin.read()
    except Exception:
        return {}
    if not raw or not raw.strip():
        return {}
    try:
        payload = json.loads(raw)
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def tool_name(event: dict[str, Any]) -> str:
    return str(event.get("tool_name") or event.get("toolName") or "")


def tool_input(event: dict[str, Any]) -> dict[str, Any]:
    value = event.get("tool_input") or event.get("toolInput") or {}
    return value if isinstance(value, dict) else {}


def touched_path(event: dict[str, Any]) -> Path | None:
    """Best-effort: the file path a tool call is about, as an absolute Path."""
    payload = tool_input(event)
    for key in _PATH_KEYS:
        value = payload.get(key)
        if not value or not isinstance(value, str):
            continue
        text = value.removeprefix("file:///").removeprefix("file://")
        try:
            candidate = Path(text)
            return candidate if candidate.is_absolute() else (REPO_ROOT / candidate)
        except Exception:
            continue
    return None


def touched_command(event: dict[str, Any]) -> str:
    """Best-effort: the shell command a tool call would run."""
    payload = tool_input(event)
    for key in _COMMAND_KEYS:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


def inside_repo(path: Path) -> bool:
    try:
        path.resolve().relative_to(REPO_ROOT)
        return True
    except Exception:
        return False


def relative(path: Path) -> str:
    try:
        return path.resolve().relative_to(REPO_ROOT).as_posix()
    except Exception:
        return str(path)


def emit(event_name: str, **fields: Any) -> None:
    """Write the hook result and exit successfully."""
    output = {"hookSpecificOutput": {"hookEventName": event_name, **fields}}
    try:
        sys.stdout.write(json.dumps(output))
        sys.stdout.flush()
    except Exception:
        pass
    sys.exit(0)


def context(event_name: str, text: str) -> None:
    """Inject text into the agent's context, or exit quietly if there is none."""
    if not text or not text.strip():
        sys.exit(0)
    emit(event_name, additionalContext=text.strip())


def deny(reason: str) -> None:
    """Refuse a tool call. The reason is shown to the agent so it can correct itself."""
    emit(
        "PreToolUse",
        permissionDecision="deny",
        permissionDecisionReason=reason.strip(),
    )


def guarded(main) -> None:
    """Run a hook body so that any failure degrades to a no-op instead of a stall."""
    try:
        main()
    except SystemExit:
        raise
    except Exception as error:  # noqa: BLE001 - a hook must never take the session down
        if os.environ.get("IOEM_HOOK_DEBUG"):
            sys.stderr.write(f"hook error: {type(error).__name__}: {error}\n")
        sys.exit(0)
