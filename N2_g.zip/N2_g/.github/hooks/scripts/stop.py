"""Stop hook — remind the agent to bank what it verified before the turn ends.

Without this the next session starts cold and pays again, in tokens and in risk,
to re-derive the same facts. The reminder is deliberately cheap: one line unless
the cache is empty, in which case it is worth being explicit.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cache as cache_module  # noqa: E402
from _common import context, guarded, read_event  # noqa: E402


def main() -> None:
    read_event()
    data = cache_module.load()

    if cache_module.is_empty(data):
        context(
            "Stop",
            "Nothing has been cached this session. If you established anything durable — a "
            "verified signal-to-frame mapping, which generator owns a directory, a project "
            "variant fact — bank it now so the next session does not re-derive it:\n\n"
            '    py -3 .github/hooks/scripts/cache.py fact "<what you established>" '
            '--evidence "<file or command that proves it>"\n\n'
            "Cache only what you verified. A wrong cached fact is worse than an empty cache.",
        )

    counts = (
        f"{len(data.get('facts', []))} fact(s), "
        f"{len(data.get('pins', []))} pin(s), "
        f"{len(data.get('questions', []))} open question(s)"
    )
    context(
        "Stop",
        f"Session cache holds {counts} and persists until `/cache-clear`. "
        "Add anything else you verified this turn with "
        "`py -3 .github/hooks/scripts/cache.py fact \"...\" --evidence \"...\"`.",
    )


if __name__ == "__main__":
    guarded(main)
