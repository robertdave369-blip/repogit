"""UserPromptSubmit hook — route the request to the artefact that already answers it.

Skill discovery is the weakest link for a smaller model: asked to write a test
spec it will write one from general knowledge, never noticing that
`.github/skills/veoneer-test-spec-generator/` encodes the required procedure.

Matching the prompt text against `.github/hooks/scripts/routing.json` makes that routing
deterministic — the model is told what to open instead of having to decide to look.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import REPO_ROOT, context, guarded, read_event  # noqa: E402

# Lives beside this script, not one level up: VS Code loads every .json directly in
# .github/hooks/ as a hook definition file, and this is data, not a definition.
ROUTING_FILE = Path(__file__).resolve().parent / "routing.json"
MIN_PROMPT_CHARS = 12


def load_rules() -> tuple[list[dict], int]:
    try:
        data = json.loads(ROUTING_FILE.read_text(encoding="utf-8"))
    except Exception:
        return [], 3
    rules = data.get("rules")
    if not isinstance(rules, list):
        return [], 3
    return rules, int(data.get("max_matches", 3))


def matches(prompt: str, phrases: list) -> list[str]:
    """Phrases that occur in the prompt, matched on word boundaries."""
    hits = []
    for phrase in phrases:
        if not isinstance(phrase, str) or not phrase.strip():
            continue
        pattern = r"(?<!\w)" + re.escape(phrase.strip().lower()) + r"(?!\w)"
        if re.search(pattern, prompt):
            hits.append(phrase.strip())
    return hits


def main() -> None:
    event = read_event()
    prompt = str(event.get("prompt") or event.get("user_prompt") or "").lower()
    if len(prompt) < MIN_PROMPT_CHARS:
        sys.exit(0)

    rules, max_matches = load_rules()
    if not rules:
        sys.exit(0)

    scored = []
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        hits = matches(prompt, rule.get("any", []) or [])
        if hits:
            # Longer phrases are more specific, so rank by the best phrase length.
            scored.append((max(len(hit) for hit in hits), len(hits), rule))
    if not scored:
        sys.exit(0)

    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    selected = [rule for _, _, rule in scored[:max_matches]]

    lines = [
        "## Routing for this request",
        "",
        "Matched against `.github/hooks/scripts/routing.json`. Open these before answering — they "
        "hold the procedure this repository expects, which general knowledge will not "
        "reproduce. If one turns out not to apply, say so and move on.",
    ]
    for rule in selected:
        lines.append("")
        lines.append(f"**{rule.get('id', 'rule')}**")
        for target in rule.get("read", []) or []:
            exists = (REPO_ROOT / str(target)).exists()
            lines.append(f"- `{target}`" + ("" if exists else "  _(not found — do not fabricate it)_"))
        note = str(rule.get("note", "")).strip()
        if note:
            lines.append(f"- {note}")

    context("UserPromptSubmit", "\n".join(lines))


if __name__ == "__main__":
    guarded(main)
