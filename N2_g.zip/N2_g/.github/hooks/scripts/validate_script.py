"""Check a framework Python file against the conventions this repository expects.

Runs automatically after every write via the PostToolUse hook, and standalone:

    py -3 .github/hooks/scripts/validate_script.py projects/EV_01/modules/EDR_CANC/scripts/*.py

The point is to close the loop. A smaller model writes a plausible-looking test
script that quietly breaks a convention — no `run_test()`, a hardcoded `C:\\` path,
a bare `except:` that swallows the failure the test exists to catch. Feeding the
specific violation straight back is far more effective than hoping the model
remembers the rule next time.

Only conventions that are actually observable in this repository are checked, and
each finding says what to do instead. Exit code is 1 when any error is found.
"""
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]

MAGIC_IMPORT = "shared_libraries.import_list import *"
GENERATED_MARKER = "GENERATED FILE - do not edit by hand"

# projects/<project>/modules/<module>/scripts/<file>.py
TEST_SCRIPT_PATTERN = re.compile(r"projects/[^/]+/modules/[^/]+/scripts/", re.IGNORECASE)
CONFIG_PATTERN = re.compile(r"projects/[^/]+/config/", re.IGNORECASE)
SHARED_LIB_PATTERN = re.compile(r"shared_libraries/", re.IGNORECASE)

ABSOLUTE_PATH = re.compile(r"""["'][A-Za-z]:[\\/]{1,2}(?!Framework_IOEM_Py["'])[^"']{3,}["']""")
BARE_EXCEPT = re.compile(r"^\s*except\s*:", re.MULTILINE)
RAW_SLEEP = re.compile(r"^\s*time\.sleep\s*\(", re.MULTILINE)
HARDCODED_CHANNEL = re.compile(r"""["'](HSCAN|CANFD|CAN FD|HS CAN|Level 61)["']""", re.IGNORECASE)


@dataclass
class Finding:
    severity: str  # "error" | "warning"
    line: int
    rule: str
    message: str


def _line_of(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def _kind(relative_path: str) -> str:
    if TEST_SCRIPT_PATTERN.search(relative_path):
        return "test-script"
    if CONFIG_PATTERN.search(relative_path):
        return "project-config"
    if SHARED_LIB_PATTERN.search(relative_path):
        return "shared-library"
    return "other"


def check_text(relative_path: str, source: str) -> list[Finding]:
    """Findings for one file. `relative_path` uses forward slashes."""
    kind = _kind(relative_path)
    findings: list[Finding] = []

    if kind == "test-script":
        if MAGIC_IMPORT not in source:
            findings.append(Finding(
                "error", 1, "import-list",
                "A test script must pull the shared library in through the magic import: "
                "`from Framework_IOEM_Py.shared_libraries.import_list import *`. Importing "
                "individual modules skips the star-import ordering, so a name can resolve to "
                "the wrong implementation.",
            ))
        if not re.search(r"^def run_test\s*\(", source, re.MULTILINE):
            findings.append(Finding(
                "error", 1, "run-test-entrypoint",
                "A test script must define `def run_test():` and put the test body inside it. "
                "The runners import the module and call `run_test()`; code at module level "
                "executes on import, which fires the test during collection.",
            ))

    if kind in {"test-script", "project-config", "shared-library"}:
        for match in ABSOLUTE_PATH.finditer(source):
            findings.append(Finding(
                "error", _line_of(source, match.start()), "absolute-path",
                f"Hardcoded absolute path {match.group(0)}. It breaks on every other bench and "
                "in CI. Derive it from `Path(__file__)`, or read it from the project config.",
            ))

        for match in BARE_EXCEPT.finditer(source):
            findings.append(Finding(
                "error", _line_of(source, match.start()), "bare-except",
                "`except:` swallows every error, including the failure this code exists to "
                "detect, and catches KeyboardInterrupt. Catch `Exception` and report it.",
            ))

    if kind == "test-script":
        for match in RAW_SLEEP.finditer(source):
            findings.append(Finding(
                "warning", _line_of(source, match.start()), "raw-sleep",
                "`time.sleep(...)` bypasses the framework's `Sleep(...)`, which is what the "
                "report and any time scaling see. Prefer `Sleep(...)`.",
            ))

        for match in HARDCODED_CHANNEL.finditer(source):
            findings.append(Finding(
                "warning", _line_of(source, match.start()), "hardcoded-channel",
                f"Channel name {match.group(0)} is hardcoded. Wrappers take an optional channel "
                "and resolve it; passing a literal ties this script to one bus and one bench.",
            ))

    if kind == "shared-library":
        if GENERATED_MARKER not in source and "def " in source and "apym" not in source.lower():
            pass  # nothing reliable to assert; left to review rather than guessed at

    return findings


def check_file(path: Path) -> list[Finding]:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except Exception as error:
        return [Finding("error", 1, "unreadable", f"Could not read the file: {error}")]
    try:
        relative_path = path.resolve().relative_to(REPO_ROOT).as_posix()
    except Exception:
        relative_path = path.as_posix()
    return check_text(relative_path, source)


def format_findings(path: Path, findings: list[Finding]) -> str:
    try:
        shown = path.resolve().relative_to(REPO_ROOT).as_posix()
    except Exception:
        shown = str(path)
    lines = []
    for finding in findings:
        lines.append(f"- **{finding.severity}** `{shown}:{finding.line}` [{finding.rule}] {finding.message}")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check framework Python files against repo conventions.")
    parser.add_argument("paths", nargs="+", help="files to check")
    parser.add_argument("--warnings-as-errors", action="store_true")
    args = parser.parse_args(argv)

    worst = 0
    for raw in args.paths:
        path = Path(raw)
        if not path.is_file() or path.suffix != ".py":
            continue
        findings = check_file(path)
        if not findings:
            continue
        print(format_findings(path, findings))
        if any(f.severity == "error" for f in findings) or args.warnings_as_errors:
            worst = 1
    return worst


if __name__ == "__main__":
    raise SystemExit(main())
