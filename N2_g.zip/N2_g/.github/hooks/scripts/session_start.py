"""SessionStart hook — put the framework's non-negotiables in front of the model.

A smaller model does not reliably go and read the knowledge base on its own. This
injects the short version at turn zero: where the rules live, the handful that are
most often broken, and whatever the persistent cache already established.

Kept deliberately brief. Long injected context crowds out the user's actual task.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cache as cache_module  # noqa: E402
from _common import REPO_ROOT, context, guarded, read_event  # noqa: E402

BRIEFING = """\
## Framework_IOEM_Py — session briefing

Mahindra SC3 2S airbag ECU (SRS/ACU) test framework. Authoritative sources, in order:

| Question | Read |
|---|---|
| ECU behaviour, requirements, protocols, test-design rules | `.github/agents/agent_sc3.md` |
| ARIA bench/project configuration | `.github/agents/aria_agent.md` |
| Task-specific procedures | `.github/skills/<name>/SKILL.md` |
| Rules for the file you are editing | `.github/instructions/` (auto-attached) |

**The five things most often got wrong here — check each before you answer:**

1. **Scripts under `projects/*/modules/*/scripts/` are usually generated.** If the file
   header says `GENERATED FILE - do not edit by hand`, edit the generator in `tools/`
   and re-run it. A hand edit is discarded on the next rebuild. (A hook blocks this.)
2. **Verify, do not recall.** Signals, frames, factors, offsets, DIDs and DTCs come from
   `project_dbc/`, the diagnostic spec, or the config module — never from memory or from
   another project. Values are not portable between projects.
3. **Every claim needs evidence or the words "Evidence unavailable."** State confidence,
   and label fact vs inference vs assumption. Guessing is worse than saying you do not know.
4. **Writing code is not running it.** Never actuate hardware, flash an ECU, or persist
   irreversible state unless the user asked for it in this turn.
5. **Read whole sources.** Excel: every sheet, every row, columns resolved by header name
   (`.github/agents/agent_sc3.md` §16.5). Never work from a preview or a partial read.

Cache verified findings so later turns need not re-derive them:
`py -3 .github/hooks/scripts/cache.py fact "<what you established>" --evidence "<file>"`
"""


def main() -> None:
    read_event()  # drain stdin so the caller never blocks on the pipe

    blocks = [BRIEFING]

    if not (REPO_ROOT / ".github/agents/agent_sc3.md").is_file():
        blocks.append(
            "> Note: `.github/agents/agent_sc3.md` is missing. Ask the user where the knowledge "
            "base has moved to rather than answering from general knowledge."
        )

    cached = cache_module.render(cache_module.load())
    if cached:
        blocks.append(cached)

    context("SessionStart", "\n\n".join(blocks))


if __name__ == "__main__":
    guarded(main)
