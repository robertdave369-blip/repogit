"""PreToolUse hook — the safety net that makes blanket auto-approval safe.

With `chat.tools.global.autoApprove` enabled the user stops confirming every
step, so this hook becomes the only thing standing between the agent and an
irreversible mistake. It refuses four specific classes of action and explains
why, so the agent corrects itself instead of retrying:

1. editing a generated file instead of its generator;
2. destructive or history-rewriting shell commands;
3. running a bench script, which can actuate real hardware;
4. writing into build artefacts.

Everything else passes straight through. The list is deliberately short — a hook
that cries wolf gets switched off.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import (  # noqa: E402
    REPO_ROOT,
    deny,
    guarded,
    inside_repo,
    read_event,
    relative,
    tool_name,
    touched_command,
    touched_path,
)

GENERATED_MARKER = "GENERATED FILE - do not edit by hand"
REBUILD_PATTERN = re.compile(r"Rebuild with:\s*(.+)")
HEADER_BYTES = 4096

WRITE_TOOL_HINTS = ("edit", "write", "create", "patch", "replace", "insert")
SHELL_TOOL_HINTS = ("terminal", "bash", "shell", "runcommand", "run_command", "execute", "powershell")

# Commands that destroy work or rewrite shared history. Each entry is
# (regex, why it is refused).
DESTRUCTIVE = [
    (r"\brm\s+(-[a-zA-Z]*\s+)*-[a-zA-Z]*[rf]", "`rm -rf` deletes without recovery"),
    (r"\bremove-item\b[^|;\n]*-recurse[^|;\n]*-force", "`Remove-Item -Recurse -Force` deletes without recovery"),
    (r"\bdel\s+/[sq]", "`del /s` deletes recursively without recovery"),
    (r"\brmdir\s+/s", "`rmdir /s` deletes recursively without recovery"),
    (r"\bgit\s+reset\s+--hard", "`git reset --hard` discards uncommitted work"),
    (r"\bgit\s+clean\s+-[a-zA-Z]*[fd]", "`git clean -fd` deletes untracked files permanently"),
    (r"\bgit\s+push\s+[^|;\n]*--force(?!-with-lease)", "a force push rewrites shared history"),
    (r"\bgit\s+checkout\s+--\s+\.", "`git checkout -- .` discards all local changes"),
    (r"\bgit\s+branch\s+-D\b", "`git branch -D` deletes a branch even if unmerged"),
]

# Running one of these can drive the rig: power, squibs, crash triggers, flashing.
BENCH_SCRIPT_PATTERN = re.compile(
    r"(python|py|py\s+-3(\.\d+)?)\s+[^\n|;]*"
    r"(projects[/\\][^\n|;]*[/\\]scripts[/\\]|run_all[^\n|;]*\.py)",
    re.IGNORECASE,
)

ARTEFACT_PARTS = ("__pycache__", ".pytest_cache", "graphify-out", "test_logs", "test_results")


def is_write_tool(name: str) -> bool:
    lowered = name.lower()
    return any(hint in lowered for hint in WRITE_TOOL_HINTS)


def is_shell_tool(name: str) -> bool:
    lowered = name.lower()
    return any(hint in lowered for hint in SHELL_TOOL_HINTS)


def header_of(path: Path) -> str:
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            return handle.read(HEADER_BYTES)
    except Exception:
        return ""


def check_generated_file(path: Path) -> None:
    if not path.is_file():
        return
    header = header_of(path)
    if GENERATED_MARKER not in header:
        return
    match = REBUILD_PATTERN.search(header)
    rebuild = match.group(1).strip() if match else "the generator in tools/"
    deny(
        f"`{relative(path)}` is a generated file — its header says so.\n\n"
        f"Editing it here is wasted work: the next rebuild overwrites the change, and the "
        f"other files generated alongside it stay inconsistent in the meantime.\n\n"
        f"Change the generator instead, then re-run:\n\n    {rebuild}\n\n"
        f"If the user explicitly wants a one-off manual edit to this exact file, say that "
        f"the change will be lost on rebuild and ask them to confirm first."
    )


def check_artefact_path(path: Path) -> None:
    parts = {part.lower() for part in path.parts}
    hit = next((part for part in ARTEFACT_PARTS if part in parts), None)
    if hit:
        deny(
            f"`{relative(path)}` is inside `{hit}`, which holds build or run artefacts. "
            f"Editing it changes nothing that survives — change the source that produces it."
        )


def check_command(command: str) -> None:
    lowered = command.lower()

    for pattern, why in DESTRUCTIVE:
        if re.search(pattern, lowered):
            deny(
                f"Refused: {why}.\n\nCommand: `{command.strip()}`\n\n"
                f"If this is genuinely what the user wants, explain exactly what will be lost "
                f"and ask them to confirm before running it. Otherwise use a reversible "
                f"alternative — `git stash`, a branch, or moving files aside."
            )

    if BENCH_SCRIPT_PATTERN.search(command):
        deny(
            f"Refused: this runs a bench script, which can power the ECU, fire a trigger, "
            f"deploy a squib, or flash the target.\n\nCommand: `{command.strip()}`\n\n"
            f"Writing a script is not running it. Only run this when the user has asked for "
            f"execution in this turn — and say first what will physically happen on the rig."
        )


def main() -> None:
    event = read_event()
    name = tool_name(event)

    if is_write_tool(name):
        path = touched_path(event)
        if path is not None and inside_repo(path):
            check_artefact_path(path)
            check_generated_file(path)

    if is_shell_tool(name):
        command = touched_command(event)
        if command:
            check_command(command)

    sys.exit(0)


if __name__ == "__main__":
    guarded(main)
