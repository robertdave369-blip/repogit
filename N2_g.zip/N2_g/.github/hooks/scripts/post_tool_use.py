"""PostToolUse hook — check what was just written and hand the violations back.

Telling a model a convention up front is weak; showing it the line it just broke
is strong. After every file write this runs the convention checker and, if
anything failed, injects the specific findings so the agent fixes them in the
same turn rather than leaving them for review.

Silent when the file is clean, which is the common case.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _common import (  # noqa: E402
    context,
    guarded,
    inside_repo,
    read_event,
    relative,
    tool_name,
    touched_path,
)
from validate_script import check_file, format_findings  # noqa: E402

WRITE_TOOL_HINTS = ("edit", "write", "create", "patch", "replace", "insert")
MAX_FINDINGS = 12


def main() -> None:
    event = read_event()
    if not any(hint in tool_name(event).lower() for hint in WRITE_TOOL_HINTS):
        sys.exit(0)

    path = touched_path(event)
    if path is None or path.suffix != ".py" or not path.is_file() or not inside_repo(path):
        sys.exit(0)

    findings = check_file(path)
    if not findings:
        sys.exit(0)

    errors = [f for f in findings if f.severity == "error"]
    shown = (errors + [f for f in findings if f.severity != "error"])[:MAX_FINDINGS]

    headline = (
        f"`{relative(path)}` does not yet meet this repository's conventions."
        if errors
        else f"`{relative(path)}` is worth a second look."
    )
    lines = [
        "## Convention check on the file you just wrote",
        "",
        headline,
        "",
        format_findings(path, shown),
        "",
    ]
    if errors:
        lines.append(
            "Fix these now, in this turn — they are not style preferences. Each one either "
            "breaks the file on another bench or hides a failure the test exists to catch."
        )
    else:
        lines.append("Warnings only: apply them unless there is a reason here not to, and say which.")

    if len(findings) > len(shown):
        lines.append(f"\n_{len(findings) - len(shown)} further finding(s) not shown; "
                     f"run `py -3 .github/hooks/scripts/validate_script.py {relative(path)}`._")

    context("PostToolUse", "\n".join(lines))


if __name__ == "__main__":
    guarded(main)
