"""Persistent session cache for Framework_IOEM_Py agent sessions.

Why this exists
---------------
A weaker model re-derives the same facts every session: which config module a
project uses, which frame carries a signal, which generator owns a script
directory. Each re-derivation costs tokens and is a fresh chance to get it
wrong.

This cache holds what has already been *verified*, survives conversation
compaction, and is injected at the start of every session by the SessionStart
hook. **It is never cleared automatically** — only ``cache.py clear`` empties it,
which is what the ``/cache-clear`` prompt runs.

Storage is a single JSON file at ``.github/cache/session.json``.

Usage
-----
    py -3 .github/hooks/scripts/cache.py show
    py -3 .github/hooks/scripts/cache.py status
    py -3 .github/hooks/scripts/cache.py clear
    py -3 .github/hooks/scripts/cache.py fact "EV_01 uses SRS_FD receivers" --evidence "project_dbc/M314.dbc"
    py -3 .github/hooks/scripts/cache.py pin tools/generate_ice01_edr_canc_scripts.py
    py -3 .github/hooks/scripts/cache.py question "Is OPEN-ND the no-data fault?"
    py -3 .github/hooks/scripts/cache.py drop fact 3
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
CACHE_DIR = REPO_ROOT / ".github" / "cache"
CACHE_FILE = CACHE_DIR / "session.json"

# Keep the injected context small enough that it never dominates the window.
MAX_FACTS = 60
MAX_PINS = 40
MAX_QUESTIONS = 25
MAX_INJECTED_CHARS = 6000

EMPTY: dict = {
    "version": 1,
    "created": None,
    "updated": None,
    "facts": [],
    "pins": [],
    "questions": [],
}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def load() -> dict:
    """Read the cache, tolerating a missing or corrupt file."""
    if not CACHE_FILE.is_file():
        return dict(EMPTY, facts=[], pins=[], questions=[])
    try:
        data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return dict(EMPTY, facts=[], pins=[], questions=[])
    if not isinstance(data, dict):
        return dict(EMPTY, facts=[], pins=[], questions=[])
    for key in ("facts", "pins", "questions"):
        if not isinstance(data.get(key), list):
            data[key] = []
    return data


def save(data: dict) -> None:
    data["updated"] = _now()
    data.setdefault("created", data["updated"])
    data.setdefault("version", 1)
    for key, limit in (("facts", MAX_FACTS), ("pins", MAX_PINS), ("questions", MAX_QUESTIONS)):
        if len(data.get(key, [])) > limit:
            data[key] = data[key][-limit:]
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")


def is_empty(data: dict) -> bool:
    return not (data.get("facts") or data.get("pins") or data.get("questions"))


def render(data: dict, *, limit_chars: int = MAX_INJECTED_CHARS) -> str:
    """Render the cache as the markdown block injected into agent context."""
    if is_empty(data):
        return ""

    lines = [
        "## Verified session cache (`.github/cache/session.json`)",
        "",
        f"Carried over from earlier work, last updated {data.get('updated') or 'unknown'}. "
        "These were verified against real artefacts — reuse them instead of re-deriving. "
        "If one turns out to be wrong, correct it with "
        "`py -3 .github/hooks/scripts/cache.py drop fact <n>` rather than working around it.",
    ]

    facts = data.get("facts", [])
    if facts:
        lines += ["", "### Established facts"]
        for index, entry in enumerate(facts, start=1):
            text = str(entry.get("text", "")).strip()
            evidence = str(entry.get("evidence", "")).strip()
            lines.append(f"{index}. {text}" + (f"  — evidence: `{evidence}`" if evidence else ""))

    pins = data.get("pins", [])
    if pins:
        lines += ["", "### Pinned files (authoritative for this work)"]
        for entry in pins:
            path = str(entry.get("path", "")).strip()
            note = str(entry.get("note", "")).strip()
            lines.append(f"- `{path}`" + (f" — {note}" if note else ""))

    questions = data.get("questions", [])
    if questions:
        lines += ["", "### Open questions (do not answer by assumption)"]
        for index, entry in enumerate(questions, start=1):
            lines.append(f"{index}. {str(entry.get('text', '')).strip()}")

    rendered = "\n".join(lines)
    if len(rendered) > limit_chars:
        rendered = rendered[:limit_chars].rsplit("\n", 1)[0] + "\n\n_(cache truncated for context size)_"
    return rendered


# ── CLI ──────────────────────────────────────────────────────────────────────

def _cmd_show(_args) -> int:
    data = load()
    print(render(data) or "Cache is empty.")
    return 0


def _cmd_status(_args) -> int:
    data = load()
    if is_empty(data):
        print("Cache is empty.")
        return 0
    print(
        f"facts={len(data.get('facts', []))} "
        f"pins={len(data.get('pins', []))} "
        f"questions={len(data.get('questions', []))} "
        f"updated={data.get('updated')}"
    )
    return 0


def _cmd_clear(_args) -> int:
    fresh = dict(EMPTY, facts=[], pins=[], questions=[], created=_now())
    save(fresh)
    print("Cache cleared. Nothing will be carried into the next session.")
    return 0


def _cmd_fact(args) -> int:
    data = load()
    text = args.text.strip()
    if not text:
        print("Refusing to store an empty fact.", file=sys.stderr)
        return 1
    if any(str(entry.get("text", "")).strip() == text for entry in data["facts"]):
        print("Already cached; nothing added.")
        return 0
    data["facts"].append({"text": text, "evidence": (args.evidence or "").strip(), "at": _now()})
    save(data)
    print(f"Cached fact {len(data['facts'])}.")
    return 0


def _cmd_pin(args) -> int:
    data = load()
    path = args.path.strip().replace("\\", "/")
    if any(str(entry.get("path", "")) == path for entry in data["pins"]):
        print("Already pinned.")
        return 0
    data["pins"].append({"path": path, "note": (args.note or "").strip(), "at": _now()})
    save(data)
    print(f"Pinned {path}.")
    return 0


def _cmd_question(args) -> int:
    data = load()
    text = args.text.strip()
    if any(str(entry.get("text", "")).strip() == text for entry in data["questions"]):
        print("Already recorded.")
        return 0
    data["questions"].append({"text": text, "at": _now()})
    save(data)
    print(f"Recorded open question {len(data['questions'])}.")
    return 0


def _cmd_drop(args) -> int:
    data = load()
    bucket = {"fact": "facts", "pin": "pins", "question": "questions"}[args.kind]
    entries = data.get(bucket, [])
    if not 1 <= args.index <= len(entries):
        print(f"No {args.kind} {args.index}; there are {len(entries)}.", file=sys.stderr)
        return 1
    removed = entries.pop(args.index - 1)
    save(data)
    print(f"Dropped {args.kind} {args.index}: {removed.get('text') or removed.get('path')}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=(__doc__ or "session cache").split("\n")[0])
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("show", help="print the cache as it is injected into context").set_defaults(func=_cmd_show)
    sub.add_parser("status", help="one-line summary").set_defaults(func=_cmd_status)
    sub.add_parser("clear", help="empty the cache (the only thing that clears it)").set_defaults(func=_cmd_clear)

    fact = sub.add_parser("fact", help="cache a verified fact")
    fact.add_argument("text")
    fact.add_argument("--evidence", default="", help="file, sheet, or command that proves it")
    fact.set_defaults(func=_cmd_fact)

    pin = sub.add_parser("pin", help="pin an authoritative file")
    pin.add_argument("path")
    pin.add_argument("--note", default="")
    pin.set_defaults(func=_cmd_pin)

    question = sub.add_parser("question", help="record something that must not be assumed")
    question.add_argument("text")
    question.set_defaults(func=_cmd_question)

    drop = sub.add_parser("drop", help="remove one entry")
    drop.add_argument("kind", choices=["fact", "pin", "question"])
    drop.add_argument("index", type=int)
    drop.set_defaults(func=_cmd_drop)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
