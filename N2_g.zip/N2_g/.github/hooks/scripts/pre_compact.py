"""PreCompact hook — survive automatic compaction with the important bits intact.

When the context window fills, VS Code summarises the conversation. Summaries are
lossy in exactly the wrong way for this work: the verified detail goes (which
frame, which factor, which sheet) and the narrative stays.

This fires just before compaction and re-states what must not be lost, plus the
whole persistent cache. Anything the agent has already cached with
`cache.py fact` therefore crosses the compaction boundary verbatim.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import cache as cache_module  # noqa: E402
from _common import context, guarded, read_event  # noqa: E402

CARRY_OVER = """\
## Carry these through compaction

The summary about to be written is lossy. Preserve, verbatim and specifically:

- **Verified values** — signal names, frame IDs, factors, offsets, DIDs, DTCs, timings —
  together with the file each came from. A value without its source is unusable afterwards.
- **The exact task** the user asked for, including any constraint they stated (paths not to
  touch, formats to follow, things they already said no to).
- **What has actually been run and proven**, as opposed to what was merely written. Do not
  let "written" become "verified" in the summary.
- **Open questions and contradictions** still unresolved.
- **Corrections the user made.** These are the most expensive things to lose and the easiest
  to drop, because they read as conversational.

Do not carry forward speculation, abandoned approaches, or tool output that has been
superseded.
"""


def main() -> None:
    read_event()
    blocks = [CARRY_OVER]
    cached = cache_module.render(cache_module.load())
    if cached:
        blocks.append(cached)
    context("PreCompact", "\n\n".join(blocks))


if __name__ == "__main__":
    guarded(main)
