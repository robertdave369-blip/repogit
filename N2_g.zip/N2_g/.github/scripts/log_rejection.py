"""Record a correction so the harness stops repeating a mistake.

Section 7.7 requires corrections to be folded back rather than lost to chat scrollback.
This is the capture end of that loop: when Terra proposes something wrong and you correct
it, one command turns that correction into a durable rule.

Why it matters more with a weaker model: Terra repeats mistakes across sessions because
nothing persists a "no". A rejection is training data. Pattern borrowed from Mira, which
synthesises rules from rejected review comments -- see decisions.md D-2026-08-29-09.

Usage
    py -3 .github/scripts/log_rejection.py \
        --proposed "called CAN.SendDiag()" \
        --wrong    "no such function; the real one is CAN.SendDiagByValues()" \
        --rule     "verify a shared-library function exists before calling it" \
        --scope    shared-libraries

    py -3 .github/scripts/log_rejection.py --list
    py -3 .github/scripts/log_rejection.py --rules      # rules only, for context
"""

from __future__ import annotations

import argparse
import datetime as _dt
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
LOG = REPO / ".github" / "knowledge" / "rejections.md"

SCOPES = [
    "shared-libraries", "projects", "test-spec", "diagnostics", "can", "edr",
    "aria", "safety", "harness", "general",
]

HEADER = """---
scope: Corrections the user has made, converted into rules the harness must not re-break
sources: user corrections during sessions; appended by .github/scripts/log_rejection.py
last_verified: {today}
fingerprint: append-only; each entry dated
---

# Rejections

Every entry is something the assistant proposed and the user rejected, plus the rule that
prevents it recurring. **Read the Rules index before proposing work in a listed scope.**

Append only, via `log_rejection.py`. Do not rewrite an entry -- add a new one that
supersedes it and say so.

## Rules index

<!-- RULES:START -->
<!-- RULES:END -->

## Entries

"""

ENTRY = """### {date} — {scope}

**Proposed:** {proposed}

**Why it was wrong:** {wrong}

**Rule:** {rule}

"""


def ensure_log() -> str:
    if not LOG.exists():
        LOG.parent.mkdir(parents=True, exist_ok=True)
        LOG.write_text(HEADER.format(today=_dt.date.today().isoformat()), encoding="utf-8")
    return LOG.read_text(encoding="utf-8")


def rebuild_index(text: str) -> str:
    """Regenerate the rules index from the entries, so the two cannot drift apart."""
    rules = re.findall(r"^\*\*Rule:\*\* (.+)$", text, re.M)
    scopes = re.findall(r"^### \S+ — (\S+)$", text, re.M)
    lines = []
    seen = set()
    for scope, rule in zip(scopes, rules):
        key = (scope, rule.strip().lower())
        if key in seen:
            continue
        seen.add(key)
        lines.append(f"- **{scope}** — {rule.strip()}")
    body = "\n".join(lines) if lines else "_No rules recorded yet._"
    return re.sub(
        r"<!-- RULES:START -->.*?<!-- RULES:END -->",
        f"<!-- RULES:START -->\n{body}\n<!-- RULES:END -->",
        text, flags=re.S)


def add(proposed: str, wrong: str, rule: str, scope: str) -> int:
    text = ensure_log()
    if rule.strip().lower() in (r.strip().lower()
                                for r in re.findall(r"^\*\*Rule:\*\* (.+)$", text, re.M)):
        print(f"  already recorded, nothing added:\n    {rule}")
        return 0
    text += ENTRY.format(date=_dt.date.today().isoformat(), scope=scope,
                         proposed=proposed.strip(), wrong=wrong.strip(),
                         rule=rule.strip())
    LOG.write_text(rebuild_index(text), encoding="utf-8")
    print(f"  recorded under '{scope}':\n    {rule}")
    print(f"  -> {LOG.relative_to(REPO)}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--proposed", help="what the assistant proposed")
    ap.add_argument("--wrong", help="why it was wrong")
    ap.add_argument("--rule", help="the rule that prevents it recurring")
    ap.add_argument("--scope", choices=SCOPES, default="general")
    ap.add_argument("--list", action="store_true", help="print the whole log")
    ap.add_argument("--rules", action="store_true", help="print the rules index only")
    args = ap.parse_args()

    if args.list:
        print(ensure_log())
        return 0
    if args.rules:
        text = ensure_log()
        m = re.search(r"<!-- RULES:START -->\n(.*?)\n<!-- RULES:END -->", text, re.S)
        print(m.group(1) if m else "_none_")
        return 0

    missing = [f"--{n}" for n, v in
               (("proposed", args.proposed), ("wrong", args.wrong), ("rule", args.rule))
               if not v]
    if missing:
        # A half-recorded rejection is worse than none: it looks handled but teaches
        # nothing. Require the full triple.
        print(f"error: missing {', '.join(missing)}", file=sys.stderr)
        print("A rejection needs all three: what was proposed, why it was wrong, and "
              "the rule.", file=sys.stderr)
        return 2

    return add(args.proposed, args.wrong, args.rule, args.scope)


if __name__ == "__main__":
    sys.exit(main())
