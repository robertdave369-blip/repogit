"""Validate .github/agents/*.agent.md against the real VS Code agent schema.

Every constant here was read out of the shipped VS Code bundle
(resources/app/out/vs/workbench/workbench.desktop.main.js, build 08d4889f9e,
VS Code 1.135.0) rather than from documentation or memory. If VS Code updates,
re-derive them before trusting this script -- see refresh_notes() at the bottom.

Usage:
    py -3 .github/scripts/validate_agents.py
    py -3 .github/scripts/validate_agents.py --json
Exit code 0 = all agents valid, 1 = at least one error.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
AGENTS_DIR = REPO / ".github" / "agents"
ROLES_FILE = Path(__file__).resolve().parent / "agent_roles.json"

ROLES = json.loads(ROLES_FILE.read_text(encoding="utf-8"))

# --- schema constants, all TOOL-tagged (read from workbench.desktop.main.js) ---

# The `bo` frontmatter attribute enum.
VALID_KEYS = {
    "name", "description", "agent", "mode", "model", "applyTo", "paths",
    "tools", "handoffs", "advancedOptions", "argument-hint", "excludeAgent",
    "target", "infer", "license", "compatibility", "metadata", "agents",
    "user-invocable", "disable-model-invocation", "hooks", "context",
}

# contributes.languageModelToolSets + the `Mm` toolset-kind enum.
VALID_TOOLSETS = {
    "edit", "execute", "read", "search", "vscode", "web", "agent", "todo",
}

# contributes.languageModelTools[].toolReferenceName
VALID_TOOLS = {
    "applyPatch", "changes", "codebase", "createDirectory", "createFile",
    "createJupyterNotebook", "editFiles", "editNotebook", "executionSubagent",
    "exploreSubagent", "fetch", "fileSearch", "findTestFiles",
    "getNotebookSummary", "githubRepo", "githubTextSearch", "insertEdit",
    "installExtension", "listDirectory", "memory", "multiReplaceString",
    "newWorkspace", "problems", "readFile", "readNotebookCellOutput",
    "replaceString", "resolveMemoryFileUri", "runCommand", "runNotebookCell",
    "searchSubagent", "sessionStoreSql", "skill", "switchAgent", "symbols",
    "textSearch", "viewImage", "vscodeAPI",
}

# Toolsets that let an agent change the workspace. A verifier must hold none.
MUTATING = {"edit", "execute", "vscode"}
MUTATING_TOOLS = {
    "applyPatch", "createDirectory", "createFile", "createJupyterNotebook",
    "editFiles", "editNotebook", "insertEdit", "multiReplaceString",
    "newWorkspace", "replaceString", "runCommand", "runNotebookCell",
    "installExtension",
}

NAME_RE = re.compile(r"^[a-z0-9-]+$")  # the `gOe` regex
BOOLISH = {"true", "false"}


def split_frontmatter(text: str):
    """Return (frontmatter_lines, error) using VS Code's own --- delimiter rule."""
    lines = text.splitlines()
    if not lines or not re.match(r"^---\s*$", lines[0]):
        return None, "no YAML frontmatter (file must start with ---)"
    for i in range(1, len(lines)):
        if re.match(r"^---\s*$", lines[i]):
            return lines[1:i], None
    return None, "frontmatter opened with --- but never closed"


def parse_frontmatter(fm_lines):
    """Minimal top-level YAML key reader: enough for the flat agent header."""
    attrs = {}
    for raw in fm_lines:
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[:1] in (" ", "\t", "-"):
            continue  # nested content belongs to the previous key
        if ":" not in raw:
            continue
        key, _, val = raw.partition(":")
        attrs[key.strip()] = val.strip()
    return attrs


def parse_list(value: str):
    """Accept `[a, b]` inline form; return None when the value is not inline."""
    v = value.strip()
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        if not inner:
            return []
        return [x.strip().strip("'\"") for x in inner.split(",") if x.strip()]
    return None


def validate(path: Path, known_names: set[str]):
    errors, warnings = [], []
    text = path.read_text(encoding="utf-8", errors="replace")

    fm_lines, err = split_frontmatter(text)
    if err:
        return [err], []

    attrs = parse_frontmatter(fm_lines)

    for key in attrs:
        if key not in VALID_KEYS:
            errors.append(
                f"unknown frontmatter key {key!r} -- VS Code ignores it silently"
            )

    if "description" not in attrs or not attrs["description"]:
        errors.append("missing 'description' -- routing cannot work without it")

    name = attrs.get("name")
    if name and not NAME_RE.match(name):
        errors.append(f"name {name!r} fails the required /^[a-z0-9-]+$/ pattern")
    if name and name != path.name[: -len(".agent.md")]:
        warnings.append(f"name {name!r} differs from filename stem")

    tools_raw = attrs.get("tools")
    tools = parse_list(tools_raw) if tools_raw else None
    if tools_raw and tools is None:
        warnings.append("'tools' is not inline [..] form; not checked")
    if tools is not None:
        for tool in tools:
            if tool not in VALID_TOOLSETS and tool not in VALID_TOOLS:
                errors.append(
                    f"unknown tool/toolset {tool!r} -- silently grants nothing"
                )

    agents_raw = attrs.get("agents")
    agents = parse_list(agents_raw) if agents_raw else None
    if agents:
        for ref in agents:
            if ref != "*" and ref not in known_names:
                errors.append(f"'agents' references unknown agent {ref!r}")

    for flag in ("user-invocable", "disable-model-invocation", "infer"):
        if flag in attrs and attrs[flag].lower() not in BOOLISH:
            errors.append(f"{flag!r} must be true or false, got {attrs[flag]!r}")

    # Integrity rule, driven by the declared registry -- never inferred from wording.
    stem = path.name[: -len(".agent.md")]
    role = ROLES["agents"].get(stem)

    if role is None:
        keyword_hit = any(
            w in f"{name or ''} {attrs.get('description', '')}".lower()
            for w in ("verif", "audit", "gate", "critic", "fidelity")
        )
        warnings.append(
            "not listed in agent_roles.json -- classify it"
            + (" (wording suggests a verifier)" if keyword_hit else "")
        )
    else:
        allowed = set(ROLES["roles"][role]["allowed"])
        if tools is None:
            errors.append(
                f"role {role!r} but no 'tools:' -- it inherits every tool, "
                f"including edit and execute"
            )
        else:
            extra = [t for t in tools if t not in allowed]
            if extra:
                sev = errors if role == "verifier" else warnings
                sev.append(
                    f"role {role!r} allows {sorted(allowed)} but declares {extra}"
                    + (" -- a gate that can edit can rubber-stamp by fixing"
                       if role == "verifier" else "")
                )
        # Only a declared operator may run commands: that is how a bench script gets launched.
        # Operators gate hardware steps in their own text (D-2026-10-26-19).
        RUNNERS = {"execute", "vscode", "runCommand", "runNotebookCell"}
        if tools:
            runs = sorted(set(tools) & RUNNERS - ({"execute"} if role == "operator" else set()))
            if runs:
                errors.append(
                    f"declares {runs} -- no agent may run commands "
                    f"(hardware must never be actuated uninvited)"
                )
    return errors, warnings


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    files = sorted(AGENTS_DIR.glob("*.agent.md"))
    known = {f.name[: -len(".agent.md")] for f in files}

    results, n_err = {}, 0
    for f in files:
        errors, warnings = validate(f, known)
        results[f.name] = {"errors": errors, "warnings": warnings}
        n_err += len(errors)

    if args.json:
        print(json.dumps(results, indent=2))
        return 1 if n_err else 0

    print(f"Validating {len(files)} agent files in {AGENTS_DIR.relative_to(REPO)}\n")
    for fname, r in results.items():
        if not r["errors"] and not r["warnings"]:
            print(f"  OK      {fname}")
            continue
        status = "ERROR " if r["errors"] else "WARN  "
        print(f"  {status}  {fname}")
        for e in r["errors"]:
            print(f"            error:   {e}")
        for w in r["warnings"]:
            print(f"            warning: {w}")

    print(f"\n{len(files)} files, {n_err} errors")
    return 1 if n_err else 0


def refresh_notes() -> str:
    return (
        "Re-derive VALID_KEYS from the `bo` enum, VALID_TOOLSETS from "
        "contributes.languageModelToolSets, and VALID_TOOLS from "
        "contributes.languageModelTools[].toolReferenceName in the installed "
        "VS Code build before trusting this after an IDE update."
    )


if __name__ == "__main__":
    sys.exit(main())
