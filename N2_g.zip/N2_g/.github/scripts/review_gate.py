"""Gate specialist output before it reaches the user.

The problem: a weaker model produces more marginal findings, and volume reads as
thoroughness. Twenty findings of which four matter is worse than four findings, because
the reader cannot tell which four -- and after the first wrong one they stop trusting all
twenty.

This gate applies, in order:

  1. source diversity   -- delegated to check_source_diversity.py; false consensus fails
  2. evidence integrity -- facts must cite sources; confidence must carry a rationale
  3. self-critique      -- a 'completed' handoff must have answered what could escape
  4. deduplication      -- near-identical facts collapse, carrying corroboration counts
  5. confidence clamp   -- below-threshold findings are HELD, listed separately, not dropped

Nothing is silently discarded. Held findings are reported under their own heading so a
real finding with weak evidence can still be chased.

Pattern borrowed from Mira's noise filter; no Mira code or service is involved.
See .github/knowledge/decisions.md D-2026-08-29-09.

Usage:
    py -3 .github/scripts/review_gate.py <dir-of-handoff-json>
    py -3 .github/scripts/review_gate.py <dir> --json
Exit 0 = surfaced set is trustworthy, 1 = gate failed or nothing to check.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from difflib import SequenceMatcher
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
CONFIG_PATH = HERE / "review_gate.config.json"

# Load the sibling module by explicit path so this works from any cwd and does not
# depend on .github/scripts being importable as a package.
def _load_sibling(module_name: str):
    import importlib.util
    spec = importlib.util.spec_from_file_location(module_name, HERE / f"{module_name}.py")
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot locate {module_name}.py beside {Path(__file__).name}")
    mod = importlib.util.module_from_spec(spec)
    # Register before exec: on Python 3.14 `@dataclass` resolves cls.__module__ through
    # sys.modules, and an unregistered module raises AttributeError on None.
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


_diversity = _load_sibling("check_source_diversity")
diversity_analyse = _diversity.analyse
load_handoffs = _diversity.load_handoffs


def load_config() -> dict:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def normalise(text: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", re.sub(r"\s+", " ", text.lower())).strip()


def confidence_of(obj: dict) -> str:
    c = obj.get("confidence")
    return c.get("level", "Unknown") if isinstance(c, dict) else "Unknown"


def dedup(findings: list[dict], threshold: float) -> list[dict]:
    """Collapse near-identical facts. Corroboration counts only when sources differ --
    the same agent repeating itself, or two agents reading one file, is not support."""
    groups: list[dict] = []
    for f in findings:
        key = normalise(f["text"])
        for g in groups:
            if SequenceMatcher(None, key, g["_key"]).ratio() >= threshold:
                g["agents"].append(f["agent"])
                g["sources"].update(f["sources"])
                if f["_rank"] > g["_rank"]:
                    g["_rank"], g["confidence"] = f["_rank"], f["confidence"]
                break
        else:
            groups.append({
                "_key": key, "text": f["text"], "agents": [f["agent"]],
                "sources": set(f["sources"]), "confidence": f["confidence"],
                "_rank": f["_rank"],
            })
    for g in groups:
        g["corroborations"] = len(set(g["sources"]))
        g["sources"] = sorted(g["sources"])
        g.pop("_key")
    return groups


def run(directory: Path, cfg: dict) -> dict:
    handoffs, malformed = load_handoffs(directory)
    result: dict = {"malformed": malformed, "blocking": [], "surfaced": [],
                    "held": [], "diversity": []}

    if not handoffs:
        result["blocking"].append(
            f"no valid handoffs in {directory} -- nothing was checked")
        return result

    # 1. source diversity
    if cfg["source_diversity"]["enabled"]:
        for level, agent, msg in diversity_analyse(handoffs):
            result["diversity"].append({"level": level, "agent": agent, "message": msg})
            if level == "FAIL":
                result["blocking"].append(f"source diversity: {msg}")

    order = cfg["confidence"]["order"]
    floor = order.index(cfg["confidence"]["surface_at_or_above"])
    ev, sc = cfg["evidence"], cfg["self_critique"]

    findings: list[dict] = []
    for name, obj in handoffs:
        srcs = [str(s.get("path", s)) if isinstance(s, dict) else str(s)
                for s in (obj.get("sources") or [])]
        facts = obj.get("facts") or []
        level = confidence_of(obj)
        rank = order.index(level) if level in order else 0

        # 2. evidence integrity
        if ev["require_source_for_facts"] and facts and not srcs:
            result["blocking"].append(
                f"{name}: states {len(facts)} fact(s) with no source cited")
        if ev["require_confidence_rationale"]:
            c = obj.get("confidence")
            if not isinstance(c, dict) or not str(c.get("rationale", "")).strip():
                result["blocking"].append(f"{name}: confidence carries no rationale")

        gaps = obj.get("evidence_gaps") or []
        status = obj.get("status")
        if status == "completed" and len(gaps) > ev["max_unresolved_gaps_for_completed"]:
            result["blocking"].append(
                f"{name}: status 'completed' with {len(gaps)} unresolved evidence gap(s)"
                f" -- use 'needs_review' or 'blocked'")

        # 3. self-critique -- evidenced in `validation`, never inferred from empty gaps
        if sc["required"] and status == "completed" and not (obj.get(sc["field"]) or []):
            result["blocking"].append(
                f"{name}: empty '{sc['field']}' on a completed handoff -- the closing "
                f"question (what defect could still escape?) was not evidenced")

        for fact in facts:
            findings.append({"text": str(fact), "agent": name, "sources": srcs,
                             "confidence": level, "_rank": rank})

    # 4. dedup, then 5. clamp
    for g in dedup(findings, cfg["deduplication"]["similarity_threshold"]):
        entry = {"text": g["text"], "confidence": g["confidence"],
                 "agents": sorted(set(g["agents"])),
                 "corroborations": g["corroborations"], "sources": g["sources"]}
        # A claim with no source never surfaces, whatever confidence it asserts.
        # High confidence on zero evidence is the invention case, not a strong finding.
        if g["corroborations"] == 0:
            entry["held_reason"] = "no source cited"
            result["held"].append(entry)
        elif g["_rank"] >= floor:
            result["surfaced"].append(entry)
        else:
            entry["held_reason"] = f"confidence {g['confidence']} below threshold"
            result["held"].append(entry)
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("directory")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    d = Path(args.directory)
    if not d.is_dir():
        print(f"error: not a directory: {d}", file=sys.stderr)
        return 2

    cfg = load_config()
    r = run(d, cfg)

    if args.json:
        print(json.dumps(r, indent=2))
        return 1 if (r["blocking"] or r["malformed"]) else 0

    print(f"Review gate  ({CONFIG_PATH.name}, surface at or above "
          f"{cfg['confidence']['surface_at_or_above']})\n")
    for name, why in r["malformed"]:
        print(f"  MALFORMED  {name}: {why}")
    for b in r["blocking"]:
        print(f"  BLOCKING   {b}")
    for dv in r["diversity"]:
        if dv["level"] != "FAIL":
            print(f"  {dv['level']:<9}  [{dv['agent']}] {dv['message']}")

    if r["surfaced"]:
        print(f"\n  SURFACED ({len(r['surfaced'])}):")
        for f in r["surfaced"]:
            print(f"    - {f['text']}")
            print(f"        {f['confidence']}, {f['corroborations']} independent "
                  f"source(s), from {', '.join(f['agents'])}")
    if r["held"]:
        print(f"\n  HELD below threshold ({len(r['held'])}) -- not dropped, chase if real:")
        for f in r["held"]:
            print(f"    - {f['text']}")
            print(f"        held: {f.get('held_reason', 'below threshold')}")

    ok = not (r["blocking"] or r["malformed"])
    print(f"\n  verdict: {'PASS' if ok else 'FAIL'}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
