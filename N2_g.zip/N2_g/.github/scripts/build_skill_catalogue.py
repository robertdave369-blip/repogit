"""Generate .github/instructions/05-skill-catalogue.instructions.md from real SKILL.md frontmatter."""
import re
from pathlib import Path

ROOT = Path(r"C:\Framework_IOEM_Py")
SKILLS = ROOT / ".github" / "skills"
OUT = ROOT / ".github" / "instructions" / "05-skill-catalogue.instructions.md"

FRONTMATTER = re.compile(r"^---\s*\n(.*?)\n---", re.S)


def field(block: str, key: str) -> str:
    match = re.search(rf"^{key}:\s*(.+?)\s*$", block, re.M)
    if not match:
        return ""
    value = match.group(1).strip()
    if value[:1] in {"'", '"'} and value[-1:] == value[:1]:
        value = value[1:-1]
    return value.strip()


def first_sentence(text: str, limit: int = 165) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"^Use when ", "", text)
    parts = re.split(r"(?<=\.)\s+", text)
    out = parts[0] if parts else text
    if len(out) > limit:
        out = out[:limit].rsplit(" ", 1)[0] + "…"
    return out[:1].upper() + out[1:]


rows = []
for skill_file in sorted(SKILLS.glob("*/SKILL.md")):
    name = skill_file.parent.name
    match = FRONTMATTER.search(skill_file.read_text(encoding="utf-8"))
    block = match.group(1) if match else ""
    declared = field(block, "name")
    description = field(block, "description")
    rows.append({
        "dir": name,
        "declared": declared,
        "ok": declared == name,
        "summary": first_sentence(description) if description else "(no description)",
    })

mismatched = [r for r in rows if not r["ok"]]

lines = [
    "---",
    "name: 'Skill catalogue'",
    "description: 'What each skill in .github/skills covers, so the right procedure gets used'",
    "applyTo: '**'",
    "---",
    "",
    "# Skill catalogue",
    "",
    "This repository ships procedures for its recurring tasks. They encode decisions already",
    "made here — formats, safety gates, which artefact is authoritative — that general",
    "knowledge will not reproduce.",
    "",
    "**Before answering a request that matches one of these, open its `SKILL.md` and follow it.**",
    "Working from memory instead is how a plausible but non-conforming answer gets produced.",
    "",
    "| Skill | Use it when |",
    "|---|---|",
]
for row in rows:
    lines.append(f"| [`{row['dir']}`](../skills/{row['dir']}/SKILL.md) | {row['summary']} |")

lines += [
    "",
    "Full text of each is in `.github/skills/<name>/SKILL.md`; several also ship runnable",
    "scripts under `scripts/` which are preferable to reimplementing the logic in chat.",
    "",
    "## Routing is also automatic",
    "",
    "`.github/hooks/scripts/user_prompt_submit.py` matches your request against",
    "`.github/hooks/scripts/routing.json` and names the files to open. If it points you at a",
    "skill, read it — the match was made on the words you used. If it turns out not to apply,",
    "say so and move on.",
    "",
    "## Not everything is a skill",
    "",
    "| Question | Read instead |",
    "|---|---|",
    "| ECU behaviour, requirements, protocols, test-design rules | `.github/agents/agent_sc3.md` |",
    "| ARIA bench and project configuration | `.github/agents/aria_agent.md` |",
    "| EDR CAN-C on-fail case validity | `.github/agents/canc_onfail.md` |",
    "| Known gaps and deferred findings | `docs/improvements/README.md` |",
    "| Specialist review personas | `.github/agents/*.agent.md` |",
    "",
]

OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"wrote {OUT.relative_to(ROOT)} with {len(rows)} skills")
if mismatched:
    print("\nWARNING - SKILL.md name does not match its directory (VS Code will not load these):")
    for row in mismatched:
        print(f"  dir={row['dir']!r} name={row['declared']!r}")
else:
    print("all skill names match their directory")
