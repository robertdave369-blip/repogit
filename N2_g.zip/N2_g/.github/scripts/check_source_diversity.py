"""Detect false consensus across specialist agents.

The failure this exists to catch: several specialists agree, the orchestrator reads
that as corroboration, but every one of them derived the claim from the same file.
That is one data point wearing several hats, and it is indistinguishable from real
agreement unless you check the sources.

Consumes evidence-handoff objects -- the schema already in this repo at
.github/skills/skill-portfolio-orchestration/references/evidence-handoff.schema.json
-- so specialists emit the format the portfolio already defines rather than a new one.

Usage:
    py -3 .github/scripts/check_source_diversity.py <dir-of-handoff-json>
    py -3 .github/scripts/check_source_diversity.py <dir> --json

Exit code 0 = no consensus risk found, 1 = at least one WARN or FAIL.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SCHEMA = (
    REPO / ".github" / "skills" / "skill-portfolio-orchestration"
    / "references" / "evidence-handoff.schema.json"
)

REQUIRED = ["stage", "intent", "facts", "contradictions", "status"]


def load_handoffs(d: Path):
    out, bad = [], []
    for p in sorted(d.glob("*.json")):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            bad.append((p.name, f"invalid JSON: {e}"))
            continue
        missing = [k for k in REQUIRED if k not in obj]
        if missing:
            bad.append((p.name, f"missing required field(s): {', '.join(missing)}"))
            continue
        out.append((p.name, obj))
    return out, bad


def source_key(s):
    """A source identity. Location is ignored: two agents citing different lines of
    the same file are still leaning on the same document."""
    if isinstance(s, dict):
        return str(s.get("path", "")).replace("\\", "/").lower()
    return str(s).replace("\\", "/").lower()


def analyse(handoffs):
    findings = []
    per_agent = {}
    for name, obj in handoffs:
        srcs = {source_key(s) for s in (obj.get("sources") or []) if source_key(s)}
        per_agent[name] = srcs

    # 1. Specialists that cited nothing at all.
    for name, srcs in per_agent.items():
        if not srcs:
            findings.append(
                ("FAIL", name, "cited no sources -- its conclusions are unverifiable")
            )

    citing = {n: s for n, s in per_agent.items() if s}
    if len(citing) >= 2:
        # 2. Every citing specialist leaning on one identical source set.
        union = set().union(*citing.values())
        common = set.intersection(*citing.values())
        if len(union) == 1:
            findings.append(
                ("FAIL", "*", f"all {len(citing)} specialists cite only "
                              f"{sorted(union)[0]} -- agreement here is one data point")
            )
        elif common and common == union:
            findings.append(
                ("WARN", "*", f"all specialists share an identical source set "
                              f"({len(common)} file(s)) -- no independent derivation")
            )

        # 3. Any single source that dominates the pool.
        tally = Counter()
        for s in citing.values():
            tally.update(s)
        for src, n in tally.items():
            if n == len(citing) and len(union) > 1:
                findings.append(
                    ("WARN", "*", f"{src} is cited by every specialist -- "
                                  f"verify at least one derived its claim elsewhere")
                )

    # 4. Contradictions are signal, not noise: surface them, never average them.
    contradictions = defaultdict(list)
    for name, obj in handoffs:
        for c in obj.get("contradictions") or []:
            contradictions[str(c)].append(name)
    for c, who in contradictions.items():
        findings.append(("INFO", ", ".join(who), f"contradiction reported: {c}"))

    # 5. Unanimous high confidence with a thin evidence pool is a smell.
    levels = [
        (obj.get("confidence") or {}).get("level")
        for _, obj in handoffs
        if isinstance(obj.get("confidence"), dict)
    ]
    if levels and all(l in ("Very High", "High") for l in levels):
        pool = set().union(*per_agent.values()) if per_agent else set()
        if len(pool) < max(2, len(handoffs)):
            findings.append(
                ("WARN", "*", f"every specialist reports high confidence from only "
                              f"{len(pool)} distinct source(s) -- unearned consensus")
            )
    return findings


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("directory", help="directory of evidence-handoff .json files")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    d = Path(args.directory)
    if not d.is_dir():
        print(f"error: not a directory: {d}", file=sys.stderr)
        return 2

    handoffs, bad = load_handoffs(d)

    # A check that silently passes on no input is worse than no check: it reads as
    # a green light. Nothing examined is an error, not a pass.
    if not handoffs:
        msg = f"no valid handoffs found in {d} -- nothing was checked"
        if args.json:
            print(json.dumps({"malformed": bad, "findings":
                              [{"level": "FAIL", "agent": "*", "message": msg}]}, indent=2))
        else:
            print(f"  FAIL   {msg}")
            for name, why in bad:
                print(f"  MALFORMED  {name}: {why}")
        return 1

    findings = analyse(handoffs)

    if args.json:
        print(json.dumps(
            {"malformed": bad,
             "findings": [{"level": l, "agent": a, "message": m} for l, a, m in findings]},
            indent=2))
    else:
        print(f"Schema: {SCHEMA.relative_to(REPO)}")
        print(f"Read {len(handoffs)} handoff(s) from {d}\n")
        for name, why in bad:
            print(f"  MALFORMED  {name}: {why}")
        if not findings and not bad:
            print("  no consensus risk detected")
        for level, agent, msg in findings:
            print(f"  {level:<5}  [{agent}] {msg}")
        print()

    blocking = [f for f in findings if f[0] in ("FAIL", "WARN")]
    return 1 if (blocking or bad) else 0


if __name__ == "__main__":
    sys.exit(main())
