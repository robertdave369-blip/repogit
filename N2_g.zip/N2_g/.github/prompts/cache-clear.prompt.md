---
name: 'cache-clear'
description: 'Empty the persistent session cache. This is the only thing that clears it.'
agent: 'agent'
argument-hint: 'Optionally: which entries to drop instead of clearing everything'
---

Clear the persistent session cache.

The cache at `.github/cache/session.json` holds facts verified in earlier sessions and is
injected at the start of every session. Nothing clears it automatically — not compaction,
not closing VS Code, not a new conversation. Only this command.

## If the user named specific entries to drop

Show the cache first, then drop only those:

```
py -3 .github/hooks/scripts/cache.py show
py -3 .github/hooks/scripts/cache.py drop fact <n>
```

Indices shift after each drop, so re-run `show` between drops or work from the highest
index down.

## Otherwise: clear everything

Show what is about to be lost, then clear:

```
py -3 .github/hooks/scripts/cache.py show
py -3 .github/hooks/scripts/cache.py clear
```

Report what was cleared — the counts and a one-line summary of the facts — so the user can
tell you if something is worth re-establishing. Confirm the cache is now empty:

```
py -3 .github/hooks/scripts/cache.py status
```
