---
name: 'cache-save'
description: 'Bank what was verified this session so the next one does not re-derive it'
agent: 'agent'
argument-hint: 'Optionally: the specific fact to cache'
---

Save what has been verified in this session to the persistent cache.

## What qualifies

Only things **established against a real artefact** in this session:

- a signal-to-frame mapping read from the DBC;
- which generator owns a script directory;
- a project-variant fact (a receiver-name convention, a DID, a qualification count);
- a correction the user made;
- a decision taken and the reason for it.

## What does not

Anything inferred, assumed, plausible, or remembered from another project. **A wrong cached
fact is worse than an empty cache** — it will be injected into every future session as
though it were established, and the model that reads it will not know to doubt it.

If you are not certain, record it as an open question instead:

```
py -3 .github/hooks/scripts/cache.py question "<what still needs confirming>"
```

## How

Each fact carries the evidence that proves it:

```
py -3 .github/hooks/scripts/cache.py fact "<what you established>" --evidence "<file, sheet, or command>"
py -3 .github/hooks/scripts/cache.py pin <path> --note "<why this file is authoritative here>"
```

Then confirm and show the result:

```
py -3 .github/hooks/scripts/cache.py show
```

List what you cached and, briefly, what you deliberately did not cache and why.
