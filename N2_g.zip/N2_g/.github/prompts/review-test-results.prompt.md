---
name: 'review-test-results'
description: 'Review HTML/XML test reports and CAN logs against the test spec and requirements; get findings (ECU defect, bench, script, test case, false pass, incomplete report ...) in an Excel sheet'
agent: 'report-review-pipeline'
argument-hint: 'Project; report and log folders or files; test spec .xlsx (optional); requirements (optional); DBC (optional)'
---

Review these test results:

${input:task:Project, report/log folder(s) or files, test spec (optional), requirements (optional), DBC (optional)}

Follow `.github/agents/report-review-pipeline.agent.md` from V1 (and `pipelines-common.md`).
Ask once for anything missing, then work hands-free. Do not modify any report or log.
