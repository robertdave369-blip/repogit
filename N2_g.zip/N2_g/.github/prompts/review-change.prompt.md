---
name: 'review-change'
description: 'Evidence-backed review of uncommitted changes, with findings ranked by consequence'
agent: 'agent'
argument-hint: 'Optionally: a path to limit the review to'
---

Review the current uncommitted changes${input:scope: (optionally limit to this path)}.

## 1. See the actual diff

```
git status --short
git diff
git diff --stat
```

Review what changed, not what you would have written. Read enough surrounding code to judge
each change in context — a diff hunk alone is not enough to call something a bug.

## 2. Check these, in this order of consequence

**Correctness against artefacts.** Every literal value that appeared or changed — signal
name, frame ID, factor, offset, DID, DTC, timing, count. Open the DBC or spec and confirm
it. This is where the real defects are.

**Cross-project contamination.** Was a value copied from another project's config? They are
not portable. Check it against *this* project's source.

**Generated files edited by hand.** Any changed file under `projects/*/modules/*/scripts/`
whose header says `GENERATED FILE`. That change will be lost on the next rebuild.

**Shared-library blast radius.** Any change in `shared_libraries/`: does it rename,
re-signature or shadow an existing public name? Star-import order means a new name can
silently replace an earlier one for every script in every project.

**Silent failure paths.** Bare `except:`, a fallback that continues after a missing input, a
wrapper returning a success code without doing anything. These turn a broken test into a
passing one, which is the worst failure mode here.

**Conventions.**

```
py -3 .github/hooks/scripts/validate_script.py <changed .py files>
py -3 -m py_compile <changed .py files>
```

## 3. Verify before reporting

For each candidate finding, construct the concrete failure: specific inputs or state →
specific wrong outcome. If you cannot, either it is not a finding or you do not understand
it yet — say which. Drop anything that survives only as "this looks off".

## 4. Report

Ranked by consequence, most severe first:

```
<file>:<line> — <one-sentence statement of the defect>
  Fails when: <concrete inputs/state → wrong output>
  Evidence:   <artefact and location that proves the expected value>
```

Then, separately: what you checked and found clean, and what you could **not** check and
why. A review that lists only findings hides its own gaps.

Do not run bench scripts as part of this review.
