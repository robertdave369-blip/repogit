---
name: 'review-test-cases'
description: 'Review existing test cases (Excel spec or Codebeamer) against requirements, the customer L10, DBC and diag spec: traceability, coverage gaps, wrong expected results, steps, timing, pre/postconditions; get an Excel findings sheet with corrections, suggested test cases and a review report'
agent: 'test-case-review-pipeline'
argument-hint: 'Project; test cases (Excel spec path or Codebeamer IDs/tracker); requirements (Codebeamer IDs/tracker or file); L10 (optional); other sources and focus (optional)'
---

Review these test cases:

${input:task:Project, test cases (Excel spec path or Codebeamer test-case IDs/tracker + status), requirements (Codebeamer IDs/tracker or file; default: what the test cases verify), customer L10 (Codebeamer IDs or documents, or none), other sources (DBC, diag spec ...), scope or focus}

Follow `.github/agents/test-case-review-pipeline.agent.md` from C1 (and `pipelines-common.md`).
Ask once for anything missing, then work hands-free. Do not edit my spec or Codebeamer: deliver the
findings sheet, the review report and the suggested test cases, and apply only the corrections I
accept, to copies.
