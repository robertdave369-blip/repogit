---
name: "Veoneer Format Spec"
description: "Use when creating a requirement-derived Veoneer Excel specification in the V3-style 22-column Export format from files, attachments, or pasted requirements."
argument-hint: "Provide requirement and context sources or pasted requirements, project/variant, optional naming rule, and output name"
agent: "agent"
---

# Veoneer Format Specification

Create one review-ready, offline Veoneer test specification from the requirements and context supplied with this invocation.

Before authoring, load and follow the [Veoneer test-spec generator skill](../skills/veoneer-test-spec-generator/SKILL.md) and the applicable evidence, test-design, traceability, and safety rules in [agent_sc3.md](../agents/agent_sc3.md). Do not operate a bench, ECU, power supply, fault-injection device, or Codebeamer importer.

## Inputs

Accept any combination of:

- Requirement files or attachments: Markdown, text, Excel, CSV, JSON, Word, or PDF.
- Pasted or inline requirements.
- Context sources: DBC, design, diagnostic, configuration, previous specification, or requirement-tracker files.
- Project/variant, intended verification scope, output name, and an optional case-naming convention.

Treat requirements as read-only. Read every supplied requirement source completely with the parsers required by the skill. Use context sources to validate terminology, applicability, encoding, timings, interfaces, and expected results; do not treat context prose as an active requirement unless the user identifies it as one.

## Required Output Format

Create the workbook through the skill's `generate-legacy-export` workflow. The output must use the V3-style 22-column `Export` layout:

`ID`, `Priority`, `Name`, `Description`, `Pre-Action`, `Post-Action`, `Test Steps.Action`, `Test Steps.Expected result`, `Test Steps.Critical`, `Test Parameters`, `Verifies`, `Status`, `Type`, `_Project`, `Reviewer(s)`, `_LatestResult`, `_Original_Id`, `Referenced Reviews`, `_ScriptPath`, `_TestType`, `_VerificationMethod`, `_TestTechnique`.

Use the known-good formatting seed at [Dummy_Legacy_Export_Spec.xlsx](../../tests/veoneer_test_spec_generator_demo/Dummy_Legacy_Export_Spec.xlsx) unless the user supplies an approved replacement template. Always write to a new output file under `tests/`; never overwrite the seed or a user artifact without explicit permission.

Write case-level fields only on the primary row containing `Name`. Write subsequent steps on continuation rows using only `Test Steps.Action`, `Test Steps.Expected result`, and, when supported, `Test Steps.Critical`.

`ID` is a test-case artifact ID. Leave it blank unless the user explicitly provides an existing test-case ID. Put verified requirement IDs in `Verifies` only, using exactly `[ISSUE:<ID>] - null` for one ID and `[ISSUE:<ID>] - null,[ISSUE:<ID>] - null` for multiple IDs. Do not invent any ID.

## Test Design And Naming

Derive every test objective, precondition, test step, expected result, priority, and test technique from the supplied requirement evidence and validated context. Build the smallest high-value suite that covers nominal behavior plus only applicable boundaries, states, decisions, failures, recovery, diagnostics, interfaces, and configuration variants. Put higher-risk cases first.

Use the user's naming convention exactly when supplied. Otherwise, first reuse a naming convention evidenced in the requirement source or prior specification. If none exists, use a concise source-derived proposal in this form:

`SUBS_<MODULE>_<FEATURE>_<SCENARIO>`

where each token uses terminology from the requirements. State the proposed pattern in the review summary. Never use a generic name when a source-defined module, feature, scenario, or existing convention is available.

Do not invent DTCs, DIDs, CAN IDs, signals, timing values, limits, fault methods, test-case IDs, or pass criteria. Keep unsupported behavior visible as `TBC: requirement clarification required`, record it in coverage gaps, and do not label it pass or fail.

## Defaults And Completion

If the user omits an output name, propose `tests/<PROJECT>_<MODULE>_Test_Spec.xlsx` using available source terminology. If project, variant, source scope, naming, or required evidence is ambiguous enough to change the test design, ask one concise question before generation; otherwise, apply the defaults and record them in the JSON validation report.

Generate the workbook and its validation report. Validate the template, all rendered headers, primary/continuation row structure, requirement traceability format, and coverage gaps. Finish with the workbook path, report path, case count, unresolved evidence gaps, and validation result. Do not claim a successful Codebeamer import without an approved importer round trip.