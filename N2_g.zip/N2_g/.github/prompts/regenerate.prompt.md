---
name: 'regenerate'
description: 'Find the generator that owns a file or directory and rebuild it correctly'
agent: 'agent'
argument-hint: 'The file, directory, or project to regenerate'
---

Regenerate: ${input:target:Which file, directory, or project?}

## 1. Find the owner

Read the header of any generated file in the target:

```
head -5 <a file in the target directory>
```

The `Rebuild with:` line names the generator and its arguments. If there is no header,
search for what writes there:

```
grep -rn "<directory name>" tools/*.py
```

If nothing owns it, the files are hand-written — say so and stop. Do not invent a
generator.

## 2. Check what the generator reads

Open it and list its inputs: DBC, DRBFM sheet, diagnostic spec, CSV, config module.
Confirm each input file exists and note its modification date. If an input is missing, stop
and ask — do not let the generator fall back to a default.

## 3. Record the before state

```
ls projects/<PROJECT>/modules/<MODULE>/scripts/ | wc -l
git status --short
```

You need this to say afterwards what actually changed.

## 4. Run it

Use `py -3.14` — that is the interpreter with `openpyxl` and `cantools`.

```
py -3.14 tools/<generator>.py --project <NAME>
```

Capture the full output. If it reports counts of rows read or files written, quote them.

## 5. Check the result

```
git status --short | head -40
git diff --stat
py -3 .github/hooks/scripts/validate_script.py projects/<PROJECT>/modules/<MODULE>/scripts/*.py
py -3 -m py_compile <a sample of the output files>
```

## 6. Report honestly

- files written, changed, added, deleted — real numbers from `git diff --stat`;
- convention findings, if any;
- **anything the generator skipped**, and why. A generator that silently drops inputs
  produces output that looks complete and is not — if its logs do not account for every
  input row, say that you could not confirm completeness.

Do not run the generated scripts. They drive hardware.
