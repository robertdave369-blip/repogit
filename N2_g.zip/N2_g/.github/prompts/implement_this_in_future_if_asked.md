Act as a Principal AI Architect and Python Framework Engineer.

Design and implement a production-grade Agent Orchestration Framework that is fully compatible with Python 3.13+.

OBJECTIVE

Create a self-learning agent framework that dynamically selects and executes the most relevant skill, tool, or agent based on user intent, context, memory, and historical success patterns.

The framework must be lightweight, modular, plugin-based, and easy to embed inside an existing Python test automation framework.

ARCHITECTURE REQUIREMENTS

The framework must contain the following components:

1. BaseSkill
2. SkillRegistry
3. AgentRouter
4. MemoryManager
5. WorkflowEngine
6. ExecutionContext
7. PluginLoader
8. VectorMemoryStore
9. SqliteMemoryStore
10. SkillEvaluator
11. EventBus
12. MiddlewareManager

SKILL SYSTEM

Create a pluggable skill architecture.

Each skill must inherit from BaseSkill.

Example:

class JiraSkill(BaseSkill):
    name = "jira"

    capabilities = [
        "create ticket",
        "update ticket",
        "search ticket"
    ]

    async def execute(self, context):
        ...

Skills must be automatically discovered from a /skills directory.

No code changes should be required when adding new skills.

Dynamic runtime registration must be supported.

INTENT ROUTING

Implement intelligent routing that can:

- Analyze user requests
- Identify intent
- Match intent to skills
- Score skill relevance
- Execute the highest scoring skill
- Execute multiple skills when necessary

Provide:

- keyword matching
- semantic matching
- confidence scores
- fallback handling

MEMORY REQUIREMENTS

Implement two memory layers.

SHORT TERM MEMORY

Store:

- conversation history
- execution context
- active workflow state

LONG TERM MEMORY

Store:

- successful executions
- failed executions
- user preferences
- skill usage history
- routing history
- learned patterns

Use SQLite as the default persistent storage layer.

VECTOR MEMORY

Implement semantic memory using:

- FAISS

Store embeddings for:

- prompts
- conversations
- execution results
- skill descriptions

Allow semantic retrieval of relevant memories.

LEARNING SYSTEM

Create a self-improving routing engine.

Track:

- success rate by skill
- failure rate by skill
- execution latency
- user feedback
- routing confidence

Routing decisions should improve over time.

Successful skills should receive higher weighting.

Failed skills should receive lower weighting.

WORKFLOW ENGINE

Implement support for:

- sequential workflows
- parallel workflows
- conditional workflows
- nested workflows

Example:

Request
   ↓
Router
   ↓
Jira Skill
   ↓
API Skill
   ↓
Reporting Skill
   ↓
Memory Update

MIDDLEWARE

Support hooks:

before_execution()

after_execution()

on_error()

before_skill_selection()

after_skill_selection()

PLUGIN SYSTEM

Create a plugin framework that supports:

plugins/
    jira/
    github/
    playwright/
    sql/
    api/
    azure/

Each plugin should be loaded automatically during application startup.

OBSERVABILITY

Implement:

- structured logging
- execution tracing
- performance metrics
- routing diagnostics
- memory diagnostics

CONFIGURATION

Create configuration support using Pydantic.

Example:

config.yaml

router:
  confidence_threshold: 0.75

memory:
  sqlite_path: "./memory.db"

vector_store:
  enabled: true

TESTS

Generate:

- unit tests
- integration tests
- sample plugins
- sample workflows

DEPENDENCIES

The generated solution must be compatible with Python 3.13+.

Avoid frameworks that require greenlet.

Use only stable modern packages that support Python 3.13+.

Preferred libraries:

- pydantic
- sqlite3
- sentence-transformers
- faiss-cpu
- numpy
- asyncio
- pathlib
- importlib

PROJECT STRUCTURE

Generate the complete project structure:

agent_framework/
│
├── core/
├── memory/
├── router/
├── skills/
├── plugins/
├── workflows/
├── middleware/
├── config/
├── tests/
├── examples/
└── main.py

OUTPUT REQUIREMENTS

Generate:

1. High-level architecture diagram
2. Folder structure
3. Complete production-ready source code
4. Pydantic models
5. SQLite schema
6. Memory implementation
7. Router implementation
8. Workflow engine implementation
9. Plugin loader implementation
10. Example skills
11. Example workflows
12. Test suite
13. README.md
14. Installation instructions
15. Extension guide for adding new skills

The solution should be designed as a reusable agent framework that can serve as the foundation for a Copilot-like system with memory, skill routing, self-learning behavior, and plugin extensibility.

Generate the solution incrementally in phases.

Phase 1:
Create architecture and folder structure.

Phase 2:
Implement core framework classes.

Phase 3:
Implement memory layer.

Phase 4:
Implement intelligent routing.

Phase 5:
Implement plugin loading.

Phase 6:
Implement workflow engine.

Phase 7:
Implement self-learning and memory scoring.

Phase 8:
Create sample skills.

Phase 9:
Create tests.

Phase 10:
Create documentation and README.