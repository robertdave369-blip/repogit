---
name: 'write-test-cases'
description: 'Write traceable test cases in the Codebeamer import format from requirements, and/or add missing traceability to an existing Excel test spec with documented corrections'
agent: 'test-case-writer-pipeline'
argument-hint: 'Project; requirement spec (CB IDs/tracker or file); existing test spec .xlsx (optional, for traceability); template (optional)'
---

Test-case task:

${input:task:Project, requirement spec (Codebeamer IDs/tracker or file path), existing test spec to trace (optional), template (optional), what you want (new test cases / traceability / both)}

Follow `.github/agents/test-case-writer-pipeline.agent.md` from W1 (and `pipelines-common.md`).
Ask once for anything missing, then work hands-free. Deliver the workbooks and the corrections
for my review; push nothing to Codebeamer until I approve.
