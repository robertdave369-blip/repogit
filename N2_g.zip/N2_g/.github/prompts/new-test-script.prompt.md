---
name: 'new-test-script'
description: 'Add a bench test script the right way — generator first, conventions checked'
agent: 'agent'
argument-hint: 'Project, module, and what the test must verify'
---

Add a test script for: ${input:objective:What must this test verify, for which project and module?}

Work through these in order. Do not skip step 1 — it decides whether you edit a script at
all.

## 1. Find out whether this directory is generated

```
head -5 projects/<PROJECT>/modules/<MODULE>/scripts/<any existing file>.py
```

If you see `GENERATED FILE - do not edit by hand`, the header names the generator. **Your
change goes in that generator**, then you re-run it. Say this to the user before writing
anything, because it changes the shape of the work. Adding one case to a generator usually
means adding a row to its input table, not writing a script.

If the directory is not generated, continue.

## 2. Establish the values you need, from artefacts

Do not write a single value from memory. For each signal, frame, DID, DTC or timing:

- signals, frames, factors, offsets → this project's DBC in `project_dbc/`
- DIDs, DTCs, NRCs → this project's diagnostic spec workbook
- intervals, EDR layout → `projects/<PROJECT>/config/edr_config.py`
- qualification timings → the diag spec's DTC List and NetworkManagement sheets

Anything you cannot establish: stop and ask. Do not substitute a value from another
project — they are not portable.

## 3. Read a neighbour

Open two or three existing scripts in the same directory. Match their structure, naming,
reporting style and numbering. Consistency here matters more than your preferences.

## 4. Write it

Follow `.github/instructions/10-test-scripts.instructions.md`, which is attached
automatically. The two rules that are checked after you write:

- `from Framework_IOEM_Py.shared_libraries.import_list import *`
- all test code inside `def run_test():`

Values come from the config module, never inline. No absolute paths, no hardcoded channel
names, no bare `except:`, `Sleep()` not `time.sleep()`.

## 5. Verify — without running it on the bench

```
py -3 -m py_compile <file>
py -3 .github/hooks/scripts/validate_script.py <file>
```

Do **not** execute the script. It drives real hardware.

## 6. Report

State: which requirement the case covers, where each value came from, what you verified,
and explicitly that it has not been run against hardware. If you had to assume anything,
say so and name it.

Then cache anything durable you established:

```
py -3 .github/hooks/scripts/cache.py fact "<...>" --evidence "<...>"
```
