---
name: 'review-requirements'
description: 'Review Codebeamer requirements against the customer L10 document and other documents; get evidence-backed review comments in an Excel sheet'
agent: 'requirement-review-pipeline'
argument-hint: 'Project; Codebeamer requirement IDs or tracker (+ status); L10 document(s) or CB IDs; other documents (DBC, diag spec, ...)'
---

Review these requirements:

${input:task:Project, Codebeamer requirement IDs or tracker ID (+ status), customer L10 document path(s) or Codebeamer IDs, other documents, scope}

Follow `.github/agents/requirement-review-pipeline.agent.md` from R1 (and `pipelines-common.md`).
Ask once for anything missing, then work hands-free. Deliver the review sheet; do not change
Codebeamer unless I approve a specific plan ID.
