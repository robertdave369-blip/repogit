---
name: 'run-test-task'
description: 'Run one bench test task end to end: Codebeamer/manager task -> requirements, test cases, OEM L10, source review -> ARIA execution -> named logs and reports -> triage and fixes -> bug list -> zip and PTC push on your paths'
agent: 'test-execution-pipeline'
argument-hint: 'Project; task (Codebeamer IDs or the manager instructions); OEM L10 source (CB IDs or file paths); ECU source folder; bench files (AriaMain.json, loadbox profile, RSU workbook, DBC)'
---

Run the test-execution pipeline for this task:

${input:task:Project, task (Codebeamer requirement/test-case IDs, or paste the manager's instructions), OEM level-10 spec source, ECU source folder, bench files (AriaMain.json, loadbox profile, RSU workbook, DBC) or "as ARIA has them"}

Follow `.github/agents/test-execution-pipeline.agent.md` from S1. Ask once for everything that is
missing (its §1), then work hands-free and stop only at its gates G1–G5. Before any test runs,
make sure ARIA — also when it is already open — runs the project, loadbox profile, RSU workbook and
DBC I named and that the bench is fault free (no DTC); if not, fix it or ask me, and go on with
problems only when I say so. Do not push anything to
Codebeamer or PTC until I approve the exact plan, and ask me for the zip name, destination and PTC
target at S15.
