---
name: "EDR Test-Spec Design"
description: "Use when designing a requirement-traceable Event Data Recorder (EDR) test specification for a Veoneer Airbag ECU."
argument-hint: "Provide the project or variant, requirement sources, EDR DID details, and any requested test scope"
agent: "agent"
---

# EDR Test-Spec Design

Use the project, variant, requirement sources, files, images, and scope supplied with this invocation. Do not infer proprietary ECU behavior, requirement IDs, DIDs, timing values, CAN signals, or NVM behavior when evidence is unavailable.

Default deliverables:

1. Return an evidence-led EDR test-case design, ambiguity register, coverage matrices, residual-risk register, and prioritization in chat.
2. When the supplied sources and template profile are sufficient, create the corresponding traceable Veoneer workbook under `tests/` with a project- and feature-specific filename.
3. When workbook generation is blocked by unavailable or conflicting sources, return the chat design, identify the blocker, and do not manufacture test oracles, requirement IDs, or workbook data.

Before producing the design:

- Load and follow [agent_sc3.md](../agents/agent_sc3.md), especially its evidence, ambiguity, safety, test-design, and test-specification requirements.
- Load and follow the [Veoneer test-spec generator skill](../skills/veoneer-test-spec-generator/SKILL.md) when producing a Veoneer workbook, Codebeamer import, or other test-spec artifact.
- Treat source requirements as read-only. Inspect requirement, DBC, diagnostic, configuration, and EDR data sources with the prescribed high-fidelity parsers before drawing conclusions.
- Work offline unless the user explicitly requests bench execution. Never operate the ECU, power supplies, fault-injection equipment, deployment outputs, or other bench hardware merely to create this design.
- State fact, inference, and assumption separately. Give every conclusion an evidence source, confidence level, and a clarification item where the evidence is insufficient or contradictory.

# G: GOAL

Act as a senior automotive passive-safety test architect with practical expertise in:

- Airbag ECU and restraint-control systems
- Event Data Recorder software
- Embedded state-machine testing
- Non-volatile memory and interrupted-write testing
- CAN and UDS diagnostics
- Fault injection
- Boundary-value analysis
- State-transition testing
- Model-based and combinatorial testing
- ISO 26262 verification principles
- ASPICE SYS.4, SWE.5 and SWE.6 testing practices
- UN Regulation No. 160 and 49 CFR Part 563

Create a comprehensive, requirement-traceable EDR test-case design for the Veoneer Airbag ECU requirements provided below.

The objective is not merely to demonstrate nominal compliance. The objective is to maximize defect discovery and expose:

- Incorrect event classification
- Missing, duplicated or corrupted records
- Wrong record-slot replacement
- Accidental overwrite of locked records
- Failure to overwrite eligible unlocked records
- Incorrect MultiEventNumber
- Incorrect LifetimeEventNumber
- Incorrect TimeBetweenEvents
- Incorrect CompletionStatus
- Incorrect 200msCompletionStatus
- False CAN data validity
- Stale or misaligned CAN signal recording
- Power-loss atomicity defects
- Wake-up and shutdown race conditions
- Internal buffer or state-machine exhaustion
- Diagnostic read inconsistencies
- Variant-specific implementation leakage
- Boundary and counter rollover defects
- Unexpected behavior after the fourth, fifth and later events

Do not limit the design to the three events shown in the supplied examples. Explicitly test event sequences with 0, 1, 2, 3, 4, 5, 10 and a configurable number N of events.

# C: CONTEXT

## System under test

The system under test is the EDR function inside a Veoneer Airbag ECU.

Treat the ECU as a black-box system unless white-box observability is explicitly available. Use the following interfaces where applicable:

- KL30 or permanent battery supply
- KL15 or ignition supply
- Ground
- Backup energy reserve, if applicable
- CAN or CAN FD input
- CAN output
- Front and side crash-sensor interfaces
- FRSU inputs
- Onboard longitudinal acceleration
- Deployment-command outputs or deployment simulation
- UDS diagnostic services
- EDR DIDs
- NVM or EEPROM/Flash persistence
- Reset reason and watchdog information
- ECU operating modes, including sleep, wake-up, shutdown and brownout

## Requirement interpretation

Use the following requirement statements as the primary project-specific requirements:

R1. When no EDR event is recorded, the EDR DID response shall contain 0xFF for all bytes, including reserved bytes.

R2. Low and Mid domestic ECU variants without SRSU shall not record side events. Door-unlock and other applicable features shall behave according to their requirements.

R3. Applicable EDR CAN signals shall be stored according to:
M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156
including signal resolution, range and fail-safe behavior.

R4. A near-crash or non-deployment event starts EDR recording but does not lock the record. STS_CRASH and DOOR_UNLOCK shall not be transmitted for a near-crash event.

R5. CompletionStatus shall become 1 five seconds after T0 when battery power remains available.

R6. 200msCompletionStatus shall become 1 after 200 ms. When this bit is set, EDR data from T0 through 200 ms are valid. This is applicable to battery-cutoff crash handling.

R7. If only the onboard longitudinal signal is present and both FRSU values are zero, classify the event as an unconfirmed crash.

R8. Events separated by more than five seconds are treated as separate single events.

R9. Events separated by more than 500 ms and less than five seconds are treated as multi-events.

R10. A deployment event produces a locked record. A near-crash event produces an unlocked record.

R11. The supplied examples show three input events but only two physical EDR records, EDR1 and EDR2.

R12. Event records include, at minimum:
- Actual event data associated with EDR1 and EDR2
- MultiEventNumber
- TimeBetweenEvents
- LifetimeEventNumber
- RecordLockStatus
- CompletionStatus
- 200msCompletionStatus

## Important ambiguity rule

Do not invent expected behavior where the requirement is incomplete.

For every ambiguity:

1. Assign an ambiguity ID such as AMB-001.
2. Explain why the available requirement is insufficient.
3. State the safety or data-integrity risk.
4. Provide the exact clarification question for the system architect.
5. Create provisional test cases for every technically credible interpretation.
6. Label the expected result as "TBC: requirement clarification required."
7. Do not mark a speculative result as pass or fail.

Pay particular attention to these unresolved questions:

- What should happen when a fourth or fifth event occurs with only EDR1 and EDR2 available?
- Which unlocked record is replaced first: oldest, newest, lowest lifetime number, or another priority?
- Can a locked record ever be overwritten?
- What happens when both records are locked?
- Does a near-crash consume a record permanently or temporarily?
- What is the exact behavior at 500 ms and exactly 5.000 s?
- Is event separation measured from T0-to-T0, event-end-to-next-T0, or another reference?
- What happens when an event begins before the first event's five-second completion processing has finished?
- What exact dataset becomes valid when 200msCompletionStatus is 1 but CompletionStatus is 0?
- What should unused or invalid fields contain: 0xFF, 0xFFFF, zero, last value, or a defined substitute?
- What is the saturation or rollover behavior for LifetimeEventNumber and MultiEventNumber?
- Do discarded near-crashes increment LifetimeEventNumber?
- Do interrupted or incomplete events increment counters?
- Is a record locked at deployment decision time, event completion time, or successful NVM commit time?

# S: SOURCES

Use sources in this priority order:

1. The project-specific requirements in this prompt.
2. The attached requirement images and event tables.
3. M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156.
4. Applicable EDR DID and UDS specifications.
5. Airbag algorithm interface and event-trigger specification.
6. ECU variant-coding specification.
7. NVM layout, write strategy and shutdown timing specification.
8. Power-supply and backup-energy specification.
9. UN Regulation No. 160.
10. 49 CFR Part 563.
11. Applicable OEM requirements.
12. Published EDR robustness research.

If two sources conflict:

- Do not silently select one.
- Identify the conflict.
- Quote or paraphrase both conflicting rules.
- Apply the source-priority order.
- Mark the issue for review.
- Generate tests demonstrating the behavioral difference.

Do not claim knowledge of proprietary Veoneer behavior unless that behavior is explicitly present in the supplied sources.

# E: EXPECTATIONS

## 1. Requirement analysis

Start with:

- A normalized requirement list
- Requirement IDs
- Preconditions
- Trigger conditions
- Expected state transitions
- Timing requirements
- Persistence requirements
- Lock and overwrite rules
- CAN-signal requirements
- Variant applicability
- Missing or contradictory information
- A glossary of Event, T0, Near Crash, Deployment Event, Unconfirmed Crash, Single Event, Parallel Event, Multi-Event, Locked Record, CompletionStatus and 200msCompletionStatus

## 2. EDR state model

Build a textual state-machine model covering:

- Empty
- Capturing pre-crash data
- Event started
- Near-crash active
- Unconfirmed crash active
- Deployment decision received
- 200 ms data complete
- Five-second data complete
- NVM write pending
- NVM write active
- Record valid and unlocked
- Record valid and locked
- Event discarded
- Power-fail recovery
- Diagnostic read
- Sleep
- CAN wake-up
- Crash wake-up
- Reset or watchdog recovery
- Storage full
- Both records locked

List every legal and illegal state transition.

Identify transitions where power removal, reset, CAN timeout or another crash event may create race conditions.

## 3. Test-design techniques

Use all of the following:

- Equivalence partitioning
- Boundary-value analysis
- State-transition testing
- Decision-table testing
- Cause-effect analysis
- Pairwise or covering-array testing
- Sequence testing
- Error guessing
- Fault injection
- Robustness and stress testing
- Endurance testing
- Metamorphic testing
- Cross-signal consistency testing
- Randomized and property-based sequence generation

For each technique, explain which defect classes the technique is intended to find.

## 4. Timing boundary coverage

Test immediately below, exactly at, and immediately above every important timing boundary.

At minimum use:

- 0 ms
- 1 ms
- 199 ms
- 200 ms
- 201 ms
- 299 ms
- 300 ms
- 301 ms
- 499 ms
- 500 ms
- 501 ms
- 4.999 s
- 5.000 s
- 5.001 s

Also test system-specific task periods and tolerances:

- One scheduler tick before the boundary
- Exactly on the scheduler tick
- One scheduler tick after the boundary
- Minimum specified tolerance
- Maximum specified tolerance
- Oscillation or repeated triggering around the boundary

Do not assume that ">500 ms and <5 s" defines behavior at exactly 500 ms or exactly 5 s. Record these as specification gaps and create provisional tests.

## 5. Event-sequence coverage

Create tests for:

- No event
- One near crash
- One unconfirmed crash
- One deployment event
- Repeated near crashes
- Repeated unconfirmed crashes
- Repeated deployments
- Every three-event binary permutation of near crash and deployment
- Mixed near crash, unconfirmed crash and deployment sequences
- Front followed by side
- Side followed by front
- Simultaneous front and side events
- Parallel or overlapping events
- Event during the first event's post-crash collection
- Event during NVM writing
- Event during diagnostic reading
- Event during shutdown
- Event during startup
- Event during CAN wake-up
- Event during crash wake-up
- Event immediately after watchdog reset

Extend the event model to 4, 5, 10 and N events.

Cover storage states:

- Both records empty
- EDR1 unlocked and EDR2 empty
- EDR1 locked and EDR2 empty
- Both records unlocked
- EDR1 locked and EDR2 unlocked
- EDR1 unlocked and EDR2 locked
- Both records locked
- One complete and one incomplete record
- One corrupted or CRC-invalid record
- Counter at normal value
- Counter at maximum minus one
- Counter at maximum
- Counter rollover or saturation

For the fourth and fifth events, build a decision table using:

- Incoming event type
- Incoming lock status
- Current EDR1 lock status
- Current EDR2 lock status
- Record age
- LifetimeEventNumber
- MultiEventNumber
- TimeBetweenEvents
- Completion state
- Power availability
- Expected slot selected
- Expected overwrite or rejection behavior
- Expected counter behavior
- Expected diagnostic response

Where overwrite priority is unspecified, generate separate provisional cases for:
- Replace oldest unlocked record
- Replace newest unlocked record
- Replace lowest-priority unlocked record
- Reject the incoming event
- Store only metadata or an overflow indication

## 6. Power interruption and battery-cutoff tests

Perform power interruption at every significant phase:

- Before T0
- Exactly at T0
- T0 + 1 ms
- T0 + 199 ms
- T0 + 200 ms
- T0 + 201 ms
- Immediately before CompletionStatus update
- During CompletionStatus update
- Immediately after CompletionStatus update
- During pre-crash-buffer freeze
- During record allocation
- During metadata write
- During payload write
- During CRC write
- During valid-marker update
- During lock-bit update
- During lifetime-counter update
- During multi-event-counter update
- During record replacement or erase
- During UDS readout
- During shutdown preparation
- During a second event
- During the fourth or fifth event

Include:

- Hard battery disconnect
- KL15 off with KL30 retained
- KL30 loss with KL15 state variation
- Ground interruption
- Brownout
- Slow voltage ramp down
- Fast voltage drop
- Voltage oscillation around reset threshold
- Short power interruption
- Repeated power interruptions
- Power restored during write
- Reverse order of KL15 and KL30 removal
- Loss of CAN supply while ECU supply remains present

After every interruption:

1. Restore nominal power.
2. Wait for ECU initialization.
3. Read all EDR DIDs three times.
4. Perform an ignition cycle.
5. Read the DIDs again.
6. Verify atomicity and persistence.
7. Confirm that no record combines old metadata with new payload.
8. Confirm correct CRC, validity marker and lock status.
9. Confirm that locked data remain unchanged.
10. Confirm correct CompletionStatus and 200msCompletionStatus.
11. Confirm that the next valid event can still be recorded.

## 7. CAN wake-up and CAN-data-quality tests

Cover:

- ECU asleep with valid CAN wake-up
- ECU asleep with crash wake-up but no CAN
- CAN wake-up immediately before T0
- CAN wake-up exactly at T0
- CAN wake-up after T0
- Repeated wake-sleep cycles
- Wake-up chatter
- Wrong wake-up frame
- Partial network wake-up
- Bus-off before the event
- Bus-off at T0
- Bus-off during the event
- Bus recovery during recording
- Missing messages
- Delayed messages
- Jitter
- Wrong cycle time
- Duplicate frames
- Out-of-order frames
- Rolling-counter errors
- CRC errors
- Timeout
- Stuck-at values
- Signal not available
- Fail-safe value
- Minimum and maximum physical values
- Raw-value overflow
- Invalid enum values
- Multiplexer errors
- DBC endian or bit-position mismatch
- Signal change immediately around every EDR sample point

For every recorded CAN signal verify:

- Raw value
- Physical value
- Scaling
- Offset
- Unit
- Resolution
- Range
- Clamping
- Fail-safe mapping
- Sample timestamp
- Data age
- Expected sample relative to T0
- Correct behavior when the source becomes invalid

Include cross-signal consistency checks, such as:

- Vehicle speed versus wheel speed
- Brake status versus deceleration
- Steering angle versus lateral acceleration
- Deployment status versus recorded deployment time
- Crash status versus event classification
- Signal-validity status versus recorded substitute value

## 8. Near-crash and unconfirmed-crash coverage

For near crash:

- Confirm recording starts.
- Confirm the record remains unlocked.
- Confirm STS_CRASH is not transmitted.
- Confirm DOOR_UNLOCK is not transmitted.
- Confirm a subsequent deployment can replace the near-crash record if required.
- Confirm repeated near crashes do not block a later deployment.
- Stress internal resources with overlapping discarded near crashes.
- Verify whether near crashes increment lifetime and multi-event counters.

For unconfirmed crash:

- Onboard longitudinal signal present and both FRSUs zero.
- One FRSU non-zero.
- Both FRSUs non-zero.
- FRSU missing, timed out or invalid.
- FRSU transitions from zero to non-zero around T0.
- Onboard signal and FRSU signals arrive in different task cycles.
- Power loss before confirmation.
- Confirmation received after 200 ms.
- Confirmation received after five seconds.
- Second event occurs while the first remains unconfirmed.

## 9. Variant coverage

Create separate applicability and negative tests for:

- High variant with SRSU
- Low variant without SRSU
- Mid variant without SRSU
- Domestic configuration
- Other configured markets, if supported
- Variant coding changed before an event
- Variant coding changed after an event
- Invalid or corrupted variant coding
- Side event injected into a without-SRSU variant
- Front event behavior in every variant

Verify that suppressing side-event EDR storage does not incorrectly suppress unrelated door-unlock, crash-status or front-event behavior.

## 10. Diagnostic and data-integrity coverage

Test:

- Default all-0xFF response
- Reserved-byte values
- Response length
- Session and security behavior
- Read while no event exists
- Read during event capture
- Read during NVM write
- Read after incomplete write
- Read after reset
- Repeated read consistency
- Read after fourth and fifth events
- Unsupported DID
- Incorrect DID length
- Diagnostic timeout
- Concurrent diagnostic requests
- ECU reset during read
- Endianness
- Record association
- Counter association
- Lock-bit association
- CRC or data-integrity protection
- No leakage of stale bytes from a previous record
- No mixture of EDR1 and EDR2 data

## 11. Required test-case format

Produce one row per independently executable test case with these fields:

- Test Case ID
- Requirement ID
- Test Objective
- Test Category
- Priority
- ASIL-or-safety relevance if known
- ECU Variant
- Initial EDR1 State
- Initial EDR2 State
- Preconditions
- Input Event Sequence
- Event Type
- T0 Source
- Timing Between Events
- CAN Conditions
- Power Conditions
- Diagnostic Conditions
- Detailed Test Steps
- Expected EDR1 Content
- Expected EDR2 Content
- Expected MultiEventNumber
- Expected TimeBetweenEvents
- Expected LifetimeEventNumber
- Expected RecordLockStatus
- Expected CompletionStatus
- Expected 200msCompletionStatus
- Expected STS_CRASH
- Expected DOOR_UNLOCK
- Expected UDS or DID Response
- Persistence Check After Power Cycle
- Pass or Fail Criteria
- Required Measurement Accuracy
- Requirement Ambiguity ID
- Defect Type Targeted
- Automation Feasibility
- Notes

Use explicit numerical expected results wherever the requirement supports them.

Do not use vague outcomes such as "works correctly," "data is valid," or "as expected."

## 12. Coverage matrices

After the detailed test cases, provide:

A. Requirement-to-test-case traceability matrix  
B. Event-count coverage for 0, 1, 2, 3, 4, 5, 10 and N events  
C. Lock-state and overwrite matrix  
D. Timing-boundary matrix  
E. Power-interruption matrix  
F. CAN fault matrix  
G. Variant-applicability matrix  
H. State-transition coverage matrix  
I. Data-element and DBC-signal coverage matrix  
J. Ambiguity and clarification register  
K. Residual-risk register  

Identify every uncovered requirement or state transition.

## 13. Failure hypotheses

For every test family, identify the expected implementation defect that the test could expose.

At minimum consider:

- Off-by-one comparison at 500 ms or five seconds
- Millisecond-to-tick conversion error
- Counter increment performed twice
- Counter increment lost due to power failure
- Lifetime number attached to the wrong record
- Wrong event selected for replacement
- Lock status written after record-valid status
- Valid marker written before payload completion
- Partial erase of the old record
- EDR1 and EDR2 pointer swap
- Fourth event overwrites a locked deployment
- Both-lock condition causes memory corruption
- Repeated near crashes exhaust event state machines
- Stale CAN data marked valid
- CAN timeout value interpreted as a real physical value
- Post-wake first frame sampled before signal validation
- CompletionStatus set before data are durable
- 200msCompletionStatus set with incomplete 200 ms data
- CompletionStatus remains zero even though the complete record is stored
- Reset produces mixed old and new event data
- Diagnostic read interferes with recording
- Reserved bytes are not 0xFF
- Variant without SRSU records a side event
- Variant filtering suppresses valid front crash behavior
- Unconfirmed crash becomes confirmed due to stale FRSU data
- Parallel events are incorrectly counted as separate multi-events
- Separate events are incorrectly merged
- Exact-boundary behavior differs between software builds

## 14. Automation and stress generation

Provide pseudocode for a property-based event-sequence generator.

The generator shall vary:

- Event count
- Event classification
- Deployment status
- Lock status
- Front or side source
- T0 source
- Inter-event timing
- CAN validity
- Signal values
- Power-cut timing
- Reset timing
- Diagnostic-read timing
- ECU variant
- Initial record-slot state

Define invariants that must always remain true, including:

- A locked record is never modified unless an explicit requirement permits it.
- A completed valid record remains identical across power cycles.
- No valid record contains mixed content from two different events.
- Counters are monotonic unless defined rollover behavior applies.
- TimeBetweenEvents corresponds to the correct pair of T0 values.
- CompletionStatus cannot indicate more valid data than were durably stored.
- 200msCompletionStatus cannot be 1 if any mandatory data within the 200 ms interval are missing.
- Default empty bytes and reserved bytes remain 0xFF.
- A near crash does not assert STS_CRASH or DOOR_UNLOCK.
- Variant restrictions do not contaminate unrelated functionality.

Recommend sequence minimization so that when a randomized test fails, the event sequence is reduced to the smallest reproducible sequence.

## 15. Final prioritization

Classify tests as:

- P0: Possible loss or corruption of deployment crash data
- P1: Wrong lock, overwrite, completion or event-association behavior
- P2: Incorrect CAN data, diagnostic data or variant behavior
- P3: Robustness, endurance and low-likelihood combinations

Finish with:

1. Top 25 highest-defect-yield tests
2. Minimum regression suite
3. Full qualification suite
4. Long-duration endurance suite
5. Open technical questions that block a conclusive test oracle
6. Recommended instrumentation and automation architecture

Before finalizing, perform a self-review and confirm that the design covers nominal, negative, boundary, power-loss, CAN-wake-up, battery-cutoff, multi-event, fourth/fifth-event, diagnostic, variant, persistence, robustness and endurance scenarios.