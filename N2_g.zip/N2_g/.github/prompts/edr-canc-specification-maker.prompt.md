---
name: "EDR CAN-C Specification Maker"
description: "Create an evidence-backed EDR CAN-C test specification for DIDs 0x0455 and 0x045B."
argument-hint: "Variant, EDR workbook, variant configuration, DBC, Veoneer template, and output path"
agent: "agent"
---

Create an Automotive EDR CAN Test Specification for the supplied Mahindra ICE vehicle variant.
Cover DID `0x0455` (Record 1) and DID `0x045B` (Record 2).

Treat the arguments as the variant name and paths to these required sources:

1. EDR requirement/specification workbook
2. Variant configuration data
3. Variant DBC
4. Approved Veoneer template and desired output path, when a workbook is requested

If any required source, revision, or output choice is missing, list it in **Data Gaps** and do
not invent its contents. Do not access the bench, run a test script, alter a controlled
requirement source, or claim execution results.

Before starting, open and follow the repository guidance in
[copilot-instructions](../copilot-instructions.md), the EDR and test-authoring rules in
[agent_sc3](../agents/agent_sc3.md), and the
[Veoneer test-specification workflow](../skills/veoneer-test-spec-generator/SKILL.md).
Use the capability-first source-ingestion policy: inspect available Python packages, select the
highest-fidelity parser(s), preserve structure and provenance, use fallback parsers when quality
checks show loss, and state the selected libraries and rationale in the final evidence report.

## Evidence and Source Precedence

Treat sources in this order of authority:

1. The EDR requirement/specification workbook controls EDR element mapping, record layout,
   field width, DID applicability, sample count, sample period, recording interval, crash
   trigger, qualification logic, fault fallback behavior, and required stored values.
2. Variant configuration controls whether an element is enabled, deconfigured, reserved, or not
   applicable.
3. The variant DBC controls only CAN message/signal definitions: sender ECU, CAN ID, cycle time,
   multiplexing, start bit, bit length, byte order, signedness, factor, offset, physical range,
   enumerations, and explicitly defined invalid, reserved, or default values.

Never infer a missing value. Use `Not specified`, cite the missing evidence, and add it to the
Data Gaps table. Do not treat a numerical ID as approved traceability unless it is verified in
the correct variant tracker with the required approval status. Preserve source provenance at the
workbook sheet/row/cell, DBC message/signal, and configuration-key level.

## Mandatory Investigation

Before drafting any test case, build an **Investigation and Coverage Matrix** with one row per
EDR CAN element and applicable DID/record. Include:

| EDR element | DID / record | EDR field location / width | Configuration status | DBC message / signal presence | CAN ID / sender / cycle / multiplexing | Signal encoding and range | Sampling / trigger evidence | Requirement traceability | Coverage decision |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

For every row, verify and report the EDR element name; field location and width; DBC message and
signal presence; CAN ID; sender ECU; cycle time; multiplexing; bit length; byte order;
signedness; factor; offset; physical min/max; enumerations; invalid/reserved/default values;
sample count; sample period; recording interval; crash/trigger reference; exact requirement ID;
and workbook source reference. Mark absent evidence as `Not specified` rather than completing it
from a similarly named variant or signal.

Classify each element using only evidence:

- **Applicable**: explicitly enabled and present in the DBC.
- **Deconfigured**: explicitly disabled for the variant.
- **Reserved**: reserved EDR field or reserved bits.
- **Not Present**: message or signal is absent from the variant DBC.

Apply stored-value precedence exactly:

1. Reserved bits/fields record `0`, at the applicable field width.
2. Deconfigured fields record all ones at the applicable field width, such as `0xFF` or
   `0xFFFF`, only when the EDR requirement says so.
3. Not Present fields use the EDR requirement's stated fallback. Do not classify them as
   deconfigured unless the configuration explicitly does so.
4. Applicable fields record according to the EDR requirement.

Create no functional CAN tests for Deconfigured, Reserved, or Not Present elements. Generate
only the required static encoding verification for those items.

## Test Design Rules

For every numeric point, show the padded CAN raw hexadecimal bit pattern, decoded raw integer,
factor, offset, physical value, and EDR stored encoding when it differs from CAN raw data. Use:

`physical_value = decoded_raw_value * factor + offset`

Apply DBC signedness, byte order, bit length, multiplexing, and encoding. For Boolean or
enumerated signals, test each DBC-defined valid state and source-supported transitions. Do not
invent min/mid/max, invalid, reserved, default, or out-of-range values.

Create separate traceable cases for each Applicable element and applicable record/DID, with IDs:

- `EDR-<VARIANT>-R1-<ELEMENT>-<CATEGORY>-<NNN>` for DID `0x0455`
- `EDR-<VARIANT>-R2-<ELEMENT>-<CATEGORY>-<NNN>` for DID `0x045B`

For Applicable numeric signals, include only source-supported cases for:

1. Normal minimum, maximum, valid boundaries, midpoint, and dynamic sequence.
2. Every configured sample and the complete sample window.
3. Earliest, intermediate, and final pre-crash samples when an explicit pre-crash interval exists.
4. First, intermediate, and final post-crash samples when an explicit post-crash interval exists.
5. Node/message loss and CAN communication failure only when an explicitly applicable fault
   reaction exists.
6. DBC/requirement-defined injectible reserved codes; always verify EDR reserved bits as zero.
7. Encodable, explicitly defined invalid or out-of-range values.
8. Record 1/Record 2 consistency only when the requirement explicitly requires matching values.

For ignition-cycle qualification/dequalification signals, generate timing tests only from the
requirement logic; do not create pre-crash or post-crash cases. For signals with no
recording-interval information, create static recording verification only. Do not derive a sample
count from interval and period when the requirement supplies a different count; report the
conflict.

Every timing test must contain a table of every sample index, target timestamp, injected
raw/physical value, and expected stored value. Keep T0-relative EDR sequences free of sleeps.

## Required Deliverables

Generate the following in priority/risk order, using the Veoneer structure when a validated
template is supplied:

1. **Investigation and Coverage Matrix** as defined above.
2. **Data Gaps, Assumptions, and Excluded-Test Rationale**, including unavailable source data,
   unapproved traceability, source conflicts, and every intentionally excluded unsupported test.
3. **Detailed Veoneer-compatible test cases**. Each case must include the EDR element, DBC
   message/signal, presence status, factor, offset, physical min/max, recording interval, sample
   count, DID/record, unique ID, objective, preconditions, procedure, test data, expected result,
   priority, and exact requirement traceability. Use verified requirement IDs only; retain `TBD`
   and report the coverage gap when no approved ID exists.
4. **Final coverage summary** separated for Record 1 / DID `0x0455` and Record 2 / DID `0x045B`.
   State every element's classification, test coverage, excluded scenarios, open gaps, source
   conflicts, and confidence.
5. **Extraction and validation evidence**, naming the selected parsers and rationale, source
   revisions, completeness checks, extraction-quality results, and any limitations.

Run the Veoneer template/profile validation only when an approved template is provided. When no
template is supplied, deliver the structured test-case data and evidence report without claiming
workbook or Codebeamer-import validation.

## Quality Gate

Before finalizing, verify that every expected value is traceable to the EDR requirement or DBC;
every DBC claim exists in the selected variant DBC; every functional test is Applicable; every
static-only classification has a rationale; timing samples match the explicit requirement; and no
unsupported fault, pre/post-crash, range, or record-consistency test has been generated. Clearly
separate facts, inferences, and assumptions, and report contradictions rather than resolving them
silently.