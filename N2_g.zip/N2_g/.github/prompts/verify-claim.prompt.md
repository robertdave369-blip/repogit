---
name: 'verify-claim'
description: 'Check a value or statement against the actual artefacts before anyone relies on it'
agent: 'agent'
argument-hint: 'The value, mapping, or statement to verify'
---

Verify: ${input:claim:What should be checked?}

Treat this as adversarial. Your job is to try to **falsify** the claim, not to confirm it.
A confirmation you reached by looking for agreement is worth nothing here.

## Procedure

1. **Restate the claim precisely.** If it is ambiguous, resolve the ambiguity first — a
   vague claim cannot be falsified.

2. **Identify what would settle it.** Name the specific artefact and location: which DBC,
   which workbook sheet, which config key, which source line. If nothing in the repository
   could settle it, say so now and stop — the answer is "Evidence unavailable."

3. **Open it and read the actual content.** Not the filename, not a grep hit in isolation,
   not your memory of it. For a workbook, read the sheet properly with `openpyxl`,
   resolving columns by header name.

4. **Look for the contradiction.** Check whether another artefact says something different —
   a second DBC, another project's config, the diagnostic spec, an existing test that
   asserts the opposite. Contradictions between sources are common here and are the most
   valuable thing you can find.

5. **Report.**

```
Claim:      <as restated>
Verdict:    Confirmed | Refuted | Evidence unavailable | Partly — <what holds, what does not>
Evidence:   <file>:<sheet/line> — <the actual content that settles it>
Type:       fact | inference (from what) | assumption
Confidence: Very High | High | Medium | Low
Conflicts:  <any source that disagrees, quoted> | none found
```

If refuted, give the correct value with its source. If confirmed against a real artefact,
cache it:

```
py -3 .github/hooks/scripts/cache.py fact "<claim>" --evidence "<source>"
```

Do not soften a refutation. If the value in use is wrong, say it is wrong and say what
depends on it.
