---
name: "Codebeamer Operations"
description: "Read, analyze, create, or update Codebeamer requirements, test cases, trackers, and traceability through the guarded code-beamer skill."
argument-hint: "Action; Project ID; Tracker ID; Item ID or all; goal; optional change; approval state."
agent: "agent"
---
"""
Action: read | analyze | create | update | move
Target: requirement | test case | tracker
Project ID: <id or discover>
Tracker ID: <id or discover>
Item ID: <id | all | n/a>
Goal: <what to do>
Changes: <for create/update/move; otherwise n/a>
Evidence: <paths or IDs; otherwise n/a>
Apply: plan only | approve <plan-id>
"""
# Codebeamer Task

Before acting, load and follow the [code-beamer skill](../skills/code-beamer/SKILL.md) and the repository rules in [agent_sc3.md](../agents/agent_sc3.md).

<!-- USER-CONFIGURABLE SETTINGS START -->
## Defaults To Edit

- Default remote mode: `read-only`.
- Missing ID behavior: `discover; never invent IDs`.
- Analysis output: `brief evidence, impact, gaps, confidence`.
- Write behavior: `plan only until exact plan ID is approved`.

Edit only this section to change defaults. Do not add credentials here.
<!-- USER-CONFIGURABLE SETTINGS END -->

## Request

```text
Action: read | analyze | create | update | move
Target: requirement | test case | tracker
Project ID: <id or discover>
Tracker ID: <id or discover>
Item ID: <id | all | n/a>
Goal: <what to read, analyze, create, or change>
Changes: <required for create/update/move; otherwise n/a>
Evidence: <local paths, Codebeamer IDs, or n/a>
Apply: plan only | approve <plan-id>
```

`Item ID: all` is valid for read or analysis of every item in the selected tracker. Updates are one item or tracker per plan; bulk changes are not supported.

For `read` or `analyze`, read only the requested records, schema, fields, and explicit relations; then report source-backed facts, impact, gaps, and confidence.

For `create`, `update`, or `move`, read the schema and current target, create a non-executing mutation plan, show its impact and ID, and stop. Apply only when the user explicitly approves that exact plan ID.

For `move`, specify the target item, destination sibling, relative position (`BEFORE`, `AFTER`,
or `BELOW`), and a complete current-item payload. Preserve all populated headers and fields,
including description, custom fields, and test-step tables; do not use a parent-only or partial
payload. Verify the target is immediately in the requested position and that content is unchanged
after applying the plan.

Never delete Codebeamer data, run a bulk change, alter workflow state, or run an importer through this prompt.