---
name: "EDR Record-Allocation Test Design"
description: "Create evidence-led EDR record-allocation and test-design outputs for the specified target."
argument-hint: "Provide target variant/release, approved requirements, EDR DID layout, and the requested test scope"
agent: "agent"
---

# EDR Record-Allocation Test Design

Create a read-only, evidence-led EDR record-allocation analysis or test-design
package for the supplied target. This prompt is derived from the target reference:

# EDR Record Logic: Parallel, Single, and Multi-Event Scenarios

## Purpose

This document is a source-faithful extraction of the EDR record expectations in
[EDR_Requirements.xlsx](./EDR_Requirements.xlsx), supplemented by the target-specific
clarifications supplied on 2026-09-01. It is intended as a decision reference when
creating EDR test cases; it is **not** an approved test specification and does not
assign Codebeamer requirement IDs.

The matrices below preserve the workbook's values for:

- EDR1 and EDR2 actual record contents;
- `Multi Event Number`;
- `TimeB/W_Events`;
- `Lifetime Event_number`;
- record-lock status; and
- `CompletionStatus` / `200ms CompletionStatus`;
- parallel-event record behavior; and
- the target crash-location/type bitfield.

## Source and extraction integrity

| Item | Verified fact |
|---|---|
| Primary source | [EDR_Requirements.xlsx](./EDR_Requirements.xlsx), worksheet `EDR_Requirements` |
| Workbook scope | One worksheet; 57 rows x 22 columns; 466 non-empty cells were read. |
| Extraction method | `openpyxl` was selected because it retains worksheet/cell coordinates and raw cell values, including embedded line breaks. The entire worksheet was enumerated in read-only mode with formulas preserved. |
| Cross-check | The extracted matrix was cross-checked with [EDR_Requirements.csv](./EDR_Requirements.csv). |
| Target-specific clarification | User-provided on 2026-09-01: multi-event timing is strictly `>500 ms` and `<5000 ms`; a crash within 500 ms is parallel; EDR2 is all `0xFF` for a parallel pair; and the crash-location/type bit order is defined below. |
| Test requirement IDs | Evidence unavailable. This workbook has `S.No`, `Topic`, and `Requirements` fields, but no Codebeamer ID, approval-status, project-release, or variant column. |

### Source locations

| Subject | Workbook cells |
|---|---|
| No-event default | `B5:E5` |
| Near-crash behavior | `B8:E8` |
| Completion-status timing | `B9:E10` |
| Single-event timing and matrix | `B13:V30` |
| Multi-event timing and matrix | `B32:V49` |
| Completion-status value matrix | `B51:E57` |
| Parallel-event rule and crash-location/type bit layout | User-provided clarification and attached Record 1 bit-order image, 2026-09-01 |

## Terms and notation

| Term | Source-backed meaning |
|---|---|
| `0` input | Near crash (non-deployment event). |
| `1` input | Deployment event. |
| Lock status `1` | Record locked. |
| Lock status `0` | Record not locked. |
| `E1`, `E2`, `E3` | Input Event 1, Input Event 2, Input Event 3. |
| `EDR1 / EDR2` | The two record locations shown by the workbook. |
| `delta_t` | Time between the relevant crashes. The workbook does not define the exact Event 3 timing reference. |
| `0xFFFF` | A value used by the workbook for `TimeB/W_Events`. Its semantic meaning is not defined in the workbook. Do not label it as "not applicable," "unknown," or any other meaning without additional evidence. |
| `0xFF` in parallel EDR2 | Every raw EDR2 byte is `0xFF`; this indicates the user-specified no-second-record result and must not be decoded as a valid crash-location/type bitfield. |

The workbook sometimes displays `Event2` and sometimes `Event 2`. This document
normalizes that presentation to `Event 2`; the record identity is unchanged.

## Timing classification

The target test expectation below applies the user clarification. It agrees with the
strict multi-event bounds in the supplied workbook and supersedes the conflicting
lower bound in the local knowledge base for this target.

| Scenario | Source wording / evidence | Applied target test expectation |
|---|---|---|
| Parallel crash | User: crash occurs "within 500ms"; multi-event begins strictly above 500 ms. | `delta_t <= 500 ms`: record the first crash only; EDR2 is all `0xFF`. Test exactly 500 ms as a boundary. |
| Multi event | Workbook: `time between events >500ms and <5sec`; user confirms this range. | `500 ms < delta_t < 5000 ms`, including `501 ms` through `800 ms`. |
| Single event | Workbook: `time between events more than 5s`. | `delta_t > 5000 ms`. |
| Exactly 5000 ms | Workbook does not classify it; the target multi-event rule is strictly `<5000 ms`, and the single-event rule is strictly `>5000 ms`. | **Unclassified; do not assert a pass/fail record result without clarification.** |

For the multi-event rows, the Event 2 and Event 3 input cells are also marked
`(less than 5sec)`. The workbook does not state whether the Event 3 interval is
measured from Event 1, Event 2, or another time reference. Treat that reference
definition as a test-design gap.

### Source conflict and applied target precedence

The local SC3 knowledge base, [agent_sc3.md](../.github/agents/agent_sc3.md),
states `800 ms < delta_T0 <= 5 s`, whereas the workbook and the user clarification
state `500 ms < delta_t < 5000 ms`.

| Interval | Workbook | Local knowledge base | Applied target expectation |
|---|---|---|---|
| 501 ms through 800 ms | Multi event | Not multi event | **Multi event.** Use the workbook multi-event allocation matrix. |
| Exactly 5000 ms | Neither single nor multi event | Multi event | Unclassified pending an approved target requirement. |

This document uses the user-confirmed workbook range for the requested target.
The conflict remains recorded so that it is not silently propagated to another
variant or release.

## Baseline and record-status rules

- With no EDR event recorded, the EDR DID response shall be `FF..`, including reserved bytes (`B5:E5`).
- A near crash is a crash that does not meet the deployable threshold. It is recorded but does **not** lock the record (`B8:E8`).
- The end-of-Event-3 lock columns explicitly encode `1 = Record Locked` and `0 = Record not Locked` (`U19:V20` and `U38:V39`).

## Parallel-event behavior: crash within 500 ms

This section is based on the user-provided target clarification; the supplied workbook
does not contain a parallel-event matrix.

| Observation point | Expected behavior | Evidence boundary |
|---|---|---|
| End of Event 1 | EDR1 records the first crash. The per-field values, lock status, and raw-byte layout at this point are not otherwise specified. | User confirms the first record is recorded; the workbook has no end-of-Event-1 matrix. |
| End of Event 2 when `delta_t <= 500 ms` | EDR1 retains the first crash record. EDR2 is **not recorded**: every EDR2 byte, including reserved bytes, is `0xFF`. | User-provided target clarification. |
| End of Event 3 after a parallel Event 1/Event 2 pair | **Evidence unavailable.** Do not apply a universal allocation rule until Event 3 timing is defined relative to the preceding events and a target record-allocation requirement is supplied. | Neither the workbook nor the user clarification defines this sequence. |

For this condition, inspect the full raw EDR2 response rather than only selected
decoded fields. `0xFF` is the expected no-second-record pattern; it is not evidence
that every crash-location/type bit is set.

## What is specified at each event end

| Observation point | Workbook coverage | Test expectation |
|---|---|---|
| End of Event 1 | No EDR1/EDR2 result columns or data rows are provided. | **Evidence unavailable.** Do not claim EDR contents, `Multi Event Number`, `TimeB/W_Events`, `Lifetime Event_number`, or lock status solely from this workbook. |
| End of Event 2: single or multi event | EDR1/EDR2 contents and the three requested number/time fields are provided for both timing classes. No end-of-Event-2 lock-status columns are present. | Use the common matrices below. Lock status at this observation point is **not specified** by the matrix. |
| End of Event 2: parallel event | No workbook row is provided. | EDR1 retains the first crash; every EDR2 byte is `0xFF`. Field-level values and lock status are not specified. |
| End of Event 3: single or multi event | EDR1/EDR2 contents, all requested fields, and EDR1/EDR2 lock status are provided for all eight input combinations in both timing classes. | Use the full row-level matrices below. |
| End of Event 3 after a parallel pair | No rule is provided. | **Evidence unavailable.** Do not infer allocation from the single/multi tables. |

## End of Event 2: common expected records

The workbook gives the same end-of-Event-2 result for every input combination `000` through `111` within each timing class.

| Timing class | EDR1 actual data | EDR2 actual data | Multi Event Number (EDR1 / EDR2) | TimeB/W_Events (EDR1 / EDR2) | Lifetime Event_number (EDR1 / EDR2) | Lock status |
|---|---|---|---|---|---|---|
| Single event, `delta_t > 5000 ms` | Event 1 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 2` | Not specified at end of Event 2 |
| Multi event, `500 ms < delta_t < 5000 ms` | Event 1 | Event 2 | `1 / 2` | `0xFFFF / <5s` | `1 / 2` | Not specified at end of Event 2 |
| Parallel event, `delta_t <= 500 ms` | First crash record | Every raw byte is `0xFF` | Not specified; EDR2 is not decoded | Not specified; EDR2 is not decoded | Not specified; EDR2 is not decoded | Not specified at end of Event 2 |

Sources: single-event rows `B23:V30`; multi-event rows `B42:V49`; parallel-event row is user-provided target clarification.

## End of Event 3: single-event expectations

**Timing precondition:** `delta_t > 5000 ms` ("time between events more than 5s").

| E1/E2/E3 inputs | EDR1 actual data | EDR2 actual data | Multi Event Number (EDR1 / EDR2) | TimeB/W_Events (EDR1 / EDR2) | Lifetime Event_number (EDR1 / EDR2) | Record Lock status (EDR1 / EDR2) |
|---|---|---|---|---|---|---|
| `0 / 0 / 0` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `0 / 0` |
| `0 / 0 / 1` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `1 / 0` |
| `0 / 1 / 0` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `0 / 1` |
| `0 / 1 / 1` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `1 / 1` |
| `1 / 0 / 0` | Event 1 | Event 3 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 3` | `1 / 0` |
| `1 / 0 / 1` | Event 1 | Event 3 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 3` | `1 / 1` |
| `1 / 1 / 0` | Event 1 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 2` | `1 / 1` |
| `1 / 1 / 1` | Event 1 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 2` | `1 / 1` |

Source: `B23:V30`.

## End of Event 3: multi-event expectations

**Timing precondition:** `500 ms < delta_t < 5000 ms`. The workbook additionally marks the Event 2 and Event 3 inputs as "less than 5sec."

| E1/E2/E3 inputs | EDR1 actual data | EDR2 actual data | Multi Event Number (EDR1 / EDR2) | TimeB/W_Events (EDR1 / EDR2) | Lifetime Event_number (EDR1 / EDR2) | Record Lock status (EDR1 / EDR2) |
|---|---|---|---|---|---|---|
| `0 / 0 / 0` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `0 / 0` |
| `0 / 0 / 1` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `1 / 0` |
| `0 / 1 / 0` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `0 / 1` |
| `0 / 1 / 1` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `1 / 1` |
| `1 / 0 / 0` | Event 1 | Event 3 | `1 / 3` | `0xFFFF / <5s` | `1 / 3` | `1 / 0` |
| `1 / 0 / 1` | Event 1 | Event 3 | `1 / 3` | `0xFFFF / <5s` | `1 / 3` | `1 / 1` |
| `1 / 1 / 0` | Event 1 | Event 2 | `1 / 2` | `0xFFFF / <5s` | `1 / 2` | `1 / 1` |
| `1 / 1 / 1` | Event 1 | Event 2 | `1 / 2` | `0xFFFF / <5s` | `1 / 2` | `1 / 1` |

Source: `B42:V49`.

## Record-selection logic visible in the matrices

The following are **derived patterns** from all eight rows in each end-of-Event-3 matrix. They explain the tables but do not replace the row-level expected values.

| Retained event history | End-of-Event-3 record selection | Evidence |
|---|---|---|
| `E1 = 0` | EDR1 contains Event 3; EDR2 contains Event 2. | Rows `000`, `001`, `010`, and `011` in both matrices. |
| `E1 = 1`, `E2 = 0` | EDR1 contains Event 1; EDR2 contains Event 3. | Rows `100` and `101` in both matrices. |
| `E1 = 1`, `E2 = 1` | EDR1 contains Event 1; EDR2 contains Event 2. | Rows `110` and `111` in both matrices. |
| Any record containing a near crash | Its end-of-Event-3 lock value is `0`. | Every retained near-crash record in the two matrices. |
| Any record containing a deployment event | Its end-of-Event-3 lock value is `1`. | Every retained deployment record in the two matrices. |

Additional source-derived observations:

- In the **single-event** matrix, `Multi Event Number` is always `1 / 1`, and `TimeB/W_Events` is always `0xFFFF / 0xFFFF`.
- In the **multi-event** matrix, Event 2 initially has multi-event number `2`. At the end of Event 3, an overwritten record takes the displayed event number: `3 / 2`, `1 / 3`, or `1 / 2`, depending on the retained records.
- In every end-of-Event-3 row, `Lifetime Event_number` identifies the event stored in the corresponding EDR location.

## Crash location/type byte: target bitfield

The user clarification defines a composable bitfield for the crash location/type byte. The supplied image names these entries as **Record 1** fields. Therefore, the layout below is evidenced for Record 1; its application to EDR2 or another DID must be confirmed from the target's DID layout before a test asserts it.

| Bit position | Mask | Decimal value | Record 1 crash type/location |
|---:|---:|---:|---|
| 0 | `0x01` | 1 | Front crash |
| 1 | `0x02` | 2 | Left Side crash |
| 2 | `0x04` | 4 | Right Side crash |
| 3 | `0x08` | 8 | Rear crash |
| 4 | `0x10` | 16 | Understrike crash |
| 5 | `0x20` | 32 | Rollover crash |
| 6 | `0x40` | 64 | Near crash |
| 7 | `0x80` | 128 | Unspecified; do not assign a meaning. |

### Encoding rule

Set the bit for every applicable crash type/location and combine the masks using bitwise OR:

```text
crash_location_or_type_byte = OR(1 << bit_position for each applicable type)
```

| Applicable crash types/locations | Calculation | Expected byte |
|---|---|---|
| Front | `0x01` | `0x01` (decimal 1) |
| Left Side | `0x02` | `0x02` (decimal 2) |
| Front + Left Side | `0x01 OR 0x02` | `0x03` (decimal 3) |
| All seven supplied type bits | `0x01 OR 0x02 OR 0x04 OR 0x08 OR 0x10 OR 0x20 OR 0x40` | `0x7F` (decimal 127) |

The Front + Left Side result (`0x03`, decimal 3) is the user-provided example. The final row demonstrates bit arithmetic only; it does **not** establish that all seven crash types can occur together or that every mathematical mask is a valid physical scenario. Use only supported crash combinations in executable tests.

The workbook does not define the field offset, field name (`Crash Location` versus `Crash Type`), byte order, unused-bit handling, or this bitfield itself. Obtain those details from the target DID/record definition before decoding a raw response.

## Completion-status expectations

### Timing behavior

| Field | Workbook expectation |
|---|---|
| `CompletionStatus` | Updated to `1` after 5 seconds from T0 if battery is available. |
| `200ms CompletionStatus` | Updated to `1` after 200 milliseconds. When set, data for the first 200 ms from T0 is valid. |

Source: `B9:E10`.

### Value combinations

| CompletionStatus | 200ms CompletionStatus | Expected data validity | Applicability stated by workbook |
|---|---|---|---|
| `0` | `0` | EDR data not valid | Battery-cutoff crash |
| `0` | `1` | EDR data valid up to 200 ms | Not further qualified |
| `1` | `don't care` | EDR data valid | No battery-cutoff crash |

Source: `B51:E57`. The workbook states that the 200 ms parameter was newly added to provide EDR-data status for a battery-cutoff crash.

## Test-design handoff

Use the decision tables above as parameter data, not as a substitute for requirement traceability or bench evidence.

| Test objective | Minimum data-driven coverage | Expected-result source |
|---|---|---|
| Verify the no-event baseline | No EDR event; read the applicable EDR DID(s). | `FF..` response, `B5:E5`. |
| Verify parallel-record suppression | Trigger Event 2 within 500 ms of Event 1. Verify EDR1 retains the first crash and verify **every EDR2 response byte** is `0xFF`, including reserved bytes. | User-provided parallel-event rule. |
| Verify end-of-Event-2 record allocation | Exercise the standard single-event (`>5000 ms`) and multi-event (`501-4999 ms`) input tuples, or justify a smaller parameterized equivalence set because the end-of-Event-2 values are identical within each timing class. | End-of-Event-2 common table. |
| Verify end-of-Event-3 allocation and lock behavior | Exercise all eight input combinations (`000` through `111`) separately for the single and multi timing classes. | The two end-of-Event-3 matrices. |
| Verify timing classification | Capture the measured inter-event time and cover `500 ms` (parallel), `501 ms`, `800 ms`, `801 ms`, and `4999 ms` (multi), `5000 ms` (characterization only), and `5001 ms` (single). | Timing-classification table. |
| Verify crash-location/type bitfield | Verify each supplied one-bit mask and supported multi-location combinations. At minimum, verify Front + Left Side is `0x03` / decimal 3. Do not treat `0xFF` from a parallel EDR2 as a valid bitfield. | User-provided bitfield layout and encoding rule. |
| Verify data-validity status | Cover battery available and battery-cutoff conditions, observing the 200 ms and 5 s status transitions where the bench and approved procedure permit. | Completion-status tables. |
| Verify end-of-Event-1 and end-of-Event-2 lock status | Do not mark pass/fail against an invented value. Raise a requirement clarification or obtain a source that explicitly defines those observations. | Evidence unavailable / not specified. |

Before creating a formal test case, obtain the correct target-variant EDR tracker row and approved requirement ID. This workbook alone cannot supply that traceability.

## Open items that must not be guessed

1. **End of Event 1 record expectation:** Evidence unavailable.
2. **End of Event 2 lock-status expectation:** Not specified by the workbook matrix.
3. **Meaning of `0xFFFF` in `TimeB/W_Events`:** Evidence unavailable.
4. **Timing at exactly 5000 ms:** It is neither multi event (`<5000 ms`) nor single event (`>5000 ms`) under the applied target rule.
5. **Event 3 timing reference:** The workbook does not state whether its time is relative to Event 1, Event 2, or another T0.
6. **End-of-Event-3 behavior after a parallel pair:** Evidence unavailable.
7. **Multi-event source conflict:** The workbook and user clarification use `>500 ms`; the local SC3 knowledge base uses `>800 ms`. The applied target rule is documented above, but source reconciliation is still needed for reuse across variants.
8. **Crash-location/type bitfield layout details:** The target DID/record byte offset, exact field name, EDR2 applicability, byte order, and bit 7 behavior are unavailable.
9. **Physical validity of composite crash masks:** The encoding is defined, but the source does not approve every mathematical combination as a real crash scenario.
10. **Approved requirement IDs and target variant/release:** Evidence unavailable in the supplied workbook.

## Confidence and intended use

| Conclusion | Confidence | Basis |
|---|---|---|
| Cell values and both record matrices | Very High | Complete worksheet extraction plus CSV cross-check. |
| End-of-Event-3 record-selection and lock patterns | High | Repeated consistently across all eight source rows in each timing class. |
| Target timing classification and parallel-record behavior | High | Direct user-provided clarification; a formal target requirement ID/status is unavailable. |
| Record 1 crash-location/type bit order and Front + Left Side = 3 | High | Direct user-provided clarification plus supplied Record 1 bit-order image; the workbook does not define the field. |
| `0xFFFF` semantics, Event 3 timing reference, Event 1 field values, Event 2 lock state, and post-parallel Event 3 behavior | Unknown | The supplied evidence does not define them. |
| Classification at exactly 5000 ms | Unknown | It is excluded by the strict target multi/single wording, and the local SC3 knowledge base conflicts. |

No bench, ECU, or hardware operation was performed to produce this reference.


Use the embedded target rules below when no newer, approved target evidence
contradicts them. Treat the supplied target requirements as read-only. Do not operate
the ECU, bench, power supplies, fault-injection equipment, deployment outputs, or
other hardware unless the user explicitly authorizes execution.

## Required engineering discipline

Before producing an analysis, test design, test case, script, or specification:

1. Load and follow [copilot-instructions.md](../copilot-instructions.md) and
   [agent_sc3.md](../agents/agent_sc3.md).
2. When asked to create a Veoneer specification, test cases, or a Codebeamer import,
   load [veoneer-test-spec-generator/SKILL.md](../skills/veoneer-test-spec-generator/SKILL.md).
3. Separate **verified fact**, **user-provided target rule**, **derived pattern**,
   **assumption**, and **TBC** in the output.
4. Give every conclusion a source/provenance reference and confidence level.
5. Do not invent requirement IDs, approval status, variant applicability, DID number,
   field name, field offset, field width, byte order, record layout, timing reference,
   DTC, UDS request, NVM behavior, or test oracle.
6. Use `TBC: requirement clarification required` for an unsupported expected result.
   Never mark a TBC result as pass or fail.
7. Do not generalize a three-event matrix to Event 4, Event 5, or Event N without a
   target requirement defining that behavior.
8. When source rules conflict, report the conflict and the applied target precedence;
   never silently substitute a rule from another target or release.
9. Do not decode an all-`0xFF` EDR2 parallel-event response as a valid crash-location
   or crash-type bitfield.

## Scope and required output

Use this prompt for EDR record-slot allocation, multi-event classification, parallel
event behavior, lock behavior, `Multi Event Number`, `TimeB/W_Events`,
`Lifetime Event_number`, `CompletionStatus`, `200ms CompletionStatus`, and the
Record 1 crash-location/type bitfield.

Return, in this order:

1. **Evidence and source-precedence table**, including target variant/release and
   approved requirement ID/status when supplied.
2. **Facts, user-provided target rules, derived patterns, and TBC items**, clearly
   separated.
3. **Timing decision table**, including the prescribed boundary values.
4. **End-of-Event record-allocation expectations** using the exact matrices below.
5. **Focused, priority-ordered test objectives** with measurable pass criteria,
   needed evidence, and requirement traceability.
6. **Coverage matrix** for timing, event type, record slot, lock state, data validity,
   and crash-location/type bits.
7. **Ambiguity, contradiction, and residual-risk register**, including the required
   clarification questions.

When formal test cases are requested, use the repository's prescribed Veoneer format,
map only verified approved requirement IDs, and place safety/data-integrity critical
tests first. Do not create an executable test script unless the user explicitly
requests one and all framework/configuration evidence is available.

## Evidence and source precedence

Apply evidence in this order for this target:

1. Approved target-specific requirement/tracker and DID/record-layout evidence,
   when supplied.
2. The target record-logic reference identified at the start of this prompt:
   - complete `EDR_Requirements.xlsx` extraction;
   - user-provided timing/parallel-event clarification; and
   - user-provided Record 1 crash-location/type bit order.
3. Target variant configuration and target DBC for applicability, field encoding, and
   signal definitions only.
4. Generic knowledge-base behavior only when it does not conflict with target-specific
   evidence.

The local knowledge base contains a conflicting multi-event lower threshold
(`800 ms < delta_T0 <= 5 s`). For this target, use the confirmed rule
`500 ms < delta_t < 5000 ms`, including the `501-800 ms` interval. Preserve the
conflict in the ambiguity/contradiction register; do not propagate this target
precedence to another variant or release.

## Definitions

| Term | Target meaning |
|---|---|
| `E1`, `E2`, `E3` | Input Event 1, Input Event 2, and Input Event 3. |
| Input `0` | Near crash (non-deployment event). |
| Input `1` | Deployment event. |
| EDR1 / EDR2 | The two physical EDR record locations shown by the source matrix. |
| Lock `1` | Record locked. |
| Lock `0` | Record not locked. |
| `delta_t` | Time between relevant crashes. The exact Event 3 timing reference is not defined by the source. |
| `0xFFFF` | Source value for `TimeB/W_Events`; do not assign a semantic meaning without additional evidence. |
| `0xFF` parallel EDR2 | Every raw EDR2 byte is `0xFF`, including reserved bytes. This is the no-second-record pattern, not a crash-location/type mask. |

## Target timing classification and parallel-event behavior

| Classification | Applied target rule | Required record expectation |
|---|---|---|
| Parallel event | `delta_t <= 500 ms` | Record only the first crash in EDR1. EDR2 is not recorded: **every raw EDR2 byte, including reserved bytes, is `0xFF`**. |
| Multi event | `500 ms < delta_t < 5000 ms` | Apply the multi-event matrices. This explicitly includes `501 ms` through `800 ms`. |
| Single event | `delta_t > 5000 ms` | Apply the single-event matrices. |
| Exactly `5000 ms` | Neither the strict multi-event nor strict single-event target wording classifies it. | `TBC: requirement clarification required`; do not assert allocation, counters, or lock behavior. |

Use the following minimum timing points when a boundary test is requested:

| Time between events | Required classification |
|---:|---|
| `500 ms` | Parallel event |
| `501 ms` | Multi event |
| `800 ms` | Multi event |
| `801 ms` | Multi event |
| `4999 ms` | Multi event |
| `5000 ms` | TBC / characterization only |
| `5001 ms` | Single event |

For parallel Event 1/Event 2 pairs:

| Observation point | Expected result |
|---|---|
| End of Event 1 | EDR1 records the first crash. Per-field values, lock state, and raw-byte layout at this observation point are not otherwise specified. |
| End of Event 2, `delta_t <= 500 ms` | EDR1 retains the first crash. EDR2 is all `0xFF` bytes, including reserved bytes. |
| End of Event 3 after a parallel pair | `TBC: requirement clarification required`. Do not infer this allocation from the single/multi matrices. |

## Baseline and record-lock behavior

- With no EDR event recorded, the EDR DID response is all `0xFF`, including reserved
  bytes.
- A near crash is recorded but does not lock its retained record.
- A retained deployment record is locked.
- The provided lock data apply to the end-of-Event-3 rows below.
- End-of-Event-2 lock behavior is not specified by the source matrix. Keep it TBC
  unless target evidence is supplied.

## End-of-Event-2 allocation expectations

The single and multi matrices have the same end-of-Event-2 record result for every
input tuple shown by the source. Do not infer end-of-Event-2 lock status.

| Timing class | EDR1 actual data | EDR2 actual data | Multi Event Number (EDR1 / EDR2) | TimeB/W_Events (EDR1 / EDR2) | Lifetime Event_number (EDR1 / EDR2) | Lock status |
|---|---|---|---|---|---|---|
| Single, `delta_t > 5000 ms` | Event 1 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 2` | TBC |
| Multi, `500 ms < delta_t < 5000 ms` | Event 1 | Event 2 | `1 / 2` | `0xFFFF / <5s` | `1 / 2` | TBC |
| Parallel, `delta_t <= 500 ms` | First crash record | Every raw byte is `0xFF` | TBC; EDR2 is not decoded | TBC; EDR2 is not decoded | TBC; EDR2 is not decoded | TBC |

## End-of-Event-3 single-event matrix

**Timing precondition:** `delta_t > 5000 ms`.

| E1/E2/E3 inputs | EDR1 actual data | EDR2 actual data | Multi Event Number (EDR1 / EDR2) | TimeB/W_Events (EDR1 / EDR2) | Lifetime Event_number (EDR1 / EDR2) | Record Lock status (EDR1 / EDR2) |
|---|---|---|---|---|---|---|
| `0 / 0 / 0` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `0 / 0` |
| `0 / 0 / 1` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `1 / 0` |
| `0 / 1 / 0` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `0 / 1` |
| `0 / 1 / 1` | Event 3 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `3 / 2` | `1 / 1` |
| `1 / 0 / 0` | Event 1 | Event 3 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 3` | `1 / 0` |
| `1 / 0 / 1` | Event 1 | Event 3 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 3` | `1 / 1` |
| `1 / 1 / 0` | Event 1 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 2` | `1 / 1` |
| `1 / 1 / 1` | Event 1 | Event 2 | `1 / 1` | `0xFFFF / 0xFFFF` | `1 / 2` | `1 / 1` |

## End-of-Event-3 multi-event matrix

**Timing precondition:** `500 ms < delta_t < 5000 ms`.

| E1/E2/E3 inputs | EDR1 actual data | EDR2 actual data | Multi Event Number (EDR1 / EDR2) | TimeB/W_Events (EDR1 / EDR2) | Lifetime Event_number (EDR1 / EDR2) | Record Lock status (EDR1 / EDR2) |
|---|---|---|---|---|---|---|
| `0 / 0 / 0` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `0 / 0` |
| `0 / 0 / 1` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `1 / 0` |
| `0 / 1 / 0` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `0 / 1` |
| `0 / 1 / 1` | Event 3 | Event 2 | `3 / 2` | `<5s / <5s` | `3 / 2` | `1 / 1` |
| `1 / 0 / 0` | Event 1 | Event 3 | `1 / 3` | `0xFFFF / <5s` | `1 / 3` | `1 / 0` |
| `1 / 0 / 1` | Event 1 | Event 3 | `1 / 3` | `0xFFFF / <5s` | `1 / 3` | `1 / 1` |
| `1 / 1 / 0` | Event 1 | Event 2 | `1 / 2` | `0xFFFF / <5s` | `1 / 2` | `1 / 1` |
| `1 / 1 / 1` | Event 1 | Event 2 | `1 / 2` | `0xFFFF / <5s` | `1 / 2` | `1 / 1` |

## Derived record-selection patterns

Treat the following as derived patterns from the End-of-Event-3 matrices, not as
substitutes for the individual rows:

| Retained event history | End-of-Event-3 allocation |
|---|---|
| `E1 = 0` | EDR1 = Event 3; EDR2 = Event 2. |
| `E1 = 1`, `E2 = 0` | EDR1 = Event 1; EDR2 = Event 3. |
| `E1 = 1`, `E2 = 1` | EDR1 = Event 1; EDR2 = Event 2. |
| Retained near-crash record | Lock value is `0`. |
| Retained deployment record | Lock value is `1`. |

Do not use these patterns to infer results for a fourth event, a prior parallel pair,
or a state with pre-existing record data beyond the matrix.

## Completion-status expectations

| Field | Target expectation |
|---|---|
| `CompletionStatus` | Becomes `1` five seconds after T0 when battery power is available. |
| `200ms CompletionStatus` | Becomes `1` after 200 ms; when set, EDR data through 200 ms from T0 are valid. |

| CompletionStatus | 200ms CompletionStatus | EDR data validity | Applicability |
|---|---|---|---|
| `0` | `0` | EDR data not valid | Battery-cutoff crash |
| `0` | `1` | EDR data valid up to 200 ms | Not further qualified by the source |
| `1` | `don't care` | EDR data valid | No battery-cutoff crash |

Do not infer record persistence, incomplete-write behavior, or a diagnostic read
sequence from these values alone.

## Record 1 crash-location/type bitfield

The following is a target-specific, user-provided bit order for the **Record 1**
crash-location/type byte. The evidence does not establish the field offset, exact
field name, byte order, application to EDR2, or bit 7 behavior.

| Bit position | Mask | Decimal value | Record 1 crash type/location |
|---:|---:|---:|---|
| 0 | `0x01` | 1 | Front crash |
| 1 | `0x02` | 2 | Left Side crash |
| 2 | `0x04` | 4 | Right Side crash |
| 3 | `0x08` | 8 | Rear crash |
| 4 | `0x10` | 16 | Understrike crash |
| 5 | `0x20` | 32 | Rollover crash |
| 6 | `0x40` | 64 | Near crash |
| 7 | `0x80` | 128 | TBC; do not assign a meaning. |

Encode supported simultaneous crash types/locations by bitwise OR:

```text
crash_location_or_type_byte = OR(1 << bit_position for each applicable type)
```

| Applicable crash types/locations | Calculation | Expected byte |
|---|---|---|
| Front | `0x01` | `0x01` (decimal 1) |
| Left Side | `0x02` | `0x02` (decimal 2) |
| Front + Left Side | `0x01 OR 0x02` | `0x03` (decimal 3) |

The Front + Left Side expectation is an explicit target example. Do not assume all
mathematical combinations are physically valid crash scenarios. Generate bitfield
tests only for individually supported types and physically supported combinations.

## Mandatory test objectives

Prioritize these objectives when they are in scope and evidence/configuration permits:

1. **P0 - Parallel record suppression:** At `delta_t <= 500 ms`, verify the first
   crash is retained in EDR1 and every returned EDR2 byte, including reserved bytes,
   is `0xFF`.
2. **P0 - Multi-event allocation:** At `501`, `800`, `801`, and `4999 ms`, verify
   the exact row-level multi-event allocation, counters, times, and end-of-Event-3
   lock values for each applicable E1/E2/E3 input combination.
3. **P0 - Single-event allocation:** At `5001 ms` and higher, verify the exact
   row-level single-event allocation, counters, times, and end-of-Event-3 lock values.
4. **P1 - Timing boundary characterization:** Verify `500 ms` as parallel; isolate
   exactly `5000 ms` as TBC/characterization without inventing an expected result.
5. **P1 - Crash-location/type encoding:** Verify each supported one-bit value and
   the Front + Left Side composite value `0x03` / decimal 3. Verify raw all-`0xFF`
   EDR2 is not decoded as a valid mask.
6. **P1 - Record status:** Verify the 200 ms and five-second completion-status
   expectations under battery-available and battery-cutoff conditions only if the
   target requirement and safe bench procedure support them.
7. **P1 - No-event baseline:** Verify all bytes, including reserved bytes, are
   `0xFF` when no EDR event is recorded.

For test cases, capture the measured timing, raw EDR1/EDR2 payload, decoded
field values only where the DID layout is verified, record lock bits, completion
status bits, configuration/variant identity, and the source requirement reference.

## Mandatory TBC and clarification register

Keep these items visible and unresolved unless approved target evidence is supplied:

| ID | Missing or conflicting behavior | Required clarification |
|---|---|---|
| TBC-EDR-001 | Exactly `5000 ms` is excluded by the strict target multi/single wording. | What classification, record allocation, counters, time values, and lock state apply at exactly 5000 ms? |
| TBC-EDR-002 | End-of-Event-3 allocation after a parallel E1/E2 pair is not defined. | What records, counters, time values, and lock states apply when Event 3 follows a `<=500 ms` parallel pair? |
| TBC-EDR-003 | Event 3 timing reference is unspecified. | Is Event 3 timing measured from Event 1 T0, Event 2 T0, Event 2 end, or another reference? |
| TBC-EDR-004 | End-of-Event-1 fields and End-of-Event-2 lock status are not fully defined. | What raw-record, field, and lock observations are expected at each intermediate event end? |
| TBC-EDR-005 | `0xFFFF` semantics are unspecified. | What does `0xFFFF` mean for `TimeB/W_Events`, and what field width/byte order applies? |
| TBC-EDR-006 | The target bitfield is evidenced for Record 1 only. | What DID, byte offset, field name, byte order, EDR2 applicability, and bit 7 behavior apply? |
| TBC-EDR-007 | A generic knowledge-base threshold conflicts with the target rule. | Confirm the target variant/release precedence for `>500 ms` versus `>800 ms`. |
| TBC-EDR-008 | Requirement IDs, approval status, target variant, and release are unavailable. | Supply the approved target EDR tracker rows and target configuration identity. |

## Quality gate

Before finalizing:

- Confirm every asserted matrix value matches the embedded row-level source data.
- Confirm `501-800 ms` is classified as multi-event for this target.
- Confirm parallel EDR2 is checked as **all raw bytes `0xFF`**, not merely selected
  fields and not a decoded crash-location/type value.
- Confirm Front + Left Side encodes to `0x03` / decimal 3 and bit 7 is not assigned
  a speculative meaning.
- Confirm every generated test case has a verified requirement reference or is
  explicitly marked `TBD` with an associated clarification gap.
- Confirm no expected result was invented for exactly `5000 ms`, Event 3 after a
  parallel pair, unknown field offsets, unknown byte order, unknown EDR2 bitfield
  applicability, or Event 4/N behavior.
- Confirm no bench hardware was operated unless explicitly authorized.
