---
name: "Automotive CAN Log Investigator"
description: "Analyze automotive CAN and ISO-TP captures, extract arbitrary UDS DID data, export frames, inspect flow control or timing, decode DBC positions, or convert BLF and text logs."
argument-hint: "Goal, log path, CAN ID/DID, ISO-TP route, DBC layout, timing comparison, filters, and output path"
agent: "agent"
---

Use the [Automotive CAN Log Analysis skill](../skills/automotive-can-log-analysis/SKILL.md) for the user's capture-analysis request. Work offline and preserve the original input log.

Interpret the user's request using this task template. Ask only for fields required by the selected operation that are missing.

```text
Goal: summary | search | export-frames | timing | isotp | extract-edr | extract-did | decode | decode-did | convert
Input log: <path>
Output: <new output path, if requested>
CAN ID: <hex, optional>
Byte pattern and byte offset: <for search, optional; ?? is a wildcard>
Channel/direction/time window: <optional filters>
Response ID and EDR DID: <for extract-edr; defaults are 0x738 and 0x0455>
Response ID and DID: <required for extract-did or decode-did>
DBC path and DBC message name: <required for decode-did; DBC message must represent the DID payload>
Compare ID, pairing rule, expected period: <for timing; pairing is next or nearest>
Data ID and Flow-Control ID: <for isotp; Flow-Control ID is optional but required for First-Frame-to-Flow-Control pairing>
Conversion format: asc | aria | csv | json
```

Choose the path that matches the goal:

1. `summary`: inventory messages, IDs, channels, directions, and timestamp range before making claims about traffic.
2. `search`: find a CAN ID and/or byte sequence. Report every match with timestamp, source line/frame, channel, direction, CAN ID, raw bytes, and match byte offset.
3. `export-frames`: export every filtered frame for one CAN ID to a new ASC, ARIA, CSV, or JSON file.
4. `timing`: report source-order inter-frame period, jitter, non-forward timestamp transitions, and optional timestamp differences to a second ID. State whether pairs use `next` or `nearest` matching.
5. `isotp`: inspect ISO-TP Single/First/Consecutive/Flow-Control frames. Report Flow-Control status, block size, STmin, source position, and the First-Frame-to-next-Flow-Control delay when both route IDs are supplied.
6. `extract-edr`: extract the specified positive `62 <DID high> <DID low>` response from raw ISO-TP traffic or already-expanded UDS rows. Show the UDS response and the EDR payload separately.
7. `extract-did`: extract any requested positive `62 <DID high> <DID low>` response. Require both response ID and DID instead of applying EDR defaults.
8. `decode`: decode selected normal CAN frames with the supplied DBC. For each signal, show physical value, raw value, start bit, bit length, byte order, signedness, factor, offset, unit, and the actual raw frame byte(s) that carry it.
9. `decode-did`: extract the requested DID and decode its payload against the explicitly named DBC payload layout. Show payload byte positions and original UDS response-byte positions. Do not use a normal CAN message definition unless it genuinely defines the DID payload.
10. `convert`: convert a supported BLF, ASC, ARIA, CSV, or JSON log to ASC, ARIA text, CSV, or JSON without overwriting the source.

Use the bundled script instead of manually parsing log text. Use exact values from the capture and supplied DBC; do not guess CAN IDs, DIDs, signal names, scaling, byte layout, or timestamp meaning.

For the final response, provide:

- Scope and exact source artefacts used.
- Command/output path and parser result.
- Observed findings with timestamp, source position, CAN ID, direction, and raw bytes.
- DBC-backed value descriptions with the signal's bit/byte position, when decoding is requested.
- Assumptions, parser limitations, conflicts, and missing evidence.

Example requests the user can make through this prompt:

- `Extract DID 0x0455 from C:\logs\crash.blf; response ID 0x738; write C:\logs\edr.txt.`
- `Search C:\logs\aria.log for RX ID 0x2C0 and 01 01 ?? at byte offset 4.`
- `Decode ID 0x2C0 in C:\logs\capture.txt using C:\dbc\variant.dbc and show each signal's raw bytes and physical value.`
- `Export all RX frames for ID 0x2C0 on channel 2 from C:\logs\capture.log to C:\logs\2c0.csv.`
- `Analyze the period of ID 0x2C0 against 20 ms and compare each 0x730 request to the next 0x738 response.`
- `Show the ISO-TP flow-control timeline for data ID 0x738 and flow-control ID 0x730, including block size, STmin, and First-Frame-to-Flow-Control timing.`
- `Extract DID 0xF190 from response ID 0x738 and decode its payload using message DID_Payload_Layout in C:\dbc\did-layout.dbc.`
- `Convert C:\logs\capture.blf to C:\logs\capture.asc and create a CSV copy.`