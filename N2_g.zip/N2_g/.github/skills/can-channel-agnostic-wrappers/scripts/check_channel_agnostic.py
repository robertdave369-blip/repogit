"""Check that CAN wrappers stay channel-agnostic.

Reports three problems, each with a line number:

  no-channel      A function that touches a CAN channel but accepts no channel argument,
                  so callers cannot target HSCAN vs CAN-FD.
  hardcoded-bus   A bus name literal ("HSCAN", "CANFD", ...) outside the resolver helpers
                  that are allowed to know them.
  raw-compare     A channel name compared without _normalize_channel_name, which misses
                  the spellings a rig actually uses ("HS CAN", "CANFDChannel", ...).

Exits non-zero when anything is found, so it can gate a commit.

Usage:
    python check_channel_agnostic.py shared_libraries/jscript_translation.py
    python check_channel_agnostic.py shared_libraries/
"""

from __future__ import annotations

import argparse
import ast
import sys
from pathlib import Path

BUS_LITERALS = {"HSCAN", "CANFD", "CAN_FD", "HS CAN", "HSCANBUS", "CANFDBUS", "Level 61"}

# Functions whose whole job is to know the bus names. They are the single place a literal
# belongs, so they are exempt from the hardcoded-bus check.
RESOLVER_FUNCTIONS = {
    "_normalize_channel_name",
    "_find_matching_channel_name",
    "_extract_optional_channel_arg",
    "_resolve_default_channel_name",
    "_resolve_default_normal_diag_channel_name",
    "_resolve_raw_can_channel_name",
    "_resolve_simulation_channel_id",
    "_resolve_diag_channel_id",
    "_resolve_level61_diag_channel_id",
    "_resolve_diag_bus_channel_name",
    "_resolve_diag_channel_name",
    "ensure_runtime",
    "runtime_status",
}

# Calls that mean "this function talks to a channel".
CHANNEL_CALLS = {
    "ChangeSignalValue",
    "GetSignalFromFrame",
    "PeriodicDisableFrame",
    "PeriodicEnableFrame",
    "ReloadDefaultPeriodicFrame",
    "DisableSignal",
    "EnableSignal",
    "SendDiagByValues",
    "SendFrame",
    "send_frame",
    "_resolve_simulation_channel_id",
    "_resolve_diag_channel_id",
    "_resolve_raw_can_channel_name",
}


def accepts_channel(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    names = [a.arg for a in node.args.args] + [a.arg for a in node.args.kwonlyargs]
    if any("channel" in name.lower() for name in names):
        return True
    # *args plus a call to the extractor is the accepted pattern for legacy call sites.
    if node.args.vararg is not None:
        for child in ast.walk(node):
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Name):
                if child.func.id == "_extract_optional_channel_arg":
                    return True
    return False


def touches_channel(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str | None:
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            name = None
            if isinstance(child.func, ast.Attribute):
                name = child.func.attr
            elif isinstance(child.func, ast.Name):
                name = child.func.id
            if name in CHANNEL_CALLS:
                return name
    return None


def check_file(path: Path) -> list[dict]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(text)
    except SyntaxError as error:
        return [
            {
                "kind": "parse-error",
                "line": error.lineno or 0,
                "detail": f"{path.name} does not parse: {error.msg}",
            }
        ]

    lines = text.splitlines()
    findings: list[dict] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        in_resolver = node.name in RESOLVER_FUNCTIONS

        call = touches_channel(node)
        if call and not accepts_channel(node) and not in_resolver:
            findings.append(
                {
                    "kind": "no-channel",
                    "line": node.lineno,
                    "detail": f"{node.name}() calls {call} but takes no channel argument",
                }
            )

        if in_resolver:
            continue

        # A name already put through the resolver is safe to compare against literals,
        # so lines that mention one are not hardcoding a bus.
        normalized_lines = {
            child.lineno
            for child in ast.walk(node)
            if isinstance(child, ast.Name) and child.id.startswith("normalized")
        }

        for child in ast.walk(node):
            if isinstance(child, ast.Constant) and isinstance(child.value, str):
                if child.lineno in normalized_lines:
                    continue
                if child.value.strip().upper().replace(" ", "") in {
                    literal.upper().replace(" ", "") for literal in BUS_LITERALS
                }:
                    findings.append(
                        {
                            "kind": "hardcoded-bus",
                            "line": child.lineno,
                            "detail": f"{node.name}() hardcodes bus name {child.value!r}",
                        }
                    )
            if isinstance(child, ast.Compare):
                left = child.left
                is_raw_name = isinstance(left, ast.Name) and "channel" in left.id.lower()
                normalized = (
                    isinstance(left, ast.Call)
                    and isinstance(left.func, ast.Name)
                    and left.func.id == "_normalize_channel_name"
                )
                compares_bus = any(
                    isinstance(c, ast.Constant)
                    and isinstance(c.value, str)
                    and c.value.strip().upper().replace(" ", "")
                    in {literal.upper().replace(" ", "") for literal in BUS_LITERALS}
                    for c in child.comparators
                )
                if is_raw_name and compares_bus and not normalized:
                    findings.append(
                        {
                            "kind": "raw-compare",
                            "line": child.lineno,
                            "detail": (
                                f"{node.name}() compares a channel name without "
                                "_normalize_channel_name"
                            ),
                        }
                    )

    for finding in findings:
        index = finding["line"] - 1
        finding["source"] = lines[index].strip()[:100] if 0 <= index < len(lines) else ""
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="+", type=Path, help="file or directory to check")
    parser.add_argument("--quiet", action="store_true", help="only print the summary")
    arguments = parser.parse_args()

    targets: list[Path] = []
    for entry in arguments.paths:
        if entry.is_dir():
            targets.extend(sorted(p for p in entry.rglob("*.py") if "__pycache__" not in p.parts))
        elif entry.is_file():
            targets.append(entry)
        else:
            print(f"Not found: {entry}", file=sys.stderr)
            return 2

    total = 0
    for path in targets:
        findings = check_file(path)
        if not findings:
            continue
        total += len(findings)
        if arguments.quiet:
            continue
        print(f"{path}")
        for finding in sorted(findings, key=lambda f: f["line"]):
            print(f"  {finding['line']:>5}  {finding['kind']:<14} {finding['detail']}")
            if finding.get("source"):
                print(f"         {finding['source']}")
        print()

    print(f"{len(targets)} file(s) checked, {total} finding(s).")
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
