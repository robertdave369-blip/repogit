---
name: can-channel-agnostic-wrappers
description: 'Use when writing or reviewing a shared-library wrapper that touches a CAN channel, so it works on HSCAN, CAN-FD, Level 61 and any project without edits. Covers the channel-resolution contract in jscript_translation, how to accept an optional channel argument, and how to avoid hardcoding a bus or project name.'
argument-hint: 'Name the wrapper you are adding, or the file to review'
user-invocable: true
disable-model-invocation: false
---

# Channel-agnostic CAN wrappers

## When to use

Use this skill whenever you add or change a function in `shared_libraries/` that sends,
receives, enables, disables or inspects anything on a CAN channel — and whenever you
review one. The goal is that a single wrapper runs unchanged on an HSCAN rig, a CAN-FD
rig, and any project, the way `CAN.SendDiagByValues()` already does.

Do not use it for reporting helpers (`RESULT`) or for pure data conversion, which have no
channel.

## The rule

**A wrapper never names a bus, a frame, or a project. It asks the resolver.**

Everything needed already exists in `shared_libraries/jscript_translation.py`:

| Helper | Line | Purpose |
|---|---|---|
| `_normalize_channel_name` | 89 | Folds `HSCAN` / `HS CAN` / `HSCANBUS` / `CANFD` / `CAN_FD` / `CANFDCHANNEL` onto one canonical name |
| `_find_matching_channel_name` | 117 | Matches a requested name against what the rig actually exposes |
| `_extract_optional_channel_arg` | 139 | Pulls an optional leading channel argument out of `*args` |
| `_resolve_default_channel_name` | 149 | Falls back through a preference list, skipping channels the rig lacks |
| `_resolve_raw_can_channel_name` | 162 | Channel name for raw frame work |
| `_resolve_simulation_channel_id` | 179 | Simulation channel id for signal writes |
| `_resolve_diag_channel_id` | 200 | Diagnostic channel id |
| `_resolve_level61_diag_channel_id` | 211 | Level 61 diagnostic channel id |

Canonical names are exactly `ARIA`, `CANFD`, `HSCAN`, `Level 61` — the names used in the
ARIA HIL setup. See the note at `jscript_translation.py:86`.

## Procedure

### 1. Accept the channel without breaking existing callers

Every existing call site omits the channel. Take it as an optional leading positional so
both forms work:

```python
@staticmethod
def MyNewWrapper(*args):
    channel_name, rest = _extract_optional_channel_arg(args, vehcSimulationChannels)
    frame, signal = rest
    simulation_id = _resolve_simulation_channel_id(channel_name)
    ...
```

`CAN.MyNewWrapper("EMS3_10", "STS_ENG")` and
`CAN.MyNewWrapper("CANFD", "EMS3_10", "STS_ENG")` both work, and the first picks the
rig's default channel.

For a diagnostic wrapper use `_resolve_diag_channel_id(channel_name)`, or
`_resolve_level61_diag_channel_id(channel_name)` behind a `level61=True` keyword.

### 2. Never hardcode a preference order in the wrapper

Wrong:

```python
channel = "CANFD" if project_is_ev else "HSCAN"          # project leaks into the library
channel = "HSCAN" if frame == "SRS1_20" else "CANFD"     # frame name leaks into the library
```

Right:

```python
channel = _resolve_default_channel_name(vehcSimulationChannels, "CANFD", "HSCAN", "ARIA")
```

The resolver returns the first name the rig actually exposes, so an HSCAN-only bench and a
CAN-FD bench both resolve correctly with no branch.

If a genuine project difference exists, it belongs in that project's config, read through
`_get_optional_project_config_symbol("CAN_FD_ENABLED", ("project_config",), False)` — not
as a literal in the library.

### 3. Resolve names, never compare them raw

Wrong:

```python
if channel_name == "HSCAN":
```

Right:

```python
if _normalize_channel_name(channel_name) == "HSCAN":
```

Rigs spell the same bus `HS CAN`, `HSCANBus`, `HSCAN_Channel`. Only the normalized form is
safe to compare.

### 4. Fail with the available channels named

When resolution fails, say what the rig offered. A bare `KeyError` costs someone a bench
session:

```python
resolved = _find_matching_channel_name(vehcSimulationChannels, channel_name)
if resolved is None:
    raise ValueError(
        f"Channel {channel_name!r} is not available. This rig exposes: "
        f"{', '.join(vehcSimulationChannels) or 'no simulation channels'}."
    )
```

### 5. Check it

```powershell
python .github/skills/can-channel-agnostic-wrappers/scripts/check_channel_agnostic.py shared_libraries/jscript_translation.py
python .github/skills/can-channel-agnostic-wrappers/scripts/check_channel_agnostic.py shared_libraries/
```

The checker reports three things per file: wrappers that touch a channel without accepting
one, hardcoded bus literals outside the resolver helpers, and raw channel-name comparisons
that skip normalization. It exits non-zero when it finds any, so it can gate a commit.

## Review checklist

- [ ] The wrapper takes an optional channel and still works when it is omitted.
- [ ] No `"HSCAN"` / `"CANFD"` literal outside the resolver helpers.
- [ ] Channel names are compared only after `_normalize_channel_name`.
- [ ] No project name, variant name or frame name decides the channel.
- [ ] Any project difference is read from that project's config, not from a library literal.
- [ ] The failure message lists the channels the rig actually exposes.
- [ ] The checker script passes.

## Current state

`CAN` is already fully compliant: all 25 methods accept a channel, which is why
`CAN.SendDiagByValues()` is portable today. The hardware classes are not — `PS` (16
methods), `SQUIB` (10), `RSU` (10 of 11), `ARIA` (9), `SPI` (5 of 6) and `RD` (3) take no
channel at all. Bring each one across as you touch it rather than in a single sweep, so
each change stays reviewable against a bench.

Two known hardcoded maps to migrate when convenient:
`core_functions.check_warning_lamp_status` (lines 2310–2325) and the frame-to-channel
branch at `core_functions.py:2851`.
