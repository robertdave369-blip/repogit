Attribute VB_Name = "CleanExportedWebTextImagesAndSymbols"
Sub CleanExportedWebTextImagesAndSymbols()
    Dim cell As Range
    Dim ws As Worksheet
    Dim s As String
    Dim pos As Long
    Dim reImg As Object
    Set ws = ActiveSheet
    Set reImg = CreateObject("VBScript.RegExp")

    reImg.Global = True
    reImg.IgnoreCase = True
    reImg.Pattern = "\[\![^\]]+\!\]" ' Matches [!....!]

    For Each cell In ws.UsedRange
        If Not IsEmpty(cell.Value) Then
            s = cell.Value
            ' Remove everything up to and including the last ')'
            pos = InStrRev(s, ")")
            If pos > 0 And pos < Len(s) Then
                s = Mid(s, pos + 1)
            End If
            ' Remove trailing %! if present
            If Right(s, 2) = "%!" Then
                s = Left(s, Len(s) - 2)
            End If
            ' Remove all [!....!] image tags
            s = reImg.Replace(s, "")
            ' Remove ~, \, and % symbols
            s = Replace(s, "~", "")
            s = Replace(s, "\", "")
            s = Replace(s, "%", "")
            s = Replace(s, "-", "")
            ' Trim spaces and line breaks
            s = Trim(s)
            cell.Value = s
        End If
    Next cell
End Sub