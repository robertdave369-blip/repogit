---
name: clean-exported-web-text-images-and-symbols
description: 'Use when cleaning exported web text, image tags, symbols, and formatting artefacts from an Excel worksheet with the CleanExportedWebTextImagesAndSymbols VBA macro. Applies the supplied active-sheet cleanup only after confirming scope, preserving an original workbook, and sampling before/after results.'
argument-hint: 'Describe the workbook, worksheet, sample cells, and whether the supplied destructive cleanup rules are intended'
user-invocable: true
disable-model-invocation: false
---

# Clean Exported Web Text, Images, And Symbols

## Purpose

Use this skill to prepare a copied Excel worksheet containing web-export artefacts for review or downstream processing. The bundled [VBA macro](./assets/CleanExportedWebTextImagesAndSymbols.bas) is named `CleanExportedWebTextImagesAndSymbols` and applies the user's supplied cleanup behavior to every non-empty cell in the **active sheet's used range**. Use the non-destructive [preview tool](./scripts/preview_clean_export.py) before any macro run.

## Exact Cleanup Behavior

For each non-empty cell, the macro:

1. Removes all text through the last `)` when that parenthesis is not the final character.
2. Removes a trailing `%!`.
3. Removes all tags matching `[! ... !]`.
4. Removes every `~`, `\`, `%`, and `-` character.
5. Trims leading/trailing spaces and line breaks.
6. Writes the result back to the cell value.

These rules are destructive. In particular, they can remove meaningful parenthetical context, negative signs, hyphenated identifiers, percentages, paths, Markdown-like content, formulas, and number formatting. The macro overwrites values and does not preserve formulas or formatting semantics after conversion to `cell.Value`.

## When To Use

Use only when the workbook is a disposable export/copy and the user confirms that the exact transformations above are wanted. Do not run this macro on the original requirement workbooks, any source under `req/`, signed/controlled records, or workbooks containing engineering identifiers, negative values, percentages, formulas, or hyphenated requirement tokens unless the user explicitly confirms the destructive behavior is acceptable.

For requirement analysis in this repository, use the non-destructive extraction/sanitization workflow instead: preserve engineering tokens and represent deleted content explicitly. This macro is an export-cleaning utility, not a requirements-preservation tool.

## Procedure

1. Confirm the workbook path, intended worksheet, target output copy, and that the active sheet is exactly the intended sheet. Save a backup before editing.
2. Run the read-only preview for the reviewed sheet. It creates a JSON diff, flags formulas, requirement-like IDs, engineering identifiers, negative signs, percentages, paths, and parenthetical context, and never modifies the workbook.

	 ```powershell
	 & "C:\Python3.13.0\python.exe" .github\skills\clean-exported-web-text-images-and-symbols\scripts\preview_clean_export.py `
		 "C:\Path\Export.xlsx" --sheet Export --report "C:\Path\Export.cleanup-preview.json"
	 ```

3. Inspect representative cells containing expected web/image artefacts and every high-risk preview flag. Confirm that stripping those characters and content is intended for this workbook. If not, stop and propose narrower cleanup rules.
4. Import the bundled `.bas` file into a macro-enabled copy of the workbook or paste the macro into the VBA editor. Keep the macro name unchanged.
5. Activate only the confirmed worksheet, run `CleanExportedWebTextImagesAndSymbols`, and save to a new output file. Do not overwrite the original.
6. Compare the preview with sampled before/after cells, check that unintended blanks or token loss did not occur, and record the workbook, sheet, macro version, preview report, samples, and output location.

## Decision Points

- **Wrong sheet active:** stop; the macro is active-sheet-only.
- **Formulas or structured data present:** stop unless conversion to values is explicitly intended.
- **Meaningful hyphens, percentages, paths, parenthetical text, or negative values found:** stop and request a narrower rule set.
- **Need to clean every worksheet:** do not loop automatically; require explicit per-sheet approval because the supplied macro is intentionally scoped to one active sheet.
- **Need reproducible batch cleanup:** use the preview tool with explicit `--sheet` values or reviewed `--all-sheets`, retain the diff reports, and obtain explicit approval before a separate apply mechanism is introduced. Do not silently repurpose the VBA macro for batch processing.

## Portfolio Handoff

For a multi-skill workflow, preserve the source-copy path/hash, explicit worksheet scope, preview-report path, high-risk cells, macro version, approval state, output copy path, and sampled before/after evidence. Do not hand cleaned text to `requirement-based-testing` as authoritative engineering evidence unless the destructive token loss has been explicitly accepted and documented.

## Completion Criteria

The cleanup is complete only when the original is preserved, the active-sheet scope was verified, a preview report was reviewed, the output is saved separately, sampled changes match the exact approved transformations, and any expected engineering-token loss is documented.