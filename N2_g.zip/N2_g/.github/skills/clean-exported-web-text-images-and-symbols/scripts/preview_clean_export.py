"""Read-only preview for the CleanExportedWebTextImagesAndSymbols VBA macro.

The script intentionally does not save or modify a workbook. It simulates the
macro's string transformations for explicitly selected worksheets and emits a
JSON diff with risk flags for review before any destructive macro run.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import openpyxl


IMAGE_TAG_PATTERN = re.compile(r"\[![^\]]+!\]")
REQUIREMENT_ID_PATTERN = re.compile(r"\b\d{6,}\b")
NEGATIVE_NUMBER_PATTERN = re.compile(r"(?<![A-Za-z0-9_])-\d")
ENGINEERING_TOKEN_PATTERN = re.compile(r"\b[A-Za-z][A-Za-z0-9_]*-[A-Za-z0-9_-]+\b")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def clean_value_like_vba(value: Any) -> tuple[Any, list[str]]:
    """Replicate the supplied macro's transformations without mutating a cell."""
    if not isinstance(value, str):
        return value, []
    original = value
    flags: list[str] = []
    last_parenthesis = value.rfind(")")
    if 0 <= last_parenthesis < len(value) - 1:
        value = value[last_parenthesis + 1:]
        flags.append("prefix_through_last_parenthesis_removed")
    if value.endswith("%!"):
        value = value[:-2]
        flags.append("trailing_percent_bang_removed")
    if IMAGE_TAG_PATTERN.search(value):
        value = IMAGE_TAG_PATTERN.sub("", value)
        flags.append("image_tag_removed")
    removed_characters = []
    for character, label in (("~", "tilde"), ("\\", "backslash"), ("%", "percent"), ("-", "hyphen")):
        if character in value:
            value = value.replace(character, "")
            removed_characters.append(label)
    if removed_characters:
        flags.append(f"characters_removed:{','.join(removed_characters)}")
    # VBA Trim removes leading/trailing spaces. It does not normalize internal whitespace.
    trimmed = value.strip(" ")
    if trimmed != value:
        flags.append("leading_or_trailing_spaces_removed")
    value = trimmed
    if value == original:
        flags.clear()
    return value, flags


def risk_flags(value: Any, *, is_formula: bool) -> list[str]:
    if not isinstance(value, str):
        return ["formula_cell" if is_formula else ""] if is_formula else []
    flags: list[str] = []
    if is_formula:
        flags.append("formula_cell")
    if REQUIREMENT_ID_PATTERN.search(value):
        flags.append("possible_requirement_or_tracker_id")
    if ENGINEERING_TOKEN_PATTERN.search(value):
        flags.append("possible_engineering_identifier")
    if NEGATIVE_NUMBER_PATTERN.search(value):
        flags.append("negative_number_sign")
    if "\\" in value or re.search(r"\b[A-Za-z]:\\", value):
        flags.append("path_or_escape_character")
    if "%" in value:
        flags.append("percent_or_percentage")
    if ")" in value:
        flags.append("parenthetical_context")
    return flags


def preview_workbook(
    workbook_path: str | Path,
    *,
    sheets: Iterable[str],
    max_changes: int = 1000,
) -> dict[str, Any]:
    source_path = Path(workbook_path).expanduser().resolve()
    if source_path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError("Only .xlsx and .xlsm workbooks are supported by the read-only preview.")
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    selected_sheets = list(dict.fromkeys(sheets))
    if not selected_sheets:
        raise ValueError("Select at least one worksheet; the VBA macro is active-sheet-only.")

    workbook = openpyxl.load_workbook(source_path, read_only=True, data_only=False, keep_vba=source_path.suffix.lower() == ".xlsm")
    try:
        missing_sheets = [sheet for sheet in selected_sheets if sheet not in workbook.sheetnames]
        if missing_sheets:
            raise ValueError(f"Worksheet(s) not found: {', '.join(missing_sheets)}")
        changes: list[dict[str, Any]] = []
        sheet_summaries = []
        total_changed = 0
        total_risky = 0
        for sheet_name in selected_sheets:
            worksheet = workbook[sheet_name]
            summary = {"sheet": sheet_name, "non_empty_cells": 0, "changed_cells": 0, "risky_cells": 0}
            for row in worksheet.iter_rows():
                for cell in row:
                    if cell.value is None:
                        continue
                    summary["non_empty_cells"] += 1
                    is_formula = cell.data_type == "f" or (isinstance(cell.value, str) and cell.value.startswith("="))
                    cleaned, transformation_flags = clean_value_like_vba(cell.value)
                    if cleaned == cell.value:
                        continue
                    flags = risk_flags(cell.value, is_formula=is_formula)
                    summary["changed_cells"] += 1
                    total_changed += 1
                    if flags:
                        summary["risky_cells"] += 1
                        total_risky += 1
                    if max_changes == 0 or len(changes) < max_changes:
                        changes.append(
                            {
                                "sheet": sheet_name,
                                "cell": cell.coordinate,
                                "original": cell.value,
                                "proposed": cleaned,
                                "transformation_flags": transformation_flags,
                                "risk_flags": flags,
                                "formula": is_formula,
                            }
                        )
            sheet_summaries.append(summary)
        return {
            "generated_at": _utc_now(),
            "operation": "CleanExportedWebTextImagesAndSymbols VBA-compatible preview",
            "source_workbook": str(source_path),
            "source_sha256": _sha256(source_path),
            "source_modified": False,
            "selected_sheets": selected_sheets,
            "max_changes": max_changes,
            "changes_truncated": max_changes != 0 and total_changed > len(changes),
            "changed_cells_total": total_changed,
            "risky_cells_total": total_risky,
            "sheets": sheet_summaries,
            "changes": changes,
            "approval_required_before_apply": True,
        }
    finally:
        workbook.close()


def write_preview_report(report: dict[str, Any], report_path: str | Path) -> Path:
    destination = Path(report_path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(destination)
    return destination


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate a non-destructive preview for the Excel cleanup VBA macro.")
    parser.add_argument("workbook", help="Source .xlsx or .xlsm workbook; it is never modified")
    scope = parser.add_mutually_exclusive_group(required=True)
    scope.add_argument("--sheet", action="append", help="Explicit worksheet to preview; repeat for multiple reviewed sheets")
    scope.add_argument("--all-sheets", action="store_true", help="Preview all worksheets; review the report before any macro use")
    parser.add_argument("--report", help="Output JSON report path; default: <workbook>.cleanup-preview.json")
    parser.add_argument("--max-changes", type=int, default=1000, help="Maximum per-cell changes in report; use 0 for all")
    return parser


def main() -> int:
    args = build_argument_parser().parse_args()
    if args.max_changes < 0:
        raise SystemExit("--max-changes must be zero or greater")
    workbook_path = Path(args.workbook).expanduser().resolve()
    if args.all_sheets:
        workbook = openpyxl.load_workbook(workbook_path, read_only=True, data_only=False, keep_vba=workbook_path.suffix.lower() == ".xlsm")
        try:
            sheets = list(workbook.sheetnames)
        finally:
            workbook.close()
    else:
        sheets = args.sheet
    report = preview_workbook(workbook_path, sheets=sheets, max_changes=args.max_changes)
    report_path = Path(args.report).expanduser() if args.report else workbook_path.with_suffix(workbook_path.suffix + ".cleanup-preview.json")
    destination = write_preview_report(report, report_path)
    print(json.dumps({"report": str(destination), "changed_cells": report["changed_cells_total"], "risky_cells": report["risky_cells_total"], "source_modified": False}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())