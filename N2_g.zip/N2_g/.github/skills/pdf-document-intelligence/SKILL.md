---
name: pdf-document-intelligence
description: 'Use when converting technical PDFs, ARIA manuals, API references, CAN documentation, functional specifications, or requirement documents into context-preserving technical knowledge repositories. Extracts hierarchy, semantic functions, parameter and return tables, examples, TOC, cross-links, images, OCR evidence, diagrams, mathematical expressions, relationships, RAG chunks, search indexes, Markdown, and quality reports under docs/processed_Documents.'
argument-hint: 'Provide the PDF path and optional OCR or vision-adapter configuration'
user-invocable: true
disable-model-invocation: false
---

# PDF Document Intelligence v2

## Purpose

Use this skill to turn a technical PDF into a structured knowledge repository without flattening its document context. The bundled [parser](./scripts/pdf_document_intelligence.py) produces a source-filename-derived folder containing semantic JSON, Markdown, image/table assets, and quality evidence.

Use this for ARIA API manuals, CAN documents, technical specifications, and requirements. Treat the repository as an extraction artefact, not a replacement for the source PDF: every item retains its source file and page provenance.

## Required Inputs And Safety Rules

1. Identify the original PDF, intended output root, document revision/date when known, and whether it is native-text, scanned, encrypted, or mixed-layout.
2. Keep the source PDF immutable in `docs/` using a meaningful filename. By default write only processed output to `docs/processed_Documents/<SourceDocumentStem>/`, preserving source-stem casing; for example `docs/AIRBAG_SPEC_v1.pdf` produces `docs/processed_Documents/AIRBAG_SPEC_v1/`.
3. Do not infer unreadable text, figure meaning, API prototypes, table cells, requirements, identifiers, or values. Use `Evidence unavailable.` or the parser's uncertainty/gap markers.
4. Preserve headers and footers in page records and metadata, while omitting recurring ones from the semantic body/Markdown. Headers and footers can carry revision or document-control evidence.
5. Treat OCR output as uncertain until its quality is reviewed. Do not use a low-confidence OCR value as an engineering fact.

## Processing Workflow

1. Run the parser against one PDF and inspect `extraction_quality.json` before using the output for engineering conclusions.
2. Compare reported page count with the source page count. Review parser choices, table warnings, low-text pages, OCR confidence, visual-review gaps, multi-column warnings, and suspected missing headings.
3. Check representative pages: a title page, a table page, an API/prototype page, and a page with a diagram, screenshot, formula, or example.
4. Verify detected headings, TOC links, functions, parameter/return tables, and examples against the source. Correct parser rules or source configuration rather than hand-editing generated facts.
5. Use `document.md` for human/LLM review and the JSON artefacts for traceability, tools, graph ingestion, and future retrieval.

## Command

```powershell
& "C:\Python3.13.0\python.exe" .github\skills\pdf-document-intelligence\scripts\pdf_document_intelligence.py `
  "C:\Path\To\ARIA User Functions.pdf"
```

The default output is `docs/processed_Documents/<SourceDocumentStem>/`; the parser preserves the source filename stem's case after filesystem-safe sanitization. To use another location, provide `--output-root <directory>`.

Use `--ocr-engine tesseract` only after installing the Tesseract executable and confirming it is available on `PATH`. Use `--ocr-engine easyocr` only after installing its model/runtime. OCR is opt-in, confidence-bearing, and marks low-confidence output for review.

For optional vision analysis, pass `--vision-adapter package.module:function`. The callable receives an image `Path` and must return a JSON-compatible dictionary with optional `description`, `detected_entities`, and `confidence` keys. Azure AI Document Intelligence, Azure Computer Vision, and local models can be used through this adapter; the skill does not assume credentials, network access, or an enterprise service exists.

## Generated Repository

```text
docs/processed_Documents/<SourceDocumentStem>/
  metadata.json
  document_structure.json
  pages.json
  functions.json
  toc.json
  references.json
  relationships.json
  mathematical_expressions.json
  knowledge_chunks.json
  document_summary.json
  duplicate_content.json
  search_index.json
  extraction_quality.json
  run_manifest.json
  document.md
  images/page_<n>_img_<n>.<ext>
  tables/page_<n>_table_<n>.json
```

- `metadata.json`: source path/name, SHA-256, PDF metadata, title, page count, document type, and parser configuration.
- `pages.json`: reading-order blocks, single/two-column layout classification, preserved headers/footers, image and table references, page provenance, OCR evidence, and visual-review gaps.
- `document_structure.json`: detected headings and parent relationships.
- `functions.json`: semantic API records with source-backed prototype, parameters, descriptions, return codes, examples, occurrences, and page/section provenance. Fields remain empty when evidence is absent.
- `toc.json`: detected table-of-contents entries and resolution to actual document sections.
- `references.json`: TOC, section, and function cross-references with resolution status.
- `relationships.json`: typed nodes and extracted contains/references/referenced-by edges for graph ingestion.
- `mathematical_expressions.json`: conservatively identified formula-like text blocks with page/bounding-box provenance.
- `knowledge_chunks.json`: section, function, and table chunks suitable for RAG/vector indexing.
- `search_index.json`: document and chunk keywords for deterministic retrieval.
- `document_summary.json`: a transparent structural/keyword summary, not a generated factual interpretation.
- `duplicate_content.json`: repeated non-header/footer text blocks for document-quality review.
- `extraction_quality.json`: parser availability/selection, page-count reconciliation, table integrity flags, low-text/OCR pages, OCR confidence, layout, image/vision gaps, and warnings.
- `document.md`: heading-aware, Git-friendly human-readable rendering with tables, code blocks, figures, page markers, and function reference sections.

## Decision Points

- **Native text layer:** use PyMuPDF blocks and `pdfplumber` tables.
- **Table fallback:** select the highest-scoring result in order: `pdfplumber`, Camelot, then OCR-derived rows. Record the selected parser and mark OCR/irregular tables for review.
- **Scanned/low-text pages or screenshots:** enable OCR deliberately. Preserve text, engine, confidence, and review status; never promote low-confidence OCR into an engineering fact.
- **Multi-column or form-heavy layout:** inspect `pages.json` layout type and reading-order method. Two-column ordering is heuristic and is flagged for review.
- **Figures, screenshots, diagrams, graphs, and code images:** retain the image, caption, section relationship, OCR output, local category, and optional vision result. If semantic meaning is not verified, retain a visual-review gap.
- **Function sections:** semantic labels such as Prototype, Description, Parameters, Return Value, and Usage Example are grouped inside the detected function section. Parameter-table enrichment occurs only when the table and function share page/section context.

## Portfolio Handoff

For a multi-skill workflow, preserve the source hash, output folder, extraction-quality gate, document/page/section provenance, unresolved references, OCR/vision confidence, and generated artifact paths. Hand approved requirement evidence to `requirement-based-testing`, dependency/library evidence to `uv-package-manager`, and cross-document relationships to `skill-portfolio-orchestration` or Graphify.

## Completion Criteria

The extraction is ready for downstream use only when the output folder exists under `docs/processed_Documents`, source/page provenance is present on every semantic artifact, page counts reconcile, headers/footers are preserved separately, tables retain rows/columns or are flagged, OCR/vision confidence is visible, references resolve or remain explicitly unresolved, and a representative technical/API/table/figure-page review supports the stated extraction quality.