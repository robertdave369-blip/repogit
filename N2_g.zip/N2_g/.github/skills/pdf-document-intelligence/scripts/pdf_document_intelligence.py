"""Context-preserving technical PDF extraction.

This module creates a provenance-preserving knowledge repository instead of a
flat text dump. It can be imported as ``PDFDocumentIntelligenceSkill`` or run
as a command-line tool.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import io
import json
import re
import shutil
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import fitz


def _optional_module(module_name: str) -> Any | None:
    try:
        return importlib.import_module(module_name)
    except Exception:
        return None


pdfplumber = _optional_module("pdfplumber")
camelot = _optional_module("camelot")
pytesseract = _optional_module("pytesseract")
Image = _optional_module("PIL.Image")

DEFAULT_OUTPUT_ROOT = Path(__file__).resolve().parents[4] / "docs" / "processed_Documents"
OCR_CONFIDENCE_THRESHOLD = 0.85

_FUNCTION_HEADING_PATTERN = re.compile(
    r"^(?:\d+(?:\.\d+)*\.?\s+)?(?P<name>[A-Z][A-Z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)(?:\s*\(|\s*$)"
)
_FUNCTION_NAME_PATTERN = re.compile(r"\b([A-Z][A-Z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)\b")
_NUMBERED_HEADING_PATTERN = re.compile(r"^(?P<number>\d+(?:\.\d+)*\.?)\s*(?P<title>\S.+)$")
_TOC_PATTERN = re.compile(
    r"^(?:(?P<number>\d+(?:\.\d+)*\.?)\s+)?(?P<title>.+?)\s*(?:\.{2,}|\s{2,})\s*(?P<target_page>\d+)$"
)
_RETURN_CODE_PATTERN = re.compile(r"\[\s*[\"']?(?P<code>[0-9A-Fa-f]{4})[\"']?\s*(?:,\s*(?P<message>[^\]]+))?\]")
_EXPLICIT_SECTION_REFERENCE_PATTERN = re.compile(
    r"\b(?:see|refer(?:\s+to)?|section)\s+(?P<number>\d+(?:\.\d+)*)\b",
    re.IGNORECASE,
)
_FIGURE_CAPTION_PATTERN = re.compile(
    r"^(?:figure|fig\.|diagram|chart|graph|table)\s*\d*\s*[:.-]?\s*(?P<caption>.+)$",
    re.IGNORECASE,
)
_WHITESPACE_PATTERN = re.compile(r"\s+")
_FILENAME_PATTERN = re.compile(r"[^a-z0-9]+")
_DOCUMENT_FOLDER_INVALID_PATTERN = re.compile(r"[<>:\"/\\|?*\x00-\x1F]")
_CODE_HINT_PATTERN = re.compile(
    r"(?:\b(?:class|def|function|public|private|return|var|const|string|int)\b|[{};]|=>|\w+\.\w+\s*\()",
    re.IGNORECASE,
)
_MATH_HINT_PATTERN = re.compile(
    r"(?:[=±∑√≤≥≈≠]|(?<!\w)\w+\s*\^\s*\d+|\b(?:sin|cos|tan|log|exp)\s*\()",
    re.IGNORECASE,
)

_SEMANTIC_LABELS = {
    "prototype": "prototype",
    "signature": "prototype",
    "method": "prototype",
    "function definition": "prototype",
    "declaration": "prototype",
    "description": "description",
    "details": "description",
    "parameters": "parameters",
    "parameter": "parameters",
    "input parameters": "parameters",
    "return value": "returns",
    "return values": "returns",
    "returns": "returns",
    "usage example": "examples",
    "usage examples": "examples",
    "example": "examples",
    "examples": "examples",
    "code sample": "examples",
    "sample call": "examples",
}

_STOP_WORDS = {
    "about", "after", "also", "and", "are", "as", "at", "be", "by", "can", "document", "for",
    "from", "has", "in", "into", "is", "it", "its", "of", "on", "or", "page", "that", "the",
    "this", "to", "use", "using", "with", "will", "you", "your",
}


@dataclass
class ExtractionQuality:
    page_count: int
    parser_availability: dict[str, bool]
    parser_selection: dict[str, Any] = field(default_factory=dict)
    low_text_pages: list[int] = field(default_factory=list)
    ocr_pages: list[int] = field(default_factory=list)
    ocr_uncertain_pages: list[int] = field(default_factory=list)
    ocr_unavailable: list[dict[str, Any]] = field(default_factory=list)
    figure_review_pages: list[int] = field(default_factory=list)
    table_warnings: list[dict[str, Any]] = field(default_factory=list)
    layout_warnings: list[dict[str, Any]] = field(default_factory=list)
    vision_warnings: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "page_count": self.page_count,
            "parser_availability": self.parser_availability,
            "parser_selection": self.parser_selection,
            "low_text_pages": self.low_text_pages,
            "ocr_pages": self.ocr_pages,
            "ocr_uncertain_pages": self.ocr_uncertain_pages,
            "ocr_unavailable": self.ocr_unavailable,
            "figure_review_pages": self.figure_review_pages,
            "table_warnings": self.table_warnings,
            "layout_warnings": self.layout_warnings,
            "vision_warnings": self.vision_warnings,
            "warnings": self.warnings,
        }


def _normalise_text(text: str) -> str:
    return _WHITESPACE_PATTERN.sub(" ", text).strip()


def _recurrence_key(text: str) -> str:
    return re.sub(r"\d+", "#", _normalise_text(text))


def _slugify(value: str) -> str:
    slug = _FILENAME_PATTERN.sub("_", value.lower()).strip("_")
    return slug or "untitled_document"


def _document_output_folder_name(source_stem: str) -> str:
    """Preserve source-document casing while creating a filesystem-safe folder."""
    folder_name = _DOCUMENT_FOLDER_INVALID_PATTERN.sub("_", source_stem).strip(" .")
    return folder_name or "untitled_document"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_write(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _markdown_escape(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", "<br>")


def _heading_level(number: str | None) -> int:
    return len(re.findall(r"\d+", number or "")) or 1


def _semantic_label(text: str) -> str | None:
    return _SEMANTIC_LABELS.get(_normalise_text(text).lower().rstrip(":"))


def _looks_like_code(text: str) -> bool:
    return bool(_CODE_HINT_PATTERN.search(text)) and len(_normalise_text(text)) >= 4


def _looks_like_math(text: str) -> bool:
    return bool(_MATH_HINT_PATTERN.search(text)) and len(_normalise_text(text)) >= 3


def _detect_code_language(text: str) -> str:
    lowered = text.lower()
    if any(token in lowered for token in ("using ", "namespace ", "string[]", "public ", "private ")):
        return "csharp"
    if any(token in lowered for token in ("def ", "import ", "self.", "print(")):
        return "python"
    if any(token in lowered for token in ("function ", "var ", "const ", "let ")):
        return "javascript"
    if ";" in text or "{" in text or "}" in text:
        return "csharp"
    return "unknown"


def _normalise_table_rows(rows: Iterable[Iterable[Any]]) -> list[list[str]]:
    return [[_normalise_text(str(cell or "")) for cell in row] for row in rows if row is not None]


def _table_score(rows: list[list[str]]) -> float:
    if not rows:
        return 0.0
    expected_columns = max((len(row) for row in rows), default=0)
    if expected_columns == 0:
        return 0.0
    filled = sum(1 for row in rows for cell in row if _normalise_text(cell))
    rectangular = sum(1 for row in rows if len(row) == expected_columns)
    return round((filled / (len(rows) * expected_columns)) * (rectangular / len(rows)), 4)


def _classify_table(headers: list[str]) -> str:
    normalized = " ".join(_normalise_text(header).lower() for header in headers)
    if "parameter" in normalized or all(token in normalized for token in ("type", "name", "description")):
        return "parameter_table"
    if any(token in normalized for token in ("return", "result", "status", "code")):
        return "return_value_table"
    if any(token in normalized for token in ("acronym", "abbreviation", "terminology", "meaning", "definition")):
        return "acronym_table"
    if any(token in normalized for token in ("revision", "version", "change", "date", "author")):
        return "change_history_table"
    if any(token in normalized for token in ("reference", "document", "section", "source")):
        return "reference_table"
    if any(token in normalized for token in ("configuration", "setting", "value", "default")):
        return "configuration_table"
    return "unknown"


def _table_markdown(headers: list[str], rows: list[list[str]]) -> list[str]:
    if not headers:
        return []
    width = len(headers)
    output = ["| " + " | ".join(_markdown_escape(cell) for cell in headers) + " |"]
    output.append("| " + " | ".join("---" for _ in headers) + " |")
    for row in rows:
        padded = row + [""] * max(0, width - len(row))
        output.append("| " + " | ".join(_markdown_escape(cell) for cell in padded[:width]) + " |")
    return output


def _keywords_from_text(text: str, limit: int = 50) -> list[str]:
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}", text)
    counts: Counter[str] = Counter(token for token in tokens if token.lower() not in _STOP_WORDS)
    return [token for token, _ in counts.most_common(limit)]


class PDFDocumentIntelligenceSkill:
    """Extract a technical PDF into an evidence-backed knowledge repository."""

    def __init__(
        self,
        ocr_engine: str = "none",
        vision_adapter: str | None = None,
        ocr_confidence_threshold: float = OCR_CONFIDENCE_THRESHOLD,
    ) -> None:
        if ocr_engine not in {"none", "tesseract", "easyocr"}:
            raise ValueError("ocr_engine must be 'none', 'tesseract', or 'easyocr'")
        if not 0.0 <= ocr_confidence_threshold <= 1.0:
            raise ValueError("ocr_confidence_threshold must be between 0.0 and 1.0")
        self.ocr_engine = ocr_engine
        self.vision_adapter = vision_adapter
        self.ocr_confidence_threshold = ocr_confidence_threshold
        self._ocr_reader: Any | None = None
        self._vision_analyzer: Any | None = None
        self._page_ocr_cache: dict[int, dict[str, Any]] = {}

    def process(self, pdf_path: str | Path, output_root: str | Path | None = None) -> Path:
        source_path = Path(pdf_path).expanduser().resolve()
        if source_path.suffix.lower() != ".pdf":
            raise ValueError(f"Expected a PDF input, received: {source_path}")
        if not source_path.is_file():
            raise FileNotFoundError(source_path)
        if source_path.is_relative_to(DEFAULT_OUTPUT_ROOT):
            raise ValueError("Processed document artifacts cannot be used as source PDFs. Use the original document from docs/ or another approved source.")

        resolved_output_root = Path(output_root).expanduser().resolve() if output_root else DEFAULT_OUTPUT_ROOT
        output_dir = resolved_output_root / _document_output_folder_name(source_path.stem)
        self._prepare_output_dir(output_dir)
        self._page_ocr_cache.clear()

        document = fitz.open(source_path)
        try:
            document_metadata: dict[str, str] = dict(document.metadata or {})
            title = self._determine_title(document, source_path, document_metadata)
            quality = ExtractionQuality(
                page_count=document.page_count,
                parser_availability={
                    "pymupdf": True,
                    "pdfplumber": pdfplumber is not None,
                    "camelot": camelot is not None,
                    "pytesseract_python": pytesseract is not None,
                    "pillow": Image is not None,
                    "vision_adapter": self.vision_adapter is not None,
                },
                parser_selection={
                    "layout": "PyMuPDF",
                    "tables": ["pdfplumber", "camelot", "ocr"],
                    "ocr": self.ocr_engine,
                    "vision_adapter": self.vision_adapter,
                },
            )
            images_dir = output_dir / "images"
            tables_dir = output_dir / "tables"
            pages = self._extract_pages(document, source_path, images_dir, quality)
            self._identify_recurring_headers_and_footers(pages, document.page_count)
            table_records = self._extract_tables(source_path, tables_dir, pages, quality)
            sections = self._detect_sections(pages)
            self._associate_assets(pages, sections, table_records)
            toc_entries = self._extract_toc_entries(pages)
            toc_resolutions = self._resolve_toc_entries(toc_entries, sections)
            functions = self._extract_semantic_functions(pages, sections, table_records)
            references = self._build_references(pages, sections, functions, toc_resolutions)
            relationships = self._build_relationships(sections, functions, table_records, pages, references)
            mathematical_expressions = self._collect_mathematical_expressions(pages)
            document_type = self._classify_document(title, pages, functions)
            duplicates = self._find_duplicate_blocks(pages)
            chunks = self._build_knowledge_chunks(source_path.name, sections, functions, table_records, pages)
            search_index = self._build_search_index(title, sections, functions, table_records, chunks)
            summary = self._build_summary(title, document_type, sections, functions, table_records, pages)

            metadata = {
                "title": title,
                "document_type": document_type,
                "page_count": document.page_count,
                "source_file": source_path.name,
                "source_document_stem": source_path.stem,
                "source_path": str(source_path),
                "source_sha256": _sha256(source_path),
                "output_folder": str(output_dir),
                "pdf_metadata": {key: value for key, value in document_metadata.items() if value},
                "ocr_engine": self.ocr_engine,
                "vision_adapter": self.vision_adapter,
            }
            quality_payload = quality.as_dict() | {
                "extracted_page_count": len(pages),
                "page_count_matches_source": len(pages) == document.page_count,
                "table_count": len(table_records),
                "image_count": sum(len(page["images"]) for page in pages),
                "section_count": len(sections),
                "function_count": len(functions),
                "toc_entry_count": len(toc_entries),
                "duplicate_block_count": len(duplicates["duplicate_blocks"]),
            }

            _json_write(output_dir / "metadata.json", metadata)
            _json_write(output_dir / "pages.json", {"source_file": source_path.name, "pages": pages})
            _json_write(output_dir / "document_structure.json", {"source_file": source_path.name, "sections": sections})
            _json_write(output_dir / "functions.json", {"source_file": source_path.name, "functions": functions})
            _json_write(output_dir / "toc.json", {"source_file": source_path.name, "entries": toc_entries, "resolutions": toc_resolutions})
            _json_write(output_dir / "references.json", references)
            _json_write(output_dir / "relationships.json", relationships)
            _json_write(output_dir / "mathematical_expressions.json", {"source_file": source_path.name, "expressions": mathematical_expressions})
            _json_write(output_dir / "knowledge_chunks.json", {"source_file": source_path.name, "chunks": chunks})
            _json_write(output_dir / "document_summary.json", summary)
            _json_write(output_dir / "duplicate_content.json", duplicates)
            _json_write(output_dir / "search_index.json", search_index)
            _json_write(output_dir / "extraction_quality.json", quality_payload)
            _json_write(
                output_dir / "run_manifest.json",
                {
                    "source_file": source_path.name,
                    "output_folder": str(output_dir),
                    "artifacts": [
                        "metadata.json", "pages.json", "document_structure.json", "functions.json", "toc.json",
                        "references.json", "relationships.json", "mathematical_expressions.json", "knowledge_chunks.json", "document_summary.json",
                        "duplicate_content.json", "search_index.json", "extraction_quality.json", "document.md",
                    ],
                },
            )
            (output_dir / "document.md").write_text(
                self._render_markdown(title, summary, pages, sections, functions, table_records, toc_entries),
                encoding="utf-8",
            )
            return output_dir
        finally:
            document.close()

    @staticmethod
    def _prepare_output_dir(output_dir: Path) -> None:
        output_dir.mkdir(parents=True, exist_ok=True)
        for directory_name in ("images", "tables"):
            directory = output_dir / directory_name
            if directory.is_dir():
                shutil.rmtree(directory)
            directory.mkdir(exist_ok=True)
        for filename in (
            "metadata.json", "pages.json", "document_structure.json", "functions.json", "toc.json",
            "references.json", "relationships.json", "mathematical_expressions.json", "knowledge_chunks.json", "document_summary.json",
            "duplicate_content.json", "search_index.json", "extraction_quality.json", "run_manifest.json", "document.md",
        ):
            (output_dir / filename).unlink(missing_ok=True)

    @staticmethod
    def _determine_title(document: fitz.Document, source_path: Path, metadata: dict[str, str]) -> str:
        metadata_title = _normalise_text(metadata.get("title", ""))
        if metadata_title:
            return metadata_title
        for page_index in range(min(2, document.page_count)):
            page_text = document[page_index].get_text("text")
            if not isinstance(page_text, str):
                continue
            for line in page_text.splitlines():
                candidate = _normalise_text(line)
                if len(candidate) >= 4 and not candidate.lower().startswith("page "):
                    return candidate
        return source_path.stem

    def _extract_pages(
        self,
        document: fitz.Document,
        source_path: Path,
        images_dir: Path,
        quality: ExtractionQuality,
    ) -> list[dict[str, Any]]:
        pages: list[dict[str, Any]] = []
        for page_number in range(1, document.page_count + 1):
            page = document[page_number - 1]
            raw_layout: Any = page.get_text("dict", sort=True)
            layout_blocks = raw_layout.get("blocks", []) if isinstance(raw_layout, dict) else []
            blocks: list[dict[str, Any]] = []
            for raw_block in layout_blocks:
                if not isinstance(raw_block, dict) or raw_block.get("type") != 0:
                    continue
                lines: list[dict[str, Any]] = []
                for raw_line in raw_block.get("lines", []):
                    if not isinstance(raw_line, dict):
                        continue
                    spans = [span for span in raw_line.get("spans", []) if isinstance(span, dict)]
                    text = "".join(str(span.get("text", "")) for span in spans)
                    if not _normalise_text(text):
                        continue
                    lines.append(
                        {
                            "text": text,
                            "font_names": sorted({str(span.get("font", "")) for span in spans if span.get("font")}),
                            "font_size_max": max((float(span.get("size", 0.0)) for span in spans), default=0.0),
                        }
                    )
                bbox = raw_block.get("bbox")
                if not lines or not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
                    continue
                x0, y0, x1, y1 = (float(value) for value in bbox)
                block_text = "\n".join(item["text"] for item in lines)
                blocks.append(
                    {
                        "text": block_text,
                        "bbox": [round(x0, 2), round(y0, 2), round(x1, 2), round(y1, 2)],
                        "reading_order": 0,
                        "font_size_max": max(item["font_size_max"] for item in lines),
                        "font_names": sorted({font for item in lines for font in item["font_names"]}),
                        "line_count": len(lines),
                        "content_type": "code_snippet" if _looks_like_code(block_text) else "mathematical_expression" if _looks_like_math(block_text) else "text",
                    }
                )
            layout_type, reading_order_method = self._order_blocks(blocks, float(page.rect.width), page_number, quality)
            body_text = "\n".join(block["text"] for block in blocks)
            if len(_normalise_text(body_text)) < 20:
                quality.low_text_pages.append(page_number)
                page_ocr = self._ocr_page(page, page_number, quality)
                if page_ocr.get("text"):
                    ocr_text = str(page_ocr["text"])
                    blocks.append(
                        {
                            "text": ocr_text if not page_ocr["requires_review"] else f"[OCR-UNCERTAIN: {ocr_text}]",
                            "bbox": [0.0, 0.0, round(page.rect.width, 2), round(page.rect.height, 2)],
                            "reading_order": len(blocks) + 1,
                            "font_size_max": 0.0,
                            "font_names": ["OCR"],
                            "line_count": len(ocr_text.splitlines()),
                            "content_type": "ocr_text",
                        }
                    )
            images = self._extract_images(document, page, page_number, images_dir, blocks, quality)
            if images:
                quality.figure_review_pages.append(page_number)
            for reading_order, block in enumerate(blocks, start=1):
                block["reading_order"] = reading_order
            pages.append(
                {
                    "page": page_number,
                    "source_file": source_path.name,
                    "size_points": {"width": round(page.rect.width, 2), "height": round(page.rect.height, 2)},
                    "rotation": page.rotation,
                    "layout_type": layout_type,
                    "reading_order_method": reading_order_method,
                    "blocks": blocks,
                    "headers": [],
                    "footers": [],
                    "images": images,
                    "tables": [],
                    "gaps": ["figure content requires visual review"] if images and not self.vision_adapter else [],
                }
            )
        return pages

    @staticmethod
    def _order_blocks(
        blocks: list[dict[str, Any]],
        page_width: float,
        page_number: int,
        quality: ExtractionQuality,
    ) -> tuple[str, str]:
        if not blocks:
            return "empty", "no selectable text blocks"
        left = [block for block in blocks if block["bbox"][2] <= page_width * 0.48]
        right = [block for block in blocks if block["bbox"][0] >= page_width * 0.52]
        left_ids = {id(block) for block in left}
        right_ids = {id(block) for block in right}
        wide = [block for block in blocks if id(block) not in left_ids | right_ids]
        if len(left) >= 3 and len(right) >= 3:
            first_column_y = min(block["bbox"][1] for block in left + right)
            leading_wide = [block for block in wide if block["bbox"][3] <= first_column_y]
            leading_ids = {id(block) for block in leading_wide}
            remaining_wide = [block for block in wide if id(block) not in leading_ids]
            blocks[:] = (
                sorted(leading_wide, key=lambda item: (item["bbox"][1], item["bbox"][0]))
                + sorted(left, key=lambda item: (item["bbox"][1], item["bbox"][0]))
                + sorted(right, key=lambda item: (item["bbox"][1], item["bbox"][0]))
                + sorted(remaining_wide, key=lambda item: (item["bbox"][1], item["bbox"][0]))
            )
            quality.layout_warnings.append(
                {
                    "page": page_number,
                    "layout_type": "two_column",
                    "warning": "Two-column reading order is heuristic and requires review for interleaved figures or sidebars.",
                }
            )
            return "two_column", "leading full-width, left column, right column, remaining full-width"
        blocks.sort(key=lambda item: (item["bbox"][1], item["bbox"][0]))
        return "single_column", "PyMuPDF text blocks sorted top-to-bottom then left-to-right"

    def _ocr_page(self, page: fitz.Page, page_number: int, quality: ExtractionQuality) -> dict[str, Any]:
        cached = self._page_ocr_cache.get(page_number)
        if cached is not None:
            return cached
        pixmap = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        result = self._ocr_bytes(pixmap.tobytes("png"), page_number, "page", quality)
        self._page_ocr_cache[page_number] = result
        return result

    def _ocr_bytes(
        self,
        image_bytes: bytes,
        page_number: int,
        scope: str,
        quality: ExtractionQuality,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {
            "engine": self.ocr_engine,
            "status": "not_requested",
            "text": None,
            "confidence": None,
            "requires_review": False,
        }
        if self.ocr_engine == "none":
            return result
        try:
            if self.ocr_engine == "tesseract":
                if Image is None or pytesseract is None:
                    raise RuntimeError("Pillow or pytesseract Python package is unavailable")
                image_api: Any = Image
                ocr_api: Any = pytesseract
                image = image_api.open(io.BytesIO(image_bytes))
                ocr_api.get_tesseract_version()
                data = ocr_api.image_to_data(image, output_type=ocr_api.Output.DICT)
                text = str(ocr_api.image_to_string(image))
                confidences = []
                for confidence in data.get("conf", []):
                    try:
                        numeric = float(confidence)
                    except (TypeError, ValueError):
                        continue
                    if numeric >= 0:
                        confidences.append(numeric / 100.0)
            else:
                if self._ocr_reader is None:
                    easyocr_module: Any = importlib.import_module("easyocr")
                    self._ocr_reader = easyocr_module.Reader(["en"], gpu=False)
                reader: Any = self._ocr_reader
                details = reader.readtext(image_bytes, detail=1)
                text = "\n".join(str(item[1]) for item in details if len(item) >= 3)
                confidences = [float(item[2]) for item in details if len(item) >= 3]
            confidence = round(sum(confidences) / len(confidences), 4) if confidences else None
            result.update(
                {
                    "status": "completed",
                    "text": text.strip() or None,
                    "confidence": confidence,
                    "requires_review": confidence is None or confidence < self.ocr_confidence_threshold,
                }
            )
            if result["text"] and page_number not in quality.ocr_pages:
                quality.ocr_pages.append(page_number)
            if result["requires_review"] and page_number not in quality.ocr_uncertain_pages:
                quality.ocr_uncertain_pages.append(page_number)
        except Exception as error:  # OCR binaries and models are environment-specific.
            result.update({"status": "unavailable", "error": str(error), "requires_review": True})
            quality.ocr_unavailable.append({"page": page_number, "scope": scope, "engine": self.ocr_engine, "error": str(error)})
        return result

    def _extract_images(
        self,
        document: fitz.Document,
        page: fitz.Page,
        page_number: int,
        images_dir: Path,
        blocks: list[dict[str, Any]],
        quality: ExtractionQuality,
    ) -> list[dict[str, Any]]:
        images: list[dict[str, Any]] = []
        seen_xrefs: set[int] = set()
        for image_number, image_info in enumerate(page.get_images(full=True), start=1):
            xref = int(image_info[0])
            if xref in seen_xrefs:
                continue
            seen_xrefs.add(xref)
            extracted = document.extract_image(xref)
            extension = str(extracted.get("ext", "bin"))
            filename = f"page_{page_number}_img_{image_number}.{extension}"
            image_path = images_dir / filename
            image_path.write_bytes(extracted["image"])
            bbox = None
            try:
                rectangles = page.get_image_rects(xref)
                if rectangles:
                    rectangle = rectangles[0]
                    bbox = [round(rectangle.x0, 2), round(rectangle.y0, 2), round(rectangle.x1, 2), round(rectangle.y1, 2)]
            except Exception:
                pass
            ocr = self._ocr_bytes(extracted["image"], page_number, "image", quality)
            ocr_text = str(ocr.get("text") or "")
            caption = self._find_caption(blocks, bbox)
            image_type = self._classify_image(
                ocr_text,
                str(caption or ""),
                int(extracted.get("width", 0) or 0),
                int(extracted.get("height", 0) or 0),
            )
            images.append(
                {
                    "page": page_number,
                    "image": f"images/{filename}",
                    "xref": xref,
                    "bbox": bbox,
                    "width": extracted.get("width"),
                    "height": extracted.get("height"),
                    "colorspace": extracted.get("colorspace"),
                    "image_type": image_type,
                    "classification_method": "local heuristic using dimensions, caption, and optional OCR text",
                    "caption": caption,
                    "related_section": None,
                    "ocr": ocr,
                    "semantic_content": _normalise_text(ocr_text)[:1000] or None,
                    "vision_analysis": self._analyze_image_with_vision(image_path, page_number, quality),
                }
            )
        return images

    @staticmethod
    def _find_caption(blocks: list[dict[str, Any]], asset_bbox: list[float] | None) -> str | None:
        candidate: tuple[float, str] | None = None
        asset_y = asset_bbox[1] if asset_bbox else None
        for block in blocks:
            for line in str(block["text"]).splitlines():
                match = _FIGURE_CAPTION_PATTERN.match(_normalise_text(line))
                if not match:
                    continue
                distance = abs(block["bbox"][1] - asset_y) if asset_y is not None else block["bbox"][1]
                text = _normalise_text(match.group("caption"))
                if text and (candidate is None or distance < candidate[0]):
                    candidate = (distance, text)
        return candidate[1] if candidate else None

    @staticmethod
    def _classify_image(ocr_text: str, caption: str, width: int, height: int) -> str:
        lowered = f"{ocr_text} {caption}".lower()
        if _looks_like_code(ocr_text):
            return "code_snippet"
        if any(token in lowered for token in ("architecture", "component", "interface", "ecu", "module")):
            return "architecture"
        if any(token in lowered for token in ("flow", "state", "transition", "sequence")):
            return "flowchart"
        if any(token in lowered for token in ("chart", "graph", "axis", "series")):
            return "graph"
        if any(token in lowered for token in ("table", "column", "row")):
            return "table_image"
        if width and height and width < 220 and height < 120:
            return "logo"
        if ocr_text:
            return "screenshot"
        return "unknown"

    def _analyze_image_with_vision(
        self,
        image_path: Path,
        page_number: int,
        quality: ExtractionQuality,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {
            "status": "not_requested",
            "provider": None,
            "description": None,
            "detected_entities": [],
            "confidence": None,
        }
        if not self.vision_adapter:
            return result
        try:
            if self._vision_analyzer is None:
                module_name, separator, function_name = self.vision_adapter.partition(":")
                if not separator or not module_name or not function_name:
                    raise ValueError("vision_adapter must use the form 'module:function'")
                module = importlib.import_module(module_name)
                analyzer = getattr(module, function_name)
                if not callable(analyzer):
                    raise TypeError("vision adapter target is not callable")
                self._vision_analyzer = analyzer
            analyzer: Any = self._vision_analyzer
            analysis = analyzer(image_path)
            if not isinstance(analysis, dict):
                raise TypeError("vision adapter must return a JSON-compatible dictionary")
            result.update(
                {
                    "status": "completed",
                    "provider": self.vision_adapter,
                    "description": analysis.get("description"),
                    "detected_entities": analysis.get("detected_entities", []),
                    "confidence": analysis.get("confidence"),
                }
            )
        except Exception as error:  # External vision services require a caller-provided adapter.
            result.update({"status": "unavailable", "provider": self.vision_adapter, "error": str(error)})
            quality.vision_warnings.append({"page": page_number, "image": str(image_path), "error": str(error)})
        return result

    @staticmethod
    def _identify_recurring_headers_and_footers(pages: list[dict[str, Any]], page_count: int) -> None:
        candidates: dict[tuple[str, str], set[int]] = defaultdict(set)
        for page in pages:
            height = float(page["size_points"]["height"])
            for block in page["blocks"]:
                text = _normalise_text(block["text"])
                if not text:
                    continue
                _, y0, _, y1 = block["bbox"]
                position = "header" if y0 <= height * 0.12 else "footer" if y1 >= height * 0.88 else "body"
                if position != "body":
                    candidates[(position, _recurrence_key(text))].add(int(page["page"]))
        threshold = max(2, round(page_count * 0.6))
        recurring = {key for key, occurrences in candidates.items() if len(occurrences) >= threshold}
        for page in pages:
            body_blocks = []
            height = float(page["size_points"]["height"])
            for block in page["blocks"]:
                text = _normalise_text(block["text"])
                _, y0, _, y1 = block["bbox"]
                position = "header" if y0 <= height * 0.12 else "footer" if y1 >= height * 0.88 else "body"
                if (position, _recurrence_key(text)) in recurring:
                    page[f"{position}s"].append({"text": block["text"], "bbox": block["bbox"]})
                else:
                    body_blocks.append(block)
            page["blocks"] = body_blocks

    def _extract_tables(
        self,
        source_path: Path,
        tables_dir: Path,
        pages: list[dict[str, Any]],
        quality: ExtractionQuality,
    ) -> list[dict[str, Any]]:
        table_records: list[dict[str, Any]] = []
        pdf_pages: list[Any] = []
        if pdfplumber is not None:
            try:
                with pdfplumber.open(source_path) as pdf:
                    pdf_pages = [page for page in pdf.pages]
                    for page_number, pdf_page in enumerate(pdf_pages, start=1):
                        candidates = self._pdfplumber_table_candidates(pdf_page, page_number, quality)
                        selected_parser = "pdfplumber"
                        if not candidates or max(candidate["score"] for candidate in candidates) < 0.7:
                            camelot_candidates = self._camelot_table_candidates(source_path, page_number, quality)
                            if camelot_candidates and self._candidate_total_score(camelot_candidates) > self._candidate_total_score(candidates):
                                candidates = camelot_candidates
                                selected_parser = "camelot"
                        if not candidates:
                            ocr_candidate = self._ocr_table_candidate(source_path, page_number, quality)
                            if ocr_candidate:
                                candidates = [ocr_candidate]
                                selected_parser = "ocr"
                        table_records.extend(
                            self._store_tables_for_page(candidates, selected_parser, source_path, tables_dir, pages[page_number - 1], quality)
                        )
            except Exception as error:
                quality.table_warnings.append({"warning": f"pdfplumber table extraction failed: {error}"})
        else:
            quality.warnings.append("pdfplumber is unavailable; table extraction fell back to optional tools only.")
            for page_number in range(1, len(pages) + 1):
                candidates = self._camelot_table_candidates(source_path, page_number, quality)
                selected_parser = "camelot"
                if not candidates:
                    ocr_candidate = self._ocr_table_candidate(source_path, page_number, quality)
                    candidates = [ocr_candidate] if ocr_candidate else []
                    selected_parser = "ocr"
                table_records.extend(
                    self._store_tables_for_page(candidates, selected_parser, source_path, tables_dir, pages[page_number - 1], quality)
                )
        return table_records

    @staticmethod
    def _candidate_total_score(candidates: list[dict[str, Any]]) -> float:
        return sum(float(candidate["score"]) for candidate in candidates)

    @staticmethod
    def _pdfplumber_table_candidates(pdf_page: Any, page_number: int, quality: ExtractionQuality) -> list[dict[str, Any]]:
        try:
            raw_tables = pdf_page.extract_tables()
        except Exception as error:
            quality.table_warnings.append({"page": page_number, "parser": "pdfplumber", "warning": str(error)})
            return []
        candidates = []
        for raw_table in raw_tables:
            rows = _normalise_table_rows(raw_table)
            if rows:
                candidates.append({"rows": rows, "score": _table_score(rows), "requires_review": False})
        return candidates

    @staticmethod
    def _camelot_table_candidates(source_path: Path, page_number: int, quality: ExtractionQuality) -> list[dict[str, Any]]:
        if camelot is None:
            quality.table_warnings.append(
                {"page": page_number, "parser": "camelot", "warning": "Camelot is unavailable; fallback was not executed."}
            )
            return []
        candidates: list[dict[str, Any]] = []
        for flavor in ("lattice", "stream"):
            try:
                table_list = camelot.read_pdf(str(source_path), pages=str(page_number), flavor=flavor)
                for table in table_list:
                    rows = _normalise_table_rows(table.df.values.tolist())
                    if rows:
                        candidates.append({"rows": rows, "score": _table_score(rows), "requires_review": False})
                if candidates:
                    break
            except Exception as error:
                quality.table_warnings.append(
                    {"page": page_number, "parser": f"camelot-{flavor}", "warning": str(error)}
                )
        return candidates

    def _ocr_table_candidate(self, source_path: Path, page_number: int, quality: ExtractionQuality) -> dict[str, Any] | None:
        if self.ocr_engine == "none":
            return None
        document = fitz.open(source_path)
        try:
            page = document[page_number - 1]
            pixmap = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
            ocr = self._ocr_bytes(pixmap.tobytes("png"), page_number, "table", quality)
        finally:
            document.close()
        text = str(ocr.get("text") or "")
        if not text:
            return None
        rows = []
        for line in text.splitlines():
            cells = [cell.strip() for cell in re.split(r"\s{2,}|\|", line) if cell.strip()]
            if len(cells) >= 2:
                rows.append(cells)
        if len(rows) < 2:
            return None
        return {"rows": rows, "score": _table_score(rows), "requires_review": True}

    @staticmethod
    def _store_tables_for_page(
        candidates: list[dict[str, Any]],
        parser_name: str,
        source_path: Path,
        tables_dir: Path,
        page: dict[str, Any],
        quality: ExtractionQuality,
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for table_number, candidate in enumerate(candidates, start=1):
            rows = candidate["rows"]
            headers = rows[0] if rows else []
            data_rows = rows[1:] if len(rows) > 1 else []
            expected_columns = max((len(row) for row in rows), default=0)
            irregular_rows = [index + 1 for index, row in enumerate(rows) if len(row) != expected_columns]
            identifier = f"page_{page['page']}_table_{table_number}"
            filename = f"{identifier}.json"
            table_type = _classify_table(headers)
            record = {
                "id": identifier,
                "source_file": source_path.name,
                "page": page["page"],
                "table": table_number,
                "path": f"tables/{filename}",
                "parser": parser_name,
                "score": candidate["score"],
                "requires_review": bool(candidate.get("requires_review")) or bool(irregular_rows),
                "table_type": table_type,
                "headers": headers,
                "rows": data_rows,
                "raw_rows": rows,
                "column_count_expected": expected_columns,
                "irregular_rows": irregular_rows,
                "related_section": None,
            }
            _json_write(tables_dir / filename, record)
            page["tables"].append(
                {
                    "id": identifier,
                    "page": page["page"],
                    "path": record["path"],
                    "table_type": table_type,
                    "headers": headers,
                    "row_count": len(data_rows),
                    "parser": parser_name,
                    "requires_review": record["requires_review"],
                }
            )
            if irregular_rows:
                quality.table_warnings.append(
                    {"page": page["page"], "table": table_number, "warning": "irregular row lengths", "rows": irregular_rows}
                )
            records.append(record)
        return records

    @staticmethod
    def _page_units(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        units: list[dict[str, Any]] = []
        for page in pages:
            for block in page["blocks"]:
                for line in str(block["text"]).splitlines():
                    text = _normalise_text(line)
                    if text:
                        units.append(
                            {
                                "page": page["page"],
                                "source_file": page["source_file"],
                                "reading_order": block["reading_order"],
                                "bbox": block["bbox"],
                                "font_size_max": block["font_size_max"],
                                "text": text,
                            }
                        )
        return units

    def _detect_sections(self, pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        units = self._page_units(pages)
        font_sizes = [float(unit["font_size_max"]) for unit in units if float(unit["font_size_max"]) > 0]
        median_size = sorted(font_sizes)[len(font_sizes) // 2] if font_sizes else 0.0
        sections: list[dict[str, Any]] = []
        stack: list[dict[str, Any]] = []
        for index, unit in enumerate(units):
            text = unit["text"]
            if _semantic_label(text) or _TOC_PATTERN.match(text) or len(text) > 180:
                continue
            numbered = _NUMBERED_HEADING_PATTERN.match(text)
            title = numbered.group("title") if numbered else text
            number = numbered.group("number") if numbered else None
            function_name = self._first_function_name(title)
            is_large = len(text) <= 120 and float(unit["font_size_max"]) >= median_size + 1.5
            is_function_heading = bool(
                function_name
                and not text.rstrip().endswith(";")
                and (numbered or is_large or _FUNCTION_HEADING_PATTERN.match(text))
            )
            if not (numbered or is_large or is_function_heading):
                continue
            level = _heading_level(number) if number else (2 if is_function_heading else 1)
            while stack and int(stack[-1]["level"]) >= level:
                stack.pop()
            section = {
                "id": f"section_{unit['page']}_{index}_{_slugify(title)}",
                "title": title,
                "number": number.rstrip(".") if number else None,
                "level": level,
                "page": unit["page"],
                "bbox": unit["bbox"],
                "parent_id": stack[-1]["id"] if stack else None,
                "parent_title": stack[-1]["title"] if stack else None,
                "source_file": unit["source_file"],
                "unit_index": index,
                "function_name": function_name if is_function_heading else None,
            }
            sections.append(section)
            stack.append(section)
        return sections

    @staticmethod
    def _first_function_name(text: str) -> str | None:
        match = _FUNCTION_NAME_PATTERN.search(text)
        return match.group(1) if match else None

    def _associate_assets(
        self,
        pages: list[dict[str, Any]],
        sections: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
    ) -> None:
        sections_by_page: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for section in sections:
            sections_by_page[int(section["page"])].append(section)
        table_by_id = {table["id"]: table for table in table_records}
        for page in pages:
            page_sections = sorted(sections_by_page[int(page["page"])], key=lambda section: section["bbox"][1])
            for image in page["images"]:
                related_section = self._related_section(page_sections, image.get("bbox"))
                image["related_section"] = related_section["title"] if related_section else None
            for page_table in page["tables"]:
                table = table_by_id.get(page_table["id"])
                if table is None:
                    continue
                related_section = self._related_section(page_sections, None)
                table["related_section"] = related_section["title"] if related_section else None
                page_table["related_section"] = table["related_section"]

    @staticmethod
    def _related_section(sections: list[dict[str, Any]], asset_bbox: list[float] | None) -> dict[str, Any] | None:
        if not sections:
            return None
        asset_y = asset_bbox[1] if asset_bbox else float("inf")
        preceding = [section for section in sections if section["bbox"][1] <= asset_y]
        return preceding[-1] if preceding else sections[0]

    def _extract_toc_entries(self, pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        entries: list[dict[str, Any]] = []
        seen: set[tuple[int, str, int]] = set()
        for unit in self._page_units(pages):
            match = _TOC_PATTERN.match(unit["text"])
            if not match:
                continue
            title = _normalise_text(match.group("title"))
            target_page = int(match.group("target_page"))
            if title.lower().startswith("page ") or len(title) < 2:
                continue
            key = (int(unit["page"]), title, target_page)
            if key in seen:
                continue
            seen.add(key)
            entries.append(
                {
                    "title": title,
                    "number": match.group("number").rstrip(".") if match.group("number") else None,
                    "target_page": target_page,
                    "toc_page": unit["page"],
                    "source_file": unit["source_file"],
                    "source_line": unit["text"],
                }
            )
        return entries

    @staticmethod
    def _resolve_toc_entries(entries: list[dict[str, Any]], sections: list[dict[str, Any]]) -> list[dict[str, Any]]:
        resolutions: list[dict[str, Any]] = []
        for entry in entries:
            normalized_title = _normalise_text(entry["title"]).lower()
            candidates = [section for section in sections if _normalise_text(section["title"]).lower() == normalized_title]
            if entry["number"]:
                candidates = [section for section in candidates if section["number"] == entry["number"]] or candidates
            section = candidates[0] if candidates else None
            resolutions.append(
                {
                    "title": entry["title"],
                    "toc_page": entry["toc_page"],
                    "target_page": entry["target_page"],
                    "actual_page": section["page"] if section else None,
                    "section_id": section["id"] if section else None,
                    "status": "resolved" if section else "unresolved",
                }
            )
        return resolutions

    def _extract_semantic_functions(
        self,
        pages: list[dict[str, Any]],
        sections: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        units = self._page_units(pages)
        names: list[str] = []
        for section in sections:
            if section.get("function_name") and section["function_name"] not in names:
                names.append(section["function_name"])
        for unit in units:
            for match in _FUNCTION_NAME_PATTERN.finditer(unit["text"]):
                if match.group(1) not in names:
                    names.append(match.group(1))
        functions = []
        for name in names:
            scope, heading = self._function_scope(name, units, sections)
            if not scope:
                continue
            grouped = self._semantic_groups(scope)
            prototype = self._extract_prototype(name, scope)
            parameters = prototype["parameters"] if prototype else []
            self._enrich_parameters_from_tables(parameters, scope, table_records)
            description = self._extract_description(grouped, scope, name)
            return_value, returns = self._extract_returns(grouped, scope, table_records)
            examples = self._extract_examples(grouped, scope, name)
            content = "\n".join(unit["text"] for unit in scope)
            occurrence_pages = sorted({int(unit["page"]) for unit in scope if name in unit["text"]})
            functions.append(
                {
                    "function": name,
                    "name": name,
                    "page": heading["page"] if heading else scope[0]["page"],
                    "source_file": scope[0]["source_file"],
                    "section": heading["title"] if heading else None,
                    "section_id": heading["id"] if heading else None,
                    "prototype": prototype or {"return_type": None, "signature": None},
                    "description": description,
                    "parameters": parameters,
                    "return_value": return_value,
                    "returns": returns,
                    "examples": examples,
                    "usage_examples": [example["content"] for example in examples],
                    "occurrences": occurrence_pages,
                    "content": content,
                    "evidence_status": "Semantic fields are extracted from the function section and must be verified against the source PDF.",
                }
            )
        return functions

    @staticmethod
    def _function_scope(
        name: str,
        units: list[dict[str, Any]],
        sections: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        heading = next((section for section in sections if section.get("function_name") == name), None)
        if heading is not None:
            start = int(heading["unit_index"])
            end = len(units)
            for section in sections:
                if int(section["unit_index"]) > start and int(section["level"]) <= int(heading["level"]):
                    end = int(section["unit_index"])
                    break
            return units[start:end], heading
        start = next((index for index, unit in enumerate(units) if name in unit["text"]), None)
        if start is None:
            return [], None
        end = min(len(units), start + 120)
        next_section = next((section for section in sections if int(section["unit_index"]) > start), None)
        if next_section is not None:
            end = min(end, int(next_section["unit_index"]))
        return units[start:end], None

    @staticmethod
    def _semantic_groups(scope: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
        groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        current_group: str | None = None
        seen_labels: set[str] = set()
        for unit in scope:
            label = _semantic_label(unit["text"])
            if label:
                current_group = label if label not in seen_labels else None
                seen_labels.add(label)
                continue
            if current_group:
                groups[current_group].append(unit)
        return groups

    @staticmethod
    def _extract_prototype(name: str, scope: list[dict[str, Any]]) -> dict[str, Any] | None:
        for index, unit in enumerate(scope):
            line = unit["text"]
            if name not in line or "(" not in line or line.rstrip().endswith(";"):
                continue
            fragments = [line]
            balance = line.count("(") - line.count(")")
            look_ahead = index + 1
            while balance > 0 and look_ahead < len(scope):
                next_line = scope[look_ahead]["text"]
                fragments.append(next_line)
                balance += next_line.count("(") - next_line.count(")")
                look_ahead += 1
            if balance > 0:
                continue
            raw_signature = "\n".join(fragments)
            before_name, _, after_name = raw_signature.partition(name)
            open_parenthesis = after_name.find("(")
            close_parenthesis = after_name.rfind(")")
            if open_parenthesis < 0 or close_parenthesis <= open_parenthesis:
                continue
            return_type = _normalise_text(before_name).strip("-:") or None
            parameters_text = after_name[open_parenthesis + 1:close_parenthesis]
            parameter_strings = [_normalise_text(item) for item in re.split(r",|\n", parameters_text) if _normalise_text(item)]
            parameters = []
            for position, parameter in enumerate(parameter_strings, start=1):
                pieces = parameter.rsplit(" ", 1)
                parameters.append(
                    {
                        "position": position,
                        "type": pieces[0] if len(pieces) == 2 else None,
                        "name": pieces[-1],
                        "description": None,
                    }
                )
            normalized_signature = f"{name}({','.join(parameter_strings)})"
            return {"return_type": return_type, "signature": normalized_signature, "raw_signature": raw_signature, "parameters": parameters}
        return None

    @staticmethod
    def _enrich_parameters_from_tables(
        parameters: list[dict[str, Any]],
        scope: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
    ) -> None:
        parameter_lookup = {str(parameter["name"]).lower(): parameter for parameter in parameters}
        scope_pages = {int(unit["page"]) for unit in scope}
        for table in table_records:
            if table["table_type"] != "parameter_table" or int(table["page"]) not in scope_pages:
                continue
            header_lookup = {header.lower(): index for index, header in enumerate(table["headers"])}
            name_index = next((index for header, index in header_lookup.items() if "name" in header), None)
            type_index = next((index for header, index in header_lookup.items() if "type" in header), None)
            description_index = next((index for header, index in header_lookup.items() if "description" in header), None)
            if name_index is None:
                continue
            for row in table["rows"]:
                if len(row) <= name_index:
                    continue
                parameter = parameter_lookup.get(row[name_index].lower())
                if parameter is None:
                    continue
                if type_index is not None and len(row) > type_index and row[type_index]:
                    parameter["type"] = row[type_index]
                if description_index is not None and len(row) > description_index and row[description_index]:
                    parameter["description"] = row[description_index]

    @staticmethod
    def _extract_description(grouped: dict[str, list[dict[str, Any]]], scope: list[dict[str, Any]], name: str) -> str | None:
        description_lines = [unit["text"] for unit in grouped.get("description", []) if unit["text"]]
        if description_lines:
            return " ".join(description_lines)
        prototype_seen = False
        candidates = []
        for unit in scope:
            text = unit["text"]
            if name in text and "(" in text:
                prototype_seen = True
                continue
            if prototype_seen and not _semantic_label(text) and not _looks_like_code(text) and len(text) > 12:
                candidates.append(text)
                if len(candidates) >= 2:
                    break
        return " ".join(candidates) or None

    @staticmethod
    def _extract_returns(
        grouped: dict[str, list[dict[str, Any]]],
        scope: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
    ) -> tuple[list[str], list[dict[str, Any]]]:
        return_units = grouped.get("returns", [])
        raw_values = [unit["text"] for unit in return_units]
        if not raw_values:
            raw_values = [unit["text"] for unit in scope if _RETURN_CODE_PATTERN.search(unit["text"])]
        returns = []
        for index, value in enumerate(raw_values):
            for match in _RETURN_CODE_PATTERN.finditer(value):
                message = _normalise_text(match.group("message") or "").strip("\"'")
                context = f"{value} {raw_values[index + 1] if index + 1 < len(raw_values) else ''}".lower()
                code = match.group("code").upper()
                meaning = "Success" if code == "0000" or " ok" in context or "success" in context else "Error" if "nok" in context or "error" in context else "Unknown"
                returns.append({"code": code, "message": message or None, "meaning": meaning, "source": value})
        scope_pages = {int(unit["page"]) for unit in scope}
        for table in table_records:
            if table["table_type"] != "return_value_table" or int(table["page"]) not in scope_pages:
                continue
            for row in table["rows"]:
                row_text = " | ".join(row)
                if row_text not in raw_values:
                    raw_values.append(row_text)
                for match in _RETURN_CODE_PATTERN.finditer(row_text):
                    code = match.group("code").upper()
                    if not any(item["code"] == code for item in returns):
                        returns.append({"code": code, "message": _normalise_text(match.group("message") or "") or None, "meaning": "Unknown", "source": row_text})
        return raw_values, returns

    @staticmethod
    def _extract_examples(grouped: dict[str, list[dict[str, Any]]], scope: list[dict[str, Any]], name: str) -> list[dict[str, Any]]:
        candidates = list(grouped.get("examples", []))
        candidates.extend(unit for unit in scope if name in unit["text"] and unit["text"].rstrip().endswith(";"))
        examples = []
        seen: set[tuple[int, str]] = set()
        for unit in candidates:
            content = unit["text"]
            key = (int(unit["page"]), content)
            if key in seen:
                continue
            seen.add(key)
            if _looks_like_code(content) or name in content:
                examples.append({"language": _detect_code_language(content), "content": content, "page": unit["page"]})
        return examples

    def _build_references(
        self,
        pages: list[dict[str, Any]],
        sections: list[dict[str, Any]],
        functions: list[dict[str, Any]],
        toc_resolutions: list[dict[str, Any]],
    ) -> dict[str, Any]:
        section_lookup = {str(section["number"]): section for section in sections if section.get("number")}
        section_references = []
        for unit in self._page_units(pages):
            for match in _EXPLICIT_SECTION_REFERENCE_PATTERN.finditer(unit["text"]):
                target = section_lookup.get(match.group("number"))
                section_references.append(
                    {
                        "source_page": unit["page"],
                        "source_line": unit["text"],
                        "target_number": match.group("number"),
                        "target_section_id": target["id"] if target else None,
                        "target_page": target["page"] if target else None,
                        "status": "resolved" if target else "unresolved",
                    }
                )
        function_references = []
        names = {function["name"] for function in functions}
        for function in functions:
            for target_name in names - {function["name"]}:
                if target_name in function["content"]:
                    function_references.append(
                        {
                            "source": function["name"],
                            "target": target_name,
                            "relationship": "references",
                            "source_page": function["page"],
                            "confidence": "EXTRACTED",
                        }
                    )
        return {"toc_resolutions": toc_resolutions, "section_references": section_references, "function_references": function_references}

    @staticmethod
    def _collect_mathematical_expressions(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        expressions = []
        for page in pages:
            for block in page["blocks"]:
                if block.get("content_type") != "mathematical_expression":
                    continue
                expressions.append(
                    {
                        "text": block["text"],
                        "page": page["page"],
                        "bbox": block["bbox"],
                        "reading_order": block["reading_order"],
                        "source_file": page["source_file"],
                        "classification": "heuristic; review formula semantics against the source PDF",
                    }
                )
        return expressions

    @staticmethod
    def _build_relationships(
        sections: list[dict[str, Any]],
        functions: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
        pages: list[dict[str, Any]],
        references: dict[str, Any],
    ) -> dict[str, Any]:
        nodes = []
        edges = []
        for section in sections:
            nodes.append({"id": section["id"], "type": "section", "label": section["title"], "page": section["page"]})
        for function in functions:
            identifier = f"function:{function['name']}"
            nodes.append({"id": identifier, "type": "function", "label": function["name"], "page": function["page"]})
            if function.get("section_id"):
                edges.append({"source": function["section_id"], "target": identifier, "relationship": "contains", "confidence": "EXTRACTED"})
        for table in table_records:
            identifier = f"table:{table['id']}"
            nodes.append({"id": identifier, "type": "table", "label": table["table_type"], "page": table["page"]})
            section = next((item for item in sections if item["title"] == table.get("related_section") and item["page"] == table["page"]), None)
            if section:
                edges.append({"source": section["id"], "target": identifier, "relationship": "contains", "confidence": "EXTRACTED"})
        for page in pages:
            for index, image in enumerate(page["images"], start=1):
                identifier = f"image:{page['page']}:{index}"
                nodes.append({"id": identifier, "type": "image", "label": image["image_type"], "page": page["page"]})
                section = next((item for item in sections if item["title"] == image.get("related_section") and item["page"] == page["page"]), None)
                if section:
                    edges.append({"source": section["id"], "target": identifier, "relationship": "contains", "confidence": "EXTRACTED"})
        for reference in references["function_references"]:
            source = f"function:{reference['source']}"
            target = f"function:{reference['target']}"
            edges.append({"source": source, "target": target, "relationship": "references", "confidence": "EXTRACTED"})
            edges.append({"source": target, "target": source, "relationship": "referenced_by", "confidence": "EXTRACTED"})
        return {"nodes": nodes, "edges": edges}

    @staticmethod
    def _classify_document(title: str, pages: list[dict[str, Any]], functions: list[dict[str, Any]]) -> dict[str, Any]:
        text = " ".join(block["text"] for page in pages for block in page["blocks"]).lower()
        scores = {
            "API Manual": 3 * len(functions) + text.count("prototype") + text.count("parameter") + text.count("return value"),
            "Requirements Specification": text.count("shall") + text.count("requirement") * 2,
            "Architecture Document": text.count("architecture") * 2 + text.count("component") + text.count("interface"),
            "Test Specification": text.count("test case") * 2 + text.count("expected result") + text.count("precondition"),
            "Configuration Guide": text.count("configuration") * 2 + text.count("setting"),
            "User Guide": text.count("user guide") * 2 + text.count("how to"),
            "Technical Manual": text.count("manual") + text.count("technical"),
        }
        scores["API Manual"] += 3 if "api" in title.lower() or "function" in title.lower() else 0
        document_type, score = max(scores.items(), key=lambda item: item[1])
        if score == 0:
            document_type = "Technical Manual"
        return {"document_type": document_type, "method": "keyword and structural heuristic", "score": score}

    @staticmethod
    def _find_duplicate_blocks(pages: list[dict[str, Any]]) -> dict[str, Any]:
        occurrences: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for page in pages:
            for block in page["blocks"]:
                normalized = _normalise_text(block["text"]).lower()
                if len(normalized) >= 30:
                    occurrences[normalized].append({"page": page["page"], "bbox": block["bbox"], "text": block["text"]})
        duplicates = [
            {"normalized_text": key, "occurrences": value}
            for key, value in occurrences.items()
            if len(value) > 1
        ]
        return {"duplicate_blocks": duplicates}

    @staticmethod
    def _build_knowledge_chunks(
        source_file: str,
        sections: list[dict[str, Any]],
        functions: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
        pages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        chunks = []
        page_blocks: dict[int, list[str]] = defaultdict(list)
        for page in pages:
            page_blocks[int(page["page"])].extend(str(block["text"]) for block in page["blocks"])
        for section in sections:
            content = "\n".join(page_blocks[int(section["page"])])[:12000]
            chunks.append(
                {
                    "id": f"chunk:{section['id']}",
                    "type": "section",
                    "title": section["title"],
                    "content": content,
                    "page": section["page"],
                    "metadata": {"source_file": source_file, "section_id": section["id"], "section_number": section["number"]},
                }
            )
        for function in functions:
            chunks.append(
                {
                    "id": f"chunk:function:{function['name']}",
                    "type": "function",
                    "title": function["name"],
                    "content": function["content"][:12000],
                    "page": function["page"],
                    "metadata": {"source_file": source_file, "section_id": function["section_id"], "prototype": function["prototype"]},
                }
            )
        for table in table_records:
            chunks.append(
                {
                    "id": f"chunk:table:{table['id']}",
                    "type": "table",
                    "title": table["table_type"],
                    "content": "\n".join(" | ".join(row) for row in table["raw_rows"]),
                    "page": table["page"],
                    "metadata": {"source_file": source_file, "table_id": table["id"], "parser": table["parser"]},
                }
            )
        return chunks

    @staticmethod
    def _build_search_index(
        title: str,
        sections: list[dict[str, Any]],
        functions: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
        chunks: list[dict[str, Any]],
    ) -> dict[str, Any]:
        entries = []
        for chunk in chunks:
            entries.append({"chunk_id": chunk["id"], "title": chunk["title"], "page": chunk["page"], "keywords": _keywords_from_text(f"{chunk['title']} {chunk['content']}")})
        all_text = " ".join([title] + [section["title"] for section in sections] + [function["name"] for function in functions] + [" ".join(table["headers"]) for table in table_records])
        return {"keywords": _keywords_from_text(all_text, limit=100), "entries": entries}

    @staticmethod
    def _build_summary(
        title: str,
        document_type: dict[str, Any],
        sections: list[dict[str, Any]],
        functions: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
        pages: list[dict[str, Any]],
    ) -> dict[str, Any]:
        topics = [section["title"] for section in sections[:12]]
        functions_preview = [function["name"] for function in functions[:12]]
        summary = (
            f"{title} is classified as {document_type['document_type']} by a structural and keyword heuristic. "
            f"The extraction contains {len(pages)} pages, {len(sections)} sections, {len(functions)} detected functions, "
            f"and {len(table_records)} extracted tables."
        )
        return {"summary": summary, "document_type": document_type, "topics": topics, "functions": functions_preview}

    @staticmethod
    def _render_markdown(
        title: str,
        summary: dict[str, Any],
        pages: list[dict[str, Any]],
        sections: list[dict[str, Any]],
        functions: list[dict[str, Any]],
        table_records: list[dict[str, Any]],
        toc_entries: list[dict[str, Any]],
    ) -> str:
        section_lookup = {(int(section["page"]), _normalise_text(section["title"])): int(section["level"]) for section in sections}
        tables_by_page: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for table in table_records:
            tables_by_page[int(table["page"])].append(table)
        output = [f"# {title}", "", summary["summary"], ""]
        if toc_entries:
            output.extend(["## Table Of Contents", ""])
            output.extend(f"- {entry['title']} (target p.{entry['target_page']})" for entry in toc_entries)
            output.append("")
        for page in pages:
            output.append(f"<!-- Source: {page['source_file']} p.{page['page']} | layout: {page['layout_type']} -->")
            for block in page["blocks"]:
                text = str(block["text"]).strip()
                normalized = _normalise_text(text)
                level = section_lookup.get((int(page["page"]), normalized))
                if level:
                    output.extend(["#" * min(level + 1, 6) + f" {normalized}", ""])
                elif _looks_like_code(text):
                    output.extend([f"```{_detect_code_language(text)}", text, "```", ""])
                elif block.get("content_type") == "mathematical_expression":
                    output.extend(["```text", text, "```", ""])
                else:
                    output.extend([text, ""])
            for table in tables_by_page[int(page["page"])]:
                output.extend([f"#### {table['table_type'].replace('_', ' ').title()} (p.{page['page']})", ""])
                output.extend(_table_markdown(table["headers"], table["rows"]))
                output.append("")
            for image in page["images"]:
                caption = f" - {image['caption']}" if image.get("caption") else ""
                output.extend([f"![{image['image_type']} p.{page['page']}]({image['image']}){caption}", ""])
                if image["vision_analysis"]["status"] != "completed":
                    output.extend([f"> Gap: image semantic interpretation requires review (source p.{page['page']}).", ""])
        if functions:
            output.extend(["## Function Reference", ""])
        for function in functions:
            output.extend([f"### {function['name']}", ""])
            signature = function["prototype"].get("signature")
            if signature:
                return_type = function["prototype"].get("return_type")
                output.extend(["#### Prototype", "", f"```{_detect_code_language(signature)}", f"{return_type + ' ' if return_type else ''}{signature}", "```", ""])
            if function.get("description"):
                output.extend(["#### Description", "", function["description"], ""])
            if function["parameters"]:
                output.extend(["#### Parameters", ""])
                output.extend(_table_markdown(["Position", "Type", "Name", "Description"], [[str(item["position"]), str(item.get("type") or ""), str(item["name"]), str(item.get("description") or "")] for item in function["parameters"]]))
                output.append("")
            if function["returns"]:
                output.extend(["#### Return Values", ""])
                output.extend(_table_markdown(["Code", "Meaning", "Message"], [[item["code"], item["meaning"], str(item.get("message") or "")] for item in function["returns"]]))
                output.append("")
            if function["examples"]:
                output.extend(["#### Usage Examples", ""])
                for example in function["examples"]:
                    output.extend([f"```{example['language']}", example["content"], "```", ""])
        return "\n".join(output).rstrip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract a PDF into a context-preserving technical knowledge repository.")
    parser.add_argument("pdf_path", help="Source PDF path")
    parser.add_argument(
        "--output-root",
        default=str(DEFAULT_OUTPUT_ROOT),
        help="Root directory for generated document folders (default: docs/processed_Documents)",
    )
    parser.add_argument("--ocr-engine", choices=("none", "tesseract", "easyocr"), default="none", help="Optional OCR engine")
    parser.add_argument("--ocr-confidence", type=float, default=OCR_CONFIDENCE_THRESHOLD, help="OCR confidence below which output requires review")
    parser.add_argument("--vision-adapter", help="Optional Python adapter in module:function form; it receives an image Path and returns a dictionary")
    args = parser.parse_args()
    output_path = PDFDocumentIntelligenceSkill(
        ocr_engine=args.ocr_engine,
        vision_adapter=args.vision_adapter,
        ocr_confidence_threshold=args.ocr_confidence,
    ).process(args.pdf_path, args.output_root)
    print(output_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())