#!/usr/bin/env python3
"""Analyze, search, convert, and decode automotive CAN logs offline."""

from __future__ import annotations

import argparse
from bisect import bisect_left
import csv
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from statistics import mean as statistical_mean
from statistics import median, pstdev
from typing import Iterable, Sequence


SUPPORTED_TEXT_SUFFIXES = {".asc", ".log", ".txt"}
SUPPORTED_INPUT_SUFFIXES = SUPPORTED_TEXT_SUFFIXES | {".blf", ".csv", ".json"}

VECTOR_ASC_PATTERN = re.compile(
    r"^\s*(?P<timestamp>\d+(?:\.\d+)?)\s+"
    r"(?P<channel>\d+)\s+"
    r"(?P<can_id>[0-9A-Fa-f]+)(?P<extended>[xX]?)\s+"
    r"(?P<direction>Rx|Tx)\s+d\s+"
    r"(?P<dlc>\d+)(?:\s+(?P<data>.*?))?\s*$",
    re.IGNORECASE,
)

ARIA_CAN_PATTERN = re.compile(
    r"^\s*(?P<timestamp>\d+(?:\.\d+)?)\s+"
    r"Can(?:Fd)?\s+(?P<channel>\d+)\s+(?P<direction>RX|TX)\s+"
    r"l\s*=\s*(?P<dlc>\d+)\s*,\s*"
    r"id\s*=\s*(?P<can_id>[0-9A-Fa-f]+)\s*,?\s*(?P<data>.*?)\s*$",
    re.IGNORECASE,
)

ARIA_MESSAGE_PATTERN = re.compile(
    r"^\s*(?P<direction>RX|TX)_MSG\s*,\s*"
    r"c\s*=\s*(?P<channel>\d+)\s*,\s*"
    r"t\s*=\s*(?P<timestamp>\d+(?:\.\d+)?)\s*,\s*"
    r"id\s*=\s*(?P<can_id>[0-9A-Fa-f]+)\s*,\s*"
    r"l\s*=\s*(?P<dlc>\d+)\s*,?\s*(?P<data>.*?)\s*$",
    re.IGNORECASE,
)

DIAGNOSTIC_EXPORT_PATTERN = re.compile(
    r"^\s*(?P<timestamp>\d+(?:\.\d+)?)\s+"
    r"(?P<channel>\d+)\s+(?P<direction>Rx|Tx)\s+"
    r"(?P<can_id>(?:0[xX])?[0-9A-Fa-f]+)\s+"
    r"(?P<dlc>\d+)(?:\s+(?P<data>.*?))?\s*$",
    re.IGNORECASE,
)


class CanLogError(RuntimeError):
    """Raised when an input cannot be read or decoded safely."""


@dataclass(frozen=True)
class CanMessage:
    """A normalized CAN frame or an already-expanded diagnostic payload row."""

    timestamp: float
    channel: int
    can_id: int
    direction: str
    dlc: int
    data: tuple[int, ...]
    line_num: int
    source_format: str
    is_extended_id: bool = False


@dataclass(frozen=True)
class DiagnosticPayload:
    """A complete UDS payload derived from one or more CAN frames."""

    timestamp: float
    data: tuple[int, ...]
    frame_count: int
    source_line: int
    source_format: str


@dataclass(frozen=True)
class TimingStatistics:
    """Descriptive timing statistics for positive timestamp intervals."""

    count: int
    minimum: float
    maximum: float
    mean: float
    median: float
    standard_deviation: float


@dataclass(frozen=True)
class TimestampPair:
    """A primary/compared CAN-frame pair used for cross-ID timing evidence."""

    primary: CanMessage
    comparison: CanMessage
    delta_seconds: float


def parse_hex_number(value: str) -> int:
    """Parse a hexadecimal CAN identifier or DID supplied on the command line."""

    normalized = value.strip()
    if normalized.lower().startswith("0x"):
        normalized = normalized[2:]
    if normalized.lower().endswith("x"):
        normalized = normalized[:-1]
    if not normalized or not re.fullmatch(r"[0-9A-Fa-f]+", normalized):
        raise argparse.ArgumentTypeError(f"Expected a hexadecimal value, got '{value}'.")
    return int(normalized, 16)


def format_can_id(can_id: int, is_extended_id: bool = False) -> str:
    """Format a CAN ID consistently without changing its numeric value."""

    width = 8 if is_extended_id or can_id > 0x7FF else 3
    return f"0x{can_id:0{width}X}"


def format_data(data: Sequence[int]) -> str:
    """Render CAN data bytes as a readable uppercase hexadecimal string."""

    return " ".join(f"{byte:02X}" for byte in data)


def normalize_direction(direction: str) -> str:
    """Use one direction spelling across all supported source formats."""

    return "Rx" if direction.strip().lower() == "rx" else "Tx"


def parse_data_bytes(data_text: str, dlc: int) -> tuple[int, ...]:
    """Extract only byte tokens and respect the source row's declared payload length."""

    byte_tokens = re.findall(r"(?<![0-9A-Za-z])([0-9A-Fa-f]{2})(?![0-9A-Za-z])", data_text)
    return tuple(int(token, 16) for token in byte_tokens[:dlc])


def message_from_match(match: re.Match[str], source_format: str, line_num: int) -> CanMessage:
    """Convert one recognized text-log row into the common message representation."""

    can_id_text = match.group("can_id")
    is_extended_id = bool(match.groupdict().get("extended"))
    can_id = parse_hex_number(can_id_text)
    dlc = int(match.group("dlc"))
    if dlc < 0:
        raise ValueError("DLC cannot be negative.")

    return CanMessage(
        timestamp=float(match.group("timestamp")),
        channel=int(match.group("channel")),
        can_id=can_id,
        direction=normalize_direction(match.group("direction")),
        dlc=dlc,
        data=parse_data_bytes(match.group("data") or "", dlc),
        line_num=line_num,
        source_format=source_format,
        is_extended_id=is_extended_id,
    )


def parse_text_log(filename: Path) -> list[CanMessage]:
    """Parse Vector ASC, ARIA, and tabular diagnostic-export rows in one pass."""

    parsers = (
        ("vector-asc", VECTOR_ASC_PATTERN),
        ("aria-can", ARIA_CAN_PATTERN),
        ("aria-message", ARIA_MESSAGE_PATTERN),
        ("diagnostic-export", DIAGNOSTIC_EXPORT_PATTERN),
    )
    messages: list[CanMessage] = []

    with filename.open("r", encoding="utf-8", errors="ignore") as source_file:
        for line_num, raw_line in enumerate(source_file, 1):
            line = raw_line.strip()
            if not line:
                continue

            for source_format, pattern in parsers:
                match = pattern.match(line)
                if match is None:
                    continue
                try:
                    messages.append(message_from_match(match, source_format, line_num))
                except ValueError:
                    pass
                break

    return messages


def parse_csv_log(filename: Path) -> list[CanMessage]:
    """Read CSV files emitted by this utility for follow-on analysis or conversion."""

    messages: list[CanMessage] = []
    with filename.open("r", encoding="utf-8", newline="") as source_file:
        for row_number, row in enumerate(csv.DictReader(source_file), 2):
            try:
                messages.append(
                    CanMessage(
                        timestamp=float(row["timestamp"]),
                        channel=int(row["channel"]),
                        can_id=parse_hex_number(row["can_id"]),
                        direction=normalize_direction(row["direction"]),
                        dlc=int(row["dlc"]),
                        data=parse_data_bytes(row.get("data", ""), int(row["dlc"])),
                        line_num=int(row.get("line_num") or row_number),
                        source_format=row.get("source_format") or "csv",
                        is_extended_id=str(row.get("is_extended_id", "")).lower() == "true",
                    )
                )
            except (KeyError, TypeError, ValueError) as error:
                raise CanLogError(f"Invalid CSV row {row_number}: {error}") from error
    return messages


def parse_json_log(filename: Path) -> list[CanMessage]:
    """Read JSON files emitted by this utility for follow-on analysis or conversion."""

    try:
        document = json.loads(filename.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise CanLogError(f"Invalid JSON log: {error}") from error

    rows = document.get("messages", document) if isinstance(document, dict) else document
    if not isinstance(rows, list):
        raise CanLogError("JSON input must be a message list or contain a 'messages' list.")

    messages: list[CanMessage] = []
    for row_number, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            raise CanLogError(f"Invalid JSON message at index {row_number}.")
        try:
            data_value = row.get("data", [])
            if isinstance(data_value, str):
                data = parse_data_bytes(data_value, int(row["dlc"]))
            else:
                data = tuple(int(byte) for byte in data_value[: int(row["dlc"])])
            messages.append(
                CanMessage(
                    timestamp=float(row["timestamp"]),
                    channel=int(row["channel"]),
                    can_id=parse_hex_number(str(row["can_id"])),
                    direction=normalize_direction(str(row["direction"])),
                    dlc=int(row["dlc"]),
                    data=data,
                    line_num=int(row.get("line_num") or row_number),
                    source_format=str(row.get("source_format") or "json"),
                    is_extended_id=bool(row.get("is_extended_id", False)),
                )
            )
        except (KeyError, TypeError, ValueError) as error:
            raise CanLogError(f"Invalid JSON message at index {row_number}: {error}") from error
    return messages


def channel_as_int(channel: object) -> int:
    """Keep a numeric channel when python-can exposes a named channel."""

    if channel is None:
        return 0
    try:
        return int(channel)
    except (TypeError, ValueError):
        match = re.search(r"\d+", str(channel))
        return int(match.group()) if match else 0


def parse_blf_log(filename: Path) -> list[CanMessage]:
    """Read BLF through python-can, which preserves binary log timestamps and frames."""

    try:
        import can
    except ImportError as error:
        raise CanLogError(
            "BLF input requires python-can. Install it with: py -3.13 -m pip install python-can"
        ) from error

    messages: list[CanMessage] = []
    try:
        with can.BLFReader(str(filename)) as reader:
            for frame_number, message in enumerate(reader, 1):
                messages.append(
                    CanMessage(
                        timestamp=float(message.timestamp or 0.0),
                        channel=channel_as_int(message.channel),
                        can_id=int(message.arbitration_id),
                        direction="Rx" if message.is_rx else "Tx",
                        dlc=int(message.dlc),
                        data=tuple(message.data),
                        line_num=frame_number,
                        source_format="blf",
                        is_extended_id=bool(message.is_extended_id),
                    )
                )
    except (OSError, ValueError) as error:
        raise CanLogError(f"Could not read BLF file '{filename}': {error}") from error
    return messages


def load_messages(filename: Path) -> list[CanMessage]:
    """Load a supported log format and fail with a useful error for empty parses."""

    if not filename.is_file():
        raise CanLogError(f"Input file was not found: {filename}")

    suffix = filename.suffix.lower()
    if suffix == ".blf":
        messages = parse_blf_log(filename)
    elif suffix == ".csv":
        messages = parse_csv_log(filename)
    elif suffix == ".json":
        messages = parse_json_log(filename)
    elif suffix in SUPPORTED_TEXT_SUFFIXES:
        messages = parse_text_log(filename)
    else:
        supported = ", ".join(sorted(SUPPORTED_INPUT_SUFFIXES))
        raise CanLogError(f"Unsupported input '{suffix}'. Supported extensions: {supported}")

    if not messages:
        raise CanLogError(
            "No CAN rows were recognized. Supported text layouts are Vector ASC, ARIA 'Can', "
            "ARIA RX_MSG/TX_MSG, and tabular diagnostic exports."
        )
    return messages


def filter_messages(
    messages: Iterable[CanMessage],
    *,
    can_id: int | None = None,
    direction: str | None = None,
    channel: int | None = None,
    start_time: float | None = None,
    end_time: float | None = None,
) -> list[CanMessage]:
    """Apply common passive filters without mutating the original log data."""

    normalized_direction = normalize_direction(direction) if direction else None
    filtered: list[CanMessage] = []
    for message in messages:
        if can_id is not None and message.can_id != can_id:
            continue
        if normalized_direction and message.direction != normalized_direction:
            continue
        if channel is not None and message.channel != channel:
            continue
        if start_time is not None and message.timestamp < start_time:
            continue
        if end_time is not None and message.timestamp > end_time:
            continue
        filtered.append(message)
    return filtered


def parse_byte_pattern(value: str) -> tuple[int | None, ...]:
    """Parse a byte sequence where ?? is a single-byte wildcard."""

    tokens = [token for token in re.split(r"[\s,:-]+", value.strip()) if token]
    if not tokens:
        raise argparse.ArgumentTypeError("Byte pattern cannot be empty.")

    pattern: list[int | None] = []
    for token in tokens:
        if token in {"??", "**", "xx", "XX"}:
            pattern.append(None)
        elif re.fullmatch(r"[0-9A-Fa-f]{2}", token):
            pattern.append(int(token, 16))
        else:
            raise argparse.ArgumentTypeError(
                f"Invalid byte token '{token}'. Use two hex digits or ??."
            )
    return tuple(pattern)


def find_pattern_offsets(
    data: Sequence[int], pattern: Sequence[int | None], byte_offset: int | None = None
) -> list[int]:
    """Return every payload offset where the requested byte pattern matches."""

    if len(pattern) > len(data):
        return []
    candidate_offsets = [byte_offset] if byte_offset is not None else range(len(data) - len(pattern) + 1)
    offsets: list[int] = []
    for offset in candidate_offsets:
        if offset is None or offset < 0 or offset + len(pattern) > len(data):
            continue
        if all(expected is None or data[offset + index] == expected for index, expected in enumerate(pattern)):
            offsets.append(offset)
    return offsets


def search_messages(
    messages: Iterable[CanMessage],
    *,
    can_id: int | None = None,
    byte_pattern: Sequence[int | None] | None = None,
    byte_offset: int | None = None,
    direction: str | None = None,
    channel: int | None = None,
    start_time: float | None = None,
    end_time: float | None = None,
) -> list[tuple[CanMessage, list[int]]]:
    """Find matching CAN frames and record the byte position of each pattern match."""

    results: list[tuple[CanMessage, list[int]]] = []
    for message in filter_messages(
        messages,
        can_id=can_id,
        direction=direction,
        channel=channel,
        start_time=start_time,
        end_time=end_time,
    ):
        offsets = find_pattern_offsets(message.data, byte_pattern, byte_offset) if byte_pattern else []
        if byte_pattern and not offsets:
            continue
        results.append((message, offsets))
    return results


def is_direct_uds_payload(data: Sequence[int]) -> bool:
    """Identify an already-expanded UDS response rather than an ISO-TP PCI frame."""

    return bool(data) and 0x40 <= data[0] <= 0x7F


def extract_diagnostic_payloads(
    messages: Iterable[CanMessage], response_id: int
) -> list[DiagnosticPayload]:
    """Extract direct UDS rows and complete ISO-TP responses for one response CAN ID."""

    payloads: list[DiagnosticPayload] = []
    current_data: list[int] | None = None
    current_length = 0
    current_timestamp = 0.0
    current_line = 0
    current_format = ""
    current_frames = 0
    expected_sequence_number = 1

    for message in messages:
        if message.can_id != response_id or not message.data:
            continue

        data = message.data
        if is_direct_uds_payload(data):
            payloads.append(
                DiagnosticPayload(
                    timestamp=message.timestamp,
                    data=data,
                    frame_count=1,
                    source_line=message.line_num,
                    source_format=message.source_format,
                )
            )
            current_data = None
            continue

        pci_type = (data[0] >> 4) & 0x0F
        if pci_type == 0:
            payload_length = data[0] & 0x0F
            if 0 < payload_length <= 7 and len(data) >= payload_length + 1:
                payloads.append(
                    DiagnosticPayload(
                        timestamp=message.timestamp,
                        data=tuple(data[1 : payload_length + 1]),
                        frame_count=1,
                        source_line=message.line_num,
                        source_format=message.source_format,
                    )
                )
            current_data = None
        elif pci_type == 1 and len(data) >= 2:
            current_length = ((data[0] & 0x0F) << 8) | data[1]
            current_data = list(data[2:])
            current_timestamp = message.timestamp
            current_line = message.line_num
            current_format = message.source_format
            current_frames = 1
            expected_sequence_number = 1
            if len(current_data) >= current_length:
                payloads.append(
                    DiagnosticPayload(
                        timestamp=current_timestamp,
                        data=tuple(current_data[:current_length]),
                        frame_count=current_frames,
                        source_line=current_line,
                        source_format=current_format,
                    )
                )
                current_data = None
        elif pci_type == 2 and current_data is not None:
            sequence_number = data[0] & 0x0F
            if sequence_number != expected_sequence_number:
                current_data = None
                continue

            current_data.extend(data[1:])
            current_frames += 1
            expected_sequence_number = (expected_sequence_number + 1) & 0x0F
            if len(current_data) >= current_length:
                payloads.append(
                    DiagnosticPayload(
                        timestamp=current_timestamp,
                        data=tuple(current_data[:current_length]),
                        frame_count=current_frames,
                        source_line=current_line,
                        source_format=current_format,
                    )
                )
                current_data = None

    return payloads


def filter_did_responses(
    payloads: Iterable[DiagnosticPayload], did: int
) -> list[DiagnosticPayload]:
    """Keep positive ReadDataByIdentifier responses for the requested DID."""

    did_high = (did >> 8) & 0xFF
    did_low = did & 0xFF
    return [
        payload
        for payload in payloads
        if len(payload.data) >= 3
        and payload.data[0] == 0x62
        and payload.data[1] == did_high
        and payload.data[2] == did_low
    ]


def filter_edr_responses(
    payloads: Iterable[DiagnosticPayload], edr_did: int
) -> list[DiagnosticPayload]:
    """Keep the EDR-specific public helper while sharing generic DID matching."""

    return filter_did_responses(payloads, edr_did)


def format_hex_dump(data: Sequence[int], bytes_per_line: int = 16) -> str:
    """Format byte data with offsets and printable ASCII for EDR inspection."""

    lines: list[str] = []
    for offset in range(0, len(data), bytes_per_line):
        chunk = data[offset : offset + bytes_per_line]
        hex_data = format_data(chunk).ljust(bytes_per_line * 3 - 1)
        ascii_data = "".join(chr(byte) if 32 <= byte <= 126 else "." for byte in chunk)
        lines.append(f"  {offset:04X}: {hex_data}  |{ascii_data}|")
    return "\n".join(lines)


def render_edr_report(
    source_file: Path,
    response_id: int,
    edr_did: int,
    edr_responses: Sequence[DiagnosticPayload],
) -> str:
    """Build an auditable EDR extraction report with transport provenance."""

    lines = [
        "=" * 80,
        "EDR RESPONSE EXTRACTION REPORT",
        f"Input file: {source_file}",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 80,
        f"Response CAN ID: {format_can_id(response_id)}",
        f"EDR DID: 0x{edr_did:04X}",
        f"EDR responses found: {len(edr_responses)}",
        "",
    ]

    for index, payload in enumerate(edr_responses, 1):
        edr_data = payload.data[3:]
        lines.extend(
            [
                "-" * 80,
                f"EDR RESPONSE #{index}",
                "-" * 80,
                f"Timestamp: {payload.timestamp:.6f} seconds",
                f"Source line/frame: {payload.source_line}",
                f"Source format: {payload.source_format}",
                f"ISO-TP frames used: {payload.frame_count}",
                f"Diagnostic data length: {len(payload.data)} bytes",
                f"EDR payload length: {len(edr_data)} bytes",
                "",
                "Diagnostic response hex dump:",
                format_hex_dump(payload.data),
                "",
                f"Raw diagnostic response: {format_data(payload.data)}",
                f"EDR bytes (without 62 {edr_did >> 8:02X} {edr_did & 0xFF:02X}): {format_data(edr_data)}",
                "",
            ]
        )

    lines.extend(["=" * 80, "SUMMARY", "=" * 80])
    if edr_responses:
        lines.extend(["#    Timestamp        Length  Frames  Source line"])
        for index, payload in enumerate(edr_responses, 1):
            lines.append(
                f"{index:<4} {payload.timestamp:<16.6f} {len(payload.data):<7} "
                f"{payload.frame_count:<7} {payload.source_line}"
            )
    else:
        lines.append("No positive 0x62 response for the requested EDR DID was found.")
    return "\n".join(lines)


def render_did_report(
    source_file: Path,
    response_id: int,
    did: int,
    did_responses: Sequence[DiagnosticPayload],
) -> str:
    """Build a generic ReadDataByIdentifier extraction report with source provenance."""

    lines = [
        "=" * 80,
        "DID RESPONSE EXTRACTION REPORT",
        f"Input file: {source_file}",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 80,
        f"Response CAN ID: {format_can_id(response_id)}",
        f"DID: 0x{did:04X}",
        f"DID responses found: {len(did_responses)}",
        "",
    ]

    for index, response in enumerate(did_responses, 1):
        did_data = response.data[3:]
        lines.extend(
            [
                "-" * 80,
                f"DID RESPONSE #{index}",
                "-" * 80,
                f"Timestamp: {response.timestamp:.6f} seconds",
                f"Source line/frame: {response.source_line}",
                f"Source format: {response.source_format}",
                f"ISO-TP frames used: {response.frame_count}",
                f"Diagnostic data length: {len(response.data)} bytes",
                f"DID payload length: {len(did_data)} bytes",
                "",
                "Diagnostic response hex dump:",
                format_hex_dump(response.data),
                "",
                f"Raw diagnostic response: {format_data(response.data)}",
                f"DID bytes (without 62 {did >> 8:02X} {did & 0xFF:02X}): {format_data(did_data)}",
                "",
            ]
        )

    lines.extend(["=" * 80, "SUMMARY", "=" * 80])
    if did_responses:
        lines.append("#    Timestamp        Length  Frames  Source line")
        for index, response in enumerate(did_responses, 1):
            lines.append(
                f"{index:<4} {response.timestamp:<16.6f} {len(response.data):<7} "
                f"{response.frame_count:<7} {response.source_line}"
            )
    else:
        lines.append("No positive 0x62 response for the requested DID was found.")
    return "\n".join(lines)


def render_summary(messages: Sequence[CanMessage], max_ids: int) -> str:
    """Create a compact passive traffic inventory for a parsed log."""

    id_counts = Counter(message.can_id for message in messages)
    direction_counts = Counter(message.direction for message in messages)
    source_counts = Counter(message.source_format for message in messages)
    channels = sorted({message.channel for message in messages})
    timestamps = [message.timestamp for message in messages]

    lines = [
        "CAN LOG SUMMARY",
        "=" * 80,
        f"Messages parsed: {len(messages)}",
        f"Time range: {min(timestamps):.6f} to {max(timestamps):.6f} seconds",
        f"Channels: {', '.join(str(channel) for channel in channels)}",
        f"Directions: Rx={direction_counts['Rx']}, Tx={direction_counts['Tx']}",
        "Source formats: " + ", ".join(f"{name}={count}" for name, count in sorted(source_counts.items())),
        f"Unique CAN IDs: {len(id_counts)}",
        "",
        "CAN ID            Frames  Rx     Tx     DLC values",
        "-" * 80,
    ]

    for can_id, count in id_counts.most_common(max_ids):
        id_messages = [message for message in messages if message.can_id == can_id]
        id_directions = Counter(message.direction for message in id_messages)
        dlc_values = ",".join(str(value) for value in sorted({message.dlc for message in id_messages}))
        lines.append(
            f"{format_can_id(can_id):<17} {count:<7} {id_directions['Rx']:<6} "
            f"{id_directions['Tx']:<6} {dlc_values}"
        )
    if len(id_counts) > max_ids:
        lines.append(f"... {len(id_counts) - max_ids} additional CAN IDs omitted; raise --max-ids to list them.")
    return "\n".join(lines)


def render_search_report(
    source_file: Path,
    results: Sequence[tuple[CanMessage, list[int]]],
    total_matches: int,
) -> str:
    """Show matching frames with source positions and byte-pattern offsets."""

    lines = [
        "CAN LOG SEARCH RESULTS",
        "=" * 80,
        f"Input file: {source_file}",
        f"Matches: {total_matches}",
        f"Rows shown: {len(results)}",
        "",
    ]
    for index, (message, offsets) in enumerate(results, 1):
        byte_offsets = ", ".join(str(offset) for offset in offsets) if offsets else "n/a"
        lines.extend(
            [
                f"#{index}: {message.timestamp:.6f}s  ch={message.channel}  {message.direction}  "
                f"id={format_can_id(message.can_id, message.is_extended_id)}  dlc={message.dlc}",
                f"    Source line/frame: {message.line_num} ({message.source_format})",
                f"    Match byte offset(s): {byte_offsets}",
                f"    Data: {format_data(message.data)}",
            ]
        )
    return "\n".join(lines)


def isotp_frame_kind(data: Sequence[int]) -> str:
    """Classify a standard ISO-TP PCI frame or an already-expanded UDS payload row."""

    if not data:
        return "Empty"
    if is_direct_uds_payload(data):
        return "Direct UDS"
    return {
        0: "Single Frame",
        1: "First Frame",
        2: "Consecutive Frame",
        3: "Flow Control",
    }.get((data[0] >> 4) & 0x0F, "Unknown PCI")


def format_isotp_stmin(stmin: int) -> str:
    """Explain ISO-TP STmin encoding without assigning a meaning to reserved values."""

    if 0 <= stmin <= 0x7F:
        return f"{stmin} ms"
    if 0xF1 <= stmin <= 0xF9:
        return f"{(stmin - 0xF0) * 100} us"
    return f"reserved code 0x{stmin:02X}"


def describe_isotp_frame(message: CanMessage) -> str:
    """Render transport-control fields and payload bytes for a recorded ISO-TP frame."""

    data = message.data
    kind = isotp_frame_kind(data)
    if kind == "Empty":
        return "no payload bytes"
    if kind == "Direct UDS":
        return f"already-expanded UDS payload: {format_data(data)}"
    if kind == "Single Frame":
        length = data[0] & 0x0F
        return f"payload length={length}; payload={format_data(data[1 : 1 + length])}"
    if kind == "First Frame":
        if len(data) < 2:
            return "incomplete first frame: missing total payload length byte"
        length = ((data[0] & 0x0F) << 8) | data[1]
        return f"total payload length={length}; initial payload={format_data(data[2:])}"
    if kind == "Consecutive Frame":
        return f"sequence number={data[0] & 0x0F}; payload={format_data(data[1:])}"
    if kind == "Flow Control":
        if len(data) < 3:
            return "incomplete flow-control frame: requires flow status, block size, and STmin"
        flow_status = {
            0x0: "Continue To Send",
            0x1: "Wait",
            0x2: "Overflow/Abort",
        }.get(data[0] & 0x0F, f"reserved status 0x{data[0] & 0x0F:X}")
        return (
            f"flow status={flow_status}; block size={data[1]}; "
            f"STmin={format_isotp_stmin(data[2])}; raw={format_data(data)}"
        )
    return f"PCI byte=0x{data[0]:02X}; raw={format_data(data)}"


def render_isotp_timeline(
    source_file: Path,
    messages: Sequence[CanMessage],
    data_id: int,
    flow_control_id: int | None,
    max_rows: int,
) -> str:
    """Report ISO-TP data and flow-control frames with source-order timing evidence."""

    selected_ids = {data_id}
    if flow_control_id is not None:
        selected_ids.add(flow_control_id)
    selected_messages = [message for message in messages if message.can_id in selected_ids]
    data_messages = [message for message in selected_messages if message.can_id == data_id]
    first_frames = [message for message in data_messages if isotp_frame_kind(message.data) == "First Frame"]
    flow_control_messages = [
        message
        for message in selected_messages
        if isotp_frame_kind(message.data) == "Flow Control"
        and (flow_control_id is None or message.can_id == flow_control_id)
    ]
    first_to_flow_control_pairs: list[TimestampPair] = []
    if flow_control_id is not None:
        pairing_messages = [
            message
            for message in selected_messages
            if message.can_id == data_id or message in flow_control_messages
        ]
        first_to_flow_control_pairs = [
            pair
            for pair in pair_cross_id_timestamps(pairing_messages, data_id, flow_control_id, "next")
            if isotp_frame_kind(pair.primary.data) == "First Frame"
        ]

    lines = [
        "ISO-TP TRANSPORT TIMELINE REPORT",
        "=" * 80,
        f"Input file: {source_file}",
        f"Data CAN ID: {format_can_id(data_id)}",
        f"Flow-control CAN ID: {format_can_id(flow_control_id) if flow_control_id is not None else 'not supplied'}",
        f"Selected transport frames: {len(selected_messages)}",
        f"First frames on data CAN ID: {len(first_frames)}",
        f"Flow-control frames observed: {len(flow_control_messages)}",
        f"Capture timestamp segments: {len(split_timestamp_segments(selected_messages))}",
        "",
        "Transport frames (capture order):",
    ]

    for index, message in enumerate(selected_messages[:max_rows], 1):
        lines.extend(
            [
                f"  #{index}: {message.timestamp:.6f}s  line/frame {message.line_num}  "
                f"{message.direction}  {format_can_id(message.can_id, message.is_extended_id)}  "
                f"{isotp_frame_kind(message.data)}",
                f"      {describe_isotp_frame(message)}",
            ]
        )
    if len(selected_messages) > max_rows:
        lines.append(f"  ... {len(selected_messages) - max_rows} additional transport frame(s) omitted.")

    if flow_control_id is not None:
        pair_deltas = [pair.delta_seconds for pair in first_to_flow_control_pairs]
        lines.extend(
            [
                "",
                "=" * 80,
                "First-frame to next flow-control timing:",
                f"Pairs: {len(first_to_flow_control_pairs)} of {len(first_frames)} first frame(s)",
            ]
        )
        lines.extend(timing_statistics_lines("First Frame -> next Flow Control", pair_deltas))
        for index, pair in enumerate(first_to_flow_control_pairs[:max_rows], 1):
            lines.append(
                f"  #{index}: first frame line/frame {pair.primary.line_num} ({pair.primary.timestamp:.6f}s) -> "
                f"flow control {pair.comparison.line_num} ({pair.comparison.timestamp:.6f}s) = "
                f"{pair.delta_seconds * 1000:.3f} ms"
            )
        if len(first_to_flow_control_pairs) > max_rows:
            lines.append(f"  ... {len(first_to_flow_control_pairs) - max_rows} additional pair(s) omitted.")
    else:
        lines.append("\nProvide --flow-control-id to pair first frames with opposite-direction flow-control frames.")
    return "\n".join(lines)


def calculate_timing_statistics(deltas: Sequence[float]) -> TimingStatistics | None:
    """Calculate statistics only when at least one forward timestamp delta exists."""

    if not deltas:
        return None
    return TimingStatistics(
        count=len(deltas),
        minimum=min(deltas),
        maximum=max(deltas),
        mean=statistical_mean(deltas),
        median=median(deltas),
        standard_deviation=pstdev(deltas),
    )


def consecutive_timing(
    messages: Sequence[CanMessage],
) -> tuple[list[tuple[CanMessage, CanMessage, float]], list[float]]:
    """Preserve capture order while calculating adjacent timestamp differences."""

    transitions: list[tuple[CanMessage, CanMessage, float]] = []
    positive_deltas: list[float] = []
    for previous, current in zip(messages, messages[1:]):
        delta = current.timestamp - previous.timestamp
        transitions.append((previous, current, delta))
        if delta > 0:
            positive_deltas.append(delta)
    return transitions, positive_deltas


def split_timestamp_segments(messages: Sequence[CanMessage]) -> list[list[CanMessage]]:
    """Keep cross-ID pairing within capture segments separated by timestamp resets."""

    if not messages:
        return []
    segments: list[list[CanMessage]] = [[]]
    previous_timestamp: float | None = None
    for message in messages:
        if previous_timestamp is not None and message.timestamp < previous_timestamp:
            segments.append([])
        segments[-1].append(message)
        previous_timestamp = message.timestamp
    return segments


def pair_cross_id_timestamps(
    messages: Sequence[CanMessage],
    primary_id: int,
    comparison_id: int,
    pairing: str,
) -> list[TimestampPair]:
    """Pair IDs within each monotonic capture segment using a documented timestamp rule."""

    pairs: list[TimestampPair] = []
    for segment in split_timestamp_segments(messages):
        primary_messages = [message for message in segment if message.can_id == primary_id]
        comparison_messages = [message for message in segment if message.can_id == comparison_id]
        comparison_timestamps = [message.timestamp for message in comparison_messages]

        for primary in primary_messages:
            index = bisect_left(comparison_timestamps, primary.timestamp)
            if pairing == "next":
                if index >= len(comparison_messages):
                    continue
                comparison = comparison_messages[index]
            else:
                candidates = comparison_messages[max(0, index - 1) : index + 1]
                if not candidates:
                    continue
                comparison = min(
                    candidates,
                    key=lambda candidate: (
                        abs(candidate.timestamp - primary.timestamp),
                        candidate.timestamp < primary.timestamp,
                    ),
                )
            pairs.append(
                TimestampPair(
                    primary=primary,
                    comparison=comparison,
                    delta_seconds=comparison.timestamp - primary.timestamp,
                )
            )
    return pairs


def timing_statistics_lines(label: str, deltas: Sequence[float]) -> list[str]:
    """Render timing metrics in milliseconds for test reports."""

    statistics = calculate_timing_statistics(deltas)
    if statistics is None:
        return [f"{label}: no positive timestamp intervals available."]
    return [
        f"{label}: count={statistics.count}",
        f"  Minimum: {statistics.minimum * 1000:.3f} ms",
        f"  Mean: {statistics.mean * 1000:.3f} ms",
        f"  Median: {statistics.median * 1000:.3f} ms",
        f"  Maximum: {statistics.maximum * 1000:.3f} ms",
        f"  Population standard deviation: {statistics.standard_deviation * 1000:.3f} ms",
    ]


def render_timing_report(
    source_file: Path,
    filtered_messages: Sequence[CanMessage],
    primary_id: int,
    comparison_id: int | None,
    pairing: str,
    expected_period_ms: float | None,
    max_rows: int,
) -> str:
    """Report inter-frame timing and optional cross-ID timestamp deltas with provenance."""

    primary_messages = [message for message in filtered_messages if message.can_id == primary_id]
    primary_transitions, primary_positive_deltas = consecutive_timing(primary_messages)
    primary_non_forward = [transition for transition in primary_transitions if transition[2] <= 0]
    timestamp_segments = split_timestamp_segments(filtered_messages)
    lines = [
        "CAN TIMING ANALYSIS REPORT",
        "=" * 80,
        f"Input file: {source_file}",
        f"Primary CAN ID: {format_can_id(primary_id)}",
        f"Primary frames: {len(primary_messages)}",
        f"Capture timestamp segments: {len(timestamp_segments)}",
        f"Non-forward primary transitions: {len(primary_non_forward)}",
        "",
    ]
    lines.extend(timing_statistics_lines(f"Primary intervals for {format_can_id(primary_id)}", primary_positive_deltas))

    if expected_period_ms is not None and primary_positive_deltas:
        expected_seconds = expected_period_ms / 1000
        deviations = [delta - expected_seconds for delta in primary_positive_deltas]
        lines.extend(
            [
                f"Expected period: {expected_period_ms:.3f} ms",
                f"Mean period error: {statistical_mean(deviations) * 1000:.3f} ms",
                f"Maximum absolute period error: {max(abs(deviation) for deviation in deviations) * 1000:.3f} ms",
            ]
        )

    lines.extend(["", "Primary transitions (capture order):"])
    for index, (previous, current, delta) in enumerate(primary_transitions[:max_rows], 1):
        status = "forward" if delta > 0 else "non-forward/reset"
        lines.append(
            f"  #{index}: line/frame {previous.line_num} ({previous.timestamp:.6f}s) -> "
            f"{current.line_num} ({current.timestamp:.6f}s) = {delta * 1000:.3f} ms [{status}]"
        )
    if len(primary_transitions) > max_rows:
        lines.append(f"  ... {len(primary_transitions) - max_rows} additional primary transitions omitted.")

    if comparison_id is not None:
        comparison_messages = [message for message in filtered_messages if message.can_id == comparison_id]
        comparison_transitions, comparison_positive_deltas = consecutive_timing(comparison_messages)
        pairs = pair_cross_id_timestamps(filtered_messages, primary_id, comparison_id, pairing)
        pair_deltas = [pair.delta_seconds for pair in pairs]
        pairing_description = (
            "first comparison timestamp at or after each primary timestamp"
            if pairing == "next"
            else "closest comparison timestamp to each primary timestamp; ties choose the later frame"
        )
        lines.extend(
            [
                "",
                "=" * 80,
                f"Comparison CAN ID: {format_can_id(comparison_id)}",
                f"Comparison frames: {len(comparison_messages)}",
            ]
        )
        lines.extend(timing_statistics_lines(f"Comparison intervals for {format_can_id(comparison_id)}", comparison_positive_deltas))
        lines.extend(
            [
                f"Cross-ID pairing: {pairing_description}",
                f"Cross-ID pairs: {len(pairs)} of {len(primary_messages)} primary frame(s)",
            ]
        )
        lines.extend(
            timing_statistics_lines(
                f"Cross-ID delta ({format_can_id(comparison_id)} - {format_can_id(primary_id)})",
                pair_deltas,
            )
        )
        lines.append("Cross-ID timestamp pairs:")
        for index, pair in enumerate(pairs[:max_rows], 1):
            lines.append(
                f"  #{index}: primary line/frame {pair.primary.line_num} ({pair.primary.timestamp:.6f}s) -> "
                f"comparison {pair.comparison.line_num} ({pair.comparison.timestamp:.6f}s) = "
                f"{pair.delta_seconds * 1000:.3f} ms"
            )
        if len(pairs) > max_rows:
            lines.append(f"  ... {len(pairs) - max_rows} additional cross-ID pairs omitted.")

    return "\n".join(lines)


def signal_bit_positions(signal: object) -> list[int]:
    """Map a cantools signal to physical DBC bit positions for byte provenance."""

    start = int(getattr(signal, "start"))
    length = int(getattr(signal, "length"))
    if getattr(signal, "byte_order") == "little_endian":
        return list(range(start, start + length))

    positions: list[int] = []
    position = start
    for _ in range(length):
        positions.append(position)
        position = position + 15 if position % 8 == 0 else position - 1
    return positions


def describe_signal_layout(
    signal: object,
    data: Sequence[int],
    *,
    byte_label: str = "byte",
    diagnostic_byte_offset: int = 0,
) -> str:
    """Provide the DBC-derived byte, bit, encoding, and scale provenance of a signal."""

    byte_indices = sorted({position // 8 for position in signal_bit_positions(signal) if position >= 0})
    source_bytes = []
    for index in byte_indices:
        if index >= len(data):
            continue
        description = f"{byte_label} {index}=0x{data[index]:02X}"
        if diagnostic_byte_offset:
            description += f" (diagnostic byte {index + diagnostic_byte_offset})"
        source_bytes.append(description)
    byte_order = "Intel/little-endian" if getattr(signal, "byte_order") == "little_endian" else "Motorola/big-endian"
    signedness = "signed" if getattr(signal, "is_signed") else "unsigned"
    unit = getattr(signal, "unit") or "-"
    return (
        f"start bit {getattr(signal, 'start')}, length {getattr(signal, 'length')} bits, "
        f"{byte_order}, {signedness}, factor {getattr(signal, 'scale')}, "
        f"offset {getattr(signal, 'offset')}, unit {unit}; {', '.join(source_bytes) or 'outside available payload'}"
    )


def find_dbc_message(database: object, can_id: int) -> object | None:
    """Look up one DBC message without treating an absent ID as a decoding failure."""

    try:
        return database.get_message_by_frame_id(can_id)
    except KeyError:
        return None


def load_dbc_database(dbc_file: Path) -> object:
    """Load a DBC through cantools and provide an actionable dependency error."""

    try:
        import cantools
    except ImportError as error:
        raise CanLogError(
            "DBC decoding requires cantools. Install it with: py -3.13 -m pip install cantools"
        ) from error

    try:
        return cantools.database.load_file(str(dbc_file))
    except (OSError, ValueError) as error:
        raise CanLogError(f"Could not load DBC file '{dbc_file}': {error}") from error


def find_dbc_message_by_name(database: object, message_name: str) -> object:
    """Look up an explicitly selected DBC layout for a diagnostic DID payload."""

    try:
        return database.get_message_by_name(message_name)
    except KeyError as error:
        raise CanLogError(f"DBC message '{message_name}' was not found in the supplied DBC.") from error


def decode_dbc_values(dbc_message: object, data: Sequence[int]) -> tuple[dict[str, object], dict[str, object]]:
    """Decode both physical and raw signal values from the exact supplied bytes."""

    try:
        physical_values = dbc_message.decode(bytes(data), decode_choices=True, scaling=True)
        raw_values = dbc_message.decode(bytes(data), decode_choices=False, scaling=False)
    except (ValueError, TypeError) as error:
        raise CanLogError(str(error)) from error
    return physical_values, raw_values


def decode_with_dbc(
    messages: Sequence[CanMessage], dbc_file: Path, max_frames: int
) -> str:
    """Decode frames through cantools and retain raw-byte/bit-level DBC provenance."""

    database = load_dbc_database(dbc_file)

    rendered = 0
    skipped_without_dbc = 0
    lines = [
        "DBC DECODE REPORT",
        "=" * 80,
        f"DBC: {dbc_file}",
        f"Candidate frames: {len(messages)}",
        "",
    ]

    for message in messages:
        dbc_message = find_dbc_message(database, message.can_id)
        if dbc_message is None:
            skipped_without_dbc += 1
            continue
        if rendered >= max_frames:
            break

        rendered += 1
        lines.extend(
            [
                "-" * 80,
                f"Frame #{rendered}: {message.timestamp:.6f}s  ch={message.channel}  {message.direction}",
                f"Source line/frame: {message.line_num} ({message.source_format})",
                f"CAN: {format_can_id(message.can_id, message.is_extended_id)}  "
                f"DBC message: {dbc_message.name}  DLC: {message.dlc}",
                "Bytes: " + "  ".join(f"[{index}]={byte:02X}" for index, byte in enumerate(message.data)),
                "Bits:  " + "  ".join(f"[{index}]={byte:08b}" for index, byte in enumerate(message.data)),
            ]
        )

        try:
            physical_values, raw_values = decode_dbc_values(dbc_message, message.data)
        except CanLogError as error:
            lines.append(f"Decode status: unable to decode this frame: {error}")
            continue

        lines.append("Signals:")
        for signal in dbc_message.signals:
            physical_value = physical_values.get(signal.name, "not active/decoded")
            raw_value = raw_values.get(signal.name, "not active/decoded")
            lines.append(f"  {signal.name}: physical={physical_value}; raw={raw_value}")
            lines.append(f"    {describe_signal_layout(signal, message.data)}")

    lines.extend(
        [
            "",
            "=" * 80,
            f"Frames decoded: {rendered}",
            f"Frames without a matching DBC message: {skipped_without_dbc}",
        ]
    )
    if rendered == max_frames and len(messages) > rendered:
        lines.append(f"Output limited to {max_frames} decoded frame(s); raise --limit to render more.")
    return "\n".join(lines)


def decode_did_with_dbc(
    source_file: Path,
    response_id: int,
    did: int,
    did_responses: Sequence[DiagnosticPayload],
    dbc_file: Path,
    dbc_message_name: str,
    max_responses: int,
    include_uds_header: bool,
) -> str:
    """Decode a DID response against an explicit DBC payload layout."""

    database = load_dbc_database(dbc_file)
    dbc_message = find_dbc_message_by_name(database, dbc_message_name)
    byte_label = "UDS response byte" if include_uds_header else "DID payload byte"
    diagnostic_byte_offset = 0 if include_uds_header else 3
    lines = [
        "DID DBC DECODE REPORT",
        "=" * 80,
        f"Input file: {source_file}",
        f"Response CAN ID: {format_can_id(response_id)}",
        f"DID: 0x{did:04X}",
        f"DBC: {dbc_file}",
        f"DBC payload message: {dbc_message.name}",
        f"Data passed to DBC: {'full UDS response' if include_uds_header else 'DID payload without 62/DID header'}",
        f"DID responses found: {len(did_responses)}",
        "",
    ]

    for index, response in enumerate(did_responses[:max_responses], 1):
        data = response.data if include_uds_header else response.data[3:]
        lines.extend(
            [
                "-" * 80,
                f"DID RESPONSE #{index}: {response.timestamp:.6f}s  source line/frame={response.source_line}",
                f"Source format: {response.source_format}  ISO-TP frames used: {response.frame_count}",
                "Full UDS response: " + "  ".join(f"[{byte_index}]={byte:02X}" for byte_index, byte in enumerate(response.data)),
                f"{byte_label.title()}s: " + "  ".join(f"[{byte_index}]={byte:02X}" for byte_index, byte in enumerate(data)),
            ]
        )

        try:
            physical_values, raw_values = decode_dbc_values(dbc_message, data)
        except CanLogError as error:
            lines.append(f"Decode status: unable to decode this DID response: {error}")
            continue

        lines.append("Signals:")
        for signal in dbc_message.signals:
            physical_value = physical_values.get(signal.name, "not active/decoded")
            raw_value = raw_values.get(signal.name, "not active/decoded")
            lines.append(f"  {signal.name}: physical={physical_value}; raw={raw_value}")
            lines.append(
                "    "
                + describe_signal_layout(
                    signal,
                    data,
                    byte_label=byte_label,
                    diagnostic_byte_offset=diagnostic_byte_offset,
                )
            )

    lines.extend(["", "=" * 80, f"DID responses decoded: {min(len(did_responses), max_responses)}"])
    if len(did_responses) > max_responses:
        lines.append(f"Output limited to {max_responses} DID response(s); raise --limit to render more.")
    return "\n".join(lines)


def write_asc(messages: Sequence[CanMessage], output_file: Path) -> None:
    """Write normalized Vector-ASC-compatible text without external conversion tools."""

    header = [
        f"date {datetime.now().strftime('%a %b %d %H:%M:%S.%f %Y')}",
        "base hex  timestamps absolute",
        "no internal events logged",
        "// Generated by can_log_analyzer.py",
    ]
    rows = []
    for message in messages:
        can_id = f"{message.can_id:X}{'x' if message.is_extended_id else ''}"
        data = format_data(message.data)
        rows.append(
            f"{message.timestamp:.6f} {message.channel} {can_id} {message.direction} d {message.dlc} {data}".rstrip()
        )
    output_file.write_text("\n".join(header + rows) + "\n", encoding="utf-8")


def write_aria_log(messages: Sequence[CanMessage], output_file: Path) -> None:
    """Write normalized ARIA RX_MSG/TX_MSG records for text-log interchange."""

    rows = []
    for message in messages:
        width = 8 if message.is_extended_id or message.can_id > 0x7FF else 4
        rows.append(
            f"{message.direction.upper()}_MSG, c={message.channel}, t={message.timestamp:.6f}, "
            f"id={message.can_id:0{width}X}, l={message.dlc}, {format_data(message.data)}".rstrip()
        )
    output_file.write_text("\n".join(rows) + "\n", encoding="utf-8")


def write_csv(messages: Sequence[CanMessage], output_file: Path) -> None:
    """Write a stable tabular interchange format with source provenance."""

    with output_file.open("w", encoding="utf-8", newline="") as destination:
        writer = csv.DictWriter(
            destination,
            fieldnames=[
                "timestamp",
                "channel",
                "direction",
                "can_id",
                "dlc",
                "data",
                "is_extended_id",
                "source_format",
                "line_num",
            ],
        )
        writer.writeheader()
        for message in messages:
            writer.writerow(
                {
                    "timestamp": f"{message.timestamp:.6f}",
                    "channel": message.channel,
                    "direction": message.direction,
                    "can_id": format_can_id(message.can_id, message.is_extended_id),
                    "dlc": message.dlc,
                    "data": format_data(message.data),
                    "is_extended_id": message.is_extended_id,
                    "source_format": message.source_format,
                    "line_num": message.line_num,
                }
            )


def write_json(messages: Sequence[CanMessage], output_file: Path) -> None:
    """Write a self-describing JSON interchange format."""

    document = {
        "messages": [
            {
                "timestamp": message.timestamp,
                "channel": message.channel,
                "direction": message.direction,
                "can_id": format_can_id(message.can_id, message.is_extended_id),
                "dlc": message.dlc,
                "data": list(message.data),
                "is_extended_id": message.is_extended_id,
                "source_format": message.source_format,
                "line_num": message.line_num,
            }
            for message in messages
        ]
    }
    output_file.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")


def infer_conversion_format(output_file: Path, requested_format: str | None) -> str:
    """Select a conversion writer from an explicit format or the destination extension."""

    if requested_format:
        return requested_format
    extension_formats = {
        ".asc": "asc",
        ".log": "aria",
        ".txt": "aria",
        ".csv": "csv",
        ".json": "json",
    }
    try:
        return extension_formats[output_file.suffix.lower()]
    except KeyError as error:
        raise CanLogError(
            "Cannot infer an output format. Use .asc, .log, .txt, .csv, .json, or pass --format."
        ) from error


def convert_messages(messages: Sequence[CanMessage], output_file: Path, output_format: str) -> None:
    """Convert normalized messages to ASC, ARIA text, CSV, or JSON."""

    output_file.parent.mkdir(parents=True, exist_ok=True)
    writers = {
        "asc": write_asc,
        "aria": write_aria_log,
        "csv": write_csv,
        "json": write_json,
    }
    writers[output_format](messages, output_file)


def write_report(report: str, output_file: Path | None) -> None:
    """Print a report or persist it when an output file was requested."""

    if output_file is None:
        print(report)
        return
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(report + "\n", encoding="utf-8")
    print(f"Report written to: {output_file}")


def add_scope_filters(parser: argparse.ArgumentParser) -> None:
    """Add non-ID filters shared by passive CAN-log analysis commands."""

    parser.add_argument("--direction", choices=("rx", "tx"), help="Restrict to Rx or Tx frames.")
    parser.add_argument("--channel", type=int, help="Restrict to one CAN channel.")
    parser.add_argument("--start-time", type=float, help="Include timestamps at or after this value.")
    parser.add_argument("--end-time", type=float, help="Include timestamps at or before this value.")


def add_common_filters(parser: argparse.ArgumentParser, *, require_can_id: bool = False) -> None:
    """Add CAN-ID and non-ID filters shared by search and DBC decode commands."""

    parser.add_argument(
        "--can-id",
        type=parse_hex_number,
        required=require_can_id,
        help="CAN ID in hexadecimal, for example 0x2C0.",
    )
    add_scope_filters(parser)


def build_parser() -> argparse.ArgumentParser:
    """Define the stable command-line interface for the reusable skill script."""

    parser = argparse.ArgumentParser(
        description="Offline automotive CAN, ISO-TP, UDS, and DBC log analysis for ASC, ARIA, BLF, CSV, and JSON."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    summary_parser = subparsers.add_parser("summary", help="Inventory CAN traffic in a supported log.")
    summary_parser.add_argument("input", type=Path)
    summary_parser.add_argument("--max-ids", type=int, default=50, help="Maximum CAN IDs to list (default: 50).")
    summary_parser.add_argument("--output", type=Path, help="Optional text report path.")

    search_parser = subparsers.add_parser("search", help="Find CAN IDs and byte patterns with source positions.")
    search_parser.add_argument("input", type=Path)
    add_common_filters(search_parser)
    search_parser.add_argument(
        "--bytes", dest="byte_pattern", type=parse_byte_pattern, help="Hex bytes to find; use ?? as a wildcard."
    )
    search_parser.add_argument(
        "--byte-offset", type=int, help="Require the byte pattern at this zero-based payload offset."
    )
    search_parser.add_argument("--limit", type=int, default=100, help="Maximum matching rows to render (default: 100).")
    search_parser.add_argument("--output", type=Path, help="Optional text report path.")

    frame_parser = subparsers.add_parser("export-frames", help="Export all filtered frames for one CAN ID.")
    frame_parser.add_argument("input", type=Path)
    frame_parser.add_argument("output", type=Path)
    add_common_filters(frame_parser, require_can_id=True)
    frame_parser.add_argument("--format", choices=("asc", "aria", "csv", "json"), help="Override output format inference.")

    timing_parser = subparsers.add_parser("timing", help="Analyze inter-frame timing and cross-ID timestamp differences.")
    timing_parser.add_argument("input", type=Path)
    add_common_filters(timing_parser, require_can_id=True)
    timing_parser.add_argument("--compare-id", type=parse_hex_number, help="Optional second CAN ID for timestamp-delta analysis.")
    timing_parser.add_argument("--pairing", choices=("next", "nearest"), default="next", help="Cross-ID pairing method (default: next).")
    timing_parser.add_argument("--expected-period-ms", type=float, help="Optional expected primary message period in milliseconds.")
    timing_parser.add_argument("--limit", type=int, default=100, help="Maximum transition/pair rows to render (default: 100).")
    timing_parser.add_argument("--output", type=Path, help="Optional text report path.")

    isotp_parser = subparsers.add_parser("isotp", help="Inspect ISO-TP single, first, consecutive, and flow-control frames.")
    isotp_parser.add_argument("input", type=Path)
    isotp_parser.add_argument("--data-id", type=parse_hex_number, required=True, help="CAN ID carrying ISO-TP data frames.")
    isotp_parser.add_argument("--flow-control-id", type=parse_hex_number, help="Opposite-direction CAN ID carrying ISO-TP flow-control frames.")
    add_scope_filters(isotp_parser)
    isotp_parser.add_argument("--limit", type=int, default=100, help="Maximum transport and pairing rows to render (default: 100).")
    isotp_parser.add_argument("--output", type=Path, help="Optional text report path.")

    edr_parser = subparsers.add_parser("extract-edr", help="Extract a DID from raw ISO-TP or direct UDS response rows.")
    edr_parser.add_argument("input", type=Path)
    edr_parser.add_argument("--response-id", type=parse_hex_number, default=0x738, help="UDS response CAN ID (default: 0x738).")
    edr_parser.add_argument("--did", type=parse_hex_number, default=0x0455, help="EDR DID (default: 0x0455).")
    edr_parser.add_argument("--output", type=Path, help="Text report path; defaults beside the source log.")

    did_parser = subparsers.add_parser("extract-did", help="Extract any DID from raw ISO-TP or direct UDS response rows.")
    did_parser.add_argument("input", type=Path)
    did_parser.add_argument("--response-id", type=parse_hex_number, required=True, help="UDS response CAN ID in hexadecimal.")
    did_parser.add_argument("--did", type=parse_hex_number, required=True, help="DID to extract in hexadecimal.")
    did_parser.add_argument("--output", type=Path, help="Text report path; defaults beside the source log.")

    did_decode_parser = subparsers.add_parser("decode-did", help="Decode a generic DID response using an explicit DBC payload layout.")
    did_decode_parser.add_argument("input", type=Path)
    did_decode_parser.add_argument("--response-id", type=parse_hex_number, required=True, help="UDS response CAN ID in hexadecimal.")
    did_decode_parser.add_argument("--did", type=parse_hex_number, required=True, help="DID to decode in hexadecimal.")
    did_decode_parser.add_argument("--dbc", required=True, type=Path, help="DBC containing the DID payload layout.")
    did_decode_parser.add_argument("--dbc-message", required=True, help="DBC message name that defines the DID payload layout.")
    did_decode_parser.add_argument("--include-uds-header", action="store_true", help="Pass the 62/DID response header to the DBC instead of only the DID payload.")
    did_decode_parser.add_argument("--limit", type=int, default=100, help="Maximum DID responses to render (default: 100).")
    did_decode_parser.add_argument("--output", type=Path, help="Text report path; defaults beside the source log.")

    decode_parser = subparsers.add_parser("decode", help="Decode matching CAN frames with a DBC and show bytes/bits.")
    decode_parser.add_argument("input", type=Path)
    decode_parser.add_argument("--dbc", required=True, type=Path, help="DBC file that defines the selected CAN frames.")
    add_common_filters(decode_parser)
    decode_parser.add_argument("--limit", type=int, default=100, help="Maximum decoded frames to render (default: 100).")
    decode_parser.add_argument("--output", type=Path, help="Optional text report path.")

    convert_parser = subparsers.add_parser("convert", help="Convert supported logs to ASC, ARIA text, CSV, or JSON.")
    convert_parser.add_argument("input", type=Path)
    convert_parser.add_argument("output", type=Path)
    convert_parser.add_argument("--format", choices=("asc", "aria", "csv", "json"), help="Override output format inference.")

    return parser


def run_summary(arguments: argparse.Namespace) -> int:
    """Execute the traffic summary command."""

    if arguments.max_ids < 1:
        raise CanLogError("--max-ids must be at least 1.")
    messages = load_messages(arguments.input)
    write_report(render_summary(messages, arguments.max_ids), arguments.output)
    return 0


def run_search(arguments: argparse.Namespace) -> int:
    """Execute the ID/byte search command."""

    if arguments.can_id is None and arguments.byte_pattern is None:
        raise CanLogError("Search requires --can-id, --bytes, or both.")
    if arguments.byte_offset is not None and arguments.byte_offset < 0:
        raise CanLogError("--byte-offset must be zero or greater.")
    if arguments.limit < 1:
        raise CanLogError("--limit must be at least 1.")

    messages = load_messages(arguments.input)
    results = search_messages(
        messages,
        can_id=arguments.can_id,
        byte_pattern=arguments.byte_pattern,
        byte_offset=arguments.byte_offset,
        direction=arguments.direction,
        channel=arguments.channel,
        start_time=arguments.start_time,
        end_time=arguments.end_time,
    )
    write_report(render_search_report(arguments.input, results[: arguments.limit], len(results)), arguments.output)
    return 0


def run_export_frames(arguments: argparse.Namespace) -> int:
    """Export all frames for one CAN ID after applying passive capture filters."""

    messages = filter_messages(
        load_messages(arguments.input),
        can_id=arguments.can_id,
        direction=arguments.direction,
        channel=arguments.channel,
        start_time=arguments.start_time,
        end_time=arguments.end_time,
    )
    if not messages:
        raise CanLogError(f"No frames matched CAN ID {format_can_id(arguments.can_id)} and the requested filters.")
    output_format = infer_conversion_format(arguments.output, arguments.format)
    convert_messages(messages, arguments.output, output_format)
    print(f"Exported {len(messages)} frame(s) for {format_can_id(arguments.can_id)} to {arguments.output}")
    return 0


def run_timing(arguments: argparse.Namespace) -> int:
    """Execute source-order interval and optional cross-ID timestamp analysis."""

    if arguments.limit < 1:
        raise CanLogError("--limit must be at least 1.")
    if arguments.expected_period_ms is not None and arguments.expected_period_ms <= 0:
        raise CanLogError("--expected-period-ms must be greater than zero.")
    if arguments.compare_id == arguments.can_id:
        raise CanLogError("--compare-id must differ from --can-id.")

    messages = filter_messages(
        load_messages(arguments.input),
        direction=arguments.direction,
        channel=arguments.channel,
        start_time=arguments.start_time,
        end_time=arguments.end_time,
    )
    if not any(message.can_id == arguments.can_id for message in messages):
        raise CanLogError(f"No frames matched primary CAN ID {format_can_id(arguments.can_id)} and the requested filters.")
    if arguments.compare_id is not None and not any(message.can_id == arguments.compare_id for message in messages):
        raise CanLogError(f"No frames matched comparison CAN ID {format_can_id(arguments.compare_id)} and the requested filters.")

    report = render_timing_report(
        arguments.input,
        messages,
        arguments.can_id,
        arguments.compare_id,
        arguments.pairing,
        arguments.expected_period_ms,
        arguments.limit,
    )
    write_report(report, arguments.output)
    return 0


def run_isotp(arguments: argparse.Namespace) -> int:
    """Execute passive ISO-TP transport and flow-control timeline analysis."""

    if arguments.limit < 1:
        raise CanLogError("--limit must be at least 1.")
    if arguments.flow_control_id == arguments.data_id:
        raise CanLogError("--flow-control-id must differ from --data-id for unambiguous pairing.")

    messages = filter_messages(
        load_messages(arguments.input),
        direction=arguments.direction,
        channel=arguments.channel,
        start_time=arguments.start_time,
        end_time=arguments.end_time,
    )
    if not any(message.can_id == arguments.data_id for message in messages):
        raise CanLogError(f"No frames matched data CAN ID {format_can_id(arguments.data_id)} and the requested filters.")
    if arguments.flow_control_id is not None and not any(
        message.can_id == arguments.flow_control_id for message in messages
    ):
        raise CanLogError(
            f"No frames matched flow-control CAN ID {format_can_id(arguments.flow_control_id)} and the requested filters."
        )
    report = render_isotp_timeline(
        arguments.input,
        messages,
        arguments.data_id,
        arguments.flow_control_id,
        arguments.limit,
    )
    write_report(report, arguments.output)
    return 0


def run_extract_edr(arguments: argparse.Namespace) -> int:
    """Execute EDR DID extraction from direct UDS and ISO-TP response traffic."""

    messages = load_messages(arguments.input)
    payloads = extract_diagnostic_payloads(messages, arguments.response_id)
    edr_responses = filter_edr_responses(payloads, arguments.did)
    output_file = arguments.output or arguments.input.with_name(
        f"{arguments.input.stem}_did_{arguments.did:04X}_edr_report.txt"
    )
    report = render_edr_report(arguments.input, arguments.response_id, arguments.did, edr_responses)
    write_report(report, output_file)
    print(f"Complete diagnostic payloads on {format_can_id(arguments.response_id)}: {len(payloads)}")
    print(f"EDR responses for DID 0x{arguments.did:04X}: {len(edr_responses)}")
    return 0


def run_extract_did(arguments: argparse.Namespace) -> int:
    """Execute generic DID extraction from direct UDS and ISO-TP response traffic."""

    messages = load_messages(arguments.input)
    payloads = extract_diagnostic_payloads(messages, arguments.response_id)
    did_responses = filter_did_responses(payloads, arguments.did)
    output_file = arguments.output or arguments.input.with_name(
        f"{arguments.input.stem}_did_{arguments.did:04X}_report.txt"
    )
    report = render_did_report(arguments.input, arguments.response_id, arguments.did, did_responses)
    write_report(report, output_file)
    print(f"Complete diagnostic payloads on {format_can_id(arguments.response_id)}: {len(payloads)}")
    print(f"DID responses for 0x{arguments.did:04X}: {len(did_responses)}")
    return 0


def run_decode_did(arguments: argparse.Namespace) -> int:
    """Execute a DBC-backed visual decode of an extracted DID payload."""

    if arguments.limit < 1:
        raise CanLogError("--limit must be at least 1.")
    if not arguments.dbc.is_file():
        raise CanLogError(f"DBC file was not found: {arguments.dbc}")
    messages = load_messages(arguments.input)
    payloads = extract_diagnostic_payloads(messages, arguments.response_id)
    did_responses = filter_did_responses(payloads, arguments.did)
    output_file = arguments.output or arguments.input.with_name(
        f"{arguments.input.stem}_did_{arguments.did:04X}_dbc_decode.txt"
    )
    report = decode_did_with_dbc(
        arguments.input,
        arguments.response_id,
        arguments.did,
        did_responses,
        arguments.dbc,
        arguments.dbc_message,
        arguments.limit,
        arguments.include_uds_header,
    )
    write_report(report, output_file)
    return 0


def run_decode(arguments: argparse.Namespace) -> int:
    """Execute DBC decode with raw-byte and DBC-layout evidence."""

    if arguments.limit < 1:
        raise CanLogError("--limit must be at least 1.")
    if not arguments.dbc.is_file():
        raise CanLogError(f"DBC file was not found: {arguments.dbc}")
    messages = filter_messages(
        load_messages(arguments.input),
        can_id=arguments.can_id,
        direction=arguments.direction,
        channel=arguments.channel,
        start_time=arguments.start_time,
        end_time=arguments.end_time,
    )
    write_report(decode_with_dbc(messages, arguments.dbc, arguments.limit), arguments.output)
    return 0


def run_convert(arguments: argparse.Namespace) -> int:
    """Execute a passive format conversion using the normalized representation."""

    messages = load_messages(arguments.input)
    output_format = infer_conversion_format(arguments.output, arguments.format)
    convert_messages(messages, arguments.output, output_format)
    print(f"Converted {len(messages)} CAN message(s) to {output_format}: {arguments.output}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command-line tool and convert known input errors into a clean exit code."""

    parser = build_parser()
    arguments = parser.parse_args(argv)
    handlers = {
        "summary": run_summary,
        "search": run_search,
        "export-frames": run_export_frames,
        "timing": run_timing,
        "isotp": run_isotp,
        "extract-edr": run_extract_edr,
        "extract-did": run_extract_did,
        "decode-did": run_decode_did,
        "decode": run_decode,
        "convert": run_convert,
    }
    try:
        return handlers[arguments.command](arguments)
    except CanLogError as error:
        parser.error(str(error))
    return 2


if __name__ == "__main__":
    sys.exit(main())