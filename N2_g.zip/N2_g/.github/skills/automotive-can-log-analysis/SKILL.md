---
name: automotive-can-log-analysis
description: 'Use when extracting EDR or arbitrary UDS DID bytes, parsing ARIA .log/.txt files, exporting CAN-ID frames, searching CAN IDs or byte patterns, analyzing message timing or cross-ID timestamp deltas, inspecting ISO-TP Single/First/Consecutive/Flow-Control frames, decoding CAN or DID data with a DBC, or converting BLF, ASC, ARIA, CSV, and JSON CAN logs offline in Framework_IOEM_Py.'
argument-hint: 'State the log path, goal, CAN ID/DID, ISO-TP route, filters, timing comparison, and optional DBC layout'
user-invocable: true
disable-model-invocation: false
---

# Automotive CAN Log Analysis

Use this skill to analyze recorded CAN traffic offline. It never transmits frames, connects to a bench, modifies source captures, or invents DBC definitions.

## Supported Inputs

The bundled [utility](./scripts/can_log_analyzer.py) automatically recognizes these text rows, regardless of whether the extension is `.asc`, `.log`, or `.txt`:

- Vector ASC CAN records: `timestamp channel ID Rx|Tx d DLC bytes`
- ARIA `Can` and `CanFd` records: `timestamp Can|CanFd channel RX|TX l=DLC, id=..., bytes`
- ARIA message records: `RX_MSG|TX_MSG, c=..., t=..., id=..., l=..., bytes`
- Tabular diagnostic exports: `timestamp channel Rx|Tx ID DLC bytes`

It also reads binary `.blf` files through `python-can` and its own CSV/JSON exports. It can convert supported inputs to Vector-style ASC, ARIA `RX_MSG`/`TX_MSG` text, CSV, or JSON. It does not claim support for unknown proprietary formats; inspect an unfamiliar sample before adding a parser.

## First Steps

1. Identify the requested operation: `summary`, `search`, `export-frames`, `timing`, `isotp`, `extract-edr`, `extract-did`, `decode`, `decode-did`, or `convert`.
2. Confirm the input log path, channel, direction, CAN ID, timestamp window, DID, and response ID from the request. Treat IDs and DIDs as hexadecimal unless the source explicitly says otherwise.
3. Preserve the original log. Send reports and converted files to a new output path.
4. For an EDR request, determine whether the log contains raw ISO-TP frames or an already-expanded UDS payload row. The utility supports both.
5. For a CAN-frame DBC decode, use the exact project/variant DBC supplied by the user. For a DID decode, require an explicitly named DBC message that defines the DID payload layout. Do not infer signal names, scaling, endianness, or bit positions from the log alone.

Run commands from the repository root. On this machine, use `py -3.13` rather than the broken PATH `python` installation.

## Commands

### Traffic Summary

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py summary <log-path> --output <summary.txt>
```

Use this before a broad investigation. It reports message count, timestamp range, channels, directions, source formats, and CAN-ID traffic counts.

### Search By CAN ID Or Bytes

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py search <log-path> --can-id 0x2C0 --direction rx --bytes "01 01 ??" --byte-offset 4 --output <matches.txt>
```

- `--can-id` filters an arbitration ID.
- `--bytes` searches a byte sequence; `??` is a one-byte wildcard.
- `--byte-offset` makes the match position explicit using a zero-based payload byte offset.
- `--channel`, `--start-time`, and `--end-time` narrow large captures.

Each result preserves timestamp, source line/frame, channel, direction, CAN ID, raw bytes, and matched byte position.

### Export All Frames For One CAN ID

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py export-frames <log-path> <selected.csv> --can-id 0x2C0 --direction rx --channel 2
```

Use this to create a smaller evidence file for one message ID. Apply `--direction`, `--channel`, `--start-time`, and `--end-time` before export. Output format is inferred from `.asc`, `.log`/`.txt`, `.csv`, or `.json`, or selected explicitly with `--format`.

### Analyze Timing And Cross-ID Timestamp Differences

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py timing <log-path> --can-id 0x2C0 --expected-period-ms 20 --output <timing.txt>
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py timing <log-path> --can-id 0x730 --compare-id 0x738 --pairing next --output <request-response-timing.txt>
```

The timing report retains source order and provides minimum, mean, median, maximum, and population standard deviation for positive inter-frame intervals. It reports non-forward transitions and timestamp-reset segments rather than silently sorting the capture.

For two IDs, `--pairing next` pairs each primary frame with the first comparison timestamp at or after it. `--pairing nearest` selects the closest comparison timestamp, preferring the later frame on a tie. The report includes each pair's signed timestamp difference and the cross-ID timing statistics. Use the pair rule that matches the observed protocol relationship; do not present periodic traffic as a request/response relationship without evidence.

### Inspect ISO-TP And Flow-Control Frames

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py isotp <log-path> --data-id 0x738 --flow-control-id 0x730 --output <isotp-timeline.txt>
```

Use this for UDS/ISO-TP transport evidence, not just DID extraction. It reports source-order Single Frames, First Frames, Consecutive Frames, direct UDS payload rows, and Flow-Control frames. A Flow-Control frame includes its status (`Continue To Send`, `Wait`, `Overflow/Abort`, or reserved), block size, raw STmin value, and interpreted STmin where valid.

When `--flow-control-id` is provided, the report pairs every First Frame on `--data-id` with the next Flow-Control frame on the opposite route and calculates the delay. The two IDs must differ for unambiguous pairing. Use `export-frames` when the test needs the raw Flow-Control records in a separate evidence file.

### Extract Any UDS DID

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py extract-did <log-path> --response-id 0x738 --did 0xF190 --output <did-report.txt>
```

Unlike `extract-edr`, this command requires the response CAN ID and DID so no EDR default is assumed. It extracts positive `62 <DID high> <DID low>` responses from raw ISO-TP traffic or already-expanded UDS rows and reports the DID bytes after the UDS header.

### Extract EDR DID Data

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py extract-edr <log-path> --response-id 0x738 --did 0x0455 --output <edr-report.txt>
```

Defaults are response ID `0x738` and EDR DID `0x0455`. The utility reassembles ISO-TP single/first/consecutive frames and also accepts direct positive UDS responses beginning `62 <DID high> <DID low>`. The report separates the UDS header from the EDR bytes and records source position plus the number of transport frames used.

### Decode A DID Payload With A DBC

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py decode-did <log-path> --response-id 0x738 --did 0xF190 --dbc <did-layout.dbc> --dbc-message <DID_Payload_Layout> --output <did-decode.txt>
```

`decode-did` first extracts the requested positive DID response, then passes the payload bytes after `62 <DID high> <DID low>` to the explicitly named DBC message. The report shows both payload byte positions and their original UDS diagnostic-byte positions, with physical/raw values and the DBC signal's start bit, length, byte order, signedness, factor, offset, and unit.

Use `--include-uds-header` only when the selected DBC layout explicitly includes the three-byte `62/DID` response header. A normal CAN-frame DBC does not automatically define a UDS DID payload layout.

### Decode And Describe Values With A DBC

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py decode <log-path> --dbc <variant.dbc> --can-id 0x2C0 --limit 50 --output <dbc-decode.txt>
```

For every decoded frame, the report includes indexed raw hex bytes, binary bytes, the DBC message name, physical and raw signal values, and each signal's start bit, length, byte order, signedness, factor, offset, unit, and contributing payload bytes. Use `--can-id` and `--limit` for a focused visual value description.

### Convert Logs

```powershell
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py convert <input.blf> <output.asc>
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py convert <input.log> <output.csv>
py -3.13 .github\skills\automotive-can-log-analysis\scripts\can_log_analyzer.py convert <input.asc> <output.log> --format aria
```

Output format is inferred from `.asc`, `.log`/`.txt`, `.csv`, or `.json`, or can be selected explicitly with `--format asc|aria|csv|json`.

## Dependencies

Plain ASC, ARIA, tabular diagnostic, CSV, and JSON processing use only the Python standard library.

- BLF reading/conversion requires `python-can`.
- DBC decoding requires `cantools`.

When needed, install the missing library with:

```powershell
py -3.13 -m pip install python-can cantools
```

## Investigation Rules

1. Report observed facts separately from inferences. A signal value is only a fact when decoded with the supplied DBC.
2. Cite each finding with log path, timestamp, source line/frame, channel, direction, CAN ID, and raw bytes. Include the byte offset for byte-pattern searches.
3. For DBC results, include message/signal name and the DBC signal layout. For Motorola signals, retain the DBC start-bit convention rather than guessing a contiguous little-endian byte range.
4. For UDS, distinguish a positive response, a negative response, a transport frame, and a timeout. Do not call an unanswered request an EDR response.
5. For ISO-TP, identify the configured data and Flow-Control IDs explicitly. Report Flow-Control status, block size, STmin, frame sequence, and First-Frame-to-Flow-Control delay from recorded timestamps; do not infer a missing Flow-Control frame.
6. If the source log has reset or non-monotonic timestamps, disclose that before making timing or ordering conclusions.
7. Keep analysis offline unless the user explicitly authorizes a separate bench task.

## Completion Checklist

- The parser recognized the expected source rows and the output identifies their source format.
- Searches include source and payload positions.
- Frame exports contain only the selected CAN ID and requested filters.
- EDR or generic DID extraction has the requested DID and response ID and contains only complete transport payloads.
- DBC results name the exact DBC file and expose raw bytes alongside decoded values.
- Timing reports declare the pair rule, show timestamp discontinuities, and do not hide non-forward deltas.
- ISO-TP reports distinguish data and Flow-Control routes and expose recorded Flow-Control fields.
- Conversions write a new file and leave source captures unchanged.