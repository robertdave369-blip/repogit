---
name: failure-mode-analysis
description: 'Use when designing or reviewing any test, specification, or change for an airbag ECU, to enumerate how it can fail rather than only how it works: wrong/missing/boundary/invalid/corrupt input, timing and timeout, power loss and reset, comms loss, CRC and counter failure, sensor failure, config failure, NVM corruption, version mismatch, boot failure, recovery failure, safety reaction, security violation, degraded mode. Also covers ISO 26262 safety-argument work (ASIL allocation, FTTI, fault injection discipline) and embedded execution analysis (MCU startup, interrupts, watchdog, bootloader, NVM, RTOS). Apply it to every feature, not only on request.'
argument-hint: 'Describe the project, the function or change under review, and the evidence available'
user-invocable: true
disable-model-invocation: false
---

# Failure Mode Analysis

Merges `embedded-systems-fundamentals`, `functional-safety-iso26262`, and the
failure-analysis half of `requirement-based-testing` — see
`.github/knowledge/decisions.md` D-2026-08-29-07. Test-case authoring and Codebeamer
output belong to `veoneer-test-spec-generator`; this skill decides *what must be tested*.

**Happy-path-only output is incomplete work.** If your analysis contains no negative,
boundary, timing, or fault-injection case, you have not finished.

## The checklist — apply all of it, every time

| Class | Ask |
|---|---|
| Input | wrong value, missing, at/over boundary, invalid encoding, corrupt payload |
| Timing | too early, too late, timeout, repeated, out of order, jitter, burst |
| Power | loss mid-operation, brownout, reset, ignition cycle, sleep/wake |
| Comms | bus off, node absent, message timeout, partial network, restart |
| Integrity | CRC failure, alive/rolling counter stuck, skipped, wrapped, E2E mismatch |
| Sensor | out of range, stuck, noisy, open, short, plausibility conflict, absent |
| Config | deconfigured parameter, variant mismatch, wrong coding, default applied |
| NVM | corrupt block, write interrupted, checksum fail, exhausted, uninitialised |
| Version | software/hardware/calibration mismatch, incompatible bootloader |
| Boot | boot failure, stuck in bootloader, rollback, post-flash verification fail |
| Recovery | does not heal, heals too fast, heals without cause, latched forever |
| Safety | wrong reaction, no reaction, reaction too late, spurious deployment inhibit |
| Security | unauthorised access, replay, freshness violation, key/MAC failure |
| Degraded | which functions survive, which are inhibited, what is reported |

For each class that applies, state the fault model, how it is detected, the expected
reaction, the observable evidence, and how the bench is restored afterwards.

## Workflow

1. **Identify the target** — project, variant, ECU hardware/software version, function,
   operating mode, and the documentation actually supplied. Do not assume a variant.
2. **Separate claims** into `FACT / INFERENCE / ASSUMPTION / UNKNOWN / CONTRADICTION`
   with provenance and confidence. Cross-check requirements, architecture, code,
   configuration, DBC, diagnostics, and logs against each other — never one in isolation.
3. **Build the execution chain**: input or interrupt → task or handler → state and memory
   → output, network, or diagnostic → recovery. Include reset, power-cycle, and boot
   transitions wherever they affect behaviour.
4. **Build the fault chain** for each fault: cause → detection → qualification →
   reaction → safe or degraded state → reporting → recovery → verification evidence.
5. **Verify timing end to end**: occurrence, detection and qualification, decision,
   actuation or inhibition, reporting, recovery, and the allocated FTTI. Never substitute
   a generic timing expectation for an allocated one.
6. **Prioritise** — a minimal, risk-ordered set covering nominal operation, detection,
   diagnostic reaction, fail-safe and degraded behaviour, boundary timing, recovery, and
   independent-monitor failure. Safety-critical first. Never pad counts.
7. **Report gaps**: residual risk, untestable conditions, and missing safety-case
   evidence.

## Safety-argument rules (ISO 26262)

Airbag functions can be safety critical, but **do not assume every component is ASIL-D**.
Verify the safety goal, allocated ASIL, decomposition, and verification obligation from
the project's own safety artefacts.

Never state a diagnostic coverage figure, FTTI, safe state, hardware metric, or ASIL
allocation without citing a project source. A generic ISO 26262 reference is not evidence
that this ECU implements a mechanism.

For each claimed safety mechanism verify: monitored element, fault model, diagnostic
method, detection latency, independence, enable conditions, failure mode, reaction,
diagnostic observability, and reset/ignition-cycle behaviour. Watchdog supervision,
plausibility and range checks, redundancy comparison, memory integrity, communication
freshness/CRC/E2E, voltage monitoring, and sensor diagnostics are *categories to check
for*, not findings.

## Embedded execution analysis

Identify rather than assume: MCU, cores, clocks, reset sources, startup sequence, memory
map, debug interface; interrupt source, priority, rate, execution budget, shared-state
protection, overrun behaviour; RAM/Flash/EEPROM or emulated-NVM ownership, integrity
checks, initialisation, persistence, wear and error handling, reset behaviour; watchdog
configuration, service owner, supervision window, fault reaction, reset propagation,
recovery; bootloader/application boundary, image format, compatibility and authentication
checks, programming sequence, rollback, post-flash verification; RTOS or static-scheduler
task priorities, periods, deadlines, resource sharing, latency, startup sequencing.

Framework anchors for existing debug and flash workflows: `shared_libraries/winidea.py`
and `shared_libraries/ascent_batch_lib.py`. Inspect their current interfaces and the
project configuration before proposing any change — do not assume a signature.

## Fault-injection discipline

Use only the project-approved fault-creation method (`agent_sc3.md` section 25.5
catalogue; ask if in doubt). Before any execution define: preconditions, injection point,
expected reaction, time basis, monitoring evidence, restoration, and post-test checks.

If a needed fault method is undocumented or ambiguous, **stop and ask for the approved
bench procedure**. Do not improvise a physical or communication fault.

## Safety boundary

Analysing or writing a test is not authorisation to run it. Never attach a debugger, halt
an ECU, erase or program memory, change NVM, reset or power-cycle hardware, flash
software, or trigger anything squib- or deployment-related without explicit authorisation
for that specific operation on a verified target.

Prefer the least invasive validation that answers the question: static review →
configuration consistency check → offline decode or analysis → simulation → trace and log
review → authorised target execution, in that order.

## Closing question, mandatory

Before the analysis is considered done, answer in writing:

> **What defect could still escape this?**

Name the residual risk and what would catch it. "Nothing" means you have not looked hard
enough.

## Handoff

Emit an evidence-handoff object
(`.github/skills/skill-portfolio-orchestration/references/evidence-handoff.schema.json`)
carrying the safety goal, ASIL evidence, requirement and architecture links, fault
hypothesis, detection/reaction chain, timing evidence, residual risk, and fault-injection
authorisation state. Approved test objectives go to `veoneer-test-spec-generator`;
executable checks to `python-test-automation`.
