---
name: uv-package-manager
description: 'Use when monitoring, auditing, installing, upgrading, validating, rolling back, or governing Python dependencies with uv in Framework_IOEM_Py. Provides release monitoring, Python compatibility, semantic-version risk, release-note/security review, dependency graphing, sandbox validation, lockfile integrity, audit trails, policy-based approval, and rollback without blindly changing the active environment.'
argument-hint: 'Describe the dependency action, target package(s), release channel, and whether online monitoring or an approved production mutation is intended'
user-invocable: true
disable-model-invocation: false
---

# UV Package Manager v2

## Purpose

Use this skill to manage the full dependency lifecycle without blindly upgrading the framework. The bundled [manager](./scripts/uv_dependency_manager.py) is read-only by default and stores durable evidence in `tests/dependency_management/`.

The required flow is:

```text
Release monitoring -> compatibility/risk review -> UV dry-run resolution -> sandbox install -> validation -> explicit production approval -> production update -> rollback on failure
```

## Safety Rules

1. Never mutate the active environment or lockfile without explicit user approval **and** a reviewed approval JSON record based on `tests/dependency_management/approval_template.json`.
2. Do not treat a newer version as safe. Review Python compatibility, semantic version change, criticality, release notes, security advisories, and sandbox validation first.
3. A missing `pyproject.toml` or `uv.lock` blocks sandbox installation, production upgrades, lock integrity checks, and rollback. Inventory and monitoring remain safe to run.
4. Major upgrades always require manual approval. Minor upgrades require sandbox validation. Patch upgrades may be recommended, but production mutation still needs explicit approval.
5. Security findings can bypass the normal schedule for review priority, not the production-approval gate.
6. Do not delete an unused package automatically. Cleanup output is a manual-review suggestion because imports can be dynamic, optional, or external.

## Framework State

The workspace policy and generated lifecycle evidence live in `tests/dependency_management/`:

```text
tests/dependency_management/
  dependency_policy.json
  dependency_inventory.json
  compatibility_matrix.json
  package_health.json
  release_monitoring.json
  security_advisories.json
  upgrade_recommendations.json
  validation_results.json
  update_history.json
  rollback_history.json
  dependency_graph.json
  lockfile_integrity.json
  cleanup_suggestions.json
  notification_summary.json
  schedule_status.json
  skill_compatibility.json
  deprecated_api_report.json
  audit_trail.jsonl
  backups/
```

The initial policy classifies `numpy`, `pandas`, `pytest`, `pymupdf`, `pdfplumber`, and `openpyxl` as critical; `easyocr` and `camelot-py` are optional. Adjust this project-owned policy only with review.

## Commands

Use the Python interpreter that owns the target environment:

```powershell
$manager = ".github\skills\uv-package-manager\scripts\uv_dependency_manager.py"

# Safe local inventory; no network or mutation.
& "C:\Python3.13.0\python.exe" $manager inventory

# Online release and OSV advisory monitoring; no mutation.
& "C:\Python3.13.0\python.exe" $manager monitor --online

# Check a package's release and compatibility evidence.
& "C:\Python3.13.0\python.exe" $manager updates --package pdfplumber --online

# Emit due-state for CI or Windows Task Scheduler; no background service is installed.
& "C:\Python3.13.0\python.exe" $manager schedule

# Scan source usage of APIs named deprecated in a reviewed release-notes file.
& "C:\Python3.13.0\python.exe" $manager deprecated-api --package pdfplumber --release-notes C:\Docs\pdfplumber-release-notes.md

# Resolve a proposed upgrade without writing a lockfile.
& "C:\Python3.13.0\python.exe" $manager simulate --package pdfplumber

# Copy the UV project, install only in the temporary sandbox, and run policy validation commands.
& "C:\Python3.13.0\python.exe" $manager simulate --package pdfplumber --sandbox-install

# Production mutation: explicit approval is mandatory and only works in a UV project.
& "C:\Python3.13.0\python.exe" $manager apply --package pdfplumber --online --approve-production `
  --approval-file tests\dependency_management\approved_change.json

# Restore the most recent backed-up successful production update.
& "C:\Python3.13.0\python.exe" $manager rollback --approve-production `
  --approval-file tests\dependency_management\approved_rollback.json
```

## Decision Rules

| Change | Default recommendation | Required next step |
| --- | --- | --- |
| No update | `wait` | Continue monitoring |
| Compatible low-risk patch | `upgrade_now` | Sandbox validation, then explicit approval |
| Minor | `manual_review` | Sandbox install and validation |
| Major | `manual_review` | Migration/release-note review and explicit approval |
| Python-incompatible | `avoid_upgrade` | Do not upgrade |
| Critical/high advisory | Review out of schedule | Validate and explicitly approve production update |

## Quality Gates

Before a production update is considered complete:

- Current package, candidate release, date, `Requires-Python`, criticality, risk, security state, and recommendation are recorded.
- `uv lock --upgrade-package <package> --dry-run` succeeds in a sandbox.
- If sandbox installation is requested, `uv sync --frozen` and every configured validation command pass in the copied project.
- The pre-update `pyproject.toml` and `uv.lock` are backed up with hashes.
- Approval provenance includes requester, change reason, risk class, approver, approval timestamp, authorized operation/package scope, and validation-evidence references.
- Active-environment validation succeeds after the approved update; otherwise the manager restores the backup and records rollback evidence.
- `uv sync --frozen --dry-run` passes for lockfile integrity.
- Configured framework-skill import checks and policy validation commands pass in the same sandbox or active environment being validated.
- Deprecated API usage is reviewed whenever release notes identify callable APIs that are deprecated or removed.

## Portfolio Handoff

For a multi-skill workflow, preserve the dependency policy, interpreter/UV version, inventory, release/security provenance, compatibility/risk result, sandbox output, framework-skill import checks, approval metadata/hash, validation results, backup, and rollback status. Hand validated environment status to `python-test-automation` and library/document extraction constraints to `pdf-document-intelligence`.

## Completion Criteria

The lifecycle task is complete only when its report contains provenance for release/security data, compatibility and risk evidence, sandbox/validation status, approval state, audit history, and any rollback outcome. Do not claim an upgrade occurred merely because release monitoring found a newer package.