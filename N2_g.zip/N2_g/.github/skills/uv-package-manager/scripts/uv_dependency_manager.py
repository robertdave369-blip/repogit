"""Safe UV dependency lifecycle management for Framework_IOEM_Py.

The manager is intentionally read-only by default. It inventories packages,
checks releases when online is explicitly enabled, assesses compatibility and
risk, and writes reproducible JSON evidence. Any production mutation requires
an existing ``pyproject.toml`` plus ``uv.lock`` and explicit approval.
"""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import importlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from importlib import metadata
from pathlib import Path
from typing import Any, Iterable, Sequence


DEFAULT_STATE_DIR_NAME = "tests/dependency_management"
DEFAULT_APPROVAL_TEMPLATE: dict[str, Any] = {
    "request_id": "CHG-YYYY-NNNN",
    "requester": "name-or-service-account",
    "reason": "Describe the package change, business rationale, and expected impact.",
    "risk_class": "low|medium|high|critical",
    "approved_by": "pending-authorization",
    "approved_at": "YYYY-MM-DDTHH:MM:SSZ",
    "expires_at": "YYYY-MM-DDTHH:MM:SSZ",
    "status": "draft",
    "operations": ["upgrade_package"],
    "packages": ["example-package"],
    "validation_evidence": [
        "tests/dependency_management/sandbox_validation.json",
        "tests/dependency_management/validation_results.json",
    ],
}
DEFAULT_POLICY: dict[str, Any] = {
    "schema_version": 1,
    "channel": "stable",
    "schedules": {
        "patch": "monthly",
        "minor": "quarterly",
        "major": "manual_approval",
        "security": "out_of_band_review",
    },
    "criticality": {
        "critical": ["numpy", "pandas", "pytest", "pymupdf", "pdfplumber", "openpyxl"],
        "standard": ["rich", "typer", "markdown"],
        "optional": ["easyocr", "camelot-py"],
    },
    "watch_packages": [
        "pymupdf",
        "pdfplumber",
        "camelot-py",
        "easyocr",
        "pandas",
        "openpyxl",
        "numpy",
        "pytest",
    ],
    "validation_commands": [
        ["{python}", "tests/test_pdf_document_intelligence.py", "-v"],
        ["{python}", "tests/test_aria_config_assistant.py", "-v"],
    ],
    "skill_import_checks": [
        {"skill": "pdf-document-intelligence", "modules": ["fitz", "pdfplumber", "PIL"]},
        {"skill": "python-test-automation", "modules": ["openpyxl", "pandas"]},
        {"skill": "uv-package-manager", "modules": ["tomllib", "importlib.metadata"]},
    ],
    "approval_requirements": [
        "request_id",
        "requester",
        "reason",
        "risk_class",
        "approved_by",
        "approved_at",
        "status",
        "validation_evidence",
    ],
    "release_notes_sources": {},
    "max_patch_risk_score": 30,
}
STATE_FILE_DEFAULTS: dict[str, Any] = {
    "compatibility_matrix.json": {"schema_version": 1, "matrix": {}},
    "update_history.json": {"schema_version": 1, "events": []},
    "rollback_history.json": {"schema_version": 1, "events": []},
    "security_advisories.json": {"schema_version": 1, "packages": []},
    "validation_results.json": {"schema_version": 1, "runs": []},
}
PACKAGE_NAME_PATTERN = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9_.-]*)")
SEMVER_PATTERN = re.compile(r"^(\d+)(?:\.(\d+))?(?:\.(\d+))?")
BREAKING_TERMS = ("breaking change", "breaking", "incompatible", "migration", "removed")
DEPRECATION_TERMS = ("deprecated", "deprecation", "obsolete")
SECURITY_TERMS = ("security", "cve-", "vulnerability", "vulnerabilities")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _json_read(path: Path, default: Any) -> Any:
    if not path.is_file():
        return copy.deepcopy(default)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return copy.deepcopy(default)


def _json_write(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(path.suffix + ".tmp")
    temporary_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary_path.replace(path)


def _sha256(path: Path) -> str | None:
    if not path.is_file():
        return None
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _version_parts(value: str | None) -> tuple[int, int, int] | None:
    if not value:
        return None
    match = SEMVER_PATTERN.match(value.strip())
    if not match:
        return None
    major, minor, patch = match.groups()
    return (int(major or 0), int(minor or 0), int(patch or 0))


def _version_sort_key(value: str) -> Any:
    packaging_version = _optional_module("packaging.version")
    if packaging_version is not None:
        try:
            return packaging_version.Version(value)
        except Exception:
            pass
    return (*(_version_parts(value) or (0, 0, 0)), value)


def _is_prerelease(value: str) -> bool:
    packaging_version = _optional_module("packaging.version")
    if packaging_version is not None:
        try:
            return bool(packaging_version.Version(value).is_prerelease)
        except Exception:
            pass
    return bool(re.search(r"(?:a|b|rc|dev|alpha|beta|preview)", value, re.IGNORECASE))


def _optional_module(module_name: str) -> Any | None:
    try:
        return importlib.import_module(module_name)
    except Exception:
        return None


@dataclass(frozen=True)
class CommandResult:
    command: list[str]
    cwd: str
    exit_code: int | None
    stdout: str
    stderr: str
    timed_out: bool = False
    error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.exit_code == 0 and not self.timed_out and self.error is None

    def as_dict(self) -> dict[str, Any]:
        return {
            "command": self.command,
            "cwd": self.cwd,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "timed_out": self.timed_out,
            "error": self.error,
            "succeeded": self.succeeded,
        }


class UVPackageManagerSkill:
    """A read-only-first dependency lifecycle manager for UV projects."""

    def __init__(
        self,
        project_root: str | Path = ".",
        state_dir: str | Path | None = None,
        uv_executable: str | None = None,
        python_executable: str | Path | None = None,
        channel: str | None = None,
    ) -> None:
        self.project_root = Path(project_root).expanduser().resolve()
        self.state_dir = Path(state_dir).expanduser().resolve() if state_dir else self.project_root / DEFAULT_STATE_DIR_NAME
        self.uv_executable = uv_executable or shutil.which("uv")
        self.python_executable = str(Path(python_executable).resolve()) if python_executable else sys.executable
        self._ensure_state_layout()
        configured_policy = _json_read(self.state_dir / "dependency_policy.json", DEFAULT_POLICY)
        self.policy = _deep_merge(DEFAULT_POLICY, configured_policy if isinstance(configured_policy, dict) else {})
        if channel:
            if channel not in {"stable", "latest", "experimental"}:
                raise ValueError("channel must be stable, latest, or experimental")
            self.policy["channel"] = channel

    # Public lifecycle API -------------------------------------------------

    def ensure_packages(
        self,
        packages: Iterable[str],
        *,
        apply: bool = False,
        approve_production: bool = False,
        approval_file: str | Path | None = None,
    ) -> dict[str, Any]:
        requested = self._normalize_packages(packages)
        if not requested:
            return {"status": "no_packages", "packages": []}
        if not apply:
            return {
                "status": "planned",
                "packages": requested,
                "reason": "No mutation performed. Re-run with explicit production approval after sandbox validation.",
            }
        if not approve_production:
            return self._blocked("Production package installation requires approve_production=True.")
        approval = self._validate_approval(approval_file, operation="add_packages", packages=requested)
        if not approval["valid"]:
            return self._blocked(str(approval["reason"]))
        readiness = self.project_readiness()
        if not readiness["production_mutation_allowed"]:
            return self._blocked(readiness["reason"])
        backup = self._backup_current_state("add_packages")
        result = self._run_uv(["add", *requested], self.project_root)
        validation = self._run_validation(self.project_root) if result.succeeded else {"status": "not_run"}
        if result.succeeded and validation["status"] == "passed":
            event = self._append_history(
                "update_history.json",
                {"operation": "add_packages", "packages": requested, "status": "successful", "backup": backup, "approval": approval["metadata"], "timestamp": _utc_now()},
            )
            return {"status": "successful", "command": result.as_dict(), "validation": validation, "history": event}
        rollback = self._restore_backup(backup, synchronize=True)
        event = self._append_history(
            "update_history.json",
            {"operation": "add_packages", "packages": requested, "status": "rolled_back", "backup": backup, "approval": approval["metadata"], "timestamp": _utc_now()},
        )
        return {"status": "rolled_back", "command": result.as_dict(), "validation": validation, "rollback": rollback, "history": event}

    def inventory(self, packages: Iterable[str] | None = None) -> dict[str, Any]:
        installed = self._installed_distributions()
        declared = self._declared_dependencies()
        monitored = self._normalize_packages(packages or declared.keys() or self.policy["watch_packages"])
        package_records = []
        for package in monitored:
            distribution = installed.get(package)
            package_records.append(
                {
                    "package": package,
                    "declared_requirement": declared.get(package),
                    "installed_version": distribution["version"] if distribution else None,
                    "installed": distribution is not None,
                    "criticality": self._criticality(package),
                    "requires": distribution["requires"] if distribution else [],
                }
            )
        readiness = self.project_readiness()
        payload = {
            "generated_at": _utc_now(),
            "project_root": str(self.project_root),
            "python": {"executable": self.python_executable, "version": self._python_version()},
            "uv": {"executable": self.uv_executable, "version": self._uv_version()},
            "readiness": readiness,
            "declared_dependency_count": len(declared),
            "installed_distribution_count": len(installed),
            "packages": package_records,
        }
        _json_write(self.state_dir / "dependency_inventory.json", payload)
        self._record_compatibility_baseline(package_records)
        self._audit("inventory", {"package_count": len(package_records), "managed": readiness["managed"]})
        return payload

    def check_updates(
        self,
        packages: Iterable[str] | None = None,
        *,
        online: bool = False,
        release_notes_path: str | Path | None = None,
    ) -> dict[str, Any]:
        inventory = self.inventory(packages)
        records = []
        for package_record in inventory["packages"]:
            release = self._fetch_release(package_record["package"], online=online)
            release_notes = self._release_notes_for_package(
                package_record["package"],
                release,
                release_notes_path=release_notes_path,
                online=online,
            )
            advisories = self._fetch_security_advisories(package_record["package"], package_record["installed_version"], online=online)
            assessment = self._assess_upgrade(package_record, release, release_notes, advisories)
            records.append(assessment)
        monitoring = {
            "generated_at": _utc_now(),
            "online": online,
            "channel": self.policy["channel"],
            "packages": records,
        }
        _json_write(self.state_dir / "release_monitoring.json", monitoring)
        _json_write(self.state_dir / "upgrade_recommendations.json", {"generated_at": _utc_now(), "packages": records})
        _json_write(self.state_dir / "security_advisories.json", {"generated_at": _utc_now(), "online": online, "packages": advisories_for(records)})
        self._audit("check_updates", {"online": online, "package_count": len(records)})
        return monitoring

    def validate_compatibility(self, updates: dict[str, Any] | None = None) -> dict[str, Any]:
        updates_payload: dict[str, Any] = updates if isinstance(updates, dict) else _json_read(
            self.state_dir / "release_monitoring.json",
            {"packages": []},
        )
        package_results = []
        for package in updates_payload.get("packages", []):
            compatibility = package.get("python_compatibility", {})
            package_results.append(
                {
                    "package": package.get("package"),
                    "installed_version": package.get("installed_version"),
                    "latest_version": package.get("latest_version"),
                    "upgrade_allowed": compatibility.get("upgrade_allowed", False),
                    "reason": compatibility.get("reason"),
                    "recommendation": package.get("recommendation"),
                }
            )
        payload = {"generated_at": _utc_now(), "python_version": self._python_version(), "packages": package_results}
        _json_write(self.state_dir / "compatibility_report.json", payload)
        return payload

    def dependency_graph(self) -> dict[str, Any]:
        installed = self._installed_distributions()
        declared = self._declared_dependencies()
        nodes = []
        edges = []
        for package, distribution in sorted(installed.items()):
            nodes.append(
                {
                    "id": package,
                    "label": distribution["name"],
                    "version": distribution["version"],
                    "declared": package in declared,
                    "criticality": self._criticality(package),
                }
            )
            for requirement in distribution["requires"]:
                dependency = self._requirement_name(requirement)
                if dependency:
                    edges.append({"source": package, "target": dependency, "relationship": "requires", "requirement": requirement})
        payload = {"generated_at": _utc_now(), "nodes": nodes, "edges": edges}
        _json_write(self.state_dir / "dependency_graph.json", payload)
        return payload

    def validate_lockfile_integrity(self) -> dict[str, Any]:
        readiness = self.project_readiness()
        if not readiness["managed"]:
            payload = self._blocked(readiness["reason"])
            _json_write(self.state_dir / "lockfile_integrity.json", payload)
            return payload
        if not readiness["uv_available"]:
            payload = self._blocked("UV executable is unavailable; cannot validate the lockfile.")
            _json_write(self.state_dir / "lockfile_integrity.json", payload)
            return payload
        result = self._run_uv(["sync", "--frozen", "--dry-run"], self.project_root)
        payload = {
            "generated_at": _utc_now(),
            "status": "passed" if result.succeeded else "failed",
            "command": result.as_dict(),
            "pyproject_sha256": _sha256(self.project_root / "pyproject.toml"),
            "lockfile_sha256": _sha256(self.project_root / "uv.lock"),
        }
        _json_write(self.state_dir / "lockfile_integrity.json", payload)
        return payload

    def simulate_upgrade(self, package: str, *, sandbox_install: bool = False) -> dict[str, Any]:
        package = _canonical_name(package)
        readiness = self.project_readiness()
        if not readiness["managed"] or not readiness["uv_available"]:
            return self._blocked(readiness["reason"] if not readiness["managed"] else "UV executable is unavailable.")
        with tempfile.TemporaryDirectory(prefix="uv-lifecycle-sandbox-") as temporary_dir:
            sandbox_root = Path(temporary_dir) / "project"
            shutil.copytree(self.project_root, sandbox_root, ignore=self._sandbox_ignore())
            resolution = self._run_uv(["lock", "--upgrade-package", package, "--dry-run"], sandbox_root)
            payload: dict[str, Any] = {
                "generated_at": _utc_now(),
                "package": package,
                "sandbox_root": str(sandbox_root),
                "status": "resolution_failed" if not resolution.succeeded else "resolved",
                "dry_run_resolution": resolution.as_dict(),
                "sandbox_install": {"status": "not_requested"},
                "validation": {"status": "not_run"},
            }
            if not resolution.succeeded or not sandbox_install:
                _json_write(self.state_dir / "sandbox_validation.json", payload)
                return payload
            lock_result = self._run_uv(["lock", "--upgrade-package", package], sandbox_root)
            sync_result = self._run_uv(["sync", "--frozen"], sandbox_root) if lock_result.succeeded else None
            payload["sandbox_install"] = {
                "status": "passed" if lock_result.succeeded and sync_result and sync_result.succeeded else "failed",
                "lock": lock_result.as_dict(),
                "sync": sync_result.as_dict() if sync_result else None,
            }
            if payload["sandbox_install"]["status"] == "passed":
                payload["validation"] = self._run_validation(sandbox_root)
                payload["status"] = "validated" if payload["validation"]["status"] == "passed" else "validation_failed"
            _json_write(self.state_dir / "sandbox_validation.json", payload)
            self._audit("simulate_upgrade", {"package": package, "sandbox_install": sandbox_install, "status": payload["status"]})
            return payload

    def upgrade_safe_packages(
        self,
        packages: Iterable[str],
        *,
        approve_production: bool = False,
        approval_file: str | Path | None = None,
        allow_manual_review: bool = False,
        online: bool = False,
    ) -> dict[str, Any]:
        requested = self._normalize_packages(packages)
        if not approve_production:
            return self._blocked("Production upgrades require approve_production=True after sandbox validation.")
        approval = self._validate_approval(approval_file, operation="upgrade_package", packages=requested)
        if not approval["valid"]:
            return self._blocked(str(approval["reason"]))
        readiness = self.project_readiness()
        if not readiness["production_mutation_allowed"]:
            return self._blocked(readiness["reason"])
        updates = self.check_updates(requested, online=online)
        assessments = {record["package"]: record for record in updates["packages"]}
        results = []
        for package in requested:
            assessment = assessments.get(package)
            if assessment is None:
                results.append({"package": package, "status": "blocked", "reason": "No release assessment available."})
                continue
            allowed = assessment["recommendation"] == "upgrade_now" or (
                allow_manual_review and assessment["recommendation"] == "manual_review"
            )
            if not allowed:
                results.append({"package": package, "status": "blocked", "reason": assessment["recommendation"], "assessment": assessment})
                continue
            results.append(self._apply_upgrade(package, assessment, approval["metadata"]))
        return {"generated_at": _utc_now(), "status": "completed", "results": results}

    def rollback_last_upgrade(
        self,
        *,
        approve_production: bool = False,
        approval_file: str | Path | None = None,
    ) -> dict[str, Any]:
        if not approve_production:
            return self._blocked("Rollback changes the active environment and requires approve_production=True.")
        approval = self._validate_approval(approval_file, operation="rollback", packages=[])
        if not approval["valid"]:
            return self._blocked(str(approval["reason"]))
        history = _json_read(self.state_dir / "update_history.json", {"events": []})
        events = history.get("events", []) if isinstance(history, dict) else []
        successful = next((event for event in reversed(events) if event.get("status") == "successful" and event.get("backup")), None)
        if not successful:
            return self._blocked("No successful upgrade with a recorded backup is available for rollback.")
        result = self._restore_backup(successful["backup"], synchronize=True)
        self._append_history(
            "rollback_history.json",
            {"timestamp": _utc_now(), "status": result["status"], "source_update": successful, "result": result, "approval": approval["metadata"]},
        )
        return result

    def generate_health_report(
        self,
        updates: dict[str, Any] | None = None,
        skill_compatibility: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        updates_payload: dict[str, Any] = updates if isinstance(updates, dict) else _json_read(
            self.state_dir / "release_monitoring.json",
            {"packages": []},
        )
        compatibility_payload = skill_compatibility if isinstance(skill_compatibility, dict) else _json_read(
            self.state_dir / "skill_compatibility.json",
            {"checks": []},
        )
        failed_modules = {
            _canonical_name(str(check.get("module")))
            for check in compatibility_payload.get("checks", [])
            if isinstance(check, dict) and not check.get("result", {}).get("succeeded", False)
        }
        health = []
        for package in updates_payload.get("packages", []):
            score = 100
            if not package.get("installed_version"):
                score -= 40
            if package.get("update_available"):
                score -= {"patch": 5, "minor": 10, "major": 20}.get(package.get("upgrade_type"), 10)
            severity = package.get("security", {}).get("highest_severity")
            score -= {"critical": 70, "high": 45, "medium": 20, "low": 5}.get(str(severity).lower(), 0)
            if not package.get("python_compatibility", {}).get("upgrade_allowed", True):
                score -= 25
            package_name = _canonical_name(str(package.get("package") or ""))
            import_integrity = "passed"
            if package_name in failed_modules or package_name.replace("-", "_") in failed_modules:
                score = 0
                import_integrity = "failed"
            health.append(
                {
                    "package": package.get("package"),
                    "health_score": max(0, score),
                    "security": "attention" if severity else "not_checked" if not package.get("security", {}).get("checked") else "good",
                    "maintenance": "update_available" if package.get("update_available") else "current_or_unknown",
                    "compatibility": package.get("python_compatibility", {}).get("status"),
                    "framework_import_integrity": import_integrity,
                    "recommendation": package.get("recommendation"),
                }
            )
        payload = {"generated_at": _utc_now(), "packages": health}
        _json_write(self.state_dir / "package_health.json", payload)
        return payload

    def cleanup_suggestions(self) -> dict[str, Any]:
        declared = self._declared_dependencies()
        imported = self._import_roots()
        package_map = metadata.packages_distributions()
        suggestions = []
        for package in declared:
            import_names = sorted(package_map.get(package, []) or package_map.get(package.replace("-", "_"), []))
            if import_names and not any(name in imported for name in import_names):
                suggestions.append(
                    {
                        "package": package,
                        "import_names": import_names,
                        "recommendation": "manual_review",
                        "reason": "No matching import root was found; optional, plugin, dynamic, or external use remains possible.",
                    }
                )
        payload = {"generated_at": _utc_now(), "suggestions": suggestions, "import_root_count": len(imported)}
        _json_write(self.state_dir / "cleanup_suggestions.json", payload)
        return payload

    def schedule_status(self) -> dict[str, Any]:
        monitor = _json_read(self.state_dir / "release_monitoring.json", {})
        raw_last_run = monitor.get("generated_at") if isinstance(monitor, dict) else None
        last_run = self._parse_timestamp(raw_last_run)
        due: dict[str, Any] = {}
        intervals = {"daily": 1, "weekly": 7, "monthly": 30, "quarterly": 90}
        for category, schedule in self.policy["schedules"].items():
            days = intervals.get(schedule)
            if days is None:
                due[category] = {
                    "schedule": schedule,
                    "automatic": False,
                    "due": False,
                    "reason": "Manual approval or event-driven review is required.",
                }
                continue
            next_due = last_run + timedelta(days=days) if last_run else None
            due[category] = {
                "schedule": schedule,
                "automatic": True,
                "last_run": last_run.isoformat() if last_run else None,
                "next_due": next_due.isoformat() if next_due else None,
                "due": next_due is None or datetime.now(timezone.utc) >= next_due,
            }
        payload = {
            "generated_at": _utc_now(),
            "runner": "Schedule the `monitor` action in CI or Windows Task Scheduler; the manager does not install a background service.",
            "schedules": due,
        }
        _json_write(self.state_dir / "schedule_status.json", payload)
        return payload

    def scan_deprecated_api_usage(
        self,
        *,
        release_notes_path: str | Path | None = None,
        package: str | None = None,
        online: bool = False,
    ) -> dict[str, Any]:
        release = self._fetch_release(_canonical_name(package), online=online) if package else {"project_urls": {}}
        notes = self._release_notes_for_package(
            _canonical_name(package) if package else None,
            release,
            release_notes_path=release_notes_path,
            online=online,
        )
        if not notes["available"]:
            payload = {
                "generated_at": _utc_now(),
                "status": "evidence_unavailable",
                "package": package,
                "reason": "Provide --release-notes or configure a release_notes_sources entry before scanning deprecated APIs.",
                "findings": [],
            }
            _json_write(self.state_dir / "deprecated_api_report.json", payload)
            return payload
        deprecated_lines = notes["analysis"]["deprecated_features"]
        api_names = sorted(
            {
                match.group(1)
                for line in deprecated_lines
                for match in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_.]*)\s*\(", line)
            }
        )
        findings = []
        for source_path in self._source_files():
            lines = source_path.read_text(encoding="utf-8", errors="ignore").splitlines()
            for line_number, line in enumerate(lines, start=1):
                for api_name in api_names:
                    if re.search(rf"\b{re.escape(api_name)}\s*\(", line):
                        findings.append(
                            {
                                "api": api_name,
                                "path": str(source_path.relative_to(self.project_root)),
                                "line": line_number,
                                "source": line.strip(),
                            }
                        )
        payload = {
            "generated_at": _utc_now(),
            "status": "completed",
            "package": package,
            "release_notes": notes,
            "deprecated_apis": api_names,
            "findings": findings,
            "requires_manual_review": bool(findings),
        }
        _json_write(self.state_dir / "deprecated_api_report.json", payload)
        return payload

    def monitor(self, *, packages: Iterable[str] | None = None, online: bool = False) -> dict[str, Any]:
        inventory = self.inventory(packages)
        updates = self.check_updates(packages, online=online)
        compatibility = self.validate_compatibility(updates)
        graph = self.dependency_graph()
        integrity = self.validate_lockfile_integrity()
        cleanup = self.cleanup_suggestions()
        schedule = self.schedule_status()
        skill_compatibility = self.validate_skill_compatibility(self.project_root)
        health = self.generate_health_report(updates, skill_compatibility)
        deprecated_api = self.scan_deprecated_api_usage(online=online)
        summary = {
            "generated_at": _utc_now(),
            "updates_available": sum(1 for package in updates["packages"] if package.get("update_available")),
            "high_risk_updates": sum(1 for package in updates["packages"] if package.get("risk_level") in {"high", "critical"}),
            "security_updates": sum(1 for package in updates["packages"] if package.get("security", {}).get("highest_severity") in {"critical", "high"}),
            "recommendations": Counter(package.get("recommendation") for package in updates["packages"]),
            "channel": self.policy["channel"],
            "schedules": self.policy["schedules"],
        }
        _json_write(self.state_dir / "notification_summary.json", summary)
        payload = {
            "inventory": inventory,
            "updates": updates,
            "compatibility": compatibility,
            "dependency_graph": {"nodes": len(graph["nodes"]), "edges": len(graph["edges"])},
            "integrity": integrity,
            "health": health,
            "cleanup": cleanup,
            "schedule": schedule,
            "skill_compatibility": skill_compatibility,
            "deprecated_api": deprecated_api,
            "notification_summary": summary,
        }
        self._audit("monitor", {"online": online, "updates_available": summary["updates_available"]})
        return payload

    # Project and state helpers -------------------------------------------

    def project_readiness(self) -> dict[str, Any]:
        pyproject_path = self.project_root / "pyproject.toml"
        lockfile_path = self.project_root / "uv.lock"
        pyproject_exists = pyproject_path.is_file()
        lockfile_exists = lockfile_path.is_file()
        uv_available = bool(self.uv_executable)
        managed = pyproject_exists and lockfile_exists
        production_mutation_allowed = managed and uv_available
        if not pyproject_exists:
            reason = "pyproject.toml is absent; the workspace is not configured as a UV project."
        elif not lockfile_exists:
            reason = "uv.lock is absent; create and review the lockfile before lifecycle mutations."
        elif not uv_available:
            reason = "UV executable is unavailable on PATH."
        else:
            reason = "UV project and lockfile are available."
        return {
            "project_root": str(self.project_root),
            "pyproject_path": str(pyproject_path),
            "lockfile_path": str(lockfile_path),
            "pyproject_exists": pyproject_exists,
            "lockfile_exists": lockfile_exists,
            "uv_available": uv_available,
            "managed": managed,
            "production_mutation_allowed": production_mutation_allowed,
            "reason": reason,
        }

    def _ensure_state_layout(self) -> None:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        policy_path = self.state_dir / "dependency_policy.json"
        if not policy_path.is_file():
            _json_write(policy_path, DEFAULT_POLICY)
        approval_template_path = self.state_dir / "approval_template.json"
        if not approval_template_path.is_file():
            _json_write(approval_template_path, DEFAULT_APPROVAL_TEMPLATE)
        for filename, default in STATE_FILE_DEFAULTS.items():
            path = self.state_dir / filename
            if not path.is_file():
                _json_write(path, default)
        (self.state_dir / "backups").mkdir(exist_ok=True)

    def _declared_dependencies(self) -> dict[str, str]:
        pyproject_path = self.project_root / "pyproject.toml"
        if not pyproject_path.is_file():
            return {}
        try:
            document = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError):
            return {}
        specs: list[str] = []
        project = document.get("project", {}) if isinstance(document, dict) else {}
        if isinstance(project, dict):
            specs.extend(item for item in project.get("dependencies", []) if isinstance(item, str))
            optional_dependencies = project.get("optional-dependencies", {})
            if isinstance(optional_dependencies, dict):
                for group_specs in optional_dependencies.values():
                    if isinstance(group_specs, list):
                        specs.extend(item for item in group_specs if isinstance(item, str))
        dependency_groups = document.get("dependency-groups", {}) if isinstance(document, dict) else {}
        if isinstance(dependency_groups, dict):
            for group_specs in dependency_groups.values():
                if isinstance(group_specs, list):
                    specs.extend(item for item in group_specs if isinstance(item, str))
        output: dict[str, str] = {}
        for spec in specs:
            name = self._requirement_name(spec)
            if name:
                output[name] = spec
        return output

    @staticmethod
    def _requirement_name(requirement: str) -> str | None:
        packaging_requirements = _optional_module("packaging.requirements")
        if packaging_requirements is not None:
            try:
                return _canonical_name(packaging_requirements.Requirement(requirement).name)
            except Exception:
                pass
        match = PACKAGE_NAME_PATTERN.match(requirement)
        return _canonical_name(match.group(1)) if match else None

    @staticmethod
    def _installed_distributions() -> dict[str, dict[str, Any]]:
        distributions: dict[str, dict[str, Any]] = {}
        for distribution in metadata.distributions():
            name = distribution.metadata.get("Name") or getattr(distribution, "name", None)
            if not name:
                continue
            canonical = _canonical_name(str(name))
            distributions[canonical] = {
                "name": str(name),
                "version": distribution.version,
                "requires": list(distribution.requires or []),
            }
        return distributions

    def _record_compatibility_baseline(self, package_records: list[dict[str, Any]]) -> None:
        path = self.state_dir / "compatibility_matrix.json"
        payload = _json_read(path, STATE_FILE_DEFAULTS["compatibility_matrix.json"])
        matrix = payload.setdefault("matrix", {})
        python_key = f"python_{sys.version_info.major}.{sys.version_info.minor}"
        python_matrix = matrix.setdefault(python_key, {})
        for package in package_records:
            if package["installed_version"]:
                python_matrix[package["package"]] = {
                    "version": package["installed_version"],
                    "status": "observed",
                    "observed_at": _utc_now(),
                }
        _json_write(path, payload)

    def _criticality(self, package: str) -> str:
        canonical = _canonical_name(package)
        for criticality, packages in self.policy["criticality"].items():
            if canonical in {_canonical_name(item) for item in packages}:
                return criticality
        return "standard"

    def _normalize_packages(self, packages: Iterable[str]) -> list[str]:
        seen: set[str] = set()
        output: list[str] = []
        for package in packages:
            canonical = _canonical_name(str(package))
            if canonical and canonical not in seen:
                seen.add(canonical)
                output.append(canonical)
        return output

    def _python_version(self) -> str:
        return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

    def _uv_version(self) -> str | None:
        if not self.uv_executable:
            return None
        result = self._run([self.uv_executable, "--version"], self.project_root)
        return result.stdout.strip() if result.succeeded else None

    # Release, compatibility, security, and risk -------------------------

    def _fetch_release(self, package: str, *, online: bool) -> dict[str, Any]:
        result = {
            "package": package,
            "online": online,
            "status": "not_checked",
            "latest_version": None,
            "release_date": None,
            "requires_python": None,
            "project_urls": {},
            "summary": None,
        }
        if not online:
            return result
        url = f"https://pypi.org/pypi/{urllib.parse.quote(package)}/json"
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Framework-IOEM-Py-UV-Lifecycle/2.0"})
            with urllib.request.urlopen(request, timeout=15) as response:
                payload = json.loads(response.read().decode("utf-8"))
            releases = payload.get("releases", {})
            candidates = []
            for version, files in releases.items():
                if not isinstance(files, list) or not files:
                    continue
                if self.policy["channel"] == "stable" and _is_prerelease(version):
                    continue
                if all(bool(item.get("yanked")) for item in files if isinstance(item, dict)):
                    continue
                candidates.append(version)
            if not candidates:
                candidates = [str(payload.get("info", {}).get("version", ""))]
            latest = max((candidate for candidate in candidates if candidate), key=_version_sort_key, default=None)
            files = releases.get(latest, []) if latest else []
            upload_dates = [
                str(item["upload_time_iso_8601"])
                for item in files
                if isinstance(item, dict) and isinstance(item.get("upload_time_iso_8601"), str)
            ]
            info = payload.get("info", {})
            result.update(
                {
                    "status": "available",
                    "latest_version": latest,
                    "release_date": max(upload_dates) if upload_dates else None,
                    "requires_python": info.get("requires_python"),
                    "project_urls": info.get("project_urls") or {},
                    "summary": info.get("summary"),
                }
            )
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError, json.JSONDecodeError) as error:
            result.update({"status": "unavailable", "error": str(error)})
        return result

    def _fetch_security_advisories(self, package: str, version: str | None, *, online: bool) -> dict[str, Any]:
        result = {"package": package, "version": version, "checked": online, "advisories": [], "highest_severity": None}
        if not online or not version:
            return result
        try:
            request = urllib.request.Request(
                "https://api.osv.dev/v1/query",
                data=json.dumps({"package": {"name": package, "ecosystem": "PyPI"}, "version": version}).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "Framework-IOEM-Py-UV-Lifecycle/2.0"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=15) as response:
                payload = json.loads(response.read().decode("utf-8"))
            advisories = []
            severities = []
            for vulnerability in payload.get("vulns", []):
                database_specific = vulnerability.get("database_specific") or {}
                severity = str(database_specific.get("severity") or "unknown").lower()
                advisories.append(
                    {
                        "id": vulnerability.get("id"),
                        "summary": vulnerability.get("summary"),
                        "details": vulnerability.get("details"),
                        "severity": severity,
                        "aliases": vulnerability.get("aliases", []),
                    }
                )
                severities.append(severity)
            ranking = {"critical": 4, "high": 3, "medium": 2, "low": 1, "unknown": 0}
            result.update({"advisories": advisories, "highest_severity": max(severities, key=lambda item: ranking.get(item, 0), default=None)})
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError, json.JSONDecodeError) as error:
            result.update({"error": str(error)})
        return result

    def _release_notes_for_package(
        self,
        package: str | None,
        release: dict[str, Any],
        *,
        release_notes_path: str | Path | None,
        online: bool,
    ) -> dict[str, Any]:
        source: str | Path | None = release_notes_path
        if source is None and package:
            source = self.policy.get("release_notes_sources", {}).get(package)
        if source is None and online:
            project_urls = release.get("project_urls") or {}
            source = next(
                (
                    url
                    for label, url in project_urls.items()
                    if isinstance(label, str)
                    and isinstance(url, str)
                    and any(token in label.lower() for token in ("release", "change", "history"))
                ),
                None,
            )
        return self._load_release_notes(source, online=online)

    def _load_release_notes(self, source: str | Path | None, *, online: bool) -> dict[str, Any]:
        if not source:
            return {"available": False, "source": None, "analysis": self.analyze_release_notes("")}
        source_text = str(source)
        if source_text.startswith(("https://", "http://")):
            if not online:
                return {"available": False, "source": source_text, "error": "online monitoring is disabled", "analysis": self.analyze_release_notes("")}
            try:
                request = urllib.request.Request(source_text, headers={"User-Agent": "Framework-IOEM-Py-UV-Lifecycle/2.0"})
                with urllib.request.urlopen(request, timeout=15) as response:
                    text = response.read(1_000_000).decode("utf-8", errors="replace")
                return {"available": True, "source": source_text, "analysis": self.analyze_release_notes(text)}
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as error:
                return {"available": False, "source": source_text, "error": str(error), "analysis": self.analyze_release_notes("")}
        path = Path(source_text).expanduser()
        if not path.is_file():
            return {"available": False, "source": str(path), "error": "file not found", "analysis": self.analyze_release_notes("")}
        text = path.read_text(encoding="utf-8", errors="replace")
        return {"available": True, "source": str(path.resolve()), "analysis": self.analyze_release_notes(text)}

    @staticmethod
    def analyze_release_notes(text: str) -> dict[str, Any]:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        lowered_lines = [(line, line.lower()) for line in lines]
        breaking = [line for line, lowered in lowered_lines if any(term in lowered for term in BREAKING_TERMS)]
        deprecated = [line for line, lowered in lowered_lines if any(term in lowered for term in DEPRECATION_TERMS)]
        security = [line for line, lowered in lowered_lines if any(term in lowered for term in SECURITY_TERMS)]
        return {
            "breaking_changes_detected": bool(breaking),
            "breaking_change_lines": breaking[:20],
            "deprecated_features": deprecated[:20],
            "security_fix_lines": security[:20],
            "status": "analyzed" if text.strip() else "evidence_unavailable",
        }

    def _python_compatibility(self, requires_python: str | None) -> dict[str, Any]:
        if not requires_python:
            return {"status": "not_declared", "upgrade_allowed": True, "reason": "Package metadata did not declare Requires-Python."}
        specifiers = _optional_module("packaging.specifiers")
        if specifiers is None:
            return {"status": "unknown", "upgrade_allowed": False, "reason": "packaging.specifiers is unavailable; compatibility cannot be proven."}
        try:
            specifier = specifiers.SpecifierSet(requires_python)
            allowed = bool(specifier.contains(self._python_version(), prereleases=True))
            return {
                "status": "compatible" if allowed else "incompatible",
                "upgrade_allowed": allowed,
                "reason": f"Framework Python {self._python_version()} {'satisfies' if allowed else 'does not satisfy'} {requires_python}.",
            }
        except Exception as error:
            return {"status": "unknown", "upgrade_allowed": False, "reason": f"Could not parse Requires-Python {requires_python!r}: {error}"}

    @staticmethod
    def _upgrade_type(installed: str | None, latest: str | None) -> str:
        current_parts = _version_parts(installed)
        latest_parts = _version_parts(latest)
        if not installed or not latest:
            return "unknown"
        if installed == latest:
            return "none"
        if current_parts is None or latest_parts is None:
            return "unknown"
        if current_parts[0] != latest_parts[0]:
            return "major"
        if current_parts[1] != latest_parts[1]:
            return "minor"
        return "patch"

    def _assess_upgrade(
        self,
        package_record: dict[str, Any],
        release: dict[str, Any],
        release_notes: dict[str, Any],
        security: dict[str, Any],
    ) -> dict[str, Any]:
        installed_version = package_record.get("installed_version")
        latest_version = release.get("latest_version")
        update_available = bool(installed_version and latest_version and installed_version != latest_version)
        upgrade_type = self._upgrade_type(installed_version, latest_version)
        compatibility = self._python_compatibility(release.get("requires_python")) if latest_version else {"status": "unknown", "upgrade_allowed": False, "reason": "Latest release metadata is unavailable."}
        notes = release_notes["analysis"]
        if not update_available:
            risk_score = 0
            risk_level = "none"
        else:
            score = {"patch": 10, "minor": 35, "major": 70, "unknown": 50}.get(upgrade_type, 50)
            score += {"critical": 15, "standard": 5, "optional": 0}.get(package_record["criticality"], 5)
            if notes["breaking_changes_detected"]:
                score += 25
            if notes["deprecated_features"]:
                score += 10
            if not compatibility["upgrade_allowed"]:
                score = 100
            risk_score = min(100, score)
            risk_level = "critical" if risk_score >= 85 else "high" if risk_score >= 60 else "medium" if risk_score >= 30 else "low"
        severity = security.get("highest_severity")
        if not update_available:
            recommendation = "wait"
            reason = "No newer release is known for the installed version."
        elif not compatibility["upgrade_allowed"]:
            recommendation = "avoid_upgrade"
            reason = compatibility["reason"]
        elif upgrade_type == "major" or notes["breaking_changes_detected"]:
            recommendation = "manual_review"
            reason = "Major version or release-note breaking change requires manual approval after sandbox validation."
        elif severity in {"critical", "high"}:
            recommendation = "upgrade_now" if upgrade_type == "patch" else "manual_review"
            reason = "Security advisory requires out-of-band review; production approval remains mandatory."
        elif upgrade_type == "patch" and risk_score <= int(self.policy["max_patch_risk_score"]):
            recommendation = "upgrade_now"
            reason = "Compatible low-risk patch release; sandbox validation is still required."
        else:
            recommendation = "manual_review"
            reason = "Minor or elevated-risk update requires sandbox validation and review."
        return {
            "package": package_record["package"],
            "criticality": package_record["criticality"],
            "installed_version": installed_version,
            "latest_version": latest_version,
            "release_date": release.get("release_date"),
            "requires_python": release.get("requires_python"),
            "update_available": update_available,
            "upgrade_type": upgrade_type,
            "python_compatibility": compatibility,
            "release": release,
            "release_notes": release_notes,
            "security": security,
            "risk_score": risk_score,
            "risk_level": risk_level,
            "recommendation": recommendation,
            "reason": reason,
        }

    # Sandbox and production mutation -------------------------------------

    def _apply_upgrade(
        self,
        package: str,
        assessment: dict[str, Any],
        approval: dict[str, Any],
    ) -> dict[str, Any]:
        backup = self._backup_current_state(f"upgrade_{package}")
        lock_result = self._run_uv(["lock", "--upgrade-package", package], self.project_root)
        sync_result = self._run_uv(["sync", "--frozen"], self.project_root) if lock_result.succeeded else None
        validation = self._run_validation(self.project_root) if sync_result and sync_result.succeeded else {"status": "not_run"}
        if lock_result.succeeded and sync_result and sync_result.succeeded and validation["status"] == "passed":
            event = self._append_history(
                "update_history.json",
                {
                    "timestamp": _utc_now(),
                    "operation": "upgrade_package",
                    "package": package,
                    "old_version": assessment.get("installed_version"),
                    "new_version": assessment.get("latest_version"),
                    "status": "successful",
                    "backup": backup,
                    "assessment": assessment,
                    "approval": approval,
                },
            )
            return {"package": package, "status": "successful", "lock": lock_result.as_dict(), "sync": sync_result.as_dict(), "validation": validation, "history": event}
        rollback = self._restore_backup(backup, synchronize=True)
        event = self._append_history(
            "update_history.json",
            {
                "timestamp": _utc_now(),
                "operation": "upgrade_package",
                "package": package,
                "old_version": assessment.get("installed_version"),
                "new_version": assessment.get("latest_version"),
                "status": "rolled_back",
                "backup": backup,
                "assessment": assessment,
                "approval": approval,
            },
        )
        return {
            "package": package,
            "status": "rolled_back",
            "lock": lock_result.as_dict(),
            "sync": sync_result.as_dict() if sync_result else None,
            "validation": validation,
            "rollback": rollback,
            "history": event,
        }

    def _validate_approval(
        self,
        approval_file: str | Path | None,
        *,
        operation: str,
        packages: Iterable[str],
    ) -> dict[str, Any]:
        if approval_file is None:
            return {"valid": False, "reason": "Production mutation requires --approval-file with reviewed approval provenance."}
        path = Path(approval_file).expanduser().resolve()
        if not path.is_file():
            return {"valid": False, "reason": f"Approval file not found: {path}"}
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            return {"valid": False, "reason": f"Approval file is not valid JSON: {error}"}
        if not isinstance(document, dict):
            return {"valid": False, "reason": "Approval file must contain a JSON object."}
        missing = [field for field in self.policy.get("approval_requirements", []) if not document.get(field)]
        if missing:
            return {"valid": False, "reason": f"Approval metadata is missing required field(s): {', '.join(missing)}"}
        if str(document.get("status", "")).lower() != "approved":
            return {"valid": False, "reason": "Approval metadata status must be 'approved'."}
        if str(document.get("risk_class", "")).lower() not in {"low", "medium", "high", "critical"}:
            return {"valid": False, "reason": "Approval metadata risk_class must be low, medium, high, or critical."}
        approved_at = self._parse_timestamp(document.get("approved_at"))
        if approved_at is None or approved_at.tzinfo is None:
            return {"valid": False, "reason": "Approval metadata approved_at must be an ISO timestamp with timezone."}
        validation_evidence = document.get("validation_evidence")
        if not isinstance(validation_evidence, list) or not validation_evidence or not all(isinstance(item, str) and item for item in validation_evidence):
            return {"valid": False, "reason": "Approval metadata validation_evidence must be a non-empty string list."}
        operations = document.get("operations", ["all"])
        if not isinstance(operations, list) or not all(isinstance(item, str) for item in operations):
            return {"valid": False, "reason": "Approval metadata operations must be a string list."}
        if "all" not in operations and operation not in operations:
            return {"valid": False, "reason": f"Approval does not authorize operation '{operation}'."}
        requested_packages = set(self._normalize_packages(packages))
        approved_packages = document.get("packages", ["all"])
        if not isinstance(approved_packages, list) or not all(isinstance(item, str) for item in approved_packages):
            return {"valid": False, "reason": "Approval metadata packages must be a string list."}
        approved = set(self._normalize_packages(approved_packages))
        if requested_packages and "all" not in approved and not requested_packages.issubset(approved):
            return {"valid": False, "reason": "Approval does not cover every requested package."}
        expires_at = document.get("expires_at")
        if expires_at:
            expiry = self._parse_timestamp(expires_at)
            if expiry is None or expiry.tzinfo is None:
                return {"valid": False, "reason": "Approval metadata expires_at must be an ISO timestamp with timezone."}
            if datetime.now(timezone.utc) > expiry:
                return {"valid": False, "reason": "Approval metadata has expired."}
        metadata = {
            "source": str(path),
            "sha256": _sha256(path),
            "approval_provenance": "metadata_only_not_cryptographically_verified",
            **document,
        }
        return {"valid": True, "metadata": metadata}

    def _backup_current_state(self, operation: str) -> dict[str, Any]:
        backup_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_{_canonical_name(operation)}"
        backup_dir = self.state_dir / "backups" / backup_id
        backup_dir.mkdir(parents=True, exist_ok=True)
        files = []
        for filename in ("pyproject.toml", "uv.lock"):
            source = self.project_root / filename
            if source.is_file():
                destination = backup_dir / filename
                shutil.copy2(source, destination)
                files.append({"name": filename, "path": str(destination), "sha256": _sha256(destination)})
        manifest = {"id": backup_id, "operation": operation, "created_at": _utc_now(), "files": files}
        _json_write(backup_dir / "manifest.json", manifest)
        return manifest

    def _restore_backup(self, backup: dict[str, Any], *, synchronize: bool) -> dict[str, Any]:
        backup_dir = self.state_dir / "backups" / str(backup["id"])
        if not backup_dir.is_dir():
            return {"status": "failed", "reason": f"Backup directory not found: {backup_dir}"}
        restored = []
        for file_record in backup.get("files", []):
            filename = file_record.get("name")
            source = backup_dir / str(filename)
            if source.is_file():
                shutil.copy2(source, self.project_root / str(filename))
                restored.append(str(filename))
        sync = self._run_uv(["sync", "--frozen"], self.project_root) if synchronize and self.uv_executable else None
        status = "successful" if restored and (sync is None or sync.succeeded) else "failed"
        return {"status": status, "restored": restored, "sync": sync.as_dict() if sync else None}

    def _run_validation(self, cwd: Path) -> dict[str, Any]:
        commands = self.policy.get("validation_commands", [])
        results = []
        validation_python = self._validation_python(cwd)
        for command_template in commands:
            if not isinstance(command_template, list) or not all(isinstance(item, str) for item in command_template):
                results.append({"status": "invalid_policy", "command": command_template})
                continue
            command = [
                item.replace("{python}", validation_python).replace("{uv}", self.uv_executable or "uv")
                for item in command_template
            ]
            result = self._run(command, cwd, timeout=300)
            results.append(result.as_dict())
        skill_compatibility = self.validate_skill_compatibility(cwd, python_executable=validation_python)
        command_status = "passed" if results and all(result.get("succeeded") for result in results) else "failed" if results else "not_configured"
        status = "passed" if command_status in {"passed", "not_configured"} and skill_compatibility["status"] == "passed" else "failed"
        payload = {
            "timestamp": _utc_now(),
            "cwd": str(cwd),
            "status": status,
            "command_status": command_status,
            "results": results,
            "skill_compatibility": skill_compatibility,
        }
        self._append_history("validation_results.json", payload, key="runs")
        return payload

    def validate_skill_compatibility(self, cwd: Path | None = None, *, python_executable: str | None = None) -> dict[str, Any]:
        working_directory = cwd or self.project_root
        selected_python = python_executable or self._validation_python(working_directory)
        checks = self.policy.get("skill_import_checks", [])
        results = []
        for check in checks:
            if not isinstance(check, dict):
                continue
            skill = str(check.get("skill", "unknown"))
            for module_name in check.get("modules", []):
                command = [selected_python, "-c", f"import importlib; importlib.import_module({module_name!r})"]
                result = self._run(command, working_directory, timeout=60)
                results.append({"skill": skill, "module": module_name, "result": result.as_dict()})
        payload = {
            "generated_at": _utc_now(),
            "cwd": str(working_directory),
            "python": selected_python,
            "status": "passed" if results and all(item["result"]["succeeded"] for item in results) else "failed" if results else "not_configured",
            "checks": results,
        }
        _json_write(self.state_dir / "skill_compatibility.json", payload)
        return payload

    def _sandbox_ignore(self) -> Any:
        ignored_names = {".git", ".venv", "__pycache__", "test_logs", "test_results", self.state_dir.name}
        return shutil.ignore_patterns(*ignored_names)

    def _validation_python(self, cwd: Path) -> str:
        candidate = cwd / ".venv" / "Scripts" / "python.exe"
        return str(candidate) if candidate.is_file() else self.python_executable

    # Runtime, audit, and cleanup -----------------------------------------

    def _run_uv(self, arguments: Sequence[str], cwd: Path, timeout: int = 300) -> CommandResult:
        if not self.uv_executable:
            return CommandResult([], str(cwd), None, "", "", error="uv executable not found")
        return self._run([self.uv_executable, *arguments], cwd, timeout=timeout)

    @staticmethod
    def _run(command: Sequence[str], cwd: Path, timeout: int = 120) -> CommandResult:
        command_list = [str(item) for item in command]
        try:
            process = subprocess.run(command_list, cwd=str(cwd), text=True, capture_output=True, timeout=timeout, check=False)
            return CommandResult(command_list, str(cwd), process.returncode, process.stdout[-12000:], process.stderr[-12000:])
        except subprocess.TimeoutExpired as error:
            return CommandResult(command_list, str(cwd), None, str(error.stdout or ""), str(error.stderr or ""), timed_out=True, error=f"Timed out after {timeout} seconds")
        except OSError as error:
            return CommandResult(command_list, str(cwd), None, "", "", error=str(error))

    def _append_history(self, filename: str, event: dict[str, Any], key: str = "events") -> dict[str, Any]:
        path = self.state_dir / filename
        payload = _json_read(path, {"schema_version": 1, key: []})
        if not isinstance(payload, dict):
            payload = {"schema_version": 1, key: []}
        values = payload.setdefault(key, [])
        if not isinstance(values, list):
            values = []
            payload[key] = values
        values.append(event)
        _json_write(path, payload)
        return event

    def _audit(self, event_type: str, details: dict[str, Any]) -> None:
        path = self.state_dir / "audit_trail.jsonl"
        record = {"timestamp": _utc_now(), "event": event_type, "details": details}
        with path.open("a", encoding="utf-8") as audit_file:
            audit_file.write(json.dumps(record, ensure_ascii=False) + "\n")

    def _import_roots(self) -> set[str]:
        roots: set[str] = set()
        for path in self._source_files():
            try:
                tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    roots.update(alias.name.split(".")[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    roots.add(node.module.split(".")[0])
        return roots

    def _source_files(self) -> Iterable[Path]:
        excluded = {".git", ".venv", "__pycache__", "test_logs", "test_results", self.state_dir.name}
        for path in self.project_root.rglob("*.py"):
            if not any(part in excluded for part in path.parts):
                yield path

    @staticmethod
    def _parse_timestamp(value: Any) -> datetime | None:
        if not isinstance(value, str):
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None

    @staticmethod
    def _blocked(reason: str) -> dict[str, Any]:
        return {"status": "blocked", "reason": reason, "timestamp": _utc_now()}


def advisories_for(records: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return [record.get("security", {}) for record in records]


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Safe UV dependency lifecycle management.")
    parser.add_argument("action", choices=("inventory", "monitor", "updates", "compatibility", "graph", "integrity", "cleanup", "schedule", "deprecated-api", "simulate", "apply", "rollback", "health"))
    parser.add_argument("--project-root", default=".", help="UV project root; defaults to the current directory")
    parser.add_argument("--state-dir", help="Dependency lifecycle state directory; defaults to <project-root>/tests/dependency_management")
    parser.add_argument("--package", action="append", default=[], help="Package to monitor, simulate, or upgrade; repeat as needed")
    parser.add_argument("--online", action="store_true", help="Permit PyPI and OSV release/security queries")
    parser.add_argument("--channel", choices=("stable", "latest", "experimental"), help="Release channel")
    parser.add_argument("--release-notes", help="Optional local release-notes file for breaking/deprecation analysis")
    parser.add_argument("--sandbox-install", action="store_true", help="Install and validate in a temporary sandbox after dry-run resolution")
    parser.add_argument("--approve-production", action="store_true", help="Explicitly authorize active project mutation; structured approval provenance is also required")
    parser.add_argument("--approval-file", help="Reviewed JSON approval metadata required for apply, ensure_packages, and rollback")
    parser.add_argument("--allow-manual-review", action="store_true", help="Allow explicitly approved minor/major/manual-review upgrades during apply")
    return parser


def main() -> int:
    args = build_argument_parser().parse_args()
    manager = UVPackageManagerSkill(args.project_root, state_dir=args.state_dir, channel=args.channel)
    packages = args.package or None
    if args.action == "inventory":
        payload = manager.inventory(packages)
    elif args.action == "monitor":
        payload = manager.monitor(packages=packages, online=args.online)
    elif args.action == "updates":
        payload = manager.check_updates(packages, online=args.online, release_notes_path=args.release_notes)
    elif args.action == "compatibility":
        payload = manager.validate_compatibility()
    elif args.action == "graph":
        payload = manager.dependency_graph()
    elif args.action == "integrity":
        payload = manager.validate_lockfile_integrity()
    elif args.action == "cleanup":
        payload = manager.cleanup_suggestions()
    elif args.action == "schedule":
        payload = manager.schedule_status()
    elif args.action == "deprecated-api":
        payload = manager.scan_deprecated_api_usage(
            release_notes_path=args.release_notes,
            package=args.package[0] if args.package else None,
            online=args.online,
        )
    elif args.action == "simulate":
        if len(args.package) != 1:
            raise SystemExit("simulate requires exactly one --package")
        payload = manager.simulate_upgrade(args.package[0], sandbox_install=args.sandbox_install)
    elif args.action == "apply":
        if not args.package:
            raise SystemExit("apply requires one or more --package values")
        payload = manager.upgrade_safe_packages(
            args.package,
            approve_production=args.approve_production,
            approval_file=args.approval_file,
            allow_manual_review=args.allow_manual_review,
            online=args.online,
        )
    elif args.action == "rollback":
        payload = manager.rollback_last_upgrade(approve_production=args.approve_production, approval_file=args.approval_file)
    else:
        payload = manager.generate_health_report()
    print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())