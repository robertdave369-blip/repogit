# Architecture — module map

The design rationale lives in
[`docs/document-understanding/architecture.md`](../../../docs/document-understanding/architecture.md).
This file is the map of what calls what, kept short so it does not drift from the code.

## Modules

| Module | Responsibility | Depends on |
|---|---|---|
| `udu/model.py` | `Element`, `Source`, `Relationship`, `Document`, `Basis`, id generation | stdlib only |
| `udu/security.py` | size caps, zip-bomb and traversal guards, safe XML parser, injection scanning and fencing | stdlib, optional lxml |
| `udu/spreadsheet.py` | `SheetGrid`, region detection, row roles, header paths, column semantics, formula analysis | stdlib only |
| `udu/adapters.py` | detection, routing, one `_build_*` per format, injection scan pass | model, security, spreadsheet, optional parsers |
| `udu/compile.py` | `compile_context`, `to_markdown` | model, security |
| `udu/chunk.py` | structural chunking with context headers | model |
| `document_understand.py` | CLI, debug stages, validation gate | all of the above |

`udu/spreadsheet.py` is deliberately free of any import from `model.py` — it is pure
structure analysis over a grid, so it can be tested and reasoned about without the element
graph.

## Call flow

    document_understand.main
      └── adapters.build(path)
            ├── security.guard_file
            ├── adapters.detect
            ├── security.guard_archive        (zip containers)
            ├── _build_<format>
            │     └── (xlsx) _read_grid → spreadsheet.analyse_sheet → _emit_region
            └── _scan_for_injection → security.scan_text
      ├── compile.compile_context / compile.to_markdown
      ├── chunk.chunk_document
      └── _validate / _debug_stages

## Reuse

`udu/__init__.py::load_sibling` imports `document_context.py` and
`pdf_document_intelligence.py` by file path. These are standalone CLI scripts, not an
installed package, so there is no import path to them.

The module is registered in `sys.modules` **before** `exec_module`: on Python 3.14
`@dataclass` resolves `cls.__module__` through `sys.modules` and raises without it.

## Adding a format

1. Write `_build_<fmt>(path, doc, root, deep)` in `adapters.py`.
2. Add it to `dispatch` in `build()`.
3. Add a signature or container rule to `detect()` if it is not already recognised.
4. Emit elements with a `Source` and an honest `Basis`.
5. Add a test with a real fixture file.

Nothing downstream changes — the compiler, chunker, validator and debugger are
format-blind by construction.
