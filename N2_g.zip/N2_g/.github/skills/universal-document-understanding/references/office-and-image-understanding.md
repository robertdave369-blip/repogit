# Office documents, images and charts

## Word (DOCX)

`_build_docx` uses **python-docx**.

| Output | Basis |
|---|---|
| core properties (title, author, modified) | `EXTRACTED` |
| heading hierarchy from `Heading N` / `Title` styles | `EXTRACTED` |
| **sections built from that hierarchy** | `INFERRED` (confidence 0.95) |
| paragraphs, list items (`List*` styles) | `EXTRACTED` |
| captions (`Caption` style or `Figure N` text) | `INFERRED` |
| tables, header row, cells, header-to-cell edges | `EXTRACTED` |
| embedded images via the relationship table | `EXTRACTED` |
| `follows` edges preserving document order | `EXTRACTED` |

A heading opens a `SECTION`; the stack pops on an equal-or-higher level, so `Heading 3`
after `Heading 1` nests correctly. Every paragraph therefore knows its section, which is
what makes a chunk answerable.

**Not extracted:** headers/footers, footnotes/endnotes, comments, tracked changes,
text-box content, nested-table structure beyond the outer table. Legacy `.doc` is detected
and routed to docling when installed — never to a LibreOffice subprocess.

## PowerPoint (PPTX)

`_build_pptx` uses **python-pptx** (optional install). Slides become `SLIDE` elements with
the slide title, layout name, text frames and picture shapes. Speaker notes, animations
and grouped-shape structure are not extracted.

## Long-tail formats

ODT, ODS, ODP, EPUB, `.eml`, `.msg`, RTF, LaTeX and AsciiDoc route to **docling**
(`docling-slim`, MIT). Its items are *mapped* into our element graph rather than adopted
wholesale, because our consumers rely on typed relationships, an authority classification
and a `basis` on every element — none of which `DoclingDocument` carries. One
representation across all formats is worth the mapping.

When docling is absent the format is reported unsupported **with the install command**:

    py -3 -m pip install "docling-slim[format-opendocument]"

## Images

`_build_image` uses **Pillow** for dimensions, mode, format and EXIF, then classifies.

### Why classify before describing

Sending every decorative rule to a vision model is expensive and pointless. Triage is
cheap — colour count and aspect ratio only — and each call records **why**:

| Class | Trigger |
|---|---|
| `decorative` | degenerate dimensions, or aspect ratio beyond 12:1 |
| `logo` | small (<40 kpx) with under 64 distinct colours |
| `diagram` | flat palette (<32 colours) |
| `chart` | limited palette (<400 colours) — **confidence 0.4, genuinely uncertain** |
| `screenshot` | wide, >=1000 px, colour-rich |
| `photo` | colour-rich, no other signal |

All of these are `INFERRED`, with `image_class_confidence` and
`image_class_rationale` recorded so a wrong call is debuggable rather than mysterious.
`chart` at 0.4 says plainly that it could equally be a diagram or a screenshot.

### What this tool will not do

**It never describes an image.** There is no vision model in this pipeline, and inventing
"a bar chart showing revenue growth" from a filename is exactly the failure this framework
exists to prevent. The report says so explicitly:

    unsupported: "visual description — no vision model is invoked by this tool; an agent
                  that can see images should read the file directly and record its
                  description as MODEL_GENERATED"

If you can see images, open the file and record your own reading, tagged
`MODEL_GENERATED`.

## Charts

**Chart data extraction is not implemented, and no chart is described from guesswork.**

What exists upstream, for when this is built:

* openpyxl exposes chart definitions in XLSX — title, series, category and value range
  references. Docling's Excel backend already reads these
  (`msexcel_backend.py:1529-1796`), which is the model to follow.
* Docling's `stages/chart_extraction` offers `chart2csv`, `chart2code` and `chart2summary`
  — but only under the `models-local` torch install.

Until that is wired through, a chart in a workbook is **absent from the output**, not
approximated. A chart rendered as an image in a PDF is a `FIGURE` classified as `chart`
with confidence 0.4, its caption and its surrounding text — enough context for a
vision-capable agent to take over, and nothing invented.

The rule from the specification holds: *do not invent numerical values that cannot be
reliably extracted.*
