# PDF understanding

## What is extracted

`udu/adapters.py::_build_pdf` uses **PyMuPDF**. Per page:

| Output | Basis | Notes |
|---|---|---|
| page count, size, rotation | `EXTRACTED` | including unusual page sizes |
| document metadata, TOC | `EXTRACTED` | TOC entries seed the section context |
| text blocks with bounding boxes | `EXTRACTED` | `page.get_text("dict")` |
| reading order | `EXTRACTED` | PyMuPDF block order, recorded as `reading_order` |
| headings | `INFERRED` | font size >= 13, or bold and short; confidence 0.8 |
| captions | `INFERRED` | text matching `Figure|Fig.|Table|Chart|Exhibit|Diagram` + number |
| figures | `EXTRACTED` | image blocks (`type == 1`) with bbox |
| caption-to-figure binding | `INFERRED` | nearest bbox centre on the same page |
| OCR text | `MODEL_GENERATED` | only with `--ocr`, confidence from the engine |

Every block keeps `page`, `bbox` and the current `section`, so any sentence can be cited
as `guide.pdf -> p.14`.

## Multi-column layouts

PyMuPDF returns blocks in its own reading order, which handles most two-column layouts
correctly. It is recorded as `reading_order` on each block **as extracted**, not as a
claim about visual order. Where a layout is genuinely ambiguous — rotated pages, sidebars,
tables spanning columns — the block order may not match how a human reads. Check with:

    document_understand.py debug report.pdf --stage reading_order

A model-based reading-order stage (docling's `stages/reading_order`) exists but requires
the torch install; it is deliberately not a default.

## Scanned PDFs

A PDF with a text layer under **40 characters per page** is flagged:

    "likely_scanned": true
    partial: "pdf text layer — only 12 characters across 19 page(s) —
              this looks like a scanned PDF; re-run with --ocr to read it"

This is reported rather than silently returning an empty document, which is the failure
mode that makes an agent conclude "the PDF is empty."

`--ocr` uses **RapidOCR** (ONNX, pure wheels, no system binary). It downloads models on
first use, so it is opt-in. Output is `MODEL_GENERATED` with the engine's per-region
confidence and a bounding box.

## Figures and captions

A caption is bound to the figure whose bbox centre is vertically nearest, and the edge is
recorded both ways (`caption_for` and `references`). When a page has captions but no
raster image blocks — common when the graphic is vector art — the caption keeps its text
and carries **no** `caption_for` edge. That is honest: no figure was found.

## Answering "what does Figure 7 mean?"

    document_understand.py search report.pdf "Figure 7"

returns the caption element with its page and section. Then:

    document_understand.py context report.pdf --level 3

gives the figure entry with `caption`, `section`, `bbox`, `surrounding_text` and, if
`--ocr` ran, `ocr_text`. **The tool never describes the picture.** If you can see images,
open the page yourself and record your reading as `MODEL_GENERATED`.

## Not supported, and not faked

* **Mathematical formula recognition** — an integral or summation rendered as an image
  stays an image. MinerU's `mfr` stack is the tool for this and is rejected here (see
  `research/document-parsers/research-notes.md`); docling's `code_formula` stage needs the
  torch install. Formula images are reported, never guessed.
* **Nested tables** and ruled-table structure inside PDF — PDF has no table object; a
  table is visual. Text blocks are extracted with coordinates, but cell structure is not
  reconstructed. Where a PDF table matters, `pdfplumber` is installed and is the right
  tool for a targeted read.
* **Annotations, form fields, hyperlink targets** are not yet extracted.
