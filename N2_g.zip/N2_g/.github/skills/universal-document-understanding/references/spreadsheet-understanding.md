# Spreadsheet understanding

How `udu/spreadsheet.py` turns a worksheet into meaning, and exactly how much each output
is worth trusting.

## The premise

A worksheet is a **canvas**, not a table. A typical engineering or finance sheet holds
several tables separated by blank rows, each introduced by a merged title, each topped by
a header band two or three rows deep. Reading it as a rectangle of cells discards most of
what a person reads off it in a glance.

## Pipeline

    workbook
      -> dual load (data_only=False for formulas, data_only=True for values)
      -> SheetGrid (occupied cells, merged ranges, spans, hidden rows/cols)
      -> region detection      (connected components)
      -> row classification    (title / header / data / subtotal / total / note)
      -> header path resolution (merged spans projected down the band)
      -> column semantics      (type + unit)
      -> formula analysis      (dependencies, functions)
      -> elements + typed relationships

## Trust table

| Output | Basis | Method |
|---|---|---|
| cell value, formula, cached value | `EXTRACTED` | openpyxl, dual pass |
| merged ranges, anchors, spans | `EXTRACTED` | `ws.merged_cells.ranges` |
| hidden rows / columns, defined names | `EXTRACTED` | openpyxl dimensions |
| region (sub-table) boundaries | `INFERRED` | connected components over occupied cells |
| row roles | `INFERRED` | position, arity, lexical cues |
| hierarchical header paths | `INFERRED` | merge spans projected down the header band |
| column semantic type, unit | `INFERRED` | number format first, values second |
| formula dependencies | `EXTRACTED` | lexical reference parse |

Nothing invents a value. When a header cannot be resolved the column keeps its letter.

## 1. Region detection

Occupied cells (**anchors and their shadow cells both count** — otherwise a merged title
would be disconnected from the table beneath it) form a graph with **8-way adjacency**;
each connected component becomes a `Region`, and overlapping bounding boxes are merged.

8-way rather than 4-way is deliberate: a single blank spacer column inside a table would
otherwise split it in two, and diagonal contact keeps a header row attached to data that
starts one column further in.

Reimplemented from Unstructured's `nx.grid_2d_graph` approach
(`partition/xlsx.py:282-335`) as an explicit BFS — no `networkx`, and no node per empty
cell on a sparse 7,000-row sheet.

Above 400,000 occupied cells, region detection is skipped and the whole sheet is treated
as one region, **reported** as a partial result rather than silently degraded.

## 2. Row roles

Top-down for titles and headers (that is the only place they can be), bottom-up for notes.

* **Title** — leading rows with exactly one populated, non-numeric cell. The first becomes
  the region title and the parent section.
* **Note** — trailing single-cell rows matching `note|source|footnote|*|(1)`.
* **Header band** — leading body rows containing no *hard* numeric value.
  **A numeric that is a period label does not break the band.** `2025`, `Q1`, `H1`,
  `FY2026`, `Jan` are headers. A row carrying a horizontal merge also stays in the band,
  because a merge is authorial intent that the row spans columns. Capped at 4 rows.
* **Total / subtotal** — first-cell text matching `total|grand total|sum|overall` or
  `subtotal`. Tagged, and given a `total_of` edge.
* **Data** — everything else. Data is the safe default: misreading data as a total drops
  it from aggregation, while the reverse merely adds a row.

> **Why the period rule exists.** Without it, a band of `2025 | 2026` over
> `Q1 | Q2 | Q1 | Q2` was cut after one row, and all four quarter columns collapsed onto
> the single label `Revenue` — four distinct measures reported under one ambiguous name,
> in output that looked perfectly well-formed. Pinned by
> `test_header_paths_are_hierarchical_and_distinct_regression`.

## 3. Merged cells

Following Docling's anchor/shadow design (`msexcel_backend.py:154-212`) — the design, not
the code:

* the **anchor** (top-left) holds the value and records `merged_anchor_for` plus
  `span: {rows, cols}`;
* every other covered cell records `covered_by` and a `merged_with` edge to the anchor;
* a merged **title** becomes a `SECTION` element, and the table below is its child with a
  `belongs_to_section` edge.

So `A1:D1 = "Financial Results"` is not four cells, three of them empty. It is:

    section  "Financial Results"   (merged_anchor_for A1:D1, span 1x4)
      └── table  A1:F8
            ├── header  Region
            ├── header  Revenue > 2025 > Q1   (covered_by B2:E2 → merged_with anchor)
            └── ...

## 4. Hierarchical headers

Merged anchors are expanded across their span so shadow columns inherit the label, then
each column walks the band top to bottom, skipping blanks and consecutive duplicates:

    row 2:  [    Revenue (B2:E2)    ] [ Growth ]
    row 3:  [ 2025 ]     [ 2026 ]
    row 4:  Q1   Q2      Q1   Q2      Growth (%)

    B -> Revenue > 2025 > Q1
    C -> Revenue > 2025 > Q2
    D -> Revenue > 2026 > Q1
    E -> Revenue > 2026 > Q2

The path is stored as a list (`["Revenue", "2025", "Q1"]`) and rendered with `>`. This is
the difference between a column called `Q1` — of which there are two — and one that can be
answered about.

## 5. Column semantics

**Number format first** (it is the author's declared intent), values second (evidence):

| Signal | Result |
|---|---|
| `$`, `€`, `£`, `¥`, `₹` or `[$` in the format | `currency_measure` |
| `%` in the format | `percentage` |
| `yy`/`mm`/`dd`/`hh` in the format, or all values are dates | `date` |
| all values numeric | `numeric_measure` |
| all text, all distinct, >3 rows | `identifier` |
| all text, low cardinality | `categorical` |
| mixed | `mixed` |

**Units** come from a trailing parenthetical in the header — `Revenue (USD millions)` →
`USD millions`, `Length (bit)` → `bit` — or from the currency symbol in the format.

## 6. Formulas

Both forms are always kept:

    formula:      =SUM(B5:B7)
    cached_value: 125000
    functions:    ["SUM"]
    depends_on:   ["Revenue!B5:B7"]

plus `formula_depends_on` edges to each referenced cell (ranges expanded, capped at 64
edges per formula, 2,000 cells per range).

Reference extraction is **lexical**: string literals are blanked first so `"B2 is text"`
is not read as a reference. A full expression parser is a large piece of work whose
failure mode here would be silent; a missed reference shows up as a missing edge, never as
a wrong number.

A workbook that Excel has never opened (one written by openpyxl or Apache POI) has **no
cached values at all**. That is reported as partial, never filled in.

## 7. Reading the output

    # find a value and where it lives
    document_understand.py search book.xlsx "CrashStatus"

    # see how a sheet was carved up
    document_understand.py debug book.xlsx --stage regions

    # check header resolution specifically
    document_understand.py debug book.xlsx --stage headers

    # every merge, anchor and span
    document_understand.py debug book.xlsx --stage merged_cells

## Known limits

* **Charts** — openpyxl exposes chart definitions, but this layer does not yet emit chart
  series as elements. Docling's Excel backend does read chart series and range references
  (`msexcel_backend.py:1529-1796`); wiring that through is the obvious next step. Until
  then charts are absent from the output rather than approximated.
* **Conditional formatting and data validation** are not extracted.
* **Cross-sheet dependency edges** resolve by name; a reference to a sheet that was
  truncated by the cell cap will not resolve.
* **Legacy `.xls`** is detected but not parsed natively — it routes to docling if
  installed, otherwise it is reported unsupported with the install command.
