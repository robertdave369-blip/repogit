# Retrieval and RAG

`udu/chunk.py`. Run with `chunks <file>`, or as part of `analyze`.

## Why not fixed-size splitting

Splitting every N tokens is what makes RAG answer confidently and wrongly. It cuts a table
from its header, a number from its unit, and a sentence from the section that gave it
meaning. Retrieved alone,

    "Revenue increased by 20%."

is unanswerable — 20% of what, when, in which region, in which units.

## Boundaries

Chunks are cut on **structural** boundaries:

* **table** — atomic until it exceeds the budget, then split by rows **with the header
  block repeated in every part**. A row group without its column names is a list of
  numbers.
* **figure** — caption, class, alt text and OCR text as one unit.
* **narrative** — grouped by section, packed to the budget, and short chunks folded
  forward into the previous one when they share a section, because a two-line chunk
  retrieves badly.

## Every chunk carries its parent context — inside the text

The context header is part of the embedded text, not only metadata, because the retriever
scores the text:

    Document: financials.xlsx
    Section: Revenue > Financial Results
    Table: Financial Results
    Range: A1:F8
    Source: financials.xlsx -> Revenue -> A1:F8
    Columns:
      - Region
      - Revenue > 2025 > Q1 | unit: $ | type: currency_measure
      - Revenue > 2025 > Q2 | unit: $ | type: currency_measure

    Rows:
    Region=North America; Revenue > 2025 > Q1=12; Revenue > 2025 > Q2=14; ...
    (total) Region=Total; Revenue > 2025 > Q1==SUM(B5:B7); ...

## Chunk fields

| Field | Purpose |
|---|---|
| `id` | stable across runs: `file:anchor:sha256[:12]` — safe as a vector-store key |
| `text` | context header plus body; this is what you embed |
| `context_header` | the header alone, if you prefer it as separate metadata |
| `section_path` | ordered ancestry, e.g. `["Revenue", "Financial Results"]` |
| `element_ids` | back-references into `document.json` |
| `source` | full provenance dict |
| `tokens_estimate` | about 4 chars per token; bounded, not exact |
| `contains_instruction_shaped_text` | **check before feeding a chunk to a model** |
| `metadata.ordinal`, `.total_chunks`, `.part` | ordering and table-split position |

## Using it

    document_understand.py chunks report.pdf --max-tokens 700 > chunks.jsonl

Embed `text`, store `id` as the key, keep `source` and `section_path` as filterable
metadata. Hybrid search works well here: the header text carries header labels, units and
sheet names verbatim, so keyword search hits them directly.

## Rules

1. Store `id` and `source` with every vector. A retrieved chunk that cannot be cited is
   not usable in this framework.
2. Honour `contains_instruction_shaped_text` — that chunk holds text shaped like a
   directive. It is still data.
3. Re-chunk when the source changes; `source.sha256` tells you when it has.
4. No embedding model is bundled and no tokenizer is used. A 15% token-count error costs
   nothing here; a model dependency would cost a great deal.
