# Debugging extraction

When output looks wrong, find out *where* it went wrong before changing anything.

    document_understand.py debug <file>                  # every stage
    document_understand.py debug <file> --stage regions  # one stage

## Stages

| Stage | Answers |
|---|---|
| `detection` | What format was detected, by signature or extension? What ran? |
| `counts` | How many of each element type? A zero here is usually the bug. |
| `regions` | How was each sheet carved into tables? Which rows are headers? Row roles? |
| `headers` | What path did each column resolve to? What type and unit? |
| `merged_cells` | Every anchor, span and covered cell. |
| `formulas` | Formula, cached value and dependencies, per cell. |
| `figures` | Image class, confidence, **rationale**, caption. |
| `reading_order` | The order blocks were extracted in (first 500). |
| `relationships` | Every typed edge in the graph. |
| `provenance_gaps` | Elements with no source. Should always be empty. |
| `model_generated` | Everything OCR or a model produced, with confidence. |
| `safety` | Instruction-shaped passages and their excerpts. |
| `report` | Successful, partial, unsupported, failed. |

## Symptom to stage

| Symptom | Look at |
|---|---|
| "The file looks empty" | `report` — often `likely_scanned`, or a missing dependency |
| Columns have letters instead of names | `regions` — `header_rows` is empty |
| Two columns share a label | `headers` — paths did not resolve; check the merge band |
| Numbers are in the wrong column | `headers`, then `merged_cells` |
| One table where there should be two | `regions` — the blank separator may be too narrow |
| Totals counted as data | `regions` — `row_roles` |
| A formula shows no value | `formulas` — the workbook was never opened by Excel |
| A caption is not attached | `figures` — vector art produces no image block |
| A value cannot be cited | `provenance_gaps` |

## The quality gate

    document_understand.py validate <file>

Exit `0` if every invariant holds, `1` otherwise. It checks:

1. every element has provenance;
2. no dangling parents;
3. every relationship target resolves;
4. every table header resolved to a path;
5. every formula kept both of its forms;
6. no `MODEL_GENERATED` element claims certainty (confidence at or above 0.999);
7. no failed stages.

`validate` is deliberately honest about the difference between a defect and a limit:
`unsupported` and `partial` entries are **reported alongside** the result rather than
folded into pass or fail, because "this format needs docling" is not a failure of
extraction.

## Exit codes

| Code | Meaning |
|---|---|
| 0 | success |
| 1 | error, or a failed validation |
| 2 | **refused** — a security guard rejected the file before parsing |

## First moves when something is off

1. `deps` — is the parser for that format even installed?
2. `inspect` — was the format detected correctly?
3. `validate` — does the representation hold together?
4. `debug --stage <the stage the table above points at>`.
5. Only then change code — and add a regression test using the file that broke it.
