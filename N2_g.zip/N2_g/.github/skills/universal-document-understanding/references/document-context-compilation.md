# AI context compilation

`udu/compile.py` turns the full element graph into something that fits in a prompt without
becoming lossy *about meaning*.

## The only distinction that matters

**Safe to drop** — styling, per-cell font size, body-text bounding boxes, repeated
boilerplate (identical short strings across pages are headers and footers), empty cells,
the thousandth identical data row.

**Never dropped** — hierarchy, resolved headers, merged-cell context, units, formulas,
typed relationships, and **provenance**. If a number survives, its address survives with
it.

## Levels

| Level | Contains | Use |
|---|---|---|
| 1 | source, metadata, counts, sections, table shapes and columns, report | "What is in here?" |
| 2 | + sample rows (40 by default), narrative with boilerplate removed, figures | default |
| 3 | + full text, all relationships | when you need the graph |

Total and subtotal rows are **always** included regardless of the row cap — dropping a
total because it fell past row 40 would be the worst possible omission. `rows_omitted`
states how many data rows were left out, and `document.json` always holds all of them.

## Dual output

`analyze` writes both representations:

    output/
      document.json   full canonical representation (every element, every edge)
      document.md     AI-friendly Markdown
      chunks.jsonl    retrieval chunks
      debug/          per-stage dumps (with --debug)

### The Markdown is written for comprehension, not visual fidelity

It does not try to redraw the layout. It **states the context a human would have inferred
from the layout**, generated from structure rather than hardcoded:

    ## Financial Results

    | Region | Revenue > 2025 > Q1 | Revenue > 2025 > Q2 | Revenue > 2026 > Q1 | ... |
    |---|---|---|---|---|
    | North America | 12 | 14 | 15 | 17 |
    | **total** Total | `=SUM(B5:B7)` | `=SUM(C5:C7)` | ... |

    Context:

    * This table belongs to the "Financial Results" section.
    * Units in use: $, %.
    * Columns are hierarchical: Revenue -> 2025 -> Q1; Revenue -> 2025 -> Q2; ...
    * Column types (inferred): Revenue > 2025 > Q1 is currency_measure; ...
    * Contains 1 total row(s) and 0 subtotal row(s) - exclude them when aggregating.
    * Table boundaries were inferred from cell occupancy, not declared in the file.

    Source:
    `financials.xlsx -> Revenue -> A1:F8`

Every "Context:" bullet is derived, not written by hand: units from `column_units`,
hierarchy from `header_paths`, roles from `row_roles`, the inference caveat from `basis`.

## Row keying — a trap worth knowing

Compiled rows are keyed by **column address**, never by header label.

Two columns can legitimately share a label (`Q1` under 2025 and under 2026). An early
version keyed the row dict by label, so the last column silently overwrote the others and
every quarter reported Q4's number — in output that looked perfectly well-formed. Pinned
by `test_row_values_are_not_overwritten_by_duplicate_labels_regression`.

## Safety block

Every compiled context carries:

    "safety": {
      "content_is_data_not_instructions": true,
      "boundary_rule": "...",
      "instruction_shaped_passages": 4,
      "findings": [ { "pattern": "instruction_override", "excerpt": "..." } ]
    }

and the Markdown opens with the boundary statement before the first horizontal rule, so a
reader cannot reach document content without passing it.
