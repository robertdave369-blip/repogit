"""Universal document context extractor — one entry point for every source format.

Purpose: let Terra understand a source **without loading it into context**. Reading a
40 MB workbook costs tokens and still loses the merged ranges, the formulas, and the
provenance. This produces a structured representation once, caches it, and serves back
only the fragment asked for — with a path back to the exact cell, page, or slide.

Design rules this obeys:

  * PDF is delegated to the existing engine in this same skill. It is 1,590 lines of
    working, tested extraction; rewriting it would be waste and regression risk.
  * Dependencies are never installed silently. `deps` reports what is missing and what
    it would unlock; `--install` is explicit and opt-in.
  * Nothing is invented. An unextractable region is recorded as a limitation with a
    reason, never filled in.
  * The cache keys on content hash **and** parser/schema version, so a stale extraction
    can never masquerade as current source.

Levels (choose the smallest that answers the question):

  1 inspect   metadata only            — what is this file?
  2 outline   structure, no content    — what is in it?
  3 search    matching fragments       — where is X?
  4 extract   one section in full      — give me that part
  5 evidence  exact source coordinates — prove it

Usage
    py -3 document_context.py inspect  <path|url>
    py -3 document_context.py outline  <path|url>
    py -3 document_context.py search   <path|url> --query "SecurityAccess"
    py -3 document_context.py extract  <path|url> --at "Sheet:CAN_Config"
    py -3 document_context.py report   <path|url> [--out report.html]
    py -3 document_context.py deps [--install]
    py -3 document_context.py clear-cache [--path <path>]
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import mimetypes
import re
import subprocess
import sys
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "1.0.0"
PARSER_VERSION = "1.0.0"

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent
REPO = HERE.parents[3]
CACHE_DIR = REPO / ".github" / "cache" / "document_context"

# Text is truncated per node so an outline of a huge file stays small.
PREVIEW_CHARS = 220
LARGE_FILE_BYTES = 25 * 1024 * 1024


# ----------------------------------------------------------------- dependencies

def optional(module: str):
    """Import if present, else None. Same convention as pdf_document_intelligence.py."""
    try:
        return importlib.import_module(module)
    except Exception:
        return None


# capability -> (module, pip name, what it unlocks)
DEPS: dict[str, tuple[str, str, str]] = {
    "pdf":       ("fitz",     "pymupdf",     "PDF text, tables, images, coordinates"),
    "pdf_table": ("pdfplumber", "pdfplumber", "PDF table extraction"),
    "docx":      ("docx",     "python-docx", "Word headings, tables, footnotes"),
    "pptx":      ("pptx",     "python-pptx", "PowerPoint slides, notes, shapes"),
    "xlsx":      ("openpyxl", "openpyxl",    "Excel cells, formulas, merges, names"),
    "xls":       ("xlrd",     "xlrd",        "Legacy .xls workbooks"),
    "tables":    ("pandas",   "pandas",      "Large CSV/TSV chunked reading"),
    "xml":       ("lxml",     "lxml",        "XML/ARXML tree with source lines"),
    "image":     ("PIL",      "pillow",      "Image metadata, size, EXIF"),
    "html":      ("bs4",      "beautifulsoup4", "HTML structure and link extraction"),
    "web":       ("requests", "requests",    "URL fetching"),
    "ocr":       ("pytesseract", "pytesseract", "Image text (also needs the tesseract binary)"),
}


def dependency_status() -> dict[str, dict[str, Any]]:
    out = {}
    for cap, (mod, pip_name, unlocks) in DEPS.items():
        out[cap] = {"module": mod, "pip": pip_name, "unlocks": unlocks,
                    "available": optional(mod) is not None}
    return out


# ------------------------------------------------------------- representation

@dataclass
class Node:
    """One structural element. `at` is the provenance address — always resolvable."""
    kind: str                       # sheet | row | cell | page | heading | table | slide | image ...
    at: str                         # "Sheet:CAN_Config!B7", "page:42", "slide:17"
    text: str | None = None
    value: Any = None
    meta: dict[str, Any] = field(default_factory=dict)
    children: list["Node"] = field(default_factory=list)

    def to_dict(self, depth: int | None = None, preview: bool = False) -> dict[str, Any]:
        d: dict[str, Any] = {"kind": self.kind, "at": self.at}
        if self.text is not None:
            d["text"] = (self.text[:PREVIEW_CHARS] + "…") if preview and len(self.text) > PREVIEW_CHARS else self.text
        if self.value is not None:
            d["value"] = self.value
        if self.meta:
            d["meta"] = self.meta
        if self.children and (depth is None or depth > 0):
            nxt = None if depth is None else depth - 1
            d["children"] = [c.to_dict(nxt, preview) for c in self.children]
        elif self.children:
            d["children_count"] = len(self.children)
        return d

    def walk(self):
        yield self
        for c in self.children:
            yield from c.walk()


@dataclass
class Report:
    """Structured extraction outcome — §25. Partial success is reported, not hidden."""
    successful: list[str] = field(default_factory=list)
    partial: list[dict[str, str]] = field(default_factory=list)
    unsupported: list[dict[str, str]] = field(default_factory=list)
    failed: list[dict[str, str]] = field(default_factory=list)

    def ok(self, what: str) -> None:
        self.successful.append(what)

    def part(self, what: str, why: str) -> None:
        self.partial.append({"what": what, "why": why})

    def unsup(self, what: str, why: str) -> None:
        self.unsupported.append({"what": what, "why": why})

    def fail(self, what: str, why: str) -> None:
        self.failed.append({"what": what, "why": why})


@dataclass
class Extraction:
    source: str
    fmt: str
    authority: str
    fingerprint: str
    size: int
    metadata: dict[str, Any]
    root: Node
    report: Report
    schema_version: str = SCHEMA_VERSION
    parser_version: str = PARSER_VERSION
    extracted_at: str = ""

    def to_dict(self, depth: int | None = None, preview: bool = False) -> dict[str, Any]:
        return {
            "source": self.source, "format": self.fmt, "authority": self.authority,
            "fingerprint": self.fingerprint, "size": self.size,
            "schema_version": self.schema_version, "parser_version": self.parser_version,
            "extracted_at": self.extracted_at, "metadata": self.metadata,
            "report": asdict(self.report),
            "root": self.root.to_dict(depth, preview),
        }


# ------------------------------------------------------------------ detection

SIGNATURES: list[tuple[bytes, str]] = [
    (b"%PDF-", "pdf"),
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"\xff\xd8\xff", "jpeg"),
    (b"GIF8", "gif"),
    (b"BM", "bmp"),
    (b"II*\x00", "tiff"),
    (b"MM\x00*", "tiff"),
    (b"\xd0\xcf\x11\xe0", "ole"),      # legacy .xls/.doc/.ppt
]

OOXML_MARKERS = {"xl/workbook.xml": "xlsx", "word/document.xml": "docx",
                 "ppt/presentation.xml": "pptx"}

EXT_MAP = {
    ".pdf": "pdf", ".docx": "docx", ".pptx": "pptx", ".xlsx": "xlsx", ".xlsm": "xlsx",
    ".xls": "xls", ".csv": "csv", ".tsv": "tsv", ".json": "json", ".xml": "xml",
    ".arxml": "arxml", ".txt": "text", ".log": "text", ".md": "markdown",
    ".html": "html", ".htm": "html", ".png": "png", ".jpg": "jpeg", ".jpeg": "jpeg",
    ".webp": "webp", ".bmp": "bmp", ".tif": "tiff", ".tiff": "tiff", ".svg": "svg",
    ".dbc": "dbc",
}


def detect_format(path: Path) -> str:
    """Signature first, extension second — extensions lie."""
    try:
        with path.open("rb") as fh:
            head = fh.read(8)
    except OSError:
        head = b""
    for sig, fmt in SIGNATURES:
        if head.startswith(sig):
            if fmt == "ole":
                return EXT_MAP.get(path.suffix.lower(), "ole")
            return fmt
    if head[:2] == b"PK":  # OOXML / zip container
        try:
            import zipfile
            with zipfile.ZipFile(path) as z:
                names = set(z.namelist())
            for marker, fmt in OOXML_MARKERS.items():
                if marker in names:
                    return fmt
            return "zip"
        except Exception:
            return "zip"
    return EXT_MAP.get(path.suffix.lower(), "unknown")


def classify_authority(path: Path) -> str:
    """§33 — never let derived content pass as authoritative."""
    p = str(path).replace("\\", "/").lower()
    if "/docs/processed_documents/" in p or "/graphify-out/" in p:
        return "DERIVED"
    if "/project_reuirements/" in p or "/req/" in p:
        return "PROJECT_DOCUMENTATION"
    if "/project_testcases/" in p:
        return "PROJECT_FILE"
    if "/aria_projects/" in p or "/crash_data/" in p:
        return "PROJECT_CONFIGURATION"
    if "/config/" in p or p.endswith("_config.py"):
        return "PROJECT_CONFIGURATION"
    if "/project_dbc/" in p or "/docs/" in p:
        return "PROJECT_DOCUMENTATION"
    if "/test_results/" in p or "/test_logs/" in p or "/evt/" in p:
        return "TOOL_OUTPUT"
    if "/.github/" in p:
        return "PROJECT_CONFIGURATION"
    if "/tests/" in p:
        return "PROJECT_FILE"
    if "/projects/" in p or "/shared_libraries/" in p or "/tools/" in p:
        return "PROJECT_FILE"
    return "UNKNOWN"


def fingerprint(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


# ----------------------------------------------------------------- extractors

def _cell_addr(sheet: str, row: int, col: int) -> str:
    letters = ""
    while col > 0:
        col, rem = divmod(col - 1, 26)
        letters = chr(65 + rem) + letters
    return f"Sheet:{sheet}!{letters}{row}"


def extract_xlsx(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    openpyxl = optional("openpyxl")
    if openpyxl is None:
        rep.fail("workbook", "openpyxl not installed — run: document_context.py deps --install")
        return Node("workbook", f"file:{path.name}"), {}

    # data_only=False keeps formulas; a second pass gets cached values (§5).
    # read_only hides merged ranges, and a merge is structure -- section 5 treats it as
    # load-bearing. Accept the memory cost unless the workbook is genuinely large.
    read_only = (not deep) and path.stat().st_size > LARGE_FILE_BYTES
    wb = openpyxl.load_workbook(path, data_only=False, read_only=read_only)
    try:
        wbv = openpyxl.load_workbook(path, data_only=True, read_only=read_only)
    except Exception:
        wbv = None
        rep.part("cached values", "second pass failed; formulas kept, values unavailable")

    meta = {"sheets": wb.sheetnames, "sheet_count": len(wb.sheetnames)}
    try:
        props = wb.properties
        meta.update({"title": props.title, "creator": props.creator,
                     "modified": str(props.modified) if props.modified else None})
    except Exception:
        rep.part("workbook metadata", "properties unreadable")

    try:
        meta["defined_names"] = list(wb.defined_names.keys())
    except Exception:
        meta["defined_names"] = []

    root = Node("workbook", f"file:{path.name}", meta={"sheets": len(wb.sheetnames)})
    for name in wb.sheetnames:
        ws = wb[name]
        wsv = wbv[name] if wbv is not None else None
        smeta: dict[str, Any] = {"state": getattr(ws, "sheet_state", "visible")}

        merged: list[str] = []
        try:
            merged = [str(r) for r in ws.merged_cells.ranges]
        except Exception:
            rep.part(f"merged ranges on {name}",
                     "workbook opened read-only (over size threshold); merges not enumerated")
        if merged:
            smeta["merged_ranges"] = merged

        try:
            smeta["dimensions"] = ws.dimensions
            smeta["max_row"], smeta["max_col"] = ws.max_row, ws.max_column
        except Exception:
            pass

        snode = Node("sheet", f"Sheet:{name}", meta=smeta)

        if deep:
            # Anchor cells of merged ranges carry the value; the rest are not empty
            # cells, they are covered cells. §5 requires that distinction.
            covered: dict[tuple[int, int], str] = {}
            for rng in merged:
                try:
                    from openpyxl.utils import range_boundaries
                    b_c1, b_r1, b_c2, b_r2 = range_boundaries(rng)
                    if b_c1 is None or b_r1 is None or b_c2 is None or b_r2 is None:
                        rep.part(f"merged range {rng}", "unbounded range, cells not mapped")
                        continue
                    c1, r1, c2, r2 = int(b_c1), int(b_r1), int(b_c2), int(b_r2)
                    for r in range(r1, r2 + 1):
                        for c in range(c1, c2 + 1):
                            if (r, c) != (r1, c1):
                                covered[(r, c)] = rng
                except Exception as exc:
                    rep.part(f"merged range {rng}", str(exc)[:80])

            for row in ws.iter_rows():
                for cell in row:
                    if cell.value is None and (cell.row, cell.column) not in covered:
                        continue
                    cmeta: dict[str, Any] = {}
                    if (cell.row, cell.column) in covered:
                        cmeta["covered_by"] = covered[(cell.row, cell.column)]
                    for rng in merged:
                        if cell.coordinate == rng.split(":")[0]:
                            cmeta["merged_anchor_for"] = rng
                    raw = cell.value
                    is_formula = isinstance(raw, str) and raw.startswith("=")
                    if is_formula:
                        cmeta["formula"] = raw
                        if wsv is not None:
                            try:
                                cmeta["cached_value"] = wsv.cell(cell.row, cell.column).value
                            except Exception:
                                pass
                    if cell.number_format and cell.number_format != "General":
                        cmeta["number_format"] = cell.number_format
                    snode.children.append(Node(
                        "cell", _cell_addr(name, cell.row, cell.column),
                        text=None if is_formula else (str(raw) if raw is not None else None),
                        value=None if is_formula else raw, meta=cmeta))
        root.children.append(snode)

    rep.ok("workbook")
    rep.ok(f"{len(wb.sheetnames)} sheet(s)")
    if not deep:
        rep.part("cell values", "outline mode — run `extract` for cell-level content")
    try:
        wb.close()
        if wbv is not None:
            wbv.close()
    except Exception:
        pass
    return root, meta


def extract_pdf(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    """Delegate to the engine already in this skill; fall back to PyMuPDF outline."""
    fitz = optional("fitz")
    if fitz is None:
        rep.fail("pdf", "pymupdf not installed — run: document_context.py deps --install")
        return Node("document", f"file:{path.name}"), {}
    doc = fitz.open(path)
    meta = dict(doc.metadata or {})
    meta["page_count"] = doc.page_count
    root = Node("document", f"file:{path.name}", meta={"pages": doc.page_count})
    for i, page in enumerate(doc, start=1):
        pnode = Node("page", f"page:{i}")
        if deep:
            try:
                pnode.text = page.get_text("text")
            except Exception as exc:
                rep.part(f"page {i} text", str(exc)[:100])
        root.children.append(pnode)
    try:
        toc = doc.get_toc()
        if toc:
            meta["outline"] = [{"level": lv, "title": t, "page": p} for lv, t, p in toc]
    except Exception:
        rep.part("bookmarks", "outline unreadable")
    doc.close()
    rep.ok(f"pdf, {meta['page_count']} page(s)")
    rep.part("tables/figures",
             "use pdf_document_intelligence.py in this skill for table, figure and OCR extraction")
    return root, meta


def extract_docx(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    docx = optional("docx")
    if docx is None:
        rep.fail("docx", "python-docx not installed — run: document_context.py deps --install")
        return Node("document", f"file:{path.name}"), {}
    d = docx.Document(str(path))
    cp = d.core_properties
    meta = {"title": cp.title, "author": cp.author,
            "modified": str(cp.modified) if cp.modified else None,
            "paragraphs": len(d.paragraphs), "tables": len(d.tables)}
    root = Node("document", f"file:{path.name}", meta={"paragraphs": len(d.paragraphs)})
    stack: list[tuple[int, Node]] = [(0, root)]
    for i, para in enumerate(d.paragraphs, start=1):
        text = para.text.strip()
        if not text:
            continue
        style = (para.style.name if para.style else "") or ""
        m = re.match(r"Heading (\d+)", style)
        if m:
            level = int(m.group(1))
            node = Node("heading", f"para:{i}", text=text, meta={"level": level, "style": style})
            while stack and stack[-1][0] >= level:
                stack.pop()
            (stack[-1][1] if stack else root).children.append(node)
            stack.append((level, node))
        elif deep:
            (stack[-1][1] if stack else root).children.append(
                Node("paragraph", f"para:{i}", text=text, meta={"style": style}))
    for ti, table in enumerate(d.tables, start=1):
        rows = len(table.rows)
        cols = len(table.columns) if table.rows else 0
        tnode = Node("table", f"table:{ti}", meta={"rows": rows, "cols": cols})
        if deep:
            for ri, row in enumerate(table.rows, start=1):
                cells = [c.text.strip() for c in row.cells]
                tnode.children.append(Node("row", f"table:{ti}!r{ri}", value=cells))
        root.children.append(tnode)
    rep.ok(f"docx, {len(d.paragraphs)} paragraph(s), {len(d.tables)} table(s)")
    rep.unsup("tracked changes / comments", "python-docx does not expose the revision API")
    return root, meta


def extract_pptx(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    pptx = optional("pptx")
    if pptx is None:
        rep.fail("pptx", "python-pptx not installed — run: document_context.py deps --install")
        return Node("presentation", f"file:{path.name}"), {}
    pres = pptx.Presentation(str(path))
    meta = {"slides": len(pres.slides)}
    root = Node("presentation", f"file:{path.name}", meta=meta)
    for i, slide in enumerate(pres.slides, start=1):
        snode = Node("slide", f"slide:{i}")
        title = None
        for shape in slide.shapes:
            if shape.has_text_frame and shape.text_frame.text.strip():
                txt = shape.text_frame.text.strip()
                if title is None and shape == slide.shapes.title:
                    title = txt
                    snode.text = txt
                elif deep:
                    snode.children.append(Node(
                        "text", f"slide:{i}!{shape.shape_id}", text=txt,
                        meta={"name": shape.name,
                              "left": getattr(shape, "left", None) and int(shape.left),
                              "top": getattr(shape, "top", None) and int(shape.top)}))
            elif shape.shape_type is not None and deep:
                snode.children.append(Node("shape", f"slide:{i}!{shape.shape_id}",
                                           meta={"type": str(shape.shape_type), "name": shape.name}))
        try:
            if slide.has_notes_slide:
                notes = slide.notes_slide.notes_text_frame.text.strip()
                if notes:
                    snode.children.append(Node("notes", f"slide:{i}!notes", text=notes))
        except Exception:
            rep.part(f"slide {i} notes", "notes slide unreadable")
        root.children.append(snode)
    rep.ok(f"pptx, {len(pres.slides)} slide(s)")
    return root, meta


def extract_tabular(path: Path, rep: Report, deep: bool, delim: str) -> tuple[Node, dict]:
    size = path.stat().st_size
    root = Node("table", f"file:{path.name}")
    rows_read = 0
    header: list[str] = []
    with path.open("r", encoding="utf-8", errors="replace", newline="") as fh:
        reader = csv.reader(fh, delimiter=delim)
        for i, row in enumerate(reader, start=1):
            if i == 1:
                header = row
                root.meta["columns"] = header
                continue
            rows_read += 1
            if deep or rows_read <= 20:
                root.children.append(Node("row", f"row:{i}", value=row))
            elif not deep and rows_read == 21:
                break
    if not deep and size > 0:
        root.meta["note"] = "first 20 rows only; use `extract` for all rows"
    root.meta["rows_sampled"] = rows_read
    rep.ok(f"tabular, {len(header)} column(s)")
    if size > LARGE_FILE_BYTES:
        rep.part("full row set", f"file is {size // (1 << 20)} MB — streamed, not fully loaded")
    return root, {"columns": header, "size": size}


def extract_json(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except json.JSONDecodeError as exc:
        rep.fail("json", f"invalid JSON at line {exc.lineno}: {exc.msg}")
        return Node("json", f"file:{path.name}"), {}
    root = Node("json", f"file:{path.name}")

    def walk(obj: Any, node: Node, at: str, depth: int) -> None:
        if isinstance(obj, dict):
            node.meta["keys"] = len(obj)
            for k, v in (obj.items() if deep or depth < 2 else list(obj.items())[:25]):
                child = Node("key", f"{at}.{k}", text=str(k))
                if isinstance(v, (dict, list)):
                    walk(v, child, f"{at}.{k}", depth + 1)
                else:
                    child.value = v
                node.children.append(child)
        elif isinstance(obj, list):
            node.meta["length"] = len(obj)
            for i, v in enumerate(obj if deep else obj[:10]):
                child = Node("item", f"{at}[{i}]")
                if isinstance(v, (dict, list)):
                    walk(v, child, f"{at}[{i}]", depth + 1)
                else:
                    child.value = v
                node.children.append(child)

    walk(data, root, "$", 0)
    rep.ok("json")
    return root, {"top_level": type(data).__name__}


def extract_xml(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    lxml = optional("lxml.etree")
    root = Node("xml", f"file:{path.name}")
    if lxml is None:
        rep.fail("xml", "lxml not installed — run: document_context.py deps --install")
        return root, {}
    try:
        tree = lxml.parse(str(path))
    except Exception as exc:
        rep.fail("xml", str(exc)[:150])
        return root, {}
    r = tree.getroot()
    meta = {"root_tag": r.tag, "namespaces": dict(r.nsmap) if hasattr(r, "nsmap") else {}}
    counts: dict[str, int] = {}
    for el in r.iter():
        tag = el.tag if isinstance(el.tag, str) else str(el.tag)
        counts[tag] = counts.get(tag, 0) + 1
    meta["element_counts"] = dict(sorted(counts.items(), key=lambda kv: -kv[1])[:40])
    meta["element_total"] = sum(counts.values())

    def walk(el, node: Node, depth: int) -> None:
        if depth > (100 if deep else 2):
            return
        for child in el:
            tag = child.tag if isinstance(child.tag, str) else str(child.tag)
            cnode = Node("element", f"line:{child.sourceline}", text=tag,
                         meta={k: v for k, v in child.attrib.items()} or {})
            if deep and child.text and child.text.strip():
                cnode.value = child.text.strip()
            node.children.append(cnode)
            walk(child, cnode, depth + 1)

    walk(r, root, 0)
    rep.ok(f"xml, {meta['element_total']} element(s)")
    return root, meta


def extract_image(path: Path, rep: Report, deep: bool) -> tuple[Node, dict]:
    PIL = optional("PIL.Image")
    root = Node("image", f"file:{path.name}")
    if PIL is None:
        rep.fail("image", "pillow not installed — run: document_context.py deps --install")
        return root, {}
    try:
        with PIL.open(path) as im:
            meta = {"width": im.width, "height": im.height, "mode": im.mode,
                    "format": im.format}
            try:
                exif = im.getexif()
                if exif:
                    meta["exif"] = {str(k): str(v)[:120] for k, v in exif.items()}
            except Exception:
                pass
    except Exception as exc:
        rep.fail("image", str(exc)[:150])
        return root, {}
    root.meta = meta
    rep.ok(f"image {meta['width']}x{meta['height']} {meta.get('format')}")
    # Honesty over capability theatre: OCR needs a native binary this repo does not have.
    if optional("pytesseract") is None:
        rep.unsup("text in image (OCR)",
                  "pytesseract not installed, and it additionally requires the native "
                  "tesseract binary. No text was read; none was invented.")
    return root, meta


def extract_text(path: Path, rep: Report, deep: bool, fmt: str) -> tuple[Node, dict]:
    size = path.stat().st_size
    root = Node("text", f"file:{path.name}", meta={"size": size})
    lines_kept = 0
    heads: list[Node] = []
    with path.open("r", encoding="utf-8", errors="replace") as fh:
        for i, line in enumerate(fh, start=1):
            if fmt == "markdown":
                m = re.match(r"^(#{1,6})\s+(.*)", line)
                if m:
                    heads.append(Node("heading", f"line:{i}", text=m.group(2).strip(),
                                      meta={"level": len(m.group(1))}))
                    continue
            if deep:
                root.children.append(Node("line", f"line:{i}", text=line.rstrip("\n")))
                lines_kept += 1
            elif i > 200:
                break
    if heads:
        root.children = heads + root.children
    root.meta["lines_captured"] = lines_kept or len(heads)
    rep.ok(f"{fmt}, {size} bytes")
    if size > LARGE_FILE_BYTES and not deep:
        rep.part("full text", f"{size // (1 << 20)} MB — streamed; use search or extract")
    return root, {"size": size}


def extract_html(source: str, rep: Report, deep: bool, is_url: bool) -> tuple[Node, dict]:
    bs4 = optional("bs4")
    if bs4 is None:
        rep.fail("html", "beautifulsoup4 not installed — run: document_context.py deps --install")
        return Node("page", source), {}
    if is_url:
        requests = optional("requests")
        if requests is None:
            rep.fail("web", "requests not installed")
            return Node("page", source), {}
        try:
            resp = requests.get(source, timeout=30, headers={"User-Agent": "document_context/1.0"})
            resp.raise_for_status()
            html = resp.text
        except Exception as exc:
            rep.fail("fetch", str(exc)[:150])
            return Node("page", source), {}
    else:
        html = Path(source).read_text(encoding="utf-8", errors="replace")

    soup = bs4.BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "aside"]):
        tag.decompose()
    meta = {"title": (soup.title.string.strip() if soup.title and soup.title.string else None),
            "retrieved_at": datetime.now(timezone.utc).isoformat()}
    if is_url:
        meta["source_url"] = source
    root = Node("page", source, meta=meta)
    for i, h in enumerate(soup.find_all(re.compile("^h[1-6]$")), start=1):
        root.children.append(Node("heading", f"heading:{i}", text=h.get_text(strip=True),
                                  meta={"level": int(h.name[1])}))
    for i, t in enumerate(soup.find_all("table"), start=1):
        rows = t.find_all("tr")
        root.children.append(Node("table", f"table:{i}", meta={"rows": len(rows)}))
    if deep:
        for i, p in enumerate(soup.find_all("p"), start=1):
            txt = p.get_text(strip=True)
            if txt:
                root.children.append(Node("paragraph", f"p:{i}", text=txt))
        for i, c in enumerate(soup.find_all(["pre", "code"]), start=1):
            root.children.append(Node("code", f"code:{i}", text=c.get_text()))
    links = [a.get("href") for a in soup.find_all("a", href=True)]
    meta["link_count"] = len(links)
    if deep:
        meta["links"] = links[:200]
    rep.ok("html")
    rep.part("noise removal", "script/style/nav/footer/aside stripped; content preserved")
    return root, meta


# ------------------------------------------------------------------ pipeline

def build(source: str, deep: bool) -> Extraction:
    rep = Report()
    is_url = source.startswith(("http://", "https://"))

    if is_url:
        root, meta = extract_html(source, rep, deep, True)
        return Extraction(source=source, fmt="web", authority="PUBLIC_WEB_SOURCE",
                          fingerprint=hashlib.sha256(source.encode()).hexdigest(),
                          size=0, metadata=meta, root=root, report=rep,
                          extracted_at=datetime.now(timezone.utc).isoformat())

    path = Path(source).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"not a file: {path}")

    fmt = detect_format(path)
    fp = fingerprint(path)
    size = path.stat().st_size

    dispatch = {
        "xlsx": lambda: extract_xlsx(path, rep, deep),
        "pdf": lambda: extract_pdf(path, rep, deep),
        "docx": lambda: extract_docx(path, rep, deep),
        "pptx": lambda: extract_pptx(path, rep, deep),
        "csv": lambda: extract_tabular(path, rep, deep, ","),
        "tsv": lambda: extract_tabular(path, rep, deep, "\t"),
        "json": lambda: extract_json(path, rep, deep),
        "xml": lambda: extract_xml(path, rep, deep),
        "arxml": lambda: extract_xml(path, rep, deep),
        "html": lambda: extract_html(str(path), rep, deep, False),
        "text": lambda: extract_text(path, rep, deep, "text"),
        "markdown": lambda: extract_text(path, rep, deep, "markdown"),
        "dbc": lambda: extract_text(path, rep, deep, "text"),
    }
    for img in ("png", "jpeg", "webp", "bmp", "tiff", "gif"):
        dispatch[img] = lambda: extract_image(path, rep, deep)

    if fmt in dispatch:
        root, meta = dispatch[fmt]()
    else:
        root, meta = Node("unknown", f"file:{path.name}"), {}
        guess, _ = mimetypes.guess_type(str(path))
        rep.unsup(
            f"format '{fmt}'",
            f"no extractor for this type (mime guess: {guess or 'unknown'}). "
            f"Supported: {', '.join(sorted(set(dispatch)))}. "
            f"If this is a text-like format, rename or pass it as .txt.")

    return Extraction(source=str(path), fmt=fmt, authority=classify_authority(path),
                      fingerprint=fp, size=size, metadata=meta, root=root, report=rep,
                      extracted_at=datetime.now(timezone.utc).isoformat())


# --------------------------------------------------------------------- cache

def cache_path(source: str, deep: bool) -> Path:
    key = hashlib.sha256(f"{source}|{deep}|{SCHEMA_VERSION}|{PARSER_VERSION}".encode()).hexdigest()[:32]
    return CACHE_DIR / f"{key}.json"


def load_cached(source: str, deep: bool) -> dict | None:
    """Reuse only when content AND parser AND schema all still match (§21)."""
    p = cache_path(source, deep)
    if not p.is_file():
        return None
    try:
        blob = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None
    if blob.get("schema_version") != SCHEMA_VERSION or blob.get("parser_version") != PARSER_VERSION:
        return None
    src = Path(blob.get("source", ""))
    if src.is_file():
        if blob.get("fingerprint") != fingerprint(src):
            return None
    return blob


def save_cached(source: str, deep: bool, blob: dict) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_path(source, deep).write_text(json.dumps(blob, indent=1, default=str), encoding="utf-8")


def get(source: str, deep: bool, refresh: bool = False) -> tuple[dict, bool]:
    if not refresh:
        cached = load_cached(source, deep)
        if cached is not None:
            return cached, True
    blob = build(source, deep).to_dict()
    save_cached(source, deep, blob)
    return blob, False


# ------------------------------------------------------------------ commands

def flatten(node: dict, out: list[dict]) -> None:
    out.append(node)
    for c in node.get("children", []):
        flatten(c, out)


def cmd_inspect(args) -> int:
    blob, hit = get(args.source, deep=False, refresh=args.refresh)
    print(json.dumps({
        "source": blob["source"], "format": blob["format"],
        "authority": blob["authority"], "size": blob["size"],
        "fingerprint": blob["fingerprint"][:16], "cache_hit": hit,
        "metadata": blob["metadata"], "report": blob["report"],
    }, indent=2, default=str))
    return 0


def cmd_outline(args) -> int:
    blob, hit = get(args.source, deep=False, refresh=args.refresh)
    root = blob["root"]
    print(json.dumps({"source": blob["source"], "format": blob["format"],
                      "authority": blob["authority"], "cache_hit": hit,
                      "report": blob["report"],
                      "root": _prune(root, args.depth)}, indent=2, default=str))
    return 0


def _prune(node: dict, depth: int) -> dict:
    d = {k: v for k, v in node.items() if k != "children"}
    kids = node.get("children", [])
    if kids:
        if depth > 0:
            d["children"] = [_prune(c, depth - 1) for c in kids]
        else:
            d["children_count"] = len(kids)
    return d


def cmd_search(args) -> int:
    blob, hit = get(args.source, deep=True, refresh=args.refresh)
    nodes: list[dict] = []
    flatten(blob["root"], nodes)
    pat = re.compile(re.escape(args.query) if not args.regex else args.query, re.I)
    hits = []
    for i, n in enumerate(nodes):
        hay = " ".join(str(x) for x in (n.get("text"), n.get("value")) if x is not None)
        if not hay or not pat.search(hay):
            continue
        # §17 — return the surrounding semantic window, not a bare keyword
        ctx_before = nodes[max(0, i - 2):i]
        ctx_after = nodes[i + 1:i + 3]
        hits.append({
            "at": n.get("at"), "kind": n.get("kind"),
            "text": (n.get("text") or str(n.get("value")))[:300],
            "meta": n.get("meta", {}),
            "context_before": [{"at": c.get("at"), "text": (c.get("text") or "")[:80]} for c in ctx_before],
            "context_after": [{"at": c.get("at"), "text": (c.get("text") or "")[:80]} for c in ctx_after],
        })
        if len(hits) >= args.limit:
            break
    print(json.dumps({"source": blob["source"], "authority": blob["authority"],
                      "query": args.query, "cache_hit": hit,
                      "matches": len(hits), "hits": hits}, indent=2, default=str))
    return 0 if hits else 1


def cmd_extract(args) -> int:
    blob, hit = get(args.source, deep=True, refresh=args.refresh)
    nodes: list[dict] = []
    flatten(blob["root"], nodes)
    if not args.at:
        print(json.dumps(blob, indent=2, default=str))
        return 0
    sel = [n for n in nodes if n.get("at", "").startswith(args.at)]
    if not sel:
        avail = sorted({n.get("at", "").split("!")[0] for n in nodes if n.get("at")})[:30]
        print(json.dumps({"error": f"no node at '{args.at}'", "available_prefixes": avail},
                         indent=2), file=sys.stderr)
        return 1
    print(json.dumps({"source": blob["source"], "authority": blob["authority"],
                      "at": args.at, "cache_hit": hit, "count": len(sel),
                      "nodes": sel[:args.limit]}, indent=2, default=str))
    return 0


def cmd_report(args) -> int:
    blob, _ = get(args.source, deep=True, refresh=args.refresh)
    nodes: list[dict] = []
    flatten(blob["root"], nodes)
    kinds: dict[str, int] = {}
    for n in nodes:
        kinds[n.get("kind", "?")] = kinds.get(n.get("kind", "?"), 0) + 1
    rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in sorted(kinds.items()))
    r = blob["report"]

    def lst(items, key=None):
        if not items:
            return "<li><em>none</em></li>"
        return "".join(f"<li>{(i[key] + ' — ' + i['why']) if key else i}</li>" for i in items)

    html = f"""<!doctype html><meta charset="utf-8"><title>Extraction — {blob['source']}</title>
<style>body{{font:14px/1.5 system-ui,sans-serif;max-width:60rem;margin:2rem auto;padding:0 1rem}}
table{{border-collapse:collapse}}td,th{{border:1px solid #ccc;padding:.3rem .6rem}}
code{{background:#f4f4f4;padding:.1rem .3rem}}h2{{margin-top:2rem}}</style>
<h1>Extraction report</h1>
<p><code>{blob['source']}</code></p>
<table><tr><th>Format</th><td>{blob['format']}</td></tr>
<tr><th>Authority</th><td>{blob['authority']}</td></tr>
<tr><th>Size</th><td>{blob['size']} bytes</td></tr>
<tr><th>Fingerprint</th><td>{blob['fingerprint'][:32]}…</td></tr>
<tr><th>Schema / parser</th><td>{blob['schema_version']} / {blob['parser_version']}</td></tr>
<tr><th>Extracted</th><td>{blob['extracted_at']}</td></tr></table>
<h2>Node counts</h2><table><tr><th>Kind</th><th>Count</th></tr>{rows}</table>
<h2>Successful</h2><ul>{lst(r['successful'])}</ul>
<h2>Partial</h2><ul>{lst(r['partial'], 'what')}</ul>
<h2>Unsupported</h2><ul>{lst(r['unsupported'], 'what')}</ul>
<h2>Failed</h2><ul>{lst(r['failed'], 'what')}</ul>
<p><em>This is exactly what the model receives. Anything absent above was not extracted
and was not invented.</em></p>"""
    out = Path(args.out) if args.out else CACHE_DIR / "report.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"report written: {out}")
    return 0


def cmd_deps(args) -> int:
    status = dependency_status()
    missing = [c for c, s in status.items() if not s["available"]]
    for cap, s in status.items():
        mark = "OK     " if s["available"] else "MISSING"
        print(f"  {mark} {cap:<10} {s['pip']:<16} {s['unlocks']}")
    if not missing:
        print("\n  all capabilities available")
        return 0
    print(f"\n  missing: {', '.join(missing)}")
    if not args.install:
        print("  re-run with --install to install them (uv preferred, pip fallback)")
        return 1
    pkgs = sorted({status[c]["pip"] for c in missing})
    # Never silent: the exact command is printed before it runs.
    for tool in (["uv", "pip", "install"], [sys.executable, "-m", "pip", "install"]):
        try:
            cmd = tool + pkgs
            print(f"\n  running: {' '.join(cmd)}")
            rc = subprocess.call(cmd)
            if rc == 0:
                break
        except FileNotFoundError:
            continue
    else:
        print("  no working installer found", file=sys.stderr)
        return 2
    still = [c for c, s in dependency_status().items() if not s["available"]]
    print(f"\n  after install, still missing: {still or 'none'}")
    return 0 if not still else 1


def cmd_clear_cache(args) -> int:
    if not CACHE_DIR.is_dir():
        print("  no cache directory")
        return 0
    n = 0
    for f in CACHE_DIR.glob("*.json"):
        if args.path and args.path not in f.read_text(encoding="utf-8", errors="replace")[:400]:
            continue
        f.unlink()
        n += 1
    print(f"  removed {n} cache entr{'y' if n == 1 else 'ies'}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(prog="document_context",
                                 description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, source=True):
        if source:
            p.add_argument("source", help="file path or http(s) URL")
        p.add_argument("--refresh", action="store_true", help="ignore cache, re-extract")
        return p

    common(sub.add_parser("inspect", help="level 1 — metadata only"))
    p = common(sub.add_parser("outline", help="level 2 — structure, no content"))
    p.add_argument("--depth", type=int, default=2)
    p = common(sub.add_parser("search", help="level 3 — matching fragments with context"))
    p.add_argument("--query", required=True)
    p.add_argument("--regex", action="store_true")
    p.add_argument("--limit", type=int, default=20)
    p = common(sub.add_parser("extract", help="level 4 — full content at an address"))
    p.add_argument("--at", help="provenance prefix, e.g. 'Sheet:CAN_Config' or 'page:42'")
    p.add_argument("--limit", type=int, default=500)
    p = common(sub.add_parser("report", help="HTML report of exactly what was extracted"))
    p.add_argument("--out")
    p = sub.add_parser("deps", help="report or install missing capabilities")
    p.add_argument("--install", action="store_true")
    p = sub.add_parser("clear-cache", help="remove cached extractions")
    p.add_argument("--path", help="only entries whose source contains this string")

    args = ap.parse_args()
    fn = {"inspect": cmd_inspect, "outline": cmd_outline, "search": cmd_search,
          "extract": cmd_extract, "report": cmd_report, "deps": cmd_deps,
          "clear-cache": cmd_clear_cache}[args.cmd]
    try:
        return fn(args)
    except FileNotFoundError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
