#!/usr/bin/env python3
"""Universal Document Understanding — CLI.

    py -3 document_understand.py analyze  <file> [-o output/]
    py -3 document_understand.py inspect  <file>            # cheapest: shape only
    py -3 document_understand.py outline  <file>
    py -3 document_understand.py context  <file> [--level 1|2|3]
    py -3 document_understand.py markdown <file>
    py -3 document_understand.py chunks   <file> [--max-tokens 900]
    py -3 document_understand.py search   <file> <query>
    py -3 document_understand.py debug    <file> [--stage tables|cells|regions|...]
    py -3 document_understand.py validate <file>
    py -3 document_understand.py formats
    py -3 document_understand.py deps

`analyze` writes the dual output required by the spec:

    output/
      document.json     full canonical representation
      document.md       AI-friendly Markdown
      chunks.jsonl      retrieval chunks, one JSON object per line
      debug/            per-stage dumps, only with --debug

Escalate deliberately. `inspect` costs a few hundred tokens and usually answers "what is
this file". Reach for `analyze` when you actually need the content.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

# Windows consoles default to cp1252, which cannot encode the arrows and en-dashes this
# tool emits in header paths -- writing to a file crashed rather than mojibaked. Force
# UTF-8 on both streams so redirected output is always valid.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")   # type: ignore[union-attr]
    except (AttributeError, ValueError):
        pass

from udu import adapters, chunk as chunking, compile as compiler, security  # noqa: E402
from udu.model import Basis, Document, ElementType  # noqa: E402

EXIT_OK, EXIT_ERROR, EXIT_REFUSED = 0, 1, 2


def _emit(payload: Any) -> None:
    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False, default=str) + "\n")


def _load(args: argparse.Namespace) -> Document:
    return adapters.build(Path(args.file), deep=not getattr(args, "shallow", False),
                          ocr=getattr(args, "ocr", False))


# ------------------------------------------------------------------- commands

def cmd_inspect(args: argparse.Namespace) -> int:
    path = Path(args.file)
    guard = security.guard_file(path)
    fmt = adapters.detect(path)
    doc = adapters.build(path, deep=False)
    _emit({
        "file": path.name, "format": fmt, "size_bytes": guard.size,
        "authority": doc.source.authority,
        "fingerprint": doc.source.sha256[:16],
        "metadata": {k: v for k, v in doc.metadata.items()
                     if k not in ("injection_findings", "root")},
        "counts": {t.value: len(doc.by_type(t))
                   for t in (ElementType.SHEET, ElementType.PAGE, ElementType.SLIDE,
                             ElementType.SECTION, ElementType.TABLE, ElementType.FIGURE)
                   if doc.by_type(t)},
        "report": doc.report.to_dict(),
        "next": "run `outline` for structure, `context` for content, `analyze` to write files",
    })
    return EXIT_OK


def cmd_outline(args: argparse.Namespace) -> int:
    doc = adapters.build(Path(args.file), deep=False)
    _emit(compiler.compile_context(doc, level=1))
    return EXIT_OK


def cmd_context(args: argparse.Namespace) -> int:
    doc = _load(args)
    _emit(compiler.compile_context(doc, level=args.level, max_rows=args.max_rows))
    return EXIT_OK


def cmd_markdown(args: argparse.Namespace) -> int:
    doc = _load(args)
    sys.stdout.write(compiler.to_markdown(doc, level=args.level, max_rows=args.max_rows))
    return EXIT_OK


def cmd_chunks(args: argparse.Namespace) -> int:
    doc = _load(args)
    chunks = chunking.chunk_document(doc, max_tokens=args.max_tokens)
    for c in chunks:
        sys.stdout.write(json.dumps(c.to_dict(), ensure_ascii=False, default=str) + "\n")
    return EXIT_OK


def cmd_search(args: argparse.Namespace) -> int:
    doc = _load(args)
    needle = args.query.lower()
    hits: list[dict[str, Any]] = []
    for el in doc.elements.values():
        hay = " ".join(str(x) for x in (el.content, el.value) if x is not None).lower()
        if needle in hay:
            section = doc.section_of(el.id)
            hits.append({
                "id": el.id, "type": el.type.value,
                "content": (el.content or str(el.value))[:300],
                "source": el.source.locator if el.source else None,
                "section": section.content if section is not None else None,
                "header": el.meta.get("header"),
                "unit": el.meta.get("unit"),
                "formula": el.meta.get("formula"),
            })
            if len(hits) >= args.limit:
                break
    _emit({"query": args.query, "hit_count": len(hits), "hits": hits,
           "note": "every hit carries a resolvable source locator"})
    return EXIT_OK


def cmd_analyze(args: argparse.Namespace) -> int:
    path = Path(args.file)
    doc = _load(args)
    out_dir = Path(args.output or "output")
    out_dir.mkdir(parents=True, exist_ok=True)

    (out_dir / "document.json").write_text(doc.to_json(), encoding="utf-8")
    (out_dir / "document.md").write_text(
        compiler.to_markdown(doc, level=args.level, max_rows=args.max_rows),
        encoding="utf-8")
    chunks = chunking.chunk_document(doc, max_tokens=args.max_tokens)
    with (out_dir / "chunks.jsonl").open("w", encoding="utf-8") as fh:
        for c in chunks:
            fh.write(json.dumps(c.to_dict(), ensure_ascii=False, default=str) + "\n")

    written = ["document.json", "document.md", "chunks.jsonl"]
    if args.debug:
        dbg = out_dir / "debug"
        dbg.mkdir(exist_ok=True)
        for stage, payload in _debug_stages(doc).items():
            (dbg / f"{stage}.json").write_text(
                json.dumps(payload, indent=2, ensure_ascii=False, default=str),
                encoding="utf-8")
            written.append(f"debug/{stage}.json")

    _emit({
        "source": path.name, "output_dir": str(out_dir), "written": written,
        "elements": len(doc.elements), "chunks": len(chunks),
        "pipeline": doc.pipeline,
        "report": doc.report.to_dict(),
        "validation": _validate(doc),
    })
    return EXIT_OK


def cmd_debug(args: argparse.Namespace) -> int:
    doc = _load(args)
    stages = _debug_stages(doc)
    if args.stage:
        if args.stage not in stages:
            _emit({"error": f"unknown stage {args.stage!r}",
                   "available": sorted(stages)})
            return EXIT_ERROR
        _emit({args.stage: stages[args.stage]})
        return EXIT_OK
    _emit({k: v for k, v in stages.items()})
    return EXIT_OK


def cmd_validate(args: argparse.Namespace) -> int:
    doc = _load(args)
    result = _validate(doc)
    _emit(result)
    return EXIT_OK if result["passed"] else EXIT_ERROR


def cmd_formats(_args: argparse.Namespace) -> int:
    native = ["pdf", "xlsx", "docx", "pptx", "csv", "tsv", "html", "markdown", "text",
              "json", "xml", "arxml", "dbc", "png", "jpeg", "gif", "bmp", "tiff", "webp"]
    _emit({
        "native": sorted(native),
        "via_docling": sorted(adapters.DOCLING_FORMATS),
        "docling_available": adapters._optional("docling.document_converter") is not None,
        "ocr_available": adapters._optional("rapidocr") is not None,
        "note": ("Excel is never delegated to docling: docling opens workbooks "
                 "data_only=True and discards cell formulas."),
    })
    return EXIT_OK


def cmd_deps(_args: argparse.Namespace) -> int:
    wanted = {
        "openpyxl": "xlsx (required for spreadsheets)",
        "fitz": "pdf (PyMuPDF)",
        "docx": "docx (python-docx)",
        "pptx": "pptx (python-pptx)",
        "PIL.Image": "images (Pillow)",
        "bs4": "html (beautifulsoup4)",
        "docling.document_converter": "odt/ods/odp/epub/eml/msg/rtf/latex (docling-slim)",
        "rapidocr": "OCR for scanned pages and images",
    }
    status = {}
    for mod, why in wanted.items():
        status[mod] = {"available": adapters._optional(mod) is not None, "enables": why}
    pip_name: dict[str, str] = {
        "fitz": "PyMuPDF", "docx": "python-docx", "pptx": "python-pptx",
        "PIL.Image": "Pillow", "bs4": "beautifulsoup4",
        "docling.document_converter":
            '"docling-slim[format-office,format-web,format-opendocument,'
            'format-pdf,format-email]"',
        "rapidocr": "rapidocr onnxruntime",
    }
    missing: list[str] = [m for m, s in status.items() if not s["available"]]
    _emit({
        "python": sys.version.split()[0],
        "status": status,
        "install_missing": (
            "py -3 -m pip install "
            + " ".join(pip_name.get(m, m) for m in missing)
            if missing else None),
        "policy": "nothing is installed automatically; run the command yourself",
    })
    return EXIT_OK


# -------------------------------------------------------------------- support

def _debug_stages(doc: Document) -> dict[str, Any]:
    """Everything a developer needs to see why extraction went wrong."""
    return {
        "detection": {"format": doc.source.fmt, "authority": doc.source.authority,
                      "fingerprint": doc.source.sha256, "pipeline": doc.pipeline},
        "counts": {t.value: len(doc.by_type(t)) for t in ElementType
                   if doc.by_type(t)},
        "regions": [{"id": t.id, "range": t.meta.get("region"),
                     "header_rows": t.meta.get("header_rows"),
                     "row_roles": t.meta.get("row_roles"),
                     "source": t.source.locator if t.source else None}
                    for t in doc.by_type(ElementType.TABLE)],
        "headers": [{"id": h.id, "label": h.content, "path": h.meta.get("path"),
                     "semantic_type": h.meta.get("semantic_type"),
                     "unit": h.meta.get("unit")}
                    for h in doc.by_type(ElementType.TABLE_HEADER)],
        "merged_cells": [{"id": e.id, "source": e.source.locator if e.source else None,
                          "anchor_for": e.meta.get("merged_anchor_for"),
                          "covered_by": e.meta.get("covered_by"),
                          "span": e.meta.get("span")}
                         for e in doc.elements.values()
                         if e.meta.get("merged_anchor_for") or e.meta.get("covered_by")],
        "formulas": [{"id": e.id, "source": e.source.locator if e.source else None,
                      "formula": e.meta.get("formula"),
                      "cached_value": e.meta.get("cached_value"),
                      "depends_on": e.meta.get("depends_on")}
                     for e in doc.elements.values() if e.meta.get("formula")],
        "figures": [{"id": f.id, "class": f.meta.get("image_class"),
                     "confidence": f.meta.get("image_class_confidence"),
                     "rationale": f.meta.get("image_class_rationale"),
                     "caption": f.meta.get("caption")}
                    for f in doc.by_type(ElementType.FIGURE)],
        "relationships": compiler._compile_relationships(doc),
        "reading_order": [{"id": e.id, "type": e.type.value,
                           "source": e.source.locator if e.source else None,
                           "text": (e.content or "")[:80]}
                          for e in doc.walk() if e.content][:500],
        "provenance_gaps": [e.id for e in doc.elements.values() if e.source is None],
        "model_generated": [{"id": e.id, "confidence": e.confidence,
                             "text": (e.content or "")[:120]}
                            for e in doc.elements.values()
                            if e.basis is Basis.MODEL_GENERATED],
        "safety": compiler._safety_block(doc),
        "report": doc.report.to_dict(),
    }


def _validate(doc: Document) -> dict[str, Any]:
    """Quality gate. Checks the invariants the representation promises."""
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"check": name, "ok": ok, "detail": detail})

    missing_src = [e.id for e in doc.elements.values() if e.source is None]
    check("every element has provenance", not missing_src,
          f"{len(missing_src)} element(s) without a source" if missing_src else "all sourced")

    orphans = [e.id for e in doc.elements.values()
               if e.parent is not None and e.parent not in doc.elements]
    check("no dangling parents", not orphans, f"{len(orphans)} orphan(s)")

    bad_rel = [(e.id, r.target) for e in doc.elements.values() for r in e.relationships
               if r.target not in doc.elements]
    check("relationship targets resolve", not bad_rel,
          f"{len(bad_rel)} edge(s) point at unknown elements"
          if bad_rel else "all targets resolve")

    headers = doc.by_type(ElementType.TABLE_HEADER)
    unresolved = [h.id for h in headers if not h.meta.get("path")]
    check("table headers resolved", not unresolved,
          f"{len(unresolved)} header(s) with no path" if unresolved
          else f"{len(headers)} header(s) resolved")

    formulas = [e for e in doc.elements.values() if e.meta.get("formula")]
    lost = [e.id for e in formulas if e.meta.get("formula") and "cached_value" not in e.meta]
    check("formulas keep both forms", not lost,
          f"{len(formulas)} formula(s), {len(lost)} without a cached value")

    guessed = [e.id for e in doc.elements.values()
               if e.basis is Basis.MODEL_GENERATED and e.confidence >= 0.999]
    check("model output declares uncertainty", not guessed,
          f"{len(guessed)} model-generated element(s) claim certainty")

    check("no failed stages", not doc.report.failed,
          f"{len(doc.report.failed)} failure(s)" if doc.report.failed else "none")

    passed = all(c["ok"] for c in checks)
    return {"passed": passed, "checks": checks,
            "unsupported": doc.report.unsupported, "partial": doc.report.partial}


# ------------------------------------------------------------------------ main

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="document_understand.py",
        description="Universal Document Understanding: any document -> AI-native context.")
    sub = p.add_subparsers(dest="command", required=True)

    def common(sp: argparse.ArgumentParser, *, file: bool = True) -> None:
        if file:
            sp.add_argument("file")
        sp.add_argument("--shallow", action="store_true",
                        help="structure only; skip cell/block content")
        sp.add_argument("--ocr", action="store_true",
                        help="run OCR on images and scanned pages (needs rapidocr)")

    def levelled(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--level", type=int, default=2, choices=(1, 2, 3))
        sp.add_argument("--max-rows", type=int, default=compiler.MAX_TABLE_ROWS_MD)

    sp = sub.add_parser("inspect", help="cheapest look: format, size, shape")
    common(sp)
    sp.set_defaults(func=cmd_inspect)

    sp = sub.add_parser("outline", help="structure without content")
    common(sp)
    sp.set_defaults(func=cmd_outline)

    sp = sub.add_parser("context", help="compiled AI context as JSON")
    common(sp)
    levelled(sp)
    sp.set_defaults(func=cmd_context)

    sp = sub.add_parser("markdown", help="AI-friendly Markdown to stdout")
    common(sp)
    levelled(sp)
    sp.set_defaults(func=cmd_markdown)

    sp = sub.add_parser("chunks", help="retrieval chunks as JSONL")
    common(sp)
    sp.add_argument("--max-tokens", type=int, default=chunking.DEFAULT_MAX_TOKENS)
    sp.set_defaults(func=cmd_chunks)

    sp = sub.add_parser("search", help="find text, with provenance")
    common(sp)
    sp.add_argument("query")
    sp.add_argument("--limit", type=int, default=50)
    sp.set_defaults(func=cmd_search)

    sp = sub.add_parser("analyze", help="write document.json + document.md + chunks.jsonl")
    common(sp)
    levelled(sp)
    sp.add_argument("-o", "--output", default="output")
    sp.add_argument("--max-tokens", type=int, default=chunking.DEFAULT_MAX_TOKENS)
    sp.add_argument("--debug", action="store_true", help="also write debug/ dumps")
    sp.set_defaults(func=cmd_analyze)

    sp = sub.add_parser("debug", help="inspect any pipeline stage")
    common(sp)
    sp.add_argument("--stage")
    sp.set_defaults(func=cmd_debug)

    sp = sub.add_parser("validate", help="run the extraction quality gate")
    common(sp)
    sp.set_defaults(func=cmd_validate)

    sp = sub.add_parser("formats", help="what this build can read")
    sp.set_defaults(func=cmd_formats)

    sp = sub.add_parser("deps", help="which optional dependencies are present")
    sp.set_defaults(func=cmd_deps)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except security.SecurityError as exc:
        _emit({"error": "refused", "reason": str(exc),
               "note": "resource or container safety check failed; the file was not parsed"})
        return EXIT_REFUSED
    except FileNotFoundError as exc:
        _emit({"error": "not found", "reason": str(exc)})
        return EXIT_ERROR
    except BrokenPipeError:
        return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
