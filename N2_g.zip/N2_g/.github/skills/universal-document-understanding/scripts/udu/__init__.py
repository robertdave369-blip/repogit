"""Universal Document Understanding layer.

Pipeline:

    input -> format detection -> parser -> structural representation
          -> context resolution -> semantic enrichment -> AI context compilation
          -> validation -> JSON + Markdown -> semantic chunks

Design rules:

* **Reuse before reimplementation.** Format detection, authority classification and
  fingerprinting come from the sibling `document_context.py`, which is already tested. PDF
  extraction delegates to `pdf_document_intelligence.py`. Long-tail formats delegate to
  docling when it is installed.
* **Dependencies are never installed silently.** A missing optional package is reported as
  `unsupported` with the exact command to fix it.
* **Nothing is invented.** Every element declares `EXTRACTED`, `INFERRED` or
  `MODEL_GENERATED`, and every element keeps its provenance.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType

SCRIPTS_DIR = Path(__file__).resolve().parent.parent

__all__ = ["load_sibling", "document_context"]


def load_sibling(name: str) -> ModuleType | None:
    """Import a script that lives beside the `udu` package, by file path.

    These scripts are standalone CLI tools rather than an installed package, so there is
    no import path to them. Registering in `sys.modules` before `exec_module` is required:
    on Python 3.14 `@dataclass` resolves `cls.__module__` through `sys.modules` and raises
    if the entry is missing.
    """
    if name in sys.modules:
        return sys.modules[name]
    path = SCRIPTS_DIR / f"{name}.py"
    if not path.exists():
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        return None
    return module


document_context = load_sibling("document_context")
