"""Format adapters: source file -> canonical `Document`.

Routing policy, decided in `research/document-parsers/comparison.md`:

* **Excel stays local.** Docling loads workbooks `data_only=True` and discards every cell
  formula (`msexcel_backend.py:334-340`). Formula fidelity is a hard requirement, so
  `.xlsx` is never delegated.
* **PDF, DOCX, PPTX, CSV, HTML, Markdown, text, images** use the local path, which is
  already tested and has no extra install cost.
* **The long tail** -- ODT, ODS, ODP, EPUB, `.eml`, `.msg`, RTF, LaTeX, AsciiDoc, legacy
  `.doc`/`.ppt` -- routes to **docling** when it is installed. Hand-writing an ODF or MIME
  parser to a worse standard would be the wrong trade.

A format with no available adapter is reported as `unsupported` with the reason and the
exact install command. It is never silently skipped and never partially guessed.
"""

from __future__ import annotations

import datetime as _dt
import re
from pathlib import Path
from typing import Any

from . import document_context as _dc
from . import security
from .model import (Basis, Document, Element, ElementType, Rel, Source, make_id)
from .spreadsheet import (CellData, ColumnType, Region, RowRole, SheetGrid, analyse_sheet,
                          col_letter, expand_ref, formula_dependencies, formula_functions,
                          header_label, parse_range)

MAX_CELLS_PER_SHEET = 200_000
PREVIEW_CHARS = 400

# Formats we hand to docling rather than parse ourselves.
DOCLING_FORMATS = {
    "odt": "format-opendocument", "ods": "format-opendocument",
    "odp": "format-opendocument", "epub": "format-web",
    "eml": "format-email", "msg": "format-email",
    "rtf": "format-web", "latex": "format-latex", "tex": "format-latex",
    "asciidoc": "format-web", "adoc": "format-web",
}

EXTRA_EXT_MAP = {
    ".odt": "odt", ".ods": "ods", ".odp": "odp", ".epub": "epub",
    ".eml": "eml", ".msg": "msg", ".rtf": "rtf", ".tex": "latex",
    ".adoc": "asciidoc", ".asciidoc": "asciidoc", ".doc": "doc",
    ".ppt": "ppt", ".pptx": "pptx",
}

ODF_MARKERS = {
    "application/vnd.oasis.opendocument.text": "odt",
    "application/vnd.oasis.opendocument.spreadsheet": "ods",
    "application/vnd.oasis.opendocument.presentation": "odp",
}


# ------------------------------------------------------------------- detection

def detect(path: Path) -> str:
    """Signature first, extension second -- reusing the tested detector, then extending it.

    `document_context.detect_format` already covers the core set. It returns `"zip"` for a
    PK container it does not recognise, which is where ODF and EPUB land, so those are
    resolved here by reading the container's own mimetype declaration rather than trusting
    the extension.
    """
    fmt = "unknown"
    if _dc is not None:
        try:
            fmt = _dc.detect_format(path)
        except Exception:
            fmt = "unknown"
    if fmt in ("zip", "unknown"):
        resolved = _resolve_container(path)
        if resolved:
            return resolved
    if fmt in ("unknown", "ole"):
        return EXTRA_EXT_MAP.get(path.suffix.lower(), fmt)
    return fmt


def _resolve_container(path: Path) -> str | None:
    import zipfile
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            if "mimetype" in names:
                mime = zf.read("mimetype").decode("ascii", "ignore").strip()
                if mime in ODF_MARKERS:
                    return ODF_MARKERS[mime]
                if mime == "application/epub+zip":
                    return "epub"
            if "META-INF/container.xml" in names:
                return "epub"
    except Exception:
        pass
    return EXTRA_EXT_MAP.get(path.suffix.lower())


def _source_for(path: Path, fmt: str, digest: str) -> Source:
    authority = "UNKNOWN"
    if _dc is not None:
        try:
            authority = _dc.classify_authority(path)
        except Exception:
            pass
    return Source(file=path.name, fmt=fmt, sha256=digest, authority=authority)


def _optional(mod: str):
    if _dc is not None:
        try:
            return _dc.optional(mod)
        except Exception:
            pass
    try:
        import importlib
        return importlib.import_module(mod)
    except Exception:
        return None


# --------------------------------------------------------------------- routing

def build(path: Path, *, deep: bool = True, ocr: bool = False) -> Document:
    """Parse `path` into the canonical representation."""
    guard = security.guard_file(path)
    fmt = detect(path)
    digest = _dc.fingerprint(path) if _dc is not None else ""
    src = _source_for(path, fmt, digest)
    doc = Document(source=src)
    doc.metadata["size_bytes"] = guard.size
    doc.pipeline.append(f"detect:{fmt}")
    for w in guard.warnings:
        doc.report.part("file", w)

    if fmt in ("xlsx", "docx", "pptx", "odt", "ods", "odp", "epub"):
        try:
            for w in security.guard_archive(path):
                doc.report.part("container", w)
            doc.pipeline.append("guard:archive")
        except security.SecurityError as exc:
            doc.report.fail("container", str(exc))
            return doc

    root = doc.add(Element(id=make_id(fmt, path.stem), type=ElementType.DOCUMENT,
                           content=path.name, source=src))
    doc.metadata["root"] = root.id

    dispatch = {
        "xlsx": _build_xlsx, "pdf": _build_pdf, "docx": _build_docx,
        "pptx": _build_pptx, "csv": _build_tabular, "tsv": _build_tabular,
        "html": _build_html, "markdown": _build_markdown, "text": _build_text,
        "json": _build_text, "xml": _build_text, "arxml": _build_text,
        "dbc": _build_text,
    }
    handler = dispatch.get(fmt)
    try:
        if handler is not None:
            handler(path, doc, root, deep)
        elif fmt in ("png", "jpeg", "gif", "bmp", "tiff", "webp", "svg"):
            _build_image(path, doc, root, deep, ocr)
        elif fmt in DOCLING_FORMATS:
            _build_via_docling(path, doc, root, fmt)
        else:
            doc.report.unsup(
                fmt, f"no adapter for format {fmt!r}; supported: "
                     f"{', '.join(sorted(set(list(dispatch) + list(DOCLING_FORMATS))))}")
    except security.SecurityError:
        raise
    except Exception as exc:                      # adapter failure must not be silent
        doc.report.fail(fmt, f"{type(exc).__name__}: {exc}"[:300])

    _scan_for_injection(doc)
    return doc


def _scan_for_injection(doc: Document) -> None:
    """Flag instruction-shaped content. Text is never rewritten -- only labelled."""
    findings: list[dict[str, Any]] = []
    for el in doc.elements.values():
        if not el.content:
            continue
        for f in security.scan_text(el.content, el.id):
            el.meta["injection_risk"] = True
            findings.append(f.to_dict())
    if findings:
        doc.metadata["injection_findings"] = findings[:50]
        doc.metadata["injection_finding_count"] = len(findings)
        doc.report.part(
            "content safety",
            f"{len(findings)} passage(s) read as instruction-shaped; content is preserved "
            f"verbatim and marked as data, never executed")
    doc.pipeline.append("scan:injection")


# ----------------------------------------------------------------------- excel

def _build_xlsx(path: Path, doc: Document, root: Element, deep: bool) -> None:
    openpyxl = _optional("openpyxl")
    if openpyxl is None:
        doc.report.unsup("workbook", "openpyxl not installed -- run: py -3 -m pip install openpyxl")
        return

    wb = openpyxl.load_workbook(path, data_only=False, read_only=False, keep_links=False)
    try:
        wbv = openpyxl.load_workbook(path, data_only=True, read_only=False, keep_links=False)
    except Exception:
        wbv = None
        doc.report.part("cached values", "second pass failed; formulas kept, values unavailable")

    try:
        props = wb.properties
        doc.metadata.update({k: v for k, v in {
            "title": props.title, "creator": props.creator,
            "modified": str(props.modified) if props.modified else None}.items() if v})
    except Exception:
        doc.report.part("workbook metadata", "properties unreadable")

    defined: dict[str, str] = {}
    try:
        for name, dn in wb.defined_names.items():
            defined[name] = str(getattr(dn, "value", ""))
    except Exception:
        pass
    if defined:
        doc.metadata["defined_names"] = defined

    doc.metadata["sheets"] = list(wb.sheetnames)
    doc.pipeline.append("parse:openpyxl(dual data_only)")

    for name in wb.sheetnames:
        ws = wb[name]
        wsv = wbv[name] if wbv is not None else None
        grid = _read_grid(ws, wsv, name, doc)
        sheet_el = doc.add(Element(
            id=make_id("sheet", name), type=ElementType.SHEET, content=name,
            source=Source(file=path.name, fmt="xlsx", sha256=doc.source.sha256,
                          sheet=name, authority=doc.source.authority),
            meta={"state": grid.state, "max_row": grid.max_row, "max_col": grid.max_col,
                  "merged_ranges": grid.merged,
                  "hidden_rows": sorted(grid.hidden_rows)[:100],
                  "hidden_columns": [col_letter(c) for c in sorted(grid.hidden_cols)][:100]},
        ), parent=root.id)

        regions, warnings = analyse_sheet(grid)
        for w in warnings:
            doc.report.part("region detection", w)
        for idx, region in enumerate(regions, 1):
            _emit_region(doc, path, grid, region, sheet_el, idx, deep)

        doc.report.ok(f"sheet {name}: {len(regions)} region(s)")

    doc.pipeline.append("semantics:spreadsheet")
    try:
        wb.close()
        if wbv is not None:
            wbv.close()
    except Exception:
        pass


def _read_grid(ws: Any, wsv: Any, name: str, doc: Document) -> SheetGrid:
    grid = SheetGrid(name=name)
    grid.state = getattr(ws, "sheet_state", "visible")
    try:
        grid.max_row, grid.max_col = int(ws.max_row or 0), int(ws.max_column or 0)
    except Exception:
        grid.max_row = grid.max_col = 0

    try:
        grid.merged = [str(r) for r in ws.merged_cells.ranges]
    except Exception:
        doc.report.part(f"merged ranges on {name}", "not enumerable")

    covered: dict[tuple[int, int], str] = {}
    spans: dict[tuple[int, int], tuple[int, int]] = {}
    for rng in grid.merged:
        bounds = parse_range(rng)
        if bounds is None:
            doc.report.part(f"merged range {rng}", "unbounded; cells not mapped")
            continue
        r1, c1, r2, c2 = bounds
        spans[(r1, c1)] = (r2 - r1 + 1, c2 - c1 + 1)
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                if (r, c) != (r1, c1):
                    covered[(r, c)] = rng

    try:
        for dim in ws.row_dimensions.values():
            if getattr(dim, "hidden", False) and dim.index:
                grid.hidden_rows.add(int(dim.index))
        for key, dim in ws.column_dimensions.items():
            if getattr(dim, "hidden", False):
                from .spreadsheet import col_index
                try:
                    grid.hidden_cols.add(col_index(str(key)))
                except Exception:
                    pass
    except Exception:
        pass

    count = 0
    for row in ws.iter_rows():
        for cell in row:
            rc = (cell.row, cell.column)
            raw = cell.value
            if raw is None and rc not in covered:
                continue
            count += 1
            if count > MAX_CELLS_PER_SHEET:
                grid.truncated = True
                doc.report.part(f"sheet {name}",
                                f"stopped after {MAX_CELLS_PER_SHEET} cells")
                return grid
            is_formula = isinstance(raw, str) and raw.startswith("=")
            cached = None
            if is_formula and wsv is not None:
                try:
                    cached = wsv.cell(cell.row, cell.column).value
                except Exception:
                    cached = None
            data = CellData(
                row=cell.row, col=cell.column,
                value=None if is_formula else raw,
                formula=raw if is_formula else None,
                cached=cached,
                number_format=(cell.number_format
                               if cell.number_format != "General" else None),
                merged_anchor_for=next((r for r in grid.merged
                                        if r.split(":")[0] == cell.coordinate), None),
                covered_by=covered.get(rc),
                span=spans.get(rc, (1, 1)),
            )
            try:
                if cell.hyperlink is not None:
                    data.hyperlink = str(cell.hyperlink.target or "")
                if cell.comment is not None:
                    data.comment = str(cell.comment.text or "")[:500]
            except Exception:
                pass
            grid.cells[rc] = data
    return grid


def _emit_region(doc: Document, path: Path, grid: SheetGrid, region: Region,
                 sheet_el: Element, idx: int, deep: bool) -> None:
    """One region -> a section (if titled) containing a table with resolved headers."""
    sheet = grid.name

    def src(cell_ref: str | None = None, rng: str | None = None) -> Source:
        return Source(file=path.name, fmt="xlsx", sha256=doc.source.sha256, sheet=sheet,
                      cell=cell_ref, cell_range=rng, authority=doc.source.authority,
                      section=region.title)

    # A one-cell island is a note or a stray label, not a table. Emitting an empty
    # table for it produced a header-less, row-less "table" in the output, which is
    # noise that reads as a failed extraction.
    if (region.r1 == region.r2 and region.c1 == region.c2) or not region.data_rows:
        # Emit EVERY populated cell, not just the anchor. Emitting only the anchor
        # silently dropped the rest of the block -- including, in testing, the one
        # passage the injection scanner most needed to see.
        emitted = 0
        for rr in range(region.r1, region.r2 + 1):
            for cc in range(region.c1, region.c2 + 1):
                cell = grid.at(rr, cc)
                if cell is None or not cell.text:
                    continue
                ref = f"{col_letter(cc)}{rr}"
                note = doc.add(Element(
                    id=make_id("note", sheet, ref), type=ElementType.NOTE,
                    content=cell.text, source=src(ref, region.ref),
                    basis=Basis.EXTRACTED,
                    meta={"region": region.ref, "reason": "text-only region",
                          "row": rr, "column": col_letter(cc)},
                ), parent=sheet_el.id)
                note.relate(Rel.BELONGS_TO_SECTION, sheet_el.id)
                emitted += 1
        if emitted:
            doc.report.ok(f"{sheet}!{region.ref}: {emitted} text cell(s)")
        return

    container = sheet_el
    if region.title:
        # The merged title is the parent context of everything below it -- the whole point
        # of the merged-cell requirement.
        section = doc.add(Element(
            id=make_id("section", sheet, region.ref), type=ElementType.SECTION,
            content=region.title, source=src(region.title_cell, region.ref),
            basis=Basis.EXTRACTED,
            meta=_merge_meta(grid, region.title_cell) | {
                "derived_from_merged_range": next(
                    (r for r in grid.merged
                     if region.title_cell and r.split(":")[0] == region.title_cell),
                    None)},
        ), parent=sheet_el.id)
        container = section

    table = doc.add(Element(
        id=make_id("table", sheet, region.ref), type=ElementType.TABLE,
        content=region.title, source=src(rng=region.ref), basis=Basis.INFERRED,
        confidence=0.9 if region.header_rows else 0.7,
        meta={
            "region": region.ref, "index": idx,
            "header_rows": region.header_rows,
            "row_count": len(region.data_rows),
            "column_count": region.c2 - region.c1 + 1,
            "row_roles": {str(r): v.value for r, v in sorted(region.row_roles.items())},
            "notes": region.notes,
        },
    ), parent=container.id)
    if container.type == ElementType.SECTION:
        table.relate(Rel.BELONGS_TO_SECTION, container.id)

    # --- header columns -----------------------------------------------------
    col_element: dict[int, str] = {}
    merge_anchor_cols: dict[str, list[int]] = {}
    for c in range(region.c1, region.c2 + 1):
        path_parts = region.header_paths.get(c, [col_letter(c)])
        ctype = region.column_types.get(c, ColumnType.EMPTY)
        anchor_ref = (f"{col_letter(c)}{region.header_rows[0]}"
                      if region.header_rows else f"{col_letter(c)}{region.r1}")
        hdr = doc.add(Element(
            id=make_id("col", sheet, region.ref, col_letter(c)),
            type=ElementType.TABLE_HEADER,
            content=header_label(region, c),
            source=src(anchor_ref),
            basis=Basis.INFERRED if len(path_parts) > 1 else Basis.EXTRACTED,
            confidence=0.95,
            meta={"column": col_letter(c), "path": path_parts,
                  "semantic_type": ctype.value,
                  **({"unit": region.column_units[c]} if c in region.column_units else {}),
                  "hidden": c in grid.hidden_cols},
        ), parent=table.id)
        hdr.relate(Rel.HEADER_FOR, table.id, column=col_letter(c))
        col_element[c] = hdr.id

        # A hierarchical header exists *because* of a horizontal merge. Recording the
        # merge only on data cells left the structure that created the header path
        # undocumented -- the path was there, its origin was not.
        for hr in region.header_rows:
            hcell = grid.at(hr, c)
            if hcell is None:
                continue
            if hcell.merged_anchor_for:
                hdr.meta["merged_anchor_for"] = hcell.merged_anchor_for
                hdr.meta["span"] = {"rows": hcell.span[0], "cols": hcell.span[1]}
                break
            if hcell.covered_by:
                hdr.meta["covered_by"] = hcell.covered_by
                merge_anchor_cols.setdefault(hcell.covered_by, []).append(c)
                break

    # Covered header columns point at the column that owns the merge, so a consumer can
    # ask "which columns does this spanning label cover?" and get an answer.
    for rng, cols in merge_anchor_cols.items():
        bounds = parse_range(rng)
        if bounds is None:
            continue
        anchor_col = bounds[1]
        anchor_id = col_element.get(anchor_col)
        if anchor_id is None:
            continue
        for cc in cols:
            covered_el = doc.get(col_element.get(cc, ""))
            if covered_el is not None:
                covered_el.relate(Rel.MERGED_WITH, anchor_id, range=rng)

    if not deep:
        doc.report.part(f"{sheet}!{region.ref}", "outline mode -- cells omitted")
        return

    # --- data rows and cells ------------------------------------------------
    prev_row_id: str | None = None
    for r in sorted(set(region.header_rows + region.data_rows)):
        role = region.row_roles.get(r, RowRole.DATA)
        row_cells = [grid.at(r, c) for c in range(region.c1, region.c2 + 1)]
        if not any(x is not None and not x.is_empty for x in row_cells):
            continue
        label = next((x.text for x in row_cells if x is not None and x.text), "")
        row_el = doc.add(Element(
            id=make_id("row", sheet, region.ref, r), type=ElementType.TABLE_ROW,
            content=label or None,
            source=src(rng=f"{col_letter(region.c1)}{r}:{col_letter(region.c2)}{r}"),
            basis=Basis.EXTRACTED,
            meta={"row": r, "role": role.value},
        ), parent=table.id)
        row_el.relate(Rel.SAME_TABLE, table.id)
        if prev_row_id:
            row_el.relate(Rel.FOLLOWS, prev_row_id)
        prev_row_id = row_el.id
        if role in (RowRole.TOTAL, RowRole.SUBTOTAL):
            row_el.relate(Rel.TOTAL_OF, table.id, kind=role.value)

        for c in range(region.c1, region.c2 + 1):
            cell = grid.at(r, c)
            if cell is None or cell.is_empty:
                continue
            ref = f"{col_letter(c)}{r}"
            meta: dict[str, Any] = {"column": col_letter(c), "row": r}
            if cell.number_format:
                meta["number_format"] = cell.number_format
            if cell.covered_by:
                meta["covered_by"] = cell.covered_by
            if cell.merged_anchor_for:
                meta["merged_anchor_for"] = cell.merged_anchor_for
                meta["span"] = {"rows": cell.span[0], "cols": cell.span[1]}
            if cell.hyperlink:
                meta["hyperlink"] = cell.hyperlink
            if cell.comment:
                meta["comment"] = cell.comment
            if c in region.column_units:
                meta["unit"] = region.column_units[c]
            meta["header"] = header_label(region, c)

            cell_el = doc.add(Element(
                id=make_id("cell", sheet, ref), type=ElementType.CELL,
                content=cell.text or None,
                value=_json_safe(cell.display),
                source=src(ref), basis=Basis.EXTRACTED, meta=meta,
            ), parent=row_el.id)
            if c in col_element:
                cell_el.relate(Rel.HEADER_FOR, col_element[c])
            if cell.covered_by:
                anchor = cell.covered_by.split(":")[0]
                cell_el.relate(Rel.MERGED_WITH, make_id("cell", sheet, anchor),
                               range=cell.covered_by)

            if cell.formula:
                deps = formula_dependencies(cell.formula, sheet)
                cell_el.meta["formula"] = cell.formula
                cell_el.meta["cached_value"] = _json_safe(cell.cached)
                cell_el.meta["functions"] = formula_functions(cell.formula)
                cell_el.meta["depends_on"] = deps
                for dep in deps:
                    for one in expand_ref(dep)[:64]:
                        sh, _, rr = one.partition("!")
                        cell_el.relate(Rel.FORMULA_DEPENDS_ON,
                                       make_id("cell", sh, rr), ref=one)


def _merge_meta(grid: SheetGrid, cell_ref: str | None) -> dict[str, Any]:
    """Merge facts for a cell address, empty when the cell is not merged."""
    if not cell_ref:
        return {}
    for rng in grid.merged:
        if rng.split(":")[0] != cell_ref:
            continue
        bounds = parse_range(rng)
        if bounds is None:
            continue
        r1, c1, r2, c2 = bounds
        return {"merged_anchor_for": rng,
                "span": {"rows": r2 - r1 + 1, "cols": c2 - c1 + 1}}
    return {}


def _json_safe(v: Any) -> Any:
    if isinstance(v, (_dt.date, _dt.datetime, _dt.time)):
        return v.isoformat()
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    return str(v)


# ------------------------------------------------------------------------- pdf

def _build_pdf(path: Path, doc: Document, root: Element, deep: bool) -> None:
    fitz = _optional("fitz")
    if fitz is None:
        doc.report.unsup("pdf", "PyMuPDF not installed -- run: py -3 -m pip install PyMuPDF")
        return
    pdf = fitz.open(str(path))
    doc.metadata["page_count"] = pdf.page_count
    try:
        doc.metadata.update({k: v for k, v in (pdf.metadata or {}).items() if v})
    except Exception:
        pass
    doc.pipeline.append("parse:pymupdf")

    toc_levels: dict[int, str] = {}
    try:
        for _lvl, title, page in pdf.get_toc() or []:
            toc_levels.setdefault(int(page), title)
    except Exception:
        pass

    current_section: str | None = None
    text_chars = 0
    table_count = 0
    prev_table: Element | None = None
    for pno in range(pdf.page_count):
        page = pdf[pno]
        psrc = Source(file=path.name, fmt="pdf", sha256=doc.source.sha256, page=pno + 1,
                      authority=doc.source.authority)
        page_el = doc.add(Element(
            id=make_id("page", pno + 1), type=ElementType.PAGE,
            source=psrc, meta={"page": pno + 1, "rotation": page.rotation,
                               "size": [round(page.rect.width, 1),
                                        round(page.rect.height, 1)]},
        ), parent=root.id)

        if pno + 1 in toc_levels:
            current_section = toc_levels[pno + 1]
            page_el.meta["section"] = current_section

        if not deep:
            continue

        try:
            blocks = page.get_text("dict")["blocks"]
        except Exception as exc:
            doc.report.part(f"page {pno + 1}", f"text extraction failed: {exc}"[:120])
            continue

        try:
            table_boxes, prev_table = _emit_pdf_tables(
                page, pno, path, doc, page_el, current_section, prev_table)
            table_count += len(table_boxes)
        except Exception as exc:
            doc.report.part(f"page {pno + 1} tables", f"table pass failed: {exc}"[:120])
            table_boxes = []

        prev_id: str | None = None
        captions: list[Element] = []
        figures: list[Element] = []
        for bi, block in enumerate(blocks):
            bbox = tuple(round(x, 1) for x in block.get("bbox", (0, 0, 0, 0)))
            if block.get("type") == 1:                      # image block
                fig = doc.add(Element(
                    id=make_id("fig", pno + 1, bi), type=ElementType.FIGURE,
                    source=Source(file=path.name, fmt="pdf", sha256=doc.source.sha256,
                                  page=pno + 1, bbox=bbox, section=current_section,
                                  authority=doc.source.authority),
                    basis=Basis.EXTRACTED,
                    meta={"width": block.get("width"), "height": block.get("height"),
                          "bbox": list(bbox)},
                ), parent=page_el.id)
                figures.append(fig)
                continue

            text = "".join(span.get("text", "")
                           for line in block.get("lines", [])
                           for span in line.get("spans", [])).strip()
            if not text:
                continue
            text_chars += len(text)
            sizes = [span.get("size", 0) for line in block.get("lines", [])
                     for span in line.get("spans", [])]
            avg_size = sum(sizes) / len(sizes) if sizes else 0
            flags = [span.get("flags", 0) for line in block.get("lines", [])
                     for span in line.get("spans", [])]
            bold = any(f & 16 for f in flags)

            etype = ElementType.PARAGRAPH
            if _is_caption(text):
                etype = ElementType.CAPTION
            elif (avg_size >= 13 or (bold and len(text) < 120)) and len(text) < 200:
                etype = ElementType.HEADING
                current_section = text

            el = doc.add(Element(
                id=make_id("blk", pno + 1, bi), type=etype, content=text,
                source=Source(file=path.name, fmt="pdf", sha256=doc.source.sha256,
                              page=pno + 1, bbox=bbox, section=current_section,
                              authority=doc.source.authority),
                basis=Basis.EXTRACTED,
                confidence=0.8 if etype is ElementType.HEADING else 1.0,
                meta={"bbox": list(bbox), "font_size": round(avg_size, 1), "bold": bold,
                      "reading_order": bi,
                      **({"inside_table": True} if _inside_any(bbox, table_boxes) else {})},
            ), parent=page_el.id)
            if prev_id:
                el.relate(Rel.FOLLOWS, prev_id)
            prev_id = el.id
            if etype is ElementType.CAPTION:
                captions.append(el)

        _bind_captions(captions, figures)

    if deep and pdf.page_count and text_chars < 40 * pdf.page_count:
        doc.report.part(
            "pdf text layer",
            f"only {text_chars} characters across {pdf.page_count} page(s) -- this looks "
            f"like a scanned PDF; re-run with --ocr to read it")
        doc.metadata["likely_scanned"] = True
    doc.metadata["table_count"] = table_count
    pdf.close()
    doc.report.ok(f"{doc.metadata['page_count']} page(s), {table_count} table(s)")


def _inside_any(bbox: tuple, boxes: list[tuple]) -> bool:
    """Does this text block sit inside a detected table? Centre-point containment.

    Text inside a table is kept as a paragraph as well as a cell -- flagged, never
    dropped -- so a consumer can dedupe but nothing is silently lost.
    """
    cx = (bbox[0] + bbox[2]) / 2
    cy = (bbox[1] + bbox[3]) / 2
    return any(b[0] <= cx <= b[2] and b[1] <= cy <= b[3] for b in boxes)


# --- PDF tables -----------------------------------------------------------------------

_MIN_TABLE_FILL = 0.45          # below this the "table" is whitespace, not structure
_MAX_TABLE_PAGE_FRACTION = 0.92  # a box this big is the page itself, not a table


def _table_quality(rows: list[list[Any]]) -> tuple[bool, str]:
    """Is this extraction actually a table, or whitespace that looked like one?

    The `text` strategy finds a grid on almost any page, so a candidate has to earn its
    place: at least two rows and two columns, and enough populated cells that the shape
    carries information.
    """
    if len(rows) < 2:
        return False, "fewer than 2 rows"
    ncols = max((len(r) for r in rows), default=0)
    if ncols < 2:
        return False, "fewer than 2 columns"
    total = sum(len(r) for r in rows)
    filled = sum(1 for r in rows for c in r if c is not None and str(c).strip())
    if not total or filled / total < _MIN_TABLE_FILL:
        return False, f"only {filled}/{total} cells populated"
    return True, ""


def _find_pdf_tables(page: Any) -> tuple[list[Any], str]:
    """Ruled tables first; fall back to whitespace alignment only when there are none.

    `lines` keys off drawn rulings and is precise. `text` infers a grid from column
    alignment and over-fires, so it runs only when `lines` found nothing on the page and
    every candidate it returns still has to pass `_table_quality`.
    """
    for strategy in ("lines", "text"):
        try:
            found = page.find_tables(strategy=strategy)
        except Exception:
            continue
        tables = list(getattr(found, "tables", []))
        if tables:
            return tables, strategy
    return [], ""


def _emit_pdf_tables(page: Any, pno: int, path: Path, doc: Document, page_el: Element,
                     section: str | None, prev_table: Element | None) -> tuple[list[tuple], Element | None]:
    """Emit every table on one page as a real row/cell structure.

    Returns the table bounding boxes (so text blocks inside them can be marked rather
    than silently dropped) and the last table emitted, so a table continuing across a
    page break can be linked to its predecessor.
    """
    tables, strategy = _find_pdf_tables(page)
    boxes: list[tuple] = []
    last = prev_table
    page_area = abs(page.rect.width * page.rect.height) or 1.0

    for ti, tb in enumerate(tables):
        try:
            rows = tb.extract()
        except Exception as exc:
            doc.report.part(f"page {pno + 1} table {ti + 1}",
                            f"cell extraction failed: {exc}"[:120])
            continue
        ok, why = _table_quality(rows)
        bbox = tuple(round(float(x), 1) for x in tb.bbox)
        if abs((bbox[2] - bbox[0]) * (bbox[3] - bbox[1])) / page_area > _MAX_TABLE_PAGE_FRACTION:
            ok, why = False, "candidate covers the whole page"
        if not ok:
            if strategy == "lines":
                doc.report.part(f"page {pno + 1} table {ti + 1}",
                                f"ruled grid rejected as a table: {why}")
            continue

        ncols = max(len(r) for r in rows)
        hdr_names: list[str] = []
        try:
            header = getattr(tb, "header", None)
            if header is not None and getattr(header, "names", None):
                hdr_names = [(n or "").strip() for n in header.names]
        except Exception:
            hdr_names = []
        # `external` means the header sits outside the table body; when it is False the
        # header IS row 0 and must not be emitted a second time as data.
        header_external = bool(getattr(getattr(tb, "header", None), "external", False))
        if not hdr_names:
            hdr_names = [(c or "").strip() if c else "" for c in rows[0]]
            header_external = False

        # A table continued from the previous page keeps its columns but loses its header
        # row. Inheriting it is a structural inference, so it is labelled as one.
        header_inherited = False
        blank = sum(1 for n in hdr_names if not n)
        if (blank * 2 >= len(hdr_names) and prev_table is not None
                and prev_table.meta.get("cols") == max(len(r) for r in rows)
                and (prev_table.source.page or 0) == pno):
            hdr_names = list(prev_table.meta.get("column_names") or hdr_names)
            header_external, header_inherited = True, True

        tbl = doc.add(Element(
            id=make_id("tbl", pno + 1, ti), type=ElementType.TABLE,
            source=Source(file=path.name, fmt="pdf", sha256=doc.source.sha256,
                          page=pno + 1, bbox=bbox, section=section,
                          authority=doc.source.authority),
            basis=Basis.INFERRED, confidence=0.9 if strategy == "lines" else 0.6,
            meta={"bbox": list(bbox), "rows": len(rows), "cols": ncols,
                  "row_count": len(rows), "column_count": ncols,
                  "detection": f"pymupdf:{strategy}", "column_names": hdr_names,
                  **({"header_inherited": True} if header_inherited else {})},
        ), parent=page_el.id)
        boxes.append(bbox)

        # One header element per column -- the same shape the spreadsheet path emits, so
        # the compiler, chunker and validator stay format-blind.
        col_element: dict[int, str] = {}
        for ci in range(ncols):
            label = (hdr_names[ci] if ci < len(hdr_names) else "").replace("\n", " ").strip()
            hdr_el = doc.add(Element(
                id=make_id("tbl", pno + 1, ti, "h", ci), type=ElementType.TABLE_HEADER,
                content=label or f"column {ci + 1}",
                source=Source(file=path.name, fmt="pdf", sha256=doc.source.sha256,
                              page=pno + 1, bbox=bbox, section=section,
                              authority=doc.source.authority),
                basis=Basis.INFERRED if header_inherited else Basis.EXTRACTED,
                confidence=0.6 if header_inherited else 0.85,
                meta={"column": ci, "path": [label] if label else [],
                      "label": label,
                      **({"inherited_from_previous_page": True} if header_inherited else {}),
                      **({} if label else {"unlabelled": True})},
            ), parent=tbl.id)
            hdr_el.relate(Rel.HEADER_FOR, tbl.id, column=ci)
            col_element[ci] = hdr_el.id

        body = rows if header_external else rows[1:]
        for ri, row in enumerate(body):
            r_el = doc.add(Element(
                id=make_id("tbl", pno + 1, ti, "r", ri), type=ElementType.TABLE_ROW,
                content=" | ".join((c or "").strip().replace("\n", " ") for c in row),
                source=Source(file=path.name, fmt="pdf", sha256=doc.source.sha256,
                              page=pno + 1, section=section,
                              authority=doc.source.authority),
                basis=Basis.EXTRACTED, meta={"row_index": ri},
            ), parent=tbl.id)
            r_el.relate(Rel.SAME_TABLE, tbl.id)
            for ci, cell in enumerate(row):
                text = (cell or "").strip().replace("\n", " ")
                if not text:
                    continue
                col = hdr_names[ci] if ci < len(hdr_names) else ""
                c_el = doc.add(Element(
                    id=make_id("tbl", pno + 1, ti, "r", ri, "c", ci),
                    type=ElementType.TABLE_CELL, content=text,
                    source=Source(file=path.name, fmt="pdf", sha256=doc.source.sha256,
                                  page=pno + 1, section=section,
                                  authority=doc.source.authority),
                    basis=Basis.EXTRACTED,
                    meta={"row": ri, "column": ci, "header": col or None},
                ), parent=r_el.id)
                if ci in col_element:
                    c_el.relate(Rel.HEADER_FOR, col_element[ci], column=ci)

        # A table split across a page break keeps the same column signature.
        if (last is not None and last.meta.get("cols") == ncols
                and (header_inherited or last.meta.get("column_names") == hdr_names)
                and (last.source.page or 0) == pno):
            tbl.relate(Rel.FOLLOWS, last.id, kind="table_continuation")
            last.relate(Rel.REFERENCES, tbl.id, kind="continues_on_next_page")
            tbl.meta["continues_from"] = last.id
        last = tbl
    return boxes, last


_CAPTION_RE = re.compile(r"^\s*(figure|fig\.?|table|chart|exhibit|diagram)\s*\.?\s*\d",
                         re.I)


def _is_caption(text: str) -> bool:
    return bool(_CAPTION_RE.match(text)) and len(text) < 400


def _bind_captions(captions: list[Element], figures: list[Element]) -> None:
    """Attach each caption to the nearest figure above or below it on the page.

    Distance is between bbox centres. When a page has captions but no figure blocks --
    common when the graphic is vector art rather than a raster image -- the caption keeps
    its own text and simply carries no `caption_for` edge, which is honest.
    """
    for cap in captions:
        cbox = cap.meta.get("bbox")
        if not cbox or not figures:
            continue
        cy = (cbox[1] + cbox[3]) / 2
        best, best_d = None, float("inf")
        for fig in figures:
            fbox = fig.meta.get("bbox")
            if not fbox:
                continue
            fy = (fbox[1] + fbox[3]) / 2
            d = abs(cy - fy)
            if d < best_d:
                best, best_d = fig, d
        if best is not None:
            cap.relate(Rel.CAPTION_FOR, best.id, distance=round(best_d, 1))
            best.relate(Rel.REFERENCES, cap.id, kind="caption")
            best.meta["caption"] = cap.content


# ------------------------------------------------------------------------ docx

def _build_docx(path: Path, doc: Document, root: Element, deep: bool) -> None:
    docx = _optional("docx")
    if docx is None:
        doc.report.unsup("docx", "python-docx not installed -- run: py -3 -m pip install python-docx")
        return
    d = docx.Document(str(path))
    doc.pipeline.append("parse:python-docx")
    try:
        cp = d.core_properties
        doc.metadata.update({k: v for k, v in {
            "title": cp.title, "author": cp.author, "subject": cp.subject,
            "modified": str(cp.modified) if cp.modified else None}.items() if v})
    except Exception:
        pass

    # Heading hierarchy: a stack of open sections keyed by outline level.
    stack: list[tuple[int, str]] = [(0, root.id)]
    prev_id: str | None = None
    captions: list[Element] = []
    figures: list[Element] = []
    counter = 0

    for para in d.paragraphs:
        text = (para.text or "").strip()
        style = (para.style.name if para.style is not None else "") or ""
        if not text:
            continue
        counter += 1
        level = _heading_level(style)
        parent_id = stack[-1][1]
        src = Source(file=path.name, fmt="docx", sha256=doc.source.sha256,
                     section=_current_section(doc, parent_id),
                     authority=doc.source.authority)
        if level:
            while len(stack) > 1 and stack[-1][0] >= level:
                stack.pop()
            parent_id = stack[-1][1]
            el = doc.add(Element(
                id=make_id("h", level, counter), type=ElementType.HEADING, content=text,
                source=src, meta={"level": level, "style": style},
            ), parent=parent_id)
            section = doc.add(Element(
                id=make_id("sec", level, counter), type=ElementType.SECTION, content=text,
                source=src, basis=Basis.INFERRED, confidence=0.95,
                meta={"level": level, "heading": el.id},
            ), parent=parent_id)
            el.relate(Rel.BELONGS_TO_SECTION, section.id)
            stack.append((level, section.id))
            prev_id = el.id
            continue

        etype = ElementType.PARAGRAPH
        if style.startswith("List"):
            etype = ElementType.LIST_ITEM
        elif style.lower().startswith("caption") or _is_caption(text):
            etype = ElementType.CAPTION
        el = doc.add(Element(
            id=make_id("p", counter), type=etype, content=text, source=src,
            meta={"style": style},
        ), parent=parent_id)
        if prev_id:
            el.relate(Rel.FOLLOWS, prev_id)
        prev_id = el.id
        if etype is ElementType.CAPTION:
            captions.append(el)

    for ti, table in enumerate(d.tables, 1):
        parent_id = stack[-1][1]
        rows = table.rows
        tbl = doc.add(Element(
            id=make_id("tbl", ti), type=ElementType.TABLE,
            source=Source(file=path.name, fmt="docx", sha256=doc.source.sha256,
                          authority=doc.source.authority),
            basis=Basis.EXTRACTED,
            meta={"index": ti, "row_count": len(rows),
                  "column_count": len(table.columns)},
        ), parent=parent_id)
        header_ids: dict[int, str] = {}
        for ri, row in enumerate(rows):
            role = "header" if ri == 0 else "data"
            row_el = doc.add(Element(
                id=make_id("tbl", ti, "r", ri), type=ElementType.TABLE_ROW,
                basis=Basis.EXTRACTED, meta={"row": ri, "role": role},
            ), parent=tbl.id)
            for ci, cell in enumerate(row.cells):
                text = (cell.text or "").strip()
                if not text:
                    continue
                el = doc.add(Element(
                    id=make_id("tbl", ti, "r", ri, "c", ci),
                    type=(ElementType.TABLE_HEADER if ri == 0
                          else ElementType.TABLE_CELL),
                    content=text, basis=Basis.EXTRACTED,
                    source=Source(file=path.name, fmt="docx", sha256=doc.source.sha256,
                                  cell=f"t{ti}r{ri}c{ci}", authority=doc.source.authority),
                    meta={"row": ri, "column": ci},
                ), parent=row_el.id)
                if ri == 0:
                    header_ids[ci] = el.id
                elif ci in header_ids:
                    el.relate(Rel.HEADER_FOR, header_ids[ci])

    try:
        for ii, rel in enumerate(d.part.rels.values(), 1):
            if "image" in rel.reltype:
                fig = doc.add(Element(
                    id=make_id("img", ii), type=ElementType.FIGURE,
                    content=str(rel.target_ref), basis=Basis.EXTRACTED,
                    source=Source(file=path.name, fmt="docx", sha256=doc.source.sha256,
                                  authority=doc.source.authority),
                    meta={"target": str(rel.target_ref)},
                ), parent=root.id)
                figures.append(fig)
    except Exception:
        doc.report.part("images", "relationship table unreadable")

    if captions and figures:
        for cap, fig in zip(captions, figures):
            cap.relate(Rel.CAPTION_FOR, fig.id)
            fig.meta["caption"] = cap.content
    doc.report.ok(f"{counter} paragraph(s), {len(d.tables)} table(s)")


_HEADING_RE = re.compile(r"^Heading\s+(\d+)", re.I)


def _heading_level(style: str) -> int | None:
    m = _HEADING_RE.match(style or "")
    if m:
        return int(m.group(1))
    if (style or "").strip().lower() == "title":
        return 1
    return None


def _current_section(doc: Document, parent_id: str) -> str | None:
    el = doc.get(parent_id)
    return el.content if el is not None and el.type is ElementType.SECTION else None


# ------------------------------------------------------------------------ pptx

def _build_pptx(path: Path, doc: Document, root: Element, deep: bool) -> None:
    pptx = _optional("pptx")
    if pptx is None:
        doc.report.unsup("pptx", "python-pptx not installed -- run: py -3 -m pip install python-pptx")
        return
    pres = pptx.Presentation(str(path))
    doc.pipeline.append("parse:python-pptx")
    doc.metadata["slide_count"] = len(pres.slides)
    for si, slide in enumerate(pres.slides, 1):
        src = Source(file=path.name, fmt="pptx", sha256=doc.source.sha256, slide=si,
                     authority=doc.source.authority)
        title = None
        try:
            if slide.shapes.title is not None:
                title = (slide.shapes.title.text or "").strip() or None
        except Exception:
            pass
        slide_el = doc.add(Element(
            id=make_id("slide", si), type=ElementType.SLIDE, content=title, source=src,
            meta={"slide": si, "layout": getattr(slide.slide_layout, "name", None)},
        ), parent=root.id)
        if not deep:
            continue
        for shi, shape in enumerate(slide.shapes):
            try:
                if shape.has_text_frame:
                    text = (shape.text_frame.text or "").strip()
                    if text:
                        doc.add(Element(
                            id=make_id("slide", si, "s", shi),
                            type=(ElementType.HEADING
                                  if text == title else ElementType.PARAGRAPH),
                            content=text, source=src, meta={"shape": shi},
                        ), parent=slide_el.id)
                elif shape.shape_type is not None and "PICTURE" in str(shape.shape_type):
                    doc.add(Element(
                        id=make_id("slide", si, "img", shi), type=ElementType.FIGURE,
                        source=src, meta={"shape": shi},
                    ), parent=slide_el.id)
            except Exception:
                continue
    doc.report.ok(f"{len(pres.slides)} slide(s)")


# --------------------------------------------------------------------- tabular

def _build_tabular(path: Path, doc: Document, root: Element, deep: bool) -> None:
    import csv as _csv
    delim = "\t" if path.suffix.lower() == ".tsv" else ","
    doc.pipeline.append("parse:csv")
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        rows = list(_csv.reader(fh, delimiter=delim))
    if not rows:
        doc.report.part("table", "file is empty")
        return
    table = doc.add(Element(
        id=make_id("table", path.stem), type=ElementType.TABLE,
        source=Source(file=path.name, fmt=doc.source.fmt, sha256=doc.source.sha256,
                      authority=doc.source.authority),
        basis=Basis.EXTRACTED,
        meta={"row_count": len(rows) - 1, "column_count": len(rows[0])},
    ), parent=root.id)
    header_ids: dict[int, str] = {}
    for ci, name in enumerate(rows[0]):
        el = doc.add(Element(
            id=make_id("col", path.stem, ci), type=ElementType.TABLE_HEADER,
            content=name.strip() or col_letter(ci + 1), basis=Basis.EXTRACTED,
            source=Source(file=path.name, fmt=doc.source.fmt, cell=f"R1C{ci + 1}",
                          sha256=doc.source.sha256, authority=doc.source.authority),
            meta={"column": ci},
        ), parent=table.id)
        header_ids[ci] = el.id
    if not deep:
        doc.report.part("rows", "outline mode -- rows omitted")
        return
    for ri, row in enumerate(rows[1:], start=2):
        row_el = doc.add(Element(
            id=make_id("row", path.stem, ri), type=ElementType.TABLE_ROW,
            content=row[0] if row else None, basis=Basis.EXTRACTED,
            source=Source(file=path.name, fmt=doc.source.fmt, cell=f"R{ri}",
                          sha256=doc.source.sha256, authority=doc.source.authority),
            meta={"row": ri},
        ), parent=table.id)
        for ci, val in enumerate(row):
            if not val.strip():
                continue
            cell = doc.add(Element(
                id=make_id("cell", path.stem, ri, ci), type=ElementType.TABLE_CELL,
                content=val.strip(), basis=Basis.EXTRACTED,
                source=Source(file=path.name, fmt=doc.source.fmt,
                              cell=f"R{ri}C{ci + 1}", sha256=doc.source.sha256,
                              authority=doc.source.authority),
                meta={"row": ri, "column": ci,
                      "header": rows[0][ci] if ci < len(rows[0]) else None},
            ), parent=row_el.id)
            if ci in header_ids:
                cell.relate(Rel.HEADER_FOR, header_ids[ci])
    doc.report.ok(f"{len(rows) - 1} data row(s)")


# ------------------------------------------------------------- text / markdown

_MD_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


def _build_markdown(path: Path, doc: Document, root: Element, deep: bool) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    doc.pipeline.append("parse:markdown")
    stack: list[tuple[int, str]] = [(0, root.id)]
    buf: list[str] = []
    counter = 0

    def flush(parent_id: str) -> None:
        nonlocal buf, counter
        body = "\n".join(buf).strip()
        buf = []
        if not body:
            return
        counter += 1
        doc.add(Element(
            id=make_id("p", counter), type=ElementType.PARAGRAPH, content=body,
            source=Source(file=path.name, fmt="markdown", sha256=doc.source.sha256,
                          authority=doc.source.authority),
        ), parent=parent_id)

    for line in text.splitlines():
        m = _MD_HEADING.match(line)
        if m:
            flush(stack[-1][1])
            level = len(m.group(1))
            while len(stack) > 1 and stack[-1][0] >= level:
                stack.pop()
            counter += 1
            section = doc.add(Element(
                id=make_id("sec", counter), type=ElementType.SECTION,
                content=m.group(2).strip(), basis=Basis.EXTRACTED,
                source=Source(file=path.name, fmt="markdown", sha256=doc.source.sha256,
                              authority=doc.source.authority),
                meta={"level": level},
            ), parent=stack[-1][1])
            stack.append((level, section.id))
        else:
            buf.append(line)
    flush(stack[-1][1])
    doc.report.ok(f"{counter} block(s)")


def _build_text(path: Path, doc: Document, root: Element, deep: bool) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    doc.pipeline.append("parse:text")
    doc.metadata["line_count"] = text.count("\n") + 1
    doc.metadata["char_count"] = len(text)
    chunks = [c for c in re.split(r"\n\s*\n", text) if c.strip()] if deep else [text[:2000]]
    for i, chunk in enumerate(chunks[:5000], 1):
        doc.add(Element(
            id=make_id("blk", i), type=ElementType.PARAGRAPH, content=chunk.strip(),
            source=Source(file=path.name, fmt=doc.source.fmt, sha256=doc.source.sha256,
                          authority=doc.source.authority),
            meta={"block": i},
        ), parent=root.id)
    doc.report.ok(f"{len(chunks)} block(s)")


def _build_html(path: Path, doc: Document, root: Element, deep: bool) -> None:
    """`deep` is honoured by the text fallback; the DOM walk is cheap either way."""
    bs4 = _optional("bs4")
    raw = path.read_text(encoding="utf-8", errors="replace")
    if bs4 is None:
        doc.report.part("html", "beautifulsoup4 not installed -- falling back to raw text")
        _build_text(path, doc, root, deep)
        return
    soup = bs4.BeautifulSoup(raw, "html.parser")
    doc.pipeline.append("parse:beautifulsoup")
    if soup.title and soup.title.string:
        doc.metadata["title"] = soup.title.string.strip()
    stack: list[tuple[int, str]] = [(0, root.id)]
    counter = 0
    for node in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6", "p", "li",
                               "table", "figcaption", "img"]):
        name = node.name
        counter += 1
        src = Source(file=path.name, fmt="html", sha256=doc.source.sha256,
                     authority=doc.source.authority)
        if name and name[0] == "h" and len(name) == 2 and name[1].isdigit():
            level = int(name[1])
            while len(stack) > 1 and stack[-1][0] >= level:
                stack.pop()
            section = doc.add(Element(
                id=make_id("sec", counter), type=ElementType.SECTION,
                content=node.get_text(" ", strip=True), source=src,
                meta={"level": level},
            ), parent=stack[-1][1])
            stack.append((level, section.id))
            continue
        if name == "img":
            doc.add(Element(
                id=make_id("img", counter), type=ElementType.FIGURE,
                content=node.get("alt") or None, source=src,
                meta={"src": node.get("src"), "alt": node.get("alt")},
            ), parent=stack[-1][1])
            continue
        text = node.get_text(" ", strip=True)
        if not text:
            continue
        etype = {"li": ElementType.LIST_ITEM, "table": ElementType.TABLE,
                 "figcaption": ElementType.CAPTION}.get(name, ElementType.PARAGRAPH)
        doc.add(Element(id=make_id("el", counter), type=etype, content=text, source=src,
                        meta={"tag": name}), parent=stack[-1][1])
    doc.report.ok(f"{counter} node(s)")


# ---------------------------------------------------------------------- images

IMAGE_CLASSES = ("decorative", "logo", "signature", "screenshot", "chart", "diagram",
                 "technical_drawing", "photo", "scanned_document", "table_image")


def _build_image(path: Path, doc: Document, root: Element, deep: bool, ocr: bool) -> None:
    PIL = _optional("PIL.Image")
    if PIL is None:
        doc.report.part("image", "Pillow not installed -- metadata only")
        doc.add(Element(id=make_id("img", path.stem), type=ElementType.FIGURE,
                        content=path.name, source=doc.source), parent=root.id)
        return
    with PIL.open(path) as im:
        w, h = im.size
        mode, fmt = im.mode, im.format
        exif = {}
        try:
            raw_exif = im.getexif()
            exif = {str(k): str(v)[:120] for k, v in dict(raw_exif).items()}
        except Exception:
            pass
        cls, conf, why = _classify_image(im)
    assert cls in IMAGE_CLASSES, f"unknown image class {cls!r}"

    doc.pipeline.append("parse:pillow")
    fig = doc.add(Element(
        id=make_id("img", path.stem), type=ElementType.FIGURE, content=path.name,
        source=doc.source, basis=Basis.EXTRACTED,
        meta={"width": w, "height": h, "mode": mode, "format": fmt,
              "aspect_ratio": round(w / h, 3) if h else None,
              **({"exif": exif} if exif else {})},
    ), parent=root.id)
    fig.meta["image_class"] = cls
    fig.meta["image_class_basis"] = Basis.INFERRED.value
    fig.meta["image_class_confidence"] = round(conf, 2)
    fig.meta["image_class_rationale"] = why

    doc.report.ok(f"image {w}x{h} {fmt}")
    doc.report.unsup(
        "visual description",
        "no vision model is invoked by this tool; an agent that can see images should read "
        "the file directly and record its description as MODEL_GENERATED")
    if ocr:
        _try_ocr(path, doc, fig)
    else:
        doc.report.unsup(
            "OCR", "not requested; pass --ocr to read embedded text (requires rapidocr)")


def _classify_image(im: Any) -> tuple[str, float, str]:
    """Cheap triage so a decorative rule never costs a vision-model call.

    Colour count and aspect ratio only. This is `INFERRED` with a stated confidence, and
    the rationale is recorded so a wrong call is debuggable rather than mysterious.
    """
    w, h = im.size
    if w <= 4 or h <= 4:
        return "decorative", 0.95, "degenerate dimensions (rule or spacer)"
    ratio = w / h if h else 0
    if ratio > 12 or ratio < 1 / 12:
        return "decorative", 0.8, f"extreme aspect ratio {ratio:.1f}"
    try:
        small = im.convert("RGB").resize((64, 64))
        colours = small.getcolors(4096)
        n = len(colours) if colours else 4096
    except Exception:
        return "photo", 0.3, "colour histogram unavailable"
    if w * h < 40_000 and n < 64:
        return "logo", 0.6, f"small ({w}x{h}) with {n} distinct colours"
    if n < 32:
        return "diagram", 0.6, f"flat colour palette ({n} colours)"
    if n < 400:
        return "chart", 0.4, (f"limited palette ({n} colours) -- could equally be a diagram "
                              f"or a screenshot; needs a vision model to settle")
    if ratio > 1.2 and n > 2000 and w >= 1000:
        return "screenshot", 0.35, f"wide ({w}x{h}) and colour-rich ({n} colours)"
    return "photo", 0.5, f"colour-rich ({n} colours)"


def _try_ocr(path: Path, doc: Document, fig: Element) -> None:
    rapidocr = _optional("rapidocr")
    if rapidocr is None:
        doc.report.unsup(
            "OCR",
            "rapidocr not installed -- run: py -3 -m pip install rapidocr onnxruntime "
            "(pure wheels, no system binary; downloads ONNX models on first use)")
        return
    try:
        engine = rapidocr.RapidOCR()
        result = engine(str(path))
    except Exception as exc:
        doc.report.fail("OCR", f"{type(exc).__name__}: {exc}"[:200])
        return
    boxes = getattr(result, "boxes", None)
    txts = getattr(result, "txts", None)
    scores = getattr(result, "scores", None)
    if txts is None:
        doc.report.part("OCR", "engine returned no text")
        return
    doc.pipeline.append("ocr:rapidocr")
    for i, txt in enumerate(txts):
        score = float(scores[i]) if scores is not None and i < len(scores) else 0.5
        bbox = None
        if boxes is not None and i < len(boxes):
            try:
                pts = boxes[i]
                xs = [float(p[0]) for p in pts]
                ys = [float(p[1]) for p in pts]
                bbox = (min(xs), min(ys), max(xs), max(ys))
            except Exception:
                bbox = None
        el = doc.add(Element(
            id=make_id("ocr", path.stem, i), type=ElementType.PARAGRAPH,
            content=str(txt), basis=Basis.MODEL_GENERATED, confidence=score,
            source=Source(file=path.name, fmt=doc.source.fmt, sha256=doc.source.sha256,
                          bbox=bbox, authority=doc.source.authority),
            meta={"engine": "rapidocr", "index": i},
        ), parent=fig.id)
        el.relate(Rel.DERIVED_FROM, fig.id, method="ocr")
    doc.report.ok(f"OCR: {len(txts)} text region(s)")


# --------------------------------------------------------------------- docling

def _build_via_docling(path: Path, doc: Document, root: Element, fmt: str) -> None:
    """Delegate long-tail formats to docling, then map its document into our IR.

    We map rather than adopt `DoclingDocument` wholesale: our consumers rely on typed
    relationships, an authority classification and a `Basis` on every element, none of
    which docling has. Mapping keeps one representation across all formats.
    """
    converter_mod = _optional("docling.document_converter")
    if converter_mod is None:
        extra = DOCLING_FORMATS.get(fmt, "format-office")
        doc.report.unsup(
            fmt,
            f"docling not installed -- run: py -3 -m pip install "
            f"\"docling-slim[{extra}]\" (MIT; no torch, no model download)")
        return
    try:
        converter = converter_mod.DocumentConverter()
        result = converter.convert(str(path))
        dl = result.document
    except Exception as exc:
        doc.report.fail(fmt, f"docling conversion failed: {type(exc).__name__}: {exc}"[:250])
        return

    doc.pipeline.append("parse:docling")
    doc.metadata["docling"] = True
    try:
        doc.metadata["title"] = getattr(dl, "name", None) or path.stem
    except Exception:
        pass

    stack: list[tuple[int, str]] = [(0, root.id)]
    counter = 0
    try:
        items = list(dl.iterate_items())
    except Exception:
        items = []

    for entry in items:
        item = entry[0] if isinstance(entry, tuple) else entry
        label = str(getattr(item, "label", "") or "").lower()
        text = (getattr(item, "text", "") or "").strip()
        counter += 1
        page = None
        try:
            prov = getattr(item, "prov", None)
            if prov:
                page = getattr(prov[0], "page_no", None)
        except Exception:
            page = None
        src = Source(file=path.name, fmt=fmt, sha256=doc.source.sha256, page=page,
                     authority=doc.source.authority)

        if "title" in label or "header" in label or "heading" in label:
            level = 1 if "title" in label else 2
            while len(stack) > 1 and stack[-1][0] >= level:
                stack.pop()
            section = doc.add(Element(
                id=make_id("sec", counter), type=ElementType.SECTION, content=text,
                source=src, meta={"level": level, "docling_label": label},
            ), parent=stack[-1][1])
            stack.append((level, section.id))
            continue

        etype = ElementType.PARAGRAPH
        if "table" in label:
            etype = ElementType.TABLE
        elif "picture" in label or "figure" in label:
            etype = ElementType.FIGURE
        elif "caption" in label:
            etype = ElementType.CAPTION
        elif "list" in label:
            etype = ElementType.LIST_ITEM
        elif "code" in label:
            etype = ElementType.CODE
        elif "footnote" in label:
            etype = ElementType.FOOTNOTE
        if not text and etype is ElementType.PARAGRAPH:
            continue
        doc.add(Element(
            id=make_id("dl", counter), type=etype, content=text or None, source=src,
            meta={"docling_label": label},
        ), parent=stack[-1][1])

    doc.report.ok(f"docling: {counter} item(s)")
    if counter == 0:
        doc.report.part(fmt, "docling returned no items")
