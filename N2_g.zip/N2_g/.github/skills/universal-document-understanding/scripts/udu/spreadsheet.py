"""Spreadsheet structural and semantic understanding.

A worksheet is not a table. It is a canvas that usually holds several tables, separated by
blank rows, introduced by merged titles, and topped by headers that are two or three rows
deep. Treating it as a rectangle of cells throws away most of what a human reads off it.

What this module derives, and what each derivation is worth trusting:

| Output                     | Basis      | How |
|----------------------------|------------|-----|
| merged ranges, spans       | EXTRACTED  | openpyxl |
| formulas, cached values    | EXTRACTED  | dual `data_only` load |
| discrete regions in sheet  | INFERRED   | connected components over occupied cells |
| title / header / data / total row roles | INFERRED | position, arity and lexical cues |
| hierarchical header paths  | INFERRED   | merged spans projected down the header band |
| column semantic type, unit | INFERRED   | number format first, values second |
| formula dependencies       | EXTRACTED  | reference parse of the formula text |

Everything in the INFERRED rows is a structural guess with a confidence, never a fact. No
cell value is ever invented: if a header cannot be resolved, the column keeps its letter.

Two algorithms are reimplemented (not copied) from Unstructured (Apache-2.0),
`unstructured/partition/xlsx.py`:
  * connected-component sub-table detection (`:282-335`) -- here without networkx.
  * leading/trailing single-cell row classification (`:401-441`).
The merged-cell anchor/shadow model follows Docling's design (MIT),
`docling/backend/msexcel_backend.py:154-212`; no code is taken from it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable

MAX_HEADER_ROWS = 4
MAX_REGION_SCAN_CELLS = 400_000     # above this, regions are not derived (reported)


class RowRole(str, Enum):
    TITLE = "title"
    HEADER = "header"
    DATA = "data"
    SUBTOTAL = "subtotal"
    TOTAL = "total"
    NOTE = "note"
    SEPARATOR = "separator"


class ColumnType(str, Enum):
    CURRENCY_MEASURE = "currency_measure"
    PERCENTAGE = "percentage"
    DATE = "date"
    NUMERIC_MEASURE = "numeric_measure"
    IDENTIFIER = "identifier"
    CATEGORICAL = "categorical"
    TEXT = "text"
    EMPTY = "empty"
    MIXED = "mixed"


# ------------------------------------------------------------------- cell model

@dataclass
class CellData:
    row: int
    col: int
    value: Any = None
    formula: str | None = None
    cached: Any = None
    number_format: str | None = None
    merged_anchor_for: str | None = None
    covered_by: str | None = None
    span: tuple[int, int] = (1, 1)          # (row_span, col_span)
    hyperlink: str | None = None
    comment: str | None = None

    @property
    def is_empty(self) -> bool:
        return self.value is None and self.formula is None

    @property
    def display(self) -> Any:
        """What a human sees: the cached result of a formula, else the raw value."""
        return self.cached if self.formula is not None else self.value

    @property
    def text(self) -> str:
        d = self.display
        return "" if d is None else str(d).strip()


@dataclass
class SheetGrid:
    """Occupied cells of one worksheet, indexed by (row, col). 1-based, like Excel."""

    name: str
    cells: dict[tuple[int, int], CellData] = field(default_factory=dict)
    merged: list[str] = field(default_factory=list)
    max_row: int = 0
    max_col: int = 0
    state: str = "visible"
    hidden_rows: set[int] = field(default_factory=set)
    hidden_cols: set[int] = field(default_factory=set)
    defined_names: dict[str, str] = field(default_factory=dict)
    charts: list[dict[str, Any]] = field(default_factory=list)
    truncated: bool = False

    def at(self, row: int, col: int) -> CellData | None:
        return self.cells.get((row, col))

    def occupied(self) -> set[tuple[int, int]]:
        """Anchors and their shadow cells both count as occupied.

        A merged title spanning A1:D1 must keep A..D connected, otherwise the region
        splitter would cut a table in half under its own heading.
        """
        occ = {rc for rc, c in self.cells.items() if not c.is_empty}
        for rng in self.merged:
            bounds = parse_range(rng)
            if bounds is None:
                continue
            r1, c1, r2, c2 = bounds
            anchor = self.cells.get((r1, c1))
            if anchor is not None and not anchor.is_empty:
                for r in range(r1, r2 + 1):
                    for c in range(c1, c2 + 1):
                        occ.add((r, c))
        return occ


# --------------------------------------------------------------- range helpers

_RANGE_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+):\$?([A-Za-z]{1,3})\$?(\d+)$")
_SINGLE_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)$")


def col_letter(col: int) -> str:
    out = ""
    while col > 0:
        col, rem = divmod(col - 1, 26)
        out = chr(65 + rem) + out
    return out


def col_index(letters: str) -> int:
    n = 0
    for ch in letters.upper():
        n = n * 26 + (ord(ch) - 64)
    return n


def parse_range(rng: str) -> tuple[int, int, int, int] | None:
    """`B2:D7` -> (row1, col1, row2, col2). Returns None for anything unbounded."""
    m = _RANGE_RE.match(rng.strip())
    if m:
        c1, r1, c2, r2 = m.group(1), int(m.group(2)), m.group(3), int(m.group(4))
        return (r1, col_index(c1), r2, col_index(c2))
    m = _SINGLE_RE.match(rng.strip())
    if m:
        r, c = int(m.group(2)), col_index(m.group(1))
        return (r, c, r, c)
    return None


def range_str(r1: int, c1: int, r2: int, c2: int) -> str:
    return f"{col_letter(c1)}{r1}:{col_letter(c2)}{r2}"


# ---------------------------------------------------- region (sub-table) detection

@dataclass
class Region:
    """One discrete data block inside a sheet."""

    r1: int
    c1: int
    r2: int
    c2: int
    row_roles: dict[int, RowRole] = field(default_factory=dict)
    title: str | None = None
    title_cell: str | None = None
    header_rows: list[int] = field(default_factory=list)
    header_paths: dict[int, list[str]] = field(default_factory=dict)   # col -> path
    column_types: dict[int, ColumnType] = field(default_factory=dict)
    column_units: dict[int, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    @property
    def ref(self) -> str:
        return range_str(self.r1, self.c1, self.r2, self.c2)

    @property
    def data_rows(self) -> list[int]:
        return [r for r in range(self.r1, self.r2 + 1)
                if self.row_roles.get(r) in (RowRole.DATA, RowRole.SUBTOTAL, RowRole.TOTAL)]


def find_regions(grid: SheetGrid, *, max_cells: int = MAX_REGION_SCAN_CELLS
                 ) -> tuple[list[Region], str | None]:
    """Connected components of occupied cells -> discrete tables.

    Reimplements Unstructured's grid-graph approach (`partition/xlsx.py:282-335`) with an
    explicit BFS instead of `networkx.grid_2d_graph`, which avoids pulling networkx in and
    avoids materialising a node per empty cell on a sparse 7,000-row sheet.

    Adjacency is 8-way, not 4-way: a single blank spacer column inside a table would
    otherwise split it, and diagonal contact is the cheapest way to keep a header row
    attached to data that starts one column in. Returns (regions, warning).
    """
    occ = grid.occupied()
    if not occ:
        return [], None
    if len(occ) > max_cells:
        return [], (f"{len(occ)} occupied cells exceeds the {max_cells} region-scan cap; "
                    f"whole sheet treated as one region")

    seen: set[tuple[int, int]] = set()
    regions: list[Region] = []
    neighbours = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    for start in sorted(occ):
        if start in seen:
            continue
        stack = [start]
        seen.add(start)
        comp: list[tuple[int, int]] = []
        while stack:
            r, c = stack.pop()
            comp.append((r, c))
            for dr, dc in neighbours:
                nxt = (r + dr, c + dc)
                if nxt in occ and nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        rows = [p[0] for p in comp]
        cols = [p[1] for p in comp]
        regions.append(Region(min(rows), min(cols), max(rows), max(cols)))

    regions = _merge_overlapping(regions)
    regions.sort(key=lambda x: (x.r1, x.c1))
    return regions, None


def _merge_overlapping(regions: list[Region]) -> list[Region]:
    """Two components whose bounding boxes overlap are one table with a hole in it."""
    changed = True
    while changed and len(regions) > 1:
        changed = False
        out: list[Region] = []
        for reg in sorted(regions, key=lambda x: (x.r1, x.c1)):
            merged_into = False
            for other in out:
                if not (reg.r2 < other.r1 or reg.r1 > other.r2
                        or reg.c2 < other.c1 or reg.c1 > other.c2):
                    other.r1, other.c1 = min(other.r1, reg.r1), min(other.c1, reg.c1)
                    other.r2, other.c2 = max(other.r2, reg.r2), max(other.c2, reg.c2)
                    merged_into = True
                    changed = True
                    break
            if not merged_into:
                out.append(reg)
        regions = out
    return regions


# --------------------------------------------------------------- row classification

_TOTAL_RE = re.compile(r"^\s*(grand\s+total|total|sum|overall)\b", re.I)
_SUBTOTAL_RE = re.compile(r"^\s*(sub-?total|subtotal)\b", re.I)
_NOTE_RE = re.compile(r"^\s*(note|notes|source|sources|footnote|\*|\(\d+\))", re.I)


def classify_rows(grid: SheetGrid, region: Region) -> None:
    """Assign a role to every row of the region, in place.

    Order matters. Titles and headers are decided from the top down because that is where
    they can only be; totals and notes from the bottom up for the same reason. Everything
    left over is data, which is the safe default -- misreading data as a total would drop
    it from aggregation, while the reverse merely adds a row.
    """
    populated: dict[int, list[CellData]] = {}
    for r in range(region.r1, region.r2 + 1):
        row_cells = [grid.at(r, c) for c in range(region.c1, region.c2 + 1)]
        populated[r] = [c for c in row_cells if c is not None and not c.is_empty]

    # --- leading single-cell rows are titles (Unstructured :401-441) ---------
    r = region.r1
    while r <= region.r2:
        cells = populated[r]
        if len(cells) == 1 and _looks_textual(cells[0]):
            region.row_roles[r] = RowRole.TITLE
            if region.title is None:
                region.title = cells[0].text
                region.title_cell = f"{col_letter(cells[0].col)}{cells[0].row}"
            r += 1
        elif len(cells) == 0:
            region.row_roles[r] = RowRole.SEPARATOR
            r += 1
        else:
            break
    first_body = r

    # --- trailing single-cell rows are notes ---------------------------------
    r = region.r2
    while r >= first_body:
        cells = populated[r]
        if len(cells) == 0:
            region.row_roles[r] = RowRole.SEPARATOR
            r -= 1
        elif len(cells) == 1 and _looks_textual(cells[0]) and _NOTE_RE.match(cells[0].text):
            region.row_roles[r] = RowRole.NOTE
            region.notes.append(cells[0].text)
            r -= 1
        else:
            break
    last_body = r

    # --- header band ---------------------------------------------------------
    # "No numeric values" is the obvious rule and it is wrong: period headers are
    # numeric. A band of `2025 | 2026` over `Q1 | Q2 | Q1 | Q2` is the textbook
    # hierarchical header, and a naive numeric test cuts it off after the first row --
    # which then collapses four distinct columns onto one ambiguous label.
    #
    # So a row stays in the header band when every numeric it holds is period-like
    # (a year, a quarter, a month, a fiscal label), or when it carries a horizontal
    # merge, which is authorial intent that the row spans columns.
    header_rows: list[int] = []
    for rr in range(first_body, min(first_body + MAX_HEADER_ROWS, last_body + 1)):
        cells = populated.get(rr, [])
        if not cells:
            break
        has_hmerge = _row_has_horizontal_merge(grid, rr, region)
        hard_numeric = [c for c in cells
                        if _is_numeric(c.display) and not _is_period_label(c.display)]
        if hard_numeric and not has_hmerge:
            break
        header_rows.append(rr)
    # A header band that would swallow the whole region is not a header band.
    if header_rows and header_rows[-1] >= last_body:
        header_rows = header_rows[:1] if last_body > first_body else []
    region.header_rows = header_rows
    for rr in header_rows:
        region.row_roles[rr] = RowRole.HEADER

    # --- remaining rows: data, unless lexically a total ----------------------
    for rr in range(first_body + len(header_rows), last_body + 1):
        if rr in region.row_roles:
            continue
        cells = populated.get(rr, [])
        if not cells:
            region.row_roles[rr] = RowRole.SEPARATOR
            continue
        label = cells[0].text if cells else ""
        if _SUBTOTAL_RE.match(label):
            region.row_roles[rr] = RowRole.SUBTOTAL
        elif _TOTAL_RE.match(label):
            region.row_roles[rr] = RowRole.TOTAL
        else:
            region.row_roles[rr] = RowRole.DATA

    for rr in range(region.r1, region.r2 + 1):
        region.row_roles.setdefault(rr, RowRole.DATA)


_QUARTER_RE = re.compile(r"^(?:q[1-4]|h[12]|fy\s*\d{2,4}|[1-4]q)$", re.I)
_MONTHS = {"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
           "dec", "january", "february", "march", "april", "june", "july", "august",
           "september", "october", "november", "december"}


def _is_period_label(v: Any) -> bool:
    """A year, quarter, half, month or fiscal tag -- numeric-looking, but a header."""
    if v is None:
        return False
    if isinstance(v, bool):
        return False
    s = str(v).strip()
    if not s:
        return False
    if _QUARTER_RE.match(s) or s.lower().rstrip(".") in _MONTHS:
        return True
    try:
        n = float(s)
    except ValueError:
        return False
    return n.is_integer() and 1900 <= n <= 2999


def _row_has_horizontal_merge(grid: SheetGrid, row: int, region: Region) -> bool:
    for rng in grid.merged:
        bounds = parse_range(rng)
        if bounds is None:
            continue
        r1, c1, r2, c2 = bounds
        if r1 <= row <= r2 and c2 > c1 and not (c2 < region.c1 or c1 > region.c2):
            return True
    return False


def _looks_textual(cell: CellData) -> bool:
    return bool(cell.text) and not _is_numeric(cell.display)


def _is_numeric(v: Any) -> bool:
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return True
    if isinstance(v, str):
        s = v.strip().replace(",", "").replace("%", "")
        if not s:
            return False
        try:
            float(s)
            return True
        except ValueError:
            return False
    return False


# ------------------------------------------------------- hierarchical headers

def resolve_header_paths(grid: SheetGrid, region: Region) -> None:
    """Project merged spans down the header band to build a path per column.

    A merged `Revenue` over `2025 | 2026` over `Q1 | Q2 | Q1 | Q2` yields
    `["Revenue", "2025", "Q1"]` for the first data column. This is the difference between
    a column called `Q1` -- ambiguous, there are two of them -- and one called
    `Revenue > 2025 > Q1`, which is answerable.

    Columns whose header cannot be resolved keep their spreadsheet letter. We never invent
    a name.
    """
    if not region.header_rows:
        for c in range(region.c1, region.c2 + 1):
            region.header_paths[c] = [col_letter(c)]
        return

    # Expand merged anchors across their span so shadow columns inherit the label.
    span_label: dict[tuple[int, int], str] = {}
    for rng in grid.merged:
        bounds = parse_range(rng)
        if bounds is None:
            continue
        r1, c1, r2, c2 = bounds
        if r1 not in region.header_rows and r2 not in region.header_rows:
            continue
        anchor = grid.at(r1, c1)
        if anchor is None or not anchor.text:
            continue
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                span_label[(r, c)] = anchor.text

    for c in range(region.c1, region.c2 + 1):
        path: list[str] = []
        for r in region.header_rows:
            label = span_label.get((r, c))
            if label is None:
                cell = grid.at(r, c)
                label = cell.text if cell is not None else ""
            label = label.strip()
            if label and (not path or path[-1] != label):
                path.append(label)
        region.header_paths[c] = path or [col_letter(c)]


# ----------------------------------------------------- column semantics + units

_UNIT_RE = re.compile(r"[\(\[]\s*([^)\]]{1,24})\s*[\)\]]\s*$")
_CURRENCY_CHARS = "$€£¥₹"
_DATE_FMT_RE = re.compile(r"(yy|mm|dd|hh|:ss)", re.I)


def infer_column_semantics(grid: SheetGrid, region: Region) -> None:
    """Number format first (it is authorial intent), values second (it is evidence)."""
    data_rows = [r for r in region.data_rows
                 if region.row_roles.get(r) == RowRole.DATA]

    for c in range(region.c1, region.c2 + 1):
        # Unit from the header text, e.g. "Revenue (USD millions)" -> "USD millions".
        for label in reversed(region.header_paths.get(c, [])):
            m = _UNIT_RE.search(label)
            if m:
                region.column_units[c] = m.group(1).strip()
                break

        cells = [grid.at(r, c) for r in data_rows]
        vals = [x for x in cells if x is not None and not x.is_empty]
        if not vals:
            region.column_types[c] = ColumnType.EMPTY
            continue

        fmts = [v.number_format or "" for v in vals]
        joined = " ".join(fmts)
        if any(ch in joined for ch in _CURRENCY_CHARS) or "[$" in joined:
            region.column_types[c] = ColumnType.CURRENCY_MEASURE
            if c not in region.column_units:
                cur = next((ch for ch in _CURRENCY_CHARS if ch in joined), None)
                if cur:
                    region.column_units[c] = cur
            continue
        if "%" in joined:
            region.column_types[c] = ColumnType.PERCENTAGE
            continue
        if any(_DATE_FMT_RE.search(f) for f in fmts):
            region.column_types[c] = ColumnType.DATE
            continue

        import datetime as _dt
        if all(isinstance(v.display, (_dt.date, _dt.datetime)) for v in vals):
            region.column_types[c] = ColumnType.DATE
            continue

        numeric = sum(1 for v in vals if _is_numeric(v.display))
        if numeric == len(vals):
            region.column_types[c] = ColumnType.NUMERIC_MEASURE
            continue
        if numeric == 0:
            texts = [v.text for v in vals]
            distinct = len(set(texts))
            if distinct == len(texts) and len(texts) > 3:
                region.column_types[c] = ColumnType.IDENTIFIER
            elif distinct <= max(2, len(texts) // 2):
                region.column_types[c] = ColumnType.CATEGORICAL
            else:
                region.column_types[c] = ColumnType.TEXT
            continue
        region.column_types[c] = ColumnType.MIXED


# ------------------------------------------------------------ formula analysis

_REF_RE = re.compile(
    r"(?:(?:'([^']+)'|([A-Za-z_][A-Za-z0-9_.]*))!)?"      # optional sheet qualifier
    r"(\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?)"
)
_FUNC_RE = re.compile(r"\b([A-Z][A-Z0-9._]{1,30})\s*\(")


def formula_dependencies(formula: str, default_sheet: str) -> list[str]:
    """Cell and range references a formula reads, as `Sheet!Range` strings.

    Deliberately lexical. A full Excel expression parser is a large piece of work whose
    failure mode here is silent, and dependency edges are an aid to comprehension rather
    than a calculation engine -- so a reference that is missed shows up as a missing edge,
    never as a wrong number.
    """
    if not formula:
        return []
    body = formula[1:] if formula.startswith("=") else formula
    # Drop string literals so "A1" inside text is not read as a reference.
    body = re.sub(r'"[^"]*"', '""', body)
    out: list[str] = []
    for m in _REF_RE.finditer(body):
        sheet = m.group(1) or m.group(2) or default_sheet
        ref = m.group(3).replace("$", "")
        token = f"{sheet}!{ref}"
        if token not in out:
            out.append(token)
    return out


def formula_functions(formula: str) -> list[str]:
    if not formula:
        return []
    body = re.sub(r'"[^"]*"', '""', formula)
    return sorted({m.group(1) for m in _FUNC_RE.finditer(body)})


def expand_ref(ref: str) -> list[str]:
    """`Sheet!B3:B5` -> ['Sheet!B3', 'Sheet!B4', 'Sheet!B5']. Capped, and never guesses."""
    if "!" not in ref:
        return [ref]
    sheet, rng = ref.split("!", 1)
    bounds = parse_range(rng)
    if bounds is None:
        return [ref]
    r1, c1, r2, c2 = bounds
    if (r2 - r1 + 1) * (c2 - c1 + 1) > 2000:
        return [ref]
    return [f"{sheet}!{col_letter(c)}{r}"
            for r in range(r1, r2 + 1) for c in range(c1, c2 + 1)]


# --------------------------------------------------------------------- analysis

def analyse_sheet(grid: SheetGrid) -> tuple[list[Region], list[str]]:
    """Full semantic pass over one sheet. Returns (regions, warnings)."""
    warnings: list[str] = []
    regions, warn = find_regions(grid)
    if warn:
        warnings.append(f"{grid.name}: {warn}")
        if grid.max_row and grid.max_col:
            regions = [Region(1, 1, grid.max_row, grid.max_col)]
    for region in regions:
        classify_rows(grid, region)
        resolve_header_paths(grid, region)
        infer_column_semantics(grid, region)
    return regions, warnings


def header_label(region: Region, col: int, sep: str = " > ") -> str:
    return sep.join(region.header_paths.get(col, [col_letter(col)]))


def iter_data_cells(grid: SheetGrid, region: Region) -> Iterable[CellData]:
    for r in region.data_rows:
        for c in range(region.c1, region.c2 + 1):
            cell = grid.at(r, c)
            if cell is not None and not cell.is_empty:
                yield cell
