"""Semantic chunking for retrieval.

Fixed-size splitting is what makes RAG answer confidently and wrongly: it cuts a table off
from its header, a number off from its unit, and a sentence off from the section that gave
it meaning. "Revenue increased by 20%" retrieved alone is unanswerable — 20% of what, when,
in which region.

So chunks are cut on **structural** boundaries (section, table, region, figure) and every
chunk carries a rendered **context header** naming the document, the section path, the units
and the provenance. The header is part of the embedded text, not just metadata, because the
retriever scores the text.

Token budgeting uses a characters-per-token estimate rather than a tokenizer. A tokenizer
would mean a model dependency for a job where being 15% out costs nothing — chunks are
bounded, not exact.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any

from .model import Basis, Document, Element, ElementType

CHARS_PER_TOKEN = 4          # conservative for English + code + numbers
DEFAULT_MAX_TOKENS = 900
MIN_MERGE_TOKENS = 120       # below this a chunk is merged with its neighbour


@dataclass
class Chunk:
    id: str
    text: str
    context_header: str
    element_ids: list[str] = field(default_factory=list)
    source: dict[str, Any] = field(default_factory=dict)
    section_path: list[str] = field(default_factory=list)
    kind: str = "narrative"
    tokens_estimate: int = 0
    contains_instruction_shaped_text: bool = False
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "kind": self.kind,
            "text": self.text,
            "context_header": self.context_header,
            "section_path": self.section_path,
            "element_ids": self.element_ids,
            "source": self.source,
            "tokens_estimate": self.tokens_estimate,
            "contains_instruction_shaped_text": self.contains_instruction_shaped_text,
            **({"metadata": self.meta} if self.meta else {}),
        }


def estimate_tokens(text: str) -> int:
    return max(1, len(text) // CHARS_PER_TOKEN)


def chunk_document(doc: Document, *, max_tokens: int = DEFAULT_MAX_TOKENS) -> list[Chunk]:
    """Structural chunking. Tables and figures are atomic; narrative packs by section."""
    chunks: list[Chunk] = []
    doc_title = str(doc.metadata.get("title") or doc.source.file)

    for table in doc.by_type(ElementType.TABLE):
        chunks.extend(_chunk_table(doc, table, doc_title, max_tokens))
    for fig in doc.by_type(ElementType.FIGURE):
        c = _chunk_figure(doc, fig, doc_title)
        if c is not None:
            chunks.append(c)
    chunks.extend(_chunk_narrative(doc, doc_title, max_tokens))

    for i, c in enumerate(chunks):
        c.meta["ordinal"] = i
        c.meta["total_chunks"] = len(chunks)
    return chunks


# ------------------------------------------------------------------- narrative

def _chunk_narrative(doc: Document, doc_title: str, max_tokens: int) -> list[Chunk]:
    keep = {ElementType.PARAGRAPH, ElementType.HEADING, ElementType.LIST_ITEM,
            ElementType.CAPTION, ElementType.FOOTNOTE, ElementType.CODE,
            ElementType.NOTE}
    buckets: dict[str, list[Element]] = {}
    order: list[str] = []
    for el in doc.walk():
        if el.type not in keep or not el.content:
            continue
        section = doc.section_of(el.id)
        key = section.id if section is not None else "__root__"
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(el)

    out: list[Chunk] = []
    for key in order:
        elements = buckets[key]
        section = doc.get(key) if key != "__root__" else None
        path = _section_path(doc, section)
        header = _context_header(doc_title, path, doc, elements[0])
        budget = max_tokens - estimate_tokens(header)
        buf: list[Element] = []
        buf_tokens = 0
        for el in elements:
            t = estimate_tokens(el.content or "")
            if buf and buf_tokens + t > budget:
                out.append(_make_chunk(doc, buf, header, path, "narrative"))
                buf, buf_tokens = [], 0
            buf.append(el)
            buf_tokens += t
        if buf:
            out.append(_make_chunk(doc, buf, header, path, "narrative"))

    return _merge_tiny(out, max_tokens)


def _merge_tiny(chunks: list[Chunk], max_tokens: int) -> list[Chunk]:
    """A two-line chunk retrieves badly. Fold it forward when the section allows."""
    out: list[Chunk] = []
    for c in chunks:
        if (out and c.tokens_estimate < MIN_MERGE_TOKENS
                and out[-1].section_path == c.section_path
                and out[-1].tokens_estimate + c.tokens_estimate <= max_tokens):
            prev = out[-1]
            prev.text = prev.text + "\n\n" + _strip_header(c.text, c.context_header)
            prev.element_ids.extend(c.element_ids)
            prev.tokens_estimate = estimate_tokens(prev.text)
            prev.contains_instruction_shaped_text |= c.contains_instruction_shaped_text
            continue
        out.append(c)
    return out


def _strip_header(text: str, header: str) -> str:
    return text[len(header):].lstrip("\n") if text.startswith(header) else text


def _make_chunk(doc: Document, elements: list[Element], header: str,
                path: list[str], kind: str) -> Chunk:
    body = "\n\n".join(e.content or "" for e in elements).strip()
    text = f"{header}\n\n{body}"
    first = elements[0]
    return Chunk(
        id=_chunk_id(doc, first.id, body),
        text=text, context_header=header, section_path=path, kind=kind,
        element_ids=[e.id for e in elements],
        source=(first.source.to_dict() if first.source else {}),
        tokens_estimate=estimate_tokens(text),
        contains_instruction_shaped_text=any(e.meta.get("injection_risk")
                                             for e in elements),
    )


# ----------------------------------------------------------------------- table

def _chunk_table(doc: Document, table: Element, doc_title: str,
                 max_tokens: int) -> list[Chunk]:
    """A table is atomic until it is too big; then it splits by rows, headers repeated.

    Repeating the header block in every split is the whole point: a row group without its
    column names is a list of numbers.
    """
    section = doc.section_of(table.id)
    path = _section_path(doc, section)
    headers = [doc.get(c) for c in table.children]
    header_els = [h for h in headers if h is not None
                  and h.type is ElementType.TABLE_HEADER]
    rows = [r for c in table.children
            if (r := doc.get(c)) is not None and r.type is ElementType.TABLE_ROW]

    col_lines: list[str] = []
    for h in header_els:
        bits = [str(h.content)]
        if h.meta.get("unit"):
            bits.append(f"unit: {h.meta['unit']}")
        if h.meta.get("semantic_type") not in (None, "text", "empty"):
            bits.append(f"type: {h.meta['semantic_type']}")
        col_lines.append("  - " + " | ".join(bits))

    intro = [f"Document: {doc_title}"]
    if path:
        intro.append("Section: " + " > ".join(path))
    if table.content:
        intro.append(f"Table: {table.content}")
    if table.meta.get("region"):
        intro.append(f"Range: {table.meta['region']}")
    if table.source:
        intro.append(f"Source: {table.source.locator}")
    if col_lines:
        intro.append("Columns:")
        intro.extend(col_lines)
    if table.meta.get("notes"):
        intro.append("Notes: " + " ".join(str(n) for n in table.meta["notes"]))
    header = "\n".join(intro)

    def row_line(row: Element) -> str:
        parts: list[str] = []
        for cid in row.children:
            cell = doc.get(cid)
            if cell is None:
                continue
            label = cell.meta.get("header") or cell.meta.get("column")
            val = cell.value if cell.value is not None else cell.content
            formula = cell.meta.get("formula")
            if val is None and formula:
                piece = f"{label}={formula}"        # uncalculated: the formula IS the value
            elif formula:
                piece = f"{label}={val} [{formula}]"
            else:
                piece = f"{label}={val}"
            parts.append(piece)
        role = row.meta.get("role")
        prefix = f"({role}) " if role and role != "data" else ""
        return prefix + "; ".join(parts)

    budget = max_tokens - estimate_tokens(header)
    out: list[Chunk] = []
    buf: list[Element] = []
    buf_lines: list[str] = []
    buf_tokens = 0

    for row in rows:
        line = row_line(row)
        t = estimate_tokens(line)
        if buf and buf_tokens + t > budget:
            out.append(_table_chunk(doc, table, buf, buf_lines, header, path))
            buf, buf_lines, buf_tokens = [], [], 0
        buf.append(row)
        buf_lines.append(line)
        buf_tokens += t
    if buf or not rows:
        out.append(_table_chunk(doc, table, buf, buf_lines, header, path))

    if len(out) > 1:
        for i, c in enumerate(out, 1):
            c.meta["part"] = f"{i}/{len(out)}"
    return out


def _table_chunk(doc: Document, table: Element, rows: list[Element],
                 lines: list[str], header: str, path: list[str]) -> Chunk:
    body = "\n".join(lines) if lines else "(no data rows)"
    text = f"{header}\n\nRows:\n{body}"
    return Chunk(
        id=_chunk_id(doc, table.id, body),
        text=text, context_header=header, section_path=path, kind="table",
        element_ids=[table.id] + [r.id for r in rows],
        source=(table.source.to_dict() if table.source else {}),
        tokens_estimate=estimate_tokens(text),
        contains_instruction_shaped_text=any(r.meta.get("injection_risk") for r in rows),
        meta={"table_id": table.id, "row_count": len(rows)},
    )


# ---------------------------------------------------------------------- figure

def _chunk_figure(doc: Document, fig: Element, doc_title: str) -> Chunk | None:
    section = doc.section_of(fig.id)
    path = _section_path(doc, section)
    bits = [f"Document: {doc_title}"]
    if path:
        bits.append("Section: " + " > ".join(path))
    if fig.source:
        bits.append(f"Source: {fig.source.locator}")
    header = "\n".join(bits)

    body: list[str] = []
    if fig.meta.get("caption"):
        body.append(f"Caption: {fig.meta['caption']}")
    if fig.meta.get("image_class"):
        body.append(f"Image class ({Basis.INFERRED.value}, confidence "
                    f"{fig.meta.get('image_class_confidence')}): {fig.meta['image_class']}")
    if fig.meta.get("alt"):
        body.append(f"Alt text: {fig.meta['alt']}")
    ocr_texts = [e.content for c in fig.children
                 if (e := doc.get(c)) is not None
                 and e.basis is Basis.MODEL_GENERATED and e.content]
    if ocr_texts:
        body.append(f"OCR text ({Basis.MODEL_GENERATED.value}): " + " ".join(ocr_texts))
    if not body:
        return None
    text = f"{header}\n\n" + "\n".join(body)
    return Chunk(
        id=_chunk_id(doc, fig.id, text), text=text, context_header=header,
        section_path=path, kind="figure", element_ids=[fig.id],
        source=(fig.source.to_dict() if fig.source else {}),
        tokens_estimate=estimate_tokens(text),
    )


# --------------------------------------------------------------------- helpers

def _section_path(doc: Document, section: Element | None) -> list[str]:
    if section is None:
        return []
    path = [section.content or section.id]
    for a in doc.ancestors(section.id):
        if a.type in (ElementType.SECTION, ElementType.SHEET):
            path.append(a.content or a.id)
    return list(reversed(path))


def _context_header(doc_title: str, path: list[str], doc: Document,
                    first: Element) -> str:
    bits = [f"Document: {doc_title}"]
    if path:
        bits.append("Section: " + " > ".join(path))
    if first.source:
        bits.append(f"Source: {first.source.locator}")
    return "\n".join(bits)


def _chunk_id(doc: Document, anchor: str, body: str) -> str:
    digest = hashlib.sha256(f"{anchor}|{body}".encode("utf-8")).hexdigest()[:12]
    return f"{doc.source.file}:{anchor}:{digest}"
