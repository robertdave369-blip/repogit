"""Canonical AI-native document representation.

Format-independent. A PDF page, an Excel sheet and an email body all become the same
`Element` graph, so downstream consumers (context compiler, chunker, RAG) never branch on
the source format.

Three rules hold this together:

1. **Every element is addressable.** `Element.id` is stable and derived from the element's
   location, so a chunk retrieved months later still resolves to a cell or a page.
2. **Every element carries provenance.** `Element.source` always names the file and, where
   the format has one, the page / sheet / cell / range. Compaction may drop text; it may
   never drop provenance.
3. **Every element declares how it came to exist.** `Basis.EXTRACTED` was read off the
   file, `Basis.INFERRED` was derived by our own structural rules, `Basis.MODEL_GENERATED`
   came from a model. Callers must be able to tell a fact from a guess.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterator

SCHEMA_VERSION = "2.0.0"


class Basis(str, Enum):
    """How an element or a piece of metadata came to exist. Never blur these."""

    EXTRACTED = "EXTRACTED"              # read directly from the file
    INFERRED = "INFERRED"                # derived by our structural rules
    MODEL_GENERATED = "MODEL_GENERATED"  # produced by an OCR / vision / language model


class ElementType(str, Enum):
    DOCUMENT = "document"
    SECTION = "section"
    HEADING = "heading"
    PARAGRAPH = "paragraph"
    LIST = "list"
    LIST_ITEM = "list_item"
    TABLE = "table"
    TABLE_HEADER = "table_header"
    TABLE_ROW = "table_row"
    TABLE_CELL = "table_cell"
    FIGURE = "figure"
    CAPTION = "caption"
    CHART = "chart"
    PAGE = "page"
    SLIDE = "slide"
    SHEET = "sheet"
    REGION = "region"          # a discrete data region inside one sheet
    CELL = "cell"
    FORMULA = "formula"
    NOTE = "note"
    FOOTNOTE = "footnote"
    CODE = "code"
    LINK = "link"
    METADATA = "metadata"
    UNSUPPORTED = "unsupported"


class Rel(str, Enum):
    """Typed edges. The graph is what separates this from a pile of text."""

    PARENT = "parent"
    CHILD = "child"
    CONTAINS = "contains"
    FOLLOWS = "follows"
    REFERENCES = "references"
    CAPTION_FOR = "caption_for"
    BELONGS_TO_SECTION = "belongs_to_section"
    HEADER_FOR = "header_for"
    MERGED_WITH = "merged_with"
    DERIVED_FROM = "derived_from"
    FORMULA_DEPENDS_ON = "formula_depends_on"
    NEAR = "near"
    SAME_TABLE = "same_table"
    SAME_SECTION = "same_section"
    TOTAL_OF = "total_of"


# --------------------------------------------------------------------- provenance

@dataclass
class Source:
    """Where this came from. `locator` is the human-readable address used in reports."""

    file: str
    fmt: str
    sha256: str = ""
    page: int | None = None
    sheet: str | None = None
    cell: str | None = None
    cell_range: str | None = None
    slide: int | None = None
    bbox: tuple[float, float, float, float] | None = None
    section: str | None = None
    authority: str = "UNKNOWN"

    @property
    def locator(self) -> str:
        parts = [self.file]
        if self.sheet:
            parts.append(self.sheet)
        if self.cell_range:
            parts.append(self.cell_range)
        elif self.cell:
            parts.append(self.cell)
        if self.page is not None:
            parts.append(f"p.{self.page}")
        if self.slide is not None:
            parts.append(f"slide {self.slide}")
        return " -> ".join(parts)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"file": self.file, "format": self.fmt,
                             "authority": self.authority, "locator": self.locator}
        for k in ("sha256", "page", "sheet", "cell", "cell_range", "slide", "section"):
            v = getattr(self, k)
            if v not in (None, ""):
                d[k] = v
        if self.bbox is not None:
            d["bbox"] = list(self.bbox)
        return d


@dataclass
class Relationship:
    rel: Rel
    target: str
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"rel": self.rel.value, "target": self.target}
        if self.meta:
            d["meta"] = self.meta
        return d


# ------------------------------------------------------------------------ element

@dataclass
class Element:
    id: str
    type: ElementType
    content: str | None = None
    value: Any = None
    source: Source | None = None
    parent: str | None = None
    children: list[str] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)
    basis: Basis = Basis.EXTRACTED
    confidence: float = 1.0
    meta: dict[str, Any] = field(default_factory=dict)

    def relate(self, rel: Rel, target: str, **meta: Any) -> None:
        self.relationships.append(Relationship(rel, target, dict(meta)))

    def to_dict(self, *, with_text: bool = True) -> dict[str, Any]:
        d: dict[str, Any] = {"id": self.id, "type": self.type.value,
                             "basis": self.basis.value}
        if with_text and self.content is not None:
            d["content"] = self.content
        if self.value is not None:
            d["value"] = self.value
        if self.source is not None:
            d["source"] = self.source.to_dict()
        if self.parent:
            d["parent"] = self.parent
        if self.children:
            d["children"] = list(self.children)
        if self.relationships:
            d["relationships"] = [r.to_dict() for r in self.relationships]
        if self.confidence != 1.0:
            d["confidence"] = round(self.confidence, 3)
        if self.meta:
            d["metadata"] = self.meta
        return d


# ----------------------------------------------------------------------- document

@dataclass
class ExtractionReport:
    """Partial success is reported, never hidden. Mirrors document_context.Report."""

    successful: list[str] = field(default_factory=list)
    partial: list[dict[str, str]] = field(default_factory=list)
    unsupported: list[dict[str, str]] = field(default_factory=list)
    failed: list[dict[str, str]] = field(default_factory=list)

    def ok(self, what: str) -> None:
        self.successful.append(what)

    def part(self, what: str, why: str) -> None:
        self.partial.append({"what": what, "why": why})

    def unsup(self, what: str, why: str) -> None:
        self.unsupported.append({"what": what, "why": why})

    def fail(self, what: str, why: str) -> None:
        self.failed.append({"what": what, "why": why})

    def to_dict(self) -> dict[str, Any]:
        return {"successful": self.successful, "partial": self.partial,
                "unsupported": self.unsupported, "failed": self.failed}


@dataclass
class Document:
    source: Source
    metadata: dict[str, Any] = field(default_factory=dict)
    elements: dict[str, Element] = field(default_factory=dict)
    roots: list[str] = field(default_factory=list)
    report: ExtractionReport = field(default_factory=ExtractionReport)
    schema_version: str = SCHEMA_VERSION
    pipeline: list[str] = field(default_factory=list)

    # -- construction -------------------------------------------------------

    def add(self, el: Element, parent: str | None = None) -> Element:
        if el.id in self.elements:
            el.id = _dedupe_id(el.id, self.elements)
        self.elements[el.id] = el
        if parent is not None and parent in self.elements:
            el.parent = parent
            self.elements[parent].children.append(el.id)
        elif parent is None and el.parent is None:
            self.roots.append(el.id)
        return el

    def get(self, eid: str) -> Element | None:
        return self.elements.get(eid)

    # -- traversal ----------------------------------------------------------

    def walk(self, start: str | None = None) -> Iterator[Element]:
        stack = list(reversed(self.roots)) if start is None else [start]
        while stack:
            eid = stack.pop()
            el = self.elements.get(eid)
            if el is None:
                continue
            yield el
            stack.extend(reversed(el.children))

    def by_type(self, *types: ElementType) -> list[Element]:
        want = set(types)
        return [e for e in self.elements.values() if e.type in want]

    def ancestors(self, eid: str) -> list[Element]:
        out: list[Element] = []
        seen: set[str] = set()
        cur = self.elements.get(eid)
        while cur is not None and cur.parent and cur.parent not in seen:
            seen.add(cur.parent)
            parent = self.elements.get(cur.parent)
            if parent is None:
                break
            out.append(parent)
            cur = parent
        return out

    def section_of(self, eid: str) -> Element | None:
        for a in self.ancestors(eid):
            if a.type in (ElementType.SECTION, ElementType.SHEET, ElementType.REGION):
                return a
        return None

    # -- serialisation ------------------------------------------------------

    def to_dict(self, *, with_text: bool = True) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source": self.source.to_dict(),
            "metadata": self.metadata,
            "pipeline": self.pipeline,
            "report": self.report.to_dict(),
            "roots": self.roots,
            "element_count": len(self.elements),
            "elements": [self.elements[i].to_dict(with_text=with_text)
                         for i in self.elements],
        }

    def to_json(self, *, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False, default=str)


# ------------------------------------------------------------------------ helpers

_ID_SAFE = re.compile(r"[^A-Za-z0-9_.:!$-]+")


def make_id(*parts: Any) -> str:
    """Stable, readable, addressable. `xlsx:Revenue!B7` beats a uuid for retrieval."""
    raw = ":".join(str(p) for p in parts if p is not None and str(p) != "")
    cleaned = _ID_SAFE.sub("_", raw).strip("_")
    if len(cleaned) > 180:
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:10]
        cleaned = cleaned[:160] + "_" + digest
    return cleaned or "el"


def _dedupe_id(base: str, existing: dict[str, Element]) -> str:
    i = 2
    while f"{base}#{i}" in existing:
        i += 1
    return f"{base}#{i}"
