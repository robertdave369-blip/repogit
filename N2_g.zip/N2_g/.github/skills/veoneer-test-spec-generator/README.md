# Veoneer Test Spec Generator

This skill converts structured or unstructured requirement sources into a Veoneer-style, Codebeamer-export-shaped Excel workbook. It is reusable across projects because its field mapping and enumerations live in `config/template_profile.json`, rather than in generator code.

## What It Includes

- `scripts/sanitize.py`: safe HTML/CSS/wiki-style cleanup that preserves engineering content and reports token integrity.
- `scripts/requirement_parser.py`: text, CSV, Excel, JSON, Word, and native-text PDF parsers with source provenance.
- `scripts/methodology.py` and `scripts/generator.py`: explainable minimal test design and requirement-to-case traceability.
- `scripts/workbook_codec.py`: template inspection plus primary/continuation-row serialization.
- `scripts/legacy_export.py`: V3-style `Export`/`ChoiceValues` rendering with the requested 22 Veoneer headers for reviewed legacy workbooks.
- `scripts/validation.py`: template-backed validation and explicit live-import evidence gap reporting.
- `scripts/legacy_adapters.py`: reusable replacements for the two reviewed legacy scripts.

## Template Facts

The bundled profile was derived from `veoneer_codebeamer_test_spec_template.xlsx` on 2026-08-24. It expects visible `Export` and hidden `ChoiceValues` sheets, 23 `Export` headers, data validations, Codebeamer hyperlinks, and step continuation rows. See [references/template-contract.md](references/template-contract.md) for the observed evidence and unknowns.

The cleaned master is always a separate copy. It is never a replacement for the original template.

## Install Optional Parsers

```powershell
py -3.13 -m pip install -r .github\skills\veoneer-test-spec-generator\requirements.txt
```

`openpyxl` is required for Excel. `python-docx` and `PyMuPDF` are only required when Word/PDF inputs are used.

## Typical Run

```powershell
py -3.13 .github\skills\veoneer-test-spec-generator\scripts\cli.py generate `
  --template .github\skills\veoneer-test-spec-generator\assets\veoneer_codebeamer_test_spec_template.cleaned.xlsx `
  --source .github\skills\veoneer-test-spec-generator\examples\requirements\example_requirements.json `
  --title Example_Review_Spec `
  --output tests\example_veoneer_review_spec.xlsx `
  --write-mode replace_data
```

The example deliberately omits a requirement ID. Its output is a review workbook with a visible traceability warning, not an import-ready claim.
Its JSON report records the source requirement provenance, generated test case, steps, and expected results for reviewable forward traceability.

## Reviewed Legacy Export Run

Use this path when the deliverable must match the reviewed EDR V3 layout while adding the requested Veoneer fields. It accepts a reviewed seven-column seed and upgrades the output to visible `Export` and `ChoiceValues` sheets with these `Export` headers: `ID`, `Priority`, `Name`, `Description`, `Pre-Action`, `Post-Action`, `Test Steps.Action`, `Test Steps.Expected result`, `Test Steps.Critical`, `Test Parameters`, `Verifies`, `Status`, `Type`, `_Project`, `Reviewer(s)`, `_LatestResult`, `_Original_Id`, `Referenced Reviews`, `_ScriptPath`, `_TestType`, `_VerificationMethod`, and `_TestTechnique`.

```powershell
py -3.13 .github\skills\veoneer-test-spec-generator\scripts\legacy_export.py `
  --template <approved-legacy-template.xlsx> `
  --source <requirements.xlsx> --source <requirements.docx> `
  --title <specification-title> `
  --output <new-specification.xlsx> `
  --write-mode replace_data --strict
```

The same command is available through `cli.py generate-legacy-export`. The template is copied, never edited in place; `replace_data` preserves the layout while replacing existing export rows, and `append` retains them. Case-level fields are written only on a test case's primary `Name` row; continuation rows contain only `Test Steps.Action`, `Test Steps.Expected result`, and optional `Test Steps.Critical`. `ID` is a test-case artifact ID and remains blank unless the user explicitly supplies it. `Verifies` contains one or more requirement IDs in this exact format: `[ISSUE:<ID>] - null,[ISSUE:<ID>] - null`. The generated JSON report contains source provenance, coverage gaps, preflight findings, and postflight format validation. It does not claim Codebeamer importer acceptance without a recorded approved round trip.

## Maintenance

When Veoneer provides a new template, do not overwrite the profile by inspection alone. Create a new cleaned copy, inspect its layout and choice values, update the profile and contract document, add a regression fixture, and record an approved Codebeamer import/export round trip before claiming importer compatibility. Full guidance is in [references/maintenance.md](references/maintenance.md).