# Bundled Template Assets

`veoneer_codebeamer_test_spec_template.cleaned.xlsx` is the portable cleaned master used by the default generator path. Its SHA-256 is `22569adeb63a8d25c2a87b1a1b2948bf4ab665add96f10470125abe602d30dad`.

The sanitization evidence is in `cleaned_template_sanitization_report.json`. The external original template was not retained with this skill package; its recorded SHA-256 is `751a1266b06dae7b5ad17d963d19c0746d28b83f4e672b465ef122358304715a`. Its location is intentionally not recorded because it was workstation-specific and is unavailable.

Use the bundled cleaned master for offline generation. A new customer-approved template should be added as a separately named asset with its own hash, profile, contract update, and regression coverage.