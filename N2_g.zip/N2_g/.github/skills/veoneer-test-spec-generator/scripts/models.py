"""Canonical data structures for Veoneer test-specification generation."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class SourceProvenance:
    """Location of a record in an immutable input source."""

    source_path: str
    source_type: str
    location: str
    sheet: str | None = None
    raw_status: str | None = None


@dataclass(slots=True)
class Requirement:
    """A normalized requirement preserved with its source evidence."""

    identifier: str | None
    text: str
    provenance: SourceProvenance
    title: str | None = None
    status: str | None = None
    project: str | None = None
    priority: str | None = None
    acceptance_criteria: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_approved(self) -> bool:
        return (self.status or "").strip().casefold() == "approved"


@dataclass(slots=True)
class TestMethodology:
    """Selected test technique plus an explicit evidence-based rationale."""

    primary_technique: str | None
    supporting_methods: list[str] = field(default_factory=list)
    rationale: str = ""


@dataclass(slots=True)
class TestStep:
    """One ordered action and its observable pass criterion."""

    action: str
    expected_result: str
    critical: bool | None = None
    identifier: str | None = None


@dataclass(slots=True)
class TestCase:
    """A test case that can be flattened into Codebeamer export rows."""

    name: str
    description: str
    steps: list[TestStep]
    methodology: TestMethodology
    requirement_ids: list[str] = field(default_factory=list)
    pre_action: str | None = None
    post_action: str | None = None
    priority: str | None = None
    status: str | None = None
    item_type: str | None = None
    project: str | None = None
    reviewer: str | None = None
    latest_result: str | None = None
    artifact_id: int | None = None
    original_id: str | None = None
    referenced_reviews: str | None = None
    script_path: str | None = None
    test_type: str | None = None
    verification_method: str | None = None
    source_requirements: list[SourceProvenance] = field(default_factory=list)
    generation_notes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class TestSpecification:
    """A complete specification and the evidence used to derive it."""

    title: str
    test_cases: list[TestCase]
    source_paths: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    coverage_gaps: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ValidationIssue:
    """A machine-readable validation result with a stable severity."""

    severity: str
    code: str
    message: str
    location: str | None = None


def as_serializable(value: Any) -> dict[str, Any]:
    """Return a dataclass graph as JSON-compatible dictionaries and lists."""
    return asdict(value)