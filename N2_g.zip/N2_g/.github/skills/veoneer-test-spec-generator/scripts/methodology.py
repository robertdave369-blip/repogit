"""Evidence-based test-methodology selection for normalized requirements."""

from __future__ import annotations

import re
from dataclasses import dataclass

from models import Requirement, TestMethodology


BOUNDARY_PATTERN = re.compile(
    r"\b(minimum|maximum|at least|at most|less than|greater than|between|range|limit|threshold|within)\b",
    re.IGNORECASE,
)
STATE_PATTERN = re.compile(
    r"\b(state|mode|transition|before|after|until|while|startup|shutdown|ignition|reset)\b",
    re.IGNORECASE,
)
DECISION_PATTERN = re.compile(r"\b(if|when|unless|and|or)\b", re.IGNORECASE)
FAULT_PATTERN = re.compile(
    r"\b(fault|failure|error|invalid|missing|corrupt|recovery|degrad)\b",
    re.IGNORECASE,
)
FAULT_TIMEOUT_PATTERN = re.compile(
    r"\b(?:node|message|communication|network)\s+timeout\b|\btimeout\s+(?:fault|error|detection)\b",
    re.IGNORECASE,
)
INTERFACE_PATTERN = re.compile(
    r"\b(can|can fd|uds|did|dtc|message|signal|interface|network|communication)\b",
    re.IGNORECASE,
)


@dataclass(slots=True)
class Scenario:
    """A distinct test scenario selected from explicit requirement cues."""

    identifier: str
    label: str
    rationale: str


def _has_fault_cue(source_text: str) -> bool:
    return bool(FAULT_PATTERN.search(source_text) or FAULT_TIMEOUT_PATTERN.search(source_text))


def _allowed_technique(preferred: str, allowed_techniques: list[str] | None) -> str | None:
    if allowed_techniques is None:
        return preferred
    by_normalized_value = {value.casefold(): value for value in allowed_techniques}
    return by_normalized_value.get(preferred.casefold())


def select_methodology(
    requirement: Requirement,
    *,
    allowed_techniques: list[str] | None = None,
) -> TestMethodology:
    """Choose a technique only from evidence that appears in the source text."""
    source_text = " ".join(filter(None, [requirement.title, requirement.text]))
    supporting_methods = ["Requirement-Based Testing"]
    rationale_parts: list[str] = []

    if _has_fault_cue(source_text):
        preferred = "Fault Injection"
        supporting_methods.append("Negative Testing")
        rationale_parts.append("The requirement contains explicit fault, invalid-input, or recovery language.")
    elif BOUNDARY_PATTERN.search(source_text):
        preferred = "Boundary Value Analysis"
        supporting_methods.append("Robustness Testing")
        rationale_parts.append("The requirement contains explicit limit, range, threshold, or timing-boundary language.")
    elif STATE_PATTERN.search(source_text):
        preferred = "State Transition Testing"
        rationale_parts.append("The requirement contains explicit state, mode, lifecycle, or transition language.")
    elif len(DECISION_PATTERN.findall(source_text)) >= 2:
        preferred = "Decision Table Testing"
        rationale_parts.append("The requirement contains multiple explicit logical-condition cues.")
    elif INTERFACE_PATTERN.search(source_text):
        preferred = "Equivalence Classes"
        supporting_methods.append("Interface Testing")
        rationale_parts.append("The requirement names an interface, signal, message, or diagnostic exchange.")
    else:
        preferred = "Equivalence Classes"
        rationale_parts.append("No stronger boundary, fault, state, or decision cue was detected in the source text.")

    selected = _allowed_technique(preferred, allowed_techniques)
    if selected is None:
        rationale_parts.append(
            f"The preferred technique '{preferred}' is not present in the supplied template choices and must be selected during review."
        )
    return TestMethodology(
        primary_technique=selected,
        supporting_methods=supporting_methods,
        rationale=" ".join(rationale_parts),
    )


def derive_scenarios(requirement: Requirement) -> list[Scenario]:
    """Derive a small, non-duplicative scenario set from requirement evidence."""
    source_text = " ".join(filter(None, [requirement.title, requirement.text]))
    scenarios = [
        Scenario(
            identifier="nominal",
            label="Nominal behavior",
            rationale="Verifies the stated behavior under the requirement's normal preconditions.",
        )
    ]
    if _has_fault_cue(source_text):
        scenarios.append(
            Scenario(
                identifier="fault_recovery",
                label="Fault and recovery behavior",
                rationale="The source explicitly describes an error, fault, invalid condition, or recovery behavior.",
            )
        )
    elif BOUNDARY_PATTERN.search(source_text):
        scenarios.append(
            Scenario(
                identifier="boundary",
                label="Boundary behavior",
                rationale="The source explicitly describes a limit, range, threshold, or timing boundary.",
            )
        )
    elif STATE_PATTERN.search(source_text):
        scenarios.append(
            Scenario(
                identifier="transition",
                label="State transition behavior",
                rationale="The source explicitly describes a state, mode, lifecycle, or transition.",
            )
        )
    elif len(DECISION_PATTERN.findall(source_text)) >= 2:
        scenarios.append(
            Scenario(
                identifier="decision_outcomes",
                label="Decision outcomes",
                rationale="The source contains multiple logical conditions that require outcome coverage.",
            )
        )
    return scenarios