"""Command-line entry point for the Veoneer test-specification skill."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from generator import generate_specification
from legacy_export import add_legacy_export_arguments, command_generate_legacy_export
from legacy_adapters import excel_to_testcase_dict, write_legacy_title_step_workbook
from requirement_parser import parse_inline_requirements, parse_sources
from sanitize import sanitize_workbook_copy, write_json_report
from validation import validate_rendered_workbook, validate_specification
from workbook_codec import inspection_as_dict, inspect_template, load_profile, render_specification


SKILL_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MASTER_TEMPLATE = SKILL_ROOT / "assets" / "veoneer_codebeamer_test_spec_template.cleaned.xlsx"


def _report_path(output_path: str | Path, explicit_path: str | None) -> Path:
    if explicit_path:
        return Path(explicit_path).expanduser().resolve()
    output = Path(output_path).expanduser().resolve()
    return output.with_suffix(output.suffix + ".validation.json")


def _template_path(value: str | None) -> Path:
    if value:
        return Path(value).expanduser().resolve()
    if DEFAULT_MASTER_TEMPLATE.is_file():
        return DEFAULT_MASTER_TEMPLATE
    raise FileNotFoundError(
        "No template was supplied and the cleaned master is unavailable. Run clean-template or provide --template."
    )


def _print_or_write(report: dict[str, Any], report_path: str | None) -> None:
    if report_path:
        write_json_report(report, report_path)
    print(json.dumps(report, indent=2, ensure_ascii=True))


def command_inspect_template(args: argparse.Namespace) -> int:
    inspection = inspect_template(args.template, load_profile(args.profile))
    report = inspection_as_dict(inspection)
    _print_or_write(report, args.report)
    return 1 if inspection.issues else 0


def command_clean_template(args: argparse.Namespace) -> int:
    report = sanitize_workbook_copy(args.template, args.output, overwrite=args.overwrite)
    report_path = _report_path(args.output, args.report)
    write_json_report(report, report_path)
    print(json.dumps({"output": args.output, "report": str(report_path), "changed_cells": report["changed_cells"]}, indent=2))
    return 1 if not report["preservation"]["passed"] else 0


def command_generate(args: argparse.Namespace) -> int:
    profile = load_profile(args.profile)
    template = _template_path(args.template)
    inspection = inspect_template(template, profile)
    if inspection.issues:
        raise ValueError("Template inspection failed: " + "; ".join(inspection.issues))
    requirements, source_reports = parse_sources(args.source or [])
    requirements.extend(parse_inline_requirements(args.requirement or []))
    generation = generate_specification(
        requirements,
        title=args.title,
        allowed_techniques=inspection.allowed_values.get("_TestTechnique"),
        approved_only=not args.include_unapproved,
    )
    preflight = validate_specification(generation.specification, template_path=template, profile=profile)
    preflight_errors = [issue for issue in preflight if issue.severity == "error"]
    report: dict[str, Any] = {
        "input_sources": source_reports,
        "inline_requirement_count": len(args.requirement or []),
        "specification": {
            "title": generation.specification.title,
            "test_case_count": len(generation.specification.test_cases),
            "assumptions": generation.specification.assumptions,
            "coverage_gaps": generation.specification.coverage_gaps,
            "excluded_requirements": generation.excluded_requirements,
        },
        "traceability": [
            {
                "test_case": test_case.name,
                "requirement_ids": test_case.requirement_ids,
                "source_requirements": [asdict(provenance) for provenance in test_case.source_requirements],
                "steps": [
                    {
                        "step_number": step_number,
                        "action": step.action,
                        "expected_result": step.expected_result,
                    }
                    for step_number, step in enumerate(test_case.steps, start=1)
                ],
            }
            for test_case in generation.specification.test_cases
        ],
        "preflight": [asdict(issue) for issue in preflight],
    }
    if args.strict and preflight_errors:
        report["output_blocked"] = "Strict mode blocked workbook generation because preflight errors were found."
        report_path = _report_path(args.output, args.report)
        write_json_report(report, report_path)
        print(json.dumps({"report": str(report_path), "errors": len(preflight_errors), "output_blocked": True}, indent=2))
        return 1
    rendering = render_specification(
        generation.specification,
        template_path=template,
        destination_path=args.output,
        write_mode=args.write_mode,
        profile=profile,
        overwrite=args.overwrite,
    )
    postflight = validate_rendered_workbook(args.output, profile=profile)
    report["rendering"] = rendering
    report["postflight"] = postflight
    report_path = _report_path(args.output, args.report)
    write_json_report(report, report_path)
    print(
        json.dumps(
            {
                "output": args.output,
                "report": str(report_path),
                "test_cases": len(generation.specification.test_cases),
                "postflight_errors": postflight["summary"]["errors"],
                "postflight_warnings": postflight["summary"]["warnings"],
            },
            indent=2,
        )
    )
    return 1 if postflight["summary"]["errors"] else 0


def command_legacy_read(args: argparse.Namespace) -> int:
    test_cases = excel_to_testcase_dict(args.input, sheet_name=args.sheet)
    report = {"input": str(Path(args.input).expanduser().resolve()), "test_case_count": len(test_cases), "test_cases": test_cases}
    _print_or_write(report, args.output)
    return 0


def command_legacy_write(args: argparse.Namespace) -> int:
    payload = json.loads(Path(args.input).expanduser().resolve().read_text(encoding="utf-8"))
    test_cases = payload.get("test_cases", payload) if isinstance(payload, dict) else payload
    if not isinstance(test_cases, list):
        raise ValueError("Legacy JSON input must be a list or an object containing 'test_cases'.")
    destination = write_legacy_title_step_workbook(
        test_cases,
        args.output,
        sheet_name=args.sheet,
        overwrite=args.overwrite,
    )
    print(json.dumps({"output": str(destination), "test_case_count": len(test_cases)}, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate and validate Veoneer Codebeamer-style test specifications offline.")
    parser.add_argument("--profile", help="Optional template profile JSON; defaults to the bundled observed profile")
    subcommands = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subcommands.add_parser("inspect-template", help="Inspect the observed workbook contract")
    inspect_parser.add_argument("template", help="Source Veoneer .xlsx/.xlsm template")
    inspect_parser.add_argument("--report", help="Optional JSON report destination")
    inspect_parser.set_defaults(handler=command_inspect_template)

    clean_parser = subcommands.add_parser("clean-template", help="Create a non-destructive cleaned template copy")
    clean_parser.add_argument("template", help="Original template; never modified")
    clean_parser.add_argument("output", help="New cleaned master template path")
    clean_parser.add_argument("--report", help="Sanitization report path")
    clean_parser.add_argument("--overwrite", action="store_true", help="Allow replacing an existing output")
    clean_parser.set_defaults(handler=command_clean_template)

    generate_parser = subcommands.add_parser("generate", help="Parse sources and generate a template-backed specification")
    generate_parser.add_argument("--template", help="Cleaned master or approved template; defaults to bundled cleaned master")
    generate_parser.add_argument("--source", action="append", help="Requirement source (.txt, .csv, .xlsx, .docx, .pdf, .json); repeatable")
    generate_parser.add_argument("--requirement", action="append", help="Inline requirement, optionally '<ID>: <text>'; repeatable")
    generate_parser.add_argument("--title", required=True, help="Test specification title")
    generate_parser.add_argument("--output", required=True, help="New output workbook path")
    generate_parser.add_argument("--report", help="Generation and validation report path")
    generate_parser.add_argument("--write-mode", choices=["append", "replace_data"], default="append")
    generate_parser.add_argument("--include-unapproved", action="store_true", help="Include records whose source status is not Approved")
    generate_parser.add_argument("--strict", action="store_true", help="Block output when preflight errors are found")
    generate_parser.add_argument("--overwrite", action="store_true", help="Allow replacing an existing output")
    generate_parser.set_defaults(handler=command_generate)

    legacy_export_parser = subcommands.add_parser(
        "generate-legacy-export",
        aliases=["generate-legacy"],
        help="Generate the V3-style Export/ChoiceValues workbook with the requested Veoneer headers",
    )
    add_legacy_export_arguments(legacy_export_parser)
    legacy_export_parser.set_defaults(handler=command_generate_legacy_export)

    legacy_read_parser = subcommands.add_parser("legacy-read", help="Read a reviewed legacy title/step workbook")
    legacy_read_parser.add_argument("input", help="Legacy .xlsx workbook")
    legacy_read_parser.add_argument("--sheet", help="Worksheet name; defaults to active sheet")
    legacy_read_parser.add_argument("--output", help="Optional JSON report path")
    legacy_read_parser.set_defaults(handler=command_legacy_read)

    legacy_write_parser = subcommands.add_parser("legacy-write", help="Write a reviewed legacy title/step workbook from JSON")
    legacy_write_parser.add_argument("input", help="JSON list of legacy test cases")
    legacy_write_parser.add_argument("output", help="New legacy workbook path")
    legacy_write_parser.add_argument("--sheet", default="EDR Test Spec", help="Worksheet title")
    legacy_write_parser.add_argument("--overwrite", action="store_true", help="Allow replacing an existing output")
    legacy_write_parser.set_defaults(handler=command_legacy_write)
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    return arguments.handler(arguments)


if __name__ == "__main__":
    raise SystemExit(main())