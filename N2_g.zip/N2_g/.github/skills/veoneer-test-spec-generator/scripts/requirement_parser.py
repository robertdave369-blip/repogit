"""Full-source requirement parsing with source location and sanitization evidence."""

from __future__ import annotations

import csv
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

import openpyxl

from models import Requirement, SourceProvenance
from sanitize import sanitize_text, sha256_file


ID_HEADERS = ("id", "requirement id", "artifact id", "requirement_id")
TEXT_HEADERS = ("description", "requirement", "summary", "text", "name", "title")
STATUS_HEADERS = ("_reqstatus", "requirement status", "status", "_status")
PROJECT_HEADERS = ("_projects", "project", "projects", "variant")
PRIORITY_HEADERS = ("priority", "_priority")
TITLE_HEADERS = ("summary", "name", "title")
IDENTIFIER_LINE_PATTERN = re.compile(
    r"^\s*(?P<identifier>(?:\d{6,}\s*,\s*)*\d{6,}|[A-Za-z][A-Za-z0-9_.-]{1,})\s*[:|]\s*(?P<text>.+?)\s*$"
)


@dataclass(slots=True)
class SourceReport:
    """Extraction evidence for one source without altering the source artifact."""

    source_path: str
    source_type: str
    sha256: str
    records: int = 0
    warnings: list[str] = field(default_factory=list)
    sheet_stats: list[dict[str, Any]] = field(default_factory=list)


def _normalized_header(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).strip()).casefold()


def _first_index(header_map: dict[str, int], candidates: tuple[str, ...]) -> int | None:
    for candidate in candidates:
        if candidate in header_map:
            return header_map[candidate]
    return None


def _find_excel_header(worksheet: openpyxl.worksheet.worksheet.Worksheet) -> tuple[int | None, dict[str, int]]:
    best_row: int | None = None
    best_map: dict[str, int] = {}
    best_score = 0
    for row_index, row in enumerate(
        worksheet.iter_rows(min_row=1, max_row=min(worksheet.max_row, 25), values_only=True), start=1
    ):
        header_map = {
            _normalized_header(value): index
            for index, value in enumerate(row)
            if _normalized_header(value)
        }
        score = sum(
            (
                _first_index(header_map, ID_HEADERS) is not None,
                _first_index(header_map, TEXT_HEADERS) is not None,
                _first_index(header_map, STATUS_HEADERS) is not None,
            )
        )
        if score > best_score:
            best_row, best_map, best_score = row_index, header_map, score
    return (best_row, best_map) if best_score >= 2 else (None, {})


def _text_from_value(value: Any) -> str | None:
    if value is None:
        return None
    sanitized = sanitize_text(value).text
    return sanitized or None


def _acceptance_criteria(text: str) -> list[str]:
    criteria = []
    for sentence in re.split(r"(?<=[.!?])\s+|\n+", text):
        normalized = sentence.strip()
        if re.search(r"\b(shall|must|should|when|if|within|not|at least|at most)\b", normalized, re.IGNORECASE):
            criteria.append(normalized)
    return criteria or [text]


def _build_requirement(
    *,
    identifier: Any,
    text: Any,
    source_path: Path,
    source_type: str,
    location: str,
    title: Any = None,
    status: Any = None,
    project: Any = None,
    priority: Any = None,
    sheet: str | None = None,
) -> Requirement | None:
    normalized_text = _text_from_value(text)
    if not normalized_text:
        return None
    normalized_identifier = _text_from_value(identifier)
    normalized_status = _text_from_value(status)
    warnings: list[str] = []
    if "[STRUCK:" in normalized_text:
        warnings.append("struck_content_present")
    if normalized_identifier is None:
        warnings.append("requirement_identifier_unavailable")
    if normalized_status is None:
        warnings.append("requirement_approval_status_unavailable")
    return Requirement(
        identifier=normalized_identifier,
        text=normalized_text,
        title=_text_from_value(title),
        status=normalized_status,
        project=_text_from_value(project),
        priority=_text_from_value(priority),
        provenance=SourceProvenance(
            source_path=str(source_path),
            source_type=source_type,
            location=location,
            sheet=sheet,
            raw_status=normalized_status,
        ),
        acceptance_criteria=_acceptance_criteria(normalized_text),
        warnings=warnings,
    )


def parse_plain_text(source_path: str | Path) -> tuple[list[Requirement], SourceReport]:
    """Parse one non-empty line as a requirement without fabricating an identifier."""
    source = Path(source_path).expanduser().resolve()
    report = SourceReport(str(source), "text", sha256_file(source))
    requirements: list[Requirement] = []
    for line_number, raw_line in enumerate(source.read_text(encoding="utf-8-sig").splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        match = IDENTIFIER_LINE_PATTERN.match(line)
        identifier = match.group("identifier") if match else None
        text = match.group("text") if match else line
        requirement = _build_requirement(
            identifier=identifier,
            text=text,
            source_path=source,
            source_type="text",
            location=f"line {line_number}",
        )
        if requirement is not None:
            requirements.append(requirement)
    report.records = len(requirements)
    if not requirements:
        report.warnings.append("no_nonempty_requirements_found")
    return requirements, report


def parse_csv(source_path: str | Path) -> tuple[list[Requirement], SourceReport]:
    """Parse header-mapped CSV records and preserve their row provenance."""
    source = Path(source_path).expanduser().resolve()
    report = SourceReport(str(source), "csv", sha256_file(source))
    requirements: list[Requirement] = []
    with source.open("r", encoding="utf-8-sig", newline="") as input_file:
        reader = csv.DictReader(input_file)
        if not reader.fieldnames:
            report.warnings.append("csv_header_unavailable")
            return requirements, report
        header_map = {_normalized_header(name): name for name in reader.fieldnames if name}
        text_header = next((header_map[name] for name in TEXT_HEADERS if name in header_map), None)
        if text_header is None:
            report.warnings.append("csv_requirement_text_header_unavailable")
            return requirements, report
        identifier_header = next((header_map[name] for name in ID_HEADERS if name in header_map), None)
        status_header = next((header_map[name] for name in STATUS_HEADERS if name in header_map), None)
        project_header = next((header_map[name] for name in PROJECT_HEADERS if name in header_map), None)
        priority_header = next((header_map[name] for name in PRIORITY_HEADERS if name in header_map), None)
        title_header = next((header_map[name] for name in TITLE_HEADERS if name in header_map), None)
        for row_number, row in enumerate(reader, start=2):
            requirement = _build_requirement(
                identifier=row.get(identifier_header) if identifier_header else None,
                text=row.get(text_header),
                source_path=source,
                source_type="csv",
                location=f"row {row_number}",
                title=row.get(title_header) if title_header else None,
                status=row.get(status_header) if status_header else None,
                project=row.get(project_header) if project_header else None,
                priority=row.get(priority_header) if priority_header else None,
            )
            if requirement is not None:
                requirements.append(requirement)
    report.records = len(requirements)
    return requirements, report


def parse_excel(source_path: str | Path) -> tuple[list[Requirement], SourceReport]:
    """Read every workbook sheet and resolve requirement fields by header name."""
    source = Path(source_path).expanduser().resolve()
    report = SourceReport(str(source), "excel", sha256_file(source))
    workbook = openpyxl.load_workbook(source, read_only=True, data_only=True, keep_vba=source.suffix.lower() == ".xlsm")
    requirements: list[Requirement] = []
    try:
        for worksheet in workbook.worksheets:
            header_row, header_map = _find_excel_header(worksheet)
            sheet_stat: dict[str, Any] = {
                "sheet": worksheet.title,
                "dimension": worksheet.calculate_dimension(),
                "max_row": worksheet.max_row,
                "max_column": worksheet.max_column,
                "header_row": header_row,
                "records": 0,
            }
            if header_row is None:
                sheet_stat["warning"] = "requirement_header_unavailable"
                report.sheet_stats.append(sheet_stat)
                continue
            identifier_index = _first_index(header_map, ID_HEADERS)
            text_index = _first_index(header_map, TEXT_HEADERS)
            status_index = _first_index(header_map, STATUS_HEADERS)
            project_index = _first_index(header_map, PROJECT_HEADERS)
            priority_index = _first_index(header_map, PRIORITY_HEADERS)
            title_index = _first_index(header_map, TITLE_HEADERS)
            for row_number, row in enumerate(worksheet.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1):
                if not any(value is not None for value in row):
                    continue
                def value_at(index: int | None) -> Any:
                    return row[index] if index is not None and index < len(row) else None

                requirement = _build_requirement(
                    identifier=value_at(identifier_index),
                    text=value_at(text_index),
                    source_path=source,
                    source_type="excel",
                    location=f"{worksheet.title}!{row_number}",
                    title=value_at(title_index),
                    status=value_at(status_index),
                    project=value_at(project_index),
                    priority=value_at(priority_index),
                    sheet=worksheet.title,
                )
                if requirement is not None:
                    requirements.append(requirement)
                    sheet_stat["records"] += 1
            report.sheet_stats.append(sheet_stat)
    finally:
        workbook.close()
    report.records = len(requirements)
    if not requirements:
        report.warnings.append("no_requirement_records_found")
    return requirements, report


def parse_json(source_path: str | Path) -> tuple[list[Requirement], SourceReport]:
    """Parse a list of requirement objects or an object containing ``requirements``."""
    source = Path(source_path).expanduser().resolve()
    report = SourceReport(str(source), "json", sha256_file(source))
    payload = json.loads(source.read_text(encoding="utf-8-sig"))
    records = payload.get("requirements", []) if isinstance(payload, dict) else payload
    if not isinstance(records, list):
        raise ValueError("JSON requirement sources must contain a list or a 'requirements' list.")
    requirements: list[Requirement] = []
    for index, record in enumerate(records, start=1):
        if not isinstance(record, dict):
            report.warnings.append(f"non_object_record_skipped:{index}")
            continue
        normalized = {_normalized_header(key): value for key, value in record.items()}
        requirement = _build_requirement(
            identifier=next((normalized[key] for key in ID_HEADERS if key in normalized), None),
            text=next((normalized[key] for key in TEXT_HEADERS if key in normalized), None),
            source_path=source,
            source_type="json",
            location=f"item {index}",
            title=next((normalized[key] for key in TITLE_HEADERS if key in normalized), None),
            status=next((normalized[key] for key in STATUS_HEADERS if key in normalized), None),
            project=next((normalized[key] for key in PROJECT_HEADERS if key in normalized), None),
            priority=next((normalized[key] for key in PRIORITY_HEADERS if key in normalized), None),
        )
        if requirement is not None:
            requirements.append(requirement)
    report.records = len(requirements)
    return requirements, report


def parse_docx(source_path: str | Path) -> tuple[list[Requirement], SourceReport]:
    """Parse paragraphs and table rows from a Word document with provenance."""
    try:
        from docx import Document
    except ImportError as error:
        raise RuntimeError("Word support requires python-docx; install the skill requirements first.") from error
    source = Path(source_path).expanduser().resolve()
    report = SourceReport(str(source), "docx", sha256_file(source))
    document = Document(source)
    requirements: list[Requirement] = []
    for paragraph_number, paragraph in enumerate(document.paragraphs, start=1):
        text = paragraph.text.strip()
        if not text:
            continue
        match = IDENTIFIER_LINE_PATTERN.match(text)
        requirement = _build_requirement(
            identifier=match.group("identifier") if match else None,
            text=match.group("text") if match else text,
            source_path=source,
            source_type="docx",
            location=f"paragraph {paragraph_number}",
        )
        if requirement is not None:
            requirements.append(requirement)
    for table_number, table in enumerate(document.tables, start=1):
        for row_number, row in enumerate(table.rows, start=1):
            cells = [cell.text.strip() for cell in row.cells]
            text = " | ".join(cell for cell in cells if cell)
            if not text:
                continue
            requirement = _build_requirement(
                identifier=cells[0] if len(cells) > 1 else None,
                text=cells[-1],
                source_path=source,
                source_type="docx",
                location=f"table {table_number} row {row_number}",
            )
            if requirement is not None:
                requirements.append(requirement)
    report.records = len(requirements)
    return requirements, report


def parse_pdf(source_path: str | Path) -> tuple[list[Requirement], SourceReport]:
    """Extract native-text PDF paragraphs page by page; unreadable pages remain explicit gaps."""
    try:
        import fitz
    except ImportError as error:
        raise RuntimeError("PDF support requires PyMuPDF; install the skill requirements first.") from error
    source = Path(source_path).expanduser().resolve()
    report = SourceReport(str(source), "pdf", sha256_file(source))
    requirements: list[Requirement] = []
    document = fitz.open(source)
    try:
        for page_number, page in enumerate(document, start=1):
            page_text = page.get_text("text").strip()
            if not page_text:
                report.warnings.append(f"page_{page_number}_text_unavailable_requires_ocr_or_visual_review")
                continue
            for paragraph_number, paragraph in enumerate(re.split(r"\n\s*\n", page_text), start=1):
                normalized = paragraph.strip()
                if not normalized:
                    continue
                match = IDENTIFIER_LINE_PATTERN.match(normalized)
                requirement = _build_requirement(
                    identifier=match.group("identifier") if match else None,
                    text=match.group("text") if match else normalized,
                    source_path=source,
                    source_type="pdf",
                    location=f"page {page_number} paragraph {paragraph_number}",
                )
                if requirement is not None:
                    requirements.append(requirement)
    finally:
        document.close()
    report.records = len(requirements)
    return requirements, report


PARSERS: dict[str, Callable[[str | Path], tuple[list[Requirement], SourceReport]]] = {
    ".csv": parse_csv,
    ".docx": parse_docx,
    ".json": parse_json,
    ".pdf": parse_pdf,
    ".txt": parse_plain_text,
    ".md": parse_plain_text,
    ".xlsx": parse_excel,
    ".xlsm": parse_excel,
}


def parse_sources(source_paths: list[str | Path]) -> tuple[list[Requirement], list[dict[str, Any]]]:
    """Parse multiple sources and return all records with per-source extraction evidence."""
    requirements: list[Requirement] = []
    reports: list[dict[str, Any]] = []
    for source_path in source_paths:
        source = Path(source_path).expanduser().resolve()
        parser = PARSERS.get(source.suffix.lower())
        if parser is None:
            raise ValueError(f"Unsupported requirement source type: {source.suffix}")
        parsed, report = parser(source)
        requirements.extend(parsed)
        reports.append(asdict(report))
    return requirements, reports


def parse_inline_requirements(requirements_text: list[str]) -> list[Requirement]:
    """Normalize user-entered requirement lines while retaining an explicit inline provenance."""
    parsed: list[Requirement] = []
    for index, raw_text in enumerate(requirements_text, start=1):
        match = IDENTIFIER_LINE_PATTERN.match(raw_text.strip())
        requirement = _build_requirement(
            identifier=match.group("identifier") if match else None,
            text=match.group("text") if match else raw_text,
            source_path=Path("<inline-user-input>"),
            source_type="inline",
            location=f"entry {index}",
        )
        if requirement is not None:
            parsed.append(requirement)
    return parsed