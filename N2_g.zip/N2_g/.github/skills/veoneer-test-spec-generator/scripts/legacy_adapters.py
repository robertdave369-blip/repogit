"""Compatibility adapters for the two reviewed legacy Veoneer Excel scripts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, cast

import openpyxl
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter


def _text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _is_step_number(value: Any) -> bool:
    if isinstance(value, (int, float)):
        return True
    return isinstance(value, str) and value.strip().isdigit()


def excel_to_testcase_dict(excel_path: str | Path, *, sheet_name: str | None = None) -> list[dict[str, Any]]:
    """Read either known legacy layout without relying on fixed positional columns."""
    source = Path(excel_path).expanduser().resolve()
    workbook = openpyxl.load_workbook(source, data_only=True)
    try:
        worksheet = workbook[sheet_name] if sheet_name else workbook.active
        if worksheet is None or not hasattr(worksheet, "iter_rows"):
            raise ValueError("The selected workbook sheet is not a worksheet.")
        worksheet = cast(Any, worksheet)
        headers = ["" if cell.value is None else str(cell.value).strip() for cell in worksheet[1]]
        indexes = {header: index for index, header in enumerate(headers) if header}
        six_column_layout = {"Sno", "Test Case Name", "Test Case Description", "Step No", "Test Step", "Expected Observation"}
        if six_column_layout.issubset(indexes):
            return _read_six_column_layout(worksheet, indexes)
        return _read_title_step_layout(worksheet)
    finally:
        workbook.close()


def _read_six_column_layout(
    worksheet: Any,
    indexes: dict[str, int],
) -> list[dict[str, Any]]:
    cases: list[dict[str, Any]] = []
    active_case: dict[str, Any] | None = None
    for row in worksheet.iter_rows(min_row=2, values_only=True):
        name = _text(row[indexes["Test Case Name"]] if indexes["Test Case Name"] < len(row) else None)
        description = _text(row[indexes["Test Case Description"]] if indexes["Test Case Description"] < len(row) else None)
        step_number = row[indexes["Step No"]] if indexes["Step No"] < len(row) else None
        step_action = _text(row[indexes["Test Step"]] if indexes["Test Step"] < len(row) else None)
        expected = _text(row[indexes["Expected Observation"]] if indexes["Expected Observation"] < len(row) else None)
        if name:
            if active_case is not None:
                cases.append(active_case)
            active_case = {
                "Sno": row[indexes["Sno"]] if indexes["Sno"] < len(row) else None,
                "Test Case Name": name,
                "Test Case Description": description or "",
                "Steps": [],
            }
        if active_case is not None and (step_action or expected):
            active_case["Steps"].append([str(step_number or len(active_case["Steps"]) + 1), step_action or "", expected or ""])
    if active_case is not None:
        cases.append(active_case)
    return cases


def _read_title_step_layout(worksheet: Any) -> list[dict[str, Any]]:
    """Read the legacy writer's title-in-column-B and step-in-columns-B:D layout."""
    cases: list[dict[str, Any]] = []
    active_case: dict[str, Any] | None = None
    for row in worksheet.iter_rows(min_row=2, values_only=True):
        column_b = row[1] if len(row) > 1 else None
        column_c = row[2] if len(row) > 2 else None
        column_d = row[3] if len(row) > 3 else None
        if _text(column_b) and not _is_step_number(column_b):
            if active_case is not None:
                cases.append(active_case)
            active_case = {
                "Sno": len(cases) + 1,
                "Test Case Name": _text(column_b),
                "Test Case Description": _text(column_c) or "",
                "Steps": [],
            }
            continue
        if active_case is not None and (_text(column_c) or _text(column_d)):
            active_case["Steps"].append([str(column_b or len(active_case["Steps"]) + 1), _text(column_c) or "", _text(column_d) or ""])
    if active_case is not None:
        cases.append(active_case)
    return cases


def write_legacy_title_step_workbook(
    test_cases: list[dict[str, Any]],
    destination_path: str | Path,
    *,
    sheet_name: str = "EDR Test Spec",
    overwrite: bool = False,
) -> Path:
    """Write the established legacy layout without a hard-coded destination or import-time side effect."""
    destination = Path(destination_path).expanduser().resolve()
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite existing output: {destination}")
    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    if worksheet is None or not hasattr(worksheet, "cell"):
        raise RuntimeError("openpyxl did not create a writable worksheet.")
    worksheet = cast(Any, worksheet)
    worksheet.title = sheet_name
    worksheet.append(["Test Case Name", "Step No", "Test Step", "Expected Observation"])
    row_number = 2
    for test_case in test_cases:
        name = _text(test_case.get("Test Case Name"))
        if name is None:
            raise ValueError("Every legacy test case requires 'Test Case Name'.")
        worksheet.cell(row=row_number, column=2, value=name)
        worksheet.cell(row=row_number, column=3, value=_text(test_case.get("Test Case Description")) or "")
        worksheet.cell(row=row_number, column=2).alignment = Alignment(wrap_text=True, vertical="top")
        worksheet.cell(row=row_number, column=3).alignment = Alignment(wrap_text=True, vertical="top")
        for step_number, step in enumerate(test_case.get("Steps", []), start=1):
            if len(step) != 3:
                raise ValueError(f"Legacy test case '{name}' contains a step that does not have three values.")
            row_number += 1
            number, action, expected = step
            worksheet.cell(row=row_number, column=2, value=str(number or step_number))
            worksheet.cell(row=row_number, column=3, value=_text(action) or "")
            worksheet.cell(row=row_number, column=4, value=_text(expected) or "")
            for column in (2, 3, 4):
                worksheet.cell(row=row_number, column=column).alignment = Alignment(wrap_text=True, vertical="top")
        row_number += 1
    for column_index in range(1, worksheet.max_column + 1):
        column_letter = get_column_letter(column_index)
        maximum = max(
            (len(str(worksheet.cell(row=row_index, column=column_index).value or "")) for row_index in range(1, worksheet.max_row + 1)),
            default=0,
        )
        worksheet.column_dimensions[column_letter].width = min(maximum + 2, 100)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f"{destination.stem}.tmp{destination.suffix}")
    workbook.save(temporary)
    workbook.close()
    temporary.replace(destination)
    return destination


def _load_test_cases_json(path: str | Path) -> list[dict[str, Any]]:
    payload = json.loads(Path(path).expanduser().resolve().read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        payload = payload.get("test_cases", payload.get("Test Cases", []))
    if not isinstance(payload, list):
        raise ValueError("Legacy writer input must be a JSON list or an object containing 'test_cases'.")
    return payload


def legacy_writer_main() -> int:
    parser = argparse.ArgumentParser(description="Write a legacy Veoneer title/step workbook from JSON test cases.")
    parser.add_argument("input_json", help="JSON list of legacy test-case dictionaries")
    parser.add_argument("output", help="New .xlsx output path")
    parser.add_argument("--sheet", default="EDR Test Spec", help="Output worksheet title")
    parser.add_argument("--overwrite", action="store_true", help="Allow replacing an existing output file")
    args = parser.parse_args()
    write_legacy_title_step_workbook(
        _load_test_cases_json(args.input_json),
        args.output,
        sheet_name=args.sheet,
        overwrite=args.overwrite,
    )
    return 0


def legacy_reader_main() -> int:
    parser = argparse.ArgumentParser(description="Read a legacy Veoneer workbook into a JSON test-case list.")
    parser.add_argument("input", help="Legacy .xlsx workbook")
    parser.add_argument("--sheet", help="Worksheet name; defaults to the active sheet")
    parser.add_argument("--output", help="Optional JSON output path")
    args = parser.parse_args()
    test_cases = excel_to_testcase_dict(args.input, sheet_name=args.sheet)
    output = json.dumps(test_cases, indent=2, ensure_ascii=True)
    if args.output:
        destination = Path(args.output).expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(output + "\n", encoding="utf-8")
    else:
        print(output)
    return 0