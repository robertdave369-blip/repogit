"""Profile-driven reader and renderer for the supplied Veoneer workbook contract."""

from __future__ import annotations

import copy
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import openpyxl
from openpyxl.utils.cell import get_column_letter, range_boundaries

from models import TestCase, TestSpecification, TestStep
from sanitize import sha256_file


DEFAULT_PROFILE_PATH = Path(__file__).resolve().parents[1] / "config" / "template_profile.json"
NUMERIC_IDENTIFIER_PATTERN = re.compile(r"^\d+$")


@dataclass(slots=True)
class TemplateInspection:
    """Observed template structure and profile validation findings."""

    template_path: str
    template_sha256: str
    export_sheet: str
    headers: list[str]
    allowed_values: dict[str, list[str]]
    max_validated_row: int | None
    issues: list[str]


def load_profile(profile_path: str | Path | None = None) -> dict[str, Any]:
    """Load the versioned, observed workbook profile."""
    path = Path(profile_path).expanduser().resolve() if profile_path else DEFAULT_PROFILE_PATH
    return json.loads(path.read_text(encoding="utf-8"))


def _headers(worksheet: openpyxl.worksheet.worksheet.Worksheet, header_row: int) -> list[str]:
    return ["" if cell.value is None else str(cell.value) for cell in worksheet[header_row]]


def _read_choice_values(workbook: openpyxl.Workbook, profile: dict[str, Any]) -> dict[str, list[str]]:
    values = {field: list(choices) for field, choices in profile["validation_values"].items()}
    for field, source in profile.get("dynamic_validation_values", {}).items():
        worksheet = workbook[source["source_sheet"]]
        min_column, min_row, max_column, max_row = range_boundaries(source["source_range"])
        choices = []
        for row in worksheet.iter_rows(
            min_row=min_row,
            max_row=max_row,
            min_col=min_column,
            max_col=max_column,
            values_only=True,
        ):
            for value in row:
                if value is not None and str(value).strip():
                    choices.append(str(value).strip())
        values[field] = choices
    return values


def _maximum_validation_row(worksheet: openpyxl.worksheet.worksheet.Worksheet) -> int | None:
    maximum: int | None = None
    if not worksheet.data_validations:
        return maximum
    for validation in worksheet.data_validations.dataValidation:
        for cell_range in validation.sqref.ranges:
            _, _, _, max_row = range_boundaries(str(cell_range))
            maximum = max(maximum or max_row, max_row)
    return maximum


def inspect_template(template_path: str | Path, profile: dict[str, Any] | None = None) -> TemplateInspection:
    """Validate only the contract that is directly observable in the supplied template."""
    template = Path(template_path).expanduser().resolve()
    profile = profile or load_profile()
    workbook = openpyxl.load_workbook(template, data_only=False, keep_vba=template.suffix.lower() == ".xlsm")
    issues: list[str] = []
    try:
        workbook_profile = profile["workbook"]
        export_sheet = workbook_profile["export_sheet"]
        choice_values_sheet = workbook_profile["choice_values_sheet"]
        if export_sheet not in workbook.sheetnames:
            issues.append(f"Missing required worksheet: {export_sheet}")
            return TemplateInspection(
                template_path=str(template),
                template_sha256=sha256_file(template),
                export_sheet=export_sheet,
                headers=[],
                allowed_values={},
                max_validated_row=None,
                issues=issues,
            )
        if choice_values_sheet not in workbook.sheetnames:
            issues.append(f"Missing required worksheet: {choice_values_sheet}")
        elif workbook[choice_values_sheet].sheet_state != "hidden":
            issues.append(f"Expected hidden worksheet is visible: {choice_values_sheet}")
        worksheet = workbook[export_sheet]
        observed_headers = _headers(worksheet, workbook_profile["header_row"])
        expected_headers = workbook_profile["header_order"]
        if observed_headers[: len(expected_headers)] != expected_headers:
            issues.append("Export header order does not match the observed template profile.")
        allowed_values = _read_choice_values(workbook, profile) if not issues else {}
        return TemplateInspection(
            template_path=str(template),
            template_sha256=sha256_file(template),
            export_sheet=export_sheet,
            headers=observed_headers,
            allowed_values=allowed_values,
            max_validated_row=_maximum_validation_row(worksheet),
            issues=issues,
        )
    finally:
        workbook.close()


def format_traceability(requirement_ids: list[str], profile: dict[str, Any]) -> tuple[str | None, list[str]]:
    """Serialize verified numeric Codebeamer IDs while reporting unresolved references."""
    traceability = profile["traceability"]
    formatted: list[str] = []
    unresolved: list[str] = []
    for raw_identifier in requirement_ids:
        identifier = str(raw_identifier).strip()
        if NUMERIC_IDENTIFIER_PATTERN.fullmatch(identifier):
            formatted.append(traceability["codebeamer_reference_format"].replace("<trimmed ID>", identifier))
        else:
            unresolved.append(identifier)
    return (traceability["separator"].join(formatted) or None, unresolved)


def _field_values(test_case: TestCase, profile: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    traceability, unresolved = format_traceability(test_case.requirement_ids, profile)
    return (
        {
            "ID": test_case.artifact_id,
            "Priority": test_case.priority,
            "Name": test_case.name,
            "Description": test_case.description,
            "Pre-Action": test_case.pre_action,
            "Post-Action": test_case.post_action,
            "Test Parameters": None,
            "Verifies": traceability,
            "Status": test_case.status,
            "Type": test_case.item_type,
            "_Project": test_case.project,
            "Reviewer(s)": test_case.reviewer,
            "_LatestResult": test_case.latest_result,
            "_Original_Id": test_case.original_id,
            "Referenced Reviews": test_case.referenced_reviews,
            "_ScriptPath": test_case.script_path,
            "_TestType": test_case.test_type,
            "_VerificationMethod": test_case.verification_method,
            "_TestTechnique": test_case.methodology.primary_technique,
        },
        unresolved,
    )


def _step_values(step: TestStep) -> dict[str, Any]:
    return {
        "Test Steps.Action": step.action,
        "Test Steps.Expected result": step.expected_result,
        "Test Steps.Critical": None if step.critical is None else str(step.critical).lower(),
        "Test Steps.Id": step.identifier,
    }


def _copy_row_style(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    source_row: int,
    destination_row: int,
    column_count: int,
) -> None:
    for column_index in range(1, column_count + 1):
        source = worksheet.cell(source_row, column_index)
        destination = worksheet.cell(destination_row, column_index)
        if source.has_style:
            destination._style = copy.copy(source._style)
        if source.number_format:
            destination.number_format = source.number_format
    if source_row in worksheet.row_dimensions and worksheet.row_dimensions[source_row].height:
        worksheet.row_dimensions[destination_row].height = worksheet.row_dimensions[source_row].height


def _capture_row_style(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    source_row: int,
    column_count: int,
) -> tuple[list[tuple[Any, str]], float | None]:
    cells = [
        (copy.copy(worksheet.cell(source_row, column_index)._style), worksheet.cell(source_row, column_index).number_format)
        for column_index in range(1, column_count + 1)
    ]
    height = worksheet.row_dimensions[source_row].height if source_row in worksheet.row_dimensions else None
    return cells, height


def _apply_row_style(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    snapshot: tuple[list[tuple[Any, str]], float | None],
    destination_row: int,
) -> None:
    cells, height = snapshot
    for column_index, (style, number_format) in enumerate(cells, start=1):
        destination = worksheet.cell(destination_row, column_index)
        if style:
            destination._style = copy.copy(style)
        if number_format:
            destination.number_format = number_format
    if height:
        worksheet.row_dimensions[destination_row].height = height


def _write_literal(cell: openpyxl.cell.cell.Cell, value: Any) -> None:
    if value is None:
        return
    cell.value = value
    if isinstance(value, str) and value.startswith("="):
        cell.data_type = "s"


def _extend_data_validations(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    *,
    first_data_row: int,
    final_row: int,
) -> None:
    if not worksheet.data_validations:
        return
    for validation in worksheet.data_validations.dataValidation:
        updated_ranges = []
        for cell_range in validation.sqref.ranges:
            min_column, min_row, max_column, max_row = range_boundaries(str(cell_range))
            if min_row == first_data_row and final_row > max_row:
                start = f"{get_column_letter(min_column)}{min_row}"
                end = f"{get_column_letter(max_column)}{final_row}"
                updated_ranges.append(f"{start}:{end}")
            else:
                updated_ranges.append(str(cell_range))
        validation.sqref = " ".join(updated_ranges)


def render_specification(
    specification: TestSpecification,
    *,
    template_path: str | Path,
    destination_path: str | Path,
    write_mode: str = "append",
    profile: dict[str, Any] | None = None,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Copy a validated template and flatten generated cases into export/continuation rows."""
    profile = profile or load_profile()
    template = Path(template_path).expanduser().resolve()
    destination = Path(destination_path).expanduser().resolve()
    if template == destination:
        raise ValueError("Generated output must use a different path from the template.")
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite existing output: {destination}")
    if write_mode not in {"append", "replace_data"}:
        raise ValueError("write_mode must be 'append' or 'replace_data'.")

    inspection = inspect_template(template, profile)
    if inspection.issues:
        raise ValueError("Invalid template: " + "; ".join(inspection.issues))
    workbook = openpyxl.load_workbook(template, data_only=False, keep_vba=template.suffix.lower() == ".xlsm")
    write_warnings: list[str] = []
    try:
        workbook_profile = profile["workbook"]
        worksheet = workbook[workbook_profile["export_sheet"]]
        headers = _headers(worksheet, workbook_profile["header_row"])
        header_indexes = {header: index + 1 for index, header in enumerate(headers) if header}
        first_data_row = workbook_profile["first_data_row"]
        primary_style_row = first_data_row
        continuation_style_row = min(first_data_row + 1, worksheet.max_row)
        primary_style = _capture_row_style(worksheet, primary_style_row, len(headers))
        continuation_style = _capture_row_style(worksheet, continuation_style_row, len(headers))
        if write_mode == "replace_data" and worksheet.max_row >= first_data_row:
            worksheet.delete_rows(first_data_row, worksheet.max_row - first_data_row + 1)
        current_row = worksheet.max_row + 1 if write_mode == "append" else first_data_row
        written_rows = 0

        for test_case in specification.test_cases:
            if not test_case.steps:
                raise ValueError(f"Test case '{test_case.name}' has no test steps.")
            case_fields, unresolved = _field_values(test_case, profile)
            if unresolved:
                write_warnings.append(
                    f"{test_case.name}: unresolved traceability identifiers were not written: {', '.join(unresolved)}"
                )
            for step_index, step in enumerate(test_case.steps):
                if write_mode == "replace_data":
                    _apply_row_style(worksheet, primary_style if step_index == 0 else continuation_style, current_row)
                else:
                    sample_row = primary_style_row if step_index == 0 else continuation_style_row
                    _copy_row_style(worksheet, sample_row, current_row, len(headers))
                row_values = _step_values(step)
                if step_index == 0:
                    row_values = {**case_fields, **row_values}
                for header, value in row_values.items():
                    if header in header_indexes:
                        _write_literal(worksheet.cell(current_row, header_indexes[header]), value)
                current_row += 1
                written_rows += 1

        _extend_data_validations(
            worksheet,
            first_data_row=first_data_row,
            final_row=max(first_data_row, current_row - 1),
        )
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(f"{destination.stem}.tmp{destination.suffix}")
        workbook.save(temporary)
        temporary.replace(destination)
    finally:
        workbook.close()
    return {
        "template_path": str(template),
        "template_sha256": inspection.template_sha256,
        "output_path": str(destination),
        "output_sha256": sha256_file(destination),
        "write_mode": write_mode,
        "test_cases": len(specification.test_cases),
        "written_rows": written_rows,
        "warnings": write_warnings,
        "template_features_preserved": profile["workbook"]["template_features_to_preserve"],
    }


def read_export_cases(
    workbook_path: str | Path,
    profile: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Read primary and continuation export rows back into a simple test-case representation."""
    profile = profile or load_profile()
    source = Path(workbook_path).expanduser().resolve()
    workbook_profile = profile["workbook"]
    workbook = openpyxl.load_workbook(source, read_only=True, data_only=False, keep_vba=source.suffix.lower() == ".xlsm")
    try:
        worksheet = workbook[workbook_profile["export_sheet"]]
        headers = _headers(worksheet, workbook_profile["header_row"])
        header_indexes = {header: index for index, header in enumerate(headers) if header}
        cases: list[dict[str, Any]] = []
        current_case: dict[str, Any] | None = None
        for row_number, row in enumerate(
            worksheet.iter_rows(min_row=workbook_profile["first_data_row"], values_only=True),
            start=workbook_profile["first_data_row"],
        ):
            values = {header: row[index] if index < len(row) else None for header, index in header_indexes.items()}
            name = values.get("Name")
            if name not in {None, ""}:
                if current_case is not None:
                    cases.append(current_case)
                current_case = {
                    "row": row_number,
                    "fields": values,
                    "steps": [],
                }
            if current_case is None:
                continue
            if values.get("Test Steps.Action") not in {None, ""} or values.get("Test Steps.Expected result") not in {None, ""}:
                current_case["steps"].append(
                    {
                        "row": row_number,
                        "action": values.get("Test Steps.Action"),
                        "expected_result": values.get("Test Steps.Expected result"),
                        "critical": values.get("Test Steps.Critical"),
                        "identifier": values.get("Test Steps.Id"),
                    }
                )
        if current_case is not None:
            cases.append(current_case)
        return cases
    finally:
        workbook.close()


def inspection_as_dict(inspection: TemplateInspection) -> dict[str, Any]:
    """Provide a JSON-compatible inspection report for CLI and tests."""
    return asdict(inspection)