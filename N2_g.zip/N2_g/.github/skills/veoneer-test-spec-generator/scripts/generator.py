"""Generate review-ready Veoneer test cases from source-backed requirements."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from methodology import Scenario, derive_scenarios, select_methodology
from models import Requirement, TestCase, TestSpecification, TestStep


@dataclass(slots=True)
class GenerationResult:
    """Generated content and visible analysis gaps for engineering review."""

    specification: TestSpecification
    excluded_requirements: list[str] = field(default_factory=list)


def _safe_name_fragment(value: str, limit: int = 48) -> str:
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")
    return (normalized or "Requirement")[:limit]


def _requirement_label(requirement: Requirement) -> str:
    return requirement.identifier or f"unidentified requirement at {requirement.provenance.location}"


def _requirement_ids(requirement: Requirement) -> list[str]:
    if requirement.identifier is None:
        return []
    return [identifier.strip() for identifier in requirement.identifier.split(",") if identifier.strip()]


def _scenario_steps(requirement: Requirement, scenario: Scenario) -> list[TestStep]:
    criterion = requirement.acceptance_criteria[0] if requirement.acceptance_criteria else requirement.text
    base_steps = [
        TestStep(
            action=f"Establish the preconditions and configuration stated for {_requirement_label(requirement)}.",
            expected_result="The required preconditions are recorded and the test environment is ready.",
        )
    ]
    if scenario.identifier == "boundary":
        base_steps.append(
            TestStep(
                action=(
                    "Exercise each source-defined boundary immediately below, at, and immediately above the stated limit; "
                    "do not invent a value when the requirement omits one."
                ),
                expected_result=f"Observed boundary behavior satisfies the acceptance criterion: {criterion}",
            )
        )
    elif scenario.identifier == "fault_recovery":
        base_steps.append(
            TestStep(
                action=(
                    "Apply only the fault, invalid input, or recovery condition explicitly described by the requirement, "
                    "then restore the stated normal condition."
                ),
                expected_result=f"Fault handling and recovery satisfy the acceptance criterion: {criterion}",
            )
        )
    elif scenario.identifier == "transition":
        base_steps.append(
            TestStep(
                action="Record the initial state, apply the stated transition trigger, and observe the resulting state.",
                expected_result=f"The required state transition satisfies the acceptance criterion: {criterion}",
            )
        )
    elif scenario.identifier == "decision_outcomes":
        base_steps.append(
            TestStep(
                action="Exercise the distinct condition combinations explicitly stated by the requirement.",
                expected_result=f"Each stated decision outcome satisfies the acceptance criterion: {criterion}",
            )
        )
    else:
        base_steps.append(
            TestStep(
                action=f"Apply the input, action, and state stated by the requirement: {criterion}",
                expected_result=f"The observed behavior satisfies the acceptance criterion: {criterion}",
            )
        )
    base_steps.append(
        TestStep(
            action="Capture the observed result and link the evidence to the source requirement location.",
            expected_result="The result is reproducible, attributable to the requirement, and contains no unresolved deviation.",
        )
    )
    return base_steps


def _default_priority(requirement: Requirement) -> str:
    source_priority = (requirement.priority or "").strip()
    return source_priority if source_priority in {"Lowest", "Low", "Normal", "High", "Highest"} else "Normal"


def _generate_case(requirement: Requirement, scenario: Scenario, allowed_techniques: list[str] | None) -> TestCase:
    methodology = select_methodology(requirement, allowed_techniques=allowed_techniques)
    name_source = requirement.title or requirement.identifier or requirement.text
    name = f"TS_{_safe_name_fragment(name_source)}_{scenario.identifier}"
    criterion = requirement.acceptance_criteria[0] if requirement.acceptance_criteria else requirement.text
    description = (
        f"Objective: verify {_requirement_label(requirement)}. "
        f"Acceptance criterion: {criterion} "
        f"Scenario: {scenario.label}. "
        f"Test methodology: {methodology.primary_technique or 'template technique review required'}. "
        f"Rationale: {methodology.rationale}"
    )
    notes = [scenario.rationale]
    if requirement.identifier is None:
        notes.append("A verified Codebeamer artifact ID is required before import.")
    if requirement.status is None:
        notes.append("Requirement approval status was unavailable in the input source.")
    return TestCase(
        name=name,
        description=description,
        steps=_scenario_steps(requirement, scenario),
        methodology=methodology,
        requirement_ids=_requirement_ids(requirement),
        pre_action=f"Confirm the environment required by {_requirement_label(requirement)}.",
        post_action="Restore the test environment and retain the captured evidence.",
        priority=_default_priority(requirement),
        status="INIT",
        item_type="Functional",
        test_type="Manual",
        verification_method="Requirements-based test",
        source_requirements=[requirement.provenance],
        generation_notes=notes,
    )


def generate_specification(
    requirements: list[Requirement],
    *,
    title: str,
    allowed_techniques: list[str] | None = None,
    approved_only: bool = True,
) -> GenerationResult:
    """Generate a prioritized, non-duplicative review draft without inventing traceability."""
    test_cases: list[TestCase] = []
    coverage_gaps: list[str] = []
    excluded_requirements: list[str] = []
    seen_case_names: set[str] = set()

    for requirement in requirements:
        label = _requirement_label(requirement)
        if "struck_content_present" in requirement.warnings:
            coverage_gaps.append(f"Excluded {label}: source content is marked [STRUCK:].")
            excluded_requirements.append(label)
            continue
        if approved_only and requirement.status is not None and not requirement.is_approved:
            coverage_gaps.append(f"Excluded {label}: source status is '{requirement.status}', not Approved.")
            excluded_requirements.append(label)
            continue
        if requirement.identifier is None:
            coverage_gaps.append(f"{label}: verified Codebeamer artifact ID is unavailable.")
        if requirement.status is None:
            coverage_gaps.append(f"{label}: approval evidence unavailable in the source.")

        for scenario in derive_scenarios(requirement):
            test_case = _generate_case(requirement, scenario, allowed_techniques)
            base_name = test_case.name
            duplicate_index = 2
            while test_case.name in seen_case_names:
                test_case.name = f"{base_name}_{duplicate_index}"
                duplicate_index += 1
            seen_case_names.add(test_case.name)
            test_cases.append(test_case)

    test_cases.sort(key=lambda case: ({"Highest": 0, "High": 1, "Normal": 2, "Low": 3, "Lowest": 4}.get(case.priority or "Normal", 5), case.name))
    specification = TestSpecification(
        title=title,
        test_cases=test_cases,
        source_paths=sorted({requirement.provenance.source_path for requirement in requirements}),
        assumptions=[
            "Generated cases are review drafts until requirement approval, project configuration, and measurable stimuli are verified.",
            "Codebeamer importer acceptance and artifact-ID generation rules are evidence gaps unless supplied externally.",
        ],
        coverage_gaps=coverage_gaps,
    )
    return GenerationResult(specification=specification, excluded_requirements=excluded_requirements)