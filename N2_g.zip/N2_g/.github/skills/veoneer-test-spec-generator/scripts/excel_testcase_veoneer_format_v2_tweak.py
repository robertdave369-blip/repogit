"""Enhanced, import-safe replacement for the reviewed legacy writer script."""

from __future__ import annotations

from legacy_adapters import legacy_writer_main, write_legacy_title_step_workbook


def create_legacy_workbook(test_cases, output_path, *, sheet_name="EDR Test Spec", overwrite=False):
    """Compatibility API replacing the legacy script's import-time workbook creation."""
    return write_legacy_title_step_workbook(test_cases, output_path, sheet_name=sheet_name, overwrite=overwrite)


if __name__ == "__main__":
    raise SystemExit(legacy_writer_main())