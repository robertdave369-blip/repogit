"""Enhanced, header-driven replacement for the reviewed legacy reader script."""

from __future__ import annotations

from legacy_adapters import excel_to_testcase_dict, legacy_reader_main


if __name__ == "__main__":
    raise SystemExit(legacy_reader_main())