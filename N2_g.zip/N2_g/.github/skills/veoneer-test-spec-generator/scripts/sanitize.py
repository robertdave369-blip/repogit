"""Non-destructive sanitization for requirement and template workbook content."""

from __future__ import annotations

import hashlib
import html
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import openpyxl


CODEBEAMER_STYLE_PATTERN = re.compile(
    r"%%\((?P<style>[^)]*)\)(?P<content>.*?)%!", re.IGNORECASE | re.DOTALL
)
CODEBEAMER_ESCAPES = {
    "~_": "_",
    "~-": "-",
    "~,": ",",
    "~'": "'",
    "~>": ">",
    "~<": "<",
    "~[": "[",
    "~]": "]",
}
KNOWN_HTML_TAGS = (
    "a|b|body|br|div|em|font|html|i|li|ol|p|span|strong|style|table|tbody|td|th|thead|tr|u|ul"
)
HTML_LINK_PATTERN = re.compile(
    r"<a\b[^>]*?\bhref\s*=\s*(['\"])(?P<href>.*?)\1[^>]*>(?P<label>.*?)</a\s*>",
    re.IGNORECASE | re.DOTALL,
)
KNOWN_HTML_TAG_PATTERN = re.compile(
    rf"</?(?:{KNOWN_HTML_TAGS})\b[^>]*>", re.IGNORECASE | re.DOTALL
)
TRACEABILITY_TOKEN_PATTERN = re.compile(r"\[(?:ISSUE|TRACKER):[^\]]+\]", re.IGNORECASE)
NUMERIC_ID_PATTERN = re.compile(r"\b\d{6,}\b")


@dataclass(slots=True)
class SanitizedText:
    """Sanitized text accompanied by an auditable list of transformations."""

    text: str
    changes: list[str]


def sha256_file(path: str | Path) -> str:
    """Return a streaming SHA-256 digest for an input or generated artifact."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _strip_control_characters(text: str) -> tuple[str, bool]:
    allowed_controls = {"\t", "\n", "\r"}
    cleaned = "".join(
        character
        for character in text
        if character in allowed_controls or (ord(character) >= 32 and ord(character) not in {0xFFFE, 0xFFFF})
    )
    return cleaned, cleaned != text


def _decode_codebeamer_styles(text: str, changes: list[str]) -> str:
    def replace_style(match: re.Match[str]) -> str:
        style = match.group("style").casefold()
        content = match.group("content")
        if "line-through" in style or "linethrough" in style:
            changes.append("codebeamer_strikethrough_preserved")
            return f"[STRUCK: {content.strip()}]"
        changes.append("codebeamer_style_wrapper_removed")
        return content

    return CODEBEAMER_STYLE_PATTERN.sub(replace_style, text)


def _strip_known_html(text: str, changes: list[str]) -> str:
    def replace_link(match: re.Match[str]) -> str:
        label = KNOWN_HTML_TAG_PATTERN.sub("", match.group("label"))
        href = html.unescape(match.group("href").strip())
        changes.append("html_link_preserved")
        return f"{label} [URL:{href}]"

    result = HTML_LINK_PATTERN.sub(replace_link, text)
    result, count = KNOWN_HTML_TAG_PATTERN.subn("", result)
    if count:
        changes.append("html_tags_removed")
    return result


def sanitize_text(value: Any) -> SanitizedText:
    """Remove presentation noise without changing engineering identifiers or tokens."""
    if not isinstance(value, str):
        return SanitizedText(text="" if value is None else str(value), changes=[])

    changes: list[str] = []
    text = value.replace("\r\n", "\n").replace("\r", "\n")
    if text != value:
        changes.append("line_endings_normalized")

    text = _decode_codebeamer_styles(text, changes)
    for escaped, replacement in CODEBEAMER_ESCAPES.items():
        if escaped in text:
            text = text.replace(escaped, replacement)
            changes.append("codebeamer_escape_decoded")
    text = _strip_known_html(text, changes)
    unescaped = html.unescape(text)
    if unescaped != text:
        text = unescaped
        changes.append("html_entities_decoded")
    without_invisible = text.replace("\ufeff", "").replace("\u200b", "").replace("\u00ad", "")
    if without_invisible != text:
        text = without_invisible
        changes.append("invisible_formatting_removed")
    text, controls_removed = _strip_control_characters(text)
    if controls_removed:
        changes.append("invalid_control_characters_removed")

    normalized_lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]
    normalized = "\n".join(normalized_lines)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized).strip()
    if normalized != text:
        text = normalized
        changes.append("whitespace_normalized")

    return SanitizedText(text=text, changes=list(dict.fromkeys(changes)))


def _collect_preservation_tokens(workbook: openpyxl.Workbook) -> set[str]:
    tokens: set[str] = set()
    for worksheet in workbook.worksheets:
        for row in worksheet.iter_rows():
            for cell in row:
                if not isinstance(cell.value, str):
                    continue
                tokens.update(TRACEABILITY_TOKEN_PATTERN.findall(cell.value))
                tokens.update(NUMERIC_ID_PATTERN.findall(cell.value))
    return tokens


def sanitize_workbook_copy(
    source_path: str | Path,
    destination_path: str | Path,
    *,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Create a cleaned copy while preserving workbook structure and source evidence."""
    source = Path(source_path).expanduser().resolve()
    destination = Path(destination_path).expanduser().resolve()
    if source == destination:
        raise ValueError("The cleaned template must be written to a different path than the source workbook.")
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError("Only .xlsx and .xlsm workbooks are supported.")
    if not source.is_file():
        raise FileNotFoundError(source)
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite existing output: {destination}")

    keep_vba = source.suffix.lower() == ".xlsm"
    workbook = openpyxl.load_workbook(source, data_only=False, keep_vba=keep_vba)
    source_tokens = _collect_preservation_tokens(workbook)
    changed_cells = 0
    change_counts: dict[str, int] = {}
    sheet_summaries: list[dict[str, Any]] = []
    try:
        for worksheet in workbook.worksheets:
            sheet_changed = 0
            for row in worksheet.iter_rows():
                for cell in row:
                    if not isinstance(cell.value, str) or cell.data_type == "f":
                        continue
                    sanitized = sanitize_text(cell.value)
                    if sanitized.text == cell.value:
                        continue
                    cell.value = sanitized.text
                    cell.data_type = "s"
                    changed_cells += 1
                    sheet_changed += 1
                    for change in sanitized.changes:
                        change_counts[change] = change_counts.get(change, 0) + 1
            sheet_summaries.append(
                {
                    "sheet": worksheet.title,
                    "state": worksheet.sheet_state,
                    "changed_cells": sheet_changed,
                    "max_row": worksheet.max_row,
                    "max_column": worksheet.max_column,
                }
            )

        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(f"{destination.stem}.tmp{destination.suffix}")
        workbook.save(temporary)
        temporary.replace(destination)
    finally:
        workbook.close()

    cleaned_workbook = openpyxl.load_workbook(destination, read_only=True, data_only=False, keep_vba=keep_vba)
    try:
        cleaned_tokens = _collect_preservation_tokens(cleaned_workbook)
    finally:
        cleaned_workbook.close()
    missing_tokens = sorted(source_tokens - cleaned_tokens)
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "operation": "non_destructive_template_sanitization",
        "source_path": str(source),
        "source_sha256": sha256_file(source),
        "destination_path": str(destination),
        "destination_sha256": sha256_file(destination),
        "source_modified": False,
        "changed_cells": changed_cells,
        "change_counts": change_counts,
        "sheets": sheet_summaries,
        "preservation": {
            "source_traceability_and_numeric_tokens": len(source_tokens),
            "missing_tokens": missing_tokens,
            "passed": not missing_tokens,
        },
        "confidence": "High",
        "limitations": [
            "Only presentation-oriented text transformations were applied.",
            "Codebeamer importer acceptance was not executed and remains unverified.",
        ],
    }


def write_json_report(report: dict[str, Any], destination_path: str | Path) -> Path:
    """Write an auditable report atomically."""
    destination = Path(destination_path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f"{destination.name}.tmp")
    temporary.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    temporary.replace(destination)
    return destination