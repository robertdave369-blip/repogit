"""Render source-backed test cases in the reviewed V3-style Export layout with Veoneer headers."""

from __future__ import annotations

import argparse
import copy
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import openpyxl
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter

from generator import generate_specification
from models import TestCase, TestSpecification, ValidationIssue
from requirement_parser import parse_inline_requirements, parse_sources
from sanitize import sha256_file, write_json_report
from workbook_codec import NUMERIC_IDENTIFIER_PATTERN, format_traceability, load_profile


LEGACY_TEMPLATE_HEADERS = (
    "Priority",
    "Name",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
)
LEGACY_EXPORT_HEADERS = (
    "ID",
    "Priority",
    "Name",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
    "Test Steps.Critical",
    "Test Parameters",
    "Verifies",
    "Status",
    "Type",
    "_Project",
    "Reviewer(s)",
    "_LatestResult",
    "_Original_Id",
    "Referenced Reviews",
    "_ScriptPath",
    "_TestType",
    "_VerificationMethod",
    "_TestTechnique",
)
STEP_HEADERS = (
    "Test Steps.Action",
    "Test Steps.Expected result",
    "Test Steps.Critical",
)
CASE_ROW_HEADERS = tuple(header for header in LEGACY_EXPORT_HEADERS if header not in STEP_HEADERS)
DEFAULT_COLUMN_WIDTHS = {
    "ID": 26,
    "Priority": 12,
    "Name": 54,
    "Description": 72,
    "Pre-Action": 44,
    "Post-Action": 44,
    "Test Steps.Action": 64,
    "Test Steps.Expected result": 64,
    "Test Steps.Critical": 18,
    "Test Parameters": 34,
    "Verifies": 34,
    "Status": 16,
    "Type": 16,
    "_Project": 20,
    "Reviewer(s)": 20,
    "_LatestResult": 20,
    "_Original_Id": 18,
    "Referenced Reviews": 24,
    "_ScriptPath": 32,
    "_TestType": 18,
    "_VerificationMethod": 28,
    "_TestTechnique": 28,
}
PRIORITY_VALUES = {"Lowest", "Low", "Normal", "High", "Highest"}
CASE_NAME_FILL = "FFF200"
DEFAULT_GROUP_NAME = "GENERATED_REQUIREMENT_TESTS"
CODEBEAMER_REFERENCE_PATTERN = re.compile(r"\[ISSUE:\d+\] - null")


@dataclass(slots=True)
class LegacyExportInspection:
    """Observed contract of a reviewed legacy Export seed or extended Veoneer profile."""

    template_path: str
    template_sha256: str
    sheet_names: list[str]
    headers: list[str]
    issues: list[str]


def _header_values(worksheet: openpyxl.worksheet.worksheet.Worksheet) -> list[str]:
    headers = ["" if cell.value is None else str(cell.value) for cell in worksheet[1]]
    while headers and not headers[-1]:
        headers.pop()
    return headers


def inspect_legacy_export_template(template_path: str | Path) -> LegacyExportInspection:
    """Check a seven-column V3 seed or an extended Veoneer-header legacy template."""
    template = Path(template_path).expanduser().resolve()
    if not template.is_file():
        raise FileNotFoundError(f"Legacy Export template is unavailable: {template}")
    workbook = openpyxl.load_workbook(template, data_only=False, keep_vba=template.suffix.lower() == ".xlsm")
    try:
        issues: list[str] = []
        if "Export" not in workbook.sheetnames:
            issues.append("Missing required worksheet: Export")
            return LegacyExportInspection(
                template_path=str(template),
                template_sha256=sha256_file(template),
                sheet_names=list(workbook.sheetnames),
                headers=[],
                issues=issues,
            )
        if "ChoiceValues" not in workbook.sheetnames:
            issues.append("Missing required worksheet: ChoiceValues")
        export = workbook["Export"]
        headers = _header_values(export)
        if headers not in (list(LEGACY_TEMPLATE_HEADERS), list(LEGACY_EXPORT_HEADERS)):
            issues.append("Export headers do not match the reviewed seven-column seed or extended Veoneer legacy profile.")
        if export.max_row < 4:
            issues.append("Template needs group, primary-case, and continuation-row style samples in rows 2 through 4.")
        return LegacyExportInspection(
            template_path=str(template),
            template_sha256=sha256_file(template),
            sheet_names=list(workbook.sheetnames),
            headers=headers,
            issues=issues,
        )
    finally:
        workbook.close()


def _ensure_veoneer_headers(worksheet: openpyxl.worksheet.worksheet.Worksheet) -> None:
    """Upgrade a reviewed seven-column seed in place while retaining its existing rows and styles."""
    headers = _header_values(worksheet)
    if headers == list(LEGACY_EXPORT_HEADERS):
        return
    if headers != list(LEGACY_TEMPLATE_HEADERS):
        raise ValueError("Cannot extend an Export sheet whose headers do not match the reviewed legacy seed.")

    original_widths = {
        header: worksheet.column_dimensions[get_column_letter(column_number)].width
        for column_number, header in enumerate(LEGACY_TEMPLATE_HEADERS, start=1)
    }
    worksheet.insert_cols(1)
    for row_number in range(1, max(worksheet.max_row, 4) + 1):
        source = worksheet.cell(row_number, 2)
        for column_number in (1, *range(9, len(LEGACY_EXPORT_HEADERS) + 1)):
            target = worksheet.cell(row_number, column_number)
            if source.has_style:
                target._style = copy.copy(source._style)
            target.number_format = source.number_format
            target.alignment = copy.copy(source.alignment)
    for column_number, header in enumerate(LEGACY_EXPORT_HEADERS, start=1):
        worksheet.cell(1, column_number).value = header
        width = original_widths.get(header) or DEFAULT_COLUMN_WIDTHS[header]
        worksheet.column_dimensions[get_column_letter(column_number)].width = width


def _capture_row_style(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    row_number: int,
) -> tuple[list[tuple[Any, str]], float | None]:
    cells = [
        (copy.copy(worksheet.cell(row_number, column_number)._style), worksheet.cell(row_number, column_number).number_format)
        for column_number in range(1, len(LEGACY_EXPORT_HEADERS) + 1)
    ]
    height = worksheet.row_dimensions[row_number].height
    return cells, height


def _apply_row_style(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    snapshot: tuple[list[tuple[Any, str]], float | None],
    row_number: int,
) -> None:
    cells, height = snapshot
    for column_number, (style, number_format) in enumerate(cells, start=1):
        cell = worksheet.cell(row_number, column_number)
        cell._style = copy.copy(style)
        cell.number_format = number_format
        alignment = copy.copy(cell.alignment)
        alignment.wrap_text = True
        alignment.vertical = "top"
        cell.alignment = alignment
    if height is not None:
        worksheet.row_dimensions[row_number].height = height


def _write_literal(cell: openpyxl.cell.cell.Cell, value: Any) -> None:
    if value is None:
        return
    cell.value = value
    if isinstance(value, str) and value.startswith("="):
        cell.data_type = "s"


def _write_row(
    worksheet: openpyxl.worksheet.worksheet.Worksheet,
    row_number: int,
    values: list[Any],
    style: tuple[list[tuple[Any, str]], float | None],
    minimum_height: float,
) -> None:
    _apply_row_style(worksheet, style, row_number)
    for column_number, value in enumerate(values, start=1):
        _write_literal(worksheet.cell(row_number, column_number), value)
    worksheet.row_dimensions[row_number].height = max(worksheet.row_dimensions[row_number].height or 0, minimum_height)


def _requirement_identifiers(test_case: TestCase) -> list[str]:
    identifiers: list[str] = []
    for raw_identifier in test_case.requirement_ids:
        for identifier in str(raw_identifier).split(","):
            normalized = identifier.strip()
            if normalized and normalized not in identifiers:
                identifiers.append(normalized)
    return identifiers


def _traceability_text(test_case: TestCase) -> str:
    identifiers = _requirement_identifiers(test_case)
    if not identifiers:
        return "Traceability: Evidence unavailable; no verified Codebeamer requirement ID was supplied."
    invalid = [identifier for identifier in identifiers if not NUMERIC_IDENTIFIER_PATTERN.fullmatch(identifier)]
    if invalid:
        return "Traceability: Evidence unavailable; unresolved requirement identifier(s): " + ", ".join(invalid) + "."
    return "Traceability: " + (_format_requirement_references(identifiers) or "Evidence unavailable.")


def _description_with_traceability(test_case: TestCase) -> str:
    identifiers = _requirement_identifiers(test_case)
    if identifiers and all(NUMERIC_IDENTIFIER_PATTERN.fullmatch(identifier) for identifier in identifiers):
        return test_case.description.strip()
    return "\n".join((test_case.description.strip(), _traceability_text(test_case)))


def _format_requirement_references(identifiers: list[str]) -> str | None:
    formatted, unresolved = format_traceability(identifiers, load_profile())
    if unresolved:
        return None
    return formatted


def _verifies_value(test_case: TestCase) -> str | None:
    return _format_requirement_references(_requirement_identifiers(test_case))


def _step_critical_value(test_case: TestCase, step_index: int) -> str | None:
    critical = test_case.steps[step_index].critical
    return None if critical is None else str(critical).lower()


def _row_values(fields: dict[str, Any]) -> list[Any]:
    return [fields.get(header) for header in LEGACY_EXPORT_HEADERS]


def _primary_case_fields(test_case: TestCase) -> dict[str, Any]:
    first_step = test_case.steps[0]
    return {
        "ID": test_case.artifact_id,
        "Priority": test_case.priority,
        "Name": test_case.name,
        "Description": _description_with_traceability(test_case),
        "Pre-Action": test_case.pre_action,
        "Post-Action": test_case.post_action,
        "Test Steps.Action": first_step.action,
        "Test Steps.Expected result": first_step.expected_result,
        "Test Steps.Critical": _step_critical_value(test_case, 0),
        "Test Parameters": None,
        "Verifies": _verifies_value(test_case),
        "Status": test_case.status,
        "Type": test_case.item_type,
        "_Project": test_case.project,
        "Reviewer(s)": test_case.reviewer,
        "_LatestResult": test_case.latest_result,
        "_Original_Id": test_case.original_id,
        "Referenced Reviews": test_case.referenced_reviews,
        "_ScriptPath": test_case.script_path,
        "_TestType": test_case.test_type,
        "_VerificationMethod": test_case.verification_method,
        "_TestTechnique": test_case.methodology.primary_technique,
    }


def _continuation_step_fields(test_case: TestCase, step_index: int) -> dict[str, Any]:
    step = test_case.steps[step_index]
    return {
        "Test Steps.Action": step.action,
        "Test Steps.Expected result": step.expected_result,
        "Test Steps.Critical": _step_critical_value(test_case, step_index),
    }


def validate_legacy_export_specification(specification: TestSpecification) -> list[ValidationIssue]:
    """Validate source-backed content before serializing it to the legacy profile."""
    issues: list[ValidationIssue] = []
    if not specification.test_cases:
        return [ValidationIssue("error", "NO_TEST_CASES", "No usable requirements produced a test case.")]
    names: set[str] = set()
    for test_case in specification.test_cases:
        location = test_case.name or "unnamed test case"
        if not test_case.name.strip():
            issues.append(ValidationIssue("error", "TEST_CASE_NAME_MISSING", "Test case name is required.", location))
        elif test_case.name in names:
            issues.append(ValidationIssue("error", "TEST_CASE_NAME_DUPLICATE", "Test case names must be unique.", location))
        names.add(test_case.name)
        if not test_case.description.strip():
            issues.append(ValidationIssue("error", "TEST_CASE_DESCRIPTION_MISSING", "Test case description is required.", location))
        if test_case.priority not in PRIORITY_VALUES:
            issues.append(
                ValidationIssue(
                    "error",
                    "PRIORITY_INVALID",
                    f"Priority must be one of {sorted(PRIORITY_VALUES)}.",
                    location,
                )
            )
        if not test_case.steps:
            issues.append(ValidationIssue("error", "TEST_STEPS_MISSING", "At least one test step is required.", location))
        for step_number, step in enumerate(test_case.steps, start=1):
            step_location = f"{location} step {step_number}"
            if not step.action.strip():
                issues.append(ValidationIssue("error", "TEST_STEP_ACTION_MISSING", "Test step action is required.", step_location))
            if not step.expected_result.strip():
                issues.append(
                    ValidationIssue("error", "TEST_STEP_EXPECTED_RESULT_MISSING", "Expected result is required.", step_location)
                )
        if not test_case.source_requirements:
            issues.append(
                ValidationIssue(
                    "error",
                    "SOURCE_PROVENANCE_MISSING",
                    "Each generated test case must retain at least one source requirement location.",
                    location,
                )
            )
        for provenance in test_case.source_requirements:
            if provenance.raw_status is None:
                issues.append(
                    ValidationIssue(
                        "warning",
                        "REQUIREMENT_APPROVAL_UNAVAILABLE",
                        "Input source did not provide an approval status; review before claiming approved-requirement coverage.",
                        location,
                    )
                )
            elif provenance.raw_status.strip().casefold() != "approved":
                issues.append(
                    ValidationIssue(
                        "warning",
                        "REQUIREMENT_NOT_APPROVED",
                        f"Input source status is '{provenance.raw_status}', not Approved.",
                        location,
                    )
                )
        if not test_case.requirement_ids:
            issues.append(
                ValidationIssue(
                    "warning",
                    "TRACEABILITY_UNRESOLVED",
                    "No verified Codebeamer requirement ID is available; the legacy description records this gap.",
                    location,
                )
            )
        for requirement_id in _requirement_identifiers(test_case):
            if not NUMERIC_IDENTIFIER_PATTERN.fullmatch(requirement_id):
                issues.append(
                    ValidationIssue(
                        "error",
                        "TRACEABILITY_IDENTIFIER_INVALID",
                        "A Codebeamer reference requires a verified numeric artifact ID.",
                        location,
                    )
                )
    return issues


def render_legacy_export_specification(
    specification: TestSpecification,
    *,
    template_path: str | Path,
    destination_path: str | Path,
    group_name: str = DEFAULT_GROUP_NAME,
    write_mode: str = "replace_data",
    overwrite: bool = False,
) -> dict[str, Any]:
    """Copy a reviewed legacy template and write group, primary, and continuation rows."""
    if not group_name.strip():
        raise ValueError("Group name must not be empty.")
    if write_mode not in {"append", "replace_data"}:
        raise ValueError("write_mode must be 'append' or 'replace_data'.")
    template = Path(template_path).expanduser().resolve()
    destination = Path(destination_path).expanduser().resolve()
    if template == destination:
        raise ValueError("Generated output must use a different path from the template.")
    if destination.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite existing output: {destination}")
    inspection = inspect_legacy_export_template(template)
    if inspection.issues:
        raise ValueError("Invalid legacy Export template: " + "; ".join(inspection.issues))

    workbook = openpyxl.load_workbook(template, data_only=False, keep_vba=template.suffix.lower() == ".xlsm")
    try:
        export = workbook["Export"]
        _ensure_veoneer_headers(export)
        group_style = _capture_row_style(export, 2)
        primary_style = _capture_row_style(export, 3)
        continuation_style = _capture_row_style(export, 4)
        if write_mode == "replace_data" and export.max_row >= 2:
            export.delete_rows(2, export.max_row - 1)
        current_row = 2 if write_mode == "replace_data" else export.max_row + 1
        _write_row(
            export,
            current_row,
            _row_values({"Priority": "Normal", "Name": group_name}),
            group_style,
            24,
        )
        current_row += 1
        written_rows = 1
        for test_case in specification.test_cases:
            if not test_case.steps:
                raise ValueError(f"Test case '{test_case.name}' has no test steps.")
            primary_height = max(145, 15 * (9 + len(test_case.description) // 145))
            _write_row(
                export,
                current_row,
                _row_values(_primary_case_fields(test_case)),
                primary_style,
                primary_height,
            )
            name_cell = export.cell(current_row, LEGACY_EXPORT_HEADERS.index("Name") + 1)
            name_cell.fill = PatternFill("solid", fgColor=CASE_NAME_FILL)
            name_font = copy.copy(name_cell.font)
            name_font.bold = True
            name_cell.font = name_font
            current_row += 1
            written_rows += 1
            for step_index in range(1, len(test_case.steps)):
                _write_row(
                    export,
                    current_row,
                    _row_values(_continuation_step_fields(test_case, step_index)),
                    continuation_style,
                    68,
                )
                current_row += 1
                written_rows += 1
        if export.auto_filter.ref:
            export.auto_filter.ref = f"A1:{get_column_letter(len(LEGACY_EXPORT_HEADERS))}{export.max_row}"
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(f"{destination.stem}.tmp{destination.suffix}")
        workbook.save(temporary)
        temporary.replace(destination)
    finally:
        workbook.close()
    return {
        "template_path": str(template),
        "template_sha256": inspection.template_sha256,
        "output_path": str(destination),
        "output_sha256": sha256_file(destination),
        "write_mode": write_mode,
        "group_name": group_name,
        "test_cases": len(specification.test_cases),
        "written_rows": written_rows,
        "template_features_preserved": [
            "worksheet names and visibility",
            "ChoiceValues content",
            "column ordering and widths",
            "freeze panes",
            "cell styles",
            "auto-filter settings",
        ],
    }


def _is_case_name_highlight(cell: openpyxl.cell.cell.Cell) -> bool:
    color = cell.fill.fgColor
    return color.type == "rgb" and bool(color.rgb) and color.rgb.upper().endswith(CASE_NAME_FILL)


def _is_valid_test_case_id(value: Any) -> bool:
    if value in {None, ""}:
        return True
    try:
        int(value)
    except (TypeError, ValueError):
        return False
    return True


def _is_valid_verifies(value: Any) -> bool:
    if value in {None, ""}:
        return True
    return all(CODEBEAMER_REFERENCE_PATTERN.fullmatch(reference) for reference in str(value).split(","))


def validate_legacy_export_workbook(
    workbook_path: str | Path,
    *,
    expected_case_names: list[str] | None = None,
    expected_case_mode: str = "exact",
    expected_test_cases: list[TestCase] | None = None,
) -> dict[str, Any]:
    """Validate primary and continuation rows in a rendered legacy Export workbook."""
    if expected_case_mode not in {"exact", "suffix"}:
        raise ValueError("expected_case_mode must be 'exact' or 'suffix'.")
    inspection = inspect_legacy_export_template(workbook_path)
    issues = [ValidationIssue("error", "TEMPLATE_CONTRACT_INVALID", message) for message in inspection.issues]
    if inspection.headers != list(LEGACY_EXPORT_HEADERS):
        issues.append(
            ValidationIssue(
                "error",
                "VEONEER_HEADERS_MISSING",
                "Rendered workbook must contain the requested extended Veoneer header set.",
            )
        )
    observed_case_names: list[str] = []
    group_names: list[str] = []
    if expected_case_names is None and expected_test_cases is not None:
        expected_case_names = [test_case.name for test_case in expected_test_cases]
    expected_name_set = set(expected_case_names or [])
    expected_cases_by_name = {test_case.name: test_case for test_case in expected_test_cases or []}
    if not issues:
        workbook = openpyxl.load_workbook(workbook_path, data_only=False, keep_vba=Path(workbook_path).suffix.lower() == ".xlsm")
        try:
            export = workbook["Export"]
            current_case: str | None = None
            step_counts: dict[str, int] = {}
            header_indexes = {header: column_number for column_number, header in enumerate(LEGACY_EXPORT_HEADERS, start=1)}
            for row_number in range(2, export.max_row + 1):
                values = {
                    header: export.cell(row_number, column_number).value
                    for header, column_number in header_indexes.items()
                }
                name = values["Name"]
                location = f"Export row {row_number}"
                if name not in {None, ""}:
                    name_text = str(name).strip()
                    if all(
                        values[header] in {None, ""}
                        for header in LEGACY_EXPORT_HEADERS
                        if header not in {"Priority", "Name"}
                    ):
                        group_names.append(name_text)
                        current_case = None
                        continue
                    current_case = name_text
                    observed_case_names.append(name_text)
                    step_counts[current_case] = 0
                    if values["Priority"] not in PRIORITY_VALUES:
                        issues.append(ValidationIssue("error", "PRIORITY_INVALID", "Primary row has an unsupported priority.", location))
                    for field_name, value in (
                        ("Description", values["Description"]),
                        ("Pre-Action", values["Pre-Action"]),
                        ("Post-Action", values["Post-Action"]),
                        ("Test Steps.Action", values["Test Steps.Action"]),
                        ("Test Steps.Expected result", values["Test Steps.Expected result"]),
                    ):
                        if not str(value or "").strip():
                            issues.append(ValidationIssue("error", "PRIMARY_FIELD_MISSING", f"{field_name} is required on a primary row.", location))
                    if not _is_valid_test_case_id(values["ID"]):
                        issues.append(
                            ValidationIssue(
                                "error",
                                "TEST_CASE_ID_INVALID",
                                "ID must be a single whole-number test-case artifact ID when supplied.",
                                location,
                            )
                        )
                    if not _is_valid_verifies(values["Verifies"]):
                        issues.append(
                            ValidationIssue(
                                "error",
                                "VERIFIES_FORMAT_INVALID",
                                "Verifies must contain comma-separated [ISSUE:<numeric ID>] - null references.",
                                location,
                            )
                        )
                    expected_test_case = expected_cases_by_name.get(name_text)
                    if expected_test_case is not None:
                        if values["ID"] != expected_test_case.artifact_id:
                            issues.append(
                                ValidationIssue(
                                    "error",
                                    "TEST_CASE_ID_MISMATCH",
                                    "ID must be blank unless the generated test case was given an artifact ID.",
                                    location,
                                )
                            )
                        expected_verifies = _verifies_value(expected_test_case)
                        if values["Verifies"] != expected_verifies:
                            issues.append(
                                ValidationIssue(
                                    "error",
                                    "VERIFIES_MISMATCH",
                                    "Verifies must correspond to the generated requirement IDs, not the test-case ID.",
                                    location,
                                )
                            )
                        if expected_verifies is None and "Traceability:" not in str(values["Description"] or ""):
                            issues.append(
                                ValidationIssue(
                                    "error",
                                    "TRACEABILITY_MISSING",
                                    "A test case with no verified requirement ID must state the traceability evidence gap.",
                                    location,
                                )
                            )
                    elif name_text in expected_name_set and not values["Verifies"] and "Traceability:" not in str(values["Description"] or ""):
                        issues.append(
                            ValidationIssue(
                                "error",
                                "TRACEABILITY_MISSING",
                                "Primary row must contain valid ID/Verifies values or state the traceability evidence gap.",
                                location,
                            )
                        )
                    if not _is_case_name_highlight(export.cell(row_number, header_indexes["Name"])):
                        issues.append(ValidationIssue("error", "CASE_NAME_HIGHLIGHT_MISSING", "Primary Name cell must use the reviewed yellow highlight.", location))
                    if str(values["Test Steps.Action"] or "").strip() and str(values["Test Steps.Expected result"] or "").strip():
                        step_counts[current_case] += 1
                    continue
                if any(values[header] not in {None, ""} for header in STEP_HEADERS):
                    if current_case is None:
                        issues.append(ValidationIssue("error", "ORPHAN_CONTINUATION_ROW", "Continuation row has no preceding primary case row.", location))
                        continue
                    if any(values[header] not in {None, ""} for header in CASE_ROW_HEADERS):
                        issues.append(ValidationIssue("error", "CONTINUATION_FIELDS_INVALID", "Continuation rows may only contain step fields.", location))
                    if not str(values["Test Steps.Action"] or "").strip() or not str(values["Test Steps.Expected result"] or "").strip():
                        issues.append(ValidationIssue("error", "CONTINUATION_STEP_INCOMPLETE", "Continuation rows need an action and expected result.", location))
                    else:
                        step_counts[current_case] += 1
            if not group_names:
                issues.append(ValidationIssue("error", "GROUP_ROW_MISSING", "At least one legacy group row is required."))
            for case_name, step_count in step_counts.items():
                if step_count == 0:
                    issues.append(ValidationIssue("error", "TEST_STEPS_MISSING", "Test case has no complete step.", case_name))
        finally:
            workbook.close()
    expected_case_order = expected_case_names or []
    matches_expected_order = (
        observed_case_names == expected_case_order
        if expected_case_mode == "exact"
        else observed_case_names[-len(expected_case_order) :] == expected_case_order
    )
    if expected_case_names is not None and not matches_expected_order:
        issues.append(
            ValidationIssue(
                "error",
                "CASE_ORDER_MISMATCH",
                "Rendered case names do not match the prioritized generated order for the selected write mode.",
            )
        )
    return {
        "workbook_path": str(Path(workbook_path).expanduser().resolve()),
        "template_contract": {
            "profile": "reviewed_legacy_export_v3_with_extended_veoneer_headers",
            "status": "passed" if not inspection.issues else "failed",
            "issues": inspection.issues,
        },
        "codebeamer_import_compatibility": {
            "status": "unverified",
            "evidence": "Evidence unavailable: no approved importer round trip for the extended V3-style legacy profile was supplied.",
        },
        "test_case_count": len(observed_case_names),
        "group_names": group_names,
        "issues": [asdict(issue) for issue in issues],
        "summary": {
            "errors": sum(issue.severity == "error" for issue in issues),
            "warnings": sum(issue.severity == "warning" for issue in issues),
        },
    }


def _report_path(output_path: str | Path, explicit_path: str | None) -> Path:
    if explicit_path:
        return Path(explicit_path).expanduser().resolve()
    output = Path(output_path).expanduser().resolve()
    return output.with_suffix(output.suffix + ".validation.json")


def command_generate_legacy_export(args: argparse.Namespace) -> int:
    """Generate a reviewed legacy Export workbook from one or more requirement sources."""
    if not args.source and not args.requirement:
        raise ValueError("Supply at least one --source or --requirement.")
    inspection = inspect_legacy_export_template(args.template)
    if inspection.issues:
        raise ValueError("Template inspection failed: " + "; ".join(inspection.issues))
    requirements, source_reports = parse_sources(args.source or [])
    requirements.extend(parse_inline_requirements(args.requirement or []))
    generation = generate_specification(
        requirements,
        title=args.title,
        approved_only=not args.include_unapproved,
    )
    preflight = validate_legacy_export_specification(generation.specification)
    preflight_errors = [issue for issue in preflight if issue.severity == "error"]
    report: dict[str, Any] = {
        "input_sources": source_reports,
        "inline_requirement_count": len(args.requirement or []),
        "template": asdict(inspection),
        "specification": {
            "title": generation.specification.title,
            "test_case_count": len(generation.specification.test_cases),
            "assumptions": generation.specification.assumptions,
            "coverage_gaps": generation.specification.coverage_gaps,
            "excluded_requirements": generation.excluded_requirements,
        },
        "traceability": [
            {
                "test_case": test_case.name,
                "requirement_ids": test_case.requirement_ids,
                "source_requirements": [asdict(provenance) for provenance in test_case.source_requirements],
                "steps": [
                    {
                        "step_number": step_number,
                        "action": step.action,
                        "expected_result": step.expected_result,
                    }
                    for step_number, step in enumerate(test_case.steps, start=1)
                ],
            }
            for test_case in generation.specification.test_cases
        ],
        "preflight": [asdict(issue) for issue in preflight],
    }
    report_path = _report_path(args.output, args.report)
    if args.strict and preflight_errors:
        report["output_blocked"] = "Strict mode blocked workbook generation because preflight errors were found."
        write_json_report(report, report_path)
        print(json.dumps({"report": str(report_path), "errors": len(preflight_errors), "output_blocked": True}, indent=2))
        return 1
    rendering = render_legacy_export_specification(
        generation.specification,
        template_path=args.template,
        destination_path=args.output,
        group_name=args.group_name,
        write_mode=args.write_mode,
        overwrite=args.overwrite,
    )
    postflight = validate_legacy_export_workbook(
        args.output,
        expected_case_names=[test_case.name for test_case in generation.specification.test_cases],
        expected_case_mode="suffix" if args.write_mode == "append" else "exact",
        expected_test_cases=generation.specification.test_cases,
    )
    report["rendering"] = rendering
    report["postflight"] = postflight
    write_json_report(report, report_path)
    print(
        json.dumps(
            {
                "output": args.output,
                "report": str(report_path),
                "test_cases": len(generation.specification.test_cases),
                "postflight_errors": postflight["summary"]["errors"],
                "postflight_warnings": postflight["summary"]["warnings"],
            },
            indent=2,
        )
    )
    return 1 if postflight["summary"]["errors"] else 0


def add_legacy_export_arguments(parser: argparse.ArgumentParser) -> None:
    """Add the shared command-line interface for the legacy Export renderer."""
    parser.add_argument("--template", required=True, help="Approved reviewed legacy Export .xlsx/.xlsm template")
    parser.add_argument("--source", action="append", help="Requirement source (.txt, .csv, .xlsx, .docx, .pdf, .json); repeatable")
    parser.add_argument("--requirement", action="append", help="Inline requirement, optionally '<ID>: <text>'; repeatable")
    parser.add_argument("--title", required=True, help="Specification title stored in the evidence report")
    parser.add_argument("--output", required=True, help="New output workbook path")
    parser.add_argument("--report", help="Generation and validation report path")
    parser.add_argument("--group-name", default=DEFAULT_GROUP_NAME, help="Legacy group row heading")
    parser.add_argument("--write-mode", choices=["append", "replace_data"], default="replace_data")
    parser.add_argument("--include-unapproved", action="store_true", help="Include records whose source status is not Approved")
    parser.add_argument("--strict", action="store_true", help="Block output when preflight errors are found")
    parser.add_argument("--overwrite", action="store_true", help="Allow replacing an existing output")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate V3-style legacy Export test specifications with the requested Veoneer headers offline.")
    add_legacy_export_arguments(parser)
    return command_generate_legacy_export(parser.parse_args())


if __name__ == "__main__":
    raise SystemExit(main())