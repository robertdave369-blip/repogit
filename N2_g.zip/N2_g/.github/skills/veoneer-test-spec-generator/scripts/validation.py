"""Template-backed validation for test specifications and rendered exports."""

from __future__ import annotations

import re
from dataclasses import asdict
from pathlib import Path
from typing import Any

from models import TestSpecification, ValidationIssue
from sanitize import write_json_report
from workbook_codec import NUMERIC_IDENTIFIER_PATTERN, inspect_template, load_profile, read_export_cases


CODEBEAMER_REFERENCE_PATTERN = re.compile(r"\[ISSUE:\d+\] - null")


def _allowed_issue(
    field: str,
    value: str | None,
    allowed_values: dict[str, list[str]],
    location: str,
) -> ValidationIssue | None:
    if value is None or value == "":
        return None
    choices = allowed_values.get(field)
    if choices is not None and value not in choices:
        return ValidationIssue(
            severity="error",
            code="TEMPLATE_ENUM_VALUE_INVALID",
            message=f"'{value}' is not one of the observed template values for {field}: {choices}",
            location=location,
        )
    return None


def validate_specification(
    specification: TestSpecification,
    *,
    template_path: str | Path,
    profile: dict[str, Any] | None = None,
) -> list[ValidationIssue]:
    """Validate generated content against observed template constraints before rendering."""
    profile = profile or load_profile()
    inspection = inspect_template(template_path, profile)
    issues = [
        ValidationIssue("error", "TEMPLATE_CONTRACT_INVALID", message)
        for message in inspection.issues
    ]
    if not specification.test_cases:
        issues.append(ValidationIssue("error", "NO_TEST_CASES", "No approved, usable requirements produced a test case."))
        return issues
    names: set[str] = set()
    for test_case in specification.test_cases:
        location = test_case.name
        if not test_case.name.strip():
            issues.append(ValidationIssue("error", "TEST_CASE_NAME_MISSING", "Test case name is required.", location))
        elif test_case.name in names:
            issues.append(ValidationIssue("error", "TEST_CASE_NAME_DUPLICATE", "Test case names must be unique.", location))
        names.add(test_case.name)
        if not test_case.description.strip():
            issues.append(ValidationIssue("error", "TEST_CASE_DESCRIPTION_MISSING", "Test case description is required.", location))
        if not test_case.steps:
            issues.append(ValidationIssue("error", "TEST_STEPS_MISSING", "At least one test step is required.", location))
        for step_number, step in enumerate(test_case.steps, start=1):
            if not step.action.strip():
                issues.append(ValidationIssue("error", "TEST_STEP_ACTION_MISSING", "Test step action is required.", f"{location} step {step_number}"))
            if not step.expected_result.strip():
                issues.append(ValidationIssue("error", "TEST_STEP_EXPECTED_RESULT_MISSING", "Expected result is required.", f"{location} step {step_number}"))
        if not test_case.requirement_ids:
            issues.append(
                ValidationIssue(
                    "warning",
                    "TRACEABILITY_UNRESOLVED",
                    "No verified Codebeamer requirement ID is available; the Verifies field will remain blank.",
                    location,
                )
            )
        for requirement_id in test_case.requirement_ids:
            if not NUMERIC_IDENTIFIER_PATTERN.fullmatch(str(requirement_id).strip()):
                issues.append(
                    ValidationIssue(
                        "error",
                        "TRACEABILITY_IDENTIFIER_INVALID",
                        "A Codebeamer export reference must use a verified numeric artifact ID.",
                        location,
                    )
                )
        for field, value in (
            ("Priority", test_case.priority),
            ("Status", test_case.status),
            ("Type", test_case.item_type),
            ("_LatestResult", test_case.latest_result),
            ("_TestType", test_case.test_type),
            ("_VerificationMethod", test_case.verification_method),
            ("_TestTechnique", test_case.methodology.primary_technique),
        ):
            invalid = _allowed_issue(field, value, inspection.allowed_values, location)
            if invalid is not None:
                issues.append(invalid)
        for provenance in test_case.source_requirements:
            if provenance.raw_status is None:
                issues.append(
                    ValidationIssue(
                        "warning",
                        "REQUIREMENT_APPROVAL_UNAVAILABLE",
                        "Input source did not provide an approval status; review before claiming approved-requirement coverage.",
                        location,
                    )
                )
    return issues


def validate_rendered_workbook(
    workbook_path: str | Path,
    *,
    profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate a rendered workbook without claiming a live Codebeamer import was executed."""
    profile = profile or load_profile()
    inspection = inspect_template(workbook_path, profile)
    issues = [
        ValidationIssue("error", "TEMPLATE_CONTRACT_INVALID", message)
        for message in inspection.issues
    ]
    cases = read_export_cases(workbook_path, profile)
    for test_case in cases:
        fields = test_case["fields"]
        location = f"Export row {test_case['row']}"
        if not str(fields.get("Name") or "").strip():
            issues.append(ValidationIssue("error", "TEST_CASE_NAME_MISSING", "Name is required on a primary row.", location))
        if not str(fields.get("Description") or "").strip():
            issues.append(ValidationIssue("error", "TEST_CASE_DESCRIPTION_MISSING", "Description is required on a primary row.", location))
        if not test_case["steps"]:
            issues.append(ValidationIssue("error", "TEST_STEPS_MISSING", "At least one step is required.", location))
        for step in test_case["steps"]:
            step_location = f"Export row {step['row']}"
            if not str(step["action"] or "").strip():
                issues.append(ValidationIssue("error", "TEST_STEP_ACTION_MISSING", "Test step action is required.", step_location))
            if not str(step["expected_result"] or "").strip():
                issues.append(ValidationIssue("error", "TEST_STEP_EXPECTED_RESULT_MISSING", "Expected result is required.", step_location))
            invalid = _allowed_issue(
                "Test Steps.Critical",
                None if step["critical"] is None else str(step["critical"]),
                inspection.allowed_values,
                step_location,
            )
            if invalid is not None:
                issues.append(invalid)
        verifies = str(fields.get("Verifies") or "").strip()
        if not verifies:
            issues.append(ValidationIssue("warning", "TRACEABILITY_UNRESOLVED", "Verifies is blank.", location))
        elif not all(CODEBEAMER_REFERENCE_PATTERN.fullmatch(reference.strip()) for reference in verifies.split(",")):
            issues.append(
                ValidationIssue(
                    "error",
                    "TRACEABILITY_FORMAT_INVALID",
                    "Verifies must contain comma-separated [ISSUE:<numeric ID>] - null references.",
                    location,
                )
            )
        for field in ("Priority", "Status", "Type", "_LatestResult", "_TestType", "_VerificationMethod", "_TestTechnique"):
            value = fields.get(field)
            invalid = _allowed_issue(field, None if value is None else str(value), inspection.allowed_values, location)
            if invalid is not None:
                issues.append(invalid)
        artifact_id = fields.get("ID")
        if artifact_id is not None:
            try:
                numeric_id = int(artifact_id)
            except (TypeError, ValueError):
                issues.append(ValidationIssue("error", "ARTIFACT_ID_INVALID", "ID must be a whole integer when supplied.", location))
            else:
                limits = profile["id_constraints"]
                if not limits["minimum"] <= numeric_id <= limits["maximum"]:
                    issues.append(ValidationIssue("error", "ARTIFACT_ID_RANGE_INVALID", "ID is outside the observed template validation range.", location))
    report = {
        "workbook_path": str(Path(workbook_path).expanduser().resolve()),
        "template_contract": {
            "profile": profile["profile_name"],
            "status": "passed" if not inspection.issues else "failed",
            "issues": inspection.issues,
        },
        "codebeamer_import_compatibility": {
            "status": "unverified",
            "evidence": "Evidence unavailable: no approved Codebeamer importer run or importer specification was supplied.",
        },
        "test_case_count": len(cases),
        "issues": [asdict(issue) for issue in issues],
        "summary": {
            "errors": sum(issue.severity == "error" for issue in issues),
            "warnings": sum(issue.severity == "warning" for issue in issues),
        },
    }
    return report


def write_validation_report(report: dict[str, Any], destination_path: str | Path) -> Path:
    """Persist a validation report separately from the generated workbook."""
    return write_json_report(report, destination_path)