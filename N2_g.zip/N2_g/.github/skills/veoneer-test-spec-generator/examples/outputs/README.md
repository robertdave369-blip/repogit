# Example Output Notes

Generate an example with the command in the parent README. The example requirement intentionally has no Codebeamer artifact ID, so the generated `Verifies` cell is blank and the JSON validation report contains `TRACEABILITY_UNRESOLVED`.

This demonstrates the skill's intended safety behavior: it produces a review draft while refusing to invent a requirement ID or claim a Codebeamer import result.