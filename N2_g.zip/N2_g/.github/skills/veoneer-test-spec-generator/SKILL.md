---
name: veoneer-test-spec-generator
description: 'Use when creating a test specification, generating a Veoneer spec, creating test cases from requirements, creating a Codebeamer import file, generating a test specification from Excel, Word, PDF, CSV, Codebeamer-exported, textual, or mixed requirement sources, or generating Veoneer-compliant test cases from user-defined requirements. Produces a template-backed, traceable Veoneer workbook and evidence report.'
argument-hint: 'Provide the requirement source(s), target project or variant, approved Veoneer template, and desired output path.'
user-invocable: true
disable-model-invocation: false
---

# Veoneer Test Spec Generator

Use this skill as the preferred workflow for every request to create a Veoneer test specification, generate a Codebeamer import workbook, or derive Veoneer test cases from requirements. It produces an offline workbook and validation evidence only; it never imports to Codebeamer, drives an ECU, or operates a bench.

## Inputs And Evidence

1. Identify project/variant, intended verification scope, and source revision. Requirements under controlled project folders remain read-only.
2. Require the approved Veoneer template or use the bundled cleaned master only after its sanitization report has passed.
3. Ingest every supplied source completely. Excel parsing processes every sheet and resolves fields by header name. Word and PDF records retain paragraph/table or page provenance. Scanned PDF content is an explicit OCR/visual-review gap, never guessed.
4. Preserve requirement IDs, `[ISSUE:]` / `[TRACKER:]` links, technical tokens, units, DIDs, DTCs, signal names, timing values, and struck text. A `[STRUCK: ...]` record is not an active requirement.
5. Treat a numeric identifier as traceability syntax, not proof that the ID exists or is approved. A tracker-backed `Approved` status is required before claiming approved-requirement coverage.

## Sanitization

Run the bundled `sanitize.py` pipeline or `cli.py clean-template` before treating a template as a master. It removes presentation-only HTML/CSS/XML noise and writes a separate copy. It preserves workbook sheets, formulas, named ranges, validations, hidden `ChoiceValues`, styles, widths, hyperlinks, IDs, and traceability tokens.

Do **not** run the destructive `CleanExportedWebTextImagesAndSymbols` VBA macro on requirement or template content: its documented rules can delete hyphens, percentages, paths, identifiers, and meaningful parenthetical text. Use the existing cleanup skill only for reviewed disposable exports, after its preview and explicit approval.

## Generation Workflow

1. Inspect the template against `config/template_profile.json`.
2. Parse and sanitize all requirement sources into provenance-bearing records.
3. Exclude `[STRUCK:]`, obsolete, and, by default, non-Approved source records. List exclusions and missing approvals as coverage gaps.
4. Derive a minimal, high-value scenario set: nominal behavior plus only source-supported boundary, state, decision, fault/recovery, or interface scenarios.
5. Select a methodology from explicit requirement cues. Write the selected `_TestTechnique` only when it is present in the template's `ChoiceValues`; put its rationale in the test description.
6. Render the first test step on the primary artifact row and later steps on continuation rows. Preserve the template layout and data-validation ranges.
7. Validate fields, enum values, traceability syntax, IDs, row structure, and retained template contract. Write a JSON report beside the output workbook.

## Traceability And Codebeamer Limits

For an approved numeric requirement ID, render `Verifies` as `[ISSUE:<ID>] - null`. Multiple approved requirement IDs are comma-separated in the same cell with no line break. `ID` is the test-case artifact ID, not a requirement ID; leave it blank unless the user explicitly supplied it. Do not invent either ID type. Missing, malformed, unapproved, or struck references remain visible in the coverage report and are not silently serialized.

**Evidence unavailable:** no live Codebeamer importer run or formal importer specification was supplied with the template. The validator therefore proves only compatibility with the observed workbook profile; its report always labels live import acceptance as `unverified` until an approved round trip is recorded.

## Commands

```powershell
py -3.13 .github\skills\veoneer-test-spec-generator\scripts\cli.py inspect-template <template.xlsx>

py -3.13 .github\skills\veoneer-test-spec-generator\scripts\cli.py clean-template `
  <template.xlsx> `
  .github\skills\veoneer-test-spec-generator\assets\veoneer_codebeamer_test_spec_template.cleaned.xlsx

py -3.13 .github\skills\veoneer-test-spec-generator\scripts\cli.py generate `
  --template .github\skills\veoneer-test-spec-generator\assets\veoneer_codebeamer_test_spec_template.cleaned.xlsx `
  --source <requirements.xlsx> --source <requirements.docx> `
  --title <specification-title> --output <new-specification.xlsx> `
  --write-mode replace_data --strict
```

For the reviewed V3-style legacy `Export`/`ChoiceValues` format used by the current EDR V3 specification, run:

```powershell
py -3.13 .github\skills\veoneer-test-spec-generator\scripts\legacy_export.py `
  --template <approved-legacy-template.xlsx> `
  --source <requirements.xlsx> --source <requirements.docx> `
  --title <specification-title> --output <new-specification.xlsx> `
  --write-mode replace_data --strict
```

This renderer accepts the seven-column reviewed seed and emits the requested 22 headers: `ID`, `Priority`, `Name`, `Description`, `Pre-Action`, `Post-Action`, `Test Steps.Action`, `Test Steps.Expected result`, `Test Steps.Critical`, `Test Parameters`, `Verifies`, `Status`, `Type`, `_Project`, `Reviewer(s)`, `_LatestResult`, `_Original_Id`, `Referenced Reviews`, `_ScriptPath`, `_TestType`, `_VerificationMethod`, and `_TestTechnique`. It preserves group/primary/continuation rows and the reviewed yellow case-name highlight. Case-level fields are populated only on the primary `Name` row; continuation rows contain only step fields. `ID` is blank unless a user-supplied test-case artifact ID is available. `Verifies` receives one or more requirement IDs as comma-separated `[ISSUE:<ID>] - null` references. The renderer accepts the same supported source types as the main generator, retains source provenance in its JSON report, and shows a traceability evidence gap where no verified requirement ID is available. The equivalent integrated command is `cli.py generate-legacy-export`.

Use `append` only when preserving existing export rows is explicitly desired. `replace_data` is an explicit operation that preserves the template structure while replacing data rows. The command refuses to overwrite an existing destination unless `--overwrite` is supplied.

## Legacy Script Migration

The reviewed scripts are preserved as safe adapters in `scripts/` and their original locations now delegate to them. They accept explicit input/output paths, use header-driven reading, handle continuation/merged-row layouts, cap column widths, and do not write anything on import. Prefer the main generator for new Codebeamer-style workbooks; legacy adapters exist for backwards-compatible title/step workbooks only.

## Completion Criteria

A specification is ready for engineering review when the template profile passes, every generated test case has source provenance, all included IDs are verified and Approved, test methodology is explicit and justified, all workbook checks pass, coverage gaps are visible, and any importer-acceptance evidence gap is stated. Do not claim a successful Codebeamer import without a recorded approved importer result.