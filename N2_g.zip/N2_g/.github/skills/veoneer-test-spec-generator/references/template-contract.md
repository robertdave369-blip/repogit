# Observed Template Contract

**Bundled portable template:** [`assets/veoneer_codebeamer_test_spec_template.cleaned.xlsx`](../assets/veoneer_codebeamer_test_spec_template.cleaned.xlsx)  
**Bundled template SHA-256:** `22569adeb63a8d25c2a87b1a1b2948bf4ab665add96f10470125abe602d30dad`  
**Original source SHA-256:** `751a1266b06dae7b5ad17d963d19c0746d28b83f4e672b465ef122358304715a`  
**Original source availability:** Evidence unavailable: the original external template was not retained with this skill package.  
**Observation date:** 2026-08-24  
**Confidence:** Very High for workbook facts; Unknown for undocumented Codebeamer importer behavior.

## Workbook Structure

- Visible worksheet: `Export`.
- Hidden worksheet: `ChoiceValues`.
- `Export` observed extent: `A1:W8032`; it contains pre-existing export rows and is not a blank workbook.
- Header row and observed column order:

```text
ID | Priority | Name | Description | Pre-Action | Post-Action |
Test Steps.Action | Test Steps.Expected result | Test Steps.Critical |
Test Steps.Id | Test Parameters | Verifies | Status | Type | _Project |
Reviewer(s) | _LatestResult | _Original_Id | Referenced Reviews |
_ScriptPath | _TestType | _VerificationMethod | _TestTechnique
```

- A primary artifact row holds item-level fields plus its first step. Following rows often populate only `Test Steps.*`; the skill serializes later steps this way.
- Observed metadata includes frozen top row, hidden column `J`, styles, column widths, named ranges, data validations, and Codebeamer hyperlinks in `ID` cells. Preserve all of these.
- No formulas, macros, tables, merged cells, conditional formatting, or workbook protection were observed in this supplied file. The renderer still preserves them if a future template adds them.

## Observed Values And Constraints

| Field | Observed choices / constraint |
| --- | --- |
| `ID` | Whole integer from $-2147483648$ to $2147483647$; test-case artifact ID only. Leave blank unless the user explicitly supplies an existing test-case ID. |
| `Priority` | `Lowest`, `Low`, `Normal`, `High`, `Highest` |
| `Test Steps.Critical` | `true`, `false` |
| `Status` | `INIT`, `IN WORK`, `IN REVIEW`, `APPROVED`, `ON HOLD`, `RESULT_PASSED`, `RESULT_FAILED` |
| `Type` | `Folder`, `Information`, `Functional` |
| `_LatestResult` | `PASSED`, `FAILED`, `NOT YET TESTED` |
| `_TestType` | `Automatic`, `Semi-Automatic`, `Manual` |
| `_VerificationMethod` | `Software Qualification`, `System Qualification`, `Software Integration`, `System Integration`, `Requirements-based test`, `Fault Injection test` |
| `_TestTechnique` | Values come from `ChoiceValues!A1:A14`; the codec reads them dynamically. |
| `Verifies` | User-directed serialization rule recorded 2026-09-02: render each approved requirement ID as `[ISSUE:<trimmed ID>] - null`; separate multiple references with commas in the same cell. |

Validations were observed through row 10032. The renderer extends those validation ranges only when it writes beyond them.

## Metadata And Formatting

- Observed `ID` links use `https://codebeamer-vne.corp.int/cb/item/<id>`.
- Sample `Test Steps.Id` values are 32-character lowercase hexadecimal strings, but no generation rule was supplied. The skill therefore preserves a supplied ID and leaves a new one blank rather than inventing it.
- `M2` contains `n/a`, although it is outside the observed `Status` validation list. The skill does not normalize this pre-existing inconsistency.

## Evidence Gaps

- Mandatory fields by imported item type.
- How Codebeamer allocates or updates `ID`, `_Original_Id`, and `Test Steps.Id` values for a new import.
- Whether hyperlinks, named ranges, and validations are importer requirements or export presentation metadata.
- Live importer acceptance for any generated workbook.

The validator labels the first three as profile-level unknowns and the last as `unverified`. It must not report “fully Codebeamer compatible” until an approved import/export round trip provides evidence.