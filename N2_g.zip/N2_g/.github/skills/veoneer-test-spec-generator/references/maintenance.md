# Maintenance Guide

## Updating A Template Profile

1. Retain an approved portable template copy under `assets/` and record its hash and revision. Do not retain workstation-specific paths; when the original cannot be bundled, record its hash and an explicit availability gap.
2. Run `inspect-template` and `clean-template` to a new, separately named master copy.
3. Compare sheets, header order, validations, named ranges, visibility, styles, hyperlinks, and continuation-row behavior against `config/template_profile.json`.
4. Update only observed values. Put unverified importer behavior in `references/template-contract.md` as an evidence gap.
5. Add a regression test for every changed header, enum, formatting rule, or row convention.
6. Run an approved sandbox Codebeamer import/export round trip. Record version, import settings, output hash, and defects. Only then update the importer-acceptance status.

## Extending Source Parsing

- Keep raw source immutable and retain source path, sheet/page/table/row location, source hash, and extraction warnings.
- Use structure-aware libraries: `openpyxl` for Excel, `python-docx` for Word, and PyMuPDF plus the repository PDF skill for PDFs.
- Never use a lossy regex-only parser for tables, tracker IDs, or diagnostic data.
- Preserve `[STRUCK:]` and traceability references rather than stripping them.

## Extending Test Design

- Add methodology rules only when their source-language trigger and template-compatible output choice are explicit.
- Prefer one nominal and one risk-driven scenario over duplicate test cases.
- Keep priority sourced from evidence; do not infer ASIL or priority from wording.
- Require project configuration, DBC, requirements, and approved wrapper evidence before turning a generated review case into an executable bench script.

## Regression Checks

Run the offline suite before release:

```powershell
py -3.13 tests\test_veoneer_test_spec_generator.py -v
```

Also run `inspect-template` against the active master. Do not treat a clean profile check as proof of live Codebeamer import success.