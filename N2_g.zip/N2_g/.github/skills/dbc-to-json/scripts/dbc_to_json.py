"""Convert CAN database (DBC) files into JSON signal metadata."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable

try:
    import cantools
except ImportError:
    cantools = None


def extract_signal_info(signal: Any) -> dict[str, Any]:
    """Extract detailed information about a signal, including value descriptions."""
    choices = {
        str(value): str(description)
        for value, description in (signal.choices or {}).items()
    }

    return {
        "name": signal.name,
        "description": signal.comment,
        "start_bit": signal.start,
        "length": signal.length,
        "byte_order": signal.byte_order,
        "is_signed": signal.is_signed,
        "factor": signal.scale,
        "offset": signal.offset,
        "min": signal.minimum,
        "max": signal.maximum,
        "unit": signal.unit,
        "value_descriptions": choices,
    }


def _normalise_collection(values: Any) -> list[Any]:
    """Return parser collections as JSON-compatible, deterministic lists."""
    if values is None:
        return []
    if isinstance(values, set):
        return sorted(values)
    return list(values)


def extract_message_info(message: Any) -> dict[str, Any]:
    """Extract detailed information about a message and its signals."""
    return {
        "name": message.name,
        "frame_id": hex(message.frame_id),
        "description": message.comment,
        "is_extended_frame": message.is_extended_frame,
        "length": message.length,
        "senders": _normalise_collection(message.senders),
        "receivers": _normalise_collection(message.receivers),
        "cycle_time": message.cycle_time,
        "signals": [extract_signal_info(signal) for signal in message.signals],
    }


def find_dbc_files(paths: Iterable[Path]) -> list[Path]:
    """Find unique DBC files from file and directory inputs."""
    input_paths = list(paths) or [Path.cwd()]
    discovered: dict[Path, Path] = {}

    for input_path in input_paths:
        resolved_path = input_path.expanduser().resolve()
        if not resolved_path.exists():
            raise FileNotFoundError(f"Input path does not exist: {input_path}")

        if resolved_path.is_file():
            if resolved_path.suffix.lower() != ".dbc":
                raise ValueError(f"Input file is not a DBC file: {input_path}")
            discovered[resolved_path] = resolved_path
            continue

        for candidate in resolved_path.rglob("*"):
            if candidate.is_file() and candidate.suffix.lower() == ".dbc":
                resolved_candidate = candidate.resolve()
                discovered[resolved_candidate] = resolved_candidate

    return sorted(discovered.values(), key=lambda dbc_path: str(dbc_path).lower())


def process_dbc_file(dbc_path: Path) -> Path:
    """Process one DBC file and write its extracted signal metadata JSON."""
    if cantools is None:
        raise RuntimeError(
            "cantools is required. Install it with: "
            "python -m pip install -r .github/skills/dbc-to-json/requirements.txt"
        )

    database = cantools.database.load_file(str(dbc_path))
    messages = [extract_message_info(message) for message in database.messages]

    output_dir = dbc_path.parent / f"{dbc_path.stem}_json"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_json = output_dir / f"{dbc_path.stem}_signals.json"

    with output_json.open("w", encoding="utf-8") as output_file:
        json.dump(messages, output_file, indent=2, ensure_ascii=False)
        output_file.write("\n")

    return output_json


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line parser."""
    parser = argparse.ArgumentParser(
        description=(
            "Recursively convert DBC files to JSON. Output is written beside each "
            "DBC in a <dbc_file_name>_json folder."
        )
    )
    parser.add_argument(
        "paths",
        metavar="PATH",
        nargs="*",
        type=Path,
        help="DBC file or directory to scan. Defaults to the current directory.",
    )
    return parser


def main(arguments: list[str] | None = None) -> int:
    """Run the DBC-to-JSON conversion command."""
    parser = build_parser()
    parsed_arguments = parser.parse_args(arguments)

    try:
        dbc_files = find_dbc_files(parsed_arguments.paths)
    except (FileNotFoundError, ValueError, OSError) as error:
        parser.error(str(error))

    if not dbc_files:
        print("No .dbc files found.")
        return 0

    failures = 0
    for dbc_path in dbc_files:
        try:
            output_json = process_dbc_file(dbc_path)
        except Exception as error:  # Keep processing independent DBC files.
            failures += 1
            print(f"Failed to convert {dbc_path}: {error}", file=sys.stderr)
            continue

        print(f"Converted {dbc_path} -> {output_json}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())