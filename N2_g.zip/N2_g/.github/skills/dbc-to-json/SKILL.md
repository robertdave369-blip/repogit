---
name: dbc-to-json
description: 'Use when converting one or more CAN database (.dbc) files into JSON signal metadata. Locates DBC files recursively, creates a sibling <dbc_file_name>_json folder for each input, and writes parsed JSON there using cantools.'
argument-hint: 'Provide a DBC file, one or more paths, or a directory to convert'
user-invocable: true
disable-model-invocation: false
---

# DBC To JSON

## When To Use

Use this skill to extract CAN message and signal metadata from `.dbc` files into JSON. It supports a single DBC file, multiple files, or a directory tree containing DBC files.

## Procedure

1. Ensure the active Python environment provides `cantools`:

   ```powershell
   python -m pip install -r .github/skills/dbc-to-json/requirements.txt
   ```

2. Run the bundled parser with one or more DBC files or directories:

   ```powershell
   python .github/skills/dbc-to-json/scripts/dbc_to_json.py path/to/Vehicle.dbc
   python .github/skills/dbc-to-json/scripts/dbc_to_json.py path/to/dbc-directory
   ```

   With no path arguments, the parser recursively locates all `.dbc` files beneath the current working directory.

3. For every input DBC, inspect its sibling output folder. For example, `Vehicle.dbc` produces:

   ```text
   Vehicle.dbc
   Vehicle_json/
     Vehicle_signals.json
   ```

## Output

Each JSON file contains the DBC messages and their signals, including frame ID, frame type, DLC, senders, receivers, cycle time, signal bit layout, scaling, ranges, units, descriptions, and enumerated value descriptions.

The parser continues with other discovered files if one DBC cannot be parsed, reports each failure to standard error, and exits with a nonzero status when any conversion fails.
