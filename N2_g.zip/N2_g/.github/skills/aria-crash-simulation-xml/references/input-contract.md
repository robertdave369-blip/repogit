# Crash XML Generator Input Contract

The generator uses the reference XML to preserve sensor hierarchy and channel order. The optional
configuration input supplies project-specific signal overrides and inversion evidence.

## Supported Files

| Extension | Expected shape |
| --- | --- |
| `.xlsx` | A header-driven table on one or more worksheets. Every sheet with recognized mapping headers is read. |
| `.csv` | Header row plus one mapping per row. |
| `.txt` | Header-driven comma, semicolon, tab, or pipe-delimited table; JSON content is also accepted. |
| `.json` | A list of mapping objects, or an object containing a `mappings`, `sensors`, `axes`, or `records` list. |

## Recognized Columns

Column spelling is case-insensitive and punctuation-insensitive.

| Canonical field | Accepted examples | Purpose |
| --- | --- | --- |
| `Channel` | `RSU_CH1`, `Channel Assignment`, `ARIA Channel`, `Sensor Channel` | Targets a template `<Sensor Type>`. |
| `Axis Index` | `Axis Index`, `Axis Number`, `Axis Position`, `Index` | One-based index within a multi-axis sensor. Required for blank/`Empty` GEN6 or Panasonic axes. |
| `Signal` | `Signal`, `Signal Name`, `Template Signal`, `Curve`, `TXT Signal` | Exact logical crash-signal identifier, excluding event and date. |
| `Sensor Location` | `Sensor`, `Sensor Location`, `Location`, `RSU Name` | Can identify a template signal with `Axis` when `Signal` is absent. |
| `Axis` | `Axis`, `Axis Assignment`, `Axis Mapping` | Usually `X`, `Y`, `Z`, `Acc_X`, or `Pres_None`. |
| `Inverted` | `Inverted`, `IsInverted`, `Inversion`, `Inversion Requirement` | Boolean `True`/`False`, `Yes`/`No`, or `1`/`0`. |
| `Sensor Variant` | `Sensor Variant`, `Variant`, `RSU Variant` | Retained as provenance; `newRSU` and `RSU` names are normalized for matching. |

## JSON Example

```json
{
  "mappings": [
    {
      "Channel": "RSU_CH3",
      "Signal": "Side A-Pillar Right RSU_Acc_Y",
      "Inverted": true,
      "Sensor Variant": "newRSU1"
    },
    {
      "Channel": "GEN6_XY",
      "Axis Index": 1,
      "Signal": "Central_Acc_Y",
      "Inverted": true
    },
    {
      "Channel": "PANASONIC",
      "Axis Index": 1,
      "Signal": "Panasonic_Acc_X",
      "Inverted": false
    }
  ]
}
```

## TXT Curve Name Contract

The default event parser accepts:

```text
<event-name>_LSB_<signal-name>_2k_<suffix>.txt
```

For example:

```text
BEV_M210_SidePole_29kmph_LSB_Side A-Pillar Left RSU_Acc_Y_2k_15-Jul-2026.txt
```

The event identity is `BEV_M210_SidePole_29kmph`; the logical signal is
`Side A-Pillar Left RSU_Acc_Y`. Files without an event prefix are not grouped by default. Use
`--event-from-parent` only when the containing folder is the approved event identity.

## Mapping Rules

- The template's non-empty axis `FilePath` supplies the default signal key.
- `Channel` plus `Axis Index` is authoritative for a blank/`Empty` template axis.
- A `Signal` in the configuration can replace the template-derived signal only for the addressed
  channel/axis; it never changes the channel itself.
- One configuration record must identify one template axis. Repeated GEN6 pressure axes require an
  explicit `Axis Index`.
- Configuration records that map to no template axis are errors, not ignored extras.
- The source TXT path must exist at generation time.