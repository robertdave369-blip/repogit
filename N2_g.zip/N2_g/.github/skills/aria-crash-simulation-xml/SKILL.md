---
name: aria-crash-simulation-xml
description: 'Use when generating or validating ARIA/Veoneer CrashSimulationSensors XML files from crash-pulse TXT files. Recursively groups LSB crash curves into events, preserves a reference XML hierarchy and channel mapping, reads project-specific RSU/GEN6/Panasonic mapping and inversion data from XLSX, CSV, TXT, or JSON, produces one XML per event, and writes a validation report. Use for ARIA HIL crash replay, RSU/newRSU naming variants, GEN6_XY, Panasonic IMU, and crash curve XML generation.'
argument-hint: 'Provide the target project, reference XML, inversion/configuration file, crash TXT root, and output directory.'
user-invocable: true
disable-model-invocation: false
---

# ARIA Crash Simulation XML

## Purpose

Generate one offline `CrashSimulationSensors` XML file per crash event from recursively discovered
LSB TXT curves. The generator treats the supplied reference XML as the structural source of truth:
sensor hierarchy, `Sensor Type`, `Enable`, channel order, GEN6 axis order, Panasonic axis count,
and unmapped placeholders are preserved. It changes only `<Axis FilePath>` values and permitted
`IsInverted` values.

This skill creates configuration artifacts only. It does not load ARIA, power an ECU, trigger a
crash, or actuate bench hardware.

## Required Inputs

Collect these before write mode:

| Input | Requirement |
| --- | --- |
| Target project and revision | Identify the vehicle program and active ARIA/loadbox configuration. |
| Reference XML | Use the project-approved source. The current default is [reference_xml.xml](../../../docs/project_documents/common_crash_xml/reference_xml.xml). |
| Crash TXT root | A directory recursively containing names in the form `<event>_LSB_<signal>_2k_<suffix>.txt`. |
| Inversion/configuration file | A user-provided `.xlsx`, `.csv`, `.txt`, or `.json` file describing target-channel signal assignment and project-specific inversion values. |
| Output directory | A separate generated-artifact folder, never the active ARIA configuration folder unless the user explicitly approves that release process. |

**Inversion gate:** Ask the user for the target project's RSU inversion source before generating
XML files. In `--write` mode the generator requires an inversion/configuration file. If a supplied
file has no inversion value for a mapped axis, the reference XML value is retained and reported as
a warning, as requested by the project rules. Do not copy inversion values from a different vehicle
program.

The bundled [M210 example](./assets/m210_inversion_example.json) mirrors the supplied sample
script, but it is an example only. It is never selected automatically.

## Process

1. Qualify the reference XML and input tree.
   - Parse the source XML with a structured XML parser.
   - Confirm the root is `CrashSimulationSensors` and record every sensor and axis in order.
   - Retain blank and `Empty` axes unchanged unless the configuration file explicitly maps them.
   - Do not invent missing sensor channels, GEN6 axes, Panasonic axes, or loadbox assignments.

2. Read the target project's configuration and inversion evidence.
   - Read every Excel sheet and resolve columns by header name; do not use fixed column indexes.
   - Accept `Channel`, `Axis Index`, `Signal`, `Sensor Location`, `Axis`, `Inverted`, and optional
     `RSU Name` / `Sensor Variant` columns. See [the input contract](./references/input-contract.md).
   - Match `RSU` and `newRSU` spelling variants case-insensitively. Use the supplied mapping file
     for all program-specific names rather than changing code.
   - Apply inversion precedence: configuration value -> reference XML fallback. Record every
     fallback in the validation report.

3. Discover and group crash curves.
   - Recursively scan only `.txt` files.
   - Extract the event and signal from `<event>_LSB_<signal>_2k_<suffix>.txt`.
   - Group by relative source folder plus event name so same-named events in different folders stay
     separate.
   - Reject duplicate signal matches in one event and report filenames that do not contain an event
     prefix. Use `--event-from-parent` only when the folder itself is the approved event identity.

4. Map curves without changing the reference hierarchy.
   - Infer the normal source-signal key from each non-empty reference `FilePath`.
   - For blank or `Empty` axes, require an explicit `Channel` plus `Axis Index` and `Signal` mapping
     before populating them.
   - Match crash files by normalized signal name only; do not silently choose between ambiguous
     candidates.
   - Preserve `RSU_CHn`, `GEN6_XY`, and `PANASONIC` ordering. Populate Panasonic only when an
     explicit mapping is supplied; otherwise preserve its `FilePath="Empty"` placeholders.

5. Validate each event before it is saved.
   - Confirm all required signal paths exist.
   - Reject missing signals, duplicate source signals, duplicate or ambiguous configuration targets,
     unmatched configuration rows, invalid inversion values, and output-file collisions.
   - Re-parse each written XML and compare its structure with the reference while allowing only
     `Axis.FilePath` and `Axis.IsInverted` to differ.
   - A failed event produces no XML; independent valid events can still be written and are clearly
     marked in the report.

6. Review the generated report before importing any XML into ARIA.
   - The generator writes JSON and CSV reports containing crash name, XML name, mapped signal
     count, missing signals, warnings, errors, and status.
   - A `success` XML is ready for controlled ARIA review, not automatic hardware execution.

## Command

Install the optional Excel reader once in the selected analysis interpreter:

```powershell
py -3.13 -m pip install -r .github/skills/aria-crash-simulation-xml/requirements.txt
```

Run a safe dry run first:

```powershell
py -3.13 .github/skills/aria-crash-simulation-xml/scripts/generate_crash_simulation_xml.py `
  --template docs/project_documents/common_crash_xml/reference_xml.xml `
  --source-root 'V:\IN01\DataLake\RCS_IOEM\Christy\TextFiles\M210\01_TXT Signals' `
  --inversion-config 'C:\Project_ARB\configs\M210\RSU Config\RSU_M210.xlsx' `
  --output 'C:\Generated_Crash_XMLs\M210'
```

After reviewing the report and confirming the inversion source, write XML files:

```powershell
py -3.13 .github/skills/aria-crash-simulation-xml/scripts/generate_crash_simulation_xml.py `
  --template docs/project_documents/common_crash_xml/reference_xml.xml `
  --source-root 'V:\IN01\DataLake\RCS_IOEM\Christy\TextFiles\M210\01_TXT Signals' `
  --inversion-config 'C:\Project_ARB\configs\M210\RSU Config\RSU_M210.xlsx' `
  --output 'C:\Generated_Crash_XMLs\M210' `
  --write
```

Use `--overwrite` only when the user has approved replacement of existing generated XML files.

## Decision Rules

| Condition | Result |
| --- | --- |
| Write mode without inversion/configuration file | Block all XML writes and report the source gap. |
| Configuration gives `Inverted` | Write `True` or `False` from that record. |
| Configuration maps an axis but omits `Inverted` | Retain reference inversion and add a warning. |
| Reference axis is blank or `Empty`, with no explicit mapping | Preserve it exactly. |
| Panasonic signals are mapped explicitly | Populate only those mapped Panasonic axes. |
| Multiple TXT files match one required signal | Fail that event rather than selecting one. |
| A required curve is missing | Fail that event; do not save a partial XML. |
| Same event name appears in different folders | Add a deterministic folder suffix to prevent output collisions. |

## Validation

Run the offline regression tests after changing the generator:

```powershell
py -3.13 -m unittest tests/test_aria_crash_simulation_xml.py -v
```

## Completion Criteria

The task is complete only when every requested event has a `success` report row, every XML is
structurally equivalent to the approved reference except for allowed axis values, all mapped TXT
paths exist, inversion provenance is visible, and the user has reviewed the report before any ARIA
HIL import or bench action.