"""Generate template-preserving ARIA crash-simulation XML files from LSB TXT curves."""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree as ET

try:
    from openpyxl import load_workbook
except ImportError:  # The feature is optional until an XLSX configuration is supplied.
    load_workbook = None


CURVE_WITH_EVENT_PATTERN = re.compile(
    r"^(?P<event>.+?)_LSB_(?P<signal>.+?)_2k(?:_|$)", re.IGNORECASE
)
CURVE_SIGNAL_PATTERN = re.compile(
    r"(?:^|_)LSB_(?P<signal>.+?)_2k(?:_|$)", re.IGNORECASE
)
ALLOWED_AXIS_CHANGES = {"FilePath", "IsInverted"}
MAPPING_LIST_KEYS = ("mappings", "sensors", "axes", "records")
DEFAULT_TEMPLATE = (
    Path(__file__).resolve().parents[3]
    / "docs"
    / "project_documents"
    / "common_crash_xml"
    / "reference_xml.xml"
)

HEADER_ALIASES = {
    "channel": {
        "channel",
        "channelassignment",
        "ariachannel",
        "sensorchannel",
        "rsuchannel",
        "type",
    },
    "axis_index": {"axisindex", "axisnumber", "axisposition", "index"},
    "signal": {
        "signal",
        "signalname",
        "templatesignal",
        "curve",
        "curvename",
        "txtsignal",
        "crashsignal",
    },
    "sensor": {"sensor", "sensorlocation", "location", "rsuname", "rsu", "sensorname"},
    "axis": {"axis", "axisassignment", "axismapping"},
    "inverted": {"inverted", "isinverted", "inversion", "inversionrequirement"},
    "variant": {"sensorvariant", "variant", "rsuvariant", "sensortype"},
}


class InputValidationError(ValueError):
    """Raised when a source cannot safely produce a crash XML."""


@dataclass(frozen=True)
class CurveRecord:
    folder: str
    event: str
    signal: str
    path: Path


@dataclass(frozen=True)
class MappingEntry:
    source: str
    row: str
    channel: str | None = None
    axis_index: int | None = None
    signal: str | None = None
    sensor: str | None = None
    axis: str | None = None
    inverted: bool | None = None
    variant: str | None = None

    @property
    def label(self) -> str:
        return f"{self.source}:{self.row}"

    def derived_signal(self) -> str | None:
        """Build a signal key only when a configuration row provides enough evidence."""
        if self.signal:
            return self.signal
        if not self.sensor:
            return None
        if not self.axis:
            return self.sensor

        axis_value = self.axis.strip()
        normalized_axis = _normalize_name(axis_value)
        if normalized_axis in {"x", "y", "z"}:
            return f"{self.sensor}_Acc_{axis_value.upper()}"
        return f"{self.sensor}_{axis_value}"


@dataclass
class TemplateAxis:
    sensor_type: str
    axis_index: int
    element: ET.Element
    original_path: str
    original_inverted: str | None
    expected_signal: str | None

    @property
    def key(self) -> tuple[str, int]:
        return self.sensor_type, self.axis_index

    @property
    def label(self) -> str:
        return f"{self.sensor_type}[{self.axis_index}]"


@dataclass
class EventResult:
    crash_name: str
    source_folder: str
    xml_name: str
    signals_mapped: int = 0
    missing_signals: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    status: str = "pending"
    xml_path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "crash_name": self.crash_name,
            "source_folder": self.source_folder,
            "generated_xml_name": self.xml_name,
            "generated_xml_path": self.xml_path,
            "signals_mapped": self.signals_mapped,
            "missing_signals": self.missing_signals,
            "warnings": self.warnings,
            "errors": self.errors,
            "generation_status": self.status,
        }


def _local_name(tag: Any) -> str:
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1]


def _normalize_name(value: object) -> str:
    text = str(value or "").strip()
    text = re.sub(r"new\s*rsu", "rsu", text, flags=re.IGNORECASE)
    return re.sub(r"[^a-z0-9]+", "", text.lower())


def _clean_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _parse_boolean(value: object, *, context: str) -> bool | None:
    text = _clean_text(value)
    if text is None:
        return None
    normalized = text.casefold()
    if normalized in {"true", "yes", "y", "1"}:
        return True
    if normalized in {"false", "no", "n", "0"}:
        return False
    raise InputValidationError(f"Invalid inversion value '{text}' at {context}; use True/False, Yes/No, or 1/0.")


def _parse_axis_index(value: object, *, context: str) -> int | None:
    text = _clean_text(value)
    if text is None:
        return None
    match = re.search(r"\d+", text)
    if match is None:
        raise InputValidationError(f"Invalid axis index '{text}' at {context}; use a one-based integer.")
    index = int(match.group())
    if index < 1:
        raise InputValidationError(f"Axis index must be one or greater at {context}.")
    return index


def _extract_signal_from_curve_name(file_path: str | Path) -> str | None:
    stem = Path(file_path).stem
    match = CURVE_SIGNAL_PATTERN.search(stem)
    return match.group("signal").strip() if match else None


def _header_fields(headers: Iterable[object]) -> dict[str, int]:
    fields: dict[str, int] = {}
    for index, header in enumerate(headers):
        normalized = _normalize_name(header)
        if not normalized:
            continue
        for field_name, aliases in HEADER_ALIASES.items():
            if normalized in aliases and field_name not in fields:
                fields[field_name] = index
                break
    return fields


def _looks_like_mapping_header(fields: dict[str, int]) -> bool:
    return bool({"channel", "signal", "sensor"} & set(fields)) and bool(
        {"inverted", "axis", "axis_index", "signal"} & set(fields)
    )


def _canonical_record(raw_record: dict[object, object]) -> dict[str, object]:
    header_values = list(raw_record.keys())
    fields = _header_fields(header_values)
    if not _looks_like_mapping_header(fields):
        raise InputValidationError(
            "Configuration header must identify a channel, signal, or sensor and at least one mapping/inversion field."
        )
    return {
        field_name: raw_record.get(header_values[index])
        for field_name, index in fields.items()
    }


def _build_mapping_entry(source: str, row: str, values: dict[str, object]) -> MappingEntry:
    channel = _clean_text(values.get("channel"))
    signal = _clean_text(values.get("signal"))
    sensor = _clean_text(values.get("sensor"))
    axis = _clean_text(values.get("axis"))
    if not any((channel, signal, sensor)):
        raise InputValidationError(f"No channel, signal, or sensor identifier at {source}:{row}.")
    return MappingEntry(
        source=source,
        row=row,
        channel=channel,
        axis_index=_parse_axis_index(values.get("axis_index"), context=f"{source}:{row}"),
        signal=signal,
        sensor=sensor,
        axis=axis,
        inverted=_parse_boolean(values.get("inverted"), context=f"{source}:{row}"),
        variant=_clean_text(values.get("variant")),
    )


def _read_excel_mappings(path: Path) -> list[MappingEntry]:
    if load_workbook is None:
        raise InputValidationError(
            "openpyxl is required for XLSX inversion configuration. Install the skill requirements first."
        )

    workbook = load_workbook(path, data_only=True, read_only=True)
    mappings: list[MappingEntry] = []
    discovered_sheets: list[str] = []
    try:
        for worksheet in workbook.worksheets:
            row_iterator = worksheet.iter_rows(values_only=True)
            fields: dict[str, int] | None = None
            header_row = 0
            for row_number, row in enumerate(row_iterator, start=1):
                candidate_fields = _header_fields(row)
                if _looks_like_mapping_header(candidate_fields):
                    fields = candidate_fields
                    header_row = row_number
                    discovered_sheets.append(worksheet.title)
                    break

            if fields is None:
                continue

            for row_number, row in enumerate(row_iterator, start=header_row + 1):
                values = {
                    field_name: row[column_index] if column_index < len(row) else None
                    for field_name, column_index in fields.items()
                }
                if not any(_clean_text(value) is not None for value in values.values()):
                    continue
                mappings.append(
                    _build_mapping_entry(
                        f"{path.name}:{worksheet.title}",
                        str(row_number),
                        values,
                    )
                )
    finally:
        workbook.close()

    if not discovered_sheets:
        raise InputValidationError(
            f"No recognized mapping header was found in any worksheet of {path}."
        )
    return mappings


def _read_delimited_mappings(path: Path) -> list[MappingEntry]:
    content = path.read_text(encoding="utf-8-sig")
    if not content.strip():
        raise InputValidationError(f"Configuration file is empty: {path}")
    try:
        dialect = csv.Sniffer().sniff(content[:4096], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel

    reader = csv.DictReader(content.splitlines(), dialect=dialect)
    if not reader.fieldnames:
        raise InputValidationError(f"Configuration file has no header row: {path}")

    mappings: list[MappingEntry] = []
    for row_number, row in enumerate(reader, start=2):
        if not any(_clean_text(value) is not None for value in row.values()):
            continue
        mappings.append(
            _build_mapping_entry(path.name, str(row_number), _canonical_record(row))
        )
    return mappings


def _read_json_mappings(path: Path) -> list[MappingEntry]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if isinstance(payload, dict):
        records: object = next(
            (payload[key] for key in MAPPING_LIST_KEYS if isinstance(payload.get(key), list)),
            payload if any(_normalize_name(key) in {alias for aliases in HEADER_ALIASES.values() for alias in aliases} for key in payload) else None,
        )
    else:
        records = payload

    if isinstance(records, dict):
        records = [records]
    if not isinstance(records, list):
        raise InputValidationError(
            f"JSON configuration must be a mapping list or contain one of: {', '.join(MAPPING_LIST_KEYS)}."
        )

    mappings: list[MappingEntry] = []
    for row_number, row in enumerate(records, start=1):
        if not isinstance(row, dict):
            raise InputValidationError(f"JSON mapping entry {row_number} in {path} is not an object.")
        mappings.append(
            _build_mapping_entry(path.name, str(row_number), _canonical_record(row))
        )
    return mappings


def read_mapping_configuration(path: Path | None) -> list[MappingEntry]:
    """Read supported configuration formats into header-normalized mapping entries."""
    if path is None:
        return []
    if not path.is_file():
        raise InputValidationError(f"Inversion configuration file does not exist: {path}")

    suffix = path.suffix.casefold()
    if suffix == ".xlsx":
        mappings = _read_excel_mappings(path)
    elif suffix == ".json":
        mappings = _read_json_mappings(path)
    elif suffix in {".csv", ".txt"}:
        content = path.read_text(encoding="utf-8-sig").lstrip()
        mappings = _read_json_mappings(path) if content.startswith(("{", "[")) else _read_delimited_mappings(path)
    else:
        raise InputValidationError(
            f"Unsupported inversion configuration format: {path.suffix}. Use XLSX, CSV, TXT, or JSON."
        )

    if not mappings:
        raise InputValidationError(f"No mapping rows were found in inversion configuration: {path}")
    return mappings


def _xml_parser() -> ET.XMLParser:
    return ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))


def parse_reference_template(path: Path) -> tuple[ET.Element, list[TemplateAxis]]:
    if not path.is_file():
        raise InputValidationError(f"Reference XML template does not exist: {path}")
    try:
        root = ET.parse(path, parser=_xml_parser()).getroot()
    except ET.ParseError as error:
        raise InputValidationError(f"Reference XML is invalid: {path}: {error}") from error

    if _local_name(root.tag) != "CrashSimulationSensors":
        raise InputValidationError(
            f"Reference XML root must be CrashSimulationSensors, found {_local_name(root.tag)!r}."
        )

    axes: list[TemplateAxis] = []
    seen_sensor_types: set[str] = set()
    for sensor in (element for element in root if _local_name(element.tag) == "Sensor"):
        sensor_type = _clean_text(sensor.get("Type"))
        if sensor_type is None:
            raise InputValidationError("A reference Sensor element has no Type attribute.")
        if sensor_type in seen_sensor_types:
            raise InputValidationError(f"Reference XML contains duplicate Sensor Type {sensor_type!r}.")
        seen_sensor_types.add(sensor_type)

        sensor_axes = [element for element in sensor if _local_name(element.tag) == "Axis"]
        if not sensor_axes:
            raise InputValidationError(f"Reference sensor {sensor_type} has no Axis elements.")
        for axis_index, axis in enumerate(sensor_axes, start=1):
            original_path = axis.get("FilePath")
            if original_path is None:
                raise InputValidationError(f"Reference axis {sensor_type}[{axis_index}] has no FilePath attribute.")
            axes.append(
                TemplateAxis(
                    sensor_type=sensor_type,
                    axis_index=axis_index,
                    element=axis,
                    original_path=original_path,
                    original_inverted=axis.get("IsInverted"),
                    expected_signal=_extract_signal_from_curve_name(original_path),
                )
            )
    if not axes:
        raise InputValidationError("Reference XML contains no Sensor/Axis entries.")
    return root, axes


def _structure_fingerprint(element: ET.Element) -> tuple[Any, ...]:
    if not isinstance(element.tag, str):
        return ("#comment", element.text)
    attributes = tuple(
        sorted(
            (name, value)
            for name, value in element.attrib.items()
            if not (_local_name(element.tag) == "Axis" and name in ALLOWED_AXIS_CHANGES)
        )
    )
    return (
        element.tag,
        attributes,
        tuple(_structure_fingerprint(child) for child in element),
    )


def _template_axes_from_root(root: ET.Element) -> list[TemplateAxis]:
    axes: list[TemplateAxis] = []
    for sensor in (element for element in root if _local_name(element.tag) == "Sensor"):
        sensor_type = sensor.get("Type")
        if sensor_type is None:
            continue
        for axis_index, axis in enumerate(
            (element for element in sensor if _local_name(element.tag) == "Axis"),
            start=1,
        ):
            original_path = axis.get("FilePath", "")
            axes.append(
                TemplateAxis(
                    sensor_type=sensor_type,
                    axis_index=axis_index,
                    element=axis,
                    original_path=original_path,
                    original_inverted=axis.get("IsInverted"),
                    expected_signal=_extract_signal_from_curve_name(original_path),
                )
            )
    return axes


def scan_crash_curves(source_root: Path, *, event_from_parent: bool = False) -> tuple[list[CurveRecord], list[str]]:
    if not source_root.is_dir():
        raise InputValidationError(f"Crash signal root does not exist: {source_root}")

    records: list[CurveRecord] = []
    unrecognized: list[str] = []
    for path in sorted(source_root.rglob("*"), key=lambda item: str(item).casefold()):
        if not path.is_file() or path.suffix.casefold() != ".txt":
            continue
        match = CURVE_WITH_EVENT_PATTERN.match(path.stem)
        if match:
            event = match.group("event").strip()
            signal = match.group("signal").strip()
        elif event_from_parent:
            signal = _extract_signal_from_curve_name(path) or ""
            event = path.parent.name.strip()
            if not signal or not event:
                unrecognized.append(str(path))
                continue
        else:
            unrecognized.append(str(path))
            continue

        folder = path.parent.relative_to(source_root).as_posix() or "."
        records.append(CurveRecord(folder=folder, event=event, signal=signal, path=path))
    return records, unrecognized


def group_crash_events(records: Iterable[CurveRecord]) -> dict[tuple[str, str], list[CurveRecord]]:
    groups: dict[tuple[str, str], list[CurveRecord]] = defaultdict(list)
    for record in records:
        groups[(record.folder, record.event)].append(record)
    return dict(sorted(groups.items(), key=lambda item: (item[0][1].casefold(), item[0][0].casefold())))


def _axis_matches_entry_by_signal(axis: TemplateAxis, entry: MappingEntry) -> bool:
    if axis.expected_signal is None:
        return False
    expected = _normalize_name(axis.expected_signal)
    if entry.signal:
        return expected == _normalize_name(entry.signal)
    if not entry.sensor:
        return False

    sensor = _normalize_name(entry.sensor)
    if not sensor or sensor not in expected:
        return False
    if not entry.axis:
        return True
    normalized_axis = _normalize_name(entry.axis)
    axis_candidates = {normalized_axis}
    if normalized_axis in {"x", "y", "z"}:
        axis_candidates.add(f"acc{normalized_axis}")
    return any(expected.endswith(candidate) for candidate in axis_candidates if candidate)


def _select_mapping_entry(
    axis: TemplateAxis,
    entries: list[MappingEntry],
    axes_per_sensor: dict[str, int],
) -> tuple[MappingEntry | None, list[str]]:
    explicit = [
        entry
        for entry in entries
        if entry.channel
        and _normalize_name(entry.channel) == _normalize_name(axis.sensor_type)
        and (
            entry.axis_index == axis.axis_index
            or (
                entry.axis_index is None
                and axes_per_sensor[axis.sensor_type] == 1
            )
        )
    ]
    if len(explicit) > 1:
        return None, [f"More than one configuration row targets {axis.label}: {', '.join(item.label for item in explicit)}."]
    if explicit:
        return explicit[0], []

    semantic = [
        entry
        for entry in entries
        if _axis_matches_entry_by_signal(axis, entry)
        and (not entry.channel or _normalize_name(entry.channel) == _normalize_name(axis.sensor_type))
    ]
    if len(semantic) > 1:
        return None, [
            f"Ambiguous configuration rows for {axis.label}: {', '.join(item.label for item in semantic)}. "
            "Use Channel plus Axis Index."
        ]
    return (semantic[0], []) if semantic else (None, [])


def _event_file_index(records: list[CurveRecord]) -> tuple[dict[str, list[CurveRecord]], list[str]]:
    indexed: dict[str, list[CurveRecord]] = defaultdict(list)
    for record in records:
        indexed[_normalize_name(record.signal)].append(record)
    duplicates = [
        f"{records_for_signal[0].signal}: {', '.join(str(item.path) for item in records_for_signal)}"
        for records_for_signal in indexed.values()
        if len(records_for_signal) > 1
    ]
    return indexed, duplicates


def _sanitize_file_stem(value: str) -> str:
    normalized = re.sub(r'[<>:"/\\|?*]+', "_", value)
    normalized = re.sub(r"\s+", "_", normalized).strip("._ ")
    return normalized or "unnamed_crash"


def _event_file_names(groups: dict[tuple[str, str], list[CurveRecord]]) -> dict[tuple[str, str], str]:
    name_counts: dict[str, int] = defaultdict(int)
    for _, event in groups:
        name_counts[event] += 1

    names: dict[tuple[str, str], str] = {}
    used: set[str] = set()
    for folder, event in groups:
        base = _sanitize_file_stem(event)
        if name_counts[event] > 1:
            base = f"{base}_{_sanitize_file_stem(folder.replace('/', '_'))}"
        candidate = f"{base}.xml"
        if candidate.casefold() in used:
            digest = hashlib.sha1(f"{folder}\0{event}".encode("utf-8")).hexdigest()[:8]
            candidate = f"{base}_{digest}.xml"
        used.add(candidate.casefold())
        names[(folder, event)] = candidate
    return names


def _verify_structure(reference_root: ET.Element, generated_root: ET.Element) -> None:
    if _structure_fingerprint(reference_root) != _structure_fingerprint(generated_root):
        raise InputValidationError(
            "Generated XML changed an element, ordering, or non-axis attribute outside FilePath/IsInverted."
        )


def _write_xml(destination: Path, root: ET.Element, reference_root: ET.Element) -> None:
    temporary = destination.with_name(f".{destination.name}.tmp")
    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    tree.write(temporary, encoding="utf-8", xml_declaration=False, short_empty_elements=True)
    try:
        generated_root = ET.parse(temporary, parser=_xml_parser()).getroot()
        _verify_structure(reference_root, generated_root)
        temporary.replace(destination)
    finally:
        if temporary.exists():
            temporary.unlink()


def _render_event(
    reference_root: ET.Element,
    reference_axes: list[TemplateAxis],
    mappings: list[MappingEntry],
    event_records: list[CurveRecord],
    result: EventResult,
) -> ET.Element | None:
    generated_root = copy.deepcopy(reference_root)
    generated_axes = _template_axes_from_root(generated_root)
    if [axis.key for axis in generated_axes] != [axis.key for axis in reference_axes]:
        result.errors.append("Copied XML does not preserve the reference sensor/axis ordering.")
        return None

    axes_per_sensor: dict[str, int] = defaultdict(int)
    for axis in reference_axes:
        axes_per_sensor[axis.sensor_type] += 1
    indexed_files, duplicate_signals = _event_file_index(event_records)
    result.errors.extend(f"Duplicate crash signal for one event: {duplicate}" for duplicate in duplicate_signals)
    if result.errors:
        return None

    selected_entries: dict[str, int] = defaultdict(int)
    for reference_axis, generated_axis in zip(reference_axes, generated_axes, strict=True):
        entry, selection_errors = _select_mapping_entry(reference_axis, mappings, axes_per_sensor)
        result.errors.extend(selection_errors)
        if selection_errors:
            continue
        if entry is not None:
            selected_entries[entry.label] += 1

        signal = (
            entry.derived_signal()
            if entry is not None and entry.derived_signal() is not None
            else reference_axis.expected_signal
        )
        if signal:
            candidates = indexed_files.get(_normalize_name(signal), [])
            if len(candidates) == 1:
                generated_axis.element.set("FilePath", str(candidates[0].path))
                result.signals_mapped += 1
            elif not candidates:
                result.missing_signals.append(f"{reference_axis.label} -> {signal}")
            else:
                result.errors.append(
                    f"Ambiguous TXT mapping for {reference_axis.label} -> {signal}: "
                    f"{', '.join(str(candidate.path) for candidate in candidates)}"
                )
        elif reference_axis.original_path not in {"", "Empty"}:
            result.errors.append(
                f"Cannot derive a signal key for required reference axis {reference_axis.label}; "
                "add an explicit Channel/Axis Index/Signal mapping."
            )

        if entry is not None and entry.inverted is not None:
            generated_axis.element.set("IsInverted", "True" if entry.inverted else "False")
        elif entry is not None:
            result.warnings.append(
                f"{reference_axis.label} retains reference inversion {reference_axis.original_inverted!r}; "
                f"{entry.label} has no inversion value."
            )

    for entry in mappings:
        use_count = selected_entries.get(entry.label, 0)
        if use_count == 0:
            result.errors.append(
                f"Configuration mapping {entry.label} does not identify an axis in the reference template."
            )
        elif use_count > 1:
            result.errors.append(
                f"Configuration mapping {entry.label} targets {use_count} axes; specify Channel plus Axis Index."
            )

    if result.missing_signals:
        result.errors.append("Required crash curves are missing; no partial XML will be saved.")
    if result.errors:
        return None

    try:
        _verify_structure(reference_root, generated_root)
    except InputValidationError as error:
        result.errors.append(str(error))
        return None
    return generated_root


def _write_report(output_directory: Path, results: list[EventResult], unrecognized_files: list[str]) -> dict[str, str]:
    output_directory.mkdir(parents=True, exist_ok=True)
    report_rows = [result.to_dict() for result in results]
    report = {
        "events": report_rows,
        "unrecognized_txt_files": unrecognized_files,
        "summary": {
            "event_count": len(results),
            "success": sum(result.status == "success" for result in results),
            "dry_run": sum(result.status == "dry-run" for result in results),
            "failed": sum(result.status == "failed" for result in results),
            "blocked": sum(result.status == "blocked" for result in results),
            "unrecognized_txt_file_count": len(unrecognized_files),
        },
    }
    json_path = output_directory / "crash_xml_generation_report.json"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

    csv_path = output_directory / "crash_xml_generation_report.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as report_file:
        writer = csv.DictWriter(
            report_file,
            fieldnames=[
                "Crash Name",
                "Source Folder",
                "Generated XML Name",
                "Generated XML Path",
                "Signals Mapped",
                "Missing Signals",
                "Warnings",
                "Errors",
                "Generation Status",
            ],
        )
        writer.writeheader()
        for result in results:
            writer.writerow(
                {
                    "Crash Name": result.crash_name,
                    "Source Folder": result.source_folder,
                    "Generated XML Name": result.xml_name,
                    "Generated XML Path": result.xml_path or "",
                    "Signals Mapped": result.signals_mapped,
                    "Missing Signals": "; ".join(result.missing_signals),
                    "Warnings": "; ".join(result.warnings),
                    "Errors": "; ".join(result.errors),
                    "Generation Status": result.status,
                }
            )
    return {"json": str(json_path), "csv": str(csv_path)}


def generate_crash_simulation_xmls(
    *,
    template_path: Path,
    source_root: Path,
    output_directory: Path,
    inversion_config: Path | None = None,
    write: bool = False,
    overwrite: bool = False,
    event_from_parent: bool = False,
) -> dict[str, Any]:
    """Validate or write one structurally-preserved XML per detected crash event."""
    reference_root, reference_axes = parse_reference_template(template_path)
    mappings = read_mapping_configuration(inversion_config)
    records, unrecognized_files = scan_crash_curves(source_root, event_from_parent=event_from_parent)
    groups = group_crash_events(records)
    if not groups:
        raise InputValidationError(f"No event-qualified LSB TXT curves were found below: {source_root}")

    names = _event_file_names(groups)
    results: list[EventResult] = []
    inversion_block = write and inversion_config is None
    for (folder, event), event_records in groups.items():
        result = EventResult(crash_name=event, source_folder=folder, xml_name=names[(folder, event)])
        if unrecognized_files:
            result.warnings.append(
                f"{len(unrecognized_files)} TXT file(s) were not event-qualified and were excluded; see report."
            )

        if inversion_block:
            result.errors.append(
                "Write mode requires a project-specific inversion/configuration file. Provide --inversion-config."
            )
            result.status = "blocked"
            results.append(result)
            continue

        generated_root = _render_event(reference_root, reference_axes, mappings, event_records, result)
        if generated_root is None:
            result.status = "failed"
            results.append(result)
            continue

        if not write:
            result.status = "dry-run"
            results.append(result)
            continue

        output_directory.mkdir(parents=True, exist_ok=True)
        destination = output_directory / result.xml_name
        if destination.exists() and not overwrite:
            result.errors.append(f"Output XML already exists: {destination}. Re-run with --overwrite to replace it.")
            result.status = "failed"
            results.append(result)
            continue

        try:
            _write_xml(destination, generated_root, reference_root)
        except (OSError, ET.ParseError, InputValidationError) as error:
            result.errors.append(f"Unable to save or validate XML: {error}")
            result.status = "failed"
        else:
            result.xml_path = str(destination)
            result.status = "success"
        results.append(result)

    report_paths = _write_report(output_directory, results, unrecognized_files)
    return {
        "template": str(template_path),
        "source_root": str(source_root),
        "output_directory": str(output_directory),
        "inversion_config": str(inversion_config) if inversion_config else None,
        "write": write,
        "report": report_paths,
        "events": [result.to_dict() for result in results],
        "summary": {
            "event_count": len(results),
            "success": sum(result.status == "success" for result in results),
            "dry_run": sum(result.status == "dry-run" for result in results),
            "failed": sum(result.status == "failed" for result in results),
            "blocked": sum(result.status == "blocked" for result in results),
        },
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate template-preserving ARIA CrashSimulationSensors XML files from LSB TXT curves."
    )
    parser.add_argument(
        "--template",
        type=Path,
        default=DEFAULT_TEMPLATE,
        help="Approved CrashSimulationSensors XML template. Defaults to the repository reference XML.",
    )
    parser.add_argument("--source-root", type=Path, required=True, help="Root directory to scan recursively for TXT curves.")
    parser.add_argument("--output", type=Path, required=True, help="Dedicated directory for XML files and reports.")
    parser.add_argument(
        "--inversion-config",
        type=Path,
        help="Project-specific XLSX, CSV, TXT, or JSON mapping/inversion evidence. Required for --write.",
    )
    parser.add_argument("--write", action="store_true", help="Write XML files after validation. Omit for a report-only dry run.")
    parser.add_argument("--overwrite", action="store_true", help="Allow replacement of an existing generated XML file.")
    parser.add_argument(
        "--event-from-parent",
        action="store_true",
        help="Use the immediate parent directory as event identity for TXT filenames without an event prefix.",
    )
    return parser


def main(arguments: list[str] | None = None) -> int:
    parser = build_parser()
    parsed = parser.parse_args(arguments)
    try:
        summary = generate_crash_simulation_xmls(
            template_path=parsed.template,
            source_root=parsed.source_root,
            output_directory=parsed.output,
            inversion_config=parsed.inversion_config,
            write=parsed.write,
            overwrite=parsed.overwrite,
            event_from_parent=parsed.event_from_parent,
        )
    except InputValidationError as error:
        print(f"Validation failed: {error}", file=sys.stderr)
        return 2

    print(json.dumps(summary["summary"], indent=2))
    print(f"Validation report: {summary['report']['json']}")
    return 0 if not summary["summary"]["failed"] and not summary["summary"]["blocked"] else 2


if __name__ == "__main__":
    raise SystemExit(main())