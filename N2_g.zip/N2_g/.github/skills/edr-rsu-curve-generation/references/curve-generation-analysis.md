# Curve_Generation: analysis and integration record

**Outcome.** The `Curve_Generation` folder contains one program, `crash_curve_tool.py`
(5,040 lines: curve engine, Tkinter GUI, thin CLI). It is vendored unchanged into
`scripts/vendor/` and driven by `scripts/edr_curve_runner.py`. The runner exposes every GUI
workflow on the command line, reads the EDR Delta-V DID layout from the project's
`edr_config.py`, and adds polarity checks against the HIL profile.

The analysis found two defects that matter for EDR recording tests:

- **F1**: in the shipped synthetic left and right sets, CTY reaches the ECU with the same sign.
- **F3**: the tool's expected DID signs are not the reported EDR signs.

**Framework conventions** (stated by the user 2026-10-21; rules R1 and R2 in
`edr-agent.agent.md` section 0):

- **R1, always-on algorithm.** Every project runs a continuously running crash algorithm. T0 is
  the continuous delta-V criterion, and the end of event is the **resultant** 20 ms criterion of
  49 CFR 563.5.
- **R2, AUTOSAR onboard axis.** Onboard acceleration follows the AUTOSAR vehicle axis, so the
  ECU-input signs are front X -, rear X +, left Y -, right Y +.

The findings below are evaluated against both rules.

Line numbers below refer to `scripts/vendor/crash_curve_tool.py`, identical to the source.
Analysis date 2026-10-21.

## 1. Source folder inventory

Source: `C:\Users\cpchr\Downloads\BT\Tax_T5\Tax_T5\Curve_Generation` (read 2026-10-21).

| Item | What it is | Disposition |
|---|---|---|
| `crash_curve_tool.py` | Engine + GUI + CLI | Vendored unchanged |
| `Copying_File_Names_txt.py` | Tkinter folder lister (writes `file_list.txt`) | Not needed |
| `Curve_Generation.md`, `Multi_Event_Curve_Generation_Note.txt`, `Finding_t0_from _exisitng_curves.txt`, `Curve_genrator_tool_usage.docx` | Requirements and usage notes | Summarised here |
| `requirements.txt` | Sensor resolution table (not a pip file) | Encoded in engine `SENSORS` (lines 164-172) |
| `change_velocity.csv` | DID 0x0455 Delta-V layout, 60 rows, spec numbering | Replaced by project `edr_config.py` (F2) |
| `output_input_comparison.csv` | 600 rows: input LSB vs ECU stored Delta-V byte | Evidence only (F4) |
| `14062026`, `24062026`, `Seperate_Folder`, `fresh_folder_U171`, `Fresh_Generation_U171`, `front_crash_2026-05-30`, `multi_crash_*`, `processed_output*` | Generated sets and earlier outputs | Inputs, not tool |
| `z121`, `DV_50K_RFB_RMR160625C1_Rear` (P212 G1 EV, ADAPT export with `.csh`), `32KPOL_18022301` | Real crash recordings with ARIA profiles | Inputs, not tool |
| `.venv`, `.venv-1`, `__pycache__` | Environments | Ignored |

Security read: the engine imports only the standard library plus optional `openpyxl`. It has no
subprocess, network, `eval` or `exec`; the only OS call is `os.startfile` in
`open_output_folder` (line 782).

## 2. Core logic

### 2.1 Sensor model

`SensorSpec(name, max_g, max_lsb)`, `g_per_lsb = max_g / max_lsb`, LSB clamped to
`+/-max_lsb` (lines 146-172).

| Key | Sensor (source table) | Range | Max LSB | g/LSB |
|---|---|---|---|---|
| `onboard_x_128g` | Gen6 ECU 128G | 128 g | 2047 | 0.062530 |
| `onboard_y_64g` | Gen6 ECU 64G | 64 g | 2047 | 0.031265 |
| `sat_x_240g` / `sat_y_240g` | RSU 240G Uncomp | 240 g | 480 | 0.5 |
| `sat_x_120g` / `sat_y_120g` | RSU 120G Uncomp | 120 g | 480 | 0.25 |
| `sat_60g` | RSU 60G Uncomp | 60 g | 480 | 0.125 |

### 2.2 Curve parsing (lines 903-1019)

- Each line yields its **last integer token**. Lines like `key: value`, `# key = value` or
  `// key: value` become metadata.
- Metadata keys: `crash_type`, `axis`, `sensor_key`, `max_g`, `max_lsb`, `g_per_lsb`, and
  `sample_dt_s` / `sample_dt_ms` / `sample_dt_us`. The default sample interval is 500 us.
- Without metadata, the crash type, axis and sensor are inferred from path and file-name tokens
  (lines 789-900). The fragment between `LSB_` and `_2k` is the channel key used everywhere
  (line 661).

### 2.3 Delta-V (lines 605, 1816-1823)

`dV[km/h] = sum(LSB * g_per_lsb) * 9.80665 * dt * 3.6`. At 2 kHz that is 0.017652 km/h per
g-sample.

### 2.4 T0 and Tend (lines 1605-1637, 194-200)

| Crash | Axis | Threshold | Window |
|---|---|---|---|
| front, rear | X | 0.8 km/h | 20 ms (40 samples) |
| left, right | Y | 0.8 km/h | 5 ms (10 samples) |
| near | X | 0.2 km/h | 20 ms |

- **T0** is the first sample *n* where `|sum of g over the window ending at n| * factor >= threshold`.
  It is direction-blind because of the absolute value.
- **Tend** is the first sample after T0 where the 20 ms rolling `|dV|` on the same single axis,
  against the same threshold, falls to the threshold or below.
- For a folder, the reported T0 is the earliest over the crash type's primary channels.

### 2.5 Waveform builders

| Builder | Lines | Shape |
|---|---|---|
| `build_demo_waveform` | 1640 | Half-sine pulse at `start_sample`, `width_samples`, `peak_g` |
| `build_sustained_trigger_waveform` | 1770 | Primary channels: full 600 samples, kept above the wake rate x1.12 with sine modulation, never below 1 LSB |
| `build_non_primary_waveform` | 1714 | Random base 0.5-1.0 g (X) / 1.0-1.8 g (Y), 1-2 random spikes up to 2-3 g, **random module unseeded** |
| `populate_zero_samples` | 1750 | Fills zeros with 1-6 LSB smooth baseline |
| `build_longitudinal_delta_v_waveform` | 1826 | Sine-weighted LSB distribution summing exactly to a target dV |
| `build_change_in_velocity_waveform` | 1913 | Crash-confirmation half-sine plus tail so dV from T0 over the pulse window meets the target |
| `inject_out_of_range_after_index` | 1660 | Pushes samples beyond `max_lsb` (x scale) after T0 + window |
| `enforce_abs_delta_v_cap` | 1976 | Scales down until total `|dV|` <= cap |

### 2.6 Crash set definitions (`DEMO_CRASH_CASES`, lines 291-418)

| Set | Primary channels (drive T0) | Other channels |
|---|---|---|
| front | Front Left/Right RSU Acc X (240 g), Central Acc X (128 g) | Front RSU Y high amplitude, side A/B/C pillars low, Mid Center RSU X low |
| left | Side A/B/C-Pillar Left Acc Y (240 g), Central Acc Y (64 g) | All other channels low |
| right | Side A/B/C-Pillar Right Acc Y, Central Acc Y | All other channels low |
| rear | Central Acc X (forced positive, threshold 1.2 km/h) | Front RSU X 70-80 g and side X 60 g half-sines, Mid Center X 100 g |
| near | Central Acc X 12 g (0.2 km/h rule) | Every other channel file zero-filled |

All outputs are positive by design ("inversions can change based on the sensor mounting", per
`Curve_Generation.md`); the HIL profile is expected to apply mounting inversion.

### 2.7 Workflows

| GUI action | Engine call | Runner command | Outputs |
|---|---|---|---|
| Process Curves | `CrashCurveProcessor.process` (3797) | `process` | Crash-type folders with copies and zero files, `crash_curve_analysis_<date>_<time>.xlsx` (4 sheets) |
| Generate Demo Files | `generate_demo_curves` (2779) | `generate` | `<type>_crash_<date>/` with 600-line LSB files, `Sensor_With_0_values.txt`, `t0_tend_summary.txt` |
| CTX/CTY 600-sample / High-Amplitude | `generate_ctx_cty_fullsample_curves` (3153) | `generate --variant ctx-cty-full / high-amp` | `<type>_crash_ctx_cty_full[_high_amp][_stress]_<date>/` |
| Out-of-Range Crash Sets | `generate_out_of_range_combo_curves` (3627) | `generate --variant out-of-range` | `<type>_crash_out_of_range_<date>/` |
| Multi-Event Crash Set | `generate_multi_event_curves` (2925) | `multi-event` | `multi_crash_<seq>_<date>_<time>/`, `multi_event_summary.txt`, `MultiEvent_profile.xml` if a source had one |
| Longitudinal Delta-V | `generate_longitudinal_delta_v_curve` / `validate_...` (3400 / 3324) | `delta-v-curve` / `delta-v-validate` | `longitudinal_delta_v_<pol>_<target>_kmph_<date>/`, `delta_v_validation_summary.txt` |
| Change in Velocity | `generate_change_in_velocity_curves` (3463) | `change-in-velocity` | `<type>_change_in_velocity_<target>_kmph_<date>/`, summary, DID expected CSV |
| Delta-V Notepad / Values | `export_curve_delta_v_notepad` / `_values_text` (1022 / 1082) | `delta-v-trace` | `*_delta_v_notepad.txt`, `*_cumulative_delta_v_kmph.txt` |
| Low-Amp Curve | `generate_low_amplitude_curve` (3312) | `low-amp` | `Custom_LowAmp_<g>_Acc_<axis>_2k_<date>.txt` |
| DID 0x0455 expected / compare | `calculate_did_0455_validation`, `compare_did_0455_response_bytes` (1340 / 1506) | `did-expected` / `did-compare` | `did_0455_expected_record_1.csv`, `did_0455_ecu_comparison.csv` |

### 2.8 Multi-event merge (lines 2925-3151)

- **Event types:** 2 to 7 events, chosen from front, left, right, rear and near.
- **Alignment:** each event is placed so its T0 lands at the requested T0-to-T0 delay from the
  previous event's T0. Overlapping waveforms are summed, and lead-in zeros are added when needed.
- **Inversion:** per-event tokens (`ctx`, `cty`, `flx` ... or `*`) negate the matching channels.
- **Source folders:** sources may be existing crash folders; all must share one sample interval,
  and each channel key may appear only once per folder.

### 2.9 DID 0x0455 expectation (lines 1101-1602)

| Field | How the engine computes it |
|---|---|
| Delta-V at *t* ms | The sum of `t/dt` samples from the T0 sample, so 0 ms is 0 and 10 ms is 20 samples |
| Longitudinal source | Central Acc X if present, else the first X file |
| Lateral source | Central Acc Y if present, else the first Y file |
| Sample sign | Negated when the folder's `CrashSimulationSensors_commonhnes.xml` marks the file `IsInverted` |
| Maximum and time of maximum | Running largest-magnitude dV from T0 to the **end of the file**, sign kept; the time is that sample's end time |
| Encoding | `raw = round((value - offset) / resolution)`, unsigned big-endian, range-checked against MIN/MAX |

## 3. Data flow

```
raw crash export (ADAPT .csh -> LSB_2K txt, ISO channel orientation)    synthetic parameters
        |                                                                   |
        v                                                                   v
 curve TXT folder + CrashSimulationSensors XML  <-----  engine generators (600 x 500 us LSB)
        |                                                   |
        +--> inspect / process: T0, Tend, dV, Excel          +--> t0_tend / delta_v summaries
        +--> polarity: file sign x IsInverted = ECU input sign, pair rules
        +--> did-expected: + project edr_config layout --> expected DID fields
        +--> did-compare: + ECU response hex (from a read the user made) --> match + sign verdict
        |
        v
 aria-crash-simulation-xml skill (new XML when no reference profile) --> HIL import (human)
```

## 4. Integration decisions

| Component | Decision | Reason |
|---|---|---|
| Engine module | Vendored unchanged, SHA-256 pinned | Upstream can be re-vendored and diffed; no hidden edits |
| GUI | Kept, reachable with `ui` | Existing users keep their tool |
| CLI (lines 4979-5029) | Superseded by the runner | Covered only process and demo generation |
| Hard-coded parameters | Overridable through `--config` (`export-config` writes the current values) | Parameterise without editing the engine |
| `change_velocity.csv` | Replaced by `projects/<P>/config/edr_config.py` | Project-specific values must come from project config (F2) |
| XML cloning | Engine clones a given profile; new XML via `aria-crash-simulation-xml` | No duplicate XML generator |
| Random noise | Runner seeds `random` (`--seed`) | Reproducible regeneration |
| Dates in names | Runner can freeze them (`--date`) | Byte-identical regeneration |
| Polarity | New `polarity` command with the AUTOSAR onboard expectations as default (R2); `did-compare` reports the sign verdict | Section 5 of `edr-agent.agent.md` |
| End of event | Runner computes the always-on end of event from onboard X/Y (`inspect`, generated `t0_tend_summary.txt`); engine Tend kept but labelled single-axis | R1; the engine's Tend is not the R1 definition (F6) |
| Report signs | Default longitudinal +1, lateral -1 | R2 + the AUTOSAR to Part 563 turn about X |

## 5. Findings

| ID | Finding | Evidence | Label / confidence |
|---|---|---|---|
| F1 | In `14062026` (UPP_EV profiles) the left **and** right sets drive onboard Y **negative** at the ECU. Against R2 the right sets are wrong (expected +); front (-) and left (-) conform. Real Z121 left/right give `-` / `+`, as R2 requires. | `polarity --input 14062026 z121` on 2026-10-21: `FAIL AUTOSAR onboard: right/central_acc_y +` for all three 14062026 right folders; `FAIL central_acc_y: left opposite to right` | Fact (computed), Very High. Whether the user re-inverts per run in the HIL is unknown |
| F2 | `change_velocity.csv` labels Delta-V `SIGNED` with offset -100; the raw is unsigned (raw 0 = -100 km/h). Its `POS_IN_BYTES` 219 is the spec byte; the framework reads the same field at 223. | `projects/U171/config/edr_config.py` header ("labelled SIGNED but carry an unsigned raw"); `tools/build_edr_config_from_diag.py:33` "specification byte b is n = b + 4"; U171/M310/Z121 `DeltaVLong.data_start_byte = 223` | Fact, Very High |
| F3 | The engine's expected DID signs are the **sensor-input** sign (curve x `IsInverted`), not the reported EDR sign. The runner applies the AUTOSAR to Part 563 report signs (+1 / -1) by default. | Lines 1269-1305; `edr-agent.agent.md` section 5.2 | Fact, High |
| F4 | `output_input_comparison.csv`: raw `7F` decodes to 0 and rises negative as positive input LSB rises. Matches neither offset -100 (raw 100 = 0) nor the engine encoding. | Rows 2-80 of the CSV | Fact (data); cause **Evidence unavailable.** |
| F5 | T0 is the sample where the window *ending* there reaches the threshold, with `>=`; Part 563 says "over 0.8 km/h" and "the first point in the interval". `inspect` adds `t0_window_start_sample` for the other reading. | Lines 1605-1623; 49 CFR 563.5 | Fact (code); regulation reading is an inference |
| F6 | The engine's Tend uses one axis and the crash's wake threshold; the always-on end of event (R1, 563.5) uses the **resultant** cumulative dV within 20 ms. On real crashes the two differ a lot: Z121 front 9.0 ms (engine) vs 170.0 ms (resultant); Z121 left 49.0 vs 79.5 ms; P212 rear 54.5 vs 90.5 ms. | Lines 2171-2177; 563.5; `inspect` 2026-10-21 | Fact, High |
| F7 | Maximum Delta-V integrates from T0 to the end of the file, not to 300 ms / EoE + 30 ms after T0. | Line 1322 | Fact, High |
| F8 | Every synthetic standard / ctx-cty / out-of-range set reports "Tend not reached": the sustained trigger keeps the window above threshold for all 300 ms. Recordings of these sets never exercise the EoE + 30 ms cut. | Runner smoke runs 2026-10-21 | Fact |
| F9 | Z-axis RSU files and the zero-filled side channels of near folders cannot be sensor-inferred and are reported as parse errors. | `inspect` on P212 + Z121 front: 15 of 45 files; generated job: 17 of 95 | Fact |
| F10 | The rear demo case uses 1.2 km/h (`REAR_DEMO_THRESHOLD_KMPH`) while `CRASH_RULES` rear is 0.8 km/h. | Lines 68, 196, 376 | Fact; intent unknown |
| F11 | Real P212 rear crash: CTX file negative, profile inverted, so `+` at the ECU, which conforms to R2. | `polarity` 2026-10-21: `PASS AUTOSAR onboard: rear/central_acc_x +` | Fact |
| F14 | Z121 front (`+`) and rear (`-`) are opposite to each other (pair rule passes) but **both reversed** on onboard X against R2. Z121 left/right conform. | `polarity --input z121` 2026-10-21: `FAIL AUTOSAR onboard: front/central_acc_x -`, `FAIL ... rear/central_acc_x +` | Fact (signs); whether the Z121 vehicle files compensate is unknown |
| F15 | The engine's folder T0 summary requires the exact channel key `central_acc_x`, so rear sets named `Rear Central_Acc_X` get no folder T0. `inspect` falls back to the onboard file's own T0 and says so. | Lines 2229-2237; `inspect z121/rear_crash`: fallback T0 sample 34 | Fact |
| F12 | Output paths near 260 characters fail on Windows; the engine's file names are about 80 characters. | Job smoke run 2026-10-21 | Fact |
| F13 | `process` writes zero files under the same names into sibling crash folders (Central X into left/right, Central Y into front) and copies Central Y into right. | Lines 3845-3857 | Fact |

## 6. Verification performed

All runs were offline and wrote into a scratch folder. No HIL, ARIA, bench or ECU was used.

| Check | Result |
|---|---|
| Vendored hash | Equals the source: `c087da50...c824` |
| Every runner command | Ran: export-config, inspect, process, generate (4 variants), multi-event (built-in, with source folders, invalid token), delta-v-curve, delta-v-validate, delta-v-trace, low-amp, change-in-velocity, did-expected (U171 OK; W610 and W616 refused), did-compare, polarity, run-job |
| Determinism | Two `generate --seed 7 --date 2026-10-21` runs: 105 TXT files byte-identical; same with the exported config passed back; `--seed 8` changed 44 noise files |
| DID round trip | A response built from the U171 expectation matched 56/56. With longitudinal signs inverted it matched 30/56, and the runner told the user to rerun with `--report-sign-long -1`; doing so matched 56/56 |
| AUTOSAR onboard default | `polarity` on 14062026 + Z121 + P212: front/left 14062026, Z121 left/right and P212 rear PASS; 14062026 right and Z121 front/rear FAIL |
| Always-on end of event | Test with an onboard Y pulse outlasting X: the resultant end sample equals an independent calculation and is later than the engine's single-axis Tend |
| Regression test | `tests/test_edr_rsu_curve_generation.py`: 13 tests, all pass |

## 7. Not done

- **No HIL or ECU run.** Generated sets were not replayed on the HIL, and no ECU response was
  read. The DID comparison was proven only on a response built from the expectation.
- **No reported-sign values per project.** The `--report-sign-*` values for each project are
  unknown; they come from the project's EDR sensor-report inversion configuration.
- **No ADAPT `.csh` parser.** The `.csh` is a binary/text hybrid, and its `Invert` and `T0`
  fields were read by eye only.
