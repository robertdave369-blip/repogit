# Input and output contract

All paths below are examples. Every value that differs per project comes from that project's
files: `projects/<P>/config/edr_config.py`, its HIL profiles and its crash exports.

## Curve TXT (input and output)

| Rule | Detail |
|---|---|
| Name | `<prefix>_LSB_<channel>_2k_<suffix>.txt`, e.g. `MXX_TestSignal_21102026_LSB_Side B-Pillar Left RSU_Acc_Y_2k_21-Oct-2026.txt`. `<channel>` is the key that matches files to profile axes and inversion tokens. |
| Body | One sample per line in sensor LSB, signed integers. The last integer token of a line is taken, so `000` and `12, 34` both work. |
| Length | Generators write 600 samples (300 ms at 2 kHz). Real ADAPT exports hold 601. |
| Metadata (optional) | `# key: value` lines: `crash_type`, `axis`, `sensor_key`, `max_g`, `max_lsb`, `g_per_lsb`, `sample_dt_s` / `_ms` / `_us`. |
| Sensor inference | From `128g` / `64g` / `240g` / `120g` / `60g` tokens, `Central_Acc_X/Y`, `ctx` / `cty`, or the crash type plus axis. Z-axis RSU files need `sensor_key` metadata. |

## HIL profile XML (`CrashSimulationSensors`)

```xml
<CrashSimulationSensors>
  <Sensor Type="RSU_CH1" Enable="True">
    <Axis FilePath="...\<curve>.txt" IsInverted="False" />
  </Sensor>
  <Sensor Type="GEN6_XY" Enable="True"> <Axis .../> x4 </Sensor>
  <Sensor Type="PANASONIC" Enable="True"> <Axis .../> x7 </Sensor>
</CrashSimulationSensors>
```

- Curves are matched by **file name** in the profile's own folder. Absolute `FilePath`s from
  another machine are fine.
- `IsInverted="True"` negates the curve before it reaches the ECU. The `polarity` command and
  the DID expectation both apply it.
- To build a new profile from curves, use the `aria-crash-simulation-xml` skill.

## EDR Delta-V DID layout

Built by `did-expected` / `did-compare` / `change-in-velocity` from `--project <P>`, written as
`did_delta_v_layout_<P>.csv` next to the results.

| Role | Element tried (in order) | Rows |
|---|---|---|
| `long_series` | `DeltaVLong`, `DeltaVLgt` | one per sample (`sample_range`, default 0..250 ms step 10 ms) |
| `lat_series` | `DeltaVLat` | as above |
| `max_long` / `max_lat` | `MaxDeltaVLgt` / `MaxDeltaVLat` | 1 |
| `time_max_long` / `time_max_lat` | `TimeMaxDeltaVLgt` / `TimeMaxDeltaVLat` | 1 |

- **Numbering:** `POS_IN_BYTES` = `data_start_byte`, which is 1-based over the **whole** positive
  response including the `62 xx xx` header. The framework reads it as `data[n - 1]`
  (`shared_libraries/edr_decoding_functions.py`, `read_edr_record_bytes`). The specification's
  own byte number is 4 lower (`tools/build_edr_config_from_diag.py:33`).
- **Required element keys:** `data_start_byte`, `scaling_factor`, and `offset` (offset may be
  missing only for the time elements). A signed raw is refused.
- **Overrides:** `--element-map long_series=<name> ...` replaces any role's element name.
- **Explicit file:** `--did-definition <csv>` supplies the layout instead. It needs the columns
  `DID` (`0x0455`), `PARAM_NAME`, `POS_IN_BYTES`, `LEN_IN_BYTES`, `OFFSET`, `RESOLUTION`, `UNIT`,
  `MIN_VALUE`, `MAX_VALUE`. Its numbering must match `--first-byte`.

## ECU response (`did-compare --ecu-response`)

- **Format:** hex bytes separated by spaces, commas, colons or dashes, either inline or as `@file`.
- **Full response:** pasted with `62 04 55 ...` and the default `--first-byte 1`.
- **Partial slice:** pass the layout number of its first byte as `--first-byte`.
- **Source:** the response comes from a read the user made with the framework or CANoe. The
  skill never reads the ECU.

## Polarity expectations (`polarity --convention`, `--expect`)

**Default, `--convention autosar` (rule R2, user, 2026-10-21):** onboard acceleration follows the
AUTOSAR vehicle axis, so the expected ECU-input signs are built in:

```json
{ "front": { "central_acc_x": "-" }, "rear": { "central_acc_x": "+" },
  "left":  { "central_acc_y": "-" }, "right": { "central_acc_y": "+" } }
```

- **Meaning:** each sign is the expected **ECU-input** sign (curve x `IsInverted`) of the
  crash's net Delta-V on that onboard channel.
- **Channel matching:** onboard channels are matched by role, so `Central_Acc_X` and
  `Rear Central_Acc_X` are both onboard X.
- **Overrides:** `--expect <json>`, in the format above, adds expectations or overrides
  individual entries. Use it for channels outside the default, such as satellites. Take the signs
  from a validated real crash of the same program (`polarity_report.csv`), never from another
  project.
- **Another convention:** only when the user specifies one, run with `--convention none`, which
  removes the AUTOSAR entries.
- **Pair rules:** the runner always checks, per input root, that onboard X has opposite signs
  for front and rear, and onboard Y opposite signs for left and right.

## Report signs (`did-expected`, `did-compare`, `change-in-velocity`)

| Option | Default | Basis |
|---|---|---|
| `--report-sign-long` | `+1` | AUTOSAR +X forward = Part 563 +X forward |
| `--report-sign-lat` | `-1` | AUTOSAR +Y left, Part 563 +Y right (the 180 degree turn about X, `edr-agent.agent.md` 5.2) |

`did-compare` reports per axis whether a real read-out confirms the sign used.

## Engine parameters (`--config`)

`export-config --output engine.json` writes the current values. Edit any of these sections:

| Key | Content |
|---|---|
| `sensors` | `{key: {name, max_g or g_per_lsb, max_lsb, axis, token}}` |
| `crash_rules` | `{type: {axis, threshold_kmph, window_ms}}` |
| `crash_cases` | `[{name, wake_axis, threshold_kmph, window_ms, channels: [{file_name, sensor_key, peak_g, start_sample, width_samples, sign, primary_for_t0, use_demo_waveform}]}]`; `file_name` may use `{compact_date}` and `{long_date}` |
| `change_in_velocity` | `{channels: {type: [[name, sensor_key], ...]}, confirmation_peak_g: {type: {name: g}}}` |

- **Fixed values:** sample count (600) and interval (500 us) are fixed by the engine. A `fixed`
  section is ignored.
- **Unknown keys:** any key not listed above fails the run.

## Job (`run-job --job`)

```json
{ "defaults": {"seed": 0, "date": "2026-10-21"},
  "continue_on_error": false,
  "steps": [ {"command": "generate", "output": "curves", "types": ["front", "rear"]},
             {"command": "change-in-velocity", "output": "civ", "project": "U171",
              "profile": {"front": "ref/front.xml"}} ] }
```

- **Arguments:** a step's keys are the command's options with `_` for `-`. Lists expand to
  several values, dicts become `KEY=VALUE` pairs, and `true` becomes a flag.
- **Paths:** relative paths are resolved from the job file's folder.
- **Errors:** the job stops at the first failing step unless `continue_on_error` is set.

## Outputs common to all commands

| File | Meaning |
|---|---|
| `edr_curve_manifest_<command>.json` | Runner and engine hash, arguments, seed, run date, exit code, result summary, warnings, every file written |
| `polarity_report.csv`, `polarity_checks.csv` | Per-channel ECU-input sign and rule results |
| `curve_inspection.csv` | Per file: T0 (and the window-start sample), engine Tend, Delta-V |
| `t0_summary.csv` | Per folder: T0 and its basis, **always-on end of event** (`end_of_event_sample/ms/source`, rule R1), engine single-axis Tend, missing primary channels |
| `t0_tend_summary.txt` (generated sets) | Engine lines plus `Always-on End of Event ...` lines added by the runner |
| `did_delta_v_layout_<P>.csv` | The layout actually used |
| `did_0455_expected_record_1.csv`, `did_0455_ecu_comparison.csv` | Engine-format expectation and comparison (the names are the engine's, whatever the record DID) |

Exit codes: `0` success, `1` a check failed (polarity rule, DID mismatch, wake threshold not
reached, validation fail), `2` input or configuration error.
