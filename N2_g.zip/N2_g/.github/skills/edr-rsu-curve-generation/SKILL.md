---
name: edr-rsu-curve-generation
description: 'Use when generating, analysing or validating RSU / onboard acceleration crash curves for EDR recording tests: synthetic front, left, right, rear and near LSB curve sets (600 samples at 2 kHz), multi-event merges, Delta-V and change-in-velocity (EDR record-trigger) curves, T0/Tend/Delta-V of existing crash exports, expected EDR Delta-V DID values from the project edr_config, comparison with an ECU DID response, and the polarity each channel reaches the ECU with through the HIL profile inversions.'
argument-hint: 'Name the project, the workflow (generate, multi-event, change-in-velocity, inspect, did-expected, did-compare, polarity), the crash types, the output folder, and any HIL profile or ECU response.'
user-invocable: true
disable-model-invocation: false
---

# EDR RSU acceleration curve generation

## Purpose

Run the Crash Curve Tool workflow end to end from the command line. The engine is
`scripts/vendor/crash_curve_tool.py`, vendored unchanged. Every operation goes through
`scripts/edr_curve_runner.py`, which adds the following on top of the tool's GUI:

- **Project DID layout:** the EDR Delta-V DID layout comes from `projects/<P>/config/edr_config.py`.
- **Parameters:** sensors, wake rules and crash definitions can be overridden with `--config`.
- **Reproducibility:** `--seed` fixes the noise and `--date` fixes the dates in names.
- **Polarity:** each channel's sign is reported as the ECU receives it, after the HIL inversion.
- **Manifest:** every run records what it read and wrote.

Logic, findings and integration decisions are in
[references/curve-generation-analysis.md](references/curve-generation-analysis.md). File
formats are in [references/input-contract.md](references/input-contract.md).

## Safety

This skill writes curve, XML and report files only. It never loads ARIA, never imports a profile
into the HIL, never powers the ECU and never reads the ECU. Running the generated curves on
the bench is a human step; deliver them as files and say they were not replayed. Write outputs
outside `projects/` and `shared_libraries/` (both protected).

## Framework conventions (defaults for every project)

Stated by the user on 2026-10-21. They are rules R1 and R2 in `edr-agent.agent.md` section 0.
Follow them unless the user specifies otherwise.

| Rule | Meaning | How the skill applies it |
|---|---|---|
| R1: always-on algorithm | Every project runs a continuously running crash algorithm. T0: cumulative delta-V over 0.8 km/h within 20 ms (X) or 5 ms (Y). End of event: the **resultant** delta-V over 20 ms falls to 0.8 km/h or less (49 CFR 563.5). | `inspect` and each generated `t0_tend_summary.txt` report the always-on end of event from onboard X/Y. The engine's single-axis Tend is labelled as such. |
| R2: AUTOSAR onboard axis | Onboard acceleration follows +X forward, +Y left, +Z up, so the ECU-input sign is front X -, rear X +, left Y -, right Y +. | `polarity` and `change-in-velocity` check this by default (`--convention autosar`). `did-*` default the report signs to longitudinal +1, lateral -1 (AUTOSAR to Part 563). |

When the user names another convention for a task, use `--convention none` with `--expect`, and
`--report-sign-long/lat`. Say in the result that the AUTOSAR default was overridden, and on
whose instruction.

## Before running

1. **Interpreter:** use `py -3.14`. `openpyxl` is needed only for `process`'s workbook:
   `py -3.14 -m pip install -r .github/skills/edr-rsu-curve-generation/requirements.txt`.
2. **Project:** confirm it with the user, then confirm that `projects/<P>/config/edr_config.py`
   exists. Never borrow another project's layout, profile or polarity.
3. **Output folder:** pick a **short** one. Engine file names are about 80 characters, and
   Windows fails at 260.
4. **Real crash data:** inspect it before generating anything that must match it.

## Commands

Run `py -3.14 .github/skills/edr-rsu-curve-generation/scripts/edr_curve_runner.py <command> ...`.
Add `-h` to any command for its options.

| Command | Use it for | Key options |
|---|---|---|
| `inspect` | T0, Tend, Delta-V of existing curves (no copies) | `--input`, `--output`, `--crash-type` |
| `process` | The tool's folder processing with Excel workbook | `--input`, `--output`, `--types`, `--no-excel`, `--no-copy` |
| `generate` | Synthetic crash sets | `--types`, `--variant standard\|ctx-cty-full\|high-amp\|out-of-range`, `--overscale`, `--max-abs-delta-v` |
| `multi-event` | 2..7 events merged on T0-to-T0 delays | `--events`, `--delays-ms`, `--invert`, `--source`, `--t0-override` (one per event, `-` for none) |
| `delta-v-curve` / `delta-v-validate` | Onboard-X curve with an exact longitudinal Delta-V | `--target-kmph`, `--pulse-ms`, `--negative`, `--tolerance` |
| `change-in-velocity` | EDR record-trigger sets (> 8 km/h within 150 ms of T0) | `--target-kmph`, `--pulse-ms`, `--types`, `--project`, `--profile TYPE=XML` |
| `delta-v-trace` | Sample-by-sample cumulative Delta-V of one curve | `--input`, `--notepad` |
| `low-amp` | One low-amplitude curve | `--sensor`, `--max-g` |
| `did-expected` | Expected EDR Delta-V DID fields | `--curves`, `--project`, `--t0-override`, `--report-sign-long/lat` (default +1 / -1) |
| `did-compare` | Expected fields against an ECU response, with a report-sign verdict | as above, plus `--ecu-response "62 04 55 ..."` or `@file`, `--first-byte` |
| `polarity` | Sign each channel reaches the ECU with: AUTOSAR onboard check, pair rules | `--input`, `--convention`, `--expect` |
| `export-config` | Current engine parameters as editable JSON | `--output` |
| `run-job` | Several commands from a JSON job | `--job`; see `config/example_job.json` |
| `ui` | The original desktop GUI | none |

Common options are `--seed` (default 0), `--date YYYY-MM-DD` and `--config <json>`.

## Recipes

**Synthetic EDR recording set for project P**

```powershell
$R = ".github/skills/edr-rsu-curve-generation/scripts/edr_curve_runner.py"
py -3.14 $R generate --output D:\EDR\P\curves --types front left right rear near --date 2026-10-21
py -3.14 $R change-in-velocity --output D:\EDR\P\civ --project P --profile front=<ref>\front.xml left=<ref>\left.xml
py -3.14 $R polarity --input D:\EDR\P\civ --output D:\EDR\P\polarity --expect <expectations.json>
```

If no reference profile exists, build one with the `aria-crash-simulation-xml` skill. Then run
`polarity` on the result before anyone loads it into the HIL.

**Analyse a real crash export**

```powershell
py -3.14 $R inspect --input <crash folder> --output D:\EDR\P\inspect
py -3.14 $R polarity --input <crash folder> --output D:\EDR\P\polarity
py -3.14 $R did-expected --curves <crash folder> --project P --output D:\EDR\P\did
```

**Check an EDR read-out**

The user supplies the DID response from their own read.

```powershell
py -3.14 $R did-compare --curves <crash folder> --project P --ecu-response "@D:\EDR\P\did_0455.txt" --output D:\EDR\P\did
```

The command uses the default report signs (longitudinal +1, lateral -1) unless given
`--report-sign-*`. It also retries every delta-V with the opposite sign, and reports per axis
whether the read-out confirms the sign used or wants the opposite one. A project whose read-out
wants the opposite sign deviates from R2 plus Part 563; record it (EDR-Q13) and tell the user.

## Decision rules

| Condition | Action |
|---|---|
| Project config missing, `EDR_PARAMETERS` not a list, or a Delta-V element missing `data_start_byte` / `scaling_factor` / `offset` | Stop with the runner's error; tell the user which key is missing and where. Use `--did-definition` only with a layout the user supplies. |
| `polarity` reports `FAIL` | Do not hand the set over for HIL replay. Report the folders, channels and signs; the profile inversions or the curve signs need correcting by the owner. |
| The user specifies an onboard convention other than AUTOSAR | Run with `--convention none` plus `--expect` (and `--report-sign-*`), and state the override in the result. |
| `generate` reports "threshold not reached" | Exit 1; the set cannot wake the algorithm. Fix the crash definition (`--config`). |
| `did-compare` mismatches | Exit 1. Check the sign verdict first, then T0 (`--t0-override` with the ECU's confirmed T0), then the layout numbering (`--first-byte`). |
| Delay of 5 s or more in `multi-event` | Warned: these are separate single events, not a multi-event. |
| Expected values needed in the reported (SAE J211 / Part 563) frame | Require `--report-sign-long/lat` from the project's report inversion or from a `did-compare` verdict; never assume. |
| Vendored engine hash changed | The runner refuses to load it; follow `scripts/vendor/PROVENANCE.md`. |

## What the numbers mean

- **Delta-V:** `sum(LSB * g_per_lsb) * 9.80665 * 0.0005 * 3.6` km/h.
- **T0 (R1):** T0 is the first sample where `|dV|` over the wake window reaches the threshold.
  The windows are front/rear X 0.8 km/h in 20 ms and left/right Y 0.8 km/h in 5 ms; near crashes
  use the tool's own 0.2 km/h. `inspect` also gives the start of that window (EDR-Q12).
- **End of event (R1):** the first sample after the onboard resultant has exceeded 0.8 km/h at
  which it falls to 0.8 km/h or less over 20 ms. The engine's single-axis Tend is reported
  separately and is not the framework value (analysis F6).
- **Signs (R2):** generated curves are positive by design. The sign the ECU sees is the curve
  sign times `IsInverted`, and it must match the AUTOSAR onboard table above. The reported EDR
  sign then passes the AUTOSAR to Part 563 / SAE J211 turn (`edr-agent.agent.md` section 5.2):
  longitudinal unchanged, lateral negated.

## Validation

```powershell
py -3.14 -m unittest tests/test_edr_rsu_curve_generation.py -v
```

## Completion criteria

The task is complete only when all of these hold:

- Every requested command exited 0, or its failures are reported with the evidence from
  `polarity_checks.csv` or the comparison CSV.
- The manifest of each run is listed to the user.
- Any polarity `FAIL` or DID mismatch is stated, not smoothed over.
- Nothing has been replayed on the HIL or read from the ECU by this skill.
