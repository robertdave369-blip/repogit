"""Headless entry point for the EDR RSU acceleration curve workflow.

Wraps the vendored Crash Curve Tool engine (``vendor/crash_curve_tool.py``, kept byte for
byte as received, see ``vendor/PROVENANCE.md``) so every workflow its desktop GUI offers can
be run from one command line, by a person or by an AI agent in VS Code:

    inspect            T0 / Tend / Delta-V of existing curve files, no copies
    process            the engine's folder processing: crash folders + Excel workbook
    generate           synthetic crash sets (standard, ctx-cty-full, high-amp, out-of-range)
    multi-event        2..7 events merged on T0-to-T0 delays
    delta-v-curve      one onboard-X curve with a requested longitudinal Delta-V
    delta-v-validate   check an onboard-X curve against a requested Delta-V
    change-in-velocity EDR record-trigger sets (> 8 km/h within 150 ms of T0)
    delta-v-trace      sample-by-sample cumulative Delta-V of one curve
    low-amp            one low-amplitude curve for a chosen sensor
    did-expected       expected EDR Delta-V DID fields from a curve folder
    did-compare        expected fields against an ECU DID response
    polarity           sign each channel reaches the ECU with, plus pair checks
    export-config      the engine's sensors, wake rules and crash definitions as JSON
    run-job            run a JSON job: several of the commands above, in order
    ui                 the original desktop GUI

What it adds to the engine:
- the EDR Delta-V DID layout is read from ``projects/<P>/config/edr_config.py`` (parsed, never
  imported) instead of a CSV copied from one project;
- sensors, wake rules and crash definitions are parameters (``--config``);
- runs are reproducible (``--seed`` for the engine's random noise, ``--date`` for file names);
- the HIL profile inversions are applied to report the sign each channel reaches the ECU with;
- every run leaves a manifest listing its inputs, outputs and warnings.

Offline only. It reads and writes curve, XML and report files. It never talks to ARIA, the
bench or the ECU, and it never loads a profile into the HIL.
"""
from __future__ import annotations

import argparse
import ast
import csv
import dataclasses
import hashlib
import importlib.util
import json
import os
import random
import sys
import time
import xml.etree.ElementTree as ET
from datetime import date, datetime
from pathlib import Path, PureWindowsPath
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
ENGINE_PATH = SCRIPT_DIR / "vendor" / "crash_curve_tool.py"
REPO_ROOT = SCRIPT_DIR.parents[3]

# Hash of the vendored engine as received. A different hash means someone edited the vendored
# file; re-vendor deliberately and update this value and vendor/PROVENANCE.md together.
ENGINE_SHA256 = "c087da50a70161e6e133c16a8b89b59ede8a5e054c6cdb0ae0a8f79df6e8c824"

# The engine reads a DID definition CSV and keeps only rows labelled with this DID. The label is
# internal to the layout file; the field positions come from the project's edr_config.
ENGINE_DID_LABEL = "0x0455"

# Element names tried, in order, for each Delta-V role. Projects are not uniform: U171, M310 and
# Z121 use DeltaVLong, UPP_EV and W610 use DeltaVLgt. --element-map overrides any role.
DELTA_V_ROLES: dict[str, tuple[str, ...]] = {
    "long_series": ("DeltaVLong", "DeltaVLgt"),
    "lat_series": ("DeltaVLat",),
    "max_long": ("MaxDeltaVLgt", "MaxDeltaVLong"),
    "max_lat": ("MaxDeltaVLat",),
    "time_max_long": ("TimeMaxDeltaVLgt", "TimeMaxDeltaVLong"),
    "time_max_lat": ("TimeMaxDeltaVLat",),
}
# Names the engine's load_did_0455_fields() recognises for the snapshot roles.
SNAPSHOT_PARAM_NAMES = {
    "max_long": "Record 1 - MaxDeltaVLgt",
    "max_lat": "Record 1 - MaxDeltaVLat",
    "time_max_long": "Record 1 - TimeMaxDeltaVLgt",
    "time_max_lat": "Record 1 - TimeMaxDeltaVLat",
}
LAYOUT_COLUMNS = (
    "DID", "PARAM_NAME", "POS_IN_BYTES", "LEN_IN_BYTES", "OFFSET", "RESOLUTION",
    "UNIT", "MIN_VALUE", "MAX_VALUE", "SOURCE_ELEMENT", "SOURCE_FILE",
)
OVERRIDE_KEYS = {"sensors", "crash_rules", "crash_cases", "change_in_velocity"}
IGNORED_CONFIG_KEYS = {"_comment", "description", "fixed"}
GENERATE_VARIANTS = ("standard", "ctx-cty-full", "high-amp", "out-of-range")
PAIR_RULES = (
    ("central_acc_x", "front", "rear"),
    ("central_acc_y", "left", "right"),
)

# Framework-wide rules stated by the user on 2026-10-21 (edr-agent.agent.md, section 0):
# R1 every project runs a continuously running ("always-on") crash algorithm, so the end of an
#    event is 49 CFR 563.5's continuous-algorithm clause: the resultant cumulative Delta-V within a
#    20 ms period falls to 0.8 km/h or less;
# R2 onboard acceleration follows the AUTOSAR vehicle axis (X forward, Y left, Z up) unless the
#    user specifies otherwise, so a front impact drives onboard X negative, a rear impact positive,
#    a left impact onboard Y negative and a right impact positive.
ALWAYS_ON_END_THRESHOLD_KMPH = 0.8
ALWAYS_ON_END_WINDOW_MS = 20.0
AUTOSAR_ONBOARD_EXPECTATIONS: dict[str, dict[str, str]] = {
    "front": {"central_acc_x": "-"},
    "rear": {"central_acc_x": "+"},
    "left": {"central_acc_y": "-"},
    "right": {"central_acc_y": "+"},
}
# AUTOSAR frame -> Part 563 / SAE J211 reporting frame is a 180 degree turn about X
# (edr-agent.agent.md section 5.2): longitudinal unchanged, lateral negated.
AUTOSAR_TO_REPORT_SIGN = {"long": 1, "lat": -1}
CONVENTIONS = ("autosar", "none")
EMPTY_AXIS_PATHS = {"", "empty", "path does not exist!"}

WARNINGS: list[str] = []


class RunnerError(Exception):
    """An input or configuration problem the user has to fix; reported without a traceback."""


def warn(message: str) -> None:
    WARNINGS.append(message)
    print(f"warning: {message}", file=sys.stderr)


# --------------------------------------------------------------------------------------------
# Engine loading and parameterisation
# --------------------------------------------------------------------------------------------

def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_engine(overrides: dict[str, Any] | None = None, run_date: date | None = None) -> Any:
    """A fresh engine module, with the date frozen and the overrides applied when given."""
    if not ENGINE_PATH.is_file():
        raise RunnerError(f"Vendored engine not found: {ENGINE_PATH}")
    digest = file_sha256(ENGINE_PATH)
    if digest != ENGINE_SHA256:
        raise RunnerError(
            f"Vendored engine {ENGINE_PATH.name} has SHA-256 {digest}, expected {ENGINE_SHA256}. "
            "It was edited after vendoring. Review the change, then update ENGINE_SHA256 and "
            "vendor/PROVENANCE.md together."
        )
    spec = importlib.util.spec_from_file_location("crash_curve_tool", ENGINE_PATH)
    if spec is None or spec.loader is None:
        raise RunnerError(f"Unable to load {ENGINE_PATH}")
    engine = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = engine
    spec.loader.exec_module(engine)
    if run_date is not None:
        freeze_engine_clock(engine, run_date)
    if overrides:
        apply_overrides(engine, overrides)
    return engine


def freeze_engine_clock(engine: Any, run_date: date) -> None:
    """Make the engine's datetime.now() return run_date at 12:00:00, for stable file names."""
    base = engine.datetime

    class FrozenDateTime(base):  # type: ignore[misc, valid-type]
        @classmethod
        def now(cls, tz=None):  # noqa: ANN001 - mirrors datetime.now
            return cls(run_date.year, run_date.month, run_date.day, 12, 0, 0, tzinfo=tz)

    engine.datetime = FrozenDateTime


def _require(mapping: dict[str, Any], keys: tuple[str, ...], where: str) -> None:
    missing = [key for key in keys if key not in mapping]
    if missing:
        raise RunnerError(f"{where}: missing key(s) {', '.join(missing)}")


def _sensor_spec(engine: Any, key: str, spec: dict[str, Any]) -> Any:
    where = f"config sensors.{key}"
    _require(spec, ("name", "axis"), where)
    max_lsb = spec.get("max_lsb")
    if max_lsb is None:
        raise RunnerError(f"{where}: missing key max_lsb")
    max_g = spec.get("max_g")
    g_per_lsb = spec.get("g_per_lsb")
    if max_g is not None:
        max_g_value = float(max_g)
    elif g_per_lsb is not None:
        max_g_value = float(g_per_lsb) * int(max_lsb)
    else:
        raise RunnerError(f"{where}: give max_g or g_per_lsb")
    sensor = engine.SensorSpec(str(spec["name"]), max_g_value, int(max_lsb))
    if g_per_lsb is not None and abs(sensor.g_per_lsb - float(g_per_lsb)) > 5e-5:
        raise RunnerError(
            f"{where}: max_g/max_lsb = {sensor.g_per_lsb:.6f} g/LSB disagrees with g_per_lsb {g_per_lsb}"
        )
    return sensor


def apply_overrides(engine: Any, overrides: dict[str, Any]) -> None:
    unknown = set(overrides) - OVERRIDE_KEYS - IGNORED_CONFIG_KEYS
    if unknown:
        raise RunnerError(
            f"Unknown config key(s) {sorted(unknown)}. Allowed: {sorted(OVERRIDE_KEYS)}. "
            "Sample count and interval are fixed by the engine (600 samples at 500 us)."
        )

    for key, spec in overrides.get("sensors", {}).items():
        engine.SENSORS[key] = _sensor_spec(engine, key, spec)
        engine.SENSOR_AXIS_MAP[key] = str(spec["axis"]).upper()
        engine.SENSOR_TOKEN_MAP[key] = str(spec.get("token") or f"{int(round(engine.SENSORS[key].max_g))}g")

    for name, rule in overrides.get("crash_rules", {}).items():
        _require(rule, ("axis", "threshold_kmph", "window_ms"), f"config crash_rules.{name}")
        engine.CRASH_RULES[name] = {
            "axis": str(rule["axis"]).upper(),
            "threshold_kmph": float(rule["threshold_kmph"]),
            "window_ms": float(rule["window_ms"]),
        }

    if "crash_cases" in overrides:
        cases = [_crash_case(engine, case, index) for index, case in enumerate(overrides["crash_cases"])]
        near = [case for case in cases if case.name == engine.NEAR_CRASH_NAME]
        others = tuple(case for case in cases if case.name != engine.NEAR_CRASH_NAME)
        if others:
            engine.DEMO_CRASH_CASES = others
        if near:
            engine.NEAR_CRASH_CASE = near[0]
        # Both are derived from the case list when the engine is imported; rebuild them.
        engine.REQUIREMENT_PRIMARY_CHANNEL_FRAGMENTS = engine.build_requirement_primary_channel_fragments()
        engine.NEAR_CRASH_ZERO_TEMPLATES = {
            channel.file_name for case in engine.DEMO_CRASH_CASES for channel in case.channels
        }
        for case in cases:
            rule = engine.CRASH_RULES.get(case.name)
            if rule is None:
                raise RunnerError(f"config crash_cases: '{case.name}' has no crash_rules entry")
            if (rule["axis"], float(rule["threshold_kmph"]), float(rule["window_ms"])) != (
                case.wake_axis, case.threshold_kmph, case.window_ms
            ):
                warn(
                    f"crash case '{case.name}' wake rule ({case.wake_axis}, {case.threshold_kmph} km/h, "
                    f"{case.window_ms} ms) differs from crash_rules ({rule['axis']}, {rule['threshold_kmph']} km/h, "
                    f"{rule['window_ms']} ms); demo summaries use the case, T0 analysis uses crash_rules"
                )

    civ = overrides.get("change_in_velocity")
    if civ is not None:
        _require(civ, ("channels", "confirmation_peak_g"), "config change_in_velocity")
        channels = {
            crash: tuple((str(name), str(sensor)) for name, sensor in pairs)
            for crash, pairs in civ["channels"].items()
        }
        for crash, pairs in channels.items():
            for name, sensor in pairs:
                if sensor not in engine.SENSORS:
                    raise RunnerError(f"config change_in_velocity.channels.{crash}: unknown sensor '{sensor}'")
                if name not in civ["confirmation_peak_g"].get(crash, {}):
                    raise RunnerError(f"config change_in_velocity.confirmation_peak_g.{crash}: no peak for '{name}'")
        engine.CHANGE_IN_VELOCITY_CHANNELS = channels
        engine.CHANGE_IN_VELOCITY_CONFIRMATION_PEAK_G = {
            crash: {name: float(peak) for name, peak in peaks.items()}
            for crash, peaks in civ["confirmation_peak_g"].items()
        }
        engine.CHANGE_IN_VELOCITY_CRASH_TYPES = tuple(channels)


def _crash_case(engine: Any, case: dict[str, Any], index: int) -> Any:
    where = f"config crash_cases[{index}]"
    _require(case, ("name", "wake_axis", "threshold_kmph", "window_ms", "channels"), where)
    channels = []
    for channel_index, channel in enumerate(case["channels"]):
        channel_where = f"{where}.channels[{channel_index}]"
        _require(channel, ("file_name", "sensor_key", "peak_g", "start_sample", "width_samples"), channel_where)
        if channel["sensor_key"] not in engine.SENSORS:
            raise RunnerError(f"{channel_where}: unknown sensor_key '{channel['sensor_key']}'")
        if int(channel["start_sample"]) + int(channel["width_samples"]) > engine.SAMPLE_COUNT:
            raise RunnerError(f"{channel_where}: pulse ends after sample {engine.SAMPLE_COUNT}")
        channels.append(
            engine.ChannelSpec(
                file_name=str(channel["file_name"]),
                sensor_key=str(channel["sensor_key"]),
                peak_g=float(channel["peak_g"]),
                start_sample=int(channel["start_sample"]),
                width_samples=int(channel["width_samples"]),
                sign=int(channel.get("sign", 1)),
                primary_for_t0=bool(channel.get("primary_for_t0", False)),
                use_demo_waveform=bool(channel.get("use_demo_waveform", False)),
            )
        )
    return engine.CrashCase(
        name=str(case["name"]).lower(),
        wake_axis=str(case["wake_axis"]).upper(),
        threshold_kmph=float(case["threshold_kmph"]),
        window_ms=float(case["window_ms"]),
        channels=tuple(channels),
    )


def engine_defaults(engine: Any) -> dict[str, Any]:
    """Everything --config can override, as the engine currently holds it."""

    def case_dict(case: Any) -> dict[str, Any]:
        return {
            "name": case.name,
            "wake_axis": case.wake_axis,
            "threshold_kmph": case.threshold_kmph,
            "window_ms": case.window_ms,
            "channels": [dataclasses.asdict(channel) for channel in case.channels],
        }

    return {
        "description": "Crash Curve Tool engine parameters. Edit and pass back with --config.",
        "fixed": {
            "sample_count": engine.SAMPLE_COUNT,
            "sample_dt_s": engine.DEFAULT_SAMPLE_DT_S,
            "tend_window_ms": engine.TEND_WINDOW_MS,
        },
        "sensors": {
            key: {
                "name": sensor.name,
                "max_g": sensor.max_g,
                "max_lsb": sensor.max_lsb,
                "g_per_lsb": round(sensor.g_per_lsb, 9),
                "axis": engine.SENSOR_AXIS_MAP.get(key, ""),
                "token": engine.SENSOR_TOKEN_MAP.get(key, ""),
            }
            for key, sensor in engine.SENSORS.items()
        },
        "crash_rules": engine.CRASH_RULES,
        "crash_cases": [case_dict(case) for case in (*engine.DEMO_CRASH_CASES, engine.NEAR_CRASH_CASE)],
        "change_in_velocity": {
            "channels": {crash: [list(pair) for pair in pairs] for crash, pairs in engine.CHANGE_IN_VELOCITY_CHANNELS.items()},
            "confirmation_peak_g": engine.CHANGE_IN_VELOCITY_CONFIRMATION_PEAK_G,
        },
    }


# --------------------------------------------------------------------------------------------
# EDR Delta-V DID layout from the project configuration
# --------------------------------------------------------------------------------------------

def literal_symbol(path: Path, symbol: str) -> Any:
    """The literal value assigned to `symbol` at module level, without importing the module."""
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(getattr(target, "id", None) == symbol for target in node.targets):
            try:
                return ast.literal_eval(node.value)
            except ValueError as error:
                raise RunnerError(f"{symbol} in {path} is not a plain literal: {error}") from error
    raise RunnerError(f"{symbol} is not assigned at module level in {path}")


def _number_text(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else f"{value:g}"


def project_did_layout(project: str, element_map: dict[str, str] | None = None) -> list[dict[str, Any]]:
    """Layout rows for the six Delta-V roles, numbered the way the framework reads a response.

    POS_IN_BYTES is the element's data_start_byte: 1-based over the whole positive response,
    three-byte header (62 xx xx) included, read as data[n - 1]
    (shared_libraries/edr_decoding_functions.py, read_edr_record_bytes). A full response pasted
    from a log therefore lines up with first byte position 1.
    """
    config_path = REPO_ROOT / "projects" / project / "config" / "edr_config.py"
    if not config_path.is_file():
        raise RunnerError(f"Project EDR config not found: {config_path}")
    parameters = literal_symbol(config_path, "EDR_PARAMETERS")
    if not isinstance(parameters, list):
        raise RunnerError(
            f"{config_path}: EDR_PARAMETERS is a {type(parameters).__name__}, not a list of element "
            "definitions. Pass the layout explicitly with --did-definition."
        )
    by_name = {parameter.get("name"): parameter for parameter in parameters if isinstance(parameter, dict)}
    relative_source = config_path.relative_to(REPO_ROOT).as_posix()
    element_map = element_map or {}
    rows: list[dict[str, Any]] = []

    for role, candidates in DELTA_V_ROLES.items():
        name = element_map.get(role) or next((candidate for candidate in candidates if candidate in by_name), None)
        if name is None or name not in by_name:
            looked_for = element_map.get(role) or ", ".join(candidates)
            raise RunnerError(f"{relative_source}: no element for {role} (looked for {looked_for}); use --element-map")
        element = by_name[name]
        where = f"{relative_source} element {name}"
        if element.get("signed"):
            raise RunnerError(f"{where}: signed raw values are not supported by the engine's encoder")
        if "data_start_byte" not in element or "scaling_factor" not in element:
            raise RunnerError(f"{where}: needs data_start_byte and scaling_factor")
        start = int(element["data_start_byte"])
        scale = float(element["scaling_factor"])
        offset = element.get("offset")
        if offset is None:
            if not role.startswith("time_max"):
                raise RunnerError(f"{where}: no offset; a signed Delta-V cannot be encoded without one")
            offset = 0.0
            warn(f"{where}: no offset; 0 used, as the framework decoder does")
        offset = float(offset)

        if role.endswith("_series"):
            per_sample = int(element.get("data_bytes_per_sample") or 1)
            count = int(element.get("data_samples_number") or 1)
        else:
            per_sample = int(element.get("data_byte_length") or element.get("data_bytes_per_sample") or 1)
            count = 1
        raw_max = (1 << (8 * per_sample)) - 1
        minimum = element.get("minimum")
        maximum = element.get("maximum")
        if minimum is None or maximum is None:
            warn(f"{where}: no minimum/maximum; the raw span {offset:g}..{offset + raw_max * scale:g} is used")
            minimum = offset if minimum is None else minimum
            maximum = offset + raw_max * scale if maximum is None else maximum
        unit = str(element.get("unit") or "")
        common = {
            "DID": ENGINE_DID_LABEL,
            "LEN_IN_BYTES": per_sample,
            "OFFSET": offset,
            "RESOLUTION": scale,
            "UNIT": unit,
            "MIN_VALUE": float(minimum),
            "MAX_VALUE": float(maximum),
            "SOURCE_ELEMENT": name,
            "SOURCE_FILE": relative_source,
        }

        if role.endswith("_series"):
            sample_range = element.get("sample_range")
            if sample_range:
                start_ms = float(sample_range["start"]) * 1000.0
                step_ms = float(sample_range["step"]) * 1000.0
            else:
                start_ms, step_ms = 0.0, 10.0
                warn(f"{where}: no sample_range; 0 ms start and 10 ms step (Part 563 Table I, 100 Hz) assumed")
            if start_ms < 0:
                raise RunnerError(f"{where}: Delta-V series starting before T0 ({start_ms:g} ms) is not supported")
            axis = "Long" if role == "long_series" else "Lat"
            for index in range(count):
                time_ms = round(start_ms + index * step_ms, 6)
                rows.append({
                    **common,
                    "PARAM_NAME": f"Record 1 - DeltaV{axis} at {_number_text(time_ms)} mS",
                    "POS_IN_BYTES": start + index * per_sample,
                })
        else:
            rows.append({**common, "PARAM_NAME": SNAPSHOT_PARAM_NAMES[role], "POS_IN_BYTES": start})
    return rows


def write_layout_csv(rows: list[dict[str, Any]], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=LAYOUT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in LAYOUT_COLUMNS})
    return path


def resolve_did_definition(args: argparse.Namespace, output_dir: Path) -> Path:
    if getattr(args, "did_definition", None):
        definition = Path(args.did_definition)
        if not definition.is_file():
            raise RunnerError(f"DID definition CSV not found: {definition}")
        warn(
            f"layout from {definition.name}: its POS_IN_BYTES numbering must match --first-byte "
            "(project edr_config numbering is 1-based over the full response)"
        )
        return definition
    if not getattr(args, "project", None):
        raise RunnerError("Give --project <NAME> (layout from projects/<NAME>/config/edr_config.py) or --did-definition")
    element_map = parse_key_values(args.element_map or [], "--element-map")
    rows = project_did_layout(args.project, element_map)
    return write_layout_csv(rows, output_dir / f"did_delta_v_layout_{args.project}.csv")


def apply_report_sign(engine: Any, validation: Any, sign_long: int, sign_lat: int) -> Any:
    """Expected values with the reporting-axis sign applied per axis (time fields unchanged)."""
    longitudinal = {"longitudinal_snapshot", "max_longitudinal"}
    lateral = {"lateral_snapshot", "max_lateral"}
    values = []
    for value in validation.values:
        kind = value.field.field_kind
        sign = sign_long if kind in longitudinal else sign_lat if kind in lateral else 1
        if sign == 1:
            values.append(value)
            continue
        calculated = sign * value.calculated_value
        expected, raw, raw_hex, in_range = engine.encode_did_0455_value(calculated, value.field)
        values.append(dataclasses.replace(
            value, calculated_value=calculated, expected_value=expected,
            raw_value=raw, raw_hex=raw_hex, range_ok=in_range,
        ))
    return dataclasses.replace(validation, values=tuple(values))


# --------------------------------------------------------------------------------------------
# Always-on end of event (rule R1)
# --------------------------------------------------------------------------------------------

def window_delta_v_series(engine: Any, record: Any, window_ms: float) -> list[float]:
    """Signed cumulative Delta-V (km/h) over the window ending at each sample."""
    values = [sample * record.sensor_spec.g_per_lsb for sample in record.samples]
    window = max(1, int(round((window_ms / 1000.0) / record.sample_dt_s)))
    factor = engine.acceleration_to_kmph_per_sample(record.sample_dt_s)
    series, running = [], 0.0
    for index, value in enumerate(values):
        running += value
        if index >= window:
            running -= values[index - window]
        series.append(running * factor)
    return series


def always_on_end_of_event(engine: Any, folder: Path, t0_sample: int | None) -> dict[str, Any]:
    """End of event for a continuously running algorithm, from the folder's onboard X and Y.

    49 CFR 563.5: "the moment at which the resultant cumulative delta-V within a 20 ms time period
    becomes 0.8 km/h (0.5 mph) or less". The resultant is a magnitude, so curve and HIL inversion
    signs do not change it. The engine's own Tend uses one axis and the crash's wake threshold.
    """
    result: dict[str, Any] = {"end_of_event_sample": None, "end_of_event_ms": None, "end_of_event_source": ""}
    if t0_sample is None:
        result["end_of_event_source"] = "no T0"
        return result
    curves = [path for path in sorted(folder.iterdir())
              if path.is_file() and path.suffix.lower() in engine.SUPPORTED_SUFFIXES
              and not engine.is_ignored_analysis_file(path)]
    onboard = []
    for test in (engine.is_central_acc_x_name, engine.is_central_acc_y_name):
        matches = [path for path in curves if test(path.stem)]
        if len(matches) > 1:
            result["end_of_event_source"] = f"ambiguous: {', '.join(path.name for path in matches)}"
            return result
        onboard.extend(matches)
    records = [record for record in (engine.parse_curve_file(path) for path in onboard)
               if record.sensor_spec is not None and record.samples]
    if not records:
        result["end_of_event_source"] = "no onboard X/Y curve"
        return result
    series = [window_delta_v_series(engine, record, ALWAYS_ON_END_WINDOW_MS) for record in records]
    sample_dt_s = records[0].sample_dt_s
    length = min(len(values) for values in series)
    resultant = [sum(values[index] ** 2 for values in series) ** 0.5 for index in range(length)]
    result["end_of_event_source"] = " + ".join(record.source_path.name for record in records)
    # The event ends when the onboard resultant falls back to the threshold, so it must first have
    # risen above it. T0 can come from a satellite earlier than the onboard rise; without this a
    # quiet onboard window right after such a T0 would read as an instant end of event.
    onset = next((index for index in range(t0_sample, length) if resultant[index] > ALWAYS_ON_END_THRESHOLD_KMPH), None)
    if onset is None:
        result["end_of_event_source"] += " (onboard resultant never exceeded 0.8 km/h after T0)"
        return result
    for index in range(onset + 1, length):
        if resultant[index] <= ALWAYS_ON_END_THRESHOLD_KMPH:
            result["end_of_event_sample"] = index
            result["end_of_event_ms"] = round(index * sample_dt_s * 1000.0, 3)
            return result
    result["end_of_event_source"] += " (not reached within the curve)"
    return result


def annotate_t0_summaries(engine: Any, output_dir: Path, since_ns: int) -> int:
    """Add the always-on end of event to each t0_tend_summary.txt the engine just wrote."""
    count = 0
    for summary in sorted(output_dir.glob("*/t0_tend_summary.txt")):
        if summary.stat().st_mtime_ns < since_ns:
            continue
        lines = [line for line in summary.read_text(encoding="ascii").splitlines()
                 if not line.startswith("Always-on End of Event")]
        t0_line = next((line for line in lines
                        if line.startswith(("Earliest T0 Sample:", "Trigger T0 Sample:"))), "")
        t0_text = t0_line.split(":", 1)[1].strip() if t0_line else ""
        t0_sample = int(t0_text) if t0_text.isdigit() else None
        end = always_on_end_of_event(engine, summary.parent, t0_sample)
        sample = end["end_of_event_sample"]
        lines += [
            f"Always-on End of Event Sample: {sample if sample is not None else 'n/a'}",
            f"Always-on End of Event (ms): {end['end_of_event_ms'] if sample is not None else 'n/a'}",
            "Always-on End of Event Rule: resultant onboard X/Y Delta-V over 20 ms <= 0.8 km/h "
            "(49 CFR 563.5, continuously running algorithm); the Tend lines above are the engine's single-axis value",
            f"Always-on End of Event Source: {end['end_of_event_source']}",
        ]
        summary.write_text("\n".join(lines) + "\n", encoding="ascii")
        count += 1
    return count


# --------------------------------------------------------------------------------------------
# Polarity: the sign each channel reaches the ECU with
# --------------------------------------------------------------------------------------------

def crash_simulation_profiles(root: Path) -> list[Path]:
    candidates = [root] if root.is_file() else sorted(root.rglob("*.xml"))
    profiles = []
    for candidate in candidates:
        try:
            if ET.parse(candidate).getroot().tag == "CrashSimulationSensors":
                profiles.append(candidate)
        except ET.ParseError:
            continue
    return profiles


def folder_crash_type(engine: Any, folder: Path) -> str:
    if folder.name.lower().startswith("multi_crash"):
        return "multi"
    # The engine scans every path part from the drive down; look at the folder's own name
    # first so an ancestor such as 'front_tests' cannot decide a 'left_crash' folder.
    own = engine.infer_crash_type(Path(folder.name), {})
    return own if own != "unknown" else engine.infer_crash_type(folder, {})


def _sign(value: float | None, dead_band: float = 1e-9) -> str:
    if value is None:
        return "?"
    return "+" if value > dead_band else "-" if value < -dead_band else "0"


def polarity_rows(engine: Any, profile: Path, crash_type: str | None = None) -> list[dict[str, Any]]:
    folder = profile.parent
    crash = crash_type or folder_crash_type(engine, folder)
    primaries = set(engine.REQUIREMENT_PRIMARY_CHANNEL_FRAGMENTS.get(crash, ()))
    rows = []
    for sensor in ET.parse(profile).getroot().findall("Sensor"):
        for index, axis in enumerate(sensor.findall("Axis")):
            file_path = axis.get("FilePath", "").strip()
            if file_path.lower() in EMPTY_AXIS_PATHS:
                continue
            name = PureWindowsPath(file_path).name
            channel = engine.extract_channel_fragment(name)
            # Onboard X/Y are recognised the engine's way, so 'Rear Central_Acc_X' (the rear-crash
            # naming) is onboard X like 'Central_Acc_X'; rules and expectations match on this role.
            role = ("central_acc_x" if engine.is_central_acc_x_name(name)
                    else "central_acc_y" if engine.is_central_acc_y_name(name) else channel)
            inverted = axis.get("IsInverted", "False").strip().lower() == "true"
            row = {
                "folder": str(folder),
                "profile": profile.name,
                "crash_type": crash,
                "sensor_type": sensor.get("Type", ""),
                "axis_index": index,
                "channel": channel,
                "role": role,
                "file": name,
                "primary": channel in primaries,
                "inverted": inverted,
                "file_peak_lsb": "",
                "file_delta_v_kmph": "",
                "ecu_input_delta_v_kmph": "",
                "ecu_input_sign": "?",
                "status": "ok",
            }
            curve = folder / name
            if not curve.is_file():
                row["status"] = "file missing next to profile"
                rows.append(row)
                continue
            record = engine.parse_curve_file(curve)
            if not record.samples:
                row["status"] = "no samples"
                rows.append(row)
                continue
            row["file_peak_lsb"] = max(record.samples, key=abs)
            if record.sensor_spec is None:
                row["status"] = "sensor not inferred; peak sign only"
                row["ecu_input_sign"] = _sign(-row["file_peak_lsb"] if inverted else row["file_peak_lsb"])
                rows.append(row)
                continue
            delta_v = engine.delta_v_kmph_from_samples(record.samples, record.sensor_spec, record.sample_dt_s)
            ecu_delta_v = -delta_v if inverted else delta_v
            row["file_delta_v_kmph"] = round(delta_v, 4)
            row["ecu_input_delta_v_kmph"] = round(ecu_delta_v, 4)
            row["ecu_input_sign"] = _sign(ecu_delta_v, dead_band=0.05)
            rows.append(row)
    return rows


def polarity_expectations(convention: str, user: dict[str, dict[str, str]]) -> dict[str, dict[str, tuple[str, str]]]:
    """Expected ECU-input signs: the AUTOSAR onboard defaults (rule R2), overridden by the user's."""
    merged: dict[str, dict[str, tuple[str, str]]] = {}
    if convention == "autosar":
        for crash, channels in AUTOSAR_ONBOARD_EXPECTATIONS.items():
            for channel, sign in channels.items():
                merged.setdefault(crash, {})[channel] = (sign, "AUTOSAR onboard")
    for crash, channels in user.items():
        for channel, sign in channels.items():
            merged.setdefault(crash, {})[channel] = (sign, "expect")
    return merged


def polarity_checks(rows: list[dict[str, Any]],
                    expectations: dict[str, dict[str, tuple[str, str]]]) -> list[dict[str, str]]:
    checks: list[dict[str, str]] = []
    for channel, first, second in PAIR_RULES:
        signs: dict[str, set[str]] = {first: set(), second: set()}
        for row in rows:
            if row["role"] == channel and row["crash_type"] in signs and row["ecu_input_sign"] in {"+", "-"}:
                signs[row["crash_type"]].add(row["ecu_input_sign"])
        for crash, found in signs.items():
            if len(found) > 1:
                checks.append({"check": f"{channel} consistent across {crash} folders", "status": "FAIL",
                               "detail": f"both signs seen: {sorted(found)}"})
        if signs[first] and signs[second]:
            clash = signs[first] & signs[second]
            checks.append({
                "check": f"{channel}: {first} opposite to {second}",
                "status": "FAIL" if clash else "PASS",
                "detail": f"{first} {sorted(signs[first])} vs {second} {sorted(signs[second])}"
                          + (" - the same physical sensor sees the same direction for opposite impacts" if clash else ""),
            })
        else:
            checks.append({"check": f"{channel}: {first} opposite to {second}", "status": "NOT RUN",
                           "detail": "needs both crash types in the same input root"})
    for crash, channels in expectations.items():
        for channel, (expected, source) in channels.items():
            matched = [row for row in rows if row["crash_type"] == crash and row["role"] == channel]
            if not matched:
                continue  # that crash type or channel is not in this input root
            wrong = [row for row in matched if row["ecu_input_sign"] != expected]
            checks.append({
                "check": f"{source}: {crash}/{channel} {expected}",
                "status": "FAIL" if wrong else "PASS",
                "detail": "; ".join(f"{Path(row['folder']).name}: {row['ecu_input_sign']}" for row in matched),
            })
    return checks


def run_polarity(engine: Any, roots: list[Path], output_dir: Path,
                 expectations: dict[str, dict[str, tuple[str, str]]], crash_type: str | None = None,
                 combine: bool = False) -> dict[str, Any]:
    """Per input root (or all roots together with combine=True): rows, pair rules, expectations."""
    all_rows: list[dict[str, Any]] = []
    all_checks: list[dict[str, str]] = []
    groups: list[tuple[str, list[dict[str, Any]]]] = []
    for root in roots:
        profiles = crash_simulation_profiles(root)
        if not profiles:
            warn(f"no CrashSimulationSensors profile under {root}; effective signs need the HIL inversions")
            continue
        root_rows = [row for profile in profiles for row in polarity_rows(engine, profile, crash_type)]
        groups.append((str(root), root_rows))
        all_rows.extend(root_rows)
    if combine and groups:
        groups = [(" + ".join(name for name, _ in groups), all_rows)]
    for name, rows in groups:
        for check in polarity_checks(rows, expectations):
            all_checks.append({"input_root": name, **check})
    output_dir.mkdir(parents=True, exist_ok=True)
    write_rows(output_dir / "polarity_report.csv", all_rows)
    write_rows(output_dir / "polarity_checks.csv", all_checks)
    for check in all_checks:
        print(f"{check['status']:8s} {check['check']} | {check['detail']}")
    failed = sum(check["status"] == "FAIL" for check in all_checks)
    return {"channels": len(all_rows), "checks": len(all_checks), "failed": failed}


# --------------------------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------------------------

def write_rows(path: Path, rows: list[dict[str, Any]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames or ["empty"])
        writer.writeheader()
        writer.writerows(rows)
    return path


def parse_key_values(items: list[str], option: str) -> dict[str, str]:
    result = {}
    for item in items:
        if "=" not in item:
            raise RunnerError(f"{option} expects KEY=VALUE, got '{item}'")
        key, value = item.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def per_event_values(values: list[str] | None, count: int, option: str) -> list[str | None]:
    if not values:
        return [None] * count
    if len(values) != count:
        raise RunnerError(f"{option} needs {count} value(s), one per event ('-' for none); got {len(values)}")
    return [None if value in {"-", ""} else value for value in values]


def inversion_tokens(engine: Any, raw: str | None) -> set[str]:
    if not raw:
        return set()
    tokens = {token.strip().lower() for token in raw.replace(";", ",").split(",") if token.strip()}
    unknown = sorted(token for token in tokens if token != "*" and token not in engine.MULTI_EVENT_INVERSION_ALIAS_RULES)
    if unknown:
        raise RunnerError(
            f"Unknown inversion token(s) {unknown}. Use * or: {', '.join(engine.MULTI_EVENT_INVERSION_ALIAS_RULES)}"
        )
    return tokens


def snapshot(directory: Path) -> dict[str, tuple[int, int]]:
    if not directory.exists():
        return {}
    return {
        path.relative_to(directory).as_posix(): (path.stat().st_size, path.stat().st_mtime_ns)
        for path in directory.rglob("*") if path.is_file()
    }


def load_json(path: str | Path, what: str) -> Any:
    source = Path(path)
    if not source.is_file():
        raise RunnerError(f"{what} not found: {source}")
    try:
        return json.loads(source.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise RunnerError(f"{what} {source} is not valid JSON: {error}") from error


def read_response_text(value: str) -> str:
    if value.startswith("@"):
        path = Path(value[1:])
        if not path.is_file():
            raise RunnerError(f"ECU response file not found: {path}")
        return path.read_text(encoding="utf-8", errors="ignore")
    return value


# --------------------------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------------------------

def cmd_export_config(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(engine_defaults(engine), indent=2) + "\n", encoding="utf-8")
    print(f"engine parameters written to {target}")
    return {"file": str(target)}


def cmd_inspect(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    processor = engine.CrashCurveProcessor()
    files = processor.discover_files([Path(value) for value in args.input])
    if not files:
        raise RunnerError("No curve files found in the input path(s)")
    processed_at = engine.datetime.now().strftime(engine.TIMESTAMP_FORMAT)
    output_dir = Path(args.output)
    results, rows = [], []
    for path in files:
        record = engine.parse_curve_file(path)
        if args.crash_type:
            record.crash_type = args.crash_type
        result = engine.analyse_curve(record, None, output_dir, processed_at)
        results.append(result)
        rule = engine.CRASH_RULES.get(result.crash_type, {})
        window = int(round((float(rule.get("window_ms", 0)) / 1000.0) / record.sample_dt_s)) if rule else 0
        rows.append({
            "file": str(path),
            "crash_type": result.crash_type,
            "sensor": result.sensor_name,
            "axis": result.axis,
            "samples": result.sample_count,
            "duration_ms": result.duration_ms,
            "peak_abs_g": result.peak_abs_g,
            "delta_v_kmph": result.delta_v_kmph,
            "wake_threshold_kmph": result.threshold_kmph,
            "wake_window_ms": rule.get("window_ms", ""),
            "t0_sample": result.t0_sample,
            "t0_ms": result.t0_ms,
            "t0_window_start_sample": "" if result.t0_sample is None else max(0, result.t0_sample - window + 1),
            "tend_sample": result.tend_sample,
            "tend_ms": result.tend_ms,
            "status": result.status,
            "remarks": result.remarks,
        })
    write_rows(output_dir / "curve_inspection.csv", rows)
    summaries = engine.summarize_requirement_t0(results)
    summary_rows = []
    for summary in summaries:
        t0_sample, t0_ms = summary.t0_sample, summary.t0_ms
        trigger = summary.trigger_file.name if summary.trigger_file else ""
        basis = "engine primary channels"
        if t0_sample is None:
            # The engine's folder summary wants the exact key 'central_acc_x'; rear sets named
            # 'Rear Central_Acc_X' miss it although their per-file T0 was computed above.
            folder = Path(summary.source_folder).resolve()
            onboard = [result for result in results
                       if result.t0_sample is not None and result.source_path.parent.resolve() == folder
                       and (engine.is_central_acc_x_name(result.source_path.stem)
                            or engine.is_central_acc_y_name(result.source_path.stem))]
            if onboard:
                first = min(onboard, key=lambda result: result.t0_sample)
                t0_sample, t0_ms, trigger = first.t0_sample, first.t0_ms, first.source_path.name
                basis = "onboard file (engine folder summary found no primary channel)"
        end = always_on_end_of_event(engine, Path(summary.source_folder), t0_sample)
        summary_rows.append({
            "folder": str(summary.source_folder),
            "crash_type": summary.crash_type,
            "trigger_file": trigger,
            "t0_basis": basis,
            "t0_sample": t0_sample,
            "t0_ms": t0_ms,
            **end,
            "engine_single_axis_tend_sample": summary.tend_sample,
            "engine_single_axis_tend_ms": summary.tend_ms,
            "missing_required_channels": ", ".join(summary.missing_fragments),
        })
        eoe = end["end_of_event_sample"]
        fallback = f" | T0 sample {t0_sample} via {trigger} [{basis}]" if basis != "engine primary channels" else ""
        print(engine.format_timing_summary_line(summary) + fallback
              + (f" | always-on end of event sample {eoe} ({end['end_of_event_ms']:.3f} ms)" if eoe is not None
                 else f" | always-on end of event not reached ({end['end_of_event_source']})"))
    write_rows(output_dir / "t0_summary.csv", summary_rows)
    errors = sum(result.status != "ok" for result in results)
    print(f"inspected {len(results)} file(s), {errors} with parse errors")
    return {"files": len(results), "parse_errors": errors, "folders_with_t0": len(summaries)}


def cmd_process(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    processor = engine.CrashCurveProcessor()
    summary = processor.process(
        input_paths=[Path(value) for value in args.input],
        output_root=Path(args.output),
        selected_types=set(args.types) if args.types else None,
        export_excel=not args.no_excel,
        copy_source_files=not args.no_copy,
        log_callback=print,
    )
    engine.print_summary_to_console(summary)
    return {
        "processed": len(summary.results),
        "skipped": len(summary.skipped),
        "errors": len(summary.errors),
        "workbook": str(summary.workbook_path) if summary.workbook_path else "",
    }


def cmd_generate(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    processor = engine.CrashCurveProcessor()
    output_dir = Path(args.output)
    types = set(args.types) if args.types else None
    started_ns = time.time_ns() - 2_000_000_000  # file-system timestamp slack
    if args.variant == "standard":
        messages = processor.generate_demo_curves(output_dir, selected_types=types)
    elif args.variant in {"ctx-cty-full", "high-amp"}:
        if types:
            warn("--types is ignored by the ctx-cty-full and high-amp variants; the engine writes front, left, right and rear")
        high_amp = args.variant == "high-amp"
        messages = processor.generate_ctx_cty_fullsample_curves(
            output_dir,
            overscale_factor=args.overscale if args.overscale is not None else (1.8 if high_amp else 1.0),
            allow_exceed_max_lsb=args.allow_exceed_max_lsb,
            folder_tag="high_amp" if high_amp else "",
            max_abs_delta_v_kmph=args.max_abs_delta_v if args.max_abs_delta_v is not None
            else (engine.HIGH_AMP_MAX_ABS_DELTA_V_KMPH if high_amp else None),
        )
    else:
        messages = processor.generate_out_of_range_combo_curves(
            output_dir,
            overscale_factor=args.overscale if args.overscale is not None else engine.OUT_OF_RANGE_DEFAULT_SCALE,
            selected_types=types,
        )
    for message in messages:
        print(message)
    annotated = annotate_t0_summaries(engine, output_dir, started_ns)
    print(f"always-on end of event added to {annotated} t0_tend_summary.txt file(s)")
    unreached = [message for message in messages if "not reached" in message and "Tend not reached" not in message]
    if unreached:
        warn(f"{len(unreached)} crash set(s) did not reach the wake threshold")
    return {"variant": args.variant, "messages": messages, "failed": len(unreached)}


def cmd_multi_event(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    count = len(args.events)
    inversions = [inversion_tokens(engine, value) for value in per_event_values(args.invert, count, "--invert")]
    sources = [Path(value) if value else None for value in per_event_values(args.source, count, "--source")]
    overrides = [int(value) if value else None for value in per_event_values(args.t0_override, count, "--t0-override")]
    for delay in args.delays_ms:
        if delay >= 5000.0:
            warn(f"T0-to-T0 delay {delay:g} ms is not below 5 s; the events are separate single events, not a multi-event")
    case_dir, messages = engine.CrashCurveProcessor().generate_multi_event_curves(
        output_dir=Path(args.output),
        event_types=args.events,
        delay_ms_between=args.delays_ms,
        inversion_tokens_by_event=inversions,
        source_dirs_by_event=sources,
        t0_override_samples_by_event=overrides,
    )
    for message in messages:
        print(message)
    return {"folder": str(case_dir), "summary": str(case_dir / "multi_event_summary.txt")}


def cmd_delta_v_curve(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    case_dir, validation = engine.CrashCurveProcessor().generate_longitudinal_delta_v_curve(
        output_dir=Path(args.output),
        target_abs_delta_v_kmph=args.target_kmph,
        pulse_duration_ms=args.pulse_ms,
        positive_polarity=not args.negative,
        tolerance_kmph=args.tolerance,
    )
    print(f"{'PASS' if validation.passed else 'FAIL'}: {validation.delta_v_kmph:.3f} km/h in {case_dir}")
    return {"folder": str(case_dir), "passed": validation.passed, "delta_v_kmph": validation.delta_v_kmph}


def cmd_delta_v_validate(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    target = None if args.target_kmph is None else (-args.target_kmph if args.negative else args.target_kmph)
    validation = engine.CrashCurveProcessor().validate_longitudinal_delta_v_curve(
        Path(args.input), target_delta_v_kmph=target, tolerance_kmph=args.tolerance,
    )
    status = "MEASURED" if validation.passed is None else "PASS" if validation.passed else "FAIL"
    print(f"{status}: {validation.delta_v_kmph:.3f} km/h | {validation.remarks}")
    return {"passed": validation.passed, "delta_v_kmph": validation.delta_v_kmph, "remarks": validation.remarks}


def cmd_change_in_velocity(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    output_dir = Path(args.output)
    profiles = {crash: Path(path) for crash, path in parse_key_values(args.profile or [], "--profile").items()}
    for crash, path in profiles.items():
        if not path.is_file():
            raise RunnerError(f"--profile {crash}: {path} not found")
    definition = resolve_did_definition(args, output_dir) if (args.project or args.did_definition) else None
    case_dirs = engine.CrashCurveProcessor().generate_change_in_velocity_curves(
        output_dir=output_dir,
        target_delta_v_kmph=args.target_kmph,
        pulse_duration_ms=args.pulse_ms,
        selected_types=set(args.types) if args.types else None,
    )
    results: dict[str, Any] = {}
    for crash, case_dir in case_dirs.items():
        entry: dict[str, Any] = {"folder": str(case_dir)}
        profile = profiles.get(crash)
        if profile is not None:
            entry["profile_cloned"] = engine.clone_xml_profile_for_change_in_velocity_folder(profile, case_dir)
        did_line = "DID Delta-V Expected Values: not generated (give --project or --did-definition)"
        if definition is not None:
            signs = report_signs(args)
            validation = apply_report_sign(engine, engine.calculate_did_0455_validation(case_dir, definition),
                                           signs["long"], signs["lat"])
            expected = engine.export_did_0455_expected_values(case_dir / engine.DID_0455_EXPECTED_VALUES_FILE_NAME, validation)
            did_line = (f"DID Delta-V Expected Values: {expected.name} (layout {definition.name}; report signs "
                        f"longitudinal {signs['long']:+d}, lateral {signs['lat']:+d}, {signs['basis']})")
            entry["did_expected"] = str(expected)
        summary = case_dir / engine.DELTA_V_VALIDATION_SUMMARY_FILE_NAME
        if summary.is_file():
            lines = [did_line if line.startswith("DID 0x0455 Expected Values:") else line
                     for line in summary.read_text(encoding="ascii").splitlines()]
            summary.write_text("\n".join(lines) + "\n", encoding="ascii")
            entry["overall"] = next((line for line in lines if line.startswith("Overall Validation:")), "")
        results[crash] = entry
        print(f"{crash}: {entry.get('overall', '')} | {case_dir}")
    if any(entry.get("profile_cloned") for entry in results.values()):
        results["polarity"] = run_polarity(
            engine, [Path(entry["folder"]) for entry in results.values() if entry.get("profile_cloned")],
            output_dir / "polarity", expectations=polarity_expectations(args.convention, {}), combine=True,
        )
    elif profiles == {}:
        warn("no --profile given: the sign these curves reach the ECU with is unchecked; run polarity "
             "on the folders once their HIL profiles exist")
    return results


def cmd_delta_v_trace(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    source, output_dir = Path(args.input), Path(args.output)
    written = [engine.export_curve_delta_v_values_text(source, output_dir)]
    if args.notepad:
        written.append(engine.export_curve_delta_v_notepad(source, output_dir))
    for path in written:
        print(f"written {path}")
    return {"files": [str(path) for path in written]}


def cmd_low_amp(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    path = engine.CrashCurveProcessor().generate_low_amplitude_curve(Path(args.output), args.sensor, args.max_g)
    print(f"written {path}")
    return {"file": str(path)}


def report_signs(args: argparse.Namespace) -> dict[str, Any]:
    """Signs taking the ECU-input (AUTOSAR, rule R2) Delta-V to the reported DID value.

    Default: the AUTOSAR -> Part 563 / SAE J211 turn about X (longitudinal +1, lateral -1).
    --report-sign-long / --report-sign-lat override either axis.
    """
    explicit_long = getattr(args, "report_sign_long", None)
    explicit_lat = getattr(args, "report_sign_lat", None)
    signs = {
        "long": explicit_long if explicit_long is not None else AUTOSAR_TO_REPORT_SIGN["long"],
        "lat": explicit_lat if explicit_lat is not None else AUTOSAR_TO_REPORT_SIGN["lat"],
    }
    defaulted = [axis for axis, value in (("long", explicit_long), ("lat", explicit_lat)) if value is None]
    signs["basis"] = ("AUTOSAR onboard frame -> Part 563 reporting frame (rule R2, edr-agent 5.2)"
                      + (f" for {', '.join(defaulted)}" if len(defaulted) == 1 else "")) if defaulted else "explicit"
    return signs


def _did_validation(engine: Any, args: argparse.Namespace, output_dir: Path) -> tuple[Any, Path, dict[str, Any]]:
    definition = resolve_did_definition(args, output_dir)
    validation = engine.calculate_did_0455_validation(Path(args.curves), definition, t0_override_sample=args.t0_override)
    signs = report_signs(args)
    validation = apply_report_sign(engine, validation, signs["long"], signs["lat"])
    print(f"report signs: longitudinal {signs['long']:+d}, lateral {signs['lat']:+d} ({signs['basis']})")
    return validation, definition, signs


def cmd_did_expected(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    output_dir = Path(args.output)
    validation, definition, signs = _did_validation(engine, args, output_dir)
    path = engine.export_did_0455_expected_values(output_dir / engine.DID_0455_EXPECTED_VALUES_FILE_NAME, validation)
    out_of_range = sum(not value.range_ok for value in validation.values)
    print(f"{validation.crash_type}: T0 sample {validation.t0_sample} ({validation.t0_ms:.3f} ms) via "
          f"{validation.trigger_curve.name}; {len(validation.values)} fields, {out_of_range} out of range -> {path}")
    return {"file": str(path), "layout": str(definition), "t0_sample": validation.t0_sample,
            "out_of_range": out_of_range, "report_signs": signs}


def cmd_did_compare(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    output_dir = Path(args.output)
    validation, definition, signs = _did_validation(engine, args, output_dir)
    response = read_response_text(args.ecu_response)
    response_bytes = engine.parse_did_0455_hex_bytes(response)
    if args.first_byte == 1 and response_bytes and response_bytes[0] != 0x62:
        warn(f"--first-byte 1 expects a full positive response starting 62; first byte is {response_bytes[0]:02X}")
    comparison = engine.compare_did_0455_response_bytes(validation, response, first_byte_position=args.first_byte)
    path = engine.export_did_0455_comparison(output_dir / engine.DID_0455_COMPARISON_FILE_NAME, comparison)
    compared = [value for value in comparison.values if value.matched is not None]
    matched = sum(value.matched is True for value in compared)
    print(f"matched {matched}/{len(compared)} field(s) -> {path}")
    result: dict[str, Any] = {"file": str(path), "layout": str(definition), "matched": matched,
                              "compared": len(compared), "failed": len(compared) - matched}
    if not compared:
        warn("no field lies inside the pasted bytes; check --first-byte against the layout numbering")
        result["failed"] = 1

    # Cross-check the report signs: does the read-out match better with an axis flipped?
    flipped = apply_report_sign(engine, validation, -1, -1)
    flipped_comparison = engine.compare_did_0455_response_bytes(flipped, response, first_byte_position=args.first_byte)
    verdicts: dict[str, Any] = {"signs_used": signs}
    for axis, option, kinds in (("longitudinal", "long", {"longitudinal_snapshot", "max_longitudinal"}),
                                ("lateral", "lat", {"lateral_snapshot", "max_lateral"})):
        def score(values: tuple[Any, ...]) -> int:
            return sum(
                value.matched is True for value in values
                if value.expected.field.field_kind in kinds and value.expected.calculated_value != 0.0
            )
        used, opposite = score(comparison.values), score(flipped_comparison.values)
        if used > opposite:
            verdict = f"report sign {signs[option]:+d} confirmed"
        elif opposite > used:
            verdict = (f"report sign is OPPOSITE to {signs[option]:+d}: "
                       f"rerun with --report-sign-{option} {-signs[option]:+d} and record it for the project (EDR-Q13)")
        else:
            verdict = "undetermined (no non-zero field decides it)"
        verdicts[axis] = {"match_with_sign_used": used, "match_with_opposite_sign": opposite, "verdict": verdict}
        print(f"polarity {axis}: {used} non-zero field(s) match with sign {signs[option]:+d}, "
              f"{opposite} with the opposite sign -> {verdict}")
    result["polarity"] = verdicts
    return result


def cmd_polarity(engine: Any, args: argparse.Namespace) -> dict[str, Any]:
    user = load_json(args.expect, "Polarity expectation file") if args.expect else {}
    for crash, channels in user.items():
        for channel, sign in channels.items():
            if sign not in {"+", "-"}:
                raise RunnerError(f"expectation {crash}/{channel}: use '+' or '-', not '{sign}'")
    if args.convention == "none":
        warn("--convention none: onboard signs are not checked against the AUTOSAR vehicle axis (rule R2)")
    return run_polarity(engine, [Path(value) for value in args.input], Path(args.output),
                        polarity_expectations(args.convention, user), args.crash_type)


def cmd_ui(engine: Any, _args: argparse.Namespace) -> dict[str, Any]:
    engine.main(["--ui"])
    return {}


COMMANDS = {
    "export-config": cmd_export_config,
    "inspect": cmd_inspect,
    "process": cmd_process,
    "generate": cmd_generate,
    "multi-event": cmd_multi_event,
    "delta-v-curve": cmd_delta_v_curve,
    "delta-v-validate": cmd_delta_v_validate,
    "change-in-velocity": cmd_change_in_velocity,
    "delta-v-trace": cmd_delta_v_trace,
    "low-amp": cmd_low_amp,
    "did-expected": cmd_did_expected,
    "did-compare": cmd_did_compare,
    "polarity": cmd_polarity,
    "ui": cmd_ui,
}
# Commands whose --output is a folder that receives the run manifest.
MANIFEST_COMMANDS = set(COMMANDS) - {"export-config", "delta-v-validate", "ui"}
CRASH_TYPE_CHOICES = ("front", "left", "right", "rear", "near", "underbody", "rollover")


# --------------------------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--config", help="JSON overriding sensors, crash_rules, crash_cases, change_in_velocity")
    common.add_argument("--seed", type=int, default=0, help="seed for the engine's random noise channels (default 0)")
    common.add_argument("--date", help="YYYY-MM-DD used in generated file and folder names (default: today)")

    did = argparse.ArgumentParser(add_help=False)
    did.add_argument("--curves", required=True, help="curve folder (or one curve file) holding the crash")
    did.add_argument("--project", help="project whose config/edr_config.py supplies the Delta-V DID layout")
    did.add_argument("--did-definition", help="explicit layout CSV instead of --project")
    did.add_argument("--element-map", nargs="*", metavar="ROLE=ELEMENT",
                     help=f"override element names; roles: {', '.join(DELTA_V_ROLES)}")
    did.add_argument("--t0-override", type=int, help="zero-based T0 sample confirmed on the ECU/HIL")
    report = argparse.ArgumentParser(add_help=False)
    report.add_argument("--report-sign-long", type=int, choices=(-1, 1),
                        help="reported / ECU-input sign of longitudinal Delta-V (default +1: AUTOSAR -> Part 563)")
    report.add_argument("--report-sign-lat", type=int, choices=(-1, 1),
                        help="reported / ECU-input sign of lateral Delta-V (default -1: AUTOSAR Y left -> Part 563 Y right)")

    convention = argparse.ArgumentParser(add_help=False)
    convention.add_argument("--convention", choices=CONVENTIONS, default="autosar",
                            help="onboard sign convention to check (default autosar: front X-, rear X+, left Y-, right Y+); "
                                 "'none' only when the user specifies another convention")
    did.add_argument("--output", required=True, help="folder for the layout and result CSVs")

    parser = argparse.ArgumentParser(
        prog="edr_curve_runner.py",
        description="EDR RSU acceleration curve generation, analysis and EDR Delta-V expectation (offline).",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("export-config", parents=[common], help="write the engine parameters as JSON")
    p.add_argument("--output", required=True, help="JSON file to write")

    p = sub.add_parser("inspect", parents=[common], help="T0/Tend/Delta-V of curve files, no copies")
    p.add_argument("--input", nargs="+", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--crash-type", choices=CRASH_TYPE_CHOICES, help="force the crash type instead of inferring it")

    p = sub.add_parser("process", parents=[common], help="engine folder processing with Excel export")
    p.add_argument("--input", nargs="+", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--types", nargs="*", choices=CRASH_TYPE_CHOICES)
    p.add_argument("--no-excel", action="store_true")
    p.add_argument("--no-copy", action="store_true")

    p = sub.add_parser("generate", parents=[common], help="synthetic crash curve sets")
    p.add_argument("--output", required=True)
    p.add_argument("--types", nargs="*", choices=("front", "left", "right", "rear", "near"))
    p.add_argument("--variant", choices=GENERATE_VARIANTS, default="standard")
    p.add_argument("--overscale", type=float, help="amplitude scale (high-amp default 1.8, out-of-range default 1.10)")
    p.add_argument("--allow-exceed-max-lsb", action="store_true", help="ctx-cty variants: let samples pass the sensor range")
    p.add_argument("--max-abs-delta-v", type=float, help="ctx-cty variants: cap |Delta-V| of the trigger channel (km/h)")

    p = sub.add_parser("multi-event", parents=[common], help="merge 2..7 events on T0-to-T0 delays")
    p.add_argument("--output", required=True)
    p.add_argument("--events", nargs="+", required=True, choices=("front", "left", "right", "rear", "near"))
    p.add_argument("--delays-ms", nargs="+", type=float, required=True, help="T0-to-T0 delay per gap (count = events - 1)")
    p.add_argument("--invert", nargs="*", help="per event: comma tokens (ctx,cty,flx,...) or * or -")
    p.add_argument("--source", nargs="*", help="per event: existing crash folder or - for the built-in curve")
    p.add_argument("--t0-override", nargs="*", help="per event: confirmed T0 sample or -")

    p = sub.add_parser("delta-v-curve", parents=[common], help="onboard-X curve with a requested Delta-V")
    p.add_argument("--output", required=True)
    p.add_argument("--target-kmph", type=float, required=True, help="requested |Delta-V| (km/h)")
    p.add_argument("--pulse-ms", type=float, default=100.0)
    p.add_argument("--negative", action="store_true", help="negative polarity")
    p.add_argument("--tolerance", type=float, default=0.05, help="km/h")

    p = sub.add_parser("delta-v-validate", parents=[common], help="check one onboard-X curve")
    p.add_argument("--input", required=True)
    p.add_argument("--target-kmph", type=float)
    p.add_argument("--negative", action="store_true")
    p.add_argument("--tolerance", type=float, default=0.05)

    p = sub.add_parser("change-in-velocity", parents=[common, report, convention], help="EDR record-trigger sets (>8 km/h in 150 ms)")
    p.add_argument("--output", required=True)
    p.add_argument("--target-kmph", type=float, default=9.0, help="Delta-V from T0, must exceed 8 km/h")
    p.add_argument("--pulse-ms", type=float, default=150.0, help="window after T0, at most 150 ms")
    p.add_argument("--types", nargs="*", choices=("front", "left", "right", "rear"))
    p.add_argument("--profile", nargs="*", metavar="TYPE=XML", help="HIL profile to clone into each crash folder")
    p.add_argument("--project", help="project for the Delta-V DID layout")
    p.add_argument("--did-definition", help="explicit layout CSV instead of --project")
    p.add_argument("--element-map", nargs="*", metavar="ROLE=ELEMENT")

    p = sub.add_parser("delta-v-trace", parents=[common], help="cumulative Delta-V of one curve")
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--notepad", action="store_true", help="also write the sample-by-sample calculation report")

    p = sub.add_parser("low-amp", parents=[common], help="one low-amplitude curve")
    p.add_argument("--output", required=True)
    p.add_argument("--sensor", required=True, help="sensor key, see export-config")
    p.add_argument("--max-g", type=float, required=True)

    sub.add_parser("did-expected", parents=[common, did, report], help="expected EDR Delta-V DID fields")

    p = sub.add_parser("did-compare", parents=[common, did, report], help="expected fields vs an ECU response")
    p.add_argument("--ecu-response", required=True, help="hex bytes, or @file holding them")
    p.add_argument("--first-byte", type=int, default=1,
                   help="position of the first pasted byte in the layout numbering (1 = full response incl. 62 xx xx)")

    p = sub.add_parser("polarity", parents=[common, convention], help="sign each channel reaches the ECU with")
    p.add_argument("--input", nargs="+", required=True, help="crash folder(s) or root(s) holding HIL profiles")
    p.add_argument("--output", required=True)
    p.add_argument("--expect", help="JSON {crash_type: {channel: '+'|'-'}} of expected ECU-input signs")
    p.add_argument("--crash-type", choices=CRASH_TYPE_CHOICES, help="force the crash type of every folder")

    p = sub.add_parser("run-job", help="run a JSON job of several commands")
    p.add_argument("--job", required=True)

    sub.add_parser("ui", parents=[common], help="launch the original desktop GUI")
    return parser


def job_step_argv(step: dict[str, Any], defaults: dict[str, Any]) -> list[str]:
    merged = {**defaults, **step}
    command = merged.pop("command", None)
    if command not in COMMANDS:
        raise RunnerError(f"job step has unknown command {command!r}; use one of {', '.join(COMMANDS)}")
    argv = [command]
    for key, value in merged.items():
        flag = "--" + key.replace("_", "-")
        if value is None or value is False:
            continue
        if value is True:
            argv.append(flag)
        elif isinstance(value, list):
            argv.extend([flag, *[str(item) for item in value]])
        elif isinstance(value, dict):
            argv.extend([flag, *[f"{item_key}={item_value}" for item_key, item_value in value.items()]])
        else:
            argv.extend([flag, str(value)])
    return argv


def run_job(job_path: Path) -> int:
    job = load_json(job_path, "Job file")
    steps = job.get("steps")
    if not isinstance(steps, list) or not steps:
        raise RunnerError(f"{job_path}: 'steps' must be a non-empty list")
    defaults = job.get("defaults", {})
    continue_on_error = bool(job.get("continue_on_error", False))
    previous_dir = Path.cwd()
    os.chdir(job_path.resolve().parent)  # relative paths in a job are relative to the job file
    worst = 0
    try:
        for index, step in enumerate(steps, start=1):
            argv = job_step_argv(step, defaults)
            print(f"== job step {index}/{len(steps)}: {' '.join(argv)}")
            code = main(argv)
            worst = max(worst, code)
            if code and not continue_on_error:
                print(f"job stopped at step {index} (exit {code})")
                return code
    finally:
        os.chdir(previous_dir)
    return worst


def write_manifest(args: argparse.Namespace, run_date: date, before: dict[str, tuple[int, int]],
                   result: dict[str, Any], exit_code: int) -> None:
    output_dir = Path(args.output)
    after = snapshot(output_dir)
    changed = sorted(path for path, stamp in after.items() if before.get(path) != stamp
                     and not path.startswith("edr_curve_manifest_"))
    manifest = {
        "runner": SCRIPT_DIR.joinpath(Path(__file__).name).relative_to(REPO_ROOT).as_posix(),
        "engine": {"file": ENGINE_PATH.relative_to(REPO_ROOT).as_posix(), "sha256": ENGINE_SHA256},
        "command": args.command,
        "arguments": {key: (str(value) if isinstance(value, Path) else value) for key, value in vars(args).items()},
        "seed": args.seed,
        "run_date": run_date.isoformat(),
        "exit_code": exit_code,
        "result": result,
        "warnings": list(WARNINGS),
        "files_written": changed,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / f"edr_curve_manifest_{args.command}.json").write_text(
        json.dumps(manifest, indent=2, default=str) + "\n", encoding="utf-8"
    )


def main(argv: list[str] | None = None) -> int:
    WARNINGS.clear()
    args = build_parser().parse_args(argv)
    try:
        if args.command == "run-job":
            return run_job(Path(args.job))
        run_date = date.fromisoformat(args.date) if args.date else datetime.now().date()
        overrides = load_json(args.config, "Config file") if args.config else None
        engine = load_engine(overrides, run_date if args.date else None)
        random.seed(args.seed)
        before = snapshot(Path(args.output)) if args.command in MANIFEST_COMMANDS else {}
        result = COMMANDS[args.command](engine, args)
        exit_code = 1 if isinstance(result, dict) and (
            result.get("failed") or result.get("passed") is False
            or (isinstance(result.get("polarity"), dict) and result["polarity"].get("failed"))
        ) else 0
        if args.command in MANIFEST_COMMANDS:
            write_manifest(args, run_date, before, result, exit_code)
        return exit_code
    except (RunnerError, ValueError, KeyError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    except OSError as error:
        hint = ""
        name = getattr(error, "filename", None)
        if os.name == "nt" and name and len(str(Path(name).resolve())) >= 250:
            hint = (" - this path reaches the Windows 260-character limit; the engine's file names are "
                    "about 80 characters, so use a shorter --output folder or enable long paths")
        print(f"error: {error}{hint}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
