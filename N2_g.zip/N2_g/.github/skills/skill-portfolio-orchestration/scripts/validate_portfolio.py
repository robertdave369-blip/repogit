"""Validate Framework_IOEM_Py skill registry and evidence handoff envelopes.

This uses only the Python standard library so it can run before optional
dependency environments are healthy. It deliberately validates the portable
contract rather than attempting to execute any domain or bench skill.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


SKILL_ROOT = Path(__file__).resolve().parents[2]
REGISTRY_PATH = SKILL_ROOT / "skill-portfolio-orchestration" / "assets" / "skill-registry.json"
SCHEMA_PATH = SKILL_ROOT / "skill-portfolio-orchestration" / "references" / "evidence-handoff.schema.json"
VALID_SAFETY_STATES = {"offline", "sandbox", "authorized_bench", "blocked"}
VALID_CONFIDENCE_LEVELS = {"Very High", "High", "Medium", "Low", "Unknown"}
VALID_STATUSES = {"completed", "blocked", "needs_review", "failed"}


def _read_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return payload


def validate_output_location_policy(policy_path: Path) -> dict[str, Any]:
    policy = _read_json(policy_path)
    errors: list[str] = []
    test_outputs = policy.get("test_related_outputs")
    documents = policy.get("document_processing")
    if not isinstance(test_outputs, dict):
        errors.append("Output policy requires test_related_outputs.")
    else:
        if test_outputs.get("root") != "tests":
            errors.append("Test-related output root must be tests.")
        if test_outputs.get("test_source_pattern") != "tests/test_<feature>.py":
            errors.append("Test source pattern must be tests/test_<feature>.py.")
        if not str(test_outputs.get("supporting_folder_pattern", "")).startswith("tests/"):
            errors.append("Test supporting folder pattern must remain under tests/.")
        if not str(test_outputs.get("validation_artifact_root", "")).startswith("tests/"):
            errors.append("Validation artifact root must remain under tests/.")
    if not isinstance(documents, dict):
        errors.append("Output policy requires document_processing.")
    else:
        if documents.get("source_root") != "docs":
            errors.append("Original document root must be docs.")
        if documents.get("processed_root") != "docs/processed_Documents":
            errors.append("Processed document root must be docs/processed_Documents.")
        if "source document filename stem" not in str(documents.get("folder_rule", "")).lower():
            errors.append("Document folder rule must preserve the source document filename stem.")
    return {"status": "passed" if not errors else "failed", "errors": errors, "path": str(policy_path)}


def validate_registry(skill_root: Path = SKILL_ROOT) -> dict[str, Any]:
    registry_path = skill_root / "skill-portfolio-orchestration" / "assets" / "skill-registry.json"
    registry = _read_json(registry_path)
    entries = registry.get("skills")
    workflows = registry.get("workflows")
    if not isinstance(entries, list) or not isinstance(workflows, list):
        raise ValueError("Registry requires skills and workflows arrays.")
    policy_relative_path = registry.get("output_location_policy")
    if not isinstance(policy_relative_path, str):
        raise ValueError("Registry requires output_location_policy.")
    policy_result = validate_output_location_policy(registry_path.parent / policy_relative_path)
    actual_skills = {
        path.name
        for path in skill_root.iterdir()
        if path.is_dir() and path.name != "skill-portfolio-orchestration"
    }
    registered: set[str] = set()
    errors: list[str] = []
    for entry in entries:
        if not isinstance(entry, dict):
            errors.append("Registry contains a non-object skill entry.")
            continue
        identifier = entry.get("id")
        relative_path = entry.get("path")
        if not isinstance(identifier, str) or not identifier:
            errors.append("Registry skill entry is missing id.")
            continue
        if identifier in registered:
            errors.append(f"Duplicate registry skill id: {identifier}")
        registered.add(identifier)
        if not isinstance(relative_path, str) or not (registry_path.parent / relative_path).resolve().is_file():
            errors.append(f"Registry path does not resolve for {identifier}: {relative_path}")
        if not isinstance(entry.get("role"), str) or not isinstance(entry.get("safety_gate"), str):
            errors.append(f"Registry entry lacks role or safety_gate: {identifier}")
    if actual_skills != registered:
        errors.append(f"Registry coverage mismatch: actual={sorted(actual_skills)}, registered={sorted(registered)}")
    errors.extend(policy_result["errors"])
    for workflow in workflows:
        if not isinstance(workflow, dict):
            errors.append("Registry contains a non-object workflow entry.")
            continue
        skills = workflow.get("skills")
        verifier = workflow.get("verifier")
        if not isinstance(skills, list) or not all(isinstance(skill, str) for skill in skills):
            errors.append(f"Workflow skills invalid: {workflow.get('id')}")
            continue
        unknown = set(skills) - registered
        if unknown or verifier not in registered:
            errors.append(f"Workflow references unknown skill(s): {workflow.get('id')} -> {sorted(unknown)}")
    return {
        "status": "passed" if not errors else "failed",
        "skill_count": len(registered),
        "workflow_count": len(workflows),
        "output_location_policy": policy_result,
        "errors": errors,
    }


def validate_envelope(envelope: dict[str, Any], schema_path: Path = SCHEMA_PATH) -> dict[str, Any]:
    schema = _read_json(schema_path)
    required = schema.get("required", [])
    errors: list[str] = []
    for field in required:
        if field not in envelope:
            errors.append(f"Missing required field: {field}")
    if errors:
        return {"status": "failed", "errors": errors}
    if envelope.get("safety_state") not in VALID_SAFETY_STATES:
        errors.append("Invalid safety_state.")
    if envelope.get("status") not in VALID_STATUSES:
        errors.append("Invalid status.")
    confidence = envelope.get("confidence")
    if not isinstance(confidence, dict) or confidence.get("level") not in VALID_CONFIDENCE_LEVELS or not isinstance(confidence.get("rationale"), str):
        errors.append("Invalid confidence object.")
    for field in ("facts", "inferences", "assumptions", "contradictions", "evidence_gaps", "artifacts"):
        if not isinstance(envelope.get(field), list):
            errors.append(f"{field} must be an array.")
    if envelope.get("safety_state") == "authorized_bench" and not isinstance(envelope.get("approval"), dict):
        errors.append("authorized_bench envelopes require approval metadata.")
    return {"status": "passed" if not errors else "failed", "errors": errors}


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate skill portfolio registry and evidence envelopes.")
    parser.add_argument("--registry", action="store_true", help="Validate the workspace skill registry")
    parser.add_argument("--envelope", help="Validate an evidence-envelope JSON file")
    parser.add_argument("--skill-root", default=str(SKILL_ROOT), help="Workspace .github/skills directory")
    return parser


def main() -> int:
    args = build_argument_parser().parse_args()
    if not args.registry and not args.envelope:
        args.registry = True
    results: dict[str, Any] = {}
    if args.registry:
        results["registry"] = validate_registry(Path(args.skill_root).resolve())
    if args.envelope:
        envelope_path = Path(args.envelope).expanduser().resolve()
        results["envelope"] = validate_envelope(_read_json(envelope_path))
    status = "passed" if all(result["status"] == "passed" for result in results.values()) else "failed"
    print(json.dumps({"status": status, "results": results}, indent=2))
    return 0 if status == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())