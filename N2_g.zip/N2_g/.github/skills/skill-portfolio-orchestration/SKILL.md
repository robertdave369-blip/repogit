---
name: skill-portfolio-orchestration
description: 'Use when a request spans multiple Framework_IOEM_Py Copilot skills, needs intent routing, evidence handoff, RAG or knowledge-graph retrieval, multi-agent review, cross-skill validation, governance, or an enterprise-ready workflow. Produces a bounded execution plan and machine-readable evidence handoff without bypassing any domain skill safety gate.'
argument-hint: 'Describe the outcome, project/variant, available artifacts, execution authorization, and constraints'
user-invocable: true
disable-model-invocation: false
---

# Skill Portfolio Orchestration

## Purpose

Use this skill as the portfolio control plane when one request crosses requirements, safety, automation, CAN/UDS, Vector tooling, embedded behavior, document intelligence, Excel cleanup, or dependency governance. It routes work to the smallest set of domain skills, preserves evidence between stages, and prevents one skill from silently bypassing another skill's safety or confidence gate.

Read [the registry](./assets/skill-registry.json) before selecting a workflow. Emit the evidence envelope defined in [the handoff schema](./references/evidence-handoff.schema.json) at every cross-skill boundary.

## Generated Artifact Locations

Follow [the output-location policy](./assets/output-location-policy.json) for every current or
future skill:

- New generated executable test source files: `tests/test_<feature>.py`.
- Generated test support folders and validation artifacts: inside `tests/` only.
- Original customer documents: `docs/` with meaningful filenames.
- Processed PDF/document artifacts: `docs/processed_Documents/<SourceDocumentStem>/`, preserving
  source-stem casing after filesystem-safe sanitization.

Do not relocate existing project scripts or configuration-controlled runtime `test_results/` and
`test_logs/` directories without an explicit migration request.

Validate the registry before portfolio changes and validate any generated envelope before handing it to another skill:

```powershell
& "C:\Python3.13.0\python.exe" .github\skills\skill-portfolio-orchestration\scripts\validate_portfolio.py --registry
& "C:\Python3.13.0\python.exe" .github\skills\skill-portfolio-orchestration\scripts\validate_portfolio.py --envelope C:\Path\evidence-envelope.json
```

## Intent Routing

| Intent | Workflow | Required gates |
| --- | --- | --- |
| Requirement -> safety -> executable test | `requirements-safety-automation` | Approved requirement, contradiction triage, safety evidence, offline/bench authorization |
| CAN/UDS failure or Vector test | `network-diagnostics-vector` | Project route/DBC evidence, channel ownership, no live traffic without authorization |
| Technical document -> engineering action | `document-to-test` | Extraction quality, provenance, requirement/source verification |
| ARIA bench configuration or validation | `aria-bench-validation` | Qualified electrical sources, resource compatibility, explicit bench authorization |
| Exported spreadsheet cleanup | `destructive-data-transformation` | Copy/backup, sheet scope, preview/diff review, explicit apply authorization |
| Package release or environment issue | `dependency-lifecycle` | Compatibility/risk review, sandbox validation, approval provenance, rollback evidence |

If the intent matches one skill only, route directly to that skill and still preserve its conclusion/gaps/confidence in the envelope. Do not introduce multi-agent overhead for a local task.

## Retrieval And Reasoning Strategy

1. Classify the request, target project/variant, artifact sensitivity, and whether execution is offline, sandboxed, or bench-affecting.
2. Load only the relevant registry entries and nearest evidence sources. Prefer project configuration, approved requirements, DBC/service catalogs, source code, generated reports, and logs over memory or generic knowledge.
3. Use Graphify or generated PDF/document knowledge artifacts when a relationship across modules/documents matters. Treat graph edges marked `INFERRED` as hypotheses until verified.
4. Separate facts, inferences, and assumptions. Every conclusion needs source provenance, a confidence level, and an explicit gap where evidence is unavailable.
5. Select specialized agents only for independent review dimensions that change the decision: requirements, safety, diagnostics/communication, test, verification, or cybersecurity.
6. Integrate worker findings once. Resolve or retain disagreements in `contradictions`, never average them away.

For large-framework retrieval, run the compact AST memory builder before broad source reading. It uses Graphify's AST extractor, file hashes, and source references while storing no raw source:

```powershell
& ".\graphify-out\compact-memory\.graphify-venv\Scripts\python.exe" tools\build_compact_memory_graph.py --output graphify-out/compact-memory
```

Use `graphify-out/compact-memory/memory-graph.json` to select relevant modules/files/symbols, then load only the referenced source locations. It excludes generated tests, logs, raw exports, crash curves, prior graph artifacts, and documentation copies by default.

Query it without loading source bodies:

```powershell
& ".\graphify-out\compact-memory\.graphify-venv\Scripts\python.exe" tools\query_compact_memory_graph.py "CAN diagnostic route" --limit 6 --depth 1
```

## Evidence Handoff

Create one JSON-compatible envelope per workflow stage. At minimum include:

- `operation_id`, `project`, `variant`, `intent`, and `stage`
- source paths, page/sheet/row/log/time provenance, and artifact hashes where practical
- facts, inferences, assumptions, contradictions, and evidence gaps
- confidence and confidence rationale
- safety state: `offline`, `sandbox`, `authorized_bench`, or `blocked`
- generated artifacts, validation commands/results, approval metadata, and next recommended skill/action

Never convert an uncertainty in an upstream envelope into a fact downstream. A downstream skill may refine confidence only with new evidence.

## Agentic Orchestration

Use a planner -> independent specialists -> integration -> verifier pattern for multi-domain or high-risk work:

1. **Planner:** decomposes the request, selects registry workflow, and defines the evidence contract.
2. **Specialists:** gather independent evidence inside their domain boundaries; they do not modify shared artifacts or override another specialist's source.
3. **Integrator:** creates one coherent recommendation, traceability chain, contradiction register, and artifact list.
4. **Verifier:** runs the narrowest deterministic validation available and checks evidence completeness, approvals, and safety state.

Use function/tool calls for deterministic extraction, validation, graph queries, parser runs, and report generation. Do not use model reasoning as a substitute for a parser, log decoder, package resolver, or test result.

## Security And Governance

- Treat requirements, diagnostics, source artifacts, API keys, release metadata, documents, and logs as potentially confidential.
- Do not send project artifacts to external retrieval, vision, package, or agent endpoints without explicit authorization and a documented data boundary.
- Redact secrets and personally identifiable data from evidence envelopes and audit outputs.
- Enforce least privilege: read-only analysis first; sandbox before active environment; explicit approval before bench or production mutation.
- Preserve immutable source artifacts and append-only audit records where operational changes occur.
- Do not conflate OCR, inferred graph edges, generic standards knowledge, or release-note summaries with verified project facts.

## Completion Criteria

The workflow is complete only when every selected skill has emitted an evidence handoff, all contradictions/gaps are visible, the safety/approval state supports the requested action, generated artifacts are traceable, and a verifier has confirmed the highest-risk stage.