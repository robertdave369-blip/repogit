---
name: uds-diagnostics
description: 'Use when analyzing, implementing, reviewing, or testing UDS diagnostics under ISO 14229: Diagnostic Session Control, ECU identification DIDs, Read/Clear DTC Information, Security Access, Routine Control, communication control, ISO-TP routing, NRCs, or diagnostic logs in Framework_IOEM_Py. Uses verified APYM and shared-library paths without inventing routes, services, DIDs, DTCs, or keys.'
argument-hint: 'Describe the project, UDS service/route, evidence, and desired outcome'
user-invocable: true
disable-model-invocation: false
---

# UDS Diagnostics

## Scope

Use this skill to learn or work on UDS over the target project's CAN/CAN FD ISO-TP route. Cover the requested service, its preconditions, request/response bytes, transport timeline, state changes, and expected verification evidence.

Per-service ISO 14229 reference (request/response layouts, sub-functions, NRCs, DTC records, timing): `.github/uds/service-catalogue.md` and `.github/uds/services/`, maintained by the `uds-protocol-engineer` agent. Project and OEM facts override it.

The framework's verified diagnostic path is APYM through `shared_libraries/apym_imports.py` and `shared_libraries/jscript_translation.py` wrappers such as `CAN.SendDiagByValues()` and `CAN.SecurityAccess()`. Inspect the wrapper's current signature and the target project configuration before use. Do not bypass the wrapper with direct `Api.*` calls in test scripts.

## Workflow

1. Identify the ECU variant, diagnostic channel, physical/functional route, active DBC/configuration, session, security level, and requested service. Load root `agent.md` if available; otherwise state `Evidence unavailable.`
2. Verify the request/response IDs, ISO-TP addressing, padding, block size, `STmin`, P2/P2* timing, and tester-present requirements from project sources. Do not copy values from another variant.
3. Establish the service contract from approved requirements and service catalog: request format, positive response, allowed NRCs, access conditions, persistence, and state transition.
4. Reconstruct captured traffic into ISO-TP transactions: single/first/consecutive/flow-control frames, complete payload, timing, response, timeout, and retries.
5. Use the smallest safe test: nominal request, each meaningful precondition failure, malformed/unsupported request where approved, timeout/transport behavior, and recovery/session expiry where applicable.
6. Report facts, inferences, assumptions, evidence gaps, observed/expected response, state impact, and confidence.

## Service Checklist

| Service area | Verify before testing |
| --- | --- |
| Session management | Session transition, required tester-present behavior, timing, default-session recovery |
| ECU identification | DID availability, response length/encoding, source of expected identity data |
| Read DTC Information | Subfunction, status mask, DTC format, fault qualification and status semantics |
| Clear Diagnostic Information | Access/session/security preconditions, group semantics, verification after clearing |
| Security Access | Seed/key algorithm ownership, level, delay/lockout rules, audit and safety effects |
| Routine Control | RID, start/stop/results behavior, input/output records, persistence and abort path |

## Security And Bench Boundaries

Never guess a seed-key algorithm, brute-force a security level, expose keys, or weaken lockout behavior. Treat diagnostic writes, routines, coding, resets, clear-DTC operations, and session changes as bench-affecting. Do not run them against an ECU without explicit authorization.

## Portfolio Handoff

For a multi-skill workflow, preserve the physical/functional route, ISO-TP parameters, session/security preconditions, full request/response timeline, observed and expected NRCs, state effect, and authorization state. Hand lower-layer timing/CRC/counter evidence to `can-protocol-automotive-networks`, measurement ownership to `canoe-automation`, and safe executable checks to `python-test-automation`.

## Completion Criteria

The outcome is complete when route, transport parameters, service contract, preconditions, response interpretation, and expected state transition are backed by target-project evidence; every NRC is observed or sourced rather than guessed; and any test is traceable to a safe, authorized execution context.