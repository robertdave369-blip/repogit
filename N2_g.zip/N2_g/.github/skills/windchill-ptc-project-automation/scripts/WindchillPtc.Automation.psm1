Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$script:WindchillPtcMutatingOperations = @(
    "CreateSandbox",
    "CreateNamedSubprojects",
    "CloneProjectStructure",
    "CreateFolders",
    "SynchronizeFolderTree",
    "UploadInitializers",
    "AddFiles",
    "AddArchives",
    "AddProjectMembers",
    "RemoveProjectMembers",
    "UpdateMemberPermissions",
    "ChangeUserRoles"
)

$script:WindchillPtcSupportedOperations = @(
    "CreateSandbox",
    "ValidateSandbox",
    "CreateNamedSubprojects",
    "CloneProjectStructure",
    "ValidateProjectStructure",
    "CreateFolders",
    "ValidateFolderPaths",
    "SynchronizeFolderTree",
    "CreateProjectTemplate",
    "UploadInitializers",
    "AddFiles",
    "AddArchives",
    "CompareFiles",
    "ValidateChangePackage",
    "AddProjectMembers",
    "RemoveProjectMembers",
    "UpdateMemberPermissions",
    "ChangeUserRoles"
)

function Get-WindchillProperty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [object]$Object,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $false)]
        [object]$Default = $null
    )

    if ($null -eq $Object) {
        return $Default
    }

    if ($Object -is [System.Collections.IDictionary]) {
        if ($Object.Contains($Name)) {
            return $Object[$Name]
        }
        return $Default
    }

    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $Default
    }

    return $property.Value
}

function ConvertTo-WindchillArray {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [object]$Value
    )

    if ($null -eq $Value) {
        return @()
    }
    if ($Value -is [string]) {
        return @($Value)
    }
    if ($Value -is [System.Collections.IEnumerable]) {
        return @($Value)
    }
    return @($Value)
}

function Resolve-WindchillDirectoryPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$Label,
        [switch]$AllowMissing
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        throw "$Label is required."
    }

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        if ($AllowMissing) {
            return [System.IO.Path]::GetFullPath($Path).TrimEnd([char[]]@([System.IO.Path]::DirectorySeparatorChar))
        }
        throw "$Label does not exist or is not a directory: $Path"
    }

    return (Resolve-Path -LiteralPath $Path).ProviderPath.TrimEnd(
        [char[]]@([System.IO.Path]::DirectorySeparatorChar)
    )
}

function Get-WindchillRelativePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullPath,
        [Parameter(Mandatory = $true)]
        [string]$RootPath
    )

    $separator = [System.IO.Path]::DirectorySeparatorChar
    $normalizedRoot = $RootPath.TrimEnd([char[]]@($separator))
    $prefix = $normalizedRoot + $separator
    if (-not $FullPath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Path is outside the requested root. Path: $FullPath Root: $RootPath"
    }

    return $FullPath.Substring($prefix.Length)
}

function Assert-WindchillSafeRelativePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath,
        [Parameter(Mandatory = $true)]
        [string]$Label
    )

    if ([string]::IsNullOrWhiteSpace($RelativePath)) {
        throw "$Label must not be empty."
    }
    if ([System.IO.Path]::IsPathRooted($RelativePath)) {
        throw "$Label must be relative: $RelativePath"
    }

    foreach ($segment in $RelativePath.Replace("/", "\").Split("\")) {
        if ($segment -eq "." -or $segment -eq "..") {
            throw "$Label must not contain traversal segments: $RelativePath"
        }
    }
}

function Get-WindchillFileHash {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [string]$Algorithm = "SHA256"
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "File does not exist: $Path"
    }

    return (Get-FileHash -LiteralPath $Path -Algorithm $Algorithm).Hash
}

function Test-WindchillFileContentEqual {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FirstPath,
        [Parameter(Mandatory = $true)]
        [string]$SecondPath,
        [string]$Algorithm = "SHA256"
    )

    $firstFile = Get-Item -LiteralPath $FirstPath -ErrorAction Stop
    $secondFile = Get-Item -LiteralPath $SecondPath -ErrorAction Stop
    if ($firstFile.Length -ne $secondFile.Length) {
        return $false
    }

    return (Get-WindchillFileHash -Path $FirstPath -Algorithm $Algorithm) -eq `
        (Get-WindchillFileHash -Path $SecondPath -Algorithm $Algorithm)
}

function Read-WindchillJsonFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "JSON file does not exist: $Path"
    }

    try {
        return Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
    }
    catch {
        throw "Unable to parse JSON file '$Path': $($_.Exception.Message)"
    }
}

function Write-WindchillJsonFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [object]$Value
    )

    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
        New-Item -ItemType Directory -Path $parent -Force -ErrorAction Stop | Out-Null
    }

    $Value | ConvertTo-Json -Depth 32 | Set-Content -LiteralPath $Path -Encoding utf8
    return $Path
}

function Get-WindchillObjectHash {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Value
    )

    $json = $Value | ConvertTo-Json -Depth 32 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([System.BitConverter]::ToString($sha256.ComputeHash($bytes))).Replace("-", "")
    }
    finally {
        $sha256.Dispose()
    }
}

function New-WindchillOutputDirectory {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [string]$OutputRoot
    )

    if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
        $OutputRoot = Get-WindchillProperty -Object $Request -Name "outputRoot" -Default ""
    }
    if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
        $audit = Get-WindchillProperty -Object $Config -Name "audit" -Default $null
        $outputDirectoryName = Get-WindchillProperty -Object $audit -Name "outputDirectoryName" -Default "windchill-ptc-audit"
        $OutputRoot = Join-Path (Get-Location).Path $outputDirectoryName
    }

    $timestamp = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssfffZ")
    $outputDirectory = Join-Path $OutputRoot $timestamp
    New-Item -ItemType Directory -Path $outputDirectory -Force -ErrorAction Stop | Out-Null
    return (Resolve-Path -LiteralPath $outputDirectory).ProviderPath
}

function Write-WindchillAuditRecord {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory,
        [Parameter(Mandatory = $true)]
        [string]$Stage,
        [Parameter(Mandatory = $true)]
        [string]$Status,
        [Parameter(Mandatory = $false)]
        [object]$Data = $null
    )

    $record = [PSCustomObject]@{
        timestampUtc = [DateTime]::UtcNow.ToString("o")
        stage = $Stage
        status = $Status
        data = $Data
    }
    $line = $record | ConvertTo-Json -Depth 16 -Compress
    Add-Content -LiteralPath (Join-Path $OutputDirectory "audit.jsonl") -Value $line -Encoding utf8
    return $record
}

function Get-WindchillConfig {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConfigPath
    )

    $config = Read-WindchillJsonFile -Path $ConfigPath
    if ([string]::IsNullOrWhiteSpace((Get-WindchillProperty -Object $config -Name "schemaVersion" -Default ""))) {
        throw "Windchill automation config has no schemaVersion: $ConfigPath"
    }
    return $config
}

function ConvertTo-WindchillIntentDraft {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Intent
    )

    if ([string]::IsNullOrWhiteSpace($Intent)) {
        throw "Intent must not be empty."
    }

    $normalizedIntent = $Intent.Trim()
    $lowerIntent = $normalizedIntent.ToLowerInvariant()
    $operation = $null
    $confidence = "Low"

    if ($lowerIntent -match "(__init__\.py|initializer|initialiser)") {
        $operation = "UploadInitializers"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(create|new).*(sandbox)") {
        $operation = "CreateSandbox"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(validate|verify|check).*(folder|directory).*(path|tree|structure)|((folder|directory).*(validate|verify|check))") {
        $operation = "ValidateFolderPaths"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(validate|verify|check).*(sandbox)") {
        $operation = "ValidateSandbox"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(clone|copy).*(project|structure|tree)") {
        $operation = "CloneProjectStructure"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(create|new).*(nested|named|subproject|sub-project)") {
        $operation = "CreateNamedSubprojects"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(validate|verify|check).*(project|subproject|sub-project|hierarchy|tree)") {
        $operation = "ValidateProjectStructure"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(synchroni[sz]e|sync).*(folder|tree|directory)") {
        $operation = "SynchronizeFolderTree"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(create|generate).*(project template|template)") {
        $operation = "CreateProjectTemplate"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(create|new).*(folder|directory)") {
        $operation = "CreateFolders"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(compare|hash|consistency|unexpected file)") {
        $operation = "CompareFiles"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(add|upload).*(archive|zip|tar|7z)") {
        $operation = "AddArchives"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(upload|add).*(file|archive|source)") {
        $operation = "AddFiles"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(change package|cp).*(validate|verify|check)") {
        $operation = "ValidateChangePackage"
        $confidence = "High"
    }
    elseif ($lowerIntent -match "(remove|delete).*(member|user)") {
        $operation = "RemoveProjectMembers"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(permission|access)") {
        $operation = "UpdateMemberPermissions"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(role|developer|admin).*(member|user)|((member|user).*(role|developer|admin))") {
        $operation = "ChangeUserRoles"
        $confidence = "Medium"
    }
    elseif ($lowerIntent -match "(add|onboard).*(member|user)") {
        $operation = "AddProjectMembers"
        $confidence = "Medium"
    }

    $requiredFields = @()
    if ($operation -ne "CreateProjectTemplate" -and $null -ne $operation) {
        $requiredFields += "sandboxRoot"
        $requiredFields += "ptcProject"
    }
    if ($operation -in $script:WindchillPtcMutatingOperations -or $operation -eq "ValidateChangePackage") {
        $requiredFields += "changePackageId"
    }
    if ($operation -in @("CreateNamedSubprojects", "CloneProjectStructure", "SynchronizeFolderTree", "CreateProjectTemplate", "UploadInitializers", "AddFiles", "AddArchives", "CompareFiles")) {
        $requiredFields += "sourceRoot"
    }
    if ($operation -in @("CreateFolders", "ValidateFolderPaths", "SynchronizeFolderTree")) {
        $requiredFields += "folders"
    }
    if ($operation -in @("AddProjectMembers", "RemoveProjectMembers", "UpdateMemberPermissions", "ChangeUserRoles")) {
        $requiredFields += "members.users"
        $requiredFields += "members.capabilityProfile"
    }

    return [PSCustomObject]@{
        intent = $normalizedIntent
        suggestedOperation = $operation
        confidence = $confidence
        requiredFields = $requiredFields | Select-Object -Unique
        needsClarification = $null -eq $operation
        note = if ($null -eq $operation) {
            "No safe operation was inferred. Clarify the operation and provide project, sandbox, and change-package evidence."
        }
        else {
            "Intent routing is a draft only. Complete the structured request and run DryRun before Preflight or Apply."
        }
    }
}

function Resolve-WindchillSiPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config
    )

    $siPath = Get-WindchillProperty -Object $Request -Name "siPath" -Default ""
    if ([string]::IsNullOrWhiteSpace($siPath)) {
        $rvsConfig = Get-WindchillProperty -Object $Config -Name "rvs" -Default $null
        $siPath = Get-WindchillProperty -Object $rvsConfig -Name "siPath" -Default ""
    }
    if ([string]::IsNullOrWhiteSpace($siPath) -or -not (Test-Path -LiteralPath $siPath -PathType Leaf)) {
        throw "Windchill RV&S client was not found: $siPath"
    }
    return (Resolve-Path -LiteralPath $siPath).ProviderPath
}

function Invoke-WindchillSiQuery {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $startedAtUtc = [DateTime]::UtcNow
    $commandOutput = @(& $Executable @Arguments 2>&1)
    return [PSCustomObject]@{
        executable = $Executable
        arguments = $Arguments
        exitCode = $LASTEXITCODE
        startedAtUtc = $startedAtUtc.ToString("o")
        finishedAtUtc = [DateTime]::UtcNow.ToString("o")
        text = (($commandOutput | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine).TrimEnd()
    }
}

function Invoke-WindchillSiCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments,
        [string]$OutputDirectory
    )

    Write-Verbose ("Running: {0} {1}" -f $Executable, ($Arguments -join " "))
    $result = Invoke-WindchillSiQuery -Executable $Executable -Arguments $Arguments
    if (-not [string]::IsNullOrWhiteSpace($OutputDirectory)) {
        Write-WindchillAuditRecord -OutputDirectory $OutputDirectory -Stage "si-command" -Status $(if ($result.exitCode -eq 0) { "succeeded" } else { "failed" }) -Data $result | Out-Null
    }
    if ($result.exitCode -ne 0) {
        throw "Windchill RV&S command failed with exit code $($result.exitCode): $($Arguments -join ' '). Details: $($result.text)"
    }
    return $result
}

function Get-WindchillSandboxInfo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot
    )

    $query = Invoke-WindchillSiQuery -Executable $Executable -Arguments @("sandboxinfo", "--batch", "--cwd=$SandboxRoot")
    if ($query.exitCode -ne 0) {
        throw "RV&S did not recognize the target as a sandbox. Details: $($query.text)"
    }

    $projectMatch = [regex]::Match($query.text, "(?m)^Project Name:\s*(?<Value>.+)$")
    $configurationMatch = [regex]::Match($query.text, "(?m)^Configuration Path:\s*(?<Value>.+)$")
    return [PSCustomObject]@{
        sandboxRoot = $SandboxRoot
        projectName = if ($projectMatch.Success) { $projectMatch.Groups["Value"].Value.Trim().Replace("\", "/") } else { "" }
        configurationPath = if ($configurationMatch.Success) { $configurationMatch.Groups["Value"].Value.Trim() } else { "" }
        raw = $query
    }
}

function Assert-WindchillSandboxMapping {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$SandboxInfo,
        [Parameter(Mandatory = $true)]
        [object]$Request
    )

    $expectedProject = Get-WindchillProperty -Object $Request -Name "ptcProject" -Default ""
    if (-not [string]::IsNullOrWhiteSpace($expectedProject) -and $SandboxInfo.configurationPath -ne $expectedProject) {
        throw "RV&S sandbox configuration does not match the requested PTC project. Expected: $expectedProject Actual: $($SandboxInfo.configurationPath)"
    }
    if ([string]::IsNullOrWhiteSpace($SandboxInfo.projectName)) {
        throw "RV&S sandbox information did not include a root Project Name."
    }
}

function Get-WindchillChangePackageInfo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot,
        [Parameter(Mandatory = $true)]
        [string]$ChangePackageId
    )

    $query = Invoke-WindchillSiQuery -Executable $Executable -Arguments @(
        "viewcps", "--batch", "--cwd=$SandboxRoot", "--fields=id,state,summary", $ChangePackageId
    )
    if ($query.exitCode -ne 0) {
        throw "Unable to inspect change package '$ChangePackageId'. Details: $($query.text)"
    }

    $lineMatch = [regex]::Match(
        $query.text,
        "(?m)^$([regex]::Escape($ChangePackageId))\s+(?<State>\S+)\s*(?<Summary>.*)$"
    )
    if (-not $lineMatch.Success) {
        throw "Change package '$ChangePackageId' was not returned by RV&S. Details: $($query.text)"
    }

    return [PSCustomObject]@{
        id = $ChangePackageId
        state = $lineMatch.Groups["State"].Value
        summary = $lineMatch.Groups["Summary"].Value.Trim()
        raw = $query
    }
}

function Assert-WindchillChangePackageOpen {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ChangePackageInfo,
        [Parameter(Mandatory = $true)]
        [object]$Config
    )

    $rvsConfig = Get-WindchillProperty -Object $Config -Name "rvs" -Default $null
    $allowedStates = ConvertTo-WindchillArray (Get-WindchillProperty -Object $rvsConfig -Name "requiredChangePackageStates" -Default @("Open"))
    if ($allowedStates -notcontains $ChangePackageInfo.state) {
        throw "Change package '$($ChangePackageInfo.id)' must be in one of these states: $($allowedStates -join ', '). Actual: $($ChangePackageInfo.state)"
    }
}

function Get-WindchillRootProjectPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$SandboxInfo
    )

    if ([string]::IsNullOrWhiteSpace($SandboxInfo.projectName) -or -not $SandboxInfo.projectName.EndsWith(".pj", [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "RV&S root project path is not available: $($SandboxInfo.projectName)"
    }
    return $SandboxInfo.projectName
}

function Test-WindchillPathHasExcludedSegment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath,
        [Parameter(Mandatory = $true)]
        [string[]]$ExcludedDirectoryNames
    )

    foreach ($segment in $RelativePath.Replace("/", "\").Split("\")) {
        if ($ExcludedDirectoryNames -contains $segment) {
            return $true
        }
    }
    return $false
}

function Get-WindchillSourceDirectories {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceRoot,
        [string[]]$ExcludedDirectoryNames = @(),
        [switch]$IncludeExcludedDirectories
    )

    $resolvedSourceRoot = Resolve-WindchillDirectoryPath -Path $SourceRoot -Label "SourceRoot"
    return @(
        Get-ChildItem -LiteralPath $resolvedSourceRoot -Force -Recurse -Directory |
            ForEach-Object {
                $relativePath = Get-WindchillRelativePath -FullPath $_.FullName -RootPath $resolvedSourceRoot
                [PSCustomObject]@{
                    SourcePath = $_.FullName
                    RelativePath = $relativePath
                }
            } |
            Where-Object {
                $IncludeExcludedDirectories -or -not (Test-WindchillPathHasExcludedSegment -RelativePath $_.RelativePath -ExcludedDirectoryNames $ExcludedDirectoryNames)
            } |
            Sort-Object @{ Expression = { $_.RelativePath.Length } }, RelativePath
    )
}

function New-WindchillNamedSubprojectPlan {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$SourceDirectories,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot,
        [Parameter(Mandatory = $true)]
        [string]$RootProjectPath
    )

    $lastSlashIndex = $RootProjectPath.LastIndexOf("/")
    if ($lastSlashIndex -lt 1) {
        throw "Unable to determine the RV&S root project directory from: $RootProjectPath"
    }
    $rootProjectDirectory = $RootProjectPath.Substring(0, $lastSlashIndex)

    return @(
        foreach ($sourceDirectory in $SourceDirectories) {
            $relativePath = $sourceDirectory.RelativePath
            $relativeRvsPath = $relativePath.Replace("\", "/")
            $projectName = Split-Path -Path $relativePath -Leaf
            $parentRelativePath = Split-Path -Path $relativePath -Parent
            $parentProjectPath = if ([string]::IsNullOrWhiteSpace($parentRelativePath)) {
                $RootProjectPath
            }
            else {
                $parentName = Split-Path -Path $parentRelativePath -Leaf
                $parentRvsPath = $parentRelativePath.Replace("\", "/")
                "$rootProjectDirectory/$parentRvsPath/$parentName.pj"
            }

            [PSCustomObject]@{
                RelativePath = $relativePath
                RelativeProjectPath = "$relativeRvsPath/$projectName.pj"
                SandboxPath = Join-Path $SandboxRoot $relativePath
                ParentProjectPath = $parentProjectPath
                ProjectPath = "$rootProjectDirectory/$relativeRvsPath/$projectName.pj"
            }
        }
    )
}

function Get-WindchillProjectTree {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot
    )

    $query = Invoke-WindchillSiQuery -Executable $Executable -Arguments @(
        "viewproject", "--batch", "--recurse", "--fields=indent,name,type,state,pendingcpid", "--cwd=$SandboxRoot"
    )
    if ($query.exitCode -ne 0) {
        throw "Unable to inspect RV&S project hierarchy. Details: $($query.text)"
    }

    $directoriesByDepth = @{}
    $subprojects = @()
    foreach ($line in ($query.text -split [Environment]::NewLine)) {
        $match = [regex]::Match(
            $line,
            "^(?<Indent>\s*)(?<Path>.+?\.pj)\s+subproject\b",
            [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
        )
        if (-not $match.Success) {
            continue
        }

        $indentLength = $match.Groups["Indent"].Value.Length
        $depth = if ($indentLength -eq 0) { 0 } else { [int](($indentLength - 1) / 2) }
        $entryPath = $match.Groups["Path"].Value.Replace("\", "/")
        $fullPath = if ($depth -eq 0) {
            $entryPath
        }
        else {
            if (-not $directoriesByDepth.ContainsKey($depth - 1)) {
                throw "RV&S project hierarchy has no parent for: $line"
            }
            "$($directoriesByDepth[$depth - 1])/$entryPath"
        }

        $lastSlash = $fullPath.LastIndexOf("/")
        if ($lastSlash -lt 1) {
            throw "Unable to determine RV&S subproject directory: $fullPath"
        }
        $directoriesByDepth[$depth] = $fullPath.Substring(0, $lastSlash)
        foreach ($knownDepth in @($directoriesByDepth.Keys)) {
            if ($knownDepth -gt $depth) {
                $directoriesByDepth.Remove($knownDepth)
            }
        }

        $subprojects += [PSCustomObject]@{
            Depth = $depth
            RelativeProjectPath = $fullPath
            Raw = $line
        }
    }

    return [PSCustomObject]@{
        Query = $query
        Subprojects = $subprojects
    }
}

function Get-WindchillProjectMemberNames {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string]$ProjectPath
    )

    $query = Invoke-WindchillSiQuery -Executable $Executable -Arguments @(
        "viewproject", "--batch", "--norecurse", "--fields=name,type,state,pendingcpid", "--project=$ProjectPath"
    )
    if ($query.exitCode -ne 0) {
        throw "Unable to inspect RV&S project '$ProjectPath'. Details: $($query.text)"
    }

    $members = @()
    foreach ($line in ($query.text -split [Environment]::NewLine)) {
        $entry = $line.Trim()
        if ([string]::IsNullOrWhiteSpace($entry) -or $entry -match "\.pj\s+subproject\b") {
            continue
        }
        $memberMatch = [regex]::Match($entry, "^(?<Name>\S+)\s+")
        if ($memberMatch.Success) {
            $members += $memberMatch.Groups["Name"].Value
        }
    }

    return @($members | Sort-Object -Unique)
}

function Get-WindchillFileSelection {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [string]$SourceRoot
    )

    $fileSelection = Get-WindchillProperty -Object $Request -Name "fileSelection" -Default $null
    $mode = Get-WindchillProperty -Object $fileSelection -Name "mode" -Default ""
    if ([string]::IsNullOrWhiteSpace($mode)) {
        $filePolicy = Get-WindchillProperty -Object $Config -Name "filePolicy" -Default $null
        $mode = Get-WindchillProperty -Object $filePolicy -Name "defaultSelection" -Default "initializers-only"
    }
    $mode = $mode.ToLowerInvariant()

    $filePolicy = Get-WindchillProperty -Object $Config -Name "filePolicy" -Default $null
    $executionPolicy = Get-WindchillProperty -Object $Config -Name "execution" -Default $null
    $excludedDirectoryNames = @(
        (ConvertTo-WindchillArray (Get-WindchillProperty -Object $filePolicy -Name "deniedDirectoryNames" -Default @())) +
        (ConvertTo-WindchillArray (Get-WindchillProperty -Object $fileSelection -Name "excludeDirectoryNames" -Default @()))
    ) | Select-Object -Unique
    $excludedExtensions = @(
        (ConvertTo-WindchillArray (Get-WindchillProperty -Object $filePolicy -Name "deniedExtensions" -Default @())) +
        (ConvertTo-WindchillArray (Get-WindchillProperty -Object $fileSelection -Name "excludeExtensions" -Default @()))
    ) | ForEach-Object { $_.ToLowerInvariant() } | Select-Object -Unique

    $candidates = switch ($mode) {
        "initializers-only" {
            @(Get-ChildItem -LiteralPath $SourceRoot -Force -Recurse -File -Filter "__init__.py")
            break
        }
        "explicit-files" {
            # @() keeps a one-path list an array: PowerShell 5.1 strict mode has no .Count on a scalar.
            $explicitRelativePaths = @(ConvertTo-WindchillArray (Get-WindchillProperty -Object $fileSelection -Name "explicitRelativePaths" -Default @()))
            if ($explicitRelativePaths.Count -eq 0) {
                throw "fileSelection.explicitRelativePaths is required for explicit-files mode."
            }
            $files = @()
            foreach ($relativePath in $explicitRelativePaths) {
                Assert-WindchillSafeRelativePath -RelativePath $relativePath -Label "Explicit file path"
                $sourcePath = Join-Path $SourceRoot $relativePath
                if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
                    throw "Explicit source file does not exist: $sourcePath"
                }
                $files += Get-Item -LiteralPath $sourcePath
            }
            $files
            break
        }
        "all-files" {
            $requestAllowsAllFiles = [bool](Get-WindchillProperty -Object $fileSelection -Name "allowAllFiles" -Default $false)
            $configAllowsAllFiles = [bool](Get-WindchillProperty -Object $executionPolicy -Name "allowAllFiles" -Default $false)
            if (-not $requestAllowsAllFiles -or -not $configAllowsAllFiles) {
                throw "All-file upload is blocked. Request fileSelection.allowAllFiles and config execution.allowAllFiles must both be true."
            }
            @(Get-ChildItem -LiteralPath $SourceRoot -Force -Recurse -File)
            break
        }
        default {
            throw "Unsupported file selection mode: $mode"
        }
    }

    $hashAlgorithm = Get-WindchillProperty -Object $filePolicy -Name "hashAlgorithm" -Default "SHA256"
    return @(
        $candidates |
            ForEach-Object {
                $relativePath = Get-WindchillRelativePath -FullPath $_.FullName -RootPath $SourceRoot
                [PSCustomObject]@{
                    SourcePath = $_.FullName
                    RelativePath = $relativePath
                    ParentRelativePath = Split-Path -Path $relativePath -Parent
                    FileName = $_.Name
                    Extension = $_.Extension.ToLowerInvariant()
                    SizeBytes = $_.Length
                    Hash = Get-WindchillFileHash -Path $_.FullName -Algorithm $hashAlgorithm
                }
            } |
            Where-Object {
                -not (Test-WindchillPathHasExcludedSegment -RelativePath $_.RelativePath -ExcludedDirectoryNames $excludedDirectoryNames) -and
                ($excludedExtensions -notcontains $_.Extension)
            } |
            Sort-Object RelativePath
    )
}

function New-WindchillFolderPlan {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot
    )

    $folders = @(ConvertTo-WindchillArray (Get-WindchillProperty -Object $Request -Name "folders" -Default @()))
    if ($folders.Count -eq 0) {
        $templatePath = Get-WindchillProperty -Object $Request -Name "templatePath" -Default ""
        if (-not [string]::IsNullOrWhiteSpace($templatePath)) {
            $template = Read-WindchillJsonFile -Path $templatePath
            foreach ($directory in (ConvertTo-WindchillArray (Get-WindchillProperty -Object $template -Name "directories" -Default @()))) {
                $relativePath = if ($directory -is [string]) {
                    $directory
                }
                else {
                    Get-WindchillProperty -Object $directory -Name "RelativePath" -Default ""
                }
                if ([string]::IsNullOrWhiteSpace($relativePath)) {
                    throw "Project template contains a directory without RelativePath: $templatePath"
                }
                $folders += $relativePath
            }
        }
    }

    if ($folders.Count -eq 0) {
        throw "At least one folder or templatePath is required for this operation."
    }

    return @(
        foreach ($folder in $folders) {
            Assert-WindchillSafeRelativePath -RelativePath $folder -Label "Folder path"
            [PSCustomObject]@{
                RelativePath = $folder
                SandboxPath = Join-Path $SandboxRoot $folder
            }
        }
    )
}

function New-WindchillAutomationPlan {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config
    )

    $operation = Get-WindchillProperty -Object $Request -Name "operation" -Default ""
    if ($script:WindchillPtcSupportedOperations -notcontains $operation) {
        throw "Unsupported Windchill operation: $operation"
    }

    $needsSourceRoot = $operation -in @(
        "CreateNamedSubprojects", "CloneProjectStructure", "SynchronizeFolderTree", "CreateProjectTemplate", "UploadInitializers", "AddFiles", "AddArchives", "CompareFiles"
    )
    $needsSandboxRoot = $operation -ne "CreateProjectTemplate"
    $mutates = $script:WindchillPtcMutatingOperations -contains $operation
    $sourceRoot = ""
    if ($needsSourceRoot) {
        $sourceRoot = Resolve-WindchillDirectoryPath -Path (Get-WindchillProperty -Object $Request -Name "sourceRoot" -Default "") -Label "SourceRoot"
    }

    $sandboxRoot = ""
    if ($needsSandboxRoot) {
        $allowMissingSandbox = $operation -eq "CreateSandbox"
        $sandboxRoot = Resolve-WindchillDirectoryPath -Path (Get-WindchillProperty -Object $Request -Name "sandboxRoot" -Default "") -Label "SandboxRoot" -AllowMissing:$allowMissingSandbox
    }

    $filePolicy = Get-WindchillProperty -Object $Config -Name "filePolicy" -Default $null
    $excludedDirectories = ConvertTo-WindchillArray (Get-WindchillProperty -Object $filePolicy -Name "deniedDirectoryNames" -Default @())
    $subprojectOptions = Get-WindchillProperty -Object $Request -Name "subprojects" -Default $null
    $includeExcludedDirectories = [bool](Get-WindchillProperty -Object $subprojectOptions -Name "includeExcludedDirectories" -Default $false)
    $sourceDirectories = @(
        if ($needsSourceRoot) {
            Get-WindchillSourceDirectories -SourceRoot $sourceRoot -ExcludedDirectoryNames $excludedDirectories -IncludeExcludedDirectories:$includeExcludedDirectories
        }
    )

    $folderPlan = @(
        if ($operation -in @("CreateFolders", "ValidateFolderPaths", "SynchronizeFolderTree")) {
            if ($operation -eq "SynchronizeFolderTree" -and $sourceDirectories.Count -gt 0) {
                $sourceDirectories | ForEach-Object { [PSCustomObject]@{ RelativePath = $_.RelativePath; SandboxPath = Join-Path $sandboxRoot $_.RelativePath } }
            }
            else {
                New-WindchillFolderPlan -Request $Request -SandboxRoot $sandboxRoot
            }
        }
    )

    $filePlan = @(
        if ($operation -in @("UploadInitializers", "AddFiles", "AddArchives", "CompareFiles")) {
            Get-WindchillFileSelection -Request $Request -Config $Config -SourceRoot $sourceRoot
        }
    )

    if ($operation -eq "AddArchives") {
        $fileSelection = Get-WindchillProperty -Object $Request -Name "fileSelection" -Default $null
        $selectionMode = Get-WindchillProperty -Object $fileSelection -Name "mode" -Default ""
        if ($selectionMode -ne "explicit-files") {
            throw "AddArchives requires fileSelection.mode to be explicit-files."
        }
    }

    return [PSCustomObject]@{
        operation = $operation
        mutates = $mutates
        sourceRoot = $sourceRoot
        sandboxRoot = $sandboxRoot
        ptcProject = Get-WindchillProperty -Object $Request -Name "ptcProject" -Default ""
        changePackageId = Get-WindchillProperty -Object $Request -Name "changePackageId" -Default ""
        description = Get-WindchillProperty -Object $Request -Name "description" -Default ""
        sourceDirectories = $sourceDirectories
        folderPlan = $folderPlan
        filePlan = $filePlan
        subprojectOptions = $subprojectOptions
        requestHash = Get-WindchillObjectHash -Value $Request
        counts = [PSCustomObject]@{
            sourceDirectories = $sourceDirectories.Count
            folders = $folderPlan.Count
            files = $filePlan.Count
            nonInitializerFiles = @($filePlan | Where-Object { $_.FileName -ne "__init__.py" }).Count
        }
    }
}

function Get-WindchillExistingMemberRelativePaths {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FilePlan,
        [Parameter(Mandatory = $true)]
        [string]$Executable
    )

    $filesByProject = @{}
    foreach ($file in $FilePlan) {
        if (-not $filesByProject.ContainsKey($file.ProjectPath)) {
            $filesByProject[$file.ProjectPath] = @()
        }
        $filesByProject[$file.ProjectPath] += $file
    }

    $existingRelativePaths = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($projectPath in $filesByProject.Keys) {
        $memberNames = Get-WindchillProjectMemberNames -Executable $Executable -ProjectPath $projectPath
        foreach ($file in $filesByProject[$projectPath]) {
            if ($memberNames -contains $file.FileName) {
                [void]$existingRelativePaths.Add($file.RelativePath)
            }
        }
    }
    return $existingRelativePaths
}

function Resolve-WindchillFileTargets {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FilePlan,
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$SubprojectPlan,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot,
        [Parameter(Mandatory = $true)]
        [string]$RootProjectPath
    )

    $subprojectsByRelativePath = @{}
    foreach ($subproject in $SubprojectPlan) {
        $subprojectsByRelativePath[$subproject.RelativePath] = $subproject
    }

    return @(
        foreach ($file in $FilePlan) {
            $parentRelativePath = $file.ParentRelativePath
            $targetDirectory = $SandboxRoot
            $projectPath = $RootProjectPath
            if (-not [string]::IsNullOrWhiteSpace($parentRelativePath)) {
                if (-not $subprojectsByRelativePath.ContainsKey($parentRelativePath)) {
                    throw "No named subproject was planned for selected file: $($file.RelativePath)"
                }
                $subproject = $subprojectsByRelativePath[$parentRelativePath]
                $targetDirectory = $subproject.SandboxPath
                $projectPath = $subproject.ProjectPath
            }

            [PSCustomObject]@{
                SourcePath = $file.SourcePath
                RelativePath = $file.RelativePath
                FileName = $file.FileName
                SizeBytes = $file.SizeBytes
                Hash = $file.Hash
                SandboxPath = Join-Path $SandboxRoot $file.RelativePath
                SandboxDirectory = $targetDirectory
                ProjectPath = $projectPath
            }
        }
    )
}

function Test-WindchillCapabilityProfile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config
    )

    $members = Get-WindchillProperty -Object $Request -Name "members" -Default $null
    $capabilityProfile = Get-WindchillProperty -Object $members -Name "capabilityProfile" -Default "memberAdministration"
    $capabilities = Get-WindchillProperty -Object $Config -Name "capabilities" -Default $null
    $profile = Get-WindchillProperty -Object $capabilities -Name $capabilityProfile -Default $null
    if ($null -eq $profile) {
        return [PSCustomObject]@{ available = $false; profile = $capabilityProfile; reason = "Capability profile is not configured." }
    }

    $enabled = [bool](Get-WindchillProperty -Object $profile -Name "enabled" -Default $false)
    $verified = [bool](Get-WindchillProperty -Object $profile -Name "verified" -Default $false)
    $commandPath = Get-WindchillProperty -Object $profile -Name "commandPath" -Default ""
    $argumentsTemplate = ConvertTo-WindchillArray (Get-WindchillProperty -Object $profile -Name "argumentsTemplate" -Default @("--request", "{{requestPath}}"))
    $accessValidationRequired = [bool](Get-WindchillProperty -Object $profile -Name "accessValidationRequired" -Default $true)
    $accessValidationCommandPath = Get-WindchillProperty -Object $profile -Name "accessValidationCommandPath" -Default ""
    $accessValidationArgumentsTemplate = ConvertTo-WindchillArray (Get-WindchillProperty -Object $profile -Name "accessValidationArgumentsTemplate" -Default @("--validate-access", "--request", "{{requestPath}}"))
    $permissionEvidence = Get-WindchillProperty -Object $profile -Name "requiredPermissionEvidence" -Default ""
    $accessValidationAvailable = -not $accessValidationRequired -or (
        -not [string]::IsNullOrWhiteSpace($accessValidationCommandPath) -and
        (Test-Path -LiteralPath $accessValidationCommandPath -PathType Leaf)
    )
    $available = $enabled -and $verified -and -not [string]::IsNullOrWhiteSpace($commandPath) -and (Test-Path -LiteralPath $commandPath -PathType Leaf) -and $accessValidationAvailable
    return [PSCustomObject]@{
        available = $available
        profile = $capabilityProfile
        commandPath = $commandPath
        argumentsTemplate = $argumentsTemplate
        accessValidationRequired = $accessValidationRequired
        accessValidationAvailable = $accessValidationAvailable
        accessValidationCommandPath = $accessValidationCommandPath
        accessValidationArgumentsTemplate = $accessValidationArgumentsTemplate
        requiredPermissionEvidence = $permissionEvidence
        reason = if ($available) { "Verified capability profile and access-validation command are available." } else { "Member, role, and permission changes require an enabled, verified organization-specific capability profile with an access-validation command." }
    }
}

function Resolve-WindchillProfileArguments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Template,
        [Parameter(Mandatory = $true)]
        [string]$RequestPath
    )

    if ($Template.Count -eq 0) {
        throw "Capability profile argument template must not be empty."
    }

    return @(
        foreach ($argument in $Template) {
            $argument.Replace("{{requestPath}}", $RequestPath)
        }
    )
}

function Invoke-WindchillMemberAccessValidation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Capability,
        [Parameter(Mandatory = $true)]
        [string]$RequestPath,
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory
    )

    if (-not $Capability.accessValidationRequired) {
        return [PSCustomObject]@{ validated = $false; skipped = $true; reason = "Access validation is disabled by the approved capability profile." }
    }
    if (-not $Capability.accessValidationAvailable) {
        throw "Member access validation cannot run because the approved capability profile has no executable validation command."
    }

    $arguments = Resolve-WindchillProfileArguments -Template $Capability.accessValidationArgumentsTemplate -RequestPath $RequestPath
    $result = Invoke-WindchillSiCommand -Executable $Capability.accessValidationCommandPath -Arguments $arguments -OutputDirectory $OutputDirectory
    return [PSCustomObject]@{ validated = $true; skipped = $false; result = $result }
}

function Invoke-WindchillPreflight {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Plan,
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [string]$OutputDirectory
    )

    $results = [ordered]@{
        passed = $true
        validations = @()
        sandbox = $null
        changePackage = $null
        projectTree = $null
        existingSubprojectPaths = @()
        missingSubprojectPaths = @()
        unexpectedSubprojectPaths = @()
        existingFiles = @()
        fileTargets = @()
        capability = $null
        missingFolderPaths = @()
    }

    $requiresRvs = $Plan.operation -ne "CreateProjectTemplate"
    $siPath = ""
    if ($requiresRvs) {
        $siPath = Resolve-WindchillSiPath -Request $Request -Config $Config
        $results.validations += [PSCustomObject]@{ name = "RV&S client"; passed = $true; detail = $siPath }
    }

    if ($Plan.operation -eq "CreateProjectTemplate") {
        $results.validations += [PSCustomObject]@{ name = "Local source structure"; passed = $true; detail = $Plan.sourceRoot }
    }
    elseif ($Plan.operation -eq "CreateSandbox") {
        $sandboxParent = Split-Path -Parent $Plan.sandboxRoot
        if (-not (Test-Path -LiteralPath $sandboxParent -PathType Container)) {
            throw "Sandbox parent does not exist: $sandboxParent"
        }
        if (Test-Path -LiteralPath $Plan.sandboxRoot) {
            throw "Sandbox root already exists. CreateSandbox requires a missing target: $($Plan.sandboxRoot)"
        }
        $results.validations += [PSCustomObject]@{ name = "Sandbox creation target"; passed = $true; detail = $Plan.sandboxRoot }
    }
    else {
        $sandbox = Get-WindchillSandboxInfo -Executable $siPath -SandboxRoot $Plan.sandboxRoot
        Assert-WindchillSandboxMapping -SandboxInfo $sandbox -Request $Request
        $results.sandbox = $sandbox
        $results.validations += [PSCustomObject]@{ name = "Sandbox mapping"; passed = $true; detail = $sandbox.configurationPath }
    }

    $rvsConfig = Get-WindchillProperty -Object $Config -Name "rvs" -Default $null
    $requiresChangePackage = $Plan.mutates -and [bool](Get-WindchillProperty -Object $rvsConfig -Name "requireChangePackageForMutations" -Default $true)
    if ($requiresChangePackage) {
        if ([string]::IsNullOrWhiteSpace($Plan.changePackageId)) {
            throw "ChangePackageId is required for operation '$($Plan.operation)'."
        }
        if ($Plan.operation -eq "CreateSandbox") {
            $results.validations += [PSCustomObject]@{ name = "Change package"; passed = $false; detail = "Sandbox creation requires a server-specific CP policy check after sandbox creation." }
        }
        else {
            $changePackage = Get-WindchillChangePackageInfo -Executable $siPath -SandboxRoot $Plan.sandboxRoot -ChangePackageId $Plan.changePackageId
            Assert-WindchillChangePackageOpen -ChangePackageInfo $changePackage -Config $Config
            $results.changePackage = $changePackage
            $results.validations += [PSCustomObject]@{ name = "Change package"; passed = $true; detail = "$($changePackage.id) $($changePackage.state)" }
        }
    }

    if ($Plan.operation -eq "ValidateFolderPaths") {
        $missingFolderPaths = @(
            $Plan.folderPlan |
                Where-Object { -not (Test-Path -LiteralPath $_.SandboxPath -PathType Container) } |
                Select-Object -ExpandProperty RelativePath
        )
        $results.missingFolderPaths = $missingFolderPaths
        $results.validations += [PSCustomObject]@{
            name = "Folder paths"
            passed = $missingFolderPaths.Count -eq 0
            detail = "Requested: $($Plan.folderPlan.Count); missing: $($missingFolderPaths.Count)"
        }
    }

    if ($null -ne $results.sandbox -and $Plan.sourceDirectories.Count -gt 0) {
        $rootProjectPath = Get-WindchillRootProjectPath -SandboxInfo $results.sandbox
        $subprojectPlan = New-WindchillNamedSubprojectPlan -SourceDirectories $Plan.sourceDirectories -SandboxRoot $Plan.sandboxRoot -RootProjectPath $rootProjectPath
        $projectTree = Get-WindchillProjectTree -Executable $siPath -SandboxRoot $Plan.sandboxRoot
        $existingSubprojectPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($subproject in $projectTree.Subprojects) {
            [void]$existingSubprojectPaths.Add($subproject.RelativeProjectPath)
        }
        $expectedSubprojectPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($subproject in $subprojectPlan) {
            [void]$expectedSubprojectPaths.Add($subproject.RelativeProjectPath)
        }
        $missingSubprojectPaths = @($expectedSubprojectPaths | Where-Object { -not $existingSubprojectPaths.Contains($_) } | Sort-Object)
        $unexpectedSubprojectPaths = @($existingSubprojectPaths | Where-Object { -not $expectedSubprojectPaths.Contains($_) } | Sort-Object)

        $results.projectTree = $projectTree
        $results.existingSubprojectPaths = @($existingSubprojectPaths | Sort-Object)
        $results.missingSubprojectPaths = $missingSubprojectPaths
        $results.unexpectedSubprojectPaths = $unexpectedSubprojectPaths
        $results.subprojectPlan = $subprojectPlan
        $results.validations += [PSCustomObject]@{
            name = "Named subproject hierarchy"
            passed = $unexpectedSubprojectPaths.Count -eq 0
            detail = "Existing: $($existingSubprojectPaths.Count); missing: $($missingSubprojectPaths.Count); unexpected: $($unexpectedSubprojectPaths.Count)"
        }

        if ($Plan.filePlan.Count -gt 0) {
            $fileTargets = Resolve-WindchillFileTargets -FilePlan $Plan.filePlan -SubprojectPlan $subprojectPlan -SandboxRoot $Plan.sandboxRoot -RootProjectPath $rootProjectPath
            $results.fileTargets = $fileTargets
            if ($missingSubprojectPaths.Count -eq 0) {
                $existingFiles = Get-WindchillExistingMemberRelativePaths -FilePlan $fileTargets -Executable $siPath
                $results.existingFiles = @($existingFiles | Sort-Object)
            }
            $results.validations += [PSCustomObject]@{
                name = "File selection"
                passed = $Plan.counts.nonInitializerFiles -eq 0 -or $Plan.operation -in @("AddFiles", "AddArchives")
                detail = "Selected: $($Plan.filePlan.Count); non-initializers: $($Plan.counts.nonInitializerFiles); existing target members: $($results.existingFiles.Count)"
            }
        }
    }

    if ($Plan.operation -in @("AddProjectMembers", "RemoveProjectMembers", "UpdateMemberPermissions", "ChangeUserRoles")) {
        $capability = Test-WindchillCapabilityProfile -Request $Request -Config $Config
        $results.capability = $capability
        if (-not $capability.available) {
            throw "$($capability.reason) Profile: $($capability.profile)"
        }
        if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
            throw "Member access validation requires an audit output directory."
        }
        $requestCopyPath = Join-Path $OutputDirectory "member-access-request.json"
        Write-WindchillJsonFile -Path $requestCopyPath -Value $Request | Out-Null
        $accessValidation = Invoke-WindchillMemberAccessValidation -Capability $capability -RequestPath $requestCopyPath -OutputDirectory $OutputDirectory
        $results.validations += [PSCustomObject]@{ name = "Member administration capability"; passed = $true; detail = $capability.profile }
        $results.validations += [PSCustomObject]@{ name = "Member access validation"; passed = $accessValidation.validated; detail = $accessValidation }
    }

    if ($null -ne $OutputDirectory) {
        Write-WindchillAuditRecord -OutputDirectory $OutputDirectory -Stage "preflight" -Status "passed" -Data ([PSCustomObject]$results) | Out-Null
    }
    return [PSCustomObject]$results
}

function Assert-WindchillApplyAuthorization {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Request,
        [Parameter(Mandatory = $true)]
        [object]$Config,
        [Parameter(Mandatory = $true)]
        [bool]$Approve
    )

    $execution = Get-WindchillProperty -Object $Config -Name "execution" -Default $null
    $requiresApproval = [bool](Get-WindchillProperty -Object $execution -Name "requireExplicitApplyApproval" -Default $true)
    if (-not $requiresApproval) {
        return
    }

    $approval = Get-WindchillProperty -Object $Request -Name "approval" -Default $null
    $approvedInRequest = [bool](Get-WindchillProperty -Object $approval -Name "approved" -Default $false)
    $approvedBy = Get-WindchillProperty -Object $approval -Name "approvedBy" -Default ""
    if (-not $Approve -or -not $approvedInRequest -or [string]::IsNullOrWhiteSpace($approvedBy)) {
        throw "Apply requires -Approve plus request.approval.approved=true and request.approval.approvedBy."
    }
}

function Invoke-WindchillCreateFolders {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FolderPlan,
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory
    )

    $created = @()
    foreach ($folder in $FolderPlan) {
        if (-not (Test-Path -LiteralPath $folder.SandboxPath -PathType Container)) {
            New-Item -ItemType Directory -Path $folder.SandboxPath -Force -ErrorAction Stop | Out-Null
            $created += $folder.SandboxPath
            Write-WindchillAuditRecord -OutputDirectory $OutputDirectory -Stage "folder" -Status "created" -Data $folder | Out-Null
        }
    }
    return $created
}

function Invoke-WindchillCreateNamedSubprojects {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$SubprojectPlan,
        [Parameter(Mandatory = $true)]
        [string[]]$ExistingRelativeProjectPaths,
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot,
        [Parameter(Mandatory = $true)]
        [string]$ChangePackageId,
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory
    )

    $existing = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($relativeProjectPath in $ExistingRelativeProjectPaths) {
        [void]$existing.Add($relativeProjectPath)
    }
    $toCreate = @($SubprojectPlan | Where-Object { -not $existing.Contains($_.RelativeProjectPath) })

    foreach ($subproject in $toCreate) {
        if (-not (Test-Path -LiteralPath $subproject.SandboxPath -PathType Container)) {
            New-Item -ItemType Directory -Path $subproject.SandboxPath -Force -ErrorAction Stop | Out-Null
        }
    }

    foreach ($subproject in $toCreate) {
        Invoke-WindchillSiCommand -Executable $Executable -Arguments @(
            "createsubproject",
            "--project=$($subproject.ParentProjectPath)",
            "--changePackageId=$ChangePackageId",
            "--nocloseCP",
            "--nocreateSubprojects",
            "--failOnAmbiguousProject",
            "--batch",
            "--yes",
            "--cwd=$SandboxRoot",
            $subproject.ProjectPath
        ) -OutputDirectory $OutputDirectory | Out-Null
    }

    return $toCreate
}

function Invoke-WindchillStageFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FileTargets,
        [Parameter(Mandatory = $true)]
        [string]$HashAlgorithm,
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory
    )

    $staged = @()
    foreach ($file in $FileTargets) {
        if (-not (Test-Path -LiteralPath $file.SandboxDirectory -PathType Container)) {
            New-Item -ItemType Directory -Path $file.SandboxDirectory -Force -ErrorAction Stop | Out-Null
        }
        if (Test-Path -LiteralPath $file.SandboxPath -PathType Leaf) {
            if (-not (Test-WindchillFileContentEqual -FirstPath $file.SourcePath -SecondPath $file.SandboxPath -Algorithm $HashAlgorithm)) {
                throw "Sandbox file differs from source and will not be overwritten: $($file.RelativePath)"
            }
        }
        else {
            Copy-Item -LiteralPath $file.SourcePath -Destination $file.SandboxPath -ErrorAction Stop
            $staged += $file.RelativePath
            Write-WindchillAuditRecord -OutputDirectory $OutputDirectory -Stage "stage-file" -Status "copied" -Data $file | Out-Null
        }
    }
    return $staged
}

function Invoke-WindchillAddFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FileTargets,
        [Parameter(Mandatory = $true)]
        [string[]]$ExistingRelativePaths,
        [Parameter(Mandatory = $true)]
        [string]$Executable,
        [Parameter(Mandatory = $true)]
        [string]$ChangePackageId,
        [Parameter(Mandatory = $true)]
        [string]$Description,
        [Parameter(Mandatory = $true)]
        [string]$ArchiveConflictPolicy,
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory
    )

    $existing = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($relativePath in $ExistingRelativePaths) {
        [void]$existing.Add($relativePath)
    }
    $toAdd = @($FileTargets | Where-Object { -not $existing.Contains($_.RelativePath) })

    foreach ($file in $toAdd) {
        Invoke-WindchillSiCommand -Executable $Executable -Arguments @(
            "add",
            "--changePackageId=$ChangePackageId",
            "--nocloseCP",
            "--nocreateSubprojects",
            "--nocreateSubprojectsForEmptyDirectories",
            "--failOnAmbiguousProject",
            "--onExistingArchive=$ArchiveConflictPolicy",
            "--onExistingOutOfTreeArchive=$ArchiveConflictPolicy",
            "--description=$Description",
            "--batch",
            "--yes",
            "--cwd=$($file.SandboxDirectory)",
            $file.FileName
        ) -OutputDirectory $OutputDirectory | Out-Null
    }

    return $toAdd
}

function Compare-WindchillFileTrees {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FileTargets,
        [string]$HashAlgorithm = "SHA256"
    )

    $comparisons = @()
    foreach ($file in $FileTargets) {
        $status = "missing"
        $sandboxHash = ""
        if (Test-Path -LiteralPath $file.SandboxPath -PathType Leaf) {
            $sandboxHash = Get-WindchillFileHash -Path $file.SandboxPath -Algorithm $HashAlgorithm
            $status = if ($sandboxHash -eq $file.Hash) { "equal" } else { "different" }
        }
        $comparisons += [PSCustomObject]@{
            RelativePath = $file.RelativePath
            SourceHash = $file.Hash
            SandboxHash = $sandboxHash
            Status = $status
        }
    }
    return $comparisons
}

function Get-WindchillUnexpectedSandboxFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [psobject[]]$FileTargets,
        [Parameter(Mandatory = $true)]
        [string]$SandboxRoot
    )

    $expectedPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($file in $FileTargets) {
        [void]$expectedPaths.Add($file.SandboxPath)
    }

    return @(
        Get-ChildItem -LiteralPath $SandboxRoot -Force -Recurse -File |
            Where-Object { -not $expectedPaths.Contains($_.FullName) } |
            ForEach-Object { Get-WindchillRelativePath -FullPath $_.FullName -RootPath $SandboxRoot } |
            Sort-Object
    )
}

function New-WindchillRollbackGuidance {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Plan,
        [Parameter(Mandatory = $true)]
        [object]$Preflight
    )

    $lines = @(
        "# Rollback Guidance",
        "",
        "Operation: $($Plan.operation)",
        "Change package: $($Plan.changePackageId)",
        "",
        "Do not run destructive rollback automatically. Review the current change package and project history first."
    )
    if ($Plan.operation -in @("CreateNamedSubprojects", "CloneProjectStructure", "UploadInitializers", "AddFiles")) {
        $lines += "Review created named project paths and added members, then use the approved RV&S drop workflow associated with the same change package."
    }
    if ($Plan.operation -in @("AddProjectMembers", "RemoveProjectMembers", "UpdateMemberPermissions", "ChangeUserRoles")) {
        $lines += "Restore the recorded prior member/role/permission state using the approved organization-specific administration profile."
    }
    return ($lines -join [Environment]::NewLine)
}

function Invoke-WindchillMemberCapability {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Capability,
        [Parameter(Mandatory = $true)]
        [string]$RequestPath,
        [Parameter(Mandatory = $true)]
        [string]$OutputDirectory
    )

    if (-not $Capability.available) {
        throw "Member administration capability is unavailable: $($Capability.reason)"
    }

    $arguments = Resolve-WindchillProfileArguments -Template $Capability.argumentsTemplate -RequestPath $RequestPath
    Invoke-WindchillSiCommand -Executable $Capability.commandPath -Arguments $arguments -OutputDirectory $OutputDirectory | Out-Null
}

Export-ModuleMember -Function @(
    "Get-WindchillProperty",
    "ConvertTo-WindchillArray",
    "Resolve-WindchillDirectoryPath",
    "Get-WindchillRelativePath",
    "Assert-WindchillSafeRelativePath",
    "Get-WindchillFileHash",
    "Test-WindchillFileContentEqual",
    "Read-WindchillJsonFile",
    "Write-WindchillJsonFile",
    "Get-WindchillObjectHash",
    "New-WindchillOutputDirectory",
    "Write-WindchillAuditRecord",
    "Get-WindchillConfig",
    "ConvertTo-WindchillIntentDraft",
    "Resolve-WindchillSiPath",
    "Invoke-WindchillSiQuery",
    "Invoke-WindchillSiCommand",
    "Get-WindchillSandboxInfo",
    "Assert-WindchillSandboxMapping",
    "Get-WindchillChangePackageInfo",
    "Assert-WindchillChangePackageOpen",
    "Get-WindchillRootProjectPath",
    "Get-WindchillSourceDirectories",
    "New-WindchillNamedSubprojectPlan",
    "Get-WindchillProjectTree",
    "Get-WindchillProjectMemberNames",
    "Get-WindchillFileSelection",
    "New-WindchillFolderPlan",
    "New-WindchillAutomationPlan",
    "Resolve-WindchillFileTargets",
    "Get-WindchillExistingMemberRelativePaths",
    "Test-WindchillCapabilityProfile",
    "Resolve-WindchillProfileArguments",
    "Invoke-WindchillMemberAccessValidation",
    "Invoke-WindchillPreflight",
    "Assert-WindchillApplyAuthorization",
    "Invoke-WindchillCreateFolders",
    "Invoke-WindchillCreateNamedSubprojects",
    "Invoke-WindchillStageFiles",
    "Invoke-WindchillAddFiles",
    "Compare-WindchillFileTrees",
    "Get-WindchillUnexpectedSandboxFiles",
    "New-WindchillRollbackGuidance",
    "Invoke-WindchillMemberCapability"
)
