"""Standalone Codebeamer REST API v3 transport for the code-beamer skill."""

from __future__ import annotations

import ssl
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol
from urllib.parse import urlsplit, urlunsplit

import requests
from dotenv import dotenv_values
from requests.adapters import HTTPAdapter
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry

DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_PAGE_SIZE = 100
DEFAULT_ENV_FILE = Path(__file__).resolve().parents[1] / ".env"
_RETRY_STATUS_CODES = (429, 500, 502, 503, 504)
_REDACTED_VALUE = "[REDACTED]"


class _HttpSession(Protocol):
    """Minimal requests-session interface used by the standalone client."""

    auth: Any
    headers: Any

    def request(self, method: str, url: str, **kwargs: Any) -> Any:
        """Send one request and return a response-like object."""

    def close(self) -> None:
        """Release session resources."""


class CodebeamerError(RuntimeError):
    """Base class for safe-to-display Codebeamer errors."""


class CodebeamerConfigurationError(CodebeamerError):
    """Raised when local Codebeamer configuration is invalid."""


class CodebeamerConnectionError(CodebeamerError):
    """Raised when the Codebeamer service cannot be reached."""


class CodebeamerConflictError(CodebeamerError):
    """Raised when Codebeamer rejects a stale or conflicting mutation."""


class CodebeamerAuthenticationError(CodebeamerError):
    """Raised when Codebeamer rejects the configured credentials."""


class CodebeamerAuthorizationError(CodebeamerError):
    """Raised when the authenticated account cannot access a resource."""


class CodebeamerResponseError(CodebeamerError):
    """Raised when Codebeamer returns an unexpected response shape."""


class CodebeamerScopeError(CodebeamerError):
    """Raised when a caller supplies an invalid or unsafe resource scope."""


class _SystemTrustAdapter(HTTPAdapter):
    """Use the operating system trust store without disabling TLS validation."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._ssl_context = ssl.create_default_context()
        super().__init__(*args, **kwargs)

    def init_poolmanager(
        self,
        connections: int,
        maxsize: int,
        block: bool = False,
        **pool_kwargs: Any,
    ) -> None:
        pool_kwargs["ssl_context"] = self._ssl_context
        super().init_poolmanager(connections, maxsize, block, **pool_kwargs)

    def proxy_manager_for(self, proxy: str, **proxy_kwargs: Any) -> Any:
        proxy_kwargs["ssl_context"] = self._ssl_context
        return super().proxy_manager_for(proxy, **proxy_kwargs)


@dataclass(frozen=True)
class CodebeamerConfig:
    """Connection settings held in memory for one client instance only."""

    base_url: str
    username: str = field(repr=False)
    password: str = field(repr=False)
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS

    @classmethod
    def from_dotenv(
        cls,
        dotenv_path: str | Path | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> "CodebeamerConfig":
        """Read Codebeamer credentials only from the standalone skill dotenv file."""
        env_path = Path(dotenv_path) if dotenv_path is not None else DEFAULT_ENV_FILE
        if not env_path.is_file():
            raise CodebeamerConfigurationError(
                "Codebeamer .env file is missing from the configured location."
            )
        values = dotenv_values(env_path)
        required_keys = (
            "CODEBEAMER_URL",
            "CODEBEAMER_USERNAME",
            "CODEBEAMER_PASSWORD",
        )
        missing_keys = [
            key for key in required_keys if not str(values.get(key) or "").strip()
        ]
        if missing_keys:
            raise CodebeamerConfigurationError(
                "Required Codebeamer environment variables are missing: "
                + ", ".join(missing_keys)
            )
        return cls(
            base_url=_normalize_base_url(str(values["CODEBEAMER_URL"])),
            username=str(values["CODEBEAMER_USERNAME"]),
            password=str(values["CODEBEAMER_PASSWORD"]),
            timeout_seconds=_validate_timeout(timeout_seconds),
        )

    @property
    def api_base_url(self) -> str:
        """Return the REST API v3 root for the configured Codebeamer server."""
        if self.base_url.lower().endswith("/api/v3"):
            return self.base_url
        return f"{self.base_url}/api/v3"


@dataclass(frozen=True, repr=False)
class _SecretRedactor:
    """Masks configured credential values before any output is displayed or saved."""

    values: tuple[str, ...] = field(repr=False)

    def redact(self, value: object) -> str:
        """Return display-safe text with configured credentials masked."""
        redacted = str(value)
        for secret in sorted(
            (item for item in self.values if item), key=len, reverse=True
        ):
            redacted = redacted.replace(secret, _REDACTED_VALUE)
        return redacted

    def contains(self, value: object) -> bool:
        """Return whether text contains a configured credential value."""
        value_text = str(value)
        return any(secret in value_text for secret in self.values if secret)


class CodebeamerClient:
    """Standalone REST client for read operations and approval-gated mutations."""

    def __init__(
        self,
        config: CodebeamerConfig,
        session: _HttpSession | None = None,
    ) -> None:
        self._config = config
        self._redactor = _SecretRedactor((config.username, config.password))
        self._session = session or self._new_session()
        self._session.auth = HTTPBasicAuth(config.username, config.password)
        self._session.headers.update(
            {
                "Accept": "application/json",
                "User-Agent": "Framework-IOEM-Codebeamer-Skill/1.0",
            }
        )

    @property
    def api_base_url(self) -> str:
        """Return the credential-free API root used by this client."""
        return self._config.api_base_url

    @classmethod
    def from_dotenv(
        cls,
        dotenv_path: str | Path | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> "CodebeamerClient":
        """Build a client from the standalone skill dotenv configuration."""
        return cls(
            CodebeamerConfig.from_dotenv(
                dotenv_path=dotenv_path,
                timeout_seconds=timeout_seconds,
            )
        )

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    def redact(self, value: object) -> str:
        """Mask configured credentials before displaying a value."""
        return self._redactor.redact(value)

    def contains_configured_credential(self, value: object) -> bool:
        """Detect configured credentials before persisting a mutation plan."""
        return self._redactor.contains(value)

    def validate_connection(self) -> None:
        """Confirm authenticated REST access with a harmless project-list request."""
        self.list_projects()

    def list_projects(self) -> list[dict[str, Any]]:
        """Return projects visible to the configured account."""
        return _extract_collection(self._get_json("projects"), ("projects", "items"))

    def get_project(self, project_id: int | str) -> dict[str, Any]:
        """Return one project after validating its identifier."""
        project_identifier = _normalize_identifier(project_id, "project")
        return self._get_mapping_json(f"projects/{project_identifier}", "project")

    def list_project_trackers(self, project_id: int | str) -> list[dict[str, Any]]:
        """Return tracker metadata for one project."""
        project_identifier = _normalize_identifier(project_id, "project")
        return _extract_collection(
            self._get_json(f"projects/{project_identifier}/trackers"),
            ("trackers", "items"),
        )

    def get_tracker(self, tracker_id: int | str) -> dict[str, Any]:
        """Return one tracker after validating its identifier."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        return self._get_mapping_json(f"trackers/{tracker_identifier}", "tracker")

    def get_tracker_schema(self, tracker_id: int | str) -> Any:
        """Return the server-provided schema for one tracker."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        return self._get_json(f"trackers/{tracker_identifier}/schema")

    def get_tracker_fields(self, tracker_id: int | str) -> list[dict[str, Any]]:
        """Return configured fields for one tracker."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        return _extract_collection(
            self._get_json(f"trackers/{tracker_identifier}/fields"),
            ("fields", "items"),
        )

    def get_item(self, item_id: int | str) -> dict[str, Any]:
        """Return one requirement, test case, task, or other tracker item."""
        item_identifier = _normalize_identifier(item_id, "item")
        return self._get_mapping_json(f"items/{item_identifier}", "item")

    def get_item_fields(self, item_id: int | str) -> Any:
        """Return editable and read-only field metadata for one item."""
        item_identifier = _normalize_identifier(item_id, "item")
        return self._get_json(f"items/{item_identifier}/fields")

    def get_item_history(self, item_id: int | str) -> Any:
        """Return the server-provided history for one item."""
        item_identifier = _normalize_identifier(item_id, "item")
        return self._get_json(f"items/{item_identifier}/history")

    def get_item_relations(self, item_id: int | str) -> list[dict[str, Any]]:
        """Return explicit relations for one item."""
        item_identifier = _normalize_identifier(item_id, "item")
        return _extract_collection(
            self._get_json(f"items/{item_identifier}/relations"),
            ("relations", "items"),
        )

    def list_tracker_items(
        self,
        tracker_id: int | str,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> list[dict[str, Any]]:
        """Read all items in a tracker while detecting unsafe pagination loops."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        if page_size < 1:
            raise CodebeamerScopeError("The Codebeamer page size must be positive.")

        page_number = 1
        results: list[dict[str, Any]] = []
        seen_pages: set[tuple[str, ...]] = set()
        while True:
            payload = self._get_json(
                f"trackers/{tracker_identifier}/items",
                params={"page": page_number, "pageSize": page_size},
            )
            items = _extract_collection(
                payload,
                ("itemRefs", "items", "content", "results"),
            )
            if not items:
                return results

            item_ids = tuple(str(item.get("id", "")) for item in items)
            if item_ids in seen_pages:
                raise CodebeamerResponseError(
                    "Codebeamer repeated a tracker page; refusing an incomplete export."
                )
            seen_pages.add(item_ids)
            results.extend(items)
            if not _has_next_page(payload, len(items), page_number, page_size):
                return results
            page_number += 1

    def list_tracker_item_details(
        self,
        tracker_id: int | str,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> list[dict[str, Any]]:
        """Read every item detail and verify each still belongs to the tracker."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        details: list[dict[str, Any]] = []
        seen_item_ids: set[str] = set()
        for item_reference in self.list_tracker_items(
            tracker_identifier,
            page_size=page_size,
        ):
            item_identifier = _mapping_identifier(item_reference, "item")
            if item_identifier in seen_item_ids:
                raise CodebeamerResponseError(
                    "Codebeamer returned a duplicate item reference."
                )
            seen_item_ids.add(item_identifier)
            item = self.get_item(item_identifier)
            if _mapping_identifier(item, "item") != item_identifier:
                raise CodebeamerResponseError(
                    "Codebeamer returned a mismatched item response."
                )
            tracker = item.get("tracker")
            if not isinstance(tracker, Mapping) or (
                _mapping_identifier(tracker, "tracker") != tracker_identifier
            ):
                raise CodebeamerResponseError(
                    "Codebeamer returned an item outside the selected tracker."
                )
            details.append(item)
        return details

    def create_item(
        self,
        tracker_id: int | str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Create one tracker item through the guarded plan/apply workflow."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        return self._write_mapping_json(
            "POST",
            f"trackers/{tracker_identifier}/items",
            payload,
            "item",
        )

    def update_item(
        self,
        item_id: int | str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Update one tracker item through the guarded plan/apply workflow."""
        item_identifier = _normalize_identifier(item_id, "item")
        return self._write_mapping_json(
            "PUT",
            f"items/{item_identifier}",
            payload,
            "item",
        )

    def move_item(
        self,
        item_id: int | str,
        reference_item_id: int | str,
        position: str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Move one item relative to a sibling through the guarded API route."""
        item_identifier = _normalize_identifier(item_id, "item")
        reference_identifier = _normalize_identifier(reference_item_id, "reference item")
        normalized_position = position.strip().upper()
        if normalized_position not in {"BEFORE", "AFTER", "BELOW"}:
            raise CodebeamerScopeError("The Codebeamer item position is invalid.")
        return self._write_mapping_json(
            "PUT",
            f"items/{item_identifier}",
            payload,
            "item",
            params={
                "referenceItemId": reference_identifier,
                "position": normalized_position,
            },
        )

    def create_tracker(
        self,
        project_id: int | str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Create one tracker through the guarded plan/apply workflow."""
        project_identifier = _normalize_identifier(project_id, "project")
        return self._write_mapping_json(
            "POST",
            f"projects/{project_identifier}/trackers",
            payload,
            "tracker",
        )

    def update_tracker(
        self,
        tracker_id: int | str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Update one tracker through the guarded plan/apply workflow."""
        tracker_identifier = _normalize_identifier(tracker_id, "tracker")
        return self._write_mapping_json(
            "PUT",
            f"trackers/{tracker_identifier}",
            payload,
            "tracker",
        )

    def _new_session(self) -> requests.Session:
        """Create a session that retries transient read-only requests only."""
        session = requests.Session()
        retry_policy = Retry(
            total=3,
            connect=3,
            read=3,
            status=3,
            backoff_factor=0.5,
            status_forcelist=_RETRY_STATUS_CODES,
            allowed_methods=frozenset({"GET"}),
            raise_on_status=False,
        )
        session.mount("https://", _SystemTrustAdapter(max_retries=retry_policy))
        return session

    def _get_mapping_json(
        self,
        resource_path: str,
        resource_label: str,
    ) -> dict[str, Any]:
        payload = self._get_json(resource_path)
        if not isinstance(payload, Mapping):
            raise CodebeamerResponseError(
                f"Codebeamer returned an invalid {resource_label} response."
            )
        return dict(payload)

    def _write_mapping_json(
        self,
        method: str,
        resource_path: str,
        payload: Mapping[str, Any],
        resource_label: str,
        params: Mapping[str, object] | None = None,
    ) -> dict[str, Any]:
        if not isinstance(payload, Mapping):
            raise CodebeamerScopeError(
                f"The Codebeamer {resource_label} payload must be a JSON object."
            )
        response_payload = self._request_json(
            method,
            resource_path,
            params=params,
            payload=dict(payload),
            allow_empty=True,
        )
        if not isinstance(response_payload, Mapping):
            raise CodebeamerResponseError(
                f"Codebeamer returned an invalid {resource_label} response."
            )
        return dict(response_payload)

    def _get_json(
        self,
        resource_path: str,
        params: Mapping[str, object] | None = None,
    ) -> Any:
        return self._request_json("GET", resource_path, params=params)

    def _request_json(
        self,
        method: str,
        resource_path: str,
        *,
        params: Mapping[str, object] | None = None,
        payload: Mapping[str, Any] | None = None,
        allow_empty: bool = False,
    ) -> Any:
        normalized_method = method.upper()
        if normalized_method not in {"GET", "POST", "PUT"}:
            raise CodebeamerScopeError("The Codebeamer HTTP method is not permitted.")
        request_kwargs: dict[str, Any] = {
            "params": params,
            "timeout": self._config.timeout_seconds,
            "allow_redirects": False,
        }
        if payload is not None:
            request_kwargs["json"] = dict(payload)
        try:
            response = self._session.request(
                normalized_method,
                self._resource_url(resource_path),
                **request_kwargs,
            )
        except requests.exceptions.SSLError as error:
            raise CodebeamerConnectionError(
                "Codebeamer TLS verification failed; install the server CA in the "
                "system trust store."
            ) from error
        except requests.RequestException as error:
            raise CodebeamerConnectionError(
                "Unable to reach the configured Codebeamer service."
            ) from error
        except (TypeError, ValueError) as error:
            raise CodebeamerScopeError(
                "The Codebeamer request payload must be JSON serializable."
            ) from error

        self._raise_for_status(response.status_code, getattr(response, "text", ""))
        if allow_empty and response.status_code == 204:
            return {}
        try:
            return response.json()
        except ValueError as error:
            content_type = response.headers.get("Content-Type", "").casefold()
            if "text/html" in content_type:
                raise CodebeamerResponseError(
                    "Codebeamer returned an HTML login or SSO page instead of REST API "
                    "JSON; verify the URL and approved REST authentication method."
                ) from error
            raise CodebeamerResponseError(
                "Codebeamer returned a non-JSON response."
            ) from error

    def _resource_url(self, resource_path: str) -> str:
        clean_path = resource_path.strip("/")
        if not clean_path or ".." in clean_path:
            raise CodebeamerScopeError("The Codebeamer resource path is invalid.")
        return f"{self.api_base_url}/{clean_path}"

    @staticmethod
    def _raise_for_status(status_code: int, response_text: str = "") -> None:
        if 200 <= status_code < 300:
            return
        if status_code in {301, 302, 303, 307, 308}:
            raise CodebeamerAuthenticationError(
                "Codebeamer redirected the request; verify the server URL and access method."
            )
        if status_code == 401:
            raise CodebeamerAuthenticationError(
                "Codebeamer rejected the configured credentials."
            )
        if status_code == 403:
            raise CodebeamerAuthorizationError(
                "The authenticated account is not authorized for this Codebeamer resource."
            )
        if status_code in {409, 412}:
            raise CodebeamerConflictError(
                "Codebeamer rejected the mutation because the target changed or is locked."
            )
        if status_code == 404:
            raise CodebeamerScopeError(
                "The requested Codebeamer project, tracker, item, or endpoint was not found."
            )
        if status_code == 429:
            raise CodebeamerConnectionError(
                "Codebeamer rate-limited the request; retry after the server cooldown."
            )
        detail = response_text.strip()
        if detail:
            raise CodebeamerResponseError(
                f"Codebeamer returned unexpected HTTP status {status_code}: {detail}"
            )
        raise CodebeamerResponseError(
            f"Codebeamer returned unexpected HTTP status {status_code}."
        )


def create_codebeamer_client(
    dotenv_path: str | Path | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    validate: bool = True,
) -> CodebeamerClient:
    """Build a standalone client and optionally validate read access first."""
    client = CodebeamerClient.from_dotenv(
        dotenv_path=dotenv_path,
        timeout_seconds=timeout_seconds,
    )
    try:
        if validate:
            client.validate_connection()
    except CodebeamerError:
        client.close()
        raise
    return client


def _normalize_base_url(value: str) -> str:
    parsed = urlsplit(value.strip())
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        raise CodebeamerConfigurationError(
            "CODEBEAMER_URL must be an absolute HTTPS URL."
        )
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise CodebeamerConfigurationError(
            "CODEBEAMER_URL must not contain credentials, query parameters, or fragments."
        )
    return urlunsplit(
        (
            parsed.scheme.lower(),
            parsed.netloc,
            parsed.path.rstrip("/"),
            "",
            "",
        )
    )


def _normalize_identifier(value: int | str, label: str) -> str:
    identifier = str(value).strip()
    if not identifier.isdecimal() or int(identifier) <= 0:
        raise CodebeamerScopeError(
            f"The Codebeamer {label} identifier must be a positive integer."
        )
    return identifier


def _mapping_identifier(value: Mapping[str, Any], label: str) -> str:
    """Read an identifier from a returned reference without accepting aliases."""
    if "id" not in value:
        raise CodebeamerResponseError(
            f"Codebeamer returned a {label} without an identifier."
        )
    try:
        return _normalize_identifier(str(value["id"]), label)
    except CodebeamerScopeError as error:
        raise CodebeamerResponseError(
            f"Codebeamer returned a {label} with an invalid identifier."
        ) from error


def _validate_timeout(value: float) -> float:
    if value <= 0:
        raise CodebeamerConfigurationError(
            "The Codebeamer timeout must be greater than zero."
        )
    return float(value)


def _extract_collection(
    payload: Any,
    keys: tuple[str, ...],
) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return _copy_mapping_items(payload)
    if not isinstance(payload, Mapping):
        raise CodebeamerResponseError(
            "Codebeamer returned an invalid collection response."
        )
    for key in keys:
        value = payload.get(key)
        if isinstance(value, list):
            return _copy_mapping_items(value)
    raise CodebeamerResponseError(
        "Codebeamer returned a collection without recognizable item data."
    )


def _copy_mapping_items(items: list[Any]) -> list[dict[str, Any]]:
    if not all(isinstance(item, Mapping) for item in items):
        raise CodebeamerResponseError(
            "Codebeamer returned a collection containing an invalid item."
        )
    return [dict(item) for item in items]


def _has_next_page(
    payload: Any,
    item_count: int,
    page_number: int,
    page_size: int,
) -> bool:
    if isinstance(payload, Mapping):
        for key in ("hasMore", "hasNext", "hasNextPage"):
            if key in payload:
                return bool(payload[key])
        if payload.get("nextPage") is not None:
            return True
        total = payload.get("total") or payload.get("totalCount")
        if isinstance(total, int):
            return page_number * page_size < total
    return item_count >= page_size