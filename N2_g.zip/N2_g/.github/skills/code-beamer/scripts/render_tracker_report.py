"""Render a readable requirement-ID report from Codebeamer item summaries."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

_WHITESPACE_PATTERN = re.compile(r"\s+")


def render_tracker_report(
    items: Sequence[Mapping[str, Any]],
    *,
    tracker_id: int | str,
    tracker_name: str,
    status_name: str = "In_Review",
) -> str:
    """Render each returned item ID with source-backed subject text."""
    ordered_items = sorted(items, key=_item_sort_key)
    item_ids = [_item_id(item) for item in ordered_items]
    if len(item_ids) != len(set(item_ids)):
        raise ValueError("The Codebeamer report input contains duplicate item IDs.")

    lines = [
        f"# Codebeamer {status_name} Requirements",
        "",
        f"- Tracker ID: `{tracker_id}`",
        f"- Tracker: `{_inline_text(tracker_name)}`",
        f"- Matching requirements: {len(ordered_items)}",
        "- Related to: the returned item title, or the returned description when no title exists.",
        "",
        "## Requirements",
        "",
    ]
    for item in ordered_items:
        lines.append(f"- `{_item_id(item)}`: {_related_to(item)}")
    lines.append("")
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> int:
    """Create one local report from an existing read-only tracker result."""
    parser = argparse.ArgumentParser(
        description="Render a Codebeamer requirement-ID report from JSON output."
    )
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tracker-id", required=True)
    parser.add_argument("--tracker-name", required=True)
    parser.add_argument("--status", default="In_Review")
    args = parser.parse_args(argv)

    try:
        raw_items = json.loads(args.input.read_text(encoding="utf-8"))
        if not isinstance(raw_items, list) or not all(
            isinstance(item, Mapping) for item in raw_items
        ):
            raise ValueError("Input must be a JSON array of Codebeamer item objects.")
        report = render_tracker_report(
            raw_items,
            tracker_id=args.tracker_id,
            tracker_name=args.tracker_name,
            status_name=args.status,
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report, encoding="utf-8")
    except (OSError, ValueError, TypeError) as error:
        parser.error(str(error))

    print(f"Requirement report created: {args.output}")
    print(f"Requirements included: {len(raw_items)}")
    return 0


def _item_id(item: Mapping[str, Any]) -> str:
    value = str(item.get("id", "")).strip()
    if not value.isdecimal() or int(value) <= 0:
        raise ValueError("A Codebeamer report item has an invalid ID.")
    return value


def _item_sort_key(item: Mapping[str, Any]) -> int:
    return int(_item_id(item))


def _related_to(item: Mapping[str, Any]) -> str:
    title = _inline_text(item.get("name"))
    if title:
        return title
    description = _inline_text(item.get("description"))
    if description:
        return description
    return "No title or description supplied by Codebeamer."


def _inline_text(value: object) -> str:
    text = str(value or "")
    text = text.replace("\u00a0", " ").replace("~_", "_").replace("~-", "-")
    text = _strip_codebeamer_style_wrappers(text)
    text = _WHITESPACE_PATTERN.sub(" ", text).strip()
    return text.replace("|", "\\|")


def _strip_codebeamer_style_wrappers(text: str) -> str:
    """Remove style prefixes and suffixes while retaining nested CSS payload text."""
    result: list[str] = []
    position = 0
    while position < len(text):
        if not text.startswith("%%(", position):
            result.append(text[position])
            position += 1
            continue

        depth = 1
        position += 3
        while position < len(text) and depth:
            if text[position] == "(":
                depth += 1
            elif text[position] == ")":
                depth -= 1
            position += 1
        if depth:
            result.append("%%(")
            continue

        terminator_position = text.find("%!", position)
        if terminator_position < 0:
            result.append(text[position:])
            break
        result.append(text[position:terminator_position])
        position = terminator_position + 2
    return "".join(result)


if __name__ == "__main__":
    raise SystemExit(main())