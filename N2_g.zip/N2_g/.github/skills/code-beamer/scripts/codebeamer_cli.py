"""Standalone command-line interface for the code-beamer skill."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

from codebeamer_client import (
    DEFAULT_ENV_FILE,
    DEFAULT_TIMEOUT_SECONDS,
    CodebeamerClient,
    CodebeamerError,
    CodebeamerScopeError,
    create_codebeamer_client,
)
from codebeamer_operations import (
    apply_mutation_plan,
    build_mutation_plan,
    default_plan_path,
    load_mutation_plan,
    write_mutation_plan,
    write_mutation_receipt,
)

_DEFAULT_OUTPUT_ROOT = Path(__file__).resolve().parents[1] / "artifacts"


def build_argument_parser() -> argparse.ArgumentParser:
    """Create a parser without reading any credentials."""
    parser = argparse.ArgumentParser(
        description=(
            "Read Codebeamer resources and apply explicitly approved mutation plans."
        )
    )
    parser.add_argument(
        "--env-file",
        type=_dotenv_path,
        default=DEFAULT_ENV_FILE,
        help="Path to the local Codebeamer .env file.",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=float,
        default=DEFAULT_TIMEOUT_SECONDS,
        help="HTTPS request timeout in seconds (default: 30).",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser(
        "validate",
        help="Validate authenticated, read-only access to the REST API.",
    )
    commands.add_parser(
        "list-projects",
        help="List projects visible to the configured account.",
    )

    list_trackers_parser = commands.add_parser(
        "list-trackers",
        help="List trackers in one project.",
    )
    _add_identifier_argument(list_trackers_parser, "project", required=True)

    get_project_parser = commands.add_parser(
        "get-project",
        help="Read one project object.",
    )
    _add_identifier_argument(get_project_parser, "project", required=True)

    get_tracker_parser = commands.add_parser(
        "get-tracker",
        help="Read one tracker object.",
    )
    _add_identifier_argument(get_tracker_parser, "tracker", required=True)

    get_tracker_schema_parser = commands.add_parser(
        "get-tracker-schema",
        help="Read the server-provided schema for one tracker.",
    )
    _add_identifier_argument(get_tracker_schema_parser, "tracker", required=True)

    get_tracker_fields_parser = commands.add_parser(
        "get-tracker-fields",
        help="Read configured fields for one tracker.",
    )
    _add_identifier_argument(get_tracker_fields_parser, "tracker", required=True)

    list_items_parser = commands.add_parser(
        "list-items",
        help="Read all requirements, test cases, or other items in one tracker.",
    )
    _add_identifier_argument(list_items_parser, "tracker", required=True)

    list_item_details_parser = commands.add_parser(
        "list-item-details",
        help="Read all item details in one tracker and optionally filter by status.",
    )
    _add_identifier_argument(list_item_details_parser, "tracker", required=True)
    list_item_details_parser.add_argument(
        "--status",
        help="Exact returned status name to include, for example In_Review.",
    )
    list_item_details_parser.add_argument(
        "--summary",
        action="store_true",
        help="Return only ID, name, status, version, and non-empty description.",
    )

    get_item_parser = commands.add_parser(
        "get-item",
        help="Read one requirement, test case, task, or other tracker item.",
    )
    _add_identifier_argument(get_item_parser, "item", required=True)

    get_item_fields_parser = commands.add_parser(
        "get-item-fields",
        help="Read editable and read-only field metadata for one item.",
    )
    _add_identifier_argument(get_item_fields_parser, "item", required=True)

    get_item_history_parser = commands.add_parser(
        "get-item-history",
        help="Read server-provided history for one item.",
    )
    _add_identifier_argument(get_item_history_parser, "item", required=True)

    get_item_relations_parser = commands.add_parser(
        "get-item-relations",
        help="Read explicit relations for one item.",
    )
    _add_identifier_argument(get_item_relations_parser, "item", required=True)

    plan_mutation_parser = commands.add_parser(
        "plan-mutation",
        help="Preflight a create or update operation without changing Codebeamer.",
    )
    plan_mutation_parser.add_argument(
        "--operation",
        choices=(
            "create-item",
            "move-item",
            "update-item",
            "create-tracker",
            "update-tracker",
        ),
        required=True,
        help="The planned Codebeamer mutation.",
    )
    _add_identifier_argument(plan_mutation_parser, "project", required=True)
    _add_identifier_argument(plan_mutation_parser, "tracker", required=False)
    _add_identifier_argument(plan_mutation_parser, "item", required=False)
    _add_identifier_argument(
        plan_mutation_parser,
        "reference-item",
        required=False,
    )
    plan_mutation_parser.add_argument(
        "--position",
        choices=("BEFORE", "AFTER", "BELOW"),
        help="Sibling-relative position for a move-item plan.",
    )
    plan_mutation_parser.add_argument(
        "--payload-file",
        type=Path,
        required=True,
        help="JSON object based on the selected tracker schema.",
    )
    plan_mutation_parser.add_argument(
        "--output-root",
        type=Path,
        default=_DEFAULT_OUTPUT_ROOT,
        help="Directory that receives reviewed plans/ and applied receipts/.",
    )

    apply_mutation_parser = commands.add_parser(
        "apply-mutation",
        help="Apply one reviewed mutation plan after explicit approval.",
    )
    apply_mutation_parser.add_argument(
        "--plan-file",
        type=Path,
        required=True,
        help="Reviewed plan generated by plan-mutation.",
    )
    apply_mutation_parser.add_argument(
        "--approve",
        required=True,
        help="Exact plan ID displayed by plan-mutation.",
    )
    apply_mutation_parser.add_argument(
        "--apply",
        action="store_true",
        required=True,
        help="Required acknowledgement that the remote mutation will run.",
    )
    apply_mutation_parser.add_argument(
        "--output-root",
        type=Path,
        default=_DEFAULT_OUTPUT_ROOT,
        help="Directory that receives applied receipts/.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run one Codebeamer command with safe console error handling."""
    args = build_argument_parser().parse_args(argv)
    client: CodebeamerClient | None = None
    try:
        client = create_codebeamer_client(
            dotenv_path=args.env_file,
            timeout_seconds=args.timeout_seconds,
            validate=args.command == "validate",
        )
        if args.command == "validate":
            print("Codebeamer REST API access validated.")
            return 0
        if args.command == "list-projects":
            _print_json(client, client.list_projects())
            return 0
        if args.command == "list-trackers":
            _print_json(client, client.list_project_trackers(args.project_id))
            return 0
        if args.command == "get-project":
            _print_json(client, client.get_project(args.project_id))
            return 0
        if args.command == "get-tracker":
            _print_json(client, client.get_tracker(args.tracker_id))
            return 0
        if args.command == "get-tracker-schema":
            _print_json(client, client.get_tracker_schema(args.tracker_id))
            return 0
        if args.command == "get-tracker-fields":
            _print_json(client, client.get_tracker_fields(args.tracker_id))
            return 0
        if args.command == "list-items":
            _print_json(client, client.list_tracker_items(args.tracker_id))
            return 0
        if args.command == "list-item-details":
            items = client.list_tracker_item_details(args.tracker_id)
            if args.status is not None:
                items = [
                    item
                    for item in items
                    if _item_status_name(item).casefold() == args.status.casefold()
                ]
            _print_json(
                client,
                [_item_summary(item) for item in items] if args.summary else items,
            )
            return 0
        if args.command == "get-item":
            _print_json(client, client.get_item(args.item_id))
            return 0
        if args.command == "get-item-fields":
            _print_json(client, client.get_item_fields(args.item_id))
            return 0
        if args.command == "get-item-history":
            _print_json(client, client.get_item_history(args.item_id))
            return 0
        if args.command == "get-item-relations":
            _print_json(client, client.get_item_relations(args.item_id))
            return 0
        if args.command == "plan-mutation":
            return _create_mutation_plan(client, args)
        if args.command == "apply-mutation":
            return _apply_mutation_plan(client, args)
        raise CodebeamerScopeError("The Codebeamer command is not supported.")
    except CodebeamerError as error:
        message = client.redact(error) if client is not None else str(error)
        print(f"Codebeamer operation failed: {message}", file=sys.stderr)
        return 2
    except OSError:
        print(
            "Codebeamer operation failed while reading or writing local artifacts.",
            file=sys.stderr,
        )
        return 3
    except Exception:
        print("Codebeamer operation failed unexpectedly.", file=sys.stderr)
        return 1
    finally:
        if client is not None:
            client.close()


def _add_identifier_argument(
    parser: argparse.ArgumentParser,
    identifier_name: str,
    *,
    required: bool,
) -> None:
    parser.add_argument(
        f"--{identifier_name}-id",
        type=_positive_identifier,
        required=required,
        help=f"Codebeamer {identifier_name} ID.",
    )


def _create_mutation_plan(client: CodebeamerClient, args: argparse.Namespace) -> int:
    payload = _load_payload(args.payload_file)
    plan = build_mutation_plan(
        client,
        operation=args.operation,
        project_id=args.project_id,
        tracker_id=args.tracker_id,
        item_id=args.item_id,
        payload=payload,
        reference_item_id=args.reference_item_id,
        position=args.position,
    )
    plan_path = write_mutation_plan(plan, default_plan_path(args.output_root, plan))
    print(f"Mutation plan created: {client.redact(plan_path)}")
    print(f"Plan ID: {plan.plan_id}")
    print("Review the plan before running apply-mutation with --apply.")
    return 0


def _apply_mutation_plan(client: CodebeamerClient, args: argparse.Namespace) -> int:
    if not args.apply:
        raise CodebeamerScopeError("Codebeamer mutations require the --apply flag.")
    plan = load_mutation_plan(args.plan_file)
    result = apply_mutation_plan(client, plan, approval_token=args.approve)
    receipt_path = write_mutation_receipt(result, args.output_root)
    print(f"Codebeamer mutation applied: {plan.operation}")
    print(f"Mutation receipt created: {client.redact(receipt_path)}")
    return 0


def _print_json(client: CodebeamerClient, value: object) -> None:
    print(
        json.dumps(
            _redact_json_value(client, value),
            indent=2,
            ensure_ascii=True,
            sort_keys=True,
        )
    )


def _redact_json_value(client: CodebeamerClient, value: object) -> object:
    if isinstance(value, Mapping):
        return {
            str(key): _redact_json_value(client, nested_value)
            for key, nested_value in value.items()
        }
    if isinstance(value, list):
        return [_redact_json_value(client, nested_value) for nested_value in value]
    if isinstance(value, tuple):
        return [_redact_json_value(client, nested_value) for nested_value in value]
    return client.redact(value) if isinstance(value, str) else value


def _item_status_name(item: Mapping[str, Any]) -> str:
    """Return a normalized display status from a Codebeamer item response."""
    status = item.get("status")
    if isinstance(status, Mapping):
        value = status.get("name") or status.get("title") or status.get("value")
        return str(value or "")
    return str(status or "")


def _item_summary(item: Mapping[str, Any]) -> dict[str, Any]:
    """Minimize detail-list output while retaining the requested requirement context."""
    summary = {
        "id": item.get("id"),
        "name": item.get("name"),
        "status": _item_status_name(item),
        "version": item.get("version"),
    }
    description = item.get("description")
    if isinstance(description, str) and description.strip():
        summary["description"] = description
    return summary


def _load_payload(payload_path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise CodebeamerScopeError(
            "The Codebeamer mutation payload file is not valid JSON."
        ) from error
    if not isinstance(payload, dict):
        raise CodebeamerScopeError(
            "The Codebeamer mutation payload file must contain a JSON object."
        )
    return payload


def _dotenv_path(value: str) -> Path:
    path = Path(value)
    if not path.name.casefold().endswith(".env"):
        raise argparse.ArgumentTypeError(
            "Credentials must be supplied through a .env file."
        )
    return path


def _positive_identifier(value: str) -> int:
    if not value.isdecimal() or int(value) <= 0:
        raise argparse.ArgumentTypeError("Value must be a positive integer.")
    return int(value)


if __name__ == "__main__":
    raise SystemExit(main())