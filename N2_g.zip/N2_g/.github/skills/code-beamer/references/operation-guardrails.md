# Codebeamer Operation Guardrails

## Scope

| Operation | Remote method | Required preflight | Apply requirement |
| --- | --- | --- | --- |
| Read project, tracker, schema, field, item, history, or relation | `GET` | Valid positive identifier | None |
| Create requirement or test case item | `POST /trackers/{trackerId}/items` | Project visibility and tracker membership | Reviewed plan ID plus `--apply` |
| Move one requirement or test case item | `PUT /items/{itemId}?referenceItemId={siblingId}&position={position}` | Project, tracker, target, reference item, same-parent check, full-field snapshot | Reviewed plan ID plus `--apply` |
| Update requirement or test case item | `PUT /items/{itemId}` | Project visibility, tracker membership, item ownership, fingerprint | Reviewed plan ID plus `--apply` |
| Create tracker | `POST /projects/{projectId}/trackers` | Project visibility | Reviewed plan ID plus `--apply` |
| Update tracker | `PUT /trackers/{trackerId}` | Project visibility, tracker membership, fingerprint | Reviewed plan ID plus `--apply` |

The route families are based on the deployed REST v3 integration and public v3 API client evidence. Tracker-specific payload fields remain server-defined: inspect the target tracker schema and fields before a mutation.

## Payload Rules

- Payloads are JSON objects only and must not contain configured credential values or credential-named fields.
- Create payloads must not include an existing `id`.
- Update item payloads must include the exact selected item `id`.
- Move payloads must preserve the complete current mutable item: mandatory `id` and `name`,
  current `status`, `description` and `descriptionFormat` when populated, and every populated
  editable `customFields` or editable table field. The move-specific query parameters select
  the position; they do not replace the item content.
- Update tracker payloads must include the exact selected tracker `id`.
- Any supplied `tracker` reference must match the selected tracker; any supplied `project` reference must match the selected project.
- Do not infer required fields, choice values, workflow states, relations, or test-step formats. Read the schema first and surface `Evidence unavailable.` when it cannot be established.

Example create-item payload shape only; confirm field availability and values with the target schema:

```json
{
  "name": "Source-backed requirement title",
  "description": "Source-backed requirement content",
  "descriptionFormat": "PlainText"
}
```

Example update-item payload shape only; begin with a fresh item read and retain required server fields:

```json
{
  "id": 123,
  "name": "Approved revised title"
}
```

For a move, the payload has the same item-content contract as an update. Its fields must come
from a fresh `get-item` and `get-item-fields` read; do not replace the complete payload with a
small hand-written subset:

```text
id, name, status,
description, descriptionFormat,
all populated editable custom fields,
all populated editable table fields
```

The move position is supplied separately by the plan options:

```powershell
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py plan-mutation `
  --operation move-item --project-id <project-id> --tracker-id <tracker-id> `
  --item-id <target-item-id> --reference-item-id <sibling-item-id> `
  --position AFTER --payload-file <complete-current-item-payload.json>
```

`AFTER` is the verified direct-below operation. Parent assignment without a sibling reference
does not guarantee placement and may append the item to the parent's final child position.
`ordinal` is observational in the verified tracker schema and must not be used as a substitute
for `referenceItemId` and `position`.

## Approval Protocol

1. Read target and schema.
2. Create a plan with `plan-mutation`; it performs only `GET` requests.
3. Review plan ID, operation, target IDs, payload, precondition fingerprint, impact, and evidence.
4. Obtain an explicit user statement approving that exact plan ID.
5. Run `apply-mutation --plan-file <path> --approve <plan-id> --apply`.
6. Record the local receipt and re-read the result when requested.

The tool rejects a changed plan, incorrect approval token, stale update target, mismatched scope, invalid payload, credential-containing payload, redirect, authentication failure, authorization failure, conflict, or unexpected response shape.

For `move-item`, re-read the parent after apply and verify the reference item immediately
precedes the moved item. Re-read the target content and compare all populated fields captured
before the move; a correct parent with missing content is a failed operation.

## Engineering Analysis

For requirements and test-case analysis, correlate the selected Codebeamer records with relevant local source, DBC, configuration, logs, specifications, and test artifacts. Report:

- Scope and source provenance.
- Verified facts, inferences, assumptions, contradictions, and evidence gaps.
- Requirement-to-test traceability based only on explicit returned links.
- Change impact on requirements, tests, source, configuration, safety evidence, and regression scope.
- Confidence level and the reason for it.

Use [agent_sc3.md](../../../agents/agent_sc3.md) for the repository's mandatory evidence, traceability, and safety rules.