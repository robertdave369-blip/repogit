---
name: code-beamer
description: "Use when reading, understanding, analyzing, creating, or modifying Codebeamer requirements, test cases, trackers, tracker items, schemas, fields, history, relations, and traceability. Provides a self-contained read-first and approval-gated write workflow."
argument-hint: "Describe the Codebeamer requirement, test-case, tracker, analysis, or approved change request."
user-invocable: true
disable-model-invocation: false
---

# Codebeamer Operations

Use this skill for Codebeamer requirements, test cases, trackers, traceability, and related item data. It is self-contained under this skill folder.

## Configuration

1. Use only the adjacent `.env` file for `CODEBEAMER_URL`, `CODEBEAMER_USERNAME`, and `CODEBEAMER_PASSWORD`. Create it locally from [`.env.example`](./.env.example); it is ignored by [`.gitignore`](./.gitignore).
2. Never place credentials in a prompt, command line, payload JSON, source file, plan, receipt, or report. Do not request credentials through chat.
3. Install the standalone dependencies only when needed:

```powershell
py -3.13 -m pip install -r .github\skills\code-beamer\requirements.txt
```

4. Use [codebeamer_cli.py](./scripts/codebeamer_cli.py) for all remote activity. Do not call HTTP libraries directly.

## Read And Analyze

1. Confirm the requested project, tracker, item, project variant, and intended outcome. Discover IDs rather than inventing them.
2. Read the smallest relevant set: project and tracker metadata, tracker schema/fields, target requirements or test cases, and explicit relations. Use local source, DBC, test specifications, and configuration when they affect the engineering conclusion.
3. Preserve provenance: record the Codebeamer project, tracker, and item IDs plus relevant source revisions or local file paths.
4. Separate verified facts, inferences, assumptions, contradictions, evidence gaps, and confidence. Do not call a requirement Approved, a link present, or a coverage gap confirmed without returned evidence.
5. For test-specification creation or Codebeamer-format workbook generation, also load the [Veoneer test-spec generator](../veoneer-test-spec-generator/SKILL.md). It remains offline unless the user explicitly requests a separately approved Codebeamer mutation.

Common read commands:

```powershell
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py validate
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py list-projects
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py list-trackers --project-id <project-id>
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py get-tracker-schema --tracker-id <tracker-id>
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py list-item-details --tracker-id <tracker-id> --status In_Review --summary
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py get-item --item-id <item-id>
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py get-item-relations --item-id <item-id>
```

## Create And Modify

The supported remote mutations are `create-item`, `move-item`, `update-item`, `create-tracker`, and `update-tracker`. Requirements and test cases are both tracker items. Delete operations, bulk updates, workflow transitions, attachments, comments, relations, test-run changes, and importer execution are deliberately out of scope.

1. Read the relevant tracker schema and fields before proposing a payload. Verify the target tracker belongs to the selected project.
2. Create a JSON payload without credentials. For updates, include the target `id`; the skill rejects a mismatched item, tracker, or project reference.
3. Create a non-executing plan. This reads the current target, records a fingerprint, and writes a reviewable local plan.
4. Present the plan's exact target, requested fields, source evidence, expected impact, and unresolved gaps to the user. Do not apply it yet.
5. Apply only after the user explicitly approves that exact plan ID in the current conversation. The command must include both `--apply` and `--approve <plan-id>`.
6. Report the receipt path and re-read the changed resource when the user requests verification. Do not claim a successful change from the plan alone.

```powershell
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py plan-mutation `
  --operation update-item --project-id <project-id> --tracker-id <tracker-id> `
  --item-id <item-id> --payload-file <payload.json>

py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py apply-mutation `
  --plan-file <reviewed-plan.json> --approve <plan-id> --apply
```

See [operation guardrails](./references/operation-guardrails.md) for payload expectations, approval rules, and evidence requirements.

## Move A Test Case

Use `move-item` when a test case must be placed in a tracker hierarchy or directly beside
another item. Do not use a parent-only `update-item`: assigning a parent can append the item
to the end of that parent's children, and a partial update payload can clear omitted item
content. The sibling-relative route was verified against the deployed Codebeamer instance on
2026-09-24 for item `37425057`, reference item `37391113`, and position `AFTER`.

Before creating the plan:

1. Read the target and destination sibling with `get-item`.
2. Read the target with `get-item-fields` and identify every populated editable field, including
   `Description`, `Pre-Action`, `Post-Action`, custom fields, and editable table fields such as
   `Test Steps`.
3. Build the move payload from the current target data. Preserve every populated mutable field,
   the mandatory `id` and `name`, and the current `status`. Change only the hierarchy field
   required by the move. Do not hand-write a payload containing only `id`, `name`, `status`,
   and `Parent`.
4. Confirm that the target and reference item belong to the same tracker and current parent.

Create a read-only sibling-relative plan:

```powershell
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py plan-mutation `
  --operation move-item --project-id <project-id> --tracker-id <tracker-id> `
  --item-id <target-item-id> --reference-item-id <sibling-item-id> `
  --position AFTER --payload-file <complete-current-item-payload.json>
```

Use `AFTER` to place the target directly below the reference sibling. The CLI also accepts
`BEFORE` and `BELOW`; select the position that matches the requested hierarchy and verify the
deployed behavior before using a less common position. Do not use `ordinal` as the move
mechanism; it is returned for display, but is not an editable tracker field in the verified
tracker schema.

Apply only the exact approved plan:

```powershell
py -3.13 .github\skills\code-beamer\scripts\codebeamer_cli.py apply-mutation `
  --plan-file <reviewed-move-plan.json> --approve <exact-plan-id> --apply
```

After applying, re-read both the target and its parent. Verify that the target's parent is
correct, its index is exactly one after the reference item's index, and all previously
populated fields are still present and unchanged. Record the receipt and report any field
loss or ordering mismatch as a failed move, not a successful update.

## Safety Rules

- The default is read-only. A plan is not permission to write.
- Do not alter a requirement, test case, tracker, relation, or status without explicit user approval for the displayed plan ID.
- Fail closed if the project, tracker, item ownership, payload ID, server response, or stale-data precondition is ambiguous.
- Do not make changes to OEM/customer requirement exports under `req/`; use Codebeamer's approved workflow only when the user authorizes a remote update.
- Do not run any bench, ECU, flashing, NVM, or hardware-affecting operation as part of Codebeamer work.

## Validation

Run the standalone offline safeguards after changing this skill:

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'
py -3.13 -m pytest tests\test_code_beamer_skill.py -q
```

The test uses a fake HTTP session and never connects to Codebeamer.