# ARIA Bench Configuration — Workflow

Bundled detail for `../SKILL.md`. Load when actually performing the configuration;
the SKILL.md summary is enough to decide whether this applies.

## Configuration Workflow

### 1. Build the Canonical ECU Pin Model

Create one record per connector cavity, including:

| Field | Requirement |
| --- | --- |
| ECU Pin | Exact pin/cavity identifier from the pinout |
| Connector | Exact connector identifier and pin-count context |
| Signal | Exact source signal name |
| Electrical function | Source description and ECU behavior |
| Classification | `POWER`, `GROUND`, `LOOP`, `DCS`, `CAN`, `GPO`, `RSU`, `SPI`, or `UNUSED` |
| Evidence | File, sheet/page, row/cell/section, and source revision |
| Confidence | Evidence-based confidence only |

Account for every pin. Pins that are reserved, not connected, diagnostic-only, or unsupported
must remain present and be classified `UNUSED` with evidence; do not silently omit them.

### 2. Inventory Harness and ARIA Resources

Build a resource ledger only from the qualified generic harness and active ARIA configuration:

| Slot | Card type | Channel | ZIF feed | ZIF return | Capability | Current state |
| --- | --- | --- | --- | --- | --- | --- |

For an existing LDBX, resolve every card `FunctionRef`, relay-map reference, configured slot,
channel, function name, and profile reference. Confirm that all profile slots exist in the
selected LDBX, and do not substitute a nested or duplicate LDBX file without an evidence-backed
comparison.

### 3. Allocate Only Compatible Resources

Use the following classification rules:

| ECU signal class | Allowed ARIA resource |
| --- | --- |
| Airbag, pretensioner, load limiter, curtain, knee, or other squib loop | Loop card only |
| Buckle, seat switch, ODS, occupancy, or resistive detection input | DCS resource only |
| KL30, KL15, IGN, VBAT, GND, wake input | Power-card resource only, with power and ground kept distinct |
| CAN High and CAN Low | Matched CAN resource only; preserve the documented pair |
| PAB lamp, warning lamp, crash output, ENS, eCall, or other discrete output | Lamp/GPO/ENS resource declared by the harness only |
| Satellite, pressure, acceleration, or PSI5 sensor | RSU resource only after RSU workbook validation |
| Gen6XY, Gen6XZ, Panasonic IMU, central sensor, or SPI sensor | SPI resource only after SPI evidence validation |

For each candidate assignment, verify that the selected slot/channel exists, is not allocated,
has the required card capability, and has a matching ZIF feed/return route. Do not allocate a
channel more than once. Do not use logical LDBX names such as `LOOP0` or `RSU_CH1` as proof of an
ECU connection.

When two or more assignments are physically valid, list every alternative with the source-backed
rationale, constraint, and confidence. Do not select one silently.

### 4. Validate RSU and SPI Interfaces

For every RSU assignment, verify all of the following from the current RSU workbook or approved
sensor source:

- Sensor identity and physical position
- Sensor family and exact variant
- Communication/interface type
- Channel or timeslot arrangement
- G-range or pressure range
- Startup/configuration bytes or parameters
- Required fault-free state and any paired/bused sensor relationship

For every SPI assignment, verify the SPI bus, chip-select or card channel, sensor family, variant,
axis labels/order, and initialization configuration. A generic or unbound SPI template is not an
assigned sensor.

### 5. Generate Deliverables

Generate these outputs only at the evidence level justified by the inputs:

1. **Pin Mapping Table**: ECU pin, connector, signal, card type, slot, channel, ZIF feed, ZIF
   return, classification, evidence, confidence, and status.
2. **ZIF Assignment Table**: ZIF feed, ZIF return, slot, card type, channel, ECU connector/cavity,
   signal, evidence, and status.
3. **ARIA Card Assignment Table**: card type, slot, channel, logical resource, mapped ECU signal,
   connector/cavity, ZIF pair, capability validation, and status.
4. **Channel Utilization Summary**: used/capacity counts for Loop, DCS, RSU, SPI, CAN, power,
   lamp/GPO, and all unallocated resources.
5. **LDBX-ready Configuration**: a complete proposed LDBX only when its schema and every
   reference are verified from an approved base file. Otherwise provide a clearly labelled
   allocation plan, not an importable LDBX.
6. **Fault-Free Profile**: a complete JSON profile only when every profile slot/channel exists in
   the selected LDBX and the intended fault-free state is source-backed. Preserve the source
   schema, card types, string/number conventions, and reference IDs.
7. **Validation Report**: PASS/FAIL, evidence, conflicts, warnings, unresolved inputs, and change
   impact.
8. **Unused Resource Report**: declared but unassigned card/channel/ZIF resources. Do not treat
   omitted profile entries as unused unless ARIA profile inheritance behavior is verified.
9. **Configuration Assumptions**: every remaining inference, constraint, and unverified fact.

