---
name: aria-bench-configuration
description: 'Use when creating, mapping, reviewing, or validating an ARIA safety ECU bench configuration, ZIF assignment, LDBX loadbox configuration, or fault-free profile from an SCD, ECU pinout, generic harness mapping, sensor configuration, RSU workbook, SPI configuration, and existing project references. Supports evidence-driven SC3 2S and other ARIA projects without inventing electrical mappings or actuating hardware.'
argument-hint: 'Provide the project, SCD, ECU pinout, generic harness mapping, sensor or RSU configuration, and existing ARIA configuration package.'
user-invocable: true
disable-model-invocation: false
---

# ARIA Bench Configuration

## Purpose

Use this skill to convert a verified ECU electrical architecture into a complete ARIA bench
configuration package. The package may include a pin mapping table, ZIF assignment table, ARIA
card assignment table, channel-utilization summary, LDBX-ready allocation, fault-free profile,
validation report, unused-resource report, and configuration assumptions.

Use this skill for ARIA, loadbox, LDBX, ZIF, generic-harness, squib-loop, DCS, RSU, PSI5, SPI,
CAN, power, lamp, ENS, or safety-ECU configuration work. It complements the repository's
`aria-configuration-assistant` prompt; use `tools/aria_config_assistant.py` for concrete bundle
validation and workbook inspection when it is available.

## Safety And Evidence Rules

1. Read the applicable `agent_sc3` knowledge-base rules before configuration work for an SC3 2S
   project. Treat SCDs, pinouts, workbooks, existing LDBX files, and previous project packages as
   evidence to verify, not automatic truth.
2. Do not execute ARIA, power an ECU, create electrical faults, flash an ECU, deploy a squib, or
   otherwise actuate bench hardware unless the user explicitly requests execution and provides an
   approved safe procedure.
3. Never guess an ECU pin, connector cavity, ZIF feed, ZIF return, card channel, sensor type,
   RSU setting, SPI variant, CAN pairing, or electrical behavior.
4. The approved generic harness mapping is the physical resource master. Do not modify it and do
   not create a channel, ZIF endpoint, or feed/return pair that it does not declare.
5. A mapping is assignable only when its evidence chain is complete:
   `ECU connector/cavity -> signal/function -> harness ZIF feed/return -> ARIA slot/channel`.
   Otherwise mark it `UNRESOLVED` and state `Evidence unavailable.`
6. Label each conclusion as Fact, Inference, Assumption, or Unknown and provide an evidence-based
   confidence level: Very High, High, Medium, Low, or Unknown.
7. Do not modify an existing LDBX or fault-free profile until all blocking validation failures are
   resolved. Preserve a source copy and report every change impact.

## Required Inputs

Collect and qualify these artifacts before generating an importable configuration:

| Input | Minimum required evidence |
| --- | --- |
| System Configuration Document (SCD) | ECU signal name, ECU function, connector, cavity/pin, electrical role |
| ECU pinout / connector definition | Connector identity, pin count, cavity, pin name, signal description |
| Generic harness mapping | Slot, card type, channel, ZIF feed, ZIF return, channel capability |
| Sensor configuration | Sensor function, sensor family/type, interface, physical placement, variant |
| RSU configuration workbook | Sensor/channel identity, communication mode, G-range, startup configuration, sensor family |
| SPI configuration | SPI bus, sensor type, variant, axis configuration, card/channel assignment |
| Existing project references | Active `.accf`, `AriaMain.json`, `.ldbx`, profile JSON, `SensorsConfig.json`, CAN configuration, and relevant DBC/XML files |

If any mandatory electrical-mapping source is missing, create a blocked report and source-gap
table only. Do not generate an ECU-specific pin map, ZIF map, LDBX revision, or fault-free JSON
that implies a verified physical connection.

## Source Qualification

1. Identify the project, ECU family, platform, software/configuration revision, and active ARIA
   root. Resolve the active configuration path from the applicable `.accf` or `AriaMain.json`
   references; do not select a similarly named copy by filename alone.
2. Inventory every source artifact with path, revision/date where available, role, source priority,
   and qualification status. Flag archived, duplicate, stale, `Not in Use`, or unreferenced files.
3. Read complete source data. For Excel files, inspect every worksheet and row, resolve columns by
   header name rather than position, retain sheet/row/cell provenance, and validate the extraction
   against workbook dimensions. For JSON/XML/LDBX, parse the complete structure and retain JSON
   paths or XML locations.
4. Compare the SCD, pinout, harness, sensor sheets, and existing configuration. Report every
   contradiction before allocating a resource. Existing project mappings are reference evidence,
   not authority over the current SCD or generic harness.

## Configuration Workflow

### 1. Build the Canonical ECU Pin Model

Create one record per connector cavity, including:

| Field | Requirement |
| --- | --- |
| ECU Pin | Exact pin/cavity identifier from the pinout |
| Connector | Exact connector identifier and pin-count context |
| Signal | Exact source signal name |
| Electrical function | Source description and ECU behavior |
| Classification | `POWER`, `GROUND`, `LOOP`, `DCS`, `CAN`, `GPO`, `RSU`, `SPI`, or `UNUSED` |
| Evidence | File, sheet/page, row/cell/section, and source revision |
| Confidence | Evidence-based confidence only |

Account for every pin. Pins that are reserved, not connected, diagnostic-only, or unsupported
must remain present and be classified `UNUSED` with evidence; do not silently omit them.

### 2. Inventory Harness and ARIA Resources

Build a resource ledger only from the qualified generic harness and active ARIA configuration:

| Slot | Card type | Channel | ZIF feed | ZIF return | Capability | Current state |
| --- | --- | --- | --- | --- | --- | --- |

For an existing LDBX, resolve every card `FunctionRef`, relay-map reference, configured slot,
channel, function name, and profile reference. Confirm that all profile slots exist in the
selected LDBX, and do not substitute a nested or duplicate LDBX file without an evidence-backed
comparison.

### 3. Allocate Only Compatible Resources

Use the following classification rules:

| ECU signal class | Allowed ARIA resource |
| --- | --- |
| Airbag, pretensioner, load limiter, curtain, knee, or other squib loop | Loop card only |
| Buckle, seat switch, ODS, occupancy, or resistive detection input | DCS resource only |
| KL30, KL15, IGN, VBAT, GND, wake input | Power-card resource only, with power and ground kept distinct |
| CAN High and CAN Low | Matched CAN resource only; preserve the documented pair |
| PAB lamp, warning lamp, crash output, ENS, eCall, or other discrete output | Lamp/GPO/ENS resource declared by the harness only |
| Satellite, pressure, acceleration, or PSI5 sensor | RSU resource only after RSU workbook validation |
| Gen6XY, Gen6XZ, Panasonic IMU, central sensor, or SPI sensor | SPI resource only after SPI evidence validation |

For each candidate assignment, verify that the selected slot/channel exists, is not allocated,
has the required card capability, and has a matching ZIF feed/return route. Do not allocate a
channel more than once. Do not use logical LDBX names such as `LOOP0` or `RSU_CH1` as proof of an
ECU connection.

When two or more assignments are physically valid, list every alternative with the source-backed
rationale, constraint, and confidence. Do not select one silently.

### 4. Validate RSU and SPI Interfaces

For every RSU assignment, verify all of the following from the current RSU workbook or approved
sensor source:

- Sensor identity and physical position
- Sensor family and exact variant
- Communication/interface type
- Channel or timeslot arrangement
- G-range or pressure range
- Startup/configuration bytes or parameters
- Required fault-free state and any paired/bused sensor relationship

For every SPI assignment, verify the SPI bus, chip-select or card channel, sensor family, variant,
axis labels/order, and initialization configuration. A generic or unbound SPI template is not an
assigned sensor.

### 5. Generate Deliverables

Generate these outputs only at the evidence level justified by the inputs:

1. **Pin Mapping Table**: ECU pin, connector, signal, card type, slot, channel, ZIF feed, ZIF
   return, classification, evidence, confidence, and status.
2. **ZIF Assignment Table**: ZIF feed, ZIF return, slot, card type, channel, ECU connector/cavity,
   signal, evidence, and status.
3. **ARIA Card Assignment Table**: card type, slot, channel, logical resource, mapped ECU signal,
   connector/cavity, ZIF pair, capability validation, and status.
4. **Channel Utilization Summary**: used/capacity counts for Loop, DCS, RSU, SPI, CAN, power,
   lamp/GPO, and all unallocated resources.
5. **LDBX-ready Configuration**: a complete proposed LDBX only when its schema and every
   reference are verified from an approved base file. Otherwise provide a clearly labelled
   allocation plan, not an importable LDBX.
6. **Fault-Free Profile**: a complete JSON profile only when every profile slot/channel exists in
   the selected LDBX and the intended fault-free state is source-backed. Preserve the source
   schema, card types, string/number conventions, and reference IDs.
7. **Validation Report**: PASS/FAIL, evidence, conflicts, warnings, unresolved inputs, and change
   impact.
8. **Unused Resource Report**: declared but unassigned card/channel/ZIF resources. Do not treat
   omitted profile entries as unused unless ARIA profile inheritance behavior is verified.
9. **Configuration Assumptions**: every remaining inference, constraint, and unverified fact.

## Mandatory Validation Gates

Before declaring an LDBX or fault-free profile importable, validate all of the following:

1. Every ECU connector cavity is classified and represented exactly once.
2. Every mapped ECU pin has a qualified connector, signal, ZIF feed, ZIF return, slot, and channel.
3. No duplicate slot/channel, ZIF feed, ZIF return, connector cavity, or incompatible shared route
   is assigned unless the approved harness explicitly permits that topology.
4. Feed and return are the documented pair for the allocated channel.
5. CAN High/Low pairing and termination assumptions match the current project evidence.
6. Power, ignition, wake, and ground paths use only declared power resources and remain distinct.
7. Squibs use loop resources only; DCS signals use DCS resources only; RSU signals use RSU resources
   only; SPI sensors use SPI resources only.
8. RSU and SPI settings match their approved configuration sheets and source files.
9. All LDBX function, card, relay-map, and profile references resolve; every profile slot exists in
   the selected LDBX.
10. No unbound or placeholder resource is presented as an active ECU connection.
11. Generated JSON and LDBX parse successfully and cross-file references resolve.
12. The final report contains no unaddressed blocking error and all assumptions remain visible.

## Failure Handling

If a validation gate fails, do not repair the gap by inference. Return a `FAIL` or `BLOCKED`
configuration package containing:

- the source gaps and exact missing fields;
- the affected ECU signals/resources;
- conflicts with source provenance;
- valid alternatives, if and only if they are explicitly supported by the harness; and
- the minimum artifact or decision needed to proceed.

Never overwrite the generic harness or active project configuration as a workaround. Preserve the
active configuration unchanged unless the user explicitly authorizes a reviewed revision.

## Reusable Project Memory

When project memory is available, store only reusable, validated knowledge: ECU family, platform,
connector definitions, common squib mappings, common RSU mappings, and common CAN assignments.
Do not store complete SCDs, full LDBX files, full fault-free JSON profiles, credentials, or
unverified project-specific mappings. Revalidate every retrieved mapping against the current SCD,
pinout, harness, and sensor configuration before use.

## Generated Artifact Locations

An ARIA configuration package is a reviewed configuration artifact, not automatically a test
artifact. Do not write an LDBX, profile, or other configuration package into an active project
configuration path without explicit authorization for that target and a reviewed change plan.

If this skill generates executable validation tests, write each test as
`tests/test_<feature>.py`; keep its generated support files and validation artifacts within
`tests/`. Do not create a separate top-level test-output directory or relocate existing runtime
`test_results/` and `test_logs/` paths.

## Portfolio Handoff

For a multi-skill workflow, preserve the project/variant, qualified source inventory, pin-to-ZIF-
to-ARIA allocations, compatibility results, unresolved mappings, configuration change impact,
validation report, and bench authorization state. Hand safety implications to
`functional-safety-iso26262`, embedded feasibility to `embedded-systems-fundamentals`, and any
generated executable validation to `python-test-automation`.

## Completion Criteria

Call the result production-ready only when the source evidence supports every ECU-to-ZIF-to-ARIA
path, all compatibility and conflict checks pass, the LDBX/profile references resolve, the
fault-free states are verified, no required sensor or electrical setting is guessed, and the final
report records the evidence, validation outcome, unused resources, and remaining assumptions.