# `.github/` — the agent configuration for this workspace

Everything that shapes how an AI assistant behaves in this repository lives here. It exists
because the failure mode that matters is not the assistant refusing to help; it is the
assistant producing a confident, plausible, **wrong** value in an airbag ECU test — a DID
copied from another project, a factor recalled instead of read, a hand edit to a generated
file that vanishes on the next rebuild.

The design principle throughout: **do not depend on the model choosing to do the right
thing.** Where a rule can be enforced deterministically, it is enforced by a hook or
auto-attached by a glob. What is left to judgement is kept short and specific.

## Layout

| Path | What VS Code does with it |
|---|---|
| `copilot-instructions.md` | Always in context. Repository-wide rules. |
| `instructions/*.instructions.md` | Auto-attached when the `applyTo` glob matches the file being worked on. |
| `prompts/*.prompt.md` | Slash commands — type `/new-test-script`. |
| `agents/*.agent.md` | Custom agents, selectable from the agent dropdown. |
| `skills/<name>/SKILL.md` | Agent skills. Loaded by the model when relevant, or picked from the menu. |
| `hooks/*.json` | Hook definitions. Every JSON file here is loaded as one. |
| `hooks/scripts/` | The hook implementations. Not scanned as hook definitions. |
| `cache/session.json` | Persistent verified facts. Injected each session; cleared only on command. |

## The hooks

Defined in `hooks/framework-guardrails.json`. All six are Python, standard library only,
and fail open — a broken hook degrades to a no-op rather than stalling the session.

| Event | Script | Effect |
|---|---|---|
| `SessionStart` | `session_start.py` | Injects a short briefing — where the knowledge base is, the five rules most often broken — plus the persistent cache. |
| `UserPromptSubmit` | `user_prompt_submit.py` | Matches the prompt against `scripts/routing.json` and names the skill or document to open. Deterministic routing, so skill discovery no longer depends on the model deciding to look. |
| `PreToolUse` | `pre_tool_use.py` | **Refuses**: editing a generated file, destructive git/filesystem commands, running a bench script, writing into build artefacts. |
| `PostToolUse` | `post_tool_use.py` | Runs the convention checker on every Python file written and hands the violations straight back. |
| `PreCompact` | `pre_compact.py` | Re-states verified values and the cache before automatic summarization discards them. |
| `Stop` | `stop.py` | Reminds the agent to bank what it verified. |

### What `PreToolUse` refuses, and why

**Generated files.** ~1,600 files carry `GENERATED FILE - do not edit by hand` with a
`Rebuild with:` line. The hook reads that header, refuses the edit, and quotes the rebuild
command. It is self-maintaining — a new generator gets the protection for free as long as it
emits the header.

**Destructive commands.** `rm -rf`, `git reset --hard`, `git clean -fd`, force push,
`Remove-Item -Recurse -Force`, `del /s`, `git branch -D`. `--force-with-lease` is allowed.

**Bench scripts.** Anything matching `python … projects/…/scripts/…` or a `run_all_*.py`.
These power rails, fire triggers, deploy squibs and flash targets. Writing a script is not
permission to run it.

This matters more than usual here because tool calls are auto-approved (see below), so this
hook is the only gate.

## The persistent cache

`cache/session.json`, managed by `hooks/scripts/cache.py`.

```bash
py -3 .github/hooks/scripts/cache.py show      # as injected into context
py -3 .github/hooks/scripts/cache.py status    # one-line summary
py -3 .github/hooks/scripts/cache.py fact "EV_01 DBC uses SRS_FD receivers" --evidence "project_dbc/M314.dbc"
py -3 .github/hooks/scripts/cache.py pin tools/generate_ice01_edr_canc_scripts.py --note "owns EDR_CANC scripts"
py -3 .github/hooks/scripts/cache.py question "Is OPEN-ND the RSU no-data fault?"
py -3 .github/hooks/scripts/cache.py drop fact 3
py -3 .github/hooks/scripts/cache.py clear     # the only thing that empties it
```

It survives new conversations, VS Code restarts and automatic compaction. Nothing clears it
implicitly — that is the point. `/cache-clear` is the command.

Three buckets: **facts** (verified, each with its evidence), **pins** (files that are
authoritative for the current work), **questions** (things that must not be answered by
assumption). Capped at 60/40/25 entries and 6,000 injected characters so it never crowds out
the actual task.

The file is committed rather than ignored, so a team shares the same verified baseline. If
you would rather keep it local, add `.github/cache/` to `.gitignore`.

## Auto-approval and compaction

`.vscode/settings.json` sets:

- `chat.tools.global.autoApprove: true` — no confirmation on any tool call;
- `chat.tools.terminal.autoApprove` — an explicit deny list for destructive commands, kept
  as a second layer;
- `chat.agent.maxRequests: 200` — up from 25, so long generations do not stop half way;
- `github.copilot.chat.summarizeAgentConversationHistory.enabled: true` — compact instead of
  failing when the window fills.

**If you disable hooks, turn `chat.tools.global.autoApprove` back off.** Together they are a
reasonable trade; alone, blanket auto-approval is not.

## Checking it still works

```bash
py -3 .github/hooks/scripts/cache.py status
echo {} | py -3 .github/hooks/scripts/session_start.py
py -3 .github/hooks/scripts/validate_script.py projects/EV_01/modules/EDR_CANC/scripts/*.py
```

A hook that fails prints nothing and exits 0 by design. To see why:

```bash
IOEM_HOOK_DEBUG=1 py -3 .github/hooks/scripts/session_start.py < nul
```

## Extending it

**A new rule for one kind of file** → add `instructions/NN-topic.instructions.md` with an
`applyTo` glob. No code needed.

**A new routing trigger** → add a rule to `hooks/scripts/routing.json`. Keep phrases
specific enough that unrelated questions do not match.

**A new convention to enforce** → add a check to `hooks/scripts/validate_script.py`. It is
used both by the `PostToolUse` hook and standalone, so one implementation covers both.

**A new skill** → `skills/<name>/SKILL.md`, with `name:` in the frontmatter exactly matching
the directory name. If they differ, VS Code silently does not load it.

## Known wrinkle

`prompts/` contains fourteen `*.agent.md` files that duplicate — with differences — files in
`agents/`. VS Code loads agents from `agents/` and prompts from `prompts/*.prompt.md`, so
the copies in `prompts/` are currently loaded by nothing. They were left in place rather
than deleted; worth reconciling against `agents/` and removing.
