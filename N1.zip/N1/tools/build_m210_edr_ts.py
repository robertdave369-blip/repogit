"""Write the M210 EDR ARIA scripts (.ts) into projects/M210/modules/EDR_CANC/script_ts.

Four standalone ARIA scripts (JScript .NET, ES5) and their README:

    M210_EDR_CANC_Parameters.ts    every CAN-received EDR parameter: nominal values, out-of-range values,
                                   reserved codes, CAN wakeup, CAN NM wakeup
    M210_EDR_CANC_Faults.ts        the same parameters under node absent, message timeout, message content,
                                   signal content (full / pre / post), signal never received, variant code
                                   error, under- and over-voltage (full / pre / post)
    M210_EDR_Crash_Parameters.ts   the non-CAN elements after crash replays: crash types, event identity,
                                   delta-V, deployment, counters, housekeeping, power loss, lifetime count
    M210_EDR_Multi_Event_Matrix.ts the merged multi-event curve sets against the record allocation rules

The scripts carry their data as JScript tables, taken here from the M210 configuration (canc_config,
edr_config, project_config, power_config, rsu_config), the shared configuration_control and
crash_configuration, the common EDR parameter reference (docs/project_documents/EDR_Spec Common) and
the expected delta-V of each standard crash set (the edr-rsu-curve-generation skill, did-expected).
Which CAN-C series take part in which case comes from the M210 per-case scripts (scripts_simple), read
through tools/generate_u171_combined_edr_scripts.py, so these scripts cover exactly what those cover.
The bench logic lives in tools/m210_edr_ts/*.ts.in.

    py -3.14 tools/build_m210_edr_ts.py            write the scripts
    py -3.14 tools/build_m210_edr_ts.py --check    compare with the files on disk, write nothing

Offline only: drives nothing. Check the output with
docs/aria_documents/Aria TypeScript/bench_probe/compile_check.ps1.
"""

from __future__ import annotations

import argparse
import ast
import csv
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT / "tools"))

import generate_u171_combined_edr_scripts as combined  # noqa: E402
from Framework_IOEM_Py.projects.M210.config import canc_config as CANC  # noqa: E402
from Framework_IOEM_Py.projects.M210.config import edr_config as EDR  # noqa: E402
from Framework_IOEM_Py.projects.M210.config import power_config as POWER  # noqa: E402
from Framework_IOEM_Py.projects.M210.config import project_config as PROJECT  # noqa: E402
from Framework_IOEM_Py.projects.M210.config import rsu_config as RSU  # noqa: E402
from Framework_IOEM_Py.shared_libraries import configuration_control as CC  # noqa: E402
from Framework_IOEM_Py.shared_libraries import crash_configuration as CRASH  # noqa: E402

OUT = ROOT / "projects" / "M210" / "modules" / "EDR_CANC" / "script_ts"
TEMPLATES = ROOT / "tools" / "m210_edr_ts"
COMMON_DOC = ROOT / "docs" / "project_documents" / "EDR_Spec Common" / "EDR_COMMON_PARAMETERS.md"
CURVE_RUNNER = ROOT / ".github" / "skills" / "edr-rsu-curve-generation" / "scripts" / "edr_curve_runner.py"
CRASH_ROOT = ROOT / "crash_data" / "m310_m314_m110"
BENCH_CRASH_ROOT = "C:\\Framework_IOEM_Py\\crash_data\\m310_m314_m110\\"
STANDARD_TYPES = ["front", "left", "right", "rear", "near"]
# M210 uses the M310_M314_M110 crash curves (crash_curve_config.py).
RSU_SPECS = CRASH.M310_M314_M110_RSU_CHANNEL_SPECS
SPI_SPECS_BY_TYPE = {"front": CRASH.M310_M314_M110_SPI_SPECS, "left": CRASH.M310_M314_M110_SPI_SPECS,
                     "right": CRASH.M310_M314_M110_RIGHT_SPI_SPECS, "rear": CRASH.M310_M314_M110_REAR_SPI_SPECS,
                     "near": CRASH.M310_M314_M110_SPI_SPECS}
# canc_config names HPCC_1_100's node HPCC; the variant code calls it HPC_C (as the combined scripts).
SNR_NODE_OVERRIDE = {"HPCC_1_100": "HPC_C"}
# Part 563 reporting sign of delta-V per crash type and axis (edr-agent 4.4; 0 = not checked).
DELTA_V_REPORT_SIGN = {"front": {"long": -1, "lat": 0}, "near": {"long": -1, "lat": 0}, "rear": {"long": 1, "lat": 0},
                       "left": {"long": 0, "lat": 1}, "right": {"long": 0, "lat": -1}}
# Crash DTCs per crash type. Front: the M210 EDR CAN-C scripts. Left, right, rear: configuration_control
# codes as the U171 crash scripts expect them (not yet seen on an M210 bench).
CRASH_DTCS = {"front": [CC.Crash_DTC, CC.PT_Crash_DTC], "left": [CC.Side_Crash_DTC, CC.PT_Crash_DTC],
              "right": [CC.Side_Crash_DTC, CC.PT_Crash_DTC], "rear": [CC.Rear_Crash_DTC], "near": []}
SCRIPTS = {
    "parameters": "M210_EDR_CANC_Parameters",
    "faults": "M210_EDR_CANC_Faults",
    "crash": "M210_EDR_Crash_Parameters",
    "multi_event": "M210_EDR_Multi_Event_Matrix",
}
FAULT_CASES = [
    ("NODE_ABSENT_FULL", "NA_Full", "node_absent", "full", "Node absent over the whole interval"),
    ("NODE_ABSENT_PRE", "NA_Pre", "node_absent", "pre", "Node absent before T0 only"),
    ("NODE_ABSENT_POST", "NA_Post", "node_absent", "post", "Node absent after T0 only"),
    ("MESSAGE_TIMEOUT_FULL", "MTO_Full", "message_timeout", "full", "Message timeout over the whole interval"),
    ("MESSAGE_TIMEOUT_PRE", "MTO_Pre", "message_timeout", "pre", "Message timeout before T0 only"),
    ("MESSAGE_TIMEOUT_POST", "MTO_Post", "message_timeout", "post", "Message timeout after T0 only"),
    ("MESSAGE_CONTENT_FULL", "MCF_Full", "message_content", "full", "Message content failure (CRC) over the whole interval"),
    ("MESSAGE_CONTENT_PRE", "MCF_Pre", "message_content", "pre", "Message content failure (CRC) before T0 only"),
    ("MESSAGE_CONTENT_POST", "MCF_Post", "message_content", "post", "Message content failure (CRC) after T0 only"),
    ("SIGNAL_CONTENT_FULL", "SCF_Full", "signal_content", "full", "Signal content failure (invalid code) over the whole interval"),
    ("SIGNAL_CONTENT_PRE", "SCF_Pre", "signal_content", "pre", "Signal content failure (invalid code) before T0 only"),
    ("SIGNAL_CONTENT_POST", "SCF_Post", "signal_content", "post", "Signal content failure (invalid code) after T0 only"),
    ("SIGNAL_NEVER_RECEIVED", "SNR", "signal_never_received", "full", "Signal never received (sender cleared from the variant code)"),
    ("VARIANT_CODE_ERROR", "VC", "variant_code_error", "full", "Variant code error (variant status bit cleared)"),
    ("UNDER_VOLTAGE_FULL", "UV_Full", "under_voltage", "full", "Under-voltage over the whole interval"),
    ("UNDER_VOLTAGE_PRE", "UV_Pre", "under_voltage", "pre", "Under-voltage before T0 only"),
    ("UNDER_VOLTAGE_POST", "UV_Post", "under_voltage", "post", "Under-voltage after T0 only"),
    ("OVER_VOLTAGE_FULL", "OV_Full", "over_voltage", "full", "Over-voltage over the whole interval"),
    ("OVER_VOLTAGE_PRE", "OV_Pre", "over_voltage", "pre", "Over-voltage before T0 only"),
    ("OVER_VOLTAGE_POST", "OV_Post", "over_voltage", "post", "Over-voltage after T0 only"),
]


class BuildError(Exception):
    pass


# ---- JScript literals ---------------------------------------------------------------------------

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
# Words JScript .NET reserves (keywords and type names): quoted as object keys.
RESERVED_WORDS = {
    "abstract", "boolean", "break", "byte", "event", "case", "catch", "char", "class", "const", "continue", "debugger", "decimal",
    "default", "delete", "do", "double", "else", "enum", "export", "extends", "false", "final", "finally", "float", "for",
    "function", "get", "goto", "if", "implements", "import", "in", "instanceof", "int", "interface", "internal", "long",
    "native", "new", "null", "package", "private", "protected", "public", "return", "sbyte", "set", "short", "static",
    "super", "switch", "synchronized", "this", "throw", "throws", "transient", "true", "try", "typeof", "uint", "ulong",
    "ushort", "var", "void", "volatile", "while", "with",
}


def js_key(name: str) -> str:
    return name if IDENTIFIER.match(name) and name not in RESERVED_WORDS else js(name)


def js(value) -> str:
    """A JScript literal for plain data; non-ASCII characters escaped (the scripts stay ASCII)."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(int(value)) if value == int(value) and abs(value) < 1e15 else repr(round(value, 10))
    if isinstance(value, str):
        out = []
        for ch in value:
            if ch in "\\\"":
                out.append("\\" + ch)
            elif ch == "\n":
                out.append("\\n")
            elif ord(ch) < 32 or ord(ch) > 126:
                out.append("\\u%04X" % ord(ch))
            else:
                out.append(ch)
        return '"' + "".join(out) + '"'
    if isinstance(value, dict):
        parts = []
        for key, item in value.items():
            name = str(key)
            parts.append(js_key(name) + ": " + js(item))
        return "{ " + ", ".join(parts) + " }" if parts else "{}"
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(js(item) for item in value) + "]"
    raise BuildError(f"no JScript literal for {value!r}")


def js_table(name: str, rows, comment: str = "") -> str:
    lead = (f"// {comment}\n" if comment else "")
    if isinstance(rows, dict):
        body = ",\n".join("    " + js_key(str(k)) + ": " + js(v) for k, v in rows.items())
        return f"{lead}var {name} = {{\n{body}\n}};\n"
    body = ",\n".join("    " + js(row) for row in rows)
    return f"{lead}var {name} = [\n{body}\n];\n"


def hex_bytes(text) -> list[int]:
    return [int(token, 16) for token in re.sub(r"0x", " ", str(text), flags=re.I).replace(",", " ").split()]


def dtc_text(code) -> str:
    return " ".join(f"0x{b:02X}" for b in hex_bytes(code)) if code else ""


# ---- Sources ------------------------------------------------------------------------------------

def common_definitions() -> dict:
    """Labels and descriptions of the common EDR reference, by the name the project config uses."""
    text = COMMON_DOC.read_text(encoding="utf-8")
    result = {}
    for section in re.split(r"(?m)^#### ", text)[1:]:
        match = re.search(r"```python\n(.*?)\n```", section, re.S)
        if not match:
            continue
        definition = ast.literal_eval(match.group(1))
        result[definition.get("config_name")] = definition
    return result


def node_bit_map() -> tuple[dict, dict]:
    """The variant-code node map of core_functions.manage_variant_code (byte, bit) and its aliases."""
    source = (ROOT / "shared_libraries" / "core_functions.py").read_text(encoding="utf-8")
    bits = re.search(r"node_bit_map = (\{.*?\n        \})", source, re.S)
    aliases = re.search(r"alias_map = (\{.*?\n        \})", source, re.S)
    if not bits or not aliases:
        raise BuildError("node_bit_map / alias_map not found in core_functions.py")
    return ast.literal_eval(bits.group(1)), ast.literal_eval(aliases.group(1))


def bus_channel_frames() -> dict:
    """Bus and period of every frame the CAN-C signal definitions name."""
    frames = {}
    for definition in CANC.MAH_CAN_SIGNAL_DEFS.values():
        frame = definition.get("frame")
        if frame and frame not in frames:
            frames[frame] = {"bus": definition.get("bus") or "CANFD", "period": definition.get("periodicity") or 100}
    return frames


def library_element_names() -> set:
    """Element names the bench library reads by name (calls, the crash-type flags and its name lists)."""
    text = (TEMPLATES / "common.ts.in").read_text(encoding="utf-8")
    names = set(re.findall(r'(?:decodeFirst|checkElementValue)\(\w+, "([^"]+)"', text))
    names |= set(re.findall(r'elementNamed\("([^"]+)"\)', text))
    flags = re.search(r"var CRASH_TYPE_BITS = \{(.*?)\};", text, re.S)
    names |= set(re.findall(r':\s*"([^"]+)"', flags.group(1))) if flags else set()
    for block in re.findall(r"var (?:items|names|axes) = (\[.*?\]);", text, re.S):
        names |= {n for n in re.findall(r'"([^"]+)"', block) if n not in ("long", "lat")}
    return names


def element_records(definitions: dict, can_elements: set) -> list[dict]:
    rows = []
    for parameter in EDR.EDR_PARAMETERS:
        name = parameter["name"]
        kind = parameter["type"]
        row = {"name": name, "type": kind, "start": parameter["data_start_byte"], "length": parameter["data_byte_length"],
               "bits": parameter.get("data_bit_length") or 8, "bytesPerSample": parameter.get("data_bytes_per_sample") or 1,
               "samples": parameter.get("data_samples_number") or 1, "signed": bool(parameter.get("signed")),
               "scale": parameter.get("scaling_factor", 1) or 1, "offset": parameter.get("offset", 0) or 0,
               "unit": parameter.get("unit") or "", "min": parameter.get("minimum"), "max": parameter.get("maximum"),
               "labels": None, "startS": None, "stepS": None, "ev": "EV" in (parameter.get("variants") or []),
               "can": name in can_elements}
        sample_range = parameter.get("sample_range")
        if sample_range:
            row["startS"] = sample_range["start"]
            row["stepS"] = sample_range["step"]
        if kind in ("bit", "bits"):
            field = str(parameter["range"])
            first, last = field.split("-")[0], field.split("-")[-1]
            low, high = int(first.split(".")[1]), int(last.split(".")[1])
            row.update({"byteNumber": int(first.split(".")[0]), "low": min(low, high), "high": max(low, high)})
            row["samplesBits"] = abs(high - low) + 1
        elif kind == "custom_bits":
            row["positions"] = [[int(t.split(".")[0]), int(t.split(".")[1])] for t in parameter["range"]]
            row["samplesBits"] = len(row["positions"])
        elif kind == "multi_sample_bytes":
            row["samplesBits"] = row["bytesPerSample"] * 8
        elif kind == "multi_sample_bits":
            if parameter.get("data_first_bit_offset"):
                raise BuildError(f"{name}: data_first_bit_offset is not decoded by the framework or these scripts")
            row["samplesBits"] = row["bits"]
        elif kind == "int":
            row["samplesBits"] = row["length"] * 8
        else:
            raise BuildError(f"{name}: unknown element type {kind}")
        common = definitions.get(name)
        if common and common.get("labels") and common.get("data_bit_length") == parameter.get("data_bit_length"):
            row["labels"] = {str(k): v for k, v in common["labels"].items()}
        rows.append(row)
    return rows


def series_records(parameters: list[dict], frames: dict, bits_map: dict, aliases: dict) -> tuple[list[dict], list[str]]:
    signals = CANC.MAH_CAN_SIGNAL_DEFS
    elements = {p["name"]: p for p in EDR.EDR_PARAMETERS}
    rows, problems = [], []
    for entry in parameters:
        definition = signals[entry["signal"]]
        number = entry["series"]
        logic = definition.get("fault_logic") or {}
        frame = definition["frame"]
        crc = CANC.choose_message_content_failure_signal(frame) or ""
        node = SNR_NODE_OVERRIDE.get(frame) or (CANC.CAN_TX_MESSAGE_CONFIG.get(frame) or {}).get("key_node") or ""
        node = node.upper().replace("-", "_")
        node = aliases.get(node, node)
        if node and node not in bits_map:
            problems.append(f"series {number}: node {node} is not in the variant-code map")
        values = definition.get(f"TestCase_{number}_Values") or []
        element = elements.get(entry["element"])
        if element is None:
            raise BuildError(f"series {number}: no edr_config element {entry['element']}")
        if entry["follows"] is None and len(values) != (element.get("data_samples_number") or 1) and (element.get("data_samples_number") or 1) > 1:
            problems.append(f"series {number}: {len(values)} values for {element.get('data_samples_number')} samples")
        if not values and entry["follows"] is None:
            raise BuildError(f"series {number}: no TestCase_{number}_Values")
        sample_range = element.get("sample_range")
        if sample_range and entry["follows"] is None:
            half = sample_range["step"] * 500
            if half <= (definition.get("periodicity") or 0) + 20:
                problems.append(f"series {number}: half step {half} ms is not longer than the frame period plus 20 ms")
        mcf = (CANC.get_message_content_failure_dtcs(frame) or {}).get(crc) if crc else None
        default = definition.get("Default_Value")
        if any(tag.startswith(("SNR", "VC")) for tag in entry["tags"]) and default is None \
                and not definition.get(f"TestCase_{number}_SNR_Values") and not definition.get(f"TestCase_{number}_VC_Values"):
            problems.append(f"series {number}: no Default_Value for the signal never received / variant code cases")
        rows.append({
            "series": number, "key": entry["signal"], "element": entry["element"], "follows": entry["follows"],
            "bus": definition.get("bus") or "CANFD", "frame": frame, "signal": definition["signal"],
            "bits": definition.get("bit_length"), "factor": definition.get("Factor", 1), "offset": definition.get("Offset", 0),
            "unit": definition.get("UNIT") or "", "period": definition.get("periodicity") or frames.get(frame, {}).get("period", 100),
            "defaultRaw": default if default is not None else 0,
            "values": values,
            "invalid": definition.get(f"TestCase_{number}_Invalid_Values") or [],
            "reserved": definition.get(f"TestCase_{number}_Reserved_Values") or [],
            "oor": definition.get(f"TestCase_{number}_OutofRange_Values") or [],
            "snr": definition.get(f"TestCase_{number}_SNR_Values") or None,
            "vc": definition.get(f"TestCase_{number}_VC_Values") or None,
            "keyFrame": logic.get("key_message") or "", "timeoutFrame": logic.get("non_key_timeout_frame") or "",
            "crc": crc, "node": node if node in bits_map else "",
            "dtc": {
                "na": dtc_text(CANC.resolve_dtc_for_event("node_absent", logic.get("key_message"))) if logic.get("key_message") else "",
                "mto": dtc_text(CANC.resolve_dtc_for_event("message_timeout", logic.get("non_key_timeout_frame")))
                if logic.get("non_key_timeout_frame") else "",
                "scf": dtc_text(CANC.resolve_dtc_for_event("signal_invalid", frame, definition["signal"])),
                "mcf": dtc_text(mcf),
            },
            "tags": sorted(entry["tags"]),
        })
        # A case the per-case scripts have must have what it needs here.
        tags = entry["tags"]
        if any(t.startswith("NA_") for t in tags) and not rows[-1]["dtc"]["na"] and entry["follows"] is None:
            problems.append(f"series {number}: node absent case without a node absent DTC")
        if any(t.startswith("MTO_") for t in tags) and not rows[-1]["timeoutFrame"]:
            problems.append(f"series {number}: message timeout case without a timeout frame")
        if any(t.startswith("MCF_") for t in tags) and not crc:
            problems.append(f"series {number}: message content case without a CRC signal")
        if any(t.startswith("SCF_") for t in tags) and not rows[-1]["invalid"]:
            problems.append(f"series {number}: signal content case without an invalid code")
    return rows, problems


def frame_table(series: list[dict], frames: dict, extra: list[str]) -> dict:
    names = []
    for row in series:
        for name in (row["frame"], row["keyFrame"], row["timeoutFrame"]):
            if name and name not in names:
                names.append(name)
    for name in extra:
        if name and name not in names:
            names.append(name)
    table = {}
    for name in names:
        info = frames.get(name) or {"bus": "CANFD", "period": 100}
        crc = CANC.choose_message_content_failure_signal(name) or ""
        table[name] = {"bus": info["bus"], "period": info["period"], "crc": crc}
    return table


def crash_set(rsu_specs, spi_specs) -> dict:
    rsu = []
    for spec in rsu_specs:
        channel, token, inverted = spec[0], spec[1], spec[2]
        rsu.append([int(str(channel).replace("RSU_CH", "")), token, bool(inverted)])
    spi = [[spec[0], bool(spec[1])] for spec in spi_specs]
    if len(spi) != 4:
        raise BuildError("the GEN6_XY SPI set needs 4 axes")
    return {"rsu": rsu, "spi": spi}


def expected_delta_v(work: Path) -> dict:
    """Delta-V each standard crash set gives (offline integration of the curves, did-expected)."""
    result = {}
    for crash_type in STANDARD_TYPES:
        out = work / crash_type
        command = [sys.executable, str(CURVE_RUNNER), "did-expected", "--curves", str(CRASH_ROOT / f"{crash_type}_crash"),
                   "--output", str(out), "--project", "M210"]
        completed = subprocess.run(command, capture_output=True, text=True)
        if completed.returncode != 0:
            raise BuildError(f"did-expected {crash_type}: {completed.stderr.strip()[-400:]}")
        with (out / "did_0455_expected_record_1.csv").open(encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        value = lambda row: round(float(row["Calculated Physical Value"]), 3)
        series = {"long": [], "lat": []}
        maxima = {}
        for row in rows:
            name = row["Parameter"]
            if " - DeltaVLong at " in name:
                series["long"].append(value(row))
            elif " - DeltaVLat at " in name:
                series["lat"].append(value(row))
            elif name.endswith("- MaxDeltaVLgt"):
                maxima["longMax"] = value(row)
            elif name.endswith("- MaxDeltaVLat"):
                maxima["latMax"] = value(row)
            elif name.endswith("- TimeMaxDeltaVLgt"):
                maxima["longTimeMs"] = value(row)
            elif name.endswith("- TimeMaxDeltaVLat"):
                maxima["latTimeMs"] = value(row)
        if len(series["long"]) != 26 or len(series["lat"]) != 26 or len(maxima) != 4:
            raise BuildError(f"did-expected {crash_type}: unexpected rows")
        t0_ms = round(float(rows[0]["T0 (ms)"]), 3)
        result[crash_type] = {"long": series["long"], "lat": series["lat"], **maxima, "curveT0Ms": t0_ms}
    return result


def multi_event_tests() -> tuple[list[dict], dict]:
    """Every merged set with the records the EV specification's allocation rules expect."""
    tests, sets = [], {}
    for key, (events, delays) in CRASH.MULTI_EVENT_SETS.items():
        cls = key.split("_")[0]
        sets[key] = crash_set(RSU_SPECS, CRASH._multi_event_spi_specs(events, SPI_SPECS_BY_TYPE))
        # Events: a gap of 500 ms or less is the same event; 500 ms to 5 s a multi-event, more than 5 s a
        # single event; exactly 5 s is in neither rule.
        sequence: list[dict] = []
        at = 0
        for index, crash_type in enumerate(events):
            gap = delays[index - 1] if index > 0 else 0
            at += gap
            deploy = crash_type != "near"
            if index > 0 and gap <= 500:
                last = sequence[-1]
                last["deploy"] = last["deploy"] or deploy
                if crash_type not in last["types"] and crash_type not in last["free"]:
                    last["free"].append(crash_type)
                continue
            if not sequence:
                men, tbe, known = 1, None, True
            elif gap < 5000:
                previous_men = sequence[-1]["men"]
                men, tbe, known = (previous_men + 1 if previous_men else None), at - sequence[-1]["at"], True
            elif gap > 5000:
                men, tbe, known = 1, None, True
            else:
                men, tbe, known = None, None, False
            sequence.append({"types": [crash_type], "free": [], "deploy": deploy, "men": men, "tbe": tbe, "known": known, "at": at})
        # A near crash that a deploying crash joined within 500 ms is no longer a near event: none of its
        # direction flags is stated, so they are reported only.
        for event in sequence:
            if event["free"] and event["types"] == ["near"] and event["deploy"]:
                event["free"] = ["near"] + event["free"]
                event["types"] = []
        # Two records: an event takes a free one, else overwrites the oldest unlocked one, else is lost.
        buffers = [-1, -1]
        for index, event in enumerate(sequence):
            event["len"] = index + 1
            event["lock"] = 1 if event["deploy"] else 0
            free = [i for i, b in enumerate(buffers) if b < 0]
            if free:
                buffers[free[0]] = index
                continue
            unlocked = [i for i, b in enumerate(buffers) if sequence[b]["lock"] == 0]
            if unlocked:
                buffers[min(unlocked, key=lambda i: buffers[i])] = index
        records = []
        for slot in buffers:
            if slot < 0:
                records.append({"eventNo": 0, "types": [], "free": [], "len": None, "men": None, "tbeMs": None, "tbeKnown": True, "lock": None})
                continue
            event = sequence[slot]
            records.append({"eventNo": slot + 1, "types": event["types"], "free": event["free"], "len": event["len"],
                            "men": event["men"], "tbeMs": event["tbe"], "tbeKnown": event["known"], "lock": event["lock"]})
        rules = {"parallel": "parallel: the second T0 falls inside the first event (500 ms or less): one event, one record",
                 "concatenated": "concatenated: the second T0 follows the first event's end, 500 ms or less after its T0: one event, one record",
                 "multi": "multi-event: more than 500 ms and less than 5 s between T0s (EV spec)",
                 "single": "single events: 5 s or more between T0s (EV spec)",
                 "boundary": "boundary of the record allocation timing (500 ms or less: one event; to 5 s: multi; over 5 s: single; 5 s itself: not stated)"}
        tests.append({
            "id": "MULTI_" + key.upper(), "setKey": key, "cls": cls, "folder": f"multi_crash_{key}", "path": "",
            "title": f"{cls}: {' -> '.join(events)}" + (f", {', '.join(str(d) for d in delays)} ms T0 to T0" if delays else ""),
            "events": list(events), "delays": list(delays), "lastEventMs": sum(delays),
            "crashTypes": sorted(set(events)), "records": records, "rule": rules[cls],
        })
    return tests, sets


# ---- Rendering ----------------------------------------------------------------------------------

def data_block(context: dict, script: str) -> str:
    parts = ["", "// ---- Data (M210 configuration; the README lists the sources) ----------------------------------", ""]
    parts.append(f'var SCRIPT_NAME = {js(SCRIPTS[script])};')
    parts.append(f'var DATA_SOURCE = {js(context["source"])};')
    parts.append(f'var RECORD_DIDS = {js(context["record_dids"])};')
    parts.append(f'var RECORD_LENGTH = {context["record_length"]};')
    parts.append(f'var EOL_DID = {js(hex_bytes(CC.EOL_DID))};')
    parts.append(f'var VARIANT_CODE_DID = {js(hex_bytes(CC.VARIANT_CODE_DID))};')
    parts.append(f'var VIN_DID = {js(hex_bytes("0xF1 0x90"))};')
    parts.append(f'var DEFAULT_EOL_CODE = {js(hex_bytes(PROJECT.DEFAULT_EOL_CODE))};')
    parts.append(f'var DEFAULT_VARIANT_CODE = {js(hex_bytes(PROJECT.DEFAULT_VARIANT_CODE))};')
    parts.append(f'var BENCH_VIN = {js(hex_bytes(CC.VIN_STRATEGY_OPTIONS["sample_32"]))};')
    parts.append(f'var VIN_SIGNAL = {js(context["vin_signal"])};')
    parts.append(f'var NVM_CLEAR_ROUTINES = {js(list(CC.NVM_CLEAR_RIDS))};')
    parts.append(f'var DTC_STATUS = {js(context["dtc_status"])};')
    parts.append(f'var VARIANT_CODE_DTC = {js(dtc_text(CC.Variant_Code_DTC))};')
    parts.append(f'var UNDER_VOLTAGE_DTC = {js(dtc_text(CC.Under_Voltage))};')
    parts.append(f'var OVER_VOLTAGE_DTC = {js(dtc_text(CC.Over_Voltage))};')
    parts.append(js_table("CRASH_DTCS", {k: [dtc_text(c) for c in v] for k, v in CRASH_DTCS.items()}))
    parts.append(js_table("VARIANT_CODE_BITS", context["variant_bits"], "Variant code (DID 0x0101): node -> [byte, mask]"))
    parts.append(f'var BUSES_USED = {js(context["buses"])};')
    parts.append(f'var CLOCK_FORMAT_24_HOUR = {context["clock_format_24"]};')
    parts.append(js_table("CLOCK_SIGNAL_DEFS", context["clock_defs"]))
    parts.append(js_table("FRAMES", context["frames"], "Every frame the scripts touch: bus, period (ms), CRC signal"))
    parts.append(js_table("CRASH_SETS", context["crash_sets"], "Standard crash sets: RSU [channel, curve name, inverted], GEN6_XY [curve name, inverted]"))
    parts.append(js_table("DELTA_V_EXPECTED", context["delta_v"], "Delta-V (km/h) of each standard set, integrated offline from its curves"))
    parts.append(js_table("DELTA_V_REPORT_SIGN", DELTA_V_REPORT_SIGN))
    parts.append(js_table("DEPLOYMENT_LOOPS", context["deployment_loops"]))
    parts.append("// Loops each crash type must deploy on M210: not stated in the configuration (open item); add\n"
                 "// e.g. front: [\"Driver Airbag squib\", \"Passenger Airbag squib\"] to check the deployed set.\n"
                 "var DEPLOYMENT_EXPECTED = {};\n")
    parts.append(js_table("IMU_AT_REST", context["imu"], "canc_config CANC_IMU_STATIC_EXPECTED / _TOLERANCE: [value, tolerance]"))
    parts.append(js_table("RESERVED_ALLOCATIONS", context["reserved"]))
    parts.append(js_table("ELEMENTS", context["elements"], "edr_config EDR_PARAMETERS; labels from the common EDR reference"))
    if script in ("parameters", "faults"):
        parts.append(js_table("QUALIFY_FRAMES", context["qualify"], "canc_config FAULT_THRESHOLDS: frames to qualify"))
        parts.append(f'var WAKEUP = {js(context["wakeup"])};')
        parts.append(js_table("SERIES", context["series"], "CAN-C series (canc_config MAH_CAN_SIGNAL_DEFS; tags from the per-case scripts)"))
    if script == "multi_event":
        parts.append(js_table("MULTI_CRASH_SETS", context["multi_sets"]))
        parts.append(js_table("MULTI_EVENT_TESTS", context["multi_tests"],
                              "path: the folder of the set's curves (empty: MULTI_EVENT_ROOT + folder)"))
    return "\n".join(parts) + "\n"


def render(script: str, context: dict) -> str:
    template = (TEMPLATES / f"{script}.ts.in").read_text(encoding="utf-8")
    settings = (TEMPLATES / "settings.ts.in").read_text(encoding="utf-8")
    for key, value in context["settings"].items():
        settings = settings.replace(f"@@{key}@@", value)
    text = template.replace("@@SETTINGS@@", settings).replace("@@DATA@@", data_block(context, script))
    text = text.replace("@@COMMON@@", (TEMPLATES / "common.ts.in").read_text(encoding="utf-8"))
    text = text.replace("@@ENGINE@@", (TEMPLATES / "can_engine.ts.in").read_text(encoding="utf-8"))
    for key, value in context["script_values"].items():
        text = text.replace(f"@@{key}@@", value)
    if "@@" in text:
        raise BuildError(f"{script}: placeholder left: {re.findall(r'@@[A-Z_]+@@', text)[:5]}")
    if any(ord(ch) > 126 for ch in text):
        raise BuildError(f"{script}: non-ASCII character in the script")
    return text.replace("\r\n", "\n").replace("\n", "\r\n")


def build_context(work: Path) -> tuple[dict, list[str]]:
    settings_m210 = {"project": "M210", "scripts": ROOT / "projects" / "M210" / "modules" / "EDR_CANC" / "scripts"}
    parameters = combined.read_parameters(settings_m210)
    frames = bus_channel_frames()
    bits_map, aliases = node_bit_map()
    series, problems = series_records(parameters, frames, bits_map, aliases)
    definitions = common_definitions()
    can_elements = {row["element"] for row in series}
    elements = element_records(definitions, can_elements)
    names = {row["name"] for row in elements}
    missing = sorted(library_element_names() - names)
    if missing:
        raise BuildError(f"the bench library reads elements edr_config does not define: {', '.join(missing)}")
    record_length = max(p["data_end_byte"] for p in EDR.EDR_PARAMETERS if "EV" in (p.get("variants") or []))
    for row in series:
        if row["element"] not in names:
            raise BuildError(f"series {row['series']}: element {row['element']} missing")
    vin = CANC.CAN_VIN_NUMBER
    wake = {
        "bus": CANC.CAN_WAKEUP_REQUEST_CHANNEL, "frame": CANC.CAN_WAKEUP_REQUEST_FRAME, "signal": CANC.CAN_WAKEUP_REQUEST_SIGNAL,
        "value": CANC.CAN_WAKEUP_REQUEST_VALUE, "release": CANC.CAN_WAKEUP_RELEASE_VALUE,
        "statusBus": CANC.CAN_CRASH_FRAME_CHANNEL_MAP["M210"].get(CANC.CAN_WAKEUP_STATUS_FRAME, "CANFD"),
        "statusFrame": CANC.CAN_WAKEUP_STATUS_FRAME, "statusSignal": CANC.CAN_WAKEUP_STATUS_SIGNAL, "statusValue": CANC.CAN_WAKEUP_STATUS_VALUE,
        "nmBus": CANC.CAN_CRASH_FRAME_CHANNEL_MAP["M210"].get(CANC.CAN_NM_SRS_FRAME, "CANFD"), "nmFrame": CANC.CAN_NM_SRS_FRAME,
        "nmSignal": CANC.CAN_RX_MESSAGE_CONFIG[CANC.CAN_NM_SRS_FRAME]["signals"][0],
        "sleepMs": CANC.CAN_WAKEUP_BUS_SLEEP_WAIT_MS, "startupMs": CANC.NM_IGN_ON_STARTUP_DELAY_MS,
    }
    clock_map = [("CAN_CLOCK_DATE", "day"), ("CAN_CLOCK_MONTH", "month"), ("CAN_CLOCK_YEAR", "year"), ("CAN_CLOCK_HOUR", "hour"),
                 ("CAN_CLOCK_MIN", "minute"), ("CAN_CLOCK_FORMAT", "format")]
    clock_defs = []
    for variable, field in clock_map:
        definition = getattr(CANC, variable)
        clock_defs.append({"field": field, "bus": definition.get("bus") or "CANFD", "frame": definition["frame"],
                           "signal": definition["signal"], "bits": definition["bit_length"], "factor": definition["Factor"],
                           "offset": definition["Offset"]})
    clock_format_24 = next(v for k, v in CANC.CAN_CLOCK_FORMAT["State_Values"].items() if "24" in k)
    frames_used = frame_table(series, frames, [vin["frame"], wake["frame"], clock_defs[0]["frame"]])
    buses = sorted({row["bus"] for row in series} | {row["bus"] for row in frames_used.values()})
    deployment = []
    for row in EDR.EDR_PARAMETERS:
        if row["name"].endswith(" - Deployment Time") and "EV" in (row.get("variants") or []):
            label = row["name"][: -len(" - Deployment Time")]
            status = label + " - Deployment Status"
            if status in names:
                deployment.append({"label": label, "time": row["name"], "status": status})
    imu = {}
    for key, value in CANC.CANC_IMU_STATIC_EXPECTED.items():
        element = "LATERAL_ACCEL" if key == "LATTERAL_ACCEL" else key
        if element not in names:
            problems.append(f"IMU element {element} not in edr_config")
            continue
        imu[element] = [value, CANC.CANC_IMU_STATIC_TOLERANCE[key]]
    reserved = [{"byteNumber": r["data_byte"], "bytes": r["byte_length"], "low": r["low_bit"], "high": r["high_bit"]} for r in EDR.RESERVED_ALLOCATIONS]
    multi_tests, multi_sets = multi_event_tests()
    t0_offsets = {RSU.RSU_T0_OFFSETS.get(t, RSU.RSU_T0_OFFSETS["default"]) for t in STANDARD_TYPES}
    if len(t0_offsets) != 1:
        problems.append("rsu_config RSU_T0_OFFSETS differ per crash type; the scripts use one offset")
    context = {
        "source": "projects/M210/config (canc_config, edr_config, project_config, power_config, rsu_config); "
                  "shared_libraries/configuration_control.py and crash_configuration.py; docs/project_documents/EDR_Spec Common/"
                  "EDR_COMMON_PARAMETERS.md (labels); crash_data/m310_m314_m110 curves (expected delta-V)",
        "record_dids": [[(did >> 8) & 0xFF, did & 0xFF] for did in EDR.EDR_DIDS.values()],
        "record_length": record_length,
        "vin_signal": {"bus": vin.get("bus") or "CANFD", "frame": vin["frame"], "signal": vin["signal"]},
        "dtc_status": {"active": int(CC.DTC_status["DTC_active"], 16), "activeLampOff": int(CC.DTC_status["DTC_active_WLOFF"], 16),
                       "healed": int(CC.DTC_status["DTC_healed"], 16), "historic": int(CC.DTC_status["DTC_historic"], 16)},
        "variant_bits": {node: [byte, 1 << bit] for node, (byte, bit) in bits_map.items()},
        "buses": buses, "clock_defs": clock_defs, "clock_format_24": clock_format_24,
        "frames": frames_used,
        "crash_sets": {t: crash_set(RSU_SPECS, SPI_SPECS_BY_TYPE[t]) for t in STANDARD_TYPES},
        "delta_v": expected_delta_v(work),
        "deployment_loops": deployment, "imu": imu, "reserved": reserved, "elements": elements,
        "qualify": {mode: count for mode, (count, _) in CANC.FAULT_THRESHOLDS.items()},
        "wakeup": wake, "series": series, "multi_sets": multi_sets, "multi_tests": multi_tests,
        "settings": {
            "DIAG_TX_ID": f"0x{PROJECT.DIAG_TX_ID:03X}", "DIAG_RX_ID": f"0x{PROJECT.DIAG_RX_ID:03X}",
            "READ_DTC_REQUEST": CC.Read_DTC_Req, "NOMINAL_VOLTAGE": js(float(POWER.NOMINAL_VOLTAGE)),
            "UNDERVOLTAGE_TEST_VOLTAGE": js(float(POWER.UNDERVOLTAGE_TEST_VOLTAGE)),
            "OVERVOLTAGE_TEST_VOLTAGE": js(float(POWER.OVERVOLTAGE_TEST_VOLTAGE)),
            "EDR_READ_SECURITY_LEVEL": f"0x{EDR.EDR_DECODER_CONFIG['read']['security_access_level']:02X}",
            "CRASH_DATA_ROOT": BENCH_CRASH_ROOT.replace("\\", "\\\\"), "T0_OFFSET_MS": str(next(iter(t0_offsets))),
            "RECORD_READY_MS": str(EDR.EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]),
            "DELTA_V_TOLERANCE_KMH": str(CANC.CANC_DELTA_V_TOLERANCE_KMH),
        },
        "script_values": {
            "NM_RESTART_DELAY_MS": str(max(CANC.NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS, CANC.NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS)),
            "DTC_TIMING_TOLERANCE_PERCENT": js(float(CANC.CAN_FAULT_TIMING_TOLERANCE_PERCENT)),
            "DTC_READ_EXTRA_WAIT_MS": str(CANC.DTC_READ_EXTRA_WAIT_MS),
            "HOUSEKEEPING_MAX_DELAY_MS": str(EDR.HOUSEKEEPING_CRASH_TRIGGER_MAX_DELAY_MS),
            "FAULT_CASES": ",\n".join(
                "    { id: %s, title: %s, tag: %s, mode: %s, scope: %s, valueSet: \"nominal\", wake: \"\", cycleSnapshots: false }"
                % (js(c[0]), js(c[4]), js(c[1]), js(c[2]), js(c[3])) for c in FAULT_CASES),
        },
    }
    return context, problems


def main() -> int:
    parser = argparse.ArgumentParser(description=(__doc__ or "").split("\n\n")[0])
    parser.add_argument("--check", action="store_true", help="compare with the files on disk, write nothing")
    args = parser.parse_args()
    try:
        with tempfile.TemporaryDirectory() as work:
            context, problems = build_context(Path(work))
        outputs = {f"{name}.ts": render(script, context) for script, name in SCRIPTS.items()}
    except BuildError as error:
        print(f"build_m210_edr_ts: {error}")
        return 2
    for problem in problems:
        print(f"note: {problem}")
    stale = []
    for name, text in outputs.items():
        path = OUT / name
        if args.check:
            if not path.exists() or path.read_bytes() != text.encode("ascii"):
                stale.append(name)
        else:
            OUT.mkdir(parents=True, exist_ok=True)
            path.write_bytes(text.encode("ascii"))
    if args.check:
        print("up to date" if not stale else "stale: " + ", ".join(stale))
        return 1 if stale else 0
    series = context["series"]
    print(f"wrote {len(outputs)} scripts to {OUT}: {len(series)} CAN-C series, {len(context['elements'])} elements, "
          f"{len(context['multi_tests'])} multi-event sets")
    return 0


if __name__ == "__main__":
    sys.exit(main())
