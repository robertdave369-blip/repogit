"""
Module Configuration: DCS
Project: U171
============================================================

Location: projects/U171/config/dcs_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is DCS
    ctx.get_module_config("DCS").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "DCS"



# ── DCS Settings ──


# List of seat logical names
SLSName = [
    "DCS_DRVR",
    "DCS_PSGR",
    "DCS_Second_Row_Right",
    "DCS_Second_Row_Middle",
    "DCS_Second_Row_Left",
    "DCS_Third_Row_Right",
    "DCS_Third_Row_Left"]
# Mapping: logical name -> seat number
DCSNumber = {
    "DCS_DRVR": 1,
    "DCS_PSGR": 2,
    "DCS_Second_Row_Right": 3,
    "DCS_Second_Row_Middle": 4,
    "DCS_Second_Row_Left": 5,
    "DCS_Third_Row_Right": 6,
    "DCS_Third_Row_Left": 7
}

# Mapping: logical name -> software channel name
DCSName = {
    "DCS_DRVR": "SW_Channel_DCS_1",
    "DCS_PSGR": "SW_Channel_DCS_2",
    "DCS_Second_Row_Right": "SW_Channel_DCS_3",
    "DCS_Second_Row_Middle": "SW_Channel_DCS_4",
    "DCS_Second_Row_Left": "SW_Channel_DCS_5",
    "DCS_Third_Row_Right": "SW_Channel_DCS_6",
    "DCS_Third_Row_Left": "SW_Channel_DCS_7"
}

# Mapping: logical name -> CAN signal name (for front seats)
DCSSignal = {
    "DCS_DRVR": "STS_SEAT_BLT_DRV",
    "DCS_PSGR": "STS_SEAT_BLT_PSGR"
}

# Mapping: logical name -> seat number (duplicate of DCSNumber)
SLSNumber = DCSNumber.copy()

# Mapping: logical name -> DTC code for DCS fault
DTC_DCS_fault = {
    "PAB_Switch": "0x92 0x05",
    "DCS_DRVR": "0x90 0x33",
    "DCS_PSGR": "0x90 0x32",
    "DCS_Second_Row_Right": "0x92 0x43",
    "DCS_Second_Row_Middle": "0x92 0x44",
    "DCS_Second_Row_Left": "0x92 0x42",
    "DCS_Third_Row_Left": "0x92 0x45",
    "DCS_Third_Row_Right": "0x92 0x46",
    "ENS": "0x92 0x18"
}

# Mapping: logical name -> DTC code for DCS cross-connect fault
DTC_DCS_CC_fault = {
    "DCS_DRVR": "0x92 0x53",
    "DCS_PSGR": "0x92 0x54"
}

# Mapping: fault type -> code
DCS_FaultTypeCode = {
    "HiRes": "0x1B",
    "Open": "0x13",
    "LowRes": "0x1A",
    "S2B": "0x12",
    "S2G": "0x11",
    "Invalid_Res": "0x1E",
    "CrossConnect": "0x2B",
    "UNEX": "0x64"
}

# Mapping: fault type -> description
DCS_Fault_Description = {
    "S2B": "BUSS_HI_ON",
    "CrossConnect": "BUSS_HI_ON",
    "buckle": "800R",
    "unbuckle": "200R",
    "PAB_unbuckle": "100R",
    "PAB_buckle": "400R"
}

# Fault timing configuration
DCS_fault_time = {
    "Qualification": 3200,
    "Qualification_CC": 1900,
    "Qualification_Tolerance": 10,
    "Dequalification": 3200,
    "Dequalification_CC": 1900,
    "Dequalification_Tolerance": 10,
    "dcs_faultcounter_offset": 10
}
# Bit mapping for rear/third row seats in PSGR_REAR_SEAT_BELT
REAR_SEAT_BIT_INDEX = {
    "DCS_Second_Row_Left": 0,
    "DCS_Second_Row_Middle": 1,
    "DCS_Second_Row_Right": 2,
    "DCS_Third_Row_Left": 3,
    "DCS_Third_Row_Middle": 4,
    "DCS_Third_Row_Right": 5,
}
