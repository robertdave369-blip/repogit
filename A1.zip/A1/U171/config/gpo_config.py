"""
Module Configuration: GPO
Project: U171
============================================================

Location: projects/U171/config/gpo_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is GPO
    ctx.get_module_config("GPO").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "GPO"



# ── GPO Settings ──

# List of GPO logical names
GPO_Names = [
    "ENS",
    "PAB_ON_LAMP",
    "PAB_OFF_LAMP",
]

# List of supported GPO fault names
gpo_fault_names = [
    "S2B",
    "S2G",
    "OPEN",
]

# Fault status values
fault_status_values = [
    "Active",
    "Healed",
    "Historic",
]

# Crash names
crash_names = [
    "FrontCrash",
    "LeftCrash",
    "RightCrash",
    "RearCrash",
    "UnderstrikeCrash",
]

# Mapping: logical name -> DTC code for GPO fault
DTC_GPO_fault = {
    "PAB_OFF": "0x92 0x10",  # PAB_OFF_LAMP
    "PAB_ON": "0x90 0x24",   # PAB_ON_LAMP
    "ENS": "0x92 0x18",      # ENS
}

# Mapping: fault type -> description
GPO_FaultDescription = {
    "Open": "OPEN",
    "S2B": "BUSS_HI_ON",
    "S2G": "BUSS_HI_ON",
}
    
# Mapping: fault type -> code
GPO_FaultStatus = {
    "S2B": "0x12",
    "S2G": "0x11",
    "OPEN": "0x13",
}

# Mapping: fault status -> status code
status_codex = {
    "Active": "0x8B",
    "Healed": "0x0A",
    "Historic": "0x08",
}

# Fault timing configuration
gpo_fault_time = {
    "gpo_faultcounter_offset": 10,
    "Qualification_Time": 2000,
    "Qualification_Tolerance": 10,
    "Dequalification_Time": 4000,
    "Dequalification_Tolerance": 20,
}