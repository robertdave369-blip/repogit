"""
Module Configuration: SQUIBS
Project: U171
============================================================

Location: projects/U171/config/squibs_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is SQUIBS
    ctx.get_module_config("SQUIBS").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "SQUIBS"

SquibName = [
    "RPT", "LPT", "RSA", "LSA", "RCA", "LCA", "DAB", "PAB", "DKA", "Battery_CutOFF", "RLPT", "LLPT"]

# Variant control: active loops for current variant
# For this variant, only LOOP0, LOOP1, LOOP6, LOOP9 are used.
# Keep full mappings below for higher variants; use ActiveSquibName in scripts.
# ACTIVE_SQUIB_LOOPS = {0,1,2,3,4,5,6,7,8,10,11}
ACTIVE_SQUIB_LOOPS = {0,1,2,3,4,5,6,7,8,10,11} 

# Simulator Loop number to which the ECU O/P is connected in ARiA/NeeVA
SquibNumber = {
    "RPT": 0,   # Right Pretensioner
    "LPT": 1,   # Left Pretensioner
    "RSA": 2,   # Right Side Airbag (disabled for this variant)
    "LSA": 3,   # Left Side Airbag (disabled for this variant)
    "RCA": 4,   # Right Curtain Airbag (disabled for this variant)
    "LCA": 5,   # Left Curtain Airbag (disabled for this variant)
    "DAB": 6,   # Driver Airbag
    "PAB": 7,   # Passenger Airbag
    "DKA": 8,   # Driver knee Airbag
    #"Battery_CutOFF": 9, # Battery Cutoff
    "RLPT": 10, # Right Lap Pretensioner (disabled for this variant)
    "LLPT": 11  # Left Lap Pretensioner (disabled for this variant)
}

# Derived active squib names for current variant (use in tests)
ActiveSquibName = [name for name, loop in SquibNumber.items() if loop in ACTIVE_SQUIB_LOOPS]

# SquibName to Byte Index mapping
Squib_DID_0446_ByteIndex = {
    "RPT": 0,    # Driver Pretensioner
    "DAB": 1,    # Driver Airbag
    "LPT": 2,    # Passenger Pretensioner
    "PAB": 3,    # Passenger Airbag
    "RLPT": 4,   # Driver Lap Pretensioner
    "LLPT": 5,   # Passenger Lap Pretensioner
    "RSA": 6,    # Driver Side Airbag
    "LSA": 7,    # Passenger Side Airbag
    "RCA": 8,    # Driver Curtain Airbag
    "LCA": 9,    # Passenger Curtain Airbag
    "DKA": 10,   # Driver Knee Airbag
    "Battery_CutOFF": 11  # Battery Cutoff switch
}

# Fault type codes
Squib_FaultTypeCode = {
    "HiRes": "0x1B",
    "Open": "0x13",
    "LoRes": "0x1A",
    "S2B": "0x12",
    "S2G": "0x11",
    "CrossConnect": "0x01",
    "UNEX": "0x64"
}

# DTC Squib Fault Codes
DTC_Squib_FaultCode = {
    "RPT": "0x80 0x70",   # Right Pretensioner
    "LPT": "0x80 0x72",   # Left Pretensioner
    "RSA": "0x92 0x06",   # Right Side Airbag
    "LSA": "0x92 0x08",   # Left Side Airbag
    "RCA": "0x92 0x07",   # Right Curtain Airbag
    "LCA": "0x92 0x09",   # Left Curtain Airbag
    "DAB": "0x80 0x01",   # Driver Airbag
    "PAB": "0x80 0x10",   # Passenger Airbag
    "DKA": "0x92 0x11",   # Driver Knee Airbag
    "Battery_CutOFF": "0x92 0x1D", # Battery Cutoff
    "RLPT": "0x92 0x03",  # Right Lap Pretensioner
    "LLPT": "0x92 0x04"   # Left Lap Pretensioner
}

# Squib fault timing parameters
squib_fault_time = {
    "Qualification_Time": 2000,
    "Qualification_Tolerance": 10,
    "Dequalification_Time": 4000,
    "Dequalification_Tolerance": 20
}

Squib_Fault_Description = {
    "HiRes": "HRES_FAULT",
    "LoRes": "SHORT",
    "Open": "OPEN",
    "S2B": "BUSS_HI_ON",
    "S2G": "BUSS_Lo_ON",
    "CrossConnect": "BUSS_HI_ON",
    "NoFault": "INHERENT",
    "UNEX": "UNEXPECTED"
}

# Expected DID 0x0446 status codes for specific squib states
Squib_DID_0446_ExpectedCode = {
    "NoFault": 0x00,
    "Open": 0x01,
    "S2G": 0x02,
    "S2B": 0x03,
    "LoRes": 0x04,
    "HiRes": 0x05,
    "CrossConnect": 0x06,
    "Not_Configured": 0x07
}

# DID 0x0446 code-to-description mapping for squib fault status bytes
Squib_DID_0446_CodeMap = {
    0x00: "No Fault",
    0x01: "Open fault",
    0x02: "Short to Ground",
    0x03: "Short to Battery",
    0x04: "Low Resistance",
    0x05: "High Resistance",
    0x06: "Cross Connect",
    0x07: "Not_Configured",
}