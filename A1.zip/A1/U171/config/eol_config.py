"""
Module Configuration: EOL
Project: U171
============================================================

Location: projects/U171/config/eol_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is EOL
    ctx.get_module_config("EOL").<SETTING>  # from any other module
"""

from pathlib import Path

PROJECT_NAME = "U171"
MODULE_NAME = "EOL"


EOL_DID = 0x0102
eol_positive_res = "0x6E 0x01 0x02"
EOL_POSITIVE_RESPONSE = eol_positive_res

U171_FEATURE_MAP = {
    "PASSENGER_AIRBAG": (0, 0),
    "DRIVER_AIRBAG": (0, 1),
    "LEFT_SIDE_AIRBAG": (0, 2),
    "RIGHT_SIDE_AIRBAG": (0, 3),
    "LEFT_CURTAIN_AIRBAG": (0, 4),
    "RIGHT_CURTAIN_AIRBAG": (0, 5),
    "DRIVER_KNEE_AIRBAG": (0, 6),
    # "CENTER_AIRBAG": (0, 7),
    "LEFT_PRETENSIONER_1_BELT": (1, 0),
    "RIGHT_PRETENSIONER_1_BELT": (1, 1),
    "LEFT_PRETENSIONER_2_LAP": (1, 2),
    "RIGHT_PRETENSIONER_2_LAP": (1, 3),
    # "BATTERY_CUTOFF_SWITCH": (1, 4),
    # "UNDERBODY_RSU": (1, 7),
    "LEFT_FRSU": (2, 0),
    "RIGHT_FRSU": (2, 1),
    "LEFT_SRSU": (2, 2),
    "RIGHT_SRSU": (2, 3),
    # "RIGHT_SIDE_PRESSURE_RSU": (2, 4),
    # "LEFT_SIDE_PRESSURE_RSU": (2, 5),
    "A_PILLAR_RIGHT_SRSU": (3, 0),
    "A_PILLAR_LEFT_SRSU": (3, 1),
    "PABD_SWITCH": (3, 3),
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH": (3, 5),
    # "DRIVER_SEAT_BELT_BUCKLE_SWITCH_SOURCE": (3, 6),
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH": (3, 7),
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH": (4, 1),
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH": (4, 3),
    "SECOND_ROW_LEFT_BUCKLE_SWITCH": (4, 5),
    "PABD_LAMP_HW": (5, 3),
    "PAB_ENABLE": (5, 4),
    "CRASH_OUTPUT_HW_LINE": (6, 0),
    # "NM_TEST_MESSAGE": (6, 1),
    "ALIVE_COUNTER": (6, 2),
}

U171_ENABLED_FEATURES = [
    "PASSENGER_AIRBAG",
    "DRIVER_AIRBAG",
    "LEFT_SIDE_AIRBAG",
    "RIGHT_SIDE_AIRBAG",
    "LEFT_CURTAIN_AIRBAG",
    "RIGHT_CURTAIN_AIRBAG",
    "DRIVER_KNEE_AIRBAG",
    # "CENTER_AIRBAG",
    "LEFT_PRETENSIONER_1_BELT",
    "RIGHT_PRETENSIONER_1_BELT",
    "LEFT_PRETENSIONER_2_LAP",
    "RIGHT_PRETENSIONER_2_LAP",
    "LEFT_FRSU",
    "RIGHT_FRSU",
    "LEFT_SRSU",
    "RIGHT_SRSU",
    # "RIGHT_SIDE_PRESSURE_RSU",
    # "LEFT_SIDE_PRESSURE_RSU",
    "A_PILLAR_RIGHT_SRSU",
    "A_PILLAR_LEFT_SRSU",
    "PABD_SWITCH",
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH",
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH",
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH",
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH",
    "SECOND_ROW_LEFT_BUCKLE_SWITCH",
    "PABD_LAMP_HW",
    "PAB_ENABLE",
    "CRASH_OUTPUT_HW_LINE",
    # "NM_TEST_MESSAGE",
    "ALIVE_COUNTER",
]

EOL_LOOP_FEATURES = [
    "PASSENGER_AIRBAG",
    "DRIVER_AIRBAG",
    "LEFT_SIDE_AIRBAG",
    "RIGHT_SIDE_AIRBAG",
    "LEFT_CURTAIN_AIRBAG",
    "RIGHT_CURTAIN_AIRBAG",
    "DRIVER_KNEE_AIRBAG",
    # "CENTER_AIRBAG",
    "LEFT_PRETENSIONER_1_BELT",
    "RIGHT_PRETENSIONER_1_BELT",
    "LEFT_PRETENSIONER_2_LAP",
    "RIGHT_PRETENSIONER_2_LAP",
]

EOL_LOOP_SQUIB_NAMES = {
    "PASSENGER_AIRBAG": "PAB",
    "DRIVER_AIRBAG": "DAB",
    "LEFT_SIDE_AIRBAG": "LSA",
    "RIGHT_SIDE_AIRBAG": "RSA",
    "LEFT_CURTAIN_AIRBAG": "LCA",
    "RIGHT_CURTAIN_AIRBAG": "RCA",
    "DRIVER_KNEE_AIRBAG": "DKA",
    # "CENTER_AIRBAG": "CAB",
    "LEFT_PRETENSIONER_1_BELT": "LPT",
    "RIGHT_PRETENSIONER_1_BELT": "RPT",
    "LEFT_PRETENSIONER_2_LAP": "LLPT",
    "RIGHT_PRETENSIONER_2_LAP": "RLPT",
}

EOL_RSU_FEATURES = [
    "LEFT_FRSU",
    "RIGHT_FRSU",
    "LEFT_SRSU",
    "RIGHT_SRSU",
    # "RIGHT_SIDE_PRESSURE_RSU",
    # "LEFT_SIDE_PRESSURE_RSU",
    "A_PILLAR_RIGHT_SRSU",
    "A_PILLAR_LEFT_SRSU",
]

EOL_GPO_FEATURES = [
    "PABD_LAMP_HW",
    "PAB_ENABLE",
    "CRASH_OUTPUT_HW_LINE",
]

EOL_SWITCH_DCS_FEATURES = [
    "PABD_SWITCH",
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH",
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH",
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH",
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH",
    "SECOND_ROW_LEFT_BUCKLE_SWITCH",
]

EOL_OTHER_FEATURES = [
    # "NM_TEST_MESSAGE",
    "ALIVE_COUNTER",
]

# Features that must change with Passenger Airbag during EOL configuration.
EOL_PAB_Dependencies = ["PABD_SWITCH", "PAB_ENABLE", "PABD_LAMP_HW","PASSENGER_AIRBAG"]

# Feature-wise available DTCs from DTC_EOL_BYTE_Matched.csv.
# Keep every U171 enabled feature as a key; features without CSV DTC entries use an empty list.
U171_FEATURE_AVAILABLE_DTCS = {
    "PASSENGER_AIRBAG": [
        {"dtc": "8010", "status_byte": "64", "description": "PASSENGER AIRBAG UNEXPECTED SQUIB"},
    ],
    "DRIVER_AIRBAG": [
        {"dtc": "8001", "status_byte": "64", "description": "DRIVER AIRBAG UNEXPECTED SQUIB"},
    ],
    "LEFT_SIDE_AIRBAG": [
        {"dtc": "9208", "status_byte": "64", "description": "LEFT SIDE AIRBAG UNEXPECTED SQUIB"},
    ],
    "RIGHT_SIDE_AIRBAG": [
        {"dtc": "9206", "status_byte": "64", "description": "RIGHT SIDE AIRBAG UNEXPECTED SQUIB"},
    ],
    "LEFT_CURTAIN_AIRBAG": [
        {"dtc": "9209", "status_byte": "64", "description": "LEFT SIDE CURTAIN AIRBAG UNEXPECTED SQUIB"},
    ],
    "RIGHT_CURTAIN_AIRBAG": [
        {"dtc": "9207", "status_byte": "64", "description": "RIGHT SIDE CURTAIN AIRBAG UNEXPECTED SQUIB"},
    ],
    "DRIVER_KNEE_AIRBAG": [
        {"dtc": "9211", "status_byte": "64", "description": "DRIVER Knee Airbag UNEXPECTED SQUIB"},
    ],
    "CENTER_AIRBAG": [],
    "LEFT_PRETENSIONER_1_BELT": [
        {"dtc": "8072", "status_byte": "64", "description": "LEFT PRETENSIONER UNEXPECTED SQUIB"},
    ],
    "RIGHT_PRETENSIONER_1_BELT": [
        {"dtc": "8070", "status_byte": "64", "description": "RIGHT PRETENSIONER UNEXPECTED SQUIB"},
    ],
    "LEFT_PRETENSIONER_2_LAP": [
        {"dtc": "9204", "status_byte": "64", "description": "LEFT LAP PRETENSIONER UNEXPECTED SQUIB"},
    ],
    "RIGHT_PRETENSIONER_2_LAP": [
        {"dtc": "9203", "status_byte": "64", "description": "RIGHT LAP PRETENSIONER UNEXPECTED SQUIB"},
    ],
    "LEFT_FRSU": [
        {"dtc": "8090", "status_byte": "64", "description": "LEFT FRSU CONFIGURATION ERROR"},
    ],
    "RIGHT_FRSU": [
        {"dtc": "8095", "status_byte": "64", "description": "RIGHT FRSU CONFIGURATION ERROR"},
    ],
    "LEFT_SRSU": [
        {"dtc": "920A", "status_byte": "64", "description": "B-PILLAR LEFT SRSU CONFIGURATION ERROR"},
    ],
    "RIGHT_SRSU": [
        {"dtc": "920B", "status_byte": "64", "description": "B-PILLAR RIGHT SRSU CONFIGURATION ERROR"},
    ],
    "RIGHT_SIDE_PRESSURE_RSU": [
        {"dtc": "9216", "status_byte": "64", "description": "RIGHT SIDE PRESSURE RSU CONFIGURATION ERROR"},
    ],
    "LEFT_SIDE_PRESSURE_RSU": [
        {"dtc": "9212", "status_byte": "64", "description": "LEFT SIDE PRESSURE RSU CONFIGURATION ERROR"},
    ],
    "A_PILLAR_RIGHT_SRSU": [
        {"dtc": "9237", "status_byte": "64", "description": "A-PILLAR RIGHT SRSU CONFIGURATION ERROR"},
    ],
    "A_PILLAR_LEFT_SRSU": [
        {"dtc": "9236", "status_byte": "64", "description": "A-PILLAR LEFT SRSU CONFIGURATION ERROR"},
    ],
    "PABD_SWITCH": [],
    "DRIVER_SEAT_BELT_BUCKLE_SWITCH": [],
    "PASSENGER_SEAT_BELT_BUCKLE_SWITCH": [],
    "SECOND_ROW_RIGHT_BUCKLE_SWITCH": [],
    "SECOND_ROW_MIDDLE_BUCKLE_SWITCH": [],
    "SECOND_ROW_LEFT_BUCKLE_SWITCH": [],
    "PABD_LAMP_HW": [
        {"dtc": "9210", "status_byte": "64", "description": "PASSENGER AIRBAG DISABLE LAMP CONFIGURATION ERROR"},
    ],
    "PAB_ENABLE": [
        {
            "dtc": "9024",
            "status_byte": "64",
            "description": "PASSENGER AIRBAG ENABLE LAMP ( GPO-1) LINE CONFIGURATION ERROR",
        },
    ],
    "CRASH_OUTPUT_HW_LINE": [
        {"dtc": "9218", "status_byte": "64", "description": "CRASH OUTPUT LINE CONFIGURATION ERROR"},
    ],
    "NM_TEST_MESSAGE": [],
    "ALIVE_COUNTER": [],
}

# Common configuration DTC used by EOL validation scripts.
EOL_CONFIG_ERROR_DTC = {
    "dtc": "9202",
    "status_byte": "00",
    "description": "ECU CONFIGURATION ERROR",
}

def _build_eol_tests(features, include_without_dtc=False):
    tests = []
    for feature in features:
        byte_index, bit_index = U171_FEATURE_MAP[feature]
        dtcs = U171_FEATURE_AVAILABLE_DTCS.get(feature, [])
        if not dtcs and not include_without_dtc:
            continue
        dtc = dtcs[0] if dtcs else {}
        tests.append(
            {
                "feature": feature,
                "byte": byte_index,
                "bit": bit_index,
                "dtc": dtc.get("dtc"),
                "status_byte": dtc.get("status_byte"),
            }
        )
    return tests


EOL_LOOP_TESTS = _build_eol_tests(EOL_LOOP_FEATURES)
EOL_RSU_TESTS = _build_eol_tests(EOL_RSU_FEATURES)
EOL_GPO_TESTS = _build_eol_tests(EOL_GPO_FEATURES)
EOL_SWITCH_DCS_TESTS = _build_eol_tests(EOL_SWITCH_DCS_FEATURES, include_without_dtc=True)
EOL_OTHER_TESTS = _build_eol_tests(EOL_OTHER_FEATURES)

# U171: FF 0F 0F AB 2A 18 05 00 00 00 00 00 00 00 00 00 00 00 00 00 
# Z121: FF 0F 3F AB 2A 18 01 00 00 00 00 00 00 00 00 00 00 00 00 00

U171_DEFAULT_EOL_BYTES = [
    0xFF, 0x0F, 0x0F, 0xAB, 0x2A, 0x18, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
]

# Generic aliases used by U171 scripts and helper utilities.
EOL_FEATURE_MAP = U171_FEATURE_MAP
EOL_DEFAULT_BYTES = U171_DEFAULT_EOL_BYTES
EOL_PAYLOAD_LENGTH = 20
EOL_DEFAULT_HEX_SPACED = " ".join(f"{value:02X}" for value in EOL_DEFAULT_BYTES)
EOL_DEFAULT_HEX = "".join(f"{value:02X}" for value in EOL_DEFAULT_BYTES)
EOL_FEATURE_AVAILABLE_DTCS = U171_FEATURE_AVAILABLE_DTCS
EOL_NRC13_NOT_APPLICABLE_FEATURES = {
    "loop": {
        "feature": "BATTERY_CUTOFF_SWITCH",
        "description": "Battery Cutoff Switch",
    },
    "rsu": {
        "feature": "UNDERBODY_RSU",
        "description": "Underbody RSU",
    },
    "dcs": {
        "feature": "DRIVER_SEAT_BELT_BUCKLE_SWITCH_SOURCE",
        "description": "Driver Seat Belt Buckle Switch Source",
    },
}
# Add only OEM-confirmed reserved bits here. byte_index is zero-based in the
# 20-byte EOL payload and bit_index uses the normal 0-to-7 bit numbering.
# The reserved-bit NRC test injects the first entry; replace it to change the
# tested bit or append additional approved reserved-bit entries for later tests.
EOL_RESERVED_BITS = [
    {
        "name": "Reserved byte 6 bit 7",
        "byte_index": 6,
        "bit_index": 7,
    },
]

_EVT_DIRECTORY = Path(__file__).resolve().parents[3] / "evt" / "z121"
EOL_EVT_CONFIG = {
    "spi_function": "GEN6_XY",
    "corrupted_evt_path": str(_EVT_DIRECTORY / "GEN6_XY_EVT_Corrupted_EVT.xlsx"),
    "normal_evt_path": str(_EVT_DIRECTORY / "GEN6_XY_U171_EVT_Christy.xlsx"),
}

# Optional scenario hooks kept for a common EOL configuration interface.
EOL_MINIMUM_LOOP_FEATURE = ""
EOL_MINIMUM_RSU_FEATURE = ""
EOL_NRC31_SCENARIOS = {}
EOL_NRC88_SPEED_SIGNAL = {}
EOL_RETENTION_TEST = {}

project_defaults = {
    "U171": {
        "feature_map": EOL_FEATURE_MAP,
        "enabled_features": U171_ENABLED_FEATURES,
        "eol_bytes": EOL_DEFAULT_BYTES,
        "payload_length": EOL_PAYLOAD_LENGTH,
        "nrc13_not_applicable_features": EOL_NRC13_NOT_APPLICABLE_FEATURES,
        "reserved_bits": EOL_RESERVED_BITS,
        "feature_available_dtcs": EOL_FEATURE_AVAILABLE_DTCS,
        "loop_features": EOL_LOOP_FEATURES,
        "loop_squib_names": EOL_LOOP_SQUIB_NAMES,
        "rsu_features": EOL_RSU_FEATURES,
        "gpo_features": EOL_GPO_FEATURES,
        "switch_dcs_features": EOL_SWITCH_DCS_FEATURES,
        "other_features": EOL_OTHER_FEATURES,
        "pab_dependencies": EOL_PAB_Dependencies,
        "evt_config": EOL_EVT_CONFIG,
        "description": "U171 default EOL configuration (FF 0F 0F AB 2A 18 05 00 00 00 00 00 00 00 00 00 00 00 00 00)",
    },
}
