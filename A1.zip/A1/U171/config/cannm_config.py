"""
Module Configuration: CANNM
Project: U171
============================================================

Location: projects/U171/config/cannm_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is CANNM
    ctx.get_module_config("CANNM").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "CANNM"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── CANNM Settings ──
NM_CHANNEL = 0
NM_BASE_ID = 0x500
NM_REPEAT_MESSAGE_TIME = 1.5
NM_WAIT_BUS_Sleep_TIME = 5.0
NM_TIMEOUT_TIME = 6.0


# ── Qualification timing ─────────────────────────────────────────────────────
# The detection and recovery thresholds that decide when a CAN fault becomes a DTC now
# live in this project's canc_config, beside the frames and signals whose faults they
# time: qualification_ms(), recovery_ms(), FAULT_THRESHOLDS and the NM DID 0x0103 /
# 0x0104 defaults they are built from.
