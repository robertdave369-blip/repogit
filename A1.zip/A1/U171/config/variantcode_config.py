"""
Module Configuration: VARIANTCODE
Project: U171
============================================================

Location: projects/U171/config/variantcode_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is VARIANTCODE
    ctx.get_module_config("VARIANTCODE").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "VARIANTCODE"


# ── VARIANTCODE Settings ──
VARIANTCODE_DID = 0x0101
vc_positive_res = "0x6E 0x01 0x01"
project_defaults = {
        "U171": {
            "enabled_nodes": [
                "VARIANT_STATUS",
                "EPS",
                "SAS",
                "IC",
                "MBFM",
                "HPC_C",
                "FR_ZONE",
                "RVC",
                "VCU",
            ],
            "variant_bytes": [0x19, 0x00, 0x00, 0x03, 0x00, 0x14, 0x04, 0x00,
                                0x00, 0x00, 0x00, 0x04, 0x01, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00],
            "description": "U171 Default - ICE Platform Base Configuration (19 00 00 03 00 14 04 00 00 00 00 04 01 00 00 00 00 00 00 00)"
        },
        
    }
