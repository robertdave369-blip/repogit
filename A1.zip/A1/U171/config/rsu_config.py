"""
Module Configuration: RSU
Project: U171
============================================================

Location: projects/U171/config/rsu_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is RSU
    ctx.get_module_config("RSU").<SETTING>  # from any other module
"""

PROJECT_NAME = "U171"
MODULE_NAME = "RSU"

ENABLED = True
TIMEOUT_SECONDS = 30
RETRY_COUNT = 1

# ── RSU Settings ──
SENSOR_CHANNELS = {
    "FRONT_LEFT":  0,
    "FRONT_RIGHT": 1,
    "SIDE_LEFT":   2,
    "SIDE_RIGHT":  3,
    "REAR":        4,
    "ROLLOVER":    5,
}

SENSOR_SENSITIVITY = {
    "FRONT":    2.5,
    "SIDE":     1.8,
    "REAR":     3.0,
    "ROLLOVER": 15.0,
}

SENSOR_TO_RSU_CHANNEL = {
    "Sensor_FL": "CH0",
    "Sensor_FR": "CH1",
    "Sensor_SL": "CH2",
    "Sensor_SR": "CH3",
}
RSU_T0_OFFSETS = {
	"default": 0,
	"front": 0,
	"left": 0,
	"right": 0,
	"rear": 11,
	"near": 0,
}