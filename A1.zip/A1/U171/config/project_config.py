"""
Project Configuration: U171
============================================================

Location: projects/U171/config/project_config.py

All module configs are also in this same config/ folder:
    U171/config/gpo_config.py
    U171/config/edr_config.py
    ... etc.

Accessed via:
    ctx = FrameworkContext(project="U171", module="GPO")
    ctx.config.CAN_CHANNEL            # project config
    ctx.mod_config.TEST_SIGNALS       # current module config
    ctx.get_module_config("EDR").EDR_DIDS  # another module config
"""

from pathlib import Path

PROJECT_NAME = "U171"
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ── Shared Defaults ──
ACTIVE_CAN_VARIANT = "U171"

APPLICATION_SW_VER = "U171SRSVRACD004"
CALIBRATION_SW_VER = "U171SRSVRDCD002"
HARDWARE_SW_VER = "U171H0-2"
EEPROM_SW_VER = "U171SRSVRECD002"
BOOTLOADER_SW_VER = "U171SRSVRBCD002"
AEF_SW_VER = "IMHBEV______1F07S09B05RHHPHHCHXHM1"
INTERNAL_SW_VERSION = "SC3M1I4AU171P74"

SOFTWARE_VERSION_READ_CONFIG = [
    {"did": "0xF1 0x81", "label": "Application Software", "expected": APPLICATION_SW_VER},
    {"did": "0xF1 0x82", "label": "Calibration Software", "expected": CALIBRATION_SW_VER},
    {"did": "0xF1 0x91", "label": "Hardware", "expected": HARDWARE_SW_VER},
    {"did": "0xF1 0xB7", "label": "EEPROM Version", "expected": EEPROM_SW_VER},
    {"did": "0xF1 0x80", "label": "Bootloader Version", "expected": BOOTLOADER_SW_VER},
    {"did": "0xFF 0xAA", "label": "AEF Version", "expected": AEF_SW_VER},
    {"did": "0xFD 0x42", "label": "Internal Version", "expected": INTERNAL_SW_VERSION},
] 
# 
SW_VERSION_DID = [item["did"] for item in SOFTWARE_VERSION_READ_CONFIG]
SW_PARAMETER = [item["label"] for item in SOFTWARE_VERSION_READ_CONFIG]
SW_VERSION_PARAM = [item["expected"] for item in SOFTWARE_VERSION_READ_CONFIG]

DEFAULT_EOL_BY_VARIANT = {
    "U171": "0x03 0x13 0xCF 0xA4 0x00 0x00 0x07 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00",
}

DEFAULT_VARIANT_CODE_BY_VARIANT = {
    "U171": "0x19 0x00 0x00 0x03 0x00 0x14 0x00 0x04 0x00 0x00 0x00 0x04 0x01 0x00 0x00 0x00 0x00 0x00 0x00 0x00",
}

DEFAULT_EOL_CODE = DEFAULT_EOL_BY_VARIANT.get(ACTIVE_CAN_VARIANT, "")
DEFAULT_VARIANT_CODE = DEFAULT_VARIANT_CODE_BY_VARIANT.get(ACTIVE_CAN_VARIANT, "")

# ── Tool Paths ──
WINIDEA_WORKSPACE = r"C:\iSYSTEM\U171\workspace.xjrf"
CAN_DB_PATH = r"C:\CAN_DB\U171\U171.dbc"
FLASH_FILE_PATH = r"C:\Builds\U171\latest.hex"

# ── Output ──
TEST_RESULTS_DIR = str(PROJECT_ROOT / "test_results")
TEST_LOGS_DIR = str(PROJECT_ROOT / "test_logs")

# ── CAN ──
CAN_FD_ENABLED = True
CAN_HS_ENABLED = True
CAN_FD_CHANNEL_NAME = "CANFD"
CAN_HS_CHANNEL_NAME = "HSCAN"

# ── Diagnostics ──
DIAG_RX_ID = 0x738
DIAG_TX_ID = 0x730
DIAG_FUNCTIONAL_ID = 0x7DF

DEFAULT_CAN_LOG_IDS = [0x2C0, 0x13C, 0x730, 0x738, 0x7DF, 0x7F1, 0x7F9]

# ── ECU ──
ECU_VARIANT = "DEFAULT"
SOFTWARE_VERSION = "1.0.0"
HARDWARE_VERSION = "1.0"

# ── EVT ──
_EVT_DIRECTORY = Path(__file__).resolve().parents[3] / "evt" / "z121"
EOL_EVT_CONFIG = {
    "spi_function": "GEN6_XY",
    "corrupted_evt_path": str(_EVT_DIRECTORY / "GEN6_XY_EVT_Corrupted_EVT.xlsx"),
    "normal_evt_path": str(_EVT_DIRECTORY / "GEN6_XY_Z121_EVT_Christy.xlsx"),
}

# ── Loadbox Path ──
AriaFileConfig = r"C:\AriaConfigFile_UPP_EV\AriaConfigFiles\AriaMain_accdata\Loadbox\UPP_EV_LOADBOX1.ldbx"

# ── Timing ──
DEFAULT_TIMEOUT = 30
FLASH_TIMEOUT = 120
RESET_WAIT_TIME = 5

# ── WinIDEA ──
TARGET_CPU = "TC397"
