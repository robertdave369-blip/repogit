# Author: Christy, Krishna
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_edr_canc_combined_scripts.py --project U171

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides, so a script
# names what it uses rather than where it lives. The two ARIA calls come through it
# too, and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- U171 project configuration -----------------------------------------
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_PARAMETERS_BY_NAME,
    EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.U171.config.rsu_config import RSU_T0_OFFSETS
from Framework_IOEM_Py.projects.U171.config.canc_config import PROJECT_NAME
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = 'ALL.NODE_ABSENT_FULL'
    tc_name = 'COMBINED_EDR_CANC_ALL_PARAMETERS_NODE_ABSENT_FULL'
    tc_desc = (
        'Verify that all 46 applicable EDR parameters record the configured reaction to '
        'Node Absent when the fault is applied in full interval and every parameter is '
        'driven together in one crash.'
    )
    tc_category = 'Node Absent in full interval - all parameters together'
    tc_priority = 'Highest'

    # -- The parameters this run covers --------------------------------------
    # element        the name the recording specification knows it by, and the key into
    #                EDR_PARAMETERS_BY_NAME
    # signal         the key into MAH_CAN_SIGNAL_DEFS
    # values         which input array in that signal definition to drive
    # action         what the record should hold while the fault is active
    # default_raw    the configured default, for action 'default'
    PARAMETERS = [
        {'element': 'ABS_ACTIVE_IEB', 'signal': 'ABS_ACTIVE', 'values': 'EDR_CANC_TestCase_10_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ACC_SYS_STATE', 'signal': 'ACC_SYS_STATE', 'values': 'EDR_CANC_TestCase_39_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ADAS_Des_StrWhl_Angle_Cmd', 'signal': 'ADAS_DES_STRWHL_ANGLE_CMD1', 'values': 'EDR_CANC_TestCase_33_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'AEB_FCTA_WARN', 'signal': 'AEB_FCTA_WARN1', 'values': 'EDR_CANC_TestCase_25_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'AEB_WARNING_MSG', 'signal': 'AEB_WARNING_MSG1', 'values': 'EDR_CANC_TestCase_24_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'AES_SYS_STS', 'signal': 'AES_SYS_STS1', 'values': 'EDR_CANC_TestCase_30_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'AES_Warning', 'signal': 'AES_WARNING1', 'values': 'EDR_CANC_TestCase_29_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Accelerator pedal, % full', 'signal': 'ACC_PED1', 'values': 'EDR_CANC_TestCase_8_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Brake switch status', 'signal': 'BRK_PEDAL1', 'values': 'EDR_CANC_TestCase_7_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Clutch Status', 'signal': 'CLUTCH_STS', 'values': 'EDR_CANC_TestCase_66_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Door Lock Status', 'signal': 'STS_DOOR_LATCH', 'values': 'EDR_CANC_TestCase_19_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Doors Open Status', 'signal': 'STS_DOOR', 'values': 'EDR_CANC_TestCase_5_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ELK_Oncoming_Warning', 'signal': 'ELK_ONCOMING_WARNING1', 'values': 'EDR_CANC_TestCase_43_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ELK_Overtaking_Warning', 'signal': 'ELK_OVERTAKING_WARNING1', 'values': 'EDR_CANC_TestCase_45_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ELK_SIDE_WARNING', 'signal': 'ELK_SIDE_WARNING1', 'values': 'EDR_CANC_TestCase_44_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ENGINE SPEED', 'signal': 'ENG_SPD1', 'values': 'EDR_CANC_TestCase_9_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ESA_SYS_STS', 'signal': 'ESA_SYS_STS1', 'values': 'EDR_CANC_TestCase_31_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'ESC_ACTIVE_IEB', 'signal': 'ESC_ACTIVE', 'values': 'EDR_CANC_TestCase_12_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Engine State', 'signal': 'STS_ENG', 'values': 'EDR_CANC_TestCase_4_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Front Head Lamp Status', 'signal': 'STS_HIGH_BEAM', 'values': 'EDR_CANC_TestCase_3_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Gear', 'signal': 'GEAR_ACTUAL', 'values': 'EDR_CANC_TestCase_18_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LATERAL_ACCEL', 'signal': 'LATTERAL_ACCEL', 'values': 'EDR_CANC_TestCase_21_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LCF_SYS_STATE', 'signal': 'LCF_SYS_STATE1', 'values': 'EDR_CANC_TestCase_36_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LC_PATH_STATE', 'signal': 'LC_PATH_STATE1', 'values': 'EDR_CANC_TestCase_42_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LDW_LKA_SYS_STATE', 'signal': 'LDW_LKA_SYS_STATE1', 'values': 'EDR_CANC_TestCase_34_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LDW_LKA_WARNING', 'signal': 'LDW_LKA_WARNING1', 'values': 'EDR_CANC_TestCase_32_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LKA_HANDSOFF_DISPLAY_WARNING', 'signal': 'LKA_HANDSOFF_DISPLAY_WARNING1', 'values': 'EDR_CANC_TestCase_35_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'LONG_ACCEL', 'signal': 'LONG_ACCEL', 'values': 'EDR_CANC_TestCase_22_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Master_Cylinder_Pressure', 'signal': 'MASTER_CYL_PRESSURE', 'values': 'EDR_CANC_TestCase_17_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'NP_SYS_STS', 'signal': 'NP_SYS_STS1', 'values': 'EDR_CANC_TestCase_40_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Odometer', 'signal': 'ODOMTR_READING', 'values': 'EDR_CANC_TestCase_2_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'RMS_MODE_STATE', 'signal': 'RMS_MODE_STATE1', 'values': 'EDR_CANC_TestCase_41_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'SPA_LCF_HANDSOFF_ WARNING', 'signal': 'SPA_LCF_HANDS_OFF_WARNING1', 'values': 'EDR_CANC_TestCase_38_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'SPA_SYS_STATE', 'signal': 'SPA_SYS_STATE1', 'values': 'EDR_CANC_TestCase_37_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'STEERING_ABSOLUTE_ANGLE', 'signal': 'ABSOLUTE_ANGLE', 'values': 'EDR_CANC_TestCase_11_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'STS_HIGHBEAM', 'signal': 'STS_HIGH_BEAM', 'values': 'EDR_CANC_TestCase_49_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'STS_LOWBEAM', 'signal': 'STS_LOW_BEAM', 'values': 'EDR_CANC_TestCase_50_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'STS_TPMS_LED', 'signal': 'STS_TPMS_LED', 'values': 'EDR_CANC_TestCase_51_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'TCS_ACTIVE_IEB', 'signal': 'TCS_ACTIVE', 'values': 'EDR_CANC_TestCase_23_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Tyre_Pressure_FL', 'signal': 'FL_TYRE_PRESSURE', 'values': 'EDR_CANC_TestCase_13_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Tyre_Pressure_FR', 'signal': 'FR_TYRE_PRESSURE', 'values': 'EDR_CANC_TestCase_14_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Tyre_Pressure_RL', 'signal': 'RL_TYRE_PRESSURE', 'values': 'EDR_CANC_TestCase_15_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Tyre_Pressure_RR', 'signal': 'RR_TYRE_PRESSURE', 'values': 'EDR_CANC_TestCase_16_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'Vehicle Speed Longitudinal', 'signal': 'VEHICLE_SPEED_ESC12', 'values': 'EDR_CANC_TestCase_6_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'VehicleSpeed Longitudinal At Time Zero', 'signal': 'VEHICLE_SPEED_ESC12', 'values': 'EDR_CANC_TestCase_1_values', 'action': 'last_valid', 'default_raw': None},
        {'element': 'YAW_RATE', 'signal': 'YAW_RATE', 'values': 'EDR_CANC_TestCase_20_values', 'action': 'last_valid', 'default_raw': None},
    ]

    fault_mode = 'node_absent'
    fault_scope = 'full'

    # -- Report and logging --------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    signal_defs = [MAH_CAN_SIGNAL_DEFS[entry["signal"]] for entry in PARAMETERS]
    can_ids = resolve_can_log_ids(signal_defs)
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Test Case Category:", tc_category)
    aria_reports.add_report_info("#Priority:", tc_priority)
    aria_reports.add_report_info("#Parameters covered:", str(len(PARAMETERS)))

    # -- Build one plan per parameter ----------------------------------------
    # Each keeps its own recording interval, its own sample spacing and its own
    # conversion. Nothing is averaged or aligned to a common rate: the merged timeline
    # below visits every instant any parameter needs.
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"
    t0_offset_ms = int(RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS.get("default", 0)) or 0)

    plans = []
    for entry in PARAMETERS:
        signal_def = MAH_CAN_SIGNAL_DEFS[entry["signal"]]
        edr_def = EDR_PARAMETERS_BY_NAME.get(entry["element"]) or {}
        values = signal_def.get(entry["values"]) or []
        if not isinstance(values, list):
            values = [values]
        time_axis, T0_INDEX = build_time_axis_and_t0(
            entry["element"], crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next(
            (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        plans.append({
            "element": entry["element"],
            "action": entry["action"],
            "default_raw": entry["default_raw"],
            "frame": signal_def["frame"],
            "signal": signal_def["signal"],
            "periodicity": signal_def["periodicity"],
            "bit_length": signal_def["bit_length"],
            "signed": signal_def.get("Signed", False),
            "factor": signal_def.get("Factor", 1),
            "offset": signal_def.get("Offset", 0),
            "unit": signal_def.get("UNIT") or "value",
            "fault_logic": signal_def.get("fault_logic") or {},
            "invalid_raw": (signal_def.get(entry["values"].replace("_values", "_Invalid_Values")) or [0])[0],
            "exception_codes": set(signal_def.get(entry["values"].replace("_values", "_Invalid_Values")) or []),
            "values": values,
            "time_axis": [round(float(t), 6) for t in time_axis],
            "t0_sample_idx": t0_sample_idx,
            "edr_bits": edr_def.get("data_bit_length") or signal_def["bit_length"],
            "edr_signed": bool(edr_def.get("signed")),
            "edr_scaling": edr_def.get("scaling_factor", 1),
            "edr_offset": edr_def.get("offset", 0),
            "samples_number": edr_def.get("data_samples_number") or 1,
        })

    # An interval element stores its whole vector in one crash. A snapshot element
    # stores one value at T0, so its list of values needs one crash each. The run
    # repeats the crash until the longest snapshot list is covered; interval
    # elements drive their full vector on every pass.
    for plan in plans:
        if plan["samples_number"] > 1:
            RESULT.InterpretEqualResult(
                f"{plan['element']}: values to drive match the samples the record holds",
                str(len(plan["values"])), str(plan["samples_number"]))

    total_crashes = max([1] + [len(plan["values"]) for plan in plans
                               if plan["samples_number"] == 1])
    RESULT.InsertComment(
        f"[{report_timestamp()}] {total_crashes} crash(es) needed: the longest"
        f" snapshot element has that many values, and a snapshot records one per"
        f" crash. Interval elements drive their full vector on every crash.")

    # -- The merged timeline -------------------------------------------------
    # The union of every parameter's recording instants, in order. A parameter is driven
    # only at the instants it actually records, so a 0.25 s element and a 1.0 s element
    # keep their own rates inside one run.
    instants = sorted({t for plan in plans for t in plan["time_axis"]})
    trigger_instant = next((t for t in instants if abs(t) < 1e-9), None)
    print(f"Combined run: {len(plans)} parameters, {len(instants)} instants "
          f"from {instants[0]}s to {instants[-1]}s, T0 at index "
          f"{instants.index(trigger_instant) if trigger_instant is not None else -1}")

    RESULT.InsertComment(
        f"[{report_timestamp()}] {len(plans)} parameter(s) driven together across "
        f"{len(instants)} instant(s) from {instants[0]}s to {instants[-1]}s. "
        f"Each keeps its own sample spacing; the crash fires at T0.")

    # Every distinct node key frame across the parameters in this run.
    fault_frames = sorted({plan['fault_logic'].get('key_message')
                           for plan in plans
                           if plan['fault_logic'].get('key_message')})

    # -- Bench bring-up ------------------------------------------------------
    fault_free_profile()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()

    for crash_index in range(total_crashes):
        did = EDR_RECORD_DIDS[crash_index % len(EDR_RECORD_DIDS)]
        load_crash_curves(crash_type)
        crash_reference = None
        fault_is_on = False
        driven_log = {plan["element"]: {} for plan in plans}

        # What each parameter drives on this crash. A snapshot takes this crash's
        # value; once its list is exhausted it repeats its last, so a shorter list
        # never leaves the bus undriven.
        for plan in plans:
            if plan["samples_number"] == 1 and plan["values"]:
                plan["current"] = [plan["values"][min(crash_index, len(plan["values"]) - 1)]]
            else:
                plan["current"] = plan["values"]

        aria_reports.add_group(
            f"{test_case_file} - DID {did} - CAN signal simulation - {tc_category}")
        RESULT.InsertComment(
            f"[{report_timestamp()}] Starting {tc_category} into event record {did}.")
        # A fault that covers the first instant can only retain the last value
        # received before it if something was received. Each parameter is
        # driven with its first value and held for one interval first.
        for plan in plans:
            if plan["values"]:
                CAN.ChangeSignalValue(plan["frame"], plan["signal"], str(plan["values"][0]))
                driven_log[plan["element"]]["retained"] = plan["values"][0]
        Wait(500)
        RESULT.InsertComment(
            f"[{report_timestamp()}] Primed all parameters with their first value before creating the fault.")

        previous_instant = instants[0] - 0.5
        for instant in instants:
            create_now = not fault_is_on
            heal_now = False
            if create_now:
                for frame in fault_frames:
                    CAN.PeriodicDisableFrame(frame)
                fault_is_on = True
                RESULT.InsertComment(
                    f"[{report_timestamp(crash_reference)}] Node Absent created at "
                    f"{instant}s on {len(fault_frames)} frame(s).")
            elif heal_now:
                for frame in fault_frames:
                    CAN.ReloadDefaultPeriodicFrame(frame)
                fault_is_on = False
                RESULT.InsertComment(
                    f"[{report_timestamp(crash_reference)}] Node Absent healed at "
                    f"{instant}s.")
            # Which parameters record at this instant, and what each one drives.
            for plan in plans:
                if instant not in plan["time_axis"]:
                    continue
                idx = plan["time_axis"].index(instant)
                in_fault = True
                if in_fault and plan["action"] == "consume":
                    CAN.ChangeSignalValue(plan["frame"], plan["signal"], str(plan["invalid_raw"]))
                elif not in_fault:
                    driven = plan["current"][idx]
                    CAN.ChangeSignalValue(plan["frame"], plan["signal"], str(driven))
                    driven_log[plan["element"]]["retained"] = driven

            Wait(int(round((instant - previous_instant) * 1000)))
            previous_instant = instant

            if trigger_instant is not None and abs(instant - trigger_instant) < 1e-9:
                if t0_offset_ms:
                    Wait(t0_offset_ms)
                TriggerCrash()
                crash_reference = time.monotonic()
                RESULT.InsertComment(
                    f"[{report_timestamp()}] Crash triggered at T0"
                    + (f", {t0_offset_ms} ms after the T0 sample." if t0_offset_ms else "."))

        # Qualification is a count of message periods, so the slowest frame in
        # this run decides how long the fault has to be held.
        hold_ms = max([qualification_ms('node_absent', plan["periodicity"]) or 0
                       for plan in plans] or [0])
        if hold_ms:
            Wait(hold_ms)
        Sleep(1)
        combined_crash_dtc = (Crash_DTC + " " + DTC_status["DTC_active"] + " "
                              + PT_Crash_DTC + " " + DTC_status["DTC_active"])
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc, Read_DTC_Req)
        aria_reports.close_group()

        # -- EDR output verification -----------------------------------------
        Sleep(5)
        # One ignition cycle before the record is read. A combined run unlocks security
        # once per parameter per crash, and the ECU allows only a limited number of
        # attempts before it locks out and answers every later request with an NRC. The
        # cycle resets that counter and starts a fresh session. It comes after Read DTC
        # so it cannot disturb the DTC status those steps expect, and the event record
        # is held in NVM, so cycling does not lose it.
        RESULT.InsertComment(
            f"[{report_timestamp(crash_reference)}] Ignition cycle before reading "
            f"record {did}, so security access starts from a clean attempt count.")
        PS.Power_Cycle()
        Sleep(1)
        RESULT.InsertComment(
            f"[{report_timestamp(crash_reference)}] Reading event record {did} for "
            f"all {len(plans)} parameter(s).")

        aria_reports.add_group(
            f"{test_case_file} - DID {did} - EDR output verification - {tc_category}")
        for plan in plans:
            edr_read = read_edr_parameters(
                [plan["element"]], did=did, crash_type=crash_type, return_data=True)
            response_bytes = edr_read.get("data", []) if isinstance(edr_read, dict) else []
            samples = edr_sample_records(plan["element"], response_bytes)

            RESULT.InterpretEqualResult(
                f"{plan['element']}: decoded sample count in DID {did}",
                str(len(samples)), str(len(plan["current"])))

            for idx, value in enumerate(plan["current"]):
                instant = plan["time_axis"][idx] if idx < len(plan["time_axis"]) else idx
                in_fault = True
                state = "fault active" if in_fault else "valid input"

                if not in_fault:
                    expected_can = value
                elif plan["action"] == "consume":
                    expected_can = plan["invalid_raw"]
                elif plan["action"] == "default":
                    expected_can = plan["default_raw"]
                else:
                    expected_can = driven_log[plan["element"]].get("retained", value)

                # The ECU reads the value with the signal's conversion and writes it with
                # the record's. A DBC marker code is not a measurement, so it is recorded
                # as it stands. A reaction stated as a band gives two ends to convert.
                band = expected_can if isinstance(expected_can, tuple) else (expected_can,)
                converted = []
                conversion_exact = True
                for can_raw in band:
                    if can_raw in plan["exception_codes"]:
                        converted.append(int(can_raw))
                        continue
                    precise = ((can_raw * plan["factor"] + plan["offset"])
                               - plan["edr_offset"]) / plan["edr_scaling"]
                    rounded = int(round(precise))
                    converted.append(rounded)
                    if abs(precise - rounded) >= 1e-6:
                        conversion_exact = False
                if len(converted) > 1:
                    expected_raw = (min(converted), max(converted))
                    conversion_exact = True
                else:
                    expected_raw = converted[0]

                if idx >= len(samples):
                    RESULT.LogCustomAction(
                        f"{plan['element']} sample {idx} at {instant}s in DID {did}",
                        f"Record supplied no sample {idx}",
                        f"Recorded raw {expected_raw}",
                        TestStatus.Failed)
                    continue
                observed = samples[idx]

                if isinstance(expected_raw, tuple):
                    low, high = expected_raw
                    RESULT.LogCustomAction(
                        f"{plan['element']} at {instant}s in DID {did} - {state}",
                        f"{observed['raw']} ({observed['hex']},"
                        f" {format_physical(observed['physical'])} {plan['unit']})",
                        f"any raw value from {low} ({raw_hex(low, plan['edr_bits'])})"
                        f" to {high} ({raw_hex(high, plan['edr_bits'])})",
                        TestStatus.Passed if low <= observed["raw"] <= high else TestStatus.Failed)
                    continue

                expected_signed = (raw_signed(expected_raw, plan["edr_bits"])
                                   if plan["edr_signed"] else expected_raw)

                if not conversion_exact:
                    difference = abs(observed["raw"] - expected_signed)
                    RESULT.LogCustomAction(
                        f"{plan['element']} at {instant}s in DID {did} - {state}",
                        f"{observed['raw']} ({observed['hex']},"
                        f" {format_physical(observed['physical'])} {plan['unit']})",
                        f"{expected_signed} +/- 1 count, the conversion landing between"
                        f" two raw values",
                        TestStatus.Passed if difference <= 1 else TestStatus.Failed)
                    continue

                # Raw decimal, raw hex and physical in one comparison, so a wrong scaling
                # and a wrong raw value cannot both hide behind a passing row.
                RESULT.InterpretEqualResult(
                    f"{plan['element']} at {instant}s in DID {did} - {state}",
                    f"{observed['raw']} ({observed['hex']},"
                    f" {format_physical(observed['physical'])} {plan['unit']})",
                    f"{expected_signed} ({raw_hex(expected_raw, plan['edr_bits'])},"
                    f" {format_physical(expected_signed * plan['edr_scaling'] + plan['edr_offset'])}"
                    f" {plan['unit']})")
        aria_reports.close_group()

        # Every record written in this pass has been read and compared, so the NVM
        # can be cleared. Clearing before the second record is read would destroy
        # it unverified.
        last_of_pass = (crash_index % len(EDR_RECORD_DIDS)) == len(EDR_RECORD_DIDS) - 1
        if last_of_pass or crash_index == total_crashes - 1:
            RESULT.InsertComment(
                f"[{report_timestamp()}] Crash {crash_index + 1} of"
                f" {total_crashes} verified for all {len(plans)} parameter(s);"
                f" clearing NVM.")
            NVM_Clear_L61()

    # -- Restore the bench ---------------------------------------------------
    for frame in fault_frames:
        CAN.ReloadDefaultPeriodicFrame(frame)
    for plan in plans:
        CAN.ReloadDefaultPeriodicFrame(plan["frame"])
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
