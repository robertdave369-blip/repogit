# Author: Christy, Krishna
#
# GENERATED FILE - do not edit by hand.
# Rebuild with: py -3.14 tools/generate_ice01_edr_canc_scripts.py --project U171

import os
import sys
import time
from pathlib import Path

# -- Make Framework_IOEM_Py importable as a top-level package ----------------
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# -- Shared library ----------------------------------------------------------
# import_list re-exports every shared library the framework provides, so a script
# names what it uses rather than where it lives. The two ARIA calls come through it
# too, and run before anything below uses the reporter.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# -- U171 project configuration -----------------------------------------
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_PARAMETERS_BY_NAME,
    EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.U171.config.rsu_config import RSU_T0_OFFSETS
from Framework_IOEM_Py.projects.U171.config.canc_config import PROJECT_NAME
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = '21.6'
    tc_name = 'SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_21_6'
    tc_desc = (
        'Verify Lateral Accel recording when Message Timeout is applied only in pre '
        'crash (-5.00s to T0) for ICE (U171).'
    )
    tc_category = 'Message Timeout only in pre crash (-5.00s to T0)'
    tc_behaviour = (
        'Samples before T0 retain the last value received before the fault; from T0 the '
        'recovered valid values are recorded.'
    )
    tc_priority = 'Highest'

    # -- Signal under test, from canc_config ---------------------------------
    signal_def = MAH_CAN_SIGNAL_DEFS['LATTERAL_ACCEL']
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    bit_length = signal_def["bit_length"]
    signal_signed = signal_def.get("Signed", False)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)
    unit = signal_def.get("UNIT") or "value"

    values = signal_def.get('EDR_CANC_TestCase_21_values') or []
    if not isinstance(values, list):
        values = [values]

    # -- EDR element under test, from edr_config -----------------------------
    edr_param = 'LATERAL_ACCEL'
    edr_def = EDR_PARAMETERS_BY_NAME.get(edr_param)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    record_samples = (edr_def or {}).get("data_samples_number") or 1
    # The record keeps its own width and conversion, which are not always the CAN
    # signal's: a pedal can arrive at 0.1 %/bit in ten bits and be stored at 0.4 %/bit
    # in eight. CAN values are read with the signal's conversion, recorded values with
    # the record's.
    edr_bits = (edr_def or {}).get("data_bit_length") or bit_length
    edr_signed = bool((edr_def or {}).get("signed"))
    edr_scaling = (edr_def or {}).get("scaling_factor", 1)
    edr_offset = (edr_def or {}).get("offset", 0)

    # A DBC invalid code is a marker, not a measurement, so the record keeps it as it
    # stands rather than putting it through the physical conversion. An out-of-range
    # value is different: it is a measurement the signal can encode but should not
    # carry, so the ECU converts it like any other, and whether the result still fits
    # the recording field is exactly what the case is there to show.
    exception_codes = set(signal_def.get('EDR_CANC_TestCase_21_Invalid_Values') or [])

    # -- Fault under test ----------------------------------------------------
    # scope   which part of the interval the fault covers
    # action  what the record is expected to hold while it is active:
    #         last_valid  the last value received before the fault
    #         consume     the value on the bus, because the signal keeps transmitting
    #         default     the value the on-fail calibration configures
    fault_scope = 'pre'
    fault_action = 'last_valid'
    default_raw = None

    fault_logic = signal_def["fault_logic"]
    key_frame = fault_logic["key_message"]
    timeout_frame = fault_logic.get("non_key_timeout_frame")
    invalid_raw = (signal_def.get('EDR_CANC_TestCase_21_Invalid_Values') or [0])[0]

    can_dtc_code = resolve_dtc_for_event('message_timeout', timeout_frame)
    # A CAN fault reads active-with-warning-lamp-off while it is present. A pre-crash
    # case is healed at T0 and read in the same operation cycle, so it reads healed
    # (0x0A): historic (0x08) needs an ignition cycle between the heal and the read.
    can_dtc_status = DTC_status['DTC_healed']
    combined_can_dtc = (can_dtc_code + " " + can_dtc_status) if can_dtc_code else ""

    # Qualification is a count of message periods, not a fixed value, so a fault
    # on a 100 ms frame needs ten times as long as the same fault on a 10 ms one.
    periodicity = signal_def["periodicity"]
    qualification = qualification_ms('message_timeout', periodicity)

    # -- Report and logging --------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Test Case Name:", tc_name)
    aria_reports.add_report_info("#Test Case Category:", tc_category)
    aria_reports.add_report_info("#Priority:", tc_priority)
    aria_reports.add_report_info("#Expected Behaviour:", tc_behaviour)
    aria_reports.add_report_info("#EDR Element:", edr_param)

    # The record must be able to hold every sample this case drives.
    RESULT.InterpretEqualResult(
        f"{edr_param} record holds the number of samples the case drives",
        str(record_samples),
        str(len(values) if record_samples > 1 else 1))

    # -- Bench bring-up ------------------------------------------------------
    fault_free_profile()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    # The crash fires at T0. rsu_config gives a per-crash offset in milliseconds: 0
    # means fire exactly at T0, any other value waits that long after T0 first. The same
    # offset shifts the recording time axis, so the two stay in step.
    t0_offset_ms = int(RSU_T0_OFFSETS.get(crash_type, RSU_T0_OFFSETS.get("default", 0)) or 0)
    RESULT.InsertComment(
        f"Crash trigger for {crash_type}: T0"
        + (f" plus the {t0_offset_ms} ms offset from RSU_T0_OFFSETS."
           if t0_offset_ms else " exactly, no offset configured."))

    # An element that records an interval stores the whole vector in one crash, so the
    # same vector goes into both event records. An element that stores a single sample
    # needs one crash per value. A DBC exception case drives one code per crash across
    # the whole interval.
    if record_samples > 1:
        per_crash = [values, values]
    else:
        per_crash = [[value] for value in values]

    # The records to read come from edr_config, so a DID that changes is a
    # configuration edit and this script does not have to be touched.
    for pass_start in range(0, len(per_crash), len(EDR_RECORD_DIDS)):
        this_pass = per_crash[pass_start:pass_start + len(EDR_RECORD_DIDS)]

        for record_index, crash_values in enumerate(this_pass):
            did = EDR_RECORD_DIDS[record_index]
            load_crash_curves(crash_type)

            # Recording times come from the element's own sample range, and carry the
            # crash-type offset that the trigger below also waits out.
            time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
            t0_sample_idx = next(
                (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
            sample_interval_s = sample_interval_ms / 1000.0
            simulation_time_axis = [t - sample_interval_s for t in time_axis]
            # The sample at T0 is driven over the window ending at T0, so the crash
            # fires once that window has elapsed, not one sample earlier.
            trigger_idx = min(t0_sample_idx, len(crash_values) - 1)

            # Which samples the fault covers. A scope of pre ends at T0, post starts
            # after it, and full covers the interval.
            if fault_scope == "pre":
                fault_from, fault_to = 0, t0_sample_idx
            elif fault_scope == "post":
                fault_from, fault_to = t0_sample_idx + 1, len(crash_values)
            else:
                fault_from, fault_to = 0, len(crash_values)

            # "The last value received before the fault" is the value driven just before
            # it starts: the primed value when the fault covers the first sample, the
            # value at T0 when it starts after the crash.
            retained = crash_values[t0_sample_idx] if fault_scope == "post" else crash_values[0]

            print(f"EDR parameter: {edr_param} in DID {did}")
            print(f"Recording time axis: {time_axis}")
            print(f"Simulation time axis: {simulation_time_axis}")
            print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
            print(f"T0 sample index: {t0_sample_idx}, trigger index: {trigger_idx},"
                  f" T0 offset: {t0_offset_ms} ms")
            print(f"Fault scope: {fault_scope} action: {fault_action}"
                  f" samples {fault_from}..{fault_to}")
            print(f"Total values to simulate: {len(crash_values)}")

            crash_reference = None
            observed_inputs = []
            fault_is_on = False

            aria_reports.add_group(
                f"{test_case_file} - DID {did} - CAN signal simulation - {tc_category}")
            RESULT.InsertComment(
                f"[{report_timestamp()}] Starting {tc_category} into event record {did}.")

            # A fault covering the first sample can only retain the last value
            # received before the fault if the element has received something. On the
            # second record it would otherwise retain whatever the previous crash left,
            # so the first value is driven and received before the fault starts.
            if fault_from == 0 and crash_values:
                CAN.ChangeSignalValue(msg, sig, str(crash_values[0]))
                Wait(sample_interval_ms)
                RESULT.InsertComment(
                    f"[{report_timestamp()}] Primed {sig} with {crash_values[0]} before "
                    f"creating the fault, so the value the element retains is known.")

            for idx, val in enumerate(crash_values):
                simulation_start_time = (simulation_time_axis[idx]
                                         if idx < len(simulation_time_axis)
                                         else ((idx * sample_interval_s) - sample_interval_s))
                recording_time = (time_axis[idx] if idx < len(time_axis)
                                  else (idx * sample_interval_s))
                window = (f"simulated from {simulation_start_time}s to {recording_time}s,"
                          f" recorded at {recording_time}s")
                in_fault = fault_from is not None and fault_from <= idx < fault_to

                # Create the fault at the first sample it covers.
                if in_fault and not fault_is_on:
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] "
                        + f"Disabling signal-carrying frame {timeout_frame} to create Message Timeout.")
                    try:
                        CAN.PeriodicDisableFrame(timeout_frame)
                        fault_call_error = None
                    except Exception as raised:
                        fault_call_error = raised
                    RESULT.LogCustomAction(
                        f"Create Message Timeout at index {idx} ({window})",
                        ("completed at [" + report_timestamp(crash_reference) + "]")
                        if fault_call_error is None else
                        f"raised {type(fault_call_error).__name__}: {fault_call_error}",
                        "the bench call to complete without raising",
                        TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
                    fault_is_on = True
                # Heal it at the first sample it does not, so the recovered values
                # are on the bus for the rest of the interval. Nothing waits here:
                # a pre-crash fault heals at the T0 sample, so any pause between the
                # heal and the next value would push T0 and every post-crash sample
                # later than the grid the record is checked against.
                elif fault_is_on and not in_fault:
                    RESULT.InsertComment(
                        f"[{report_timestamp(crash_reference)}] "
                        + f"Restoring signal-carrying frame {timeout_frame}.")
                    try:
                        CAN.ReloadDefaultPeriodicFrame(timeout_frame)
                        fault_call_error = None
                    except Exception as raised:
                        fault_call_error = raised
                    RESULT.LogCustomAction(
                        f"Heal Message Timeout at index {idx} ({window})",
                        ("completed at [" + report_timestamp(crash_reference) + "]")
                        if fault_call_error is None else
                        f"raised {type(fault_call_error).__name__}: {fault_call_error}",
                        "the bench call to complete without raising",
                        TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
                    fault_is_on = False

                # The simulation never stops. The value is driven for every sample, fault
                # or no fault, so a bench buffer left frozen at the last valid value cannot
                # pass itself off as the ECU on-fail reaction. Only the frame the fault
                # stops decides whether the ECU still sees it.
                driven = val

                CAN.ChangeSignalValue(msg, sig, str(driven))
                Wait(sample_interval_ms)
                received = CAN.GetSignalFromFrame(msg, sig)
                try:
                    received_raw = (int(str(received), 16)
                                    if str(received).lower().startswith("0x")
                                    else int(received))
                except (TypeError, ValueError):
                    received_raw = None

                if received_raw is None:
                    observed_inputs.append(None)
                    RESULT.LogCustomAction(
                        f"{sig} index {idx}",
                        f"Unreadable value {received!r} ({window})",
                        f"An integer raw value ({window})",
                        TestStatus.Failed)
                else:
                    received_signed = (raw_signed(received_raw, bit_length)
                                       if signal_signed else received_raw)
                    observed_inputs.append(received_signed)
                    # Raw decimal, raw hex and physical, because a wrong scaling
                    # and a wrong raw value look identical in only one of them.
                    RESULT.InterpretEqualResult(
                        f"{sig} raw decimal at index {idx} ({window})",
                        str(received_signed), str(driven))
                    RESULT.InterpretEqualResult(
                        f"{sig} raw hex at index {idx} ({window})",
                        raw_hex(received_raw, bit_length), raw_hex(driven, bit_length))
                    RESULT.InterpretEqualResult(
                        f"{sig} physical value in {unit} at index {idx} ({window})",
                        format_physical(received_signed * factor + offset),
                        format_physical(driven * factor + offset))

                if idx == trigger_idx:
                    # T0 has been reached. rsu_config may delay the trigger for this
                    # crash type; 0 means fire exactly here.
                    if t0_offset_ms:
                        Wait(t0_offset_ms)
                    TriggerCrash()
                    crash_reference = time.monotonic()
                    RESULT.InsertComment(
                        f"[{report_timestamp()}] Crash triggered after the sample at"
                        f" {recording_time}s"
                        + (f", {t0_offset_ms} ms after T0." if t0_offset_ms else " at T0."))

            if qualification:
                Wait(qualification)
            Sleep(1)
            combined_crash_dtc = (Crash_DTC + " " + DTC_status["DTC_active"] + " "
                                  + PT_Crash_DTC + " " + DTC_status["DTC_active"])
            final_combined_dtc = (combined_crash_dtc
                                  + ((" " + combined_can_dtc) if combined_can_dtc else ""))
            Read_DTC("Front Crash", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
            aria_reports.close_group()

            # -- EDR output verification -------------------------------------
            Sleep(5)
            RESULT.InsertComment(
                f"[{report_timestamp(crash_reference)}] Reading event record {did}.")
            edr_read = read_edr_parameters(
                [edr_param], did=did, crash_type=crash_type, return_data=True)
            Sleep(2)
            response_bytes = edr_read.get("data", []) if isinstance(edr_read, dict) else []
            samples = edr_sample_records(edr_param, response_bytes)

            aria_reports.add_group(
                f"{test_case_file} - DID {did} - EDR output verification - {tc_category}")

            # A short or undecodable record is reported once, not once per sample.
            RESULT.InterpretEqualResult(
                f"{edr_param} decoded sample count in DID {did}",
                str(len(samples)),
                str(len(crash_values)))

            for idx, val in enumerate(crash_values):
                simulation_start_time = (simulation_time_axis[idx]
                                         if idx < len(simulation_time_axis)
                                         else ((idx * sample_interval_s) - sample_interval_s))
                recording_time = (time_axis[idx] if idx < len(time_axis)
                                  else (idx * sample_interval_s))
                window = (f"simulated from {simulation_start_time}s to {recording_time}s,"
                          f" recorded at {recording_time}s")
                in_fault = fault_from is not None and fault_from <= idx < fault_to
                state = "fault active" if in_fault else "valid input"

                if not in_fault:
                    expected_can = val
                elif fault_action == 'consume':
                    expected_can = val
                elif fault_action == 'default':
                    expected_can = default_raw
                else:
                    expected_can = retained

                # The ECU reads the value with the signal's conversion and writes it with
                # the record's. Where the two do not divide evenly the stored value is the
                # nearest whole raw, and a count either side is allowed below. A DBC marker
                # code is not a measurement, so it is recorded as it stands.
                # A calibration that states its reaction as a band of acceptable values
                # gives two ends to convert rather than one, and the record may hold
                # anything between them.
                band = expected_can if isinstance(expected_can, tuple) else (expected_can,)
                converted = []
                conversion_exact = True
                for can_raw in band:
                    if can_raw in exception_codes:
                        converted.append(int(can_raw))
                        continue
                    precise = ((can_raw * factor + offset) - edr_offset) / edr_scaling
                    rounded = int(round(precise))
                    converted.append(rounded)
                    if abs(precise - rounded) >= 1e-6:
                        conversion_exact = False
                if len(converted) > 1:
                    expected_raw = (min(converted), max(converted))
                    conversion_exact = True
                else:
                    expected_raw = converted[0]

                if idx >= len(samples):
                    RESULT.LogCustomAction(
                        f"{edr_param} sample {idx}",
                        f"Record supplied no sample {idx} ({window})",
                        f"Recorded raw {expected_raw} ({window})",
                        TestStatus.Failed)
                    continue
                observed = samples[idx]

                if isinstance(expected_raw, tuple):
                    # The calibration states this reaction as a band of acceptable raw
                    # values rather than one value, so membership is what is checked.
                    low, high = expected_raw
                    within = low <= observed["raw"] <= high
                    RESULT.LogCustomAction(
                        f"{edr_param} raw at {recording_time}s in DID {did} - {state} ({window})",
                        f"{observed['raw']} ({observed['hex']},"
                        f" {format_physical(observed['physical'])} {unit})",
                        f"any raw value from {low} ({raw_hex(low, edr_bits)})"
                        f" to {high} ({raw_hex(high, edr_bits)})",
                        TestStatus.Passed if within else TestStatus.Failed)
                    continue

                if expected_raw > (1 << edr_bits) - 1 or expected_raw < -(1 << edr_bits):
                    # The case drives a value larger than the field allocated to record
                    # it, so this sample cannot pass as it stands. It is compared anyway:
                    # what the record holds says which of the two is wrong.
                    RESULT.InsertComment(
                        f"{edr_param} at {recording_time}s: the value {expected_raw} needs more"
                        f" than the {edr_bits} bit(s) the specification allocates"
                        f" (maximum {(1 << edr_bits) - 1}). A recorded value of"
                        f" {expected_raw & ((1 << edr_bits) - 1)} here means the ECU truncated"
                        f" it; anything else is worth reporting against the record layout.")

                expected_signed = (raw_signed(expected_raw, edr_bits)
                                   if edr_signed else expected_raw)

                if not conversion_exact:
                    # The two conversions do not divide evenly, so the stored value is
                    # the nearest whole raw either side. One count counts as a match.
                    difference = abs(observed["raw"] - expected_signed)
                    RESULT.LogCustomAction(
                        f"{edr_param} raw at {recording_time}s in DID {did} - {state} ({window})",
                        f"{observed['raw']} ({observed['hex']},"
                        f" {format_physical(observed['physical'])} {unit})",
                        f"{expected_signed} +/- 1 count"
                        f" ({format_physical(expected_signed * edr_scaling + edr_offset)} {unit}),"
                        f" the conversion landing between two raw values",
                        TestStatus.Passed if difference <= 1 else TestStatus.Failed)
                    continue

                # Raw decimal, raw hex and physical, so a scaling error and a placement
                # error cannot both hide behind the same passing comparison.
                RESULT.InterpretEqualResult(
                    f"{edr_param} raw decimal at {recording_time}s in DID {did}"
                    f" - {state} ({window})",
                    str(observed["raw"]),
                    str(expected_signed))
                RESULT.InterpretEqualResult(
                    f"{edr_param} raw hex at {recording_time}s in DID {did} - {state} ({window})",
                    observed["hex"],
                    raw_hex(expected_raw, edr_bits))
                RESULT.InterpretEqualResult(
                    f"{edr_param} physical value in {unit} at {recording_time}s in DID {did}"
                    f" - {state} ({window})",
                    format_physical(observed["physical"]),
                    format_physical(expected_signed * edr_scaling + edr_offset))
            aria_reports.close_group()

            # This record is verified. The bench still holds whatever state the last
            # sample left it in, so the fault is removed before the next record is
            # driven; without this the next crash would drive valid values into a
            # frame that is still stopped.
            if fault_is_on:
                RESULT.InsertComment(
                    f"[{report_timestamp(crash_reference)}] "
                    + f"Restoring signal-carrying frame {timeout_frame}.")
                try:
                    CAN.ReloadDefaultPeriodicFrame(timeout_frame)
                    fault_call_error = None
                except Exception as raised:
                    fault_call_error = raised
                RESULT.LogCustomAction(
                    f"Heal Message Timeout after reading record {did}",
                    ("completed at [" + report_timestamp(crash_reference) + "]")
                    if fault_call_error is None else
                    f"raised {type(fault_call_error).__name__}: {fault_call_error}",
                    "the bench call to complete without raising",
                    TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
                fault_is_on = False
                Sleep(1)

        # Every event record written in this pass has been read and compared, so the NVM
        # can be cleared to make room for the next one. Clearing any earlier would
        # destroy the second record before it was verified.
        numbers = [pass_start + n + 1 for n in range(len(this_pass))]
        if len(numbers) > 1:
            covered = f"Crashes {numbers[0]} and {numbers[-1]} of {len(per_crash)}"
            into = f"records {EDR_RECORD_DIDS[0]} and {EDR_RECORD_DIDS[-1]}"
        else:
            covered = f"Crash {numbers[0]} of {len(per_crash)}"
            into = f"record {EDR_RECORD_DIDS[0]}"
        RESULT.InsertComment(
            f"[{report_timestamp()}] {covered} recorded into {into} and verified;"
            f" clearing NVM.")
        NVM_Clear_L61()

    # -- Restore the bench ---------------------------------------------------
    CAN.ChangeSignalValue(msg, sig, "0")
    crash_reference = None
    RESULT.InsertComment(
        f"[{report_timestamp(crash_reference)}] "
        + f"Restoring signal-carrying frame {timeout_frame}.")
    try:
        CAN.ReloadDefaultPeriodicFrame(timeout_frame)
        fault_call_error = None
    except Exception as raised:
        fault_call_error = raised
    RESULT.LogCustomAction(
        "Heal Message Timeout during cleanup",
        ("completed at [" + report_timestamp(crash_reference) + "]")
        if fault_call_error is None else
        f"raised {type(fault_call_error).__name__}: {fault_call_error}",
        "the bench call to complete without raising",
        TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
    CAN.ReloadDefaultPeriodicFrame(msg)
    fault_free_profile()
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
