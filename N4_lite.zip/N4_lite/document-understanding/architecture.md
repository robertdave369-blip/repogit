# Universal Document Understanding — architecture

## Position in the repository

    .github/skills/universal-document-understanding/
      SKILL.md            operational instructions for an AI agent
      README.md           orientation
      architecture.md     module map (points here for the design)
      references/         the seven topic guides
      schemas/            JSON Schema for document.json
      scripts/
        document_understand.py       CLI entry point
        document_context.py          fast lean extractor (pre-existing, reused)
        pdf_document_intelligence.py PDF engine (pre-existing, reused)
        udu/
          __init__.py     sibling-script loader
          model.py        canonical representation
          security.py     untrusted-input guards
          spreadsheet.py  spreadsheet structure and semantics
          adapters.py     format routing and parsers
          compile.py      AI context compiler + Markdown
          chunk.py        semantic chunking

    docs/document-understanding/   this directory
    research/document-parsers/     the evidence behind the design
    tests/test_universal_document_understanding.py

Scripts live under the skill because that is the established convention in this repository
(`.github/skills/<skill>/scripts/`). No new top-level package was introduced, and no
existing directory was reorganised.

## Pipeline

    INPUT (path or URL)
      │
      ├─ security.guard_file          size cap, symlink resolution
      ├─ adapters.detect              signature → container mimetype → extension
      ├─ security.guard_archive       zip bomb, member count, path traversal
      │
      ├─ adapters.build ──► format adapter
      │     xlsx  → openpyxl dual pass → SheetGrid → spreadsheet.analyse_sheet
      │     pdf   → PyMuPDF blocks, bboxes, TOC, caption binding
      │     docx  → python-docx heading stack, tables, images
      │     pptx  → python-pptx slides
      │     csv / html / md / text / json / xml / dbc → native
      │     images→ Pillow metadata + cheap classification (+ optional RapidOCR)
      │     odt / ods / odp / epub / eml / msg / rtf / latex → docling (optional)
      │
      ├─ canonical Document           elements + typed relationships + provenance
      ├─ security.scan_text           instruction-shaped passages flagged, never rewritten
      │
      ├─ compile.compile_context      compaction that keeps meaning and provenance
      ├─ compile.to_markdown          AI-friendly Markdown
      ├─ chunk.chunk_document         structural chunks with parent context
      └─ _validate                    quality gate

## Design decisions

### 1. One representation for every format

`Document` is a flat `dict[id, Element]` plus a root list, not a per-format tree. Adapters
differ; everything downstream — compiler, chunker, validator, debugger — is format-blind.
Adding a format means writing one adapter, and nothing else changes.

### 2. `basis` on every element

`EXTRACTED` / `INFERRED` / `MODEL_GENERATED` is a first-class field, not a convention. It
is what lets a consumer distinguish "the file says 15" from "we deduced this is a header"
from "OCR thinks this says 15". The validator enforces that `MODEL_GENERATED` elements
never claim certainty.

### 3. Provenance is structural, not decorative

`Source` is a dataclass with `page`, `sheet`, `cell`, `cell_range`, `slide`, `bbox`,
`section`, plus a rendered `locator`. Compaction may drop text; it may not drop `source`.
The validator fails on any element without one.

### 4. Stable, readable ids

`xlsx:Revenue!B7` rather than a UUID. A chunk stored in a vector database months ago still
resolves to a cell. Ids are sanitised, length-capped with a hash suffix, and de-duplicated
deterministically.

### 5. Reuse before reimplementation

`udu/__init__.py::load_sibling` imports the existing `document_context.py` by file path and
reuses its tested `detect_format`, `classify_authority`, `fingerprint` and `optional`.
Registering the module in `sys.modules` before `exec_module` is required: on Python 3.14
`@dataclass` resolves `cls.__module__` through `sys.modules`.

### 6. Optional dependencies are declared, never installed

`_optional()` returns `None` rather than raising, and the adapter records an `unsupported`
entry naming the exact `pip install` command. `deps` prints the whole picture. Nothing is
installed on the user's behalf.

### 7. Excel is never delegated

Docling opens workbooks `data_only=True` (`msexcel_backend.py:334-340`) and keeps no cell
formulas. Formula fidelity is a hard requirement here, so `.xlsx` always takes the local
openpyxl path. Docling's merged-cell *design* is adopted; its code is not.

## Extension points

| To add | Do this |
|---|---|
| A format | Write `_build_<fmt>` in `adapters.py`, add it to `dispatch`, add a detection rule if the signature is not already known. |
| A relationship type | Add to `Rel` in `model.py`, emit it from the adapter. Consumers ignore unknown edges. |
| A semantic rule | Extend `spreadsheet.py`. Keep the trust table honest — new inference means a new `INFERRED` row. |
| An OCR or vision engine | Follow `_try_ocr`: optional import, `MODEL_GENERATED`, real confidence, a `derived_from` edge. |
| An output format | Add a renderer in `compile.py` reading `compile_context`. |

## What deliberately is not here

* **No hosted service, no separate runtime, no vendored upstream copy** (§1).
* **No native binaries.** OCR is RapidOCR (ONNX wheels), not tesseract; legacy Office goes
  to docling, not a LibreOffice subprocess.
* **No vision model.** Images are classified cheaply and never described.
* **No embedding model or tokenizer.** Chunks are bounded by a character estimate.
