# Supported formats

`document_understand.py formats` prints this for the machine you are on, including which
optional parsers are actually installed.

## Native — no extra install beyond what this repository already has

| Format | Parser | What survives |
|---|---|---|
| **XLSX / XLSM** | openpyxl | sheets, hidden sheets/rows/columns, regions, merged ranges with anchors and spans, hierarchical headers, row roles, formulas **and** cached values, number formats, units, defined names, hyperlinks, cell comments |
| **PDF** | PyMuPDF | pages, rotation, page size, TOC, text blocks with bounding boxes, reading order, headings, captions bound to figures, images, scanned-PDF detection |
| **DOCX** | python-docx | heading hierarchy as sections, paragraphs, lists, tables with header-to-cell links, images, captions, core properties |
| **PPTX** | python-pptx *(optional)* | slides, titles, layouts, text frames, pictures |
| **CSV / TSV** | stdlib `csv` | header row, rows, cells, header-to-cell links |
| **HTML / URL** | beautifulsoup4 | heading hierarchy, paragraphs, lists, tables, images with alt text |
| **Markdown** | native | ATX heading hierarchy as sections, paragraph blocks |
| **TXT / LOG** | native | paragraph blocks, line and character counts |
| **JSON** | native | text blocks (structure-aware extraction is a known gap) |
| **XML / ARXML** | native | text blocks; entity expansion disabled |
| **DBC** | native | text blocks — for signal-level detail use the `dbc-to-json` skill |
| **PNG / JPEG / GIF / BMP / TIFF / WEBP** | Pillow | dimensions, mode, EXIF, inferred image class with rationale; optional OCR |
| **SVG** | native | treated as an image; no vector parsing |

## Via docling — `docling-slim`, MIT, optional

| Format | Extra |
|---|---|
| **ODT, ODS, ODP** | `format-opendocument` |
| **EPUB** | `format-web` |
| **`.eml`, `.msg`** | `format-email` |
| **RTF** | `format-web` |
| **LaTeX** | `format-latex` |
| **AsciiDoc** | `format-web` |

Install once:

    py -3 -m pip install "docling-slim[format-office,format-web,format-opendocument,format-pdf,format-email]"

Docling items are mapped into the same element graph, so downstream behaviour is identical
to a native format.

## Detected but not parsed natively

| Format | Status |
|---|---|
| **Legacy `.doc`, `.xls`, `.ppt`** | Detected by OLE signature. Routed to docling if installed; otherwise reported unsupported with the install command. This repository will **not** shell out to LibreOffice, which is how Unstructured handles them. |
| **Password-protected Office files** | Reported as a failed container. Not decrypted. |
| **Scanned PDFs without `--ocr`** | Structure extracted, text reported as `likely_scanned` with the fix. |
| **Math formula images** | Reported unsupported. MinerU's recognition stack is rejected (licence and Python 3.14); docling's needs torch. Never guessed. |

## Compute and model requirements

| Capability | CPU | GPU | Model download | Network |
|---|---|---|---|---|
| Detection, security guards, chunking, compilation | yes | no | none | no |
| XLSX, DOCX, PPTX, CSV, HTML, MD, text, XML, DBC | yes | no | none | no |
| PDF text, images, layout blocks | yes | no | none | no |
| Image metadata and classification | yes | no | none | no |
| ODT/ODS/EPUB/email via docling | yes | no | **none** | install only |
| **OCR (`--ocr`)** | yes | optional | **ONNX models on first use** | first run only |
| URL input | yes | no | none | **yes** |

**The default path is fully offline and CPU-only.** The only capability that downloads
anything is OCR, and it is opt-in.

## Formats deliberately not supported

Audio, video and speech transcription. Docling supports them (`format-audio`,
`format-video`) but they require whisper-class models, and no repository content needs
them. Adding them would be scope, not capability.
