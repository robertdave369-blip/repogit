# Dependencies and licences

Run `document_understand.py deps` to see what is present on the current machine.

Environment: **Python 3.14.0** (`C:\Python 3.14.0\python.exe`), Windows 11, no GPU assumed.

## Required

| Package | Version here | Licence | Enables |
|---|---|---|---|
| *(stdlib only)* | 3.14.0 | PSF | detection, text/CSV/JSON/XML/DBC, security guards, chunking, compilation |

The core layer runs on the standard library alone. Every parser is optional and degrades
to a reported `unsupported` entry rather than an exception.

## Optional — already installed in this environment

| Package | Version | Licence | Enables |
|---|---|---|---|
| `openpyxl` | 3.1.5 | MIT | **XLSX** — merged cells, formulas, cached values, number formats |
| `PyMuPDF` (`fitz`) | 1.26.7 | AGPL-3.0 (commercial licence available) | **PDF** — text blocks, bboxes, TOC, images |
| `python-docx` | 1.2.0 | MIT | **DOCX** |
| `Pillow` | 12.0.0 | MIT-CMU | **images** — dimensions, EXIF, classification |
| `beautifulsoup4` | 4.14.2 | MIT | **HTML** |
| `lxml` | 6.0.2 | BSD-3-Clause | XML parsing with entity resolution disabled |
| `pdfplumber` | 0.11.9 | MIT | targeted PDF table reads (not on the default path) |

> **PyMuPDF is AGPL-3.0.** It was already a dependency of this repository before this work
> and is used unchanged. Worth a deliberate decision if this tool is ever distributed
> outside the organisation; for internal use it is settled. `pypdfium2` (BSD/Apache) is the
> permissive alternative if that changes.

## Optional — not installed, offered with the exact command

| Package | Licence | Enables | Install |
|---|---|---|---|
| `python-pptx` | MIT | **PPTX** | `py -3 -m pip install python-pptx` |
| `docling-slim` | **MIT** | ODT, ODS, ODP, EPUB, `.eml`, `.msg`, RTF, LaTeX, AsciiDoc | `py -3 -m pip install "docling-slim[format-office,format-web,format-opendocument,format-pdf,format-email]"` |
| `rapidocr` + `onnxruntime` | Apache-2.0 | **OCR** for scanned PDFs and images | `py -3 -m pip install rapidocr onnxruntime` |

**None of these is installed automatically.** The tool prints the command; a person runs
it.

### Why `docling-slim` with narrow extras, and not `docling`

Measured with `pip install --dry-run` on this interpreter:

* `docling` pulls **torch 2.13, transformers 5.16, opencv, accelerate, docling-ibm-models,
  rapidocr** — multiple gigabytes, and model downloads on first use.
* `docling-slim[format-office,format-web,format-opendocument,format-pdf,format-email]`
  pulls **~30 small pure-Python packages, no torch, no transformers, no models**.

The format backends need no models. Only the layout, table-structure, OCR and VLM stages
do, and none of those is on our default path.

### Why RapidOCR and not tesseract

RapidOCR is ONNX-based and installs as wheels. Tesseract requires a **native binary
install**, which §1 of the governing spec forbids where a Python equivalent is practical.
RapidOCR downloads its ONNX models on first use, so it stays opt-in behind `--ocr`.

## Upstream projects inspected — and what was taken

Full evidence in [`research/document-parsers/`](../../research/document-parsers/).

| Project | Licence | Decision |
|---|---|---|
| **Docling** | MIT | **Adopted as an optional dependency.** One design pattern adopted without code: merged-cell indexing by anchor versus shadow with explicit spans (`docling/backend/msexcel_backend.py:154-212`). |
| **Unstructured** | Apache-2.0 | **Rejected as a dependency** (needs libmagic, poppler, tesseract, LibreOffice). **Two algorithms reimplemented and credited**: connected-component sub-table detection (`unstructured/partition/xlsx.py:282-335`) and leading/trailing single-cell row classification (`:401-441`). |
| **MinerU** | Apache-2.0 **plus additional terms** | **Rejected.** Cannot install on Python 3.14 (`requires-python >=3.10,<3.14`, confirmed by pip). Its additional terms require a separate commercial licence above **USD 20 M monthly revenue** or 100 M MAU, with automatic termination on breach — a real consideration for a tier-1 supplier. Nothing was taken. |

**No source file from any of these repositories is vendored into this repository.** The
clones used for inspection live in a temporary directory outside the repo.

### Attribution notices

The two reimplemented algorithms are credited in the module docstring of
`udu/spreadsheet.py` and in `research/document-parsers/comparison.md`. Because no
Apache-2.0 source was copied, no `NOTICE` file obligation is incurred — the credit is
given because it is owed, not because a licence compels it.

## Version pinning

This repository declares no `pyproject.toml` or `requirements.txt`. Versions above are
what is installed today, recorded so a future change is visible. If a manifest is ever
added, these are the entries.
