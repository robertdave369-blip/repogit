# Extraction strategy

Which parser handles what, why, and how the system behaves when it cannot do the job.

## Routing

| Format | Route | Why |
|---|---|---|
| **XLSX** | **always local (openpyxl)** | Docling discards cell formulas (`data_only=True`). Formula fidelity is a hard requirement. |
| PDF | local (PyMuPDF) | already a dependency, fast, gives bounding boxes and TOC |
| DOCX, PPTX, CSV, HTML, Markdown, text, XML, DBC | local | already available, no install cost |
| Images | local (Pillow) | metadata and cheap classification only |
| ODT, ODS, ODP, EPUB, eml, msg, RTF, LaTeX, AsciiDoc | **docling** | hand-writing an ODF or MIME parser to a worse standard is the wrong trade |
| Legacy .doc, .xls, .ppt | docling if present, else reported | never a LibreOffice subprocess |

The full evidence is in [`research/document-parsers/comparison.md`](../../research/document-parsers/comparison.md).

## Detection: signature, then container, then extension

1. **Magic bytes** — `%PDF-`, PNG, JPEG, OLE, `PK` (zip).
2. **Container inspection** — for `PK`, read the member list: `xl/workbook.xml` → xlsx,
   `word/document.xml` → docx, `ppt/presentation.xml` → pptx; then the `mimetype` member,
   which is how ODT/ODS/ODP/EPUB identify themselves.
3. **Extension** — last resort only.

Extensions lie. A `.xlsx` holding a PDF is detected as a PDF, and pinned by
`test_signature_beats_extension`.

## Escalation — cost is a design constraint

The whole point is to avoid loading raw files into a model context.

| Command | Output on a 220 KB workbook | Reduction |
|---|---|---|
| `inspect` | 4.3 KB | ~51x |
| `outline` | small | structure only |
| `search` | proportional to hits | targeted |
| `context --level 2` | 69 KB | ~3.2x |
| `analyze` | full | none — writes to disk |

`inspect` runs in about 1.4 s and `context` in about 1.8 s on that file. Start at
`inspect`; most questions never need more.

## Degradation ladder

Modelled on Unstructured's `AUTO → FAST → OCR_ONLY → HI_RES` idea, but explicit rather
than automatic:

1. **Parser present** — full extraction.
2. **Parser absent** — `unsupported` entry naming the exact `pip install` command. Never
   an exception, never a silent skip.
3. **Parser present but partial** — `partial` entry saying what was lost and why (merged
   ranges not enumerable, cached values unavailable, cell cap reached).
4. **Parser fails** — `failed` entry with the exception type and message, truncated. The
   rest of the document still extracts.

Four separate lists, never a boolean. Partial success is the normal case for real
documents, and hiding it is how an agent ends up reporting an empty file as empty.

## Caps, and why each exists

| Cap | Value | Reason |
|---|---|---|
| File size | 512 MB | generous for engineering workbooks; refuses at exit 2 |
| Archive members | 20,000 | member-count explosion |
| Uncompressed total | 4 GB | zip bomb |
| Per-member ratio | 200x on members over 10 MB | zip bomb, without tripping on legitimately compressible XML |
| Cells per sheet | 200,000 | bounded memory; reported when hit |
| Region scan | 400,000 occupied cells | above this the sheet is one region, reported |
| Dependency edges | 64 per formula, 2,000 cells per range | a whole-column reference must not explode the graph |

Every cap that bites produces a `partial` entry. A silent truncation would be worse than
the crash it prevents.

## Untrusted input

Documents are treated as hostile in two independent senses:

* **As files** — size, zip bomb, member count and archive path traversal are checked
  *before* parsing, and refusal uses a distinct exit code (`2`) so a caller can tell
  refusal from failure. XML is parsed with entity resolution and network access disabled.
* **As content** — text is scanned for instruction-shaped passages, which are **flagged
  and fenced, never rewritten**. See §7 of the SKILL and
  [`references/document-context-compilation.md`](../../.github/skills/universal-document-understanding/references/document-context-compilation.md).

The distinction matters: a malformed zip is refused, but a document that says "ignore all
previous instructions" is extracted faithfully and labelled. Censoring it would corrupt an
OEM requirement that legitimately says "ignore bit 7".

## What is never done

* No dependency is installed automatically.
* No value is invented — no OCR text without an OCR engine, no image description without a
  vision model, no chart values read off a picture.
* No cached formula value is fabricated when the workbook has none.
* No file under `shared_libraries/` or `projects/` is written; the tool only reads.
