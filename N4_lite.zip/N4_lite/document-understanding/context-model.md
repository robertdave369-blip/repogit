# The context model

The canonical representation, defined in `udu/model.py`. Schema:
[`ai-native-document.schema.json`](../../.github/skills/universal-document-understanding/schemas/ai-native-document.schema.json).

## Element

Every extracted thing is one `Element`:

| Field | Meaning |
|---|---|
| `id` | stable, readable, addressable — `cell:Revenue:D5`, `page:14` |
| `type` | see the type list below |
| `content` | text, when the element has text |
| `value` | typed value, when it has one (numbers, dates) |
| `source` | provenance — always present |
| `parent`, `children` | containment tree |
| `relationships` | typed edges beyond containment |
| `basis` | `EXTRACTED` / `INFERRED` / `MODEL_GENERATED` |
| `confidence` | 0–1; omitted from output when exactly 1.0 |
| `metadata` | type-specific: formula, span, unit, bbox, header, image class |

### Types

`document` `section` `heading` `paragraph` `list` `list_item` `table` `table_header`
`table_row` `table_cell` `figure` `caption` `chart` `page` `slide` `sheet` `region` `cell`
`formula` `note` `footnote` `code` `link` `metadata` `unsupported`

## Basis — the field that carries the honesty

| Value | Meaning | Example |
|---|---|---|
| `EXTRACTED` | read from the file | a cell value, a merged range, a page count |
| `INFERRED` | derived by our structural rules | region boundaries, header paths, row roles, column types, image class |
| `MODEL_GENERATED` | produced by OCR or a model | OCR text, with the engine's confidence |

A consumer that ignores `basis` will eventually report a guess as a fact. The validator
enforces one rule mechanically: a `MODEL_GENERATED` element may not claim certainty.

## Source (provenance)

    {
      "file": "financials.xlsx",
      "format": "xlsx",
      "authority": "PROJECT_DOCUMENTATION",
      "locator": "financials.xlsx -> Revenue -> D5",
      "sha256": "1e41be92...",
      "sheet": "Revenue",
      "cell": "D5",
      "section": "Financial Results"
    }

`page`, `cell_range`, `slide` and `bbox` appear where the format has them. `authority`
comes from this repository's own classification (`PROJECT_DOCUMENTATION`, `PROJECT_FILE`,
`PROJECT_CONFIGURATION`, `TOOL_OUTPUT`, `DERIVED`, `UNKNOWN`) so derived content is never
mistaken for a requirement source.

**Compaction never drops `source`.** That is checked by the validator and by
`test_compaction_keeps_provenance`.

## Relationships

Beyond `parent`/`children`:

| Edge | Meaning |
|---|---|
| `contains`, `follows` | structure and reading order |
| `belongs_to_section` | element to its section |
| `header_for` | header to table, cell to its column header |
| `merged_with` | covered cell (or covered header column) to its anchor |
| `caption_for` | caption to figure |
| `formula_depends_on` | cell to each cell its formula reads |
| `total_of` | a total or subtotal row to its table |
| `same_table`, `same_section`, `near` | proximity |
| `derived_from` | OCR text to the image it came from |
| `references` | figure to caption, and general cross-reference |

Edges are typed strings; a consumer that meets an unknown edge can ignore it. The validator
fails if any edge points at a non-existent element.

## Document

    {
      "schema_version": "2.0.0",
      "source":   { ... },
      "metadata": { "sheets": [...], "page_count": 19, "injection_finding_count": 4 },
      "pipeline": ["detect:xlsx", "guard:archive", "parse:openpyxl(dual data_only)",
                   "semantics:spreadsheet", "scan:injection"],
      "report":   { "successful": [], "partial": [], "unsupported": [], "failed": [] },
      "roots":    ["xlsx:financials"],
      "element_count": 214,
      "elements": [ ... ]
    }

`pipeline` records what actually ran, which makes a surprising result traceable without a
rerun. `report` is four separate lists, never a boolean: partial success is the normal case
for real documents and must be visible.

## Worked example — the specification's merged-cell case

`A1:D1 = "Financial Results"` above a table becomes:

    section  "Financial Results"           merged_anchor_for A1:F1, span 1x6
      └── table  A1:F8                     basis INFERRED, belongs_to_section
            ├── header "Region"            path ["Region"]
            ├── header "Revenue > 2025 > Q1"
            │     path ["Revenue","2025","Q1"], unit "$", type currency_measure
            │     covered_by B2:E2 → merged_with the anchor header
            ├── ...
            ├── row  role=data             "North America"
            │     ├── cell D5  value 15    header "Revenue > 2026 > Q1"
            │     └── ...
            └── row  role=total            total_of → table
                  └── cell B8  formula "=SUM(B5:B7)", cached_value ...,
                        depends_on ["Revenue!B5:B7"], formula_depends_on → B5,B6,B7

Not `A1 = "Financial Results", B1 = null, C1 = null, D1 = null`.
