# Deviation and discrepancy index

One entry point to every register in this repository that records where requirements, standards, OEM
behaviour, configuration and test artefacts disagree. The registers stay where they are (each is owned by
its domain); this index says where to look and how to classify. Owner:
`.github/agents/automotive-requirements-compliance.agent.md`.

## 1. Registers

| Register | IDs | Covers | Owner / location |
|---|---|---|---|
| Requirement discrepancy register | D-01 … D-12 | Contradictions inside or between OEM requirements (VIN inhibit, alive-counter rollover, DLC acceptance, PABON/PABOFF, NRC for SPR, EOL bit map, RSU table, message-timeout design trap, EOL defaults, INDC_PADL) | `.github/agents/agent_sc3.md` §3.1 |
| CAN NM OEM deviation matrix | NM-DEV-01 … NM-DEV-19 | OEM NM behaviour vs AUTOSAR R22-11 CanNm; timer-value conflicts | `docs/can-network-management/oem-deviation-matrix.md` |
| CAN NM findings / open questions | F-01 … F-10, Q-01 … Q-15 | Test-side config/script problems, missing NM facts | `docs/can-network-management/project-implementation.md` §5–§6 |
| UDS project profile | (in text; D-07 for SPR) | ISO 14229 vs the project's diagnostic profile | `agent_sc3.md` §4.3; "Project notes" in `.github/uds/services/` |
| EDR open questions | EDR-Q1 … EDR-Q15 | Part 563 / deck interpretation, axis and polarity | `.github/agents/edr-agent.agent.md` |
| EDR CAN-C open points | sections A–D | On-fail values, DBC vs spec, review decisions | `review/EDR_CANC_OPEN_POINTS.md` |
| Framework review | C-01 … C-04, H-01 … H-09, M-xx | Defects in the test framework itself (verdict integrity, power, wrappers) | `review/Framework_Review_Points.md` |
| Known failure signatures | KFS-01 … | Recurring failure causes with confirmation steps | `docs/engineering/known-failure-signatures.md` |
| Standards register open items | S-01 … S-03 | Missing editions / texts | `docs/compliance/standards-register.md` |
| Traceability findings | T-01 … | Requirement ↔ test-case link gaps | `docs/compliance/traceability.md` |

## 2. Classification (same in every domain)

| Classification | Meaning | Routing |
|---|---|---|
| Conformant | OEM requirement and the applicable standard agree, and the project follows both | **A** — implement/test to both |
| Permitted configuration choice | The standard leaves the value/feature to configuration; the project chose one | **B** — keep it; test the configured value |
| OEM extension / explicit deviation | An approved OEM requirement adds to or departs from the standard | **C** — keep it; test to the OEM requirement; state the difference |
| Apparent non-conformance / inconsistency | Sources disagree, or behaviour contradicts an approved requirement | **D** — investigate and report; never normalise silently |
| Unknown | Evidence missing | **E** — do the evidence-backed part; name what is missing |

Never call something a "standard violation" from a summary, a name or a passing test: the claim needs the
standard's text (edition named), the OEM requirement (ID, status Approved, right variant) and the observed
behaviour.

## 3. Adding an entry

Put the entry in the **owning** register (the table above), with evidence (file:line, requirement ID,
clause, log line), classification, routing path, validation status and follow-up. Add a new register here
only if no existing one fits.
