# Standards register

Which external standards this repository's work depends on, which edition is used, whether the text is
available to check against, and where the project-specific knowledge lives. Built 2026-10-26 from the
knowledge files (`.github/agents/`, `.github/uds/`, `.github/skills/`, `docs/can-network-management/`) and the
documents in `docs/project_documents/`. Owner: `.github/agents/automotive-requirements-compliance.agent.md`.

**Rules.** A standard's clause, table or value may be cited only from a text someone actually read (column
"Text available"). "Edition used" = the edition the knowledge base was written against, not necessarily
the one the ECU was developed to — the ECU's development editions are not documented in this repository
(open item S-01). Copyright: summarise in your own words; do not store standard texts in the repository
unless the user provides them.

| Standard | Used here for | Edition used | Text available | Knowledge lives in | Status |
|---|---|---|---|---|---|
| ISO 14229-1 (UDS) | All diagnostics, DTC handling, NRCs, security access, routines | 2020 + Amd 1:2022 (catalogue baseline); 2026 4th edition noted as published | Only a **pre-PRF draft of 2011** (`docs/project_documents/ISO_Documents/`) | `.github/uds/`, `agent_sc3.md` §4.3, `uds-protocol-engineer.agent.md` | Catalogue entries carry their own verification status; project deviations D-07 |
| ISO 15765-2 (ISO-TP) | Multi-frame diagnostics, flow control | not stated | No | `.github/uds/protocol-fundamentals.md`, `agent_sc3.md` | general knowledge |
| ISO 13400 (DoIP) | Explanation only — this ECU is diagnosed over CAN (0x730/0x738) | — | No | `.github/uds/protocol-fundamentals.md` | not applicable `[inference]` |
| ISO 11898-1/-2 (CAN, CAN FD, HS physical layer) | Bus, error handling, bus-off, wake-up | not stated | No | `agent_sc3.md` §4.1, §27.2; `docs/can-network-management/autosar-architecture.md` | general knowledge |
| AUTOSAR CP SWS CanNm (Doc ID 13) | NM baseline for the OEM deviation matrix | **R22-11** | Read 2026-10-26 (not stored) | `docs/can-network-management/` | 75 `SWS_CanNm_*` IDs verified |
| AUTOSAR E2E (Profile 5 on CAN FD) | Rx/Tx frame protection, message-content failures | Profile 5 stated; AUTOSAR release not stated | No | `agent_sc3.md` §2.2, §28.10; OEM `E2E Profile.xlsx` | profile parameters from OEM sheet |
| SAE J1850 CRC-8 | HS-CAN frame CRC (poly 0x1D, init 0xFF, XOR-out 0xFF) | — | No | `agent_sc3.md` §2.2, §28.10 | parameters stated with check value |
| AUTOSAR SecOC | `FR_ZONE2_100` freshness/MAC; DIAG_RE network-security DIDs 0x0105–0x010C | not stated | No | `agent_sc3.md` §28 | general + OEM DIDs |
| ISO 26262 | ASIL ratings on OEM requirements (e.g. NM requirements ASIL B); safety reasoning | not stated | No | `agent_sc3.md`, `safety-agent.agent.md`, skill `functional-safety-iso26262` | S-02 |
| ISO/SAE 21434, UNECE R155 | Secure diagnostics/flashing, SecOC, key handling | not stated | No | `agent_sc3.md` §28, `cybersecurity-agent.agent.md` | S-02 |
| 49 CFR Part 563 (EDR) | EDR content, ΔV recording, T0/locking | not stated (agent quotes sections) | Quoted sections in `edr-agent.agent.md` §4 | `edr-agent.agent.md`, `agent_sc3.md` §2.7–§2.8 | S-02 |
| UN R160, GB 39732, AIS-140 | EDR differences / alignment | not stated | No (summarised only) | `edr-agent.agent.md`, `agent_sc3.md` | summary only |
| PSI5 | RSU satellite interface | **v2.1** | No | `agent_sc3.md` §4.2 | stated |
| ISO 26021 (end-of-life activation of in-vehicle pyrotechnic devices) | "Scrap" sequence: scrap session, `27 5F`, `31 01 E2 00/01 XX`, `22 FA06`, IDs 0x7F1/0x7F9 | not stated | No; OEM flow in DIAG_RE sheet `ISO_SCRAP_Flow_Chart` | `.github/uds/` (0x10, 0x27), DIAG_RE | No Scrap test scripts exist (`projects/*/modules/Scrap/scripts/` empty) |
| Automotive SPICE | Process reference only | — | No | `agent_sc3.md` (3 mentions) | no ASPICE work products in the repository |
| MISRA C:2012 | ECU code rules (review only) | 2012 | No | `agent_sc3.md`, `architecture-agent.agent.md` | not applicable to this Python repository; ECU source is external and read-only |
| ISO 16750 | Environmental conditions (one IMU mention) | — | No | `imu-airbag-validator.agent.md` | mention only |
| SAE J1939, CANopen (CiA 301), OSEK NM | Contrast only, to avoid misconceptions | — | No | `docs/can-network-management/standards-and-terminology.md` §4 | not applicable |

## Open items

| ID | Item | Why it matters |
|---|---|---|
| S-01 | The ECU's development editions (ISO 14229-1, ISO 26262, ISO/SAE 21434, AUTOSAR release) are not documented in the repository | "Conformant" can only be said against a named edition |
| S-02 | ISO 26262, ISO/SAE 21434 / R155 and Part 563 are cited without edition | Clause-level claims cannot be checked; label them `[unverified]` |
| S-03 | No standard text is stored except the ISO 14229 2011 draft | Verification needs the user's licensed copies or official public releases (AUTOSAR) |
