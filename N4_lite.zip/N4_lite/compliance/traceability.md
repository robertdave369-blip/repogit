# Requirement traceability: method and current state

## 1. Method

Traceability chain: **requirement (Codebeamer, Approved, right variant) → test case (Codebeamer test
specification, `Verifies`) → script (`_ScriptPath`, or the framework script mapped to it) → result
(`_LatestResult`, or the run's HTML report and CAN log)**.

Measure it with:

```
py -3 tools/trace_coverage.py --req <requirement exports> --tests <test-spec exports> [--out <folder>]
```

It reads the exports only and reports Approved requirements without a linked test case, how each
`Verifies` link resolves (ID, unique name, ambiguous, unresolved), links to requirements that are not
Approved, unlinked test cases, script paths and latest results. A test case exported in several workbooks
counts once. Pass every requirement export a test specification may point to; an unresolved link means
"not resolvable from these exports", not "absent in Codebeamer".

Related tools: `tools/map_codebeamer_requirement_links.py` turns EDR name links into `[ISSUE:<id>]` links
(plan → review → write); `tools/test_task.py map` maps Codebeamer test cases to framework scripts inside a
test campaign.

## 2. Current state — M310_M314_M110 exports (measured 2026-10-26)

Inputs: the 20 requirement exports under `project_reuirements/m310_m314_m110/` (incl. `CAN C
Requirements/`) and the 38 test-specification exports under `project_testcases/m310_m314_m110/`, "(2)"
copies excluded.

| Measure | Value |
|---|---|
| Requirements read | 3005 (2577 functional: 617 Approved, 1159 In_Review, 614 Obsolete, 187 Init) |
| Approved requirements with at least one linked test case | **288 of 617** (286 through an ID link) |
| Distinct test cases | 2508 (1713 rows repeated in other workbooks) |
| Test cases with no `Verifies` link | 866 |
| Links by ID | 808 resolved, 88 to IDs in none of the exports |
| Links by name | 246 resolved, 207 ambiguous, 1361 unresolved |
| Script paths / latest results in the exports | none filled in |

Approved requirements without a linked test case, per export:

| Requirement export | Approved | Without a linked test case |
|---|---|---|
| DES_SW_Mahindra_EDR.xlsx | 170 | 168 |
| DES_SW_Mahindra_Network_Management.xlsx | 60 | 60 |
| Rx Message Requirements.xlsx | 249 | 41 |
| DES_SW_Mahindra_GPO.xlsx | 13 | 13 |
| Tx Message Requiements.xlsx | 71 | 12 |
| Battery Voltage Diagnostics.xlsx | 14 | 10 |
| CAN_INITIALISATION_MODE.xlsx | 6 | 6 |
| CRC and Alive Counter Overview.xlsx | 5 | 5 |
| CAN_Communication.xlsx | 5 | 4 |
| Missing ACK Stratergy.xlsx | 4 | 4 |
| Node Monitoring.xlsx | 8 | 3 |
| DTC Management.xlsx, Ignition Counter Update.xlsx, E2E Profile.xlsx | 1, 1, 4 | 1, 1, 1 |
| Buss Off Handling.xlsx | 6 | 0 |

The other requirement exports in the folder (UDS, FaultList, RSU, EOL) contain no Approved functional row
in this export.

## 3. Findings

| ID | Finding | Evidence | Meaning | Next step |
|---|---|---|---|---|
| T-01 | EDR test specifications link by requirement **name**: of 1218 distinct EDR test cases, 1196 carry a link and 2 resolve to an EDR requirement ID | `EDR/DES_SW_EDR_SwQTS.xlsx` and `EDR/canc_m314.xlsx` (overlapping exports) vs `DES_SW_Mahindra_EDR.xlsx` | EDR coverage cannot be shown from the exports — a link-data gap, not proof that EDR is untested | Convert the links with `tools/map_codebeamer_requirement_links.py`, or export the tracker the names point to |
| T-02 | No test specification links any NM requirement (60 Approved) | `DES_SW_Mahindra_Network_Management.xlsx` | NM has no test specification in the repository | `docs/can-network-management/test-case-catalogue.md` NM-TC-01..15 is the starting point |
| T-03 | IOControl and Bootloader specifications carry no requirement-ID links (Bootloader: none at all) | `DES_SW_IOControl_SwQTS.xlsx`, `DES_SW_Bootloader_SwQTS.xlsx` | Their coverage cannot be measured from these exports | Export with `Verifies`, or the requirement trackers they verify |
| T-04 | `_ScriptPath` and `_LatestResult` are empty in every export | all 38 workbooks | The test case → script → result part of the chain is not in Codebeamer exports | Use `tools/test_task.py map` and campaign results for those links |
| T-05 | Most functional requirements are not Approved (1159 In_Review, 187 Init) | requirement exports | Test cases may only trace to Approved rows (`agent_sc3.md` §16) | Confirm the status before writing a test case |

Re-run the tool after a new export and update this section with the date.
