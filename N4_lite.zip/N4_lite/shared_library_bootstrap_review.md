# Bootstrap layer review — `apym_imports`, `project_config_loader`, `framework_registry`

Inspection of the three files that bring the framework up: SDK discovery, project
detection, and config loading. **Nothing has been changed.**

Reviewed 2026-08-28 against the current working tree.

## Summary

These three are the cleanest files in `shared_libraries/`. The dead-code analysis finds
**zero** unused imports, unused module variables or dead locals in any of them, and all
three parse and import cleanly.

So this review is about behaviour, not cleanup. There are four findings, one of which can
silently make a script load the wrong project's configuration.

| # | Finding | Severity |
|---|---|---|
| 1 | Project detection disagrees between the two entry points | **High** — silent wrong config |
| 2 | Importing `apym_imports` attempts a bench connection | Medium |
| 3 | Project detection is not cached and costs ~13 ms per lookup at real stack depth | Medium |
| 4 | `list_available_projects()` reports non-projects | Low |

---

## 1. Split-brain project detection

`framework_registry.infer_project_name()` and `project_config_loader.get_active_project()`
resolve the project in **opposite orders**.

| | First | Then | Then |
|---|---|---|---|
| `infer_project_name()` | call-stack `projects/<NAME>/` path | `IOEM_FRAMEWORK_PROJECT` | — |
| `get_active_project()` | `set_active_project()` override | `IOEM_FRAMEWORK_PROJECT` | `infer_project_name()` |

Path first in one, environment first in the other. They agree whenever only one signal is
present, and disagree the moment both are.

Exactly **87 project scripts** are written like this:

```python
PROJECT_NAME = infer_project_name(Path(__file__)) or get_active_project()
```

`Path(__file__)` forces the path to win. Meanwhile every shared-library config lookup goes
through `get_active_project()`, where the environment wins. Reproduced:

```
IOEM_FRAMEWORK_PROJECT = ICE_01
  infer_project_name(start=<U171 script>)  -> U171
  get_active_project()                     -> ICE_01
```

A U171 script run with that variable set reports itself as U171 in its own report header
while `canc_config`, `edr_config` and every other lookup resolve against **ICE_01**. The
script does not fail; it silently tests the wrong configuration. On a bench that means
driving one variant's frames while asserting another variant's expectations.

This is not hypothetical: it is exactly the state my own verification harness created
earlier when it set `IOEM_FRAMEWORK_PROJECT=U171` to get the imports to resolve.

Worth deciding which signal should win and making both functions agree. My suggestion is
that the explicit override wins, then the script path, then the environment — the
environment being the weakest, since it is process-wide and the script path is specific.
But that is a policy call, and either order is fine as long as it is one order.

Affected files, for scope: 87 scripts under `projects/*/modules/{EOL,PlantMode,CANNM,Fault_List}/scripts/`,
plus `core_functions.py` lines 269 and 553 which call `infer_project_name(...)` directly.

---

## 2. Importing the module attempts a bench connection

`apym_imports.py` runs two calls at module scope:

| Line | Call |
|---|---|
| 125 | `ensure_apym_on_path()` |
| 258 | `refresh_apym_exports()` |

`refresh_apym_exports()` → `_try_load_real_apym()` → `apym.connection.Instance.init()`.

So on any machine where `apym` is installed, merely importing `apym_imports` — which
`import_list` does, which every generated script does — opens the ARIA handshake. Import
becomes an I/O operation with a timeout, before any script has decided it wants hardware.

Consequences worth weighing:

- A syntax check, a docs build or a unit-test collection pays the connection timeout.
- `init()` failure is swallowed here (`_try_load_real_apym` catches everything), so a
  half-initialised state can be reached without anyone being told.
- The same `init()` is also called by `init_aria()`, which every script calls explicitly
  right after importing. That is the call that *should* own the lifecycle.

The stubs already exist and work, so deferring line 258 to first use of `get_api()` /
`get_reporter()` would keep every consumer working while making import free of side
effects. `init_aria()` already calls `refresh_apym_exports()` itself, so scripts that
follow the documented bootstrap would see no change at all.

I could not execute this path to confirm the timing: `apym` is not installed in this
environment. The call chain above is read from the source and is unambiguous, but the
runtime cost is inference, not measurement.

---

## 3. Project detection is uncached and walks the whole call stack

`_candidate_paths()` calls `inspect.stack()`, which builds a `FrameInfo` for every frame
— and by default reads source context for each. Cost scales with stack depth:

| Call | Shallow stack | At stack depth 60 |
|---|---|---|
| `infer_project_name()` | 0.99 ms | **12.7 ms** |
| `locate_framework_root()` | 0.36 ms | — |

A test script running inside ARIA sits deep, so 12 ms is the realistic figure.

The config cache does not protect against this, because the detection happens *before* the
cache lookup:

```python
def _load_project_config_module(module_name, project=None):
    project = project or get_active_project()   # <- stack walk on every call
    cache_key = (project, module_name)
    cached = _PROJECT_CONFIG_CACHE.get(cache_key)
```

Every `_get_optional_project_config_symbol(...)` therefore pays full detection cost even
on a cache hit. `core_functions` resolves several config symbols lazily per operation, so
this compounds across a run.

Two independent fixes, either helps:

- Memoise the detected project (invalidated by `set_active_project`), which is what
  `reset_project_config_cache()` already implies should happen.
- Pass `inspect.stack(0)` to skip source-context reading — usually the bulk of the cost.

Setting `IOEM_FRAMEWORK_PROJECT` sidesteps it entirely, because `get_active_project()`
returns from the environment before reaching the stack walk. That is worth knowing but is
a workaround, not a fix — and per finding 1 it changes which project wins.

---

## 4. `list_available_projects()` reports directories that are not projects

It returns every directory under `projects/` that does not start with `__`:

```
['Aria_skills', 'canc_edr', 'EV_01', 'graphify-out', 'ICE_01',
 'M310_M314_M110', 'U171', 'UPP_EV', 'W610', 'W616', 'Z121']
```

Three of those have no `config/` directory and cannot be used as a project:
`Aria_skills`, `canc_edr`, and `graphify-out` (a tool output directory that happens to sit
there).

The list is only used in the "Active project could not be detected" error, so the impact
is a misleading message at the exact moment someone is already confused — it invites them
to try `graphify-out`. Filtering on `(entry / "config").is_dir()` would fix it.

---

## What is good here

Worth recording, since the rest of this document is problems:

- `framework_registry` genuinely is dependency-free as its docstring claims, so it is safe
  to import anywhere. That is what keeps the cycle manageable elsewhere.
- The `_LazyObjectProxy` / no-op stub pattern is the right shape: it lets the library
  import off-bench and fail only at the point of real hardware use.
- `_load_project_config_module`'s `allowed_missing` check is careful — it distinguishes
  "this project has no such config file" from "the config file exists but its own import
  failed", and re-raises the second. That distinction is easy to get wrong and is right here.
- Error messages name the thing that failed and what to do about it, which is why finding
  1 and finding 3 were diagnosable at all.

---

## Minor observations

Not worth a section each.

| File | Line | Note |
|---|---|---|
| `project_config_loader.py` | 93 | Commented-out debug print left in |
| `project_config_loader.py` | 120 | Commented-out debug print, after `return` — unreachable even if enabled |
| `project_config_loader.py` | 68 | Commented-out debug print |
| `apym_imports.py` | 3–16 | Docstring says "four small surface helpers"; `__all__` exports eight |
| `apym_imports.py` | 168 | `_apym_cache` is initialised without the `"Instance"` key that `_try_load_real_apym()` returns; harmless because `update()` adds it, but the two should match |

---

## Suggested order

1. Decide the project-detection precedence and make both functions agree (finding 1).
   This is the only one that can produce a wrong test result.
2. Filter `list_available_projects()` (finding 4) — one line, makes finding 1's error
   message trustworthy.
3. Memoise project detection (finding 3).
4. Defer the import-time `refresh_apym_exports()` (finding 2), once someone can test it on
   a machine with `apym` installed.

Tell me which to apply and I will make the changes.
