"""
Build Framework_IOEM_Py_Architecture_Guide.pdf — a beginner-to-architect
walkthrough of how the Framework_IOEM_Py codebase is wired together.

Run:
    python docs_build_architecture_pdf.py
Output:
    C:/Framework_IOEM_Py/Framework_IOEM_Py_Architecture_Guide.pdf
"""

from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Preformatted,
    Spacer,
    Table,
    TableStyle,
)


# ── Visual palette ──────────────────────────────────────────────────────────
PRIMARY = colors.HexColor("#1F3A68")      # deep navy
ACCENT  = colors.HexColor("#2E7D8F")      # teal
WARN    = colors.HexColor("#B36B00")      # amber
GOOD    = colors.HexColor("#2E7D32")      # green
BG_CODE = colors.HexColor("#F2F4F7")      # very light gray-blue
BORDER  = colors.HexColor("#D0D7DE")
SOFT    = colors.HexColor("#5C6C7C")
PAGEBG  = colors.HexColor("#FFFFFF")
CALLOUT = colors.HexColor("#EEF4FB")
INFO    = colors.HexColor("#1565C0")


# ── Styles ──────────────────────────────────────────────────────────────────
base = getSampleStyleSheet()

S_TITLE = ParagraphStyle(
    "Title", parent=base["Title"],
    fontName="Helvetica-Bold", fontSize=28, leading=34,
    textColor=PRIMARY, alignment=TA_CENTER, spaceAfter=10,
)
S_SUB = ParagraphStyle(
    "Sub", parent=base["Normal"],
    fontName="Helvetica", fontSize=13, leading=17,
    textColor=SOFT, alignment=TA_CENTER, spaceAfter=18,
)
S_H1 = ParagraphStyle(
    "H1", parent=base["Heading1"],
    fontName="Helvetica-Bold", fontSize=20, leading=24,
    textColor=PRIMARY, spaceBefore=18, spaceAfter=10,
)
S_H2 = ParagraphStyle(
    "H2", parent=base["Heading2"],
    fontName="Helvetica-Bold", fontSize=14, leading=18,
    textColor=ACCENT, spaceBefore=14, spaceAfter=6,
)
S_H3 = ParagraphStyle(
    "H3", parent=base["Heading3"],
    fontName="Helvetica-Bold", fontSize=11.5, leading=15,
    textColor=PRIMARY, spaceBefore=10, spaceAfter=3,
)
S_BODY = ParagraphStyle(
    "Body", parent=base["BodyText"],
    fontName="Helvetica", fontSize=10.5, leading=15,
    textColor=colors.HexColor("#1F2933"),
    spaceAfter=6, alignment=TA_JUSTIFY,
)
S_BODY_TIGHT = ParagraphStyle(
    "BodyTight", parent=S_BODY,
    spaceAfter=2,
)
S_BULLET = ParagraphStyle(
    "Bullet", parent=S_BODY,
    leftIndent=14, bulletIndent=4,
    spaceAfter=2,
)
S_CODE = ParagraphStyle(
    "Code", parent=base["Code"],
    fontName="Courier", fontSize=9, leading=12,
    textColor=colors.HexColor("#0E2440"),
    backColor=BG_CODE,
    borderColor=BORDER, borderWidth=0.5, borderPadding=6,
    leftIndent=0, rightIndent=0, spaceBefore=4, spaceAfter=8,
)
S_CALLOUT_TITLE = ParagraphStyle(
    "CalloutTitle", parent=S_BODY,
    fontName="Helvetica-Bold", textColor=INFO, fontSize=10.5,
    spaceAfter=2,
)
S_CALLOUT_BODY = ParagraphStyle(
    "CalloutBody", parent=S_BODY,
    textColor=colors.HexColor("#1A3A60"),
    spaceAfter=0,
)
S_TOC_ITEM = ParagraphStyle(
    "Toc", parent=S_BODY,
    fontName="Helvetica", fontSize=11, leading=16,
    leftIndent=8, spaceAfter=2,
)
S_FOOTER = ParagraphStyle(
    "Footer", parent=S_BODY,
    fontSize=8, textColor=SOFT, alignment=TA_CENTER,
)


# ── Helpers ─────────────────────────────────────────────────────────────────
def code(text: str):
    return Preformatted(text.rstrip(), S_CODE)


def callout(title: str, body_paragraphs):
    if isinstance(body_paragraphs, str):
        body_paragraphs = [body_paragraphs]
    inner = [Paragraph(title, S_CALLOUT_TITLE)]
    for b in body_paragraphs:
        inner.append(Paragraph(b, S_CALLOUT_BODY))
    t = Table([[inner]], colWidths=[16.2 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CALLOUT),
        ("BOX", (0, 0), (-1, -1), 0.7, INFO),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    return KeepTogether([t, Spacer(1, 8)])


def bullets(items):
    return [Paragraph(f"•&nbsp;&nbsp;{t}", S_BULLET) for t in items]


def kv_table(rows, col_widths=(5.4 * cm, 10.8 * cm)):
    data = [[Paragraph(f"<b>{k}</b>", S_BODY), Paragraph(v, S_BODY)] for k, v in rows]
    t = Table(data, colWidths=list(col_widths))
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F7F9FC")),
        ("BOX", (0, 0), (-1, -1), 0.4, BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.3, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def hr():
    t = Table([[""]], colWidths=[16.2 * cm], rowHeights=[1])
    t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.5, BORDER)]))
    return t


# ── Page chrome (footer) ────────────────────────────────────────────────────
def on_page(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(2 * cm, 1.6 * cm, A4[0] - 2 * cm, 1.6 * cm)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(SOFT)
    canvas.drawString(2 * cm, 1.1 * cm, "Framework_IOEM_Py — Architecture Guide")
    canvas.drawRightString(A4[0] - 2 * cm, 1.1 * cm, f"Page {doc.page}")
    canvas.restoreState()


# ── Content sections ────────────────────────────────────────────────────────
def section_cover():
    story = []
    story.append(Spacer(1, 4 * cm))
    story.append(Paragraph("Framework_IOEM_Py", S_TITLE))
    story.append(Paragraph(
        "Architecture, Imports, Lazy Loading &amp; Pylance — Beginner to Architect",
        S_SUB,
    ))
    story.append(Spacer(1, 0.6 * cm))
    story.append(hr())
    story.append(Spacer(1, 0.6 * cm))
    story.append(Paragraph(
        "<b>Audience</b>: developers new to Python who need to read, debug and "
        "extend this multi-project automotive test framework — and grow into "
        "people who can design new projects, new layers, and new tooling.",
        S_BODY,
    ))
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph(
        "<b>What you'll learn</b>: how every test script wires itself to the "
        "framework with three lines, what those three lines actually do, how "
        "imports are layered, why a deliberate dependency cycle is safe, how "
        "Pylance can still resolve names through that cycle, why every module "
        "declares <font face='Courier'>__all__</font>, and how the ARIA / Apym "
        "bench connection bootstraps itself (or fakes itself when off-bench).",
        S_BODY,
    ))
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph(
        "Read it once cover-to-cover for the mental model. Then keep it next "
        "to your editor as a reference when you add a project, write a config, "
        "or chase down an <font face='Courier'>ImportError</font>.",
        S_BODY,
    ))
    story.append(PageBreak())
    return story


def section_toc():
    story = [Paragraph("Table of Contents", S_H1), Spacer(1, 6)]
    items = [
        "1.  The 30-second mental model",
        "2.  Repository layout (where everything lives)",
        "3.  How a test script bootstraps itself",
        "4.  The five-layer architecture",
        "5.  Apym / ARIA: the bench connection bridge",
        "6.  Lazy loading: proxies, why &amp; how",
        "7.  The intentional cycle between core_functions and jscript_translation",
        "8.  <font face='Courier'>__all__</font>: explicit star-import surface",
        "9.  Pylance, pyrightconfig.json and TYPE_CHECKING",
        "10. Project-aware configuration loading",
        "11. The <font face='Courier'>parents[5]</font> path bootstrap, explained",
        "12. Adding a new project (step-by-step)",
        "13. Adding a new test script (step-by-step)",
        "14. Debugging guide: ImportError, AttributeError, hangs",
        "15. Glossary",
    ]
    for it in items:
        story.append(Paragraph(it, S_TOC_ITEM))
    story.append(PageBreak())
    return story


def section_mental_model():
    story = [Paragraph("1.  The 30-second mental model", S_H1)]
    story.append(Paragraph(
        "Think of Framework_IOEM_Py as a stack of five layers, each one calling "
        "<b>down</b> into the layer below it. A test script sits on top. It "
        "imports a handful of names from the shared library. Those names are "
        "thin wrappers that ultimately talk to the bench through Apym (the "
        "ARIA test-bench SDK).",
        S_BODY,
    ))
    story.append(callout(
        "Why this matters",
        "Once you know the layer of any symbol you look at, you know what it can do, "
        "what it imports, and what is safe to change. Most bugs in this codebase "
        "come from accidentally inverting the layering."
    ))
    story.append(Paragraph(
        "A test script is, by convention, just a function called "
        "<font face='Courier'>run_test()</font>. The script's job is to: (1) "
        "wake up the bench, (2) drive CAN signals or power, (3) trigger an "
        "event (e.g. a crash), (4) read the ECU back, (5) write an HTML "
        "report. Every one of those verbs is a one-liner in the shared "
        "library.",
        S_BODY,
    ))
    story.append(PageBreak())
    return story


def section_layout():
    story = [Paragraph("2.  Repository layout", S_H1)]
    story.append(code(
        "C:/Framework_IOEM_Py/\n"
        "├── pyrightconfig.json          ← Pylance/Pyright settings\n"
        "├── .vscode/settings.json       ← Python interpreter + analysis paths\n"
        "├── shared_libraries/           ← ALL projects use these\n"
        "│   ├── __init__.py             (just a package docstring + layering notes)\n"
        "│   ├── framework_registry.py   (Layer 0) locates the framework root\n"
        "│   ├── apym_imports.py         (Layer 0) wraps the Apym SDK\n"
        "│   ├── configuration_control.py (Layer 0) global constants / Enums\n"
        "│   ├── can_library.py          (Layer 0) CAN signal/frame defs\n"
        "│   ├── crash_configuration.py  (Layer 0) crash-curve paths\n"
        "│   ├── data_conversions.py     (Layer 1) byte/sample utilities\n"
        "│   ├── project_config_loader.py(Layer 1) dynamic project config\n"
        "│   ├── fault_monitor.py        (Layer 2) DTC monitors\n"
        "│   ├── ascent_batch_lib.py     (Layer 2) Ascent CLI + RESULT proxy\n"
        "│   ├── core_functions.py       (Layer 3) ★ orchestration + lazy proxies\n"
        "│   ├── jscript_translation.py  (Layer 4) ★ real CAN/PS/RSU/SPI classes\n"
        "│   ├── check_sequence.py       (Layer 5)\n"
        "│   ├── infineon_memtool.py     (Layer 5)\n"
        "│   ├── winidea.py              (Layer 5)\n"
        "│   └── import_list.py          star-import aggregator (legacy convenience)\n"
        "└── projects/\n"
        "    ├── U171/                   ← project package\n"
        "    │   ├── __init__.py         (just PROJECT_NAME = 'U171')\n"
        "    │   ├── config/             ← project-specific values\n"
        "    │   │   ├── project_config.py\n"
        "    │   │   ├── edr_config.py\n"
        "    │   │   ├── rsu_config.py\n"
        "    │   │   └── ...one config file per subsystem\n"
        "    │   └── modules/\n"
        "    │       └── EDR/\n"
        "    │           ├── scripts/    ← test scripts live here\n"
        "    │           └── test_data/  ← input CSVs/XLSXs, etc.\n"
        "    ├── M310_M314_M110/         ← other projects, same shape\n"
        "    ├── UPP_EV/\n"
        "    ├── W610/\n"
        "    ├── W616/\n"
        "    └── Z121/"
    ))
    story.append(callout(
        "Two invariants",
        [
            "1.  <b>Shared logic NEVER reaches into a project</b>. It reaches a project "
            "<i>indirectly</i> via <font face='Courier'>project_config_loader</font>, "
            "which detects which project is running and imports its config.",
            "2.  <b>Project code NEVER edits shared logic</b>. It supplies values "
            "(DIDs, frame names, sensitivities) — all behaviour lives in shared."
        ],
    ))
    story.append(PageBreak())
    return story


def section_bootstrap():
    story = [Paragraph("3.  How a test script bootstraps itself", S_H1)]
    story.append(Paragraph(
        "Every script under <font face='Courier'>projects/&lt;P&gt;/modules/&lt;M&gt;/scripts/</font> "
        "starts with the same four-block preamble. The blocks are identical "
        "across projects on purpose — copy-paste is the intended way to start "
        "a new test.",
        S_BODY,
    ))
    story.append(Paragraph("Block 1: path bootstrap", S_H2))
    story.append(code(
        "import os, sys\n"
        "from pathlib import Path\n\n"
        "# Make Framework_IOEM_Py importable as a top-level package\n"
        "_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]\n"
        "if str(_FRAMEWORK_ROOT.parent) not in sys.path:\n"
        "    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))"
    ))
    story.append(Paragraph(
        "<b>What <font face='Courier'>parents[5]</font> means.</b> Counting from the "
        "script: parents[0] is <font face='Courier'>scripts/</font>, [1] is "
        "<font face='Courier'>EDR/</font>, [2] <font face='Courier'>modules/</font>, "
        "[3] <font face='Courier'>U171/</font>, [4] <font face='Courier'>projects/</font>, "
        "[5] <font face='Courier'>Framework_IOEM_Py/</font>. Section 11 has a "
        "diagram.",
        S_BODY,
    ))
    story.append(Paragraph("Block 2: ARIA bring-up", S_H2))
    story.append(code(
        "from Framework_IOEM_Py.shared_libraries.apym_imports import (\n"
        "    ensure_apym_on_path,\n"
        "    init_aria,\n"
        ")\n"
        "ensure_apym_on_path()   # locate apym SDK and put it on sys.path\n"
        "init_aria()             # open the connection to the ARIA bench tool\n\n"
        "from apym.connection import Instance as aria_instance     # type: ignore\n"
        "from apym.reports    import ApymReports as aria_reports   # noqa: E402"
    ))
    story.append(callout(
        "Idempotent on purpose",
        "<font face='Courier'>init_aria()</font> can be called many times. It treats "
        "'already initialized' as success. This means importing two test scripts in "
        "the same Python process does not blow up."
    ))
    story.append(Paragraph("Block 3: shared symbols", S_H2))
    story.append(code(
        "from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT\n"
        "from Framework_IOEM_Py.shared_libraries.can_library      import MAH_CAN_SIGNAL_DEFS\n"
        "from Framework_IOEM_Py.shared_libraries.core_functions   import (\n"
        "    Sleep, Wait, TriggerCrash, create_report_and_logging, ...\n"
        ")\n"
        "from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS"
    ))
    story.append(Paragraph("Block 4: project config", S_H2))
    story.append(code(
        "from Framework_IOEM_Py.projects.U171.config.edr_config import (\n"
        "    EDR_DIDS, EDR_PARAMETERS,\n"
        ")"
    ))
    story.append(Paragraph(
        "These four blocks are the <b>only</b> source of all names you see in "
        "the rest of the script. Master them and you've mastered 90% of how "
        "the framework is consumed.",
        S_BODY,
    ))
    story.append(PageBreak())
    return story


def section_layers():
    story = [Paragraph("4.  The five-layer architecture", S_H1)]
    story.append(Paragraph(
        "Each module lives at a specific layer. A module at layer N may import "
        "any module at layer &lt; N. It must <b>never</b> import a module at "
        "layer ≥ N. The only exception is the deliberate "
        "<font face='Courier'>core_functions ↔ jscript_translation</font> cycle, "
        "which is broken via deferred imports (see section 7).",
        S_BODY,
    ))
    story.append(kv_table([
        ("Layer 0 — utility",
         "<font face='Courier'>framework_registry, apym_imports, configuration_control, "
         "crash_configuration, can_library, dcs_library, edr_did_library, excel_handler</font>"
         "<br/>Pure data &amp; SDK shims. No project knowledge, no bench dependence."),
        ("Layer 1 — loaders",
         "<font face='Courier'>project_config_loader</font> (uses framework_registry); "
         "<font face='Courier'>data_conversions</font> (uses configuration_control + "
         "project_config_loader)."),
        ("Layer 2 — services",
         "<font face='Courier'>fault_monitor, ascent_batch_lib</font>. Use Layer 0–1 only. "
         "Defer jscript_translation behind deferred imports."),
        ("Layer 3 — orchestration",
         "<font face='Courier'>core_functions</font>. Defines the high-level verbs every "
         "test calls (Sleep, Wait, Read_DTC, TriggerCrash, power, security). "
         "Uses Layer 0–2 + apym_imports. Carries lazy proxies for CAN/PS/RSU/etc."),
        ("Layer 4 — apym surface",
         "<font face='Courier'>jscript_translation</font>. The real CAN/PS/RSU/SPI/ARIA/LAMPS "
         "classes that wrap Apym. Imports a few names from core_functions "
         "(Internal_Security_Access, enter_ext_session) — this is the cycle."),
        ("Layer 5 — debug bridges",
         "<font face='Courier'>winidea, infineon_memtool, check_sequence</font>. Consume "
         "everything below. Useful in special workflows; ordinary tests usually "
         "do not touch them."),
    ]))
    story.append(Spacer(1, 6))
    story.append(callout(
        "Mental check before adding an import",
        "<i>If I'm in module X (Layer N), is the symbol I want defined at Layer &lt; N?</i> "
        "If yes — import it normally. If no — either move the symbol down, or use a "
        "deferred import inside a function body (see Section 7)."
    ))
    story.append(PageBreak())
    return story


def section_apym():
    story = [Paragraph("5.  Apym / ARIA: the bench connection bridge", S_H1)]
    story.append(Paragraph(
        "<b>Apym</b> is the Python SDK for the ARIA test-bench tool. It is "
        "<i>not</i> pip-installed; it ships as an sdist under "
        "<font face='Courier'>C:/Python 3.14.0/Lib/apym-2.6.0/src/apym/</font>. "
        "The framework has to teach Python where to find it, then bring up the "
        "TCP connection to the bench, before any "
        "<font face='Courier'>import apym...</font> works.",
        S_BODY,
    ))
    story.append(Paragraph(
        "Both jobs live in <font face='Courier'>shared_libraries/apym_imports.py</font>.",
        S_BODY,
    ))
    story.append(Paragraph("ensure_apym_on_path()", S_H2))
    story.append(code(
        "# Pseudocode of what it does:\n"
        "1. Try `import apym`. If it works, return.\n"
        "2. Build a list of candidate directories:\n"
        "   - $APYM_SRC if set\n"
        "   - <sys.prefix>/Lib/apym-*/src   (the typical layout)\n"
        "   - every `Lib/apym-*/src` under each sys.path entry\n"
        "3. For each candidate that has `<candidate>/apym/__init__.py`,\n"
        "   prepend it to sys.path and return."
    ))
    story.append(Paragraph("init_aria()", S_H2))
    story.append(code(
        "ensure_apym_on_path()\n"
        "from apym.connection import Instance\n"
        "try:\n"
        "    Instance.init()       # opens the connection to ARIA\n"
        "except Exception as exc:\n"
        "    if 'already initialized' not in str(exc).lower():\n"
        "        raise            # bench truly offline → bail loudly\n"
        "refresh_apym_exports()    # re-populate the cache of Api/Reporter/Types"
    ))
    story.append(Paragraph("Off-bench safety: no-op fallbacks", S_H2))
    story.append(Paragraph(
        "If <font face='Courier'>apym</font> is unimportable (e.g. running on a "
        "developer laptop), <font face='Courier'>get_reporter(strict=False)</font> "
        "returns a <font face='Courier'>_NoOpReporter</font> whose every method is "
        "a no-op. Imports still succeed; the test just doesn't do anything bench-"
        "side. This is what makes unit tests and editor type-checking work "
        "without the bench tool installed.",
        S_BODY,
    ))
    story.append(callout(
        "Two accessors, same data",
        [
            "<font face='Courier'>get_api(strict=True)</font> — raises if ARIA is offline. Use in production paths.",
            "<font face='Courier'>get_api(strict=False)</font> — returns None or a no-op stub. Use in code that needs to import even off-bench.",
        ],
    ))
    story.append(PageBreak())
    return story


def section_lazy():
    story = [Paragraph("6.  Lazy loading: proxies, why &amp; how", S_H1)]
    story.append(Paragraph(
        "Two kinds of lazy loading live in this framework — and both exist for "
        "specific, real reasons.",
        S_BODY,
    ))
    story.append(Paragraph("6.1  <font face='Courier'>_LazyMappingProxy</font>", S_H2))
    story.append(Paragraph(
        "Some constants in <font face='Courier'>core_functions</font> "
        "(<font face='Courier'>SENSOR_TO_RSU_CHANNEL, SENSOR_SENSITIVITY, "
        "CRASH_CURVE_CONFIG</font>, …) really live in <i>project</i> config "
        "files. But Layer 3 doesn't know which project is running until a "
        "script under <font face='Courier'>projects/&lt;P&gt;/</font> imports it.",
        S_BODY,
    ))
    story.append(code(
        "class _LazyMappingProxy(Mapping[str, Any]):\n"
        "    def __init__(self, resolver):  # resolver is a 0-arg callable\n"
        "        self._resolver = resolver\n"
        "    def __getitem__(self, key):\n"
        "        return self._resolver()[key]    # resolves on first access\n\n"
        "SENSOR_TO_RSU_CHANNEL = _LazyMappingProxy(\n"
        "    lambda: _get_project_config_symbol('rsu_config', 'SENSOR_TO_RSU_CHANNEL')\n"
        ")"
    ))
    story.append(callout(
        "The trick",
        "At <i>import time</i>, <font face='Courier'>SENSOR_TO_RSU_CHANNEL</font> is just a "
        "proxy object — no project config is loaded yet, so the framework "
        "imports cleanly regardless of which project is active. The first time "
        "anyone does <font face='Courier'>SENSOR_TO_RSU_CHANNEL['LH_FRONT']</font>, "
        "the proxy detects the active project, loads its "
        "<font face='Courier'>rsu_config.py</font>, and returns the value."
    ))
    story.append(Paragraph("6.2  <font face='Courier'>_LazyObjectProxy</font>", S_H2))
    story.append(Paragraph(
        "Same pattern for jscript classes. The runtime objects "
        "(<font face='Courier'>CAN, PS, RSU, SPI, ARIA, LAMPS, RESULT</font>) live in "
        "<font face='Courier'>jscript_translation</font>. But "
        "<font face='Courier'>core_functions</font> wants to expose them too — "
        "without importing jscript_translation at module load (that would close "
        "the cycle; see Section 7).",
        S_BODY,
    ))
    story.append(code(
        "class _LazyObjectProxy:\n"
        "    def __init__(self, resolver):\n"
        "        self._resolver = resolver\n"
        "    def __getattr__(self, item):\n"
        "        return getattr(self._resolver(), item)\n\n"
        "# Resolves on first attribute access, NOT at module import:\n"
        "CAN    = _LazyObjectProxy(lambda: _get_jscript_symbol('CAN'))\n"
        "RESULT = _LazyObjectProxy(lambda: _get_jscript_symbol('RESULT'))\n"
        "PS     = _LazyObjectProxy(lambda: _get_jscript_symbol('PS'))\n"
        "# ..."
    ))
    story.append(Paragraph(
        "First time you write <font face='Courier'>CAN.ChangeSignalValue(...)</font>, "
        "Python calls <font face='Courier'>CAN.__getattr__('ChangeSignalValue')</font>, "
        "which calls the resolver, which imports "
        "<font face='Courier'>jscript_translation</font> lazily, fetches the real "
        "<font face='Courier'>CAN</font> class, and returns its "
        "<font face='Courier'>ChangeSignalValue</font> attribute. From your "
        "script's perspective it's just an attribute lookup.",
        S_BODY,
    ))
    story.append(PageBreak())
    return story


def section_cycle():
    story = [Paragraph("7.  The intentional cycle between core_functions and jscript_translation", S_H1)]
    story.append(Paragraph(
        "<b>The shape of the cycle.</b> "
        "<font face='Courier'>core_functions</font> wants to call CAN/PS classes "
        "from <font face='Courier'>jscript_translation</font>. "
        "<font face='Courier'>jscript_translation</font> wants to call "
        "<font face='Courier'>Internal_Security_Access</font> and "
        "<font face='Courier'>enter_ext_session</font> from "
        "<font face='Courier'>core_functions</font>. If both imported each "
        "other at the top of the file, Python would hit a half-initialised "
        "module mid-import — classic circular-import error.",
        S_BODY,
    ))
    story.append(Paragraph("Three things break the cycle:", S_H3))
    story.append(Paragraph(
        "<b>(a) jscript_translation imports normally from core_functions.</b> "
        "It only needs two function names; both are already defined by the time "
        "jscript_translation loads.",
        S_BODY,
    ))
    story.append(code(
        "# jscript_translation.py (top of file)\n"
        "from .core_functions import Internal_Security_Access, enter_ext_session"
    ))
    story.append(Paragraph(
        "<b>(b) core_functions does <i>not</i> import jscript_translation at the top.</b> "
        "Instead, it defines a tiny helper and a lazy proxy:",
        S_BODY,
    ))
    story.append(code(
        "# core_functions.py\n\n"
        "def _get_jscript_symbol(name: str):\n"
        "    from . import jscript_translation as jt     # deferred import\n"
        "    return getattr(jt, name)\n\n"
        "CAN    = _LazyObjectProxy(lambda: _get_jscript_symbol('CAN'))\n"
        "RESULT = _LazyObjectProxy(lambda: _get_jscript_symbol('RESULT'))\n"
        "# ..."
    ))
    story.append(Paragraph(
        "Because the import of jscript_translation happens <i>inside a "
        "function</i>, it does not run at module load time. By the time you "
        "actually call <font face='Courier'>CAN.Something(...)</font>, both "
        "modules are fully loaded and the import is safe.",
        S_BODY,
    ))
    story.append(Paragraph(
        "<b>(c) A <font face='Courier'>TYPE_CHECKING</font> block gives Pylance "
        "a real reference.</b> Pylance evaluates this block at analysis time "
        "but Python skips it at runtime, so it's free.",
        S_BODY,
    ))
    story.append(code(
        "from typing import TYPE_CHECKING\n"
        "if TYPE_CHECKING:\n"
        "    from .jscript_translation import (\n"
        "        ARIA, CAN, CurveData, LAMPS, PS, RESULT, RSU, SPI,\n"
        "    )\n"
        "# ↑ at runtime, this block is skipped, so NO circular import.\n"
        "# ↑ at analysis time, Pylance sees the real classes and Go-to-\n"
        "#   Definition jumps to jscript_translation.py.\n\n"
        "if not TYPE_CHECKING:\n"
        "    # Runtime-only bindings — the lazy proxies\n"
        "    CAN    = _LazyObjectProxy(lambda: _get_jscript_symbol('CAN'))\n"
        "    PS     = _LazyObjectProxy(lambda: _get_jscript_symbol('PS'))\n"
        "    # ..."
    ))
    story.append(callout(
        "Why this is elegant",
        [
            "At <b>runtime</b>, only proxies exist on Layer 3 — no eager import = no cycle.",
            "At <b>analysis time</b>, Pylance sees the real classes — autocomplete and Go-to-Definition still work.",
            "At <b>call time</b>, the proxy resolves once and forwards every attribute access.",
        ],
    ))
    story.append(PageBreak())
    return story


def section_all():
    story = [Paragraph("8.  <font face='Courier'>__all__</font>: explicit star-import surface", S_H1)]
    story.append(Paragraph(
        "<font face='Courier'>__all__</font> is a list of strings that controls "
        "what <font face='Courier'>from module import *</font> brings into the "
        "caller's namespace. Without it, star-import takes <i>every</i> name "
        "not starting with an underscore — including the names the module "
        "<i>itself</i> imported from elsewhere.",
        S_BODY,
    ))
    story.append(Paragraph("Why this matters here", S_H2))
    story.append(Paragraph(
        "<font face='Courier'>shared_libraries/import_list.py</font> star-imports "
        "every module in a fixed order. If two modules <i>silently</i> re-"
        "exported the same name (e.g. both pulling "
        "<font face='Courier'>Sleep</font> from somewhere), the last one in "
        "the star-import list would win — and rebind a real implementation to "
        "a re-export.",
        S_BODY,
    ))
    story.append(callout(
        "The historical bug this fixed",
        "Before <font face='Courier'>__all__</font> was added everywhere, "
        "<font face='Courier'>winidea.py</font> was loaded last and accidentally "
        "rebound <font face='Courier'>RESULT</font> to a re-export. Tests then "
        "called the wrong reporter. The fix wasn't to reorder imports — it was "
        "to make every module declare its surface explicitly."
    ))
    story.append(Paragraph("The pattern in every module", S_H2))
    story.append(code(
        "# at the BOTTOM of a module, after all definitions:\n"
        "__all__ = [\n"
        "    # only names this module DEFINES — never re-exports\n"
        "    'Sleep', 'Wait', 'TriggerCrash',\n"
        "    'create_report_and_logging',\n"
        "    'POWER_OFF', 'POWER_ON', 'POWER_CYCLE',\n"
        "    # ...\n"
        "]"
    ))
    story.append(Paragraph("Reading rules of thumb", S_H3))
    story.extend(bullets([
        "<b>Public symbols</b> appear in <font face='Courier'>__all__</font>. They are documented and stable.",
        "<b>Underscore-prefixed symbols</b> (<font face='Courier'>_LazyObjectProxy</font>, <font face='Courier'>_get_jscript_symbol</font>) are private. Use them at your own risk.",
        "If a name is exposed by both a module and <font face='Courier'>import_list</font>, the <b>module is the source of truth</b>. Always cite the originating module path in new code.",
    ]))
    story.append(PageBreak())
    return story


def section_pylance():
    story = [Paragraph("9.  Pylance, pyrightconfig.json and TYPE_CHECKING", S_H1)]
    story.append(Paragraph(
        "Pylance is the language server VS Code uses to give you autocomplete, "
        "hover docs, and Go-to-Definition. Under the hood it runs Pyright (a "
        "static type checker). Pyright reads two config sources in this "
        "framework:",
        S_BODY,
    ))
    story.append(Paragraph("9.1  <font face='Courier'>pyrightconfig.json</font> (workspace root)", S_H2))
    story.append(code(
        "{\n"
        '    "include":     ["shared_libraries", "projects", "tests"],\n'
        '    "exclude":     ["**/__pycache__", "**/.venv", "test_logs", "test_results"],\n'
        '    "extraPaths":  ["..", "C:/Python 3.14.0/Lib/apym-2.6.0/src"],\n'
        '    "pythonVersion": "3.14",\n'
        '    "pythonPlatform": "Windows",\n'
        '    "reportMissingImports": "warning",\n'
        '    "reportMissingTypeStubs": "none",\n'
        '    "useLibraryCodeForTypes": true\n'
        "}"
    ))
    story.append(kv_table([
        ("<font face='Courier'>extraPaths: '..'</font>",
         "Tells Pylance to treat the <i>parent</i> of the workspace as if it were on "
         "<font face='Courier'>sys.path</font>. That is how Pylance resolves "
         "<font face='Courier'>from Framework_IOEM_Py.shared_libraries.x import y</font>: "
         "it expects Framework_IOEM_Py to sit under that parent."),
        ("<font face='Courier'>extraPaths: 'C:/Python 3.14.0/Lib/apym-2.6.0/src'</font>",
         "Tells Pylance where the Apym sdist lives so that "
         "<font face='Courier'>from apym.connection import Instance</font> resolves "
         "in the editor even before <font face='Courier'>ensure_apym_on_path()</font> runs."),
        ("<font face='Courier'>reportMissingImports: 'warning'</font>",
         "Demotes 'unresolved import' from error to warning. Useful because some "
         "modules (jscript runtime state) only exist after a bench connection."),
    ]))
    story.append(Paragraph("9.2  <font face='Courier'>.vscode/settings.json</font>", S_H2))
    story.append(Paragraph(
        "Mirrors the same two extraPaths under "
        "<font face='Courier'>python.analysis.extraPaths</font>. This is what "
        "the Pylance VS Code extension reads. The duplication keeps Pylance "
        "running standalone (pyrightconfig.json) <i>and</i> via VS Code "
        "settings (settings.json) consistent.",
        S_BODY,
    ))
    story.append(Paragraph("9.3  <font face='Courier'>TYPE_CHECKING</font> — the editor-only door", S_H2))
    story.append(code(
        "from typing import TYPE_CHECKING\n"
        "if TYPE_CHECKING:\n"
        "    from .jscript_translation import CAN, PS, RESULT     # ← only Pylance sees this"
    ))
    story.append(Paragraph(
        "<font face='Courier'>TYPE_CHECKING</font> is the constant "
        "<font face='Courier'>False</font> at runtime — but Pyright/Pylance "
        "evaluate the block as if it were True. So the editor sees the "
        "<i>real</i> types and gives you precise hover/IntelliSense, while "
        "Python at runtime never executes the import (skipping the cycle).",
        S_BODY,
    ))
    story.append(callout(
        "Practical takeaway",
        "If you see a name in the framework that has both a "
        "<font face='Courier'>TYPE_CHECKING</font> import and a runtime "
        "<font face='Courier'>_LazyObjectProxy</font> binding, that's not a "
        "mistake — it's the pattern. The editor types are real; the runtime "
        "value is a proxy."
    ))
    story.append(PageBreak())
    return story


def section_project_cfg():
    story = [Paragraph("10.  Project-aware configuration loading", S_H1)]
    story.append(Paragraph(
        "Different projects (U171, M310, UPP_EV, W610, W616, Z121) share the "
        "<i>same</i> shared library but have <i>different</i> DIDs, frame "
        "names, sensor mappings. The bridge is "
        "<font face='Courier'>project_config_loader.py</font>.",
        S_BODY,
    ))
    story.append(Paragraph("How the active project is detected", S_H2))
    story.append(Paragraph(
        "<b>Resolution order</b> (first non-empty wins):",
        S_BODY,
    ))
    story.extend(bullets([
        "1. Explicit override via <font face='Courier'>set_active_project('U171')</font>.",
        "2. Environment variable <font face='Courier'>IOEM_FRAMEWORK_PROJECT</font>.",
        "3. Walking the call stack and <font face='Courier'>sys.argv[0]</font> "
        "for the first <font face='Courier'>projects/&lt;NAME&gt;/</font> segment.",
    ]))
    story.append(Paragraph(
        "Once the project is detected, "
        "<font face='Courier'>_load_project_config_module('rsu_config')</font> "
        "imports "
        "<font face='Courier'>Framework_IOEM_Py.projects.&lt;NAME&gt;.config.rsu_config</font> "
        "and caches it.",
        S_BODY,
    ))
    story.append(Paragraph("Two main accessors", S_H2))
    story.append(code(
        "# Required symbol — raises if missing.\n"
        "rsu_map = _get_project_config_symbol('rsu_config', 'SENSOR_TO_RSU_CHANNEL')\n\n"
        "# Search several candidates, return default if none defines it.\n"
        "crash_cfg = _get_optional_project_config_symbol(\n"
        "    'CRASH_CURVE_CONFIG',\n"
        "    ('project_config', 'rsu_config', 'dcs_config'),\n"
        "    default=None,\n"
        ")"
    ))
    story.append(callout(
        "How this pairs with lazy mappings",
        "Combining the loader with <font face='Courier'>_LazyMappingProxy</font> "
        "is what lets <font face='Courier'>core_functions</font> declare "
        "<font face='Courier'>SENSOR_TO_RSU_CHANNEL</font> at module-load time "
        "without knowing the project. The proxy holds a closure that calls the "
        "loader on first access."
    ))
    story.append(PageBreak())
    return story


def section_parents5():
    story = [Paragraph("11.  The <font face='Courier'>parents[5]</font> path bootstrap, explained", S_H1)]
    story.append(Paragraph(
        "Test scripts live <i>inside</i> the framework package, but they need "
        "to import <font face='Courier'>Framework_IOEM_Py</font> as a "
        "<b>top-level package</b> (so that "
        "<font face='Courier'>from Framework_IOEM_Py.shared_libraries.x import y</font> "
        "works). That means the framework's <b>parent</b> directory has to be "
        "on <font face='Courier'>sys.path</font>.",
        S_BODY,
    ))
    story.append(Paragraph(
        "Walk up from a test script and count the parents:",
        S_BODY,
    ))
    story.append(code(
        "Path:                                                       parents[N]\n"
        "C:/Framework_IOEM_Py/projects/U171/modules/EDR/scripts/foo.py\n"
        "                                                ^^^^^^^^         [0] = scripts/\n"
        "                                       ^^^                        [1] = EDR/\n"
        "                              ^^^^^^^                              [2] = modules/\n"
        "                       ^^^^                                        [3] = U171/\n"
        "              ^^^^^^^^                                              [4] = projects/\n"
        "C:/Framework_IOEM_Py                                                [5] = Framework_IOEM_Py/\n"
        "C:                                                                  [6] = drive root"
    ))
    story.append(Paragraph(
        "So <font face='Courier'>parents[5]</font> is the framework root and "
        "<font face='Courier'>parents[5].parent</font> is its parent (here: "
        "<font face='Courier'>C:/</font>). Adding the parent to "
        "<font face='Courier'>sys.path</font> makes "
        "<font face='Courier'>Framework_IOEM_Py</font> a top-level importable "
        "package.",
        S_BODY,
    ))
    story.append(callout(
        "Watch out when the depth changes",
        "If you ever put scripts at a different depth (say, "
        "<font face='Courier'>projects/U171/scripts/foo.py</font> instead of "
        "<font face='Courier'>projects/U171/modules/EDR/scripts/foo.py</font>), "
        "the index changes. Always count from your script's directory upward."
    ))
    story.append(PageBreak())
    return story


def section_add_project():
    story = [Paragraph("12.  Adding a new project (step-by-step)", S_H1)]
    story.append(Paragraph("Suppose you're adding a project called <font face='Courier'>A300</font>:", S_BODY))
    story.append(code(
        "1.  mkdir Framework_IOEM_Py/projects/A300/\n"
        "    mkdir Framework_IOEM_Py/projects/A300/config/\n"
        "    mkdir Framework_IOEM_Py/projects/A300/modules/\n\n"
        "2.  Create Framework_IOEM_Py/projects/A300/__init__.py:\n"
        '       \"\"\"Project: A300\"\"\"\n'
        "       PROJECT_NAME = 'A300'\n\n"
        "3.  Create Framework_IOEM_Py/projects/A300/config/__init__.py (empty).\n\n"
        "4.  Copy a sibling project's config files (project_config.py,\n"
        "    rsu_config.py, edr_config.py, …) into A300/config/ and edit\n"
        "    values to match the new project. NEVER rename the symbol names\n"
        "    inside those files — shared library expects them by name.\n\n"
        "5.  For each subsystem (EDR, DCS, RSU, …) create:\n"
        "        projects/A300/modules/<SUBSYSTEM>/scripts/\n"
        "        projects/A300/modules/<SUBSYSTEM>/test_data/\n\n"
        "6.  Add a smoke test in projects/A300/modules/EDR/scripts/ that does:\n"
        "        ensure_apym_on_path(); init_aria()\n"
        "        from Framework_IOEM_Py.projects.A300.config.edr_config\n"
        "            import EDR_DIDS\n"
        "        print(EDR_DIDS)\n"
        "    and run it — if EDR_DIDS prints, the project is wired correctly."
    ))
    story.append(callout(
        "How does the framework know A300 exists?",
        "It doesn't need to be told. "
        "<font face='Courier'>infer_project_name()</font> walks the call stack "
        "looking for a <font face='Courier'>projects/&lt;NAME&gt;/</font> segment. "
        "Any script under <font face='Courier'>projects/A300/...</font> auto-selects A300 as active."
    ))
    story.append(PageBreak())
    return story


def section_add_test():
    story = [Paragraph("13.  Adding a new test script (step-by-step)", S_H1)]
    story.append(Paragraph(
        "Goal: write a script that toggles a CAN signal, triggers a crash, "
        "and verifies an EDR readback.",
        S_BODY,
    ))
    story.append(Paragraph("Step 1 — choose location", S_H3))
    story.append(Paragraph(
        "<font face='Courier'>projects/&lt;PROJECT&gt;/modules/&lt;SUBSYSTEM&gt;/scripts/SUBS_EDR_..._TestCase_X_Y.py</font>",
        S_BODY,
    ))
    story.append(Paragraph("Step 2 — copy the four-block preamble (section 3).", S_H3))
    story.append(Paragraph("Step 3 — write the test as a single <font face='Courier'>run_test()</font> function.", S_H3))
    story.append(code(
        "def run_test():\n"
        "    signal_def = MAH_CAN_SIGNAL_DEFS['ACC_PED']\n"
        "    msg, sig = signal_def['frame'], signal_def['signal']\n"
        "    edr_param = signal_def['EDR_Parameter']\n\n"
        "    test_case_file = os.path.splitext(os.path.basename(__file__))[0]\n"
        "    can_ids = resolve_can_log_ids([signal_def])\n"
        "    create_report_and_logging(test_case_file, can_ids=can_ids, ...)\n\n"
        "    PS.Power_Cycle(); Sleep(1)\n"
        "    for did in (EDR_DIDS or {}).get('front', []):\n"
        "        load_crash_curves('front')\n"
        "        CAN.ChangeSignalValue(msg, sig, '0x32')\n"
        "        Wait(500)\n"
        "        TriggerCrash()\n"
        "        Sleep(5)\n"
        "        edr = read_edr_parameters([edr_param], did=did, crash_type='front',\n"
        "                                  return_data=True)\n"
        "        for i, sample in enumerate(edr['decoded'][edr_param]):\n"
        "            RESULT.InterpretEqualResult(f'sample {i}', sample, expected[i])\n"
        "    aria_reports.write_to_file()\n\n"
        "if __name__ == '__main__':\n"
        "    run_test()"
    ))
    story.append(callout(
        "Three things you DON'T need to do",
        [
            "<b>1. Set up sys.path</b> — the preamble does it.",
            "<b>2. Decide which project's config to load</b> — the loader infers it from your file path.",
            "<b>3. Pre-initialize ARIA</b> — <font face='Courier'>init_aria()</font> handles it (and is a no-op the second time).",
        ],
    ))
    story.append(PageBreak())
    return story


def section_debug():
    story = [Paragraph("14.  Debugging guide", S_H1)]
    story.append(Paragraph("14.1  ImportError: cannot import name 'X' from 'Framework_IOEM_Py....'", S_H2))
    story.extend(bullets([
        "Check spelling against the source module — the framework has both "
        "<font face='Courier'>read_edr_parameters</font> (modern) and the legacy "
        "<font face='Courier'>read_edr_parameters_UPP</font> in older mirrors.",
        "Check the module's <font face='Courier'>__all__</font>. If a name is missing from <font face='Courier'>__all__</font>, "
        "<font face='Courier'>from M import *</font> won't bring it in — but "
        "<font face='Courier'>from M import name</font> still works.",
        "Check the layer of the importing module: are you trying to import something "
        "above your layer?",
    ]))
    story.append(Paragraph("14.2  ImportError: No module named 'Framework_IOEM_Py'", S_H2))
    story.append(Paragraph(
        "Your script's path bootstrap missed. Either:",
        S_BODY,
    ))
    story.extend(bullets([
        "Your script lives at a different depth than expected — recount "
        "<font face='Courier'>parents[N]</font>.",
        "You're running from inside a sub-shell whose <font face='Courier'>sys.path</font> "
        "didn't pick up the script's path because the script wasn't started by file path.",
        "You moved the framework root — verify "
        "<font face='Courier'>parents[5]</font> still points to <font face='Courier'>Framework_IOEM_Py</font>.",
    ]))
    story.append(Paragraph("14.3  ImportError: No module named 'apym'", S_H2))
    story.append(Paragraph(
        "<font face='Courier'>ensure_apym_on_path()</font> couldn't find apym. Either:",
        S_BODY,
    ))
    story.extend(bullets([
        "Set <font face='Courier'>$env:APYM_SRC</font> to "
        "<font face='Courier'>C:/path/to/apym-X.Y.Z/src</font>.",
        "Confirm <font face='Courier'>C:/Python 3.14.0/Lib/apym-*/src/apym/__init__.py</font> exists.",
        "If running off-bench on purpose, call "
        "<font face='Courier'>get_reporter(strict=False)</font> — you'll get no-op stubs.",
    ]))
    story.append(Paragraph("14.4  AttributeError on a lazy proxy", S_H2))
    story.append(Paragraph(
        "If you call <font face='Courier'>CAN.X(...)</font> and get "
        "<font face='Courier'>AttributeError: 'NoneType' object has no attribute 'X'</font>, "
        "it means the resolver returned None — ARIA isn't connected. Confirm "
        "<font face='Courier'>init_aria()</font> returned True (its return value is "
        "<font face='Courier'>True</font> on success).",
        S_BODY,
    ))
    story.append(Paragraph("14.5  Pylance says 'unresolved import' but the script runs fine", S_H2))
    story.append(Paragraph(
        "Almost always one of: (a) the extra path in <font face='Courier'>pyrightconfig.json</font> "
        "is missing or wrong; (b) the workspace root in VS Code is set somewhere "
        "<i>below</i> the framework parent. Reopen VS Code at the framework parent.",
        S_BODY,
    ))
    story.append(Paragraph("14.6  Mysterious 'name already defined' duplicate warning", S_H2))
    story.append(Paragraph(
        "Some module is silently re-exporting a name. Find the offender via "
        "<font face='Courier'>grep -n &quot;^from .X import &quot; shared_libraries/</font>, "
        "and confirm the offender's <font face='Courier'>__all__</font> does not "
        "include that name.",
        S_BODY,
    ))
    story.append(PageBreak())
    return story


def section_glossary():
    story = [Paragraph("15.  Glossary", S_H1)]
    rows = [
        ("ARIA", "The bench test tool. Apym is its Python SDK."),
        ("Apym", "<font face='Courier'>apym.connection.Instance</font> + "
                 "<font face='Courier'>apym.functions.Api</font> + "
                 "<font face='Courier'>apym.reports.ApymReports</font>. The "
                 "framework's Apym shim is "
                 "<font face='Courier'>shared_libraries/apym_imports.py</font>."),
        ("ECU", "Electronic Control Unit — the device under test."),
        ("EDR", "Event Data Recorder — the subsystem that records pre/post-crash "
                "signal samples in non-volatile memory."),
        ("DID", "Diagnostic Identifier — a UDS handle for reading/writing a "
                "specific ECU memory region (e.g. EDR data)."),
        ("DTC", "Diagnostic Trouble Code — fault codes reported by the ECU."),
        ("CAN", "Controller Area Network — the bus the ECU listens on. CAN/PS/RSU/SPI "
                "are the classes in <font face='Courier'>jscript_translation</font>."),
        ("Crash curve", "Pre-recorded acceleration profile loaded into the bench "
                        "before <font face='Courier'>TriggerCrash()</font> to simulate a real impact."),
        ("Layer", "Architectural slice in the shared library; see section 4."),
        ("Lazy proxy", "An object that forwards attribute access to a resolver "
                       "callable. Used to defer expensive imports / project-config "
                       "lookups until first use."),
        ("Deferred import", "An <font face='Courier'>import</font> statement placed inside a "
                            "function body so it runs on first call rather than at module load."),
        ("TYPE_CHECKING", "Constant from <font face='Courier'>typing</font>. "
                          "True in type checkers, False at runtime. Used to import "
                          "things the type checker needs but the runtime must not."),
        ("__all__", "Per-module list of public names. Controls "
                    "<font face='Courier'>from M import *</font> and acts as the "
                    "module's contract with consumers."),
        ("Pylance / Pyright", "Microsoft's Python language server / static type "
                              "checker. The framework configures both via "
                              "<font face='Courier'>pyrightconfig.json</font> and "
                              "<font face='Courier'>.vscode/settings.json</font>."),
        ("extraPaths", "Paths Pylance treats as if on "
                       "<font face='Courier'>sys.path</font>. Why "
                       "<font face='Courier'>from Framework_IOEM_Py...</font> resolves "
                       "in the editor even though that import is normally bootstrapped "
                       "at script start."),
    ]
    story.append(kv_table(rows))
    return story


# ── Build ───────────────────────────────────────────────────────────────────
def build(out_path: Path):
    doc = BaseDocTemplate(
        str(out_path), pagesize=A4,
        leftMargin=2 * cm, rightMargin=2 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm,
        title="Framework_IOEM_Py Architecture Guide",
        author="Framework_IOEM_Py",
    )
    frame = Frame(
        doc.leftMargin, doc.bottomMargin,
        doc.width, doc.height, id="content"
    )
    doc.addPageTemplates([
        PageTemplate(id="default", frames=[frame], onPage=on_page),
    ])
    story = []
    story.extend(section_cover())
    story.extend(section_toc())
    story.extend(section_mental_model())
    story.extend(section_layout())
    story.extend(section_bootstrap())
    story.extend(section_layers())
    story.extend(section_apym())
    story.extend(section_lazy())
    story.extend(section_cycle())
    story.extend(section_all())
    story.extend(section_pylance())
    story.extend(section_project_cfg())
    story.extend(section_parents5())
    story.extend(section_add_project())
    story.extend(section_add_test())
    story.extend(section_debug())
    story.extend(section_glossary())
    doc.build(story)


if __name__ == "__main__":
    out = Path(__file__).resolve().parent / "Framework_IOEM_Py_Architecture_Guide.pdf"
    build(out)
    print(f"Wrote: {out}")
