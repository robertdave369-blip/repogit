# Vector network interfaces

Primary source: **Vector "VN1600 Interface Family" manual, Version 6.0, © 2026** (downloaded from the
VN1600 product page https://www.vector.com/en/product/vn1600/ on 2026-10-26; file
`VN1600_Manual_EN.2026-10-12…pdf`; not stored in the repository). Page numbers below refer to it.
Product-page facts: vector.com pages read 2026-10-26. Anything else is marked `[unverified]`.

## 1. VN1610 — the bench interface (serial 48714)

**What it is.** A two-channel USB interface for CAN and CAN FD with built-in transceivers. **Why it
exists:** cheapest Vector way to put a PC on one or two high-speed CAN/CAN FD buses with Vector's driver,
time-stamping and multi-application support. **Engineering use here:** ARIA's bus access to the chassis
CAN (CH1) and the ECU's CAN FD bus (CH2).

| Property | Value | Source |
|---|---|---|
| Channels / transceivers | 2× CAN High-Speed **1051cap** (capacitively decoupled), built in — **no piggyback slots** | p.14, p.16 |
| Bit rates | CAN up to 1 Mbit/s (up to 2 Mbit/s depending on wiring and transceivers); CAN FD up to 5 Mbit/s (up to 8 Mbit/s depending on wiring and transceivers) | p.16 |
| Time stamps | 1 µs within one device; software sync typ. 50 µs; **software sync only** (no hardware sync connector) | p.14, p.16, §4.2 p.152 |
| Connector | **One D-SUB9 carrying both channels** (pinout in `connectors-pinouts-and-wiring.md`); USB to the PC | p.15 |
| Electrical isolation | Functional isolation between logic/USB and the channel side, max 60 VDC between isolated areas; channel grounds on the isolated side; **D-SUB shield (pin 5) tied to USB/system ground** | p.17 |
| Internal termination | Not described in the manual — terminate externally (ARIA set-up uses 2 × 120 Ω) | manual (no termination section); ARIA Documentation p.12 |
| Host OS | Windows 10 x64, Windows 11 x64 | p.16 |
| Operating temperature | −40 … +70 °C | p.16 |
| Accessories listed | CANcable0, CANcable1, CANcableA, CANcable Y, **CANcable 2Y** (part 05075, splits CH1/CH2 to two D-SUB9), CANterm 120, CANcable Set Pro, USBadapter 3.2 Gen 1 C-A SDSL | p.15, p.18 |
| Multi-application | The family supports several applications on one channel at once (e.g. CANoe and CANape) | p.13 |

**Limitations that matter for testing.** No hardware sync → timestamps of the VN1610 and another device are
aligned only to ~50 µs; no LIN, no FlexRay, no Ethernet; no exchangeable transceivers (no low-speed or
single-wire CAN); only two channels, both used on the M314 bench — a third bus (e.g. a real HS-CAN) needs
another interface; a CAN loop test between CH1 and CH2 needs both channels free (§3.3, p.146–148).

## 2. Other Vector interfaces listed by ARIA

ARIA Documentation p.12 lists as supported communication devices: Veoneer CommCard, VN1640A, VN1630A,
CANcase XL, VN7640, VN3600. The VN1610 in use is not in that list (ARIA works with it on this bench per the
`.accf`).

| Model | Verified capabilities | Source | Notes |
|---|---|---|---|
| VN1630A | Max. 4 CAN: 2× built-in CAN HS 1051cap + 2× piggyback slots (CAN HS/LS/single-wire, LIN, J1708); max. 2 LIN via piggybacks; K-Line with LINpiggy 7269mag; CH5 digital/analog IO; software and **hardware sync** (SYNCcableXL); CAN FD up to 5 (8) Mbit/s; ~2.5 W; Windows 10/11 x64 | manual p.25, p.31–33, p.41–42 | Piggyback order rule: LINpiggies before CANpiggies (p.32) |
| VN1640A | Max. 4 CAN via 4 piggyback slots; max. 4 LIN; J1708; SENT (SENSORpiggy SENT); CH5 IO; hardware sync; USB 3.2 Gen 1 via USB-C (product page) | manual p.74–76, p.81–82; vector.com VN1600 page | Same piggyback order rule (p.74) |
| VN1611 | 1× CAN HS 1051cap + 1× LIN 7269cap; no LIN 2.1 compliance tests | manual p.19 | not ARIA-listed |
| VN7640 | Listed by Vector's driver package as "VN7640 (CAN FD/LIN/FlexRay)"; ARIA says CAN, CAN FD, FlexRay, Ethernet, LIN | vector.com Download Center (Driver Package 26.40.0); ARIA p.12 | product page not read `[unverified beyond this]` |
| VN3600 | ARIA says FlexRay | ARIA p.12 | `[unverified]` — no Vector page read |
| CANcase XL | ARIA says CAN, CAN FD and LIN | ARIA p.12 | **Not on Vector's current network-interfaces page; CAN FD support not confirmed by Vector** (Q-HW-05) |

## 3. Software chain for every Vector interface

| Layer | Item | Facts | Source |
|---|---|---|---|
| Driver | **Vector Driver Setup** | Installs/removes Vector device drivers; needs administrator rights; run `\Drivers\Setup.exe` **before** connecting the device | manual §3.1 p.136–137 |
| Driver package | Vector Driver Package **26.40.0** for Windows 10 and 11 (2026-10-23), also a Linux package 26.40.0 | vector.com Download Center (read 2026-10-26) | latest at that date |
| Configuration | **Vector Hardware Manager** (`C:\Program Files (x86)\Vector Hardware Manager\vHardwareManager.exe`) — "successor of the Vector Hardware Config tool", needed to set up devices for Vector applications; also time-sync configuration | manual §3.2 p.144, §4.2 p.152 | ARIA's documentation still says "Vector Hardware Configuration" |
| Self-test | Loop test `\Drivers\Common\Loop3.exe` from the driver setup; CANcable1 between two HS channels | manual §3.3 p.146–148 | Needs two free channels |
| API | **XL Driver Library** (`vxlapi.dll`, `vxlapi64.dll`, .NET wrapper) — free of charge; extended FlexRay functions need the Advanced FlexRay Library License or a CANoe/CANalyzer FlexRay licence; current version 26.30.16 (2026-07-23) | vector.com XL Driver Library page (read 2026-10-26) | ARIA ships **20.30.14.0** |
| Applications | CANoe, CANalyzer, CANape, vFlash, Indigo (not used by this framework) | `licensing-and-software-dependencies.md` | — |

`[unverified]` Whether ARIA's bundled XL 20.30 DLL works with the newest 26.x driver: Vector's pages read do
not state a compatibility rule between XL DLL version and driver version. Check on the bench PC (Q-HW-01).
