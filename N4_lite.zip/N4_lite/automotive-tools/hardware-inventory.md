# Hardware and tool inventory

What this framework actually uses, what is available but unused, and what is only a candidate. Built
2026-10-26 from the repository, the bench configuration files and this PC. Owner:
`.github/agents/automotive-tools-hardware-engineer.agent.md`.

**The PC this was built on is a development PC, not the bench PC**: no Vector or PEAK driver package is in
the Windows driver store, no CAN interface is attached, and no Vector/PEAK/iSYSTEM program folder exists
(checked with `pnputil /enum-drivers` and `Get-PnpDevice`, 2026-10-26). The bench hardware below is
evidenced by the bench configuration files, not by a device seen on this PC.

## 1. In use (evidence in the repository or bench configs)

| Item | Exact identification | Role | Evidence | Status |
|---|---|---|---|---|
| CAN interface | **Vector VN1610**, serial **48714** — Channel 1 and Channel 2 | ARIA's bus access: CH1 = ARIA chassis CAN ("ARIA", classic CAN 500 kbit/s, card commands); CH2 = ECU CAN FD ("CANFD", 500 kbit/s arbitration / 2 Mbit/s data) | `C:\AriaConfigFiles_Generic\AriaConfigFiles\AriaMain.accf` (`<DeviceChannelName>VN1610 Channel 1 (48714)`, `… Channel 2 (48714)`), also `UPP_Default.accf`, `W610_fault_free_profile_10RSU.accf`; `aria_projects/M314/M314.project.json` | verified (config); hardware revision unknown |
| HS-CAN | `Virtual Channel 1 (100)` (Vector virtual channel), **disabled** | The M314 HS-CAN bus is not connected to real hardware in this configuration | same `.accf`; `aria_projects/M314/M314.project.json` (`"enabled": false`) | verified (config) |
| Vector XL Driver Library | `vxlapi.dll`, `vxlapi64.dll`, `vxlapi_NET.dll` **20.30.14.0** shipped inside `C:\ARIA5.20` | API through which ARIA opens the VN1610 channels `[inference: DLL present + Vector channel names in .accf]` | file version read 2026-10-26 | verified (files) |
| PEAK PCAN-Basic API | `PCANBasic32.dll`, `PCANBasic64.dll` **4.3.2.161** shipped inside `C:\ARIA5.20` | Bundled with ARIA; no PEAK interface is configured on this bench | file version read 2026-10-26 | available, unused |
| HIL simulator | ARIA 5.20 chassis (cards, loadbox) | Everything else on the bench | `.github/agents/aria-bench.agent.md` | see that agent |
| ECU flashing (configured default) | Infineon **Memtool 2021** (`C:\Program Files\Infineon\Memtool 2021\IMTMemtool.exe`), `FlashingTool = "MEMTOOL"` | ECU programming | `shared_libraries/configuration_control.py` | config only; not installed on this PC |
| Debugger / flasher (configured) | iSYSTEM **winIDEA** with **iC5000** and **iC6000** workspaces; `TARGET_CPU = "TC397"` | Debug and flash | `shared_libraries/configuration_control.py` (IC5000/IC6000 `.xjrf`), `projects/M310_M314_M110/config/project_config.py` | config only; `C:\iSYSTEM` absent on this PC; the M310 tool paths look like template values |
| Logic analyzer | Saleae Logic (model not recorded), `RunSaleaeCapture` | ENS/PWM capture | `.github/agents/agent_sc3.md` §26; `tools/analysis-requirements.txt` (`saleae` package "on demand") | model unknown |
| Python CAN stack (offline analysis) | python-can **4.6.1** (LGPL-3.0-only), cantools **42.0.3** (MIT) | Log/DBC analysis; python-can's `vector` and `pcan` backends load `vxlapi*` / `PCANBasic` | installed packages, read 2026-10-26 | installed on this PC |

## 2. Bench communication topology (M314)

```
Bench PC ── USB ── Vector VN1610 (s/n 48714), one D-SUB9 carrying CH1 + CH2
                     │  (CANcable 2Y needed to split into two D-SUB9 — see connectors doc)
                     ├─ CH1 "ARIA"  : classic CAN 500 kbit/s ── ARIA "T CAN" port ── chassis cards
                     └─ CH2 "CANFD" : CAN FD 500 k / 2 M   ── ARIA CAN A/B/C ── harness ── ECU (SRS_FD)
                                         diagnostics 0x730 → 0x738, padding 0xAA, frame sizes 8/64
 ARIA documentation: "2 x CAN cables for CAN case connection to ARIA system plus 2 CAN terminators (120 ohm)"
```

Sources: `.accf` / `aria_projects/M314/M314.project.json` (channels, bit rates, FD timings
abr 63/16/16, dbr 13/6/6, diagnostics); ARIA Documentation p.12 (cables, terminators); channel roles
`aria-bench.agent.md` §2. Whether the bench really uses a CANcable 2Y is **not documented** (physical fact).

## 3. Conflicting statements found (do not merge them)

| Statement | Source | Assessment |
|---|---|---|
| "CAN interface is a Vector CANcaseXL, two channels" | `agent_sc3.md` §29.4, from the ARIA knowledge base built on ARIA's own documentation screenshots (`AutomatedTestExecutive.docx`, `CanCaseXlSerialNumber` setting) | Describes ARIA's documentation example, not this project's bench, whose `.accf` names a VN1610 |
| "ECU target MCU NXP S32K388, flashed over SWD with SEGGER J-Link V9.24a" | `agent_sc3.md` §29.4, from a screenshot in ARIA's generic `Flashing Documentation.pdf` | ARIA documentation example; not evidence about the SC3 ECU |
| `TARGET_CPU = "TC397"` (Infineon AURIX) | `projects/M310_M314_M110/config/project_config.py` | Consistent with Memtool, but the file's tool paths look like template values — **ECU MCU unconfirmed** (Q-HW-03) |
| ARIA comm devices: CommCard, VN1640A, VN1630A, CANcase XL "CAN, CAN FD and LIN", VN7640, VN3600 | ARIA Documentation p.12 | The bench's VN1610 is not in ARIA's list; the CANcase XL CAN FD claim is not confirmed by Vector documentation in hand (Q-HW-05) |
| ARIA OS requirement "Windows 7 and Windows 10" | ARIA Documentation p.13 | The VN1600 family requires Windows 10/11 x64 (VN1600 manual v6.0 p.16) — a VN1610 bench cannot run Windows 7 with the current driver |

## 4. Not present (candidates only)

No reference to Kvaser, Intrepid (neoVI/ValueCAN), ETAS (INCA/ES-series), NI-XNET, CANoe/CANalyzer/CANape
projects, vFlash or Indigo exists in the framework code or configs (search of `.github`, `shared_libraries`,
`tools`, `tests`, `aria_projects`, project configs, 2026-10-26). They are documented only where the
tool-selection guide needs them as alternatives, and only with verified facts.

## 5. Open questions

| ID | Question | Where the answer is |
|---|---|---|
| Q-HW-01 | VN1610 hardware revision, driver and firmware version on the bench PC | Vector Hardware Manager on the bench PC |
| Q-HW-02 | Physical cabling between the VN1610 and the ARIA back panel (CANcable 2Y? custom cable? where the two 120 Ω terminators sit) | Bench inspection / bench wiring drawing |
| Q-HW-03 | ECU microcontroller and its debug/flash connector (TC397? other?) | ECU hardware documentation |
| Q-HW-04 | Which application name ARIA registers with the XL driver, and whether channels must be assigned to it in Vector Hardware Manager | ARIA's "How to install Vector driver.docx" (referenced in ARIA Documentation p.13, not available) |
| Q-HW-05 | Does CANcase XL support CAN FD (ARIA says yes)? | Vector CANcaseXL manual (not obtained) |
| Q-HW-06 | Saleae model; power supply used for sleep-current measurement (ARIA power card or external, `Config_Bench.xml`) | Bench inventory |
| Q-HW-07 | Licences installed on the bench PC (ARIA, any Vector application, iSYSTEM, Memtool) | Bench PC licence managers — never copy licence keys into the repository |
