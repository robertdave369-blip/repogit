# Drivers, APIs and the software stack

## 1. The stack, layer by layer (bench example)

| Layer | M314 bench | Check it with |
|---|---|---|
| Physical bus | CAN FD 500 k / 2 M on CH2, classic CAN 500 k on CH1 | Scope; resistance check (`connectors-pinouts-and-wiring.md`) |
| Interface hardware | Vector VN1610 s/n 48714 | Vector Hardware Manager device list |
| Firmware | VN1610 firmware (version unknown, Q-HW-01) | Vector Hardware Manager |
| Driver | Vector driver from the Vector Driver Setup / Driver Package (version unknown on the bench) | Vector Hardware Manager; Windows Device Manager |
| Vendor API | XL Driver Library 20.30.14.0 (`vxlapi64.dll` in `C:\ARIA5.20`) | File version |
| Application | ARIA 5.20 (opens "VN1610 Channel 1/2 (48714)") | ARIA log, `aria_ctl.py status` (`aria-bench.agent.md`) |
| Framework | `shared_libraries/jscript_translation.py` wrappers → apym → ARIA | `.github/agents/FRAMEWORK_CORE_AND_DEBUGGING_GUIDE.md` §6 |
| Licence | ARIA licence; XL library free | `licensing-and-software-dependencies.md` |
| Channel selection | `.accf` `<DeviceChannelName>`; project `CAN_FD_CHANNEL_NAME = "CANFD"`, `CAN_HS_CHANNEL_NAME = "HSCAN"` mapped to ARIA protocol names | `aria_agent.md` §2.2; `projects/<P>/config/project_config.py` |

The framework never talks to a CAN interface directly: scripts go through `shared_libraries` wrappers to
ARIA (`agent_sc3.md` §18). A new vendor API in a test script would bypass ARIA's restbus, E2E/SecOC
handling and logging — do not add one; ask first.

## 2. Vendor APIs compared (facts that change code)

| Topic | Vector XL Driver Library | PEAK PCAN-Basic | SocketCAN (Linux) |
|---|---|---|---|
| Library | `vxlapi.dll` / `vxlapi64.dll`, .NET `vxlapi_NET.dll` | `PCANBasic.dll` (Windows), `.so` (Linux) | Kernel network interfaces |
| Licence | Free; FlexRay extended functions licensed | Free with PEAK hardware only | Kernel (open source) |
| Channel identity | Device + channel names as configured in Vector Hardware Manager (e.g. "VN1610 Channel 2 (48714)") | PCAN channel handles (USB bus 1…) `[unverified naming]` | `can0`, `can1` … |
| Multi-application | VN1600 family: several applications on one channel (manual p.13) | `[unverified]` | Several sockets per interface |
| python-can backend | `interface="vector"` → loads `vxlapi`/`vxlapi64` | `interface="pcan"` → loads `PCANBasic` | `interface="socketcan"` |
| Time stamps | 1 µs per device; software sync typ. 50 µs (VN1610) | 1 µs resolution (PCAN-USB FD) | Kernel time stamps |

Code written for one backend is not portable unchanged: channel names, bit-timing parameters (CAN FD
tseg/sjw vs. bit-rate strings), error reporting and licences differ.

## 3. Install and verify (Vector, from the VN1600 manual)

1. Run the Vector Driver Setup (`\Drivers\Setup.exe`) **as administrator before** plugging in the device
   (§3.1 p.136–137).
2. Open **Vector Hardware Manager** (successor of Vector Hardware Config) — the device and its channels must
   appear; set up channels and time sync there (§3.2 p.144).
3. Run the loop test `\Drivers\Common\Loop3.exe` with a cable between two free HS channels (§3.3 p.146–148).
4. Start the application (ARIA) and check that its configured device-channel names match the Hardware
   Manager exactly — the `.accf` stores the serial number in the name.

PEAK (from the PCAN-USB FD manual and drivers page): install Device Driver Setup 5.x, check the device in
PEAK-Settings / PCAN-View, then use PCAN-Basic.

## 4. Things not to assume

- A device appearing in the driver tool proves only USB and driver, not bus wiring, bit rate or termination.
- ARIA's bundled XL DLL (20.30) and the bench's driver version are separate; a mismatch is a candidate cause
  when ARIA cannot open channels (Q-HW-01).
- Replacing the VN1610 with another device changes the channel names in the `.accf`; ARIA will not find the
  old "VN1610 Channel n (48714)" names.
