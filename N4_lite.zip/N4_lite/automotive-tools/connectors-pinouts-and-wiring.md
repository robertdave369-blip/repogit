# Connectors, pinouts, wiring and electrical safety

Only pinouts read from the manufacturer's manual (page image checked, not just extracted text) are marked
**verified**. A connector type never implies a pinout: the same D-SUB9 carries different signals on
different products.

## 1. Vector VN1610 — D-SUB9 "CH1/2" (both channels on one connector)

Source: Vector VN1600 manual **v6.0, §2.2.2 p.15** (page image checked 2026-10-26). Hardware revision: the
manual does not distinguish revisions for this table.

| Pin | Signal | Direction | Function | Required connection (bench) | Restrictions | Status |
|---|---|---|---|---|---|---|
| 1 | CH2 CAN Low | bidirectional | CAN FD channel 2 low line | ECU CAN FD CAN_L (via CANcable 2Y "Channel 2 (B)" pin 2) | — | verified |
| 2 | CH1 CAN Low | bidirectional | Channel 1 low line | ARIA chassis CAN_L (2Y "Channel 1 (A)" pin 2) | — | verified |
| 3 | CH1 GND | — | Channel 1 reference ground (isolated side) | CAN ground of the CH1 bus | Isolated from USB ground, max 60 VDC (p.17) | verified |
| 4 | CH2 CAN Low (greyed in the table) | bidirectional | Second appearance of channel 2 low | Normally not used | **Appears on pin 4 of the 2Y "Channel 1 (A)" connector** as "(CAN Low of CH2)" — a channel-1 cable that uses pin 4 couples channel 2 into it | verified |
| 5 | CH1/2 Shield | — | Cable shield | Shield | Tied to USB/system ground (not isolated) — p.17 | verified |
| 6 | CH2 GND | — | Channel 2 reference ground (isolated side) | CAN ground of the CH2 bus | A standard cable that bridges pins 3 and 6 ties CH1 and CH2 grounds together | verified |
| 7 | CH1 CAN High | bidirectional | Channel 1 high line | ARIA chassis CAN_H (2Y A pin 7) | — | verified |
| 8 | CH2 CAN High | bidirectional | Channel 2 high line | ECU CAN FD CAN_H (2Y B pin 7) | — | verified |
| 9 | not connected | — | — | — | — | verified |

Electrical limits per pin (voltage tolerance of CAN lines, max. common mode) are not stated in this manual
section — `[unverified]`; the transceiver type is "1051cap".

### CANcable 2Y (Vector part 05075) — splitting CH1/CH2

Source: same page, note and drawing.

| VN1610 pin | 2Y "Channel 1 (A)" pin | Signal | 2Y "Channel 2 (B)" pin | Signal |
|---|---|---|---|---|
| 2 | 2 | CAN Low (CH1) | | |
| 3 | 3 | GND (CH1) | | |
| 7 | 7 | CAN High (CH1) | | |
| 4 | 4 | (CAN Low of CH2) | | |
| 5 | 5 | Shield | 5 | Shield |
| 9 | 9 | — | | |
| 1 | | | 2 | CAN Low (CH2) |
| 6 | | | 3 | GND (CH2) |
| 8 | | | 7 | CAN High (CH2) |

Both 2Y ends therefore present the common single-channel layout (2 = CAN_L, 7 = CAN_H, 3 = GND,
5 = shield), plus CH2 CAN Low on pin 4 of end A.

## 2. PEAK PCAN-USB FD — D-Sub 9 (male), CiA 106

Source: PEAK "PCAN-USB FD User Manual" **2.3.0, © 2026, §4.1 p.14** (page image checked); technical data p.32.

| Pin | Signal | Notes | Status |
|---|---|---|---|
| 1 | CAN_V+ (optional) | 5 V, max. 50 mA, **not connected at delivery**; enabled by a solder bridge | verified |
| 2 | CAN_Low | | verified |
| 3 | CAN_GND | | verified |
| 4, 5, 8, 9 | Not connected | | verified |
| 6 | CAN_GND | | verified |
| 7 | CAN_High | | verified |

Internal 120 Ω termination exists but only via solder bridges, not active at delivery (p.10, p.32).
Galvanic isolation up to 500 V (p.6). Manual inconsistency: §2.1 p.8 mentions solder bridges "at pin 1
and/or pin 9", while the table (p.14) and specifications (p.32) give pin 1 only — use pin 1.

**Do not reuse a PCAN/CiA 106 cable on the VN1610 without checking:** pin 6 is a second GND on CiA 106 but
CH2 GND on the VN1610; pin 1 is a supply on PCAN but CH2 CAN Low on the VN1610.

## 3. Unverified / unknown connections

| Connection | What is known | Status |
|---|---|---|
| ARIA back panel "T CAN", "CAN A/B/C", "BUS H/L" pinouts | Port names only (`aria-bench.agent.md` §2) | unknown — do not wire from assumption |
| ECU connector pins for CAN FD / HS-CAN | `aria_projects/M314/M314.project.json` notes "ecu_pins/zif_pins are TBD" | unknown |
| ECU debug/flash connector (DAP/JTAG/SWD) | MCU unconfirmed (Q-HW-03) | unknown |
| PCAN-USB Pro FD D-Sub (CAN + LIN on one connector) | Only a summarised, incomplete table from the product page | unverified — read the PCAN-USB Pro FD manual before wiring |

## 4. CAN / CAN FD wiring rules

- **Two wires plus reference:** CAN_H, CAN_L and the CAN ground of the channel. A missing ground between
  isolated interface and ECU can still communicate on a short bench but is a common source of
  intermittent errors `[unverified general practice]`.
- **Termination:** 120 Ω at each end of the bus, 60 Ω measured between CAN_H and CAN_L with power off
  (`agent_sc3.md` §27.2). The ARIA set-up uses two 120 Ω terminators (ARIA Documentation p.12). Neither the
  VN1610 manual nor the default PCAN-USB FD enables internal termination.
- **Topology:** a line bus with short stubs; CAN FD data-phase bit rates (2 Mbit/s here) are more sensitive
  to stub length and reflections than classic CAN `[unverified general practice]`.
- **CAN FD timing:** every node, the interface included, must use the same nominal and data bit rates and
  compatible sample points; the bench's values are in the `.accf` (abr 63/16/16, dbr 13/6/6 at
  500 k / 2 M).
- **Isolation:** the VN1610 isolates the channel side from USB only functionally (60 VDC); its shield pin
  is on USB ground — connecting the shield to the vehicle chassis links PC ground and chassis.

## 5. Safe connection procedure

1. Identify the exact interface model (and, where it matters, revision) and the manual section for its
   connector. No manual → stop; mark the connection unverified.
2. Identify the ECU/bench connector pin for each signal from the project wiring documentation.
3. Decide which channel goes to which bus; check bit rates and FD settings in the tool configuration first.
4. With everything **unpowered**: check CAN_H–CAN_L resistance (≈ 60 Ω with two terminators) and that no
   supply voltage appears on any communication pin.
5. Connect grounds/reference before signal lines; keep isolated interfaces' grounds to the bus they serve.
6. Power the ECU/bench, then start the interface software; check error counters before trusting traffic.
7. Disconnect in reverse order: stop the application, then unplug, then power down.

Before connecting to a live vehicle or a powered ECU, verify the interface's voltage limits and the
connector pinout in its manual; this document does not replace that check.
