# Tool selection guide

Start from the objective, then the minimum capability, then what the bench already has. **On this project,
the default answer is the existing ARIA bench (VN1610 + ARIA 5.20)**; add equipment only when the
objective needs a capability it lacks. Every capability below is from `vector-hardware.md` /
`peak-system-hardware.md`; prices are deliberately not given (no current, credible pricing was collected).

| Objective | Minimum capability | Existing bench covers it? | If not / alternative | Licences | Limits |
|---|---|---|---|---|---|
| Capture CAN FD traffic from the ECU | 1 CAN FD channel at 500 k / 2 M | Yes — CH2, ARIA log (`CAN.StartLoggingToFile`) | A second interface in listen-only on the same bus (any CAN FD device; VN1610 supports multi-application on one channel) | ARIA (+ application licence if a Vector tool is used) | Trace ≠ physical-layer evidence |
| Monitor several buses at once | One channel per bus | Partly — CH1 is the chassis CAN, CH2 the ECU CAN FD; HS-CAN is virtual/disabled | A further CAN interface for HS-CAN (e.g. VN1630A/VN1640A with 4 channels; PCAN-USB Pro FD 2× CAN FD) | per tool | Timestamps across devices: VN1610 software sync ≈ 50 µs |
| Simulate other ECUs (restbus) for black-box tests | Restbus engine + E2E/SecOC handling | Yes — ARIA restbus with the OEM product library | — | ARIA | ARIA card limit 24 frames + 1 CEVG per CAN card (`aria-bench.agent.md` §4.2) |
| UDS diagnostics | ISO-TP on the diagnostic bus | Yes — ARIA diagnostic channel 0x730/0x738 on CANFD | — | ARIA | Diagnostics on HS-CAN not available while HS-CAN is virtual |
| ECU flashing / bootloader | Flash tool + probe, or UDS flashing | Configured: Memtool (default), winIDEA, "CANFLASHING" | — | Tool licences `[unverified]` | KFS-04 (`Software_Flashing`); irreversible — explicit user request only |
| CAN NM state-transition tests | Restbus control of `VCU_CANNM`/`FR_ZONE2_100` + time-stamped log | Yes — ARIA + log | — | ARIA | Presence checks from the log, not `ReceiveFrame` (KFS-05) |
| Wake-up / sleep validation | Restbus on/off, ignition control, log | Yes | — | ARIA | A silent trace is not proof of sleep |
| Sleep-current measurement | Supply current at mA/µA level with time stamps | Partly — `PS.GetCurrentVBAT()`; resolution unknown | Programmable supply or ammeter with µA range and logging | — | Q-HW-06 |
| LIN tests | LIN channel | Not on this bench (VN1610 has no LIN) | VN1630A/VN1640A with LINpiggy; ARIA's LinConfig with a LIN-capable comm device | per tool | — |
| Automotive Ethernet / DoIP | Ethernet interface | Not on this bench; the ECU is diagnosed over CAN | Vector VN5000 family / VN7640 `[unverified]` | per tool | Not needed for this ECU |
| Synchronized multi-device HIL | Hardware sync between interfaces | No (VN1610 has software sync only) | VN1630A / VN1640A with SYNCcableXL (hardware sync typ. 1 µs) | — | — |
| Scripted access from Python outside ARIA | Vendor API + driver | python-can installed; would need the interface free of ARIA | Only with the user's agreement — the framework rule is "through ARIA wrappers" | python-can LGPL; vendor API terms | PEAK APIs only with PEAK hardware |
| Physical-layer debugging | Differential measurement | Not in the framework | Oscilloscope + differential probe | — | — |

If the device model or revision is unknown, say which recommendation depends on it (pinout, transceiver,
channel count, sync) and ask for that one detail before recommending a cable or pin connection.
