# PEAK-System interfaces and software

No PEAK interface is configured on this project's bench. PEAK matters because **ARIA 5.20 ships
PCAN-Basic 4.3.2.161** (`C:\ARIA5.20\PCANBasic32.dll`, `PCANBasic64.dll`) and python-can's `pcan` backend
loads PCAN-Basic. Sources: PEAK manuals downloaded 2026-10-26 (not stored), the verbatim
`High-Layer-PCAN-Basic-API-ReadMe.txt` (© 2024) and PEAK web pages read 2026-10-26. Items read only through
a summariser are marked `[page summary]` — confirm on the page before relying on them.

## 1. Interface classes (what to look for)

| Class | What it adds | PEAK example |
|---|---|---|
| Basic CAN adapter | One classic CAN channel | PCAN-USB |
| CAN FD interface | Flexible data rate, 64-byte payloads | PCAN-USB FD |
| Multi-channel | Several buses at once, often mixed CAN FD + LIN | PCAN-USB Pro FD, PCAN-USB X6 |
| Galvanic isolation | PC protected from bus ground offsets; isolation voltage is a datasheet value | PCAN-USB FD (500 V) |
| Gateway / router | Stand-alone forwarding between buses or to Ethernet, no PC needed | PCAN-Router / PCAN-Gateway families `[not researched]` |

Capabilities come from the hardware; drivers, PCAN-View and PCAN-Basic come in the free driver package;
PCAN-Explorer is a separate product (see licensing).

## 2. PCAN-USB FD (verified from its manual)

Source: "PCAN-USB FD User Manual" **2.3.0, © 2026**.

| Property | Value | Page |
|---|---|---|
| Buses | 1× CAN / CAN FD, high-speed ISO 11898-2; CAN FD ISO and non-ISO switchable | p.6, p.32 |
| Bit rates | CAN 25 kbit/s – 1 Mbit/s; CAN FD data 25 kbit/s – 12 Mbit/s | p.6, p.32 |
| Controller / transceiver | FPGA CAN FD controller; NXP TJA1044GT | p.6, p.32 |
| Isolation | Galvanic, up to 500 V | p.6, p.32 |
| Connector | D-Sub 9 male, CiA 106 (pinout in `connectors-pinouts-and-wiring.md`) | p.14 |
| Termination | 120 Ω via solder bridges, off at delivery; PEAK recommends terminating in the cabling | p.10, p.32 |
| Supply to bus connector | 5 V max. 50 mA on pin 1 via solder bridge, off at delivery | p.8, p.32 |
| Time stamp resolution | 1 µs | p.6, p.32 |
| Host | USB 2.0 high-speed (USB-A or USB-C version); Windows 11 (x64/ARM64), 10 (x64), Linux | p.6–7 |
| Scope of supply | Device drivers, PCAN-View, PCAN-Basic, programming interfaces for automotive protocols, manual | p.7 |

## 3. PCAN-USB Pro FD `[page summary]`

Two CAN FD channels and two LIN channels (LIN via adapter cables); each CAN FD channel separately isolated
up to 500 V; two D-Sub connectors. The pin table seen through the summary is incomplete — **read the
PCAN-USB Pro FD manual before wiring** (its download timed out on 2026-10-26).

## 4. Software stack

| Item | Facts | Source |
|---|---|---|
| Device Driver Setup **5.x** (Windows 11 x64/ARM64, 10 x64) | "Installation package with device drivers, tools, and APIs … Included tools: PEAK-Settings, PCAN-View, PLIN-View Pro, and Virtual PCAN-Gateway. Included APIs: PCAN-Basic, PLIN-API, and PCAN-RP1210." Driver version 4 last release: 4.6.4 | drivers page (verbatim), last modified 2025-05-21 |
| Linux | "SocketCAN-capable drivers are part of the Linux mainline kernel"; separate PCAN-Linux page not read | drivers page (verbatim) |
| PCAN-Basic | Current line **5.x**; 4.x listed under outdated APIs ("use is not recommended and support is limited"); supports CAN CC, CAN FD and CAN XL | development page / PCAN-Basic page `[page summary]` |
| PCAN-View | Part of the device driver setup; version 6.1.0 listed (2026-09-11) | PCAN-View page `[page summary]` |
| PCAN-ISO-TP, PCAN-UDS, PCAN-CCP, PCAN-XCP, PCAN-OBD-2, PCAN-PassThru | High-layer APIs on top of PCAN-Basic | readme (verbatim) |

**ARIA consequence.** ARIA's bundled PCAN-Basic is 4.3 — an "outdated" line per PEAK. If a PEAK interface
is ever used with ARIA, check that combination with ARIA's vendor before relying on it.
