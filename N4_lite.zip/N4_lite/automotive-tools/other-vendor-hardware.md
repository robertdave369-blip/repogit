# Other tools: debug, flash, measurement, other CAN vendors

## 1. Referenced by this framework

| Tool | What the repository says | Evidence | Verification |
|---|---|---|---|
| Infineon Memtool 2021 | Default ECU flashing tool (`FlashingTool = "MEMTOOL"`; valid choices "ISYSTEM", "MEMTOOL", "CANFLASHING"); executable path `C:\Program Files\Infineon\Memtool 2021\IMTMemtool.exe` | `shared_libraries/configuration_control.py` | Not installed on this PC; Memtool targets Infineon microcontrollers `[unverified: product scope not read]` |
| iSYSTEM winIDEA + iC5000 / iC6000 | Workspaces `winIDEA_Workspace_IC5000.xjrf`, `winIDEA_Workspace_IC6000.xjrf`; `TARGET_CPU = "TC397"` in the M310 project config | `shared_libraries/configuration_control.py`, `shared_libraries/winidea.py`, `projects/M310_M314_M110/config/project_config.py` | Not installed on this PC; debug connector and licence not documented |
| CAN flashing ("CANFLASHING") | A selectable flashing mode | `shared_libraries/configuration_control.py` | Mechanism not documented here; UDS flashing knowledge in `.github/uds/` |
| `Software_Flashing` | Known defect: power-cycles the ECU 3 s after starting Memtool asynchronously | `docs/engineering/known-failure-signatures.md` KFS-04 | Do not use until fixed |
| SEGGER J-Link V9.24a (SWD) with NXP S32K388 | Appears in ARIA's generic flashing documentation example | `agent_sc3.md` §29.4 (source: ARIA `Flashing Documentation.pdf` screenshot) | Documentation example, **not** this ECU |
| Saleae Logic | ENS/PWM capture with `RunSaleaeCapture`, started ≥ 5 s before the event window | `agent_sc3.md` §26; `tools/analysis-requirements.txt` | Model and channel wiring not recorded |
| Bench power | ARIA power card (BATT/IGN); optional external supply via `Config_Bench.xml` | `aria-bench.agent.md` §2, §4.2 | Current measurement via `PS.GetCurrentVBAT()` / `PS.GetCurrentIGN()` (`shared_libraries/jscript_translation.py`); resolution unknown |

## 2. Not used by this framework

Kvaser, Intrepid Control Systems (neoVI, ValueCAN), ETAS (INCA, ES-series), National Instruments (NI-XNET),
Lauterbach TRACE32: **no reference anywhere in the framework code or configs** (search 2026-10-26). They
are not researched here; before recommending one, read its current manual and licence terms and add a
verified section. Do not assume a vendor API is a drop-in replacement: python-can selects a different
backend per vendor (`vector` → `vxlapi*`, `pcan` → `PCANBasic`, verified in the installed python-can 4.6.1
sources), and each backend has its own channel naming, bit-timing parameters and licence conditions.

## 3. Oscilloscopes and probes

For physical-layer questions (dominant/recessive levels, reflections, wake-up patterns) a differential
probe across CAN_H–CAN_L (or two channels and math) is needed; a CAN trace cannot show these.
Instrument settings for this bench's PWM checks are in `agent_sc3.md` §26. No oscilloscope model is
recorded in the repository.
