# Troubleshooting interfaces, drivers, licences and wiring

ARIA error messages and their fixes: `aria-bench.agent.md` §21 (do not duplicate here). Recurring framework
failure causes: `docs/engineering/known-failure-signatures.md`. This file covers the layer below ARIA.

**Isolate in this order:** licence/application → API/driver → device → channel/bit timing → wiring and
termination → ECU. A device seen by the driver proves only USB + driver.

| # | Symptom | Likely causes | Evidence / checks | Expected result | Fix and regression check |
|---|---|---|---|---|---|
| HT-01 | Device not detected | USB cable/port; driver not installed or installed after plugging in; Windows version unsupported (VN1600: Windows 10/11 x64 only) | Device Manager; Vector Hardware Manager device list; driver installed **before** plugging in (manual §3.1) | Device listed with serial | Reinstall driver as admin, re-plug; loop test |
| HT-02 | Driver installation fails | No admin rights; old driver package; OS not supported | Installer log; OS version | — | Admin install of the current package |
| HT-03 | Application cannot open the channel / licence error | Application licence missing; channel not assigned to the application; channel name changed (serial in the `.accf`) | ARIA log; Hardware Manager channel assignment; `<DeviceChannelName>` vs actual | Names match exactly | Correct the assignment or `.accf`; restart ARIA |
| HT-04 | Works for one application, not for another | Exclusive use, or TX by two applications on one channel | Which applications hold the channel | VN1600 supports multi-application, but two senders interfere | One sender per channel |
| HT-05 | No frames received | Wrong channel (CH1 vs CH2 swapped); bus not connected; ECU not powered/awake; bit rate wrong | ARIA log on both channels; ECU power; `.accf` bit rates | Frames on CH2 with ECU powered | Correct mapping; record the channel map |
| HT-06 | TX not acknowledged / error frames | Wrong bit rate or CAN FD data rate/sample point; only one node on the bus; termination missing | Error counters; scope on CAN_H/CAN_L; 60 Ω check unpowered | 60 Ω; matching timings (abr 63/16/16, dbr 13/6/6) | Fix timing or termination; loop test |
| HT-07 | Bus-off | Persistent errors: timing mismatch, short, CAN_H/CAN_L swapped | Error frames before the silence; `AutoRecoverFromBusOff` setting (CH2 true, CH1 false in the `.accf`) | — | Correct the physical fault; ECU bus-off recovery is a separate test (NM-DEV-19) |
| HT-08 | CAN_H / CAN_L swapped | Wrong cable/pin | Recessive levels both ~2.5 V, dominant inverted on scope | — | Rewire per the verified pinout |
| HT-09 | Channel 2 traffic appears on the channel-1 harness | Cable uses pin 4 of the CANcable 2Y "A" end (CH2 CAN Low) | Continuity check | — | Leave pin 4 unconnected on the CH1 harness |
| HT-10 | Ground loop / intermittent errors when bench and PC share chassis | VN1610 shield (pin 5) is on USB ground; CH grounds isolated only to 60 VDC | Voltage between PC ground and bench ground | — | Do not tie shield to chassis without need; keep each channel's GND to its own bus |
| HT-11 | Missing reference ground | Isolated interface with CAN_H/CAN_L only | Errors depend on bench state | — | Connect the channel GND (VN1610 pin 3/6; CiA pins 3/6) |
| HT-12 | Diagnostics fail while CAN traffic is visible | Wrong diagnostic channel (diagnostics are on CANFD, not HS-CAN on M314); FD frame size/padding; security | ARIA diagnostic channel config (0x730/0x738, padding 0xAA, sizes 8/64) | — | `.github/uds/` and `uds-protocol-engineer.agent.md` |
| HT-13 | Wrong or drifting time stamps between devices | Software sync only (VN1610 ≈ 50 µs); sync disabled | Hardware Manager time-sync settings | — | Hardware sync needs devices with a sync connector |
| HT-14 | Firmware/driver mismatch, ARIA cannot open Vector channels after a driver update | ARIA ships XL 20.30; driver newer/older | Driver version vs XL DLL version | — | Unverified rule — test on the bench, record result in `compatibility-matrix.md` |
| HT-15 | PEAK API used with a non-PEAK interface | Licence violation, not a technical fix | — | — | Use the vendor's own API |
