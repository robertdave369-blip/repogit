# Licensing and software dependencies

**Never store licence keys, licence files, dongle data, activation codes or passwords in this repository.**
Record only *which* entitlement is needed and where it is managed.

Sources: vendor pages read 2026-10-26 (quotes below), PEAK `High-Layer-PCAN-Basic-API-ReadMe.txt` (© 2024,
verbatim), installed package metadata. "NOT FOUND" = searched on the vendor's pages and not stated there.

## 1. What a purchase gives you — four separate things

| Layer | Example | Typical condition |
|---|---|---|
| Hardware capability | VN1610 can do CAN FD at 5 Mbit/s | Fixed by the device |
| Driver and vendor API | Vector Driver Setup + XL Driver Library; PEAK Device Driver Setup + PCAN-Basic | Free download, but tied to the vendor's hardware (PEAK: explicitly) |
| Application licence | CANoe, CANalyzer, vFlash, PCAN-Explorer, ARIA | Paid; edition/variant/option decides features |
| Activation / entitlement | Vector Keyman USB dongle; ARIA licence file | Per vendor; may be bound to a PC or a dongle |

## 2. Vector

| Product | Licensing facts (quoted) | Source |
|---|---|---|
| XL Driver Library | "You can get the latest version of the library free-of-charge in our downloads." Extended FlexRay: "Use of the extended functions requires the Advanced FlexRay Library License or a CANoe/CANalyzer FlexRay license" (free library limited to 128 different transmit frames) | XL Driver Library page |
| CANoe | Editions since 2023: "CANoe DE" (Desktop), "CANoe TBE" (Test Bench), "CANoe SE" (Server); variants "Project Execution", "Runtime", "Professional"; options "flexibly extend CANoe with specific functional scopes" — "The CAN option is already included in CANoe"; named options include LIN, Ethernet, FlexRay, J1939, AMD/XCP, Scope, Sensor, Car2x, CANopen, DiVa (diagnostic validation). CAN FD is **not named** as an option (NOT FOUND either way) | CANoe page, CANoe product-concept page |
| CANalyzer | "CANalyzer DE" / "CANalyzer TBE"; variants "Expert (/exp)" (no CAPL) and "Professional (/pro)"; options for CAN, Car2X, Ethernet, FlexRay, LIN, CANopen, ISO 11783, J1587, J1939, Scope, avionics | CANalyzer page |
| CANape | ECU calibration, measurement, flash programming and diagnostics; options (Driver Assistance, vCDM, Bypassing, …); variant/licence wording NOT FOUND | CANape page |
| vFlash | "flashing ECUs via diagnostics (UDS)"; variants "vFlash Standard" and "vFlash Station", each as DE and TBE | vFlash page |
| Indigo | Diagnostic tester; subscription model; reprogramming: "An installation and license of vFlash is required for this." | Indigo page |
| Keyman | "The Vector Keyman is a USB dongle used for license activation and operates as a HID device"; Type A and Type C; "Vector Driver needed" | USB accessories page |
| Licence activation tool, network/floating licences | **NOT FOUND** on the pages read | — |

**Workflow rule.** Name the edition, variant and option a workflow needs only when the vendor's documentation
for that version states it; otherwise write "licence feature `[unverified]` — check Vector's product
documentation for version X".

## 3. PEAK-System

| Item | Licensing facts | Source |
|---|---|---|
| PCAN-Basic, PCAN-Light, high-layer APIs (CCP, XCP, ISO-TP, UDS, OBD-2, PassThru) | "licensed free of charge for owners of PEAK-System Technik GmbH CAN PC interfaces. Every PEAK CAN PC hardware is exactly one license." "It is NOT allowed to use any of our APIs with a non-PEAK-System Technik CAN interface." No "Wrapper" DLL to use PEAK software with non-PEAK hardware | readme (verbatim) |
| EULA | "The usage of the free PEAK Software in combination with 3rd party hardware is prohibited." (§2.6); EULA dated 10/2019 | https://www.peak-system.com/quick/eula `[page summary]` |
| Device Driver Setup, PCAN-View | Free download; PCAN-View is part of the driver setup | drivers page (verbatim); PCAN-View page `[page summary]` |
| PCAN-Explorer 7 | Licensing model and price **NOT FOUND**; a "PEAK License Manager" exists | PCAN-Explorer page `[page summary]` |

**Consequence for this repository:** ARIA's bundled `PCANBasic*.dll` may only be used with PEAK hardware.
Do not point it — or python-can's `pcan` backend — at another vendor's interface.

## 4. ARIA, Python and other tools

| Item | Licensing | Source |
|---|---|---|
| ARIA 5.x | Licence file per user/PC ("Single" bound to a hardware UID; "Volume" not); errors and fixes | `.github/agents/aria-bench.agent.md` §21–§22 |
| python-can 4.6.1 | LGPL-3.0-only | installed package metadata |
| cantools 42.0.3 | MIT | installed package metadata |
| iSYSTEM winIDEA, Infineon Memtool, Saleae Logic | Not documented in the repository | Q-HW-07 |

## 5. Licences needed per workflow on this bench

| Workflow | Needed | Not needed |
|---|---|---|
| ARIA restbus, UDS, fault injection on the M314 bench | ARIA licence; Vector driver for the VN1610; XL Driver Library (free, shipped with ARIA) | Any Vector application licence `[inference: ARIA opens the channels through the XL API itself]` |
| Offline log/DBC analysis | python-can, cantools (open source) | Hardware |
| Live capture with a Vector application next to ARIA | That application's licence (edition/variant per vendor documentation) | — |
| Flashing via Memtool or winIDEA | Their licences and probe hardware `[unverified]` | — |
