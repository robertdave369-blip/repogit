# Hardware / software / licence compatibility matrix

Rows in use first. "Verified" = read in the named manual/page or file on the date given; "config" = taken
from the bench configuration; "unverified" = not confirmed for this exact combination.

| # | Manufacturer / device (rev.) | Networks, channels | Cable / adapter | Driver | Firmware | OS | API / SDK | Application | Licences | Restrictions | Source | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Vector **VN1610** s/n 48714 (rev. unknown) | 2× CAN / CAN FD (HS 1051cap) | CANcable 2Y (part 05075) to split CH1/CH2 `[physical use unverified, Q-HW-02]`; 2 × 120 Ω terminators | Vector Driver Setup / Package (bench version unknown) | unknown | Windows 10/11 x64 | XL Driver Library 20.30.14.0 (shipped in ARIA) | ARIA 5.20 | ARIA licence; XL free | Software sync only; no LIN/FlexRay/Ethernet; both channels used | VN1600 manual v6.0 p.14–18; `AriaMain.accf`; `C:\ARIA5.20` file versions | config + verified specs |
| 2 | Vector virtual channel "Virtual Channel 1 (100)" | Virtual CAN (HS-CAN slot) | none | Vector driver | — | — | XL Driver Library | ARIA 5.20 | — | Disabled; no physical HS-CAN on this configuration | `AriaMain.accf`; `aria_projects/M314/M314.project.json` | config |
| 3 | PEAK PCAN-Basic 4.3.2.161 (in `C:\ARIA5.20`) | — (API only) | — | PEAK driver (not installed) | — | Windows | PCAN-Basic 4.x (PEAK: outdated line) | ARIA 5.20 | Free, PEAK hardware only | No PEAK device on the bench | file versions; readme; PEAK development page `[page summary]` | available, unused |
| 4 | python-can 4.6.1 | backends incl. `vector`, `pcan`, `socketcan` | — | needs the vendor driver for live use | — | Windows (this PC) | `vxlapi*` / `PCANBasic` | offline log analysis, skills | LGPL-3.0-only | Not used for bench I/O (ARIA owns the interface) | installed sources/metadata | verified (installed) |
| 5 | Infineon Memtool 2021 | ECU flash | probe unknown | unknown | — | Windows | — | `shared_libraries/configuration_control.py` | unknown | Default `FlashingTool`; KFS-04 timing defect | config | unverified |
| 6 | iSYSTEM winIDEA + iC5000 / iC6000 | debug / flash, target "TC397" | debug cable unknown | unknown | — | Windows | winIDEA SDK `[unverified]` | `shared_libraries/winidea.py` | unknown | Paths look like templates; ECU MCU unconfirmed | config | unverified |
| 7 | Vector VN1630A | ≤ 4 CAN (2 built-in + 2 piggy), ≤ 2 LIN, IO, HW sync | piggybacks; SYNCcableXL | Vector driver | — | Windows 10/11 x64 | XL Driver Library | listed by ARIA | as row 1 | Piggy order: LIN before CAN | VN1600 manual p.25–42; ARIA Documentation p.12 | verified specs; not on this bench |
| 8 | Vector VN1640A | ≤ 4 CAN / ≤ 4 LIN / J1708 / SENT via piggies, IO, HW sync | piggybacks | Vector driver | — | Windows 10/11 x64 | XL Driver Library | listed by ARIA | as row 1 | as row 7 | VN1600 manual p.68–85 | verified specs; not on this bench |
| 9 | Vector VN7640, VN3600, CANcase XL | per ARIA: VN7640 CAN/CAN FD/FlexRay/Ethernet/LIN; VN3600 FlexRay; CANcase XL "CAN, CAN FD and LIN" | — | — | — | — | — | listed by ARIA | — | CANcase XL CAN FD not confirmed by Vector; not on Vector's current interface page | ARIA Documentation p.12; Vector Download Center | unverified |
| 10 | PEAK PCAN-USB FD | 1× CAN / CAN FD (12 Mbit/s data), 500 V isolation | D-Sub 9 CiA 106; external terminators | Device Driver Setup 5.x | — | Windows 11/10 x64, Linux (SocketCAN in mainline) | PCAN-Basic 5.x | not used | free with the device | Not configured for ARIA | PCAN-USB FD manual 2.3.0; drivers page | verified specs; candidate |

Never treat two rows as interchangeable because both "support CAN": channel count, isolation, transceiver
type, connector pinout, API and licence all differ.
