# From the wire to ComM: the layers NM depends on

Everything about modules other than CanNm is general AUTOSAR/CAN knowledge, labelled `[unverified]`: their
SWS documents were not read and the ECU's stack is not in the repository. CanNm statements cite the
verified R22-11 IDs. The ECU's own module set is unknown (Q-09). The OEM requirements name application
components, not AUTOSAR modules: `CanMgr`, `CAN NM`, `DiagMgr`, `FltMonrCallback`, `EnsMgr`, `Padi`,
`OpsCrashMgr` (column `_Impacted_Element` of the NM workbook), and `agent_sc3.md` describes "CanNm ──►
enables/disables CanMgr TX/RX + network diagnostics".

## 1. Layer map

```
 Application / SWCs (crash, diagnostics, CanMgr signal handling)
        │  communication needs (ignition, CAN wake-up qualification)
 BswM ── EcuM ── ComM ───────────── Nm (Generic NM Interface)
                  │                    │
                CanSM                CanNm  ◄── NM PDU Rx/Tx (SRS_CANNM / VCU_CANNM)
                  │                    │
                  └──── CanIf ─────────┘ ── PduR/Com (application PDUs)
                          │
                  Can driver ── CanTrcv driver
 ───────────────── hardware ─────────────────
   MCU CAN controller (FD)  ◄─TXD/RXD─►  CAN transceiver  ◄─CANH/CANL─►  bus (120 Ω each end)
                                           │ wake / INH / EN / STB (part-specific)
```

## 2. Physical layer essentials (what can masquerade as an NM fault)

| Concept | What / why | How it shows up | How to test / distinguish |
|---|---|---|---|
| CANH / CANL, differential | Two wires driven in opposite directions; the receiver looks at the difference, rejecting common-mode noise | Recessive ≈ both 2.5 V (diff ≈ 0 V), dominant CANH ≈ 3.5 V / CANL ≈ 1.5 V `[agent_sc3.md §27.2]` | Differential probe or two channels + math on a scope |
| Dominant / recessive, arbitration | Dominant overwrites recessive; lowest ID wins | Under high bus load an NM PDU can be delayed by every lower ID (jitter, never loss) | Bus-load view in a trace; jitter on `SRS_CANNM` |
| Termination | 120 Ω at each end, 60 Ω across an unpowered bus | Missing/extra termination → reflections, error frames, intermittent loss | Ohmmeter across CANH-CANL with power off |
| Bit rate, sample point, CAN FD data phase | Nominal + data bit timing must match on all nodes (`agent_sc3.md` §4.1; OEM 31117229) | Wrong FD data-phase setting → error frames only on FD frames (both NM PDUs are FD frames) | Error-frame counts per ID; scope bit width |
| Error confinement, bus-off | TEC/REC; TEC > 255 → bus-off; missing ACK only drives error-passive `[agent_sc3.md §4.1]` | A bus-off node stops sending everything, including NM PDUs → looks like "went to sleep" | Error frames before the silence; OEM fast/slow recovery pattern (100 ms × 5, then slow — DID 0x0103) |
| Supply faults | Under-/over-voltage stops CAN communication `[OEM 31137830]`, restarts after the window `[OEM 31137832]` | Silence that looks like Prepare Bus-Sleep | Log supply voltage with the CAN trace |

Rule: **silence on the bus is not proof of sleep.** Bus-off, an unpowered transceiver, a supply window, a
bench restbus that stopped, or a filter in the logger all produce the same trace.

## 3. The CAN transceiver

**What it is.** The chip between the MCU's CAN controller (logic-level TXD/RXD) and the two-wire bus. It turns
TXD into dominant/recessive bus levels and the bus difference back into RXD. `[unverified]`

**Why the controller cannot drive the bus directly.** The controller has CMOS logic pins; the bus needs a
differential, short-circuit-proof, ESD-robust driver with a defined common-mode range and a receiver with
thresholds around 0.5–0.9 V differential. That is the transceiver's job. `[unverified]`

**Controller vs transceiver.** The controller does framing, bit timing, arbitration, CRC, error counters,
acceptance filtering. The transceiver does only electrical conversion — plus, on wake-capable parts, low-power
modes and wake detection. `[unverified]`

**Modes (part-specific — never assume).** Typical high-speed transceivers have Normal (TX+RX), Receive-only /
Silent, Standby (low power, bus monitored for wake-up) and, on parts with an INH/supply-control pin, Sleep
(the transceiver switches off the ECU's regulator via INH and wakes it again on a bus wake-up). Wake-up comes
from a bus wake-up pattern (ISO 11898-2 style) or, on selective-wake parts, only from a configured "wake-up
frame". Some parts report the wake source and bus faults through status pins or SPI. `[unverified]`

**How it interacts.** CanTrcv driver sets the mode; CanSM requests transceiver normal/standby as part of
channel start/stop; EcuM checks and validates the wake-up source; the wake-up then leads (via ComM/Nm) to
CanNm_PassiveStartUp or a network request. `[unverified]`

**Consequences of a wrong transceiver configuration** `[unverified]`:

| Misconfiguration | Symptom |
|---|---|
| Left in standby/silent | ECU receives (maybe) but never transmits; NM PDUs from the ECU missing |
| Wake-up disabled or wrong wake source | ECU does not wake from bus activity; only ignition wakes it |
| Wake on any edge (no pattern/selective filter) | Spurious wake-ups from noise or any restbus traffic; high average sleep current |
| Not put to standby/sleep at Bus-Sleep | Sleep current too high although the trace is silent |
| Software mode ≠ hardware mode (mode change not confirmed) | Driver reports "normal" while TX is dead, or "sleep" while the part draws normal current |

**In this project:** the transceiver part, its modes, wake method and the ECU's sleep-current limit are not in
the repository (Q-08). Requirements show the ECU wakes from CAN with hardware ignition OFF `[OEM 31790371]`,
so a wake-capable path exists `[inference]`. Whether it is a generic bus wake-up or selective wake-up is
unknown; NM-DEV-04 (wake only on AWB = 1) may be implemented in software after a generic hardware wake.

## 4. Software modules and their NM role

| Module | What / why | NM-relevant responsibilities | Standardised vs configurable | Black-box testable? |
|---|---|---|---|---|
| Can (driver) | MCU CAN controller access | Controller start/stop/sleep, wake-up detection by controller, bus-off notification | API standard; timing/IDs configured `[unverified]` | Only through bus behaviour |
| CanTrcv | Transceiver mode control and wake reporting | Normal/standby/sleep, wake-up reason | API standard; part-specific behaviour `[unverified]` | Through current and wake behaviour |
| CanIf | PDU routing between driver and upper modules | Routes NM PDUs to CanNm, application PDUs to PduR; PDU-mode (online/offline/TX-offline) | Standard; routing configured `[unverified]` | Indirectly |
| CanSM | CAN channel state manager | Starts/stops the channel for ComM, bus-off recovery | Standard; recovery timing configured `[unverified]` | Bus-off recovery timing (needs bus-off injection) |
| **CanNm** | NM state machine for one CAN channel | States, timers, NM PDU TX/RX, CBV, node detection, wake-up indication | State machine standardised (SWS_CanNm_00092, 00094, …); all timers and features configured (chapter 10) | **Partly**: NM PDU timing/content and the sleep chain |
| Nm (NmIf) | Generic NM interface over bus-specific NMs | Forwards ComM requests; passes CanNm callbacks (Nm_NetworkMode, Nm_PrepareBusSleepMode SWS_CanNm_00114, Nm_BusSleepMode SWS_CanNm_00126, Nm_NetworkStartIndication SWS_CanNm_00127, Nm_RemoteSleepIndication SWS_CanNm_00150) | Standard `[unverified beyond the CanNm callbacks]` | No |
| ComM | Communication manager | Turns user requests into CanNm_NetworkRequest/Release and channel full/silent/no communication | Standard; users and channels configured `[unverified]` | Through application-frame start/stop |
| EcuM | ECU state manager | Startup/shutdown, wake-up source detection and validation | Standard; wake-up sources configured `[unverified]` | Wake-up with/without validation |
| BswM | Mode arbitration | Rules reacting to modes (e.g. enable PDU groups after NM mode change) | Rules entirely configured `[unverified]` | Through its effects only |
| OS | Scheduling of main functions | CanNm main function period (DID 0x0110 lists 10 ms) | Configured | Timer granularity (± one main-function period) |

## 5. End-to-end flows

**Ignition ON from Bus-Sleep (this project, OEM view).** Ignition rises → ECU powers up → CAN controller and
transceiver initialised; no transmission before 150 ms `[OEM 31117240]` → NM enters Bus-Sleep after init
`[OEM 31234521]` → ignition = network request → Repeat Message `[OEM 31234522]`; NM-Timeout and Repeat
Message timers start `[OEM 31234523]`; application TX/RX enabled `[OEM 31234542]`; **no `SRS_CANNM`** on this
first wake-up `[OEM 32088462]` → after the Repeat Message Time, Normal Operation `[OEM 32078450]` →
application TX (with the 350 ms rule) `[OEM 31234543]`. Network diagnostics start after the NM IGN On
Startup Delay (2000 ms, DID 0x0103) `[agent_sc3.md §2.2]`.

**AUTOSAR view of the same** `[unverified except CanNm IDs]`: EcuM startup → ComM user requests FULL_COM →
ComM → Nm → CanNm_NetworkRequest → Bus-Sleep → Repeat Message (SWS_CanNm_00129), NM PDUs start
(SWS_CanNm_00100), AWB set if enabled (SWS_CanNm_00401) → Nm_NetworkMode → ComM → CanSM starts the channel →
Com PDU groups enabled.

**Remote wake-up by `VCU_CANNM` AWB = 1, ignition OFF (OEM).** Bus activity → transceiver/controller
wake-up `[inference]` → AWB = 1 received → Repeat Message `[OEM 31790371]` → `SRS_CANNM` every 100 ms
`[OEM 32088432, 31234550]`, application frames with `IGN_STS_SRS = 2` → after the Repeat Message Time,
Ready Sleep while AWB stays 1 `[OEM-VC 31789302]` `[OEM 31790339]` (no `SRS_CANNM`, application frames continue) →
deployment, diagnostics, fault and GPO management run as in ignition ON `[OEM 32088512]`.

**Release and sleep (OEM).** Ignition OFF and AWB/PKE gone → Ready Sleep → NM-Timeout expires → Prepare
Bus-Sleep: application TX/RX off `[OEM 31234546, impl. no]` → Wait-Bus-Sleep (750 ms) → Bus-Sleep, all
communication off `[OEM 31234541]` → (AUTOSAR view `[unverified]`: Nm_BusSleepMode → ComM NO_COM → CanSM
stops controller, transceiver to standby/sleep → EcuM may power down).

## 6. Development and integration notes (for anyone touching an ECU-side stack)

These apply if CanNm source or configuration ever enters this repository; today none does.
`[unverified, general practice]`

- Separate generated configuration, vendor code and user code before changing anything; change the
  configuration tool input, not generated files.
- Initialisation order: CanIf before CanNm (SWS_CanNm_00253); the channel must be started before NM PDUs can
  be sent.
- Main-function period bounds timer resolution: expect up to one period (10 ms per DID 0x0110) of jitter on
  every NM timer edge.
- Keep NM independent of application fault monitoring (OEM 32088533).
- Validate configuration consistency: NM PDU ID and layout vs DBC, timers vs OEM spec, passive mode vs the
  requirement to send `SRS_CANNM` after a CAN wake-up.
