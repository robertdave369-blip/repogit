# NM state machine, timers and what the bus shows

Source of the OEM rows: `project_reuirements/m310_m314_m110/DES_SW_Mahindra_Network_Management.xlsx`
(full table in `project-implementation.md` §4). AUTOSAR column: R22-11 SWS CanNm (verified IDs only).
Applies to the EV projects with `VCU_CANNM`/`SRS_CANNM` (M310_M314_M110, M210; W610/UPP_EV assumed, DBC
not in repo).

## 1. Inputs the OEM state machine uses

| OEM input | Meaning | Bus/hardware source |
|---|---|---|
| Network requested | `Ignition_Signal` ON `[OEM 31234510]` | Hardwired ignition (bench: `PS.IGN_ON()`) |
| AWB set / clear | Received `CANNM_PDU` with `ACTIVE_WAKEUP_BIT` = 1 / 0 | `VCU_CANNM` (0x38F) byte 1 bit 4 `[DBC]` |
| RMB set / clear | Received `CANNM_PDU` with Repeat Message bit = 1 / 0 | `VCU_CANNM` byte 1 bit 0 `[DBC]` |
| PKE 2/3/4 | `PKE_CLMP_STATE` ∈ {2 ON, 3 CRANK, 4 RUN} | `FR_ZONE2_100` (0x319) bits 16–18 `[DBC]` |
| FrZone2 timer expired | `FR_ZONE2_100` not received for `P_CanNmMsgTimeoutTime` `[inference from name; value Q-03]` | — |
| ACTIVE_WAKEUP_Reception Flag | Undefined in the export (Q-05) `[inference: latch set by the first AWB=1 reception]` | — |

## 2. Transition table (OEM vs AUTOSAR R22-11)

BS = Bus Sleep, PBS = Prepare Bus Sleep, RM = Repeat Message, NO = Normal Operation, RS = Ready Sleep.
"rel." = network released (ignition not ON). Impl. = OEM `_Implemented` flag in the export.

| From | Condition | To | OEM | Impl. | AUTOSAR R22-11 | Match |
|---|---|---|---|---|---|---|
| init | CAN initialised | BS | 31234521 | yes | 00141, 00144 | same |
| BS | network requested | RM | 31234522 | yes | 00129 | same |
| BS | rel. and (AWB set or PKE 2/3/4) | RM | 31790371 | yes | 00127: NM PDU only indicates start; 00128 passive start-up enters RM | OEM extension (NM-DEV-04) |
| BS | rel. and AWB clear and PKE not 2/3/4 | stay BS | 31790372 | yes | 00127 (indication on *any* NM PDU) | OEM extension (NM-DEV-04) |
| RM entry | — | start NM-Timeout and RM timers | 31234523 | yes | 00096, 00102 | same |
| RM | requested and RM timer expired | NO | 32078450 | yes | 00103 | same |
| RM | rel., AWB clear, PKE 2/3/4, FrZone2 timer running, RM timer expired | NO | 31234525 | yes | — (PKE is an OEM input) | OEM extension (NM-DEV-09) |
| RM | rel., AWB set, RMB set | stay RM and restart RM timer | 31789295, 31234524 | yes | no rule for a received RMR in RM (00119/00111 cover NO/RS only) | OEM extension (NM-DEV-07) |
| RM | rel., AWB clear, PKE not 2/3/4, RM timer expired | RS | 31234527 | yes | 00106 | same |
| RM | rel., AWB clear, PKE 2/3/4, FrZone2 expired, RM timer expired | RS | 31789301 | yes | 00106 | same (OEM inputs) |
| RM | AWB set, RMB clear (text truncated in export; target from its VC: "after 400 ms … Ready sleep") | RS | 31789302 | yes | 00106 | same, text incomplete (Q-15) |
| NO | ignition ON | stay NO | 31789836 | yes | — | same |
| NO | rel., AWB clear, PKE 2/3/4, FrZone2 running | stay NO | 31789834 | yes | — | OEM extension (NM-DEV-09) |
| NO | rel., AWB clear, PKE not 2/3/4 | RS | 31234528, 32056081 | yes | 00118 | same |
| NO | rel., AWB clear, PKE 2/3/4, FrZone2 expired | RS | 31789831 | yes | 00118 | same (OEM inputs) |
| NO | rel., AWB set, RMB clear | RS | 32056095 | yes | 00118 | same — a remote AWB does not hold NO |
| NO | rel., AWB set, RMB set | RM | 32056097 | yes | 00119 (needs node detection) | same if node detection configured (NM-DEV-08) |
| RS | network requested | RM | 31234532 | yes | 00110: → **NO** | **deviation** (NM-DEV-06) |
| RS | requested, or rel. + AWB clear + PKE 2/3/4 + FrZone2 running | RM | 31813093 | **no** | 00110 | deviation (NM-DEV-06) |
| RS | rel., AWB set, flag set, RMB clear, NM-Timeout expired | restart NM-Timeout | 31234531 | yes | 00098: restart on **every** NM PDU | **deviation** (NM-DEV-03) |
| RS | rel., AWB set, flag set, RMB clear | stay RS | 31790339 | yes | — | consistent with NM-DEV-03 |
| RS | rel., AWB set, flag clear | RM | 31790328 | yes | — | OEM extension (NM-DEV-07) |
| RS | rel., AWB set, flag set, RMB set | RM | 31234529 | yes | 00111 | same |
| RS | rel., AWB clear, PKE 2/3/4 and FrZone2 expired, NM-Timeout running | stay RS | 31848567 | yes | — | same |
| RS | rel., AWB clear, PKE not 2/3/4, NM-Timeout expired | PBS | 31234533 | yes | 00109 | same transition; but AWB=0 NM PDUs did not restart the timer (NM-DEV-03) |
| RS | rel., AWB clear, PKE 2/3/4, FrZone2 expired, NM-Timeout expired | PBS | 31790290 | yes | 00109 | same |
| PBS | Wait-Bus-Sleep timer expired | BS | 31234535 | yes | 00115 | same |
| PBS | requested, timer running | RM | 31790350 | yes | 00123 | same |
| PBS | rel., timer running, AWB set or PKE 2/3/4 | RM | 31234534 | yes | 00124: **any** NM PDU | **deviation** (NM-DEV-05) |
| PBS | rel., timer running, AWB clear and PKE not 2/3/4 | (text truncated; presumably stay PBS) | 32056145 | yes | 00124 | deviation (NM-DEV-05), text incomplete (Q-15) |
| PBS → RM | — | reset Wait-Bus-Sleep timer | 31234536 | yes | — | same in effect |
| PBS | entry | content-failure diagnosis off, counters reset | 33031889, 33031904 | **no** | — | OEM extension (NM-DEV-16) |
| PBS → RM | — | content-failure diagnosis on | 33031944 | **no** | — | OEM extension (NM-DEV-16) |
| PBS | AWB cleared | `IGN_STS_SRS` → IGN_OFF after `P_IGN_STS_AWB_Clear_Delay` | 32364537 | **no** | — | OEM extension; value Q-04 |
| any | VC error, node absent, DLC, message/signal content failure | must not change NM transitions | 32088533 | yes | layering: CanNm has no such inputs | same (NM-DEV-17) |

Obsolete and not to be tested: 31234526, 32056077 (Normal Operation timer/PKE rules).
Obsolete constraints: 31234549 (NmAsrMessageCount), 31234551 (Remote Sleep Indication).

```mermaid
stateDiagram-v2
    [*] --> BS: CAN init (31234521)
    BS --> RM: IGN ON (31234522) / AWB=1 or PKE 2-4 (31790371)
    RM --> NO: RM timer expired + IGN ON (32078450) or PKE path (31234525)
    RM --> RS: RM timer expired + released (31234527, 31789301, 31789302)
    RM --> RM: AWB=1 + RMB=1 restarts RM timer (31234524)
    NO --> RS: released (31234528, 31789831, 32056081, 32056095)
    NO --> RM: AWB=1 + RMB=1 (32056097)
    RS --> RM: IGN ON (31234532) / RMB=1 (31234529) / new AWB edge (31790328)
    RS --> PBS: NM-Timeout expired, no AWB/PKE (31234533, 31790290)
    PBS --> RM: IGN ON (31790350) / AWB=1 or PKE (31234534)
    PBS --> BS: Wait-Bus-Sleep expired (31234535)
```

## 3. Timers and their values

| OEM timer (expiry parameter) | AUTOSAR counterpart | DID 0x0110 EV (V2.7, V3.4) | DID 0x0110 ICE (V1.4, V1.6, V1.9) | OEM verification criteria | Test-side config |
|---|---|---|---|---|---|
| CANNM_RepeatMsgTimer (`P_NmAsrRepeatMessageTime`) `[OEM 31234539]` | CanNmRepeatMessageTime | "N*400" ms (N undefined) | "N*400" ms | 400 ms (e.g. `[OEM-VC 31790371]`, `[OEM-VC 32078450]`) | W610 `NM_REPEAT_MESSAGE_TIME = 0.4`; others 1.5 (placeholder, F-01) |
| CANNM_Timeout_Timer (`P_NmAsrTimeoutTime`) `[OEM 31234537]` | CanNmTimeoutTime | **500 ms** | 1000 ms | **1000 ms** (`[OEM-VC 31790290]`, `[OEM-VC 31234537]`) | W610 1.0; others 6.0 (placeholder) |
| CANNM_BusSleepTimer (`P_NmAsrWaitBusSleepTime`) `[OEM 31234538]` | CanNmWaitBusSleepTime | 750 ms | 750 ms | 750 ms (`[OEM-VC 31234535]`) | W610 0.75; others 5.0 (placeholder) |
| `SRS_CANNM` period (`P_NmAsrCanMsgCycleTime`) `[OEM 31234550]` | CanNmMsgCycleTime | 100 ms | 100 ms | — | DBC `GenMsgCycleTime` 100 for 0x36D and 0x38F |
| CANNM_FrZone2_Timer (`P_CanNmMsgTimeoutTime`) | none (see glossary) | not listed | not listed | 100 ms (`[OEM-VC 31234534]`) **and** 300 ms (`[OEM-VC 31789831]`) | — |
| IGN_STS AWB clear delay (`P_IGN_STS_AWB_Clear_Delay`) `[OEM 32364537]` | none | not listed | not listed | — | — |
| Remote sleep indication (`NmAsrCanRemoteSleepIndTime`) | CanNmRemoteSleepIndTime | 500 ms | 500 ms | requirement 31234551 obsolete | — |
| Reduced cycle (`NmAsrCanMsgReducedTime`) | CanNmMsgReducedTime | 50 ms | 50 ms | no requirement | DBC node default 50 |
| Cycle offset, main-function period | CanNmMsgCycleOffset, main function | 0 ms, 10 ms | 0 ms, 10 ms | — | DBC node default offset 0 |

Network-diagnostics delays (not CanNm timers, DID 0x0103): NM IGN On Startup Delay 2000 ms; NM restart
delay after under/over-voltage 500 ms; after bus-off 500 ms (EV V2.7/V3.4) / 1000 ms (ICE); after cranking
1000 ms. These gate CAN fault monitoring, see `agent_sc3.md` §2.2.

**Conflicts to resolve before a timing test can be pass/fail:** NM-Timeout 500 vs 1000 ms on EV (NM-DEV-13,
Q-01), "N*400" (Q-02), FrZone2 100 vs 300 ms (Q-03). Until resolved, a timing test measures and reports the
value and states which source it agrees with.

Message-period tolerance: CAN-C requires < 10 % for periods under 100 ms and < 3 % above 100 ms
`[OEM 31137824, 31137826]`; exactly 100 ms is not covered (Q-14). Use ±3 % and say so.

## 4. Communication gating per state

| State | NM TX (`SRS_CANNM`) | NM RX | App TX | App RX | OEM | AUTOSAR R22-11 (CanNm part only) |
|---|---|---|---|---|---|---|
| BS | off | off | off | off | 31234541 | no NM TX (00033); NM RX → start indication (00127) |
| RM, woken by AWB or PKE with ignition OFF | **on** | on | on | on | 31234542, 32088432 | NM TX on (00100) |
| RM, entered by ignition request on first wake-up | **off** | on | on | on | 31234542, 32088462 | NM TX on (00100) — deviation NM-DEV-02 |
| RM, re-entered by ignition from RS/PBS | not specified (Q-10) | on | on | on | — | NM TX on |
| NO | **off** | on | on, **350 ms delay** | on | 31234543, 31234544 | NM TX on (00087, 00116) — deviation NM-DEV-01 |
| RS | off | on | on | on | 31234544, 31234545 (impl. no) | NM TX off (00108) — same |
| PBS | off | on | **off** | **off** | 31234546, 31234547 (impl. no) | NM TX off; application gating is ComM/CanSM scope `[unverified]` |

Note the internal tension: NM RX is "disabled" in BS `[OEM 31234541]`, yet an AWB=1 NM PDU must wake the ECU
from BS `[OEM 31790371]`. `[inference]` The wake-up is detected by the transceiver/controller wake path, after
which the first NM PDUs are evaluated; the export does not describe this (Q-08).

## 5. What the bus can and cannot show

| State | `SRS_CANNM` 0x36D | Airbag application frames (e.g. `SRS1_FD_10`) | `IGN_STS_SRS` | Distinguishable on the bus? |
|---|---|---|---|---|
| BS | absent | absent | — | **not from PBS** — use time since the last application frame (> Wait-Bus-Sleep) and supply current |
| PBS | absent | absent (31234546, impl. no — may still be present on current software) | — | not from BS |
| RM after CAN wake-up | every 100 ms for about one Repeat Message Time | present | 2 | yes — the only state with `SRS_CANNM` |
| RM after ignition (first wake) | absent | present | 1 | **not from NO**, except by time since ignition ON |
| NO | absent | present | 1 with ignition ON | not from RM-after-ignition (see above); RS never lasts with ignition ON, since ignition is a request (31234532) |
| RS (ignition OFF, kept awake by AWB/PKE) | absent | present | 2 | not from NO-with-PKE (31789834); use the response to removing AWB/PKE |

Sleep-entry timing chain after the last keep-awake input disappears (ignition OFF, AWB→0, PKE not 2/3/4)
`[inference from 31234528, 31234533, 31234535]`:

```
NO --(release, immediate)--> RS --(remaining NM-Timeout: 0 … P_NmAsrTimeoutTime)--> PBS --(750 ms)--> BS
      app frames continue        app frames continue           app frames stop       silence
```

The remaining NM-Timeout on entry to RS depends on when the timer was last restarted (on entry to network
mode `[OEM 31234523]`, on AWB receptions `[OEM 31234531]`; the ECU sends no NM PDU in NO, so the AUTOSAR
TX-restart rule 00099 does not refresh it). A black-box test should therefore start the clock at the **last
AWB=1 `VCU_CANNM` frame** in a scenario where AWB held the ECU in RS, where the expected time to the last
application frame is one full NM-Timeout (+ one cycle, + tolerance).
