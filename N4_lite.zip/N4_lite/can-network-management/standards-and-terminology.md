# Standards baseline and terminology

## 1. Baseline register

| Standard / document | Identifier | Edition used | Full text available here? | Status in this knowledge base |
|---|---|---|---|---|
| AUTOSAR CP Specification of CAN Network Management | AUTOSAR_SWS_CANNetworkManagement, Document ID 13 | **R22-11** (2022-11-24) | Read from autosar.org on 2026-10-26; **not stored in the repository** (copyright) | Reference baseline. IDs in §2 verified against the text |
| Same, earlier releases | — | R4.4.0, R19-11, R20-11, R21-11 | No | Change history in R22-11 lists PN rework (R20-11/R21-11), extended Wait Bus-Sleep handling and CAN FD clarification (R19-11). Core state-machine IDs in §2 were not re-checked in older releases `[unverified]` |
| AUTOSAR SWS NmIf (Nm), ComM, CanSM, CanIf, Can, CanTrcv, EcuM, BswM | — | — | No | Described from general knowledge only, labelled `[unverified]` in `autosar-architecture.md` |
| **ECU's actual AUTOSAR release / BSW vendor** | — | **Unknown** | — | No ARXML, BSW source or vendor note in the repository (Q-09) |
| ISO 11898-1 (CAN data link, CAN FD), ISO 11898-2 (high-speed physical layer, incl. low-power/wake-up) | — | Unknown | No | Physical/link facts from `agent_sc3.md` §4.1, §27.2 and general knowledge |
| OSEK/VDX NM, CANopen NMT (CiA 301), SAE J1939-81 address claim | — | — | No | Explanation only (§4); not used by this ECU `[inference: no such frames in any project DBC]` |
| Mahindra OEM NM requirements | `DES_SW_Mahindra_Network_Management.xlsx` (Codebeamer export; IDs 31234500–33031944) | Export with modifications up to 2025-03-25 | Yes | Primary project requirement source |
| Mahindra IVN CANNM specification | "Mahindra_IVN_CANNM_Specification" (cited by requirement 31234503) | — | **No** | Missing (Q-13) |
| Mahindra diagnostic spec, NM DIDs | `M312_M112_M210_SRS_V2.7_DIAG_RE.xlsx`, `..._V3.4_...` (EV); `ICE_COMMON_SRS_V1.4/V1.6/V1.9_DIAG_RE.xlsx` (ICE) | Several | Yes | DID 0x0103, 0x0104, 0x0110 defaults |
| Mahindra CAN-C requirements | `project_reuirements/m310_m314_m110/CAN C Requirements/*.xlsx` | — | Yes | Bus-off, missing ACK, CAN init timing, TX tolerance |

## 2. Verified AUTOSAR R22-11 SWS_CanNm IDs

Only the IDs below may be cited as `[AUTOSAR R22-11 SWS_CanNm_xxxxx]`. Add an ID only after reading it in the
document. Paraphrases are ours.

| ID | Meaning (paraphrase) |
|---|---|
| SWS_CanNm_00141, SWS_CanNm_00144 | After successful init the state is Bus-Sleep Mode |
| SWS_CanNm_00085 | Init sets the Control Bit Vector to 0x00 |
| SWS_CanNm_00033 | After init, NM PDU transmission is stopped (Message Cycle Timer stopped) |
| SWS_CanNm_00092, SWS_CanNm_00094 | Three operational modes (Network, Prepare Bus-Sleep, Bus-Sleep); Network Mode has Repeat Message, Normal Operation, Ready Sleep |
| SWS_CanNm_00314, SWS_CanNm_00315 | Entering Network Mode from Bus-Sleep or Prepare Bus-Sleep goes to Repeat Message by default |
| SWS_CanNm_00096 | Entering Network Mode starts the NM-Timeout Timer |
| SWS_CanNm_00098 | Every successfully received NM PDU in Network Mode restarts the NM-Timeout Timer (if PDU transmission ability is enabled) |
| SWS_CanNm_00099 | Every successfully transmitted NM PDU restarts the NM-Timeout Timer |
| SWS_CanNm_00100 | Entering Repeat Message (re)starts NM PDU transmission unless passive mode or communication disabled |
| SWS_CanNm_00101, SWS_CanNm_00117 | NM-Timeout expiry in Repeat Message / Normal Operation restarts the timer (and reports a DET runtime error, SWS_CanNm_00193 / SWS_CanNm_00194) |
| SWS_CanNm_00102 | Repeat Message lasts CanNmRepeatMessageTime |
| SWS_CanNm_00103, SWS_CanNm_00106 | Leaving Repeat Message → Normal Operation if requested, Ready Sleep if released |
| SWS_CanNm_00104, SWS_CanNm_00105 | CanNm_NetworkRequest / CanNm_NetworkRelease set the network to requested / released |
| SWS_CanNm_00107 | With node detection, the Repeat Message bit is cleared when leaving Repeat Message |
| SWS_CanNm_00087 | A node transmits periodic NM PDUs while it needs the bus, otherwise none |
| SWS_CanNm_00116, SWS_CanNm_00006 | Entering Normal Operation from Ready Sleep starts NM PDU transmission immediately |
| SWS_CanNm_00118 | Network release in Normal Operation → Ready Sleep |
| SWS_CanNm_00119, SWS_CanNm_00111 | With node detection, a received Repeat Message Request bit in Normal Operation / Ready Sleep → Repeat Message |
| SWS_CanNm_00108 | Entering Ready Sleep stops NM PDU transmission |
| SWS_CanNm_00109 | NM-Timeout expiry in Ready Sleep → Prepare Bus-Sleep |
| SWS_CanNm_00110 | Network request in Ready Sleep → **Normal Operation** |
| SWS_CanNm_00114 | Entering Prepare Bus-Sleep notifies Nm_PrepareBusSleepMode |
| SWS_CanNm_00115 | Prepare Bus-Sleep lasts CanNmWaitBusSleepTime, then Bus-Sleep (unless CanNmStayInPbsEnabled) |
| SWS_CanNm_00088 | Released and no NM PDUs for CanNmTimeoutTime + CanNmWaitBusSleepTime → Bus-Sleep |
| SWS_CanNm_00123, SWS_CanNm_00124 | Network request, or **any** received NM PDU, in Prepare Bus-Sleep → Network Mode (Repeat Message) |
| SWS_CanNm_00122 | With CanNmImmediateRestartEnabled, a request in Prepare Bus-Sleep sends an NM PDU at once |
| SWS_CanNm_00126 | Entering Bus-Sleep (except at init) notifies Nm_BusSleepMode |
| SWS_CanNm_00127, SWS_CanNm_00336 | An NM PDU received in Bus-Sleep only notifies Nm_NetworkStartIndication (and a DET runtime error); CanNm itself stays in Bus-Sleep |
| SWS_CanNm_00128, SWS_CanNm_00129 | CanNm_PassiveStartUp or a network request in Bus-Sleep / Prepare Bus-Sleep → Network Mode (Repeat Message) |
| SWS_CanNm_00147 | CanNm_PassiveStartUp in Network Mode is rejected |
| SWS_CanNm_00137 | CanNm_RepeatMessageRequest is rejected in Repeat Message, Prepare Bus-Sleep and Bus-Sleep |
| SWS_CanNm_00045 | CBV bits: 0 Repeat Message Request, 1 PN Shutdown Request, 3 NM Coordinator Sleep, 4 Active Wakeup, 5 PN Learning, 6 PN Information; 2 and 7 not assigned |
| SWS_CanNm_00074, SWS_CanNm_00075 | Source Node ID and CBV positions configurable: byte 0, byte 1 or off |
| SWS_CanNm_00013 | Transmitted node ID = CanNmNodeId unless NID position is off |
| SWS_CanNm_00401, SWS_CanNm_00402 | With CanNmActiveWakeupBitEnabled, AWB is set when CanNm_NetworkRequest causes the wake-up from Bus-Sleep/Prepare Bus-Sleep, and cleared when Network Mode is left |
| SWS_CanNm_00005, SWS_CanNm_00334 | NM PDU start in Repeat Message: delayed by CanNmMsgCycleOffset unless an active wake-up with immediate transmissions, which uses CanNmImmediateNmCycleTime |
| SWS_CanNm_00072, SWS_CanNm_00161, SWS_CanNm_00073 | Passive mode (CanNmPassiveModeEnabled): no NM PDU transmission, no transmission error handling |
| SWS_CanNm_00149, SWS_CanNm_00150, SWS_CanNm_00151 | Remote Sleep Indication: optional; no NM PDUs for CanNmRemoteSleepIndTime in Normal Operation → Nm_RemoteSleepIndication; cancelled on a new NM PDU |
| SWS_CanNm_00410, SWS_CanNm_00411, SWS_CanNm_00413, SWS_CanNm_00414 | Partial networking: PNI bit; with CanNmPnEnabled and PNI=0, NM PDUs are ignored unless CanNmAllNmMessagesKeepAwake |
| SWS_CanNm_00069, SWS_CanNm_00157, SWS_CanNm_00156 | Bus-load reduction (CanNmMsgReducedTime) active in Normal Operation only, if enabled |
| SWS_CanNm_00170, SWS_CanNm_00173, SWS_CanNm_00174, SWS_CanNm_00179 | CanNm_DisableCommunication stops NM PDU transmission and the NM-Timeout Timer; re-enabling restarts it |
| SWS_CanNm_00066, SWS_CanNm_00446 | Transmission failure → Nm_TxTimeoutException; with global PN support, Tx timeout → CanSM_TxTimeoutException |
| SWS_CanNm_00246, SWS_CanNm_00248, SWS_CanNm_00249 | CanNmTimeoutTime, CanNmWaitBusSleepTime, CanNmRemoteSleepIndTime define the respective timing parameters |
| SWS_CanNm_00253 | CanNm_Init is called after CanIf initialisation |

Configuration parameters (chapter 10, R22-11), all per channel and **configurable, not fixed by the
standard**: `CanNmMsgCycleTime` (period), `CanNmRepeatMessageTime` (time in Repeat Message),
`CanNmTimeoutTime` ("how long NM stays in Ready Sleep before Prepare Bus-Sleep"), `CanNmWaitBusSleepTime`
(calm-down time in Prepare Bus-Sleep), `CanNmMsgCycleOffset`, `CanNmImmediateNmCycleTime`,
`CanNmRemoteSleepIndTime`, `CanNmMsgTimeoutTime`; switches `CanNmPassiveModeEnabled`,
`CanNmActiveWakeupBitEnabled`, `CanNmNodeDetectionEnabled`, `CanNmStayInPbsEnabled`,
`CanNmAllNmMessagesKeepAwake`. The ECU's values for these are not in the repository; the OEM publishes its
own `NmAsr*` set in DID 0x0110 (see `state-machine-and-timers.md` §3).

## 3. Glossary and wording traps

| Term | Meaning | Trap in this project |
|---|---|---|
| Network requested / released | Local need for communication (AUTOSAR: CanNm_NetworkRequest/Release via ComM) | OEM: requested **⇔ hardwired ignition ON** `[OEM 31234510]`; "released" = ignition not ON |
| Active wake-up (AUTOSAR) | **This** node woke the network by its own request; it sets AWB in its own NM PDU `[AUTOSAR R22-11 SWS_CanNm_00401]` | OEM test procedures call *receiving* `VCU_CANNM.ACTIVE_WAKEUP_BIT = 1` an "Active Wakeup" (e.g. `[OEM-VC 31234523]`, `[OEM-VC 31790371]`, `[OEM-VC 32088512]`). For the airbag ECU that is a **remote** wake-up |
| Passive wake-up (AUTOSAR) | Woken by another node's NM PDU | OEM-VC uses "Passive Wakeup" for the **PKE clamp** path (`FR_ZONE2_100.PKE_CLMP_STATE` = 2) `[OEM-VC 31789831]` |
| Local wake-up | Wake from a local input | OEM-VC: ignition ON from Bus Sleep `[OEM-VC 31234521]` |
| AWB, Active Wakeup Bit | CBV bit 4 `[AUTOSAR R22-11 SWS_CanNm_00045]`; informational in AUTOSAR | Used by the OEM as the **keep-awake/wake request** signal (NM-DEV-03) |
| RMR, Repeat Message Request | CBV bit 0; forces receivers into Repeat Message (node detection) | OEM name `CANNM_RepeatMsgBit`, DBC `REPEAT_MESSAGE_REQUEST` |
| CANNM_PDU | OEM name for a received NM PDU | On EV DBCs only `VCU_CANNM` (0x38F) is received |
| PKE_CLMP_State | Clamp state from the passive-entry system, `FR_ZONE2_100` (0x319) bits 16–18 | OEM keep-awake input `[OEM 31234514]`; values 2 ON, 3 CRANK, 4 RUN wake/keep awake `[OEM 31790371, 31234525]` |
| CANNM_FrZone2_Timer | OEM timer for `FR_ZONE2_100` reception, expiry `P_CanNmMsgTimeoutTime` | No AUTOSAR CanNm counterpart (`CanNmMsgTimeoutTime` in AUTOSAR is the NM PDU **Tx** timeout — same name, different meaning) |
| `IGN_STS_SRS` | Airbag ECU signal: 0 off, 1 ignition ON by hardware, 2 ignition ON due to CAN wake-up, 3 reserved | Best black-box proxy for "awake because of CAN" `[config canc_config State_Values]` |
| NM IGN On Startup Delay | DID 0x0103: delay before **network diagnostics** start | Not a CanNm timer; do not confuse with Repeat Message Time |
| ACTIVE_WAKEUP_Reception Flag | Used in Ready Sleep transitions | Not defined in the export ("DataDictionary module", not in repo) — Q-05 |
| Bus-off | ISO 11898-1 error state after TEC > 255 | Handled by OEM fast/slow recovery (CAN-C sheet), not by NM |

## 4. CanNm versus other "network management" on CAN

| Mechanism | What it is | Why it exists | How it works | Relation to this ECU |
|---|---|---|---|---|
| **AUTOSAR CanNm** | Decentralised, *indirect* NM: no ring, no master; each node only broadcasts "I need the bus" | Coordinated sleep of all nodes without a master | Periodic NM PDUs while needed; silence for timeout + wait-bus-sleep → all sleep | The OEM state machine uses its states and timers (with deviations) |
| OSEK/VDX NM (direct) | Logical ring: each node passes a ring message to its successor; limp-home on faults | Pre-AUTOSAR coordinated sleep with node monitoring | Token-like ring messages, sleep indication bits, ring stabilisation `[unverified]` | Not used; no ring messages in any DBC |
| CANopen NMT (CiA 301) | **Master/slave state control** of devices: Initialisation, Pre-operational, Operational, Stopped | Industrial/commercial device control, not power saving | NMT master sends commands (CAN-ID 0) and monitors heartbeats `[unverified]` | Not applicable; do not equate NMT "start/stop node" with CanNm sleep |
| SAE J1939-81 address claim | Dynamic **source-address arbitration** on 29-bit networks | Unique addresses for plug-in nodes in trucks/off-highway | Address Claimed PGN with 64-bit NAME; lowest NAME wins `[unverified]` | Not applicable; it decides *who has which address*, not *when to sleep* |
| ISO 11898-2 wake-up / selective wake-up | Transceiver low-power mode woken by a bus wake-up pattern or (selective) by one configured frame | Low quiescent current with bus-triggered wake | Transceiver monitors the bus while the MCU is off `[unverified]` | Transceiver part and wake method unknown (Q-08) |

None of these is "another name" for CanNm. A CAN log showing silence proves only that nobody transmitted —
not which NM scheme, nor that any node reached a low-power state.
