# CAN Network Management — knowledge base overview

Persistent reference for `.github/agents/can-network-management-engineer.agent.md`. Created 2026-10-26
from a full inspection of this repository and the AUTOSAR CP R22-11 SWS CanNm text.

## 1. Scope and the one thing to remember

This repository is a **black-box HIL test framework**. The airbag ECU's NM software is not here: no BSW
source, no ARXML, no generated CanNm configuration. What this knowledge base knows about the ECU's NM comes
from:

| Evidence class | Source in this repository | Strength |
|---|---|---|
| OEM requirement | `project_reuirements/m310_m314_m110/DES_SW_Mahindra_Network_Management.xlsx` (Codebeamer export, 64 requirements, last modified 2025-03-25) | Normative for the ECU (approved rows) |
| OEM verification criteria | Same workbook, `_Verification_Criteria` column | Test procedure text; source of most timer *numbers* — weaker than normative text |
| OEM parameter table | `docs/project_documents/Common Diag Spec/*_DIAG_RE.xlsx`, sheet `NetworkMgmtIdentifiers` (DID 0x0103, 0x0104, 0x0110) | Default calibration values |
| OEM CAN-C requirements | `project_reuirements/m310_m314_m110/CAN C Requirements/*.xlsx` | Bus-off, missing ACK, CAN init timing, node monitoring |
| DBC | `project_dbc/*/` | NM PDU IDs, layout, cycle time |
| Project config / test code | `projects/<P>/config/`, `shared_libraries/`, `projects/W610/modules/CANNM/scripts/` | How the *bench* drives and checks NM — not ECU behaviour |
| Standard | AUTOSAR CP R22-11 SWS CanNm (Document ID 13), read 2026-10-26 | Reference baseline only; the ECU's AUTOSAR release is unknown |
| Bench observation | `test_logs/`, `test_results/` | **None yet**: no log in the repository contains `SRS_CANNM` (0x36D) or `VCU_CANNM` (0x38F) (searched 2026-10-26) |

So every statement about how the ECU behaves is a requirement or an inference until a bench trace confirms it.

## 2. Files

| File | Use it for |
|---|---|
| [standards-and-terminology.md](standards-and-terminology.md) | Standards baseline, verified `SWS_CanNm_*` list, glossary, OEM-vs-AUTOSAR wording traps, CanNm vs OSEK NM / CANopen NMT / J1939 |
| [autosar-architecture.md](autosar-architecture.md) | Physical layer, transceiver, controller, the BSW chain up to ComM/EcuM/BswM, call flows |
| [project-implementation.md](project-implementation.md) | Inventory per project, NM PDU layout, OEM requirement table, findings F-01… |
| [state-machine-and-timers.md](state-machine-and-timers.md) | OEM state machine and transition table, timer sources, per-state bus observables |
| [oem-deviation-matrix.md](oem-deviation-matrix.md) | NM-DEV-01… classification and routing paths A–E |
| [black-box-testing.md](black-box-testing.md) | Method, bench equipment, observability limits, timing measurement |
| [test-case-catalogue.md](test-case-catalogue.md) | NM-TC-01… with traceability, priority, status; coverage gaps |
| [troubleshooting.md](troubleshooting.md) | Symptom-driven root-cause playbook |

Checker: `py -3 tools/check_cannm_docs.py` (requirement IDs exist, `SWS_CanNm_*` IDs verified, repo paths resolve).

## 3. Evidence labels used everywhere

`[AUTOSAR R22-11 SWS_CanNm_xxxxx]` · `[OEM <ID>]` · `[OEM-VC <ID>]` (verification criteria) ·
`[DID 0x0110 V3.4]` · `[DBC]` · `[config]` · `[observed]` · `[inference]` · `[unverified]` · `[illustrative]`.

## 4. CAN Network Management in one page

**What it is.** CAN NM is a protocol and a per-node state machine that coordinates *when the nodes of one CAN
network may communicate and when they may all go to sleep together*. Each node that still needs the bus says
so (in AUTOSAR CanNm: by sending periodic NM PDUs); when no node needs it any more, every node sees the
silence, waits a common calm-down time, and stops communicating at the same moment. `[AUTOSAR R22-11
SWS_CanNm_00087, SWS_CanNm_00088]`

**Why it exists.** A vehicle has dozens of ECUs on shared buses and a 12 V battery that must survive weeks
parked. Without coordination, one ECU could sleep while another still sends to it (it would miss messages and
raise timeout faults), or one ECU could keep the whole bus — and every transceiver and MCU on it — awake and
drain the battery. NM gives a *distributed* agreement: no master, and the network sleeps only when nobody
needs it.

**CAN frame vs PDU vs message vs NM message.** A *CAN frame* is what is on the wire (identifier, DLC, data,
CRC). A *PDU* is the payload unit the software stack handles; one frame carries one I-PDU here. An
*application message* carries functional signals (e.g. `SRS1_FD_10`). An *NM message / NM PDU* is a frame
reserved for network management (here `SRS_CANNM` 0x36D from the airbag ECU, `VCU_CANNM` 0x38F from the VCU)
carrying a node ID and a control bit vector, not application data. `[DBC]`

**Communication vs managing communication.** CAN itself only moves frames. NM decides whether the node's
communication stack is allowed to run (network mode) or must be shut down (bus-sleep). In AUTOSAR, CanNm tells
the generic NM interface and ComM, which switch the channel's communication on or off. `[AUTOSAR R22-11
SWS_CanNm_00114, SWS_CanNm_00126, SWS_CanNm_00127]`

**Node vs network responsibility.** A node controls only its own request ("I need the bus") and its own
sleep. The network sleeps when *all* requests are gone — a property no single node can force.

### Typical scenarios (general behaviour, then this project)

| Scenario | Expected behaviour (AUTOSAR-style) | This project (OEM) | Typical failure | How to test |
|---|---|---|---|---|
| Ignition ON wakes an ECU | Local request → Repeat Message → Normal Operation; NM PDUs sent | IGN = network request `[OEM 31234510]`; **no `SRS_CANNM` on first wake** `[OEM 32088462]` | No application frames after init | NM-TC-04 |
| Another ECU wakes the network | Remote NM PDU → node starts, joins | Only `VCU_CANNM` with `ACTIVE_WAKEUP_BIT=1` or `PKE_CLMP_STATE` 2/3/4 wakes it `[OEM 31790371]` | ECU stays asleep, or wakes on any traffic | NM-TC-01, NM-TC-02 |
| One ECU releases while others still need the bus | Released node stays in Ready Sleep while others' NM PDUs arrive | Ready Sleep held only while AWB=1 is received `[OEM 31234531]` | ECU sleeps early or never | NM-TC-03 |
| All requests gone | Ready Sleep → (NM-Timeout) → Prepare Bus-Sleep → (Wait Bus-Sleep) → Bus-Sleep | Same chain; NM PDUs with AWB=0 do **not** keep it awake `[OEM 31234533]` | Stuck awake, high sleep current | NM-TC-02, NM-TC-03 |
| Unexpected NM PDU keeps the network awake | Any NM PDU restarts the timeout `[AUTOSAR R22-11 SWS_CanNm_00098]` | Only AWB=1 restarts it (NM-DEV-03) | — | NM-TC-02 |
| Wake-up while going to sleep | Request or NM PDU in Prepare Bus-Sleep → back to Repeat Message `[AUTOSAR R22-11 SWS_CanNm_00123, SWS_CanNm_00124]` | IGN, AWB=1 or PKE only `[OEM 31790350, 31234534]` | Missed wake, ECU sleeps with IGN ON | NM-TC-06 |
| Transceiver wakes the MCU | Bus activity → transceiver wake flag → MCU start → validation | Mechanism and transceiver part not documented (Path E) | Spurious wake, no wake | troubleshooting.md T-06, T-14 |

## 5. Project at a glance (verified 2026-10-26)

- **EV projects with an NM PDU in the DBC:** M310_M314_M110 (DBC 41243) and M210 (DBC 40250): `SRS_CANNM`
  0x36D (TX by the airbag ECU), `VCU_CANNM` 0x38F (RX), both 8-byte CAN FD frames, 100 ms. W610 and UPP_EV
  point at DBCs outside the repository (`C:\CAN_DB\...`), so their NM frames are unverified.
- **ICE projects** U171 and Z121: no NM PDU in the DBC. Z121 has `MBFM_WAKEUP` but the user decided on
  2026-10-22 that Z121 does not support CAN wake-up. The ICE DIAG_RE still lists DID 0x0110 NM parameters
  (open question Q-07).
- **The OEM NM design is a "partially passive" AUTOSAR-style NM:** same five states, but the ECU sends
  `SRS_CANNM` only in Repeat Message after a CAN wake-up, never in Normal Operation or Ready Sleep, and it
  stays awake on `ACTIVE_WAKEUP_BIT`/`PKE_CLMP_STATE`/ignition rather than on "any NM PDU". See the deviation
  matrix.

## 6. Change log

| Date | Change | By |
|---|---|---|
| 2026-10-26 | Knowledge base created: repository inventory, OEM requirement analysis, AUTOSAR R22-11 comparison, deviation matrix, test catalogue, findings F-01..F-10 | can-network-management-engineer (initial build) |
