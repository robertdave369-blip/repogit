# CAN NM test-case catalogue

Black-box cases for the EV projects (`VCU_CANNM` / `SRS_CANNM`), ordered by priority. All expected values
name their source; values in conflict are measured and reported (NM-DEV-13..15). Execution status: **none of
these cases has been run** (no NM trace exists in the repository, F-09). Common set-up for every case:
fault-free bench, battery ON, CAN logging to file for the whole case, restbus running unless stated,
`VCU_CANNM` AWB = 0 and RMR = 0 and `FR_ZONE2_100.PKE_CLMP_STATE` = 0 unless stated. Common clean-up:
AWB → 0 before ignition ON, restbus restored, ignition ON (`CAN_Wakeup_Restore()` pattern).

"Bus Sleep established" means: ignition OFF, no keep-awake input, and no airbag application frame for at
least NM-Timeout + Wait-Bus-Sleep + margin since the last keep-awake input, confirmed from the log.

Priority: **P1** mandatory (core OEM behaviour and the deviations that change test expectations) ·
**P2** important · **P3** exploratory / blocked.

---

### NM-TC-01 — Remote wake-up by AWB and the `SRS_CANNM` burst (P1)
- **Objective:** a CAN wake-up by `VCU_CANNM` AWB = 1 starts the ECU, sends `SRS_CANNM` only during Repeat
  Message, then holds the ECU in Ready Sleep without `SRS_CANNM`.
- **Trace:** OEM 31790371, 31234523, 32088432, 31234542, 31789302 (VC), 31790339, 31234544, 31234550,
  32088512; NM-DEV-02, NM-DEV-03, NM-DEV-10.
- **Pre:** Bus Sleep established.
- **Stimulus:** `VCU_CANNM` AWB = 1, RMR = 0, every 100 ms, ignition stays OFF, for ≥ 3 s.
- **Expected:** (1) airbag application frames resume; (2) `SRS1_FD_10.IGN_STS_SRS = 2`; (3) `SRS_CANNM`
  (0x36D, 8-byte FD frame) every 100 ms ±3 % (Q-14) from wake-up for one Repeat Message Time (400 ms per
  OEM-VC, Q-02), then **no** `SRS_CANNM` while AWB stays 1; (4) application frames continue while AWB = 1.
- **Pass/fail:** all four from the log; burst length reported against 400 ms ± (100 ms + 10 ms).
- **Implementation:** not implemented as such. W610 Testcase15 covers parts with conflicting expectations
  (F-02). `CAN_Wakeup()` performs the stimulus but its `SRS_CANNM` check is not valid (F-03).

### NM-TC-02 — NM PDUs with AWB = 0 neither wake nor keep awake (P1)
- **Objective:** verify the OEM keep-awake rule that differs from AUTOSAR (any NM PDU keeps awake).
- **Trace:** OEM 31790372, 31234533 (VC "keep sending AWB=0 … Prepare Bus sleep"), 31234514; NM-DEV-03,
  NM-DEV-04; contrast AUTOSAR R22-11 SWS_CanNm_00098, SWS_CanNm_00127.
- **Part a, Pre:** Bus Sleep established. **Stimulus:** `VCU_CANNM` AWB = 0, RMR = 0 every 100 ms for ≥ 5 s.
  **Expected:** no airbag frame at all. (Optional: supply current stays at its sleep level; limit Q-08.)
- **Part b, Pre:** ECU held awake by AWB = 1 with ignition OFF (as NM-TC-01, ≥ 1 s after wake-up).
  **Stimulus:** switch AWB to 0 while `VCU_CANNM` continues every 100 ms. **Expected:** application frames
  stop one NM-Timeout after the last AWB = 1 frame (see NM-TC-03 for the value) despite continuing NM PDUs.
- **Pass/fail:** a: zero airbag frames; b: application frames stop within NM-Timeout + 110 ms + 3 % (or
  that plus Wait-Bus-Sleep if application frames continue in PBS — see NM-TC-03).
- **Implementation:** none.

### NM-TC-03 — Sleep-entry timing after keep-awake removal (P1)
- **Objective:** measure NM-Timeout and Wait-Bus-Sleep as seen on the bus; resolves Q-01.
- **Trace:** OEM 31234533, 31234537, 31234546 (impl. no), 31234535, 31234538, 31234541; NM-DEV-13,
  NM-DEV-18.
- **Pre:** as NM-TC-02 b.
- **Stimulus:** stop `VCU_CANNM` entirely (frame disabled) at t0 = last AWB = 1 frame.
- **Expected:** last application frame at t0 + NM-Timeout (EV DID 500 ms **or** OEM-VC 1000 ms) ± 110 ms;
  no frame afterwards; supply current reaches its sleep level within Wait-Bus-Sleep (750 ms) after that.
- **Pass/fail:** report the measured NM-Timeout and state which source it matches; FAIL if it matches
  neither, or if any airbag frame appears after the silence starts. If application frames do **not** stop at
  PBS entry (31234546 not implemented), report the observed end of traffic as PBS + Wait-Bus-Sleep instead.
- **Implementation:** none.

### NM-TC-04 — Ignition wake-up: no `SRS_CANNM` (P1)
- **Objective:** a local (ignition) wake-up starts application communication without NM PDUs.
- **Trace:** OEM 31234510, 31234522, 32078450, 32088462, 31234543, 31234544, 31117240; NM-DEV-01,
  NM-DEV-02.
- **Pre:** Bus Sleep established. **Stimulus:** ignition ON, observe ≥ 3 s.
- **Expected:** first airbag frame ≥ 150 ms after ignition ON (31117240); `IGN_STS_SRS = 1`; **no**
  `SRS_CANNM` at any time.
- **Pass/fail:** from the log.
- **Implementation:** W610 Testcase15 expects the opposite in Normal Operation (F-02).

### NM-TC-05 — Repeat Message Request from the VCU (P1)
- **Objective:** RMR = 1 with AWB = 1 moves the ECU to Repeat Message and holds it there while RMR stays 1.
- **Trace:** OEM 32056097, 31789295, 31234524, 32088432, 31789302 (VC); NM-DEV-07, NM-DEV-08.
- **Pre:** ignition ON (Normal Operation), then at t0: ignition OFF together with `VCU_CANNM` AWB = 1, RMR = 1.
- **Stimulus:** hold RMR = 1 for ≥ 2 s, then RMR = 0 (AWB stays 1).
- **Expected:** `SRS_CANNM` present every 100 ms from t0 while RMR = 1; stops one Repeat Message Time after
  RMR → 0; application frames continue.
- **Implementation:** none.

### NM-TC-06 — Wake-up request during Prepare Bus-Sleep (P1)
- **Objective:** ignition, AWB = 1 or PKE 2/3/4 inside the Wait-Bus-Sleep window restarts the network; an
  NM PDU with AWB = 0 does not.
- **Trace:** OEM 31790350, 31234534, 32056145, 31234536, 31234535; NM-DEV-05.
- **Pre:** as NM-TC-03 up to the last application frame (PBS entry, t_pbs).
- **Stimulus (one per run):** (a) ignition ON at t_pbs + 300 ms; (b) AWB = 1 at t_pbs + 300 ms;
  (c) `VCU_CANNM` AWB = 0 at t_pbs + 300 ms; (d) as (b) at t_pbs + 1000 ms (after Wait-Bus-Sleep).
- **Expected:** (a) frames resume, `IGN_STS_SRS = 1`, no `SRS_CANNM`; (b) frames resume with a `SRS_CANNM`
  burst; (c) silence continues; (d) like NM-TC-01 (wake from Bus Sleep — indistinguishable on the bus from
  (b), record the difference in reaction time only).
- **Implementation:** none.

### NM-TC-07 — CAN-C faults do not change NM transitions (P1)
- **Objective:** application-level CAN faults leave wake/sleep behaviour and timing unchanged.
- **Trace:** OEM 32088533; NM-DEV-17.
- **Stimulus:** repeat NM-TC-01 and NM-TC-03 with, one at a time: node absent (key frame disabled), message
  content failure (CRC/counter frozen), variant-code error — using the fault recipes in `agent_sc3.md` §25.5
  (#1, #3) and the project's `canc_config.py`.
- **Expected:** same observables and timings as the fault-free runs (within tolerance).
- **Implementation:** none; W610 Testcase12 combines AWB wake-up with fault diagnostics (review against F-04).

### NM-TC-08 — `SRS_CANNM` layout and period (P1)
- **Objective:** the transmitted NM PDU matches the DBC and the OEM period.
- **Trace:** OEM 31234550; DBC 41243/40250; NM-DEV-10, NM-DEV-11.
- **Stimulus:** NM-TC-01 log.
- **Expected:** ID 0x36D, 8 bytes, CAN FD frame; byte 1 bits other than 0 and 4 = 0; period 100 ms ±3 %.
  Node ID, AWB/RMR values and byte 2 are **recorded, not judged** (Q-06). Do not require a minimum number
  of frames (rationale of 31234550).
- **Implementation:** none.

### NM-TC-09 — PKE clamp wake-up and keep-awake (P2)
- **Trace:** OEM 31790371, 31234525, 31789834, 31789831, 31790290, 31848567; NM-DEV-09, NM-DEV-15.
- **Stimulus:** from Bus Sleep, `FR_ZONE2_100.PKE_CLMP_STATE` = 2 every 100 ms (valid E2E/SecOC); then each
  of the classes {0, 1}, {2, 3, 4}, {5, 6, 7}; then stop `FR_ZONE2_100`.
- **Expected:** wake and stay awake for 2/3/4 only, with an `SRS_CANNM` burst (32088432); after
  `FR_ZONE2_100` stops: application frames stop after FrZone2 timer (100 or 300 ms, Q-03) + NM-Timeout.
- **Implementation:** none. Blocker: confirm the bench can send `FR_ZONE2_100` with valid MAC/freshness.

### NM-TC-10 — AWB edge in Ready Sleep (P2)
- **Trace:** OEM 31790328, 31790339, 31234531; NM-DEV-07; Q-05.
- **Stimulus:** ECU in Ready Sleep held by AWB = 1; AWB → 0 for 200 ms (less than NM-Timeout) → 1.
- **Expected `[inference: flag = latch of AWB reception]`:** a new `SRS_CANNM` burst (re-entry to Repeat
  Message) only if the flag was cleared in between. Exploratory until Q-05 is answered.

### NM-TC-11 — Communication gating and `IGN_STS_SRS` in Prepare Bus-Sleep (P2)
- **Trace:** OEM 31234546, 31234547, 32364537 (all impl. no); NM-DEV-18; Q-11.
- **Expected:** application frames stop at PBS entry; `IGN_STS_SRS` → 0 after `P_IGN_STS_AWB_Clear_Delay`
  (value unknown). Expected to fail on software where these rows are not implemented — report, do not
  "fix" the expectation.

### NM-TC-12 — Content-failure diagnosis across PBS (P2)
- **Trace:** OEM 33031889, 33031904, 33031944 (impl. no); NM-DEV-16.
- **Stimulus:** start a message-content failure below its qualification count, let the ECU pass through PBS
  and back to Repeat Message (NM-TC-06 b), continue the failure.
- **Expected:** the counter restarts (DTC qualifies a full detection count after re-entry).

### NM-TC-13 — Functions under CAN wake-up (P2)
- **Trace:** OEM 32088512.
- **Expected:** with the ECU awake by AWB = 1 and ignition OFF, UDS answers, DTC handling, deployment and
  GPO management work as with ignition ON.
- **Implementation:** largely covered by the EDR CAN-wake-up scripts (`CAN_Wakeup()` users); diagnostics and
  GPO under CAN wake-up are not separately covered.

### NM-TC-14 — Sleep current after Bus-Sleep (P3, blocked)
- **Expected:** `PS.GetCurrentVBAT()` below the ECU's quiescent-current limit — limit not in the repository
  (Q-08). Until then: measure and record only.

### NM-TC-15 — Bus-off in Network Mode (P3, blocked)
- **Trace:** CAN-C 31123365, 31123367, 31123368, 31123370, 31123371; DID 0x0103 (fast 100 ms × 5, slow
  500/1000 ms, NM restart delay after bus-off); NM-DEV-19.
- **Blocked:** no bench wrapper for bus-off (`agent_sc3.md` §25.5 #18) — ask the user how to inject it.

## Coverage report

| Requirement group | Covered by | Not covered |
|---|---|---|
| General 31234510–31234514, 32088512 | TC-01, 02, 04, 13 | 31234511/31234512/31234513 are generic (covered implicitly) |
| BS transitions | TC-01, 02, 04 | — |
| RM transitions and timers | TC-01, 05, 06, 09 | RM re-entry by ignition from RS (Q-10) |
| NO transitions | TC-04, 05, 09 | 31789836 (implicit) |
| RS transitions | TC-02, 03, 10 | 31234532 / 31813093 (RS + ignition → RM vs NO) — not black-box observable (NM-DEV-06) |
| PBS transitions and timers | TC-03, 06, 11, 12 | — |
| Communication gating 31234541–31234547 | TC-01, 03, 04, 11 | NM RX gating (not observable) |
| 32088533 robustness | TC-07 | — |
| 32361859 (bus load 80 % + CAN wake-up, text truncated) | — | needs full text (Q-15) and a bus-load generator |
| Constraints 31234550 | TC-08 | — |

Existing NM scripts: `projects/W610/modules/CANNM/scripts/CANNM_Testcase12_ActiveWakeup_FaultDiagnostics.py`
and `CANNM_Testcase15_NM_StateTransitions.py`. Both need the F-02/F-04 review before their verdicts can be
trusted.
