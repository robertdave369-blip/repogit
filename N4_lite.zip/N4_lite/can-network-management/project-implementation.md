# Project implementation inventory

What exists in this repository for CAN NM, per project, as found on 2026-10-26. "Implementation" here is
the **test side** (bench functions, configs, scripts); the ECU's NM software is not in the repository.

## 1. Applicability per project

| Project | Type | NM PDUs in DBC | DBC | CAN wake-up path used by the bench | NM-related config |
|---|---|---|---|---|---|
| M310_M314_M110 | EV | `SRS_CANNM` 0x36D TX, `VCU_CANNM` 0x38F RX, `FR_ZONE2_100` 0x319 RX | `project_dbc/m314_dbc/SRS_FD_SVNID_41243.dbc` | `CAN_Wakeup()`: ignition OFF + `VCU_CANNM.ACTIVE_WAKEUP_BIT = 1` on CANFD | `canc_config.py` `CAN_WAKEUP_*`, `CAN_NM_*`, `NM_*`; `cannm_config.py` (placeholder, F-01) |
| M210 | EV | same frames and layout | `project_dbc/m210_dbc/SRS_FD_40250_22042026.dbc` | same | same; `cannm_config.py` copied from M310 (placeholder) |
| W610 | EV | not verifiable: `project_config.py` points to `C:\CAN_DB\W610\W610.dbc` (outside the repo) | — | `canc_config.py` carries M310 values | `cannm_config.py` with OEM-VC timings + `NM_STATE_EXPECTATIONS`; two CANNM scripts |
| UPP_EV | EV | not verifiable (`C:\CAN_DB\UPP_EV\UPP_EV.dbc`) | — | `canc_config.py` carries M310 values; legacy `CAN_Wakep_UPP()` (VCU_WAKEUP / VCU_ACTIVE) | `cannm_config.py` placeholder |
| U171 | ICE | none (only Vector NM attribute definitions, no NM frame) | `project_dbc/u171_dbc/U171_SRS_SVNID39216_20250917.dbc` | `wake_ecu_over_can()`: restbus restart with ignition OFF; status `SRS1_20.IGN_STS_SRS = 2` | `canc_config.py` NM qualification block; only `cannm_config.bak.py` |
| Z121 | ICE | none; `MBFM_WAKEUP` (0x97) present but deliberately unconfigured | `project_dbc/z121_dbc/Z121_SRS_39588_06012026.dbc` | user decision 2026-10-22: Z121 does **not** support CAN wake-up (F-10) | `canc_config.py` NM qualification block; `cannm_config.py` placeholder |
| W616 | ICE | DBC not checked (memory: same structure as U171) | — | — | `cannm_config.py` placeholder |

The OEM NM requirement workbook lives under `project_reuirements/m310_m314_m110/` and its releases name
"SC32S" and "W610 BEV" programmes. Treat it as applying to the EV projects above; its applicability to ICE is
undocumented (Q-07).

## 2. NM PDU layout (DBC, identical in 41243 and 40250)

| Frame | ID | DLC | Cycle | Byte | Bits | Signal | Encoding |
|---|---|---|---|---|---|---|---|
| `SRS_CANNM` (sender `SRS_FD`) | 0x36D | 8 (CAN FD frame) | 100 ms | 0 | 0–7 | `SOURCE_NODE_ID` | raw; value sent by the ECU unknown (Q-06) |
| | | | | 1 | 0 | `REPEAT_MESSAGE_REQUEST` | 1 = Repeat Msg State requested |
| | | | | 1 | 4 | `ACTIVE_WAKEUP_BIT` | 1 = Active, 0 = Passive |
| | | | | 2 | 0–7 | `SRS_WAKEUP_REASON` | no value table in the DBC (Q-06) |
| `VCU_CANNM` (received by `SRS_FD`) | 0x38F | 8 (CAN FD frame) | 100 ms | 0 | 0–7 | `SOURCE_NODE_ID` | raw |
| | | | | 1 | 0 | `REPEAT_MESSAGE_REQUEST` | as above |
| | | | | 1 | 4 | `ACTIVE_WAKEUP_BIT` | as above |
| | | | | 2 | 0–7 | `VCU_WAKEUP_REASON` | 0 Default … 5 T15 ON … 20 V2V_Active (21 values in the DBC) |
| `FR_ZONE2_100` | 0x319 | 64 (CAN FD) | 100 ms | 2 | 0–2 | `PKE_CLMP_STATE` | 0 OFF, 1 ACC, 2 ON, 3 CRANK, 4 RUN, 5–7 reserved; frame also carries E2E CRC/counter and SecOC freshness/MAC |

DBC attributes: `NmMessage = 1` on 0x36D and 0x38F; node defaults `NmAsrNode = Yes`,
`NmAsrCanMsgReducedTime = 50`, `NmAsrCanMsgCycleOffset = 0`. The layout matches the AUTOSAR CBV
definition (NM-DEV-10). Decoding example `[illustrative]`: payload `00 10 05 …` = node 0, RMR 0, AWB 1,
wake reason 5.

Note: `FR_ZONE2_100` is SecOC-protected (`FZ2_TRUNCATED_FRESHNESS_VALUE`, `FZ2_TRUNCATED_MAC`) and E2E
protected. A bench stimulus that changes `PKE_CLMP_STATE` must keep CRC/counter/MAC valid, or the ECU will
reject the frame for reasons unrelated to NM (see `agent_sc3.md` §28 and `troubleshooting.md` T-06).

## 3. Test-side code and config

| Item | Location | What it does | Status |
|---|---|---|---|
| `CAN_Wakeup(project, via_nm)` | `shared_libraries/core_functions.py` | Ignition OFF, restbus off for `CAN_WAKEUP_BUS_SLEEP_WAIT_MS`, restbus on, set wake request (`CAN_WAKEUP_REQUEST_*`), wait `NM_IGN_ON_STARTUP_DELAY_MS`, optional `SRS_CANNM` check, check `IGN_STS_SRS = 2` | Used by EDR CAN-C scripts; see F-03, F-04 |
| `CAN_Wakeup_Restore(project)` | same | Restbus on, wake request released (`CAN_WAKEUP_RELEASE_VALUE`), then ignition ON | Correct ordering per user rule 2026-10-22 |
| `wake_ecu_over_can`, `wake_ecu_over_can_nm`, `restore_can_nm_wakeup` | same | Legacy flows kept as at HEAD | `wake_ecu_over_can_nm` has the same check as F-03 |
| `CAN_Wakep_UPP`, `CAN_Wakeup_Disable_UPP`, `CAN_Wakeup_Cycle_UPP` | same | UPP flow with `VCU_WAKEUP` / `VCU_ACTIVE` frames | Frames not in the repo DBCs |
| `CAN.ReceiveFrame`, `CAN.GetSignalFromFrame`, `CAN.PeriodicChangeSignal`, `CAN.PeriodicDisableFrame`, `CAN.PeriodicDisableAllFrames`, `CAN.StartLoggingToFile`, `CAN.ReadFromCanLogFile` | `shared_libraries/jscript_translation.py` | Bench CAN primitives | F-04 |
| `PS.GetCurrentVBAT`, `PS.GetCurrentIGN` | same | Measured supply current | Usable for sleep evidence; resolution and limit unknown (Q-08) |
| `CANNM_Testcase12_ActiveWakeup_FaultDiagnostics.py`, `CANNM_Testcase15_NM_StateTransitions.py` | `projects/W610/modules/CANNM/scripts/` | W610 NM tests | F-02, F-04 |
| NM qualification block (`NODE_ABSENT_*`, `NM_*`, `CAN_WAKEUP_*` from DID 0x0103/0x0104) | `projects/U171/config/canc_config.py`, `projects/Z121/config/canc_config.py` (and hand-kept equivalents in the EV configs) | Network-diagnostics thresholds and delays | F-05 |
| EDR CAN-wake-up scripts and templates | `tools/edr_canc_templates/`, `projects/*/modules/EDR*/` | EDR recording under CAN wake-up | Consumers of `CAN_Wakeup()` |

No ECU-side NM artefact (source, ARXML, generated configuration, A2L, NM state DID) exists in the repository.

## 4. OEM NM requirement inventory

Generated from the workbook on 2026-10-26 (64 non-heading rows; descriptions condensed, list items joined with
`;`). "Impl." is the export's `_Implemented` flag. Text marked "." or ending abruptly was truncated in the
export (Q-15).

| ID | Section | Status | Impl. | Release | Requirement (OEM wording; list items joined with `;`) |
|---|---|---|---|---|---|
| 31234510 | 4.1.1 General | Approved | yes | Mahinda SC32S P31 Release | If Ignition_Signal is ON, the NM_Module shall request Network. |
| 31234511 | 4.1.1 General | Approved | yes | Mahinda SC32S P31 Release | If Network requested, the NM_Module shall start transmitting and receiving application specific Messages as per CAN_C. |
| 31234512 | 4.1.1 General | Approved | yes | Mahinda SC32S P31 Release | CANNM_PDU message is received!, the NM_Module shall release the network connection. |
| 31234513 | 4.1.1 General | Approved | yes | W610 BEV P47 Release | If Network is released, the NM_Module shall disable communication based on operating NM_States. |
| 31234514 | 4.1.1 General | Approved | yes | W610 BEV P39 Release | The NM_Module shall keep the Network_Awake, If Ignition_Signal is ON or based on below Signal status: ACTIVE_WAKEUP_BIT in CANNM_PDU; PKE_CLMP_State in PKE_CLMP_Signal |
| 32088512 | 4.1.1 General | Approved | yes | W610 BEV P47 Release | If ECU awake by valid wakeup signals, the software shall perform below functions as per respective requirements defined.; Determine Deployment; Process Diagnostics; Faults Management; GPO Management |
| 31234520 | 4.1.2 Operating Modes | Approved | yes | W610 BEV P39 Release | The NM_Module shall operates on below NM_STATES: NM_STATE_BUS_SLEEP; NM_STATE_PREPARE_BUS_SLEEP; NM_STATE_REPEAT_MESSAGE; NM_STATE_READY_SLEEP; NM_STATE_NORMAL_OPERATION |
| 31234521 | NM_STATE_BUS_SLEEP | Approved | yes | Mahinda SC32S P31 Release | After CAN initialization, NM_Module shall enters NM_STATE_BUS_SLEEP. |
| 31234522 | NM_STATE_BUS_SLEEP | Approved | yes | Mahinda SC32S P41 Release | If NM_State NM_STATE_BUS_SLEEP and Network requested, the NM_Module shall enter to NM_STATE_REPEAT_MESSAGE. |
| 31790371 | NM_STATE_BUS_SLEEP | Approved | yes | W610 BEV P39 Release | If Network released in NM_State NM_STATE_BUS_SLEEP and any of below conditions are met, the NM_Module shall enter to NM_STATE_REPEAT_MESSAGE.; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set; PKE_CLMP_State is 0x2/3/4 |
| 31790372 | NM_STATE_BUS_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P46 Release | If Network released in NM_State NM_STATE_BUS_SLEEP and any of below conditions are met, the NM_Module shall continue in NM_STATE_BUS_SLEEP.; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is not 0x2/3/4 |
| 31234523 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | Upon transition to NM_STATE_REPEAT_MESSAGE, the NM_Module shall starts CANNM_Timeout_Timer and CANNM_RepeatMsgTimer. |
| 32078450 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | If Network requested and CANNM_RepeatMsgTimer Expired in NM_STATE_REPEAT_MESSAGE, the NM_Module shall enter to NM_STATE_NORMAL_OPERATION. |
| 31234525 | NM_STATE_REPEAT_MESSAGE | Approved | yes | Mahinda SC32S P41 Release | If all of the below conditions are met and CANNM_RepeatMsgTimer Expired in NM_STATE_REPEAT_MESSAGE, the NM_Module shall enter to NM_STATE_NORMAL_OPERATION.; Ignition_Signal not available; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT Clear; PKE_CLMP_State 0x2/3/4; CANNM_FrZone2_Timer not Expired |
| 31789295 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | If NM_State NM_STATE_REPEAT_MESSAGE and all of the below conditions met, the NM_Module shall continues in NM_STATE_REPEAT_MESSAGE: Ignition_Signal not available; CANNM_PDU recieves with Active_wakeup_Bit set; CANNM_PDU recieves with CANNM_RepeatMsgBit set |
| 31234524 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | If all of the below conditions met in NM_STATE_REPEAT_MESSAGE, the NM_Module reset CANNM_RepeatMsgTimer .; Ignition_Signal not available; CANNM_PDU recieves with Active_wakeup_Bit set; CANNM_PDU recieves with CANNM_RepeatMsgBit set; CANNM_RepeatMsgTimer Expired |
| 31234527 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | If all of the below conditions are met and CANNM_RepeatMsgTimer Expired in NM_STATE_REPEAT_MESSAGE, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Ignition_Signal not available; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is not 0x2/3/4 |
| 31789301 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | If CANNM_RepeatMsgTimer Expired and all of the below conditions are met in NM_STATE_REPEAT_MESSAGE, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Ignition_Signal not available; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is 0x2/3/4; CANNM_FrZone2_Timer Expired |
| 31789302 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | ACTIVE_WAKEUP_BIT !set; CANNM_PDU recieves with CANNM_RepeatMsgBit Clear |
| 33031944 | NM_STATE_REPEAT_MESSAGE | Approved | no | W610 BEV P68 Release | If NM_Module is switched from NM_STATE_PREPARE_BUS_SLEEP to NM_STATE_REPEAT_MESSAGE, the software shall enable diagnosis of below faults: Receiving message content failure faults; Receiving signal content failure faults |
| 31234539 | NM_STATE_REPEAT_MESSAGE | Approved | yes | W610 BEV P39 Release | The NM_Module shall set CANNM_RepeatMsgTimer expired if CANNM_RepeatMsgTimer exceeds P_NmAsrRepeatMessageTime . |
| 31789836 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P39 Release | If Ignition_Signal available in NM_STATE_NORMAL_OPERATION, the NM_Module shall continues in NM_STATE_NORMAL_OPERATION. |
| 31789834 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If Network released and all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall continue in NM_STATE_NORMAL_OPERATION.; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is 0x2/3/4; CANNM_FrZone2_Timer not expired |
| 31234526 | NM_STATE_NORMAL_OPERATION | Obsolete | no | - | If any of the below conditions met in NM_STATE_NORMAL_OPERATION, the NM_Module reset CANNM_Timeout_Timer.; Sucessful reception of FrZone2 with PKE_CLMP_STATE as 0x2/3/4; CANNM_FrZone2_Timer expired |
| 31234528 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P39 Release | If all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is not 0x2/3/4 |
| 31789831 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is 0x2/3/4; CANNM_FrZone2_Timer expired |
| 32056077 | NM_STATE_NORMAL_OPERATION | Obsolete | no | - | If all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Network Released; PKE_CLMP_State is 0x2/3/4; CANNM_FrZone2_Timer expired |
| 32056081 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P39 Release | If all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Network Released; PKE_CLMP_State is not 0x2/3/4 |
| 32056095 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P47 Release,W610 BEV P39 Release | If all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall enter to NM_STATE_READY_SLEEP.; Network Released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set; CANNM_PDU recieves with CANNM_RepeatMsgBit Clear |
| 32056097 | NM_STATE_NORMAL_OPERATION | Approved | yes | W610 BEV P39 Release | If all of the below conditions are met in NM_STATE_NORMAL_OPERATION, the NM_Module shall enter to NM_STATE_REPEAT_MESSAGE.; Network Released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT Set; CANNM_PDU recieves with CANNM_RepeatMsgBit Set |
| 31234532 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P39 Release | If Network requested in NM_STATE_READY_SLEEP, the NM_Module shall enter to NM_STATE_REPEAT_MESSAGE. |
| 31234531 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions met in NM_STATE_READY_SLEEP, the NM_Module reset CANNM_Timeout_Timer.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set; ACTIVE_WAKEUP_Reception Flag is set; CANNM_PDU recieves CANNM_RepeatMsgBit is clear; CANNM_Timeout_Timer expired |
| 31813093 | NM_STATE_READY_SLEEP | Approved | no | W610 BEV P47 Release,W610 BEV P42 Release | If Network requested or all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall enter to NM_STATE_REPEAT_MESSAGE.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is 0x2/3/4; CANNM_FrZone2_Timer not Expired |
| 31234533 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall enter to NM_STATE_PREPARE_BUS_SLEEP.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is not 0x2/3/4; CANNM_Timeout_Timer expired |
| 31790290 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall enter to NM_STATE_PREPARE_BUS_SLEEP.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is 0x2/3/4; CANNM_FrZone2_Timer expired; CANNM_Timeout_Timer expired |
| 31790328 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P47 Release,W610 BEV P39 Release | If all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall enter to NM_STATE_REPEAT_MESSAGE.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set; ACTIVE_WAKEUP_Reception Flag is clear |
| 31234529 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall enters to NM_STATE_REPEAT_MESSAGE: Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set; ACTIVE_WAKEUP_Reception Flag is set; CANNM_PDU recieves CANNM_RepeatMsgBit is set |
| 31790339 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall continue in NM_STATE_READY_SLEEP.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set; ACTIVE_WAKEUP_Reception Flag is set; CANNM_PDU recieves CANNM_RepeatMsgBit is clear |
| 31848567 | NM_STATE_READY_SLEEP | Approved | yes | W610 BEV P47 Release,W610 BEV P39 Release | If all of the below conditions are met in NM_STATE_READY_SLEEP, the NM_Module shall continue in NM_STATE_READY_SLEEP.; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear; PKE_CLMP_State is 0x2/3/4 and CANNM_FrZone2_Timer expired; CANNM_Timeout_Timer not expired |
| 33031889 | NM_STATE_PREPARE_BUS_SLEEP | Approved | no | W610 BEV P68 Release | If NM_Module is in NM_STATE_PREPARE_BUS_SLEEP, the software shall disable diagnosis of below faults: Receiving message content failure faults; Receiving signal content failure faults |
| 33031904 | NM_STATE_PREPARE_BUS_SLEEP | Approved | no | W610 BEV P68 Release | If NM_Module is in NM_STATE_PREPARE_BUS_SLEEP, the software shall reset all error counters of below faults: Receiving message content failure faults; Receiving signal content failure faults |
| 31234535 | NM_STATE_PREPARE_BUS_SLEEP | Approved | yes | W610 BEV P39 Release | If CANNM_BusSleepTimer expired in NM_STATE_PREPARE_BUS_SLEEP, the NM_Module shall switch to NM_STATE_BUS_SLEEP. |
| 32364537 | NM_STATE_PREPARE_BUS_SLEEP | Approved | no | - | IGN_STS_SRS Signal status to IGN_OFF with a delay P_IGN_STS_AWB_Clear_Delay. |
| 31790350 | NM_STATE_PREPARE_BUS_SLEEP | Approved | yes | W610 BEV P47 Release,W610 BEV P39 Release | If CANNM_BusSleepTimer not expired and Network requested in NM_STATE_PREPARE_BUS_SLEEP, the NM_Module shall switch to NM_STATE_REPEAT_MESSAGE. |
| 31234534 | NM_STATE_PREPARE_BUS_SLEEP | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | If all of the below conditions met in NM_STATE_PREPARE_BUS_SLEEP, the NM_Module shall switch to NM_STATE_REPEAT_MESSAGE.; CANNM_BusSleepTimer not expired; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT set or PKE_CLMP_State is 0x2/3/4 |
| 32056145 | NM_STATE_PREPARE_BUS_SLEEP | Approved | yes | Mahinda SC32S P41 Release | .!; CANNM_BusSleepTimer not expired; Network released; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT clear and PKE_CLMP_State is not 0x2/3/4 |
| 31234536 | NM_STATE_PREPARE_BUS_SLEEP | Approved | yes | W610 BEV P39 Release | If NM_STATE switch from NM_STATE_PREPARE_BUS_SLEEP to NM_STATE_REPEAT_MESSAGE, the NM_Module shall reset CANNM_BusSleepTimer. |
| 31234538 | 4.1.2 Operating Modes | Approved | yes | W610 BEV P39 Release | The NM_Module shall set CANNM_BusSleepTimer expired if CANNM_BusSleepTimer exceeds P_NmAsrWaitBusSleepTime. |
| 31234537 | 4.1.2 Operating Modes | Approved | yes | W610 BEV P39 Release | The NM_Module shall set CANNM_Timeout_Timer expired if CANNM_Timeout_Timer exceeds P_NmAsrTimeoutTime. |
| 31813099 | 4.1.2 Operating Modes | Approved | yes | W610 BEV P39 Release | . |
| 32088533 | 4.1.2 Operating Modes | Approved | yes | W610 BEV P39 Release,W610 BEV P47 Release | All of the below errors shall not affect any of the NM_STATES transition.; Variant code error; ECU Node absent; Invalid CAN Message Length; Message Content Failures; Signal Invalid Failures |
| 32361859 | 4.1.3 Communication handling in NM | Approved | no | - | If ECU awake by valid wakeup signals |
| 31234541 | 4.1.3 Communication handling in NM | Approved | yes | W610 BEV P39 Release | The NM_Module shall disable all of the below communications in NM_STATE_BUS_SLEEP.; CANNM Transmiting Messages; CANNM Receiving Messages; Application Transmitting Messages; Application Receiving Messages |
| 31234542 | 4.1.3 Communication handling in NM | Approved | yes | W610 BEV P39 Release | The NM_Module shall enable all of the below communications in NM_STATE_REPEAT_MESSAGE.; CANNM Receiving Messages; Application Transmitting Messages; Application Receiving Messages |
| 32088432 | 4.1.3 Communication handling in NM | Approved | yes | Mahinda SC32S P41 Release | If Network_Awake by all of the below conditions in NM_STATE_REPEAT_MESSAGE, the NM_Module shall enable CANNM Transmiting Messages.; CANNM_PDU recieves with ACTIVE_WAKEUP_BIT or PKE_CLMP_State is 0x2/3/4; Network released |
| 32088462 | 4.1.3 Communication handling in NM | Approved | yes | W610 BEV P47 Release,Mahinda SC32S P41 Release | If NM_Module entered to NM_STATE_REPEAT_MESSAGE by Network requested and if below conditions are met, The NM_Module shall disable CANNM Transmiting Messages.; ECU Wakeup for first time. |
| 31234543 | 4.1.3 Communication handling in NM | Approved | yes | W610 BEV P39 Release | The NM_Module shall enable all of the below communications in NM_STATE_NORMAL_OPERATION.; CANNM Receiving Messages; Application Transmitting Messages with delay of 350ms; Application Receiving Messages |
| 31234544 | 4.1.3 Communication handling in NM | Approved | yes | W610 BEV P39 Release | The NM_Module shall disable CANNM Transmiting Messages in NM_STATE_READY_SLEEP and NM_STATE_NORMAL_OPERATION. |
| 31234545 | 4.1.3 Communication handling in NM | Approved | no | - | The NM_Module shall enable all of the below communications in NM_STATE_READY_SLEEP.; CANNM Receiving Messages; Application Transmitting Messages; Application Receiving Messages |
| 31234546 | 4.1.3 Communication handling in NM | Approved | no | W610 BEV P68 Release | The NM_Module shall disable all of the below communications in NM_STATE_PREPARE_BUS_SLEEP.; CANNM Transmiting Messages; Application Transmitting Messages; Application Receiving Messages |
| 31234547 | 4.1.3 Communication handling in NM | Approved | no | W610 BEV P68 Release | The NM_Module shall enable all of the below communications in NM_STATE_PREPARE_BUS_SLEEP.; CANNM Receiving Messages |
| 31234549 | 5 Constraints | Obsolete | no | - | The NM_Module shall receive maximum range of NmAsrMessageCount CANNM_PDU Message. |
| 31234550 | 5 Constraints | Approved | yes | W610 BEV P39 Release | The NM_Module shall send CANNM_PDU Message with periodicity P_NmAsrCanMsgCycleTime.; There will be no Guarente to Ensure SRSCANNM is out for 4 to 5 times. |
| 31234551 | 5 Constraints | Obsolete | no | - | The NM_Module shall recognize that all other nodes are ready to sleep within P_NmAsrCanRemoteSleepIndTime . |

Related CAN-C requirements (same project folder): CAN init timing 31117229–31117240 (no transmission before
T_CANInit, minimum 150 ms `[OEM 31117240]`), bus-off 31123365–31123372, missing ACK 31137860–31137864, node
monitoring 31124066–31124157, TX period tolerance 31137824/31137826, T15 communication window
31137830/31137832.

## 5. Findings

| ID | Finding | Evidence | Impact | Recommended action (not applied) |
|---|---|---|---|---|
| F-01 | `cannm_config.py` holds template values in M210, M310_M314_M110, UPP_EV, W616, Z121: `NM_BASE_ID = 0x500`, Repeat 1.5 s, Wait-Bus-Sleep 5.0 s, Timeout 6.0 s; key spelled `NM_WAIT_BUS_Sleep_TIME` in M210/M310/Z121 vs `NM_WAIT_BUS_SLEEP_TIME` elsewhere | the six `projects/*/config/cannm_config.py` files | Any script using them would test wrong timings and a non-existent ID (DBC: 0x36D/0x38F) | Replace with DID 0x0110 / OEM-VC values once Q-01..Q-03 are answered; unify the key name |
| F-02 | W610 `NM_STATE_EXPECTATIONS` expects `SRS_CANNM` in NORMAL_OPERATION; Testcase15 checks "Normal Operation SRS CAN NM" after ignition ON; `network_rx_present` checks `FR_ZONE2_100`, a frame the **bench itself** sends | `projects/W610/config/cannm_config.py`, `CANNM_Testcase15_NM_StateTransitions.py` | Contradicts OEM 31234544 / 32088462; rx checks observe the restbus, not the ECU | Set NO/first-wake RM NM TX to absent; drop or redefine the rx checks; time-bound all presence checks |
| F-03 | `CAN_Wakeup(via_nm=True)` and `wake_ecu_over_can_nm()` look for `SRS_CANNM` after `NM_IGN_ON_STARTUP_DELAY_MS` (2000 ms) with AWB = 1, RMR = 0, ignition OFF. Per OEM the ECU leaves Repeat Message after the Repeat Message Time (OEM-VC 400 ms) and stops `SRS_CANNM` | `core_functions.py`; OEM 31789302 (VC), 31234544 | The check can only pass from a stale frame (F-04); it does not prove "network mode" | Check `SRS_CANNM` in a log window starting at the wake request; or remove the check |
| F-04 | `CAN.ReceiveFrame` = `Api.Simulation.Frame.get_last_visible` = "receive most recent frame" (returns timestamp + payload); callers ignore the timestamp; on error it returns an exception **string**, which `is not None` counts as "received" | `jscript_translation.py` `ReceiveFrame`; `docs/aria_documents/Aria Python/APYM_CALL_REFERENCE.md` | Presence/absence checks per state are unreliable in both directions | Judge presence from a CAN log window or by comparing the frame timestamp with the bench clock (wrapper change needs user approval) |
| F-05 | The generated NM qualification blocks name `tools/nm_qualification.py` as their generator; the file does not exist and has no git history | `projects/U171/config/canc_config.py`, `projects/Z121/config/canc_config.py` | Blocks cannot be regenerated; "do not edit by hand" cannot be honoured | Ask the user whether the generator should be restored or the header changed |
| F-06 | `agent_sc3.md` §2.3 says "NM TX enabled only for active wakeup (passive wakeup on first ECU wake keeps NM TX off)". OEM: NM TX on in RM when woken by AWB **or PKE** with ignition OFF (32088432); off when RM was entered by the **ignition** request on first wake-up (32088462) | `.github/agents/agent_sc3.md` §2.3 | Readers may expect no `SRS_CANNM` after a PKE wake-up and mis-assign "passive" | Propose a §2.3 wording fix to the user (§29 maintenance) |
| F-07 | EV DID 0x0110 `NmAsrTimeoutTime` = 500 ms; OEM-VC and ICE = 1000 ms | `state-machine-and-timers.md` §3 | NM-DEV-13 | Q-01 |
| F-08 | DID 0x0110 defaults `NmAsrBaseAddress = 0x400`, `NmAsrMessage = No`, `NmAsrNodeIdentifier = 0` do not describe the DBC frame (0x36D, `NmMessage = 1`) | DIAG_RE `NetworkMgmtIdentifiers`; DBC | DID defaults are not a reliable source for ID/node values | Use the DBC for IDs; Q-06 for the node ID |
| F-09 | No bench log in the repository contains 0x36D or 0x38F | search of `test_logs/` and `test_results/`, 2026-10-26 | Every "project behaviour" in the deviation matrix is requirement-only | First bench run: NM-TC-01..04 with CAN logging |
| F-10 | Z121: user decision (2026-10-22) "no CAN wake-up", but `canc_config.py` keeps `CAN_WAKEUP_FEATURE_ENABLE = 1` (DID default) and `CAN_WAKEUP_STATUS_*` for `wake_ecu_over_can()` | `projects/Z121/config/canc_config.py` | Ambiguous intent for future scripts | Ask the user; do not add Z121 CAN wake-up tests meanwhile |

## 6. Open questions

| ID | Question | Where the answer would be |
|---|---|---|
| Q-01 | EV NM-Timeout: 500 ms (DID V2.7/V3.4) or 1000 ms (OEM-VC)? | Mahindra IVN CANNM spec; ECU calibration; bench NM-TC-03 |
| Q-02 | `NmAsrRepeatMessageTime` "N*400": what is N? | IVN CANNM spec |
| Q-03 | `P_CanNmMsgTimeoutTime` (FrZone2 timer): 100 or 300 ms? | IVN CANNM spec / DataDictionary |
| Q-04 | Value of `P_IGN_STS_AWB_Clear_Delay` | DataDictionary |
| Q-05 | Definition of "ACTIVE_WAKEUP_Reception Flag" | DataDictionary module (not exported) |
| Q-06 | `SRS_CANNM` content: node ID, RMR/AWB values sent, `SRS_WAKEUP_REASON` encoding | IVN CANNM spec; bench trace |
| Q-07 | Do the ICE ECUs run CanNm (ICE DIAG_RE lists DID 0x0110) although the ICE DBCs have no NM PDU? | OEM / supplier |
| Q-08 | CAN transceiver part, wake-up method (bus wake-up pattern vs selective wake), sleep-current limit | Hardware design, transceiver datasheet, ECU current spec |
| Q-09 | ECU AUTOSAR release, BSW vendor, any NM-state readout (DID, XCP) | Supplier software documentation |
| Q-10 | NM TX in Repeat Message when re-entered by ignition from RS/PBS (not first wake-up) | IVN CANNM spec |
| Q-11 | Do application frames stop in PBS (31234546, impl. no) on current software, and how is the `IGN_STS_SRS` clear (32364537) observable if they do? | Supplier; bench |
| Q-12 | Behaviour behind DID 0x0104 (`CAN Wakeup Msg Count` 10, quick/slow wake-up recovery) | No behavioural requirement found |
| Q-13 | "Mahindra_IVN_CANNM_Specification" (reference document of the NM workbook) | Not in the repository |
| Q-14 | TX period tolerance at exactly 100 ms (CAN-C covers < 100 and > 100 ms) | CAN-C spec owner |
| Q-15 | Full text of 31789302, 32056145, 32361859, 31813099 (truncated in the export) | Codebeamer |
