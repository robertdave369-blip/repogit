# Black-box testing of CAN NM on this bench

## 1. What "black-box" means here

The tester controls only external inputs (supply, hardwired ignition, the simulated restbus incl.
`VCU_CANNM` and `FR_ZONE2_100`) and observes only outputs (frames the ECU sends, their timing and content,
UDS answers, supply current). The internal NM state is never observed directly; it is **inferred** from
observables, and every inference must name its ambiguity (`state-machine-and-timers.md` §5).

| Level | Sees | Used for | Available here |
|---|---|---|---|
| Black-box | Bus, current, UDS | Requirement verification on the bench | Yes (ARIA HIL) |
| Gray-box | + debug DID / XCP / internal error codes | State confirmation, timer values | No NM-state DID known (Q-09) |
| White-box | Source, unit tests | Module verification | Not in this repository |

## 2. Bench capabilities (ARIA 5.20 via shared libraries)

| Need | Wrapper (`shared_libraries/`) | What it measures / does | Limitation |
|---|---|---|---|
| Ignition / battery | `PS.IGN_ON()`, `PS.IGN_OFF()`, `PS.Power_ON("BATT")`, `PS.Power_OFF()` | Hardwired network request | — |
| Drive NM inputs | `CAN.PeriodicChangeSignal(channel, frame, signal, value)`, `CAN.PeriodicEnableFrame` / `PeriodicDisableFrame`, `PeriodicEnableAllFrames` / `PeriodicDisableAllFrames`, `CAN.ReloadDefaultPeriodicFrame` | `VCU_CANNM` AWB/RMR, `FR_ZONE2_100` PKE, restbus on/off | E2E/SecOC of `FR_ZONE2_100` must stay valid (`project-implementation.md` §2) |
| Observe frames | `CAN.StartLoggingToFile` / `StopLogging` / `ReadFromCanLogFile` | Time-stamped trace — **the** evidence for presence, period and timing | File-based; analyse after the run |
| Last frame | `CAN.ReceiveFrame` | Most recent frame ever seen (+ timestamp) | **Not** a presence check (F-04) |
| Signal value | `CAN.GetSignalFromFrame` | Raw value of the last received frame | Same staleness caveat |
| Supply current | `PS.GetCurrentVBAT()`, `PS.GetCurrentIGN()` | Sleep vs awake evidence | Resolution and the ECU's limit unknown (Q-08) |
| CAN wake-up flows | `CAN_Wakeup()`, `CAN_Wakeup_Restore()` (`core_functions.py`) | Standard CAN wake-up used by EDR scripts | F-03 |
| DTCs / UDS | `Read_DTC`, `CAN.SendDiagByValues` | Functions active under CAN wake-up `[OEM 32088512]` | Diagnostic traffic itself is bus activity |
| Bus-off, physical faults | none | — | `agent_sc3.md` §25.5 #18: ask the user |
| Oscilloscope / differential probe | outside the framework (`agent_sc3.md` §26) | Physical layer, transceiver wake pattern | Manual |

A CAN trace with no frames is **not** evidence of low power: add the supply current (and, for physical
questions, a scope) before claiming Bus-Sleep.

## 3. Measuring timing correctly

1. Log the whole scenario to file; take every timestamp from the log, not from the script clock.
2. Define each timing as a pair of **bus events**, e.g. "last `VCU_CANNM` with AWB = 1" → "last `SRS1_FD_10`".
3. Expected value = OEM source value; tolerance = message cycle (100 ms granularity of the stimulus) + one
   NM main-function period (10 ms, DID 0x0110) + period tolerance (±3 %, Q-14). State the source of every term.
4. Where the source is in conflict (NM-DEV-13..15), the test **measures and reports** and the verdict names
   which source the measurement agrees with.
5. Waits in scripts come from config/OEM values and are longer than the expected edge plus tolerance; the
   verdict comes from the log, not from the wait.

## 4. Observables per scenario (summary)

| Question | Decisive observable |
|---|---|
| Did the ECU wake on CAN? | First airbag application frame after the stimulus; `IGN_STS_SRS = 2`; `SRS_CANNM` burst |
| Is it in Repeat Message after a CAN wake-up? | `SRS_CANNM` every 100 ms; burst length ≈ Repeat Message Time |
| Has it left Repeat Message? | `SRS_CANNM` stops while application frames continue |
| Did it enter Prepare Bus-Sleep? | Application frames stop (if 31234546 is implemented) |
| Did it reach Bus-Sleep? | Silence > Wait-Bus-Sleep **and** supply current at sleep level |
| Did an input keep it awake? | Application frames continue past the NM-Timeout after the last AWB/PKE |

## 5. Test design rules

- Requirement-based and priority-first (`agent_sc3.md` §16.10): every case traces to OEM requirement IDs
  and, where relevant, an NM-DEV row; no padding.
- Positive, negative (AWB = 0, PKE = 1 or 5–7, missing frames), boundary (stimulus removed just before and
  just after a timer edge), robustness (CAN-C faults during NM, NM-TC-07) and multi-node (VCU + PKE inputs
  combined).
- Equivalence classes for `PKE_CLMP_STATE`: {0, 1} no wake; {2, 3, 4} wake; {5, 6, 7} reserved → expected
  no wake `[inference: OEM lists only 2/3/4]`.
- Clean-up: AWB back to 0 **before** ignition ON (user rule 2026-10-22), restbus restored, in `finally`.
- Safety (`agent_sc3.md` §23): writing a test is not running it. Bench runs only on explicit request.

## 6. Coverage mapping (areas from the original brief)

| Area | Cases | Gaps |
|---|---|---|
| A Startup | NM-TC-04 | Startup with the network already active (VCU AWB = 1 before ignition) not specified by the OEM |
| B Request/release | NM-TC-04, NM-TC-03, NM-TC-06 | Overlapping requests beyond ignition + AWB + PKE: none defined |
| C NM message behaviour | NM-TC-01, NM-TC-05, NM-TC-08 | Invalid NM PDU DLC/content: no OEM requirement |
| D Sleep | NM-TC-02, NM-TC-03, NM-TC-14 | Sleep-current limit unknown |
| E Wake-up | NM-TC-01, NM-TC-02, NM-TC-06, NM-TC-09, NM-TC-10 | Transceiver-level spurious wake (Q-08) |
| F Timers | NM-TC-01, NM-TC-03, NM-TC-09 | Conflicting values (Q-01..Q-03) |
| G Multi-node | NM-TC-05, NM-TC-09 | Other NM nodes than the VCU: none in the DBC |
| H Faults | NM-TC-07, NM-TC-15 | Bus-off injection has no wrapper |
| I Integration | NM-TC-11, NM-TC-12, NM-TC-13 | Internal module coordination is not observable |
