# Troubleshooting CAN NM symptoms

## 1. Method

1. **Get evidence first:** a time-stamped CAN log of the whole scenario (both FD and HS channels), the
   script report, supply voltage/current, the exact stimulus timeline. A single `CAN.ReceiveFrame` result is
   not evidence (F-04).
2. **Separate the layers** before blaming NM: physical bus → transceiver/supply → controller (error state) →
   bench restbus/simulation → test script/wrapper → ECU NM logic → ECU integration (gating, diagnostics).
3. For each hypothesis write the experiment that would confirm or kill it and its expected result; run the
   cheapest decisive one first (offline log analysis before any bench run; bench runs only on request,
   `agent_sc3.md` §23).
4. Confirm the root cause by reproducing the symptom *and* its absence after the fix; add the scenario to
   `test-case-catalogue.md`.
5. Report: symptom → evidence → root cause (or ranked hypotheses) → fix → verification.

## 2. Bench-specific traps (check these first)

| Trap | Looks like | Check |
|---|---|---|
| Stale frame from `ReceiveFrame` (F-04) | "ECU sends `SRS_CANNM` in Normal Operation", "frame present while asleep" | Timestamp of the frame vs now; the log |
| Error string treated as a frame (`is not None`) | Presence check passes although the call failed | Type of the returned value |
| Bench sends the frame you are checking | "NM RX present" (F-02) | Is the frame's sender the ECU (DBC sender `SRS_FD`)? |
| Restbus default content | ECU never sleeps because the default `VCU_CANNM` or `FR_ZONE2_100` content requests wake-up | Decode the restbus frames in the log |
| Wake request not released before ignition ON | Next test starts in an unexpected state | `CAN_Wakeup_Restore()` order |
| Invalid E2E/SecOC on `FR_ZONE2_100` | PKE keep-awake "does not work" | MAC/freshness/CRC in the log; related network-security DTCs |
| Placeholder timings (F-01) | Every sleep test fails by seconds | Source of the wait values |

## 3. Symptom playbook

| # | Symptom | Likely causes (ranked) | Evidence / next experiment | Expected result per hypothesis |
|---|---|---|---|---|
| T-01 | ECU never transmits `SRS_CANNM` | (1) Correct OEM behaviour: no NM TX after ignition wake-up, in NO or RS (NM-DEV-01/02); (2) the wake-up was not a CAN wake-up; (3) logger filter / wrong channel; (4) TX path dead (transceiver mode, bus-off) | Wake with AWB = 1 and ignition OFF (NM-TC-01); check log filter and channel; look for error frames | (1) burst appears only after the CAN wake-up; (4) no application frames either |
| T-02 | `SRS_CANNM` sent but the ECU still goes to sleep | Correct: NM TX is not a keep-awake; only ignition, AWB = 1 or PKE 2/3/4 hold the ECU (NM-DEV-03) | Decode `VCU_CANNM` AWB in the log at the time of sleep | AWB = 0 or `VCU_CANNM` stopped before the silence |
| T-03 | Network never enters Bus-Sleep | (1) Restbus keeps AWB = 1 or PKE 2/3/4; (2) ignition still sensed ON (wiring/IGN level); (3) diagnostic tester traffic / periodic requests; (4) ECU software not reaching PBS | Decode all inputs in the last seconds; measure IGN voltage; stop the tester | Inputs explain it, or the ECU is at fault (report, NM-TC-03) |
| T-04 | ECU sleeps too early | (1) AWB held but the reception flag/edge rules (Q-05) ended Ready Sleep; (2) `VCU_CANNM` gaps longer than NM-Timeout (bench jitter, bus load); (3) EV timeout is 500 ms, not 1000 (NM-DEV-13); (4) supply dip | Measure `VCU_CANNM` inter-frame gaps; compare silence onset with both timeout values | Gap > timeout explains it; onset at 500 ms → Q-01 |
| T-05 | Another node keeps the network awake | In this ECU only the defined inputs can (VCU AWB, PKE clamp, ignition); other NM PDUs do not (NM-DEV-03) | List frames with AWB = 1 / PKE 2/3/4 in the log | One of them is present |
| T-06 | ECU does not wake on CAN | (1) Stimulus had AWB = 0 or PKE not 2/3/4 — correct behaviour (NM-DEV-04); (2) `FR_ZONE2_100` rejected (E2E/SecOC); (3) wrong channel (`CAN_WAKEUP_REQUEST_CHANNEL`); (4) transceiver wake disabled/broken (Q-08); (5) ECU not actually in Bus Sleep but in a fault/unpowered state | Decode the stimulus; check channel; scope CANH/CANL for the wake pattern; check supply | Each cause yields a distinct log signature |
| T-07 | Wakes but normal communication does not start | (1) Only the NM burst, application TX blocked (PBS gating, `IGN_STS` rules); (2) the 350 ms application TX delay in NO (31234543) misread as failure; (3) network diagnostics still within the 2000 ms start-up delay; (4) supply outside the communication window (31137830) | Time from wake-up to first application frame; supply voltage | (2) ≈ 350 ms gap; (4) voltage out of window |
| T-08 | Inferred NM state disagrees with the trace | The bus cannot distinguish NO/RS or PBS/BS (`state-machine-and-timers.md` §5) | Re-derive the state from timing and `IGN_STS_SRS`, not from presence checks | — |
| T-09 | Unexpected NM ID or payload | (1) Decoding with assumed offsets instead of the DBC; (2) wrong project DBC (W610/UPP_EV DBCs outside the repo); (3) node ID/AWB values legitimately differ (Q-06) | Decode with `cantools` against the project DBC | Correct decoding resolves (1)/(2) |
| T-10 | Timing differs from configuration | (1) Config holds placeholders (F-01); (2) conflicting OEM sources (NM-DEV-13..15); (3) script clock used instead of log timestamps; (4) stimulus granularity (100 ms) and main-function jitter (10 ms) not in the tolerance | Recompute from the log with the tolerance model in `black-box-testing.md` §3 | — |
| T-11 | Communication fails after reset or bus-off | (1) Bus-off recovery still running (fast 100 ms × 5, then slow); (2) NM restart delay after bus-off (500/1000 ms) before diagnostics; (3) CAN init: no TX before 150 ms | Error frames and recovery pattern in the log | Recovery timing matches DID 0x0103 |
| T-12 | Transceiver in an unexpected mode | Mode control/INH wiring, part-specific behaviour (Q-08) | Supply current, scope on CANH/CANL and INH/EN if accessible | Needs hardware documentation |
| T-13 | ECU reports the wrong wake state (`IGN_STS_SRS`) | (1) Reading a stale value (F-04); (2) value 2 kept after AWB clear until `P_IGN_STS_AWB_Clear_Delay` (32364537, impl. no); (3) ignition sensed through leakage | Fresh frame timestamps; IGN line voltage | — |
| T-14 | Sleep current too high | (1) ECU not in Bus-Sleep (inputs, T-03); (2) transceiver not in standby/sleep; (3) repeated spurious wake-ups by restbus traffic with the ECU re-validating and sleeping again; (4) bench load/measurement offset | Current log over minutes with the CAN log; look for periodic current spikes with or without bus traffic | Spikes aligned with bus activity → (3) |
