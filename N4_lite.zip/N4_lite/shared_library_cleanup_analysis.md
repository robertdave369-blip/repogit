# Shared library cleanup — analysis for review

Static analysis of `shared_libraries/`, focused on `jscript_translation.py` and
`core_functions.py`. **Nothing has been changed.** Every item below is a proposal with a
line number so you can accept or reject it individually.

Generated 2026-08-28 against the current working tree.

Method: each file is parsed with `ast`; a name is only called unused when it is never
read in its own file **and** never referenced anywhere else in the repository (7,140
Python files scanned). String literals count as references, so a name reached through
`getattr("X")` or a config lookup is not reported as dead.

---

## 1. Blocker — `core_functions.py` does not parse

**This is not a cleanup item. The module is currently unimportable.**

| File | Line | Problem |
|---|---|---|
| `shared_libraries/core_functions.py` | **408** | Stray doubled quote in `__all__` |

```python
    "CheckCAN_WarningSignal_Status", "check_warning_lamp_status",""checkWLof2C0",
                                                                ^^
```

`ast.parse` fails with `unterminated string literal`. Because `import_list.py` does
`from .core_functions import *`, every generated script that imports the shared libraries
fails at import time. This arrived with the uncommitted working-tree changes
(`git diff` shows 1,014 insertions in this file against `d2bad85`).

Fix is one character: `,""checkWLof2C0"` → `,"checkWLof2C0"`.

I analysed a patched scratch copy to produce the rest of this report; the real file is
untouched.

### 1.1 `__all__` exports 9 names the module does not define

Even after the quote fix, `from core_functions import *` still misbehaves, because
`__all__` (line 377) lists names that are not module-level in this file:

| Exported name | Status |
|---|---|
| `checkWLof2C0` | **No definition anywhere in the repository.** Likely a typo for `check_warning_lamp_status` (line 2296) or a function that was deleted. |
| `ARIA`, `CAN`, `CurveData`, `LAMPS`, `PS`, `RESULT`, `RSU`, `SPI` | Defined in `jscript_translation.py`, imported by `core_functions` only *inside* functions (lines 105, 117, 468), so they are not module attributes and `import *` cannot re-export them. |

Two options, your call:
- **A** — drop all 9 from `__all__`. Scripts already get these 8 classes from
  `jscript_translation` via `import_list`, so nothing breaks.
- **B** — keep the 8 class names and add a real module-level
  `from .jscript_translation import ARIA, CAN, ...`. This creates a circular import
  (`jscript_translation` imports `core_functions` at line 29), which is presumably why
  they were made function-local in the first place.

I recommend **A**. `checkWLof2C0` should be removed regardless.

---

## 2. `jscript_translation.py` (2,540 lines)

### 2.1 Unused imports

| Line | Name | Statement | Notes |
|---|---|---|---|
| 8 | `inspect` | `import inspect` | Never used in this file. |
| 29 | `Internal_Security_Access` | `from .core_functions import Internal_Security_Access, enter_ext_session` | Never used in this file. |
| 29 | `enter_ext_session` | *(same line)* | Never used in this file. |

Line 29 is the **only** import of `core_functions` from `jscript_translation`. Removing
it breaks the import cycle between the two modules, which is what currently forces the
function-local imports described in §1.1. Worth doing for that reason alone.

Both names are heavily used elsewhere (1,155 and 831 references across the repo) — they
just are not used *here*, and scripts get them from `core_functions` directly.

### 2.2 Dead local variables

| Line | Function | Variable |
|---|---|---|
| 1350 | `ReadAllDTCNamesWithStatus` | `count` |
| 1367 | `ReadAllDTCNamesWithStatus` | `expected_errors` |
| 1368 | `ReadAllDTCNamesWithStatus` | `optional_errors` |
| 2054 | `SendAcceleration` | `original_value` |

Each is assigned and never read. `expected_errors` / `optional_errors` sit next to each
other and look like the start of an abandoned comparison — worth a glance before deleting,
in case the assertion was meant to be written and never was.

### 2.3 Duplicate method definitions — silent shadowing

| Lines | Definition | Effect |
|---|---|---|
| 1653, 1657 | `SensorTypeMainIni.sensor_type_main_ini` | The definition at 1653 is discarded; only 1657 exists at runtime. |
| 1681, 1685 | `DesignerHelper.SensorTypeMainIni` | The definition at 1681 is discarded; only 1685 exists at runtime. |

Python keeps the last definition silently. Please confirm which body is the intended one
before I delete the other — the discarded halves may hold the behaviour you actually want.

---

## 3. `core_functions.py` (5,227 lines)

### 3.1 Unused imports

| Line | Name | Source |
|---|---|---|
| 11 | `datetime` | `from datetime import datetime` |
| 12 | `Dict` | `from typing import ... Dict ...` |
| 35 | `DEFAULT_EOL_BY_VARIANT` | `from .configuration_control import (...)` at line 30 |
| 37 | `DEFAULT_VARIANT_CODE_BY_VARIANT` | `from .configuration_control import (...)` at line 30 |
| 47 | `HSCAN_WARNING_LAMP_CONFIG` | `from .configuration_control import (...)` at line 30 |
| 64 | `ResultLoc` | `from .configuration_control import (...)` at line 30 |
| 91 | `list_available_projects` | `from .framework_registry import ...` |
| 96 | `_load_project_config_module` | `from .project_config_loader import (...)` at line 92 |

`HSCAN_WARNING_LAMP_CONFIG` deserves a second look: `check_warning_lamp_status`
(line 2296) is explicitly about HSCAN/CANFD warning lamps and builds its own channel map
inline at lines 2310–2325. It is plausible this import was meant to be used there and the
inline map is the accidental duplicate. Please confirm the intent before I remove it.

### 3.2 Dead local variables

28 assigned-and-never-read locals. Grouped by likely cause:

**Probably safe — leftover scaffolding**

| Line | Function | Variable |
|---|---|---|
| 707 | `POWER_OFF` | `ret` |
| 755 | `POWER_ON` | `ret` |
| 1618 | `SET_LOOPS_LOADS` | `ARiALoadBoxLoop_Name` |
| 1619 | `SET_LOOPS_LOADS` | `temp` |
| 1651 | `SET_DCS_LOADS` | `u8count` |
| 2440 | `GenerateCurveFile` | `MaturationTimer_Expired` |
| 3273 | `DataIdentifier_Read_Write` | `header_only` |
| 3274 | `DataIdentifier_Read_Write` | `data_only` |
| 3275 | `DataIdentifier_Read_Write` | `data_len` |
| 3621 | `testCase_ReadAllSensorData_1` | `testCase` |
| 3656 | `testCase_ReadAllSensorData_2` | `testCase` |
| 3658 | `testCase_ReadAllSensorData_2` | `ch` |

**Check first — computed expectations that are never asserted**

| Line | Function | Variable |
|---|---|---|
| 1411 | `IMUCalibration_Routine` | `XRedCalibration` |
| 1413 | `IMUCalibration_Routine` | `YRedCalibration` |
| 1416 | `IMUCalibration_Routine` | `YawRedCalibration` |
| 1418 | `IMUCalibration_Routine` | `PitchCalibration` |
| 1426 | `IMUCalibration_Routine` | `PitchCalibrationExp` |
| 1428 | `IMUCalibration_Routine` | `XRedCalibrationExp` |
| 1429 | `IMUCalibration_Routine` | `YRedCalibrationExp` |
| 1430 | `IMUCalibration_Routine` | `YawRedCalibrationExp` |
| 2373 | `Read_customer_DTC` | `Displayed_DTC` |
| 2374 | `Read_customer_DTC` | `ObtainedDTC` |
| 2376 | `Read_customer_DTC` | `Dtc` |

The `IMUCalibration_Routine` block is the one I would not delete without you looking. The
`*Exp` names read as *expected* values sitting beside their measured counterparts, so this
looks like a comparison that was never written rather than dead code. If the routine is
supposed to assert calibration results, deleting these removes the evidence that the check
is missing. Same reasoning for the three `Read_customer_DTC` names.

**Repeated pattern — likely one shared helper**

| Line | Function | Variable |
|---|---|---|
| 2548 | `NVM_Clear_L61` | `vin_strategy_options` |
| 2579 | `fault_free_profile_classic_can` | `vin_strategy_options` |
| 2628 | `fault_free_profile_can_fd` | `vin_strategy_options` |
| 3969 | `vin_strategy_test` | `vin_strategy_options` |
| 3970 | `vin_strategy_test` | `vin_strategy_key` |

The same unused assignment appears in four functions. That is usually copy-paste from a
template, not four independent mistakes. Deleting all five is safe; it may also be worth
asking why the VIN strategy lookup is prepared and then ignored.

---

## 4. Other shared library files

Included for completeness; not the focus of your request.

| File | Unused imports | Dead module vars | Dead locals |
|---|---|---|---|
| `configuration_control.py` | 9 | 2 | 0 |
| `crash_configuration.py` | 0 | 6 | 0 |
| `winidea.py` | 2 | 0 | 2 |
| `edr_did_library.py` | 0 | 3 | 0 |
| `edr_decoding_functions.py` | 0 | 0 | 2 |
| `ascent_batch_lib.py` | 0 | 1 | 1 |
| `excel_handler.py` | 0 | 0 | 1 |
| `fault_monitor.py` | 0 | 0 | 1 |

Full per-item detail is in the JSON alongside this report if you want it expanded.

---

## 5. Channel handling — current state

Relevant to the new skill. `CAN` is already fully channel-agnostic; the hardware classes
are not.

| Class | Methods | Accept a channel | Do not |
|---|---|---|---|
| `CAN` | 25 | **25** | 0 |
| `RSU` | 11 | 1 | 10 |
| `SPI` | 6 | 1 | 5 |
| `PS` | 16 | 0 | 16 |
| `SQUIB` | 10 | 0 | 10 |
| `ARIA` | 9 | 0 | 9 |
| `RD` | 3 | 0 | 3 |
| `RESULT` | 17 | 0 | 17 (reporting only — correctly has no channel) |

`CAN` already carries the pattern worth standardising, in `jscript_translation.py`:

- `_normalize_channel_name` (line 89) — folds `HSCAN`/`HS CAN`/`CANFD`/`CAN_FD`/… onto a
  canonical name.
- `_extract_optional_channel_arg` (line 139) — lets a channel be passed as a leading
  positional argument without changing existing call sites.
- `_resolve_default_channel_name` (line 149) — falls back through `CANFD` → `HSCAN` →
  `ARIA` based on what the rig actually exposes.
- `_resolve_raw_can_channel_name` (162), `_resolve_simulation_channel_id` (179),
  `_resolve_diag_channel_id` (200), `_resolve_level61_diag_channel_id` (211).

This is why `CAN.SendDiagByValues()` already works unchanged on an HSCAN rig and a CAN-FD
rig. The gap is that nothing writes this down, so each new wrapper re-invents it — and
`core_functions.check_warning_lamp_status` (2310–2325) and `_frame_channel` (2851) both
hardcode their own channel maps instead of calling the resolvers above.

The skill in `.github/skills/can-channel-agnostic-wrappers/` documents this contract.

---

## 6. Suggested order

1. Fix the line 408 syntax error — nothing else can be verified until then.
2. Decide on the `__all__` question in §1.1.
3. Remove the unused imports (§2.1, §3.1), keeping `HSCAN_WARNING_LAMP_CONFIG` pending
   your answer. Removing line 29 of `jscript_translation.py` also breaks the import cycle.
4. Resolve the two duplicate methods (§2.3) — needs your decision on which body is correct.
5. Delete the "probably safe" locals (§3.2 first table, §2.2).
6. Leave the `IMUCalibration_Routine` and `Read_customer_DTC` locals until you confirm
   whether a missing assertion is hiding there.

Tell me which groups to apply and I will make the changes.

---

## 7. Re-verification — 2026-08-28

Re-ran every check against the current working tree.

| Check | Result |
|---|---|
| Shared library files parsing | 18 of 19; `core_functions.py` still fails at line 408 |
| Reported items still present | **47 of 47** |
| Items resolved since the review | 0 |
| New items found | 0 |
| Dead-code analysis | byte-for-byte identical to the first run |
| Channel checker | 8 findings, unchanged |

Nothing in `shared_libraries/` has been edited since the review, so every item below
still applies as written. `git status` shows the same uncommitted working-tree state that
introduced the line 408 error.

One correction to this report, not to the code: five unused imports were cited at the
line of their `from ... import (` statement rather than the line the name itself sits on.
The tables in §3.1 now give the name's own line, with the statement line noted alongside.
Affected: `DEFAULT_EOL_BY_VARIANT` (30 → 35), `DEFAULT_VARIANT_CODE_BY_VARIANT` (30 → 37),
`HSCAN_WARNING_LAMP_CONFIG` (30 → 47), `ResultLoc` (30 → 64),
`_load_project_config_module` (92 → 96). The findings themselves are unchanged.

---

## 8. Cleanup applied — 2026-08-28

### Applied

| Item | File | Result |
|---|---|---|
| B.4 | `jscript_translation.py` | Removed `import inspect` and `from .core_functions import Internal_Security_Access, enter_ext_session`. The import cycle is now one-directional. |
| B.5 | `core_functions.py` | Removed `datetime`, `Dict`, `DEFAULT_EOL_BY_VARIANT`, `DEFAULT_VARIANT_CODE_BY_VARIANT`, `ResultLoc`. `Dict` was dropped from the shared `typing` line; the other names stayed. |
| C | `core_functions.py` | Removed 14 dead locals. `ret` was assigned **twice** in each of `POWER_OFF` and `POWER_ON`, not once as originally reported. |
| C | `jscript_translation.py` | Removed `count`, `expected_errors`, `optional_errors`. |
| C | `jscript_translation.py` | `SendAcceleration`: kept `float(line.strip())` as a bare call and removed only `original_value =`. The call raises on a malformed curve line and the enclosing handler reports it, so the loop is a validation pass. A comment now records that. |
| D | `core_functions.py` | Removed all 5 VIN strategy locals. Both helpers were confirmed pure config reads. |

Net: `core_functions.py` 5228 → 5205 lines, `jscript_translation.py` 2540 → 2536.

### Not applied — the original finding was wrong

**B.3 must not be applied.** The 8 names (`ARIA`, `CAN`, `CurveData`, `LAMPS`, `PS`,
`RESULT`, `RSU`, `SPI`) **are** real module-level bindings, created as `_LazyObjectProxy`
instances inside `if not TYPE_CHECKING:` at lines 361–369. The code comment states the
intent: deferring resolution to first attribute access is what keeps the
core_functions/jscript_translation cycle benign. Removing them from `__all__` would
strip them from `from core_functions import *`.

Section §1.1 of this report was a false positive: the analyser walked only top-level
`tree.body` and never descended into the `if` block. Re-checked properly, **all 136
`__all__` entries are bound**. Runtime confirms it — the proxies resolve to the real
`jscript_translation` classes.

`checkWLof2C0` was the one genuine miss, and you had already removed it. It was not a
typo: it existed as a real function in the prior snapshot
(`graphify-out/framework_memory_sources/.../core_functions.py:3033`) and was replaced by
the config-driven `check_warning_lamp_status(network, status)`. Deliberate replacement.

**E.4 must not be applied.** Both "duplicate" pairs are `@property` / `@<name>.setter`
pairs — the standard idiom, where the setter attaches to the property rather than
shadowing it. Another analyser false positive; it did not inspect decorators.

### Retained deliberately

| Name | Why |
|---|---|
| `HSCAN_WARNING_LAMP_CONFIG` | Held per E.1. See §9 — it is now a broken import. |
| `list_available_projects`, `_load_project_config_module` | Unused, but not in the approved B.5 list. |
| IMU and `Read_customer_DTC` locals | Held per E.2 / E.3, pending your review. |

### Newly orphaned by the approved removals — awaiting your decision

Three names lost their only reader as a direct consequence of the approved deletions.
None were in the approved list, so all three were left in place:

| File | Line | Name | Note |
|---|---|---|---|
| `core_functions.py` | 702 | `timestamp` in `POWER_OFF` | RHS is `RESULT.get_current_timestamp()` — a call, inside an explicit `#TODO`/`pass` branch |
| `core_functions.py` | 748 | `timestamp` in `POWER_ON` | same |
| `core_functions.py` | 3947 | `project` in `vin_strategy_test` | RHS is `_active_project_for_fallback()` |

Say the word and I will remove them.

---

## 9. New blocker found during verification — NOT caused by the cleanup

`shared_libraries/configuration_control.py` **cannot be imported.** It is a file I did
not touch; the breakage is in your uncommitted working-tree changes (`git diff` shows
8 insertions, 69 deletions).

```
NameError: name 'HSCAN_WARNING_LAMP_CONFIG' is not defined
  configuration_control.py, line 253
```

Lines 252–254 build `WARNING_LAMP_CONFIG` from two dicts that were deleted from the file:

```python
WARNING_LAMP_CONFIG = {
"HSCAN": HSCAN_WARNING_LAMP_CONFIG,     # never defined
"CANFD": CANFD_WARNING_LAMP_CONFIG,     # never defined
}
```

Because `import_list` pulls in `configuration_control` early, this breaks **every**
script, exactly like the line 408 error did. It was invisible until now: `core_functions`
failed at parse time, so nothing ever reached this line.

### It cascades into `core_functions.py`

The same edit deleted names that `core_functions` still imports at line 29. Eight of them
no longer exist anywhere:

```
ACTIVE_CAN_VARIANT      DEFAULT_EOL_CODE           DEFAULT_VARIANT_CODE
HSCAN_WARNING_LAMP_CONFIG                          SOFTWARE_VERSION_READ_CONFIG
SW_PARAMETER            SW_VERSION_DID             SW_VERSION_PARAM
```

Each is an `ImportError` waiting behind the `NameError`. Two more —
`DEFAULT_EOL_BY_VARIANT` and `DEFAULT_VARIANT_CODE_BY_VARIANT` — were in the same
condition, and the approved B.5 removal happens to have fixed those two already.

This also resolves the E.1 question: `HSCAN_WARNING_LAMP_CONFIG` is not a missed
refactor. `WARNING_LAMP_CONFIG` is a wrapper `{"HSCAN": ..., "CANFD": ...}` around it, and
`check_warning_lamp_status` already uses the wrapper. The inline map at lines 2299–2314 is
an *alias table* (`HS`→`HSCAN`, `FD`→`CANFD`), a different thing entirely, not a duplicate.
The import is redundant — and now also broken. I left it in place per your instruction.

### Fixing it is outside this cleanup

Restoring the deleted definitions is a content decision about what those configs should
contain, in a file outside the approved scope (safety rule 8). Two routes:

- **A** — restore the deleted definitions in `configuration_control.py` and re-add them to
  its `__all__`.
- **B** — if the deletion was intended, drop the dangling `WARNING_LAMP_CONFIG` reference
  and remove the 8 now-invalid imports from `core_functions.py` line 29.

Tell me which and I will apply it.

## 10. Verification results

| Check | Result |
|---|---|
| H.1 All 19 shared library files parse | **PASS** |
| H.2 `core_functions.py` parses | **PASS** |
| H.3 `from core_functions import *` initializes | **PASS** — 136 names bound, no probe missing |
| H.4 No circular-import error, both orders | **PASS** — and the lazy proxies resolve to the real classes |
| H.5 Re-run dead-code analysis | `jscript_translation.py` fully clean (3→0 imports, 4→0 locals) |

H.3 and H.4 were run with the §9 `configuration_control` breakage stubbed, and with
`IOEM_FRAMEWORK_PROJECT=U171` set. That isolation is deliberate: it proves the remaining
failure is not attributable to this cleanup. **Against the unmodified tree they still
fail**, because of §9. I am not claiming those two as green end-to-end.

`jscript_translation.py` was read-only; I cleared the attribute to edit it and set it back
afterwards. It is read-only again now, as found. `core_functions.py` was already writable.
