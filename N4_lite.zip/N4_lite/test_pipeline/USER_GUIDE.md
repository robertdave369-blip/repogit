# The task pipelines — user guide

| You have … | Type in Copilot Chat | You get |
|---|---|---|
| a test-execution task (Codebeamer or your manager) | `/run-test-task …` | bench run on ARIA, logs + HTML per test case, triaged failures, bug list, zip/PTC push |
| requirements to review against the customer L10 | `/review-requirements …` | review comments in Excel (what is written vs what L10 says, missing requirements …) — §9 |
| requirements to test, or a test spec with missing traceability | `/write-test-cases …` | test cases in the Codebeamer import format with traceability, or a traced copy of your spec + corrections — §10 |
| existing test cases to review (Excel or Codebeamer) | `/review-test-cases …` | findings in Excel with the corrected version (coverage gaps, wrong expected results, steps, timing, traceability), suggested test cases, review report — §10a |
| HTML/XML reports and CAN logs to check | `/review-test-results …` | findings in Excel: real defects, bench/script problems, false passes, incomplete reports — §11 |

All of them work the same way: one prompt, one list of questions at the start, then hands-free; they
keep the PC awake and online while the screen is locked (§12); they deliver Excel for you to review
and change nothing in Codebeamer or PTC without your approval. Sections 1–8 explain the
test-execution pipeline in detail; most of it (setup, stops, files) applies to the others too.

```
your task ─► setup ─► read Codebeamer / manager text ─► OEM L10 ─► ECU source review
          ─► requirement ↔ test case ↔ script check ─► map test cases to scripts
          ─► G2 plan ── you say "go" ──► run on ARIA ─► logs + HTML per test case
          ─► triage failures ─► fix script / Excel test case ─► re-run
          ─► bug list + issue log ─► hand-over ─► (you approve) Codebeamer update / PTC push
```

---

## 1. One-time setup

| What | How | Done automatically? |
|---|---|---|
| Python packages (openpyxl, Codebeamer CLI, test-spec and document skills, python-can) | the agent runs `py -3.14 tools/test_task.py setup --pipeline <kind>` at every task start; it pip-installs what that pipeline needs | **yes** |
| PC awake while locked | started by the agent at task start, released at the end (§12) | **yes** — keep the lid open and the charger in |
| Codebeamer login | create `.github\skills\code-beamer\.env` from `.env.example` (URL, user, password). Never paste credentials in chat | no — you, once |
| Hands-free terminal | in VS Code settings, add `py -3.14 tools/test_task.py` and `py -3.14 tools/aria_ctl.py` to the terminal auto-approve list (`chat.tools.terminal.autoApprove`). Without it VS Code asks you to allow each command | no — you, once |
| ARIA offline | run `tools\block_aria_network.ps1` once in an **Administrator** PowerShell (again after installing a new ARIA version) | no — you, once |

Check everything at any time: `py -3.14 tools/test_task.py setup --online` (the `--online`
part also tests the Codebeamer login).

---

## 2. Starting a task

Open **Copilot Chat** (Ctrl+Alt+I), choose **Agent** mode and your model (for you: the "sol 6.1"
model you normally use — the pipeline works with any model you pick).

**Way A — the prompt file (recommended).** In the chat box type `/run-test-task`, a space, and
the task details, then Enter. If VS Code asks for the `task` value instead, paste the same details
into that box. The prompt switches the chat to the `test-execution-pipeline` agent for you.

**Way B — pick the agent.** In the agent drop-down choose `test-execution-pipeline`, then write
the task as a normal message.

**Way C — continue an earlier task.** Write: "Resume the test task in
`test_campaigns\<project>\<date>_<task>`" — the agent reads its `manifest.json` and carries on
where it stopped.

---

## 3. What to write

Give these four things; anything you leave out, the agent asks for once at the start (gate G1).

| Field | Examples |
|---|---|
| Project | `M310_M314_M110`, `U171`, `Z121`, `M210`, `UPP_EV`, `W610`, `W616` |
| Task | Codebeamer requirement / test-case IDs, **or** paste your manager's instructions |
| OEM level-10 spec | Codebeamer IDs of the OEM requirements, or file paths (PDF/DOCX/ReqIF/Excel), or "none" |
| ECU source folder | e.g. `D:\src\SC3_ACU\M314` (read-only), or "none" |

**Bench files** — say which files the run must use, or "as ARIA has them now" (the agent then
shows you what ARIA has and you confirm):

| Field | Examples |
|---|---|
| ARIA project | `C:\AriaConfigFiles_Generic\AriaConfigFiles\AriaMain.json` |
| Loadbox profile | `...\AriaMain_accdata\Loadbox\M314_LoadBox_Profile.json` |
| RSU workbook | `...\Config_folder\RSU\XLS\M314\M314_RSU.xlsx` |
| DBC file(s) | `project_dbc\m314_dbc\SRS_FD_SVNID_41243.dbc` (+ the HS-CAN one if that bus is simulated) |

Before anything runs, and again when the run starts, the agent checks that ARIA — also when it is
already open — runs exactly these: the active project, the profile and RSU workbook (same file or
same content), the DBC each CAN simulation was imported from and its frames and signals, and that
none of the files changed after ARIA started. Then it reads the ECU's DTCs once (the framework's
`Read_DTC_Req`): the bench is **fault free** only when the ECU reports no DTC.

Also useful: test cases to skip, anything already known to be broken.

### Example 1 — task from Codebeamer

```
/run-test-task Project M310_M314_M110. Codebeamer requirement 37425057 and its linked test
cases. OEM L10: C:\specs\Mahindra\SRS_L10_v3.pdf, section on crash output. ECU source:
D:\src\SC3_ACU\M314. Bench config: C:\AriaConfigFiles_Generic\AriaConfigFiles\AriaMain.json,
profile M314_LoadBox_Profile.json, RSU workbook M314_RSU.xlsx, DBC
project_dbc\m314_dbc\SRS_FD_SVNID_41243.dbc
```

### Example 2 — task from your manager (not yet in Codebeamer)

```
/run-test-task Project M310_M314_M110. Manager's instructions (not in Codebeamer yet):
"Run F010 ACTIVATE CRASH IO-control test cases 1 and 2 and check the crash output stays
active for 5 s." No OEM L10 this time. ECU source: none today.
```

### Example 3 — only some test cases, re-run after a bench fix

```
Resume test_campaigns\M310_M314_M110\20261026_F010_ACTIVATE_CRASH. Re-run only M2; the
bench power supply was off during the first run.
```

---

## 4. The stops and what you answer

The agent works on its own between these stops and posts a one-line status after each stage.

| Stop | When | What you see | Typical answer |
|---|---|---|---|
| **G1 Inputs** | start | one list of missing inputs | give them, or "none" |
| **G2 Bench go** | before anything runs on the bench | `analysis\g2_plan.md`: test cases → scripts, what each script does that matters (security access, DTC clear, IO overrides, flashing …), bench state, ARIA set-up against your bench files, what must happen first (e.g. start ARIA, re-import a DBC), its questions | answer its questions, then **"go"**. One go covers this batch, its DTC check and its re-runs |
| **G2b Bench not ready** | the run starts with a check: ARIA set-up and the ECU's DTCs | the DTCs (code, status, active or stored) or what differs from your bench files; nothing has run yet | let the agent fix it (it asks for each bench step), or tell it to go on anyway in your own words — e.g. "go on, 0x9A1234 is a known open loop" — which is recorded with the run |
| **G3 New risky step** | a fix or re-run needs something G2 did not list (flash, NVM/EOL/VIN write, crash trigger, editing a generator-owned script) | the exact step | "yes" / "no, skip that case" |
| **G4 Codebeamer update** | after you reviewed the Excel changes | `testcases\changes.md` + Codebeamer plan IDs | "approve plan <id>" (only those) or "not now" |
| **G5 PTC push** | when you want the logs uploaded | asks for the zip name, destination, PTC source root, sandbox, project, change package and target folder; then shows the PTC preflight | give the values; after the preflight: "approve" |

Nothing goes to Codebeamer or PTC without G4/G5. The PTC target folder may not contain
`test_logs` or `test_results` in its name (the PTC tool silently skips such folders).

---

## 5. Your review work

Everything for one task lives in `test_campaigns\<project>\<date>_<task>\` (not in git).

| File | What to do with it |
|---|---|
| `analysis\g2_plan.md` | read before saying "go" |
| `testcases\<task>_testcases.xlsx` | **edit test cases here, in VS Code/Excel — never directly in Codebeamer.** The agent also puts its corrections here; the `Review notes` column says why. When you are happy, tell it "review done"; it builds `testcases\changes.md` and asks at G4 |
| `package\` | the deliverable: `<test case name>.html` (report), `.txt` (CAN log), `.console.txt`, `summary.csv` |
| `bugs.xlsx` / `bugs.md` | "Bugs to verify" = suspected ECU defects and undetermined failures, with category, confidence (High/Medium/Low), evidence and action. Verify them before raising defects |
| `issues.md` | running log of every problem met and what was done |
| `analysis\alignment.md`, `source_review.md` | requirement / test case / script mismatches and suspected code defects |
| `manifest.json` | task state: attempts, script corrections (commit id + backup), zip, PTC request |

**Script corrections** follow your rule: only test scripts
(`projects\<p>\modules\**\scripts\*.py`), the current file is **git-committed first**, a copy
`<script>.py.bak-<time>` is kept, and the corrected script keeps its name. To undo one:
`git checkout <commit> -- <script>` (the commit id is in `manifest.json`) or copy the `.bak` back.
Config files and `shared_libraries` are never changed; such fixes are proposed in
`docs\improvements\`.

---

## 6. How failures are judged

Each failure gets one category, in this order of checking: **BENCH** (ARIA/connection/power/
loadbox/CAN problem) → **SCRIPT** (script does not do what the test case says) → **TEST_CASE**
(test case contradicts the requirement/L10) → **REQUIREMENT** (requirement contradicts L10 or other
specs) → **ECU_DEFECT** (everything else is right and the ECU behaves wrongly) → **UNDETERMINED**.
Bench and script problems are fixed and re-run (max two re-runs per test case). Confidence is
**High** when reproduced or flipped by a fix, **Medium** for one clear run, **Low** for partial
evidence.

---

## 7. When something goes wrong

| Symptom | What to do |
|---|---|
| "ARIA is not running" in the plan | let the agent start it (it asks — with a chassis that is a hardware step) or start ARIA yourself |
| "2 ActiveInstances files" | a leftover from a crashed ARIA: the agent runs `aria_ctl.py clean-stale` (asks first) |
| "project: ARIA's active project is …; expected …" | wrong bench project loaded: close ARIA; the agent switches it (`aria_ctl.py use-config`) |
| "DBC CANFD: simulation CANFD was imported from …" / "DBC … content: n difference(s)" | ARIA simulates an older or other DBC: re-import your DBC in ARIA (Configuration → Periodics, save & restart), or confirm that the DBC ARIA has is the right one |
| "loadbox profile" / "RSU workbook" problem | ARIA loads another file than you named: the agent points ARIA at yours (backup kept) and restarts it, after your yes |
| "changed after ARIA started" | a bench file was edited while ARIA was open: restart ARIA |
| "bench not fault free: 0x… status 0x…" | the ECU reports DTCs before the test: find the bench cause (load, sensor, power, CAN), or say to go on anyway |
| "fault-free check not possible" | the ECU did not answer the DTC read: switch it on (IGN ON) and wait for the proveout, then run again |
| Codebeamer error (401, timeout) | check `.env`, VPN/network; `setup --online` |
| `pip install … failed` | no internet/proxy on this PC; install once on a connected network, then retry |
| A test case shows `??` in the mapping | the agent opens the candidate scripts and confirms the right one, or reports "no script" |
| VS Code asks to allow every command | add the auto-approve rule from §1 |

---

## 8. Command cheat sheet (if you want to run steps yourself)

```
py -3.14 tools/test_task.py setup [--online]
py -3.14 tools/test_task.py init --project <P> --task "<title>" [--task-source manager --manager-file note.txt]
                                 [--cb-req <ids>] [--cb-tc <ids>] [--oem-spec <ids|path>] [--source-dir <dir>]
                                 [--aria-dir C:\ARIA5.20] [--aria-config <AriaMain.json>]
                                 [--loadbox-profile <profile.json>] [--rsu-workbook <RSU.xlsx>] [--dbc <file> ...]
py -3.14 tools/test_task.py cb-fetch <campaign> --items <ids> --follow
py -3.14 tools/test_task.py add-tc   <campaign> --id M1 --name "<test case name>"
py -3.14 tools/test_task.py tc-workbook | map | risk | plan <campaign>
py -3.14 tools/test_task.py map      <campaign> --set <id>=<script path>
py -3.14 tools/test_task.py run      <campaign> [--only <ids>] [--reason "<why>"] --apply      (drives the bench)
                                     [--accept-bench "<your words>"]  only when you accept the bench-check problems
py -3.14 tools/test_task.py collect | triage-scan | bugs | tc-diff <campaign>
py -3.14 tools/test_task.py backup-script <campaign> <script> --reason "<why>" --apply
py -3.14 tools/test_task.py zip <campaign> --name <zip name> --dest <folder>
py -3.14 tools/test_task.py ptc-request <campaign> --source-root … --sandbox-root … --ptc-project … --change-package … --target-folder …
py -3.14 tools/aria_ctl.py status | versions | logs | ping | clean-stale | compat
py -3.14 tools/aria_ctl.py check-inputs --config <AriaMain.json> --profile <json> --rsu <xlsx> --dbc <file> [--live]
py -3.14 tools/aria_ctl.py read-dtc --project <P> --apply                                        (one UDS DTC read)
```

---

## 9. Requirement review — `/review-requirements`

Give: project, the Codebeamer requirement IDs **or** the tracker ID (+ status), the customer L10
document(s) (file paths or Codebeamer IDs — asked per task), any other documents (DBC, diagnostic
spec, earlier release), and the scope.

```
/review-requirements Project M310_M314_M110. Codebeamer tracker 165204682, status In_Review.
Customer L10: C:\specs\Mahindra\SRS_L10_v3.pdf. Also check against the project DBC and the
diagnostic spec C:\specs\M314_DiagSpec_v2.xlsx. Focus: DTC qualification timing.
```

You get `review\<task>_requirement-review.xlsx` (+ `.md`), one row per finding, sorted by
severity: requirement ID, the L10 reference (document + section/page), category (CORRECTNESS,
COMPLETENESS, AMBIGUITY, TESTABILITY, CONSISTENCY, TRACEABILITY, TERMINOLOGY, FORMAT, STATUS,
MISSING_REQUIREMENT), **what is written** in Codebeamer and **what the source says** (quoted),
proposed wording, confidence and evidence. Review the sheet (Status column). The agent never edits
Codebeamer; if you want a requirement changed, it prepares a Codebeamer plan and applies it only
after you approve the plan ID. Comments cannot be posted by the tool — post them from the sheet.

## 10. Test-case writing and traceability — `/write-test-cases`

**New test cases:**

```
/write-test-cases Project M310_M314_M110. Write test cases for Codebeamer requirements
37425057, 37425058, 37425060. Use the default Codebeamer template.
```

**Add missing traceability to an existing spec:**

```
/write-test-cases Project U171. Add traceability to C:\specs\U171_CANC_TestSpec.xlsx against the
requirement export C:\specs\U171_SRS_export.xlsx. Also review the test steps.
```

You get, in the task folder `testcases\`:

- `<task>_CB_import.xlsx` — new test cases in the Codebeamer import format (Veoneer template),
  each with `Verifies = [ISSUE:<id>] - null`, checked by the template's own validator, plus a
  coverage sheet (every approved requirement → its test cases, gaps listed);
- `<your spec>_traced.xlsx` — a **copy** of your spec with three new columns (Proposed Verifies,
  Trace basis, Trace confidence) and a Coverage sheet; your original file is not touched;
- `review\<task>_trace.xlsx` — the corrections: missing / wrong / unknown / unapproved / struck
  links, untested requirements, duplicate cases, weak steps (no measurable expected result),
  expected results that contradict the requirement.

Tell the agent which corrections to apply (it edits its copies and re-validates). Then either you
import the workbook with Codebeamer's Excel importer, or the agent prepares one Codebeamer plan per
test case and applies them after you approve the plan IDs.

## 10a. Test-case review — `/review-test-cases`

Give: project, the test cases (an Excel spec path, or Codebeamer test-case IDs / a tracker with a
status), the requirements (default: what the test cases verify), the customer L10 (or "none"),
other sources if they matter (DBC, diag spec, on-fail spec), and a focus if you have one.

```
/review-test-cases Project M310_M314_M110. Review C:\specs\M314_CANC_TestSpec.xlsx against
Codebeamer tracker 165204682 (Approved). L10: C:\specs\Mahindra\SRS_L10_v3.pdf. Focus: DTC status
bytes and timing.
```

```
/review-test-cases Project U171. Review Codebeamer test cases 38001001-38001020 against the
requirements they verify. No L10 this time.
```

It follows the review protocol of `agent_sc3.md` §19: it reads all sources first, looks for
contradictions between them, then checks every test case and every requirement. You get, in the
task folder:

- `review\<task>_tc-review.xlsx` — one row per finding, most severe first: test case, spec row,
  requirement, category (MISSING_TEST, COVERAGE_GAP, TRACEABILITY, EXPECTED_RESULT, STEP,
  PRECONDITION, TIMING, DIAGNOSTICS, COMMUNICATION, CONFIGURATION, DUPLICATE, SOURCE_CONFLICT,
  AUTOMATION, FORMAT), why it is wrong, evidence, impact, **current** and **proposed** (the
  corrected step / expected result / link), additional tests, confidence, Status for you;
- `review\<task>_tc-review_report.md` — summary, requirements covered and missing, traceability
  and coverage matrices, risks, open questions;
- `testcases\<spec>_traced.xlsx` — a copy of your spec with the proposed links and a Coverage
  sheet, and `testcases\suggested_cases.json` — the missing test cases it proposes.

Mark each finding's Status (accept / reject). The agent then writes only the accepted corrections,
into copies: `<spec>_corrected.xlsx` (Excel input) or the Excel copy of the Codebeamer test cases
(`changes.md` lists every change), and renders accepted new test cases into the Codebeamer import
format. Your spec and Codebeamer are never edited; Codebeamer is updated only by you (Excel
importer) or by a plan you approve.

## 11. Test-results review — `/review-test-results`

```
/review-test-results Project M310_M314_M110. Reports in test_results\M310_M314_M110\2026-10-15,
logs in test_logs\M310_M314_M110\2026-10-15. Test spec: C:\specs\M314_CANC_spec.xlsx. Use the
project DBC.
```

It reads framework/apym HTML reports and ARIA XML results, pairs each with its CAN log, matches
them to the test spec, checks failures in the logs (frames, timing, DTC status, diagnostic
responses) and delivers `review\<task>_report-review.xlsx`: per finding the category (ECU_DEFECT,
BENCH, SCRIPT, TEST_CASE, REQUIREMENT, REPORT_INTEGRITY, FALSE_PASS, COVERAGE_GAP, LOG_ANOMALY,
UNDETERMINED), expected vs observed, evidence (report step, log line, spec row), confidence and
the action (re-run, fix script, fix test case, raise defect). Reports and logs are never changed.
To re-run what it flags, start `/run-test-task` with those test cases.

## 12. Working with the screen locked

Every pipeline starts a keep-awake hold when the task starts and releases it when the task
finishes (or after 12 hours at most, so a forgotten task cannot keep the PC on for ever):

- Lock the screen (Win+L) and leave: the PC does not go to sleep, Copilot and the network keep
  working. The display may switch off; that is fine.
- If the internet drops, the helper reconnects the Wi-Fi you were on and logs it.
- **Keep the lid open and the charger connected.** On this PC closing the lid means sleep, and no
  program can override that; on battery a low charge shuts the PC down. A Windows Update restart
  or closing VS Code also stops the task.
- Check it any time: `py -3.14 tools/keep_awake.py status` (shows the running tasks and warns
  about the lid and battery). Release it by hand: `py -3.14 tools/keep_awake.py stop --all`.
- Log: `%LOCALAPPDATA%\test_pipelines\keep_awake.log`.

While a pipeline waits at one of its stops for your answer, the hold stays on, so you can answer
when you are back.
