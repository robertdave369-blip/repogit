# EDR CAN-C script generation — handoff

Everything a new session needs to pick this work up. Written 2026-09-04, updated 2026-09-05.

Scope: the common EDR CAN-C test scripts for DIDs **0x0455 (EDR1)** and **0x045B (EDR2)**
in three projects — `U171`, `ICE_01`, `EV_01`.

---

## 0. Standing intent — read before writing any script

**The generated scripts must look like the old legacy hand-written EDR scripts.** Not
like a new, cleverer format. This is the user's explicit and repeated instruction, and it
outranks any structural idea that looks tidier.

Reference style to copy:

| What | Path |
|---|---|
| Plain case | `projects/U171/modules/EDR/scripts/SUBS_EDR_Element_ID_ABS_Active_TestCase_13_1.py` |
| Fault case | `projects/U171/modules/EDR/scripts/updated_MCF/` (folder — style only) |

What "legacy style" means in practice:

- The standard import block, then `def run_test():` with the entire procedure inside
  it, then `if __name__ == "__main__":`.
- **The shared library arrives through one module.** A script writes
  `from Framework_IOEM_Py.shared_libraries.import_list import *` and never names an
  individual shared-library module. `import_list` re-exports all sixteen of them.
  Project configuration is still imported per module, and `canc_config` is
  star-imported last so a project value wins over a generic one of the same name.
- **Nothing at module level** except imports.
- **No nested functions anywhere.** No `def` inside `run_test`, no lambdas. The only
  `def` in the file is `run_test` itself. (A `record_raw()` helper existed and was
  removed for exactly this reason — see §6.)
- **Banned constructs the user named explicitly:** `ITERATIONS`, `SPEC_NOMINAL_VALUES`,
  `plan_rows`. Do not reintroduce them under other names.
- **Every sample value comes from `canc_config` at run time**, never baked into the
  script as a literal table.
- Logic may be *corrected* relative to the legacy scripts — the user said the old ones
  have logical issues that should be fixed — but new logic or new structure is added
  only when it is genuinely necessary, never for elegance.

**Golden rule:** edit the generator, never the generated scripts. All 1595 scripts are
rebuilt from `tools/generate_ice01_edr_canc_scripts.py`.

---

## 1. What exists

| Item | Path |
|---|---|
| Script generator (the thing to edit) | `tools/generate_ice01_edr_canc_scripts.py` |
| Case list / spec loader | `tests/test_common_edr_canc_specification.py` |
| On-fail calibration policy | `tools/build_edr_onfail_policy.py` |
| CAN route substitutions | `tools/edr_route_overrides.py` |
| `edr_config` builder | `tools/build_edr_config.py` |
| `canc_config` builder | `tools/build_ice01_canc_config.py` |
| NM qualification block (emitted into every `canc_config`) | `tools/nm_qualification.py` |
| Static audit | `tools/audit_edr_canc_scripts.py` |
| Independent spec check | `tools/verify_edr_config_against_spec.py` |
| Report theme (CSS only) | `shared_libraries/report_theme.py` |
| Report theme preview | `tools/preview_report_theme.py` |
| Modelled ECU (bench simulator) | `tools/simulate_edr_bench.py` |
| HTML review renderer | `tools/render_edr_review.py` |

Generated scripts live in `projects/<PROJECT>/modules/EDR_CANC/scripts/`, with a runner
(`run_all_*_scripts.py`) that the generator also writes.

Counts (per project, including the two whole-record checks):

| Project | Scripts | Vehicle class | Spec routes |
|---|---|---|---|
| U171 | 503 | ICE | U171 |
| ICE_01 | 503 | ICE | U171 |
| EV_01 | 589 | EV | M314 |

Two aggregate checks per project, rendered separately from the per-element cases:
`SUBS_EDR_RESERVED_BYTES_RECORD_00_TestCase_9001_1` (reserved bytes must read 0x00) and
`SUBS_EDR_NOT_CONFIGURED_RECORDS_FF_TestCase_9000_1` (allocations with no CAN route for
the variant must read 0xFF).

---

## 2. Sources of truth

| Fact | Source | Note |
|---|---|---|
| Every shared-library name | `shared_libraries/import_list.py` | The scripts' only shared-library import. Note the order inside it: `jscript_translation` is star-imported late, so `RESULT`, `Sleep`, `Wait`, `CAN` and `PS` resolve to its versions. Verified equivalent - `ascent_batch_lib.RESULT` is a proxy that forwards to `jscript_translation.RESULT`, and `core_functions.Sleep`/`Wait` forward there too. |
| Byte positions, lengths, signedness, scaling, offsets | `docs/project_documents/Common Diag Spec/ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx`, sheet **`EDR_0455_045B`** | **Only** source for data/byte/position info. The user ruled out DRBFM for this. The ICE_COMMON spec is correct for EV too. |
| Case list, names, descriptions, categories | `project_testcases/ice_common_spec/EDR/Common_EDR_CANC_0455_045B_U171_M314_v7_authoring.xlsx`, Sheet1 | |
| CAN signal encoding, invalid codes, state values | `project_dbc/u171_dbc/U171_SRS_SVNID39216_20250917_json/U171_SRS_SVNID39216_20250917_signals.json` (and the EV DBC for EV_01) | |
| NM detection/recovery counts | Same diag workbook, sheet `NetworkMgmtIdentifiers` (DIDs 0x0103, 0x0104) | |
| DTC mature/demature times | Same workbook, ` DTC List` sheet → "as per network management identifier sheet" | i.e. a count of message periods, not a duration |
| Frame period, sample arrays, fault logic | The project's own `config/canc_config.py` | |
| Record layout at run time | The project's own `config/edr_config.py` | No `spec_start_data`; the keys are `data_start_byte`, `data_end_byte`, `data_bit_length`, `data_samples_number`, `signed`, `scaling_factor`, `offset`, `type` |
| T0 offset per crash type | The project's `config/rsu_config.py` → `RSU_T0_OFFSETS` | 0 means fire exactly at T0 |
| Event record DIDs | The project's `config/edr_config.py` → `EDR_RECORD_DIDS` | Derived from `EDR_DIDS`; scripts never name a DID themselves |
| Version parameters | The project's `config/project_config.py` | |

Diagnostic indexing: the positive-response header `62 04 55` sits ahead of payload byte 0,
and `read_edr_parameters` reads `data[n-1]`, so **spec byte `b` is at `n = b + 4`**.

DTC maturation:

```
qualification_ms = detection_threshold x frame_cycle_time_ms
recovery_ms      = recovery_threshold  x frame_cycle_time_ms
```

Node Absent is 50 periods: 500 ms on a 10 ms frame, 5000 ms on a 100 ms frame. Never
hard-code a wait. `qualification_ms()` / `recovery_ms()` live in `canc_config` (moved
there from `cannm_config` at the user's request, because these are CAN-C faults).

DTC status bytes: `0x8B` active, `0x0B` active with warning lamp off, `0x08` historic.
A pre-crash fault is healed at T0, so by the time the DTC is read it is **historic**; a
fault still present reads **active_WLOFF**.

---

## 3. Commands

Generate (writes into the project and rebuilds the runner):

```
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project U171  --clean
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project ICE_01 --clean
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project EV_01  --clean
```

Review build — render a subset somewhere else, leaving the project untouched (the runner
is deliberately *not* rebuilt in this mode, so a partial build cannot leave the project
unable to run the rest):

```
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project U171 \
    --only '^SUBS_EDR_Element_ID_VehSpdLgt_TestCase_7_5$' \
    --output-directory <somewhere>
```

Static audit — parses each script, checks every identity field, resolves every config
lookup, and confirms every global name exists in the namespace the script will actually
run in:

```
py -3.14 tools/audit_edr_canc_scripts.py U171 [SCRIPT_DIRECTORY]
```

Independent check of the configuration against the diagnostic specification. It
re-reads the `EDR_0455_045B` sheet with its own parsing and compares the result
against `edr_config` as it stands, sharing no code with the builder, so a mistake in
the builder cannot hide:

```
py -3.14 tools/verify_edr_config_against_spec.py [PROJECT ...]
```

Sample report, to look at the theme without a bench:

```
py -3.14 tools/preview_report_theme.py [OUTPUT_DIRECTORY]
```

Modelled ECU — replays each script against a model that derives the record from the
bench actions, so it catches semantic errors the audit cannot:

```
py -3.14 tools/simulate_edr_bench.py --project U171 --match "" \
    [--scripts <dir>] [--out <dir>]
```

Verdicts: `PASSED`, `FAILED`, `PARTIAL` (record content is determined by ECU calibration
the model deliberately does not carry — startup faults, ECU-transmitted signals),
`ERROR`.

HTML review page:

```
py -3.14 tools/render_edr_review.py --project U171 \
    --run test_results/U171/simulated/run.json
```

Published review (vehicle-speed run, acting as the ECU):
<https://claude.ai/code/artifact/2473ce70-126e-48d8-ad03-decb5e0576bc>

---

## 4. Shape of a generated script

```
imports (ARIA, shared libraries, edr_config, rsu_config, canc_config PROJECT_NAME + star)

def run_test():
    tc_id / tc_name / tc_desc / tc_category / tc_behaviour / tc_priority
    signal under test          <- MAH_CAN_SIGNAL_DEFS[...] in canc_config
    EDR element under test     <- EDR_PARAMETERS_BY_NAME[...] in edr_config
    exception_codes            <- the DBC invalid array
    fault definition           <- only present when the case has a fault
    report and logging         <- create_report_and_logging + aria_reports.add_report_info
    bench bring-up
    per_crash                  <- interval element: same vector into both records
                                  snapshot element: one crash per value
    for each pass of two records (0455, 045B):
        for each record:
            time axis + T0 index      <- build_time_axis_and_t0(..., RSU_T0_OFFSETS)
            fault window              <- pre / post / full, per sample index
            [prime the element]       <- only when the fault is created inside the loop
            for each sample:
                create / heal the fault at its boundary
                drive the value, read it back, compare raw decimal + raw hex + physical
                fire the crash at T0 (+ RSU offset if configured)
            wait the qualification time, read DTCs
            read the record, compare every sample: raw decimal + raw hex + physical
        heal the fault between records
        NVM_Clear_L61()        <- only after BOTH records are verified
    restore the bench
```

Points that were specifically asked for and must not regress:

1. **Both records first, then NVM.** `NVM_Clear_L61()` runs after 0455 *and* 045B have
   been read and compared. Clearing earlier destroys the second record.
2. **Full interval, every case.** Faulty cases still record the whole interval: valid
   values in the un-faulted part, the fault reaction in the faulted part.
3. **Physical and hex, both sides.** Raw decimal, raw hex and physical value are compared
   both on CAN simulation and on EDR output — a wrong scaling and a wrong raw value look
   identical in only one of them.
4. **Whatever is simulated on CAN must come back in the record**, even when the record's
   resolution differs from the CAN signal's. The conversion chain is
   `CAN raw -> physical -> EDR raw`; identity only when the scalings match. Where they do
   not divide evenly, one count either side is accepted and the report says so.
5. **A DBC invalid code is a marker, not a measurement** — recorded as it stands, not
   converted. An out-of-range value *is* a measurement the signal can encode, so it is
   converted like any other; whether the result still fits the field is the point of
   the case.
6. **Trigger at T0.** `RSU_T0_OFFSETS[crash_type]`: 0 fires exactly at T0, any other
   value waits that many ms first, and the same offset shifts the recording time axis.
7. **Fault calls are asserted as calls.** A fault does not always show on the bus
   immediately, so the script asserts the bench call returned without raising — not the
   effect.
8. **DBC units, consistently**, everywhere the physical value is printed.
9. Configs stay project-specific. A supported parameter's signal must exist in that
   project's DBC json, otherwise it is "not configured" — checked wholesale by the
   `NOT_CONFIGURED_RECORDS_FF` script.

---

## 5. Verification chain

Three independent layers. Each has caught real defects the others missed.

1. **Parse** — every generated file compiles.
2. **Static audit** (`tools/audit_edr_canc_scripts.py`) — names, imports, config lookups,
   identity fields. It builds its namespace from `builtins` + what `canc_config`'s
   `__all__` actually exports, and nothing else. **Do not widen that namespace**: adding
   modules the scripts don't star-import is what let a real `NameError` hide twice.
3. **Modelled ECU** (`tools/simulate_edr_bench.py`) — derives the record from the bench
   actions the script performs, then checks it against what the script expects. Because
   it does not read the script's expectations to build the record, it catches semantic
   errors.

Baseline results (unchanged across the style restructure — style changed, behaviour did not):

| Project | Passed | Not modelled | Failed |
|---|---|---|---|
| U171 | 406 | 92 | 3 |
| ICE_01 | 406 | 92 | 3 |
| EV_01 | 582 | 1 | 4 |

---

## 5a. The HTML report theme

`shared_libraries/report_theme.py` holds CSS and nothing else. It starts from
`ApymReportsThemes.theme_light_three` and extends it, and
`create_report_and_logging` hands the result to `ApymReports.add_style()` - the
mechanism apym provides for exactly this. The report's HTML, its classes, its
expand/collapse behaviour and its pass/fail filters are untouched, and nothing
outside apym is used: no web font, no icon set, no external stylesheet or script. A
report has to open from a share on a bench machine with no internet.

Colour is a language, one meaning each: indigo for hierarchy and identity, slate for
data, green for passed, red for failed, amber for commentary. Nothing else is
coloured, so anything coloured means something. The page is built to be read in this
order: overall verdict, passed/failed counts, sections, failed rows, detail.

Two things worth knowing before editing it:

- The report has **no doctype**, so browsers lay it out in **quirks mode** and a
  table does not inherit the body's font size. Every level (`.l1` … `.l6`) must
  state its own size or it falls back to the browser's 16px and the hierarchy reads
  upside down. This was a real bug: `.l2` rendered larger than `.l1`.
- The result column carries the classes `PASSED` / `FAILED` in **upper case**, which
  the base stylesheet never styled; the lower-case `.passed` / `.failed` are used
  for a failed step's obtained value. Both are styled now.

Check any change with `py -3.14 tools/preview_report_theme.py`, which writes a
passing and a failing sample report using the same apym calls a real test makes.
`file://` URLs cannot be opened by the browser tooling; serve the directory
(`py -3.14 -m http.server 8731 --bind 127.0.0.1`) and open it over localhost.

---

## 6. What was done in the last two sessions

**Style restructure to the legacy format** — scripts rebuilt around `run_test()` with
identity fields, everything else read from `canc_config` / `edr_config` at run time.
`ITERATIONS`, `SPEC_NOMINAL_VALUES` and `plan_rows` removed.

**All nested functions removed** (most recent request). `record_raw()` was the only one;
its conversion is now written out at the two places that use it, in a form that also
handles a calibration stating its reaction as a band:

```python
band = expected_can if isinstance(expected_can, tuple) else (expected_can,)
converted = []
conversion_exact = True
for can_raw in band:
    if can_raw in exception_codes:
        converted.append(int(can_raw))
        continue
    precise = ((can_raw * factor + offset) - edr_offset) / edr_scaling
    rounded = int(round(precise))
    converted.append(rounded)
    if abs(precise - rounded) >= 1e-6:
        conversion_exact = False
```

**Dead machinery removed from cases that do not have a fault.** Nominal scripts were
carrying `fault_scope`, `fault_action`, `default_raw`, `fault_from`/`fault_to`,
`retained`, `fault_is_on`, `periodicity`, `can_dtc_status`, `in_fault = False`, a
`print` of a fault they do not have, and an `if driven is None:` branch that reported
"fault active, no value driven" and could never run. All of it now appears only in
scripts that have a fault. A nominal script went 473 → 411 lines. Also removed from every
script: `iteration_started` and `ecu_generated` (assigned, never read).

**Defects found and fixed during verification:**

| Defect | Effect |
|---|---|
| `PROJECT_NAME` undefined | `canc_config` defines it but its `__all__` filtered it out of the star import — `NameError` in every variant-code and signal-never-received script. Fixed with an explicit import. |
| Audit blind to the above | It used `dir(module)` and pulled in modules the scripts don't star-import. Now honours `__all__` and counts only `canc_config`. |
| Priming ran for startup faults | The script claimed it had primed an element that was already dead. Priming is now emitted only for faults created inside the loop. |
| Out-of-range values passed through unconverted | Only the DBC *invalid* array feeds `exception_codes` now. |
| `print` naming a fault in nominal scripts | Would have been a `NameError` in ~200 files. Caught by the audit after the gating change. |
| Duplicated NM block in `projects/U171/config/canc_config.py` | The file held two copies of the network-management block — one from before `tools/nm_qualification.py` used BEGIN/END markers, so `strip()` could never remove it, and a rebuild appended the marked copy alongside it. Values were identical and the later definition won, so nothing was wrong at run time, but the unmarked copy could never be updated by the tool and would have drifted. The unmarked copy was deleted; every NM value and both helpers verified byte-identical before and after. `ICE_01` and `EV_01` never had it. |

**Then, on the user's next pass:**

- `fault_free_profile_classic_can()` replaced by `fault_free_profile()`, which reads
  `CAN_FD_ENABLED` from `project_config` and picks the classic-CAN or CAN-FD profile.
  Naming the classic variant directly applied the wrong profile to a CAN FD project.
- `DIDS = ("0455", "045B")` removed from the scripts. The records come from
  `EDR_RECORD_DIDS` in `edr_config`, derived from `EDR_DIDS`, so a DID change is a
  configuration edit. Adding a record to `EDR_DIDS` means it is read too, and the NVM
  is still cleared only after every record in the pass has been verified.
- **A real configuration error, found by the new independent check.**
  `build_edr_config.py` took a recording interval's `end` from the *last row* of the
  sheet rather than the latest sample time. Three elements list their samples out of
  chronological order, so `Brake switch status` was recorded as ending at 0.0s when
  the sheet gives -5s..+3s over 17 samples. `build_time_axis_and_t0` reads
  `data_samples_number` and was unaffected, but `get_sample_range()` returns the list
  by walking `start` to `end`, so it returned 11 of the 17 samples. Fixed at the
  builder by sorting the times, and the out-of-order rows are now reported as an
  anomaly rather than silently smoothed over (see §8).
- The HTML report theme, §5a.
- **The shared library now comes through `import_list`.** Every explicit shared-library
  import was replaced by one star import. Two things were checked before the switch,
  because a star import hides both:
  1. All 33 names the scripts use are reachable through it. `aria_instance` is not,
     but nothing used it - it was an unused import carried from the legacy scripts.
  2. `import_list` star-imports `jscript_translation` late, so it wins for `RESULT`,
     `Sleep`, `Wait`, `CAN` and `PS`. Those are not the objects the scripts imported
     before. They are the same implementations: `ascent_batch_lib.RESULT` is a lazy
     proxy forwarding to `jscript_translation.RESULT`, and `core_functions.Sleep` /
     `Wait` forward there too, so the switch removes an indirection and changes no
     behaviour.
  The audit's namespace was widened to match, and a negative control confirms it
  still catches a misspelled name. A generated script was also imported with the
  real shared libraries (only the ARIA connection stubbed, since no tool runs here)
  and every name it needs resolved.

**Tooling added:** `--only` and `--output-directory` on the generator (review builds),
`--scripts` on the simulator, and the audit promoted from a scratch file into
`tools/audit_edr_canc_scripts.py`.

---

## 7. State right now

All three projects are generated from the current generator and verified:

| Project | Scripts | Parse | Audit | Modelled ECU |
|---|---|---|---|---|
| U171 | 503 | 505/505 | clean | 406 passed / 92 not modelled / 3 failed |
| ICE_01 | 503 | 505/505 | clean | same as U171 |
| EV_01 | 589 | 591/591 | clean | 582 / 1 / 4 |

No nested functions in any of them. Every configured element in all three `edr_config`s
agrees with the `EDR_0455_045B` sheet, with one documented deviation (STS_LOWBEAM).

Test suite: 52 passed, 60 skipped, 2 failed. The two failures are in
`tests/test_crash_configuration.py` and pre-date this work - they track uncommitted
edits under `projects/M310_M314_M110/config/`, and
`shared_libraries/crash_configuration.py` is unmodified against HEAD. Six test
modules cannot be collected because `openpyxl` and `fitz` are missing from the
interpreter that has pytest (`python`, a 3.11 uv venv); the tools themselves run
under `py -3.14`, which has openpyxl.

---

## 8. Open decisions (the user has not answered these)

1. ~~Brake switch status sample order~~ **Answered 2026-09-05.** The OEM confirms
   the `+0.5s`..`+3s` labels on this element are an authoring mistake: it records
   from -5s to T0 only. Applied in `build_edr_config.py` through
   `CONFIRMED_SHEET_ERRORS`, giving 11 samples over -5s..T0, and no post-crash case
   is generated for any element whose interval ends at T0 - a general rule, which
   also caught **Clutch Status**.
   Still open for the other two elements whose rows are out of chronological order:
   **AEB_WARNING_MSG** (transpositions, plus a 0.55s that breaks its own 0.25s grid)
   and **ECALL_PWM_ACK_CRASH** (already excluded as unresolved). For those, byte
   order follows row order, so if the sheet is literal the chronological axis the
   scripts build is wrong for them. The interval bounds are taken from the sorted
   times either way.
2. `recovery_ms` is defined in the NM block but never called anywhere. Either add a
   demature check to the scripts or delete it.
3. **Doors Open Status** — the 5-bit EDR field cannot hold the CAN values 32 and 63.
   The user asked to *keep* length 5 and drive all values so the bug surfaces; it
   currently reports as a failure with an explanatory note. Confirm that is the wanted
   end state.
4. **EV `ACC_PED_TestCase_9_28`** — CAN raw 1023 → 102.3 % → EDR raw 256, one count past
   the 8-bit field. Genuine spec/route conflict, needs a decision.
5. `ICE_01` has no `DEFAULT_VARIANT_CODE` (90 scripts want it).
6. Neither `ICE_01` nor `EV_01` has `SOFTWARE_VERSION_READ_CONFIG`.

---

## 9. Traps that have already cost time

- **Escaped newlines in shell heredocs.** Writing generator patches through a bash
  heredoc silently collapses `\n` inside Python string literals into real newlines,
  producing `SyntaxError: unterminated string literal`. This has happened three times.
  Build such blocks from `NEWLINE = chr(10)` and `repr()` of plain lines, or write the
  patch to a file with an editor tool instead of a heredoc.
- **`__all__` filters star imports.** A name defined in `canc_config` is not visible to
  a generated script unless `__all__` lists it. `tools/nm_qualification.py` extends
  `__all__` for exactly this reason.
- **Star-import order decides who wins.** With `import_list` in play, the last module
  to export a name is the one a script gets. Before assuming two same-named objects
  are interchangeable, check: `is` comparison first, then read both definitions.
  Here they were forwarders, but nothing guarantees that for a name added later.
- **Substring matching on state-value names.** `"fault" in "default value"` is `True`.
  Marker detection in the simulator matches whole words via `re.split`; a substring test
  turned every nominal accel/yaw case into a failure.
- **`IOEM_FRAMEWORK_PROJECT`.** The shared library resolves its project config at import
  time. Any tool that drives a script from outside a project directory must set this
  environment variable first, or it raises "Active project could not be detected".
- **Interpreter.** Use `py -3.14`. The `python` on PATH is a venv missing `openpyxl` and
  `fitz`, which makes six test modules fail at collection — unrelated to this work.
- **Pre-existing test failures.** `tests/test_crash_configuration.py` has two failures
  that trace to uncommitted `projects/M310_M314_M110/config/` edits, not to anything
  here. `shared_libraries/crash_configuration.py` is unmodified against HEAD.
