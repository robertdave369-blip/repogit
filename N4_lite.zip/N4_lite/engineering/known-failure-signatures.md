# Known failure signatures

Recurring ways a test, script or bench run in this repository goes wrong, each with how to recognise it,
how to confirm it and who owns the fix. Used first by `.github/agents/ecu-integration-debugger.agent.md`
and by the triage step of `.github/agents/test-execution-pipeline.agent.md`.

**Status column.** "re-checked 2026-10-26" = the code was looked at on that date and the cause is still
present. "reported 2026-10-22" = taken from `review/Framework_Review_Points.md`, not re-checked since —
re-verify in the current code before relying on it. "fixed" = a dated record says it was corrected.

**Layers** (outermost first): `physical` (wiring, termination, supply) · `bench` (ARIA, loadbox, cards,
restbus) · `apym` · `framework` (`shared_libraries/` wrappers, runners, report verdicts) · `config`
(`projects/<P>/config/`) · `generator` (`tools/generate_*`, templates) · `script` · `test case` ·
`requirement` · `ECU`.

## 1. Verdict integrity — the result itself may be wrong

Check these before analysing any ECU behaviour: they make a failure look like a pass, or the reverse.

| ID | Signature (what you see) | Layer | Cause | How to confirm | Owner / fix | Source | Status |
|---|---|---|---|---|---|---|---|
| KFS-01 | Runner summary says PASSED, the HTML report says FAILED | framework | Runners judge the subprocess **exit code**; scripts do not exit with the report verdict | Open the report; look for `returncode == 0` in the runner | Runner/generator change (protected path: user decision) | `review/Framework_Review_Points.md` C-01 | re-checked 2026-10-26: 143 `run_*.py` files under `projects/` contain `returncode == 0` |
| KFS-02 | PASSED report for a test that aborted or ran almost no steps | framework / apym | Empty or aborted run produces a PASSED report | Step count in the report; exception in the console | Framework (user decision) | C-02 | reported 2026-10-22 |
| KFS-03 | "No DTC present" pass, but the CAN log shows `7F 19 xx` or a final `7F 19 78` | framework | `Read_DTC` treats an NRC as "no DTC"; availability mask hard-coded `0xCB`; a final 0x78 can be returned as the answer | Raw UDS response in the CAN log | Framework (user decision) | C-03 | re-checked 2026-10-26: `0xCB` header handling still in `Read_DTC` |
| KFS-04 | Flash "succeeds" but the ECU is in boot/garbage state | framework | `Software_Flashing` power-cycles 3 s after starting Memtool asynchronously | Memtool log vs power log timing | Do not use until fixed | C-04 | reported 2026-10-22 |
| KFS-05 | "Frame present" / "frame absent" check contradicts the CAN log | framework | `CAN.ReceiveFrame` = most recent frame ever seen (timestamp ignored); returns an error **string** that `is not None` counts as received | Compare the frame timestamp with the log; check the returned type | Judge from a time-bounded log; wrapper change needs approval | `docs/can-network-management/project-implementation.md` F-03/F-04; review H-01 | re-checked 2026-10-26 (`core_functions.py` `wake_ecu_over_can_nm`) |
| KFS-06 | Steps that can never fail (expected = obtained written by the code) | framework | Tautological verdicts in helpers | Read the helper: is "expected" derived from "obtained"? | Framework | H-08 | reported 2026-10-22 |
| KFS-07 | Old results show PASSED where a wrapper actually failed | framework | Wrapper verdicts (`LogCustomAction` etc.) hid failures before the fix | Result date before 2026-10-22 | Re-run; checker `tools/check_jscript_wrappers_offline.py` | `docs/improvements/jscript-wrapper-review.md` | fixed 2026-10-22 |

## 2. Bench and set-up state

| ID | Signature | Layer | Cause | How to confirm | Owner / fix | Source | Status |
|---|---|---|---|---|---|---|---|
| KFS-08 | ARIA/apym error text ("No available aria host", "Multiple aria instances", "Api level N not supported", "…not found in configuration") | bench / apym | See the message table | Match the message | `aria-bench.agent.md` §21 table, `tools/aria_ctl.py` | `aria-bench.agent.md` §21; `tools/test_task.py` `BENCH_HINTS` | current |
| KFS-09 | Wrapper calls fail oddly although "init OK" was reported | apym / framework | "Already initialized" counted as success; apym marks itself initialised before the handshake | Console: init messages; `aria_ctl.py` status | `aria-bench` runbook | H-06 | reported 2026-10-22 |
| KFS-10 | Failures cascade through a batch after one exception | framework / script | Injected fault or changed frame not restored in teardown; CAN log never stopped | First failing test in the batch; restbus state in the log | Script teardown in `finally`; framework fix needs approval | H-03 | reported 2026-10-22 |
| KFS-11 | Precondition looks fine but later steps fail on security/DTC state | framework | Fault-free profile ignores security-access and write results, no wait after power-on, no DTC check after clear | Report steps of the fault-free profile | Framework (user decision) | H-02 | reported 2026-10-22 |
| KFS-12 | NVM-dependent results flaky across power cycles | framework / ECU | BATT removed before IGN, fixed 4 s off-time, no shutdown/NvM wait | Power log order; repeat with a longer off-time | Framework (user decision) | H-04 (NvM effect is an inference) | reported 2026-10-22 |
| KFS-13 | RSU reset or DTC mask behaves like another project | framework / config | Project data in shared `configuration_control.py` (UPP_EV loadbox for `RSU.ResetRSU`; three availability masks) | Which loadbox/mask the call used | Framework (user decision) | H-05 | reported 2026-10-22 |
| KFS-14 | Values belong to another project | config | Wrong project inferred from the script path, or env override; M210 has its own config since 2026-10-22 | Active project in the console/report; `project_config_loader.py` | Move/run the script from the right project folder | `.github/agents/FRAMEWORK_CORE_AND_DEBUGGING_GUIDE.md` §10.3 | current |
| KFS-15 | CAN wake-up "does not work" in a crash test | script | `load_crash_curves()` power-cycles the ECU with hardware ignition ON, cancelling a wake-up done before it | Order of `load_crash_curves()` and `CAN_Wakeup()` in the script | Wake **after** `load_crash_curves()` | `tools/edr_canc_templates/interval_CAN_NM.py:131` | current |
| KFS-16 | Next test starts awake / in the wrong NM state | script | Wake request (`ACTIVE_WAKEUP_BIT`) left at 1, or released after ignition ON | Last `VCU_CANNM` value before ignition ON | `CAN_Wakeup_Restore()` order (release, then ignition) | `docs/can-network-management/test-case-catalogue.md` common clean-up | current |
| KFS-17 | Stimulated protected frame is ignored or raises a content-failure DTC | script / bench | Changing a signal in an E2E/SecOC-protected frame without valid CRC/counter/MAC | CRC/counter/MAC in the log; content-failure DTC | Use the project's protection handling (`agent_sc3.md` §28) | `docs/can-network-management/project-implementation.md` §2 | current |

## 3. Test design versus ECU behaviour

| ID | Signature | Layer | Cause | How to confirm | Owner / fix | Source | Status |
|---|---|---|---|---|---|---|---|
| KFS-18 | DTC absent or only pending when read | script / test case | Read before qualification time, before the EDR interval ends, or before the NM IGN On Startup Delay (2000 ms) / restart delay after UV/OV/bus-off | Time from fault start to `19 02` in the log vs qualification = count × frame cycle | Wait from config (`agent_sc3.md` §18) | `agent_sc3.md` §13 #7, §2.2 | current |
| KFS-19 | UV/OV DTC expected `0B`, reads `08` | test case | UV/OV DTC stays `08` by project rule | DTC status byte | Expect `08` | `agent_sc3.md` §13 #6, §16.3 | current |
| KFS-20 | Message-timeout test gives the "wrong" on-fail value or DTC | test case / script | Timeout injected on a different frame than the one carrying the signal | Disabled frame vs DBC frame of the signal | Disable the signal's own frame | D-10; `agent_sc3.md` §13 #2 | current |
| KFS-21 | Alive-counter fault fires unexpectedly or never | script / config | Counter range hard-coded instead of the EOL bit (0…15 vs 0…14) | EOL Byte6 Bit2; counter sequence in the log | Range from config/EOL | D-03 | current |
| KFS-22 | EOL / variant-code write "has no effect" | test case | Applied at the next ignition cycle, not immediately | Read back after a power cycle | Add the ignition cycle | `agent_sc3.md` §13 #9 | current |
| KFS-23 | Every test after a crash test fails on DTCs/EDR | ECU state | Deployment locks the ECU: lock DTCs `8B` survive `$14`, EDR locked | Lock DTCs present before the failing test | Order tests; replacement ECU per project rule | `agent_sc3.md` §2.4 | current |
| KFS-24 | NM test expects `SRS_CANNM` and fails in Normal Operation | test case / config | OEM NM sends no NM PDU in Normal Operation / Ready Sleep | Requirement 31234544 | Fix the expectation (NM-DEV-01) | `docs/can-network-management/oem-deviation-matrix.md` | current |
| KFS-25 | Sleep/timeout test off by seconds | config | `cannm_config.py` placeholder timings | Source of the wait values | NM-DEV-13..15, F-01 | `docs/can-network-management/project-implementation.md` F-01 | re-checked 2026-10-26 |
| KFS-26 | Signal-content test cannot fail | test case | Signal has no DBC invalid value | DBC value table | Drop or redesign the case | `agent_sc3.md` §13 #14 | current |

## 4. Tooling and repository

| ID | Signature | Layer | Cause | How to confirm | Owner / fix | Source | Status |
|---|---|---|---|---|---|---|---|
| KFS-27 | A script fix disappears | generator | Hand edit of a generated script, overwritten by the next generation | Script listed in `generated_script_list.json` or written by a `tools/generate_*.py` | Fix the generator | `.github/instructions/40-generators.instructions.md`; routing rule `generated-scripts` | current |
| KFS-28 | Protected-path drift after running tests | harness | Tests importing `shared_libraries/`/`projects/` write `.pyc` | `git status` on protected paths | `PYTHONDONTWRITEBYTECODE=1` | `.github/knowledge/rejections.md` rules index | current |
| KFS-29 | CLI crashes with `UnicodeEncodeError` (cp1252) | tooling | Non-ASCII output without UTF-8 stdout | Traceback | `sys.stdout.reconfigure(encoding="utf-8")` | rejections rules index | current |
| KFS-30 | Values read from Excel are shifted or missing | tooling | Column by index, preview read, or Codebeamer escapes not decoded | Re-read every row by header name | `00-core-engineering.instructions.md` §4 | rejections rules index | current |

## 5. Maintaining this register

Add a row when a failure cause is confirmed (reproduced, or the fix flipped the result) and is likely to
recur. Give it the next KFS number, a source a reader can open, and a status with a date. When a cause is
fixed, change the status to "fixed <date>" with the record of the fix; keep the row, since old results may
still carry it.
