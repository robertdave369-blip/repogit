# CAN-C EDR testing: what runs, what it depends on, and how it works

Written 2026-09-05.

This describes the EDR CAN-C test scripts — the ones that drive a CAN signal, fire a
crash, and check what the ECU recorded in its two event records.

It assumes you can write a Python function and a small class. Everything beyond that is
explained where it first appears. Read section 3 first if you only have ten minutes; it
is the whole idea in one page.

---

## 1. The one-paragraph picture

The ECU records a crash into two **event records**, read over diagnostics as
**DID 0x0455** (record 1) and **DID 0x045B** (record 2). Each record is a long string of
bytes. A given measurement — vehicle speed, brake switch, engine speed — lives at a known
place in those bytes.

A test script does four things:

1. Drives a CAN signal with known values.
2. Fires a crash.
3. Reads the record back over diagnostics.
4. Checks the recorded bytes hold what the driven values should have produced.

Nothing about *which* signal, *which* values, or *where in the record* is written in the
script. All of that is read from two configuration files when the script runs. The script
is the procedure; the configuration is the data.

---

## 2. Every file this depends on

### 2.1 The scripts you run

| What | Path |
|---|---|
| U171 test scripts (511) | `projects/U171/modules/EDR_CANC/scripts/SUBS_EDR_*.py` |
| U171 runner | `projects/U171/modules/EDR_CANC/scripts/run_all_u171_edr_canc_scripts.py` |
| ICE_01 test scripts (511) | `projects/ICE_01/modules/EDR_CANC/scripts/SUBS_EDR_*.py` |
| ICE_01 runner | `projects/ICE_01/modules/EDR_CANC/scripts/run_all_ice_common_scripts.py` |
| EV_01 test scripts (614) | `projects/EV_01/modules/EDR_CANC/scripts/SUBS_EDR_*.py` |
| EV_01 runner | `projects/EV_01/modules/EDR_CANC/scripts/run_all_ev_common_scripts.py` |

**Never edit these by hand.** They are written by a generator (section 7). An edit here is
erased the next time anyone regenerates.

### 2.2 Project configuration — the data a script reads

| What | Path | Holds |
|---|---|---|
| CAN signal configuration | `projects/<PROJECT>/config/canc_config.py` | Which frame and signal, how to encode it, which values to drive, which frames a fault acts on, which DTC each fault raises |
| EDR record configuration | `projects/<PROJECT>/config/edr_config.py` | Where each element sits in the record, how wide, how to convert, how many samples, at what times, and the record DIDs |
| Crash timing offsets | `projects/<PROJECT>/config/rsu_config.py` | `RSU_T0_OFFSETS` — how long after T0 to fire, per crash type |
| Project identity and versions | `projects/<PROJECT>/config/project_config.py` | Project name, EOL code, default variant code, `CAN_FD_ENABLED` |
| Variant code | `projects/<PROJECT>/config/variantcode_config.py` | Node bits used by the variant-code faults |

`<PROJECT>` is `U171`, `ICE_01` or `EV_01`.

### 2.3 Shared library — the functions a script calls

A script imports **one** module, which re-exports all of them:

```
shared_libraries/import_list.py
```

Behind it:

| Module | Path | What a script uses from it |
|---|---|---|
| ARIA bring-up | `shared_libraries/apym_imports.py` | `ensure_apym_on_path()`, `init_aria()` |
| Bench actions | `shared_libraries/core_functions.py` | `create_report_and_logging`, `TriggerCrash`, `Read_DTC`, `load_crash_curves`, `NVM_Clear_L61`, `manage_variant_code`, `fault_free_profile`, `read_software_version`, `resolve_can_log_ids` |
| CAN / power / reporting | `shared_libraries/jscript_translation.py` | `CAN`, `PS`, `RESULT`, `Sleep`, `Wait` |
| Record decoding | `shared_libraries/edr_decoding_functions.py` | `read_edr_parameters`, `edr_sample_records`, `raw_hex`, `raw_signed`, `format_physical`, `report_timestamp` |
| Timing helpers | `shared_libraries/data_conversions.py` | `get_sample_interval_ms`, `build_time_axis_and_t0` |
| Constants | `shared_libraries/configuration_control.py` | `TestStatus`, `Crash_DTC`, `PT_Crash_DTC`, `DTC_status`, `Read_DTC_Req`, `Read_DTC_Resp` |
| Crash types | `shared_libraries/crash_configuration.py` | `CRASH_TYPES` |
| Result object | `shared_libraries/ascent_batch_lib.py` | `RESULT` (a thin forwarder to the one in `jscript_translation`) |
| Report styling | `shared_libraries/report_theme.py` | CSS only; applied automatically |

**A note on `import_list`.** It does `from .<module> import *` for sixteen modules in a
fixed order. When two modules export the same name, **the last one wins**. That is why
`RESULT`, `Sleep`, `Wait`, `CAN` and `PS` come from `jscript_translation`. They behave
identically to the versions in `core_functions` and `ascent_batch_lib`, because those are
thin forwarders to the same objects — but if you ever add a name that two modules define
differently, order decides which one you get.

### 2.4 Source documents — where the configuration comes from

| Source | Path | Supplies |
|---|---|---|
| Diagnostic specification | `docs/project_documents/Common Diag Spec/ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx`, sheet `EDR_0455_045B` | **The only source** for byte positions, field widths, sample counts, sample times, conversions, units, ranges |
| Same workbook, sheet `NetworkMgmtIdentifiers` | as above | Fault detection and recovery counts |
| U171 DBC (ICE) | `project_dbc/u171_dbc/U171_SRS_SVNID39216_20250917_json/U171_SRS_SVNID39216_20250917_signals.json` | CAN encoding for ICE |
| M314 DBC (EV) | `project_dbc/m314_dbc/SRS_FD_40777_json/SRS_FD_40777_signals.json`<br>`project_dbc/m314_dbc/SRS_HSCAN_40250_22042026_json/SRS_HSCAN_40250_22042026_signals.json` | CAN encoding for EV |
| Test case list | `project_testcases/ice_common_spec/EDR/Common_EDR_CANC_0455_045B_U171_M314_v8_authoring.xlsx`, `Sheet1` | Case names, descriptions, categories, steps |
| On-fail calibration | `tests/edr_onfail_policy.json` | What the ECU records while a fault is active |
| DRBFM analysis | `docs/project_documents/DRBFM/EDR_Common_DRBFM/RstEdr_DRBFM.xlsx` | **CAN routes only** — which signal feeds which element. Never byte or timing data. |

### 2.5 Output

| What | Path |
|---|---|
| HTML report | `test_results/<PROJECT>/<YYYY-MM-DD>/<case>_<YYYYMMDD_HHMMSS>.html` |
| CAN log | `test_logs/<PROJECT>/<YYYY-MM-DD>/<case>_<YYYYMMDD_HHMMSS>.txt` |

A new folder per day; a timestamp per run, so re-running never overwrites an earlier
report.

---

## 3. How one script works, line by line

Take `SUBS_EDR_Element_ID_VehSpdLgt_TestCase_6_5.py` — vehicle speed, with a Node Absent
fault covering the post-crash half.

### 3.1 The header

```python
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_PARAMETERS_BY_NAME,
    EDR_RECORD_DIDS,
)
from Framework_IOEM_Py.projects.U171.config.rsu_config import RSU_T0_OFFSETS
from Framework_IOEM_Py.projects.U171.config.canc_config import PROJECT_NAME
from Framework_IOEM_Py.projects.U171.config.canc_config import *
```

`import *` means "bring every public name from that module into this file". The two ARIA
calls connect to the bench tool. `canc_config` is imported with `*` **last**, so where it
and the shared library both define a name, the project's value wins.

> `PROJECT_NAME` is imported by name on the line above the `*`. A module can define
> `__all__`, a list that limits what `import *` hands over; `canc_config` does, and
> `PROJECT_NAME` is not on it. Without the explicit import the scripts would crash with
> `NameError`. If you add a name to `canc_config` and a script cannot see it, this is why.

Everything else lives inside `def run_test():`. There are **no other functions** in the
file — no helper defined inside `run_test`, no lambdas. That is deliberate: the procedure
reads top to bottom.

### 3.2 Reading the configuration

```python
signal_def = MAH_CAN_SIGNAL_DEFS['VEHICLE_SPEED_ESC12']
msg    = signal_def["frame"]        # 'ESC12_10'  — the CAN message
sig    = signal_def["signal"]       # 'VEHICLE_SPEED_ESC12'
factor = signal_def.get("Factor", 1)    # 0.015625
offset = signal_def.get("Offset", 0)    # 0
values = signal_def.get('EDR_CANC_TestCase_6_values')   # the raw values to drive
```

`MAH_CAN_SIGNAL_DEFS` is a **dictionary of dictionaries**: the outer key is a signal name,
and the value is a dictionary describing that signal. Nothing is computed here; the script
is just looking things up.

```python
edr_param = 'Vehicle Speed Longitudinal'
edr_def   = EDR_PARAMETERS_BY_NAME.get(edr_param)
record_samples = edr_def.get("data_samples_number")   # 17
edr_bits       = edr_def.get("data_bit_length")       # 16
edr_scaling    = edr_def.get("scaling_factor", 1)     # 0.015625
edr_offset     = edr_def.get("offset", 0)             # 0.0
```

Same idea for the record side. **The two sides are separate on purpose** — see section 5.

### 3.3 The two conversions

This is the single most important idea in the whole test.

A CAN signal carries an integer, the **raw** value. What it means physically is:

```
physical = raw_can * factor + offset
```

The record stores its own integer, with its own conversion:

```
physical = raw_record * edr_scaling + edr_offset
```

So to predict what the record should hold for a value you drove on CAN, you go through
the physical value in the middle:

```python
precise = ((can_raw * factor + offset) - edr_offset) / edr_scaling
rounded = int(round(precise))
```

For vehicle speed both conversions are 0.015625, so the numbers come out identical. For a
pedal that arrives at 0.1 %/bit in ten bits and is stored at 0.4 %/bit in eight, they do
not — and the record holds a different integer from the one you drove. Getting this right
is why the script never assumes "what I drove is what is recorded".

When the two resolutions do not divide evenly, `precise` is not a whole number. The script
notices, and accepts the stored value if it is within one count.

**One exception.** If the driven value is a DBC *invalid marker* — a code like `65535`
that means "no reading" rather than a measurement — it is stored as-is, not converted.
`exception_codes` holds those codes. An out-of-range value is *not* an exception: it is a
real measurement the signal should not be carrying, so it is converted like any other, and
whether the result still fits the record's field is exactly what those cases test.

### 3.4 The time axis

```python
time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
```

This returns a list of the instants each sample is recorded at, built from the element's
`sample_range` — for vehicle speed, `start -5.0, end 3.0, step 0.5`, giving
`[-5.0, -4.5, ..., 0.0, ..., 3.0]`, 17 entries. `t0_sample_idx` is the position of `0.0`,
so index 10.

`RSU_T0_OFFSETS` can delay the crash for a given crash type. If the offset is `0`, the
crash fires exactly at T0. If it is, say, 200 ms, the script waits 200 ms after the T0
sample before firing, and the same offset shifts the axis so the two stay in step.

### 3.5 The record loop

```python
for pass_start in range(0, len(per_crash), len(EDR_RECORD_DIDS)):
    this_pass = per_crash[pass_start:pass_start + len(EDR_RECORD_DIDS)]
    for record_index, crash_values in enumerate(this_pass):
        did = EDR_RECORD_DIDS[record_index]      # '0455' then '045B'
```

`EDR_RECORD_DIDS` comes from `edr_config`, so a DID change is a configuration edit and no
script is touched.

The ECU holds **two** event records. One pass fires two crashes: the first fills 0x0455,
the second fills 0x045B. **The NVM is cleared only after both have been read and
compared** — clearing earlier destroys the second record before anyone has looked at it.

### 3.6 Driving and reading back

For each sample:

```python
CAN.ChangeSignalValue(msg, sig, str(driven))
Wait(sample_interval_ms)
received = CAN.GetSignalFromFrame(msg, sig)
```

Then it compares what came back three ways — raw decimal, raw hex, and physical value:

```python
RESULT.InterpretEqualResult(f"{sig} raw decimal at index {idx} ({window})",
                            str(received_signed), str(driven))
RESULT.InterpretEqualResult(f"{sig} raw hex at index {idx} ({window})",
                            raw_hex(received_raw, bit_length), raw_hex(driven, bit_length))
RESULT.InterpretEqualResult(f"{sig} physical value in {unit} at index {idx} ({window})",
                            format_physical(received_signed * factor + offset),
                            format_physical(driven * factor + offset))
```

Three comparisons and not one, because a wrong scaling and a wrong raw value look
identical if you only check one of them.

`RESULT.InterpretEqualResult(name, obtained, expected)` writes one row into the HTML
report and marks it passed or failed. `RESULT.LogCustomAction(name, obtained, expected,
status)` does the same when you want to decide pass/fail yourself. `RESULT.InsertComment`
writes a note that is not a pass/fail row.

### 3.7 The crash

```python
if idx == trigger_idx:
    if t0_offset_ms:
        Wait(t0_offset_ms)
    TriggerCrash()
    crash_reference = time.monotonic()
```

`trigger_idx` is the sample at T0. The sample at T0 is driven over the window *ending* at
T0, so the crash fires once that window has elapsed — not one sample early.

`crash_reference` is kept so later report lines can be timestamped relative to the crash
(`+0.512s`) rather than as wall-clock time.

### 3.8 Reading the record back

```python
edr_read = read_edr_parameters([edr_param], did=did, crash_type=crash_type, return_data=True)
response_bytes = edr_read.get("data", [])
samples = edr_sample_records(edr_param, response_bytes)
```

`edr_sample_records` splits the raw response into one entry per sample using the element's
own definition, and returns them all in the same shape whatever the packing:

```python
[{"index": 0, "raw": 1, "hex": "0x1", "physical": 1.0}, ...]
```

> **Byte numbering.** A diagnostic response opens with a three-byte positive-response
> header (`62 04 55`) before payload byte 0, and the reader indexes from 1. So a byte the
> specification calls `b` is read at `b + 4`. `edr_config` already stores the adjusted
> number — you do not add anything yourself.

Then each recorded sample is compared, again three ways, against the expected raw computed
in 3.3.

### 3.9 Cleaning up

```python
NVM_Clear_L61()      # after both records are verified
...
CAN.ChangeSignalValue(msg, sig, "0")
CAN.ReloadDefaultPeriodicFrame(msg)
fault_free_profile()
aria_reports.write_to_file()
```

`fault_free_profile()` reads `CAN_FD_ENABLED` from `project_config` and applies the
classic-CAN or CAN-FD profile accordingly — which is why scripts call it rather than
`fault_free_profile_classic_can()` directly.

---

## 4. The categories

Every script follows section 3. What changes between categories is a small, well-defined
part of it.

### 4.1 Nominal, interval element

The plain case. No fault. The element records a series of samples across a window
(`recording_model: "interval"`).

- `values` holds one value per recorded sample — 17 for vehicle speed.
- Both records get the same vector, so one pass of two crashes covers the case.
- Expected recorded value = the driven value put through the conversion in 3.3.

A nominal script contains **no fault machinery at all**: no `fault_scope`, no
`fault_action`, no `in_fault`. Those lines are only emitted for cases that have a fault.

### 4.2 Nominal, snapshot element

A snapshot element records **one value, at T0** (`recording_model: "snapshot"`,
`data_samples_number: 1`). Battery voltage, odometer, doors-open status.

Because only one value is stored per crash, testing several values needs several crashes:

```python
per_crash = [[value] for value in values]     # one crash per value
```

With three values that is three crashes. The pass loop still takes two at a time, so:

| Iteration | Record | What is recorded |
|---|---|---|
| 1 | 0x0455 | value 1 |
| 2 | 0x045B | value 2 |
| — | NVM cleared | both verified |
| 3 | 0x0455 | value 3 |

The specification states this per iteration, e.g.:

```
Recorded at: T0
Iteration 1: EDR1 (0x0455) and EDR2 (0x045B) each record raw 0x0001 (1 decimal, 0.015625 kmph).
Iteration 2: EDR1 (0x0455) and EDR2 (0x045B) each record raw 0x2580 (9600 decimal, 150 kmph).
```

### 4.3 Fault cases

A fault case adds three things: which part of the interval the fault covers, how the fault
is created and healed, and what the record is expected to hold while it is active.

**Scope** — `fault_scope` is `'pre'`, `'post'` or `'full'`:

```python
if fault_scope == "pre":
    fault_from, fault_to = 0, t0_sample_idx                    # up to T0
elif fault_scope == "post":
    fault_from, fault_to = t0_sample_idx + 1, len(crash_values) # after T0
else:
    fault_from, fault_to = 0, len(crash_values)                 # the whole interval
```

For each sample the script asks `fault_from <= idx < fault_to`. That one flag drives
everything, so the pre, post and full variants are the same code path.

**Reaction** — `fault_action` says what the record should hold while the fault is active.
It comes from the on-fail calibration, not from the fault family, because the same fault
behaves differently on different signals:

| `fault_action` | Meaning |
|---|---|
| `last_valid` | The element keeps the last value it received before the fault |
| `consume` | The signal keeps transmitting, so the value on the bus is recorded |
| `default` | A configured default value is recorded |

**Priming.** For `last_valid` to mean anything, the element must have received something
first. When a fault covers the very first sample, the script drives one valid value and
waits before creating the fault, so "the last value received" is known. This is emitted
**only** for faults created inside the loop — a fault that exists before the interval
starts has nothing to prime.

**The families:**

| Family | How it is created | Healed by |
|---|---|---|
| `node_absent` | `CAN.PeriodicDisableFrame(key_frame)` — stop the node's key message | `ReloadDefaultPeriodicFrame` |
| `message_timeout` | `CAN.PeriodicDisableFrame(timeout_frame)` — stop the frame carrying the signal | `ReloadDefaultPeriodicFrame` |
| `message_content` | `CAN.DisableSignal(msg, integrity_signal)` — break the CRC or alive counter | `EnableSignal` |
| `signal_content` | Drive the signal's own invalid code — no separate action | the next valid value |
| `signal_never_received` | Clear the node bit in the variant code, then power cycle — **before** the interval | restore the bit |
| `variant_code_error` | Disable the variant code, then one ignition cycle — **before** the interval | restore it |

The frames come from `signal_def["fault_logic"]`:

```python
fault_logic = signal_def["fault_logic"]
key_frame     = fault_logic["key_message"]            # 'ESC5_10'
timeout_frame = fault_logic.get("non_key_timeout_frame")  # 'ESC12_10'
```

Note these differ. Node Absent stops the **node's key message**; Message Timeout stops the
**frame carrying the signal**. On this signal those are two different frames.

**Asserting the fault.** The script does not assert that the fault appeared on the bus —
a timeout needs its qualification time to elapse first. What it asserts is that the bench
call returned without raising:

```python
try:
    CAN.PeriodicDisableFrame(key_frame)
    fault_call_error = None
except Exception as raised:
    fault_call_error = raised
RESULT.LogCustomAction(..., TestStatus.Passed if fault_call_error is None else TestStatus.Failed)
```

**Qualification time.** A DTC does not appear the instant a fault does. The ECU counts
consecutive bad message periods, so the time depends on how fast the frame is:

```
qualification_ms = detection_threshold x frame_cycle_time_ms
recovery_ms      = recovery_threshold  x frame_cycle_time_ms
```

Node Absent is 50 periods: 500 ms on a 10 ms frame, 5000 ms on a 100 ms one. Never
hard-code a wait — call `qualification_ms(fault_mode, periodicity)`, which lives in
`canc_config`.

**DTC status.** A fault still present reads active-with-lamp-off (`0x0B`). A pre-crash
fault is healed at T0, so by the time the DTC is read it is historic (`0x08`). Crash DTCs
are always active (`0x8B`).

### 4.4 DBC exception cases

These drive the signal's own invalid or reserved codes rather than a nominal sweep:

```python
codes = signal_def.get('EDR_CANC_TestCase_6_Invalid_Values')
per_crash = [[code] * max(1, record_samples) for code in codes]
```

One crash per code, the code held across the whole interval. As noted in 3.3, an invalid
marker is recorded as-is, not converted.

### 4.5 Whole-record checks

Two per project, and they check the record as a whole rather than one element:

| Script | Checks |
|---|---|
| `SUBS_EDR_RESERVED_BYTES_RECORD_00_TestCase_*` | Every reserved byte and bit records `0x00` |
| `SUBS_EDR_NOT_CONFIGURED_RECORDS_FF_TestCase_*` | Every allocation with no CAN route on this variant records `0xFF` |

### 4.6 What is deliberately not tested

A signal the ACU **transmits itself** cannot be driven by a bench — it is the ECU's own
output. Routes on `SRS1_20` (0x2C0, ICE) and `SRS1_FD_10` (0x13C, EV) are therefore not
turned into cases at all. This is decided per route, not per element: yaw rate, lateral
and longitudinal acceleration are external inputs on ICE but ECU outputs on EV, so they
have ICE cases and no EV ones.

---

## 5. How `canc_config` and `edr_config` relate

They describe the **two ends of the same measurement**, and they are separate because they
come from different authorities and can legitimately disagree.

```
    CAN bus                    ECU                     event record
       │                        │                           │
  canc_config             (records it)                 edr_config
  frame, signal,                                  byte position, width,
  factor, offset,                                 samples, times,
  values to drive                                 scaling, offset
```

| | `canc_config` | `edr_config` |
|---|---|---|
| Describes | The CAN input | The recorded output |
| Authority | The project DBC | The diagnostic specification, sheet `EDR_0455_045B` |
| Built by | `tools/annotate_u171_canc_config.py` (U171), `tools/build_ice01_canc_config.py` (ICE_01, EV_01) | `tools/build_edr_config.py` |
| Key lookup | `MAH_CAN_SIGNAL_DEFS["<signal name>"]` | `EDR_PARAMETERS_BY_NAME["<element name>"]` |

**The link between them** is the `EDR_Parameter` field in a signal definition:

```python
MAH_CAN_SIGNAL_DEFS["VEHICLE_SPEED_ESC12"]["EDR_Parameter"]  ->  "VehSpdLgt"
```

A generated script does not follow that link at run time — the generator has already
resolved it and written both the signal key and the element name into the script. But it
is what ties the two files together, and it is what the tooling uses.

Side by side for vehicle speed:

```python
# canc_config — the CAN side
{'frame': 'ESC12_10', 'signal': 'VEHICLE_SPEED_ESC12', 'periodicity': 10,
 'Factor': 0.015625, 'Offset': 0, 'UNIT': 'kmph', 'bit_length': 16,
 'EDR_CANC_TestCase_6_values': [1, 1201, 2401, ...],
 'fault_logic': {'key_message': 'ESC5_10', 'non_key_timeout_frame': 'ESC12_10', ...}}

# edr_config — the record side
{'name': 'Vehicle Speed Longitudinal', 'type': 'multi_sample_bytes',
 'data_start_byte': 34, 'data_end_byte': 67, 'data_bit_length': 16,
 'data_samples_number': 17, 'scaling_factor': 0.015625, 'offset': 0.0,
 'sample_range': {'start': -5.0, 'end': 3.0, 'step': 0.5},
 'recording_model': 'interval'}
```

Here the two conversions match, so the driven raw and the recorded raw are the same
number. That is a coincidence of this signal, not a rule.

**The value arrays are sized by the record.** `EDR_CANC_TestCase_<n>_values` in
`canc_config` holds one value per recorded sample for an interval element — so the
`canc_config` builders read `data_samples_number` out of `edr_config` when they write
them. That is why the build order matters (section 7.2).

**`type` tells the decoder how to split the bytes:**

| `type` | Meaning |
|---|---|
| `multi_sample_bytes` | Several samples, each a whole number of bytes, big-endian |
| `multi_sample_bits` | Several samples packed into bits, most-significant first |
| `int` | One whole-integer value |
| `bits` / `bit` | A sub-byte field; `range` gives the position |
| `custom_bits` | A field whose layout does not follow the regular packing (one element) |

---

## 6. The report

`create_report_and_logging(...)` in `shared_libraries/core_functions.py` opens the report
and starts the CAN log. Two behaviours worth knowing:

- **The report is written as each step is added** (`direct_write=True`, the default). A run
  that is stopped or that raises still leaves a readable report. With it off, everything is
  held in memory until the closing `write_to_file()`, which is how an interrupted run used
  to leave a 0 KB file.
- **CAN log filtering.** The scripts pass `can_ids=resolve_can_log_ids([signal_def])`, which
  is the project's baseline IDs plus the frames under test. If a caller passes `None`
  instead, no filter is applied and **every ID on the selected channels is logged**.

Styling is `shared_libraries/report_theme.py` — CSS only, applied through apym's own
`add_style()`. Colour means one thing each: indigo for hierarchy, slate for data, green
passed, red failed, amber for commentary.

---

## 7. How the scripts are built

### 7.1 The generator

```
tools/generate_ice01_edr_canc_scripts.py
```

```
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project U171  --clean
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project ICE_01 --clean
py -3.14 tools/generate_ice01_edr_canc_scripts.py --project EV_01  --clean
```

It reads the case list, resolves each case to a signal and an element, and writes one file
per case from a single template. `--only '<regex>'` with `--output-directory <path>`
renders a subset elsewhere for review without touching the project.

**Edit the generator, never the generated scripts.**

### 7.2 The full chain, and the order it must run in

```
  diagnostic spec  ─┐
                    ├─► build_edr_config.py      ─► edr_config.py
  DBC json ─────────┤
                    ├─► annotate_u171_canc_config.py  ─► canc_config.py   (U171)
  DRBFM routes ─────┤   build_ice01_canc_config.py    ─► canc_config.py   (ICE_01, EV_01)
                    │
  authoring spec ───┴─► generate_ice01_edr_canc_scripts.py ─► SUBS_EDR_*.py
```

**Order matters.** Each stage reads the one above it:

1. `tests/test_common_edr_canc_specification.py --generate --version vN` — the case list
2. `tools/build_edr_config.py --project <P>` — the record layout
3. `tools/annotate_u171_canc_config.py` / `tools/build_ice01_canc_config.py` — the CAN side
   and the value arrays, which are sized from `edr_config`
4. `tools/generate_ice01_edr_canc_scripts.py --project <P> --clean` — the scripts

Running these out of order produces stale value arrays and audit failures that look
mysterious. If case numbering changed, all four must run.

### 7.3 Supporting tools

| Tool | Path | Does |
|---|---|---|
| Case list and spec workbooks | `tests/test_common_edr_canc_specification.py` | Builds the authoring workbook and evidence package |
| On-fail policy | `tools/build_edr_onfail_policy.py` | The calibration behind `fault_action` |
| Route substitutions | `tools/edr_route_overrides.py` | Where the resolved signal cannot carry what the element records |
| NM block | `tools/nm_qualification.py` | The qualification/recovery block emitted into each `canc_config` |

---

## 8. Checking your work

Three independent layers. Each has caught real defects the others missed — use all three.

| Tool | Command | Catches |
|---|---|---|
| Static audit | `py -3.14 tools/audit_edr_canc_scripts.py <PROJECT> [DIR]` | Undefined names, failed imports, missing config entries, value arrays that do not match the record |
| Modelled ECU | `py -3.14 tools/simulate_edr_bench.py --project <PROJECT> --match ""` | Semantic errors — it derives the record from the bench actions and compares against what the script expects |
| Spec check | `py -3.14 tools/verify_edr_config_against_spec.py` | Re-reads the diagnostic specification with its own parser and compares to `edr_config` |
| Report preview | `py -3.14 tools/preview_report_theme.py` | A sample report to look at without a bench |

Simulator verdicts: `PASSED`; `FAILED`; `PARTIAL` — the record depends on ECU calibration
the model deliberately does not carry; `ERROR` — the script would not run.

---

## 9. Things that will bite you

- **`__all__` filters `import *`.** A name in `canc_config` that is not in its `__all__`
  never reaches a script. This is why `PROJECT_NAME` is imported explicitly.
- **Star-import order decides who wins.** `import_list` imports sixteen modules; the last
  one to define a name provides it. Check with `is` before assuming two same-named objects
  are the same thing.
- **`IOEM_FRAMEWORK_PROJECT`.** The shared library resolves its project config at import
  time. Any tool run from outside a project directory must set this environment variable
  or it raises "Active project could not be detected".
- **Use `py -3.14`.** The `python` on `PATH` is a 3.11 virtual environment without
  `openpyxl`, and `tests/test_common_edr_canc_specification.py` needs 3.12+ to parse at all.
- **Build order.** Section 7.2. Most "impossible" audit failures are a stale `canc_config`.
- **A locked workbook.** If a spec workbook is open in Excel or LibreOffice, the generator
  fails with `PermissionError` and leaves a `.tmp.xlsx` behind. Close it and delete the temp
  file.
