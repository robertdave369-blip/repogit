import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import (
    EDR_UPP_PARAMETERS,
    build_time_axis_and_t0,
    get_sample_interval_ms,
)

def run_test():
    tc_id = "22.9"
    tc_desc = (
        "EsaSysSts1 node-absent scenario: send first non-zero value, disable key message (simulate node absent), "
        "continue CAN simulation with actual values, trigger crash at T0, verify EDR latches non-zero value in all samples after fault, and DTCs are set."
    )

    param_def = MAH_CAN_SIGNAL_DEFS["ESA_SYS_STS1"]
    msg = param_def["frame"]            # key message
    sig = param_def["signal"]           # signal name
    periodicity = param_def["periodicity"]
    values = param_def["TestCase_22_values"]
    edr_param = param_def["EDR_Parameter"]
    edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = param_def.get("Factor", 1)
    offset = param_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    fault_logic = param_def["fault_logic"]
    # Get the key message for node absent scenario
    key_message = fault_logic.get("key_message")
    # Get node absent DTC directly from fault_logic
    node_absent_dtc = fault_logic.get("node_absent_dtc")
    combined_can_dtc_final = node_absent_dtc + " " + DTC_status["DTC_active_WLOFF"]
    print(f"Key message for node absent: {key_message}")
    print(f"Node absent DTC: {node_absent_dtc}, combined with WLOFF status: {combined_can_dtc_final}")

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([param_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # Derive time axis and T0 index from definition and RSU offsets
        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis (one sample interval before recording time)
        sample_interval_s = sample_interval_ms / 1000.0  # Convert ms to seconds
        
        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Find first non-zero value index to disable key message after simulating it
        first_nonzero_index = next((i for i, v in enumerate(values) if int(v) != 0), 0)
        disable_index = first_nonzero_index
        latched_raw = values[disable_index] if disable_index < len(values) else values[-1]

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(f"Disable index: {disable_index}")
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"EsaSysSts1 {tc_id}: Send first non-zero value, disable key message '{key_message}' (simulate node absent), "
            "continue CAN simulation with actual values, trigger crash at T0, verify EDR latches non-zero value in all samples after fault."
        )
        disabled_done = False

        # Loop through ALL values - simulate entire duration
        for idx, val in enumerate(values):
            # Get simulation time and recording time for current index
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            # SIMULATION: Always send actual values from the list
            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            
            # Always verify CAN simulation value (before and after fault)
            if not disabled_done:
                fault_status = ""
            else:
                fault_status = " [Node Absent Active - ECU latching]"
                
            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s){fault_status}", 
                str(received_val_int), 
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s){fault_status}", 
                str(received_phys), 
                str(expected_phys))

            # Disable key message (simulate node absent) immediately after first non-zero sample
            if not disabled_done and idx == disable_index:
                RESULT.InsertComment(f"Disabling key CAN message '{key_message}' at index {disable_index} (simulated from {simulation_start_time}s to {recording_time}s) to simulate node absent fault.")
                RESULT.InsertComment(f"ECU will latch value {latched_raw} (physical: {latched_raw * factor + offset}) for all subsequent samples.")
                RESULT.InsertComment(f"CAN simulation continues with actual values from list, but ECU cannot receive them.")
                CAN.PeriodicDisableFrame(key_message)
                disabled_done = True

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                continue

        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters_UPP([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        # EDR verification:
        # - Samples up to and including disable_index: actual values (ECU received them before fault)
        # - Samples after disable_index: latched value (ECU couldn't receive new values due to node absent)
        aria_reports.add_group("EDR Output Verification - Node Absent (Latched Value)")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("EsaSysSts1 Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            
            if i <= disable_index:
                # Before and at fault: expect actual values (ECU received them)
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (before/at fault)"
            else:
                # After fault: expect latched value (ECU couldn't receive new values)
                expected_phys = expected_phys_latched
                description = "latched value (node absent active)"
                
            RESULT.InterpretEqualResult(
                f"ESA SYS STS1 recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys)
            )
        aria_reports.close_group()

    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(key_message)
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()
