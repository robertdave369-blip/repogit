import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import *


def run_test():
    tc_id = "16.10"
    tc_desc = (
        "DoorLockStatus Out of Range (Reserved) scenario (pre-crash): send out of range values for pre-crash samples, "
        "then send valid values from T0 onwards, trigger crash, verify EDR records reserved value in pre-crash and valid values in post-crash. No DTC for reserved values."
    )

    param_def = MAH_CAN_SIGNAL_DEFS["DOOR_LOCK_STATUS"]
    msg = param_def["frame"]
    sig = param_def["signal"]
    periodicity = param_def["periodicity"]
    valid_values = param_def["TestCase_16_values"]
    out_of_range_values = param_def["TestCase_16_OutofRange_Values"]
    edr_param = param_def["EDR_Parameter"]
    edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = param_def.get("Factor", 1)
    offset = param_def.get("Offset", 0)

    if not isinstance(valid_values, list):
        valid_values = [valid_values]
    if not isinstance(out_of_range_values, list):
        out_of_range_values = [out_of_range_values]

    # Out of range value
    out_of_range_raw = out_of_range_values[0]

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([param_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis (one sample interval before recording time)
        sample_interval_s = sample_interval_ms / 1000.0  # Convert ms to seconds
        
        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Correct pre-crash sample identification (negative time values only, i.e., before T0)
        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]  # Only negative time values (before T0)
        num_pre_crash = len(pre_crash_samples)

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Number of pre-crash samples: {num_pre_crash}")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(f"Out of Range raw value: 0x{out_of_range_raw:04X} ({out_of_range_raw})")
        print(f"Total samples: {len(time_axis)}")

        aria_reports.add_group(
            f"DoorLockStatus {tc_id}: Send out of range values (0x{out_of_range_raw:04X}) for pre-crash (up to T0), then valid values from T0 onwards, trigger crash, verify EDR behavior."
        )

        # Loop through ALL samples - simulate entire duration
        for idx in range(len(time_axis)):
            # Get simulation time and recording time for current index
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            # Determine value to send:
            # - Before T0 (pre-crash): send out of range values
            # - From T0 onwards (post-crash): send valid values
            if idx < t0_sample_idx:
                # Pre-crash: send out of range value
                value_to_send = out_of_range_values[idx] if idx < len(out_of_range_values) else out_of_range_raw
                value_type = "Out of Range"
            else:
                # Post-crash: send valid values from T0 point onwards
                value_to_send = valid_values[idx] if idx < len(valid_values) else valid_values[-1]
                value_type = "Valid"

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            
            if value_to_send == out_of_range_raw or value_to_send in out_of_range_values:
                RESULT.InterpretEqualResult(
                    f"Check {sig} set to 0x{value_to_send:04X} - {value_type} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)", 
                    str(received_val_int), 
                    str(value_to_send))
            else:
                RESULT.InterpretEqualResult(
                    f"Check {sig} set to {value_to_send} - {value_type} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)", 
                    str(received_val_int), 
                    str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s) - {value_type}", 
                str(received_phys), 
                str(expected_phys))

            # At T0: transitioning from out of range to valid values
            if idx == t0_sample_idx:
                RESULT.InsertComment(f"Switching from out of range (0x{out_of_range_raw:04X}) to valid values at T0 (index {idx}).")
                RESULT.InsertComment(f"Post-crash samples will record valid values from simulation.")

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                # Continue to next iteration, do not break
                continue

        # After simulation loop completes, wait and read only crash DTCs (no DTC for reserved/out of range)
        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters_UPP([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        # Calculate expected physical value for out of range
        expected_out_of_range = out_of_range_raw * scaling + offset_edr

        # EDR verification:
        # - Pre-crash (before T0): expect out of range value
        # - Post-crash (from T0 onwards): expect valid values
        aria_reports.add_group("EDR Output Verification - Out of Range (Pre-Crash)")
        for i in range(len(time_axis)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("DoorLockStatus Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            
            if i < t0_sample_idx:
                # Pre-crash: expect out of range value
                expected_phys = expected_out_of_range
                description = f"0x{out_of_range_raw:04X} (Out of Range - pre-crash)"
            else:
                # Post-crash: expect valid values
                valid_raw = valid_values[i] if i < len(valid_values) else valid_values[-1]
                expected_phys = valid_raw * scaling + offset_edr
                description = "valid value (post-crash)"
                
            RESULT.InterpretEqualResult(
                f"Door Lock Status recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - expected {description}",
                str(observed),
                str(expected_phys)
            )
        aria_reports.close_group()

    # Cleanup - restore signal and frame
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)
    
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()
