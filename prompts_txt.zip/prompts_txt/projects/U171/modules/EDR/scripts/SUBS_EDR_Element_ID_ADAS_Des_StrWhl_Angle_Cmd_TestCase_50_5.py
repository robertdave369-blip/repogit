import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import (
    EDR_UPP_PARAMETERS,
    build_time_axis_and_t0,
    get_sample_interval_ms,
)

def run_test():
    tc_id = "50.5"
    tc_desc = (
        "ADAS_Des_StrWhl_Angle_Cmd signal never received scenario: disable key node from variant code (simulate signal never received), "
        "send values for full duration (-5.5s to +2.5s simulation -> -5s to +3s recording), trigger crash at T0, verify EDR records 0xFFFE in all samples."
    )

    adas_des_strwhl_angle_cmd_def = MAH_CAN_SIGNAL_DEFS["ADAS_Des_StrWhl_Angle_Cmd"]
    msg = adas_des_strwhl_angle_cmd_def["frame"]
    sig = adas_des_strwhl_angle_cmd_def["signal"]
    periodicity = adas_des_strwhl_angle_cmd_def["periodicity"]
    values = adas_des_strwhl_angle_cmd_def["TestCase_5_values"]
    edr_param = adas_des_strwhl_angle_cmd_def["EDR_Parameter"]
    veh_edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = adas_des_strwhl_angle_cmd_def.get("Factor", 1)
    offset = adas_des_strwhl_angle_cmd_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # Get key node information
    key_message = CAN_TX_MESSAGE_CONFIG[msg]["key_node"]

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([adas_des_strwhl_angle_cmd_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    
    # Disable key node from variant code BEFORE power cycle
    # This simulates "signal never received" - ECU will never receive this signal from startup   
    RESULT.InsertComment(f"Disabling key node '{key_message}' from variant code to simulate 'Signal Never Received' scenario.")
    # enter_ext_session()
    # Internal_Security_Access(0x01)
    manage_variant_code(key_message, "disable", project="UPP_EV", base_from_project_default=True)
    
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"
    
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # Derive time axis and T0 index from definition and RSU offsets
        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis (one sample interval before recording time)
        sample_interval_s = sample_interval_ms / 1000.0

        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Expected EDR value for "Signal Never Received" scenario
        signal_never_received_raw = 0xFFFE  # 65534 in decimal

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(f"Total values to simulate: {len(values)}")
        print(f"Expected EDR value (Signal Never Received): 0xFFFE ({signal_never_received_raw})")

        aria_reports.add_group(
            "ADAS_Des_StrWhl_Angle_Cmd 50.5: Node disabled from variant code (signal never received), send values for full duration (sim: -5.5s to +2.5s -> rec: -5s to +3s), trigger crash at T0, verify EDR records 0xFFFE in all samples."
        )

        # Loop through ALL values - simulate entire duration
        for idx, val in enumerate(values):        
            value_to_send = val
            
            # Get simulation time and recording time for current index
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)", 
                str(received_val_int), 
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s)", 
                str(received_phys), 
                str(expected_phys))

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                # Continue to next iteration, do not break
                continue

        # After simulation loop completes, wait and read only crash DTCs (no CAN fault DTC)
        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash", Read_DTC_Resp + " " + combined_crash_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters_UPP([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = veh_edr_def.get("scaling_factor", 1) if veh_edr_def else 1
        offset_edr = veh_edr_def.get("offset", 0) if veh_edr_def else 0

        # Calculate expected physical value for 0xFFFE
        expected_signal_never_received = signal_never_received_raw * scaling + offset_edr

        # EDR verification:
        # All samples should show 0xFFFE (Signal Never Received) because node was disabled from variant code
        aria_reports.add_group("EDR Output Verification - Signal Never Received")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("ADAS_Des_StrWhl_Angle_Cmd Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            
            # All samples should be 0xFFFE (Signal Never Received)
            RESULT.InterpretEqualResult(
                f"ADAS_Des_StrWhl_Angle_Cmd recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - expected 0xFFFE (Signal Never Received)",
                str(observed),
                str(expected_signal_never_received)
            )
        aria_reports.close_group()

    # Cleanup - restore signal and frame    
    CAN.ChangeSignalValue(msg, sig, "0")
    fault_free_profile_classic_can()
    enter_ext_session()
    # Internal_Security_Access(0x01)
    manage_variant_code(key_message, "enable", project="UPP_EV", base_from_project_default=True)
    CAN.ReloadDefaultPeriodicFrame(msg)
    
    
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()

#display_tracebility(34972737, 34984790)
