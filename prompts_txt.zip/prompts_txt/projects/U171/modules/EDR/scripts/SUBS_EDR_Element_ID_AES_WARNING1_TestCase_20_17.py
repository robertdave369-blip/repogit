import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import *


def run_test():
    tc_id = "20.17"
    tc_desc = (
        "AES_WARNING1 over-voltage scenario (pre-crash): send values up to disable index (half pre-crash samples), "
        "induce over-voltage fault, restore voltage at T0, trigger crash, "
        "verify EDR latches values in pre-crash during fault and normal values in post-crash after fault is cleared."
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["AES_WARNING1"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_20_values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # Over Voltage DTC
    over_voltage_dtc = Over_Voltage + " " + DTC_status["DTC_active"]
    over_voltage_dtc_wloff = Over_Voltage + " " + DTC_status["DTC_active_WLOFF"]
    print(f"Over Voltage DTC: {over_voltage_dtc}")

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"
    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        sample_interval_s = sample_interval_ms / 1000.0
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        num_pre_crash = len(pre_crash_samples)
        
        disable_index = num_pre_crash // 2
        
        if disable_index >= num_pre_crash:
            disable_index = num_pre_crash - 1
        if disable_index < 0:
            disable_index = 0
            
        latched_raw = values[disable_index] if disable_index < len(values) else values[-1]
        
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Pre-crash samples: {pre_crash_samples}")
        print(f"Disable index (fault induced at): {disable_index}")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"AES_WARNING1 {tc_id}: Send values, induce over-voltage at index {disable_index} (pre-crash), "
            f"restore voltage at T0, verify EDR latches values during fault and normal values after fault cleared."
        )
        fault_induced = False
        fault_removed = False

        for idx, val in enumerate(values):
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            
            if not fault_induced:
                fault_status = ""
            elif fault_induced and not fault_removed:
                fault_status = " [Over Voltage Active - ECU latching]"
            else:
                fault_status = " [Fault Cleared - ECU receiving]"
                
            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s){fault_status}", 
                str(received_val_int), 
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s){fault_status}", 
                str(received_phys), 
                str(expected_phys))

            if not fault_induced and idx == disable_index:
                RESULT.InsertComment(f"Inducing over-voltage fault at index {disable_index} (simulated from {simulation_start_time}s to {recording_time}s).")
                RESULT.InsertComment(f"ECU will latch value {latched_raw} (physical: {latched_raw * factor + offset}) until voltage is restored at T0.")
                PS.SetVoltage(21.0)
                fault_induced = True
                

            if idx == trigger_idx:
                RESULT.InsertComment(f"Restoring voltage at T0 (simulated from {simulation_start_time}s to {recording_time}s) to remove over-voltage fault.")
                RESULT.InsertComment(f"Post-crash samples will record normal values from simulation.")
                PS.SetVoltage(12.0)
                fault_removed = True
                #Sleep(1)
                TriggerCrash()
                continue

        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        final_combined_dtc = combined_crash_dtc + " " + over_voltage_dtc_wloff
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters_UPP([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        aria_reports.add_group("EDR Output Verification - Over Voltage (Pre-Crash)")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("AES_WARNING1 Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)
            
            if i <= disable_index:
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (before/at fault)"
            elif i <= t0_sample_idx:
                expected_phys = expected_phys_latched
                description = "latched value (over-voltage active)"
            else:
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (fault cleared)"
                
            RESULT.InterpretEqualResult(
                f"AES_WARNING1 recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys)
            )
        aria_reports.close_group()

    PS.SetVoltage(12.0)
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()
