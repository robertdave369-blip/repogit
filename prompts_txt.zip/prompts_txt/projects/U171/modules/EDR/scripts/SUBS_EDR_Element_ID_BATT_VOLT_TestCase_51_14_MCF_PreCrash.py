import time
from apym.connection import Instance as aria_instance
aria_instance.init()
from apym.reports import ApymReports as aria_reports
from Test_Enviornment.Library.ImportList import *
from Test_Enviornment.Library.CoreFunctions import *
from Test_Enviornment.Library.EDRDataReading_more_generic import *
from Test_Enviornment.Library.CANLibrary import *
from Test_Enviornment.Library.ConfigurationControl import *
import os
from Test_Enviornment.Library.EDR_Parameters_UPP import *


def run_test():
    tc_id = "51.14"
    tc_desc = (
        "BATT_VOLT Message Content Failure (pre-crash only): send values up to disable index "
        "(half pre-crash samples), disable CRC (simulate message content failure), "
        "re-enable CRC at T0, trigger crash, verify EDR latches values in pre-crash "
        "during fault and normal values in post-crash after fault is cleared."
    )

    # ── Signal definition ──────────────────────────────────────────────
    signal_def = MAH_CAN_SIGNAL_DEFS["CAN_BATT_VOLT"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_51_values"]
    edr_param = signal_def["EDR_Parameter"]
    veh_edr_def = next(
        (p for p in EDR_UPP_PARAMETERS if p.get("name") == edr_param), None
    )
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # ── CRC / Message-content-failure specifics (direct from config) ──
    fault_logic = signal_def["fault_logic"]
    key_message = fault_logic.get("key_message")
    mcf_dtcs = fault_logic.get("message_content_failure_dtcs", {})

    crc_frame = signal_def["frame"]
    crc_ch = signal_def["ch"]

    crc_signal_name = None
    crc_dtc_value = None
    for dtc_key, dtc_val in mcf_dtcs.items():
        if "CRC" in dtc_key.upper():
            crc_signal_name = dtc_key
            crc_dtc_value = dtc_val
            break

    if not crc_signal_name:
        raise ValueError(
            f"No CRC entry in message_content_failure_dtcs for '{sig}'. "
            f"Available: {list(mcf_dtcs.keys())}"
        )

    combined_can_dtc_final = crc_dtc_value + " " + DTC_status["DTC_active_WLOFF"]

    print(f"Key message: {key_message}")
    print(f"CRC signal to disable: {crc_signal_name} on frame {crc_frame} ch {crc_ch}")
    print(f"Message content failure DTC: {crc_dtc_value}")
    print(f"Combined DTC (with WLOFF): {combined_can_dtc_final}")

    # ── Report / logging setup ─────────────────────────────────────────
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # ── Time axis ──────────────────────────────────────────────────
        time_axis, T0_INDEX = build_time_axis_and_t0(
            edr_param, crash_type, RSU_T0_OFFSETS
        )
        t0_sample_idx = next(
            (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX
        )
        trigger_idx = t0_sample_idx - 1

        sample_interval_s = sample_interval_ms / 1000.0
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # ── Pre-crash disable index (half of pre-crash samples) ────────
        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        num_pre_crash = len(pre_crash_samples)

        disable_index = num_pre_crash // 2
        if disable_index >= num_pre_crash:
            disable_index = num_pre_crash - 1
        if disable_index < 0:
            disable_index = 0

        latched_raw = (
            values[disable_index] if disable_index < len(values) else values[-1]
        )

        # Debug prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Number of pre-crash samples: {num_pre_crash}")
        print(f"Disable index (fault induced at): {disable_index}")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(
            f"Time at disable_index: "
            f"{time_axis[disable_index] if disable_index < len(time_axis) else 'N/A'}"
        )
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"{sig} {tc_id}: Send values, disable CRC '{crc_signal_name}' on frame "
            f"'{crc_frame}' at index {disable_index} (pre-crash), "
            f"re-enable at T0, verify EDR latches values during fault and "
            f"normal values after fault cleared."
        )
        disabled_done = False
        fault_removed = False

        # ── Simulation loop ────────────────────────────────────────────
        for idx, val in enumerate(values):
            simulation_start_time = (
                simulation_time_axis[idx]
                if idx < len(simulation_time_axis)
                else ((idx * sample_interval_s) - sample_interval_s)
            )
            recording_time = (
                time_axis[idx]
                if idx < len(time_axis)
                else (idx * sample_interval_s)
            )

            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = (
                    int(received_val, 16)
                    if isinstance(received_val, str)
                    and received_val.startswith("0x")
                    else int(received_val)
                )
            except Exception:
                received_val_int = int(received_val)

            if not disabled_done:
                fault_status = ""
            elif disabled_done and not fault_removed:
                fault_status = " [Message Content Failure Active - ECU latching]"
            else:
                fault_status = " [Fault Cleared - ECU receiving]"

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, "
                f"simulated from {simulation_start_time}s to {recording_time}s, "
                f"recorded at {recording_time}s){fault_status}",
                str(received_val_int),
                str(value_to_send),
            )

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value "
                f"(simulated from {simulation_start_time}s to {recording_time}s)"
                f"{fault_status}",
                str(received_phys),
                str(expected_phys),
            )

            # ── Induce fault: disable CRC at pre-crash disable index ──
            if not disabled_done and idx == disable_index:
                RESULT.InsertComment(
                    f"Disabling CRC signal '{crc_signal_name}' on frame "
                    f"'{crc_frame}' ch {crc_ch} at index {disable_index} "
                    f"(simulated from {simulation_start_time}s to "
                    f"{recording_time}s) to simulate message content failure."
                )
                RESULT.InsertComment(
                    f"ECU will latch value {latched_raw} "
                    f"(physical: {latched_raw * factor + offset}) "
                    f"until fault is removed at T0."
                )
                RESULT.InsertComment(
                    "CAN simulation continues with actual values from list, "
                    "but ECU will reject frames due to CRC failure."
                )
                CAN.DisableDynamicSigna(crc_ch, crc_frame, crc_signal_name)
                disabled_done = True
                Sleep(6)
                combined_can_dtc_wloff = (
                    crc_dtc_value + " " + DTC_status["DTC_active_WLOFF"]
                )
                Read_DTC(
                    "Message Content Failure (after fault induced)",
                    Read_DTC_Resp + " " + combined_can_dtc_wloff,
                    Read_DTC_Req,
                )

            # ── At T0: remove fault (re-enable CRC) and trigger crash ─
            if idx == trigger_idx:
                RESULT.InsertComment(
                    f"Re-enabling CRC signal '{crc_signal_name}' on frame "
                    f"'{crc_frame}' ch {crc_ch} at T0 "
                    f"(simulated from {simulation_start_time}s to "
                    f"{recording_time}s) to remove message content failure."
                )
                RESULT.InsertComment(
                    "Post-crash samples will record normal values from simulation."
                )
                CAN.EnableDynamicSigna(crc_ch, crc_frame, crc_signal_name)
                fault_removed = True
                Sleep(1)
                TriggerCrash()
                continue

        # ── Post-simulation DTC verification ───────────────────────────
        Sleep(1)
        combined_crash_dtc = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC(
            "Front Crash ",
            Read_DTC_Resp + " " + final_combined_dtc,
            Read_DTC_Req,
        )
        aria_reports.close_group()

        # ── EDR readout ────────────────────────────────────────────────
        Sleep(5)
        edr_read = read_edr_parameters_UPP(
            [edr_param], did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = (
                edr_read.get("decoded", {}).get(edr_param, []) or []
            )

        scaling = veh_edr_def.get("scaling_factor", 1) if veh_edr_def else 1
        offset_edr = veh_edr_def.get("offset", 0) if veh_edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        # ── EDR verification ───────────────────────────────────────────
        aria_reports.add_group(
            "EDR Output Verification - Message Content Failure (Pre-Crash)"
        )
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction(
                    f"{sig} Decode",
                    f"Missing decoded sample {i}",
                    f"Missing decoded sample {i}",
                    TestStatus.Failed,
                )
                continue

            observed = decoded_samples[i]
            recording_time = (
                time_axis[i]
                if i < len(time_axis)
                else (i * sample_interval_s)
            )
            simulation_start_time = (
                simulation_time_axis[i]
                if i < len(simulation_time_axis)
                else ((i * sample_interval_s) - sample_interval_s)
            )

            if i <= disable_index:
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (before/at fault)"
            elif i <= t0_sample_idx:
                expected_phys = expected_phys_latched
                description = "latched value (message content failure active)"
            else:
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (fault cleared)"

            RESULT.InterpretEqualResult(
                f"{edr_param} recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to "
                f"{recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys),
            )
        aria_reports.close_group()

    # ── Cleanup ────────────────────────────────────────────────────────
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.EnableDynamicSigna(crc_ch, crc_frame, crc_signal_name)
    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
