"""
Module Configuration: EDR
Project: U171
============================================================

Location: projects/U171/config/edr_config.py

Accessed via:
    ctx = FrameworkContext(project="U171", module="<any>")
    ctx.mod_config.<SETTING>                  # if current module is EDR
    ctx.get_module_config("EDR").<SETTING>  # from any other module
"""

# PROJECT_NAME = "U171"
# MODULE_NAME = "EDR"

# ENABLED = True
# TIMEOUT_SECONDS = 30
# RETRY_COUNT = 1

# # ── EDR Settings ──
# EDR_PARAMETERS = {
#     "max_events":         3,
#     "pre_crash_time_ms":  5000,
#     "post_crash_time_ms": 300,
#     "sample_rate_ms":     10,
# }

EDR_DIDS = {
    "EDR_EVENT_1": 0x0455,
    "EDR_EVENT_2": 0x045B,
    # "EDR_EVENT_3": 0x0403,
    # "EDR_STATUS":  0x0410,
    # "EDR_CLEAR":   0x0420,
}

# CRASH_THRESHOLD_G = 8.0
# SIDE_THRESHOLD_G = 4.0
# ROLLOVER_THRESHOLD_DEG = 25.0


Crash_Parameters = [
    ["Life_Time_Event_Number", 4, 7],
    ["Multi_Event_Number", 25, 25],
    ["Squib_Deployment_Status", 358, 359],
    ["TimetoDeploy", 201, 226],
    ["Completion_Status", 227, 227],
    ["200msCompletion_Status", 227, 227],
    ["Crash_Location", 26, 26],
    ["Crash_Record_Lock_Status",26,26],
    ["Time_Btw_Events",228,229],
    ["SRS_ECU_Status",227,227]
]

EDR_PARAMETERS = [
    {
        "name": "LifeTimeEventNb",
        "range": "4-7",
        "type": "int"
    },
    {
        "name": "VehSpdLgtAtTimeZero",
        "range": "8-9",
        "type": "int",
        "scaling_factor": 0.015625,
        "unit": "km/h",
        "signed": False,
        "offset": 0,
        "data_start_byte": 8,
        "data_byte_length": 2
    },
    {
        "name": "BattVolt",
        "range": 10,
        "type": "int",
        "scaling_factor": 0.1,
        "unit": "V",
        "signed": False
    },
    {
        "name": "Odometer",
        "range": "11-13",
        "type": "int",
        "signed": False,
        "scaling_factor": 1,
        "offset": 0,
        "unit": "km",
        "data_start_byte": 11,
        "data_byte_length": 3
    },

    {
        "name": "STS_ENG",
        "data_start_byte": 14,
        "data_byte_length": 1,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": 0,
        "data_bit_length": 3,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": False,
        "sample_range": None
    },
    {
        "name": "DoorsOpenStatus",
        "data_start_byte": 15,
        "data_byte_length": 1,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": 0,
        "data_bit_length": 6,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": False,
        "sample_range": None
    },

    {
        "name": "SRSMalLampOnIGCycle",
        "range": "16-17",
        "type": "int"
    },
    {
        "name": "SRSMalLampOnTime",
        "range": "18-19",
        "type": "int"
    },

    {
        "name": "EventDt",
        "data_start_byte": 20,
        "data_byte_length": 2,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": "date",
        "type": None,
        "signed": None,
        "sample_range": None
    },
    {
        "name": "EventTime",
        "data_start_byte": 22,
        "data_byte_length": 3,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": "time",
        "type": None,
        "signed": None,
        "sample_range": None
    },

    {
        "name": "MultiEventNumber",
        "range": 25,
        "type": "int"
    },
    {
        "name": "CrashLocation",
        "range": 26,
        "type": "int"
    },
    {
        "name": "CrashRecordLockStatus",
        "range": "26.7",
        "type": "bit"
    },
    {
        "name": "IgnCycleCrash",
        "range": "27-30",
        "type": "int"
    },

    {
        "name": "BltLockStateDriver",
        "data_start_byte": None,
        "data_byte_length": None,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": None,
        "sample_range": None
    },
    {
        "name": "BltLockStatePassenger",
        "data_start_byte": None,
        "data_byte_length": None,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": None,
        "sample_range": None
    },

    {
        "name": "SRSMalFunIndicator",
        "range": "31.5",
        "type": "bit"
    },
    {
        "name": "FrntAirbagWarnLampSts (PADI Lamp)",
        "data_start_byte": None,
        "data_byte_length": None,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": None,
        "sample_range": None
    },
    {
        "name": "SeatBltRow2",
        "data_start_byte": None,
        "data_byte_length": None,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": None,
        "sample_range": None
    },
    {
        "name": "CuttoffSwitchFPsngr",
        "data_start_byte": None,
        "data_byte_length": None,
        "data_bytes_per_sample": None,
        "data_samples_number": None,
        "data_start_bit": None,
        "data_bit_length": None,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": None,
        "sample_range": None
    },

    {
        "name": "VehSpdLgt",
        "data_start_byte": 33,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.015625,
        "offset": 0,
        "unit": "km/h",
        "type": None,
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "BRAKE_PEDAL_VALUE",
        "data_start_byte": 67,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {
            "start": -5,
            "end": 3,
            "step": 0.5
        }
    },
    {
        "name": "ACC_PED",
        "data_start_byte": 72,
        "data_byte_length": 17,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.4,
        "offset": 0,
        "unit": "%",
        "type": "multi_sample_bytes",
        "sample_range": {
            "start": -5,
            "end": 3,
            "step": 0.5
        },
        "signed": False
    },

    {
        "name": "Engine_Speed",
        "data_start_byte": 89,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 1,
        "offset": 0,
        "unit": "rpm",
        "type": None,
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "CLUTCH_STS",
        "data_start_byte": 124,
        "data_byte_length": 3,
        "data_bytes_per_sample": 1,
        "data_samples_number": 6,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": False,
        "sample_range": {"start": -5, "end": 0, "step": 1.0}
    },
    {
        "name": "ABS_ACTIVE",
        "data_start_byte": 127,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },

    {
        "name": "STEERING_ABSOLUTE_ANGLE",
        "data_start_byte": 132,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.1,
        "offset": 0,
        "unit": "deg",
        "type": "multi_sample_bytes",
        "signed": True,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "ESC_ACTIVE",
        "data_start_byte": 166,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": None,
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },

    {
        "name": "TimetoDeployCmd",
        "data_start_byte": 171,
        "data_byte_length": 26,
        "data_bytes_per_sample": 2,
        "data_samples_number": 13,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "type": "multi_sample_bytes",
        "signed": False
    },
    {
        "name": "CompletionStatus",
        "range":"195.7",
        "type": "bit"
    },
    {
        "name": "200ms CompletionStatus",
        "range": "195.6",
        "type": "bit"
    },
    {
        "name": "TimeBtwEvents",
        "range": "196-197",
        "type": "int",
        "scaling_factor": 0.5
    },

    {
        "name": "DeltaVLgt",
        "data_start_byte": 192,
        "data_byte_length": 26,
        "data_bytes_per_sample": 1,
        "data_samples_number": 26,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "signed": False
    },
    {
        "name": "DeltaVLat",
        "data_start_byte": 224,
        "data_byte_length": 26,
        "data_bytes_per_sample": 1,
        "data_samples_number": 26,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "signed": False
    },
    {
        "name": "TimeMaxDeltaVLgt",
        "data_start_byte": 250,
        "data_byte_length": 2,
        "data_bytes_per_sample": 2,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "type": "multi_sample_bytes",
        "signed": False
    },
    {
        "name": "TimeMaxDeltaVLat",
        "data_start_byte": 252,
        "data_byte_length": 2,
        "data_bytes_per_sample": 2,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "type": "multi_sample_bytes",
        "signed": False
    },
    {
        "name": "MaxDeltaVLgt",
        "data_start_byte": 254,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "signed": False
    },
    {
        "name": "MaxDeltaVLat",
        "data_start_byte": 255,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 1,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "type": "multi_sample_bytes",
        "signed": False
    },

    {
        "name": "Tyre_Pressure_FL",
        "data_start_byte": 256,
        "data_byte_length": 9,
        "data_bytes_per_sample": 1,
        "data_samples_number": 9,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.25,
        "offset": 0,
        "unit": "psi",
        "type": None,
        "signed": False,
        "sample_range": {"start": -2, "end": 2, "step": 0.5}
    },
    {
        "name": "Tyre_Pressure_FR",
        "data_start_byte": 265,
        "data_byte_length": 9,
        "data_bytes_per_sample": 1,
        "data_samples_number": 9,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.25,
        "offset": 0,
        "unit": "psi",
        "type": None,
        "signed": False,
        "sample_range": {"start": -2, "end": 2, "step": 0.5}
    },
    {
        "name": "Tyre_Pressure_RL",
        "data_start_byte": 274,
        "data_byte_length": 9,
        "data_bytes_per_sample": 1,
        "data_samples_number": 9,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.25,
        "offset": 0,
        "unit": "psi",
        "type": None,
        "signed": False,
        "sample_range": {"start": -2, "end": 2, "step": 0.5}
    },
    {
        "name": "Tyre_Pressure_RR",
        "data_start_byte": 283,
        "data_byte_length": 9,
        "data_bytes_per_sample": 1,
        "data_samples_number": 9,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.25,
        "offset": 0,
        "unit": "psi",
        "type": None,
        "signed": False,
        "sample_range": {"start": -2, "end": 2, "step": 0.5}
    },
    {
        "name": "Master_Cylinder_Pressure",
        "data_start_byte": 292,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.05,
        "offset": -40,
        "unit": "bar",
        "type": "multi_sample_bytes",
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },

    {
        "name": "Squib_Deployment_Status",
        "range": [
            "326.7", "326.6", "326.5", "326.4", "326.3", "326.2", "326.1", "326.0",
        "327.4", "327.3", "327.2", "327.1", "327.0"
        ],
        "type": "custom_bits"
    },
    {
        "name": "GEAR_ACTUAL",
        "data_start_byte": 328,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "signed": False,
        "data_samples_number": 21,
        "type": "multi_sample_bits",
        "sample_range": {"start": -5, "end": 3, "step": 1.0}
    },

    {
        "name": "Door Lock Status",
        "data_start_byte": 333,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "YAW_RATE",
        "data_start_byte": 338,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.005,
        "offset": -163.84,
        "unit": "deg/s",
        "type": "multi_sample_bytes",
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "LATERAL_ACCEL",
        "data_start_byte": 372,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.000127465,
        "offset": -4.1768,
        "unit": "g",
        "type": "multi_sample_bytes",
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "LONG_ACCEL",
        "data_start_byte": 406,
        "data_byte_length": 34,
        "data_bytes_per_sample": 2,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.000127465,
        "offset": -4.1768,
        "unit": "g",
        "type": "multi_sample_bytes",
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },

    {
        "name": "TCS_ACTIVE_IEB",
        "data_start_byte": 440,
        "data_byte_length": 5,
        "data_bytes_per_sample": 1,
        "data_samples_number": 17,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -5, "end": 3, "step": 0.5}
    },
    {
        "name": "AEB_WARNING_MSG1",
        "data_start_byte": 445,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "AEB_FCTA_WARN",
        "data_start_byte": 456,
        "data_byte_length": 3,
        "data_bytes_per_sample": 1,
        "data_samples_number": 11,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },
    {
        "name": "AES_WARNING1",
        "data_start_byte": 459,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },
    {
        "name": "AES_SYS_STS1",
        "data_start_byte": 470,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },
    {
        "name": "ESA_SYS_STS1",
        "data_start_byte": 481,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "LDW_LKA_WARNING1",
        "data_start_byte": 492,
        "data_byte_length": 3,
        "data_bytes_per_sample": 1,
        "data_samples_number": 11,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },

    {
        "name": "ADAS_Des_StrWhl_Angle_Cmd",
        "data_start_byte": 495,
        "data_byte_length": 22,
        "data_bytes_per_sample": 2,
        "data_samples_number": 11,
        "data_start_bit": 0,
        "data_bit_length": 16,
        "scaling_factor": 0.1,
        "offset": -720,
        "unit": "deg",
        "type": "multi_sample_bytes",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },
    {
        "name": "LDW_LKA_SYS_STATE1",
        "data_start_byte": 517,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "LKA_HANDSOFF_DISPLAY_WARNING1",
        "data_start_byte": 528,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 6,
        "data_start_bit": 0,
        "data_bit_length": 1,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 1.0}
    },
    {
        "name": "LCF_SYS_STATE1",
        "data_start_byte": 529,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "SPA_SYS_STATE1",
        "data_start_byte": 540,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "SPA_LCF_HANDS_OFF_WARNING1",
        "data_start_byte": 551,
        "data_byte_length": 3,
        "data_bytes_per_sample": 1,
        "data_samples_number": 11,
        "data_start_bit": 0,
        "data_bit_length": 2,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },
    {
        "name": "ACC_SYS_STATE",
        "data_start_byte": 554,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 22,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "NP_SYS_STS1",
        "data_start_byte": 565,
        "data_byte_length": 6,
        "data_bytes_per_sample": 1,
        "data_samples_number": 11,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    },
    {
        "name": "RMS_MODE_STATE1",
        "data_start_byte": 571,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "LC_PATH_STATE1",
        "data_start_byte": 582,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "ELK_ONCOMING_WARNING1",
        "data_start_byte": 593,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "ELK_SIDE_WARNING1",
        "data_start_byte": 604,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },
    {
        "name": "ELK_OVERTAKING_WARNING1",
        "data_start_byte": 615,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 21,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.25}
    },

    {
        "name": "STS_HIGH_BEAM",
        "data_start_byte": 626,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 6,
        "data_start_bit": 0,
        "data_bit_length": 1,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 1.0}
    },
    {
        "name": "STS_LOW_BEAM",
        "data_start_byte": 627,
        "data_byte_length": 1,
        "data_bytes_per_sample": 1,
        "data_samples_number": 6,
        "data_start_bit": 0,
        "data_bit_length": 1,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",             
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 1.0}
    },
    {
        "name": "STS_TPMS_LED",
        "data_start_byte": 628,
        "data_byte_length": 3,
        "data_bytes_per_sample": 1,
        "data_samples_number": 6,
        "data_start_bit": 0,
        "data_bit_length": 4,
        "scaling_factor": None,
        "offset": None,
        "unit": None,
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 1.0}
    },

    {
        "name": "BATT_VOLT",
        "data_start_byte": 631,
        "data_byte_length": 11,
        "data_bytes_per_sample": 1,
        "data_samples_number": 11,
        "data_start_bit": 0,
        "data_bit_length": 8,
        "scaling_factor": 0.25,
        "offset": 0,
        "unit": "V",
        "type": "multi_sample_bits",
        "signed": False,
        "sample_range": {"start": -3, "end": 2, "step": 0.5}
    }
]
