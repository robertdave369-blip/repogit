"""
Module Configuration: GPO
Project: M210
============================================================

Location: projects/M210/config/gpo_config.py
"""
# Copied from projects/M310_M314_M110 on 2026-10-22 (user: separate configs per DBC);
# M210-specific values still to be confirmed are marked 'M314 value'.

PROJECT_NAME = "M210"
MODULE_NAME = "GPO"



# ── GPO Settings ──

# List of GPO logical names
GPO_Names = [
    "ENS",
    "PAB_ON_LAMP",
    "PAB_OFF_LAMP",
]

# List of supported GPO fault names
gpo_fault_names = [
    "S2B",
    "S2G",
    "OPEN",
]

# Fault status values
fault_status_values = [
    "Active",
    "Healed",
    "Historic",
]

# Crash names
crash_names = [
    "FrontCrash",
    "LeftCrash",
    "RightCrash",
    "RearCrash",
    "UnderstrikeCrash",
]

# Mapping: logical name -> DTC code for GPO fault
DTC_GPO_fault = {
    "PAB_OFF": "0x92 0x10",  # PAB_OFF_LAMP
    "PAB_ON": "0x90 0x24",   # PAB_ON_LAMP
    "ENS": "0x92 0x18",      # ENS
}

# Mapping: fault type -> description
GPO_FaultDescription = {
    "Open": "OPEN",
    "S2B": "BUSS_HI_ON",
    "S2G": "BUSS_HI_ON",
    # The output's rest state (as U171's Gpo_Fault_Description); the Fault_List scripts put an
    # output back to it after a fault (2026-10-22).
    "NoFault": "INHERENT",
}
    
# Mapping: fault type -> code
GPO_FaultStatus = {
    "S2B": "0x12",
    "S2G": "0x11",
    "OPEN": "0x13",
}

# Mapping: fault status -> status code
status_codex = {
    "Active": "0x8B",
    "Healed": "0x0A",
    "Historic": "0x08",
}

# Fault timing configuration
gpo_fault_time = {
    "gpo_faultcounter_offset": 10,
    "Qualification_Time": 2000,
    "Qualification_Tolerance": 10,
    "Dequalification_Time": 4000,
    "Dequalification_Tolerance": 20,
}


# ====================================================================================================
# ENS (crash output): timing, limits and test design of the ENS scripts (modules/ENS/scripts)
# Was projects/M210/config/ens_config.py until 2026-11-13. Only what no other M210 config holds:
# crash sets are in crash_curve_config, CAN signals and the crash signal hold time in canc_config,
# DTC numbers in fault_list_config, IO control (DID F010) in cand_config, voltages in power_config.
# ====================================================================================================

# ── ENS output timing: ECU source EnsMgr_PBCfg.h, EnsMgr_MainFunction at 0.5 ms ──
ENS_TICK_MS = 0.5           # EnsMgr_Swc.arxml PERIOD 5.0E-4
ENS_NORMAL_HIGH_MS = 6.0    # ENSMGR_NORMAL_HIGH_TIME 0x0C ticks
ENS_NORMAL_LOW_MS = 4.0     # ENSMGR_NORMAL_LOW_TIME 0x08 ticks
ENS_CRASH_HIGH_MS = 4.0     # ENSMGR_DEPLOY_HIGH_TIME 0x08 ticks
ENS_CRASH_LOW_MS = 6.0      # ENSMGR_DEPLOY_LOW_TIME 0x0C ticks
ENS_CRASH_MS = 800.0        # ENSMGR_OUTPUT_DURATION_TIMEOUT 1600 ticks
ENS_CAN_UPDATE_MS = 25      # EnsMgr_SlowMainFunction (arxml PERIOD 0.025): crash status on CAN
ENS_WAKEUP_REACTION_MS = 30     # valid / invalid wake-up read in the slow task: one period + one tick

# ── Limits that are test design or not confirmed for M210 ──
ENS_TOLERANCE_MS = ENS_TICK_MS  # one ECU tick either side of every high and low time (test design)
ENS_STEADY_MS = 20.0            # a level longer than two periods is a steady level, not a pulse
# TO BE CONFIRMED FOR M210: longest init pulse after ignition on. EnsMgr has no init timer;
# 450 ms is the M314 family limit (agent_sc3.md), the W610 bench record shows about 135 ms.
ENS_INIT_HIGH_MAX_MS = 450

# ── Lamp card recording ──
ENS_RECORD_MARGIN_MS = 100      # ARIA User Functions 2.4: 50-100 ms more before the samples are read
ENS_CRASH_RECORD_MS = 3000      # a multiple of 500 ms, at most 60000 ms
ENS_LONG_RECORD_MS = 6000       # "exactly one run" checks: 6 s
ENS_BEFORE_CRASH_MS = 500       # normal PWM recorded before the crash is triggered
ENS_NORMAL_PULSES_MIN = 10      # normal pulses required where a normal PWM is graded
ENS_DTC_READ_WAIT_MS = 2000     # after a crash, before the DTCs are read

# ── Crashes ──
ENS_CRASH_SETS = ("front", "left", "right", "rear", "understrike")
ENS_NEAR_SET = "near"
# CRASH_LOCATION of the sets canc_config CAN_SIGNAL_Rx_EXPECTED_VALUES does not list.
# 7 for understrike is the W610 bench record: TO BE CONFIRMED in the M210 DBC.
ENS_CRASH_LOCATION = {"understrike": "0x7"}
# Crash set -> fault_list_config mnemonic of its crash DTC. Inference: the "ECU LOCKED DUE TO ...
# CRASH" DTC is the FltMonr E_CRASH_DETECT_... event (shown for understrike: 0x925200 both).
ENS_CRASH_DTC = {
    "front": "ECU_LOCK_FRONT",
    "left": "ECU_LOCK_LH_SIDE",
    "right": "ECU_LOCK_RH_SIDE",
    "rear": "ECU_LOCK_REAR",
    "understrike": "ECU_LOCK_UNDERSTRIKE",
}
ENS_PRETENSIONER_DTC = "ECU_LOCK_PT_DEPLOY"
# Front set that fires the pretensioners only (ENS-TC-15): none in crash_data yet. Give the
# CRASH_CURVE_CONFIG key here once the set exists; the script reports BLOCKED until then.
ENS_LOW_SEVERITY_FRONT_SET = None
# Front then left, T0 distance (ms) -> CRASH_CURVE_CONFIG key. No 1000 ms set exists.
ENS_MULTI_IMPACT_SETS = {100: "parallel_front_left", 400: "concatenated_front_left", 2000: "multi_front_left"}

# ── Test design: times inside the test cases (ms) ──
ENS_IO_RETURN_AFTER_MS = (300, 100, 700)    # ENS-TC-02: IO control returned this long after its start
ENS_AFTER_IO_CONTROL_MS = 5000              # ENS-TC-02: wait between return-control and the crash
ENS_IO_CRASH_AFTER_MS = 600                 # ENS-TC-17: crash this long after the IO control start
ENS_ACTION_AFTER_CRASH_MS = 200             # ENS-TC-17 / 19: return-control or reset after the crash
ENS_SESSION_TIMEOUT_WAIT_MS = 6000          # ENS-TC-18: S3 server 5 s (ISO 14229-2) + 1 s
ENS_SUPPLY_LOSS_RUNS = (                    # ENS-TC-03: (supply lost, ms after the trigger)
    ("ignition", 50), ("ignition", 200), ("ignition", 600), ("battery", 50), ("battery", 200),
)
ENS_IGNITION_OFF_TIMES_MS = (200, 500, 1000, 2000, 5000, 10000)    # ENS-TC-13
ENS_WAKEUP_CHANGES = 20                     # ENS-TC-14: changes between valid and invalid wake-up
ENS_BATTERY_INTERRUPTION_MS = 100           # ENS-TC-19
ENS_BATTERY_OFF_MS = 30000                  # ENS-TC-21
ENS_BATTERY_CUT_AFTER_CRASH_MS = 1000       # ENS-TC-20 step 4
ENS_CHANGEOVER_RUNS = 20                    # ENS-TC-09: crashes with a free-running trigger
ENS_PIN_CAN_RUNS = 20                       # ENS-TC-26
ENS_LONG_RUN_RECORDINGS = 10                # ENS-TC-25: recordings of the largest lamp card window
ENS_LONG_RUN_RECORD_MS = 60000
ENS_LONG_RUN_GAP_MS = 120000                # 10 recordings over 30 minutes
ENS_DECONFIGURED_FLAT_MS = 1000             # ENS-TC-22: no edge for this long = no PWM
ENS_VOLTAGE_SETTLE_MS = 2000                # ENS-TC-23: after every voltage change
ENS_VOLTAGE_FAULT_WAIT_MS = 10000           # ENS-TC-23: ENS open held during the voltage fault
ENS_VOLTAGE_STEP_V = 0.5                    # ENS-TC-23: ramp step

# ── Crash counters, DID 0458 (named in EnsMgr.c 1020; 5 bytes in the diagnostic specification) ──
ENS_CRASH_COUNTER_READ = "0x22 0x04 0x58"
# Order of the counters in EnsMgr_NvmData. The byte order of the DID is not in the reviewed
# source (DiagMgr): the script reports the position and does not grade it.
ENS_CRASH_COUNTER_ORDER = ("front", "left", "right", "rear", "understrike")

# ── Internal faults (fault_list_config monitor names), read with DID FD39 ──
ENS_FRONTAL_FAULT = "OPS_E_FRONTAL_BAGS_FIRED"
ENS_FRONTAL_INHIBITED_FAULT = "OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBITED"
ENS_LATERAL_FAULT = {"left": "OPS_E_LEFT_LATERAL_AIRBAGS_FIRED", "right": "OPS_E_RIGHT_LATERAL_AIRBAGS_FIRED"}

# ── Test design: supply and recording steps shared by several test cases (ms) ──
ENS_SUPPLY_STEP_MS = 100                    # between battery and ignition, as load_crash_curves
ENS_CURVE_LOAD_WAIT_MS = 2000               # after the RSU curves, before the SPI curves, as load_crash_curves
ENS_AFTER_SECURITY_MS = 50                  # after security access, as the F010 IO-control scripts
ENS_STEADY_RECORD_MS = 2000                 # recording of a PWM or a steady level without a crash
ENS_WAKEUP_OFF_MS = 1000                    # ENS-TC-14: ignition off time of one valid / invalid change
ENS_CRASH_AFTER_IGNITION_OFF_MS = 1000      # ENS-TC-13: off time of the cycle before the crash
ENS_IGNITION_CYCLES = 3                     # ENS-TC-21
ENS_STEERING_POSITIONS = ("LHD", "RHD")     # ENS-TC-30: SteeringWheelPosition_Config values; the first is restored
ENS_INIT_RUNS = 5                           # ENS-TC-31 / 32: starts timed
ENS_BEFORE_SUPPLY_MS = 300                  # ENS-TC-31 / 32: recording before ignition on / the CAN_Wakeup call


# ====================================================================================================
# LAMPS (warning lamp, PAB ON / OFF lamps): test design of the Lamps scripts (modules/LAMPS/scripts)
# Was projects/M210/config/lamps_config.py until 2026-11-13. Only what no other M210 config holds:
# lamp, squib, satellite and node-absent faults are in fault_list_config, CAN signals, the warning
# lamp DID and the prove-out time in canc_config, IO-control requests in cand_config.
# ====================================================================================================

# ── Lamp outputs ──
LAMPS_OUTPUTS = ("PAB_OFF", "PAB_ON")       # gpo_config DTC_GPO_fault names of the two lamp outputs
# EOL bit (eol_config) that configures each output. The pairs are those of the eol_config
# configuration-error DTC table (9210 / 9024 / 9218).
LAMPS_EOL_BIT = {"PAB_OFF": "PABD_LAMP_HW", "PAB_ON": "PAB_ENABLE", "ENS": "CRASH_OUTPUT_HW_LINE"}
# DID 044A (cand_config decode table): byte 0 bit 0 PAB ON lamp, bit 1 PAB OFF lamp, bytes 1 and 2
# the fault status of the PAB ON and PAB OFF lamp.
LAMPS_PAB_STATUS_READ = "0x22 0x04 0x4A"
# TO BE CONFIRMED FOR M210: lamp IO-control DIDs. From the common diagnostic specification
# (ICE_COMMON_SRS_V1.6, IOControl): F011 warning lamp, F012 PAB disable indicator, F013 PAB enable
# indicator; the M210 specification V3.4 was read for F010 only.
LAMPS_IO_CONTROL_DID = {"warning lamp": "F011", "PAB_OFF": "F012", "PAB_ON": "F013"}

# ── Faults used to light the lamp (test design) ──
LAMPS_SATELLITE = "A_PILLAR_LEFT_S1"        # LMP-TC-11: fault_list_config RSU_FAULT_BY_SATELLITE key (latched lamp)
LAMPS_NO_LAMP_FRAME = "EPS1_FD_10"          # LMP-TC-16: key frame of the EPS node (canc_config fault_logic)
LAMPS_NO_LAMP_FAULT = "FM_EPS_NODE_ABSENT"  # LMP-TC-16: its fault_list_config entry (no warning lamp, P31 table)
LAMPS_SWITCH_FAULT = "FM_HPCC_NODE_ABSENT"  # LMP-TC-20: node-absent fault of the PAB switch frame (HPCC_1_100)

# ── Test design: times inside the test cases (ms) ──
LAMPS_CRASH_READS_MS = (1000, 10000, 60000)     # LMP-TC-01 / 02: lamp read this long after the crash
LAMPS_STEADY_WATCH_MS = 3000                    # lamp read every frame for this long: steady, not flashing
LAMPS_IGNITION_CYCLES = 20                      # LMP-TC-03 (off times: gpo_config ENS_IGNITION_OFF_TIMES_MS)
LAMPS_BATTERY_OFF_MS = (1000, 5000, 10000, 30000, 60000)    # LMP-TC-03
LAMPS_NO_WAKEUP_MS = 10000                      # LMP-TC-04 / 14: battery on without ignition and CAN
LAMPS_PROVEOUT_WATCH_MS = 15000                 # LMP-TC-04 / 18: lamp watched from the start
LAMPS_AFTER_CLEAR_MS = 5000                     # LMP-TC-05: second read after clear DTC
LAMPS_EARLY_READ_MS = 500                       # DTC read this long before a qualification / heal time ends
LAMPS_VOLTAGE_FAULTS = ("OPEN", "S2G")          # LMP-TC-08: lamp faults applied during the voltage fault
LAMPS_LATCH_HOLD_MS = 10000                     # LMP-TC-11: wait after the latched-lamp fault is removed
LAMPS_SWITCH_SETTLE_MS = 2000                   # LMP-TC-19: after a change of the PAB switch signal
LAMPS_SWITCH_POLL_MS = 50                       # LMP-TC-19: lamp loop read every ... while timing the change
LAMPS_SWITCH_TOGGLES = 20                       # LMP-TC-19
LAMPS_SWITCH_TOGGLE_MS = 200                    # LMP-TC-19
LAMPS_CONNECT_READ_MS = 500                     # LMP-TC-14: DTC read every ...
LAMPS_CONNECT_WATCH_MS = 10000                  # LMP-TC-14: ... for this long after the start
LAMPS_CONTROL_DTC_WAIT_MS = 10000               # LMP-TC-15: fault held with the DTC setting off
LAMPS_TESTER_PRESENT_MS = 2000                  # LMP-TC-15: TesterPresent period (S3 server 5 s, ISO 14229-2)
LAMPS_UNUSED_GPO_WAIT_MS = 60000                # LMP-TC-17
LAMPS_LONG_FAULT_READS = 10                     # LMP-TC-24: DTC reads with the short to battery held
LAMPS_LONG_FAULT_READ_MS = 60000                # LMP-TC-24: one read per minute
LAMPS_IO_CONTROL_HOLD_MS = 1000                 # LMP-TC-21: after an IO-control request, before the lamp is read
