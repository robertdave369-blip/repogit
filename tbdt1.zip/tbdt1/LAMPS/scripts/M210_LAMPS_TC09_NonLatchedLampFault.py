# Author: Kris
#
# M210 Lamps: a fault of the largest class of the fault table (warning lamp on, not latched).
# The squib loop of the lamp cases (canc_config CANC_LOOP_FAULT_SQUIB, driver pretensioner) is
# opened with SQUIB.SendRequest. After its qualification time (fault_list_config) the DTC is
# active
# and the lamp on (CAN and DID, steady for 3 s). The loop is restored; after the heal time the DTC
# is not active and the lamp is off, without an ignition cycle.
# Not automated: the second fault family of the test case (for example a buckle switch fault).
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-09 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_LOOP_FAULT_SQUIB, CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP,
    CAN_RX_MESSAGE_CONFIG, CAN_SIGNAL_Rx_EXPECTED_VALUES, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import LAMPS_EARLY_READ_MS, LAMPS_STEADY_WATCH_MS
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT
from Framework_IOEM_Py.projects.M210.config.squibs_config import SquibNumber, Squib_Fault_Description


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def watch_can(names, watch_ms, actions=()):
    """Read CAN signals once per frame period for watch_ms: [(ms after the call, {name: raw})].
    actions: (ms after the call, call), made between two reads."""
    period_ms = CAN_RX_MESSAGE_CONFIG[CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][names[0]][0]]["periodicity"]
    start, trace, pending = time.monotonic(), [], sorted(actions, key=lambda action: action[0])
    while (now := (time.monotonic() - start) * 1000) <= watch_ms:
        while pending and now >= pending[0][0]:
            pending.pop(0)[1]()
        trace.append((now, {name: read_can(name) for name in names}))
        Wait(max(0.0, now + period_ms - (time.monotonic() - start) * 1000))
    return trace


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def steady_lamp_step(title, lit=True):
    """INDC_SRS read once per frame period for LAMPS_STEADY_WATCH_MS: the same value at every read
    (steady, not flashing)."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    seen = {values["INDC_SRS"] for _, values in watch_can(["INDC_SRS"], LAMPS_STEADY_WATCH_MS)}
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS values at every frame for {LAMPS_STEADY_WATCH_MS} ms",
                                sorted(seen, key=str), [expected], seen == {expected})


def squib_load(load):
    """Set the squib loop of the lamp cases (canc_config CANC_LOOP_FAULT_SQUIB) to a squibs_config load:
    "Open" or "NoFault"."""
    device, value = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}", Squib_Fault_Description[load]
    RESULT.InterpretEqualResult(f"{device} ({CANC_LOOP_FAULT_SQUIB}) set to {value}", str(SQUIB.SendRequest(device, value)),
                                f"{value} for {device} set OK.")


def run_test():
    tc_id = "LMP-TC-09"
    tc_desc = "Non-latched warning lamp fault (squib open): lamp on with the fault, off after the heal."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "squib open: DTC active, lamp on and steady; loop restored: DTC not active and lamp off without ignition cycle")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        fault = fault_list_config.LOOP_FAULT_BY_SQUIB[CANC_LOOP_FAULT_SQUIB]["Open"]
        label = f"{CANC_LOOP_FAULT_SQUIB} squib open"
        squib_load("Open")
        Wait(fault["qualify_ms"] + LAMPS_EARLY_READ_MS)
        dtc_step(label, fault["dtc"])
        warning_lamp(label, True)
        steady_lamp_step(label)
        squib_load("NoFault")
        Wait(fault["dequalify_ms"] + LAMPS_EARLY_READ_MS)
        dtc_step(f"{label} removed", fault["dtc"], "inactive")
        warning_lamp(f"{label} removed", False)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        squib_load("NoFault")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
