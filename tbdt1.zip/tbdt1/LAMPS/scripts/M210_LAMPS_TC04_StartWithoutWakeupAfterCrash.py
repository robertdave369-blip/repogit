# Author: Kris
#
# M210 Lamps: a stored crash after a start without valid wake-up.
# A front crash is replayed. Then, twice: battery and ignition off, battery on with ignition off
# and the restbus stopped for 10 s (no valid wake-up), then the wake-up - first by ignition on,
# then over CAN (shared CAN_Wakeup). From the wake-up INDC_SRS is read at every frame for 15 s: on
# without an off phase. After it the lamp (CAN and DID) and the front crash DTC are read.
# With the CAN wake-up the reads start when CAN_Wakeup returns, which is its start-up delay after
# the wake request: the first part of the prove-out is not seen in that run.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-04 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_LAMP_PROVEOUT_ON_MS, CANC_PROVEOUT_TOLERANCE_PERCENT, CANC_WARNING_LAMP_DID,
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_RX_MESSAGE_CONFIG, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_CRASH_DTC, ENS_DTC_READ_WAIT_MS, ENS_SUPPLY_STEP_MS, LAMPS_NO_WAKEUP_MS,
    LAMPS_PROVEOUT_WATCH_MS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def watch_can(names, watch_ms, actions=()):
    """Read CAN signals once per frame period for watch_ms: [(ms after the call, {name: raw})].
    actions: (ms after the call, call), made between two reads."""
    period_ms = CAN_RX_MESSAGE_CONFIG[CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][names[0]][0]]["periodicity"]
    start, trace, pending = time.monotonic(), [], sorted(actions, key=lambda action: action[0])
    while (now := (time.monotonic() - start) * 1000) <= watch_ms:
        while pending and now >= pending[0][0]:
            pending.pop(0)[1]()
        trace.append((now, {name: read_can(name) for name in names}))
        Wait(max(0.0, now + period_ms - (time.monotonic() - start) * 1000))
    return trace


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def lamp_phases(trace):
    """A watch_can trace of INDC_SRS as [[lit, first ms, last ms]]; reads that failed are left out."""
    phases = []
    for at, values in trace:
        if values["INDC_SRS"] is None:
            continue
        lit = values["INDC_SRS"] != 0
        if phases and phases[-1][0] == lit:
            phases[-1][2] = at
        else:
            phases.append([lit, at, at])
    return phases


def proveout_step(title, stays_on):
    """Watch INDC_SRS from now for LAMPS_PROVEOUT_WATCH_MS (called right after the wake-up).
    stays_on False: lit for the prove-out time (canc_config), then off for the rest.
    stays_on True: lit without an off phase.
    An off phase at the very start is left out: the signal value of before the ECU start."""
    phases = lamp_phases(watch_can(["INDC_SRS"], LAMPS_PROVEOUT_WATCH_MS))
    if phases and not phases[0][0]:
        phases = phases[1:]
    shown = ", ".join(f"{'on' if lit else 'off'} {first:.0f} .. {last:.0f}" for lit, first, last in phases) or "no read"
    order = [lit for lit, _, _ in phases]
    if stays_on:
        RESULT.InterpretEqualResult(f"{title}: INDC_SRS phases (ms after the wake-up)", shown, "on, no off phase",
                                    order == [True])
        return
    tolerance = CANC_LAMP_PROVEOUT_ON_MS * CANC_PROVEOUT_TOLERANCE_PERCENT / 100
    RESULT.InterpretEqualResult(
        f"{title}: INDC_SRS phases (ms after the wake-up)", shown,
        f"on, then off from {CANC_LAMP_PROVEOUT_ON_MS - tolerance:g} to {CANC_LAMP_PROVEOUT_ON_MS + tolerance:g} ms",
        order == [True, False] and abs(phases[1][1] - CANC_LAMP_PROVEOUT_ON_MS) <= tolerance)


def run_test():
    tc_id = "LMP-TC-04"
    tc_desc = "Start without valid wake-up after a crash: the crash is shown again once the ECU wakes (LMP-BUG-02)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "both starts: lamp on from the start with no off phase after the prove-out, front crash DTC active")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        TriggerCrash()
        Wait(ENS_DTC_READ_WAIT_MS)
        dtc_step("After the front crash", ENS_CRASH_DTC["front"])
        for wake in ("ignition on", "CAN wake-up"):
            label = f"Start by {wake} after {LAMPS_NO_WAKEUP_MS} ms without wake-up"
            aria_reports.add_group(label)
            PS.BATT_OFF()
            Wait(ENS_SUPPLY_STEP_MS)
            PS.IGN_OFF()
            Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
            CAN.PeriodicDisableAllFrames()
            PS.BATT_ON()
            Wait(LAMPS_NO_WAKEUP_MS)
            CAN.PeriodicEnableAllFrames()
            if wake == "ignition on":
                PS.IGN_ON()
            else:
                CAN_Wakeup()    # restbus restarted with the wake request; graded by the shared function
            proveout_step(label, stays_on=True)
            dtc_step(label, ENS_CRASH_DTC["front"])
            warning_lamp(label, True)
            if wake != "ignition on":
                CAN_Wakeup_Restore()    # wake request released, ignition on
                Wait(PROVEOUT_COMPLETION_TIME)
            aria_reports.close_group()

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        CAN.PeriodicEnableAllFrames()
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
