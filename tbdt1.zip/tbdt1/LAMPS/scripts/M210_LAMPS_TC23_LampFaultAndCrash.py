# Author: Kris
#
# M210 Lamps: a crash with a lamp output fault present.
# The PAB OFF lamp output is opened (DTC active), then a front crash is replayed: the front crash
# DTC and the lamp DTC are active and the warning lamp is on. The lamp fault is removed: after the
# heal time the lamp DTC is not active, the crash DTC is still active and the lamp stays on.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-23 (P2). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, ENS_CRASH_DTC, ENS_DTC_READ_WAIT_MS, GPO_FaultStatus, LAMPS_EARLY_READ_MS,
    gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)
QUALIFY_MS = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]    # lamp output fault active
HEAL_MS = gpo_fault_time["Dequalification_Time"] + gpo_fault_time["Dequalification_Tolerance"]    # lamp output fault healed


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def run_test():
    tc_id = "LMP-TC-23"
    tc_desc = "A lamp output fault and a crash together: both stored; the lamp stays on when the lamp fault heals."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "crash DTC and lamp DTC active, lamp on; lamp fault removed: lamp DTC healed, crash DTC active, lamp still on")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        name, fault = "PAB_OFF", "OPEN"
        dtc = gpo_dtc(name, fault)
        label = f"{name} lamp {fault}"
        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        SetGpoFaultCondition(name, fault)
        Wait(QUALIFY_MS + LAMPS_EARLY_READ_MS)
        dtc_step(label, dtc)
        TriggerCrash()
        Wait(ENS_DTC_READ_WAIT_MS)
        dtc_step(f"{label}, front crash", ENS_CRASH_DTC["front"])
        dtc_step(f"{label}, front crash: lamp DTC", dtc)
        warning_lamp(f"{label}, front crash", True)
        SetGpoFaultCondition(name, "INHERENT")    # the output's rest state: fault removed
        Wait(HEAL_MS + LAMPS_EARLY_READ_MS)
        dtc_step(f"{label} removed after the crash: lamp DTC", dtc, "inactive")
        dtc_step(f"{label} removed after the crash", ENS_CRASH_DTC["front"])
        warning_lamp(f"{label} removed after the crash", True)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        SetGpoFaultCondition("PAB_OFF", "INHERENT")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
