# Author: Kris
#
# M210 Lamps: a fault with a latched warning lamp that is not a crash.
# The satellite of gpo_config (fault_list_config RSU_FAULT_BY_SATELLITE, ARIA channel from
# rsu_config) is set open with the shared SetRsuFaultCondition.
# 1. After the qualification time: DTC active, lamp on (CAN and DID).
# 2. Fault removed (shared RemoveRsuFaultCondition), 10 s later: the DTC and the lamp are
# reported.
#    The fault list says "dematuration: next cycle"; what "latched lamp" means is decided in
# WLMgr,
#    which is not in the source snapshot: confirm with the requirement.
# 3. Ignition cycle: DTC not active, lamp off after the prove-out.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-11 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    LAMPS_EARLY_READ_MS, LAMPS_LATCH_HOLD_MS, LAMPS_SATELLITE,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT
from Framework_IOEM_Py.projects.M210.config.rsu_config import DTC_RSU_fault


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def ignition_cycle():
    PS.IGN_OFF()
    Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def run_test():
    tc_id = "LMP-TC-11"
    tc_desc = "Latched-lamp fault that is not a crash (satellite open): lamp on, off after an ignition cycle without the fault."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "satellite open: DTC active, lamp on; after the fault is removed and an ignition cycle: DTC not active, lamp off")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        fault = fault_list_config.RSU_FAULT_BY_SATELLITE[LAMPS_SATELLITE]["Open"]
        channel = next(name for name, code in DTC_RSU_fault.items() if code.split() == fault["dtc"].split()[:2])
        label = f"{LAMPS_SATELLITE} ({channel}) open"
        SetRsuFaultCondition("OPEN", channel, "")
        Wait(fault["qualify_ms"] + LAMPS_EARLY_READ_MS)
        dtc_step(label, fault["dtc"])
        warning_lamp(label, True)
        RemoveRsuFaultCondition("OPEN", channel, "")
        Wait(LAMPS_LATCH_HOLD_MS)
        RESULT.CommentStep(f"{label} removed, same ignition cycle: DTC / INDC_SRS (observed, per requirement)",
                           f"{CAN.CheckSingleDTC(None, fault['dtc'])[1]} / {read_can('INDC_SRS')}")
        ignition_cycle()
        dtc_step(f"{label} removed, after an ignition cycle", fault["dtc"], "inactive")
        warning_lamp(f"{label} removed, after an ignition cycle", False)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        RemoveRsuFaultCondition("OPEN", next(name for name, code in DTC_RSU_fault.items() if code.split() == fault_list_config.RSU_FAULT_BY_SATELLITE[LAMPS_SATELLITE]["Open"]["dtc"].split()[:2]), "")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
