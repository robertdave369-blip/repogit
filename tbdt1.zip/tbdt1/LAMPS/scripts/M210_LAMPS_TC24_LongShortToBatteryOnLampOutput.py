# Author: Kris
#
# M210 Lamps: the indirect check of the GPO driver faults (thermal, internal, SPI), which cannot
# be created from outside without overloading the output.
# The PAB OFF lamp output is held short to battery; the DTCs are read once a minute for 10 minutes
# (gpo_config). The short-to-battery DTC stays active and no DTC of another failure type
# appears. The GPO driver DTC (thermal / internal / SPI share it, so they cannot be told apart by
# the DTC) and the internal faults (DID FD39) are reported: a thermal fault may appear and must
# then stay until the ignition cycle; an internal or SPI fault is a failure.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-24 (P3). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, GPO_FaultStatus, LAMPS_EARLY_READ_MS, LAMPS_LONG_FAULT_READS,
    LAMPS_LONG_FAULT_READ_MS, gpo_fault_names, gpo_fault_time,
)


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def internal_faults(label):
    """Names of the internal faults the ECU reports (DID FD39, shared internal error list)."""
    text = str(CAN.ReadAllDTCNamesWithStatus())
    RESULT.CommentStep(f"{label}: internal faults (DID FD39)", text)
    return {entry.split(" with status")[0].strip() for entry in text.rstrip(".").split(",")}
QUALIFY_MS = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]    # lamp output fault active


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def run_test():
    tc_id = "LMP-TC-24"
    tc_desc = "PAB OFF lamp short to battery held for 10 minutes: the short-to-battery DTC only."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P3")
    aria_reports.add_report_info("#Expected:", "at every read: short-to-battery DTC active, no short-to-ground and no open DTC; the GPO driver DTC is reported")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        name = "PAB_OFF"
        label = f"{name} lamp S2B"
        driver = fault_list_config.GPO_FAULT_BY_OUTPUT[name]["THERMAL"]["dtc"]
        SetGpoFaultCondition(name, "S2B")
        Wait(QUALIFY_MS + LAMPS_EARLY_READ_MS)
        for read in range(1, LAMPS_LONG_FAULT_READS + 1):
            Wait(LAMPS_LONG_FAULT_READ_MS)
            when = f"{label}, read {read} of {LAMPS_LONG_FAULT_READS}"
            dtc_step(when, gpo_dtc(name, "S2B"))
            for other in gpo_fault_names:
                if other != "S2B":
                    dtc_step(when, gpo_dtc(name, other), "inactive")
            RESULT.CommentStep(f"{when}: GPO driver DTC {driver} (observed)", str(CAN.CheckSingleDTC(None, driver)[1]))
        internal_faults(label)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        SetGpoFaultCondition("PAB_OFF", "INHERENT")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
