# Author: Kris
#
# M210 Lamps: service 85 (control DTC setting) against a lamp fault.
# Extended session, 85 02 (off). The PAB ON lamp output is opened for 10 s with the session kept
# open by TesterPresent: the DTC is not active; the warning lamp is reported. 85 01 (on): after
# the qualification time the DTC is active and the lamp on.
# The P31 fault table makes the control DTC setting an enable condition of every fault.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-15 (P2). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.cand_config import (
    IOC_REQ_SESSION_DEFAULT, IOC_REQ_SESSION_EXTENDED, IOC_RESP_SESSION_EXTENDED, UDS_REQ_3E_80,
    UDS_REQ_85_01, UDS_REQ_85_02, UDS_RESP_C5_01, UDS_RESP_C5_02,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, GPO_FaultStatus, LAMPS_CONTROL_DTC_WAIT_MS, LAMPS_EARLY_READ_MS,
    LAMPS_TESTER_PRESENT_MS, gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)
QUALIFY_MS = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]    # lamp output fault active


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def diag_step(title, request, expected):
    """One diagnostic request, graded on the first bytes of the response."""
    response = " ".join(str(CAN.SendDiagByValues(request)).split()[:len(expected.split())])
    RESULT.InterpretEqualResult(f"{title} ({request})", response, expected, response == expected)


def hold_session(ms):
    """Wait ms with the diagnostic session kept open (TesterPresent every LAMPS_TESTER_PRESENT_MS)."""
    for _ in range(int(ms // LAMPS_TESTER_PRESENT_MS)):
        Wait(LAMPS_TESTER_PRESENT_MS)
        CAN.SendDiagByValuesNoLog(UDS_REQ_3E_80)


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def run_test():
    tc_id = "LMP-TC-15"
    tc_desc = "Control DTC setting off: no lamp DTC is stored; it is stored after the setting is on again."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "setting off: PAB ON lamp open DTC not active after 10 s; setting on: active after the qualification time, lamp on")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        name, fault = "PAB_ON", "OPEN"
        dtc = gpo_dtc(name, fault)
        label = f"{name} lamp {fault}"
        diag_step("Start extended diagnostic session", IOC_REQ_SESSION_EXTENDED, IOC_RESP_SESSION_EXTENDED)
        diag_step("Control DTC setting off", UDS_REQ_85_02, UDS_RESP_C5_02)
        SetGpoFaultCondition(name, fault)
        hold_session(LAMPS_CONTROL_DTC_WAIT_MS)
        dtc_step(f"{label}, DTC setting off", dtc, "inactive")
        RESULT.CommentStep(f"{label}, DTC setting off: INDC_SRS (observed)", read_can("INDC_SRS"))
        diag_step("Control DTC setting on", UDS_REQ_85_01, UDS_RESP_C5_01)
        Wait(QUALIFY_MS + LAMPS_EARLY_READ_MS)
        dtc_step(f"{label}, DTC setting on", dtc)
        warning_lamp(f"{label}, DTC setting on", True)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        CAN.SendDiagByValues(IOC_REQ_SESSION_DEFAULT)
        SetGpoFaultCondition("PAB_ON", "INHERENT")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
