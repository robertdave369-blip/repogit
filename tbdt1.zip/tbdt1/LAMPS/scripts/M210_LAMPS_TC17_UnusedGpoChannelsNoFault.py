# Author: Kris
#
# M210 Lamps: the unused GPO channels (GPO 3 and 4 are control-disabled in the P31 table).
# The fault-free bench is left for 60 s. Then no short to battery, short to ground, open or
# configuration DTC of the PAB OFF, PAB ON and ENS output is reported, nor the GPO driver DTC
# (thermal / internal / SPI share one DTC). The internal faults (DID FD39, shared internal error
# list) are read: none with GPO in its name.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-17 (P3). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, GPO_FaultStatus, LAMPS_UNUSED_GPO_WAIT_MS, gpo_fault_names,
)


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def internal_faults(label):
    """Names of the internal faults the ECU reports (DID FD39, shared internal error list)."""
    text = str(CAN.ReadAllDTCNamesWithStatus())
    RESULT.CommentStep(f"{label}: internal faults (DID FD39)", text)
    return {entry.split(" with status")[0].strip() for entry in text.rstrip(".").split(",")}


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def run_test():
    tc_id = "LMP-TC-17"
    tc_desc = "Unused GPO channels give no fault: no GPO DTC on a fault-free bench (LMP-BUG-08)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P3")
    aria_reports.add_report_info("#Expected:", "after 60 s fault free: no short / open / configuration DTC of any GPO output, no GPO driver DTC, no GPO internal fault")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        label = f"Fault free for {LAMPS_UNUSED_GPO_WAIT_MS} ms"
        Wait(LAMPS_UNUSED_GPO_WAIT_MS)
        for name in DTC_GPO_fault:
            for fault in gpo_fault_names:
                dtc_step(f"{label}, {name} {fault}", gpo_dtc(name, fault), "absent")
            dtc_step(f"{label}, {name} configuration", fault_list_config.GPO_FAULT_BY_OUTPUT[name]["CONFIG"]["dtc"], "absent")
        dtc_step(f"{label}, GPO driver (thermal / internal / SPI)",
                 fault_list_config.GPO_FAULT_BY_OUTPUT["PAB_OFF"]["THERMAL"]["dtc"], "absent")
        found = sorted(name for name in internal_faults(label) if "GPO" in name.upper())
        RESULT.InterpretEqualResult(f"{label}: internal faults with GPO in the name", found, [], not found)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
