# Author: Kris
#
# M210 Lamps: the same lamp state from every source, read at the same step.
# Warning lamp (INDC_SRS and the warning lamp DID): fault free (off), squib open (on), healed
# (off), PAB OFF lamp open (on), healed (off), after a front crash (on).
# PAB lamps (both lamp loops on the lamp card, INDC_PADL, DID 044A): airbag enabled, disabled and
# enabled again (PSGR_AIRBAG_SW_IC).
# The warning lamp has no pin on this ECU (CAN only): its sources are CAN and the DID.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-22 (P2). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_LOOP_FAULT_SQUIB, CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP,
    CAN_PSGR_AIRBAG_SW_IC, CAN_SIGNAL_Rx_EXPECTED_VALUES, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, ENS_DTC_READ_WAIT_MS, GPO_Names, LAMPS_EARLY_READ_MS, LAMPS_OUTPUTS,
    LAMPS_PAB_STATUS_READ, LAMPS_SWITCH_SETTLE_MS, gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT
from Framework_IOEM_Py.projects.M210.config.squibs_config import SquibNumber, Squib_Fault_Description


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)
QUALIFY_MS = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]    # lamp output fault active
HEAL_MS = gpo_fault_time["Dequalification_Time"] + gpo_fault_time["Dequalification_Tolerance"]    # lamp output fault healed


# lamp output (gpo_config DTC_GPO_fault name) -> its ARIA lamp loop (gpo_config GPO_Names)
PAB_LOOP = {name: next(loop for loop in GPO_Names if loop.startswith(name)) for name in LAMPS_OUTPUTS}


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def pab_loop_on(name):
    """True / False when the lamp card's filtered status of a PAB lamp loop is ON / OFF, else None
    (dimming, flashing, indeterminate or a failed read)."""
    response = LAMPS.GetLampFilteredStatus(PAB_LOOP[name])
    state = str(response[1]).split(".")[-1].strip().upper() if response[0] == "0000" else ""
    return {"ON": True, "OFF": False}.get(state)


def pab_loop_step(title, name, lit):
    """One PAB lamp loop on the lamp card against the expected state."""
    state = pab_loop_on(name)
    RESULT.InterpretEqualResult(f"{title}: {PAB_LOOP[name]} on the lamp card",
                                {True: "ON", False: "OFF", None: "neither ON nor OFF"}[state], "ON" if lit else "OFF",
                                state is lit)


def pab_step(title, disabled):
    """The PAB lamps with the passenger airbag disabled / enabled, from all three sources: both lamp
    loops on the lamp card, INDC_PADL on CAN and the lamp bits of DID 044A."""
    pab_loop_step(title, "PAB_OFF", disabled)
    pab_loop_step(title, "PAB_ON", not disabled)
    value = read_can("INDC_PADL")
    RESULT.InterpretEqualResult(f"{title}: INDC_PADL", value, int(disabled), value == int(disabled))
    response = str(CAN.SendDiagByValues(LAMPS_PAB_STATUS_READ)).split()
    bits = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    expected = 0x02 if disabled else 0x01
    RESULT.InterpretEqualResult(f"{title}: DID 044A lamp bits (bit 0 PAB ON lamp, bit 1 PAB OFF lamp)", bits, expected,
                                bits == expected)


def pab_switch(value):
    """CAN simulation: PSGR_AIRBAG_SW_IC = value (canc_config State_Values: 1 PAB OFF, 0 PAB ON)."""
    frame, signal = CAN_PSGR_AIRBAG_SW_IC["frame"], CAN_PSGR_AIRBAG_SW_IC["signal"]
    answer = CAN.PeriodicChangeSignal(None, frame, signal, str(value))    # None: the wrapper resolves the channel
    RESULT.InterpretEqualResult(f"CAN simulation: {frame} / {signal} = {value}",
                                str(answer) if isinstance(answer, Exception) else "accepted", "accepted")


def squib_load(load):
    """Set the squib loop of the lamp cases (canc_config CANC_LOOP_FAULT_SQUIB) to a squibs_config load:
    "Open" or "NoFault"."""
    device, value = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}", Squib_Fault_Description[load]
    RESULT.InterpretEqualResult(f"{device} ({CANC_LOOP_FAULT_SQUIB}) set to {value}", str(SQUIB.SendRequest(device, value)),
                                f"{value} for {device} set OK.")


def run_test():
    tc_id = "LMP-TC-22"
    tc_desc = "The lamp state on CAN, in the DID and on the pin agree in every state."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "warning lamp: INDC_SRS and its DID the same; PAB lamps: lamp loops, INDC_PADL and DID 044A the same, in every state")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        fault = fault_list_config.LOOP_FAULT_BY_SQUIB[CANC_LOOP_FAULT_SQUIB]["Open"]
        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        warning_lamp("Fault free", False)
        pab_switch(0)
        Wait(LAMPS_SWITCH_SETTLE_MS)
        pab_step("Airbag enabled", False)
        pab_switch(1)
        Wait(LAMPS_SWITCH_SETTLE_MS)
        pab_step("Airbag disabled", True)
        pab_switch(0)
        Wait(LAMPS_SWITCH_SETTLE_MS)
        pab_step("Airbag enabled again", False)

        squib_load("Open")
        Wait(fault["qualify_ms"] + LAMPS_EARLY_READ_MS)
        warning_lamp(f"{CANC_LOOP_FAULT_SQUIB} squib open", True)
        squib_load("NoFault")
        Wait(fault["dequalify_ms"] + LAMPS_EARLY_READ_MS)
        warning_lamp(f"{CANC_LOOP_FAULT_SQUIB} squib restored", False)

        SetGpoFaultCondition("PAB_OFF", "OPEN")
        Wait(QUALIFY_MS + LAMPS_EARLY_READ_MS)
        warning_lamp("PAB_OFF lamp open", True)
        SetGpoFaultCondition("PAB_OFF", "INHERENT")    # the output's rest state: fault removed
        Wait(HEAL_MS + LAMPS_EARLY_READ_MS)
        warning_lamp("PAB_OFF lamp open removed", False)

        TriggerCrash()
        Wait(ENS_DTC_READ_WAIT_MS)
        warning_lamp("After a front crash", True)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        squib_load("NoFault")
        SetGpoFaultCondition("PAB_OFF", "INHERENT")
        pab_switch(0)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
