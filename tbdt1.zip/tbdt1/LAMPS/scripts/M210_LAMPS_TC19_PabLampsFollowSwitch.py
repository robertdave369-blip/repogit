# Author: Kris
#
# M210 Lamps: the PAB lamps against PSGR_AIRBAG_SW_IC (HPCC_1_100, canc_config). [KB]: the lamp
# logic is not in the M210 source snapshot.
# 1. Signal 0 (airbag enabled): both lamp loops on the lamp card, INDC_PADL and the lamp bits of
#    DID 044A.
# 2. Signal 1 (disabled): the time to the PAB OFF lamp on is reported (no limit in the reviewed
#    sources), then the same reads.
# 3. 20 changes of the signal at 200 ms: the reads for the last value sent.
# The signal has one bit: there is no other value to send.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-19 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_PSGR_AIRBAG_SW_IC, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, GPO_Names, LAMPS_OUTPUTS, LAMPS_PAB_STATUS_READ, LAMPS_SWITCH_POLL_MS,
    LAMPS_SWITCH_SETTLE_MS, LAMPS_SWITCH_TOGGLES, LAMPS_SWITCH_TOGGLE_MS,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


# lamp output (gpo_config DTC_GPO_fault name) -> its ARIA lamp loop (gpo_config GPO_Names)
PAB_LOOP = {name: next(loop for loop in GPO_Names if loop.startswith(name)) for name in LAMPS_OUTPUTS}


def pab_loop_on(name):
    """True / False when the lamp card's filtered status of a PAB lamp loop is ON / OFF, else None
    (dimming, flashing, indeterminate or a failed read)."""
    response = LAMPS.GetLampFilteredStatus(PAB_LOOP[name])
    state = str(response[1]).split(".")[-1].strip().upper() if response[0] == "0000" else ""
    return {"ON": True, "OFF": False}.get(state)


def pab_loop_step(title, name, lit):
    """One PAB lamp loop on the lamp card against the expected state."""
    state = pab_loop_on(name)
    RESULT.InterpretEqualResult(f"{title}: {PAB_LOOP[name]} on the lamp card",
                                {True: "ON", False: "OFF", None: "neither ON nor OFF"}[state], "ON" if lit else "OFF",
                                state is lit)


def pab_step(title, disabled):
    """The PAB lamps with the passenger airbag disabled / enabled, from all three sources: both lamp
    loops on the lamp card, INDC_PADL on CAN and the lamp bits of DID 044A."""
    pab_loop_step(title, "PAB_OFF", disabled)
    pab_loop_step(title, "PAB_ON", not disabled)
    value = read_can("INDC_PADL")
    RESULT.InterpretEqualResult(f"{title}: INDC_PADL", value, int(disabled), value == int(disabled))
    response = str(CAN.SendDiagByValues(LAMPS_PAB_STATUS_READ)).split()
    bits = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    expected = 0x02 if disabled else 0x01
    RESULT.InterpretEqualResult(f"{title}: DID 044A lamp bits (bit 0 PAB ON lamp, bit 1 PAB OFF lamp)", bits, expected,
                                bits == expected)


def pab_switch(value):
    """CAN simulation: PSGR_AIRBAG_SW_IC = value (canc_config State_Values: 1 PAB OFF, 0 PAB ON)."""
    frame, signal = CAN_PSGR_AIRBAG_SW_IC["frame"], CAN_PSGR_AIRBAG_SW_IC["signal"]
    answer = CAN.PeriodicChangeSignal(None, frame, signal, str(value))    # None: the wrapper resolves the channel
    RESULT.InterpretEqualResult(f"CAN simulation: {frame} / {signal} = {value}",
                                str(answer) if isinstance(answer, Exception) else "accepted", "accepted")


def run_test():
    tc_id = "LMP-TC-19"
    tc_desc = "[KB] PAB ON / OFF lamps follow the passenger airbag switch signal PSGR_AIRBAG_SW_IC."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "0: PAB ON lamp on, PAB OFF lamp off, INDC_PADL 0; 1: PAB OFF on, PAB ON off, INDC_PADL 1; never both in the same state")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        pab_switch(0)
        Wait(LAMPS_SWITCH_SETTLE_MS)
        pab_step("PSGR_AIRBAG_SW_IC = 0 (airbag enabled)", False)

        since, changed = time.monotonic(), None
        pab_switch(1)
        while changed is None and (time.monotonic() - since) * 1000 < LAMPS_SWITCH_SETTLE_MS:
            if pab_loop_on("PAB_OFF"):
                changed = (time.monotonic() - since) * 1000
            else:
                Wait(LAMPS_SWITCH_POLL_MS)
        RESULT.CommentStep(f"Signal change to the PAB OFF lamp on (ms, read every {LAMPS_SWITCH_POLL_MS} ms; observed)",
                           "no change" if changed is None else f"{changed:.0f}")
        Wait(LAMPS_SWITCH_SETTLE_MS)
        pab_step("PSGR_AIRBAG_SW_IC = 1 (airbag disabled)", True)

        for change in range(LAMPS_SWITCH_TOGGLES):
            pab_switch(change % 2)
            Wait(LAMPS_SWITCH_TOGGLE_MS)
        last = (LAMPS_SWITCH_TOGGLES - 1) % 2
        Wait(LAMPS_SWITCH_SETTLE_MS)
        pab_step(f"After {LAMPS_SWITCH_TOGGLES} changes at {LAMPS_SWITCH_TOGGLE_MS} ms, last value {last}", bool(last))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        pab_switch(0)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
