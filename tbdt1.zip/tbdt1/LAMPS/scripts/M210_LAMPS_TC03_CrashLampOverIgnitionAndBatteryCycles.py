# Author: Kris
#
# M210 Lamps: the crash latch over restarts.
# 1. Front crash: lamp on, front crash DTC active.
# 2. 20 ignition cycles with the off times of gpo_config (0.2 to 10 s, repeated); after each start
#    and the prove-out the lamp (CAN and DID) and the crash DTC are read.
# 3. 5 battery cycles with the off times of gpo_config (1 to 60 s), same reads.
# 4. The ECU is made fault free (crash data cleared) and steps 2 and 3 are repeated: lamp off
# after
#    the prove-out and no crash DTC.
# One start that differs fails the test (LMP-BUG-01: the latch after a restart depends on a status
# read whose result is not checked).
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-03 (P0). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_CRASH_DTC, ENS_DTC_READ_WAIT_MS, ENS_IGNITION_OFF_TIMES_MS, ENS_SUPPLY_STEP_MS,
    LAMPS_BATTERY_OFF_MS, LAMPS_IGNITION_CYCLES,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def battery_cycle(off_ms):
    """Battery and ignition off for off_ms, then on and prove-out (the load_crash_curves order)."""
    PS.BATT_OFF()
    Wait(ENS_SUPPLY_STEP_MS)
    PS.IGN_OFF()
    Wait(off_ms)
    PS.BATT_ON()
    Wait(ENS_SUPPLY_STEP_MS)
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def run_test():
    tc_id = "LMP-TC-03"
    tc_desc = "Warning lamp and crash DTC over ignition and battery cycles, after a crash and on a clean ECU (LMP-BUG-01)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P0")
    aria_reports.add_report_info("#Expected:", "after the crash: lamp on and crash DTC active after every start; clean ECU: lamp off and no crash DTC after every start")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        def started(when, crashed):
            dtc_step(when, ENS_CRASH_DTC["front"], "active" if crashed else "absent")
            warning_lamp(when, crashed)

        for crashed in (True, False):
            name = "After a front crash" if crashed else "Clean ECU"
            aria_reports.add_group(f"{name}: {LAMPS_IGNITION_CYCLES} ignition cycles, {len(LAMPS_BATTERY_OFF_MS)} battery cycles")
            if crashed:
                load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
                TriggerCrash()
                Wait(ENS_DTC_READ_WAIT_MS)
                started("Front crash", True)
            else:
                fault_free_profile()    # crash data and DTCs cleared
            for cycle in range(LAMPS_IGNITION_CYCLES):
                off_ms = ENS_IGNITION_OFF_TIMES_MS[cycle % len(ENS_IGNITION_OFF_TIMES_MS)]
                PS.IGN_OFF()
                Wait(off_ms)
                PS.IGN_ON()
                Wait(PROVEOUT_COMPLETION_TIME)
                started(f"{name}: ignition cycle {cycle + 1}, off {off_ms} ms", crashed)
            for off_ms in LAMPS_BATTERY_OFF_MS:
                battery_cycle(off_ms)
                started(f"{name}: battery off {off_ms} ms", crashed)
            aria_reports.close_group()

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
