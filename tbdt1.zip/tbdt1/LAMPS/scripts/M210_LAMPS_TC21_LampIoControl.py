# Author: Kris
#
# M210 Lamps: IO control of the three lamps. The DIDs are those of the common diagnostic
# specification (gpo_config LAMPS_IO_CONTROL_DID: to be confirmed for M210); the requests are
# the cand_config IO-control requests of these DIDs.
# For each lamp:
# 1. default session: the request is refused (negative response to 2F);
# 2. extended session and security access: short-term adjustment on, then off - the lamp follows
#    (warning lamp: INDC_SRS; PAB lamps: the lamp loop on the lamp card, not INDC_PADL);
# 3. return control: the lamp shows the real state (fault-free bench, airbag enabled: warning lamp
#    off, PAB OFF lamp off, PAB ON lamp on);
# 4. short-term adjustment on, then the session left to time out: the real state again;
# 5. PAB lamps: no lamp output DTC active.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-21 (P2). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import cand_config, fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.cand_config import (
    IOC_REQ_SESSION_DEFAULT, IOC_REQ_SESSION_EXTENDED, IOC_RESP_NEG_NRC33,
    IOC_RESP_SESSION_EXTENDED,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, ENS_AFTER_SECURITY_MS, ENS_SESSION_TIMEOUT_WAIT_MS, GPO_FaultStatus, GPO_Names,
    LAMPS_IO_CONTROL_DID, LAMPS_IO_CONTROL_HOLD_MS, LAMPS_OUTPUTS, gpo_fault_names,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def io_session():
    """Extended session and security access, as the F010 IO-control scripts."""
    response = CAN.SendDiagByValues(IOC_REQ_SESSION_EXTENDED)
    RESULT.InterpretEqualResult("Start extended diagnostic session", response, IOC_RESP_SESSION_EXTENDED,
                                str(response) == IOC_RESP_SESSION_EXTENDED)
    Internal_Security_Access(0x01)
    Wait(ENS_AFTER_SECURITY_MS)


# lamp output (gpo_config DTC_GPO_fault name) -> its ARIA lamp loop (gpo_config GPO_Names)
PAB_LOOP = {name: next(loop for loop in GPO_Names if loop.startswith(name)) for name in LAMPS_OUTPUTS}


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def diag_step(title, request, expected):
    """One diagnostic request, graded on the first bytes of the response."""
    response = " ".join(str(CAN.SendDiagByValues(request)).split()[:len(expected.split())])
    RESULT.InterpretEqualResult(f"{title} ({request})", response, expected, response == expected)


def pab_loop_on(name):
    """True / False when the lamp card's filtered status of a PAB lamp loop is ON / OFF, else None
    (dimming, flashing, indeterminate or a failed read)."""
    response = LAMPS.GetLampFilteredStatus(PAB_LOOP[name])
    state = str(response[1]).split(".")[-1].strip().upper() if response[0] == "0000" else ""
    return {"ON": True, "OFF": False}.get(state)


def pab_loop_step(title, name, lit):
    """One PAB lamp loop on the lamp card against the expected state."""
    state = pab_loop_on(name)
    RESULT.InterpretEqualResult(f"{title}: {PAB_LOOP[name]} on the lamp card",
                                {True: "ON", False: "OFF", None: "neither ON nor OFF"}[state], "ON" if lit else "OFF",
                                state is lit)


def run_test():
    tc_id = "LMP-TC-21"
    tc_desc = "[KB] Lamp IO control (warning lamp, PAB OFF, PAB ON): session, on, off, return, session time-out."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "default session: refused; extended: the lamp follows on / off; real state after return and after the time-out; no lamp DTC")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        real = {"warning lamp": False, "PAB_OFF": False, "PAB_ON": True}    # fault-free bench, airbag enabled
        refused = " ".join(IOC_RESP_NEG_NRC33.split()[:2])    # 7F 2F, whatever the NRC
        for lamp, did in LAMPS_IO_CONTROL_DID.items():
            name = f"{did[:2]}_{did[2:]}"
            switch_on, switch_off, give_back = (getattr(cand_config, f"IOC_REQ_2F_{name}_{tail}") for tail in ("03_01", "03_00", "00"))
            adjusted, returned = (getattr(cand_config, f"IOC_RESP_6F_{name}_{tail}") for tail in ("03", "00"))
            label = f"IO control {did} ({lamp})"

            def shown(when, lit):
                if lamp == "warning lamp":
                    lamp_step(when, lit)
                else:
                    pab_loop_step(when, lamp, lit)

            aria_reports.add_group(label)
            CAN.SendDiagByValues(IOC_REQ_SESSION_DEFAULT)
            diag_step(f"{label} in the default session: negative response", switch_on, refused)
            io_session()
            diag_step(f"{label}: lamp on", switch_on, adjusted)
            Wait(LAMPS_IO_CONTROL_HOLD_MS)
            shown(f"{label}: lamp on", True)
            diag_step(f"{label}: lamp off", switch_off, adjusted)
            Wait(LAMPS_IO_CONTROL_HOLD_MS)
            shown(f"{label}: lamp off", False)
            diag_step(f"{label}: return control to the ECU", give_back, returned)
            Wait(LAMPS_IO_CONTROL_HOLD_MS)
            shown(f"{label}: after return control (real state)", real[lamp])
            diag_step(f"{label}: lamp {'off' if real[lamp] else 'on'}", switch_off if real[lamp] else switch_on, adjusted)
            Wait(ENS_SESSION_TIMEOUT_WAIT_MS)
            shown(f"{label}: after the session time-out (real state)", real[lamp])
            if lamp in LAMPS_OUTPUTS:
                for fault in gpo_fault_names:
                    dtc_step(f"{label}: no lamp DTC from the control", gpo_dtc(lamp, fault), "inactive")
            aria_reports.close_group()

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        CAN.SendDiagByValues(IOC_REQ_SESSION_DEFAULT)
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
