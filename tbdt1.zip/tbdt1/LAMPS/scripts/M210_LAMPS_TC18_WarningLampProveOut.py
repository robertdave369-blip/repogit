# Author: Kris
#
# M210 Lamps: the lamp check at ignition on. [KB]: 6 s on, then off when fault free (canc_config
# CANC_LAMP_PROVEOUT_ON_MS, from agent_sc3.md); there is no M210 source for it.
# In each of three conditions the ignition is cycled and INDC_SRS is read at every frame for 15 s
# from ignition on:
# 1. fault free: on for the prove-out time (within the canc_config tolerance), then off;
# 2. squib loop open (DTC active before the cycle): on, no off phase;
# 3. after a front crash: on, no off phase.
# The time is counted from the ignition-on command, so the ECU start-up is inside it.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-18 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_LAMP_PROVEOUT_ON_MS, CANC_LOOP_FAULT_SQUIB, CANC_PROVEOUT_TOLERANCE_PERCENT,
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_RX_MESSAGE_CONFIG, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_CRASH_DTC, ENS_DTC_READ_WAIT_MS, LAMPS_EARLY_READ_MS, LAMPS_PROVEOUT_WATCH_MS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT
from Framework_IOEM_Py.projects.M210.config.squibs_config import SquibNumber, Squib_Fault_Description


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def watch_can(names, watch_ms, actions=()):
    """Read CAN signals once per frame period for watch_ms: [(ms after the call, {name: raw})].
    actions: (ms after the call, call), made between two reads."""
    period_ms = CAN_RX_MESSAGE_CONFIG[CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][names[0]][0]]["periodicity"]
    start, trace, pending = time.monotonic(), [], sorted(actions, key=lambda action: action[0])
    while (now := (time.monotonic() - start) * 1000) <= watch_ms:
        while pending and now >= pending[0][0]:
            pending.pop(0)[1]()
        trace.append((now, {name: read_can(name) for name in names}))
        Wait(max(0.0, now + period_ms - (time.monotonic() - start) * 1000))
    return trace


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_phases(trace):
    """A watch_can trace of INDC_SRS as [[lit, first ms, last ms]]; reads that failed are left out."""
    phases = []
    for at, values in trace:
        if values["INDC_SRS"] is None:
            continue
        lit = values["INDC_SRS"] != 0
        if phases and phases[-1][0] == lit:
            phases[-1][2] = at
        else:
            phases.append([lit, at, at])
    return phases


def proveout_step(title, stays_on):
    """Watch INDC_SRS from now for LAMPS_PROVEOUT_WATCH_MS (called right after the wake-up).
    stays_on False: lit for the prove-out time (canc_config), then off for the rest.
    stays_on True: lit without an off phase.
    An off phase at the very start is left out: the signal value of before the ECU start."""
    phases = lamp_phases(watch_can(["INDC_SRS"], LAMPS_PROVEOUT_WATCH_MS))
    if phases and not phases[0][0]:
        phases = phases[1:]
    shown = ", ".join(f"{'on' if lit else 'off'} {first:.0f} .. {last:.0f}" for lit, first, last in phases) or "no read"
    order = [lit for lit, _, _ in phases]
    if stays_on:
        RESULT.InterpretEqualResult(f"{title}: INDC_SRS phases (ms after the wake-up)", shown, "on, no off phase",
                                    order == [True])
        return
    tolerance = CANC_LAMP_PROVEOUT_ON_MS * CANC_PROVEOUT_TOLERANCE_PERCENT / 100
    RESULT.InterpretEqualResult(
        f"{title}: INDC_SRS phases (ms after the wake-up)", shown,
        f"on, then off from {CANC_LAMP_PROVEOUT_ON_MS - tolerance:g} to {CANC_LAMP_PROVEOUT_ON_MS + tolerance:g} ms",
        order == [True, False] and abs(phases[1][1] - CANC_LAMP_PROVEOUT_ON_MS) <= tolerance)


def squib_load(load):
    """Set the squib loop of the lamp cases (canc_config CANC_LOOP_FAULT_SQUIB) to a squibs_config load:
    "Open" or "NoFault"."""
    device, value = f"LOOP{SquibNumber[CANC_LOOP_FAULT_SQUIB]}", Squib_Fault_Description[load]
    RESULT.InterpretEqualResult(f"{device} ({CANC_LOOP_FAULT_SQUIB}) set to {value}", str(SQUIB.SendRequest(device, value)),
                                f"{value} for {device} set OK.")


def run_test():
    tc_id = "LMP-TC-18"
    tc_desc = "[KB] Warning lamp prove-out at ignition on: fault free, with an active fault, after a crash."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "fault free: on for 6 s, then off; with a squib open and after a crash: on, no off phase")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        def cycle_and_watch(label, stays_on):
            PS.IGN_OFF()
            Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
            PS.IGN_ON()
            proveout_step(label, stays_on)

        cycle_and_watch("Fault free", False)

        fault = fault_list_config.LOOP_FAULT_BY_SQUIB[CANC_LOOP_FAULT_SQUIB]["Open"]
        label = f"{CANC_LOOP_FAULT_SQUIB} squib open"
        squib_load("Open")
        Wait(fault["qualify_ms"] + LAMPS_EARLY_READ_MS)
        dtc_step(label, fault["dtc"])
        cycle_and_watch(label, True)
        squib_load("NoFault")

        label = "After a front crash"
        fault_free_profile()
        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        TriggerCrash()
        Wait(ENS_DTC_READ_WAIT_MS)
        dtc_step(label, ENS_CRASH_DTC["front"])
        cycle_and_watch(label, True)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        squib_load("NoFault")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
