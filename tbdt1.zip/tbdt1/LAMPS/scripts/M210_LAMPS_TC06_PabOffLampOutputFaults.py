# Author: Kris
#
# M210 Lamps: faults on the PAB OFF lamp output (GPO 0), shared SetGpoFaultCondition.
# For short to battery, short to ground and open (gpo_config names, DTC, failure types and times):
# 1. fault applied: the DTC is not active 500 ms before the qualification time and active after
#    it, with no DTC of another failure type;
# 2. warning lamp on (CAN and DID); SRS_PAB_WARN_STS and DID 044A are reported;
# 3. fault removed: the DTC is still active 500 ms before the heal time and not active after it;
#    warning lamp off;
# 4. ignition cycle: DTC not active, lamp off after the prove-out.
# The 2 s / 4 s are the M314 values of gpo_config: the P31 fault table gives counter limits only.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-06 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CANC_WARNING_LAMP_DID, CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, GPO_FaultStatus, LAMPS_EARLY_READ_MS, LAMPS_PAB_STATUS_READ, gpo_fault_names,
    gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def ignition_cycle():
    PS.IGN_OFF()
    Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)
QUALIFY_MS = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]    # lamp output fault active
HEAL_MS = gpo_fault_time["Dequalification_Time"] + gpo_fault_time["Dequalification_Tolerance"]    # lamp output fault healed


def wait_until(since, ms):
    """Wait until ms after the time.monotonic() value `since`."""
    Wait(max(0.0, ms - (time.monotonic() - since) * 1000))


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def lamp_did_step(title, lit):
    """The warning lamp status DID (canc_config CANC_WARNING_LAMP_DID): 1 when lit, else 0."""
    response = str(CAN.SendDiagByValues("0x22 " + CANC_WARNING_LAMP_DID)).split()
    value = int(response[3], 16) & 0x03 if len(response) > 3 and response[0] == "0x62" else None
    RESULT.InterpretEqualResult(f"{title}: DID {CANC_WARNING_LAMP_DID} (warning lamp {'on' if lit else 'off'})", value,
                                int(lit), value == int(lit))


def warning_lamp(title, lit):
    """The warning lamp on CAN (INDC_SRS) and in its status DID: both must give the same state."""
    lamp_step(title, lit)
    lamp_did_step(title, lit)


def lamp_output_faults(name):
    """Every gpo_config fault on one lamp output: no DTC before the qualification time, the DTC with
    its failure type after it, warning lamp on; fault removed: still active before the heal time,
    healed after it, warning lamp off; not active after an ignition cycle."""
    for fault in gpo_fault_names:
        label, dtc = f"{name} lamp {fault}", gpo_dtc(name, fault)
        aria_reports.add_group(label)
        since = time.monotonic()
        SetGpoFaultCondition(name, fault)
        wait_until(since, gpo_fault_time["Qualification_Time"] - LAMPS_EARLY_READ_MS)
        dtc_step(f"{label}: {LAMPS_EARLY_READ_MS} ms before the qualification time", dtc, "inactive")
        wait_until(since, QUALIFY_MS + LAMPS_EARLY_READ_MS)
        dtc_step(f"{label}: after the qualification time", dtc)
        for other in gpo_fault_names:
            if other != fault:
                dtc_step(f"{label}: no DTC of another failure type", gpo_dtc(name, other), "inactive")
        warning_lamp(f"{label} present", True)
        RESULT.CommentStep(f"{label} present: SRS_PAB_WARN_STS / DID 044A (observed)",
                           f"{read_can('SRS_PAB_WARN_STS')} / {CAN.SendDiagByValues(LAMPS_PAB_STATUS_READ)}")
        since = time.monotonic()
        SetGpoFaultCondition(name, "INHERENT")    # the output's rest state: fault removed
        wait_until(since, gpo_fault_time["Dequalification_Time"] - LAMPS_EARLY_READ_MS)
        dtc_step(f"{label} removed: {LAMPS_EARLY_READ_MS} ms before the heal time", dtc)
        wait_until(since, HEAL_MS + LAMPS_EARLY_READ_MS)
        dtc_step(f"{label} removed: after the heal time", dtc, "inactive")
        warning_lamp(f"{label} removed", False)
        ignition_cycle()
        dtc_step(f"{label} removed: after an ignition cycle", dtc, "inactive")
        warning_lamp(f"{label} removed, after an ignition cycle", False)
        aria_reports.close_group()


def run_test():
    tc_id = "LMP-TC-06"
    tc_desc = "PAB OFF lamp output: short to battery, short to ground, open - DTC, warning lamp, heal."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "each fault: no DTC before 2 s, DTC with its failure type after it, lamp on; healed after 4 s, lamp off; not active after an ignition cycle")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        lamp_output_faults("PAB_OFF")

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        SetGpoFaultCondition("PAB_OFF", "INHERENT")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
