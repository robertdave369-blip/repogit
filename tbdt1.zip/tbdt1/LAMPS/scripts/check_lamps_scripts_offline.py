# Author: Kris
#
# Offline check of the M210 Lamps scripts: no ARIA, no ECU, nothing on the bench.
#
# Every script runs against the stubbed shared library and the simulated ECU of the ENS check
# (projects/M210/modules/ENS/scripts/check_ens_scripts_offline.py: virtual clock, crashes, crash
# DTCs, supply, diagnostics), extended here by the lamps: warning lamp with its prove-out, the
# warning lamp DID, the PAB lamps (lamp loops, INDC_PADL, DID 044A), lamp output faults with their
# qualification and heal times and enable conditions (voltage, control DTC setting), squib,
# satellite and node-absent faults, the EOL configuration DTCs and the lamp IO control.
# The simulated ECU behaves as the test cases expect (a "good" ECU). Every script must pass against
# it and fail against each fault planted for it.
# This checks the scripts, not the ECU: what the real ECU does is the bench run.
#
#     py -3 projects/M210/modules/LAMPS/scripts/check_lamps_scripts_offline.py            check
#     py -3 projects/M210/modules/LAMPS/scripts/check_lamps_scripts_offline.py --html     report previews
# (both take a part of a script name as a further argument)

import sys
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "ENS" / "scripts"))

import check_ens_scripts_offline as ens_check  # noqa: E402
from check_ens_scripts_offline import CRASH_DTC, ENS_FAULT_DTC, dtc_number  # noqa: E402

from Framework_IOEM_Py.projects.M210.config import (  # noqa: E402
    canc_config, cand_config, fault_list_config, gpo_config,
)

PROVEOUT_MS = canc_config.CANC_LAMP_PROVEOUT_ON_MS
SQUIB_FAULT = fault_list_config.LOOP_FAULT_BY_SQUIB[canc_config.CANC_LOOP_FAULT_SQUIB]["Open"]
SATELLITE_FAULT = fault_list_config.RSU_FAULT_BY_SATELLITE[gpo_config.LAMPS_SATELLITE]["Open"]
SWITCH_FRAME = canc_config.CAN_PSGR_AIRBAG_SW_IC["frame"]
SWITCH_DTC = dtc_number(getattr(fault_list_config, gpo_config.LAMPS_SWITCH_FAULT)["dtc"])
FRAME_FAULT = {gpo_config.LAMPS_NO_LAMP_FRAME: getattr(fault_list_config, gpo_config.LAMPS_NO_LAMP_FAULT),
               SWITCH_FRAME: getattr(fault_list_config, gpo_config.LAMPS_SWITCH_FAULT)}
CONFIG_DTC = {bit: dtc_number(fault_list_config.GPO_FAULT_BY_OUTPUT[name]["CONFIG"]["dtc"])
              for name, bit in gpo_config.LAMPS_EOL_BIT.items()}
GPO_TIME = gpo_config.gpo_fault_time


def frame_period(frame):
    return next(entry["periodicity"] for entry in canc_config.MAH_CAN_SIGNAL_DEFS.values()
                if entry["frame"] == frame and entry.get("periodicity"))


class LampBench(ens_check.Bench):
    """The simulated ECU of the ENS check with the lamps. A planted fault is a key of `ecu`."""

    tool = "check_lamps_scripts_offline.py"
    shared = ("SetRsuFaultCondition", "RemoveRsuFaultCondition")

    def __init__(self, ecu):
        self.faults = {}    # key -> dict(code, present, since, qualify, heal, lamp)
        self.running, self.run_at = True, -1e9    # the ECU is on and past its prove-out when a script starts
        self.eol, self.switch, self.forced = {}, 0, {}
        self.setting_off = self.lamp_killed = self.healed_once = False
        self.last_diag, self.toggle = 0.0, 0
        super().__init__(ecu)

    # -- fault monitoring, every 10 ms -----------------------------------------------------------------
    def step(self, t):
        super().step(t)
        if int(t * 2) % 20 == 0:
            self.monitor(t)

    def monitor(self, t):
        ecu = self.ecu
        running = self.batt and (self.ign or self.can_wake)
        if running and not self.running:    # a start: prove-out, EOL read, the faults of the last cycle re-tested
            self.run_at, self.lamp_killed, self.healed_once = t, False, False
            for fault in self.faults.values():
                if not fault["present"] and fault["code"] in self.dtcs:
                    self.dtcs[fault["code"]] = 0x08
            for bit, code in CONFIG_DTC.items():
                if self.eol.get(bit) and not ecu.get("no_config_dtc"):
                    self.dtcs[code] = 0x8B
                elif code in self.dtcs:
                    self.dtcs[code] = 0x08
            if ecu.get("crash_lost_at_start"):    # planted: the stored crash is not reported again after a start
                for code in CRASH_DTC.values():
                    if code in self.dtcs:
                        self.dtcs[code] = 0x08
        if not running:
            self.session = self.setting_off = False
            self.forced = {}
        self.running = running
        if running and self.session and t - self.last_diag > 5000.0:    # S3 server time-out
            self.session = self.setting_off = False
            if not ecu.get("io_stays_forced"):
                self.forced = {}
        if running and ecu.get("unused_gpo_dtc"):    # planted: a GPO DTC without a fault
            self.dtcs[ENS_FAULT_DTC["OPEN"]] = 0x8B
        in_range = 9.0 <= self.voltage <= 16.0 or ecu.get("dtc_during_voltage_fault")
        enabled = (running and t >= self.run_at + ecu["startup_ms"] and in_range
                   and (not self.setting_off or ecu.get("control_dtc_ignored")))
        for fault in self.faults.values():
            if not enabled:
                fault["since"] = t
            elif fault["present"] and t - fault["since"] >= fault["qualify"]:
                self.dtcs[fault["code"]] = 0x8B
            elif (not fault["present"] and self.dtcs.get(fault["code"], 0) & 0x01 and fault["heal"] is not None
                  and t - fault["since"] >= fault["heal"] and not ecu.get("no_heal")):
                self.dtcs[fault["code"]] = 0x0A
                self.healed_once = True
                self.lamp_killed = bool(ecu.get("lamp_off_with_heal"))    # planted: a heal switches the lamp off

    def fault_set(self, key, present, fault, lamp="on", code=None, qualify=None, heal=None):
        """Apply or remove a fault. fault: its fault_list_config entry (times in ms)."""
        record = self.faults.setdefault(key, dict(
            code=code or dtc_number(fault["dtc"]), present=False, since=self.now, lamp=lamp,
            qualify=qualify if qualify is not None else fault["qualify_ms"],
            heal=heal if heal is not None else fault.get("dequalify_ms")))
        if record["present"] != present:
            record.update(present=present, since=self.now)

    # -- lamp states -----------------------------------------------------------------------------------
    def started(self):
        return self.running and self.now >= self.run_at + self.ecu["startup_ms"]

    def lamp(self, forced=True):
        ecu = self.ecu
        if not self.started():
            return 0
        if forced and "warning lamp" in self.forced:
            return int(self.forced["warning lamp"])
        if self.now < self.run_at + ecu["startup_ms"] + PROVEOUT_MS and not ecu.get("no_proveout"):
            return 1
        if self.lamp_killed:
            return 0
        if ecu.get("lamp_stays_after_heal") and self.healed_once:
            return 1
        no_lamp = {record["code"] for record in self.faults.values() if record["lamp"] == "off"}
        for code, status in self.dtcs.items():
            if not status & 0x01:
                continue
            if code in no_lamp and not ecu.get("node_absent_lights_lamp"):
                continue
            if code in CRASH_DTC.values() and ecu.get("crash_lamp_off"):
                continue
            if code == dtc_number(SATELLITE_FAULT["dtc"]) and ecu.get("satellite_no_lamp"):
                continue
            return 1
        return 0

    def pab_disabled(self):
        lost = self.dtcs.get(SWITCH_DTC, 0) & 0x01 and not self.ecu.get("pab_keeps_last")
        return bool(self.switch) and not lost

    def pab_lamps(self, forced=True):
        """(PAB ON lamp, PAB OFF lamp)."""
        if not self.started():
            return False, False
        disabled = self.pab_disabled()
        state = {"PAB_ON": not disabled or bool(self.ecu.get("pab_both_on")), "PAB_OFF": disabled}
        if forced:
            state.update({name: value for name, value in self.forced.items() if name in state})
        return state["PAB_ON"], state["PAB_OFF"]

    # -- what the stubs do -----------------------------------------------------------------------------
    def fault_free(self, *args, **kwargs):
        self.faults, self.eol, self.switch, self.forced = {}, {}, 0, {}
        self.setting_off, self.running = False, False    # power cycle: a start with its prove-out
        super().fault_free(*args, **kwargs)

    def load(self, key, **kwargs):
        super().load(key, **kwargs)
        self.advance(8000.0)    # load_crash_curves waits for the prove-out

    def eol_write(self, target, action="disable", **_):
        self.eol[target] = action == "disable"
        if target == "CRASH_OUTPUT_HW_LINE":
            self.eol_off = action == "disable"
        self.batt = False    # manage_eol_code cycles the supply
        self.advance(200.0)
        self.batt = True
        self.advance(self.ecu["startup_ms"] + 1000.0)

    def gpo_fault(self, name, fault, *_):
        if name == "ENS":
            return super().gpo_fault(name, fault, *_)
        for kind, status in gpo_config.GPO_FaultStatus.items():
            reported = "S2G" if kind == "S2B" and self.ecu.get("wrong_failure_type") else kind
            if kind == fault or (name, kind) in self.faults:
                self.fault_set((name, kind), kind == fault, None, qualify=GPO_TIME["Qualification_Time"],
                               heal=GPO_TIME["Dequalification_Time"],
                               code=dtc_number(f"{gpo_config.DTC_GPO_fault[name]} {gpo_config.GPO_FaultStatus[reported]}"))

    def squib(self, device, load):
        self.fault_set("squib", load == "OPEN", SQUIB_FAULT)
        return f"{load} for {device} set OK."

    def satellite(self, present):
        return lambda *_: self.fault_set("satellite", present, SATELLITE_FAULT)

    def frame(self, stopped):
        def switch(_channel, name):
            if name in FRAME_FAULT:
                fault, period = FRAME_FAULT[name], frame_period(name)
                self.fault_set(name, stopped, fault, lamp="off", qualify=fault["qualify_counts"] * period,
                               heal=fault["dequalify_counts"] * period)
            return f"Simulation {'Stopped' if stopped else 'Started'} on {name}"
        return switch

    def change_signal(self, _channel, _frame, signal, value, *_):
        if signal == canc_config.CAN_PSGR_AIRBAG_SW_IC["signal"]:
            self.switch = int(value)
        return "ok"

    def loop_status(self, loop):
        on, off = self.pab_lamps()
        return ["0000", "ON" if (on if loop.startswith("PAB_ON") else off) else "OFF"]

    def signal(self, channel, frame, name):
        if name == "INDC_SRS":
            return self.lamp()
        if name == "INDC_PADL":
            return int(self.started() and self.pab_disabled())
        if name == "SRS_PAB_WARN_STS":
            return 2 if self.pab_disabled() else 1
        return super().signal(channel, frame, name)

    def check_dtc(self, channel, code, *rest):
        self.last_diag = self.now
        response = super().check_dtc(channel, code, *rest)
        lamp_codes = {record["code"] for key, record in self.faults.items() if isinstance(key, tuple)}
        if self.ecu.get("gpo_dtc_toggles") and dtc_number(code) in lamp_codes and response[0] == "0000":
            self.toggle ^= 1    # planted: the DTC comes and goes
            if self.toggle:
                return ["1111", f"DTC {dtc_number(code):06X} not present"]
        return response

    def diag(self, *args):
        request = " ".join(str(args[-1]).split())
        self.last_diag = self.now
        if request == cand_config.UDS_REQ_3E_80:
            return ""
        if request in (cand_config.UDS_REQ_85_01, cand_config.UDS_REQ_85_02):
            if not self.session:
                return "0x7F 0x85 0x7F"
            self.setting_off = request == cand_config.UDS_REQ_85_02
            return "0xC5 " + request.split()[1]
        if request == "0x22 " + canc_config.CANC_WARNING_LAMP_DID:
            lamp = 0 if self.ecu.get("did_differs") else self.lamp(forced=False)
            return f"0x62 {canc_config.CANC_WARNING_LAMP_DID} 0x{lamp:02X}"
        if request == gpo_config.LAMPS_PAB_STATUS_READ:
            on, off = self.pab_lamps(forced=False)
            return f"0x62 0x04 0x4A 0x{int(on) | int(off) << 1:02X} 0x00 0x00"
        for lamp, did in gpo_config.LAMPS_IO_CONTROL_DID.items():
            head = f"0x2F 0x{did[:2]} 0x{did[2:]}"
            if request.startswith(head):
                tail = request[len(head):].split()
                if not self.session:
                    return "0x7F 0x2F 0x7F"
                if tail == ["0x00"]:    # return control
                    if not self.ecu.get("io_stays_forced"):
                        self.forced.pop(lamp, None)
                else:
                    self.forced[lamp] = tail[1] == "0x01"
                return " ".join(["0x6F", *head.split()[1:], *tail])
        response = super().diag(*args)
        if request == cand_config.IOC_REQ_SESSION_DEFAULT:
            self.setting_off = False
            if not self.ecu.get("io_stays_forced"):
                self.forced = {}
        return response

    def stubs(self, stubs):
        return dict(
            CAN=types.SimpleNamespace(**{**vars(stubs["CAN"]), "PeriodicChangeSignal": self.change_signal,
                                         "PeriodicDisableFrame": self.frame(True), "PeriodicEnableFrame": self.frame(False)}),
            LAMPS=types.SimpleNamespace(**{**vars(stubs["LAMPS"]), "GetLampFilteredStatus": self.loop_status}),
            SQUIB=types.SimpleNamespace(SendRequest=self.squib),
            SetRsuFaultCondition=self.satellite(True), RemoveRsuFaultCondition=self.satellite(False),
            manage_eol_code=self.eol_write,
        )


# script -> planted ECU faults it must catch
CASES = {
    "M210_LAMPS_TC01_WarningLampAfterFrontCrash.py": [dict(crash_lamp_off=True), dict(no_dtc=True)],
    "M210_LAMPS_TC02_WarningLampAfterOtherCrashes.py": [dict(crash_lamp_off=True), dict(no_dtc=True)],
    "M210_LAMPS_TC03_CrashLampOverIgnitionAndBatteryCycles.py": [dict(crash_lost_at_start=True)],
    "M210_LAMPS_TC04_StartWithoutWakeupAfterCrash.py": [dict(crash_lost_at_start=True)],
    "M210_LAMPS_TC05_CrashNotRemovedByClearDtc.py": [dict(clear_removes_dtc=True)],
    "M210_LAMPS_TC06_PabOffLampOutputFaults.py": [dict(wrong_failure_type=True), dict(no_heal=True)],
    "M210_LAMPS_TC07_PabOnLampOutputFaults.py": [dict(wrong_failure_type=True), dict(lamp_stays_after_heal=True)],
    "M210_LAMPS_TC08_LampFaultsDuringVoltageFault.py": [dict(dtc_during_voltage_fault=True)],
    "M210_LAMPS_TC09_NonLatchedLampFault.py": [dict(lamp_stays_after_heal=True), dict(no_proveout=True, did_differs=True)],
    "M210_LAMPS_TC10_LampConfigurationError.py": [dict(no_config_dtc=True)],
    "M210_LAMPS_TC11_LatchedLampFault.py": [dict(satellite_no_lamp=True)],
    "M210_LAMPS_TC14_LampFaultAtBatteryConnect.py": [dict(gpo_dtc_toggles=True)],
    "M210_LAMPS_TC15_ControlDtcSettingOff.py": [dict(control_dtc_ignored=True)],
    "M210_LAMPS_TC16_FaultWithoutWarningLamp.py": [dict(node_absent_lights_lamp=True)],
    "M210_LAMPS_TC17_UnusedGpoChannelsNoFault.py": [dict(unused_gpo_dtc=True)],
    "M210_LAMPS_TC18_WarningLampProveOut.py": [dict(no_proveout=True), dict(crash_lost_at_start=True)],
    "M210_LAMPS_TC19_PabLampsFollowSwitch.py": [dict(pab_both_on=True)],
    "M210_LAMPS_TC20_PabSwitchFrameMissing.py": [dict(pab_keeps_last=True)],
    "M210_LAMPS_TC21_LampIoControl.py": [dict(io_stays_forced=True)],
    "M210_LAMPS_TC22_LampStateOnCanDidAndPinAgree.py": [dict(did_differs=True), dict(pab_both_on=True)],
    "M210_LAMPS_TC23_LampFaultAndCrash.py": [dict(lamp_off_with_heal=True), dict(no_dtc=True)],
    "M210_LAMPS_TC24_LongShortToBatteryOnLampOutput.py": [dict(wrong_failure_type=True)],
}


if __name__ == "__main__":
    arguments = sys.argv[1:]
    if arguments[:1] == ["--html"]:
        sys.exit(ens_check.previews("".join(arguments[1:2]), CASES, HERE, LampBench, "LAMPS_offline_preview"))
    sys.exit(ens_check.main("".join(arguments[:1]), CASES, HERE, LampBench))
