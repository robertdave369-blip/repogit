# Author: Kris
#
# M210 Lamps: the PAB OFF lamp open fault around the ECU start.
# 1. The fault is applied with the ECU off; battery and ignition on; the DTC is read every 500 ms
#    for 10 s: it becomes active once, not before the qualification time, and stays active.
# 2. The fault is removed and healed. Battery on, ignition off, restbus stopped: the fault is
#    applied for 10 s; ignition on: the DTC is not active 500 ms before the qualification time
#    counted from ignition on, and active after it.
# The battery-connect inhibition time is not in the reviewed sources: the first read with the DTC
# active is in the report.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-14 (P2). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, ENS_SUPPLY_STEP_MS, GPO_FaultStatus, LAMPS_CONNECT_READ_MS,
    LAMPS_CONNECT_WATCH_MS, LAMPS_EARLY_READ_MS, LAMPS_NO_WAKEUP_MS, gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed
HEAL_MS = gpo_fault_time["Dequalification_Time"] + gpo_fault_time["Dequalification_Tolerance"]    # lamp output fault healed


def wait_until(since, ms):
    """Wait until ms after the time.monotonic() value `since`."""
    Wait(max(0.0, ms - (time.monotonic() - since) * 1000))


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def run_test():
    tc_id = "LMP-TC-14"
    tc_desc = "Lamp fault right after battery connect and without valid wake-up: the DTC appears once, after the wake-up."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "the DTC becomes active once, not before the qualification time, and stays; without wake-up only after ignition on")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        name, fault = "PAB_OFF", "OPEN"
        dtc = gpo_dtc(name, fault)
        label = f"{name} lamp {fault} applied with the ECU off"
        PS.BATT_OFF()
        Wait(ENS_SUPPLY_STEP_MS)
        PS.IGN_OFF()
        Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
        SetGpoFaultCondition(name, fault)
        PS.BATT_ON()
        Wait(ENS_SUPPLY_STEP_MS)
        since = time.monotonic()
        PS.IGN_ON()
        active = []
        for read in range(1, LAMPS_CONNECT_WATCH_MS // LAMPS_CONNECT_READ_MS + 1):
            wait_until(since, read * LAMPS_CONNECT_READ_MS)
            response = CAN.CheckSingleDTC(None, dtc)
            active.append(response[0] == "0000" and bool(int(str(response[1]).split()[-1], 16) & 0x01))
        RESULT.CommentStep(f"{label}: DTC {dtc} active at each read (every {LAMPS_CONNECT_READ_MS} ms from ignition on)",
                           "".join("1" if state else "0" for state in active))
        changes = sum(1 for earlier, later in zip(active, active[1:]) if earlier != later)
        RESULT.InterpretEqualResult(f"{label}: changes of the DTC state (becomes active once and stays)", changes, 1,
                                    changes == 1 and active[-1])
        first = (active.index(True) + 1) * LAMPS_CONNECT_READ_MS if True in active else None
        RESULT.InterpretEqualResult(f"{label}: first read with the DTC active (ms after ignition on)", first,
                                    f"at least {gpo_fault_time['Qualification_Time']}",
                                    first is not None and first >= gpo_fault_time["Qualification_Time"])

        SetGpoFaultCondition(name, "INHERENT")    # the output's rest state: fault removed
        Wait(HEAL_MS + LAMPS_EARLY_READ_MS)
        dtc_step(f"{name} lamp {fault} removed", dtc, "inactive")

        label = f"{name} lamp {fault} applied with battery on, ignition off, restbus stopped"
        PS.IGN_OFF()
        CAN.PeriodicDisableAllFrames()
        Wait(POWER_OFF_DELAY * 1000)
        SetGpoFaultCondition(name, fault)
        Wait(LAMPS_NO_WAKEUP_MS)
        CAN.PeriodicEnableAllFrames()
        since = time.monotonic()
        PS.IGN_ON()
        wait_until(since, gpo_fault_time["Qualification_Time"] - LAMPS_EARLY_READ_MS)
        dtc_step(f"{label}: {LAMPS_EARLY_READ_MS} ms before the qualification time after ignition on", dtc, "inactive")
        wait_until(since, PROVEOUT_COMPLETION_TIME)
        dtc_step(f"{label}: after ignition on and the prove-out", dtc)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        SetGpoFaultCondition("PAB_OFF", "INHERENT")
        CAN.PeriodicEnableAllFrames()
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
