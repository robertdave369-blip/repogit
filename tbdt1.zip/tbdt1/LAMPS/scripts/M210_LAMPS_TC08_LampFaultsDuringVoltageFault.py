# Author: Kris
#
# M210 Lamps: the lamp output faults against the supply voltage (voltages from power_config).
# For the PAB OFF, PAB ON and ENS output, with open and short to ground, at the under-voltage and
# the over-voltage test voltage:
# 1. the fault applied during the voltage fault for 10 s: DTC not active;
# 2. back at the nominal voltage: DTC active within the qualification time;
# 3. voltage fault again for 10 s: DTC still active; fault removed during the voltage fault for
#    10 s: DTC still active (not healed); back at the nominal voltage: healed within the heal
# time.
# The P31 fault table makes the voltage conditions an enable condition of these faults.
# Test case: Lamps_Black_Box_Test_Cases.md, LMP-TC-08 (P1). Expected values: P31 fault table
# (FltMonr_PBCfg.h) and EnsMgr.c through projects/M210/config/gpo_config.py and the other M210
# configs; test cases tagged [KB] in the document have no M210 source.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, ENS_VOLTAGE_FAULT_WAIT_MS, ENS_VOLTAGE_SETTLE_MS, GPO_FaultStatus, LAMPS_OUTPUTS,
    LAMPS_VOLTAGE_FAULTS, gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.power_config import (
    NOMINAL_VOLTAGE, OVERVOLTAGE_TEST_VOLTAGE, UNDERVOLTAGE_TEST_VOLTAGE,
)


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed
QUALIFY_MS = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]    # lamp output fault active
HEAL_MS = gpo_fault_time["Dequalification_Time"] + gpo_fault_time["Dequalification_Tolerance"]    # lamp output fault healed


def gpo_dtc(name, fault):
    """DTC bytes of a lamp output fault (gpo_config: DTC of the output and failure type of the fault)."""
    return f"{DTC_GPO_fault[name]} {GPO_FaultStatus[fault]}"


def run_test():
    tc_id = "LMP-TC-08"
    tc_desc = "Lamp output faults during under-voltage and over-voltage: not set and not healed (LMP-BUG-04)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "during the voltage fault the lamp DTC does not change; after the return it follows the real state")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        Wait(PROVEOUT_COMPLETION_TIME)    # the lamp is valid only after the start-up prove-out
        for name in (*LAMPS_OUTPUTS, "ENS"):
            for fault in LAMPS_VOLTAGE_FAULTS:
                dtc = gpo_dtc(name, fault)
                for kind, voltage in (("under-voltage", UNDERVOLTAGE_TEST_VOLTAGE), ("over-voltage", OVERVOLTAGE_TEST_VOLTAGE)):
                    label = f"{name} {fault}, {kind} {voltage:g} V"
                    aria_reports.add_group(label)
                    PS.SetVoltage(voltage)
                    Wait(ENS_VOLTAGE_SETTLE_MS)
                    SetGpoFaultCondition(name, fault)
                    Wait(ENS_VOLTAGE_FAULT_WAIT_MS)
                    dtc_step(f"{label}: fault applied during the voltage fault", dtc, "inactive")
                    PS.SetVoltage(NOMINAL_VOLTAGE)
                    Wait(ENS_VOLTAGE_SETTLE_MS + QUALIFY_MS)
                    dtc_step(f"{label}: back at {NOMINAL_VOLTAGE:g} V with the fault", dtc)
                    PS.SetVoltage(voltage)
                    Wait(ENS_VOLTAGE_FAULT_WAIT_MS)
                    dtc_step(f"{label}: voltage fault again with the fault", dtc)
                    SetGpoFaultCondition(name, "INHERENT")    # the output's rest state: fault removed
                    Wait(ENS_VOLTAGE_FAULT_WAIT_MS)
                    dtc_step(f"{label}: fault removed during the voltage fault (not healed)", dtc)
                    PS.SetVoltage(NOMINAL_VOLTAGE)
                    Wait(ENS_VOLTAGE_SETTLE_MS + HEAL_MS)
                    dtc_step(f"{label}: back at {NOMINAL_VOLTAGE:g} V without the fault", dtc, "inactive")
                    aria_reports.close_group()

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        PS.SetVoltage(NOMINAL_VOLTAGE)
        for name in (*LAMPS_OUTPUTS, "ENS"):
            SetGpoFaultCondition(name, "INHERENT")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
