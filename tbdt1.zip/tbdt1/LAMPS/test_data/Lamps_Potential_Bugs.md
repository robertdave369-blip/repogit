# M210 Lamps: potential bugs from the source review

Review date: 2026-11-12. Reviewed snapshot: `C:\Project_M210`. Moved here from
`../../ENS/test_data/ENS_and_Lamps_Potential_Bugs.md` on 2026-11-13; what was reviewed, the
evidence tags ([CFG], [SRC], [EDR]) and the ENS findings (ENS-BUG-xx) are in that document.

These are **potential** bugs: each one is a behaviour the code can produce, found by reading the
source. None has been reproduced on the bench. The lamp software itself (`WLMgr`, `PADI`,
`GpoMgr`) is not in the snapshot.

## 1. Lamps potential bugs

Channel assignment used below, from [CFG] lines 98-100 and [SRC] `EnsMgr.c` 348: GPO 0 = passenger
airbag disable (PAB OFF) lamp, GPO 1 = PAB ON LED, GPO 2 = crash output (ENS). GPO 3 and 4 are
disabled.

### LMP-BUG-01 (P1) Warning lamp after a crash depends on an unchecked status read at start
- **Evidence:** [SRC] `ensmgr_CrashInitialization` (668-713): `fault_event_status` is not
  initialised and the return value of `FltMonr_GetEventStatus` is ignored. The crash faults are then
  reported failed or **passed** from that value.
- **Issue:** If the status read fails (fault memory not ready at start), the decision uses an
  undefined byte: a stored crash can be reported "passed" (lamp off after a crash) or a clean ECU
  "failed" (lamp on, crash DTC without crash).
- **Impact:** Latched crash indication lost, or false crash DTC, after a restart.
- **Reproduce:**
  1. Front crash. Check warning lamp on and crash DTCs.
  2. 20 ignition cycles and 5 battery cycles with different off times (0.2 s to 30 s). After each
     start check the lamp and read DTCs.
  3. Clean ECU (no crash): same cycles.
- **Expected:** after a crash: lamp on and crash DTCs in every cycle. Clean ECU: lamp off after
  prove-out, no crash DTC.
- **Fails when:** one cycle shows the lamp off after a crash, or a crash DTC on a clean ECU.
- **Confidence:** Medium.

### LMP-BUG-02 (P1) Crash indication after start waits for a valid wake-up
- **Evidence:** [SRC] 1347-1362 and 1159-1164: with invalid wake-up at init, the re-report of stored
  crash faults is postponed to the first slow task with valid wake-up. [CFG] every crash event has
  the invalid-wake-up enable condition.
- **Issue:** After a start with invalid wake-up the stored crash is not re-reported until the
  wake-up is valid; the wake-up state is read up to 25 ms late (ENS-BUG-12).
- **Reproduce:** crash; battery off / on with ignition off; then ignition on. Observe the lamp from
  ignition on; read DTCs 1 s after ignition on.
- **Expected:** lamp on (no off phase after prove-out), crash DTCs active.
- **Fails when:** the lamp goes off after prove-out, or the crash DTC is not active.
- **Confidence:** Medium.

### LMP-BUG-03 (P1) Some deployments are configured without warning lamp
- **Evidence:** [CFG] lines 1571, 1580, 1582-1584: anti-submarining, rollover bar, windscreen
  airbag, belt load limiter and hood lifter "fired" events are `WL_OFF`, not latched.
- **Issue:** If only one of these devices fires (and no crash-direction event is set), the lamp
  stays off although a pyrotechnic device is used up.
- **Reproduce:** only if M210 configures one of these loops: crash that fires it; check the lamp.
- **Expected:** lamp on after any deployment (to be confirmed against the requirement).
- **Fails when:** a loop fired and the lamp is off.
- **Confidence:** High for the configuration; applicability to M210 loops unknown.

### LMP-BUG-04 (P1) Lamp and ENS output faults are not detected while under- or over-voltage is active
- **Evidence:** [CFG] lines 63-82, 98-100: short to ground, short to battery, open and configuration
  faults of GPO 0-2 carry the under-voltage, over-voltage, battery-connect and invalid-wake-up enable
  conditions. Thermal, internal and SPI faults (83-97) carry no voltage condition.
- **Issue:** Intended inhibition, but: a fault created during under-voltage must appear after the
  voltage returns, and a fault active before must not heal during the inhibition.
- **Reproduce:**
  1. Under-voltage; apply open on the PAB OFF lamp; wait 10 s; read DTCs. Return to 12 V; wait;
     read DTCs.
  2. Open at 12 V (DTC active); go to under-voltage; read DTC status; return to 12 V.
  3. Same with over-voltage, and for PAB ON lamp and ENS.
- **Expected:** no lamp DTC change during the voltage fault; after return the DTC follows the real
  state within the qualification time.
- **Fails when:** a lamp DTC is set or healed during the voltage fault, or stays wrong after it.
- **Confidence:** High for the configuration.

### LMP-BUG-05 (P2) Configuration and thermal faults of the lamp outputs are latched
- **Evidence:** [CFG] 78-87, 98-100: `LATCHED_FAULT` on configuration, unexpected-load and thermal
  faults.
- **Issue:** Once set they do not heal while the cause is gone, at least in the same ignition
  cycle. A wrong EOL corrected in the same cycle keeps the lamp on.
- **Reproduce:** EOL with the PAB OFF lamp de-configured while the lamp load is connected:
  configuration DTC. Correct the EOL without ignition cycle; read DTC; ignition cycle; read DTC.
- **Expected:** per requirement (usually: heals at the next ignition cycle).
- **Fails when:** the DTC stays active after the ignition cycle with a correct configuration.
- **Confidence:** High for the configuration; heal rule not in the snapshot.

### LMP-BUG-06 (P2) Warning-lamp state stored in the EDR may differ from the lamp
- **Evidence:** [EDR] `RstEdr_Cfg.h` 2670 (`OpsWlStatus`), 2859 and 2493 (PADI state, pre-event);
  `RstEdr.c` 4603-4609.
- **Issue:** The record takes the lamp state from internal status signals at capture time, not from
  the output. During prove-out, IO control or a lamp output fault the stored state can differ from
  what the driver saw.
- **Reproduce:** crash with (a) lamp off, (b) lamp on from an active fault, (c) during prove-out,
  (d) PAB switched off. Read the warning-lamp and PAD lamp elements of the record.
- **Expected:** the record equals the lamp state at the event.
- **Fails when:** the record shows "off" while the lamp was on, or the opposite.
- **Confidence:** Medium.

### LMP-BUG-07 (P2) Crash DTC and lamp latch are held in RAM for the ignition cycle
- **Evidence:** [SRC] `EnsAlgoSevStatusForFlt` is cleared only at init (1332); 954-1000 reports the
  crash events failed every 25 ms.
- **Issue:** Clearing DTCs (`14 FF FF FF`) in the crash ignition cycle is followed by an immediate
  re-report. After a reset the latch relies on the stored "confirmed" bit (LMP-BUG-01): if the clear
  removed it, the crash DTC and the lamp do not come back.
- **Reproduce:** crash; clear DTCs; read DTCs; ignition cycle; read DTCs and check the lamp. W610
  record [REC] `W610_ENS_TEST_07` step 7 expects: not cleared, not healed.
- **Expected:** crash DTC active and lamp on before and after the ignition cycle.
- **Fails when:** crash DTC or lamp is gone after clear plus ignition cycle.
- **Confidence:** Medium.

### LMP-BUG-08 (P3) Unused GPO channels
- **Evidence:** [CFG] GPO 3 and 4 faults carry the control-disabled mask.
- **Issue:** None expected. Check that no DTC and no lamp come from the unused channels.
- **Reproduce:** fault-free bench, read all DTCs; covered by any fault-free check.
- **Confidence:** High.

### Not reviewable (Evidence unavailable)

The following lamp behaviour has no source in the snapshot and therefore no finding: warning-lamp
prove-out time, lamp on / off decision in `WLMgr`, PAB ON / OFF lamp selection from
`PSGR_AIRBAG_SW_IC`, `INDC_SRS` / `INDC_PADL` CAN signals, lamp IO control, the qualification and
heal times of the GPO faults (the fault table gives jump-counter limits -12 / +13 without the step
time). Test cases for them are in `Lamps_Black_Box_Test_Cases.md`, marked [KB], and must be checked
against the M210 requirement first.

---

## 2. Trace: finding to test case

| Finding | Test case | Script |
|---|---|---|
| LMP-BUG-01 (P1) | LMP-TC-03 | `M210_LAMPS_TC03_CrashLampOverIgnitionAndBatteryCycles.py` |
| LMP-BUG-02 (P1) | LMP-TC-04 | `M210_LAMPS_TC04_StartWithoutWakeupAfterCrash.py` |
| LMP-BUG-03 (P1) | LMP-TC-12 | not automated |
| LMP-BUG-04 (P1) | LMP-TC-08 | `M210_LAMPS_TC08_LampFaultsDuringVoltageFault.py` |
| LMP-BUG-05 (P2) | LMP-TC-10 | `M210_LAMPS_TC10_LampConfigurationError.py` |
| LMP-BUG-06 (P2) | LMP-TC-13 | not automated |
| LMP-BUG-07 (P2) | LMP-TC-05 | `M210_LAMPS_TC05_CrashNotRemovedByClearDtc.py` |
| LMP-BUG-08 (P3) | LMP-TC-17 | `M210_LAMPS_TC17_UnusedGpoChannelsNoFault.py` |
