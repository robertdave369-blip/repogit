# M210 Lamps (warning lamp, PAB ON / OFF lamps): black-box test cases

Findings referenced as LMP-BUG-xx and ENS-BUG-xx are in `Lamps_Potential_Bugs.md` (LMP) and
`../../ENS/test_data/ENS_and_Lamps_Potential_Bugs.md` (ENS).

The test cases are in **priority order, highest first**. The IDs are fixed names, not the order.

## 1. Read this first: what the source allows

The lamp software itself (`WLMgr`, `PADI`, `GpoMgr`, the GPO driver) is **not** in
`C:\Project_M210`. What the snapshot does establish about the lamps:

| Evidence tag | Source | What it establishes |
|---|---|---|
| **[CFG]** | `ProjectInformation/Release/Mahindra_M210_P31/SupportFiles/FltMonr_PBCfg.h` | For every fault: warning lamp class (`WL_ON` 1340 entries, `WL_LATCHED` 151, `WL_OFF` 87), latch, enable conditions, DTC event. GPO faults per channel |
| **[SRC]** | `EnsMgr.c` 668-713, 735-1000 | Crash and deployment faults are raised here, and re-raised at every start from the stored status |
| **[EDR]** | `RstEdr_Cfg.h` 2670, 2859, 2493; `RstEdr.c` 4603-4609 | Warning lamp and PAD lamp state are captured in the crash record |
| **[FW]** | Framework config `gpo_config`, `canc_config`, `cand_config`, `eol_config` (M314 values copied for M210, partly unconfirmed) | Signal names, DTC bytes, times used by the scripts |
| **[KB]** | `agent_sc3.md` 2.5 (M314 family) | Prove-out, PAB lamp logic. **Not M210 source evidence** |

Test cases tagged **[KB]** describe behaviour that could not be established from the M210 source.
They are included so the lamp functions are covered, and they must be checked against the M210
requirement before a failure is raised.

GPO channels [CFG 98-100]: GPO 0 = passenger airbag disable (PAB OFF) lamp, GPO 1 = PAB ON LED,
GPO 2 = crash output (ENS), GPO 3-4 disabled. Outputs are low-side: pin low = lamp on.

| Priority | Meaning |
|---|---|
| **P0** | Driver not warned after a crash or of a system failure |
| **P1** | Lamp or lamp diagnosis wrong in a likely condition |
| **P2** | Corner condition, robustness, stored information |
| **P3** | Unused or not creatable from outside |

### 1.1 Common data

- **Warning lamp state:** CAN signal `INDC_SRS` (`SRS1_FD_10`; `SRS1_20` on HS-CAN),
  `check_warning_lamp_status`; lamp status DID (`cand_config` `airbag_warning_lamp_status`).
- **PAB lamps:** ARIA lamp card loops `PAB_ON_LAMP`, `PAB_OFF_LAMP` (`LAMPS.GetLampFilteredStatus`,
  or a recording as in the ENS scripts); CAN `INDC_PADL`, `SRS_PAB_WARN_STS`; DID bits
  `pab_on_lamp_status`, `pab_off_lamp_status`.
- **Lamp output faults:** `SetGpoFaultCondition(<lamp>, "S2B" | "S2G" | "OPEN" | "INHERENT")`.
  DTC bytes `gpo_config.DTC_GPO_fault`, failure type `GPO_FaultStatus` (S2B 0x12, S2G 0x11, OPEN
  0x13), times `gpo_fault_time` (qualification 2000 ms, heal 4000 ms: **M314 values, confirm**; the
  fault table gives jump-counter limits -12 / +13 without the step time).
- **Precondition of every test:** bench fault free, default EOL and variant code, 12 V, ignition on,
  prove-out complete, no DTC, warning lamp off. **Postcondition:** faults removed, crash data
  cleared, fault free.

### 1.2 Automated scripts

One script per test case in `modules/LAMPS/scripts`, written by
`tools/generate_m210_lamps_scripts.py` (bodies in `tools/m210_lamps/lamps_bodies.py`); values from
`projects/M210/config/gpo_config.py` and the other M210 configs. None has run on the bench yet.

| Test case | Script | Not automated / note |
|---|---|---|
| LMP-TC-01 | `M210_LAMPS_TC01_WarningLampAfterFrontCrash.py` |  |
| LMP-TC-02 | `M210_LAMPS_TC02_WarningLampAfterOtherCrashes.py` |  |
| LMP-TC-03 | `M210_LAMPS_TC03_CrashLampOverIgnitionAndBatteryCycles.py` |  |
| LMP-TC-04 | `M210_LAMPS_TC04_StartWithoutWakeupAfterCrash.py` | CAN wake-up run: the first 2 s of the prove-out are not seen |
| LMP-TC-05 | `M210_LAMPS_TC05_CrashNotRemovedByClearDtc.py` |  |
| LMP-TC-06 | `M210_LAMPS_TC06_PabOffLampOutputFaults.py` |  |
| LMP-TC-07 | `M210_LAMPS_TC07_PabOnLampOutputFaults.py` |  |
| LMP-TC-08 | `M210_LAMPS_TC08_LampFaultsDuringVoltageFault.py` |  |
| LMP-TC-09 | `M210_LAMPS_TC09_NonLatchedLampFault.py` | second fault family (buckle switch) not automated |
| LMP-TC-10 | `M210_LAMPS_TC10_LampConfigurationError.py` | "correct EOL without ignition cycle" reported only: `manage_eol_code` cycles the supply |
| LMP-TC-11 | `M210_LAMPS_TC11_LatchedLampFault.py` | step 2 (same ignition cycle) reported, not graded |
| LMP-TC-12 | - | **not automated**: none of these loops is known for M210 |
| LMP-TC-13 | - | **not automated**: the record elements of the warning lamp and PAD lamp are not identified in `edr_config` |
| LMP-TC-14 | `M210_LAMPS_TC14_LampFaultAtBatteryConnect.py` |  |
| LMP-TC-15 | `M210_LAMPS_TC15_ControlDtcSettingOff.py` |  |
| LMP-TC-16 | `M210_LAMPS_TC16_FaultWithoutWarningLamp.py` |  |
| LMP-TC-17 | `M210_LAMPS_TC17_UnusedGpoChannelsNoFault.py` |  |
| LMP-TC-18 | `M210_LAMPS_TC18_WarningLampProveOut.py` |  |
| LMP-TC-19 | `M210_LAMPS_TC19_PabLampsFollowSwitch.py` | time to the lamp change reported, not graded (no limit) |
| LMP-TC-20 | `M210_LAMPS_TC20_PabSwitchFrameMissing.py` | wrong CRC / alive counter not automated |
| LMP-TC-21 | `M210_LAMPS_TC21_LampIoControl.py` | IO-control DIDs F011 / F012 / F013 from the common specification: to be confirmed for M210 |
| LMP-TC-22 | `M210_LAMPS_TC22_LampStateOnCanDidAndPinAgree.py` | own script: the sources are read in the same step |
| LMP-TC-23 | `M210_LAMPS_TC23_LampFaultAndCrash.py` |  |
| LMP-TC-24 | `M210_LAMPS_TC24_LongShortToBatteryOnLampOutput.py` | GPO driver DTC and internal faults reported, not graded |

`check_lamps_scripts_offline.py` runs every script against a simulated ECU (no bench): each must pass
on a good ECU and fail on the fault planted for it. With `--html` it writes a preview of every
report into `test_results/M210/LAMPS_offline_preview` (simulated values, marked as such).

---

## 2. P0 test cases

### LMP-TC-01 (P0) Warning lamp on and latched after a front crash
- **Why P0:** the driver must be told the system has deployed.
- **Trace:** [SRC] `EnsMgr.c` 954-1000; [CFG] 1620 (`FRONT_CRASH_EVENT`: `WL_LATCHED`, latched
  fault), 1570-1579.
- **Steps:**
  1. Check the lamp is off. Replay the front crash set once.
  2. Read `INDC_SRS` and the lamp status DID 1 s, 10 s and 60 s after the crash. Read DTCs.
- **Expected:** lamp on at every read, steady (not flashing); front crash-detect DTC and ECU-locked
  DTC active.
- **Fails when:** the lamp is off or goes off; no crash DTC.

### LMP-TC-02 (P0) Warning lamp after left, right, rear and underbody crash
- **Why P0:** same as LMP-TC-01 for the other crash events.
- **Trace:** [CFG] 1585-1587, 1654 (all `WL_LATCHED`); [SRC] 965-999.
- **Steps:** as LMP-TC-01 with each set, one set per run, crash data cleared in between.
- **Expected:** lamp on and the crash-detect DTC of that direction active in every run.
- **Fails when:** lamp off after any of the four.

### LMP-TC-03 (P0) Warning lamp and crash DTC survive ignition and battery cycles
- **Why P0:** LMP-BUG-01: the latch after a restart depends on an unchecked status read.
- **Trace:** [SRC] `EnsMgr.c` 668-713 (`fault_event_status` not initialised, return value ignored).
- **Steps:**
  1. Front crash. Lamp on, DTCs read.
  2. 20 ignition cycles: off times 0.2, 0.5, 1, 2, 5, 10 s (repeat the list). After each start wait
     for prove-out, read `INDC_SRS` and DTCs.
  3. 5 battery cycles: off times 1, 5, 10, 30, 60 s. Same reads.
  4. Clean ECU (crash data cleared): repeat steps 2-3.
- **Expected:** after the crash: lamp on and crash DTC active after every start. Clean ECU: lamp
  off after prove-out and no crash DTC after every start.
- **Fails when:** a single start differs.

---

## 3. P1 test cases

### LMP-TC-04 (P1) Start without valid wake-up after a crash
- **Why P1:** LMP-BUG-02: the stored crash is re-reported only with a valid wake-up.
- **Trace:** [SRC] `EnsMgr.c` 1159-1164, 1347-1362.
- **Steps:**
  1. Front crash. Battery and ignition off.
  2. Battery on, ignition off (no CAN) for 10 s. Then ignition on.
  3. Watch `INDC_SRS` from ignition on for 15 s; read DTCs 1 s after prove-out.
  4. Repeat with a CAN wake-up (`CAN_Wakeup`) in place of ignition on.
- **Expected:** lamp on from the start and it stays on after prove-out; crash DTC active.
- **Fails when:** the lamp goes off after prove-out; crash DTC not active.

### LMP-TC-05 (P1) Crash indication is not removed by clearing DTCs
- **Why P1:** LMP-BUG-07.
- **Trace:** [SRC] `EnsMgr.c` 954-1000, 1332; W610 record `W610_ENS_TEST_07` step 7.
- **Steps:** front crash. `14 FF FF FF`. Read DTCs and the lamp at once and 5 s later. Ignition
  cycle. Read again. Second clear right after the start; ignition cycle; read.
- **Expected:** crash DTC active and lamp on at every read.
- **Fails when:** crash DTC or lamp gone at any read.

### LMP-TC-06 (P1) PAB OFF lamp output: short to battery, short to ground, open
- **Why P1:** a broken PAB OFF lamp hides "passenger airbag off" from the passenger.
- **Trace:** [CFG] 63, 68, 73 (GPO 0: `WL_ON`, not latched). Times and DTC bytes [FW].
- **Steps:** for each of S2B, S2G, OPEN:
  1. Apply the fault. Read DTCs just before the qualification time (expect none) and after it.
  2. Read `INDC_SRS`, `SRS_PAB_WARN_STS` and the lamp status DID fault byte.
  3. Remove the fault (INHERENT). Read DTCs just before the heal time and after it. Read the lamp.
  4. Ignition cycle. Read DTCs.
- **Expected:** 1: PAB OFF lamp DTC with failure type 0x12 / 0x11 / 0x13, status active, only after
  the qualification time. 2: warning lamp on. 3: DTC healed after the heal time; warning lamp off.
  4: DTC historic, lamp off after prove-out.
- **Fails when:** no DTC, wrong failure type, DTC before the qualification time, lamp state wrong,
  no heal.

### LMP-TC-07 (P1) PAB ON lamp output: short to battery, short to ground, open
- **Trace:** [CFG] 64, 69, 74 (GPO 1).
- **Steps and expected:** as LMP-TC-06 with `PAB_ON` and its DTC.
- **Fails when:** as LMP-TC-06.

### LMP-TC-08 (P1) Lamp output faults during under-voltage and over-voltage
- **Why P1:** LMP-BUG-04.
- **Trace:** [CFG] 63-82 (voltage enable conditions on short, open and configuration faults of
  GPO 0-2). Supply levels: `power_config`.
- **Steps:** for PAB OFF, PAB ON and ENS, with OPEN (then S2G):
  1. Go to `UNDERVOLTAGE_TEST_VOLTAGE`. Apply the fault. Wait 10 s. Read DTCs.
  2. Return to 12 V. Read DTCs after the qualification time.
  3. Remove the fault; DTC heals. Apply it again at 12 V (DTC active). Go to under-voltage; read
     the DTC status after 10 s. Remove the fault during under-voltage; wait 10 s; read. Return to
     12 V; read after the heal time.
  4. Repeat 1-3 with `OVERVOLTAGE_TEST_VOLTAGE`.
- **Expected:** during the voltage fault the lamp DTC does not change (not set in step 1, not healed
  in step 3). After return it follows the real state within the qualification / heal time.
- **Fails when:** the lamp DTC is set or healed during the voltage fault, or is wrong after return.

### LMP-TC-09 (P1) Non-latched warning lamp fault: on with the fault, off after heal
- **Why P1:** the largest class of the fault table (`WL_ON`, 1340 entries).
- **Trace:** [CFG] e.g. 698 (`LOOP_F_OPEN_00`, driver pretensioner squib open: `WL_ON`, not
  latched).
- **Steps:**
  1. Open one squib loop (`SET_LOOPS_LOADS` / `SQUIB.SendRequest(<loop>, "OPEN")`). Read DTCs and
     the lamp after the qualification time of the loop fault.
  2. Restore the loop. Read DTCs and the lamp after its heal time.
  3. Repeat with one fault of another family that is `WL_ON` (for example a buckle switch fault).
- **Expected:** 1: DTC active, lamp on. 2: DTC healed, lamp off, without ignition cycle.
- **Fails when:** lamp off with the fault active, or still on after the heal.

### LMP-TC-10 (P1) Lamp configuration error: set, latched, healed after correction
- **Why P1:** LMP-BUG-05.
- **Trace:** [CFG] 98-100 (`GPO_F_UNEXEPCTED_LOAD_0/1/2`: `WL_ON`, latched; DTC events
  `LAMP_E_PASSENGER_AIRBAG_DISABLE_LAMP_CONFIGURATION_ERROR`,
  `GPO_E_PAB_ON_LED_LINE_CONFIGURATION_ERROR`, `GPO_CRASH_OUTPUT_E_CONFIGURATION_ERROR`); 78-80
  (`GPO_F_CFG_x`). EOL bits [FW] `eol_config` (`PABD_LAMP_HW`, `CRASH_OUTPUT_HW_LINE`).
- **Steps:** for the PAB OFF lamp (then PAB ON, ENS):
  1. Write the EOL with the output de-configured, load still connected. Ignition cycle. Read DTCs
     and the lamp.
  2. Write the correct EOL without ignition cycle. Read DTCs.
  3. Ignition cycle. Read DTCs and the lamp.
  4. Opposite case: output configured, load removed: this is the OPEN fault of LMP-TC-06, no
     configuration DTC.
- **Expected:** 1: configuration DTC of that output active, warning lamp on. 2: still active
  (latched). 3: healed, lamp off (confirm the heal rule with the requirement).
- **Fails when:** no configuration DTC; the DTC stays active after step 3.

### LMP-TC-11 (P1) Latched-lamp fault that is not a crash: lamp stays on for the ignition cycle
- **Why P1:** 131 satellite faults and others are `WL_LATCHED` in the table.
- **Trace:** [CFG] `RSU_F_SAT_OPEN_xx`, `RSU_F_SAT_COMM_xx` ... (`WL_LATCHED`). The exact meaning of
  "latched lamp" is in `WLMgr` (not in the snapshot): expected result is an inference from the name.
- **Steps:**
  1. Set one satellite open (`SetRsuFaultCondition`). Read DTC and lamp.
  2. Remove the fault. Wait 10 s. Read DTC and lamp.
  3. Ignition cycle. Read DTC and lamp.
- **Expected:** 1: DTC active, lamp on. 2: lamp still on in the same ignition cycle. 3: lamp off
  after prove-out if the fault is gone.
- **Fails when:** lamp off in step 1; lamp on in step 3 without fault. Step 2 result to be confirmed
  with the requirement.

### LMP-TC-12 (P1) Deployments configured without warning lamp
- **Why P1:** LMP-BUG-03.
- **Trace:** [CFG] 1571, 1580, 1582-1584 (`WL_OFF`): anti-submarining, rollover bar, windscreen
  airbag, belt load limiter, hood lifter.
- **Steps:** only if M210 has one of these loops in its EOL: crash that fires it. Read the lamp and
  DTCs.
- **Expected:** lamp on after any deployment (through the crash-direction event). To be confirmed.
- **Fails when:** a loop fired and the lamp is off. **Not applicable** if none of the loops exists.

### LMP-TC-18 (P1) [KB] Warning lamp prove-out at ignition on
- **Why P1:** the driver's lamp check.
- **Trace:** [KB] 6 s on, then off when fault free. No M210 source.
- **Steps:** ignition on. Log `INDC_SRS` from the first frame for 15 s. Repeat with a fault active
  (LMP-TC-09) and after a crash.
- **Expected:** fault free: on for the prove-out time, then off. With a fault or after a crash: on,
  no off phase.
- **Fails when:** no prove-out; lamp off phase with an active fault.

### LMP-TC-19 (P1) [KB] PAB ON / OFF lamps follow the passenger airbag switch signal
- **Why P1:** wrong PAB indication misleads the passenger.
- **Trace:** [KB]; signal `PSGR_AIRBAG_SW_IC` [FW] `canc_config`. No M210 source.
- **Steps:**
  1. `PSGR_AIRBAG_SW_IC` = 0 (airbag enabled): read both lamp loops, `INDC_PADL`, the DID bits.
  2. `PSGR_AIRBAG_SW_IC` = 1 (disabled): same reads. Measure the time to the lamp change.
  3. Toggle 20 times at 200 ms; check the final state. Send every other value of the signal.
- **Expected [KB]:** 0: PAB ON lamp on, PAB OFF lamp off, `INDC_PADL` = 0. 1: PAB OFF on, PAB ON
  off, `INDC_PADL` = 1. Never both on or both off after the change. Invalid values: per requirement.
- **Fails when:** lamp state differs; both lamps in the same state.

---

## 4. P2 test cases

### LMP-TC-13 (P2) Lamp state stored in the crash record
- **Why P2:** LMP-BUG-06.
- **Trace:** [EDR] `RstEdr_Cfg.h` 2670 (`OpsWlStatus`), 2859 (PADI state), `RstEdr.c` 4603-4609.
- **Steps:** front crash in each condition, then read the warning-lamp and PAD lamp elements of the
  record (`read_edr_parameters`):
  1. lamp off, PAB enabled; 2. lamp on from an active squib-open fault; 3. PAB disabled
  (`PSGR_AIRBAG_SW_IC` = 1); 4. crash 2 s after ignition on (inside prove-out).
- **Expected:** warning lamp element: off / on / off / per requirement for prove-out. PAD lamp
  element: off / off / on.
- **Fails when:** the record differs from the lamp state at the event.

### LMP-TC-14 (P2) Lamp faults right after battery connect and without valid wake-up
- **Trace:** [CFG] battery-connect and invalid-wake-up enable conditions on all GPO faults.
- **Steps:**
  1. Apply PAB OFF lamp OPEN with the ECU off. Battery and ignition on. Read DTCs every 500 ms for
     10 s.
  2. Battery on, ignition off, no CAN: apply the fault; wait 10 s; ignition on; read DTCs.
- **Expected:** the DTC appears after the battery-connect inhibition plus the qualification time
  (once, no toggling); in step 2 only after ignition on.
- **Fails when:** the DTC never appears, or toggles.

### LMP-TC-15 (P2) Control DTC setting off
- **Trace:** [CFG] `CONTROLDTC` enable condition on every fault.
- **Steps:** extended session, `85 02`. Apply PAB ON lamp OPEN; wait 10 s; read DTCs and the lamp.
  `85 01`; read after the qualification time.
- **Expected:** no DTC while the setting is off; DTC and lamp after `85 01`.
- **Fails when:** DTC stored while off; none after on.

### LMP-TC-16 (P2) Faults configured without warning lamp do not light it
- **Trace:** [CFG] `WL_OFF` entries, for example `EPS_NODE_ABSENT`, `HPCC_NODE_ABSENT`,
  `ECU_IN_PLANT_MODE`.
- **Steps:** stop the key frame of one such node (`CAN.PeriodicDisableFrame`). After the node-absent
  time read DTCs and the lamp. Restore.
- **Expected:** node-absent DTC active, warning lamp off.
- **Fails when:** the lamp comes on.

### LMP-TC-20 (P2) [KB] PAB switch frame missing or invalid
- **Trace:** [KB]. No M210 source.
- **Steps:** with `PSGR_AIRBAG_SW_IC` = 1 (PAB OFF lamp on): stop its frame. Read lamps,
  `INDC_PADL`, DTCs after the time-out. Restore. Repeat with a wrong CRC / alive counter.
- **Expected [KB]:** default: PAB ON lamp on, PAB OFF lamp off; time-out DTC; back to the signal
  value after the frame returns.
- **Fails when:** lamps keep the last value or both go off.

### LMP-TC-21 (P2) [KB] Lamp IO control
- **Trace:** [KB]; IO-control DIDs from the M210 diagnostic specification. No M210 source.
- **Steps:** for the warning lamp, PAB ON and PAB OFF: default session (expect a negative
  response); extended session with security: on, off, return control; session time-out with the
  control active.
- **Expected:** the lamp follows the request; after return or time-out it shows the real state; no
  DTC from the control.
- **Fails when:** the lamp stays forced after return; a lamp DTC is stored.

### LMP-TC-22 (P2) Lamp state on CAN, in the DID and on the pin agree
- **Trace:** [FW] `cand_config` lamp status DIDs, `canc_config` `INDC_SRS`, `INDC_PADL`.
- **Steps:** in LMP-TC-01, 06, 09 and 19 read all three sources at the same step.
- **Expected:** the same state from all three, in every step.
- **Fails when:** one source differs for more than one frame period.

### LMP-TC-23 (P2) Lamp outputs with a crash
- **Trace:** [SRC] crash events `WL_LATCHED`; ENS-TC-16.
- **Steps:** PAB OFF lamp OPEN active (DTC stored), then front crash. Read DTCs and the lamp.
  Remove the lamp fault; read after the heal time.
- **Expected:** crash DTCs stored, lamp on; after the heal the lamp stays on (crash), the lamp DTC
  heals.
- **Fails when:** the crash DTC is missing, or the lamp goes off with the heal.

---

## 5. P3 test cases

### LMP-TC-17 (P3) Unused GPO channels give no fault
- **Trace:** LMP-BUG-08; [CFG] GPO 3 and 4 control-disabled.
- **Steps:** fault-free bench; read all DTCs (and internal faults if available) after 60 s.
- **Expected:** no GPO DTC.
- **Fails when:** a GPO DTC without an applied fault.

### LMP-TC-24 (P3) Thermal, internal and SPI faults of the GPO driver
- **Trace:** [CFG] 83-97 (`WL_ON`; thermal latched; no voltage condition).
- **Steps:** not creatable from outside without overloading the output. Indirect check: keep PAB
  OFF lamp S2B for 10 minutes; read DTCs every minute.
- **Expected:** S2B DTC only; if a thermal DTC appears it stays until the ignition cycle.
- **Fails when:** an internal or SPI GPO fault appears. Otherwise **not testable** black box.

---

## 6. Coverage

| Lamp behaviour | Evidence | Test cases |
|---|---|---|
| Lamp after crash, every direction | [SRC] [CFG] | TC-01, TC-02 |
| Crash latch over restarts, clear | [SRC] | TC-03, TC-04, TC-05 |
| Lamp classes: on, latched, off | [CFG] | TC-09, TC-11, TC-16, TC-12 |
| GPO faults: short, open | [CFG] | TC-06, TC-07 (ENS output: ENS-TC-16) |
| GPO faults: enable conditions | [CFG] | TC-08, TC-14, TC-15 |
| GPO configuration, latch | [CFG] | TC-10 |
| Unused channels, driver internal faults | [CFG] | TC-17, TC-24 |
| Lamp state in the crash record | [EDR] | TC-13 |
| Lamp with a crash and a lamp fault together | [SRC] [CFG] | TC-23 |
| Prove-out, PAB lamp logic, IO control | [KB] only | TC-18, TC-19, TC-20, TC-21 |
| Consistency CAN / DID / pin | [FW] | TC-22 |

**Not covered, and why:**
- Anything decided inside `WLMgr`, `PADI` and `GpoMgr` beyond the rows above: no source in the
  snapshot. Request these modules to complete the review.
- Qualification and heal times of the GPO faults: the fault table has the counter limits only; the
  2 s / 4 s in `gpo_config` are M314 values.
- `OPS_E_BACK_IMPACT_FIRED` (latched lamp, never raised, ENS-BUG-19): nothing to observe; the rear
  crash lamp is checked in TC-02.
- Lamp dimming or flashing patterns: none found in the reviewed files.
