"""Module: LAMPS (M210)"""
