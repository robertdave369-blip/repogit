# M210 ENS (crash output): black-box test cases

Derived from the ECU source in `C:\Project_M210` (`EnsMgr.c` rev 1.1.2.25.4.2, `EnsMgr_PBCfg.h`,
`EnsMgr_Swc.arxml`, P31 `FltMonr_PBCfg.h`). Findings referenced as ENS-BUG-xx are in
`ENS_and_Lamps_Potential_Bugs.md`.

The test cases are in **priority order, highest first**. The IDs are fixed names, not the order.

| Priority | Meaning |
|---|---|
| **P0** | Crash notification lost or wrong: safety impact. Run first, every release |
| **P1** | Wrong crash information or a main function wrong; likely to be hit |
| **P2** | Corner condition, robustness, configuration |
| **P3** | Internal information only, or needs an invalid configuration |

## 1. Common data

### 1.1 Expected values (from the source)

| Item | Expected | Tolerance | Source |
|---|---|---|---|
| Normal high / low | 6.0 ms / 4.0 ms | +/- 0.5 ms (one ECU tick) | `EnsMgr_PBCfg.h` 69, 74 |
| Normal period, frequency, duty | 10 ms, 100 Hz, 60 % high | from the above | |
| Crash high / low | 4.0 ms / 6.0 ms | +/- 0.5 ms | `EnsMgr_PBCfg.h` 78, 83 |
| Crash run | 800 ms, 80 pulses, one run, starts with a low | 799.5 to 805.5 ms | `EnsMgr_PBCfg.h` 64; `EnsMgr.c` 454-566 |
| First low of the crash run | 6 to 10.5 ms (may carry the rest of a normal low) | +/- 0.5 ms | `EnsMgr.c` 110-155, 459-492 |
| First pulse after the run | 4 ms low, then 6 ms high | +/- 0.5 ms | `EnsMgr.c` 529-549 |
| Output without valid wake-up, at init, in power-down | steady high | | `EnsMgr.c` 638-655, 1230-1249 |
| Init pulse after ignition on | **not in the source** (no timer in `EnsMgr`). Limit used: 450 ms [KB, M314 family]; W610 measured about 135 ms. **To be confirmed for M210** | | |
| CAN crash status update | every 25 ms | + one frame period | arxml `PERIOD 0.025` |

The 40 ms, 62.5 % / 37.5 % pattern of the M314 family does **not** apply to M210.

### 1.2 Signals, DTCs, services

- CAN (framework `canc_config`, frame `SRS1_FD_10`; `SRS1_20` on HS-CAN): `STS_CRASH`,
  `CRASH_LOCATION` (front 1, right 2, left 3, rear 4; understrike 7 per the W610 bench record: confirm
  in the M210 DBC), `NEAR_CRASH`, `INDC_SRS`.
- Crash DTC events (P31 `FltMonr_PBCfg.h`): `E_CRASH_DETECT_FRONT`, `E_CRASH_DETECT_SIDE_LEFT`,
  `E_CRASH_DETECT_SIDE_RIGHT`, `E_CRASH_DETECT_REAR`, `E_CRASH_DETECT_UNDERSTRIKE`,
  `E_ECU_LOCKED_DUE_TO_PT_DEPLOYMENT`. DTC numbers: `fault_list_config` (`ECU_LOCK_FRONT` 906196,
  `ECU_LOCK_LH_SIDE` 920100, `ECU_LOCK_RH_SIDE` 991600, `ECU_LOCK_REAR` 921E00, `ECU_LOCK_UNDERSTRIKE`
  925200, `ECU_LOCK_PT_DEPLOY` 921A00), mapped in `gpo_config.ENS_CRASH_DTC`. That the "ECU locked"
  DTC is the crash-detect event is an inference (shown for understrike only).
- ENS output fault DTC: `gpo_config.DTC_GPO_fault["ENS"]` with failure type from `GPO_FaultStatus`;
  configuration error `GPO_CRASH_OUTPUT_E_CONFIGURATION_ERROR`.
- Crash counters: DID 0458 (named in `EnsMgr.c` 1020; 5 bytes in the M210 diagnostic specification
  V3.4, byte order not in the reviewed source). ENS IO control: DID F010 ACTIVATE CRASH, byte 0 bit 0
  (diagnostic specification V3.4, sheet IOControl; requests in `cand_config`).

### 1.3 Measurement

- **Pin:** ARIA lamp card recording of the `ENS` loop (`LAMPS.StartLampMonitoring`, then
  `LAMPS.GetLampRecordedSamples`: edges with time), as in the three scripts; or a logic analyser /
  oscilloscope on the ENS pin with at least 100 kS/s. The output is low-side: pin low = driver on.
- **CAN:** log `SRS1_FD_10` with time stamps.
- **Crash:** ARIA crash curves from `crash_data` (front, left, right, rear, underbody, near,
  multi-event sets), loaded with the ECU off, one replay per test.

### 1.4 Preconditions and postconditions (every test case)

Precondition: bench fault free (`fault_free_profile`), default EOL and variant code, 12 V, ignition
on, prove-out complete, no DTC. Postcondition: clear the crash data (NVM clear as the EDR scripts
do), fault free again. A test is **blocked**, not failed, when the precondition cannot be reached.

### 1.5 Automated scripts

One script per test case in `modules/ENS/scripts`; expected values from
`projects/M210/config/gpo_config.py` and the other M210 configs. None has run on the bench yet.

| Test case | Script | Not automated / note |
|---|---|---|
| ENS-TC-01 | `M210_ENS_03_CrashInversion.py` |  |
| ENS-TC-02 | `M210_ENS_TC02_CrashAfterIoControlReturned.py` |  |
| ENS-TC-03 | `M210_ENS_TC03_SupplyLostDuringCrashPulse.py` | battery-loss runs reported, not graded (hold time needs the requirement) |
| ENS-TC-04 | `M210_ENS_TC04_CanCrashStatusEveryDirection.py` |  |
| ENS-TC-05 | `M210_ENS_TC05_CrashDtcLockAndLampEveryDirection.py` |  |
| ENS-TC-06 | `M210_ENS_02_PwmTiming.py` |  |
| ENS-TC-07 | `M210_ENS_01_InitPulse.py` |  |
| ENS-TC-08 | `M210_ENS_TC08_CrashInversionOtherDirections.py` |  |
| ENS-TC-09 | `M210_ENS_TC09_CrashAtEveryPulsePosition.py` |  |
| ENS-TC-10 | `M210_ENS_TC10_NearCrash.py` |  |
| ENS-TC-11 | `M210_ENS_TC11_TwoCrashesDifferentDirection.py` | 100, 400 and 2000 ms sets; no 1000 ms set exists |
| ENS-TC-12 | `M210_ENS_TC12_OneCrashRunPerCrash.py` |  |
| ENS-TC-13 | `M210_ENS_TC13_PwmAfterIgnitionOffOn.py` |  |
| ENS-TC-14 | `M210_ENS_TC14_InvalidWakeup.py` |  |
| ENS-TC-15 | `M210_ENS_TC15_LowSeverityFrontCrash.py` | blocked until `gpo_config.ENS_LOW_SEVERITY_FRONT_SET` names a set |
| ENS-TC-16 | `M210_ENS_TC16_OutputFaults.py` |  |
| ENS-TC-17 | `M210_ENS_TC17_CrashDuringIoControlPulse.py` |  |
| ENS-TC-18 | `M210_ENS_TC18_IoControl.py` | EDR record check not automated |
| ENS-TC-19 | `M210_ENS_TC19_ResetDuringCrashPulse.py` |  |
| ENS-TC-20 | `M210_ENS_TC20_CrashCounters.py` | byte order of DID 0458 reported, not graded |
| ENS-TC-21 | `M210_ENS_TC21_CrashDtcStays.py` |  |
| ENS-TC-22 | `M210_ENS_TC22_CrashOutputDeconfigured.py` |  |
| ENS-TC-23 | `M210_ENS_TC23_UnderAndOverVoltage.py` |  |
| ENS-TC-24 | `M210_ENS_TC24_CrashOutsideCrashMode.py` | EDR record check and plant-mode run not automated |
| ENS-TC-25 | `M210_ENS_TC25_LongRun.py` |  |
| ENS-TC-26 | `M210_ENS_TC26_PinAndCanAgreeInTime.py` |  |
| ENS-TC-27 | `M210_ENS_TC27_FrontCrashNotUnderstrike.py` | crash location of the EDR record not automated |
| ENS-TC-28 | `M210_ENS_TC28_FrontalDeploymentInternalFaults.py` | passenger-airbag-disabled run not automated |
| ENS-TC-29 | `M210_ENS_TC29_UnderstrikeWithoutArming.py` |  |
| ENS-TC-30 | `M210_ENS_TC30_SideDeploymentFaultsSteeringPosition.py` |  |
| ENS-TC-31 | `M210_ENS_TC31_InitTimeFromIgnitionOn.py` | limit 450 ms not confirmed for M210 |
| ENS-TC-32 | `M210_ENS_TC32_InitTimeFromCanWakeup.py` | limit 450 ms not confirmed for M210 |

`check_ens_scripts_offline.py` runs every script against a simulated ECU (no bench): each must pass
on a good ECU and fail on the fault planted for it.

---|---|
| `M210_ENS_01_InitPulse.py` | ENS-TC-07 |
| `M210_ENS_02_PwmTiming.py` | ENS-TC-06 |
| `M210_ENS_03_CrashInversion.py` | ENS-TC-01 |
| `check_ens_scripts_offline.py` | offline check of the three scripts (no bench) |

---

## 2. P0 test cases

### ENS-TC-01 (P0) Front crash: inverted PWM for 800 ms
- **Why P0:** the main function of the output; if wrong, the crash is not notified.
- **Trace:** `EnsMgr.c` 110-175, 454-566. Script `M210_ENS_03_CrashInversion.py`.
- **Steps:**
  1. Load the front crash set with the ECU off. Battery on, ignition on, wait for prove-out.
  2. Start a 3 s recording of the ENS pin. After 500 ms trigger the crash.
  3. Read the edges. Find the inverted run (lows above 5 ms).
- **Expected:**
  1. Before the crash at least 10 pulses of 6 / 4 ms.
  2. Inverted run 799.5 to 805.5 ms long, 80 pulses, no normal pulse inside.
  3. First low of the run 6 to 10.5 ms; every later low 6 ms, every high 4 ms.
  4. After the run: 4 ms low, then 6 / 4 ms pulses, at least 10.
- **Fails when:** any of 1-4 is not met; no inverted run; two runs.

### ENS-TC-02 (P0) Crash after ENS IO control was returned: still 800 ms
- **Why P0:** ENS-BUG-01: a real crash would be notified with a short pulse after a workshop test.
- **Trace:** `EnsMgr.c` 1107-1132, 459-466, 497, 529-538.
- **Steps:**
  1. Extended session, security access. Start recording.
  2. Start ENS IO control (short-term adjustment). After **300 ms** send return-control-to-ECU.
  3. Wait 5 s. Check normal PWM. Trigger a front crash. Record 3 s.
  4. Repeat with 100 ms and 700 ms in step 2. Repeat with an ignition cycle between steps 2 and 3
     (reference run).
- **Expected:** in every run the crash gives 80 inverted pulses, 799.5 to 805.5 ms; `STS_CRASH` = 1
  for 800 ms; crash DTC stored.
- **Fails when:** the run after the crash is shorter (about 800 ms minus the IO-control time), or
  `STS_CRASH` is missing.

### ENS-TC-17 (P0) Crash while an ENS IO-control pulse runs, and return-control during a crash pulse
- **Why P0:** ENS-BUG-02: crash notified for less than 800 ms.
- **Trace:** `EnsMgr.c` 166-169, 529-538, 1127-1132.
- **Steps:**
  1. Start ENS IO control. 600 ms later trigger a front crash. Record pin and CAN.
  2. New run: trigger a front crash. 200 ms later send return-control for the ENS DID.
- **Expected:** both runs: inverted pulses and `STS_CRASH` = 1 for 800 ms counted from the crash.
- **Fails when:** the inverted run ends about 200 ms after the crash (step 1) or at the
  return-control (step 2); `STS_CRASH` shorter than 750 ms.

### ENS-TC-03 (P0) Supply lost during the crash pulse
- **Why P0:** ENS-BUG-03: ignition and battery are often lost in a crash.
- **Trace:** `EnsMgr.c` 1292-1297, 1230-1236. Expected behaviour from [KB] (pulse completed from the
  energy reserve): confirm with the M210 requirement.
- **Steps:** trigger a front crash while recording, then:
  1. ignition off 50 ms after the trigger, battery stays on;
  2. ignition off after 200 ms; 3. after 600 ms;
  4. battery and ignition off after 50 ms; 5. after 200 ms.
- **Expected:** inverted run of 800 ms in runs 1-3. Runs 4-5: inverted pulses for as long as the
  requirement states (energy reserve), no steady level before that.
- **Fails when:** the pin goes steadily high (or low) before the 800 ms, while the ECU is still
  powered.

### ENS-TC-04 (P0) Crash status on CAN for every crash direction
- **Why P0:** CAN is the second crash notification path (unlock, eCall).
- **Trace:** `EnsMgr.c` 187-236, 581-607; `canc_config` `CAN_SIGNAL_Rx_EXPECTED_VALUES`.
- **Steps:** for each set (front, left, right, rear, underbody): replay once, log `SRS1_FD_10` for
  5 s, record the pin.
- **Expected:**

  | Crash | `STS_CRASH` | `CRASH_LOCATION` |
  |---|---|---|
  | front | 1 | 1 |
  | right | 1 | 2 |
  | left | 1 | 3 |
  | rear | 1 | 4 |
  | underbody | 1 | 7 (confirm in the DBC) |

  `STS_CRASH` = 1 starts within 25 ms + one frame period of the first inverted low and lasts
  800 ms +/- (25 ms + one frame period), then 0 and the location back to 0. One period only.
- **Fails when:** wrong location, status missing, shorter than 750 ms, or a second period.

### ENS-TC-05 (P0) Crash DTC, ECU lock and warning lamp for every crash direction
- **Why P0:** the crash must be stored.
- **Trace:** `EnsMgr.c` 735-1000; P31 `FltMonr_PBCfg.h` 1570-1587, 1620, 1654.
- **Steps:** for each set: replay once, wait 2 s, read DTCs with status (`19 02`), read `INDC_SRS`.
- **Expected:** the crash-detect DTC of the direction is active; `E_ECU_LOCKED_DUE_TO_PT_DEPLOYMENT`
  active when a pretensioner fired; warning lamp on; no crash DTC of another direction.
- **Fails when:** DTC missing, DTC of a direction that did not crash, lamp off.

### ENS-TC-06 (P0) Normal PWM timing
- **Why P0:** the receiver reads "ECU alive, no crash" from this pattern; ENS-BUG-21.
- **Trace:** `EnsMgr.c` 373-431; `EnsMgr_PBCfg.h` 69, 74. Script `M210_ENS_02_PwmTiming.py`.
- **Steps:** ignition on, prove-out complete. Record the pin for 2 s. Measure every whole pulse.
- **Expected:** every high 6.0 +/- 0.5 ms, every low 4.0 +/- 0.5 ms, every period 10 +/- 0.5 ms;
  frequency 95.2 to 105.3 Hz; duty 55 to 65 %; 200 +/- 2 pulses in 2 s.
- **Fails when:** one pulse is outside the limits or pulses are missing.

---

## 3. P1 test cases

### ENS-TC-07 (P1) Init pulse at ECU start
- **Why P1:** start-up signature of the line; the limit is not yet confirmed for M210.
- **Trace:** `EnsMgr.c` 638-655, 1313-1363. Script `M210_ENS_01_InitPulse.py`.
- **Steps:**
  1. Battery and ignition off, wait for the ECU to be off.
  2. Start a 3 s recording. After 300 ms battery on, 100 ms later ignition on.
  3. Read the edges: the long high and the first falling edge.
- **Expected:** the pin is high without any edge from supply on until the PWM starts; the PWM
  starts at most 450 ms after ignition on (limit to be confirmed); it starts with a 4 ms low, then
  20 pulses of 6 / 4 ms.
- **Fails when:** an edge inside the init pulse, init pulse longer than the limit, wrong first
  pulses.

### ENS-TC-08 (P1) Left, right, rear and underbody crash: inverted PWM for 800 ms
- **Why P1:** same function as ENS-TC-01 through the other algorithm inputs.
- **Trace:** `EnsMgr.c` 262-266; thresholds `EnsMgr_PBCfg.h` 122-138.
- **Steps:** as ENS-TC-01 with the left, right, rear and underbody sets.
- **Expected:** as ENS-TC-01 for each set. Rear: rear crash DTC and warning lamp (ENS-BUG-19).
- **Fails when:** as ENS-TC-01.

### ENS-TC-09 (P1) Crash at every position of the normal pulse (change-over)
- **Why P1:** ENS-BUG-16: the first pulses of the run depend on where the crash meets the pulse.
- **Trace:** `EnsMgr.c` 110-155, 459-492.
- **Steps:** 11 runs. Trigger the crash 0, 1, 2 ... 10 ms after a rising edge of the pin (or 20
  runs with a free-running trigger). Record each.
- **Expected:** last normal high 0.5 to 6.5 ms; first inverted low 6 to 10.5 ms; all other pulses
  4 / 6 ms; run 799.5 to 805.5 ms; 80 pulses.
- **Fails when:** a pulse shorter than 0.5 ms (glitch), a low above 11 ms, or a run outside the
  limits.

### ENS-TC-10 (P1) Near crash
- **Why P1:** ENS-BUG-07; a near crash must not look like a crash.
- **Trace:** `EnsMgr.c` 287-313; `canc_config` expected values "near".
- **Steps:** replay the near-crash set. Record the pin 3 s, log CAN 5 s, read DTCs.
- **Expected:** no inverted pulse; `NEAR_CRASH` = 1 for one period of about 800 ms, then 0;
  `STS_CRASH` = 0, `CRASH_LOCATION` = 0; no crash DTC; warning lamp off.
- **Fails when:** inverted pulses, `STS_CRASH` = 1, a crash DTC, a second `NEAR_CRASH` period or a
  one-frame drop inside the period.
- **Also:** in ENS-TC-01 log `NEAR_CRASH`: after `STS_CRASH` returns to 0 no new `NEAR_CRASH` period
  may start.

### ENS-TC-11 (P1) Two crashes of different direction
- **Why P1:** ENS-BUG-06, ENS-BUG-05: location on CAN for multi-impact.
- **Trace:** `EnsMgr.c` 166-169, 220-226, 529-538.
- **Steps:** multi-event sets front then left with T0 distances 100 ms, 400 ms, 1000 ms and 2000 ms.
  Record pin and CAN 6 s; read DTCs.
- **Expected (from the source, to be checked against the requirement):** both crash DTCs in every
  run. Distances below 800 ms: one inverted run of 800 ms from the first crash, `CRASH_LOCATION`
  = 1 only. Distances above 800 ms: a second run of 800 ms with `CRASH_LOCATION` = 3.
- **Fails when:** a DTC is missing; the pin shows a run that is neither 800 ms nor two clean runs;
  the result contradicts the customer requirement for multi-impact.

### ENS-TC-12 (P1) Exactly one crash run per crash
- **Why P1:** ENS-BUG-05: a repeated run looks like a second crash.
- **Trace:** `EnsMgr.c` 210-226, 271-275, 535.
- **Steps:** each crash set once; record the pin and CAN for 6 s after the trigger.
- **Expected:** one inverted run, one `STS_CRASH` period; normal PWM for the rest.
- **Fails when:** a second run or period starts.

### ENS-TC-13 (P1) PWM returns after ignition off / on
- **Why P1:** ENS-BUG-04: line dead until the next reset.
- **Trace:** `EnsMgr.c` 1292-1297, 1323, 1379-1382.
- **Steps:**
  1. Battery on, restbus running. Ignition off for 0.2 s, then on. Record 2 s.
  2. Repeat with 0.5 s, 1 s, 2 s, 5 s, 10 s off time.
  3. After the 1 s run trigger a front crash.
- **Expected:** during ignition off the pin is steady high (or PWM, per the wake-up state: note
  it); after ignition on the 6 / 4 ms PWM is back within the init time; the crash gives 800 ms.
- **Fails when:** the pin stays high after ignition on; no crash run.

### ENS-TC-14 (P1) Invalid wake-up: output high, PWM back with a valid wake-up
- **Why P1:** defined state of the line with battery only; ENS-BUG-12.
- **Trace:** `EnsMgr.c` 1205-1249; W610 record `W610_ENS_TEST_09`.
- **Steps:**
  1. Battery on, ignition off, no CAN: record 2 s.
  2. Ignition on: record.
  3. Ignition off, CAN messages of the invalid wake-up state: record 2 s.
  4. Wake the ECU over CAN (`CAN_Wakeup`), then release: record.
  5. Change between valid and invalid 20 times; measure the delay to PWM start and stop.
- **Expected:** steps 1 and 3: steady high, no edge. Steps 2 and 4: PWM 6 / 4 ms. Step 5: PWM stops
  and starts within about 30 ms of the change, every time.
- **Fails when:** PWM during invalid wake-up, no PWM during valid wake-up, delay above 30 ms.

### ENS-TC-15 (P1) Front crash of low severity (pretensioners only)
- **Why P1:** ENS-BUG-08: logged but not notified; needs the requirement.
- **Trace:** `EnsMgr.c` 210-226; `EnsMgr_PBCfg.h` 123, 126.
- **Steps:** front set that fires pretensioners only. Record pin, log CAN, read DTCs.
- **Expected (source):** front crash DTC and ECU-locked DTC, warning lamp on; **no** inverted run,
  `STS_CRASH` = 0. Compare with the L10.
- **Fails when:** the result differs from the requirement (if the requirement asks for the crash
  output at any deployment, the source behaviour is the failure).

### ENS-TC-16 (P1) ENS output faults: short to battery, short to ground, open
- **Why P1:** a faulty line must be diagnosed; the crash pulse must not look valid on a faulty line.
- **Trace:** P31 `FltMonr_PBCfg.h` 65, 70, 75, 100 (GPO 2). Electrical signature and times from
  `gpo_config` / [KB]: confirm.
- **Steps:** for each fault (`SetGpoFaultCondition("ENS", "S2B" | "S2G" | "OPEN")`):
  1. Apply the fault. Read DTCs after the qualification time (`gpo_fault_time`).
  2. Record the pin 1 s. Check `INDC_SRS`.
  3. Trigger a front crash with the fault present; record the pin; read DTCs.
  4. Remove the fault; read DTCs after the heal time; record the pin.
- **Expected:** 1: ENS DTC with the failure type of the fault, active. 2: warning lamp on. 3: the
  crash DTCs are stored and `STS_CRASH` = 1 for 800 ms on CAN, whatever the pin shows. 4: DTC
  healed, PWM 6 / 4 ms back.
- **Fails when:** no DTC, wrong failure type, lamp off, crash not on CAN, PWM not back after heal.

### ENS-TC-18 (P1) ENS IO control
- **Why P1:** workshop function; base for ENS-TC-02 and ENS-TC-17.
- **Trace:** `EnsMgr.c` 1107-1132 (IO control requests the crash pattern; it ends by time-out).
- **Steps:**
  1. Default session: request the IO control: negative response expected.
  2. Extended session, security access: short-term adjustment. Record pin 3 s, log CAN.
  3. Return control. Record.
  4. Start IO control and leave the session (time-out, no tester present).
- **Expected:** 2: one inverted run of 800 ms, then normal PWM although the control is still
  active (source behaviour: confirm with the requirement); `STS_CRASH` stays 0, no crash DTC, no EDR
  record. 3 and 4: normal PWM.
- **Fails when:** `STS_CRASH` = 1 or a crash DTC from IO control; inverted pulses after return or
  session time-out.

### ENS-TC-21 (P1) Crash DTC stays: clear, ignition cycles, battery cycle
- **Why P1:** LMP-BUG-07, LMP-BUG-01: the crash must stay stored and the lamp on.
- **Trace:** `EnsMgr.c` 668-713, 954-1000; W610 record `W610_ENS_TEST_07` step 7.
- **Steps:** front crash. Then: read DTCs; clear DTCs (`14 FF FF FF`); read; 3 ignition cycles,
  read after each; battery off 30 s / on, read.
- **Expected:** crash-detect DTC active and warning lamp on at every read.
- **Fails when:** the DTC or the lamp is gone at any read.

---

## 4. P2 test cases

### ENS-TC-19 (P2) ECU reset during the crash pulse
- **Trace:** ENS-BUG-13; `EnsMgr.c` 1313-1363.
- **Steps:** trigger a front crash; 200 ms later `11 01` (second run `11 03`; third run a 100 ms
  battery interruption). Record the pin 4 s; log CAN.
- **Expected:** after the restart: init high, then normal PWM; no inverted pulse and `STS_CRASH`
  = 0 after the restart; crash DTC still stored.
- **Fails when:** inverted pulses or `STS_CRASH` = 1 after the restart; crash DTC lost.

### ENS-TC-20 (P2) Crash counters (DID 0458)
- **Trace:** ENS-BUG-14; `EnsMgr.c` 1016-1057.
- **Steps:**
  1. Fault free: read DID 0458: all counters 0.
  2. Front crash; ignition cycle; read: front = 1, others 0.
  3. Second front crash in a new cycle; read: front still 1.
  4. Clean ECU; front crash; cut the battery 1 s after the crash; power on; read.
  5. Repeat 2 for left, right, rear, underbody.
- **Expected:** the counter of the crash type = 1, others unchanged, in every step.
- **Fails when:** a counter is 0 after its crash (step 4), or a wrong counter changes.

### ENS-TC-22 (P2) Crash output de-configured by EOL
- **Trace:** ENS-BUG-15; `eol_config` `CRASH_OUTPUT_HW_LINE` (byte 6 bit 0); W610 record
  `W610_ENS_TEST_05`.
- **Steps:**
  1. Write the EOL with the crash output de-configured (`manage_eol_code`). Ignition cycle.
  2. Record the pin 3 s from ignition on. Read DTCs.
  3. Trigger a front crash; record the pin; log CAN; read DTCs.
  4. Restore the EOL; ignition cycle; record the pin.
- **Expected:** 2: after the start phase a steady level, no PWM (W610: about 180 ms of normal
  pulses, then flat); no ENS fault DTC, or the configuration DTC if the load is still connected
  (per requirement). 3: no inverted run on the pin; crash DTC and CAN crash status present. 4: PWM
  back.
- **Fails when:** PWM or crash pulses with the output de-configured; crash not stored.

### ENS-TC-23 (P2) Under-voltage and over-voltage
- **Trace:** P31 `FltMonr_PBCfg.h` 65, 70, 75 (ENS faults inhibited by the voltage conditions);
  `power_config` test voltages. PWM behaviour under voltage faults is not in the source.
- **Steps:**
  1. `UNDERVOLTAGE_TEST_VOLTAGE`: record the pin 2 s; apply ENS open; read DTCs after 10 s; return
     to 12 V; read DTCs.
  2. Same with `OVERVOLTAGE_TEST_VOLTAGE`.
  3. Ramp 12 V to 9 V to 12 V and 12 V to 16 V to 12 V in 0.5 V steps; record at each step.
- **Expected:** inside the working range the PWM is 6 / 4 ms at every step. During the voltage
  fault no ENS DTC is set; after return the open DTC appears within the qualification time.
- **Fails when:** PWM timing changes with voltage inside the range; ENS DTC during the voltage
  fault; DTC missing after return.

### ENS-TC-24 (P2) Crash outside the normal crash mode
- **Trace:** ENS-BUG-11; `EnsMgr.c` 211, 1156, 1208.
- **Steps:**
  1. Battery on, ignition off (invalid wake-up): replay the front set. Ignition on: read DTCs, EDR
     records and loop deployment status.
  2. Plant mode, if a crash replay is allowed in it: same.
- **Expected:** if nothing fired and no EDR record exists: no DTC, no pulse (consistent). If a loop
  fired or a record exists: the crash DTC must exist.
- **Fails when:** deployment or EDR record without crash DTC.

### ENS-TC-25 (P2) Long run
- **Trace:** `EnsMgr.c` 373-431 (16-bit timers, restarted every pulse).
- **Steps:** record 60 s (largest lamp card window) 10 times over 30 minutes of ignition on.
- **Expected:** every pulse 6 / 4 ms +/- 0.5 ms; 6000 +/- 2 pulses per recording.
- **Fails when:** one pulse out of tolerance, a missing pulse, drift over time.

### ENS-TC-26 (P2) Pin and CAN agree in time
- **Trace:** ENS-BUG-17; `EnsMgr.c` 581-607, 1167.
- **Steps:** 20 front crashes. For each: time of the first inverted low, of `STS_CRASH` 0 to 1 and
  1 to 0, of the end of the run.
- **Expected:** `STS_CRASH` rises 0 to 25 ms + one frame period after the first inverted low and
  falls 0 to 25 ms + one frame period after the end of the run, in all 20.
- **Fails when:** `STS_CRASH` missing once, earlier than the pin, or later than the limit.

### ENS-TC-27 (P2) Severe front crash is not reported as understrike
- **Trace:** ENS-BUG-10; `EnsMgr.c` 266; `EnsMgr_PBCfg.h` 138.
- **Steps:** highest-severity front set, underbody channels at zero. Read DTCs, `CRASH_LOCATION`,
  crash location of the EDR record, DID 0458.
- **Expected:** front only.
- **Fails when:** understrike DTC, `CRASH_LOCATION` = 7, or the understrike counter = 1.

---

## 5. P3 test cases

### ENS-TC-28 (P3) Staged frontal deployment: internal faults
- **Trace:** ENS-BUG-18; `EnsMgr.c` 799-823.
- **Steps:** front crash with the passenger airbag enabled and staged firing. Read the internal
  fault list (if available on the bench).
- **Expected:** `OPS_E_FRONTAL_BAGS_FIRED` only. With the passenger airbag disabled:
  `OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBITED` only.
- **Fails when:** both are set. Blocked without internal fault read.

### ENS-TC-29 (P3) Understrike without arming
- **Trace:** ENS-BUG-09; `EnsMgr.c` 220, 276-280.
- **Steps:** underbody curve on the underbody sensor only (central sensors at zero). Record pin,
  log CAN, read DTCs.
- **Expected:** per requirement. Source: without arming, no pulse and no CAN status.
- **Fails when:** understrike DTC stored but neither pulse nor CAN status, against the requirement.
  Limited: arming cannot be set from outside.

### ENS-TC-30 (P3) Side deployment faults with left- and right-hand drive
- **Trace:** ENS-BUG-20; `EnsMgr.c` 829-867.
- **Steps:** steering position left (`SteeringWheelPosition_Config`), left crash, read faults;
  steering position right, left crash, read faults. Same for a right crash.
- **Expected:** the left crash sets the left lateral fault, the right crash the right one, with
  both steering positions.
- **Fails when:** the side is swapped. Blocked without internal fault read.

---

## 5a. Init time test cases (added 2026-11-13)

### ENS-TC-31 (P1) Init time from ignition on
- **Why P1:** ENS-BUG-21: the measured init pulse of the sister project did not match its limit.
- **Trace:** `EnsMgr.c` 638-655, 1203-1250 (output high until a valid wake-up; no init timer).
- **Steps:** battery stays on. 5 times: ignition off for the power-off delay; record the pin 3 s;
  ignition on 300 ms into the recording.
- **Expected:** pin high without an edge until the PWM starts; first PWM low at most 450 ms after
  ignition on (**M314 family limit, to be confirmed for M210**); then 6 ms high / 4 ms low, the
  first low included.
- **Fails when:** an edge before the PWM start; the PWM starts later than the limit; wrong PWM.
- **Note:** the time is counted from the ignition-on command of the script, so it is a range (before
  and after the command); the longest value is graded. ENS-TC-07 is the cold start (battery and
  ignition together).

### ENS-TC-32 (P1) Init time from a CAN wake-up
- **Why P1:** same as ENS-TC-31 for the second wake-up source.
- **Trace:** `EnsMgr.c` 1159-1164, 1347-1362 (valid wake-up); `canc_config` CAN wake-up settings.
- **Steps:** 5 times: ignition off for the power-off delay; record the pin; wake the ECU over CAN
  (`CAN_Wakeup`: restbus stopped 11 s, restbus started with `VCU_CANNM` `ACTIVE_WAKEUP_BIT` = 1,
  start-up delay 2 s); then `CAN_Wakeup_Restore`.
- **Expected:** `CAN_Wakeup` reports the ECU woken; pin high without an edge until the PWM starts;
  first PWM low at most 450 ms after the wake request (**to be confirmed for M210**); then 6 ms
  high / 4 ms low.
- **Fails when:** as ENS-TC-31.
- **Note:** the wake request is sent inside `CAN_Wakeup`, between "call + bus sleep wait" and
  "return - start-up delay": the init time is that range and the longest value is graded.

---

## 6. Coverage

| Function in the source | Lines (`EnsMgr.c`) | Test cases |
|---|---|---|
| Normal pattern | 373-431 | TC-06, TC-25, TC-23 |
| Init and output without valid wake-up | 638-655, 1203-1250, 1313-1363 | TC-07, TC-14, TC-13, TC-31, TC-32 |
| Crash request, thresholds, arming, crash mode | 187-236, 252-284 | TC-01, TC-08, TC-15, TC-24, TC-27, TC-29 |
| Crash pattern, time-out, return to normal | 110-175, 454-566 | TC-01, TC-09, TC-12, TC-11 |
| Near crash | 287-313 | TC-10 |
| CAN status | 581-607 | TC-04, TC-26, TC-11 |
| EDR shock information | 620-625 | TC-27 (crash location of the record); otherwise covered by the EDR scripts |
| Crash faults at start | 668-713 | TC-21, LMP-TC-03 |
| Deployment and crash DTCs | 735-1000 | TC-05, TC-21, TC-28, TC-30 |
| Crash counters | 1016-1057 | TC-20 |
| IO control | 1107-1132 | TC-18, TC-02, TC-17 |
| Power-down, start | 1271-1297, 1379-1382 | TC-03, TC-13 |
| Reset behaviour | 1313-1363 | TC-19 |
| Output faults, configuration | (GpoMgr, not in snapshot; P31 fault table) | TC-16, TC-22, TC-23 |

**Not covered, and why:**
- Calibration paths that the fixed calibration never takes (normal low or high time 0, crash start
  type low, "passed low / high" options, CAN or hardware output disabled): not reachable from
  outside without another calibration.
- `EnsMgr_GetEnsCrashPulseStartedFlag` (read by `CanMgr`): effect not visible in the reviewed
  source.
- Pedestrian and EPD severity inputs: defined in `EnsMgr_Cfg.h`, not used in `EnsMgr.c`.
- Init pulse limit, energy-reserve hold time, multi-impact rule, low-severity rule: expected values
  need the M210 requirement (marked in TC-07, TC-03, TC-11, TC-15).
