# M210 ENS and Lamps: potential bugs from the source review

Review date: 2026-11-12. Reviewed snapshot: `C:\Project_M210`.

These are **potential** bugs: each one is a behaviour the code can produce, found by reading the
source. None has been reproduced on the bench. Each entry says what to do on the bench to confirm or
dismiss it, using only inputs and outputs visible from outside the ECU.

## 1. What was reviewed, and what was not

| Evidence tag | Source | Used for |
|---|---|---|
| **[SRC]** | `SwEntities/Application/Ops/EnsMgr/Implementation/Source/EnsMgr.c` (rev 1.1.2.25.4.2), `EnsMgr_Intl.h`, `Cfg/EnsMgr_Cfg.h`, `Cfg/EnsMgr_PBCfg.h`, `Public/EnsMgr.h`, `Config/Arxml/EnsMgr_Swc.arxml` | All ENS findings |
| **[CFG]** | `ProjectInformation/Release/Mahindra_M210_P31/SupportFiles/FltMonr_PBCfg.h` (fault table: warning lamp class, latch, enable conditions) | Lamp findings |
| **[EDR]** | `SwEntities/Application/Ops/RstEdr/Implementation/Cfg/RstEdr_Cfg.h`, `Source/RstEdr.c` (lamp status captured in the record) | Lamp findings |
| **[REC]** | `EnsMgr/Tests/BenchTest/EnsMgr_Bench_Test_Report.xlsx` (W610 bench record, P25 to P44) | Observed values on a sister project |
| **[KB]** | Framework knowledge base `agent_sc3.md` section 2.5 (M314 family) | Expected behaviour where the M210 source gives none. Not M210 evidence: confirm before use |

**Not in the snapshot (Evidence unavailable):** `WLMgr`, `PADI`, `GpoMgr`, `Sb3Ex3GpoDrvr`, `CanMgr`,
`OpsModMgr`, `FltMonr` code. So the warning-lamp prove-out, the PAB ON / OFF lamp logic, the GPO
electrical diagnosis (short, open), the ENS IO-control DID and the CAN mapping of the crash signals
could **not** be reviewed. Lamp findings below come from the fault configuration and from the parts
of `EnsMgr` and `RstEdr` that touch the lamps. No lamp behaviour is asserted beyond that.

### ENS behaviour established from the source (the reference for every finding)

| Item | Value | Evidence |
|---|---|---|
| Task of the pulse state machine | `EnsMgr_MainFunction`, 0.5 ms | [SRC] arxml `PERIOD 5.0E-4` |
| Task of CAN status, crash DTCs, counters | `EnsMgr_SlowMainFunction`, 25 ms (the source comment says 5 ms) | [SRC] arxml `PERIOD 0.025` |
| Output | GPO channel 2, low-side: "low" = driver on | [SRC] `EnsMgr_Intl.h` 46-49, `EnsMgr.c` 348 |
| Normal pattern | 6 ms high / 4 ms low: 10 ms, 100 Hz, 60 % | [SRC] `EnsMgr_PBCfg.h` 69, 74 |
| Crash pattern | 4 ms high / 6 ms low for 1600 ticks = 800 ms = 80 pulses, starts with a low | [SRC] `EnsMgr_PBCfg.h` 64, 78, 83; `EnsMgr.c` 454-566 |
| After the 800 ms | Normal pattern, starting with a 4 ms low | [SRC] `EnsMgr.c` 529-549 |
| At init and without valid wake-up | Output high | [SRC] `EnsMgr.c` 638-655, 1244-1249 |
| Init pulse length | No timer in `EnsMgr`: set by the ECU start-up | [SRC]; W610 measured about 135 ms [REC] |
| Crash request | Algorithm severity above its threshold, crash mode normal, arming not open; front needs severity 2 (`0x0004`) | [SRC] `EnsMgr.c` 210-226 |
| Second crash while the pulse runs | Ignored | [SRC] `EnsMgr.c` 166-169 |
| Near crash | CAN flag only, 800 ms, no change of the pulse | [SRC] `EnsMgr.c` 287-313 |

Note: M210 runs a **10 ms** pulse (6 / 4 ms). The 40 ms, 62.5 % / 37.5 % pattern in [KB] is the M314
family and does not apply here.

Priority: **P0** safety or crash notification lost; **P1** wrong crash or lamp information, likely
to occur; **P2** wrong behaviour in a rare or corner condition; **P3** minor or internal only.
Confidence is that the code behaves as described, not that the bench will show a failure.

---

## 2. ENS potential bugs

### ENS-BUG-01 (P0) A crash after ENS IO control gives a pulse shorter than 800 ms
- **Evidence:** [SRC] `EnsMgr_IOControlReset` (1127-1132) sets request and state back to normal only.
  `DplyTimeoutTimer`, `DeployFirstCycleComplete` and `CrashPulseStartedSetOnce` are cleared only when
  a pulse runs to its end (529-538).
- **Issue:** If IO control is returned while its test pulse is still running, the elapsed time stays
  in `DplyTimeoutTimer`. The next pulse, including one for a real crash, lasts only the remainder.
  `CrashPulseStarted` (read by `CanMgr`) is not raised again either.
- **Impact:** After a workshop actuator test, a real crash in the same ignition cycle is notified
  with a truncated ENS pulse (a 500 ms test leaves 300 ms). A receiver that needs the full pulse
  misses the crash. Expected: every crash gives 800 ms.
- **Reproduce (black box):**
  1. Bench fault free, ignition on, prove-out complete. Record the ENS output.
  2. Extended session, security access, start ENS IO control (short-term adjustment).
  3. 300 ms later send return-control-to-ECU.
  4. Wait 5 s. Trigger a front crash (crash curves).
  5. Measure the inverted run after the crash. Repeat with 100 ms and 700 ms in step 3.
- **Expected:** 80 inverted pulses, 800 ms, whatever was done in steps 2-3.
- **Fails when:** the inverted run after the crash is shorter than 800 ms (about 800 ms minus the
  time in step 3), or `STS_CRASH` is not set.
- **Confidence:** High. Depends on the IO-control DID reaching `EnsMgr_IOControlSet/Reset` (caller is
  `CanMgr`, not in the snapshot).

### ENS-BUG-02 (P0) A crash during a running pulse is not given its own 800 ms
- **Evidence:** [SRC] 166-169 ("Ignore other crash during current ENS working"), 529-538.
- **Issue:** While a pulse runs (IO-control test pulse or an earlier crash), a new crash does not
  restart the time-out. The pulse and the CAN crash status end when the first pulse ends. Also,
  return-control during a real crash pulse stops it at once (1127-1132).
- **Impact:** Crash notified for less than 800 ms on the pin and on CAN.
- **Reproduce:**
  1. Record the ENS output and the SRS crash signals on CAN.
  2. Start ENS IO control. 600 ms later trigger a front crash.
  3. Measure the inverted run and the time `STS_CRASH` = 1 from the crash.
  4. Second run: trigger a crash, send return-control 200 ms later.
- **Expected:** 800 ms of inverted pulse and of `STS_CRASH` = 1 counted from the crash; a diagnostic
  request does not stop a crash pulse.
- **Fails when:** the inverted run ends about 200 ms after the crash (step 2), or stops at the
  return-control (step 4).
- **Confidence:** High.

### ENS-BUG-03 (P0) Power-down stops the crash pulse before the 800 ms are over
- **Evidence:** [SRC] `EnsMgr_PowerDown` (1292-1297) enters `POWER_DOWN` and reports complete at once,
  with no check of a running pulse; in that state the output is held high (1230-1236).
- **Issue:** If the mode manager calls power-down while the pulse runs (ignition lost in the crash),
  the pulse is cut.
- **Impact:** Ignition is often lost in a crash. The crash output would stop early. [KB] expects the
  pulse to finish from the energy reserve.
- **Reproduce:**
  1. Record the ENS output. Trigger a front crash.
  2. Switch ignition off 50 ms after the crash trigger. Keep battery on.
  3. Repeat with 200 ms and 600 ms; repeat with battery and ignition both off.
- **Expected:** the inverted run lasts 800 ms in every run.
- **Fails when:** the output goes steadily high before 800 ms have passed.
- **Confidence:** Medium. Whether power-down is requested during a crash is decided in `OpsModMgr`
  (not in the snapshot).

### ENS-BUG-04 (P1) ENS stays high after an ignition off / on without ECU reset
- **Evidence:** [SRC] `POWER_DOWN` is left only through `EnsMgr_Initialization` (1323);
  `EnsMgr_Start` does nothing (1379-1382).
- **Issue:** If the ECU is told to power down and ignition returns before it resets, the state stays
  `POWER_DOWN`: output high, no PWM, no crash pulse, until the next reset.
- **Impact:** A receiver sees a dead line (no PWM) and a crash would not be notified on the pin.
- **Reproduce:**
  1. Ignition on, PWM present. Keep battery on and the CAN restbus running.
  2. Ignition off for 200 ms, then on. Repeat with 0.5 s, 1 s, 2 s, 5 s off times.
  3. After each ignition on, record the output for 2 s. In one run trigger a crash afterwards.
- **Expected:** PWM 6 / 4 ms returns after every ignition on; a crash gives the 800 ms run.
- **Fails when:** the output stays high after ignition on, or no inverted run follows the crash.
- **Confidence:** Medium. Depends on whether the platform re-initialises on an aborted shutdown.

### ENS-BUG-05 (P1) The crash pulse can repeat every 800 ms
- **Evidence:** [SRC] the pulse end clears `EcallStartedAtLeastOnce` (535); the next tick sets it
  again if a severity output is still above its threshold (210-226), which requests a new pulse
  (271-275).
- **Issue:** If the algorithm keeps its severity output set longer than 800 ms, a second run starts
  right after the first, and so on.
- **Impact:** Receiver sees more than one crash event; `STS_CRASH` toggles; unlock and eCall actions
  may be repeated.
- **Reproduce:** trigger each crash type once and record the output and CAN for 5 s.
- **Expected:** exactly one inverted run of 800 ms, one `STS_CRASH` period.
- **Fails when:** a second inverted run or a second `STS_CRASH` = 1 period appears.
- **Confidence:** Medium. Depends on how long `OpsCshMgr` holds the severity output.

### ENS-BUG-06 (P1) A second crash direction inside the 800 ms is not shown on CAN
- **Evidence:** [SRC] 220-226: the CAN crash bit of an algorithm is set only while
  `EcallStartedAtLeastOnce` is false.
- **Issue:** Front crash, then a side crash 300 ms later: the side bit never reaches CAN. DTC and
  EDR bits are set for both (214-215). After the 800 ms the side crash may start a new pulse with the
  side location (ENS-BUG-05) or be lost, depending on the severity hold time.
- **Impact:** `CRASH_LOCATION` wrong or incomplete for multi-impact crashes.
- **Reproduce:** multi-event crash sets (front then left) with T0 distances of 100, 400 and 1000 ms.
  Record `CRASH_LOCATION`, `STS_CRASH`, the ENS output, and read the DTCs.
- **Expected:** per the customer requirement for multi-impact (to be taken from the L10). At least:
  both crash DTCs, and one continuous crash indication.
- **Fails when:** the second direction has a DTC but never appears on CAN, or the crash indication
  is interrupted and restarted.
- **Confidence:** High for the gating; the correct expected value needs the requirement.

### ENS-BUG-07 (P1) NEAR_CRASH comes back after a crash and repeats while the EDR event is active
- **Evidence:** [SRC] 287-313. Near crash is set when no crash pulse is pending and the EDR reports
  an active event; it is cleared 800 ms later and may be set again on the next tick.
- **Issue:** (a) During a long EDR event the flag drops for one 0.5 ms tick every 800 ms; the 25 ms
  CAN update can catch it, so `NEAR_CRASH` can show a one-frame 0. (b) After a real crash pulse ends,
  an EDR event that is still active sets `NEAR_CRASH` again for 800 ms.
- **Impact:** A near-crash indication after, and in addition to, a real crash; glitches on the
  signal.
- **Reproduce:**
  1. Near-crash curve: log `NEAR_CRASH` for 5 s.
  2. Front crash curve: log `NEAR_CRASH` and `STS_CRASH` for 5 s.
- **Expected:** near crash: one period of `NEAR_CRASH` = 1, no `STS_CRASH`. Crash: `NEAR_CRASH`
  does not start a new period after `STS_CRASH` returns to 0.
- **Fails when:** `NEAR_CRASH` shows more than one period, or a single-frame drop.
- **Confidence:** Medium. Depends on how long `RstEdr` reports the event active.

### ENS-BUG-08 (P1) A front crash of severity 1 is logged but not notified
- **Evidence:** [SRC] 210-226: threshold `0x0002` sets the front crash DTC, the EDR bit and the
  deployment counter; the pulse and CAN status need `0x0004` ("any airbags deployment").
- **Issue:** A front crash that fires pretensioners only gives the crash DTC and the latched warning
  lamp, but no inverted pulse and no `STS_CRASH`.
- **Impact:** May be intended. If the customer wants the crash output for any deployment, crashes
  with pretensioner-only firing are not notified.
- **Reproduce:** front curve that fires pretensioners only (low severity). Read DTCs, record the
  output and CAN.
- **Expected:** to be confirmed against the L10 (source: no pulse, no `STS_CRASH`, front crash DTC
  present).
- **Fails when:** the behaviour differs from the requirement.
- **Confidence:** High for the code; the verdict needs the requirement.

### ENS-BUG-09 (P2) Understrike without arming gives no crash output
- **Evidence:** [SRC] the understrike branch at 276-280 needs `EcallStartedAtLeastOnce`, which is
  only set when arming is not open (220). The branch cannot be reached with arming open.
- **Issue:** The code seems to intend "understrike requests the pulse even without arming"; it
  cannot.
- **Reproduce:** understrike curve built so that only the underbody sensor sees the event (no
  central confirmation). Record the output and CAN.
- **Expected:** per requirement; source comment and the W610 record [REC] expect the 800 ms pulse
  and `CRASH_LOCATION` = 7.
- **Fails when:** understrike DTC is stored but no pulse and no CAN status appear.
- **Confidence:** Medium. Arming cannot be set directly from outside: limited test access.

### ENS-BUG-10 (P2) Understrike is read from the front algorithm severity word
- **Evidence:** [SRC] 266: the understrike index uses `ENSMGR_LISA_SEV_LEVEL` (front) with mask
  `0x0200`.
- **Issue:** Any front severity value with bit `0x0200` set is reported as understrike (DTC, EDR,
  CAN), for a front crash without underbody impact. May be intended if the front algorithm carries
  the understrike decision.
- **Reproduce:** highest-severity front crash set, no underbody signal. Read DTCs and
  `CRASH_LOCATION`.
- **Expected:** front crash only.
- **Fails when:** the understrike crash DTC or `CRASH_LOCATION` = 7 appears.
- **Confidence:** Low (design intent unknown).

### ENS-BUG-11 (P2) Crash outside "normal" crash mode or without valid wake-up is neither notified nor logged
- **Evidence:** [SRC] 211 (`CrashMode == OPSCSHMODE_2_NORMAL`), 1156 and 1208 (everything skipped in
  invalid wake-up; crash DTC handling and counters included).
- **Issue:** If the ECU can still deploy in another crash mode, or while battery is on with invalid
  wake-up, the crash gives no pulse, no CAN status, no crash DTC and no counter.
- **Reproduce:**
  1. Battery on, ignition off, CAN in the invalid wake-up state: replay a front crash. Then ignition
     on, read DTCs and EDR.
  2. Plant mode (if the project allows a crash replay in it): same.
- **Expected:** per requirement. If loops fire, the crash must be logged.
- **Fails when:** loops fired or an EDR record exists, but no crash DTC is stored.
- **Confidence:** Medium. Whether the algorithms run in these modes is outside the snapshot.

### ENS-BUG-12 (P2) Wake-up state reaches the pulse task late
- **Evidence:** [SRC] the 0.5 ms task and the init function read wake-up mode through the buffer of
  the 25 ms runnable (`Rte_IRead_EnsMgr_SlowMainFunction_WakeUpModeMah`, 1205, 1315).
- **Issue:** The 0.5 ms task sees a wake-up change up to 25 ms late; at init the buffer may hold the
  RTE initial value, not the real state.
- **Impact:** PWM starts or stops up to 25 ms late; a crash in that window is handled with the old
  state.
- **Reproduce:** switch between valid and invalid wake-up 20 times; record the output. Measure the
  time from the CAN wake-up change to the PWM start / stop.
- **Expected:** stable delay, no partial pulses other than the one cut by the change.
- **Fails when:** PWM continues for more than about 30 ms after the wake-up became invalid, or does
  not start.
- **Confidence:** Medium.

### ENS-BUG-13 (P2) Pulse state is not cleared by the init function
- **Evidence:** [SRC] `EnsMgr_Initialization` (1313-1363) does not clear `EnsTimer`,
  `DplyTimeoutTimer`, `EnsSignalRequest`, `EnsAlgoSevStatusForCAN`, `CrashPulseStarted`,
  `CrashPulseStartedSetOnce`, `NearCrashTimeoutTimer`.
- **Issue:** After a reset that keeps RAM (or any re-initialisation), a pulse that was running
  continues: `EnsSignalRequest` is still "deploy".
- **Reproduce:** trigger a crash; 200 ms later send ECU reset (`11 01`, then `11 03`); record the
  output for 3 s after the restart.
- **Expected:** after restart: init high, then normal PWM. No inverted pulses.
- **Fails when:** inverted pulses appear after the restart, or `STS_CRASH` = 1 after the restart.
- **Confidence:** Low to Medium (depends on RAM initialisation at reset).

### ENS-BUG-14 (P2) Crash counters can be lost on supply loss; they never count above 1
- **Evidence:** [SRC] 1016-1057: the counter is set to 1 and the NVM block is only marked changed
  (`NvM_SetRamBlockStatus`); it is written when the NVM housekeeping runs.
- **Issue:** Battery lost right after the crash: the counter read by DID 0458 may still be 0. A
  second crash of the same type does not change it.
- **Reproduce:** front crash; cut battery 1 s after the crash; power on; read DID 0458. Repeat with
  a normal ignition-off shutdown.
- **Expected:** front counter = 1 in both runs.
- **Fails when:** the counter is 0 after the battery cut while the crash DTC and the EDR record
  exist.
- **Confidence:** Medium.

### ENS-BUG-15 (P2) ENS feature switch and documented calibrations are not used by the code
- **Evidence:** [SRC] `EnsMgrFeatureConfig` is in the calibration structure (`EnsMgr.h`,
  `EnsMgr_PBCfg.h` 164-167) and never read in `EnsMgr.c`. `Design/EnsMgr_CalibrationParameters.xlsx`
  lists parameters (`u8AlgoThreshForENSHwPin`, `bEnableNHTSACheck`, `pacos_type`, `EpdActivation`)
  that do not exist in `EnsMgr_FixedCalType`.
- **Issue:** Switching the feature off by calibration has no effect in `EnsMgr`; the design workbook
  does not describe this code.
- **Reproduce (black box):** write the EOL with the crash output de-configured; ignition cycle;
  record the output; read DTCs. W610 record [REC] `W610_ENS_TEST_05`: about 180 ms of normal pulse
  after init, then a flat line.
- **Expected:** per requirement: no PWM after the start phase, no crash pulse at a crash, no ENS
  fault DTC; configuration DTC only if the load is still connected.
- **Fails when:** PWM or the crash pulse is present with the output de-configured.
- **Confidence:** High for the unused switch; the bench result depends on `GpoMgr`.

### ENS-BUG-16 (P2) Change-over pulses differ from both patterns
- **Evidence:** [SRC] 110-155 and 459-492: the crash run starts wherever the normal pulse is. The
  calibration "crash start type = high" produces a first **low** (the first-cycle code flips it).
- **Issue:** The last normal high can be cut to 0.5 to 6.5 ms; the first inverted low can be 6 to
  10.5 ms. One pulse at the start is neither 60 % nor 40 %.
- **Impact:** A receiver that validates each pulse may reject the first one. Harmless if it counts
  pulses of 40 %.
- **Reproduce:** trigger the crash at delays 0 to 10 ms in 1 ms steps after a rising edge; record.
- **Expected:** first inverted low 6 to 10.5 ms; all later pulses 4 / 6 ms; total 800 ms.
- **Fails when:** a pulse outside these limits appears, or the total run leaves 800 to 805.5 ms.
- **Confidence:** High.

### ENS-BUG-17 (P2) CAN crash status is written from the 25 ms task through the 0.5 ms task's port access
- **Evidence:** [SRC] `ensmgr_CANUpdateEventStatus` is called from the slow task (1167) and uses
  `Rte_IWrite_EnsMgr_MainFunction_*` (`EnsMgr_Cfg.h` 88-92). The source comment calls the slow task
  "5 ms"; it runs at 25 ms.
- **Issue:** Implicit-write buffers belong to one runnable; writing them from another task can lose
  or delay an update. The crash status on CAN follows the pin by up to 25 ms and its length is
  800 ms +/- 25 ms.
- **Reproduce:** 20 crashes; log `STS_CRASH` and record the pin.
- **Expected:** `STS_CRASH` = 1 within 25 ms + one frame period of the first inverted low, for
  800 ms +/- (25 ms + one frame period).
- **Fails when:** `STS_CRASH` is missing in a run, or shorter than 750 ms.
- **Confidence:** Medium.

### ENS-BUG-18 (P3) Frontal deployment: both "passenger inhibited" and "frontal bags fired" can be set
- **Evidence:** [SRC] 799-823, evaluated every 25 ms, faults never reset.
- **Issue:** Driver bag fires first, passenger bag one task later: the first pass reports "passenger
  inhibited", the next reports "frontal bags fired". Both stay.
- **Impact:** Internal fault list only (both map to the no-DTC crash event).
- **Reproduce:** front crash with staged firing; read the internal fault list (if the internal DTC
  read is available).
- **Fails when:** `OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBITED` is set although the passenger bag fired.
- **Confidence:** Medium. Limited black-box access.

### ENS-BUG-19 (P3) "Back impact fired" is never reported
- **Evidence:** [SRC] 938-940: the block is empty. [CFG] the event is configured with a latched
  warning lamp.
- **Issue:** Dead configuration. A rear crash is covered only by `REAR_CRASH_EVENT`.
- **Reproduce:** rear crash; check the rear crash DTC and the warning lamp.
- **Fails when:** a rear crash with deployment leaves no DTC or no lamp.
- **Confidence:** High for the code; impact low.

### ENS-BUG-20 (P3) Side airbag attribution with an invalid steering-side configuration
- **Evidence:** [SRC] 829-867: left uses "== left-hand drive", right uses "== right-hand drive"; any
  other value sends the passenger seat bag to both sides and the driver seat bag to none.
- **Reproduce:** only with a wrong steering-position configuration; side crash; internal faults.
- **Confidence:** High for the code; needs an invalid configuration.

### ENS-BUG-21 (P1) Measured timing on the sister project did not match the configuration
- **Evidence:** [REC] `W610_ENS_TEST_08` (P44): low 2.469 ms and high 6.03 ms measured (configured
  4 / 6 ms); init pulse 134.655 ms against 100 ms expected, marked OK.
- **Issue:** Either the measurement or the output timing was off by 1.5 ms on W610. Not a code
  finding; a reason to measure M210.
- **Reproduce:** `M210_ENS_02_PwmTiming.py`, `M210_ENS_01_InitPulse.py`.
- **Expected:** 6.0 / 4.0 ms +/- 0.5 ms.
- **Fails when:** any high or low time is outside the tolerance.
- **Confidence:** Evidence is a bench record of another project.

---

## 3. Lamps potential bugs

Moved to `../../LAMPS/test_data/Lamps_Potential_Bugs.md` (LMP-BUG-01 to LMP-BUG-08) on 2026-11-13,
with the Lamps test cases (`Lamps_Black_Box_Test_Cases.md`).

---

## 4. Trace: finding to test case

| Finding | Priority | Test case(s) | Automated |
|---|---|---|---|
| ENS-BUG-01 | P0 | ENS-TC-02 | `M210_ENS_TC02` |
| ENS-BUG-02 | P0 | ENS-TC-17 | `M210_ENS_TC17` |
| ENS-BUG-03 | P0 | ENS-TC-03 | `M210_ENS_TC03` |
| ENS-BUG-04 | P1 | ENS-TC-13 | `M210_ENS_TC13` |
| ENS-BUG-05 | P1 | ENS-TC-12 | `M210_ENS_TC12` |
| ENS-BUG-06 | P1 | ENS-TC-11 | `M210_ENS_TC11` |
| ENS-BUG-07 | P1 | ENS-TC-10 | `M210_ENS_TC10` |
| ENS-BUG-08 | P1 | ENS-TC-15 | `M210_ENS_TC15` |
| ENS-BUG-09 | P2 | ENS-TC-29 | `M210_ENS_TC29` |
| ENS-BUG-10 | P2 | ENS-TC-27 | `M210_ENS_TC27` |
| ENS-BUG-11 | P2 | ENS-TC-24 | `M210_ENS_TC24` |
| ENS-BUG-12 | P2 | ENS-TC-14 | `M210_ENS_TC14` |
| ENS-BUG-13 | P2 | ENS-TC-19 | `M210_ENS_TC19` |
| ENS-BUG-14 | P2 | ENS-TC-20 | `M210_ENS_TC20` |
| ENS-BUG-15 | P2 | ENS-TC-22 | `M210_ENS_TC22` |
| ENS-BUG-16 | P2 | ENS-TC-09 | `M210_ENS_TC09` |
| ENS-BUG-17 | P2 | ENS-TC-04, ENS-TC-26 | `M210_ENS_TC04`, `M210_ENS_TC26` |
| ENS-BUG-18 | P3 | ENS-TC-28 | `M210_ENS_TC28` |
| ENS-BUG-19 | P3 | ENS-TC-08 (rear) | `M210_ENS_TC08` |
| ENS-BUG-20 | P3 | ENS-TC-30 | `M210_ENS_TC30` |
| ENS-BUG-21 | P1 | ENS-TC-06, ENS-TC-07 | `M210_ENS_02`, `M210_ENS_01` |
| LMP-BUG-01 | P1 | LMP-TC-03 | `M210_LAMPS_TC03` |
| LMP-BUG-02 | P1 | LMP-TC-04 | `M210_LAMPS_TC04` |
| LMP-BUG-03 | P1 | LMP-TC-12 | no |
| LMP-BUG-04 | P1 | LMP-TC-08 | `M210_LAMPS_TC08` |
| LMP-BUG-05 | P2 | LMP-TC-10 | `M210_LAMPS_TC10` |
| LMP-BUG-06 | P2 | LMP-TC-13 | no |
| LMP-BUG-07 | P2 | LMP-TC-05 | `M210_LAMPS_TC05` |
| LMP-BUG-08 | P3 | LMP-TC-17 | `M210_LAMPS_TC17` |
