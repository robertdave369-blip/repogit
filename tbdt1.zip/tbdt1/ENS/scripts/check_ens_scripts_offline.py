# Author: Kris
#
# Offline check of the M210 ENS scripts: no ARIA, no ECU, nothing on the bench.
#
# Every script runs against a stubbed shared library and a simulated ECU on a virtual clock. The
# simulated ENS output follows EnsMgr.c tick by tick (0.5 ms): low without battery, high from battery
# on, PWM from wake-up + start-up time (8 ticks low / 12 ticks high), and at a crash or an IO-control
# request the deploy pattern (12 ticks low / 8 ticks high) until the 1600-tick time-out, entered
# wherever the normal pulse is. The simulated ECU also has the crash status on CAN, the DTCs, the
# crash counters, the ENS output faults and the EOL bit, in the way the test cases expect them
# (a "good" ECU: it has none of the potential bugs of ENS_and_Lamps_Potential_Bugs.md).
# Every script must pass against the good ECU and fail against each fault planted for it.
# This checks the scripts, not the ECU: what the real ECU does is the bench run.
#
#     py -3 projects/M210/modules/ENS/scripts/check_ens_scripts_offline.py

import importlib.util
import math
import sys
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
FRAMEWORK_ROOT = HERE.parents[4]
if str(FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries import import_list  # noqa: E402

import_list.init_aria = lambda *args, **kwargs: False    # no ARIA: the scripts get the stubs below

from Framework_IOEM_Py.projects.M210.config import canc_config, fault_list_config, gpo_config  # noqa: E402
from Framework_IOEM_Py.projects.M210.config.cand_config import IOC_RESP_SESSION_EXTENDED  # noqa: E402

GOOD = dict(normal_low=8, normal_high=12, deploy_low=12, deploy_high=8, deploy_ticks=1600, startup_ms=130.0,
            crash_delay_ms=20.0, unit=1.0)
TYPES = ("front", "left", "right", "rear", "understrike")    # counter order of EnsMgr
LOCATION = {"front": 1, "right": 2, "left": 3, "rear": 4, "understrike": 7}
SETS = {    # crash set -> (ms after the trigger, crash type)
    **{name: [(0, name)] for name in (*TYPES, "near", "underbody_only")},
    "parallel_front_left": [(0, "front"), (100, "left")],
    "concatenated_front_left": [(0, "front"), (400, "left")],
    "multi_front_left": [(0, "front"), (2000, "left")],
}


def dtc_number(text):
    return int("".join(token[2:] if token.lower().startswith("0x") else token for token in str(text).split()), 16)


CRASH_DTC = {name: dtc_number(getattr(fault_list_config, gpo_config.ENS_CRASH_DTC[name])["dtc_hex"]) for name in TYPES}
ENS_FAULT_DTC = {fault: dtc_number(f"{gpo_config.DTC_GPO_fault['ENS']} {status}")
                 for fault, status in gpo_config.GPO_FaultStatus.items()}


class Bench:
    """Virtual clock (ms) and the simulated ECU. A planted fault is a key of `ecu`."""

    tool = "check_ens_scripts_offline.py"    # named in the report previews
    shared = ()    # more shared-library functions that write report steps of their own (previews)

    def stubs(self, stubs):
        """More stubs for the scripts of another module (the Lamps checker)."""
        return {}

    def __init__(self, ecu):
        self.ecu, self.now, self.tick, self.verdicts = ecu, 0.0, 0, []
        self.batt = self.ign = True
        self.can_wake = False
        self.boot_at = -1e9    # the ECU is on when a script starts (fault_free_profile)
        self.level, self.edges, self.rec_index, self.rec_from, self.window = "H", [], 0, 0.0, 0
        self.awake = self.stuck = self.was_off = False
        self.wake_at = None
        self.abort()
        self.leftover = 0
        self.set_key, self.pending, self.can_events = "front", [], []
        self.can = dict(STS_CRASH=0, CRASH_LOCATION=0, NEAR_CRASH=0)
        self.dtcs, self.internal = {}, set()
        self.ram_counters, self.nvm_counters = [0] * 5, [0] * 5
        self.eol_off, self.fault, self.fault_since, self.voltage = False, None, 0.0, 12.0
        self.session, self.steering, self.rerun = False, "LHD", False

    # -- EnsMgr ---------------------------------------------------------------------------------------
    def abort(self):
        self.deploy, self.deploy_timer, self.first_cycle_done, self.signal_low, self.timer = None, 0, False, True, 0

    def request(self, kind):
        """ensmgr_ManageRequest: kind "crash" or "io"."""
        if self.deploy:
            if kind == "crash" and self.deploy == "io":    # the crash takes the running IO-control pulse over
                self.deploy = "crash"
                if not self.ecu.get("crash_no_restart"):
                    self.deploy_timer = 0
            return
        self.deploy, self.timer, self.signal_low, self.first_cycle_done = kind, 0, False, False
        self.deploy_timer = self.leftover if self.ecu.get("io_timer_kept") else 0

    def crash(self, kind, at):
        ecu = self.ecu
        if not (self.ign or self.can_wake):    # outside the crash mode
            if ecu.get("dtc_without_pulse"):
                self.dtcs[CRASH_DTC[kind]] = 0x8B
            return
        grid = math.ceil(at / 25.0) * 25.0 + (200.0 if ecu.get("can_late") else 0.0)
        if kind == "near":
            names = ["NEAR_CRASH"] + (["STS_CRASH"] if ecu.get("near_sets_sts") else [])
            self.can_events += [(grid, name, 1) for name in names] + [(grid + 800.0, name, 0) for name in names]
            return
        if kind == "underbody_only":    # no arming: nothing, unless planted
            if ecu.get("understrike_dtc_only"):
                self.dtcs[CRASH_DTC["understrike"]] = 0x8B
            return
        kinds = [kind] + (["understrike"] if kind == "front" and ecu.get("front_sets_understrike") else [])
        for name in kinds:
            if not ecu.get("no_dtc"):
                self.dtcs[CRASH_DTC[name]] = 0x8B
            self.ram_counters[TYPES.index(name)] = 1
        if not ecu.get("counter_lost"):
            self.nvm_counters = list(self.ram_counters)
        if kind == "front":
            self.internal.add(gpo_config.ENS_FRONTAL_FAULT)
            if ecu.get("both_frontal_faults"):
                self.internal.add(gpo_config.ENS_FRONTAL_INHIBITED_FAULT)
        if kind in ("left", "right"):
            swapped = ecu.get("sides_swapped_rhd") and self.steering == "RHD"
            side = {"left": "right", "right": "left"}[kind] if swapped else kind
            self.internal.add(gpo_config.ENS_LATERAL_FAULT[side])
        if self.deploy == "crash":    # inside a running crash pulse: no new pulse, no new location
            return
        if not self.eol_off or ecu.get("eol_ignored"):
            self.request("crash")
        location = LOCATION[kinds[-1]] if not ecu.get("wrong_location") else 5
        self.can_events += [(grid, "STS_CRASH", 1), (grid, "CRASH_LOCATION", location),
                            (grid + 800.0, "STS_CRASH", 0), (grid + 800.0, "CRASH_LOCATION", 0)]

    def reset(self):
        self.boot_at = self.now
        if not self.ecu.get("deploy_survives_reset"):
            self.abort()
            self.can_events, self.can = [], dict.fromkeys(self.can, 0)

    def step(self, t):
        ecu = self.ecu
        if not self.batt:
            self.boot_at = None
            self.abort()
            self.can_events, self.can = [], dict.fromkeys(self.can, 0)
            self.ram_counters = list(self.nvm_counters)
            return self.out(t, "L")
        wake = self.ign or self.can_wake
        if self.boot_at is None:
            if not wake:
                return self.out(t, "H")
            self.boot_at = t
        if t < self.boot_at + ecu["startup_ms"]:
            self.awake = False
            return self.out(t, "H")
        # crash decisions, CAN status, ENS fault qualification
        for event in [event for event in self.pending if event[0] <= t]:
            self.pending.remove(event)
            self.crash(event[1], t)
        for event in [event for event in self.can_events if event[0] <= t]:
            self.can_events.remove(event)
            self.can[event[1]] = event[2]
        in_range = 9.0 <= self.voltage <= 16.0 or ecu.get("dtc_during_voltage_fault")
        if not in_range:
            self.fault_since = t
        if self.fault and t - self.fault_since >= 2000.0 and not ecu.get("no_ens_dtc"):
            self.dtcs[ENS_FAULT_DTC[self.fault]] = 0x8B
        if not self.fault and t - self.fault_since >= 4000.0:
            for code in ENS_FAULT_DTC.values():
                if code in self.dtcs:
                    self.dtcs[code] = 0x0A
        if not wake and not (self.deploy == "crash" and not ecu.get("powerdown_cuts")):
            self.abort()
            self.awake = False
            self.wake_at = None
            return self.out(t, "H")
        if self.wake_at is None:
            self.wake_at = t
        if t < self.wake_at + ecu.get("wake_delay_ms", 0.0):    # planted: the PWM starts late after a wake-up
            return self.out(t, "H")
        if not self.awake:    # valid wake-up (again): the pattern starts with a low
            self.stuck = bool(ecu.get("stuck_high")) and self.was_off    # planted: stuck high after ignition off
            self.awake, self.signal_low, self.timer = True, True, 0
        self.timer += 1
        if not self.deploy:
            if self.timer > (ecu["normal_low"] if self.signal_low else ecu["normal_high"]):
                self.signal_low, self.timer = not self.signal_low, 1
            level = "L" if self.signal_low else "H"
        elif not self.first_cycle_done:
            self.timer, self.signal_low, self.first_cycle_done = 0, True, True    # the output keeps its level this tick
            level = self.pattern
        else:
            self.deploy_timer += 1
            if self.timer > (ecu["deploy_low"] if self.signal_low else ecu["deploy_high"]):
                self.signal_low, self.timer = not self.signal_low, 1
            level = "L" if self.signal_low else "H"
            if self.deploy_timer > ecu["deploy_ticks"]:
                again = ecu.get("double_run") and self.deploy == "crash" and not self.rerun
                self.deploy, self.deploy_timer, self.first_cycle_done, self.signal_low, level = None, 0, False, True, "L"
                if again:
                    self.rerun = True
                    self.pending.append((t + 1000.0, "front"))
        self.pattern = level
        flat = self.eol_off and not ecu.get("eol_ignored") and t >= self.boot_at + ecu["startup_ms"] + 180.0
        return self.out(t, "H" if flat or self.fault or self.stuck else level)

    pattern = "H"

    def out(self, t, level):
        if level != self.level:
            self.level = level
            self.edges.append((t, level))

    def advance(self, ms):
        self.now += float(ms)
        while self.tick * 0.5 < self.now:
            self.step(self.tick * 0.5)
            self.tick += 1

    # -- what the stubs do -----------------------------------------------------------------------------
    def supply(self, name, value):
        def switch():
            if name == "ign" and not value:
                self.nvm_counters = list(self.ram_counters)    # power-down: NVM written
                self.was_off = True
            setattr(self, name, value)
            self.advance(15.0)    # command latency, so a time after a supply call is a range
        return switch

    def fault_free(self, *_, **__):
        self.dtcs, self.internal, self.ram_counters, self.nvm_counters = {}, set(), [0] * 5, [0] * 5
        self.eol_off, self.fault, self.voltage, self.session, self.rerun, self.leftover = False, None, 12.0, False, False, 0
        self.fault_since, self.stuck, self.awake, self.was_off = self.now, False, False, False
        self.batt = self.ign = True
        self.can_wake = False
        self.pending, self.set_key = [], "front"
        self.reset()
        self.advance(self.ecu["startup_ms"] + 1000.0)

    def load(self, key, **_):
        if key not in SETS:
            raise ValueError(f"Crash type '{key}' not configured.")
        self.batt = False
        self.advance(200.0)
        self.batt = self.ign = True
        self.pending, self.set_key = [], key
        self.advance(self.ecu["startup_ms"] + 1000.0)

    def trigger(self):
        self.pending += [(self.now + self.ecu["crash_delay_ms"] + offset, kind) for offset, kind in SETS[self.set_key]]

    def spi(self, _sensor, *curves):    # scripts that load the curves themselves
        zero = all("Sensor_With_0_values" in str(curve) for curve in curves if isinstance(curve, str))
        self.set_key = "underbody_only" if zero else "front"

    def diag(self, *args):
        request = " ".join(str(args[-1]).split())
        if request == "0x10 0x03":
            self.session = True
            return IOC_RESP_SESSION_EXTENDED
        if request == "0x10 0x01":
            self.session = False
            return "0x50 0x01 0x00 0x32 0x01 0xF4"
        if request.startswith("0x2F 0xF0 0x10"):
            if not self.session:
                return "0x7F 0x2F 0x7F"
            if request.endswith("0x10 0x00"):    # return control
                if self.deploy == "io" or (self.deploy == "crash" and self.ecu.get("crash_no_restart")):
                    self.leftover = self.deploy_timer
                    self.abort()
                return "0x6F 0xF0 0x10 0x00"
            self.request("io")
            return "0x6F 0xF0 0x10 0x03 0x01"
        if request.startswith("0x11"):
            self.reset()
            return "0x51 " + request.split()[1]
        if request == gpo_config.ENS_CRASH_COUNTER_READ:
            return "0x62 0x04 0x58 " + " ".join(f"0x{value:02X}" for value in self.ram_counters)
        if request.startswith("0x14"):
            if self.ecu.get("clear_removes_dtc"):
                self.dtcs = {}
            return "0x54"
        return "0x7F " + request.split()[0] + " 0x11"

    def check_dtc(self, _channel, code, *_):
        number = dtc_number(code)
        if number in self.dtcs:
            return ["0000", f"{number:06X} {self.dtcs[number]:02X}"]
        return ["1111", f"DTC {number:06X} not present"]

    def signal(self, _channel, _frame, name):
        if name == "INDC_SRS":
            return int(any(status & 0x01 for status in self.dtcs.values()))
        return self.can[name]

    def gpo_fault(self, _name, fault, *_):
        self.fault, self.fault_since = (None if fault == "INHERENT" else fault), self.now

    def start_recording(self, _loop, ch1=False, timeCh1=None, **_):
        self.rec_index, self.rec_from, self.window = len(self.edges), self.now, timeCh1
        return ["0000", ""]

    def samples(self, _loop):
        return ["0000", [((t - self.rec_from) / self.ecu["unit"], 1 if level == "H" else 0)
                         for t, level in self.edges[self.rec_index:] if self.rec_from < t <= self.rec_from + self.window]]

    def wakeup(self, value):
        def switch(*_, **__):    # the steps of the shared CAN_Wakeup / CAN_Wakeup_Restore
            if value:
                self.supply("ign", False)()
                self.advance(canc_config.CAN_WAKEUP_BUS_SLEEP_WAIT_MS)
                self.can_wake = True
                self.advance(canc_config.NM_IGN_ON_STARTUP_DELAY_MS)
            else:
                self.can_wake = False
                self.supply("ign", True)()
            return True
        return switch


def run(script, ecu, report_dir=None, bench_class=Bench, here=HERE):
    """Run one script against the simulated ECU; the verdicts of its graded steps.
    report_dir: also write the script's HTML report there (see preview_stubs)."""
    bench = bench_class(ecu)
    spec = importlib.util.spec_from_file_location(script[:-3], here / script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    def verdict(step, obtained, expected=None, stat=None):
        bench.verdicts.append((step, stat if stat is not None else str(obtained) == str(expected), obtained, expected))

    nothing = lambda *args, **kwargs: None
    stubs = dict(
        Wait=bench.advance, Sleep=lambda seconds: bench.advance(seconds * 1000.0), TriggerCrash=bench.trigger,
        PS=types.SimpleNamespace(BATT_ON=bench.supply("batt", True), BATT_OFF=bench.supply("batt", False),
                                 IGN_ON=bench.supply("ign", True), IGN_OFF=bench.supply("ign", False),
                                 SetVoltage=lambda voltage: setattr(bench, "voltage", voltage)),
        LAMPS=types.SimpleNamespace(StartLampMonitoring=bench.start_recording, GetLampRecordedSamples=bench.samples,
                                    GetLampInstantStatus=lambda loop: ["0000", bench.level]),
        RSU=types.SimpleNamespace(SendAcceleration=nothing), SPI=types.SimpleNamespace(SendCrashData=bench.spi),
        CAN=types.SimpleNamespace(
            SendDiagByValues=bench.diag, SendDiagByValuesNoLog=bench.diag, CheckSingleDTC=bench.check_dtc,
            GetSignalFromFrame=bench.signal, PeriodicDisableAllFrames=nothing, PeriodicEnableAllFrames=nothing,
            ReadAllDTCNamesWithStatus=lambda *_: ", ".join(f"{name} with status 0x8B" for name in sorted(bench.internal))
            + "." if bench.internal else "No error found."),
        RESULT=types.SimpleNamespace(InterpretEqualResult=verdict, CommentStep=nothing),
        aria_reports=types.SimpleNamespace(add_group=nothing, close_group=nothing, add_content=nothing,
                                           add_report_info=nothing, write_to_file=nothing),
        time=types.SimpleNamespace(monotonic=lambda: bench.now / 1000.0),
        fault_free_profile=bench.fault_free, load_crash_curves=bench.load, SetGpoFaultCondition=bench.gpo_fault,
        Clear_DTC_Info=lambda: bench.diag("0x14 0xFF 0xFF 0xFF"), CAN_Wakeup=bench.wakeup(True),
        CAN_Wakeup_Restore=bench.wakeup(False), READ_TTFANDFDResult=lambda: ["0000", [], [], []],
        manage_eol_code=lambda _target, action="disable", **_: setattr(bench, "eol_off", action == "disable"),
        SteeringWheelPosition_Config=lambda position: setattr(bench, "steering", position),
        resolve_can_log_ids=lambda *args: [],
    )
    for name in ("read_software_version", "create_report_and_logging", "ResultStep", "Internal_Security_Access"):
        stubs[name] = nothing
    stubs.update(bench.stubs(stubs))
    if report_dir is not None:
        stubs.update(preview_stubs(bench, stubs, report_dir))
    for name, stub in stubs.items():
        setattr(module, name, stub)
    module.run_test()
    return bench.verdicts


def preview_stubs(bench, stubs, report_dir):
    """The stubs that make a run write its HTML report: the real apym reporter, the real RESULT
    wrappers and the real report theme, on the virtual clock. What the report then shows:
    - layout, groups, steps, pulse traces and verdict logic: the script's own, as on the bench;
    - obtained values: the simulated good ECU, not a bench;
    - Wait, supply and diagnostic request lines: the text the real wrappers write;
    - shared-library functions with report steps of their own (fault free profile, software version,
      crash-curve load, security access, ...): one line each that says so."""
    import apym.reports as apym_reports
    from datetime import datetime, timedelta

    from Framework_IOEM_Py.shared_libraries import core_functions, jscript_translation
    from Framework_IOEM_Py.shared_libraries.report_theme import THEME

    started = datetime.now()

    class Clock(datetime):    # the report's time stamps follow the virtual clock
        @classmethod
        def now(cls, tz=None):
            return started + timedelta(milliseconds=bench.now)

        utcnow = now

    apym_reports.datetime = Clock
    # the reporter's one ARIA call (it stores the report path in ARIA)
    apym_reports.aria_api = types.SimpleNamespace(Storage=types.SimpleNamespace(store_item=lambda *args: None))
    reporter, result = apym_reports.ApymReports, jscript_translation.RESULT

    def create(test_case_file, can_ids=None, direct_write=False, tc_desc=None, **_):
        report_dir.mkdir(parents=True, exist_ok=True)
        path = report_dir / f"{test_case_file}_SIMULATED.html"
        reporter.create(str(path), f"[SIMULATED, not a bench result] {tc_desc or test_case_file}",
                        apym_reports.ApymReportsOptions())
        reporter.add_style(THEME)
        reporter.add_report_info("#SIMULATED:", f"offline preview from {bench.tool} --html. Every "
                                 "obtained value comes from a simulated ECU, none from a bench or an ECU.")
        reporter.add_report_info("#Test Case Description:", str(tc_desc))
        try:
            core_functions.add_standard_report_info()
        except Exception as error:    # the identity fields are not worth a failed preview
            print("report identity fields not added:", error)
        print("report:", path)

    def shared(name):
        stub = stubs[name]

        def call(*args, **kwargs):
            result.LogAction(f"{name}({', '.join(repr(arg) for arg in args)})", "- shared-library function: on the bench "
                             "its own report steps appear here (not simulated)")
            return stub(*args, **kwargs)
        return call

    def wait(ms):
        bench.advance(ms)
        result.CommentStep(f"Wait {float(ms):g} ms")    # the line the real Wait writes

    def supply(text, switch):
        def call():
            switch()
            result.ExpectTestResult(text, "", "", True)    # the step the real PS call writes
        return call

    def diag(*args):
        result.LogAction("Send request", args[-1])    # the line the real SendDiagByValues writes
        return bench.diag(*args)

    def set_voltage(voltage):
        bench.voltage = voltage
        result.LogAction(f"Set voltage to {voltage}V on the battery line")

    ps, can = stubs["PS"], stubs["CAN"]
    preview = dict(
        RESULT=result, aria_reports=reporter, create_report_and_logging=create, Wait=wait,
        ResultStep=jscript_translation.ResultStep,
        PS=types.SimpleNamespace(BATT_ON=supply("Turn on BATTERY", ps.BATT_ON), BATT_OFF=supply("Turn OFF BATTERY", ps.BATT_OFF),
                                 IGN_ON=supply("Turn on IGN", ps.IGN_ON), IGN_OFF=supply("Turn off IGN", ps.IGN_OFF),
                                 SetVoltage=set_voltage),
        CAN=types.SimpleNamespace(**{**vars(can), "SendDiagByValues": diag}),
    )
    for name in ("fault_free_profile", "read_software_version", "load_crash_curves", "Internal_Security_Access",
                 "SetGpoFaultCondition", "manage_eol_code", "CAN_Wakeup", "CAN_Wakeup_Restore", "Clear_DTC_Info",
                 "SteeringWheelPosition_Config", "READ_TTFANDFDResult", *bench.shared):
        preview[name] = shared(name)
    return preview


# script -> planted ECU faults it must catch
CASES = {
    "M210_ENS_01_InitPulse.py": [dict(startup_ms=600.0), dict(normal_low=12)],
    "M210_ENS_02_PwmTiming.py": [dict(normal_high=14), dict(normal_low=5, normal_high=12)],
    "M210_ENS_03_CrashInversion.py": [dict(deploy_ticks=1200), dict(deploy_ticks=3200), dict(deploy_high=12),
                                      dict(deploy_low=8, deploy_high=12), dict(normal_high=10)],
    "M210_ENS_TC02_CrashAfterIoControlReturned.py": [dict(io_timer_kept=True), dict(no_dtc=True)],
    "M210_ENS_TC03_SupplyLostDuringCrashPulse.py": [dict(powerdown_cuts=True)],
    "M210_ENS_TC04_CanCrashStatusEveryDirection.py": [dict(wrong_location=True), dict(can_late=True)],
    "M210_ENS_TC05_CrashDtcLockAndLampEveryDirection.py": [dict(no_dtc=True), dict(front_sets_understrike=True)],
    "M210_ENS_TC08_CrashInversionOtherDirections.py": [dict(deploy_ticks=1200), dict(no_dtc=True)],
    "M210_ENS_TC09_CrashAtEveryPulsePosition.py": [dict(deploy_low=14)],
    "M210_ENS_TC10_NearCrash.py": [dict(near_sets_sts=True)],
    "M210_ENS_TC11_TwoCrashesDifferentDirection.py": [dict(no_dtc=True), dict(double_run=True)],
    "M210_ENS_TC12_OneCrashRunPerCrash.py": [dict(double_run=True)],
    "M210_ENS_TC13_PwmAfterIgnitionOffOn.py": [dict(stuck_high=True)],
    "M210_ENS_TC14_InvalidWakeup.py": [dict(stuck_high=True)],
    "M210_ENS_TC15_LowSeverityFrontCrash.py": [],    # blocked until gpo_config names the set
    "M210_ENS_TC16_OutputFaults.py": [dict(no_ens_dtc=True), dict(no_dtc=True)],
    "M210_ENS_TC17_CrashDuringIoControlPulse.py": [dict(crash_no_restart=True)],
    "M210_ENS_TC18_IoControl.py": [dict(deploy_ticks=1200)],
    "M210_ENS_TC19_ResetDuringCrashPulse.py": [dict(deploy_survives_reset=True)],
    "M210_ENS_TC20_CrashCounters.py": [dict(counter_lost=True), dict(front_sets_understrike=True)],
    "M210_ENS_TC21_CrashDtcStays.py": [dict(clear_removes_dtc=True)],
    "M210_ENS_TC22_CrashOutputDeconfigured.py": [dict(eol_ignored=True)],
    "M210_ENS_TC23_UnderAndOverVoltage.py": [dict(dtc_during_voltage_fault=True), dict(normal_high=14)],
    "M210_ENS_TC24_CrashOutsideCrashMode.py": [dict(dtc_without_pulse=True)],
    "M210_ENS_TC25_LongRun.py": [dict(normal_high=14)],
    "M210_ENS_TC26_PinAndCanAgreeInTime.py": [dict(can_late=True)],
    "M210_ENS_TC27_FrontCrashNotUnderstrike.py": [dict(front_sets_understrike=True)],
    "M210_ENS_TC28_FrontalDeploymentInternalFaults.py": [dict(both_frontal_faults=True)],
    "M210_ENS_TC29_UnderstrikeWithoutArming.py": [dict(understrike_dtc_only=True)],
    "M210_ENS_TC30_SideDeploymentFaultsSteeringPosition.py": [dict(sides_swapped_rhd=True)],
    "M210_ENS_TC31_InitTimeFromIgnitionOn.py": [dict(wake_delay_ms=600.0), dict(normal_low=12)],
    "M210_ENS_TC32_InitTimeFromCanWakeup.py": [dict(wake_delay_ms=600.0), dict(normal_low=12)],
}


def main(only="", cases=None, here=HERE, bench_class=Bench):
    """Every script against the good ECU and against each fault planted for it."""
    failures = 0
    cases = CASES if cases is None else cases
    missing = sorted({path.name for path in here.glob("M210_*.py")} ^ set(cases))
    if missing:
        failures += 1
        print("FAIL scripts and CASES differ:", missing)
    for script, faults in cases.items():
        if only not in script:
            continue
        first = script.split("_")[1:3] in (["ENS", "01"], ["ENS", "02"], ["ENS", "03"])    # the three lamp-card scripts: units and crash phases
        variants = [(unit, delay) for unit in (1.0, 0.001) for delay in (20.0, 23.0, 27.5)] if first else [(1.0, 20.0)]
        for unit, crash_delay in variants:    # lamp card times in ms / microseconds; the crash meets the pulse low / edge / high
            verdicts = run(script, dict(GOOD, unit=unit, crash_delay_ms=crash_delay), None, bench_class, here)
            failed = [v for v in verdicts if not v[1]]
            blocked = len(failed) == 1 and str(failed[0][0]).startswith("BLOCKED") and not faults
            ok = bool(verdicts) and (not failed or blocked)
            failures += not ok
            print(f"{'ok  ' if ok else 'FAIL'} {script}: good ECU, unit {unit:g} ms, crash +{crash_delay:g} ms, "
                  f"{len(verdicts)} graded steps" + (" (BLOCKED by design)" if blocked else "")
                  + ("" if ok else "".join(f"\n       {v}" for v in failed[:8])))
        for fault in faults:
            caught = any(not v[1] for v in run(script, dict(GOOD, **fault), None, bench_class, here))
            failures += not caught
            print(f"{'ok  ' if caught else 'FAIL'} {script}: planted {fault} {'caught' if caught else 'NOT caught'}")
    print("ALL OK" if not failures else f"{failures} FAILED")
    return failures


def previews(only="", cases=None, here=HERE, bench_class=Bench, folder="ENS_offline_preview"):
    """Write the HTML report of every script (or those whose name contains `only`), good ECU."""
    for script in (CASES if cases is None else cases):
        if only in script:
            run(script, dict(GOOD), FRAMEWORK_ROOT / "test_results" / "M210" / folder, bench_class, here)
    return 0


if __name__ == "__main__":
    arguments = sys.argv[1:]
    sys.exit(previews(*arguments[1:2]) if arguments[:1] == ["--html"] else main(*arguments[:1]))
