# Author: Kris
#
# M210 ENS: the init time of the ENS output counted from ignition on, the battery kept on.
# ENS_INIT_RUNS times: ignition off for the power-off delay, the ENS output recorded with the lamp
# card, ignition on ENS_BEFORE_SUPPLY_MS into the recording.
# Checked in every run: the pin is high without an edge from the start of the recording until the
# PWM starts; the time from ignition on to the first PWM low against ENS_INIT_HIGH_MAX_MS; the
# normal PWM after it, the first low included.
# The script clock times the ignition-on command, so the init time is a range (before and after
# the command); the longest value is graded. The lamp card's own start latency is inside the time.
# EnsMgr has no init timer: the limit is the M314 family value until the M210 requirement gives
# one.
# M210_ENS_01 is the cold start (battery and ignition together); here the battery stays on.
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-31 (P1). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_BEFORE_SUPPLY_MS, ENS_CRASH_RECORD_MS, ENS_INIT_HIGH_MAX_MS, ENS_INIT_RUNS,
    ENS_LONG_RECORD_MS, ENS_NORMAL_HIGH_MS, ENS_NORMAL_LOW_MS, ENS_NORMAL_PULSES_MIN,
    ENS_RECORD_MARGIN_MS, ENS_STEADY_MS, ENS_TICK_MS, ENS_TOLERANCE_MS, GPO_Names,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")
ENS_LOOP = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording. No edge: an empty list (the level is not known from the samples)."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def spread(values):
    return f"min {min(values):.3f} / mean {sum(values) / len(values):.3f} / max {max(values):.3f} ms" if values else "none"


def record_ens(title, record_ms, actions=()):
    """Record the ENS output with the lamp card for record_ms (a multiple of 500, at most 60000).
    actions: (ms after the recording start, label, call), made in time order.
    Returns the levels [(level, start ms, duration ms)] and {label: ms at which the call was made}.
    The report gets the recorded pulse as a high / low trace."""
    aria_reports.add_group(title)
    started = LAMPS.StartLampMonitoring(ENS_LOOP, ch1=True, timeCh1=record_ms)
    start = time.monotonic()
    RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
    done = {}
    for at_ms, label, call in sorted(actions, key=lambda action: action[0]):
        Wait(max(0.0, at_ms - (time.monotonic() - start) * 1000))
        done[label] = (time.monotonic() - start) * 1000
        call()
    Wait(max(0.0, record_ms + ENS_RECORD_MARGIN_MS - (time.monotonic() - start) * 1000))
    response = LAMPS.GetLampRecordedSamples(ENS_LOOP)
    RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
    samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
    RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
    if done:
        RESULT.CommentStep("Actions, ms after the recording start (the time the call was made)",
                           ", ".join(f"{label} {at:.0f}" for label, at in done.items()))
    segments = pulse_segments(samples, record_ms)
    if segments and record_ms <= ENS_LONG_RECORD_MS:
        aria_reports.add_content(pulse_svg(f"ENS output: the whole recording ({len(segments)} levels)", segments,
                                           0.0, float(record_ms), [(at, label) for label, at in done.items()]))
    aria_reports.close_group()
    return segments, done


def all_within(title, values, expected):
    """Every value within one tolerance of the expected time."""
    RESULT.InterpretEqualResult(title, spread(values), f"{expected:g} +/- {ENS_TOLERANCE_MS:g} ms",
                                bool(values) and all(abs(value - expected) <= ENS_TOLERANCE_MS for value in values))


def grade_normal(label, pulses, least=ENS_NORMAL_PULSES_MIN):
    """Normal PWM: every whole high 6 ms, every whole low 4 ms, at least `least` pulses."""
    RESULT.InterpretEqualResult(f"{label}: normal pulses recorded", len(pulses) // 2, f"at least {least}",
                                len(pulses) // 2 >= least)
    all_within(f"{label}: high time of every pulse", [duration for level, _, duration in pulses if level == "H"],
           ENS_NORMAL_HIGH_MS)
    all_within(f"{label}: low time of every pulse", [duration for level, _, duration in pulses if level == "L"],
           ENS_NORMAL_LOW_MS)


def pwm_from(segments, after_ms):
    """The PWM after a time: (start ms of its first low or None, its whole levels)."""
    for index, (level, start, duration) in enumerate(segments):
        if level == "L" and start >= after_ms and duration <= ENS_STEADY_MS:
            return start, list(segments[index:-1])
    return None, []


def init_time_step(label, wake, segments, earliest_ms, latest_ms):
    """Grade one start of the ENS output. The wake-up (ignition on or the CAN wake request) was made
    between earliest_ms and latest_ms of the recording. Graded: the pin is high without an edge
    until the PWM starts, the time from the wake-up to the first PWM low (the longest value of the
    range) against ENS_INIT_HIGH_MAX_MS, and the normal PWM after it.
    Returns the longest init time in ms, None without a PWM."""
    aria_reports.add_group(f"{label}: init time from {wake}")
    start, pulses = pwm_from(segments, earliest_ms - ENS_TICK_MS)    # one tick: the two clocks differ
    if start is None:
        RESULT.InterpretEqualResult(f"{label}: PWM after {wake}", "no PWM in the recording", "6 / 4 ms PWM", False)
        aria_reports.close_group()
        return None
    aria_reports.add_content(pulse_svg(
        f"ENS output: {wake} to the first pulses", segments, max(0.0, earliest_ms - 50), start + 60,
        [(earliest_ms, "wake-up, earliest"), (latest_ms, "wake-up, latest"), (start, "PWM starts")]))
    level, _, duration = segments[0]
    RESULT.InterpretEqualResult(f"{label}: level from the start of the recording to the PWM start",
                                f"{level} for {duration:.1f} ms", f"H for {start:.1f} ms (no edge)",
                                level == "H" and abs(duration - start) < ENS_TICK_MS)
    shortest, longest = start - latest_ms, start - earliest_ms
    RESULT.InterpretEqualResult(
        f"{label}: init time, {wake} to the first PWM low (ms)",
        f"{shortest:.1f} to {longest:.1f} (the time of the wake-up is a range)", f"at most {ENS_INIT_HIGH_MAX_MS:g}",
        longest <= ENS_INIT_HIGH_MAX_MS)
    grade_normal(f"{label}: PWM after the init time", pulses)
    aria_reports.close_group()
    return longest


def run_test():
    tc_id = "ENS-TC-31"
    tc_desc = "ENS init time from ignition on: steady high, then the PWM, timed from the ignition-on command."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "every run: no edge until the PWM starts, first PWM low at most 450 ms after ignition on (to be confirmed), then 6 / 4 ms PWM")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        longest = []
        for run in range(1, ENS_INIT_RUNS + 1):
            label = f"Run {run}"
            PS.IGN_OFF()
            Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off; the battery stays on
            segments, done = record_ens(f"{label}: ENS output across ignition on", ENS_CRASH_RECORD_MS, [
                (ENS_BEFORE_SUPPLY_MS, "IGN on sent", PS.IGN_ON), (ENS_BEFORE_SUPPLY_MS, "IGN on done", lambda: None)])
            longest.append(init_time_step(label, "ignition on", segments, done["IGN on sent"], done["IGN on done"]))
            Wait(PROVEOUT_COMPLETION_TIME)
        RESULT.CommentStep("Init time from ignition on, longest value of each run (ms)",
                           ", ".join("none" if value is None else f"{value:.1f}" for value in longest))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        PS.IGN_ON()
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
