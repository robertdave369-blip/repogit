# Author: Kris
#
# M210 ENS: the front set (underbody channels play the zero curve, crash_curve_config) must be
# reported as a front crash only. CRASH_LOCATION is read once per frame period across the crash;
# then the front and the understrike crash DTC and, after an ignition cycle, the crash counters of
# DID 0458 are read.
# Not checked here: the crash location of the EDR record (EDR scripts).
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-27 (P2). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_RX_MESSAGE_CONFIG, CAN_SIGNAL_Rx_EXPECTED_VALUES,
    CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_BEFORE_CRASH_MS, ENS_CRASH_COUNTER_ORDER, ENS_CRASH_COUNTER_READ, ENS_CRASH_DTC,
    ENS_CRASH_RECORD_MS, ENS_LONG_RECORD_MS, ENS_RECORD_MARGIN_MS, GPO_Names,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")
ENS_LOOP = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording. No edge: an empty list (the level is not known from the samples)."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def record_ens(title, record_ms, actions=()):
    """Record the ENS output with the lamp card for record_ms (a multiple of 500, at most 60000).
    actions: (ms after the recording start, label, call), made in time order.
    Returns the levels [(level, start ms, duration ms)] and {label: ms at which the call was made}.
    The report gets the recorded pulse as a high / low trace."""
    aria_reports.add_group(title)
    started = LAMPS.StartLampMonitoring(ENS_LOOP, ch1=True, timeCh1=record_ms)
    start = time.monotonic()
    RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
    done = {}
    for at_ms, label, call in sorted(actions, key=lambda action: action[0]):
        Wait(max(0.0, at_ms - (time.monotonic() - start) * 1000))
        done[label] = (time.monotonic() - start) * 1000
        call()
    Wait(max(0.0, record_ms + ENS_RECORD_MARGIN_MS - (time.monotonic() - start) * 1000))
    response = LAMPS.GetLampRecordedSamples(ENS_LOOP)
    RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
    samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
    RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
    if done:
        RESULT.CommentStep("Actions, ms after the recording start (the time the call was made)",
                           ", ".join(f"{label} {at:.0f}" for label, at in done.items()))
    segments = pulse_segments(samples, record_ms)
    if segments and record_ms <= ENS_LONG_RECORD_MS:
        aria_reports.add_content(pulse_svg(f"ENS output: the whole recording ({len(segments)} levels)", segments,
                                           0.0, float(record_ms), [(at, label) for label, at in done.items()]))
    aria_reports.close_group()
    return segments, done


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def watch_can(names, watch_ms, actions=()):
    """Read CAN signals once per frame period for watch_ms: [(ms after the call, {name: raw})].
    actions: (ms after the call, call), made between two reads."""
    period_ms = CAN_RX_MESSAGE_CONFIG[CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][names[0]][0]]["periodicity"]
    start, trace, pending = time.monotonic(), [], sorted(actions, key=lambda action: action[0])
    while (now := (time.monotonic() - start) * 1000) <= watch_ms:
        while pending and now >= pending[0][0]:
            pending.pop(0)[1]()
        trace.append((now, {name: read_can(name) for name in names}))
        Wait(max(0.0, now + period_ms - (time.monotonic() - start) * 1000))
    return trace


def crash_locations(trace):
    """CRASH_LOCATION values other than 0 of a watch_can trace."""
    return sorted({values["CRASH_LOCATION"] for _, values in trace if values["CRASH_LOCATION"]})


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def ignition_cycle():
    PS.IGN_OFF()
    Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def record_crash(label, record_ms=ENS_CRASH_RECORD_MS, can=(), actions=()):
    """Record the ENS output across one replay of the loaded crash set; the crash is triggered
    ENS_BEFORE_CRASH_MS after the start. can: signals read once per frame period from the trigger
    on. actions: (ms after the trigger, label, call).
    Returns the levels, the action times (ms of the recording) and the CAN trace."""
    trace = []
    timed = [(ENS_BEFORE_CRASH_MS, "crash", TriggerCrash)]
    if can:    # the actions are made between two CAN reads
        watch_ms = record_ms - ENS_BEFORE_CRASH_MS - 500
        timed.append((ENS_BEFORE_CRASH_MS, "CAN read", lambda: trace.extend(
            watch_can(list(can), watch_ms, [(at, call) for at, _, call in actions]))))
    else:
        timed += [(ENS_BEFORE_CRASH_MS + at, name, call) for at, name, call in actions]
    segments, done = record_ens(f"{label}: ENS output across the crash", record_ms, timed)
    return segments, done, trace


def read_counters(when):
    """The crash counters of DID 0458 as a list of bytes (empty when the read fails)."""
    response = str(CAN.SendDiagByValues(ENS_CRASH_COUNTER_READ))
    RESULT.CommentStep(f"{when}: DID 0458 ({' / '.join(ENS_CRASH_COUNTER_ORDER)} in the EnsMgr order; the byte "
                       "order of the DID is not confirmed)", response)
    return [int(token, 16) for token in response.split()[3:]] if response.startswith("0x62") else []


def one_counter(when, values):
    """Exactly one crash counter at 1, every other at 0."""
    RESULT.InterpretEqualResult(f"{when}: crash counters", values, "one counter at 1, the others 0",
                                sorted(values)[:-1] == [0] * (len(values) - 1) and values.count(1) == 1)


def run_test():
    tc_id = "ENS-TC-27"
    tc_desc = "A front crash is not reported as understrike (ENS-BUG-10)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "CRASH_LOCATION front only, front crash DTC active, understrike DTC absent, one crash counter at 1")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        label = "Front crash"
        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        _, _, trace = record_crash(label, can=["CRASH_LOCATION"])
        front = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["CRASH_LOCATION"], 0)
        RESULT.InterpretEqualResult(f"{label}: CRASH_LOCATION values other than 0 on CAN", crash_locations(trace), [front],
                                    crash_locations(trace) == [front])
        dtc_step(label, ENS_CRASH_DTC["front"])
        dtc_step(label, ENS_CRASH_DTC["understrike"], "absent")
        ignition_cycle()
        one_counter(label, read_counters(label))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
