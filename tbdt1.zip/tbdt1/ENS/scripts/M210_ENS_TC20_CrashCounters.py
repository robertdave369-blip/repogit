# Author: Kris
#
# M210 ENS: the crash counters EnsMgr keeps in NVM, read with DID 0458.
# 1. Fault free: all counters 0.
# 2. Front crash, ignition cycle: one counter at 1.
# 3. Second front crash in a new power cycle: counters unchanged.
# 4. Clean ECU, front crash, battery cut 1 s after the crash: one counter at 1 after power on
#    (ENS-BUG-14: the count may be lost).
# 5. Left, right, rear and underbody crash on a clean ECU: one counter at 1 each, at a different
#    byte for each crash type.
# The byte order of the DID is not in the reviewed source: the position is reported, not graded.
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-20 (P2). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_BATTERY_CUT_AFTER_CRASH_MS, ENS_CRASH_COUNTER_ORDER, ENS_CRASH_COUNTER_READ, ENS_CRASH_SETS,
    ENS_DTC_READ_WAIT_MS, ENS_SUPPLY_STEP_MS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY


def ignition_cycle():
    PS.IGN_OFF()
    Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def battery_cycle(off_ms):
    """Battery and ignition off for off_ms, then on and prove-out (the load_crash_curves order)."""
    PS.BATT_OFF()
    Wait(ENS_SUPPLY_STEP_MS)
    PS.IGN_OFF()
    Wait(off_ms)
    PS.BATT_ON()
    Wait(ENS_SUPPLY_STEP_MS)
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def read_counters(when):
    """The crash counters of DID 0458 as a list of bytes (empty when the read fails)."""
    response = str(CAN.SendDiagByValues(ENS_CRASH_COUNTER_READ))
    RESULT.CommentStep(f"{when}: DID 0458 ({' / '.join(ENS_CRASH_COUNTER_ORDER)} in the EnsMgr order; the byte "
                       "order of the DID is not confirmed)", response)
    return [int(token, 16) for token in response.split()[3:]] if response.startswith("0x62") else []


def one_counter(when, values):
    """Exactly one crash counter at 1, every other at 0."""
    RESULT.InterpretEqualResult(f"{when}: crash counters", values, "one counter at 1, the others 0",
                                sorted(values)[:-1] == [0] * (len(values) - 1) and values.count(1) == 1)


def run_test():
    tc_id = "ENS-TC-20"
    tc_desc = "Crash counters of DID 0458: one count per crash type, kept over a battery cut (ENS-BUG-14)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "fault free all 0; after a crash exactly one counter at 1; a second crash of the type does not change it; each type its own counter")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        def crash(key):
            load_crash_curves(key)    # ECU off, curves loaded, ECU on, prove-out
            TriggerCrash()
            Wait(ENS_DTC_READ_WAIT_MS)

        values = read_counters("Fault free")
        RESULT.InterpretEqualResult("Fault free: crash counters", values, "all 0",
                                    len(values) == len(ENS_CRASH_COUNTER_ORDER) and not any(values))

        crash("front")
        ignition_cycle()
        first = read_counters("Front crash, ignition cycle")
        one_counter("Front crash, ignition cycle", first)

        crash("front")
        ignition_cycle()
        second = read_counters("Second front crash")
        RESULT.InterpretEqualResult("Second front crash: crash counters unchanged", second, first, second == first)

        fault_free_profile()
        load_crash_curves("front")
        TriggerCrash()
        Wait(ENS_BATTERY_CUT_AFTER_CRASH_MS)
        battery_cycle(POWER_OFF_DELAY * 1000)
        one_counter("Front crash, battery cut after the crash", read_counters("Front crash, battery cut after the crash"))

        positions = {"front": first.index(1) if 1 in first else None}
        for key in ENS_CRASH_SETS[1:]:
            fault_free_profile()
            crash(key)
            ignition_cycle()
            values = read_counters(f"{key} crash")
            one_counter(f"{key} crash", values)
            positions[key] = values.index(1) if 1 in values else None
        RESULT.InterpretEqualResult("Byte of the counter at 1 per crash type", positions, "a different byte for each type",
                                    None not in positions.values() and len(set(positions.values())) == len(positions))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
