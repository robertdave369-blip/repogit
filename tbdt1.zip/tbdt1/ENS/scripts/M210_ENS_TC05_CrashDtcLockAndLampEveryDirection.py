# Author: Kris
#
# M210 ENS: the crash DTC of a front, left, right, rear and underbody crash.
# Each set is replayed once; 2 s later the DTCs are read (19 02 FF) and INDC_SRS is read on CAN.
# Expected: the crash DTC of the direction active (fault_list_config through gpo_config
# ENS_CRASH_DTC), the crash DTCs of the other directions not reported, warning lamp on. The
# pretensioner lock DTC is reported: it is expected when a pretensioner fired.
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-05 (P0). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_CRASH_DTC, ENS_CRASH_SETS, ENS_DTC_READ_WAIT_MS, ENS_PRETENSIONER_DTC,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def run_test():
    tc_id = "ENS-TC-05"
    tc_desc = "Crash DTC, ECU lock and warning lamp for every crash direction."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P0")
    aria_reports.add_report_info("#Expected:", "the crash DTC of the direction active, no crash DTC of another direction, warning lamp on")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        for index, key in enumerate(ENS_CRASH_SETS):
            label = f"{key} crash"
            if index:
                fault_free_profile()
            load_crash_curves(key)    # ECU off, curves loaded, ECU on, prove-out
            aria_reports.add_group(f"{label}: crash DTC, ECU lock and warning lamp")
            TriggerCrash()
            Wait(ENS_DTC_READ_WAIT_MS)
            for direction, mnemonic in ENS_CRASH_DTC.items():
                dtc_step(label, mnemonic, "active" if direction == key else "absent")
            locked = CAN.CheckSingleDTC(None, getattr(fault_list_config, ENS_PRETENSIONER_DTC)["dtc_hex"])
            RESULT.CommentStep(f"{label}: {ENS_PRETENSIONER_DTC} (expected when a pretensioner fired)", str(locked[1]))
            lamp_step(label, True)
            aria_reports.close_group()

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
