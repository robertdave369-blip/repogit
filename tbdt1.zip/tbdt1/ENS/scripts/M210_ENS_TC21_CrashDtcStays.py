# Author: Kris
#
# M210 ENS: the crash stays stored.
# A front crash is replayed. The front crash DTC and INDC_SRS are read after the crash, after
# clear DTC (14 FF FF FF), after each of 3 ignition cycles and after a battery off of 30 s
# (gpo_config).
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-21 (P1). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_SIGNAL_Rx_EXPECTED_VALUES, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_BATTERY_OFF_MS, ENS_CRASH_DTC, ENS_DTC_READ_WAIT_MS, ENS_IGNITION_CYCLES,
    ENS_SUPPLY_STEP_MS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def lamp_step(title, lit):
    """The warning lamp request on CAN (INDC_SRS): the canc_config crash value when lit, else 0."""
    expected = int(CAN_SIGNAL_Rx_EXPECTED_VALUES["front"]["INDC_SRS"], 0) if lit else 0
    value = read_can("INDC_SRS")
    RESULT.InterpretEqualResult(f"{title}: INDC_SRS (warning lamp {'on' if lit else 'off'})", value, expected,
                                value == expected)


def ignition_cycle():
    PS.IGN_OFF()
    Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def battery_cycle(off_ms):
    """Battery and ignition off for off_ms, then on and prove-out (the load_crash_curves order)."""
    PS.BATT_OFF()
    Wait(ENS_SUPPLY_STEP_MS)
    PS.IGN_OFF()
    Wait(off_ms)
    PS.BATT_ON()
    Wait(ENS_SUPPLY_STEP_MS)
    PS.IGN_ON()
    Wait(PROVEOUT_COMPLETION_TIME)


def run_test():
    tc_id = "ENS-TC-21"
    tc_desc = "The crash DTC and the warning lamp stay after clear DTC, ignition cycles and a battery cycle."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "front crash DTC active and warning lamp on at every read")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        def stored(when):
            dtc_step(when, ENS_CRASH_DTC["front"])
            lamp_step(when, True)

        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        TriggerCrash()
        Wait(ENS_DTC_READ_WAIT_MS)
        stored("After the crash")
        Clear_DTC_Info()    # 14 FF FF FF
        stored("After clear DTC")
        for cycle in range(1, ENS_IGNITION_CYCLES + 1):
            ignition_cycle()
            stored(f"After ignition cycle {cycle}")
        battery_cycle(ENS_BATTERY_OFF_MS)
        stored(f"After the battery off of {ENS_BATTERY_OFF_MS} ms")

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
