# Author: Kris
#
# M210 ENS: the internal faults EnsMgr sets at a frontal deployment, read with DID FD39 through
# the
# shared internal error list (CAN.ReadAllDTCNamesWithStatus).
# With the passenger airbag enabled (fault free profile) a front crash must set
# OPS_E_FRONTAL_BAGS_FIRED only. Blocked when the bench cannot read internal faults or the list
# does
# not name them: the raw read is in the report.
# Not automated: the run with the passenger airbag disabled (expected: ..._PASS_INHIBITED only).
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-28 (P3). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_DTC_READ_WAIT_MS, ENS_FRONTAL_FAULT, ENS_FRONTAL_INHIBITED_FAULT,
)


def internal_faults(label):
    """Names of the internal faults the ECU reports (DID FD39, shared internal error list)."""
    text = str(CAN.ReadAllDTCNamesWithStatus())
    RESULT.CommentStep(f"{label}: internal faults (DID FD39)", text)
    return {entry.split(" with status")[0].strip() for entry in text.rstrip(".").split(",")}


def run_test():
    tc_id = "ENS-TC-28"
    tc_desc = "Front crash: frontal deployment internal faults (ENS-BUG-18)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P3")
    aria_reports.add_report_info("#Expected:", "passenger airbag enabled: OPS_E_FRONTAL_BAGS_FIRED set, OPS_E_FRONTAL_BAGS_FIRED_PASS_INHIBITED not set")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        label = "Front crash, passenger airbag enabled"
        load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
        TriggerCrash()
        Wait(ENS_DTC_READ_WAIT_MS)
        faults = internal_faults(label)
        for fault, expected in ((ENS_FRONTAL_FAULT, True), (ENS_FRONTAL_INHIBITED_FAULT, False)):
            RESULT.InterpretEqualResult(f"{label}: {fault} set", fault in faults, expected, (fault in faults) == expected)

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
