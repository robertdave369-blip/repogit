# Author: Kris
#
# M210 ENS (crash output, GPO): PWM timing in normal operation.
# The ENS output is recorded with the ARIA lamp card (LAMPS.StartLampMonitoring) and read back as
# edges (LAMPS.GetLampRecordedSamples); every high and low time of the recording is checked.
# Expected, from the ECU source (EnsMgr_PBCfg.h, EnsMgr_MainFunction at 0.5 ms): normal pattern
# 6 ms high (ENSMGR_NORMAL_HIGH_TIME 12 ticks) and 4 ms low (ENSMGR_NORMAL_LOW_TIME 8 ticks),
# so 10 ms period, 100 Hz, 60 % high.
# The report shows the recorded pulse as a high / low trace.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    GPO_Names, ENS_NORMAL_HIGH_MS, ENS_NORMAL_LOW_MS, ENS_RECORD_MARGIN_MS, ENS_TICK_MS, ENS_TOLERANCE_MS,
)

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def spread(values):
    return f"min {min(values):.3f} / mean {sum(values) / len(values):.3f} / max {max(values):.3f} ms" if values else "none"


def run_test():
    tc_id = "M210-ENS-02"
    tc_desc = "ENS PWM timing in normal operation: high time, low time, period, frequency and duty cycle."
    ens_loop = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output

    # -- 1. Expected results (timing: projects/M210/config/gpo_config.py, from the ECU source) --
    tick_ms = ENS_TICK_MS                # EnsMgr_MainFunction period
    normal_high_ms = ENS_NORMAL_HIGH_MS
    normal_low_ms = ENS_NORMAL_LOW_MS
    tolerance_ms = ENS_TOLERANCE_MS      # one ECU tick either side of every high and low time
    period_ms = normal_high_ms + normal_low_ms
    record_ms = 2000        # lamp card recording: a multiple of 500 ms, at most 60000 ms
    record_margin_ms = ENS_RECORD_MARGIN_MS    # before the samples are read
    plot_ms = 100.0         # report trace: the first 100 ms of whole pulses

    # -- 2. Report ----------------------------------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#ENS lamp loop:", ens_loop)
    aria_reports.add_report_info("#Expected:", f"high {normal_high_ms:g} ms, low {normal_low_ms:g} ms, "
                                               f"each +/- {tolerance_ms:g} ms")

    try:
        fault_free_profile()    # NVM cleared, default EOL / variant code, power cycle
        read_software_version()

        # -- 3. Record the ENS output in normal operation --------------------------------------------
        aria_reports.add_group(f"Record the ENS output for {record_ms} ms")
        Wait(PROVEOUT_COMPLETION_TIME)    # prove-out complete: steady normal operation
        started = LAMPS.StartLampMonitoring(ens_loop, ch1=True, timeCh1=record_ms)
        RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
        Wait(record_ms + record_margin_ms)
        response = LAMPS.GetLampRecordedSamples(ens_loop)
        RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
        samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
        RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
        aria_reports.close_group()

        segments = pulse_segments(samples, record_ms)
        whole = segments[1:-1]    # the first and the last level are cut by the recording
        highs = [duration for level, start, duration in whole if level == "H"]
        lows = [duration for level, start, duration in whole if level == "L"]
        if not highs or not lows:
            RESULT.InterpretEqualResult("BLOCKED - ENS PWM", f"{len(samples)} samples, no whole pulse",
                                        "a PWM on the ENS output", False)
            return

        # -- 4. The recorded pulse ----------------------------------------------------------------------
        aria_reports.add_group("ENS pulse (high / low)")
        first = whole[0][1]
        aria_reports.add_content(pulse_svg(f"ENS output, {plot_ms:g} ms of the recording", segments,
                                           first, first + plot_ms))
        aria_reports.close_group()

        # -- 5. High time, low time, period, frequency, duty cycle ----------------------------------------
        aria_reports.add_group("ENS PWM timing")
        periods = [whole[i][2] + whole[i + 1][2] for i in range(0, len(whole) - 1, 2)]
        RESULT.InterpretEqualResult(
            "High time of every pulse", spread(highs), f"{normal_high_ms:g} +/- {tolerance_ms:g} ms",
            all(abs(value - normal_high_ms) <= tolerance_ms for value in highs))
        RESULT.InterpretEqualResult(
            "Low time of every pulse", spread(lows), f"{normal_low_ms:g} +/- {tolerance_ms:g} ms",
            all(abs(value - normal_low_ms) <= tolerance_ms for value in lows))
        RESULT.InterpretEqualResult(
            "Period of every pulse", spread(periods), f"{period_ms:g} +/- {tolerance_ms:g} ms",
            all(abs(value - period_ms) <= tolerance_ms for value in periods))
        mean_period = sum(periods) / len(periods)
        frequency, duty = 1000.0 / mean_period, 100.0 * (sum(highs) / len(highs)) / mean_period
        low_period, high_period = period_ms - tolerance_ms, period_ms + tolerance_ms
        RESULT.InterpretEqualResult(
            "Frequency (Hz)", f"{frequency:.2f}", f"{1000.0 / period_ms:g} ({1000.0 / high_period:.1f} to "
            f"{1000.0 / low_period:.1f})", 1000.0 / high_period <= frequency <= 1000.0 / low_period)
        duty_low = 100.0 * (normal_high_ms - tolerance_ms) / period_ms
        duty_high = 100.0 * (normal_high_ms + tolerance_ms) / period_ms
        RESULT.InterpretEqualResult(
            "Duty cycle, high (%)", f"{duty:.2f}", f"{100.0 * normal_high_ms / period_ms:g} ({duty_low:g} to "
            f"{duty_high:g})", duty_low <= duty <= duty_high)
        # No pulse missing: the whole pulses fill the recording.
        expected_pulses = record_ms / period_ms
        RESULT.InterpretEqualResult(
            "Whole pulses in the recording", len(periods), f"{expected_pulses:g} +/- 2",
            abs(len(periods) - expected_pulses) <= 2)
        aria_reports.close_group()

    finally:
        # -- 6. Make the bench fault free, even when a step above raised ---------------------------------
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
