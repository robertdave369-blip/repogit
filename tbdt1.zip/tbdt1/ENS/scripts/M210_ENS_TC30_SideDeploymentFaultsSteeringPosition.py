# Author: Kris
#
# M210 ENS: the lateral deployment internal faults against the steering position.
# For each steering position (shared SteeringWheelPosition_Config) a left and a right crash are
# replayed; the internal faults are read with DID FD39 through the shared internal error list.
# The fault of the crash side must be set and the fault of the other side not, whatever the
# steering position. Blocked when the bench cannot read internal faults: the raw read is in the
# report. The first steering position of gpo_config is written back at the end.
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-30 (P3). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_DTC_READ_WAIT_MS, ENS_LATERAL_FAULT, ENS_STEERING_POSITIONS,
)


def internal_faults(label):
    """Names of the internal faults the ECU reports (DID FD39, shared internal error list)."""
    text = str(CAN.ReadAllDTCNamesWithStatus())
    RESULT.CommentStep(f"{label}: internal faults (DID FD39)", text)
    return {entry.split(" with status")[0].strip() for entry in text.rstrip(".").split(",")}


def run_test():
    tc_id = "ENS-TC-30"
    tc_desc = "Side deployment internal faults with left- and right-hand drive (ENS-BUG-20)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P3")
    aria_reports.add_report_info("#Expected:", "a left crash sets the left lateral fault, a right crash the right one, with both steering positions")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        for steering in ENS_STEERING_POSITIONS:
            for side, fault in ENS_LATERAL_FAULT.items():
                label = f"{steering}, {side} crash"
                fault_free_profile()
                SteeringWheelPosition_Config(steering)
                load_crash_curves(side)    # ECU off, curves loaded, ECU on, prove-out
                TriggerCrash()
                Wait(ENS_DTC_READ_WAIT_MS)
                faults = internal_faults(label)
                for name in ENS_LATERAL_FAULT.values():
                    RESULT.InterpretEqualResult(f"{label}: {name} set", name in faults, name == fault,
                                                (name in faults) == (name == fault))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        SteeringWheelPosition_Config(ENS_STEERING_POSITIONS[0])
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
