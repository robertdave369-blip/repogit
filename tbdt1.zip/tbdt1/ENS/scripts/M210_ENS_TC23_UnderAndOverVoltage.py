# Author: Kris
#
# M210 ENS: supply voltage (voltages from power_config, PS.SetVoltage).
# 1. Under-voltage test voltage: the pin for 2 s (reported: the PWM under a voltage fault is not
# in
#    the ECU source); ENS open applied for 10 s: no ENS open DTC active (the ENS faults are
# inhibited
#    by the voltage conditions, P31 FltMonr_PBCfg.h); back at the nominal voltage the DTC becomes
#    active within the qualification time.
# 2. The same with the over-voltage test voltage.
# 3. Ramp nominal -> under-voltage threshold -> nominal -> over-voltage threshold -> nominal in
#    steps of ENS_VOLTAGE_STEP_V: 6 / 4 ms PWM at every step inside the range (at the thresholds:
#    reported).
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-23 (P2). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config import fault_list_config
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    DTC_GPO_fault, ENS_LONG_RECORD_MS, ENS_NORMAL_HIGH_MS, ENS_NORMAL_LOW_MS, ENS_NORMAL_PULSES_MIN,
    ENS_RECORD_MARGIN_MS, ENS_STEADY_RECORD_MS, ENS_TOLERANCE_MS, ENS_VOLTAGE_FAULT_WAIT_MS,
    ENS_VOLTAGE_SETTLE_MS, ENS_VOLTAGE_STEP_V, GPO_FaultStatus, GPO_Names, gpo_fault_time,
)
from Framework_IOEM_Py.projects.M210.config.power_config import (
    NOMINAL_VOLTAGE, OVERVOLTAGE_TEST_VOLTAGE, OVERVOLTAGE_THRESHOLD, UNDERVOLTAGE_TEST_VOLTAGE,
    UNDERVOLTAGE_THRESHOLD,
)

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")
ENS_LOOP = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording. No edge: an empty list (the level is not known from the samples)."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def spread(values):
    return f"min {min(values):.3f} / mean {sum(values) / len(values):.3f} / max {max(values):.3f} ms" if values else "none"


def record_ens(title, record_ms, actions=()):
    """Record the ENS output with the lamp card for record_ms (a multiple of 500, at most 60000).
    actions: (ms after the recording start, label, call), made in time order.
    Returns the levels [(level, start ms, duration ms)] and {label: ms at which the call was made}.
    The report gets the recorded pulse as a high / low trace."""
    aria_reports.add_group(title)
    started = LAMPS.StartLampMonitoring(ENS_LOOP, ch1=True, timeCh1=record_ms)
    start = time.monotonic()
    RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
    done = {}
    for at_ms, label, call in sorted(actions, key=lambda action: action[0]):
        Wait(max(0.0, at_ms - (time.monotonic() - start) * 1000))
        done[label] = (time.monotonic() - start) * 1000
        call()
    Wait(max(0.0, record_ms + ENS_RECORD_MARGIN_MS - (time.monotonic() - start) * 1000))
    response = LAMPS.GetLampRecordedSamples(ENS_LOOP)
    RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
    samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
    RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
    if done:
        RESULT.CommentStep("Actions, ms after the recording start (the time the call was made)",
                           ", ".join(f"{label} {at:.0f}" for label, at in done.items()))
    segments = pulse_segments(samples, record_ms)
    if segments and record_ms <= ENS_LONG_RECORD_MS:
        aria_reports.add_content(pulse_svg(f"ENS output: the whole recording ({len(segments)} levels)", segments,
                                           0.0, float(record_ms), [(at, label) for label, at in done.items()]))
    aria_reports.close_group()
    return segments, done


def all_within(title, values, expected):
    """Every value within one tolerance of the expected time."""
    RESULT.InterpretEqualResult(title, spread(values), f"{expected:g} +/- {ENS_TOLERANCE_MS:g} ms",
                                bool(values) and all(abs(value - expected) <= ENS_TOLERANCE_MS for value in values))


def grade_normal(label, pulses, least=ENS_NORMAL_PULSES_MIN):
    """Normal PWM: every whole high 6 ms, every whole low 4 ms, at least `least` pulses."""
    RESULT.InterpretEqualResult(f"{label}: normal pulses recorded", len(pulses) // 2, f"at least {least}",
                                len(pulses) // 2 >= least)
    all_within(f"{label}: high time of every pulse", [duration for level, _, duration in pulses if level == "H"],
           ENS_NORMAL_HIGH_MS)
    all_within(f"{label}: low time of every pulse", [duration for level, _, duration in pulses if level == "L"],
           ENS_NORMAL_LOW_MS)


def dtc_step(title, dtc, state="active"):
    """One DTC read with 19 02 FF and graded: "active" (ISO 14229-1 status bit 0 testFailed set),
    "inactive" (not reported, or testFailed clear) or "absent". dtc: a fault_list_config mnemonic or
    the DTC bytes. A read that fails is a failed step in every state."""
    code = getattr(fault_list_config, dtc)["dtc_hex"] if hasattr(fault_list_config, dtc) else dtc
    response = CAN.CheckSingleDTC(None, code)
    present = response[0] == "0000"
    read = present or "not present" in str(response[1])
    active = present and bool(int(str(response[1]).split()[-1], 16) & 0x01)
    passed = read and {"active": active, "inactive": not active, "absent": not present}[state]
    RESULT.InterpretEqualResult(f"{title}: DTC {code} ({dtc})", response[1], state, passed)
    return passed


def run_test():
    tc_id = "ENS-TC-23"
    tc_desc = "Under-voltage and over-voltage: PWM timing over the working range, ENS fault inhibited by the voltage fault."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P2")
    aria_reports.add_report_info("#Expected:", "inside the working range 6 / 4 ms PWM at every step; no ENS open DTC during the voltage fault, active after return")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        open_dtc = f"{DTC_GPO_fault['ENS']} {GPO_FaultStatus['OPEN']}"
        qualify_ms = gpo_fault_time["Qualification_Time"] + gpo_fault_time["Qualification_Tolerance"]
        heal_ms = gpo_fault_time["Dequalification_Time"] + gpo_fault_time["Dequalification_Tolerance"]
        for name, voltage in (("Under-voltage", UNDERVOLTAGE_TEST_VOLTAGE), ("Over-voltage", OVERVOLTAGE_TEST_VOLTAGE)):
            label = f"{name} {voltage:g} V"
            PS.SetVoltage(voltage)
            Wait(ENS_VOLTAGE_SETTLE_MS)
            segments, _ = record_ens(f"{label}: ENS output", ENS_STEADY_RECORD_MS)
            RESULT.CommentStep(f"{label}: levels in the recording (observed)", len(segments))
            SetGpoFaultCondition("ENS", "OPEN")
            Wait(ENS_VOLTAGE_FAULT_WAIT_MS)
            dtc_step(f"{label}, ENS open", open_dtc, "inactive")
            PS.SetVoltage(NOMINAL_VOLTAGE)
            Wait(ENS_VOLTAGE_SETTLE_MS + qualify_ms)
            dtc_step(f"{label}, back at {NOMINAL_VOLTAGE:g} V, ENS open", open_dtc)
            SetGpoFaultCondition("ENS", "INHERENT")    # the output's rest state: fault removed
            Wait(heal_ms)

        down = [NOMINAL_VOLTAGE - step * ENS_VOLTAGE_STEP_V
                for step in range(1, round((NOMINAL_VOLTAGE - UNDERVOLTAGE_THRESHOLD) / ENS_VOLTAGE_STEP_V) + 1)]
        up = [NOMINAL_VOLTAGE + step * ENS_VOLTAGE_STEP_V
              for step in range(1, round((OVERVOLTAGE_THRESHOLD - NOMINAL_VOLTAGE) / ENS_VOLTAGE_STEP_V) + 1)]
        for voltage in down + down[-2::-1] + [NOMINAL_VOLTAGE] + up + up[-2::-1] + [NOMINAL_VOLTAGE]:
            label = f"{voltage:g} V"
            PS.SetVoltage(voltage)
            Wait(ENS_VOLTAGE_SETTLE_MS)
            segments, _ = record_ens(f"{label}: ENS output", ENS_STEADY_RECORD_MS)
            if UNDERVOLTAGE_THRESHOLD < voltage < OVERVOLTAGE_THRESHOLD:
                grade_normal(label, segments[1:-1])
            else:
                RESULT.CommentStep(f"{label}: limit of the working range - levels in the recording (observed)", len(segments))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        PS.SetVoltage(NOMINAL_VOLTAGE)
        SetGpoFaultCondition("ENS", "INHERENT")
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
