# Author: Kris
#
# M210 ENS (crash output, GPO): init pulse at ECU start.
# The ECU is switched off, the ENS output is recorded with the ARIA lamp card
# (LAMPS.StartLampMonitoring) while battery and ignition are switched on, and the edges are read back
# (LAMPS.GetLampRecordedSamples). Checked: the output is high without interruption from supply on
# until the PWM starts, the time it stays high after ignition on, and that the normal PWM follows.
# From the ECU source: EnsMgr_Initialization drives the output high (ENSMGR_SIGNAL_STARTTYPE_INIT
# high), the output stays high while there is no valid wake-up, and the PWM starts with a low of
# 4 ms (ENSMGR_SIGNAL_STARTTYPE_NORMAL low), then 6 ms high / 4 ms low. EnsMgr has no init timer:
# the length of the init pulse comes from the ECU start-up, not from an ENS constant.
# The script clock times the supply commands, so the init time is given as a range (the command
# latency); the upper end is graded. The report shows the recorded pulse as a high / low trace.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    GPO_Names, ENS_INIT_HIGH_MAX_MS, ENS_NORMAL_HIGH_MS, ENS_NORMAL_LOW_MS, ENS_RECORD_MARGIN_MS, ENS_TICK_MS, ENS_TOLERANCE_MS,
)
from Framework_IOEM_Py.projects.M210.config.power_config import POWER_OFF_DELAY

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def spread(values):
    return f"min {min(values):.3f} / mean {sum(values) / len(values):.3f} / max {max(values):.3f} ms" if values else "none"


def run_test():
    tc_id = "M210-ENS-01"
    tc_desc = "ENS init pulse: high from supply on until the PWM starts, time after ignition on, then the normal PWM."
    ens_loop = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output

    # -- 1. Expected results (timing: projects/M210/config/gpo_config.py, from the ECU source) --
    tick_ms = ENS_TICK_MS                # EnsMgr_MainFunction period
    normal_high_ms = ENS_NORMAL_HIGH_MS
    normal_low_ms = ENS_NORMAL_LOW_MS
    tolerance_ms = ENS_TOLERANCE_MS      # one ECU tick either side of every high and low time
    init_high_max_ms = ENS_INIT_HIGH_MAX_MS    # gpo_config: to be confirmed for M210
    record_ms = 3000        # lamp card recording: a multiple of 500 ms, at most 60000 ms
    record_margin_ms = ENS_RECORD_MARGIN_MS    # before the samples are read
    before_supply_ms = 300  # recording runs this long with the ECU off, so the supply edge is in it
    batt_to_ign_ms = 100    # battery on to ignition on, as the load_crash_curves sequence
    pwm_pulses = 20         # normal pulses checked after the init pulse

    # -- 2. Report ----------------------------------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#ENS lamp loop:", ens_loop)
    aria_reports.add_report_info("#Expected:", f"high until the PWM starts, at most {init_high_max_ms:g} ms after "
                                               f"ignition on (to be confirmed for M210); then high "
                                               f"{normal_high_ms:g} ms / low {normal_low_ms:g} ms")

    try:
        fault_free_profile()    # NVM cleared, default EOL / variant code, power cycle
        read_software_version()

        # -- 3. ECU off, record the ENS output, ECU on ----------------------------------------------------
        aria_reports.add_group(f"Switch the ECU off, record the ENS output for {record_ms} ms, switch the ECU on")
        PS.IGN_OFF()
        PS.BATT_OFF()
        Wait(POWER_OFF_DELAY * 1000)    # power_config: the ECU is off
        started = LAMPS.StartLampMonitoring(ens_loop, ch1=True, timeCh1=record_ms)
        record_start = time.monotonic()
        RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
        Wait(before_supply_ms)
        before_batt = time.monotonic()
        PS.BATT_ON()
        after_batt = time.monotonic()
        Wait(batt_to_ign_ms)
        before_ign = time.monotonic()
        PS.IGN_ON()
        after_ign = time.monotonic()
        Wait(max(0.0, record_ms + record_margin_ms - (after_ign - record_start) * 1000))
        response = LAMPS.GetLampRecordedSamples(ens_loop)
        RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
        samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
        RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
        aria_reports.close_group()

        segments = pulse_segments(samples, record_ms)
        # The init pulse: the highs longer than two normal highs (a PWM high is never that long).
        long_highs = [segment for segment in segments[:-1] if segment[0] == "H" and segment[2] > 2 * normal_high_ms]
        if not long_highs:
            RESULT.InterpretEqualResult("BLOCKED - ENS init pulse", f"{len(samples)} samples, no long high followed "
                                        f"by an edge", "a high from supply on until the PWM starts", False)
            return
        level, rise, init_duration = max(long_highs, key=lambda segment: segment[2])
        fall = rise + init_duration

        # Ignition on, on the time axis of the recording. With a rising edge at battery on the edge is
        # the anchor (independent of the recording's time origin); without one (the pin is high with
        # the ECU off) the start of the recording is.
        if rise > 0:
            ign_earliest = rise + (before_ign - after_batt) * 1000
            ign_latest = rise + (after_ign - before_batt) * 1000
            anchor = f"rising edge at battery on, {rise:.1f} ms into the recording"
        else:
            ign_earliest = (before_ign - record_start) * 1000
            ign_latest = (after_ign - record_start) * 1000
            anchor = "start of the recording (no rising edge at battery on)"
        init_shortest, init_longest = fall - ign_latest, fall - ign_earliest

        # -- 4. The recorded pulse ----------------------------------------------------------------------
        aria_reports.add_group("ENS pulse (high / low)")
        marks = [(ign_earliest, "IGN on, earliest"), (ign_latest, "IGN on, latest"), (fall, "PWM starts")]
        aria_reports.add_content(pulse_svg("ENS output: supply on to the first pulses", segments,
                                           max(0.0, rise - 50), fall + 60, marks))
        aria_reports.add_content(pulse_svg("ENS output: end of the init pulse and the first pulses", segments,
                                           fall - 20, fall + 80, [(fall, "PWM starts")]))
        aria_reports.close_group()

        # -- 5. The init pulse ---------------------------------------------------------------------------
        aria_reports.add_group("ENS init pulse")
        RESULT.CommentStep("Time reference", anchor)
        RESULT.InterpretEqualResult("Highs longer than a PWM high before the PWM (no edge inside the init pulse)",
                                    len(long_highs), 1)
        RESULT.CommentStep("High from supply on to the first falling edge", f"{init_duration:.1f} ms")
        RESULT.InterpretEqualResult(
            "Init pulse after ignition on (ms)", f"{init_shortest:.1f} to {init_longest:.1f} (command latency)",
            f"at most {init_high_max_ms:g}", 0 < init_longest <= init_high_max_ms)
        aria_reports.close_group()

        # -- 6. The normal PWM follows -------------------------------------------------------------------
        aria_reports.add_group(f"Normal PWM after the init pulse, first {pwm_pulses} pulses")
        after = [segment for segment in segments[:-1] if segment[1] >= fall][:2 * pwm_pulses]
        highs = [duration for level, start, duration in after if level == "H"]
        lows = [duration for level, start, duration in after if level == "L"]
        RESULT.InterpretEqualResult("Pulses recorded after the init pulse", len(highs), pwm_pulses,
                                    len(highs) == pwm_pulses and len(lows) == pwm_pulses)
        RESULT.InterpretEqualResult(
            "High time of every pulse", spread(highs), f"{normal_high_ms:g} +/- {tolerance_ms:g} ms",
            bool(highs) and all(abs(value - normal_high_ms) <= tolerance_ms for value in highs))
        RESULT.InterpretEqualResult(
            "Low time of every pulse, the first low included", spread(lows),
            f"{normal_low_ms:g} +/- {tolerance_ms:g} ms",
            bool(lows) and all(abs(value - normal_low_ms) <= tolerance_ms for value in lows))
        aria_reports.close_group()

    finally:
        # -- 7. Make the bench fault free, even when a step above raised ---------------------------------
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
