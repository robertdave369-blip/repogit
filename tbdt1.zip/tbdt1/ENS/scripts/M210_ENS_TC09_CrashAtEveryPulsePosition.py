# Author: Kris
#
# M210 ENS: the change-over from the normal to the inverted PWM.
# The front crash is replayed ENS_CHANGEOVER_RUNS times (gpo_config) with a free-running trigger,
# so the crash meets the normal pulse at different positions. Each recording is graded like
# M210_ENS_03_CrashInversion, and no level of it may be shorter than one ECU tick (glitch). The
# first inverted low of every run is reported at the end: it shows the positions reached.
# Test case: ENS_Black_Box_Test_Cases.md, ENS-TC-09 (P1). Expected values: ENS source
# (EnsMgr.c, EnsMgr_PBCfg.h) through projects/M210/config/gpo_config.py and the other M210 configs.
# Not run on the bench yet.

import os
import sys
import time
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.canc_config import (
    CAN_CRASH_FRAME_CHANNEL_MAP, CAN_RX_MESSAGE_CONFIG, CAN_SIGNAL_Rx_MAP,
)
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    ENS_BEFORE_CRASH_MS, ENS_CHANGEOVER_RUNS, ENS_CRASH_HIGH_MS, ENS_CRASH_LOW_MS, ENS_CRASH_MS,
    ENS_CRASH_RECORD_MS, ENS_LONG_RECORD_MS, ENS_NORMAL_HIGH_MS, ENS_NORMAL_LOW_MS,
    ENS_NORMAL_PULSES_MIN, ENS_RECORD_MARGIN_MS, ENS_STEADY_MS, ENS_TICK_MS, ENS_TOLERANCE_MS,
    GPO_Names,
)
from Framework_IOEM_Py.projects.M210.config.project_config import ACTIVE_CAN_VARIANT

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")
ENS_LOOP = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output
LONG_LOW_MS = (ENS_NORMAL_LOW_MS + ENS_CRASH_LOW_MS) / 2    # a low above this is an inverted pulse
CARRIED_LOW_MS = ENS_NORMAL_LOW_MS + ENS_TICK_MS    # the first inverted low may carry this much of a normal low


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording. No edge: an empty list (the level is not known from the samples)."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def spread(values):
    return f"min {min(values):.3f} / mean {sum(values) / len(values):.3f} / max {max(values):.3f} ms" if values else "none"


def record_ens(title, record_ms, actions=()):
    """Record the ENS output with the lamp card for record_ms (a multiple of 500, at most 60000).
    actions: (ms after the recording start, label, call), made in time order.
    Returns the levels [(level, start ms, duration ms)] and {label: ms at which the call was made}.
    The report gets the recorded pulse as a high / low trace."""
    aria_reports.add_group(title)
    started = LAMPS.StartLampMonitoring(ENS_LOOP, ch1=True, timeCh1=record_ms)
    start = time.monotonic()
    RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
    done = {}
    for at_ms, label, call in sorted(actions, key=lambda action: action[0]):
        Wait(max(0.0, at_ms - (time.monotonic() - start) * 1000))
        done[label] = (time.monotonic() - start) * 1000
        call()
    Wait(max(0.0, record_ms + ENS_RECORD_MARGIN_MS - (time.monotonic() - start) * 1000))
    response = LAMPS.GetLampRecordedSamples(ENS_LOOP)
    RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
    samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
    RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
    if done:
        RESULT.CommentStep("Actions, ms after the recording start (the time the call was made)",
                           ", ".join(f"{label} {at:.0f}" for label, at in done.items()))
    segments = pulse_segments(samples, record_ms)
    if segments and record_ms <= ENS_LONG_RECORD_MS:
        aria_reports.add_content(pulse_svg(f"ENS output: the whole recording ({len(segments)} levels)", segments,
                                           0.0, float(record_ms), [(at, label) for label, at in done.items()]))
    aria_reports.close_group()
    return segments, done


def inverted_runs(segments):
    """The inverted runs of a recording: [(start ms, end ms, levels)]. A low above LONG_LOW_MS
    belongs to a run; a normal low or a steady level ends it. A run ends with the high after its
    last long low. The first and the last level are cut by the recording and left out."""
    whole = segments[1:-1]
    found, current = [], None
    for index, (level, _, duration) in enumerate(whole):
        if level == "L" and LONG_LOW_MS < duration <= ENS_STEADY_MS:
            current = [index, index] if current is None else [current[0], index]
        elif current is not None and (level == "L" or duration > ENS_STEADY_MS):
            found.append(current)
            current = None
    if current is not None:
        found.append(current)
    runs = []
    for first, last in found:
        if last + 1 < len(whole) and whole[last + 1][2] <= ENS_STEADY_MS:
            last += 1
        runs.append((whole[first][1], whole[last][1] + whole[last][2], whole[first:last + 1]))
    return runs


def all_within(title, values, expected):
    """Every value within one tolerance of the expected time."""
    RESULT.InterpretEqualResult(title, spread(values), f"{expected:g} +/- {ENS_TOLERANCE_MS:g} ms",
                                bool(values) and all(abs(value - expected) <= ENS_TOLERANCE_MS for value in values))


def grade_normal(label, pulses, least=ENS_NORMAL_PULSES_MIN):
    """Normal PWM: every whole high 6 ms, every whole low 4 ms, at least `least` pulses."""
    RESULT.InterpretEqualResult(f"{label}: normal pulses recorded", len(pulses) // 2, f"at least {least}",
                                len(pulses) // 2 >= least)
    all_within(f"{label}: high time of every pulse", [duration for level, _, duration in pulses if level == "H"],
           ENS_NORMAL_HIGH_MS)
    all_within(f"{label}: low time of every pulse", [duration for level, _, duration in pulses if level == "L"],
           ENS_NORMAL_LOW_MS)


def grade_crash_run(label, segments, expected_runs=1, around=True):
    """Grade the inverted run(s) of a recording: how many, and for each 800 ms, 80 pulses of
    4 ms high / 6 ms low, starting with a low that may carry the rest of a normal low.
    around: also the normal PWM before the first and after the last run (the last high before
    the run may be cut short by the crash: reported). Returns the runs."""
    aria_reports.add_group(f"{label}: inverted PWM")
    runs = inverted_runs(segments)
    RESULT.InterpretEqualResult("Inverted runs in the recording", len(runs), expected_runs,
                                len(runs) == expected_runs)
    pulses = round(ENS_CRASH_MS / (ENS_CRASH_HIGH_MS + ENS_CRASH_LOW_MS))
    for start, end, run in runs:
        marks = [(start, "inverted from"), (end, "normal from")]
        aria_reports.add_content(pulse_svg("ENS output: start of the inverted run", segments, start - 30, start + 50, marks))
        aria_reports.add_content(pulse_svg("ENS output: end of the inverted run", segments, end - 50, end + 30, marks))
        lows = [duration for level, _, duration in run if level == "L"]
        RESULT.InterpretEqualResult(
            "Duration of the inverted run (ms)", f"{end - start:.1f} (from {start:.1f} ms of the recording)",
            f"{ENS_CRASH_MS - ENS_TOLERANCE_MS:g} to {ENS_CRASH_MS + CARRIED_LOW_MS + ENS_TOLERANCE_MS:g}",
            -ENS_TOLERANCE_MS <= end - start - ENS_CRASH_MS <= CARRIED_LOW_MS + ENS_TOLERANCE_MS)
        RESULT.InterpretEqualResult("Inverted pulses", len(lows), pulses, len(lows) == pulses)
        RESULT.InterpretEqualResult(
            "First low of the inverted run (ms)", f"{lows[0]:.3f}",
            f"{ENS_CRASH_LOW_MS - ENS_TOLERANCE_MS:g} to {ENS_CRASH_LOW_MS + CARRIED_LOW_MS + ENS_TOLERANCE_MS:g}",
            -ENS_TOLERANCE_MS <= lows[0] - ENS_CRASH_LOW_MS <= CARRIED_LOW_MS + ENS_TOLERANCE_MS)
        all_within("High time of every inverted pulse", [duration for level, _, duration in run if level == "H"],
               ENS_CRASH_HIGH_MS)
        all_within("Low time of every inverted pulse after the first", lows[1:], ENS_CRASH_LOW_MS)
    if around and runs:
        before = [segment for segment in segments[1:-1] if segment[1] + segment[2] <= runs[0][0]]
        if before and before[-1][0] == "H":
            RESULT.CommentStep("Last high before the inverted run (may be cut short by the crash)",
                               f"{before[-1][2]:.3f} ms")
            before = before[:-1]
        grade_normal("Before the inverted run", before)
        grade_normal("After the inverted run", [segment for segment in segments[1:-1] if segment[1] >= runs[-1][1]])
    aria_reports.close_group()
    return runs


def read_can(name):
    """Raw value of a crash-frame signal (canc_config name); None when it cannot be read."""
    frame, signal = CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][name]
    try:
        return int(str(CAN.GetSignalFromFrame(CAN_CRASH_FRAME_CHANNEL_MAP[ACTIVE_CAN_VARIANT][frame], frame, signal)), 0)
    except ValueError:
        return None


def watch_can(names, watch_ms, actions=()):
    """Read CAN signals once per frame period for watch_ms: [(ms after the call, {name: raw})].
    actions: (ms after the call, call), made between two reads."""
    period_ms = CAN_RX_MESSAGE_CONFIG[CAN_SIGNAL_Rx_MAP[ACTIVE_CAN_VARIANT][names[0]][0]]["periodicity"]
    start, trace, pending = time.monotonic(), [], sorted(actions, key=lambda action: action[0])
    while (now := (time.monotonic() - start) * 1000) <= watch_ms:
        while pending and now >= pending[0][0]:
            pending.pop(0)[1]()
        trace.append((now, {name: read_can(name) for name in names}))
        Wait(max(0.0, now + period_ms - (time.monotonic() - start) * 1000))
    return trace


def record_crash(label, record_ms=ENS_CRASH_RECORD_MS, can=(), actions=()):
    """Record the ENS output across one replay of the loaded crash set; the crash is triggered
    ENS_BEFORE_CRASH_MS after the start. can: signals read once per frame period from the trigger
    on. actions: (ms after the trigger, label, call).
    Returns the levels, the action times (ms of the recording) and the CAN trace."""
    trace = []
    timed = [(ENS_BEFORE_CRASH_MS, "crash", TriggerCrash)]
    if can:    # the actions are made between two CAN reads
        watch_ms = record_ms - ENS_BEFORE_CRASH_MS - 500
        timed.append((ENS_BEFORE_CRASH_MS, "CAN read", lambda: trace.extend(
            watch_can(list(can), watch_ms, [(at, call) for at, _, call in actions]))))
    else:
        timed += [(ENS_BEFORE_CRASH_MS + at, name, call) for at, name, call in actions]
    segments, done = record_ens(f"{label}: ENS output across the crash", record_ms, timed)
    return segments, done, trace


def run_test():
    tc_id = "ENS-TC-09"
    tc_desc = "Front crash at every position of the normal pulse: the change-over to the inverted PWM (ENS-BUG-16)."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#Priority:", "P1")
    aria_reports.add_report_info("#Expected:", "every run: 800 ms, 80 pulses, first inverted low 6 to 10.5 ms, no level shorter than one ECU tick")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        first_lows = []
        for run in range(ENS_CHANGEOVER_RUNS):
            label = f"Run {run + 1} of {ENS_CHANGEOVER_RUNS}"
            if run:
                fault_free_profile()
            load_crash_curves("front")    # ECU off, curves loaded, ECU on, prove-out
            segments, _, _ = record_crash(label)
            runs = grade_crash_run(label, segments)
            shortest = min((duration for _, _, duration in segments[1:-1]), default=0.0)
            RESULT.InterpretEqualResult(f"{label}: shortest level of the recording (ms)", f"{shortest:.3f}",
                                        f"at least {ENS_TICK_MS:g}", shortest >= ENS_TICK_MS)
            first_lows += [levels[0][2] for _, _, levels in runs]
        RESULT.CommentStep("First inverted low over all runs (the positions of the normal pulse reached)", spread(first_lows))

    finally:
        # Put the bench back and make it fault free, even when a step above raised.
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
