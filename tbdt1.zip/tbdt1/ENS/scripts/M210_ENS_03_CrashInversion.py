# Author: Kris
#
# M210 ENS (crash output, GPO): inverted PWM for 800 ms at a crash.
# The ENS output is recorded with the ARIA lamp card (LAMPS.StartLampMonitoring) across a front
# crash and read back as edges (LAMPS.GetLampRecordedSamples).
# Crash set (the curves fed, named in the script): crash_data/m310_m314_m110/front_crash, loaded
# with the ECU off (the load_crash_curves sequence) and replayed once.
# Expected, from the ECU source (EnsMgr.c, EnsMgr_PBCfg.h, EnsMgr_MainFunction at 0.5 ms):
# - before and after the crash: 6 ms high / 4 ms low;
# - at the crash: 4 ms high (ENSMGR_DEPLOY_HIGH_TIME 8 ticks) / 6 ms low (ENSMGR_DEPLOY_LOW_TIME
#   12 ticks) for 800 ms (ENSMGR_OUTPUT_DURATION_TIMEOUT 1600 ticks), that is 80 inverted pulses,
#   in one run, starting with a low; then the normal pattern again, starting with a 4 ms low;
# - the change-over: the inverted run starts wherever the normal pulse is, so the last normal high
#   may be cut short (reported) and the first inverted low may carry the rest of a normal low
#   (6 to 4 + 0.5 + 6 ms); the 800 ms carries that much tolerance.
# The inverted run is found by its lows: a low above 5 ms belongs to it.
# The report shows the recorded pulse as a high / low trace: the whole inverted run, its start and
# its end.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (bench and report calls).
# The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

from Framework_IOEM_Py.shared_libraries.crash_configuration import build_rsu_config, build_spi_config

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.crash_curve_config import M210_RSU_CHANNEL_SPECS, M210_SPI_SPECS
from Framework_IOEM_Py.projects.M210.config.gpo_config import (
    GPO_Names, ENS_CRASH_HIGH_MS, ENS_CRASH_LOW_MS, ENS_CRASH_MS, ENS_NORMAL_HIGH_MS, ENS_NORMAL_LOW_MS, ENS_RECORD_MARGIN_MS, ENS_TICK_MS, ENS_TOLERANCE_MS,
)

# NOT IN CONFIG - edge values of a lamp card sample that mean "the pin went high". The Apym SDK
# gives a sample as (Time: float, Edge: int) without naming the values: confirm on the first bench
# run with the raw samples printed in the report.
RISING_EDGE = ("1", "true", "rising", "high")


def pulse_segments(samples, window_ms):
    """Lamp card samples (time, edge) -> [(level, start ms, duration ms)], level "H" or "L".
    The level before the first edge is the opposite of that edge; the last level runs to the end
    of the recording."""
    edges = []
    for sample in samples:
        time_value, edge = (list(sample.values()) if isinstance(sample, dict) else list(sample))[:2]
        edges.append((float(time_value), "H" if str(edge).strip().lower() in RISING_EDGE else "L"))
    if not edges:
        return []
    edges.sort()
    span = edges[-1][0] - edges[0][0]
    # shortcut: the SDK does not state the time unit or origin; the unit is the largest of us / ms /
    # s whose span fits the recording, the origin is the recording start when the last edge fits it,
    # else the first edge. Replace both by the stated values once the bench shows them.
    scale = max((unit for unit in (0.001, 1.0, 1000.0) if span * unit <= window_ms), default=1.0)
    origin = 0.0 if edges[-1][0] * scale <= window_ms else edges[0][0]
    segments = []
    if (edges[0][0] - origin) * scale > 0:
        segments.append(["L" if edges[0][1] == "H" else "H", 0.0, (edges[0][0] - origin) * scale])
    for time_value, level in edges:
        start = (time_value - origin) * scale
        if segments:
            segments[-1][2] = start - segments[-1][1]
            if segments[-1][0] == level:    # the same edge twice: one level
                continue
        segments.append([level, start, 0.0])
    segments[-1][2] = max(window_ms - segments[-1][1], 0.0)
    return [tuple(segment) for segment in segments]


def pulse_svg(title, segments, first_ms, last_ms, marks=()):
    """The recorded pulse between two times as a high / low trace (inline SVG for the report).
    marks: (time ms, label) drawn as dashed lines."""
    width, left, high_y, low_y = 1100, 45, 22, 62

    def x(ms):
        return left + (ms - first_ms) * (width - left - 15) / (last_ms - first_ms)

    points = []
    for level, start, duration in segments:
        if start + duration >= first_ms and start <= last_ms:
            y = high_y if level == "H" else low_y
            points += [f"{x(max(start, first_ms)):.1f},{y}", f"{x(min(start + duration, last_ms)):.1f},{y}"]
    lines = "".join(
        f'<line x1="{x(ms):.1f}" y1="8" x2="{x(ms):.1f}" y2="72" stroke="#c0392b" stroke-dasharray="4 3"/>'
        f'<text x="{x(ms) + 3:.1f}" y="12" font-size="10" fill="#c0392b">{label}</text>'
        for ms, label in marks if first_ms <= ms <= last_ms)
    return (
        f'<div style="margin:6px 0"><b>{title}</b><br>'
        f'<svg width="{width}" height="95" style="background:#fff;border:1px solid #bbb">'
        f'<text x="4" y="{high_y + 4}" font-size="11">High</text><text x="4" y="{low_y + 4}" font-size="11">Low</text>'
        f'<polyline points="{" ".join(points)}" fill="none" stroke="#1f4e79" stroke-width="1.5"/>{lines}'
        f'<text x="{left}" y="88" font-size="11">{first_ms:.1f} ms</text>'
        f'<text x="{width - 15}" y="88" font-size="11" text-anchor="end">{last_ms:.1f} ms</text>'
        f'</svg></div>')


def spread(values):
    return f"min {min(values):.3f} / mean {sum(values) / len(values):.3f} / max {max(values):.3f} ms" if values else "none"


def run_test():
    tc_id = "M210-ENS-03"
    tc_desc = "ENS at a front crash: inverted PWM (4 ms high / 6 ms low) for 800 ms, then the normal PWM again."
    ens_loop = next(name for name in GPO_Names if name.upper() == "ENS")    # ARIA lamp loop of the ENS output

    # -- 1. The crash set ---------------------------------------------------------------------------
    set_dir = str(_FRAMEWORK_ROOT / "crash_data" / "m310_m314_m110" / "front_crash")
    rsu = build_rsu_config(set_dir, M210_RSU_CHANNEL_SPECS)    # ARIA RSU channel -> (curve, inverted by ARIA)
    spi = build_spi_config(set_dir, M210_SPI_SPECS["front"])   # GEN6_XY curves 1-4 -> (curve, inverted)

    # -- 2. Expected results (timing: projects/M210/config/gpo_config.py, from the ECU source) --
    tick_ms = ENS_TICK_MS                # EnsMgr_MainFunction period
    normal_high_ms = ENS_NORMAL_HIGH_MS
    normal_low_ms = ENS_NORMAL_LOW_MS
    crash_high_ms = ENS_CRASH_HIGH_MS
    crash_low_ms = ENS_CRASH_LOW_MS
    crash_ms = ENS_CRASH_MS              # 800 ms of inverted PWM
    tolerance_ms = ENS_TOLERANCE_MS      # one ECU tick either side of every high and low time
    period_ms = normal_high_ms + normal_low_ms
    carried_low_ms = normal_low_ms + tick_ms    # the first inverted low may carry this much of a normal low
    crash_tolerance_ms = carried_low_ms + tolerance_ms
    crash_pulses = round(crash_ms / (crash_high_ms + crash_low_ms))
    long_low_ms = (normal_low_ms + crash_low_ms) / 2    # a low above this is an inverted pulse
    record_ms = 3000        # lamp card recording: a multiple of 500 ms, at most 60000 ms
    record_margin_ms = ENS_RECORD_MARGIN_MS    # before the samples are read
    before_crash_ms = 500   # normal PWM recorded before the crash is triggered
    normal_pulses = 10      # normal pulses required before and after the inverted run

    # -- 3. Report ----------------------------------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    aria_reports.add_report_info("#ENS lamp loop:", ens_loop)
    aria_reports.add_report_info("#Crash set:", set_dir)
    aria_reports.add_report_info("#Expected:", f"{crash_pulses} pulses of {crash_high_ms:g} ms high / "
                                               f"{crash_low_ms:g} ms low for {crash_ms:g} ms, "
                                               f"{normal_high_ms:g} / {normal_low_ms:g} ms before and after")

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        # -- 4. Load the set with the ECU off, then switch the ECU on (the load_crash_curves sequence) --
        aria_reports.add_group(f"Load the crash set {os.path.basename(set_dir)} and switch the ECU on")
        PS.BATT_OFF()
        Wait(100)
        PS.IGN_OFF()
        for rsu_channel, (path, inverted) in rsu.items():
            RSU.SendAcceleration(rsu_channel, path, inverted)
        Wait(2000)
        SPI.SendCrashData("GEN6_XY", *[item for pair in spi for item in pair])    # the SPI function load_crash_curves uses
        ResultStep(f"Crash files of {os.path.basename(set_dir)} loaded through ARIA", None, None)
        Wait(100)
        PS.BATT_ON()
        Wait(100)
        PS.IGN_ON()
        Wait(PROVEOUT_COMPLETION_TIME)
        aria_reports.close_group()

        # -- 5. Record the ENS output across one replay of the set -----------------------------------------
        aria_reports.add_group(f"Record the ENS output for {record_ms} ms across the crash")
        started = LAMPS.StartLampMonitoring(ens_loop, ch1=True, timeCh1=record_ms)
        RESULT.InterpretEqualResult("Lamp monitoring started", started[0], "0000")
        Wait(before_crash_ms)
        TriggerCrash()
        Wait(record_ms + record_margin_ms - before_crash_ms)
        response = LAMPS.GetLampRecordedSamples(ens_loop)
        RESULT.InterpretEqualResult("Lamp samples read", response[0], "0000")
        samples = list(response[1]) if response[0] == "0000" and not isinstance(response[1], str) else []
        RESULT.CommentStep("Raw samples (time, edge), first 10", str(samples[:10]))
        aria_reports.close_group()

        segments = pulse_segments(samples, record_ms)
        whole = segments[1:-1]    # the first and the last level are cut by the recording
        long_lows = [index for index, (level, _, duration) in enumerate(whole)
                     if level == "L" and duration > long_low_ms]
        if not long_lows:
            RESULT.InterpretEqualResult("BLOCKED - ENS inverted PWM", f"{len(samples)} samples, no low above "
                                        f"{long_low_ms:g} ms", f"{crash_pulses} inverted pulses", False)
            return
        # The inverted run: from the first long low to the end of the high after the last long low.
        first, last = long_lows[0], min(long_lows[-1] + 1, len(whole) - 1)
        run_start, run_end = whole[first][1], whole[last][1] + whole[last][2]
        before, run, after = whole[:first], whole[first:last + 1], whole[last + 1:]

        # -- 6. The recorded pulse ----------------------------------------------------------------------
        aria_reports.add_group("ENS pulse (high / low)")
        marks = [(run_start, "inverted from"), (run_end, "normal from")]
        aria_reports.add_content(pulse_svg("ENS output: the whole inverted run", segments,
                                           run_start - 100, run_end + 100, marks))
        aria_reports.add_content(pulse_svg("ENS output: start of the inverted run", segments,
                                           run_start - 30, run_start + 50, marks))
        aria_reports.add_content(pulse_svg("ENS output: end of the inverted run", segments,
                                           run_end - 50, run_end + 30, marks))
        aria_reports.close_group()

        def check(title, pulses, level, expected):
            values = [duration for pulse_level, _, duration in pulses if pulse_level == level]
            RESULT.InterpretEqualResult(title, spread(values), f"{expected:g} +/- {tolerance_ms:g} ms",
                                        bool(values) and all(abs(value - expected) <= tolerance_ms for value in values))

        # -- 7. Normal PWM before the crash ----------------------------------------------------------------
        # The last high before the run may be cut short by the crash: reported, not graded.
        aria_reports.add_group("Normal PWM before the crash")
        steady = before[:-1] if before and before[-1][0] == "H" else before
        RESULT.InterpretEqualResult("Normal pulses recorded before the inverted run", len(steady) // 2,
                                    f"at least {normal_pulses}", len(steady) // 2 >= normal_pulses)
        check("High time of every pulse", steady, "H", normal_high_ms)
        check("Low time of every pulse", steady, "L", normal_low_ms)
        if steady is not before:
            RESULT.CommentStep("Last high before the inverted run (may be cut short by the crash)",
                               f"{before[-1][2]:.3f} ms")
        aria_reports.close_group()

        # -- 8. The inverted run: one run of 800 ms, 4 ms high / 6 ms low ----------------------------------
        aria_reports.add_group("Inverted PWM at the crash")
        RESULT.InterpretEqualResult(
            "Duration of the inverted run (ms)", f"{run_end - run_start:.1f} (from {run_start:.1f} to {run_end:.1f} "
            f"ms of the recording)", f"{crash_ms - tolerance_ms:g} to {crash_ms + crash_tolerance_ms:g}",
            -tolerance_ms <= run_end - run_start - crash_ms <= crash_tolerance_ms)
        RESULT.InterpretEqualResult("Inverted pulses", len(long_lows), crash_pulses)
        normal_inside = [f"{start:.1f}" for level, start, duration in run if level == "L" and duration <= long_low_ms]
        RESULT.InterpretEqualResult("Normal pulses inside the inverted run, at ms (one run, no gap)",
                                    ", ".join(normal_inside) or "none", "none", not normal_inside)
        # The first low may carry the rest of a normal low.
        RESULT.InterpretEqualResult(
            "First low of the inverted run (ms)", f"{run[0][2]:.3f}",
            f"{crash_low_ms - tolerance_ms:g} to {crash_low_ms + carried_low_ms + tolerance_ms:g}",
            crash_low_ms - tolerance_ms <= run[0][2] <= crash_low_ms + carried_low_ms + tolerance_ms)
        check("High time of every inverted pulse", run, "H", crash_high_ms)
        check("Low time of every inverted pulse after the first", run[1:], "L", crash_low_ms)
        aria_reports.close_group()

        # -- 9. Normal PWM after the 800 ms ------------------------------------------------------------------
        aria_reports.add_group("Normal PWM after the inverted run")
        RESULT.InterpretEqualResult("Normal pulses recorded after the inverted run", len(after) // 2,
                                    f"at least {normal_pulses}", len(after) // 2 >= normal_pulses)
        check("High time of every pulse", after, "H", normal_high_ms)
        check("Low time of every pulse, the first low included", after, "L", normal_low_ms)
        aria_reports.close_group()

    finally:
        # -- 10. Clear NVM and make the bench fault free, even when a step above raised ------------------
        fault_free_profile()
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
