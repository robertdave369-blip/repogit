"""
Parallel multi-signal EDR simulator (FAULT-induced recording).

One script that drives every EDR signal at its own cadence in parallel and
injects per-signal faults of these classes:

  Mid-simulation faults (induced during the recording window):
    - MESSAGE_TIMEOUT     -> disable the key (carrying) frame
    - NODE_ABSENT         -> disable the key (carrying) frame
    - MESSAGE_CONTENT_FAIL-> corrupt CRC of the associated message
    - SIGNAL_CONTENT_FAIL -> hold an out-of-range / invalid signal value
    => After the fault time, ECU latches the LAST VALID VALUE received before
       the fault. Simulation keeps publishing on CAN, but the ECU ignores it.

  Pre-simulation faults (induced BEFORE simulation starts):
    - VARIANT_CODE_ERROR  -> wrong variant coding written before run
    - NEVER_RECEIVED      -> frame disabled from t=t_start
    - BUS_OFF             -> bus-off forced for the whole window
    => Expected EDR samples are the signal-specific default ('fault_default'),
       not the simulated stream.

Fault timing taxonomy (per signal):
    PRE_SIM   -> fault on before any value is sent
    PRE_HALF  -> mid pre-crash, half-way through negative-time samples
    AT_T0    -> at the trigger sample (one signal-sample before T0)
    POST_HALF -> mid post-crash, half-way through positive-time samples
    clear_at_t0=true => re-enable fault at T0 so post-crash records normally

Config sources (priority):
  1. Excel workbook (env var EDR_SIM_XLSX, .xlsx) - sheets 'Signals' + 'Faults'
  2. CSV file       (env var EDR_SIM_XLSX, .csv)  - signals + sibling edr_sim_faults.csv
  3. MAH_CAN_SIGNAL_DEFS['<key>']['fault_logic'] (default)
"""

import csv
import heapq
import os
import sys
import time
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ───────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (                  # noqa: E402
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance                          # noqa: E402,F401
from apym.reports import ApymReports as aria_reports                           # noqa: E402

# ── Shared libraries ────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT         # noqa: E402
from Framework_IOEM_Py.shared_libraries.can_library import (                   # noqa: E402
    MAH_CAN_SIGNAL_DEFS,
    resolve_dtc_for_event,
)
from Framework_IOEM_Py.shared_libraries.configuration_control import (         # noqa: E402
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.core_functions import (                # noqa: E402
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (              # noqa: E402
    get_sample_interval_ms,
    build_time_axis_and_t0,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (        # noqa: E402
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS     # noqa: E402

# ── Project config (DIDs) ───────────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import EDR_DIDS         # noqa: E402


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

EVENT_SET_SIGNAL = 0
EVENT_INDUCE_FAULT = 1
EVENT_CLEAR_FAULT = 2
EVENT_TRIGGER_CRASH = 3

FAULT_MID = {
    "MESSAGE_TIMEOUT", "NODE_ABSENT", "MESSAGE_CONTENT_FAIL", "SIGNAL_CONTENT_FAIL",
}
FAULT_PRE = {"VARIANT_CODE_ERROR", "NEVER_RECEIVED", "BUS_OFF"}

TIMING_PRE_SIM = "PRE_SIM"
TIMING_PRE_HALF = "PRE_HALF"
TIMING_AT_T0 = "AT_T0"
TIMING_POST_HALF = "POST_HALF"


# ---------------------------------------------------------------------------
# Config loaders
# ---------------------------------------------------------------------------

def _excel_workbook(xlsx_path):
    try:
        import openpyxl
    except ImportError:
        return None
    if not (xlsx_path and os.path.isfile(xlsx_path) and xlsx_path.lower().endswith(".xlsx")):
        return None
    return openpyxl.load_workbook(xlsx_path, data_only=True)


def _sheet_rows(wb, name):
    if wb is None or name not in wb.sheetnames:
        return []
    ws = wb[name]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    header = [str(h).strip() for h in rows[0]]
    out = []
    for r in rows[1:]:
        if r is None or all(c is None for c in r):
            continue
        out.append(dict(zip(header, r)))
    return out


def _csv_rows(csv_path):
    if not (csv_path and os.path.isfile(csv_path)):
        return []
    with open(csv_path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _resolve_csv_inputs(env_path):
    if not env_path or not env_path.lower().endswith(".csv"):
        return None, None
    signals_path = env_path
    folder = os.path.dirname(signals_path)
    candidates = [
        os.path.join(folder, "edr_sim_faults.csv"),
        signals_path.replace("signals", "faults"),
    ]
    faults_path = next((p for p in candidates if os.path.isfile(p)), None)
    return signals_path, faults_path


def _parse_values(field):
    if field is None:
        return []
    vals = []
    for tok in str(field).replace(";", ",").split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            vals.append(int(tok, 0))
        except ValueError:
            vals.append(int(float(tok)))
    return vals


def load_signal_specs(wb, csv_signals_path=None):
    rows = _sheet_rows(wb, "Signals") if wb else []
    if not rows and csv_signals_path:
        rows = _csv_rows(csv_signals_path)
    specs = []
    if rows:
        for row in rows:
            if not row.get("edr_param"):
                continue
            specs.append({
                "edr_param": str(row["edr_param"]).strip(),
                "frame": row.get("frame"),
                "signal": row.get("signal"),
                "ch": row.get("ch"),
                "sample_rate_ms": int(row.get("sample_rate_ms") or 0) or None,
                "recording_start_s": (
                    float(row["recording_start_s"])
                    if row.get("recording_start_s") not in (None, "") else None
                ),
                "recording_end_s": (
                    float(row["recording_end_s"])
                    if row.get("recording_end_s") not in (None, "") else None
                ),
                "values": _parse_values(row.get("values")),
                "factor": float(row.get("factor") or 1),
                "offset": float(row.get("offset") or 0),
                "signal_def_key": row.get("signal_def_key"),
            })
        return specs

    # Framework fallback
    for key, sd in MAH_CAN_SIGNAL_DEFS.items():
        edr_param = sd.get("EDR_Parameter")
        if not edr_param:
            continue
        values = None
        for k in sd:
            if (
                k.startswith("TestCase_")
                and k.endswith("_values")
                and "Invalid" not in k
                and "OutofRange" not in k
            ):
                v = sd[k]
                if isinstance(v, list) and v:
                    values = list(v)
                    break
        if values is None:
            continue
        specs.append({
            "edr_param": edr_param,
            "frame": sd["frame"],
            "signal": sd["signal"],
            "ch": sd.get("ch"),
            "sample_rate_ms": get_sample_interval_ms(edr_param, default_ms=500),
            "values": values,
            "factor": sd.get("Factor", 1),
            "offset": sd.get("Offset", 0),
            "fault_logic": sd.get("fault_logic", {}),
            "signal_def_key": key,
        })
    return specs


def load_fault_specs(wb, signal_specs, csv_faults_path=None):
    """Return {edr_param: fault_cfg_dict}. Defaults derived from fault_logic."""
    by_param = {s["edr_param"]: s for s in signal_specs}
    rows = _sheet_rows(wb, "Faults") if wb else []
    if not rows and csv_faults_path:
        rows = _csv_rows(csv_faults_path)
    out = {}
    if rows:
        for row in rows:
            ep = row.get("edr_param")
            ftype = row.get("fault_type")
            if not ep or not ftype:
                continue
            ftype_norm = str(ftype).strip().upper()
            if ftype_norm in ("", "NONE"):
                continue
            clear_raw = str(row.get("clear_at_t0") or "").strip().lower()
            out[str(ep).strip()] = {
                "fault_type": ftype_norm,
                "timing": str(row.get("timing") or TIMING_PRE_HALF).strip().upper(),
                "clear_at_t0": clear_raw in ("1", "true", "yes", "y"),
                "fault_default": row.get("fault_default") if row.get("fault_default") not in (None, "") else None,
                "param1": row.get("param1") if row.get("param1") not in (None, "") else None,
                "param2": row.get("param2") if row.get("param2") not in (None, "") else None,
            }
        return out

    # Auto-derive sensible fault from each signal's fault_logic
    for ep, spec in by_param.items():
        sd = MAH_CAN_SIGNAL_DEFS.get(spec.get("signal_def_key") or "", {}) or {}
        fl = sd.get("fault_logic") or {}
        if fl.get("message_content_failure_dtcs"):
            crc_sig = next(
                (k for k in fl["message_content_failure_dtcs"] if "CRC" in str(k).upper()),
                None,
            )
            out[ep] = {
                "fault_type": "MESSAGE_CONTENT_FAIL",
                "timing": TIMING_PRE_HALF,
                "clear_at_t0": False,
                "fault_default": None,
                "param1": crc_sig,
                "param2": None,
            }
        elif fl.get("key_message") and fl.get("message_timeout_dtc"):
            out[ep] = {
                "fault_type": "MESSAGE_TIMEOUT",
                "timing": TIMING_PRE_HALF,
                "clear_at_t0": False,
                "fault_default": None,
                "param1": fl.get("key_message"),
                "param2": None,
            }
    return out


# ---------------------------------------------------------------------------
# Per-signal schedule
# ---------------------------------------------------------------------------

def build_signal_schedule(spec, crash_type, rsu_offsets):
    edr_param = spec["edr_param"]
    sample_interval_ms = spec.get("sample_rate_ms") or get_sample_interval_ms(
        edr_param, default_ms=500
    )
    sample_interval_s = sample_interval_ms / 1000.0

    rec_start = spec.get("recording_start_s")
    rec_end = spec.get("recording_end_s")
    if rec_start is None or rec_end is None:
        time_axis, _ = build_time_axis_and_t0(edr_param, crash_type, rsu_offsets)
    else:
        time_axis = []
        t = rec_start
        while t <= rec_end + 1e-3:
            time_axis.append(round(t, 6))
            t += sample_interval_s

    sim_time_axis = [round(t - sample_interval_s, 6) for t in time_axis]
    values = list(spec["values"])
    if len(values) < len(time_axis):
        values += [values[-1]] * (len(time_axis) - len(values))
    elif len(values) > len(time_axis):
        values = values[: len(time_axis)]

    t0_idx = next((i for i, t in enumerate(time_axis) if abs(t) < 1e-9), len(time_axis) // 2)
    set_points = [(sim_time_axis[i], values[i], i) for i in range(len(time_axis))]
    return {
        "edr_param": edr_param,
        "frame": spec["frame"],
        "signal": spec["signal"],
        "ch": spec.get("ch"),
        "factor": spec.get("factor", 1),
        "offset": spec.get("offset", 0),
        "sample_interval_ms": sample_interval_ms,
        "sample_interval_s": sample_interval_s,
        "time_axis": time_axis,
        "sim_time_axis": sim_time_axis,
        "values": values,
        "set_points": set_points,
        "t0_index": t0_idx,
        "fault_logic": (MAH_CAN_SIGNAL_DEFS.get(spec.get("signal_def_key") or "") or {}).get("fault_logic", {}),
        "signal_def_key": spec.get("signal_def_key"),
    }


# ---------------------------------------------------------------------------
# Fault scheduling
# ---------------------------------------------------------------------------

def resolve_fault_index(schedule, timing):
    n = len(schedule["values"])
    t0 = schedule["t0_index"]
    if timing == TIMING_PRE_SIM:
        return -1
    if timing == TIMING_PRE_HALF:
        return max(0, t0 // 2)
    if timing == TIMING_AT_T0:
        return max(0, t0 - 1)
    if timing == TIMING_POST_HALF:
        return min(n - 1, t0 + max(1, (n - t0) // 2))
    return max(0, t0 // 2)


def induce_fault(schedule, fault_cfg):
    ft = fault_cfg["fault_type"]
    fl = schedule["fault_logic"] or {}
    frame = schedule["frame"]
    signal = schedule["signal"]
    ch = schedule.get("ch")

    if ft == "MESSAGE_TIMEOUT":
        target = fault_cfg.get("param1") or fl.get("key_message") or frame
        CAN.PeriodicDisableFrame(target)
        return ("frame_disabled", target)

    if ft == "NODE_ABSENT":
        target = fault_cfg.get("param1") or fl.get("key_message") or frame
        CAN.PeriodicDisableFrame(target)
        return ("node_absent", target)

    if ft == "MESSAGE_CONTENT_FAIL":
        mcf = (fl.get("message_content_failure_dtcs") or {})
        crc_sig = fault_cfg.get("param1")
        if not crc_sig:
            crc_sig = next((k for k in mcf if "CRC" in str(k).upper()), None)
        if crc_sig and ch is not None:
            CAN.DisableDynamicSigna(ch, frame, crc_sig)
        return ("mcf_crc", crc_sig)

    if ft == "SIGNAL_CONTENT_FAIL":
        invalid = fault_cfg.get("param1")
        if invalid is None:
            invalid = 0xFF
        try:
            invalid_int = int(str(invalid), 0)
        except Exception:
            invalid_int = int(invalid)
        CAN.ChangeSignalValue(frame, signal, str(invalid_int))
        return ("scf", invalid_int)

    if ft == "NEVER_RECEIVED":
        CAN.PeriodicDisableFrame(frame)
        return ("never_received", frame)

    if ft == "BUS_OFF":
        try:
            CAN.SetBusOff(ch)
        except Exception:
            CAN.PeriodicDisableFrame(frame)
        return ("bus_off", ch)

    if ft == "VARIANT_CODE_ERROR":
        return ("variant_code", fault_cfg.get("param1"))

    return (None, None)


def clear_fault(schedule, fault_cfg, induced_info):
    ft = fault_cfg["fault_type"]
    frame = schedule["frame"]
    ch = schedule.get("ch")
    _kind, ref = induced_info or (None, None)

    if ft in ("MESSAGE_TIMEOUT", "NODE_ABSENT", "NEVER_RECEIVED"):
        CAN.ReloadDefaultPeriodicFrame(ref or frame)
    elif ft == "MESSAGE_CONTENT_FAIL" and ref and ch is not None:
        CAN.EnableDynamicSigna(ch, frame, ref)
    elif ft == "BUS_OFF":
        try:
            CAN.ClearBusOff(ch)
        except Exception:
            CAN.ReloadDefaultPeriodicFrame(frame)


# ---------------------------------------------------------------------------
# Master event-loop driver
# ---------------------------------------------------------------------------

def run_master_schedule(schedules, fault_plan, crash_time_s=0.0):
    heap = []
    seq = 0
    for sch in schedules:
        for t_abs, val, idx in sch["set_points"]:
            heapq.heappush(
                heap,
                (t_abs, seq, EVENT_SET_SIGNAL, sch, val, idx, None),
            )
            seq += 1
        fp = fault_plan.get(sch["edr_param"])
        if fp and fp.get("induce_time_s") is not None:
            heapq.heappush(
                heap,
                (fp["induce_time_s"], seq, EVENT_INDUCE_FAULT, sch, None, None, fp["cfg"]),
            )
            seq += 1
        if fp and fp.get("clear_time_s") is not None:
            heapq.heappush(
                heap,
                (fp["clear_time_s"], seq, EVENT_CLEAR_FAULT, sch, None, None, fp["cfg"]),
            )
            seq += 1

    heapq.heappush(heap, (crash_time_s, seq, EVENT_TRIGGER_CRASH, None, None, None, None))

    # Apply PRE_SIM faults BEFORE the wall-clock starts
    induced_info_by_param = {}
    for ep, fp in fault_plan.items():
        if fp.get("timing_resolved") == TIMING_PRE_SIM:
            sch = next(s for s in schedules if s["edr_param"] == ep)
            induced_info_by_param[ep] = induce_fault(sch, fp["cfg"])

    t_start_abs = heap[0][0]
    wall0 = time.perf_counter() - t_start_abs

    while heap:
        t_abs, _, etype, sch, val, idx, cfg = heapq.heappop(heap)
        target_wall = wall0 + t_abs
        remaining = target_wall - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)

        if etype == EVENT_SET_SIGNAL:
            CAN.ChangeSignalValue(sch["frame"], sch["signal"], str(val))
        elif etype == EVENT_INDUCE_FAULT:
            induced_info_by_param[sch["edr_param"]] = induce_fault(sch, cfg)
        elif etype == EVENT_CLEAR_FAULT:
            clear_fault(sch, cfg, induced_info_by_param.get(sch["edr_param"]))
        elif etype == EVENT_TRIGGER_CRASH:
            TriggerCrash()
    return induced_info_by_param


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

def expected_phys_value(raw, edr_def):
    scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
    offset_edr = edr_def.get("offset", 0) if edr_def else 0
    return raw * scaling + offset_edr


def verify_signal(schedule, fault_plan_entry, edr_read, edr_defs_by_name):
    edr_param = schedule["edr_param"]
    values = schedule["values"]
    time_axis = schedule["time_axis"]
    sim_time_axis = schedule["sim_time_axis"]
    sample_interval_s = schedule["sample_interval_s"]
    edr_def = edr_defs_by_name.get(edr_param)
    t0_idx = schedule["t0_index"]

    decoded = []
    if isinstance(edr_read, dict):
        decoded = edr_read.get("decoded", {}).get(edr_param, []) or []

    cfg = fault_plan_entry["cfg"] if fault_plan_entry else None
    fault_idx = fault_plan_entry["fault_idx"] if fault_plan_entry else None
    clear_at_t0 = bool(cfg and cfg.get("clear_at_t0"))
    is_pre_sim = bool(cfg and fault_plan_entry["timing_resolved"] == TIMING_PRE_SIM)
    is_mid = bool(cfg and cfg["fault_type"] in FAULT_MID)
    is_pre = bool(cfg and cfg["fault_type"] in FAULT_PRE)

    latched_raw = values[fault_idx] if (is_mid and fault_idx is not None and fault_idx >= 0) else None
    fault_default = cfg.get("fault_default") if cfg else None

    aria_reports.add_group(
        f"EDR Verification - {edr_param} (fault={cfg['fault_type'] if cfg else 'NONE'})"
    )

    for i, expected_raw in enumerate(values):
        rec_t = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
        sim_t = sim_time_axis[i] if i < len(sim_time_axis) else (rec_t - sample_interval_s)

        if is_pre_sim or (is_pre and not is_mid):
            if fault_default is not None:
                try:
                    fault_default_raw = int(str(fault_default), 0)
                except Exception:
                    fault_default_raw = int(fault_default)
                expected = expected_phys_value(fault_default_raw, edr_def)
                desc = f"fault-default ({cfg['fault_type']})"
            else:
                expected = "<fault_default>"
                desc = f"fault-default unset ({cfg['fault_type']}) -- comparison skipped"
        elif is_mid and fault_idx is not None:
            if i <= fault_idx:
                expected = expected_phys_value(expected_raw, edr_def)
                desc = "actual (before/at fault)"
            elif clear_at_t0 and i > t0_idx:
                expected = expected_phys_value(expected_raw, edr_def)
                desc = "actual (fault cleared at T0)"
            else:
                expected = expected_phys_value(latched_raw, edr_def)
                desc = f"latched ({cfg['fault_type']})"
        else:
            expected = expected_phys_value(expected_raw, edr_def)
            desc = "actual"

        if i >= len(decoded):
            RESULT.LogCustomAction(
                f"{edr_param} Decode",
                f"Missing decoded sample {i}",
                f"Missing decoded sample {i}",
                TestStatus.Failed,
            )
            continue

        RESULT.InterpretEqualResult(
            f"{edr_param} @ {rec_t:g}s (sim {sim_t:g}s -> {rec_t:g}s) [{desc}]",
            str(decoded[i]),
            str(expected),
        )
    aria_reports.close_group()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_test():
    tc_id = "ALL.F"
    tc_desc = (
        "Parallel EDR fault simulation - drives every configured signal at its "
        "own cadence with per-signal faults: MESSAGE_TIMEOUT, NODE_ABSENT, "
        "MESSAGE_CONTENT_FAIL, SIGNAL_CONTENT_FAIL (mid-window, ECU latches "
        "last valid value); VARIANT_CODE_ERROR, NEVER_RECEIVED, BUS_OFF "
        "(induced before simulation starts). Single shared TriggerCrash at T0."
    )

    env_path = os.environ.get("EDR_SIM_XLSX")
    wb = _excel_workbook(env_path)
    csv_signals, csv_faults = _resolve_csv_inputs(env_path)
    signal_specs = load_signal_specs(wb, csv_signals)
    fault_cfgs = load_fault_specs(wb, signal_specs, csv_faults)
    if not signal_specs:
        raise RuntimeError("No signal specs available.")

    edr_params = get_edr_parameters() or []
    edr_defs_by_name = {p["name"]: p for p in edr_params}
    crash_type = "front"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = []
    for spec in signal_specs:
        key = spec.get("signal_def_key")
        if key and key in MAH_CAN_SIGNAL_DEFS:
            can_ids.extend(resolve_can_log_ids([MAH_CAN_SIGNAL_DEFS[key]]))
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=list(set(can_ids)), direct_write=False, tc_desc=tc_desc
    )

    try:
        fault_free_profile_classic_can()
    except Exception:
        pass
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()

    front_dids = list((EDR_DIDS or {}).get(crash_type, []) or [])
    if not front_dids:
        front_dids = [f"{0x455 + (x * 0x6):04X}" for x in range(2)]

    for did in front_dids:
        load_crash_curves(crash_type)

        schedules = [
            build_signal_schedule(spec, crash_type, RSU_T0_OFFSETS)
            for spec in signal_specs
        ]

        # Build per-signal fault plan with absolute induce/clear times
        fault_plan = {}
        for sch in schedules:
            cfg = fault_cfgs.get(sch["edr_param"])
            if not cfg:
                continue
            timing = cfg.get("timing", TIMING_PRE_HALF)
            fault_idx = resolve_fault_index(sch, timing)
            if timing == TIMING_PRE_SIM:
                induce_t = None
            elif fault_idx < 0:
                induce_t = sch["sim_time_axis"][0] - 0.01
            else:
                induce_t = sch["sim_time_axis"][fault_idx] + sch["sample_interval_s"] / 2.0
            clear_t = 0.0 if cfg.get("clear_at_t0") else None
            fault_plan[sch["edr_param"]] = {
                "cfg": cfg,
                "fault_idx": fault_idx,
                "induce_time_s": induce_t,
                "clear_time_s": clear_t,
                "timing_resolved": timing,
            }

        earliest = min(sch["sim_time_axis"][0] for sch in schedules)
        latest = max(sch["time_axis"][-1] for sch in schedules)
        print(f"[Parallel-Faults] {len(schedules)} signals, "
              f"window {earliest:g}..{latest:g}s, did={did}")
        for sch in schedules:
            fp = fault_plan.get(sch["edr_param"])
            print(f"  - {sch['edr_param']}: rate={sch['sample_interval_ms']}ms "
                  f"samples={len(sch['values'])}"
                  + (f" fault={fp['cfg']['fault_type']}@idx{fp['fault_idx']}"
                     f"({fp['timing_resolved']})" if fp else " fault=NONE"))

        aria_reports.add_group(f"Parallel fault simulation of {len(schedules)} signals")
        induced = run_master_schedule(schedules, fault_plan, crash_time_s=0.0)

        Sleep(int(max(0.0, latest) + 2))

        # Aggregate DTC expectations
        dtc_extras = []
        for ep, fp in fault_plan.items():
            ft = fp["cfg"]["fault_type"]
            sch = next(s for s in schedules if s["edr_param"] == ep)
            if ft in ("MESSAGE_TIMEOUT", "NODE_ABSENT", "NEVER_RECEIVED"):
                target = induced.get(ep, (None, None))[1] or sch["frame"]
                try:
                    code = resolve_dtc_for_event("frame_disabled", target)
                    if code:
                        dtc_extras.append(code + " " + DTC_status["DTC_active_WLOFF"])
                except Exception:
                    pass
            elif ft == "MESSAGE_CONTENT_FAIL":
                fl = sch["fault_logic"] or {}
                mcf = fl.get("message_content_failure_dtcs", {}) or {}
                crc_key = induced.get(ep, (None, None))[1]
                if crc_key and crc_key in mcf and mcf[crc_key]:
                    dtc_extras.append(mcf[crc_key] + " " + DTC_status["DTC_active_WLOFF"])
            elif ft == "BUS_OFF":
                try:
                    code = resolve_dtc_for_event("bus_off", sch.get("ch"))
                    if code:
                        dtc_extras.append(code + " " + DTC_status["DTC_active_WLOFF"])
                except Exception:
                    pass

        combined_crash_dtc = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        final_dtc = " ".join([combined_crash_dtc] + dtc_extras)
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + final_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        params = [sch["edr_param"] for sch in schedules]
        edr_read = read_edr_parameters(
            params, did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        for sch in schedules:
            verify_signal(sch, fault_plan.get(sch["edr_param"]), edr_read, edr_defs_by_name)

        # Restore everything per-signal
        for sch in schedules:
            ep = sch["edr_param"]
            fp = fault_plan.get(ep)
            if fp and fp.get("clear_time_s") is None:
                clear_fault(sch, fp["cfg"], induced.get(ep))
            CAN.ChangeSignalValue(sch["frame"], sch["signal"], "0")

    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
