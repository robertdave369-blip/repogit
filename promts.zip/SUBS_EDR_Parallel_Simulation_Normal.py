"""
Parallel multi-signal EDR simulator (NORMAL value recording).

One script that, for every EDR-recorded CAN signal:
  - reads its sample rate, pre/post-crash recording window and value list
  - schedules each value onto the bus one sample-interval before the
    recording timestamp it should be captured at
  - runs all signals together on one shared wall-clock so every signal hits
    its own cadence in parallel (no per-signal threads required)
  - triggers a single global crash at T0
  - reads EDR after the run and compares decoded/raw samples against the
    expected per-signal values

Signal data source priority:
  1. Excel workbook (env var EDR_SIM_XLSX, .xlsx)
  2. CSV file       (env var EDR_SIM_XLSX, .csv -- signals only)
  3. MAH_CAN_SIGNAL_DEFS from the live framework (default)
"""

import csv
import heapq
import os
import sys
import time
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up (matches the modern reference TC 3.1) ─────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (                  # noqa: E402
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance                          # noqa: E402,F401
from apym.reports import ApymReports as aria_reports                           # noqa: E402

# ── Shared libraries ────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT         # noqa: E402
from Framework_IOEM_Py.shared_libraries.can_library import MAH_CAN_SIGNAL_DEFS # noqa: E402
from Framework_IOEM_Py.shared_libraries.configuration_control import (         # noqa: E402
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.core_functions import (                # noqa: E402
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (              # noqa: E402
    get_sample_interval_ms,
    build_time_axis_and_t0,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (        # noqa: E402
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS     # noqa: E402

# ── Project config (DIDs) ───────────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import EDR_DIDS         # noqa: E402


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

EVENT_SET_SIGNAL = 0
EVENT_TRIGGER_CRASH = 1


# ---------------------------------------------------------------------------
# Config loaders
# ---------------------------------------------------------------------------

def _parse_values_field(field):
    if field is None:
        return []
    vals = []
    for tok in str(field).replace(";", ",").split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            vals.append(int(tok, 0))
        except ValueError:
            vals.append(int(float(tok)))
    return vals


def _row_to_signal_spec(row):
    if not row.get("edr_param"):
        return None
    return {
        "edr_param": str(row["edr_param"]).strip(),
        "frame": row.get("frame"),
        "signal": row.get("signal"),
        "ch": row.get("ch"),
        "sample_rate_ms": int(row.get("sample_rate_ms") or 0) or None,
        "recording_start_s": (
            float(row["recording_start_s"])
            if row.get("recording_start_s") not in (None, "") else None
        ),
        "recording_end_s": (
            float(row["recording_end_s"])
            if row.get("recording_end_s") not in (None, "") else None
        ),
        "values": _parse_values_field(row.get("values")),
        "factor": float(row.get("factor") or 1),
        "offset": float(row.get("offset") or 0),
        "signal_def_key": row.get("signal_def_key"),
    }


def _load_from_excel(xlsx_path):
    try:
        import openpyxl
    except ImportError:
        return None
    if not (xlsx_path and os.path.isfile(xlsx_path) and xlsx_path.lower().endswith(".xlsx")):
        return None
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    if "Signals" not in wb.sheetnames:
        return None
    ws = wb["Signals"]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return None
    header = [str(h).strip() for h in rows[0]]
    out = []
    for r in rows[1:]:
        if r is None or all(c is None for c in r):
            continue
        spec = _row_to_signal_spec(dict(zip(header, r)))
        if spec:
            out.append(spec)
    return out or None


def _load_from_csv(csv_path):
    if not (csv_path and os.path.isfile(csv_path) and csv_path.lower().endswith(".csv")):
        return None
    with open(csv_path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        out = []
        for row in reader:
            spec = _row_to_signal_spec(row)
            if spec:
                out.append(spec)
    return out or None


def _load_from_framework():
    out = []
    for key, sd in MAH_CAN_SIGNAL_DEFS.items():
        edr_param = sd.get("EDR_Parameter")
        if not edr_param:
            continue
        values = None
        for k in sd:
            if (
                k.startswith("TestCase_")
                and k.endswith("_values")
                and "Invalid" not in k
                and "OutofRange" not in k
            ):
                v = sd[k]
                if isinstance(v, list) and v:
                    values = list(v)
                    break
        if values is None:
            continue
        out.append({
            "edr_param": edr_param,
            "frame": sd["frame"],
            "signal": sd["signal"],
            "ch": sd.get("ch"),
            "sample_rate_ms": get_sample_interval_ms(edr_param, default_ms=500),
            "values": values,
            "factor": sd.get("Factor", 1),
            "offset": sd.get("Offset", 0),
            "signal_def_key": key,
        })
    return out


def load_signal_specs():
    path = os.environ.get("EDR_SIM_XLSX")
    specs = None
    if path:
        if path.lower().endswith(".xlsx"):
            specs = _load_from_excel(path)
        elif path.lower().endswith(".csv"):
            specs = _load_from_csv(path)
    if not specs:
        specs = _load_from_framework()
    return specs


# ---------------------------------------------------------------------------
# Per-signal schedule
# ---------------------------------------------------------------------------

def build_signal_schedule(spec, crash_type, rsu_offsets):
    edr_param = spec["edr_param"]
    sample_interval_ms = spec.get("sample_rate_ms") or get_sample_interval_ms(
        edr_param, default_ms=500
    )
    sample_interval_s = sample_interval_ms / 1000.0

    rec_start = spec.get("recording_start_s")
    rec_end = spec.get("recording_end_s")
    if rec_start is None or rec_end is None:
        time_axis, _ = build_time_axis_and_t0(edr_param, crash_type, rsu_offsets)
    else:
        time_axis = []
        t = rec_start
        while t <= rec_end + 1e-3:
            time_axis.append(round(t, 6))
            t += sample_interval_s

    sim_time_axis = [round(t - sample_interval_s, 6) for t in time_axis]
    values = list(spec["values"])
    if len(values) < len(time_axis):
        values += [values[-1]] * (len(time_axis) - len(values))
    elif len(values) > len(time_axis):
        values = values[: len(time_axis)]

    set_points = [(sim_time_axis[i], values[i]) for i in range(len(time_axis))]
    return {
        "edr_param": edr_param,
        "frame": spec["frame"],
        "signal": spec["signal"],
        "factor": spec.get("factor", 1),
        "offset": spec.get("offset", 0),
        "sample_interval_ms": sample_interval_ms,
        "sample_interval_s": sample_interval_s,
        "time_axis": time_axis,
        "sim_time_axis": sim_time_axis,
        "values": values,
        "set_points": set_points,
        "signal_def_key": spec.get("signal_def_key"),
    }


# ---------------------------------------------------------------------------
# Master event-loop scheduler (single-thread, real wall-clock)
# ---------------------------------------------------------------------------

def run_master_schedule(schedules, crash_time_s=0.0):
    heap = []
    seq = 0
    for sch in schedules:
        for t_abs, val in sch["set_points"]:
            heapq.heappush(
                heap,
                (t_abs, seq, EVENT_SET_SIGNAL, sch["frame"], sch["signal"], val),
            )
            seq += 1
    heapq.heappush(heap, (crash_time_s, seq, EVENT_TRIGGER_CRASH, None, None, None))

    t_start_abs = heap[0][0]
    wall0 = time.perf_counter() - t_start_abs

    while heap:
        t_abs, _, etype, frame, signal, payload = heapq.heappop(heap)
        target_wall = wall0 + t_abs
        remaining = target_wall - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)

        if etype == EVENT_SET_SIGNAL:
            CAN.ChangeSignalValue(frame, signal, str(payload))
        elif etype == EVENT_TRIGGER_CRASH:
            TriggerCrash()


# ---------------------------------------------------------------------------
# EDR verification
# ---------------------------------------------------------------------------

def verify_signal_against_edr(schedule, edr_read, edr_defs_by_name):
    edr_param = schedule["edr_param"]
    values = schedule["values"]
    time_axis = schedule["time_axis"]
    sim_time_axis = schedule["sim_time_axis"]
    sample_interval_s = schedule["sample_interval_s"]

    edr_def = edr_defs_by_name.get(edr_param)
    scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
    offset_edr = edr_def.get("offset", 0) if edr_def else 0

    decoded_samples = []
    raw_samples = []
    if isinstance(edr_read, dict):
        decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []
        raw_samples = edr_read.get("raw", {}).get(edr_param, []) or []

    aria_reports.add_group(f"EDR Output Verification - {edr_param}")
    for i, expected_raw in enumerate(values):
        rec_t = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
        sim_t = sim_time_axis[i] if i < len(sim_time_axis) else (rec_t - sample_interval_s)
        expected_phys = expected_raw * scaling + offset_edr

        if i >= len(decoded_samples):
            RESULT.LogCustomAction(
                f"{edr_param} Decode",
                f"Missing decoded sample {i}",
                f"Missing decoded sample {i}",
                TestStatus.Failed,
            )
            continue

        RESULT.InterpretEqualResult(
            f"{edr_param} physical recorded at {rec_t:g}s "
            f"(simulated {sim_t:g}s -> {rec_t:g}s)",
            str(decoded_samples[i]),
            str(expected_phys),
        )

        if i < len(raw_samples):
            raw_obs = raw_samples[i]
            try:
                raw_int = (
                    int(raw_obs, 16)
                    if isinstance(raw_obs, str) and raw_obs.lower().startswith("0x")
                    else int(raw_obs)
                )
                raw_norm = f"0x{raw_int:02X}"
            except Exception:
                raw_norm = str(raw_obs).upper()
            RESULT.InterpretEqualResult(
                f"{edr_param} raw recorded at {rec_t:g}s",
                raw_norm,
                f"0x{int(expected_raw):02X}",
            )
    aria_reports.close_group()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_test():
    tc_id = "ALL.1"
    tc_desc = (
        "Parallel EDR simulation - normal value recording for every configured "
        "signal in a single run; each signal is driven at its own sample rate "
        "over its own pre/post-crash window, with one shared TriggerCrash at T0."
    )

    specs = load_signal_specs()
    if not specs:
        raise RuntimeError("No signal specs available (Excel/CSV and framework defs both empty).")

    edr_params = get_edr_parameters() or []
    edr_defs_by_name = {p["name"]: p for p in edr_params}
    crash_type = "front"

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = []
    for spec in specs:
        key = spec.get("signal_def_key")
        if key and key in MAH_CAN_SIGNAL_DEFS:
            can_ids.extend(resolve_can_log_ids([MAH_CAN_SIGNAL_DEFS[key]]))
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=list(set(can_ids)), direct_write=False, tc_desc=tc_desc
    )

    try:
        fault_free_profile_classic_can()
    except Exception:
        pass
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()

    front_dids = list((EDR_DIDS or {}).get(crash_type, []) or [])
    if not front_dids:
        front_dids = [f"{0x455 + (x * 0x6):04X}" for x in range(2)]

    for did in front_dids:
        load_crash_curves(crash_type)

        schedules = [
            build_signal_schedule(spec, crash_type, RSU_T0_OFFSETS) for spec in specs
        ]

        earliest_sim_t = min(sch["sim_time_axis"][0] for sch in schedules)
        latest_rec_t = max(sch["time_axis"][-1] for sch in schedules)
        print(f"[Parallel-Normal] {len(schedules)} signals, "
              f"window {earliest_sim_t:g}s .. {latest_rec_t:g}s, "
              f"crash at T0=0s, did={did}")
        for sch in schedules:
            print(f"  - {sch['edr_param']}: rate={sch['sample_interval_ms']}ms "
                  f"rec=[{sch['time_axis'][0]:g}..{sch['time_axis'][-1]:g}]s "
                  f"samples={len(sch['values'])}")

        aria_reports.add_group(
            f"Parallel simulation of {len(schedules)} signals "
            f"(normal recording, single shared T0)"
        )
        run_master_schedule(schedules, crash_time_s=0.0)

        post_drain = max(0.0, latest_rec_t) + 1.0
        Sleep(int(post_drain))

        combineDTC = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + combineDTC, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        params = [sch["edr_param"] for sch in schedules]
        edr_read = read_edr_parameters(
            params, did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        for sch in schedules:
            verify_signal_against_edr(sch, edr_read, edr_defs_by_name)

    for sch in schedules:
        CAN.ChangeSignalValue(sch["frame"], sch["signal"], "0")
    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
