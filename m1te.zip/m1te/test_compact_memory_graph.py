from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "tools" / "build_compact_memory_graph.py"
SPEC = importlib.util.spec_from_file_location("compact_memory_graph", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
MEMORY_GRAPH = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MEMORY_GRAPH
SPEC.loader.exec_module(MEMORY_GRAPH)


class CompactMemoryGraphTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory(prefix="compact-memory-graph-")
        self.root = Path(self.temp_dir.name)
        (self.root / "shared_libraries").mkdir()
        (self.root / "tools").mkdir()
        (self.root / "projects" / "Demo" / "config").mkdir(parents=True)
        (self.root / ".github" / "skills" / "sample" / "scripts").mkdir(parents=True)
        (self.root / "test_results").mkdir()
        (self.root / "shared_libraries" / "runtime.py").write_text(
            "import json\n__all__ = ['Api']\nclass Api: pass\ndef run(): return json.dumps({})\n",
            encoding="utf-8",
        )
        (self.root / "tools" / "export.py").write_text("from shared_libraries import runtime\ndef export(): return runtime.run()\n", encoding="utf-8")
        (self.root / "projects" / "Demo" / "config" / "can_config.py").write_text("CAN_ID = 1\ndef route(): return CAN_ID\n", encoding="utf-8")
        (self.root / ".github" / "skills" / "sample" / "scripts" / "engine.py").write_text("def validate(): return True\n", encoding="utf-8")
        (self.root / "test_results" / "ignored.py").write_text("def ignored(): pass\n", encoding="utf-8")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_stores_compact_metadata_without_raw_source_and_reuses_hashes(self) -> None:
        first = MEMORY_GRAPH.build_memory_graph(self.root, "memory")
        second = MEMORY_GRAPH.build_memory_graph(self.root, "memory")

        paths = {file["path"] for file in first["files"]}
        self.assertIn("shared_libraries/runtime.py", paths)
        self.assertIn("projects/Demo/config/can_config.py", paths)
        self.assertNotIn("test_results/ignored.py", paths)
        self.assertFalse(first["budget"]["raw_code_stored"])
        self.assertEqual(first["budget"]["semantic_agent_tokens"], 0)
        self.assertGreater(first["budget"]["estimated_raw_tokens"], 0)
        self.assertGreater(first["budget"]["memory_percent_of_raw_token_baseline"], 0)
        self.assertEqual(second["incremental"]["changed_files"], 0)
        self.assertEqual(second["incremental"]["reused_files"], len(second["files"]))
        serialized = json.dumps(second)
        self.assertNotIn("return runtime.run()", serialized)
        self.assertNotIn("def ignored", serialized)

    def test_changed_file_is_reanalyzed_without_reprocessing_unchanged_files(self) -> None:
        MEMORY_GRAPH.build_memory_graph(self.root, "memory")
        target = self.root / "tools" / "export.py"
        target.write_text("from shared_libraries import runtime\ndef export(): return runtime.run()\ndef summary(): return 'ok'\n", encoding="utf-8")

        graph = MEMORY_GRAPH.build_memory_graph(self.root, "memory")

        self.assertEqual(graph["incremental"]["changed_files"], 1)
        self.assertGreater(graph["incremental"]["reused_files"], 0)
        export_file = next(file for file in graph["files"] if file["path"] == "tools/export.py")
        self.assertIn("summary", export_file["exports"])
        report_path = self.root / "memory" / "MEMORY_REPORT.md"
        self.assertTrue(report_path.is_file())


if __name__ == "__main__":
    unittest.main()