from __future__ import annotations

import os
import unittest
from unittest.mock import patch

os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "U171")

from shared_libraries import core_functions


class ReportMetadataTests(unittest.TestCase):
    def test_add_standard_report_info_keeps_identity_and_common_fields(self) -> None:
        recorded: list[tuple[str, str]] = []

        with patch.object(
            core_functions.aria_reports,
            "add_report_info",
            side_effect=lambda label, value: recorded.append((label, value)),
        ), patch.dict(os.environ, {"COMPUTERNAME": "TEST-PC"}, clear=False):
            core_functions.add_standard_report_info(
                tester_name="Tester One",
                test_executor="Executor One",
                author_name="Author One",
            )

        self.assertEqual(
            recorded,
            [
                ("#PC Name:", "TEST-PC"),
                ("#Tester Name:", "Tester One"),
                ("#Test Executor:", "Executor One"),
                ("#Author Name:", "Author One"),
            ],
        )


if __name__ == "__main__":
    unittest.main()