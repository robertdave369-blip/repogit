# Test Artifacts

This folder contains retained non-executable test inputs, generated workbooks,
validation reports, and evidence. Each immediate child folder represents one
feature or deliverable and has its own README with provenance and retention
information. Executable regression tests remain at `tests/test_<feature>.py`.