# M210 IO Control DID Migration Report

## Scope

- Source: `docs/project_documents/M210/Customer Diag Spec/M312_M112_M210_SRS_V2.7_DIAG_RE.xlsx`
- Source SHA-256: `cb164d42d85d3d20fae02d3ba2bba135e07a01745ed1eb53268dbab444aee13d`
- Source locations: `IOControl!C3:S28`, `2nd row occupant Logic!C3:H67`, `3rd row occupant Logic!A2:F18`, `UDS Specification!A76:F76`, and `NRC_22!C24:E24`.
- Safety state: offline update only. No bench-facing script was executed.
- Confidence: High for the mapped DID/subfunction and bit assignments; medium for the exact positive response bytes of F015/F016 because the source delegates detailed request/response tables to an unavailable external UDS specification.

## Verified Backup

- Backup directory: `tests/backups/m210_iocontrol_diag_v2_7_20260812/`
- Manifest: `tests/backups/m210_iocontrol_diag_v2_7_20260812/manifest.json`
- Files copied and hash-verified before edits: 1,086.

## Applied DID Mapping

| Existing cohort | Updated target |
| --- | --- |
| F013 driver seat-belt cases 31-51 | F014, byte 0 bit 0, control state `0x01` |
| F014 passenger seat-belt cases 52-72 | F014, byte 0 bit 1, control state `0x02` |
| F017 second-row RH seat-belt cases 91-110 | F014, byte 0 bit 2, control state `0x04` |
| F018 second-row LH seat-belt cases 128-148 | F014, byte 0 bit 3, control state `0x08` |
| F019 second-row center seat-belt cases 167-188 | F014, byte 0 bit 4, control state `0x10` |
| 0F22 PADI-enable cases 283-294 | F013 |
| F017 second-row RH ODS cases 111-127 | F015, byte 0 bit 0, control state `0x01` |
| F018 second-row LH ODS cases 149-166 | F015, byte 0 bit 1, control state `0x02` |
| F019 second-row center ODS cases 189-206 | F015, byte 0 bit 2, control state `0x04` |
| F024 rollover cases 517-523 | F010, byte 0 bit 6, control state `0x40` |
| 04A7/04A8/04A9/04AA/04AB manual crash packs | F010, byte 0 bits 1/2/3/4/5 |
| NRC cases 524-536 and 539-546 | F010-F016 source DID set; stale unsupported-DID expectations were updated where the source defines support |

The project configuration now contains configuration-driven request and response constants for these forms. Legacy script filenames were retained to avoid breaking existing runner entries and external references; script headers and descriptions describe the new DID behavior.

## Preserved Fields

- Every migrated script retains its original `tc_id`.
- Workbook `Name` values holding `IOControl_Testcase...` and `Verifies` column values were checked against the backup after each migration slice.
- Only `Test Steps.Action` and `Test Steps.Expected result` cell values were changed in the migrated workbooks.

## Excluded Cases And Gaps

- F022 cases 295-454 and F023 cases 455-516 were not mechanically remapped. Their legacy control vectors encode occupant type and status, while F015/F016 expose only documented status bits. Mapping them would lose adult/type semantics.
- F014 OCS cases 73-90 have no replacement DID in the supplied IOControl sheet.
- Third-row F020/F021 cases 207-282 and NRC cases 537-538 remain unchanged. The supplied table marks third-row seat-belt controls unavailable for M110/M310, and M210 applicability is not explicitly provided.
- Test case 172 has no matching automation script in the existing corpus.
- No automation script exists for manual crash test cases 564-598; their test steps were updated, and the missing script coverage remains visible.
- Evidence unavailable: target ECU response trace, target DBC/output contract for F015/F016, and the external request/response table referenced by the source UDS sheet.

## Validation Performed

- `cand_config.py` compiled and imported after each constant addition.
- 176 core scripts, 16 reusable NRC scripts, and 5 final NRC scripts compiled with `py_compile`.
- Migrated workbook Test Case ID and Verifies values were compared with the backup.
- Workbook checks failed if a non-Test-Steps cell value changed.
- Final NRC checks confirmed no legacy F017-F024 or 0F22 payload remained in their updated Test Steps cells.

## Follow-Up Needed

Before bench execution, validate F015/F016 positive responses and output behavior using an approved target ECU route, DBC, and trace. Resolve the excluded vector/type cohorts from an approved M210-specific diagnostic or implementation source.
