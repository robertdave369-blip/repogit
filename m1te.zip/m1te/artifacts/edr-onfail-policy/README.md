# EDR On-Fail Policy Artifacts

This group contains policy JSON used by the offline common EDR CAN-C
specification generator. `edr_onfail_policy.json` is the active policy consumed
by `tests/test_common_edr_canc_specification.py`.

`edr_onfail_policy_alternate.json` is a retained, differently sized historical
variant. Its semantic relationship to the active policy is not yet verified, so
it is preserved rather than merged or deleted. Review it against its generation
inputs before deciding retention. No file in this folder is a bench command.