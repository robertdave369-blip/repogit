# U171/Z121 EDR Record 1 Sensor Data

This group contains the Codebeamer-derived requirement evidence, the generated
offline test-specification workbook, and the workbook validation report for the
U171/Z121 EDR Record 1 sensor-data review.

`tests/test_edr_record1_sensor_data_spec.py` is the owning offline generator
and validation test. The evidence source has requirement status and coverage
limits recorded in the generated validation JSON; these files do not authorize
bench execution. Retain the three files together so the workbook can be traced
to its evidence and validation result.