# U171/M314 CAN-C Preapproval Mapping

This group contains the generated U171/M314 CAN-C preapproval mapping workbook,
its validation result, review notes, and record register. The files are a
single review deliverable and must remain together to preserve traceability.

The content is an offline preapproval artifact. Its validation and review files
describe the available evidence and limitations; it is not a released test
specification or a bench-execution input.

## 2026-09-16 Codebeamer traceability delivery

- Purpose: Map all 489 retained U171 ICE CANC/EDR primary test cases to
  source-verified W616 functional leaves and common U171/Z121
  EDR_Additional references where applicable, after removing user-excluded
  CAN-wakeup and generic-EDR cases.
- Contents: `U171_CANC_U171_codebeamer_all_mapped_import.xlsx` is the
  completed canonical Codebeamer-profile import workbook.
  `U171_CANC_U171_codebeamer_mapping.validation.json` records the case-level
  references, source provenance, validation results, source-status
  limitations, and unresolved contradiction. The older
  `U171_CANC_U171_codebeamer_import.xlsx` remains a prior partial artifact
  because it was open in Excel and was intentionally not overwritten.
- Provenance: The mapping was derived from
  `tests/U171_CANC_U171_preapproval_mapping.xlsx`, W616 hierarchy
  `MAH_EDR-33827780`, common hierarchy `EDR_U171_Z121-37221447`, and the
  returned approved M314/U171 BATT_VOLT and NEAR_CRASH requirements.
- Validation: The user-directed cleanup removed 47 case groups whose primary
  records specify CAN wakeup with hardware ignition off, plus the Near Crash,
  `STS_CRASH`, and `SRS_OPERATION_MODE` generic-EDR cases. All 489 remaining
  primary `Verifies` fields use canonical `[ISSUE:<ID>] - null` syntax; 487
  cases include both W616 functional-leaf and common EDR_Additional
  references, while the remaining two retain the exact source subset
  available. The remaining per-group test-case minor suffixes are consecutive
  after 258 name updates. The import workbook passes the observed
  `Export`/hidden `ChoiceValues` profile and both completed workbooks open in
  native Excel. The post-cleanup artifact audit reported 11 existing baseline
  hygiene findings; neither completed CANC artifact is a finding. No remote
  Codebeamer import was performed.
- Retention: Keep these files with the preapproval mapping. The
  `NOT_CONFIGURED_RECORDS_FF` mapping remains review-gated because its
  all-ones reserved-bit expectation conflicts with common source item
  `37266101`, which states reserved bits default/deconfigure to zero.

## 2026-09-16 Codebeamer project-reference update

- Purpose: Replace the review-only `_Project` value `Common EDR` with the
  user-supplied U171/Z121 scope references while preserving every other field.
- Provenance: Codebeamer tracker `150078379` returned the following active
  items: `34384185` (`SC3_2S_U171-High_High+`), `34371287`
  (`SC3_2S_U171-Low_Mid`), `36546981` (`SC3_2S_Z121_Low`), and `34653404`
  (`SC3_2S_Z121`).
- Contents: Both the review workbook and the all-mapped import workbook now
  contain `[ISSUE:34384185] - null, [ISSUE:34371287] - null,
  [ISSUE:36546981] - null, [ISSUE:34653404] - null` in `_Project` for every
  retained primary case.
- Validation: Exactly 489 `_Project` primary cells changed in each workbook;
  no `Common EDR` `_Project` value remains. Values, styles, data validations,
  comments, mappings, test names, and import profile were otherwise
  preserved. Both workbooks opened in native Excel.
- Retention: Keep this provenance in the validation report with the existing
  CAN-C preapproval artifacts. No remote Codebeamer mutation was performed.