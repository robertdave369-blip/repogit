from __future__ import annotations

import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = (
    REPO_ROOT
    / ".github"
    / "skills"
    / "aria-crash-simulation-xml"
    / "scripts"
    / "generate_crash_simulation_xml.py"
)
SPEC = importlib.util.spec_from_file_location("aria_crash_simulation_xml", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
CRASH_XML = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = CRASH_XML
SPEC.loader.exec_module(CRASH_XML)


class AriaCrashSimulationXmlTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="aria-crash-xml-tests-"))
        self.source_root = self.temp_dir / "curves"
        self.event_dir = self.source_root / "01_Front"
        self.event_dir.mkdir(parents=True)
        self.output_dir = self.temp_dir / "generated"
        self.template_path = self.temp_dir / "reference.xml"
        self.config_path = self.temp_dir / "inversion.json"
        self._write_template()
        self._write_config()

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _write_template(self) -> None:
        self.template_path.write_text(
            """<CrashSimulationSensors>
  <Sensor Type="RSU_CH1" Enable="True">
    <Axis FilePath="reference_LSB_Side A-Pillar Left RSU_Acc_Y_2k.txt" IsInverted="False" />
  </Sensor>
  <Sensor Type="GEN6_XY" Enable="True">
    <Axis FilePath="reference_LSB_Central_Acc_X_2k.txt" IsInverted="True" />
    <Axis FilePath="" IsInverted="False" />
  </Sensor>
  <Sensor Type="PANASONIC" Enable="True">
    <Axis FilePath="Empty" IsInverted="False" />
    <Axis FilePath="Empty" IsInverted="False" />
  </Sensor>
</CrashSimulationSensors>
""",
            encoding="utf-8",
        )

    def _write_config(self) -> None:
        self.config_path.write_text(
            json.dumps(
                {
                    "mappings": [
                        {
                            "Channel": "RSU_CH1",
                            "Signal": "Side A-Pillar Left RSU_Acc_Y",
                            "Inverted": True,
                        },
                        {
                            "Channel": "GEN6_XY",
                            "Axis Index": 1,
                            "Signal": "Central_Acc_X",
                            "Inverted": False,
                        },
                        {
                            "Channel": "GEN6_XY",
                            "Axis Index": 2,
                            "Signal": "Front Door Pressure Left RSU_Pres_None",
                            "Inverted": False,
                        },
                        {
                            "Channel": "PANASONIC",
                            "Axis Index": 1,
                            "Signal": "Panasonic newRSU1_Acc_X",
                            "Inverted": True,
                        },
                    ]
                }
            ),
            encoding="utf-8",
        )

    def _write_curve(self, signal: str) -> Path:
        path = self.event_dir / f"M210_Front_32kmph_LSB_{signal}_2k_15-Jul-2026.txt"
        path.write_text("0\n1\n2\n", encoding="utf-8")
        return path

    def test_generates_template_preserving_xml_with_configured_inversions(self) -> None:
        rsu_curve = self._write_curve("Side A-Pillar Left RSU_Acc_Y")
        gen6_curve = self._write_curve("Central_Acc_X")
        pressure_curve = self._write_curve("Front Door Pressure Left RSU_Pres_None")
        panasonic_curve = self._write_curve("Panasonic RSU1_Acc_X")

        result = CRASH_XML.generate_crash_simulation_xmls(
            template_path=self.template_path,
            source_root=self.source_root,
            output_directory=self.output_dir,
            inversion_config=self.config_path,
            write=True,
        )

        self.assertEqual(result["summary"], {"event_count": 1, "success": 1, "dry_run": 0, "failed": 0, "blocked": 0})
        output_path = self.output_dir / "M210_Front_32kmph.xml"
        self.assertTrue(output_path.is_file())
        root = ET.parse(output_path).getroot()
        sensors = {sensor.get("Type"): sensor for sensor in root.findall("Sensor")}
        self.assertEqual(sensors["RSU_CH1"].find("Axis").get("FilePath"), str(rsu_curve))
        self.assertEqual(sensors["RSU_CH1"].find("Axis").get("IsInverted"), "True")
        gen6_axes = sensors["GEN6_XY"].findall("Axis")
        self.assertEqual(gen6_axes[0].get("FilePath"), str(gen6_curve))
        self.assertEqual(gen6_axes[0].get("IsInverted"), "False")
        self.assertEqual(gen6_axes[1].get("FilePath"), str(pressure_curve))
        panasonic_axes = sensors["PANASONIC"].findall("Axis")
        self.assertEqual(panasonic_axes[0].get("FilePath"), str(panasonic_curve))
        self.assertEqual(panasonic_axes[0].get("IsInverted"), "True")
        self.assertEqual(panasonic_axes[1].get("FilePath"), "Empty")
        report = json.loads((self.output_dir / "crash_xml_generation_report.json").read_text(encoding="utf-8"))
        self.assertEqual(report["events"][0]["signals_mapped"], 4)

    def test_write_mode_requires_project_inversion_configuration(self) -> None:
        self._write_curve("Side A-Pillar Left RSU_Acc_Y")
        self._write_curve("Central_Acc_X")

        result = CRASH_XML.generate_crash_simulation_xmls(
            template_path=self.template_path,
            source_root=self.source_root,
            output_directory=self.output_dir,
            write=True,
        )

        self.assertEqual(result["summary"]["blocked"], 1)
        self.assertFalse((self.output_dir / "M210_Front_32kmph.xml").exists())

    def test_missing_required_curve_fails_without_writing_partial_xml(self) -> None:
        self._write_curve("Side A-Pillar Left RSU_Acc_Y")

        result = CRASH_XML.generate_crash_simulation_xmls(
            template_path=self.template_path,
            source_root=self.source_root,
            output_directory=self.output_dir,
            inversion_config=self.config_path,
            write=True,
        )

        event = result["events"][0]
        self.assertEqual(event["generation_status"], "failed")
        self.assertTrue(event["missing_signals"])
        self.assertFalse((self.output_dir / "M210_Front_32kmph.xml").exists())

    def test_duplicate_signal_files_are_rejected_as_ambiguous(self) -> None:
        self._write_curve("Side A-Pillar Left RSU_Acc_Y")
        duplicate_directory = self.source_root / "02_Front_Copy"
        duplicate_directory.mkdir()
        duplicate_path = duplicate_directory / "M210_Front_32kmph_LSB_Side A-Pillar Left RSU_Acc_Y_2k_copy.txt"
        duplicate_path.write_text("0\n", encoding="utf-8")
        self._write_curve("Central_Acc_X")
        self._write_curve("Front Door Pressure Left RSU_Pres_None")
        self._write_curve("Panasonic RSU1_Acc_X")

        result = CRASH_XML.generate_crash_simulation_xmls(
            template_path=self.template_path,
            source_root=self.source_root,
            output_directory=self.output_dir,
            inversion_config=self.config_path,
            write=False,
        )

        self.assertEqual(result["summary"]["event_count"], 2)
        self.assertIn("failed", {event["generation_status"] for event in result["events"]})


if __name__ == "__main__":
    unittest.main()