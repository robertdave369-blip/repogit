# Veoneer Test Specification Generator Demo

This folder contains a generated legacy-export workbook and its validation JSON
used to demonstrate and regression-check the Veoneer test-specification
generator. It is an offline sample, not an approved customer test
specification and not a bench-execution input.

Validate changes with `tests/test_veoneer_test_spec_generator.py`. Retain the
workbook and validation pair together so the generator output remains
reproducible; record replacements or removals in the test logbook.