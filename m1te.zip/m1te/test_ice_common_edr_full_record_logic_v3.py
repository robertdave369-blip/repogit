"""Create the complete corrected V3 EDR test specification.

The result preserves every legacy and V2 test scenario by name, applies the
target record-logic clarification to their expected results, and adds the
remaining V3 requirement and robustness coverage. It is an offline authoring
artifact only and never connects to a bench or ECU.
"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import copy
from datetime import date
import json
from pathlib import Path
from shutil import copy2
from typing import Any
from zipfile import ZipFile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from test_ice_common_edr_test_spec_design import inspect_source


ROOT = Path(__file__).resolve().parents[1]
LEGACY_TEMPLATE = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "Legacy_EDR"
    / "Legacy_EDR_Spec_Covering Multievent_parallel_ignoff_batt_off_.xlsx"
)
TARGET_RECORD_REFERENCE = Path(
    r"C:\Users\christy.paul\Downloads\edr_requirements\EDR_Record_Logic_Multi_and_Single_Events.md"
)
VERSION_DIRECTORY = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design"
    / "03_Authoring_Versions"
    / "V3_Prioritized_Record_Logic_Review"
    / "Full_Updated_Spec"
)
OUTPUT_WORKBOOK = VERSION_DIRECTORY / "EDR_Full_Updated_Record_Logic_CANWakeup_v3.xlsx"
OUTPUT_REPORT = VERSION_DIRECTORY / "EDR_Full_Updated_Record_Logic_CANWakeup_v3_validation.json"

EXPORT_HEADERS = [
    "Priority",
    "Name",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
]
LEGACY_GROUPS = {
    "SUBS_EDR_MULTI_EVENT",
    "SUBS_EDR_PARALLEL_EVENTS",
    "SUBS_EDR_UNCONFIRMED_EVENT",
    "SUBS_EDR_POWER_CUTOFF",
}
V2_CASE_NAMES = {
    "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_NearCrash_NearCrash",
    "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_NearCrash_DeploymentFront",
    "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_DeploymentFront_NearCrash",
    "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_DeploymentFront_DeploymentRight",
    "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_NearCrash_NearCrash",
    "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_NearCrash_DeploymentRight",
    "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_DeploymentRight_NearCrash",
    "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_DeploymentRight_DeploymentLeft",
    "SUBS_EDR_CANWakeup_ParallelEvent_FrontCrash_LeftCrash_Within500ms",
    "SUBS_EDR_CANWakeup_ParallelEvent_RightCrash_LeftCrash_Within500ms",
    "SUBS_EDR_CANWakeup_ParallelEvent_FrontCrash_RightCrash_Within500ms",
    "SUBS_EDR_CANWakeup_UnconfirmedCrash_OnlyXData",
    "SUBS_EDR_CANWakeup_MultiEvent_WakeupTiming",
}
HIGHLIGHT_YELLOW = "FFF200"
PALE_BLUE = "D9EAF7"
PALE_GREEN = "E2F0D9"
NAVY = "1F4E78"
WHITE = "FFFFFF"
THIN_GRAY = Side(style="thin", color="B7B7B7")
PENDING = "Pending confirmation. Record the observed behavior and do not set pass or fail."


def lines(*items: str) -> str:
    return "\n".join(item for item in items if item)


def event_code(value: Any) -> str:
    text = str(value).strip()
    if not text or text[0] not in {"0", "1"}:
        raise ValueError(f"Unexpected event vector value: {value!r}")
    return text[0]


def find_vector(source_data: dict[str, Any], family: str, pattern: tuple[str, str, str]) -> dict[str, Any]:
    for item in source_data["vectors"]:
        item_pattern = tuple(event_code(item[f"event_{index}"]) for index in (1, 2, 3))
        if item["family"] == family and item_pattern == pattern:
            return item
    raise ValueError(f"Missing {family} vector for pattern {pattern}.")


def validate_target_reference() -> None:
    if not TARGET_RECORD_REFERENCE.is_file():
        raise FileNotFoundError(f"Target record-logic reference is unavailable: {TARGET_RECORD_REFERENCE}")
    text = TARGET_RECORD_REFERENCE.read_text(encoding="utf-8")
    required_anchors = (
        "500 ms < delta_t < 5000 ms",
        "delta_t <= 500 ms",
        "every EDR2 byte, including reserved bytes, is `0xFF`",
        "Front + Left Side",
        "Exactly 5000 ms",
        "Lock status at this observation point is **not specified**",
    )
    missing = [anchor for anchor in required_anchors if anchor not in text]
    if missing:
        raise ValueError(f"Target record-logic reference lacks required anchors: {missing}")


def e2_result(data: dict[str, Any]) -> str:
    return lines(
        f"EDR1 (End E2): {data['after_2_edr1']}",
        f"EDR2 (End E2): {data['after_2_edr2']}",
        f"MultiEvent# EDR1 (E2): {data['after_2_multi_1']}",
        f"MultiEvent# EDR2 (E2): {data['after_2_multi_2']}",
        f"TimeB/W EDR1 (E2): {data['after_2_time_1']}",
        f"TimeB/W EDR2 (E2): {data['after_2_time_2']}",
        f"Lifetime# EDR1 (E2): {data['after_2_lifetime_1']}",
        f"Lifetime# EDR2 (E2): {data['after_2_lifetime_2']}",
        "Record Lock status at End E2 is not evaluated because it is not specified.",
    )


def e3_result(data: dict[str, Any]) -> str:
    return lines(
        f"EDR1 (End E3): {data['after_3_edr1']}",
        f"EDR2 (End E3): {data['after_3_edr2']}",
        f"MultiEvent# EDR1 (E3): {data['after_3_multi_1']}",
        f"MultiEvent# EDR2 (E3): {data['after_3_multi_2']}",
        f"TimeB/W EDR1 (E3): {data['after_3_time_1']}",
        f"TimeB/W EDR2 (E3): {data['after_3_time_2']}",
        f"Lifetime# EDR1 (E3): {data['after_3_lifetime_1']}",
        f"Lifetime# EDR2 (E3): {data['after_3_lifetime_2']}",
        f"Record Lock EDR1 (E3): {data['after_3_lock_1']}",
        f"Record Lock EDR2 (E3): {data['after_3_lock_2']}",
    )


def event_steps(crash_type: str) -> list[tuple[str, str]]:
    if crash_type == "Near Crash":
        return [
            ("Trigger Near Crash and check that no squibs are deployed.", "No squibs are deployed."),
            ("Check crash signals after Near Crash.", "DOOR_UNLOCK=0, STS_CRASH=0, CRASH_LOCATION=0 (Near), SCM_CNT=0, NEAR_CRASH=1."),
            ("Read DTC and check that no new DTC is active for Near Crash.", "No new DTC is active."),
        ]
    if crash_type == "Deployment (Front)":
        return [
            (
                "Trigger Front Crash and check Front Crash squib deployment: Driver Airbag, Passenger Airbag, Passenger PT, Driver PT, Driver Lap PT, Passenger Lap PT, and Driver Knee Airbag.",
                "All listed Front Crash squibs are deployed.",
            ),
            ("Read DTC and check Front Crash and Pretensioner Crash DTCs.", "Crash DTC 90 61 96 8B and Pretensioner Crash DTC 92 1A 00 8B are active."),
            ("Check crash signals after Front Crash.", "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=1 (Front), and SCM_CNT increments while STS_CRASH=1."),
        ]
    if crash_type == "Deployment (Right)":
        return [
            (
                "Trigger Right Crash and check Right Crash squib deployment: Right Side Airbag, Right Curtain Airbag, Right PT, and Right Lap PT.",
                "All listed Right Crash squibs are deployed.",
            ),
            ("Read DTC and check Right Side Crash and Pretensioner Crash DTCs.", "Side Crash DTC 92 01 00 8B and Pretensioner Crash DTC 92 1A 00 8B are active."),
            ("Check crash signals after Right Crash.", "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=3 (Right), and SCM_CNT increments while STS_CRASH=1."),
        ]
    if crash_type == "Deployment (Left)":
        return [
            (
                "Trigger Left Crash and check Left Crash squib deployment: Left Side Airbag, Left Curtain Airbag, Left PT, and Left Lap PT.",
                "All listed Left Crash squibs are deployed.",
            ),
            ("Read DTC and check Left Side Crash and Pretensioner Crash DTCs.", "Side Crash DTC 92 02 00 8B and Pretensioner Crash DTC 92 1B 00 8B are active."),
            ("Check crash signals after Left Crash.", "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=2 (Left), and SCM_CNT increments while STS_CRASH=1."),
        ]
    raise ValueError(f"Unsupported crash type: {crash_type}")


def normal_pre_action() -> str:
    return lines(
        "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
        "2. IGN ON and wait for proveout to complete.",
        "3. Start the required EDR, CAN, sensor, diagnostic, and power evidence capture before the first event.",
    )


def can_wakeup_pre_action() -> str:
    return lines(
        "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
        "2. Turn IGN OFF and wait until the ECU is ready for CAN wakeup.",
        "3. Send valid CAN wakeup and confirm that the ECU wakes while IGN remains OFF.",
        "4. Keep CAN communication available until the required EDR observations are complete.",
    )


def common_post_action() -> str:
    return lines(
        "1. Retain the EDR, CAN, sensor, diagnostic, and power evidence.",
        "2. Restore the approved normal condition.",
        "3. Do not clear locked EDR data or crash DTCs without separate approval.",
    )


def make_case(
    priority: str,
    name: str,
    description: str,
    pre_action: str,
    post_action: str,
    steps: list[tuple[str, str]],
    status: str,
) -> dict[str, Any]:
    return {
        "priority": priority,
        "name": name,
        "description": lines(description, f"Review status: {status}."),
        "pre_action": pre_action,
        "post_action": post_action,
        "steps": steps,
        "status": status,
    }


CRASH_SEQUENCE_TYPES = {
    ("0", "0", "0"): ("Near Crash", "Near Crash", "Near Crash"),
    ("0", "0", "1"): ("Near Crash", "Near Crash", "Deployment (Front)"),
    ("0", "1", "0"): ("Near Crash", "Deployment (Front)", "Near Crash"),
    ("0", "1", "1"): ("Near Crash", "Deployment (Front)", "Deployment (Right)"),
    ("1", "0", "0"): ("Deployment (Front)", "Near Crash", "Near Crash"),
    ("1", "0", "1"): ("Deployment (Front)", "Near Crash", "Deployment (Right)"),
    ("1", "1", "0"): ("Deployment (Front)", "Deployment (Right)", "Near Crash"),
    ("1", "1", "1"): ("Deployment (Front)", "Deployment (Right)", "Deployment (Left)"),
}
LEGACY_MULTI_NAMES = {
    ("0", "0", "0"): "SUBS_EDR_MultiEvent_NearCrash_NearCrash_NearCrash",
    ("0", "0", "1"): "SUBS_EDR_MultiEvent_NearCrash_NearCrash_Deployment",
    ("0", "1", "0"): "SUBS_EDR_MultiEvent_NearCrash_Deployment_NearCrash",
    ("0", "1", "1"): "SUBS_EDR_MultiEvent_NearCrash_Deployment_Deployment",
    ("1", "0", "0"): "SUBS_EDR_MultiEvent_Deployment_NearCrash_NearCrash",
    ("1", "0", "1"): "SUBS_EDR_MultiEvent_Deployment_NearCrash_Deployment",
    ("1", "1", "0"): "SUBS_EDR_MultiEvent_Deployment_Deployment_NearCrash",
    ("1", "1", "1"): "SUBS_EDR_MultiEvent_Deployment_Deployment_Deployment",
}
LEGACY_SINGLE_NAMES = {
    ("0", "0", "0"): "SUBS_EDR_SingleEvent_NearCrash_NearCrash_NearCrash",
    ("0", "0", "1"): "SUBS_EDR_SingleEvent_NearCrash_NearCrash_Deployment",
    ("0", "1", "0"): "SUBS_EDR_SingleEvent_NearCrash_Deployment_NearCrash",
    ("0", "1", "1"): "SUBS_EDR_SingleEvent_NearCrash_Deployment_Deployment",
    ("1", "0", "0"): "SUBS_EDR_SingleEvent_Deployment_NearCrash_NearCrash",
    ("1", "0", "1"): "SUBS_EDR_SingleEvent_Deployment_NearCrash_Deployment",
    ("1", "1", "0"): "SUBS_EDR_SingleEvent_Deployment_Deployment_NearCrash",
    ("1", "1", "1"): "SUBS_EDR_SingleEvent_Deployment_Deployment_Deployment",
}
CAN_WAKEUP_MULTI_NAMES = {
    ("0", "0", "0"): "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_NearCrash_NearCrash",
    ("0", "0", "1"): "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_NearCrash_DeploymentFront",
    ("0", "1", "0"): "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_DeploymentFront_NearCrash",
    ("0", "1", "1"): "SUBS_EDR_CANWakeup_MultiEvent_NearCrash_DeploymentFront_DeploymentRight",
    ("1", "0", "0"): "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_NearCrash_NearCrash",
    ("1", "0", "1"): "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_NearCrash_DeploymentRight",
    ("1", "1", "0"): "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_DeploymentRight_NearCrash",
    ("1", "1", "1"): "SUBS_EDR_CANWakeup_MultiEvent_DeploymentFront_DeploymentRight_DeploymentLeft",
}


def three_event_case(
    name: str,
    family: str,
    pattern: tuple[str, str, str],
    source_data: dict[str, Any],
    can_wakeup: bool = False,
) -> dict[str, Any]:
    data = find_vector(source_data, family, pattern)
    crash_types = CRASH_SEQUENCE_TYPES[pattern]
    timing = "more than 500 ms and less than 5000 ms between consecutive events" if family == "Multi event" else "more than 5000 ms between relevant events"
    description = lines(
        f"Simulate three events in the {family.lower()} timing class.",
        f"Event 1: {crash_types[0]}",
        f"Event 2: {crash_types[1]}",
        f"Event 3: {crash_types[2]}",
        f"Keep {timing}.",
        "Verify EDR data, event numbering, TimeB/W, lifetime number, and End-of-Event-3 lock status. Do not evaluate End-of-Event-2 lock status.",
        "The Event 3 timing reference is recorded as an open review item; retain both inter-event measurements.",
    )
    steps: list[tuple[str, str]] = [
        ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
        (
            "Turn IGN OFF and perform valid CAN wakeup." if can_wakeup else "IGN ON and wait for proveout to complete.",
            "The ECU is ready for the selected event sequence while IGN remains OFF." if can_wakeup else "Proveout completes successfully.",
        ),
    ]
    for event_number, crash_type in enumerate(crash_types, start=1):
        steps.extend(event_steps(crash_type))
        if event_number == 2:
            steps.append(("Read EDR1 and EDR2 after Event 2 and check recorded data and meta-data.", e2_result(data)))
    steps.extend(
        [
            ("Read EDR1 and EDR2 after Event 3 and check recorded data and meta-data.", e3_result(data)),
            ("Read sensor data after Event 3.", "Recorded sensor data match the applied inputs for the retained records."),
        ]
    )
    if can_wakeup:
        steps.append(("Confirm CAN wakeup remains active until EDR readout is complete.", "EDR data are read while the ECU remains awake through CAN wakeup with IGN OFF."))
    return make_case("High", name, description, can_wakeup_pre_action() if can_wakeup else normal_pre_action(), common_post_action(), steps, "IN REVIEW")


def five_near_case(final_type: str, final_delay: str, timing_class: str, bit_mask: str) -> dict[str, Any]:
    suffix = {
        "Deployment (Front)": "DeploymentFront",
        "Deployment (Right)": "DeploymentRight",
        "Deployment (Left)": "DeploymentLeft",
    }[final_type]
    return make_case(
        "Highest",
        f"SUBS_EDR_MultiEvent_5NearCrash_{suffix}_{final_delay.replace(' ', '')}",
        lines(
            "Validate deployable-event retention and replacement behavior after five Near Crash events.",
            "Event 1 through Event 5: Near Crash, with 1000 ms between consecutive Near Crash events.",
            f"Event 6: {final_type}, {final_delay} after Event 5. Applied timing class: {timing_class}.",
            "Every retained Near Crash record is expected to have Record Lock status 0. The final deployment record is expected to have Record Lock status 1 if it is stored.",
            "Record allocation, replacement order, event numbering, and timing fields after the third event are pending confirmation and are recorded without pass/fail.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
            ("Trigger five Near Crash events with 1000 ms between consecutive events.", "No squibs deploy for any Near Crash. DOOR_UNLOCK=0 and STS_CRASH=0 for each Near Crash. Every retained Near Crash record has Record Lock status 0."),
            (f"Trigger {final_type} {final_delay} after Event 5.", f"The final event is classified as {timing_class}. The selected deployment crash input is captured."),
            ("Check final deployment actions, active crash DTCs, and crash notifications.", "The final deployment actions, DTCs, and notifications are captured using the approved crash-type procedure."),
            ("Read full EDR1 and EDR2 data repeatedly after Event 6 and retain all raw evidence.", PENDING),
            ("Check Record 1 crash location/type when the final deployment is stored in Record 1.", f"The Record 1 crash location/type bit for {final_type} is {bit_mask}. Record selection and Record 2 bitfield applicability are pending confirmation."),
        ],
        "ON HOLD",
    )


def parallel_case(
    name: str,
    first_crash: str,
    second_crash: str,
    bit_mask: str,
    dts: str,
    squib_expectation: str,
    can_wakeup: bool = False,
) -> dict[str, Any]:
    mode = "while the ECU is awake through valid CAN wakeup with IGN OFF" if can_wakeup else "with IGN ON after proveout"
    return make_case(
        "High",
        name,
        lines(
            f"Simulate two parallel deployment crashes {mode}.",
            f"First crash: {first_crash}.",
            f"Second crash: {second_crash}.",
            "Apply the second crash within 500 ms of the first crash.",
            "EDR1 retains the first crash record. Every raw EDR2 byte, including reserved bytes, is FF. Do not decode the all-FF EDR2 response as a crash-location/type bitfield.",
            f"The Record 1 crash location/type byte combines both crash types and is {bit_mask}.",
            "Do not evaluate parallel-event record meta-data or lock status because these values are not specified.",
        ),
        can_wakeup_pre_action() if can_wakeup else normal_pre_action(),
        common_post_action(),
        [
            ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
            ("Turn IGN OFF and perform valid CAN wakeup." if can_wakeup else "IGN ON and wait for proveout to complete.", "The ECU is ready for the parallel crash input."),
            (f"Trigger {first_crash}, then {second_crash}, with the second crash within 500 ms.", "Both crash inputs are captured. The first crash ordering is retained."),
            ("Read full raw EDR1 and EDR2 data after the parallel pair.", f"EDR1 retains the first crash record. Every raw EDR2 byte, including reserved bytes, is FF."),
            ("Check the Record 1 crash location/type byte.", f"Record 1 crash location/type byte is {bit_mask}."),
            ("Check deployed squibs and active crash DTCs.", lines(squib_expectation, dts)),
            ("Check crash notifications.", "DOOR_UNLOCK=1 and STS_CRASH=1. The output representation is captured without applying an unsupported priority enum."),
        ],
        "IN REVIEW",
    )


def completion_battery_available_case() -> dict[str, Any]:
    return make_case(
        "Highest",
        "SUBS_EDR_CompletionStatus_BatteryAvailable",
        lines(
            "Verify completion status and data-validity behavior for a Front deployment while battery power remains available.",
            "Observe at 199 ms, 200 ms, 201 ms, 4.999 s, 5.000 s, and 5.001 s after T0.",
            "The 200 ms completion flag is expected to be 1 after 200 ms. CompletionStatus is expected to be 1 after five seconds when battery power is available.",
            "Exact behavior at 200 ms and exactly 5.000 s is characterized only until timing tolerance is confirmed.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Trigger Front Crash and retain the T0 timestamp and battery waveform.", "Front Crash deployment is captured. Battery remains available."),
            ("Observe the 200 ms completion flag at 199 ms, 200 ms, and 201 ms after T0.", "At 201 ms, the 200 ms completion flag is 1. Exact behavior at 199 ms and 200 ms is retained for timing review."),
            ("Observe CompletionStatus at 4.999 s, 5.000 s, and 5.001 s after T0.", "At 5.001 s, CompletionStatus is 1 and EDR data are valid. Exact behavior at 4.999 s and 5.000 s is retained for timing review."),
            ("Read EDR data and completion flags after the five-second observation.", "CompletionStatus=1. The 200 ms completion flag is don't care. EDR data are valid."),
            ("Check Record 1 crash location/type when Front Crash is stored in Record 1.", "Record 1 Front crash location/type bit is 0x01."),
        ],
        "IN REVIEW",
    )


def legacy_ign_off_case() -> dict[str, Any]:
    return make_case(
        "Highest",
        "SUBS_EDR_Crash_IGN_Off_50ms",
        lines(
            "Verify a Front deployment when IGN is turned OFF 50 ms after the crash while battery power remains available and CAN wakeup keeps the ECU awake.",
            "At more than 200 ms and before five seconds, the expected status combination is CompletionStatus=0 and 200 ms CompletionStatus=1; EDR data are valid through 200 ms.",
            "At more than five seconds with battery power available, CompletionStatus=1 and EDR data are valid.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Trigger Front Crash and check Front Crash deployment actions.", "All selected Front Crash deployment actions are captured."),
            ("Wait 50 ms after the crash, turn IGN OFF, and keep battery power and valid CAN wakeup available.", "IGN is OFF 50 ms after the crash and the ECU remains awake through CAN wakeup."),
            ("Read completion flags after the initial 200 ms data period and before five seconds.", "CompletionStatus=0, 200 ms CompletionStatus=1, and EDR data are valid through 200 ms."),
            ("Keep battery power available through more than five seconds after T0 and read the completion flags again.", "CompletionStatus=1 and EDR data are valid."),
            ("Read EDR data and retain power, CAN, and crash evidence.", "Record write order and recovery behavior beyond the stated completion flags are retained for review."),
        ],
        "IN REVIEW",
    )


def legacy_batt_off_case() -> dict[str, Any]:
    return make_case(
        "Highest",
        "SUBS_EDR_Crash_BATT_Off_50ms",
        lines(
            "Verify data-validity status when battery power is disconnected 50 ms after a Front deployment.",
            "The battery interruption occurs before completion of the initial 200 ms data period.",
            "After recovery, CompletionStatus=0 and 200 ms CompletionStatus=0. EDR data are not valid.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Trigger Front Crash and check Front Crash deployment actions.", "All selected Front Crash deployment actions are captured."),
            ("Wait 50 ms after the crash and turn battery power OFF.", "Battery power is removed 50 ms after the crash."),
            ("Restore battery power using the approved procedure and wait for initialization.", "The system initializes and the recovery evidence is retained."),
            ("Read EDR data and completion flags after recovery.", "CompletionStatus=0, 200 ms CompletionStatus=0, and EDR data are not valid."),
            ("Check that no unsupported payload, CRC, valid-marker, or record-allocation assumption is used to judge this case.", "Only the stated completion/data-validity rule is judged. Other recovery behavior is retained for review."),
        ],
        "IN REVIEW",
    )


def default_data_case() -> dict[str, Any]:
    return make_case(
        "High",
        "SUBS_EDR_DefaultData_NoEvent",
        "Verify the EDR no-event condition.",
        normal_pre_action(),
        common_post_action(),
        [
            ("Confirm that no EDR event is stored.", "No EDR event is present before readout."),
            ("Read all implemented EDR data records three times without creating an event.", "All three readouts are retained."),
            ("Compare every returned data byte, including reserved bytes, across the three readouts.", "Every returned EDR data byte, including reserved bytes, is FF. All three readouts are identical."),
            ("Check that no stale data from a previous record is present.", "No stale, zero, or mixed data byte is present."),
            ("Restore the approved normal condition.", "The no-event baseline remains valid."),
        ],
        "IN REVIEW",
    )


def side_without_srsu_case() -> dict[str, Any]:
    return make_case(
        "High",
        "SUBS_EDR_SideEvent_WithoutSRSU_LowMid",
        lines(
            "Verify that Domestic Low and Domestic Mid configurations without side remote sensors do not store a side event.",
            "Run two vectors: Low configuration without side remote sensors and Mid configuration without side remote sensors.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Select the Low or Mid configuration vector and confirm the selected configuration.", "The selected configuration is recorded before side-event input."),
            ("Apply the approved non-destructive side-event input.", "The side-event input is captured."),
            ("Read EDR data after the required observation interval.", "No side-event EDR record is stored for the selected configuration."),
            ("Repeat for the other configuration vector.", "Both Low and Mid configurations are covered."),
            ("Record unrelated output observations separately.", "Door-unlock and other unrelated functions are not judged by this test case."),
        ],
        "IN REVIEW",
    )


def near_crash_case() -> dict[str, Any]:
    return make_case(
        "High",
        "SUBS_EDR_NearCrash_UnlockedRecord",
        "Verify Near Crash recording, record unlocking, and suppression of crash and door-unlock notifications.",
        normal_pre_action(),
        common_post_action(),
        [
            ("Apply a non-deployment Near Crash input.", "The input remains below the deployable threshold."),
            ("Check deployed squibs, DTCs, and crash signals.", "No squibs are deployed, no new DTC is active, DOOR_UNLOCK=0, STS_CRASH=0, CRASH_LOCATION=0 (Near), SCM_CNT=0, and NEAR_CRASH=1."),
            ("Read the retained Near Crash record.", "A Near Crash record is stored."),
            ("Check Record Lock status for the retained Near Crash record.", "Record Lock status is 0."),
            ("Retain the EDR and CAN evidence.", "The Near Crash record is available for review without an unsupported record-slot assumption."),
        ],
        "IN REVIEW",
    )


def unconfirmed_ign_off_case() -> dict[str, Any]:
    return make_case(
        "High",
        "SUBS_EDR_UnconfirmedCrash_OnlyXData_IGN_Off",
        lines(
            "Characterize an Unconfirmed Crash after IGN OFF using onboard longitudinal input only and both front remote sensor values at zero.",
            "The classification result is defined. EDR record, DTC, notification, and sensor-data outcomes are retained as observations because they are not defined.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Turn IGN OFF and load onboard longitudinal input only. Set both front remote sensor values to zero.", "Only longitudinal input is present and both front remote sensor values are zero."),
            ("Trigger the event-classification evaluation.", "The event is classified as Unconfirmed Crash."),
            ("Turn IGN ON and wait for proveout to complete.", "The system restarts and stabilizes."),
            ("Read EDR data, DTCs, crash signals, and sensor data.", PENDING),
            ("Retain all observations without assigning pass or fail to the undefined downstream behavior.", "The Unconfirmed Crash classification evidence is available for review."),
        ],
        "ON HOLD",
    )


def bitfield_case() -> dict[str, Any]:
    return make_case(
        "High",
        "SUBS_EDR_Record1_CrashLocationType_Bitfield",
        lines(
            "Verify supplied Record 1 crash location/type bit masks for supported crash types and supported parallel combinations.",
            "Single-type masks: Front=0x01; Left Side=0x02; Right Side=0x04; Rear=0x08; Understrike=0x10; Rollover=0x20; Near=0x40.",
            "Parallel masks: Front plus Left Side=0x03; Right Side plus Left Side=0x06; Front plus Right Side=0x05.",
            "Do not decode an all-FF Record 2 response as a crash location/type bitfield. Do not use bit 7 because no meaning is defined.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Select a supported crash-type or parallel-crash vector.", "The selected physical crash combination is recorded."),
            ("Trigger the selected crash type or supported parallel pair.", "The crash input(s) are captured."),
            ("Read the Record 1 crash location/type byte.", "The byte matches the selected one-bit or supported combined mask."),
            ("For a parallel pair, read full raw Record 2 data.", "Every Record 2 byte is FF and is not decoded as a bitfield."),
            ("Record unsupported crash combinations as not executed.", "Only supported physical combinations receive a pass/fail result."),
        ],
        "IN REVIEW",
    )


def generic_case(
    priority: str,
    name: str,
    description: str,
    setup: str,
    trigger: str,
    verification: str,
    expected: str,
    status: str = "ON HOLD",
) -> dict[str, Any]:
    return make_case(
        priority,
        name,
        description,
        normal_pre_action(),
        common_post_action(),
        [
            ("Select and record the required vector.", "The selected condition, timing, configuration, and measurement method are recorded."),
            (setup, "The required precondition is established."),
            (trigger, "The selected event, fault, state, or read condition is captured."),
            (verification, expected),
            ("Retain the raw evidence and restore the approved normal condition.", "The observation is available for review without converting an undefined outcome into a pass/fail result."),
        ],
        status,
    )


def can_wakeup_unconfirmed_case() -> dict[str, Any]:
    return make_case(
        "Normal",
        "SUBS_EDR_CANWakeup_UnconfirmedCrash_OnlyXData",
        lines(
            "Characterize an Unconfirmed Crash while the ECU is awake through valid CAN wakeup with IGN OFF.",
            "Provide onboard longitudinal input only and set both front remote sensor values to zero.",
        ),
        can_wakeup_pre_action(),
        common_post_action(),
        [
            ("Load onboard longitudinal input only and set both front remote sensor values to zero.", "Only longitudinal input is present and both front remote sensor values are zero."),
            ("Trigger the Unconfirmed Crash evaluation while CAN wakeup remains active.", "The event is classified as Unconfirmed Crash."),
            ("Read EDR data, DTCs, crash signals, and sensor data.", PENDING),
            ("Retain CAN wakeup and classification evidence.", PENDING),
            ("Restore the approved normal condition.", "The result remains pending confirmation for downstream behavior."),
        ],
        "ON HOLD",
    )


def can_wakeup_timing_case() -> dict[str, Any]:
    return make_case(
        "Normal",
        "SUBS_EDR_CANWakeup_MultiEvent_WakeupTiming",
        lines(
            "Characterize CAN wakeup timing around a Near Crash, Front deployment, and Right deployment sequence with IGN OFF.",
            "Run four vectors: CAN wakeup before Event 1; at Event 1; after Event 1 before Event 2; and after Event 2 before Event 3.",
            "Keep more than 500 ms and less than 5000 ms between consecutive events.",
        ),
        can_wakeup_pre_action(),
        common_post_action(),
        [
            ("Select one CAN wakeup timing vector and record the timing reference.", "The selected wakeup timing is recorded."),
            ("Apply valid CAN wakeup at the selected timing point while IGN remains OFF.", "CAN wakeup timing is captured relative to the event sequence."),
            ("Apply Event 1 Near Crash, Event 2 Deployment (Front), and Event 3 Deployment (Right).", "All event timestamps and CAN wakeup timing are retained."),
            ("Read EDR1, EDR2, crash signals, DTCs, and event meta-data after Event 2 and Event 3.", PENDING),
            ("Retain the wakeup and event timing evidence.", "The result remains pending confirmation until CAN wakeup timing behavior is defined."),
        ],
        "ON HOLD",
    )


def build_full_groups(source_data: dict[str, Any]) -> list[tuple[str, list[dict[str, Any]]]]:
    multi_patterns = tuple(CRASH_SEQUENCE_TYPES)
    single_patterns = tuple(CRASH_SEQUENCE_TYPES)

    regular_multi = {pattern: three_event_case(LEGACY_MULTI_NAMES[pattern], "Multi event", pattern, source_data) for pattern in multi_patterns}
    regular_single = {pattern: three_event_case(LEGACY_SINGLE_NAMES[pattern], "Single event", pattern, source_data) for pattern in single_patterns}
    can_multi = {pattern: three_event_case(CAN_WAKEUP_MULTI_NAMES[pattern], "Multi event", pattern, source_data, can_wakeup=True) for pattern in multi_patterns}

    five_near_cases = [
        five_near_case("Deployment (Front)", "501 ms", "Multi Event", "0x01"),
        five_near_case("Deployment (Right)", "800 ms", "Multi Event", "0x04"),
        five_near_case("Deployment (Left)", "4999 ms", "Multi Event", "0x02"),
        five_near_case("Deployment (Front)", "5001 ms", "Single Event", "0x01"),
    ]
    parallel_cases = [
        parallel_case(
            "SUBS_EDR_ParallelEvent_FrontCrash_LeftCrash_Within500ms",
            "Front Crash", "Left Crash", "0x03",
            "Crash DTC 90 61 96 8B and Side Crash DTC 92 02 00 8B are active.",
            "All Front Crash squibs and all Left Crash squibs are deployed.",
        ),
        parallel_case(
            "SUBS_EDR_ParallelEvent_RightCrash_LeftCrash_Within500ms",
            "Right Crash", "Left Crash", "0x06",
            "Side Crash DTC 92 01 00 8B and Side Crash DTC 92 02 00 8B are active.",
            "All Right Crash squibs and all Left Crash squibs are deployed.",
        ),
        parallel_case(
            "SUBS_EDR_ParallelEvent_FrontCrash_RightCrash_Within500ms",
            "Front Crash", "Right Crash", "0x05",
            "Crash DTC 90 61 96 8B and Side Crash DTC 92 01 00 8B are active.",
            "All Front Crash squibs and all Right Crash squibs are deployed.",
        ),
        parallel_case(
            "SUBS_EDR_CANWakeup_ParallelEvent_FrontCrash_LeftCrash_Within500ms",
            "Front Crash", "Left Crash", "0x03",
            "Crash DTC 90 61 96 8B and Side Crash DTC 92 02 00 8B are active.",
            "All Front Crash squibs and all Left Crash squibs are deployed.",
            can_wakeup=True,
        ),
        parallel_case(
            "SUBS_EDR_CANWakeup_ParallelEvent_RightCrash_LeftCrash_Within500ms",
            "Right Crash", "Left Crash", "0x06",
            "Side Crash DTC 92 01 00 8B and Side Crash DTC 92 02 00 8B are active.",
            "All Right Crash squibs and all Left Crash squibs are deployed.",
            can_wakeup=True,
        ),
        parallel_case(
            "SUBS_EDR_CANWakeup_ParallelEvent_FrontCrash_RightCrash_Within500ms",
            "Front Crash", "Right Crash", "0x05",
            "Crash DTC 90 61 96 8B and Side Crash DTC 92 01 00 8B are active.",
            "All Front Crash squibs and all Right Crash squibs are deployed.",
            can_wakeup=True,
        ),
    ]

    remaining_event_numbering_patterns = (("1", "0", "0"), ("1", "0", "1"))
    record_lock_patterns = (("0", "0", "0"), ("0", "0", "1"), ("0", "1", "0"), ("1", "1", "1"))
    remaining_can_patterns = (("0", "0", "0"), ("0", "0", "1"), ("0", "1", "0"), ("1", "0", "0"), ("1", "0", "1"), ("1", "1", "1"))

    power_interruption = generic_case(
        "High",
        "SUBS_EDR_PowerInterruption_AtomicityRecovery",
        lines(
            "Characterize EDR integrity and recovery for power interruption during every significant recording phase.",
            "Cover before T0; exactly at T0; T0+1 ms; T0+199 ms; T0+200 ms; T0+201 ms; before/during/after CompletionStatus update; pre-crash buffer freeze; allocation; metadata; payload; CRC; valid marker; lock bit; lifetime counter; multi-event counter; replacement/erase; EDR readout; shutdown; second event; and fourth/fifth event.",
            "Cover hard battery disconnect, IGN OFF with battery retained, battery loss, ground interruption, brownout, slow ramp-down, fast drop, voltage oscillation, short/repeated interruption, restoration during write, reverse IGN/battery order, and CAN-supply loss.",
        ),
        "Establish the selected event, record, power, and timing state.",
        "Apply the selected interruption only through an approved procedure, restore power, initialize, read EDR data three times, and where permitted apply a recovery cycle.",
        "Check for mixed metadata/payload, partial erase, incorrect lock/valid order, counter loss/double increment, locked-data change, and inability to record the next valid event.",
        PENDING,
    )
    corrupted_incomplete = generic_case(
        "High",
        "SUBS_EDR_CorruptedIncompleteData_Recovery",
        lines(
            "Characterize recovery from corrupted or incomplete EDR data.",
            "Cover EDR1 integrity failure, EDR2 integrity failure, missing valid marker, interrupted payload, interrupted replacement/erase, and counter metadata inconsistent with payload.",
        ),
        "Establish the selected corrupted or incomplete data state only through an approved method.",
        "Initialize, read EDR1 and EDR2 three times, and apply one later valid event where authorized.",
        "Check data integrity, lock preservation, event association, and recovery of future recording.",
        PENDING,
    )
    extended_multi = generic_case(
        "Normal",
        "SUBS_EDR_ExtendedMultiEvent_Sequence",
        lines(
            "Exercise extended sequences beyond three events without duplicating the five-Near-Crash priority cases.",
            "Cover four-event, five-event, ten-event, configurable N-event, repeated Near Crash, and mixed Unconfirmed Crash/Near Crash/Deployment Event sequences.",
            "For multi-event vectors, keep more than 500 ms and less than 5000 ms between consecutive events. Record allocation and counters after the third event are pending confirmation.",
        ),
        "Establish the selected event count, crash types, timing, and initial record state.",
        "Apply the complete sequence while retaining every event timestamp and all CAN, EDR, and diagnostic evidence.",
        "Read after selected checkpoints and minimize any unexpected sequence to the smallest reproducible prefix.",
        PENDING,
    )
    can_loss_recovery = generic_case(
        "Normal",
        "SUBS_EDR_CANWakeup_MultiEvent_LossRecovery",
        lines(
            "Characterize CAN loss and recovery during a CAN-wakeup multi-event sequence with IGN OFF.",
            "Sequence: Event 1 Near Crash, Event 2 Deployment (Front), Event 3 Deployment (Right). Keep more than 500 ms and less than 5000 ms between consecutive events.",
            "Run CAN-loss vectors before Event 2, during Event 2, after Event 2 before Event 3, and recovery before EDR readout.",
        ),
        "Wake the ECU through valid CAN with IGN OFF, then establish Event 1 Near Crash.",
        "Apply the selected CAN-loss/recovery timing while completing the three-event sequence.",
        "Read EDR, crash signals, and diagnostic evidence after Event 2 and Event 3 and compare data age/validity only to confirmed behavior.",
        PENDING,
    )
    can_quality = generic_case(
        "Normal",
        "SUBS_EDR_CANDataQuality_OnFail",
        lines(
            "Characterize recorded CAN data quality and failure behavior for EDR events.",
            "Cover valid range; missing, delayed, jittered, wrong-cycle-time, duplicate, and out-of-order frames; rolling-counter error; CRC error; raw overflow; invalid enum; multiplexer error; timeout; stuck value; unavailable signal; fail-safe value; sample-point change; cross-signal consistency; bus-off/recovery; and CAN-supply loss.",
        ),
        "Identify the exact signal, frame, valid-value range, timing, failure reaction, and expected recorded representation before execution.",
        "Apply the selected CAN condition around the EDR event and capture CAN timestamps.",
        "Read and decode EDR data and compare value, scaling, range, age, failure reaction, and cross-signal consistency with confirmed behavior.",
        PENDING,
    )
    diagnostic = generic_case(
        "Normal",
        "SUBS_EDR_DiagnosticConsistency_DataIntegrity",
        lines(
            "Characterize EDR diagnostic read consistency and data integrity.",
            "Cover read during capture; read during write/recovery; repeated/concurrent reads; reset during read; invalid data identifier/request length/access condition; and record association/endian/stale-data/mixed-record checks.",
        ),
        "Establish the selected EDR capture, write, reset, or concurrent-read state and confirm diagnostic access behavior.",
        "Send the selected confirmed diagnostic request sequence and capture raw request/response timing.",
        "Check response consistency, record association, stale-data absence, mixed-record absence, access behavior, and error behavior.",
        PENDING,
    )
    timing_boundaries = make_case(
        "Normal",
        "SUBS_EDR_TimingBoundary_ParallelMultiSingle",
        lines(
            "Verify timing classification boundaries after all higher-priority retention, completion, numbering, locking, power, and robustness cases.",
            "Parallel: 0 ms, 1 ms, and 500 ms. For 1 ms and 500 ms, EDR1 retains the known first crash and every raw EDR2 byte is FF. At 0 ms, record EDR2=FF but do not assert first-crash ordering without a tie-break rule.",
            "Multi Event: 501 ms, 800 ms, 801 ms, and 4999 ms. Use the multi-event allocation fields and do not evaluate End-of-Event-2 lock status.",
            "Exactly 5000 ms is characterization only. Single Event: 5001 ms. Use the single-event allocation fields and do not evaluate End-of-Event-2 lock status.",
        ),
        normal_pre_action(),
        common_post_action(),
        [
            ("Select one timing-boundary vector and record the timing measurement uncertainty.", "The selected separation and timing evidence are recorded."),
            ("Apply the selected two-event or three-event sequence at the exact boundary.", "Every event timestamp is retained."),
            ("For 0 ms, 1 ms, and 500 ms, read full raw EDR1 and EDR2 data after the parallel pair.", "Every raw EDR2 byte, including reserved bytes, is FF. At 1 ms and 500 ms, EDR1 retains the first crash. At 0 ms, first-record ordering is recorded only."),
            ("For 501 ms, 800 ms, 801 ms, and 4999 ms, read the End-of-Event-2 fields for the selected multi-event vector.", "EDR1=Event 1, EDR2=Event 2, MultiEvent#=1/2, TimeB/W=0xFFFF/<5s, and Lifetime#=1/2. End-of-Event-2 lock status is not evaluated."),
            ("For exactly 5000 ms, record the observed EDR behavior without assigning pass or fail.", PENDING),
            ("For 5001 ms, read the End-of-Event-2 fields for the selected single-event vector.", "EDR1=Event 1, EDR2=Event 2, MultiEvent#=1/1, TimeB/W=0xFFFF/0xFFFF, and Lifetime#=1/2. End-of-Event-2 lock status is not evaluated."),
        ],
        "ON HOLD",
    )

    return [
        (
            "SUBS_EDR_DEPLOYABLE_VS_NEAR_REPLACEMENT",
            five_near_cases,
        ),
        (
            "SUBS_EDR_NC_D_D",
            [regular_multi[("0", "1", "1")], can_multi[("0", "1", "1")]],
        ),
        (
            "SUBS_EDR_D_D_NC",
            [regular_multi[("1", "1", "0")], can_multi[("1", "1", "0")]],
        ),
        (
            "SUBS_EDR_BATTERY_DISCONNECT",
            [legacy_ign_off_case(), legacy_batt_off_case(), completion_battery_available_case()],
        ),
        (
            "SUBS_EDR_INDEPENDENT_EVENT_VALIDATION",
            [default_data_case(), side_without_srsu_case(), near_crash_case(), unconfirmed_ign_off_case(), bitfield_case()],
        ),
        (
            "SUBS_EDR_EVENT_NUMBERING_VALIDATION",
            [regular_single[pattern] for pattern in single_patterns]
            + [regular_multi[pattern] for pattern in remaining_event_numbering_patterns]
            + [can_multi[pattern] for pattern in remaining_can_patterns],
        ),
        (
            "SUBS_EDR_RECORD_LOCKING_VALIDATION",
            [regular_multi[pattern] for pattern in record_lock_patterns],
        ),
        (
            "SUBS_EDR_POWER_INTERRUPTION_SCENARIOS",
            [power_interruption],
        ),
        (
            "SUBS_EDR_CORRUPTED_INCOMPLETE_DATA",
            [corrupted_incomplete],
        ),
        (
            "SUBS_EDR_EXTENDED_MULTI_EVENT",
            [extended_multi],
        ),
        (
            "SUBS_EDR_REMAINING_ROBUSTNESS_NEGATIVE",
            parallel_cases + [can_wakeup_unconfirmed_case(), can_wakeup_timing_case(), can_loss_recovery, can_quality, diagnostic],
        ),
        (
            "SUBS_EDR_TIMING_BOUNDARIES",
            [timing_boundaries],
        ),
    ]


def apply_style(cell: Any) -> None:
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)


def append_row(sheet: Any, values: list[Any], styles: list[Any], height: float) -> int:
    row_number = sheet.max_row + 1
    for column_number, value in enumerate(values, start=1):
        cell = sheet.cell(row_number, column_number, value)
        cell._style = copy(styles[column_number - 1])
        apply_style(cell)
    sheet.row_dimensions[row_number].height = height
    return row_number


def write_export(workbook: Any, groups: list[tuple[str, list[dict[str, Any]]]]) -> list[str]:
    sheet = workbook["Export"]
    headers = [sheet.cell(1, column_number).value for column_number in range(1, 8)]
    if headers != EXPORT_HEADERS:
        raise ValueError("The legacy Export layout does not contain the expected headers.")
    group_styles = [copy(sheet.cell(2, column_number)._style) for column_number in range(1, 8)]
    primary_styles = [copy(sheet.cell(3, column_number)._style) for column_number in range(1, 8)]
    continuation_styles = [copy(sheet.cell(4, column_number)._style) for column_number in range(1, 8)]
    if sheet.max_row > 1:
        sheet.delete_rows(2, sheet.max_row - 1)
    names: list[str] = []
    for group_name, cases in groups:
        append_row(sheet, ["Normal", group_name, None, None, None, None, None], group_styles, 24)
        for case in cases:
            names.append(case["name"])
            first_action, first_expected = case["steps"][0]
            case_row = append_row(
                sheet,
                [case["priority"], case["name"], case["description"], case["pre_action"], case["post_action"], first_action, first_expected],
                primary_styles,
                min(500, max(145, 15 * (9 + len(case["description"]) // 145))),
            )
            name_cell = sheet.cell(case_row, 2)
            name_cell.fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
            name_cell.font = Font(bold=True, color="000000")
            for action, expected in case["steps"][1:]:
                continuation_row = append_row(sheet, [None, None, None, None, None, action, expected], continuation_styles, 68)
                if action.startswith("Turn IGN OFF") or action.startswith("Apply valid CAN wakeup"):
                    for column_number in range(6, 8):
                        sheet.cell(continuation_row, column_number).fill = PatternFill("solid", fgColor=PALE_BLUE)
                if expected == PENDING:
                    for column_number in range(6, 8):
                        sheet.cell(continuation_row, column_number).fill = PatternFill("solid", fgColor=PALE_GREEN)
    for column_number in range(1, 8):
        header = sheet.cell(1, column_number)
        header.fill = PatternFill("solid", fgColor=NAVY)
        header.font = Font(bold=True, color=WHITE)
        header.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        apply_style(header)
    sheet.row_dimensions[1].height = 26
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:G{sheet.max_row}"
    sheet.sheet_view.showGridLines = False
    return names


def remove_comments_and_hyperlinks(workbook: Any) -> None:
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.comment is not None:
                    cell.comment = None
                if cell.hyperlink is not None:
                    cell.hyperlink = None


FORBIDDEN_VISIBLE_TEXT = (
    "edr_requirements",
    "edr_record_logic_multi_and_single_events.md",
    "ice_common_srs_v1.4_diag_re.xlsx",
    "legacy_edr_spec_covering",
    "edr_prioritized_record_logic_canwakeup_v3.xlsx",
    "project_testcases",
    "docs\\",
    "c:\\",
    ".xlsx",
    ".csv",
    ".json",
    ".md",
)


def reference_findings(workbook: Any) -> list[str]:
    findings: list[str] = []
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and any(token in cell.value.lower() for token in FORBIDDEN_VISIBLE_TEXT):
                    findings.append(f"{sheet.title}!{cell.coordinate}")
                if cell.comment is not None:
                    findings.append(f"comment at {sheet.title}!{cell.coordinate}")
                if cell.hyperlink is not None:
                    findings.append(f"hyperlink at {sheet.title}!{cell.coordinate}")
    return findings


def package_reference_findings(path: Path) -> list[str]:
    forbidden = (
        "edr_requirements",
        "edr_record_logic_multi_and_single_events.md",
        "ice_common_srs_v1.4_diag_re.xlsx",
        "legacy_edr_spec_covering",
        "c:\\framework_ioem_py",
    )
    findings: list[str] = []
    with ZipFile(path) as archive:
        for member in archive.namelist():
            if member.endswith((".xml", ".rels")):
                content = archive.read(member).decode("utf-8", errors="ignore").lower()
                if any(token in content for token in forbidden):
                    findings.append(member)
    return findings


def legacy_case_names() -> set[str]:
    workbook = load_workbook(LEGACY_TEMPLATE, data_only=True, read_only=True)
    sheet = workbook["Export"]
    return {
        str(row[1])
        for row in sheet.iter_rows(min_row=2, values_only=True)
        if row[1] and str(row[1]).startswith("SUBS_EDR_") and str(row[1]) not in LEGACY_GROUPS
    }


def expected_names(groups: list[tuple[str, list[dict[str, Any]]]]) -> list[str]:
    return [case["name"] for _, cases in groups for case in cases]


def validate_workbook(path: Path, groups: list[tuple[str, list[dict[str, Any]]]]) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Complete V3 workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=False)
    if workbook.sheetnames != ["Export", "ChoiceValues"]:
        raise ValueError(f"Complete V3 must preserve the legacy two-sheet structure: {workbook.sheetnames}")
    export = workbook["Export"]
    headers = [export.cell(1, column_number).value for column_number in range(1, 8)]
    if headers != EXPORT_HEADERS:
        raise ValueError("Complete V3 Export headers are not legacy-compatible.")
    group_order = [group_name for group_name, _ in groups]
    expected_row_names = [name for group_name, cases in groups for name in [group_name] + [case["name"] for case in cases]]
    observed_row_names = [
        str(export.cell(row_number, 2).value)
        for row_number in range(2, export.max_row + 1)
        if export.cell(row_number, 2).value is not None
    ]
    if observed_row_names != expected_row_names:
        raise ValueError("Complete V3 group/case priority order does not match the required order.")
    names = expected_names(groups)
    if len(names) != 51 or len(names) != len(set(names)):
        raise ValueError(f"Complete V3 must contain 51 unique authoring cases, found {len(names)}.")
    missing_legacy = legacy_case_names() - set(names)
    if missing_legacy:
        raise ValueError(f"Complete V3 is missing legacy cases: {sorted(missing_legacy)}")
    missing_v2 = V2_CASE_NAMES - set(names)
    if missing_v2:
        raise ValueError(f"Complete V3 is missing V2 CAN-wakeup cases: {sorted(missing_v2)}")
    primary_rows = {
        str(export.cell(row_number, 2).value): row_number
        for row_number in range(2, export.max_row + 1)
        if export.cell(row_number, 2).value in set(names)
    }
    if len(primary_rows) != len(names):
        raise ValueError("Complete V3 primary rows do not map one-to-one to expected case names.")
    highlighted = 0
    minimum_steps: list[int] = []
    ordered_rows = [primary_rows[name] for name in names]
    for index, name in enumerate(names):
        row_number = primary_rows[name]
        name_cell = export.cell(row_number, 2)
        if name_cell.fill.fill_type == "solid" and (name_cell.fill.fgColor.rgb or "").endswith(HIGHLIGHT_YELLOW):
            highlighted += 1
        else:
            raise ValueError(f"Complete V3 case is not yellow highlighted: {name}")
        if not export.cell(row_number, 3).value or not export.cell(row_number, 4).value or not export.cell(row_number, 5).value:
            raise ValueError(f"Complete V3 case lacks description or pre/post action: {name}")
        end_row = ordered_rows[index + 1] if index + 1 < len(ordered_rows) else export.max_row + 1
        step_count = sum(1 for candidate in range(row_number, end_row) if export.cell(candidate, 6).value not in (None, ""))
        minimum_steps.append(step_count)
        if step_count < 5:
            raise ValueError(f"Complete V3 case has fewer than five test steps: {name}")
    full_text = "\n".join(
        str(cell.value or "")
        for row in export.iter_rows()
        for cell in row
    )
    forbidden_legacy_assertions = (
        "Record Lock EDR1 (E2)",
        "Record Lock EDR2 (E2)",
        "higher-priority crash",
    )
    present_assertions = [assertion for assertion in forbidden_legacy_assertions if assertion in full_text]
    if present_assertions:
        raise ValueError(f"Complete V3 retains corrected-away legacy assertions: {present_assertions}")
    for phrase in (
        "EDR1 retains the first crash record. Every raw EDR2 byte, including reserved bytes, is FF.",
        "more than 500 ms and less than 5000 ms",
        "Exactly 5000 ms is characterization only",
        "Record Lock status at End E2 is not evaluated",
        "CompletionStatus=0, 200 ms CompletionStatus=0, and EDR data are not valid.",
        "CompletionStatus=0, 200 ms CompletionStatus=1, and EDR data are valid through 200 ms.",
    ):
        if phrase not in full_text:
            raise ValueError(f"Complete V3 is missing corrected target behavior: {phrase}")
    five_near = [name for name in names if "5NearCrash" in name]
    if len(five_near) != 4:
        raise ValueError("Complete V3 must include four five-Near-Crash final-deployment cases.")
    reference_issues = reference_findings(workbook)
    if reference_issues:
        raise ValueError(f"Complete V3 contains external visible references: {reference_issues[:10]}")
    package_issues = package_reference_findings(path)
    if package_issues:
        raise ValueError(f"Complete V3 package retains external references: {package_issues}")
    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "primary_sheet": "Export",
        "legacy_headers_preserved": True,
        "complete_authoring_case_count": len(names),
        "legacy_case_count_retained": len(legacy_case_names()),
        "v2_can_wakeup_case_count_retained": len(V2_CASE_NAMES),
        "new_v3_case_count": len(names) - len(legacy_case_names() | V2_CASE_NAMES),
        "yellow_highlighted_case_names": highlighted,
        "minimum_detailed_steps": min(minimum_steps),
        "five_near_crash_cases": five_near,
        "group_priority_order": group_order,
        "visible_external_references": 0,
        "package_reference_residue": 0,
    }


def generate() -> dict[str, Any]:
    if not LEGACY_TEMPLATE.is_file():
        raise FileNotFoundError(f"Legacy layout template is unavailable: {LEGACY_TEMPLATE}")
    validate_target_reference()
    source_data = inspect_source()
    groups = build_full_groups(source_data)
    all_names = expected_names(groups)
    if len(all_names) != 51:
        raise ValueError(f"Expected 51 complete V3 cases, found {len(all_names)}.")
    if len(all_names) != len(set(all_names)):
        raise ValueError("Complete V3 case names must be unique.")
    VERSION_DIRECTORY.mkdir(parents=True, exist_ok=True)
    copy2(LEGACY_TEMPLATE, OUTPUT_WORKBOOK)
    workbook = load_workbook(OUTPUT_WORKBOOK, data_only=False, read_only=False)
    written_names = write_export(workbook, groups)
    if written_names != all_names:
        raise ValueError("Complete V3 writer altered the expected test-case ordering.")
    remove_comments_and_hyperlinks(workbook)
    workbook.properties.title = "EDR Full Updated Record Logic and CAN Wakeup Specification V3"
    workbook.properties.subject = "Complete standalone legacy-format EDR review specification"
    workbook.properties.creator = "EDR Test Team"
    workbook.properties.description = "Full V3 review copy with corrected prior cases and added coverage."
    workbook.save(OUTPUT_WORKBOOK)
    workbook.close()
    validation = validate_workbook(OUTPUT_WORKBOOK, groups)
    status_counts = Counter(case["status"] for _, cases in groups for case in cases)
    report = {
        "version": "V3 Full Updated",
        "status": "Review",
        "format": "Legacy two-sheet Export and ChoiceValues structure with every legacy/V2 case carried forward and corrected.",
        "case_count": validation["complete_authoring_case_count"],
        "legacy_case_count_retained": validation["legacy_case_count_retained"],
        "v2_can_wakeup_case_count_retained": validation["v2_can_wakeup_case_count_retained"],
        "new_v3_case_count": validation["new_v3_case_count"],
        "status_counts": dict(status_counts),
        "key_corrections": [
            "Parallel pairs retain the first crash in EDR1 and retain raw FF in every EDR2 byte; old priority-record assertions are removed.",
            "Multi-event timing is strictly greater than 500 ms and strictly less than 5000 ms, including 501 through 800 ms.",
            "Single-event timing is strictly greater than 5000 ms; exactly 5000 ms is observation-only.",
            "End-of-Event-2 lock is not asserted.",
            "IGN OFF/BATT OFF completion behavior is corrected to the supplied completion status table.",
            "Unconfirmed-crash downstream outcomes are observation-only.",
        ],
        "standalone_content": "No external workbook, sheet, path, script, or document reference appears in the specification.",
        "validation": validation,
        "generation_date": date.today().isoformat(),
    }
    OUTPUT_REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate the complete corrected V3 EDR legacy-format specification.")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--generate", action="store_true", help="Generate the full corrected V3 workbook.")
    action.add_argument("--validate", action="store_true", help="Validate the full corrected V3 workbook.")
    arguments = parser.parse_args()
    validate_target_reference()
    source_data = inspect_source()
    groups = build_full_groups(source_data)
    report = generate() if arguments.generate else validate_workbook(OUTPUT_WORKBOOK, groups)
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())