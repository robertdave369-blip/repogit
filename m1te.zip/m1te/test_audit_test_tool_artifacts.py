from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "tools" / "audit_test_tool_artifacts.py"
SPEC = importlib.util.spec_from_file_location("artifact_audit", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
ARTIFACT_AUDIT = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = ARTIFACT_AUDIT
SPEC.loader.exec_module(ARTIFACT_AUDIT)


class ArtifactAuditTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory(prefix="artifact-audit-")
        self.root = Path(self.temp_dir.name)
        for directory in ("tests", "tools"):
            (self.root / directory).mkdir()
        (self.root / "tests" / "test_sample.py").write_text("pass\n", encoding="utf-8")
        (self.root / "tests" / "~$sample.xlsx").write_text("lock", encoding="utf-8")
        (self.root / "tests" / "output.json").write_text("{}\n", encoding="utf-8")
        (self.root / "tools" / "duplicate (2).py").write_text("pass\n", encoding="utf-8")
        (self.root / "tools" / "__pycache__").mkdir()
        (self.root / "tools" / "report").mkdir()
        (self.root / "tools" / "report" / "output.json").write_text("{}\n", encoding="utf-8")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_audit_catalogues_files_and_reports_hygiene_candidates(self) -> None:
        findings = ARTIFACT_AUDIT.audit(self.root)

        reasons = {finding.reason for finding in findings}
        self.assertIn("Office lock file", reasons)
        self.assertIn("numbered duplicate-name candidate", reasons)
        self.assertIn("interpreter cache folder", reasons)
        self.assertIn("grouped artifact folder lacks README.md", reasons)
        self.assertIn("test artifact should be in a purpose-named folder", reasons)
        catalogue = (self.root / "tests" / "ARTIFACT_CATALOG.md").read_text(encoding="utf-8")
        self.assertIn("tests/test_sample.py", catalogue)
        self.assertTrue((self.root / "tools" / "ARTIFACT_CATALOG.md").is_file())
        self.assertFalse((self.root / "tools" / "~$missing.xlsx").exists())


if __name__ == "__main__":
    unittest.main()