from __future__ import annotations

import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

import fitz
from PIL import Image, ImageDraw


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / ".github" / "skills" / "pdf-document-intelligence" / "scripts" / "pdf_document_intelligence.py"
SPEC = importlib.util.spec_from_file_location("pdf_document_intelligence", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
PDF_SKILL = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = PDF_SKILL
SPEC.loader.exec_module(PDF_SKILL)


@unittest.skipIf(PDF_SKILL.pdfplumber is None, "pdfplumber is required for PDF table tests")
class PDFDocumentIntelligenceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="pdf-intelligence-tests-"))

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _create_fixture(self, file_name: str = "aria_user_functions.pdf") -> Path:
        image_path = self.temp_dir / "logo.png"
        image = Image.new("RGB", (100, 50), "white")
        ImageDraw.Draw(image).text((5, 15), "ARIA", fill="black")
        image.save(image_path)

        pdf_path = self.temp_dir / file_name
        document = fitz.open()
        document.set_metadata({"title": "ARIA User Functions"})

        contents_page = document.new_page()
        contents_page.insert_text((72, 42), "Veoneer ARIA User Functions", fontsize=10)
        contents_page.insert_text((72, 100), "Contents", fontsize=18)
        contents_page.insert_text((72, 140), "1. LAMPS ............ 2", fontsize=11)
        contents_page.insert_text((72, 800), "Page 1/2", fontsize=10)

        function_page = document.new_page()
        function_page.insert_text((72, 42), "Veoneer ARIA User Functions", fontsize=10)
        function_page.insert_text((72, 100), "1. LAMPS", fontsize=18)
        function_page.insert_text((72, 135), "1.1 LAMPS.ConfigureLamp", fontsize=15)
        function_page.insert_text((72, 170), "Prototype", fontsize=11)
        function_page.insert_text((72, 195), "String[] LAMPS.ConfigureLamp(", fontsize=11)
        function_page.insert_text((92, 212), "string elementName,", fontsize=11)
        function_page.insert_text((92, 229), "string actionName", fontsize=11)
        function_page.insert_text((72, 246), ")", fontsize=11)
        function_page.insert_text((72, 278), "Description", fontsize=11)
        function_page.insert_text((72, 295), "Create an action for specified lamp.", fontsize=11)
        function_page.insert_text((72, 327), "Return value", fontsize=11)
        function_page.insert_text((72, 344), '["0000", "OPEN for PAD1_LMP set OK."] if OK', fontsize=11)
        function_page.insert_text((72, 361), '["1111", "error message"] if NOK', fontsize=11)
        function_page.insert_text((72, 393), "Usage Example", fontsize=11)
        function_page.insert_text((72, 410), 'LAMPS.ConfigureLamp("PAD1_LMP","OPEN");', fontsize=11)
        function_page.insert_text((72, 442), "E = m * c^2", fontsize=11)
        function_page.insert_text((72, 462), "Figure 1: Lamp Configuration Flow", fontsize=10)
        function_page.insert_image(fitz.Rect(350, 440, 450, 490), filename=image_path)

        x_positions = [72, 150, 260, 470]
        y_positions = [500, 520, 540, 560]
        for x_position in x_positions:
            function_page.draw_line((x_position, y_positions[0]), (x_position, y_positions[-1]))
        for y_position in y_positions:
            function_page.draw_line((x_positions[0], y_position), (x_positions[-1], y_position))
        for text, position in [
            ("Type", (78, 514)), ("Name", (156, 514)), ("Description", (266, 514)),
            ("string", (78, 534)), ("elementName", (156, 534)), ("Load name", (266, 534)),
            ("string", (78, 554)), ("actionName", (156, 554)), ("Action name", (266, 554)),
        ]:
            function_page.insert_text(position, text, fontsize=9)
        function_page.insert_text((72, 800), "Page 2/2", fontsize=10)

        document.save(pdf_path)
        document.close()
        return pdf_path

    def test_extracts_semantic_repository(self) -> None:
        pdf_path = self._create_fixture()
        output_root = self.temp_dir / "output"

        output_dir = PDF_SKILL.PDFDocumentIntelligenceSkill().process(pdf_path, output_root)

        self.assertTrue(output_dir.samefile(output_root / "aria_user_functions"))
        expected_artifacts = {
            "metadata.json", "pages.json", "document_structure.json", "functions.json", "toc.json",
            "references.json", "relationships.json", "mathematical_expressions.json", "knowledge_chunks.json",
            "document_summary.json", "duplicate_content.json", "search_index.json", "extraction_quality.json",
            "run_manifest.json", "document.md",
        }
        self.assertTrue(all((output_dir / artifact).is_file() for artifact in expected_artifacts))

        pages = json.loads((output_dir / "pages.json").read_text(encoding="utf-8"))["pages"]
        functions = json.loads((output_dir / "functions.json").read_text(encoding="utf-8"))["functions"]
        toc = json.loads((output_dir / "toc.json").read_text(encoding="utf-8"))
        math = json.loads((output_dir / "mathematical_expressions.json").read_text(encoding="utf-8"))["expressions"]
        chunks = json.loads((output_dir / "knowledge_chunks.json").read_text(encoding="utf-8"))["chunks"]
        search_index = json.loads((output_dir / "search_index.json").read_text(encoding="utf-8"))
        function = next(item for item in functions if item["name"] == "LAMPS.ConfigureLamp")

        self.assertTrue(all(page["headers"] and page["footers"] for page in pages))
        self.assertEqual(function["prototype"]["return_type"], "String[]")
        self.assertEqual(function["prototype"]["signature"], "LAMPS.ConfigureLamp(string elementName,string actionName)")
        self.assertEqual([item["name"] for item in function["parameters"]], ["elementName", "actionName"])
        self.assertEqual([item["description"] for item in function["parameters"]], ["Load name", "Action name"])
        self.assertEqual(function["description"], "Create an action for specified lamp.")
        self.assertEqual({item["code"] for item in function["returns"]}, {"0000", "1111"})
        self.assertTrue(function["examples"])
        self.assertEqual(toc["resolutions"][0]["actual_page"], 2)
        self.assertTrue(any("E = m * c^2" in item["text"] for item in math))
        self.assertTrue(pages[1]["images"])
        self.assertTrue(pages[1]["tables"])
        self.assertEqual(pages[1]["images"][0]["caption"], "Lamp Configuration Flow")
        self.assertEqual(pages[1]["images"][0]["image_type"], "flowchart")
        self.assertEqual(pages[1]["images"][0]["ocr"]["status"], "not_requested")
        self.assertEqual(pages[1]["tables"][0]["table_type"], "parameter_table")
        self.assertTrue(any(chunk["type"] == "function" and chunk["title"] == "LAMPS.ConfigureLamp" for chunk in chunks))
        self.assertIn("LAMPS", search_index["keywords"])

    def test_optional_ocr_never_silently_discards_image_content(self) -> None:
        pdf_path = self._create_fixture()
        output_dir = PDF_SKILL.PDFDocumentIntelligenceSkill(ocr_engine="tesseract").process(
            pdf_path,
            self.temp_dir / "ocr-output",
        )

        pages = json.loads((output_dir / "pages.json").read_text(encoding="utf-8"))["pages"]
        quality = json.loads((output_dir / "extraction_quality.json").read_text(encoding="utf-8"))
        image_ocr = pages[1]["images"][0]["ocr"]

        self.assertEqual(image_ocr["engine"], "tesseract")
        self.assertIn(image_ocr["status"], {"completed", "unavailable"})
        if image_ocr["status"] == "completed":
            self.assertIn("confidence", image_ocr)
        else:
            self.assertTrue(quality["ocr_unavailable"])

    def test_default_output_root_targets_framework_docs(self) -> None:
        self.assertEqual(PDF_SKILL.DEFAULT_OUTPUT_ROOT, REPO_ROOT / "docs" / "processed_Documents")

    def test_processed_folder_preserves_source_document_stem_casing(self) -> None:
        pdf_path = self._create_fixture("AIRBAG_SPEC_v1.pdf")
        output_root = self.temp_dir / "output"

        output_dir = PDF_SKILL.PDFDocumentIntelligenceSkill().process(pdf_path, output_root)

        self.assertTrue(output_dir.samefile(output_root / "AIRBAG_SPEC_v1"))
        metadata = json.loads((output_dir / "metadata.json").read_text(encoding="utf-8"))
        self.assertEqual(metadata["source_document_stem"], "AIRBAG_SPEC_v1")


if __name__ == "__main__":
    unittest.main()