from __future__ import annotations

import datetime as dt
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.dont_write_bytecode = True
TOOLS_DIR = Path(__file__).resolve().parents[1] / "tools"
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import keep_awake as ka  # noqa: E402

POWERCFG_LID = """    Possible Setting Index: 003
    Possible Setting Friendly Name: Shut down
    Current AC Power Setting Index: 0x00000000
    Current DC Power Setting Index: 0x00000001
"""


class KeepAwakeStateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="keep-awake-"))
        for p in (mock.patch.object(ka, "STATE_DIR", self.tmp), mock.patch.object(ka, "spawn_holder", return_value=1),
                  mock.patch.object(ka, "pid_alive", return_value=False), mock.patch.object(ka, "wifi_profile", return_value="Lab"),
                  mock.patch.object(ka, "cmd_status", return_value=0), mock.patch.object(ka.time, "sleep")):
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_tasks_share_one_hold_and_stop_one_by_one(self) -> None:
        ka.main(["start", "--task", "req-review-A", "--hours", "2"])
        ka.main(["start", "--task", "test-run-B", "--hours", "1", "--display"])
        state = ka.load()
        self.assertEqual(sorted(state["tasks"]), ["req-review-A", "test-run-B"])
        self.assertEqual(state["wifi_profile"], "Lab")
        self.assertTrue(state["tasks"]["test-run-B"]["display"])
        ka.main(["stop", "--task", "req-review-A"])
        self.assertEqual(list(ka.load()["tasks"]), ["test-run-B"])
        ka.main(["stop", "--all"])
        self.assertEqual(ka.load()["tasks"], {})

    def test_expired_tasks_are_not_active(self) -> None:
        now = dt.datetime(2026, 10, 26, 12, 0)
        tasks = {"old": {"until": "2026-10-26T11:59:59"}, "live": {"until": "2026-10-26T12:00:30"}}
        self.assertEqual(list(ka.active(tasks, now)), ["live"])

    def test_lid_action_reads_hidden_setting_indices(self) -> None:
        self.assertEqual(ka.lid_action(POWERCFG_LID), {"AC": "do nothing", "DC": "sleep"})


if __name__ == "__main__":
    unittest.main()
