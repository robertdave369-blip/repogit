"""Offline regression tests for the Veoneer test-specification skill."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any, cast

import openpyxl


SKILL_SCRIPTS = (
    Path(__file__).resolve().parents[1]
    / ".github"
    / "skills"
    / "veoneer-test-spec-generator"
    / "scripts"
)
if str(SKILL_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SKILL_SCRIPTS))

from generator import generate_specification
from legacy_adapters import excel_to_testcase_dict, write_legacy_title_step_workbook
from methodology import select_methodology
from models import Requirement, SourceProvenance
from requirement_parser import parse_docx, parse_excel, parse_pdf
from sanitize import sanitize_text
from validation import validate_rendered_workbook, validate_specification
from workbook_codec import inspect_template, load_profile, read_export_cases, render_specification


class VeoneerTestSpecGeneratorTests(unittest.TestCase):
    """Exercise deterministic skill behavior without an ARIA bench or Codebeamer connection."""

    def _build_template(self, destination: Path) -> None:
        profile = load_profile()
        workbook = openpyxl.Workbook()
        export = workbook.active
        if export is None or not hasattr(export, "append"):
            self.fail("openpyxl did not create a writable worksheet.")
        export = cast(Any, export)
        export.title = "Export"
        export.append(profile["workbook"]["header_order"])
        export.append([None] * len(profile["workbook"]["header_order"]))
        export.append([None] * len(profile["workbook"]["header_order"]))
        choices = workbook.create_sheet("ChoiceValues")
        choices.sheet_state = "hidden"
        techniques = [
            "Equivalence Classes",
            "Boundary Value Analysis",
            "Fault Injection",
            "State Transition Testing",
            "Decision Table Testing",
        ]
        for row_number, technique in enumerate(techniques, start=1):
            choices.cell(row=row_number, column=1, value=technique)
        workbook.save(destination)
        workbook.close()

    def _approved_requirement(self) -> Requirement:
        return Requirement(
            identifier="31300826",
            title="Status timeout",
            text="The controller shall report the requested status within 100 ms.",
            status="Approved",
            provenance=SourceProvenance(
                source_path="test-requirements.json",
                source_type="json",
                location="item 1",
                raw_status="Approved",
            ),
        )

    def test_sanitization_preserves_engineering_tokens_and_struck_content(self) -> None:
        normal = sanitize_text("%%(color:red;)<span>CAN-FD 62.5%</span>%! [ISSUE:31300826]-null ~-")
        self.assertIn("CAN-FD 62.5%", normal.text)
        self.assertIn("[ISSUE:31300826]-null", normal.text)
        self.assertIn("-", normal.text)
        struck = sanitize_text("%%(text-decoration:line-through;)obsolete behavior%!")
        self.assertEqual(struck.text, "[STRUCK: obsolete behavior]")

    def test_excel_parser_reads_all_sheets_and_preserves_provenance(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "requirements.xlsx"
            workbook = openpyxl.Workbook()
            requirements = workbook.active
            if requirements is None or not hasattr(requirements, "append"):
                self.fail("openpyxl did not create a writable worksheet.")
            requirements = cast(Any, requirements)
            requirements.title = "Requirements"
            requirements.append(["ID", "Summary", "Description", "_ReqStatus", "_Projects"])
            requirements.append(["31300826", "Status", "The status shall be available.", "Approved", "Demo"])
            notes = workbook.create_sheet("Notes")
            notes.append(["Free text"])
            notes.append(["Not a requirement table"])
            workbook.save(source)
            workbook.close()

            parsed, report = parse_excel(source)
            self.assertEqual(len(parsed), 1)
            self.assertEqual(parsed[0].identifier, "31300826")
            self.assertEqual(parsed[0].provenance.location, "Requirements!2")
            self.assertEqual(len(report.sheet_stats), 2)
            self.assertEqual(report.sheet_stats[1]["warning"], "requirement_header_unavailable")

    def test_docx_and_pdf_parsers_preserve_source_locations(self) -> None:
        try:
            import fitz
            from docx import Document
        except ImportError:
            self.skipTest("Optional DOCX/PDF parser dependencies are not installed.")
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory)
            docx_path = workspace / "requirements.docx"
            document = Document()
            document.add_paragraph("90000001: The fixture shall report status.")
            document.save(docx_path)
            docx_records, _ = parse_docx(docx_path)
            self.assertEqual(docx_records[0].provenance.location, "paragraph 1")

            pdf_path = workspace / "requirements.pdf"
            pdf = fitz.open()
            page = pdf.new_page()
            page.insert_text((72, 72), "90000002: The fixture shall preserve the stated value.")
            pdf.save(pdf_path)
            pdf.close()
            pdf_records, _ = parse_pdf(pdf_path)
            self.assertEqual(pdf_records[0].provenance.location, "page 1 paragraph 1")

    def test_legacy_adapter_round_trip(self) -> None:
        test_cases = [
            {
                "Sno": 1,
                "Test Case Name": "Status_Nominal",
                "Test Case Description": "Verify nominal status behavior.",
                "Steps": [
                    ["1", "Establish normal state", "System is ready"],
                    ["2", "Request status", "Status is reported"],
                ],
            }
        ]
        with tempfile.TemporaryDirectory() as directory:
            workbook_path = Path(directory) / "legacy.xlsx"
            write_legacy_title_step_workbook(test_cases, workbook_path)
            parsed = excel_to_testcase_dict(workbook_path)
            self.assertEqual(parsed, test_cases)

    def test_response_timeout_uses_boundary_not_fault_methodology(self) -> None:
        requirement = self._approved_requirement()
        methodology = select_methodology(
            requirement,
            allowed_techniques=["Boundary Value Analysis", "Fault Injection"],
        )
        self.assertEqual(methodology.primary_technique, "Boundary Value Analysis")

    def test_template_render_round_trip_and_traceability_format(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            template = Path(directory) / "template.xlsx"
            output = Path(directory) / "generated.xlsx"
            self._build_template(template)
            inspection = inspect_template(template)
            self.assertEqual(inspection.issues, [])
            generation = generate_specification(
                [self._approved_requirement()],
                title="Generated specification",
                allowed_techniques=inspection.allowed_values["_TestTechnique"],
            )
            self.assertEqual(len(generation.specification.test_cases), 2)
            preflight = validate_specification(generation.specification, template_path=template)
            self.assertEqual([issue for issue in preflight if issue.severity == "error"], [])
            render_specification(
                generation.specification,
                template_path=template,
                destination_path=output,
                write_mode="replace_data",
            )
            postflight = validate_rendered_workbook(output)
            self.assertEqual(postflight["summary"]["errors"], 0)
            cases = read_export_cases(output)
            self.assertEqual(len(cases), 2)
            self.assertEqual(cases[0]["fields"]["Verifies"], "[ISSUE:31300826]-null")
            self.assertEqual(len(cases[0]["steps"]), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)