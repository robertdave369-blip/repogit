"""Generate and validate an offline EDR Record 1 sensor-data test specification."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, cast

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIRECTORY = REPOSITORY_ROOT / "tests" / "artifacts" / "edr-record1-sensor-data"
SKILL_SCRIPTS = (
    REPOSITORY_ROOT
    / ".github"
    / "skills"
    / "veoneer-test-spec-generator"
    / "scripts"
)
EVIDENCE_PATH = ARTIFACT_DIRECTORY / "edr_record1_sensor_data_requirements.json"
TEMPLATE_PATH = REPOSITORY_ROOT / "tests" / "veoneer_test_spec_generator_demo" / "Dummy_Legacy_Export_Spec.xlsx"
DEFAULT_OUTPUT_PATH = ARTIFACT_DIRECTORY / "U171_Z121_EDR_Record1_Sensor_Data_Test_Spec.xlsx"

sys.path.insert(0, str(SKILL_SCRIPTS))

_legacy_export = cast(Any, importlib.import_module("legacy_export"))
_models = cast(Any, importlib.import_module("models"))
_sanitize = cast(Any, importlib.import_module("sanitize"))

_SourceProvenance = _models.SourceProvenance
_TestCase = _models.TestCase
_TestMethodology = _models.TestMethodology
_TestSpecification = _models.TestSpecification
_TestStep = _models.TestStep
render_legacy_export_specification = _legacy_export.render_legacy_export_specification
validate_legacy_export_specification = _legacy_export.validate_legacy_export_specification
validate_legacy_export_workbook = _legacy_export.validate_legacy_export_workbook
write_json_report = _sanitize.write_json_report


def load_evidence() -> dict[str, Any]:
    """Load the safe, Codebeamer-derived evidence record used by this spec."""
    evidence = json.loads(EVIDENCE_PATH.read_text(encoding="utf-8"))
    if not isinstance(evidence, dict):
        raise ValueError("EDR Record 1 evidence must be a JSON object.")
    requirements = evidence.get("requirements")
    if not isinstance(requirements, list) or len(requirements) != 16:
        raise ValueError("EDR Record 1 evidence must contain exactly 16 requirements.")
    requirement_ids = [record.get("id") for record in requirements if isinstance(record, dict)]
    if len(requirement_ids) != 16 or len(set(requirement_ids)) != 16:
        raise ValueError("EDR Record 1 requirement IDs must be present and unique.")
    return evidence


def build_specification() -> Any:
    """Build one review case per source-backed Record 1 sensor DID."""
    evidence = load_evidence()
    source = _mapping(evidence, "source")
    metadata = _mapping(evidence, "common_record_metadata")
    project_variants = _string_list(evidence.get("project_variants"), "project_variants")
    cases = [
        _build_case(record, source, metadata, project_variants)
        for record in _record_list(evidence.get("requirements"))
    ]
    return _TestSpecification(
        title="U171 Z121 EDR Record 1 Sensor Data DID Verification",
        test_cases=cases,
        source_paths=[str(EVIDENCE_PATH)],
        assumptions=[
            "These are offline review cases. No bench, ECU, crash, diagnostic, or Codebeamer importer action is performed by this generator.",
            "The supplied Codebeamer records are In_Review and marked _Implemented = false; the cases are not evidence of released implementation coverage.",
            "The selected projects are the variants listed by every retrieved requirement record; sensor enablement and diagnostic routing must be confirmed in the target configuration before execution.",
        ],
        coverage_gaps=[
            "All 16 source requirements have Codebeamer status In_Review rather than Approved.",
            "All 16 source requirements are marked _Implemented = false.",
            str(source["response_layout_gap"]),
            "Exact stored-byte order, signed encoding for acceleration fields, saturation behavior, and byte-level decoder evidence are unavailable.",
            "The source requests security access but does not identify the exact security level or key procedure for these DIDs.",
            "Target-specific sensor stimulation, variant-code enablement, and physical diagnostic route evidence are unavailable for these exact DIDs.",
            "Codebeamer importer acceptance remains unverified because no approved importer round trip is included.",
        ],
    )


def generate_workbook(
    output_path: str | Path = DEFAULT_OUTPUT_PATH,
    report_path: str | Path | None = None,
    *,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Render a review-ready V3-style Export workbook and validation report."""
    specification = build_specification()
    preflight = validate_legacy_export_specification(specification)
    preflight_errors = [issue for issue in preflight if issue.severity == "error"]
    if preflight_errors:
        raise ValueError("Preflight blocked output: " + "; ".join(issue.message for issue in preflight_errors))

    rendering = render_legacy_export_specification(
        specification,
        template_path=TEMPLATE_PATH,
        destination_path=output_path,
        group_name="EDR_RECORD1_SENSOR_DATA_DID_VERIFICATION",
        write_mode="replace_data",
        overwrite=overwrite,
    )
    postflight = validate_legacy_export_workbook(
        output_path,
        expected_case_names=[test_case.name for test_case in specification.test_cases],
        expected_case_mode="exact",
        expected_test_cases=specification.test_cases,
    )
    evidence = load_evidence()
    source = _mapping(evidence, "source")
    report = {
        "specification": {
            "title": specification.title,
            "test_case_count": len(specification.test_cases),
            "priority_rationale": "High is a test-execution priority for crash-event EDR data integrity; it is not an ASIL assignment.",
            "assumptions": specification.assumptions,
            "coverage_gaps": specification.coverage_gaps,
        },
        "source_evidence": {
            "path": str(EVIDENCE_PATH.resolve()),
            "sha256": _sha256(EVIDENCE_PATH),
            "system": source["system"],
            "project_id": source["project_id"],
            "project_name": source["project_name"],
            "tracker_id": source["tracker_id"],
            "tracker_name": source["tracker_name"],
            "parent_id": source["parent_id"],
            "parent_name": source["parent_name"],
            "requirements": [
                {
                    "id": record["id"],
                    "did": record["did"],
                    "name": record["name"],
                    "status": record["status"],
                    "version": record["version"],
                    "implemented": record["implemented"],
                }
                for record in _record_list(evidence.get("requirements"))
            ],
        },
        "traceability": [
            {
                "test_case": test_case.name,
                "requirement_ids": test_case.requirement_ids,
                "source_requirements": [asdict(item) for item in test_case.source_requirements],
            }
            for test_case in specification.test_cases
        ],
        "preflight": [asdict(issue) for issue in preflight],
        "rendering": rendering,
        "postflight": postflight,
        "codebeamer_import_compatibility": {
            "status": "unverified",
            "evidence": "Evidence unavailable: no approved Codebeamer importer round trip was requested or executed.",
        },
    }
    resolved_report_path = (
        Path(report_path)
        if report_path is not None
        else Path(output_path).with_suffix(Path(output_path).suffix + ".validation.json")
    )
    write_json_report(report, resolved_report_path)
    return report


def test_record_1_sensor_data_specification_validates() -> None:
    """Ensure all requested IDs render into a valid, traceable offline workbook."""
    specification = build_specification()
    assert len(specification.test_cases) == 16
    assert {
        requirement_id
        for test_case in specification.test_cases
        for requirement_id in test_case.requirement_ids
    } == {
        str(record["id"])
        for record in _record_list(load_evidence().get("requirements"))
    }
    assert not [
        issue
        for issue in validate_legacy_export_specification(specification)
        if issue.severity == "error"
    ]

    with tempfile.TemporaryDirectory() as temporary_directory:
        workbook_path = Path(temporary_directory) / "record1_sensor_data.xlsx"
        report = generate_workbook(workbook_path)
        assert report["postflight"]["summary"]["errors"] == 0
        assert report["postflight"]["test_case_count"] == 16
        assert Path(str(workbook_path) + ".validation.json").is_file()


def _build_case(
    record: Mapping[str, Any],
    source: Mapping[str, Any],
    metadata: Mapping[str, Any],
    project_variants: list[str],
) -> Any:
    requirement_id = str(record["id"])
    did = str(record["did"])
    sample_count = int(metadata["size_in_bytes"])
    sample_period_us = int(metadata["sample_period_us"])
    sample_rate_hz = int(metadata["sample_rate_hz"])
    start_ms = int(metadata["recording_start_ms"])
    end_ms = int(metadata["recording_end_ms"])
    sample_count_from_grid = ((end_ms - start_ms) * 1000 // sample_period_us) + 1
    if sample_count_from_grid != sample_count:
        raise ValueError("Source timing grid does not match the declared Record 1 size.")
    subject = str(record["subject"])
    response_did = f"04 {did[2:]}"
    source_location = (
        f"Codebeamer project {source['project_id']}, tracker {source['tracker_id']}, "
        f"item {requirement_id}, parent {source['parent_id']}, version {record['version']}"
    )
    description = (
        f"Objective: verify Record 1 DID 0x{did} records {subject} after a confirmed crash. "
        f"The source declares {sample_count} data bytes at {sample_rate_hz} samples/s "
        f"({sample_period_us} us spacing), from T0 {start_ms} ms through T0 +{end_ms} ms, "
        f"with unit {record['unit']}, resolution '{record['resolution']}', and range '{record['range']}'. "
        f"Requirement {requirement_id} is {record['status']} and _Implemented is {record['implemented']}. "
        f"Byte-level pass remains ON HOLD: {source['response_layout_gap']}"
    )
    pre_action = (
        "Select one source-listed target variant and retain its configuration evidence; establish the "
        "fault-free EDR environment; confirm source sensor enablement and capture the diagnostic baseline. "
        "Do not execute this review case without separate bench authorization."
    )
    post_action = (
        "Retain raw diagnostic traffic, reference capture, EDR response, target configuration, and deviation evidence. "
        "Restore the approved bench condition; do not clear crash-lock data, NVM, or DTCs under this test plan."
    )
    steps = [
        _TestStep(
            action=(
                f"Select one of: {', '.join(project_variants)}. IGN ON, check the diagnostic baseline, "
                f"and record the enabled configuration for {subject}."
            ),
            expected_result=(
                "The target variant, EDR configuration, sensor enablement evidence, and baseline diagnostic result are retained. "
                "No DTC identifier is asserted because the source does not provide one."
            ),
            critical=False,
        ),
        _TestStep(
            action=(
                f"Apply the project-approved confirmed-crash stimulus and synchronously capture the {subject} reference signal with T0."
            ),
            expected_result=(
                "A confirmed event and a traceable T0 reference are available. The source does not define a concrete "
                "bench stimulus, so unapproved stimulation must not be substituted."
            ),
            critical=False,
        ),
        _TestStep(
            action=(
                f"Capture the reference signal from T0 {start_ms} ms through T0 +{end_ms} ms at {sample_period_us} us intervals."
            ),
            expected_result=(
                f"The capture provides {sample_count} grid points: (({end_ms} - ({start_ms})) ms / "
                f"{sample_period_us} us) + 1 = {sample_count}."
            ),
            critical=False,
        ),
        _TestStep(
            action=(
                f"Perform the target-approved diagnostic security access, then request ReadDataByIdentifier: 22 {response_did}. "
                "Capture the complete physical diagnostic request and response."
            ),
            expected_result=(
                f"A positive ReadDataByIdentifier response is 62 {response_did} followed by Record 1 data. "
                "The exact security level and key procedure are not established by this requirement and must be evidenced before execution."
            ),
            critical=False,
        ),
        _TestStep(
            action=(
                f"Map the DID 0x{did} Record 1 data to the reference capture and evaluate {record['encoding']}"
            ),
            expected_result=(
                f"The returned data can be correlated to the {sample_count}-point source time grid and respects the "
                f"declared {record['unit']} range {record['range']}. Exact stored-byte order, acceleration signed encoding, "
                "saturation, and comparison tolerance require confirmed decoder evidence before a numeric pass verdict."
            ),
            critical=False,
        ),
        _TestStep(
            action="Review the response data index against the source Record 1 byte-position statement before recording a verdict.",
            expected_result=(
                "The response-index discrepancy is resolved, or the test remains IN REVIEW with byte-level verification ON HOLD. "
                "No byte-level pass is claimed from the ambiguous source range."
            ),
            critical=False,
        ),
    ]
    return _TestCase(
        name=str(record["case_name"]),
        description=description,
        steps=steps,
        methodology=_TestMethodology(
            primary_technique="Requirement Based",
            supporting_methods=["Data Flow", "Boundary Value Analysis"],
            rationale=(
                "Requirement-based DID verification is selected because the source defines the DID, time grid, "
                "resolution, and range. Boundary analysis is limited to source-defined ranges pending a verified stimulus and decoder."
            ),
        ),
        requirement_ids=[requirement_id],
        pre_action=pre_action,
        post_action=post_action,
        priority="High",
        status="IN REVIEW",
        item_type="Functional",
        project=", ".join(project_variants),
        latest_result="NOT YET TESTED",
        test_type="Manual",
        verification_method=str(metadata["verification_method"]),
        source_requirements=[
            _SourceProvenance(
                source_path=f"Codebeamer tracker {source['tracker_id']}",
                source_type="Codebeamer REST API v3",
                location=source_location,
                raw_status=str(record["status"]),
            )
        ],
        generation_notes=[
            "Source status is In_Review; this traceability does not claim Approved coverage.",
            "Source _Implemented value is false.",
            str(source["response_layout_gap"]),
        ],
    )


def _mapping(value: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    nested_value = value.get(key)
    if not isinstance(nested_value, Mapping):
        raise ValueError(f"Evidence field '{key}' must be an object.")
    return nested_value


def _record_list(value: object) -> list[Mapping[str, Any]]:
    if not isinstance(value, list) or not all(isinstance(record, Mapping) for record in value):
        raise ValueError("Evidence requirements must be a list of objects.")
    return list(value)


def _string_list(value: object, field_name: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) and item for item in value):
        raise ValueError(f"Evidence field '{field_name}' must be a list of strings.")
    return list(value)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(argv: list[str] | None = None) -> int:
    """Generate the offline workbook from the preserved Codebeamer evidence."""
    parser = argparse.ArgumentParser(
        description="Generate the EDR Record 1 sensor-data Veoneer test specification offline."
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT_PATH)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    report = generate_workbook(
        args.output,
        args.report,
        overwrite=args.overwrite,
    )
    print(
        json.dumps(
            {
                "output": str(args.output),
                "report": str(
                    args.report
                    or args.output.with_suffix(args.output.suffix + ".validation.json")
                ),
                "test_cases": report["specification"]["test_case_count"],
                "preflight_warnings": len(report["preflight"]),
                "postflight_errors": report["postflight"]["summary"]["errors"],
            },
            indent=2,
        )
    )
    return 1 if report["postflight"]["summary"]["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())