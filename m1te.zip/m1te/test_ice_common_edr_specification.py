"""Extract source evidence for the U171 ICE common EDR CAN-C specification."""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import re
import sys
import tempfile
from collections.abc import Iterable
from datetime import date, datetime, time
from pathlib import Path
from typing import Any

import cantools
import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


SKILL_SCRIPTS = (
    Path(__file__).resolve().parents[1]
    / ".github"
    / "skills"
    / "veoneer-test-spec-generator"
    / "scripts"
)
if str(SKILL_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SKILL_SCRIPTS))

from models import SourceProvenance, TestCase, TestMethodology, TestSpecification, TestStep
from validation import validate_rendered_workbook, validate_specification, write_validation_report
from workbook_codec import inspect_template, render_specification

for model_type in (TestCase, TestMethodology, TestSpecification, TestStep):
    setattr(model_type, "__test__", False)


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
SOURCE_WORKBOOKS = {
    "common_diagnostic_spec": REPOSITORY_ROOT
    / "docs"
    / "project_documents"
    / "Common Diag Spec"
    / "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx",
    "u171_edr_requirements": REPOSITORY_ROOT
    / "project_reuirements"
    / "u171_w616_z121"
    / "DES_SW_Mahindra_EDR .xlsx",
    "u171_edr_drbfm": REPOSITORY_ROOT
    / "project_reuirements"
    / "u171_w616_z121"
    / "RstEdr_DRBFM.xlsx",
}
U171_EDR_CONFIG = REPOSITORY_ROOT / "projects" / "U171" / "config" / "edr_config.py"
U171_CAN_LIBRARY = REPOSITORY_ROOT / "projects" / "U171" / "config" / "U171_CANLibrary.py"
U171_CANC_CONFIG = REPOSITORY_ROOT / "projects" / "U171" / "config" / "canc_config.py"
U171_VARIANT_CONFIG = REPOSITORY_ROOT / "projects" / "U171" / "config" / "variantcode_config.py"
U171_DBC = REPOSITORY_ROOT / "project_dbc" / "u171_dbc" / "U171_SRS_SVNID39216_20250917.dbc"
TEMPLATE_PATH = (
    REPOSITORY_ROOT
    / ".github"
    / "skills"
    / "veoneer-test-spec-generator"
    / "assets"
    / "veoneer_codebeamer_test_spec_template.cleaned.xlsx"
)
DEFAULT_OUTPUT_DIRECTORY = REPOSITORY_ROOT / "project_testcases" / "ice_common_spec" / "EDR"

RECORD_1_ACCESS_REQUIREMENT = "34856976"
RECORD_2_ACCESS_REQUIREMENT = "34984359"
RECORD_1_RESERVED_REQUIREMENT = "34885285"
RECORD_2_RESERVED_REQUIREMENT = "34984647"
RECORD_1_FALLBACK_REQUIREMENTS = [
    "34856978",
    "34856981",
    "34856983",
    "34856984",
    "34856985",
    "34856986",
    "34856987",
]
RECORD_2_FALLBACK_REQUIREMENTS = [
    "34984361",
    "34984364",
    "34984366",
    "34984367",
    "34984368",
    "34984369",
    "34984370",
]
GENERIC_EDR_LIFECYCLE_REQUIREMENTS = [
    "34856955",
    "34856958",
    "34856960",
    "34856961",
    "34856963",
    "34856966",
    "34856967",
    "34856972",
]
RECORD_1_SPEED_AT_T0_REQUIREMENT = "34856977"
RECORD_2_SPEED_AT_T0_REQUIREMENT = "34984360"
RECORD_1_ODOMETER_REQUIREMENT = "34856990"
RECORD_2_ODOMETER_REQUIREMENT = "34984373"

LAYOUT_COLUMNS = [
    "DID",
    "PARAM_NAME",
    "DISPLAY_NAME",
    "LEN_IN_BYTES",
    "LEN_IN_BITS",
    "POS_IN_BYTES",
    "POS_IN_BITS",
    "OFFSET",
    "RESOLUTION",
    "DATA_TYPE",
    "DATA_FORMAT",
    "CONVERSION_FORMULA",
    "UNIT",
    "MIN_VALUE",
    "MAX_VALUE",
    "Reference CAN Signal",
]
TIME_PATTERN = re.compile(
    r"\bat\s*([+-]?\d+(?:\.\d+)?)\s*(ms|msec|s|sec|seconds?)\b",
    flags=re.IGNORECASE,
)
TRAILING_TIME_PATTERN = re.compile(
    r"\s*(?:at\s*)?[+-]?\d+(?:\.\d+)?\s*(?:ms|msec|s|sec|seconds?)\s*$",
    flags=re.IGNORECASE,
)
ELEMENT_TO_FRAMEWORK_KEY = {
    "vehiclespeedlongitudinal": "VehSpdLgt",
    "vehiclespeedlongitudinalattimezero": "VehSpdLgtAtTimeZero",
    "odometer": "Odometer",
    "enginestate": "STS_ENG",
    "doorsopenstatus": "DoorsOpenStatus",
    "brakeswitchstatus": "BRAKE_PEDAL_VALUE",
    "acceleratorpedalfull": "ACC_PED",
    "enginespeed": "Engine_Speed",
    "clutchstatus": "CLUTCH_STS",
    "steeringabsoluteangle": "STEERING_ABSOLUTE_ANGLE",
    "absactiveieb": "ABS_ACTIVE",
    "escactiveieb": "ESC_ACTIVE",
    "tcsactiveieb": "TCS_ACTIVE_IEB",
    "tyrepressurefl": "Tyre_Pressure_FL",
    "tyrepressurefr": "Tyre_Pressure_FR",
    "tyrepressurerl": "Tyre_Pressure_RL",
    "tyrepressurerr": "Tyre_Pressure_RR",
    "mastercylinderpressure": "Master_Cylinder_Pressure",
    "gear": "GEAR_ACTUAL",
    "driverdoorlockstatus": "Door Lock Status",
    "yawrate": "YAW_RATE",
    "lateralaccel": "LATERAL_ACCEL",
    "longaccel": "LONG_ACCEL",
    "aebwarningmsg": "AEB_WARNING_MSG1",
    "aebfctawarn": "AEB_FCTA_WARN",
    "aeswarning": "AES_WARNING1",
    "aessyssts": "AES_SYS_STS1",
    "esasyssts": "ESA_SYS_STS1",
    "ldwlkawarning": "LDW_LKA_WARNING1",
    "adasdesstrwhlanglecmd": "ADAS_Des_StrWhl_Angle_Cmd",
    "accsysstate": "ACC_SYS_STATE",
    "npsyssts": "NP_SYS_STS1",
    "rmsmodestate": "RMS_MODE_STATE1",
    "lcpathstate": "LC_PATH_STATE1",
    "elkcomingwarning": "ELK_ONCOMING_WARNING1",
    "elksidewarning": "ELK_SIDE_WARNING1",
    "elkovertakingwarning": "ELK_OVERTAKING_WARNING1",
    "stshighbeam": "STS_HIGH_BEAM",
    "stslowbeam": "STS_LOW_BEAM",
    "ststpmsled": "STS_TPMS_LED",
    "zonalbattvolt": "BATT_VOLT",
    "stscrash": "STS_CRASH",
}


def _normalize_name(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def _integer_from_value(value: object) -> int | None:
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    match = re.search(r"-?\d+", str(value or ""))
    return int(match.group()) if match else None


def _literal_assignment(path: Path, variable_name: str) -> Any:
    """Read literal configuration data without importing any framework or bench module."""
    source_tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for statement in source_tree.body:
        if not isinstance(statement, ast.Assign):
            continue
        if any(isinstance(target, ast.Name) and target.id == variable_name for target in statement.targets):
            return ast.literal_eval(statement.value)
    raise KeyError(f"Literal configuration assignment not found: {variable_name} in {path}")


def _workbook_headers(worksheet: Any) -> dict[str, int]:
    return {
        str(value).strip(): index
        for index, value in enumerate(next(worksheet.iter_rows(min_row=1, max_row=1, values_only=True)))
        if value is not None and str(value).strip()
    }


def _load_layout_rows() -> list[dict[str, Any]]:
    source_path = SOURCE_WORKBOOKS["common_diagnostic_spec"]
    workbook = openpyxl.load_workbook(source_path, read_only=True, data_only=False)
    try:
        worksheet = workbook["EDR_0455_045B"]
        headers = _workbook_headers(worksheet)
        missing = [column for column in LAYOUT_COLUMNS if column not in headers]
        if missing:
            raise ValueError(f"EDR layout header(s) unavailable: {missing}")
        rows: list[dict[str, Any]] = []
        for row_number, values in enumerate(worksheet.iter_rows(min_row=2, values_only=True), start=2):
            record = str(values[headers["DID"]] or "").strip().casefold()
            if record != "0x0455":
                continue
            row = {column: values[index] for column, index in headers.items()}
            row["source_reference"] = f"ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx!EDR_0455_045B!{row_number}"
            row["source_row"] = row_number
            rows.append(row)
        if not rows:
            raise ValueError("No Record 1 layout rows were extracted from EDR_0455_045B.")
        return rows
    finally:
        workbook.close()


def _canonical_element_name(parameter_name: object) -> str:
    name = re.sub(r"^Record\s+1\s*-\s*", "", str(parameter_name or ""), flags=re.IGNORECASE).strip()
    return TRAILING_TIME_PATTERN.sub("", name).strip() or "Unnamed Record 1 element"


def _timestamp_seconds(parameter_name: object) -> float | None:
    match = TIME_PATTERN.search(str(parameter_name or ""))
    if not match:
        return None
    timestamp = float(match.group(1))
    return timestamp / 1000 if match.group(2).casefold().startswith("m") else timestamp


def _field_location(row: dict[str, Any]) -> str:
    byte_position = _integer_from_value(row.get("POS_IN_BYTES"))
    byte_length = _integer_from_value(row.get("LEN_IN_BYTES"))
    bit_position = _integer_from_value(row.get("POS_IN_BITS"))
    if byte_position is None:
        return "Not specified"
    if byte_length and byte_length > 1:
        location = f"bytes {byte_position}-{byte_position + byte_length - 1}"
    else:
        location = f"byte {byte_position}"
    return f"{location}, bit {bit_position}" if bit_position is not None else location


def _field_width(row: dict[str, Any]) -> str:
    bit_length = _integer_from_value(row.get("LEN_IN_BITS"))
    byte_length = _integer_from_value(row.get("LEN_IN_BYTES"))
    if bit_length:
        return f"{bit_length} bit"
    if byte_length:
        return f"{byte_length * 8} bit ({byte_length} byte)"
    return "Not specified"


def _range_summary(rows: list[dict[str, Any]]) -> str:
    minimum = next((row.get("MIN_VALUE") for row in rows if row.get("MIN_VALUE") not in {None, ""}), None)
    maximum = next((row.get("MAX_VALUE") for row in rows if row.get("MAX_VALUE") not in {None, ""}), None)
    if minimum is None and maximum is None:
        return "Not specified"
    return f"min={minimum}; max={maximum}"


def _sample_summary(rows: list[dict[str, Any]]) -> tuple[str, str, str, list[dict[str, Any]]]:
    timed_rows = []
    for row in rows:
        timestamp = _timestamp_seconds(row.get("PARAM_NAME"))
        if timestamp is not None:
            timed_rows.append({**row, "timestamp_seconds": timestamp})
    timestamps = sorted({row["timestamp_seconds"] for row in timed_rows})
    if not timestamps:
        return "Not specified", "Not specified", "Not specified", []
    periods = [round(later - earlier, 9) for earlier, later in zip(timestamps, timestamps[1:])]
    if not periods:
        period = "Not specified"
    elif len(set(periods)) == 1:
        period = f"{periods[0]:g} s"
    else:
        period = "Variable; inspect Timing Schedule sheet"
    interval = f"{timestamps[0]:g} s to {timestamps[-1]:g} s relative to T0"
    return str(len(timestamps)), period, interval, timed_rows


def _group_layout_rows(layout_rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in layout_rows:
        grouped.setdefault(_canonical_element_name(row.get("PARAM_NAME")), []).append(row)
    return dict(sorted(grouped.items(), key=lambda item: min(_integer_from_value(row.get("POS_IN_BYTES")) or 0 for row in item[1])))


def _load_tracker_requirements() -> dict[str, dict[str, Any]]:
    source_path = SOURCE_WORKBOOKS["u171_edr_requirements"]
    workbook = openpyxl.load_workbook(source_path, read_only=True, data_only=False)
    try:
        worksheet = workbook["Export"]
        headers = _workbook_headers(worksheet)
        identifier_index = headers.get("ID")
        status_index = headers.get("_ReqStatus")
        if identifier_index is None or status_index is None:
            raise ValueError("U171 EDR tracker lacks ID or _ReqStatus headers.")
        requirements: dict[str, dict[str, Any]] = {}
        for row_number, values in enumerate(worksheet.iter_rows(min_row=2, values_only=True), start=2):
            identifier = values[identifier_index]
            if identifier is None:
                continue
            requirements[str(identifier).strip()] = {
                "status": str(values[status_index] or "").strip(),
                "row": row_number,
            }
        return requirements
    finally:
        workbook.close()


def _approved_requirements(candidate_identifiers: list[str], tracker: dict[str, dict[str, Any]]) -> tuple[list[str], list[SourceProvenance]]:
    approved: list[str] = []
    provenance: list[SourceProvenance] = []
    for identifier in candidate_identifiers:
        record = tracker.get(identifier)
        if record is None or record["status"].casefold() != "approved":
            continue
        approved.append(identifier)
        provenance.append(
            SourceProvenance(
                source_path=str(SOURCE_WORKBOOKS["u171_edr_requirements"]),
                source_type="xlsx",
                location=f"Export!{record['row']}",
                sheet="Export",
                raw_status=record["status"],
            )
        )
    return approved, provenance


def _framework_mapping_hints() -> dict[str, str]:
    """Return exact U171 framework mapping hints, clearly distinct from authoritative DBC data."""
    can_map = _literal_assignment(U171_CAN_LIBRARY, "CAN_SIGNAL_Rx_MAP")["U171"]
    aliases = {
        "vehiclespeedlongitudinal": "VehSpdLgt",
        "vehiclespeedlongitudinalattimezero": "VehSpdLgtAtTimeZero",
        "batteryvoltage": "BattVolt",
        "odometer": "Odometer",
        "enginestate": "STS_ENG",
        "doorsopenstatus": "DoorsOpenStatus",
        "brakepedalstatus": "BRAKE_PEDAL_VALUE",
        "acceleratorpedalposition": "ACC_PED",
        "enginespeed": "Engine_Speed",
        "clutchstatus": "CLUTCH_STS",
        "steeringabsoluteangle": "STEERING_ABSOLUTE_ANGLE",
        "gearactual": "GEAR_ACTUAL",
        "vehicleyawrate": "YAW_RATE",
        "lateralacceleration": "LATERAL_ACCEL",
        "longitudinalacceleration": "LONG_ACCEL",
        "mastercylinderpressure": "Master_Cylinder_Pressure",
        "absactive": "ABS_ACTIVE",
        "escactive": "ESC_ACTIVE",
        "tcsactive": "TCS_ACTIVE_IEB",
        "tyrepressurefl": "Tyre_Pressure_FL",
        "tyrepressurefr": "Tyre_Pressure_FR",
        "tyrepressurerl": "Tyre_Pressure_RL",
        "tyrepressurerr": "Tyre_Pressure_RR",
    }
    hints: dict[str, str] = {}
    for alias, map_key in aliases.items():
        message_signal = can_map.get(map_key)
        if message_signal:
            hints[alias] = f"{message_signal[0]} / {message_signal[1]} (U171_CANLibrary framework hint only)"
    return hints


def _literal_dict_fields(value: ast.AST, allowed_fields: set[str]) -> dict[str, Any]:
    if not isinstance(value, ast.Dict):
        return {}
    fields: dict[str, Any] = {}
    for key, field_value in zip(value.keys, value.values):
        if not isinstance(key, ast.Constant) or not isinstance(key.value, str) or key.value not in allowed_fields:
            continue
        try:
            fields[key.value] = ast.literal_eval(field_value)
        except (TypeError, ValueError):
            continue
    return fields


def _canc_edr_definitions() -> list[dict[str, Any]]:
    """Read literal EDR-to-CAN definitions without importing framework runtime dependencies."""
    source_tree = ast.parse(U171_CANC_CONFIG.read_text(encoding="utf-8"), filename=str(U171_CANC_CONFIG))
    definitions: dict[str, dict[str, Any]] = {}
    published_symbols: set[str] = set()
    for statement in source_tree.body:
        if not isinstance(statement, ast.Assign) or len(statement.targets) != 1 or not isinstance(statement.targets[0], ast.Name):
            continue
        symbol = statement.targets[0].id
        if symbol == "MAH_CAN_SIGNAL_DEFS" and isinstance(statement.value, ast.Dict):
            for value in statement.value.values:
                if isinstance(value, ast.Name):
                    published_symbols.add(value.id)
            continue
        if not symbol.startswith("CAN_"):
            continue
        fields = _literal_dict_fields(statement.value, {"frame", "signal", "EDR_Parameter"})
        if {"frame", "signal", "EDR_Parameter"} <= fields.keys():
            definitions[symbol] = {"symbol": symbol, **fields}
    return [{**definition, "published": definition["symbol"] in published_symbols} for definition in definitions.values()]


def _message_key_nodes() -> dict[str, set[str]]:
    source_tree = ast.parse(U171_CAN_LIBRARY.read_text(encoding="utf-8"), filename=str(U171_CAN_LIBRARY))
    key_nodes: dict[str, set[str]] = {}
    for statement in source_tree.body:
        if not isinstance(statement, ast.Assign) or not any(
            isinstance(target, ast.Name) and target.id == "CAN_TX_MESSAGE_CONFIG" for target in statement.targets
        ):
            continue
        if not isinstance(statement.value, ast.Dict):
            continue
        for message_key, message_value in zip(statement.value.keys, statement.value.values):
            if not isinstance(message_key, ast.Constant) or not isinstance(message_key.value, str):
                continue
            fields = _literal_dict_fields(message_value, {"key_node"})
            node = fields.get("key_node")
            if isinstance(node, str):
                key_nodes.setdefault(message_key.value, set()).add(node)
    return key_nodes


def _format_choice_values(choices: list[tuple[str, str]]) -> str:
    return "; ".join(f"{raw}={label}" for raw, label in choices) if choices else "Not specified"


def _load_dbc_context() -> dict[str, Any]:
    """Load authoritative U171 DBC metadata and correlate it with static configuration evidence."""
    if not U171_DBC.is_file():
        raise FileNotFoundError(U171_DBC)
    database = cantools.database.load_file(U171_DBC)
    routes: dict[tuple[str, str], dict[str, Any]] = {}
    for message in database.messages:
        for signal in message.signals:
            choices = [(str(raw), str(label)) for raw, label in (signal.choices or {}).items()]
            routes[(message.name, signal.name)] = {
                "message": message.name,
                "signal": signal.name,
                "can_id": f"0x{message.frame_id:X}",
                "dlc": message.length,
                "senders": list(message.senders),
                "cycle_time_ms": message.cycle_time,
                "is_extended_frame": message.is_extended_frame,
                "start_bit": signal.start,
                "bit_length": signal.length,
                "byte_order": signal.byte_order,
                "signed": signal.is_signed,
                "factor": signal.scale,
                "offset": signal.offset,
                "minimum": signal.minimum,
                "maximum": signal.maximum,
                "unit": signal.unit,
                "choices": choices,
                "initial": None if signal.initial is None else str(signal.initial),
                "invalid": None if signal.invalid is None else str(signal.invalid),
                "multiplexer_signal": signal.multiplexer_signal,
                "multiplexer_ids": signal.multiplexer_ids,
            }
    variant_defaults = _literal_assignment(U171_VARIANT_CONFIG, "project_defaults")
    return {
        "path": U171_DBC,
        "sha256": _sha256(U171_DBC),
        "message_count": len(database.messages),
        "network_nodes": sorted(node.name for node in database.nodes),
        "routes": routes,
        "can_map": _literal_assignment(U171_CAN_LIBRARY, "CAN_SIGNAL_Rx_MAP")["U171"],
        "canc_definitions": _canc_edr_definitions(),
        "key_nodes": _message_key_nodes(),
        "enabled_nodes": set(variant_defaults["U171"]["enabled_nodes"]),
    }


def _route_for_element(element_name: str, context: dict[str, Any]) -> dict[str, Any] | None:
    framework_key = ELEMENT_TO_FRAMEWORK_KEY.get(_normalize_name(element_name))
    if framework_key is None:
        return None
    message_signal = context["can_map"].get(framework_key)
    if message_signal is None:
        return {
            "framework_key": framework_key,
            "message": None,
            "signal": None,
            "dbc": None,
            "config_status": "No U171_CANLibrary message/signal mapping is defined for this EDR element.",
            "explicitly_enabled": False,
            "canc_sources": [],
        }
    message, signal = message_signal
    dbc = context["routes"].get((message, signal))
    key_nodes = context["key_nodes"].get(message, set())
    enabled_nodes = context["enabled_nodes"]
    if dbc is None:
        config_status = f"U171 configuration maps {message}/{signal}, but the route is absent from the raw U171 DBC."
        explicitly_enabled = False
    elif len(key_nodes) == 1 and next(iter(key_nodes)) in enabled_nodes:
        node = next(iter(key_nodes))
        config_status = f"Enabled: U171 variant default lists {node}; U171 CAN configuration maps {message} to {node}."
        explicitly_enabled = True
    elif len(key_nodes) == 1:
        node = next(iter(key_nodes))
        config_status = f"DBC route verified, but U171 variant default does not explicitly list configured node {node}."
        explicitly_enabled = False
    elif key_nodes:
        config_status = f"DBC route verified, but U171 CAN configuration has conflicting key-node assignments: {', '.join(sorted(key_nodes))}."
        explicitly_enabled = False
    else:
        config_status = "DBC route verified, but no unique U171 CAN configuration key-node evidence was found."
        explicitly_enabled = False
    cancellable_sources = [
        definition
        for definition in context["canc_definitions"]
        if definition["frame"] == message and definition["signal"] == signal
    ]
    return {
        "framework_key": framework_key,
        "message": message,
        "signal": signal,
        "dbc": dbc,
        "config_status": config_status,
        "explicitly_enabled": explicitly_enabled,
        "canc_sources": cancellable_sources,
    }


def _choice_categories(dbc: dict[str, Any]) -> str:
    choices = dbc["choices"]
    invalid = [(raw, label) for raw, label in choices if "invalid" in label.casefold()]
    reserved = [(raw, label) for raw, label in choices if "reserved" in label.casefold()]
    defaults = [(raw, label) for raw, label in choices if "default" in label.casefold()]
    enumeration = _format_choice_values(choices)
    categories = [f"enum={enumeration}"]
    if invalid:
        categories.append(f"invalid={_format_choice_values(invalid)}")
    if reserved:
        categories.append(f"reserved={_format_choice_values(reserved)}")
    if defaults:
        categories.append(f"default={_format_choice_values(defaults)}")
    if dbc["initial"] is not None:
        categories.append(f"initial={dbc['initial']}")
    return "; ".join(categories)


def _float_value(value: object) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _encoding_assessment(
    element_name: str,
    rows: list[dict[str, Any]],
    route: dict[str, Any] | None,
    *,
    is_reserved: bool,
) -> tuple[str, str, str]:
    if is_reserved:
        return (
            "0x0 at each applicable reserved field width.",
            "Static encoding verification only.",
            "Reserved EDR field; no functional CAN test is generated.",
        )
    if route is None:
        return (
            "Not specified: no verified EDR-to-CAN route.",
            "Functional CAN test withheld pending a source mapping.",
            "The common layout does not provide a Reference CAN Signal and no configured alias was verified.",
        )
    dbc = route["dbc"]
    if dbc is None:
        return (
            "Not specified: configured route is absent from the raw U171 DBC.",
            "Static review only; DBC route mismatch.",
            route["config_status"],
        )
    if _normalize_name(element_name) == "odometer":
        return (
            "20-bit raw integer stored in three DID bytes; tracker defines the upper four bits of the first byte as reserved zero and the numeric value MSB-first.",
            "Detailed nominal Odometer case is in review; invalid/fallback behavior remains excluded.",
            "The common Record 1 layout uses bytes 7-9 while the approved tracker cites response bytes 11-13; the four-byte response-header relation is an inference requiring capture confirmation.",
        )
    first_row = rows[0]
    edr_bits = _integer_from_value(first_row.get("LEN_IN_BITS"))
    if edr_bits is None:
        byte_length = _integer_from_value(first_row.get("LEN_IN_BYTES"))
        edr_bits = byte_length * 8 if byte_length else None
    edr_scale = _float_value(first_row.get("RESOLUTION"))
    edr_offset = _float_value(first_row.get("OFFSET"))
    edr_type = str(first_row.get("DATA_TYPE") or "").casefold()
    edr_signed = edr_type == "signed"
    if edr_bits == dbc["bit_length"] and edr_scale is not None and edr_offset is not None and (
        abs(edr_scale - dbc["factor"]) < 1e-12 and abs(edr_offset - dbc["offset"]) < 1e-12 and edr_signed == dbc["signed"]
    ):
        return (
            "Canonical raw integer is numerically compatible with the EDR resolution and offset; apply the EDR record byte/bit layout instead of copying CAN payload bytes.",
            "DBC-backed relation recorded; functional case requires approved element-specific requirement and applicable-node evidence.",
            "No direct CAN-payload byte comparison is authorized because CAN and EDR bit/byte serialization differ.",
        )
    return (
        "Not specified: DBC and EDR encoding are not directly compatible without an approved conversion rule.",
        "Functional stored-value assertion withheld pending conversion/layout reconciliation.",
        "DBC route is available, but the EDR width, signedness, factor, or offset differs from the common layout.",
    )


def _layout_matrix(layout_rows: list[dict[str, Any]]) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    grouped = _group_layout_rows(layout_rows)
    dbc_context = _load_dbc_context()
    matrix: list[dict[str, str]] = []
    timing_schedule: list[dict[str, str]] = []
    for element_name, rows in grouped.items():
        field_locations = sorted({_field_location(row) for row in rows})
        sample_count, sample_period, recording_interval, timed_rows = _sample_summary(rows)
        is_reserved = "reserv" in _normalize_name(element_name)
        route = _route_for_element(element_name, dbc_context)
        dbc = route["dbc"] if route else None
        if is_reserved:
            classification = "Reserved"
            requirement_id = RECORD_1_RESERVED_REQUIREMENT
        elif route is None:
            classification = "Unclassified: no verified EDR-to-DBC mapping"
            requirement_id = "Not specified"
        elif dbc is None:
            classification = "Not Present: configured message/signal route absent from raw U171 DBC"
            requirement_id = "Not specified"
        elif route["explicitly_enabled"]:
            classification = "Applicable"
            requirement_id = RECORD_1_ODOMETER_REQUIREMENT if _normalize_name(element_name) == "odometer" else "Not specified"
        else:
            classification = "Unclassified: DBC route verified; variant enablement not proven"
            requirement_id = RECORD_1_SPEED_AT_T0_REQUIREMENT if _normalize_name(element_name) == "vehiclespeedlongitudinalattimezero" else "Not specified"
        expected_encoding, coverage_decision, data_gap = _encoding_assessment(
            element_name,
            rows,
            route,
            is_reserved=is_reserved,
        )
        if route is None:
            framework_hint = "Not specified"
            config_status = "Not specified: no verified U171 configuration mapping."
            dbc_message_presence = "Not specified: no verified EDR-to-DBC mapping"
            dbc_message_signal = "Not specified"
            can_metadata = "Not specified"
            dbc_bit_metadata = "Not specified"
            dbc_value_metadata = "Not specified"
            dbc_choice_metadata = "Not specified"
        elif dbc is None:
            framework_hint = f"U171_CANLibrary key {route['framework_key']}: {route['message']} / {route['signal']}"
            config_status = route["config_status"]
            dbc_message_presence = "Not Present: configured route is absent from raw U171 DBC"
            dbc_message_signal = f"{route['message']} / {route['signal']}"
            can_metadata = "Not specified: route absent from raw U171 DBC"
            dbc_bit_metadata = "Not specified"
            dbc_value_metadata = "Not specified"
            dbc_choice_metadata = "Not specified"
        else:
            canc_sources = "; ".join(
                f"{definition['symbol']} ({'MAH_CAN_SIGNAL_DEFS' if definition['published'] else 'direct config only'})"
                for definition in route["canc_sources"]
            ) or "No matching canc_config.py EDR definition"
            sender = ", ".join(dbc["senders"]) if dbc["senders"] else "Not specified by DBC"
            multiplexing = (
                f"mux signal={dbc['multiplexer_signal']}; ids={dbc['multiplexer_ids']}"
                if dbc["multiplexer_signal"] or dbc["multiplexer_ids"]
                else "not multiplexed"
            )
            framework_hint = (
                f"U171_CANLibrary key {route['framework_key']}: {route['message']} / {route['signal']}; "
                f"canc_config.py: {canc_sources}"
            )
            config_status = route["config_status"]
            dbc_message_presence = "Present: U171 configuration route and raw U171 DBC agree"
            dbc_message_signal = f"{dbc['message']} / {dbc['signal']}"
            can_metadata = (
                f"CAN ID={dbc['can_id']}; sender={sender}; DLC={dbc['dlc']}; "
                f"cycle={dbc['cycle_time_ms']} ms; {multiplexing}"
            )
            dbc_bit_metadata = (
                f"start bit={dbc['start_bit']}; length={dbc['bit_length']}; "
                f"byte order={dbc['byte_order']}; signed={dbc['signed']}"
            )
            dbc_value_metadata = (
                f"factor={dbc['factor']}; offset={dbc['offset']}; "
                f"min={dbc['minimum']}; max={dbc['maximum']}; unit={dbc['unit']}"
            )
            dbc_choice_metadata = _choice_categories(dbc)
        matrix.append(
            {
                "DID / Record": "0x0455 / Record 1",
                "EDR Element": element_name,
                "EDR field location / width": "; ".join(field_locations),
                "Exact common source reference": f"ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx!EDR_0455_045B!{min(row['source_row'] for row in rows)}-{max(row['source_row'] for row in rows)}",
                "Configuration status": config_status,
                "Classification": classification,
                "DBC message presence": dbc_message_presence,
                "DBC message / signal": dbc_message_signal,
                "CAN ID / sender / cycle / multiplexing": can_metadata,
                "DBC bit length / byte order / signedness": dbc_bit_metadata,
                "DBC factor / offset / physical range": dbc_value_metadata,
                "DBC enumeration / invalid / reserved / default": dbc_choice_metadata,
                "Framework mapping hint": framework_hint,
                "EDR resolution / offset / range": (
                    f"resolution={next((row.get('RESOLUTION') for row in rows if row.get('RESOLUTION') not in {None, ''}), 'Not specified')}; "
                    f"offset={next((row.get('OFFSET') for row in rows if row.get('OFFSET') not in {None, ''}), 'Not specified')}; "
                    f"{_range_summary(rows)}"
                ),
                "EDR data type / format / unit": (
                    f"type={next((row.get('DATA_TYPE') for row in rows if row.get('DATA_TYPE') not in {None, ''}), 'Not specified')}; "
                    f"format={next((row.get('DATA_FORMAT') for row in rows if row.get('DATA_FORMAT') not in {None, ''}), 'Not specified')}; "
                    f"unit={next((row.get('UNIT') for row in rows if row.get('UNIT') not in {None, ''}), 'Not specified')}"
                ),
                "Sample count": sample_count,
                "Sample period": sample_period,
                "Recording interval": recording_interval,
                "Crash / trigger reference": "Generic EDR trigger is source-defined; no element-specific binding supplied",
                "Requirement ID": requirement_id,
                "Requirement source": (
                    "DES_SW_Mahindra_EDR .xlsx!Export!334 (Approved)"
                    if is_reserved
                    else (
                        "DES_SW_Mahindra_EDR .xlsx!Export!58 (Approved)"
                        if requirement_id == RECORD_1_ODOMETER_REQUIREMENT
                        else (
                            "DES_SW_Mahindra_EDR .xlsx!Export!45 (Approved)"
                            if requirement_id == RECORD_1_SPEED_AT_T0_REQUIREMENT
                            else "Not specified: common diagnostic source has no Codebeamer ID"
                        )
                    )
                ),
                "Expected stored value": expected_encoding,
                "Coverage decision": coverage_decision,
                "Data gap / rationale": data_gap,
            }
        )
        for sample_index, row in enumerate(sorted(timed_rows, key=lambda value: value["timestamp_seconds"])):
            timing_dbc = _route_for_element(element_name, dbc_context)
            timing_signal = timing_dbc["dbc"] if timing_dbc else None
            timing_schedule.append(
                {
                    "DID / Record": "0x0455 / Record 1",
                    "EDR Element": element_name,
                    "Sample index": str(sample_index),
                    "Target timestamp": f"{row['timestamp_seconds']:g} s relative to T0",
                    "EDR field location": _field_location(row),
                    "EDR field width": _field_width(row),
                    "Injected CAN raw value": "Not specified: no source-approved time-indexed test vector",
                    "Decoded raw integer": "Not specified: no source-approved time-indexed test vector",
                    "CAN factor / offset": (
                        f"factor={timing_signal['factor']}; offset={timing_signal['offset']}"
                        if timing_signal else "Not specified: no verified EDR-to-DBC mapping"
                    ),
                    "Physical value": (
                        f"range={timing_signal['minimum']} to {timing_signal['maximum']} {timing_signal['unit']}"
                        if timing_signal else "Not specified: no verified EDR-to-DBC mapping"
                    ),
                    "Expected stored encoding": "Not specified: no approved time-indexed CAN-to-EDR conversion assertion",
                    "Source reference": row["source_reference"],
                }
            )

    matrix.append(
        {
            "DID / Record": "0x045B / Record 2",
            "EDR Element": "Record 2 field layout",
            "EDR field location / width": "Not specified",
            "Exact common source reference": "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx!ECUIdentifiers!159",
            "Configuration status": "Not classified: no complete Record 2 source-to-signal layout is available.",
            "Classification": "Unclassified: Record 2 full layout unavailable",
            "DBC message presence": "U171 DBC is available, but no complete Record 2 field map is supplied",
            "DBC message / signal": "Not specified",
            "CAN ID / sender / cycle / multiplexing": "Not specified",
            "DBC bit length / byte order / signedness": "Not specified",
            "DBC factor / offset / physical range": "Not specified",
            "DBC enumeration / invalid / reserved / default": "Not specified",
            "Framework mapping hint": "Not specified",
            "EDR resolution / offset / range": "Not specified",
            "EDR data type / format / unit": "Not specified",
            "Sample count": "Not specified",
            "Sample period": "Not specified",
            "Recording interval": "Not specified",
            "Crash / trigger reference": "Generic EDR trigger source is not explicitly bound to Record 2",
            "Requirement ID": RECORD_2_ACCESS_REQUIREMENT,
            "Requirement source": "DES_SW_Mahindra_EDR .xlsx!Export!699 (Approved)",
            "Expected stored value": "Not specified",
            "Coverage decision": "No functional or static field-encoding test until Record 2 layout is supplied",
            "Data gap / rationale": "The provided EDR_0455_045B sheet contains no 0x045B field rows; approved tracker rows can support only narrow element-level cases.",
        }
    )
    odometer_route = _route_for_element("Odometer", dbc_context)
    odometer_dbc = odometer_route["dbc"] if odometer_route else None
    if odometer_dbc is not None:
        sender = ", ".join(odometer_dbc["senders"]) if odometer_dbc["senders"] else "Not specified by DBC"
        matrix.append(
            {
                "DID / Record": "0x045B / Record 2",
                "EDR Element": "Odometer",
                "EDR field location / width": "Approved tracker response bytes 11-13; 20-bit value with upper four bits reserved zero",
                "Exact common source reference": "DES_SW_Mahindra_EDR .xlsx!Export!713; complete Record 2 common layout unavailable",
                "Configuration status": odometer_route["config_status"],
                "Classification": "Applicable",
                "DBC message presence": "Present: U171 configuration route and raw U171 DBC agree",
                "DBC message / signal": f"{odometer_dbc['message']} / {odometer_dbc['signal']}",
                "CAN ID / sender / cycle / multiplexing": f"CAN ID={odometer_dbc['can_id']}; sender={sender}; DLC={odometer_dbc['dlc']}; cycle={odometer_dbc['cycle_time_ms']} ms; not multiplexed",
                "DBC bit length / byte order / signedness": f"start bit={odometer_dbc['start_bit']}; length={odometer_dbc['bit_length']}; byte order={odometer_dbc['byte_order']}; signed={odometer_dbc['signed']}",
                "DBC factor / offset / physical range": f"factor={odometer_dbc['factor']}; offset={odometer_dbc['offset']}; min={odometer_dbc['minimum']}; max={odometer_dbc['maximum']}; unit={odometer_dbc['unit']}",
                "DBC enumeration / invalid / reserved / default": _choice_categories(odometer_dbc),
                "Framework mapping hint": "U171_CANLibrary key Odometer: IC2_100 / ODOMTR_READING; canc_config.py: CAN_ODOMETER (MAH_CAN_SIGNAL_DEFS)",
                "EDR resolution / offset / range": "resolution=1; offset=0; min=0; max=999999",
                "EDR data type / format / unit": "type=UNSIGNED; format=MSB-first tracker bit map; unit=Km",
                "Sample count": "1",
                "Sample period": "Not applicable",
                "Recording interval": "0 ms relative to T0",
                "Crash / trigger reference": "Approved tracker describes live IC2_100 data at T0; trigger mechanism is outside the supplied field requirement",
                "Requirement ID": RECORD_2_ODOMETER_REQUIREMENT,
                "Requirement source": "DES_SW_Mahindra_EDR .xlsx!Export!713 (Approved)",
                "Expected stored value": "20-bit raw integer stored across the three tracker-defined bytes with upper nibble zero; do not copy CAN byte order directly.",
                "Coverage decision": "Detailed nominal Odometer case is in review; invalid/fallback and full Record 2 layout coverage remain excluded.",
                "Data gap / rationale": "The full Record 2 common layout is unavailable. The field-level tracker evidence supports only this narrow nominal case.",
            }
        )
    return matrix, timing_schedule


def _data_gaps() -> list[dict[str, str]]:
    return [
        {
            "ID": "G-01",
            "Severity": "Major",
            "Gap / conflict": "The U171 DBC does not identify external sender ECUs for the relevant messages.",
            "Evidence": "U171_SRS_SVNID39216_20250917.dbc defines only node SRS; cantools reports empty sender lists for IC, MBFM, EPS/SAS, ESC, EMS, TCU, HPC, and FRM source messages.",
            "Impact": "The specification can cite message routes but cannot claim independent DBC sender-ECU ownership.",
            "Disposition": "Use the configured node label only as corroborating configuration evidence and obtain the network ownership matrix when sender attribution is required.",
        },
        {
            "ID": "G-02",
            "Severity": "Blocking",
            "Gap / conflict": "A complete Record 2 (0x045B) field layout is absent.",
            "Evidence": "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx!EDR_0455_045B has 1,072 rows for 0x0455 and none for 0x045B. Approved tracker row 713 supplies only a narrow Odometer field definition.",
            "Impact": "Record 2 offsets, widths, samples, and stored encodings cannot be generalized beyond explicitly supplied tracker rows.",
            "Disposition": "Retain only DID access and the narrow Odometer nominal case; do not derive other Record 2 fields from Record 1.",
        },
        {
            "ID": "G-03",
            "Severity": "Major",
            "Gap / conflict": "Default stored encoding is unreconciled: 0xFF versus 0xFFFE.",
            "Evidence": "Common layout note at EDR_0455_045B!3 says 0xFF; Approved tracker rows 46/701 specify 0xFFFE for vehicle-speed fallback.",
            "Impact": "Fallback expected values must not be asserted.",
            "Disposition": "Require a field-width and fault-condition clarification before execution.",
        },
        {
            "ID": "G-04",
            "Severity": "Major",
            "Gap / conflict": "Approved multi-event timing statements conflict: >500 ms versus >800 ms.",
            "Evidence": "Approved tracker rows 33 and 1486; common EDR_Requirements!32 aligns with >500 ms.",
            "Impact": "Multi-event qualification timing cannot be made an execution pass criterion.",
            "Disposition": "Obtain approved requirement clarification; do not derive a threshold.",
        },
        {
            "ID": "G-05",
            "Severity": "Major",
            "Gap / conflict": "Record 1 position convention differs by four bytes between tracker and common layout.",
            "Evidence": "Tracker access/fallback positions begin at bytes 4/8; common EDR_0455_045B begins lifetime event at byte 0 and speed at byte 4.",
            "Impact": "DID payload-to-layout alignment is ambiguous.",
            "Disposition": "Require a response-header/offset definition before byte-level checks.",
        },
        {
            "ID": "G-06",
            "Severity": "Major",
            "Gap / conflict": "Record 1 layout sources contain unresolved internal discrepancies.",
            "Evidence": "DRBFM reports eCall sample duplication, low/high-beam bit overlap, AEB timestamp anomaly, and Y-angular offset mismatch.",
            "Impact": "Affected field-level expected encodings are not execution-ready.",
            "Disposition": "Reconcile V1.4 common spec with the DRBFM revision before authoring field assertions.",
        },
        {
            "ID": "G-07",
            "Severity": "Major",
            "Gap / conflict": "Variant code does not expose a source-node-to-bit mapping for individual EDR elements.",
            "Evidence": "projects/U171/config/variantcode_config.py declares enabled-node labels and bytes, not the authoritative bit mapping.",
            "Impact": "Applicable, Deconfigured, and Not Present classifications cannot be proved.",
            "Disposition": "Provide the U171 variant-code mapping or generated configuration evidence.",
        },
        {
            "ID": "G-08",
            "Severity": "Medium",
            "Gap / conflict": "No approved diagnostic capture or DID response fixture was supplied.",
            "Evidence": "Only requirement/configuration workbooks and local source files were reviewed.",
            "Impact": "No actual payload length, conversion, or runtime behavior is verified.",
            "Disposition": "Use a controlled offline capture/fixture after source reconciliation; no bench operation was performed.",
        },
        {
            "ID": "G-09",
            "Severity": "Major",
            "Gap / conflict": "U171 framework mappings and the DBC are not fully aligned.",
            "Evidence": "The U171_CANLibrary mapping has five configured messages and two configured signals absent from the added DBC; the EDR-oriented canc_config mapping has additional absent routes and duplicate/alias inconsistencies.",
            "Impact": "A configured route is not itself proof that a field is available in this DBC revision.",
            "Disposition": "Only matrix routes with exact configuration and DBC agreement may support a test case. Treat absent routes as Not Present or unclassified according to their evidence.",
        },
        {
            "ID": "G-10",
            "Severity": "Major",
            "Gap / conflict": "Several DBC-to-EDR encodings are not direct raw-value copies.",
            "Evidence": "Examples include Record 1 versus DBC differences for engine speed, yaw rate, lateral/longitudinal acceleration, packed Boolean/state fields, and the separate BattVolt versus BATT_VOLT definitions.",
            "Impact": "Raw CAN payload bytes or source raw values cannot be used as EDR expected bytes without a verified field conversion and packing rule.",
            "Disposition": "Assert only the Odometer nominal conversion currently evidenced; retain all other conversion-dependent tests in review or on hold.",
        },
    ]


def _choose_technique(allowed_values: dict[str, list[str]], candidates: list[str]) -> str:
    available = allowed_values.get("_TestTechnique", [])
    for candidate in candidates:
        if candidate in available:
            return candidate
    if not available:
        raise ValueError("The template provides no _TestTechnique choices.")
    return available[0]


def _case_description(
    *,
    element: str,
    did: str,
    field_location: str,
    sample_detail: str,
    expected_encoding: str,
    traceability: str,
    gap: str,
    dbc_message: str = "Not specified for this element.",
    dbc_signal: str = "Not specified for this element.",
    presence_status: str = "ON HOLD: evidence is insufficient to classify the source as Applicable, Deconfigured, Reserved, or Not Present.",
    can_metadata: str = "Not specified for this element.",
    test_data: str = "Not specified.",
) -> str:
    return "\n".join(
        [
            f"EDR Element Name: {element}",
            f"DBC Message: {dbc_message}",
            f"DBC Signal: {dbc_signal}",
            f"Presence Status: {presence_status}",
            f"Associated DID / Record: {did}",
            f"EDR Field Location / Width: {field_location}",
            f"CAN Factor / Offset / Min-Max Physical: {can_metadata}",
            f"Recording Interval / Sample Count: {sample_detail}",
            f"Test Data: {test_data}",
            f"Expected Stored Encoding: {expected_encoding}",
            f"Exact Requirement Traceability: {traceability}",
            f"Blocking Evidence Gap: {gap}",
        ]
    )


def _build_test_cases(
    tracker: dict[str, dict[str, Any]],
    allowed_values: dict[str, list[str]],
    matrix: list[dict[str, str]],
) -> list[TestCase]:
    technique = _choose_technique(allowed_values, ["Boundary Value Analysis", "Equivalence Classes"])
    decision_technique = _choose_technique(allowed_values, ["Decision Table Testing", technique])
    record_1_rows = [row for row in matrix if row["DID / Record"] == "0x0455 / Record 1"]
    reserved_rows = [row for row in record_1_rows if row["Classification"] == "Reserved"]
    region_definitions = [
        ("HEADER", "Record 1 fixed header", 0, 29, "Static field-decoding review; no CAN stimulus is authored."),
        ("HISTORY", "Record 1 vehicle and control histories", 30, 164, "Timing schedule is provided separately; raw/physical inputs remain unspecified."),
        ("CRASH", "Record 1 deployment, status, and Delta-V fields", 165, 276, "Static layout review only; no crash action is authorized or generated."),
        ("DYNAMICS", "Record 1 tyre and dynamics histories", 277, 565, "Static layout review only; source-CAN conversion remains unavailable."),
        ("ADAS", "Record 1 ADAS and vehicle-state histories", 566, 849, "Static layout review only; source-CAN conversion remains unavailable."),
        ("TAIL", "Record 1 tail fields", 850, 882, "Static layout review only; source-CAN conversion remains unavailable."),
    ]
    cases: list[TestCase] = []

    def append_case(
        case_id: str,
        priority: str,
        description: str,
        requirement_candidates: list[str],
        steps: list[TestStep],
        methodology: str = technique,
        status: str = "ON HOLD",
        pre_action: str | None = None,
        post_action: str | None = None,
        generation_note: str | None = None,
    ) -> None:
        requirement_ids, source_requirements = _approved_requirements(requirement_candidates, tracker)
        if not requirement_ids:
            raise ValueError(f"No approved source requirement found for {case_id}.")
        cases.append(
            TestCase(
                name=case_id,
                description=description,
                steps=steps,
                methodology=TestMethodology(
                    primary_technique=methodology,
                    rationale="The specification includes only source-backed CAN metadata and retains unresolved layout or applicability evidence as explicit gaps.",
                ),
                requirement_ids=requirement_ids,
                pre_action=pre_action or "ON HOLD: reconcile the remaining variant applicability and EDR record-layout evidence. Do not transmit or trigger a crash while this specification is in review.",
                post_action=post_action or "No bench action is performed by this review specification. Preserve source revisions and review evidence.",
                priority=priority,
                status=status,
                item_type="Functional",
                project="U171",
                latest_result="NOT YET TESTED",
                test_type="Manual",
                verification_method="Requirements-based test",
                source_requirements=source_requirements,
                generation_notes=[generation_note or "The case remains constrained by the gaps recorded in the evidence report."],
            )
        )

    append_case(
        "EDR-U171-ICE-R1-DID_ACCESS-STATIC-001",
        "Highest",
        _case_description(
            element="Record 1 diagnostic access",
            did="0x0455 / Record 1",
            field_location="Response layout begins at a source-unreconciled offset convention",
            sample_detail="Not applicable",
            expected_encoding="Positive $22 response and record payload only after source-controlled access conditions are verified",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!44, ID 34856976, Approved",
            gap="The U171 DBC confirms diagnostic route 0x730 to 0x738, but the DID response-header/offset convention and complete session evidence remain unresolved.",
        ),
        [RECORD_1_ACCESS_REQUIREMENT],
        [
            TestStep("Verify the approved U171 Record 1 DID-access requirement and its stated security/session conditions.", "The evidence package identifies DID 0x0455 and source requirement 34856976; no undocumented request-frame or response-length assumption is made.", True),
            TestStep("After required source gaps are closed, issue the source-authorized ReadDataByIdentifier request for 0x0455 in a controlled test environment.", "The returned record can be aligned to the approved Record 1 byte-position convention; until then, the case remains ON HOLD.", True),
        ],
    )

    for sequence, (category, label, lower, upper, sample_detail) in enumerate(region_definitions, start=2):
        covered = [
            row for row in record_1_rows
            if any(lower <= int(number) <= upper for number in re.findall(r"\d+", row["EDR field location / width"]))
        ]
        append_case(
            f"EDR-U171-ICE-R1-{category}-STATIC-{sequence:03d}",
            "High",
            _case_description(
                element=label,
                did="0x0455 / Record 1",
                field_location=f"bytes {lower}-{upper}; {len(covered)} grouped layout elements in Investigation Matrix",
                sample_detail=sample_detail,
                expected_encoding="Decode each field only according to the common layout; CAN raw/physical inputs are intentionally not fabricated.",
                traceability="ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx!EDR_0455_045B; DID access: DES_SW_Mahindra_EDR .xlsx!Export!44, ID 34856976, Approved",
                gap="The U171 DBC now supplies many CAN routes, but not every field has an exact mapping, enabled-node proof, and reconciled CAN-to-EDR conversion.",
            ),
            [RECORD_1_ACCESS_REQUIREMENT],
            [
                TestStep("Review the Investigation Matrix rows within the stated byte interval, preserving every source byte/bit location and resolution.", "All source-defined Record 1 fields in scope have a provenance reference; a field is treated as Applicable only when its exact DBC route and variant enabled-node evidence are both verified.", True),
                TestStep("After DBC and layout reconciliation, compare a recorded 0x0455 response against each matrix field in this interval.", "Every assertion uses the verified source-CAN raw pattern, decoded raw integer, factor, offset, physical value, and EDR stored encoding; no unsupported value is asserted.", True),
            ],
        )

    append_case(
        "EDR-U171-ICE-R1-RESERVED_STATIC-008",
        "Highest",
        _case_description(
            element="Record 1 reserved fields and bits",
            did="0x0455 / Record 1",
            field_location=f"{len(reserved_rows)} grouped reserved layout element(s); see Investigation Matrix",
            sample_detail="Not applicable",
            expected_encoding="0x0 at each applicable reserved field width",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!334, ID 34885285, Approved; common EDR layout reserved rows",
            gap="The record-header offset convention still requires reconciliation before physical DID-byte assertions.",
        ),
        [RECORD_1_RESERVED_REQUIREMENT],
        [
            TestStep("Identify every matrix row classified Reserved and retain its source field width and byte/bit location.", "Reserved rows are treated as static encoding only; no CAN stimulus or fault injection is designed.", True),
            TestStep("After Record 1 response-offset reconciliation, inspect each reserved field/bits in the captured DID payload.", "Every reserved field is encoded as zero at its stated field width; any nonzero reserved encoding is a review finding.", True),
        ],
    )

    append_case(
        "EDR-U171-ICE-R1-VEHICLE_SPEED-FALLBACK-ON_HOLD-009",
        "Highest",
        _case_description(
            element="Record 1 vehicle-speed fallback behavior",
            did="0x0455 / Record 1",
            field_location="Common layout speed-at-T0 bytes 4-5; sampled speed source layout requires offset reconciliation",
            sample_detail="Source timing exists but raw U171 CAN encoding is unavailable",
            expected_encoding="Not asserted: approved tracker says 0xFFFE for defined faults, while common layout note states 0xFF for default/deconfigured signals",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!46, 49, 51-55, Approved",
            gap="Conflict G-03 and missing variant applicability/field-level fallback conversion evidence prohibit fault stimulus and expected-value generation.",
        ),
        RECORD_1_FALLBACK_REQUIREMENTS,
        [
            TestStep("Review the approved Record 1 vehicle-speed fault/fallback rows and the common layout default note.", "The 0xFF versus 0xFFFE conflict is documented as a blocking discrepancy; no value is selected by assumption.", True),
            TestStep("After clarification and DBC delivery, derive a source-authorized CAN fault stimulus and corresponding EDR stored encoding.", "The finalized case covers only the explicitly applicable fault conditions and records padded CAN raw hex, decoded raw integer, scaling, physical value, and stored encoding.", True),
        ],
        decision_technique,
    )

    append_case(
        "EDR-U171-ICE-R1-LIFECYCLE-ON_HOLD-010",
        "Highest",
        _case_description(
            element="Record 1 recording lifecycle",
            did="0x0455 / Record 1",
            field_location="Record-level behavior",
            sample_detail="Element-specific sample plan is captured in the Investigation Matrix and Timing Schedule",
            expected_encoding="Not applicable",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!23, 26, 28, 29, 31, 34, 35, 40, Approved; application to Record 1 is an evidence-backed inference requiring record binding confirmation",
            gap="Multi-event threshold conflict and no explicit generic-to-Record-1 binding prevent executable timing criteria.",
        ),
        GENERIC_EDR_LIFECYCLE_REQUIREMENTS,
        [
            TestStep("Review generic EDR enablement, T0, event-number, storage, power-loss, and trigger requirements against the selected Record 1 source set.", "The report labels the generic-to-Record-1 application as an inference and records the 500 ms versus 800 ms timing conflict.", True),
            TestStep("After requirement clarification, author only the source-supported trigger and collection sequence without sleeps in T0-relative timing.", "An execution-ready lifecycle test contains a reconciled trigger threshold, exact timing grid, and DID-read timing; this review version remains ON HOLD.", True),
        ],
        decision_technique,
    )

    odometer_test_data = (
        "0x00000 -> raw 0 -> factor 1, offset 0 -> 0 km -> EDR 00 00 00; "
        "0x00001 -> raw 1 -> factor 1, offset 0 -> 1 km -> EDR 00 00 01; "
        "0x7A120 -> raw 500000 -> factor 1, offset 0 -> 500000 km -> EDR 07 A1 20; "
        "0xF423F -> raw 999999 -> factor 1, offset 0 -> 999999 km -> EDR 0F 42 3F."
    )
    odometer_pre_action = (
        "Review setup only: use U171 DBC U171_SRS_SVNID39216_20250917.dbc, SHA-256 "
        "EE7342003C1C4AB76F7E11A2AD69207BD7198928C6C3F4EBA7CF33D01F214358. "
        "The U171 variant default explicitly lists IC. Execution requires an approved non-deployment "
        "EDR event procedure and customer security level 1; this generated artifact does not execute either action."
    )
    odometer_post_action = (
        "No NVM clear, DTC clear, crash trigger, or bench operation is prescribed by this review artifact. "
        "Preserve the diagnostic response and source revisions for review."
    )
    append_case(
        "EDR-U171-ICE-R1-ODOMETER-NOMINAL-011",
        "High",
        _case_description(
            element="Odometer",
            did="0x0455 / Record 1",
            field_location="Common layout bytes 7-9; approved tracker diagnostic response bytes 11-13, 20-bit value with upper four bits reserved zero",
            sample_detail="Single T0 snapshot; source tracker recording interval = 0 ms",
            expected_encoding="For the four stated valid raw values, store the three-byte MSB-first encodings in Test Data; do not copy CAN payload byte order.",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!58, ID 34856990, Approved; common EDR_0455_045B!5; DRBFM EDR 0455 045B Analysis!5",
            gap="The common-layout versus diagnostic-response byte numbering differs by four bytes; use the tracker-defined response bytes for review and retain the offset convention as an open evidence item.",
            dbc_message="IC2_100, CAN ID 0x340, cycle 100 ms, sender not specified by DBC",
            dbc_signal="ODOMTR_READING: start bit 0, 20 bit, little endian, unsigned",
            presence_status="Applicable: U171 variant default lists IC, U171 CAN configuration maps IC2_100 to IC, and the raw U171 DBC contains ODOMTR_READING.",
            can_metadata="factor=1; offset=0; physical range=0 to 999999 km; DBC default raw=0x00000; DBC invalid raw=0xFFFFF",
            test_data=odometer_test_data,
        ),
        [RECORD_1_ODOMETER_REQUIREMENT],
        [
            TestStep("Confirm the U171 DBC hash, the IC enabled-node evidence, and the approved Record 1 Odometer requirement before selecting test data.", "The selected source chain is U171 variant configuration -> IC2_100/ODOMTR_READING -> U171 DBC -> DID 0x0455 tracker requirement 34856990.", True),
            TestStep("For each valid Test Data row, use the project-approved CAN stimulation method to provide IC2_100/ODOMTR_READING at T0. Do not use 0xFFFFF because no EDR invalid-value fallback is specified.", "The intended CAN raw pattern is padded to five hexadecimal digits and decodes with factor 1 and offset 0 to the stated kilometre value.", True),
            TestStep("Use only an approved non-deployment EDR event procedure, then after collection request $22 04 55 through DBC diagnostic route 0x730 and observe the response on 0x738 after customer security level 1.", "The procedure remains IN REVIEW until the approved event-generation method and response-header convention are attached; no event is generated by this specification.", True),
            TestStep("Inspect the tracker-defined Odometer response bytes 11-13 and preserve the response evidence.", "The upper four bits of the first field byte are zero and the lower 20 bits equal the stated raw integer encoded MSB-first: 00 00 00, 00 00 01, 07 A1 20, or 0F 42 3F for the corresponding Test Data row.", True),
        ],
        status="IN REVIEW",
        pre_action=odometer_pre_action,
        post_action=odometer_post_action,
        generation_note="DBC-backed Odometer nominal coverage is review-ready; event generation and the response-offset convention remain outside the supplied evidence.",
    )

    append_case(
        "EDR-U171-ICE-R2-DID_ACCESS-STATIC-001",
        "Highest",
        _case_description(
            element="Record 2 diagnostic access",
            did="0x045B / Record 2",
            field_location="Not specified: Record 2 field layout unavailable",
            sample_detail="Not specified",
            expected_encoding="No field encoding asserted; only DID availability is source-traceable",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!699, ID 34984359, Approved",
            gap="The U171 DBC supplies the diagnostic route, but no complete Record 2 response layout or payload fixture was supplied.",
        ),
        [RECORD_2_ACCESS_REQUIREMENT],
        [
            TestStep("Verify the approved U171 Record 2 DID-access requirement and its stated security/session conditions.", "The evidence package identifies DID 0x045B and source requirement 34984359; no record-layout or response-size assumption is made.", True),
            TestStep("After the Record 2 layout is supplied, perform the controlled source-authorized 0x045B read and align the payload to the approved field map.", "No Record 2 byte, bit, sample, or stored-value assertion is executed until an approved layout is available.", True),
        ],
    )

    append_case(
        "EDR-U171-ICE-R2-FIELD_LAYOUT-ON_HOLD-002",
        "Highest",
        _case_description(
            element="Record 2 field layout and sampling",
            did="0x045B / Record 2",
            field_location="Not specified",
            sample_detail="Not specified",
            expected_encoding="Not specified",
            traceability="Record 2 DID access: DES_SW_Mahindra_EDR .xlsx!Export!699, ID 34984359, Approved; field-layout source unavailable",
            gap="The common EDR layout contains no 0x045B rows; do not derive Record 2 from Record 1.",
        ),
        [RECORD_2_ACCESS_REQUIREMENT],
        [
            TestStep("Confirm that the source package contains an approved Record 2 field layout before selecting any element-level test objective.", "The existing source gap is visible and the case remains ON HOLD; no copied Record 1 offset or sample count is accepted.", True),
            TestStep("After layout delivery, populate the Investigation Matrix and Timing Schedule from the approved Record 2 source.", "Each Record 2 element receives its own evidence-backed classification and only source-supported test scenarios.", True),
        ],
    )

    append_case(
        "EDR-U171-ICE-R2-VEHICLE_SPEED-FALLBACK-ON_HOLD-003",
        "Highest",
        _case_description(
            element="Record 2 vehicle-speed fallback behavior",
            did="0x045B / Record 2",
            field_location="Not specified: Record 2 layout unavailable",
            sample_detail="Not specified",
            expected_encoding="Not asserted: tracker fallback rows need a Record 2 field-width/layout reference and a verified field-level fallback conversion",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!701, 704, 706-710, Approved",
            gap="Missing Record 2 layout, variant applicability, and unresolved default-value conflict.",
        ),
        RECORD_2_FALLBACK_REQUIREMENTS,
        [
            TestStep("Review the approved Record 2 vehicle-speed fallback rows without inferring their byte location, width, or raw CAN encoding.", "The requirement IDs remain traceable and all unspecified values are retained as gaps.", True),
            TestStep("After source reconciliation, generate only the explicitly applicable fault cases and their authoritative stored encodings.", "No node-loss, timeout, bus-off, invalid, or reserved-value case is created unless the final DBC and requirement define it.", True),
        ],
        decision_technique,
    )

    append_case(
        "EDR-U171-ICE-R2-LIFECYCLE-ON_HOLD-004",
        "High",
        _case_description(
            element="Record 2 recording lifecycle",
            did="0x045B / Record 2",
            field_location="Record-level behavior",
            sample_detail="Not specified: Record 2 sample plan unavailable",
            expected_encoding="Not applicable",
            traceability="Generic EDR IDs 34856955, 34856958, 34856960, 34856961, 34856963, 34856966, 34856967, 34856972 are Approved; application to Record 2 is not explicitly bound",
            gap="Missing explicit Record 2 binding and multi-event timing conflict.",
        ),
        GENERIC_EDR_LIFECYCLE_REQUIREMENTS,
        [
            TestStep("Review generic EDR lifecycle evidence and identify the missing explicit binding to Record 2.", "The record-specific coverage gap remains visible; no timing or trigger behavior is inferred for Record 2.", True),
            TestStep("After an approved Record 2 lifecycle requirement is supplied, derive the minimum source-supported trigger, storage, and readout tests.", "The final test design contains no unsupported pre/post-crash, consistency, or fault scenario.", True),
        ],
        decision_technique,
    )
    append_case(
        "EDR-U171-ICE-R2-ODOMETER-NOMINAL-005",
        "High",
        _case_description(
            element="Odometer",
            did="0x045B / Record 2",
            field_location="Approved tracker diagnostic response bytes 11-13, 20-bit value with upper four bits reserved zero; complete Record 2 layout unavailable",
            sample_detail="Single T0 snapshot; source tracker recording interval = 0 ms",
            expected_encoding="For the four stated valid raw values, store the three-byte MSB-first encodings in Test Data; do not copy CAN payload byte order.",
            traceability="DES_SW_Mahindra_EDR .xlsx!Export!713, ID 34984373, Approved; complete Record 2 common layout unavailable",
            gap="The tracker supplies this element-level field map, but no full Record 2 layout; do not extend the case to other Record 2 fields by analogy.",
            dbc_message="IC2_100, CAN ID 0x340, cycle 100 ms, sender not specified by DBC",
            dbc_signal="ODOMTR_READING: start bit 0, 20 bit, little endian, unsigned",
            presence_status="Applicable: U171 variant default lists IC, U171 CAN configuration maps IC2_100 to IC, and the raw U171 DBC contains ODOMTR_READING.",
            can_metadata="factor=1; offset=0; physical range=0 to 999999 km; DBC default raw=0x00000; DBC invalid raw=0xFFFFF",
            test_data=odometer_test_data,
        ),
        [RECORD_2_ODOMETER_REQUIREMENT],
        [
            TestStep("Confirm the U171 DBC hash, the IC enabled-node evidence, and the approved Record 2 Odometer requirement before selecting test data.", "The selected source chain is U171 variant configuration -> IC2_100/ODOMTR_READING -> U171 DBC -> DID 0x045B tracker requirement 34984373.", True),
            TestStep("For each valid Test Data row, use the project-approved CAN stimulation method to provide IC2_100/ODOMTR_READING at T0. Do not use 0xFFFFF because no EDR invalid-value fallback is specified.", "The intended CAN raw pattern is padded to five hexadecimal digits and decodes with factor 1 and offset 0 to the stated kilometre value.", True),
            TestStep("Use only an approved non-deployment EDR event procedure, then after collection request $22 04 5B through DBC diagnostic route 0x730 and observe the response on 0x738 after customer security level 1.", "The procedure remains IN REVIEW until the approved event-generation method and full Record 2 layout are attached; no event is generated by this specification.", True),
            TestStep("Inspect the tracker-defined Odometer response bytes 11-13 and preserve the response evidence.", "The upper four bits of the first field byte are zero and the lower 20 bits equal the stated raw integer encoded MSB-first: 00 00 00, 00 00 01, 07 A1 20, or 0F 42 3F for the corresponding Test Data row.", True),
        ],
        status="IN REVIEW",
        pre_action=odometer_pre_action,
        post_action=odometer_post_action,
        generation_note="DBC-backed Record 2 Odometer nominal coverage is review-ready, but it does not establish a complete Record 2 layout or broader test applicability.",
    )
    return cases


def _write_table_sheet(workbook: openpyxl.Workbook, title: str, rows: list[dict[str, str]]) -> None:
    if title in workbook.sheetnames:
        del workbook[title]
    worksheet = workbook.create_sheet(title)
    headers = list(rows[0]) if rows else ["Status"]
    worksheet.append(headers)
    for row in rows:
        worksheet.append([row.get(header, "") for header in headers])
    worksheet.freeze_panes = "A2"
    for cell in worksheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    for column_index, header in enumerate(headers, start=1):
        width = min(max(len(header) + 2, 18), 52)
        worksheet.column_dimensions[get_column_letter(column_index)].width = width
    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")


def _write_matrix_csv(destination: Path, matrix: list[dict[str, str]]) -> None:
    with destination.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(matrix[0]))
        writer.writeheader()
        writer.writerows(matrix)


def _evidence_report(
    *,
    layout_rows: list[dict[str, Any]],
    matrix: list[dict[str, str]],
    timing_schedule: list[dict[str, str]],
    test_cases: list[TestCase],
    gaps: list[dict[str, str]],
    source_manifest: dict[str, Any],
    raw_dbc_paths: list[Path],
) -> str:
    record_1_matrix = [row for row in matrix if row["DID / Record"] == "0x0455 / Record 1"]
    reserved = [row for row in record_1_matrix if row["Classification"] == "Reserved"]
    review_cases = [test_case for test_case in test_cases if test_case.status == "IN REVIEW"]
    held_cases = [test_case for test_case in test_cases if test_case.status == "ON HOLD"]
    dbc = source_manifest["dbc"]
    lines = [
        "# U171 ICE EDR CAN-C Review Specification",
        "",
        "## Scope",
        "",
        "This offline review package targets U171 ICE DID `0x0455` (Record 1) and DID `0x045B` (Record 2). It does not operate an ECU, bench, or CAN interface.",
        "",
        "**Result:** the package is a traceable partial specification. The U171 DBC is parsed and used for every mapped CAN claim. Two Odometer nominal cases are review-ready; all other functional assertions remain constrained by unresolved layout, conversion, or variant-applicability evidence.",
        "",
        "## Sources And Extraction",
        "",
        "- `openpyxl 3.1.5` was selected because it preserves XLSX worksheet structure, formula text, sheet visibility, and raw cell values while streaming full sheets.",
        f"- `cantools 39.4.5` parsed `{dbc['path']}` (SHA-256 `{dbc['sha256']}`): {dbc['message_count']} messages. `canmatrix 1.0` is available but was not needed for this native DBC parse.",
        "- The full workbook extraction manifest and SHA-256 identities are in the validation JSON.",
        "",
        "## Investigation And Coverage Matrix",
        "",
        f"- Record 1: {len(layout_rows)} source layout rows grouped into {len(record_1_matrix)} elements; {len(reserved)} elements are explicitly Reserved.",
        "- Record 2: full layout evidence is absent, but the approved Odometer field row supports one bounded nominal case.",
        "- The workbook `Investigation Matrix` sheet and the companion CSV record DBC message/signal, CAN ID, cycle, bit layout, scaling, enumerations, invalid/reserved/default values, configuration status, and gap disposition for every mapped element.",
        f"- The workbook `Timing Schedule` sheet contains {len(timing_schedule)} Record 1 source-timestamp rows. It states authoritative DBC scaling/range where a route is verified, while withholding unsupported time-indexed raw values and EDR encodings.",
        "",
        "## Data Gaps, Assumptions, And Excluded Tests",
        "",
    ]
    for gap in gaps:
        lines.extend(
            [
                f"### {gap['ID']} - {gap['Severity']}",
                gap["Gap / conflict"],
                f"Evidence: {gap['Evidence']}",
                f"Impact: {gap['Impact']}",
                f"Disposition: {gap['Disposition']}",
                "",
            ]
        )
    lines.extend(
        [
            "**Assumptions:** None are used to generate expected ECU values. A U171 configuration route is used only when it exactly matches the raw U171 DBC; configuration labels do not replace missing DBC sender or variant-bit evidence.",
            "",
            "**Excluded tests:** except for the two Odometer nominal cases, functional CAN range, invalid, reserved-input, node-loss, message-timeout, bus-off, pre-crash, post-crash, Record 1/Record 2 consistency, and conversion-dependent raw-encoding tests remain excluded until their specific applicability, field layout, and explicit requirement conditions are available.",
            "",
            "## Detailed Test Cases",
            "",
            f"Generated cases: {len(review_cases)} `IN REVIEW` and {len(held_cases)} `ON HOLD`. Each Veoneer description contains the element, DID/record, field location, sample information, DBC metadata where verified, expected-encoding status, exact traceability, and gap disposition.",
            "",
            "| Test Case ID | DID / Record | Priority | Verified IDs | Status |",
            "| --- | --- | --- | --- | --- |",
        ]
    )
    for test_case in test_cases:
        record = "0x0455 / R1" if "-R1-" in test_case.name else "0x045B / R2"
        lines.append(f"| {test_case.name} | {record} | {test_case.priority} | {', '.join(test_case.requirement_ids)} | {test_case.status} |")
    lines.extend(
        [
            "",
            "## Coverage Summary",
            "",
            "| Record | Coverage | Residual gap | Confidence |",
            "| --- | --- | --- | --- |",
            "| 0x0455 / Record 1 | DID access, full source-layout inventory, DBC correlation, reserved-field, fallback-conflict, lifecycle review, and Odometer nominal case | Most field applicability, payload packing, timing, fault, and conversion checks remain unresolved | High for DBC/source facts; Medium for Odometer nominal relation; Low for other functional behavior |",
            "| 0x045B / Record 2 | DID access, fallback/lifecycle evidence review, and Odometer nominal case | Complete Record 2 layout, sample plan, and non-Odometer field conversion remain unavailable | High for Odometer tracker/DBC facts; Unknown for broader Record 2 behavior |",
            "",
            "## Validation",
            "",
            f"- Raw DBC scan result: {len(raw_dbc_paths)} DBC file(s) found; selected U171 evidence is `{dbc['path']}`.",
            f"- Generated Veoneer cases: {len(test_cases)}. All source requirement IDs were verified as Approved in the U171 EDR tracker before serialization.",
            f"- Extracted workbook count: {len(source_manifest['workbooks'])}; all sheets were streamed completely, including the large formatted Timeline Tracker sheet.",
            "- Live Codebeamer import acceptance is unverified because no approved importer round trip was performed.",
        ]
    )
    return "\n".join(lines) + "\n"


def generate_review_specification(output_directory: Path) -> dict[str, Any]:
    """Generate an offline, evidence-limited U171 EDR review specification and companion report."""
    output_directory.mkdir(parents=True, exist_ok=True)
    layout_rows = _load_layout_rows()
    matrix, timing_schedule = _layout_matrix(layout_rows)
    dbc_context = _load_dbc_context()
    tracker = _load_tracker_requirements()
    inspection = inspect_template(TEMPLATE_PATH)
    if inspection.issues:
        raise ValueError("Template inspection failed: " + "; ".join(inspection.issues))
    test_cases = _build_test_cases(tracker, inspection.allowed_values, matrix)
    specification = TestSpecification(
        title="U171 ICE EDR CAN-C 0x0455 / 0x045B Review Specification",
        test_cases=test_cases,
        source_paths=[str(path) for path in SOURCE_WORKBOOKS.values()] + [str(U171_EDR_CONFIG), str(U171_CANC_CONFIG), str(U171_CAN_LIBRARY), str(U171_VARIANT_CONFIG), str(U171_DBC)],
        assumptions=["Only exact U171 configuration-to-DBC routes are used; unresolved source-to-EDR conversion or applicability remains explicit."],
        coverage_gaps=[gap["Gap / conflict"] for gap in _data_gaps()],
    )
    preflight = validate_specification(specification, template_path=TEMPLATE_PATH)
    errors = [issue for issue in preflight if issue.severity == "error"]
    if errors:
        raise ValueError("Preflight validation failed: " + "; ".join(issue.message for issue in errors))

    workbook_path = output_directory / "U171_ICE_EDR_CANC_0455_045B_review_spec.xlsx"
    render_report = render_specification(
        specification,
        template_path=TEMPLATE_PATH,
        destination_path=workbook_path,
        write_mode="replace_data",
        overwrite=True,
    )
    gaps = _data_gaps()
    full_extraction_manifest = _full_source_manifest()
    source_manifest = {
        "extractor": full_extraction_manifest["extractor"],
        "parser_rationale": full_extraction_manifest["parser_rationale"],
        "workbooks": [
            {
                "name": record["source_name"],
                "path": record["source_path"],
                "sha256": record["sha256"],
                "sheet_count": record["sheet_count"],
                "fully_scanned": all(
                    sheet["declared_max_row"] == sheet["scanned_rows"]
                    for sheet in record["sheets"]
                ),
            }
            for record in full_extraction_manifest["workbooks"]
        ],
        "full_extraction": full_extraction_manifest,
        "dbc": {
            "path": str(dbc_context["path"]),
            "sha256": dbc_context["sha256"],
            "message_count": dbc_context["message_count"],
            "network_nodes": dbc_context["network_nodes"],
            "parser": "cantools 39.4.5",
            "rationale": "cantools exposes native DBC message, signal, bit-layout, scaling, enum, and multiplex metadata without lossy manual parsing.",
        },
    }
    raw_dbc_paths = sorted(REPOSITORY_ROOT.rglob("*.dbc"))
    workbook = openpyxl.load_workbook(workbook_path)
    try:
        _write_table_sheet(workbook, "Investigation Matrix", matrix)
        _write_table_sheet(workbook, "Timing Schedule", timing_schedule)
        _write_table_sheet(workbook, "Data Gaps", gaps)
        _write_table_sheet(
            workbook,
            "Coverage Summary",
            [
                {
                    "DID / Record": "0x0455 / Record 1",
                    "Source layout coverage": f"{len(layout_rows)} source rows / {len([row for row in matrix if row['DID / Record'] == '0x0455 / Record 1'])} grouped elements",
                    "Functional CAN coverage": "Odometer nominal case IN REVIEW; all other functional CAN cases remain constrained by evidence gaps",
                    "Static coverage": "DID access, layout regions, reserved encoding, sample-schedule review, and DBC correlation",
                    "Confidence": "High for extracted/DBC facts; Medium for Odometer nominal relation; Low for unresolved field behavior",
                },
                {
                    "DID / Record": "0x045B / Record 2",
                    "Source layout coverage": "DID catalogue/access plus approved Odometer field row; no complete Record 2 layout supplied",
                    "Functional CAN coverage": "Odometer nominal case IN REVIEW; all other field behavior withheld",
                    "Static coverage": "DID access, Odometer field correlation, and evidence-gap review",
                    "Confidence": "High for Odometer tracker/DBC facts; Unknown for broader field behavior",
                },
            ],
        )
        _write_table_sheet(
            workbook,
            "Odometer Test Data",
            [
                {
                    "DID / Record": did,
                    "CAN message / signal": "IC2_100 / ODOMTR_READING",
                    "CAN raw bit pattern": raw_hex,
                    "Decoded raw integer": raw_integer,
                    "Factor": "1",
                    "Offset": "0",
                    "Physical value": physical_value,
                    "Expected three-byte EDR encoding": stored_encoding,
                    "Restriction": "Valid nominal value only; 0xFFFFF invalid behavior is not source-defined for EDR storage.",
                }
                for did in ("0x0455 / Record 1", "0x045B / Record 2")
                for raw_hex, raw_integer, physical_value, stored_encoding in (
                    ("0x00000", "0", "0 km", "00 00 00"),
                    ("0x00001", "1", "1 km", "00 00 01"),
                    ("0x7A120", "500000", "500000 km", "07 A1 20"),
                    ("0xF423F", "999999", "999999 km", "0F 42 3F"),
                )
            ],
        )
        _write_table_sheet(
            workbook,
            "DBC Correlation",
            [
                {
                    "DID / Record": row["DID / Record"],
                    "EDR Element": row["EDR Element"],
                    "Classification": row["Classification"],
                    "Configuration status": row["Configuration status"],
                    "DBC message / signal": row["DBC message / signal"],
                    "CAN metadata": row["CAN ID / sender / cycle / multiplexing"],
                    "Encoding relation": row["Expected stored value"],
                    "Coverage decision": row["Coverage decision"],
                }
                for row in matrix
                if row["DBC message presence"].startswith("Present")
            ],
        )
        _write_table_sheet(
            workbook,
            "Source Evidence",
            [
                {
                    "Source": record["name"],
                    "Path": record["path"],
                    "SHA-256": record["sha256"],
                    "Parser / rationale": "openpyxl 3.1.5 - full XLSX row scan with sheet/row provenance",
                }
                for record in source_manifest["workbooks"]
            ]
            + [
                {
                    "Source": "U171 raw DBC",
                    "Path": source_manifest["dbc"]["path"],
                    "SHA-256": source_manifest["dbc"]["sha256"],
                    "Parser / rationale": source_manifest["dbc"]["parser"] + " - " + source_manifest["dbc"]["rationale"],
                }
            ],
        )
        workbook.save(workbook_path)
    finally:
        workbook.close()

    matrix_path = output_directory / "U171_ICE_EDR_CANC_0455_045B_investigation_matrix.csv"
    _write_matrix_csv(matrix_path, matrix)
    report_path = output_directory / "U171_ICE_EDR_CANC_0455_045B_evidence_report.md"
    report_path.write_text(
        _evidence_report(
            layout_rows=layout_rows,
            matrix=matrix,
            timing_schedule=timing_schedule,
            test_cases=test_cases,
            gaps=gaps,
            source_manifest=source_manifest,
            raw_dbc_paths=raw_dbc_paths,
        ),
        encoding="ascii",
    )
    postflight = validate_rendered_workbook(workbook_path)
    validation_path = output_directory / "U171_ICE_EDR_CANC_0455_045B_validation_report.json"
    write_validation_report(
        {
            **postflight,
            "generation": render_report,
            "preflight_issues": [
                {
                    "severity": issue.severity,
                    "code": issue.code,
                    "message": issue.message,
                    "location": issue.location,
                }
                for issue in preflight
            ],
            "source_manifest": source_manifest,
            "raw_dbc_scan": [str(path.relative_to(REPOSITORY_ROOT)) for path in raw_dbc_paths],
            "quality_gate": {
                "functional_can_specification": "partial",
                "reason": "U171 DBC-backed Odometer nominal cases are in review. All other functional expectations remain gated by variant applicability, full Record 2 layout, response-offset, or conversion evidence.",
                "bench_execution": "not performed",
            },
        },
        validation_path,
    )
    return {
        "workbook": workbook_path,
        "matrix": matrix_path,
        "report": report_path,
        "validation": validation_path,
        "matrix_rows": len(matrix),
        "timing_rows": len(timing_schedule),
        "test_cases": len(test_cases),
        "postflight": postflight,
    }


def _json_value(value: Any) -> Any:
    if isinstance(value, (date, datetime, time)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.hex()
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _non_empty_row(values: Iterable[Any]) -> list[Any] | None:
    serialized = [_json_value(value) for value in values]
    return serialized if any(value is not None for value in serialized) else None


def extract_workbook(source_name: str, source_path: Path, scratch_directory: Path) -> dict[str, Any]:
    """Dump every scanned worksheet row while retaining source sheet and row provenance."""
    if not source_path.is_file():
        raise FileNotFoundError(source_path)

    dump_path = scratch_directory / f"{source_name}.jsonl"
    workbook = openpyxl.load_workbook(source_path, read_only=True, data_only=False)
    workbook_summary: dict[str, Any] = {
        "source_name": source_name,
        "source_path": str(source_path),
        "sha256": _sha256(source_path),
        "sheet_count": len(workbook.worksheets),
        "sheets": [],
    }

    with dump_path.open("w", encoding="utf-8") as dump_file:
        for worksheet in workbook.worksheets:
            non_empty_rows = 0
            scanned_rows = 0
            for row_number, values in enumerate(worksheet.iter_rows(values_only=True), start=1):
                scanned_rows = row_number
                row = _non_empty_row(values)
                if row is None:
                    continue
                non_empty_rows += 1
                dump_file.write(
                    json.dumps(
                        {
                            "source_name": source_name,
                            "sheet": worksheet.title,
                            "row": row_number,
                            "values": row,
                        },
                        ensure_ascii=True,
                    )
                    + "\n"
                )

            workbook_summary["sheets"].append(
                {
                    "name": worksheet.title,
                    "state": worksheet.sheet_state,
                    "declared_max_row": worksheet.max_row,
                    "declared_max_column": worksheet.max_column,
                    "scanned_rows": scanned_rows,
                    "non_empty_rows": non_empty_rows,
                }
            )

    workbook.close()
    return workbook_summary


def extract_sources(scratch_directory: Path) -> dict[str, Any]:
    """Extract all selected source workbooks and write a single integrity manifest."""
    scratch_directory.mkdir(parents=True, exist_ok=True)
    manifest = {
        "extractor": "openpyxl 3.1.5",
        "parser_rationale": (
            "openpyxl preserves XLSX worksheet structure, formulas, sheet visibility, and raw cell "
            "values while streaming all rows with bounded memory."
        ),
        "workbooks": [
            extract_workbook(source_name, source_path, scratch_directory)
            for source_name, source_path in SOURCE_WORKBOOKS.items()
        ],
    }
    (scratch_directory / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=True, indent=2),
        encoding="utf-8",
    )
    return manifest


def _full_source_manifest() -> dict[str, Any]:
    scratch_directory = Path(tempfile.gettempdir()) / "u171_ice_edr_specification_evidence"
    manifest_path = scratch_directory / "manifest.json"
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        source_hashes = {
            record["source_name"]: record["sha256"]
            for record in manifest.get("workbooks", [])
        }
        if all(source_hashes.get(name) == _sha256(path) for name, path in SOURCE_WORKBOOKS.items()):
            return manifest
    return extract_sources(scratch_directory)


def test_source_workbooks_exist() -> None:
    """Keep the source inventory explicit without accessing any bench resource."""
    assert all(source_path.is_file() for source_path in SOURCE_WORKBOOKS.values())


def test_u171_dbc_loads() -> None:
    """Verify the specified U171 DBC is parseable without transmitting any CAN traffic."""
    assert U171_DBC.is_file()
    database = cantools.database.load_file(U171_DBC)
    assert database.get_message_by_name("IC2_100").get_signal_by_name("ODOMTR_READING").length == 20


def test_dbc_backed_odometer_matrix_and_cases() -> None:
    """Keep the narrow DBC-backed Odometer coverage tied to verified U171 evidence."""
    matrix, _ = _layout_matrix(_load_layout_rows())
    entries = {
        row["DID / Record"]: row
        for row in matrix
        if row["EDR Element"] == "Odometer"
    }
    assert entries["0x0455 / Record 1"]["Classification"] == "Applicable"
    assert entries["0x045B / Record 2"]["Classification"] == "Applicable"
    assert entries["0x0455 / Record 1"]["DBC message / signal"] == "IC2_100 / ODOMTR_READING"
    assert "20-bit raw integer" in entries["0x045B / Record 2"]["Expected stored value"]

    inspection = inspect_template(TEMPLATE_PATH)
    assert inspection.issues == []
    cases = _build_test_cases(_load_tracker_requirements(), inspection.allowed_values, matrix)
    cases_by_name = {case.name: case for case in cases}
    assert cases_by_name["EDR-U171-ICE-R1-ODOMETER-NOMINAL-011"].requirement_ids == [RECORD_1_ODOMETER_REQUIREMENT]
    assert cases_by_name["EDR-U171-ICE-R2-ODOMETER-NOMINAL-005"].requirement_ids == [RECORD_2_ODOMETER_REQUIREMENT]
    assert cases_by_name["EDR-U171-ICE-R1-ODOMETER-NOMINAL-011"].status == "IN REVIEW"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--generate-review-spec",
        action="store_true",
        help="Generate the offline U171 EDR review specification and companion evidence artifacts.",
    )
    parser.add_argument(
        "--output-directory",
        type=Path,
        default=DEFAULT_OUTPUT_DIRECTORY,
        help="Destination for generated review-specification artifacts.",
    )
    parser.add_argument(
        "--scratch",
        type=Path,
        default=Path(tempfile.gettempdir()) / "u171_ice_edr_specification_evidence",
        help="Directory for non-source extraction artifacts.",
    )
    arguments = parser.parse_args()
    if arguments.generate_review_spec:
        result = generate_review_specification(arguments.output_directory)
        print(json.dumps({key: str(value) for key, value in result.items() if key != "postflight"}, ensure_ascii=True, indent=2))
        print(json.dumps(result["postflight"], ensure_ascii=True, indent=2))
        return
    manifest = extract_sources(arguments.scratch)
    print(json.dumps(manifest, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()