"""Generate and validate the minimum-scope ICE Common EDR test specification.

The generated workbook is an offline engineering-review authoring specification.
It does not communicate with ARIA, an ECU, diagnostics, power equipment, or any
other bench interface.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import date
import json
from pathlib import Path
import re
import sys
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from test_ice_common_edr_test_spec_design import SOURCE_NAME, SOURCE_WORKBOOK, cell_text, inspect_source


ROOT = Path(__file__).resolve().parents[1]
VEONEER_WRITER_DIRECTORY = ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "scripts"
if str(VEONEER_WRITER_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(VEONEER_WRITER_DIRECTORY))

from legacy_adapters import excel_to_testcase_dict, write_legacy_title_step_workbook

OUTPUT_DIRECTORY = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design"
    / "02_Minimum_Test_Spec"
)
OUTPUT_WORKBOOK = OUTPUT_DIRECTORY / "ICE_COMMON_SRS_V1_4_EDR_Minimum_Coverage_Test_Spec.xlsx"
OUTPUT_REPORT = OUTPUT_DIRECTORY / "ICE_COMMON_SRS_V1_4_EDR_Minimum_Coverage_Test_Spec_Validation.json"

NAVY = "1F4E78"
PALE_BLUE = "D9EAF7"
PALE_GREEN = "E2F0D9"
PALE_AMBER = "FFF2CC"
PALE_RED = "FCE4D6"
HIGHLIGHT_YELLOW = "FFF200"
PALE_YELLOW = "FFF9D9"
WHITE = "FFFFFF"
THIN_GRAY = Side(style="thin", color="B7B7B7")
TBC = "TBC: requirement clarification required."
ON_HOLD = "ON HOLD: TBC: requirement clarification required; do not record a pass/fail verdict."
SOURCE_ID_NOTICE = "Source-row traceability only; EDR_Requirements has no verified Codebeamer artifact ID or approval-status field."


def source_reference(row_number: int, serial: str | None = None, cell: str = "E") -> str:
    suffix = f" | S.No {serial}" if serial else ""
    return f"{SOURCE_NAME} | EDR_Requirements!{cell}{row_number}{suffix}"


def make_case(
    case_id: str,
    name: str,
    objective: str,
    scope: str,
    priority: str,
    status: str,
    source: str,
    ambiguities: str,
    pre_action: str,
    steps: list[tuple[str, str]],
    post_action: str,
    notes: str,
) -> dict[str, Any]:
    return {
        "id": case_id,
        "name": name,
        "objective": objective,
        "scope": scope,
        "priority": priority,
        "status": status,
        "source": source,
        "ambiguities": ambiguities,
        "pre_action": pre_action,
        "steps": steps,
        "post_action": post_action,
        "notes": notes,
    }


def build_case_definitions() -> list[dict[str, Any]]:
    approved_baseline = (
        "Use only an approved, non-destructive project procedure to establish the required ECU/EDR state. "
        "This authoring specification does not authorize bench execution."
    )
    return [
        make_case(
            "EDR-ICE-MIN-001",
            "No-Event Default EDR DID Data",
            "Verify that no-event EDR DID data return FF.. in every byte, including reserved bytes.",
            "No-event default response, reserved-byte initialization, repeated-read consistency.",
            "P1",
            "IN REVIEW",
            source_reference(5, "1"),
            "AMB-001; AMB-010; AMB-012",
            f"{approved_baseline} Establish a no-EDR-event condition.",
            [
                ("Confirm the approved no-event baseline and record the relevant ECU/variant identity.", "No EDR event is present before diagnostic readout."),
                ("Read every implemented EDR DID using the approved diagnostic procedure.", "Raw EDR DID responses are retained; exact DID/session/security contract is TBC."),
                ("Map every returned data byte, including reserved bytes, from the retained raw response.", "Every returned EDR DID data byte, including reserved bytes, is FF.."),
                ("Repeat the same EDR DID read two additional times without an event.", "All repeated responses are identical; no stale, zero, or mixed byte is present."),
            ],
            "Retain the three raw diagnostic responses and restore the approved non-event baseline.",
            "Do not accept a generic all-FF assumption for an unverified DID or response length.",
        ),
        make_case(
            "EDR-ICE-MIN-002",
            "Domestic Low Without SRSU Side-Event Suppression",
            "Verify that a Domestic Low variant without SRSU does not record a side event in EDR.",
            "Low Domestic variant, without-SRSU negative side-event recording behavior.",
            "P1",
            "IN REVIEW",
            source_reference(6, "2"),
            "AMB-013; AMB-014",
            f"{approved_baseline} Confirm Domestic Low coding without SRSU through an approved read-only configuration check.",
            [
                ("Record the approved evidence that the target is Domestic Low without SRSU.", "Variant applicability is demonstrated before the stimulus."),
                ("Apply only an approved, non-destructive side-event simulation for this variant.", "The intended side-event input is captured without using an unstated hardware method."),
                ("After the approved observation interval, read all applicable EDR data and preserve raw evidence.", "No side-event EDR record is present."),
                ("Record unrelated outputs only for later tracing to their own requirements.", "Door unlock and other unrelated features are not judged by this source row."),
            ],
            "Restore the approved variant/test environment without changing persistent configuration from this specification.",
            "The source directs door-unlock and other features to separate requirements; this case deliberately does not assert them.",
        ),
        make_case(
            "EDR-ICE-MIN-003",
            "Domestic Mid Without SRSU Side-Event Suppression",
            "Verify that a Domestic Mid variant without SRSU does not record a side event in EDR.",
            "Mid Domestic variant, without-SRSU negative side-event recording behavior.",
            "P1",
            "IN REVIEW",
            source_reference(6, "2"),
            "AMB-013; AMB-014",
            f"{approved_baseline} Confirm Domestic Mid coding without SRSU through an approved read-only configuration check.",
            [
                ("Record the approved evidence that the target is Domestic Mid without SRSU.", "Variant applicability is demonstrated before the stimulus."),
                ("Apply only an approved, non-destructive side-event simulation for this variant.", "The intended side-event input is captured without using an unstated hardware method."),
                ("After the approved observation interval, read all applicable EDR data and preserve raw evidence.", "No side-event EDR record is present."),
                ("Record unrelated outputs only for later tracing to their own requirements.", "Door unlock and other unrelated features are not judged by this source row."),
            ],
            "Restore the approved variant/test environment without changing persistent configuration from this specification.",
            "Low and Mid are retained as separate procedures because the source names both but supplies no common coding evidence.",
        ),
        make_case(
            "EDR-ICE-MIN-004",
            "Near-Crash Record, Unlock, and CAN Suppression",
            "Verify a near crash records EDR data, remains unlocked, and does not transmit STS_CRASH or DOOR_UNLOCK.",
            "Near-crash classification, record lock state, and prohibited CAN-output coverage.",
            "P0",
            "IN REVIEW",
            source_reference(8, "4"),
            "AMB-010; AMB-011; AMB-014",
            f"{approved_baseline} Establish the approved event-ready condition and start synchronized CAN/EDR evidence capture.",
            [
                ("Apply the approved non-deployment near-crash stimulus below the deployable threshold.", "The stimulus is classified as a near crash by the approved project observable."),
                ("Capture STS_CRASH and DOOR_UNLOCK through the complete approved observation interval.", "STS_CRASH and DOOR_UNLOCK are not transmitted for the near crash."),
                ("Read the applicable EDR data after the approved completion condition.", "A near-crash EDR record is present at the architect-confirmed DID/slot."),
                ("Decode the record lock status using the approved decoder.", "RecordLockStatus is 0 / record not locked for the near-crash record."),
            ],
            "Retain synchronized CAN and EDR evidence; restore the approved test environment.",
            "The source does not provide a DID number, record slot, observation interval, or T0 source.",
        ),
        make_case(
            "EDR-ICE-MIN-005",
            "Unconfirmed-Crash Classification",
            "Verify unconfirmed-crash classification when onboard longitudinal input is present and both FRSU values equal 0.",
            "Decision-table coverage for the stated onboard/FRSU input combination.",
            "P1",
            "IN REVIEW",
            source_reference(11, "7"),
            "AMB-011; AMB-014",
            f"{approved_baseline} Prepare the approved onboard longitudinal and FRSU stimulation interface.",
            [
                ("Set valid onboard longitudinal input according to the approved project stimulus definition.", "Onboard longitudinal input is present."),
                ("Set both FRSU values to 0 and retain the input evidence around the decision point.", "FRSU1=0 and FRSU2=0 at the approved classification instant."),
                ("Trigger the classifier evaluation and capture the approved classification observable.", "The event is classified as Unconfirmed Crash."),
                ("Preserve EDR/CAN observations without assigning an unstated pass/fail expectation.", "Recording, locking, CAN-output, and delayed-confirmation behavior remain TBC."),
            ],
            "Restore the approved sensor-input condition and retain classification evidence.",
            "The source states only the classification condition, not its EDR, CAN, lock, or delayed-confirmation consequences.",
        ),
        make_case(
            "EDR-ICE-MIN-006",
            "200 ms and Five-Second Completion Timing",
            "Verify source-stated completion behavior after 200 ms and after five seconds from T0 with battery available.",
            "CompletionStatus and 200msCompletionStatus timing observations, including boundary characterization.",
            "P0",
            "IN REVIEW",
            f"{source_reference(9, '5')}; {source_reference(10, '6')}",
            "AMB-003; AMB-007; AMB-011; AMB-014",
            f"{approved_baseline} Prepare an approved synchronized T0 timebase and maintain battery availability beyond five seconds.",
            [
                ("Capture the approved T0 reference and trigger one source-applicable EDR event.", "The T0 source and event timestamp are retained with measurement uncertainty."),
                ("Observe 200msCompletionStatus at the vector-defined times around 200 ms.", "It becomes 1 after 200 ms; exact equality, scheduler tick, and tolerance are TBC."),
                ("Observe CompletionStatus at the vector-defined times around five seconds while battery remains available.", "It becomes 1 after five seconds from T0 with battery available; exact equality, scheduler tick, and tolerance are TBC."),
                ("Retain the decoded EDR response at each observation point.", "No claim is made that a completion bit proves durability until the data-set and NVM criteria are supplied."),
            ],
            "Retain timebase, power, and EDR evidence; restore the approved test environment.",
            "This procedure contains one timing-observation vector. Exact boundary behavior is intentionally not passed or failed before AMB-003 closure.",
        ),
        make_case(
            "EDR-ICE-MIN-007",
            "Completion-State and Battery-Cutoff Decision Table",
            "Verify each source-defined CompletionStatus / 200msCompletionStatus data-validity state.",
            "Completion-state decision table: 0/0, 0/1, and 1/don't-care.",
            "P0",
            "IN REVIEW",
            f"{SOURCE_NAME} | EDR_Requirements!B53:E55",
            "AMB-007; AMB-008; AMB-014",
            f"{approved_baseline} Obtain an architect-approved power/event profile for each status-pair vector.",
            [
                ("Select one completion-state vector from the Parameter Vectors sheet.", "The intended CompletionStatus and 200msCompletionStatus pair is identified before execution."),
                ("Apply the approved event/power profile and retain synchronized power and T0 evidence.", "Power handling is performed only by an authorized procedure; this spec does not prescribe electrical values."),
                ("Read the decoded completion flags and applicable EDR data.", "The observed flag pair and source-stated data-validity outcome match the selected vector."),
                ("Preserve data records for later NVM/durability review.", "No unsupported CRC, valid-marker, or write-order conclusion is made."),
            ],
            "Restore nominal approved conditions and retain raw evidence.",
            "The source supplies status meanings, not the physical power profile, data list, or NVM durability criteria.",
        ),
        make_case(
            "EDR-ICE-MIN-008",
            "Single-Event Three-Event Permutation Matrix",
            "Verify all eight source-defined Near Crash/Deployment three-event outcomes in the single-event timing class.",
            "Eight binary Event1/Event2/Event3 permutations, EDR1/EDR2 retention, counters, lock state, and time-between-events.",
            "P0",
            "IN REVIEW",
            f"{SOURCE_NAME} | EDR_Requirements!B23:V30",
            "AMB-003; AMB-004; AMB-005; AMB-006; AMB-010; AMB-014",
            f"{approved_baseline} Obtain an approved clean EDR baseline and decoder for EDR1/EDR2 source-table fields.",
            [
                ("Select one of the eight mandatory source-vector rows from the Parameter Vectors sheet.", "Event codes and exact source-table expected fields are identified before the run."),
                ("Apply Event1, Event2, and Event3 at the source-table single-event timing class.", "The source-table class is time between events more than 5 s; exact 5.000 s behavior is TBC."),
                ("Capture/decode EDR1 and EDR2 after Event2.", "EDR1/EDR2 retained-event, MultiEventNumber, TimeBetweenEvents, and LifetimeEventNumber match the selected source row."),
                ("Capture/decode EDR1 and EDR2 after Event3.", "EDR1/EDR2 retained-event, MultiEventNumber, TimeBetweenEvents, LifetimeEventNumber, and RecordLockStatus match the selected source row."),
            ],
            "Retain raw/decoded evidence per vector and restore the architect-approved clean baseline.",
            "This procedure covers the eight supplied source rows only; it cannot establish an Event4+ replacement rule.",
        ),
        make_case(
            "EDR-ICE-MIN-009",
            "Multi-Event Three-Event Permutation Matrix",
            "Verify all eight source-defined Near Crash/Deployment three-event outcomes in the multi-event timing class.",
            "Eight binary Event1/Event2/Event3 permutations, EDR1/EDR2 retention, counters, lock state, and time-between-events.",
            "P0",
            "IN REVIEW",
            f"{SOURCE_NAME} | EDR_Requirements!B42:V49",
            "AMB-003; AMB-004; AMB-005; AMB-006; AMB-010; AMB-014",
            f"{approved_baseline} Obtain an approved clean EDR baseline and decoder for EDR1/EDR2 source-table fields.",
            [
                ("Select one of the eight mandatory source-vector rows from the Parameter Vectors sheet.", "Event codes and exact source-table expected fields are identified before the run."),
                ("Apply Event1, Event2, and Event3 at the source-table multi-event timing class.", "The source-table class is >500 ms and <5 s; exact 500 ms/5.000 s behavior is TBC."),
                ("Capture/decode EDR1 and EDR2 after Event2.", "EDR1/EDR2 retained-event, MultiEventNumber, TimeBetweenEvents, and LifetimeEventNumber match the selected source row."),
                ("Capture/decode EDR1 and EDR2 after Event3.", "EDR1/EDR2 retained-event, MultiEventNumber, TimeBetweenEvents, LifetimeEventNumber, and RecordLockStatus match the selected source row."),
            ],
            "Retain raw/decoded evidence per vector and restore the architect-approved clean baseline.",
            "This procedure covers the eight supplied source rows only; it cannot establish an Event4+ replacement rule.",
        ),
        make_case(
            "EDR-ICE-MIN-010",
            "Inter-Event Boundary Classification Matrix",
            "Characterize specified inter-event timing boundaries and prevent silent off-by-one decisions.",
            "0/1/299/300/301/499/500/501 ms and 4.999/5.000/5.001 s event separation.",
            "P0",
            "ON HOLD",
            f"{SOURCE_NAME} | EDR_Requirements!B13:V49",
            "AMB-003; AMB-011; AMB-014",
            "Do not execute as pass/fail until the architect defines time reference, equality behavior, scheduler tick, and measurement tolerance.",
            [
                ("Select one timing boundary vector and establish its approved timestamp reference.", "The selected boundary and measurement uncertainty are recorded."),
                ("Apply the approved two-event Near Crash/Deployment pair at the exact vector separation.", "Both input timestamps are retained relative to the approved T0 reference."),
                ("Decode EDR allocation, multi-event fields, TimeBetweenEvents, lifetime fields, and lock states.", TBC),
                ("Record the result as evidence for requirement clarification; do not assign pass/fail.", ON_HOLD),
            ],
            "Restore the approved baseline without interpreting a timing result as conclusive.",
            "The source defines open timing intervals only; all equality/tick decisions remain a formal ambiguity gate.",
        ),
        make_case(
            "EDR-ICE-MIN-011",
            "Fourth/Fifth Event Storage and Overwrite Decision Matrix",
            "Exercise every credible storage-full interpretation without manufacturing an overwrite oracle.",
            "Event4/Event5, unlocked/locked/incomplete record states, allocation, reject, overflow, counters, and diagnostics.",
            "P0",
            "ON HOLD",
            f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49 | source tables stop at Event3",
            "AMB-004; AMB-005; AMB-006; AMB-008; AMB-010; AMB-014",
            "Do not execute as pass/fail until the architect supplies storage allocation, lock-overwrite, counter, and NVM recovery rules.",
            [
                ("Select one Event4/Event5 storage-state vector and establish the specified EDR1/EDR2 age, lock, completion, and validity state.", "The starting storage state is evidenced without assuming an undocumented reset/overwrite method."),
                ("Apply the selected incoming Near Crash or Deployment Event.", "Incoming event and timing class are recorded."),
                ("Read EDR1/EDR2 and diagnostic data three times, then repeat after an approved power-cycle/initialization procedure if permitted.", TBC),
                ("Compare only to the architect-selected interpretation and retain all alternative outcomes as rejected/TBC.", ON_HOLD),
            ],
            "Restore the approved environment and retain readout evidence.",
            "Five mutually exclusive unlocked-record policies are retained as separate vector interpretations; none is silently chosen.",
        ),
        make_case(
            "EDR-ICE-MIN-012",
            "Power-Interruption Atomicity and Recovery Matrix",
            "Cover every named power interruption phase and power mode at least once in a risk-focused minimum campaign.",
            "23 write/capture/read phases with 13 power-mode factors, repeated reads, ignition-cycle persistence, and next-event recovery.",
            "P0",
            "ON HOLD",
            f"{source_reference(9, '5')}; {source_reference(10, '6')}; {SOURCE_NAME} | EDR_Requirements!B53:E57",
            "AMB-007; AMB-008; AMB-010; AMB-014",
            "No bench execution is authorized. Use only an approved power-control, event-trigger, and recovery procedure after NVM/power oracle closure.",
            [
                ("Select one phase/mode vector and establish the stated event/recording state.", "The selected phase, power mode, event type, and timebase are captured."),
                ("Apply the interruption only under an approved, separately authorized procedure.", "Power waveform and the interruption instant are retained."),
                ("Restore nominal power; wait for approved ECU initialization; read all applicable EDR DIDs three times.", TBC),
                ("Perform an approved ignition cycle, reread, and attempt a separately authorized next valid event.", "Atomicity, persistence, status flags, lock preservation, and next-event readiness require the missing NVM/DID oracle."),
            ],
            "Return to an approved safe test state and retain all raw records; do not clear crash-locked data unless separately authorized.",
            "The 23 vectors provide minimum one-factor coverage of every listed phase and power mode; they are not the full 23 x 13 cross-product.",
        ),
        make_case(
            "EDR-ICE-MIN-013",
            "CAN Wake-Up and EDR Data-Quality Matrix",
            "Cover nominal CAN storage, wake-up, invalidity, timing, integrity, cross-signal, and bus-off conditions.",
            "Twelve parameterized CAN/wake-up/data-quality vectors.",
            "P1",
            "ON HOLD",
            source_reference(7, "3"),
            "AMB-002; AMB-009; AMB-010; AMB-014",
            "The released W501 communication matrix, target DBC, source-to-EDR packing, and CAN wake-up rules must be supplied before execution verdicts.",
            [
                ("Select one CAN vector and lock the exact source message/signal, validity, timing, and sample-point definitions from the released matrix.", "The vector's required communication evidence is traceable to the supplied matrix/DBC."),
                ("Apply the specified CAN wake-up, timing, validity, integrity, or data condition around the EDR event.", "CAN frames, signal timestamps, and diagnostic state are retained."),
                ("Read and decode EDR data using the approved packing rule.", TBC),
                ("Compare raw/physical values, scaling, range, data age, on-fail behavior, and cross-signal consistency to the released oracle.", ON_HOLD),
            ],
            "Restore network state through the approved test procedure and retain CAN/EDR traces.",
            "This is a structured coverage procedure, not a claim that a missing communication matrix has been verified.",
        ),
        make_case(
            "EDR-ICE-MIN-014",
            "Diagnostic Read Consistency and Data-Integrity Matrix",
            "Cover EDR reads during capture/write/reset, repeated/concurrent reads, invalid diagnostic requests, and record association.",
            "Five parameterized diagnostic/data-integrity vectors.",
            "P1",
            "ON HOLD",
            f"{source_reference(5, '1')} | generic EDR DID response wording",
            "AMB-001; AMB-008; AMB-010; AMB-014",
            "The released UDS/EDR-DID specification must identify the DID(s), access conditions, response format, NRCs, and concurrency policy.",
            [
                ("Select one diagnostic state vector and establish the approved EDR recording/NVM/reset condition.", "The initial diagnostic and EDR state is recorded."),
                ("Send only the approved diagnostic request(s) and capture raw request/response timing.", "Raw diagnostic evidence is retained; exact request/response oracle is TBC."),
                ("Repeat or overlap requests as defined by the vector without masking ECU reset/timeout behavior.", TBC),
                ("Compare response consistency, record association, stale-byte absence, session/security, and negative-response behavior to the released DID/UDS contract.", ON_HOLD),
            ],
            "Close the diagnostic session by the approved procedure and retain raw traffic.",
            "No UDS request byte, response byte, or NRC is invented in this specification.",
        ),
        make_case(
            "EDR-ICE-MIN-015",
            "Variant Coding and Front/Side Applicability Matrix",
            "Extend the source-backed Low/Mid without-SRSU check to High, coding-change, corrupted-coding, and front-event coverage as gated tests.",
            "Variant applicability and negative behavior beyond the supplied Low/Mid side-event rule.",
            "P1",
            "ON HOLD",
            source_reference(6, "2"),
            "AMB-013; AMB-014",
            "The source does not supply high/market coding maps, invalid-coding behavior, or front-event expectations. Do not write persistent coding from this specification.",
            [
                ("Select the variant/coding vector and obtain its approved target-variant requirement and configuration evidence.", "Applicable variant scope is verified before the event."),
                ("Establish the variant condition through an approved, separately authorized method.", "No persistent configuration operation is performed from this specification."),
                ("Apply the stated side/front event and retain EDR/CAN/diagnostic evidence.", TBC),
                ("Compare behavior only to the approved variant-specific oracle and separately verify unrelated functionality with its own requirement.", ON_HOLD),
            ],
            "Restore the approved configuration only through an authorized procedure; retain version/coding evidence.",
            "The two source-backed Low/Mid cases remain MIN-002 and MIN-003; this procedure is the gated extension.",
        ),
        make_case(
            "EDR-ICE-MIN-016",
            "Concurrent Event and Operating-Mode Race Matrix",
            "Cover event races during post-crash collection, NVM, diagnostic read, shutdown/startup, wake-up, and watchdog recovery.",
            "Eight concurrent-event/operating-mode vectors.",
            "P1",
            "ON HOLD",
            f"{SOURCE_NAME} | EDR_Requirements!B5:V57 | coverage extension beyond supplied scenarios",
            "AMB-003; AMB-007; AMB-008; AMB-010; AMB-011; AMB-014",
            "No source state machine, concurrency arbitration, wake-up, reset, or recovery oracle is provided.",
            [
                ("Select one race vector and establish the first event or operating state through an approved procedure.", "The state entry and timing reference are captured."),
                ("Apply the second event or mode transition at the defined concurrency point.", "Both triggers and their order are retained."),
                ("Capture EDR allocation, completion flags, CAN outputs, reset history, and diagnostics.", TBC),
                ("Record the observed transition for architect disposition; do not assign pass/fail until concurrency behavior is specified.", ON_HOLD),
            ],
            "Return to the approved baseline and retain all race evidence.",
            "These vectors expose race conditions but cannot establish undocumented state-machine behavior.",
        ),
        make_case(
            "EDR-ICE-MIN-017",
            "0-to-N Event-Count Sequence Campaign",
            "Cover no-event through configurable-N event sequences with mixed Near Crash, Unconfirmed Crash, and Deployment inputs.",
            "0, 1, 2, 3, 4, 5, 10, and N-event parameterized sequence coverage.",
            "P1",
            "ON HOLD",
            f"{SOURCE_NAME} | EDR_Requirements!B5:V57 | supplied source vectors are limited to Event1-Event3",
            "AMB-004; AMB-005; AMB-006; AMB-007; AMB-011; AMB-014",
            "Event4+, mixed unconfirmed behavior, counter policy, and resource limits are unspecified. This campaign remains a design gate.",
            [
                ("Select the event-count vector and its mixed event/source/lock/timing factors.", "The selected sequence is recorded before execution."),
                ("Apply the sequence using only approved event stimulation and capture all event timestamps.", "The event order, source, classification, and power/CAN conditions are retained."),
                ("Read EDR/diagnostic data at defined checkpoints and after any approved recovery cycle.", TBC),
                ("For a failure, reduce the sequence to the smallest reproducible prefix before defect disposition.", ON_HOLD),
            ],
            "Retain the generated seed/vector and raw evidence; restore the approved test state.",
            "The source-vector procedures MIN-008/MIN-009 supply the conclusive Event1-Event3 binary cases; this campaign extends beyond them.",
        ),
        make_case(
            "EDR-ICE-MIN-018",
            "Counter Limit and Metamorphic Consistency Matrix",
            "Check lifetime/multi-event counter association at normal, maximum-minus-one, maximum, and rollover/saturation states.",
            "Counter limit, saturation/rollover, and equivalent-input consistency coverage.",
            "P1",
            "ON HOLD",
            f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49 | table values only",
            "AMB-004; AMB-005; AMB-006; AMB-014",
            "Counter width, maximum, rollover/saturation policy, discarded-event rule, and setup method are not supplied.",
            [
                ("Select the counter-state vector and obtain an approved way to establish/observe that state.", "Counter state provenance is recorded."),
                ("Apply the selected event sequence and retain EDR1/EDR2 associations.", TBC),
                ("Repeat equivalent non-impacting input ordering where the clarified oracle permits metamorphic comparison.", TBC),
                ("Compare increment, saturation/rollover, association, and persistence behavior to the clarified rule.", ON_HOLD),
            ],
            "Return to the approved state without unauthorized NVM/counter modification.",
            "This procedure does not assume that a counter can be safely preset on an ECU.",
        ),
        make_case(
            "EDR-ICE-MIN-019",
            "Long-Duration Endurance and Property-Based Campaign",
            "Run a controlled long-duration campaign using sequence generation, invariant checks, and failure shrinking.",
            "Endurance, randomized/property-based sequences, reset/power/CAN/diagnostic interactions, and reproducible minimization.",
            "P3",
            "ON HOLD",
            f"{SOURCE_NAME} | EDR_Requirements!B5:V57 | long-duration criteria unavailable",
            "AMB-004; AMB-006; AMB-007; AMB-008; AMB-009; AMB-010; AMB-011; AMB-014",
            "Campaign duration, event budget, allowed NVM impact, stress limits, and invariants must be approved before execution.",
            [
                ("Approve the campaign envelope, sequence generator seed policy, non-destructive limits, and evidence-retention plan.", "Campaign authorization and limits are available."),
                ("Generate sequences varying count, event type/source, timing, CAN validity, power/reset/diagnostic timing, variant, and initial slot state.", "Every sequence has a reproducible seed and input record."),
                ("Evaluate only source-backed invariants as pass/fail and record all unresolved observations as TBC.", "No locked-record, durability, counter, or CAN-packing claim is made without its clarified source."),
                ("Shrink every observed failure to the smallest reproducible sequence and preserve raw evidence.", "A minimized reproducer is available for defect analysis."),
            ],
            "Stop at the approved campaign limit and restore the approved safe test condition.",
            "This is a campaign specification, not a permission to run high-risk endurance or NVM-impacting activity.",
        ),
    ]


def make_vector(
    case_id: str,
    vector_id: str,
    scenario: str,
    inputs: str,
    expected_result: str,
    source: str,
    status: str,
    notes: str,
) -> dict[str, str]:
    return {
        "case_id": case_id,
        "vector_id": vector_id,
        "scenario": scenario,
        "inputs": inputs,
        "expected_result": expected_result,
        "source": source,
        "status": status,
        "notes": notes,
    }


def event_label(value: str) -> str:
    return "Near Crash" if value.startswith("0") else "Deployment Event"


def source_vector_expected(vector: dict[str, Any]) -> str:
    return (
        f"After Event2: EDR1={vector['after_2_edr1']}; EDR2={vector['after_2_edr2']}; "
        f"MultiEventNumber EDR1/EDR2={vector['after_2_multi_1']}/{vector['after_2_multi_2']}; "
        f"TimeBetweenEvents EDR1/EDR2={vector['after_2_time_1']}/{vector['after_2_time_2']}; "
        f"LifetimeEventNumber EDR1/EDR2={vector['after_2_lifetime_1']}/{vector['after_2_lifetime_2']}. "
        f"After Event3: EDR1={vector['after_3_edr1']}; EDR2={vector['after_3_edr2']}; "
        f"MultiEventNumber EDR1/EDR2={vector['after_3_multi_1']}/{vector['after_3_multi_2']}; "
        f"TimeBetweenEvents EDR1/EDR2={vector['after_3_time_1']}/{vector['after_3_time_2']}; "
        f"LifetimeEventNumber EDR1/EDR2={vector['after_3_lifetime_1']}/{vector['after_3_lifetime_2']}; "
        f"RecordLockStatus EDR1/EDR2={vector['after_3_lock_1']}/{vector['after_3_lock_2']}."
    )


def build_parameter_vectors(source_data: dict[str, Any]) -> list[dict[str, str]]:
    vectors: list[dict[str, str]] = [
        make_vector(
            "EDR-ICE-MIN-001",
            "EDR-ICE-MIN-001-V01",
            "No EDR event",
            "No recorded EDR event; read every implemented EDR DID three times.",
            "Every returned EDR DID data byte, including reserved bytes, is FF...",
            source_reference(5, "1"),
            "IN REVIEW",
            "DID identity, length, session, and security are TBC.",
        ),
        make_vector(
            "EDR-ICE-MIN-002",
            "EDR-ICE-MIN-002-V01",
            "Domestic Low without SRSU side event",
            "Verified Domestic Low without-SRSU configuration; approved side-event input.",
            "No side-event EDR record is present.",
            source_reference(6, "2"),
            "IN REVIEW",
            "Do not judge door unlock or unrelated features from this source row.",
        ),
        make_vector(
            "EDR-ICE-MIN-003",
            "EDR-ICE-MIN-003-V01",
            "Domestic Mid without SRSU side event",
            "Verified Domestic Mid without-SRSU configuration; approved side-event input.",
            "No side-event EDR record is present.",
            source_reference(6, "2"),
            "IN REVIEW",
            "Do not judge door unlock or unrelated features from this source row.",
        ),
        make_vector(
            "EDR-ICE-MIN-004",
            "EDR-ICE-MIN-004-V01",
            "One near crash",
            "One approved non-deployment near-crash event; capture EDR and CAN outputs.",
            "EDR records the near crash; RecordLockStatus=0; STS_CRASH and DOOR_UNLOCK are not transmitted.",
            source_reference(8, "4"),
            "IN REVIEW",
            "DID/slot/observation-window details are TBC.",
        ),
        make_vector(
            "EDR-ICE-MIN-005",
            "EDR-ICE-MIN-005-V01",
            "Unconfirmed crash classifier",
            "Onboard longitudinal input present; FRSU1=0; FRSU2=0.",
            "Approved classifier observable reports Unconfirmed Crash.",
            source_reference(11, "7"),
            "IN REVIEW",
            "EDR record, lock, CAN, and delayed confirmation outcomes are TBC.",
        ),
        make_vector(
            "EDR-ICE-MIN-006",
            "EDR-ICE-MIN-006-V01",
            "Completion timing observation",
            "One EDR-recording event with battery available; observe at T0+199/200/201 ms and T0+4.999/5.000/5.001 s.",
            "200msCompletionStatus becomes 1 after 200 ms; CompletionStatus becomes 1 after five seconds with battery available. Equality/tolerance points are TBC.",
            f"{source_reference(9, '5')}; {source_reference(10, '6')}",
            "IN REVIEW",
            "One run provides a timing observation series; it is not a conclusive equality/tolerance oracle.",
        ),
        make_vector(
            "EDR-ICE-MIN-007",
            "EDR-ICE-MIN-007-V01",
            "Completion state 0 / 0",
            "Architect-approved battery-cutoff/event profile yielding the selected completion-state condition.",
            "CompletionStatus=0; 200msCompletionStatus=0; EDR data not valid.",
            f"{SOURCE_NAME} | EDR_Requirements!B53:E53",
            "IN REVIEW",
            "Power profile, EDR DID decoding, and durable-write criteria are TBC.",
        ),
        make_vector(
            "EDR-ICE-MIN-007",
            "EDR-ICE-MIN-007-V02",
            "Completion state 0 / 1",
            "Architect-approved battery-cutoff/event profile yielding the selected completion-state condition.",
            "CompletionStatus=0; 200msCompletionStatus=1; EDR data valid up to 200 ms.",
            f"{SOURCE_NAME} | EDR_Requirements!B54:E54",
            "IN REVIEW",
            "Exact 200 ms data element list and durable-write criteria are TBC.",
        ),
        make_vector(
            "EDR-ICE-MIN-007",
            "EDR-ICE-MIN-007-V03",
            "Completion state 1 / don't care",
            "Architect-approved no-battery-cutoff event profile yielding the selected completion-state condition.",
            "CompletionStatus=1; 200msCompletionStatus=don't care; EDR data valid.",
            f"{SOURCE_NAME} | EDR_Requirements!B55:E55",
            "IN REVIEW",
            "Exact data element list and durable-write criteria are TBC.",
        ),
    ]

    family_counts: Counter[str] = Counter()
    for source_vector in source_data["vectors"]:
        family = source_vector["family"]
        family_counts[family] += 1
        case_id = "EDR-ICE-MIN-008" if family == "Single event" else "EDR-ICE-MIN-009"
        vector_id = f"{case_id}-V{family_counts[family]:02d}"
        inputs = (
            f"Event1={event_label(source_vector['event_1'])}; "
            f"Event2={event_label(source_vector['event_2'])}; "
            f"Event3={event_label(source_vector['event_3'])}; {source_vector['timing']}"
        )
        vectors.append(
            make_vector(
                case_id,
                vector_id,
                f"{family} source vector at EDR_Requirements row {source_vector['source_row']}",
                inputs,
                source_vector_expected(source_vector),
                f"{SOURCE_NAME} | EDR_Requirements!B{source_vector['source_row']}:V{source_vector['source_row']}",
                "IN REVIEW",
                "Exact source-table field values are transcribed. DID mapping, baseline method, and Event4+ policy remain TBC.",
            )
        )

    timing_boundaries = [
        ("V01", "0 ms", "Parallel/overlap event relation"),
        ("V02", "1 ms", "Near-simultaneous event relation"),
        ("V03", "299 ms", "Intermediate timing relation"),
        ("V04", "300 ms", "Intermediate timing relation"),
        ("V05", "301 ms", "Intermediate timing relation"),
        ("V06", "499 ms", "Before source >500 ms multi-event threshold"),
        ("V07", "500 ms", "Exact source >500 ms threshold"),
        ("V08", "501 ms", "After source >500 ms threshold"),
        ("V09", "4.999 s", "Before source 5 s class boundary"),
        ("V10", "5.000 s", "Exact source 5 s class boundary"),
        ("V11", "5.001 s", "After source 5 s class boundary"),
    ]
    for suffix, boundary, scenario in timing_boundaries:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-010",
                f"EDR-ICE-MIN-010-{suffix}",
                scenario,
                f"Two-event Near Crash/Deployment parameter pair separated by {boundary}; timestamp reference and pair selection require approved definition.",
                TBC,
                f"{SOURCE_NAME} | EDR_Requirements!B13:V49",
                "ON HOLD",
                "Source gives open intervals only; do not mark pass/fail before AMB-003 closure.",
            )
        )

    overwrite_vectors = [
        ("V01", "Both records unlocked; incoming Event4 deployment", "Provisional interpretation: replace oldest unlocked record."),
        ("V02", "Both records unlocked; incoming Event4 deployment", "Provisional interpretation: replace newest unlocked record."),
        ("V03", "Both records unlocked; incoming Event4 deployment", "Provisional interpretation: replace lowest-priority unlocked record."),
        ("V04", "Both records unlocked; incoming Event4 deployment", "Provisional interpretation: reject incoming event and preserve records."),
        ("V05", "Both records unlocked; incoming Event4 deployment", "Provisional interpretation: preserve records and store only metadata/overflow indication."),
        ("V06", "EDR1 locked; EDR2 unlocked; incoming Event4 deployment", "Slot selection/rejection and counter behavior are TBC."),
        ("V07", "EDR1 unlocked; EDR2 locked; incoming Event4 deployment", "Slot selection/rejection and counter behavior are TBC."),
        ("V08", "Both records locked; incoming Event4 deployment", "Locked-record preservation/rejection/overflow behavior is TBC."),
        ("V09", "Both records locked; incoming Event4 near crash", "Locked-record preservation/rejection/overflow behavior is TBC."),
        ("V10", "One complete record and one CRC-invalid/incomplete record; incoming Event5 deployment", "Recovery, selection, and data-integrity behavior are TBC."),
    ]
    for suffix, inputs, expected_result in overwrite_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-011",
                f"EDR-ICE-MIN-011-{suffix}",
                "Fourth/Fifth event overwrite decision",
                inputs,
                f"{TBC} {expected_result}",
                f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49",
                "ON HOLD",
                "Source examples stop at Event3. This is an alternative-interpretation vector, not an approved expected result.",
            )
        )

    power_phases = [
        "Before T0",
        "Exactly at T0",
        "T0 + 1 ms",
        "T0 + 199 ms",
        "T0 + 200 ms",
        "T0 + 201 ms",
        "Immediately before CompletionStatus update",
        "During CompletionStatus update",
        "Immediately after CompletionStatus update",
        "During pre-crash-buffer freeze",
        "During record allocation",
        "During metadata write",
        "During payload write",
        "During CRC write",
        "During valid-marker update",
        "During lock-bit update",
        "During lifetime-counter update",
        "During multi-event-counter update",
        "During record replacement or erase",
        "During UDS/DID readout",
        "During shutdown preparation",
        "During a second event",
        "During a fourth or fifth event",
    ]
    power_modes = [
        "Hard battery disconnect",
        "KL15 off with KL30 retained",
        "KL30 loss with KL15 variation",
        "Ground interruption",
        "Brownout",
        "Slow voltage ramp down",
        "Fast voltage drop",
        "Voltage oscillation around reset threshold",
        "Short power interruption",
        "Repeated power interruptions",
        "Power restored during write",
        "Reverse KL15/KL30 removal order",
        "Loss of CAN supply while ECU supply remains present",
    ]
    critical_mode_rotation = [
        "Hard battery disconnect",
        "Hard battery disconnect",
        "Hard battery disconnect",
        "Hard battery disconnect",
        "Hard battery disconnect",
        "Hard battery disconnect",
        "KL30 loss with KL15 variation",
        "KL15 off with KL30 retained",
        "Brownout",
        "Hard battery disconnect",
    ]
    selected_modes = power_modes + critical_mode_rotation
    for sequence_number, (phase, mode) in enumerate(zip(power_phases, selected_modes, strict=True), start=1):
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-012",
                f"EDR-ICE-MIN-012-V{sequence_number:02d}",
                f"Power interruption: {phase}",
                f"Power mode={mode}; event type=Deployment and Near Crash parameter sweep when approved; interruption phase={phase}.",
                TBC,
                f"{SOURCE_NAME} | EDR_Requirements!B9:E10; B53:E57",
                "ON HOLD",
                "Minimum one-factor coverage: every phase and named power mode appears at least once. NVM/write/recovery oracle is unavailable.",
            )
        )

    can_vectors = [
        ("V01", "Nominal signal storage", "Nominal values across released resolution, range, and sampling grid."),
        ("V02", "CAN wake-up timing", "Asleep valid wake-up; wake before/at/after T0; repeated wake/sleep; chatter; wrong wake frame; partial wake-up."),
        ("V03", "Crash wake-up without CAN", "Crash wake-up with no CAN data present."),
        ("V04", "Data age and frame timing", "Missing, delayed, jittered, and wrong-cycle-time frames."),
        ("V05", "Frame ordering", "Duplicate and out-of-order frames around EDR sample points."),
        ("V06", "Frame/data integrity", "Rolling counter, CRC, raw overflow, invalid enum, and multiplexer errors."),
        ("V07", "Signal availability and fail-safe", "Timeout, stuck-at, signal unavailable, and released fail-safe reaction."),
        ("V08", "Sample-point edge", "Signal changes immediately before, at, and after every released EDR sample point."),
        ("V09", "Cross-signal consistency", "Speed/wheel speed; brake/deceleration; steering/lateral acceleration; deployment/time; crash/classification."),
        ("V10", "Bus-off and recovery", "Bus-off before event, at T0, during event, and recovery during recording."),
        ("V11", "DBC representation", "Endian, bit position, scaling, offset, unit, resolution, range, clamp, and EDR packing."),
        ("V12", "CAN supply loss", "Loss of CAN supply while ECU supply remains present."),
    ]
    for suffix, scenario, inputs in can_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-013",
                f"EDR-ICE-MIN-013-{suffix}",
                scenario,
                inputs,
                TBC,
                source_reference(7, "3"),
                "ON HOLD",
                "W501 matrix, target DBC, sample times, on-fail mapping, and EDR packing are unavailable.",
            )
        )

    diagnostic_vectors = [
        ("V01", "Read during event capture", "Read EDR data while capture is active."),
        ("V02", "Read during NVM activity", "Read during record write, interrupted write, and after reset."),
        ("V03", "Concurrent/repeated reads", "Repeated reads, concurrent requests, and ECU reset during read."),
        ("V04", "Negative diagnostics", "Unsupported DID, incorrect request length, session/security gating, and diagnostic timeout."),
        ("V05", "Data association", "Endianness, EDR1/EDR2 association, counters, lock bits, stale-byte leakage, and record mixing."),
    ]
    for suffix, scenario, inputs in diagnostic_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-014",
                f"EDR-ICE-MIN-014-{suffix}",
                scenario,
                inputs,
                TBC,
                source_reference(5, "1"),
                "ON HOLD",
                "DID/UDS access, response, and concurrency rules are unavailable.",
            )
        )

    variant_vectors = [
        ("V01", "High variant with SRSU", "Side/front behavior against approved high-variant requirements."),
        ("V02", "Domestic configuration", "Variant/coding applicability cross-check."),
        ("V03", "Variant coding changed before/after event", "Pre-existing record and new-event interpretation."),
        ("V04", "Invalid/corrupted variant coding", "EDR behavior, safety reaction, and recovery."),
        ("V05", "Front event across variants", "Verify without-SRSU filtering does not suppress applicable front behavior."),
    ]
    for suffix, scenario, inputs in variant_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-015",
                f"EDR-ICE-MIN-015-{suffix}",
                scenario,
                inputs,
                TBC,
                source_reference(6, "2"),
                "ON HOLD",
                "Only Low/Mid Domestic without-SRSU side-event suppression is source-backed.",
            )
        )

    race_vectors = [
        ("V01", "Second event during first 0-200 ms collection", "First event still collecting initial 200 ms data."),
        ("V02", "Second event during first 200 ms-to-5 s collection", "First event has 200 ms status path but five-second completion is pending."),
        ("V03", "Second event during NVM write/allocation", "Allocation/write/replacement/erase state."),
        ("V04", "Event during diagnostic read", "EDR client is reading data while the event begins."),
        ("V05", "Event during startup/shutdown", "Apply separately during startup and shutdown under approved procedure."),
        ("V06", "Event during CAN wake-up", "Event begins while CAN wake-up occurs."),
        ("V07", "Event during crash wake-up", "Event begins while crash wake-up occurs without/with CAN per approved design."),
        ("V08", "Event after watchdog reset", "Event begins immediately after confirmed watchdog/reset recovery."),
    ]
    for suffix, scenario, inputs in race_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-016",
                f"EDR-ICE-MIN-016-{suffix}",
                scenario,
                inputs,
                TBC,
                f"{SOURCE_NAME} | EDR_Requirements!B5:V57",
                "ON HOLD",
                "Source state-transition, wake-up, reset, and concurrency behavior is unavailable.",
            )
        )

    sequence_vectors = [
        ("V01", "0 events", "No event; repeat default-data and diagnostic consistency observations."),
        ("V02", "1 event", "One Near Crash; record/unlock/CAN suppression path."),
        ("V03", "2 events", "Two Unconfirmed Crash input sequences with FRSU timing variation."),
        ("V04", "3 events", "Three Deployment Events; compare supplied source-vector scope where applicable."),
        ("V05", "4 events", "Mixed Near Crash/Deployment with front followed by side."),
        ("V06", "5 events", "Mixed Near Crash/Unconfirmed/Deployment with side followed by front."),
        ("V07", "10 events", "Repeated Near Crash/Unconfirmed/Deployment stress sequence with overlaps."),
        ("V08", "N events", "Configurable randomized sequence varying classification, source, lock, timing, CAN, power, reset, diagnostic, variant, and initial slots."),
    ]
    for suffix, scenario, inputs in sequence_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-017",
                f"EDR-ICE-MIN-017-{suffix}",
                scenario,
                inputs,
                TBC,
                f"{SOURCE_NAME} | EDR_Requirements!B5:V57",
                "ON HOLD",
                "Only 0-event/near-crash/unconfirmed and supplied three-event rules have partial source support; Event4+ behavior is TBC.",
            )
        )

    counter_vectors = [
        ("V01", "Normal counter value", "Incoming event from a normal observed counter state."),
        ("V02", "Maximum minus one", "Incoming event when each relevant counter is maximum minus one."),
        ("V03", "Maximum", "Incoming event when each relevant counter is at maximum."),
        ("V04", "Rollover or saturation", "Incoming event that would require rollover or saturation handling."),
    ]
    for suffix, scenario, inputs in counter_vectors:
        vectors.append(
            make_vector(
                "EDR-ICE-MIN-018",
                f"EDR-ICE-MIN-018-{suffix}",
                scenario,
                inputs,
                TBC,
                f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49",
                "ON HOLD",
                "Counter width, threshold, rollover/saturation, and discarded-event rules are unavailable.",
            )
        )

    vectors.append(
        make_vector(
            "EDR-ICE-MIN-019",
            "EDR-ICE-MIN-019-V01",
            "Long-duration property-based endurance campaign",
            "Approved bounded campaign using reproducible seeds and non-destructive limits; vary event count, class, source, timing, CAN, power/reset/diagnostic timing, variant, and slots.",
            TBC,
            f"{SOURCE_NAME} | EDR_Requirements!B5:V57",
            "ON HOLD",
            "Campaign duration, NVM impact, invariant set, and allowed failure injection require approval.",
        )
    )
    return vectors


def build_traceability_rows(case_definitions: list[dict[str, Any]]) -> list[list[str]]:
    mapping = {
        "ICE-EDR-R01": ("1", "EDR Default", source_reference(5, "1"), "EDR-ICE-MIN-001"),
        "ICE-EDR-R02": ("2", "ECU variant without SRSU", source_reference(6, "2"), "EDR-ICE-MIN-002; EDR-ICE-MIN-003; EDR-ICE-MIN-015"),
        "ICE-EDR-R03": ("3", "CAN signals", source_reference(7, "3"), "EDR-ICE-MIN-013"),
        "ICE-EDR-R04": ("4", "Near Crash", source_reference(8, "4"), "EDR-ICE-MIN-004; EDR-ICE-MIN-017"),
        "ICE-EDR-R05": ("5", "CompletionStatus", source_reference(9, "5"), "EDR-ICE-MIN-006; EDR-ICE-MIN-007; EDR-ICE-MIN-012"),
        "ICE-EDR-R06": ("6", "200ms CompletionStatus", source_reference(10, "6"), "EDR-ICE-MIN-006; EDR-ICE-MIN-007; EDR-ICE-MIN-012"),
        "ICE-EDR-R07": ("7", "Unconfirmed Crash", source_reference(11, "7"), "EDR-ICE-MIN-005; EDR-ICE-MIN-017"),
        "ICE-EDR-SINGLE-TABLE": ("Table", "Single-event source vectors", f"{SOURCE_NAME} | EDR_Requirements!B23:V30", "EDR-ICE-MIN-008"),
        "ICE-EDR-MULTI-TABLE": ("Table", "Multi-event source vectors", f"{SOURCE_NAME} | EDR_Requirements!B42:V49", "EDR-ICE-MIN-009"),
        "ICE-EDR-COMP-TABLE": ("Table", "Completion-state source table", f"{SOURCE_NAME} | EDR_Requirements!B53:E55", "EDR-ICE-MIN-007"),
    }
    rows: list[list[str]] = []
    case_ids = {case_definition["id"] for case_definition in case_definitions}
    for internal_id, (serial, topic, source, covered_cases) in mapping.items():
        all_cases_exist = all(case_id.strip() in case_ids for case_id in covered_cases.split(";"))
        rows.append(
            [
                internal_id,
                serial,
                topic,
                source,
                covered_cases,
                "Source-row traceability only",
                "Covered" if all_cases_exist else "ERROR",
                "No verified Codebeamer ID/approval status is present in the primary source sheet.",
            ]
        )
    return rows


def build_coverage_rows(vector_counts: dict[str, int]) -> list[list[str]]:
    return [
        ["No event", "EDR default bytes including reserved bytes", "EDR-ICE-MIN-001", vector_counts["EDR-ICE-MIN-001"], "IN REVIEW", "Source-backed content; DID access/length TBC."],
        ["Near crash", "Record, unlock, STS_CRASH/DOOR_UNLOCK suppression", "EDR-ICE-MIN-004", vector_counts["EDR-ICE-MIN-004"], "IN REVIEW", "Source-backed behavior; DID/slot/timing TBC."],
        ["Unconfirmed crash", "Longitudinal input present and both FRSUs=0", "EDR-ICE-MIN-005", vector_counts["EDR-ICE-MIN-005"], "IN REVIEW", "Classification is source-backed; downstream behavior TBC."],
        ["Completion states", "200 ms, five seconds, 0/0, 0/1, 1/don't-care", "EDR-ICE-MIN-006; EDR-ICE-MIN-007", vector_counts["EDR-ICE-MIN-006"] + vector_counts["EDR-ICE-MIN-007"], "IN REVIEW", "Timing equality, durable data, and power profile TBC."],
        ["Three-event binary permutations", "Eight single-event and eight multi-event source vectors", "EDR-ICE-MIN-008; EDR-ICE-MIN-009", vector_counts["EDR-ICE-MIN-008"] + vector_counts["EDR-ICE-MIN-009"], "IN REVIEW", "Exact source-vector outcomes transcribed; Event4+ is not defined."],
        ["Inter-event boundaries", "0/1/299/300/301/499/500/501 ms; 4.999/5.000/5.001 s", "EDR-ICE-MIN-010", vector_counts["EDR-ICE-MIN-010"], "ON HOLD", "Source gives open intervals; equality/time-reference/tolerance TBC."],
        ["Fourth/fifth events", "Storage state, overwrite/rejection/overflow, locked records", "EDR-ICE-MIN-011", vector_counts["EDR-ICE-MIN-011"], "ON HOLD", "Source tables stop at Event3."],
        ["Power interruption", "Every named interruption phase and every named power mode appears at least once", "EDR-ICE-MIN-012", vector_counts["EDR-ICE-MIN-012"], "ON HOLD", "Minimum one-factor plan, not full phase x mode cross-product; NVM/power oracle TBC."],
        ["CAN and wake-up", "Wake-up, quality, invalidity, on-fail, data age, bus-off, cross-signal", "EDR-ICE-MIN-013", vector_counts["EDR-ICE-MIN-013"], "ON HOLD", "W501/DBC/packing/sample/on-fail source unavailable."],
        ["Diagnostics", "Read during capture/write/reset, repeat/concurrent, negative, association", "EDR-ICE-MIN-014", vector_counts["EDR-ICE-MIN-014"], "ON HOLD", "UDS/DID contract unavailable."],
        ["Variants", "Low/Mid without SRSU plus gated High/coding/front-side scope", "EDR-ICE-MIN-002; EDR-ICE-MIN-003; EDR-ICE-MIN-015", vector_counts["EDR-ICE-MIN-002"] + vector_counts["EDR-ICE-MIN-003"] + vector_counts["EDR-ICE-MIN-015"], "IN REVIEW / ON HOLD", "Only Low/Mid Domestic no-side-event behavior is source-backed."],
        ["Race conditions", "Post-crash, NVM, diagnostic, startup/shutdown, wake-up, watchdog", "EDR-ICE-MIN-016", vector_counts["EDR-ICE-MIN-016"], "ON HOLD", "State machine/concurrency behavior unavailable."],
        ["Event counts", "0, 1, 2, 3, 4, 5, 10, N", "EDR-ICE-MIN-017", vector_counts["EDR-ICE-MIN-017"], "ON HOLD", "Event4+, counter, storage, and mixed unconfirmed policy unavailable."],
        ["Counter limits", "Normal, maximum-1, maximum, rollover/saturation", "EDR-ICE-MIN-018", vector_counts["EDR-ICE-MIN-018"], "ON HOLD", "Counter max/width/policy unavailable."],
        ["Endurance/property-based", "Bounded randomized campaign, invariants, shrinking", "EDR-ICE-MIN-019", vector_counts["EDR-ICE-MIN-019"], "ON HOLD", "Campaign limits and full invariant/oracle set unavailable."],
    ]


def build_ambiguity_rows() -> list[list[str]]:
    return [
        ["AMB-001", "Traceability and DID identity", "No Codebeamer IDs/statuses, EDR DID identities, access conditions, lengths, or response rules in EDR_Requirements.", "Provide approved target-variant tracker and UDS/DID specification.", "MIN-001; MIN-014"],
        ["AMB-002", "Referenced W501 matrix unavailable", "Named communication matrix is not available locally.", "Provide released W501 matrix, target DBC, and source-to-EDR mapping.", "MIN-013"],
        ["AMB-003", "Timing reference/equality/tolerance", "Open intervals are stated but equality, timestamp reference, task period, and tolerance are not.", "Define T0/reference, exact 500 ms/5 s behavior, scheduler tick, and tolerance.", "MIN-006; MIN-008; MIN-009; MIN-010"],
        ["AMB-004", "Event4/Event5 behavior", "Source vectors stop at Event3 with two records.", "Define Event4/5/10/N allocation, rejection/overflow, persistence, diagnostics, and counters.", "MIN-011; MIN-017"],
        ["AMB-005", "Unlocked replacement priority", "No deterministic oldest/newest/priority policy is stated.", "Define tie-break and priority order for unlocked records.", "MIN-011"],
        ["AMB-006", "Locked-record/counter policy", "No overwrite permission, lock commit instant, discarded-event handling, or counter saturation/rollover is stated.", "Define lock and counter behavior for every storage state.", "MIN-011; MIN-017; MIN-018"],
        ["AMB-007", "Completion semantics/durability", "Status-bit meanings are present, but data set, durable-write point, and concurrent-event handling are missing.", "Define data scope, durability criterion, flag order, and concurrent-event policy.", "MIN-006; MIN-007; MIN-012"],
        ["AMB-008", "NVM atomicity/recovery", "No NVM layout, CRC, valid marker, write order, erase, energy reserve, reset, or threshold data are provided.", "Provide NVM format and power-fail recovery state machine.", "MIN-011; MIN-012; MIN-014"],
        ["AMB-009", "CAN sample age/packing", "No source message/signal, scaling, invalid code, sample schedule, or EDR packing rule is available.", "Provide per-signal CAN and EDR mapping.", "MIN-013"],
        ["AMB-010", "Diagnostic read contract", "No DID/session/security/NRC/read-while-recording contract is supplied.", "Provide approved UDS/EDR-DID access and concurrency behavior.", "MIN-001; MIN-004; MIN-008; MIN-009; MIN-014"],
        ["AMB-011", "Unconfirmed crash/T0 behavior", "Only classifier input is stated; resulting record/lock/CAN/delayed confirmation behavior is absent.", "Define T0 and unconfirmed crash lifecycle.", "MIN-005; MIN-006; MIN-016; MIN-017"],
        ["AMB-012", "Reserved-byte default conflict", "Primary EDR requirement says FF.. including reserve bytes; supplemental layout note reportedly says reserved default/deconfigured bits are 0.", "Resolve scope and byte/bit mapping before byte-level sign-off.", "MIN-001"],
        ["AMB-013", "Variant scope", "Only Low/Mid Domestic without-SRSU side-event storage is specified; other behavior is delegated or absent.", "Provide approved variant-code maps and High/market/front/door requirements.", "MIN-002; MIN-003; MIN-015"],
        ["AMB-014", "Execution environment", "No bench profile, stimulus interface, measurement accuracy, reset baseline, or cleanup procedure is supplied.", "Provide approved project/variant bench and evidence plan.", "All procedures"],
    ]


def build_summary_rows(case_definitions: list[dict[str, Any]], parameter_vectors: list[dict[str, str]], source_data: dict[str, Any]) -> list[list[str]]:
    vector_statuses = Counter(vector["status"] for vector in parameter_vectors)
    case_statuses = Counter(case_definition["status"] for case_definition in case_definitions)
    return [
        ["Document title", "ICE Common SRS V1.4 EDR Minimum Coverage Test Specification"],
        ["Minimum procedure count", f"{len(case_definitions)} parameterized test procedures"],
        ["Mandatory execution count", f"{len(parameter_vectors)} independently executable parameter vectors"],
        ["Counting rule", "Use 19 when your test-management process supports parameterized procedures. Materialize 112 individual rows when every vector must be independently planned, selected, and reported."],
        ["Coverage strategy", "Each stated source behavior and every requested scope family is represented at least once. This is a minimum, risk-focused one-factor/sequence suite, not every possible cross-product."],
        ["Power-sweep limit", "The minimum suite uses 23 power vectors so every named interruption phase and every named power mode appears at least once. A complete phase x mode cross-product alone would require 299 power trials."],
        ["Source workbook", str(SOURCE_WORKBOOK)],
        ["Source SHA-256", source_data["source_hash"]],
        ["Source evidence", "Rows 5-11, 23-30, 32, 42-49, and 53-55 are re-verified during generation; source vectors are transcribed dynamically."],
        ["Traceability", SOURCE_ID_NOTICE],
        ["Procedure status count", f"IN REVIEW={case_statuses['IN REVIEW']}; ON HOLD={case_statuses['ON HOLD']}"],
        ["Vector status count", f"IN REVIEW={vector_statuses['IN REVIEW']}; ON HOLD={vector_statuses['ON HOLD']}"],
        ["Highlighter convention", "Every Test Case Name cell is filled bright yellow in Test Case Catalogue and every title row in Test Specification."],
        ["Safety boundary", "Generation and validation are offline only. No ECU, ARIA API, power card, diagnostics, fault injection, deployment output, NVM operation, or network was operated."],
        ["Codebeamer/Veoneer status", "Not import-ready. The supplied EDR_Requirements sheet lacks verified Codebeamer IDs and approval status; use source-row traceability until approved tracker evidence is supplied."],
        ["Generated on", date.today().isoformat()],
    ]


def apply_border(cell: Any) -> None:
    cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)


def prepare_table_sheet(
    workbook: Workbook,
    sheet_name: str,
    title: str,
    subtitle: str,
    headers: list[str],
    rows: list[list[Any]],
    tab_color: str,
    highlight_header: str | None = None,
) -> Any:
    sheet = workbook.create_sheet(sheet_name)
    sheet.sheet_properties.tabColor = tab_color
    sheet.sheet_view.showGridLines = False
    width = len(headers)
    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=width)
    title_cell = sheet.cell(1, 1, title)
    title_cell.fill = PatternFill("solid", fgColor=NAVY)
    title_cell.font = Font(bold=True, color=WHITE, size=14)
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    sheet.row_dimensions[1].height = 24
    sheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=width)
    subtitle_cell = sheet.cell(2, 1, subtitle)
    subtitle_cell.font = Font(italic=True, color="404040")
    subtitle_cell.alignment = Alignment(wrap_text=True, vertical="top")
    sheet.row_dimensions[2].height = 36
    for column_number, header in enumerate(headers, start=1):
        header_cell = sheet.cell(4, column_number, header)
        header_cell.fill = PatternFill("solid", fgColor=NAVY)
        header_cell.font = Font(bold=True, color=WHITE)
        header_cell.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        apply_border(header_cell)
    sheet.row_dimensions[4].height = 34
    highlighted_column = headers.index(highlight_header) + 1 if highlight_header in headers else None
    for row_number, row_values in enumerate(rows, start=5):
        longest_value = 0
        for column_number, value in enumerate(row_values, start=1):
            cell = sheet.cell(row_number, column_number, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            apply_border(cell)
            if row_number % 2:
                cell.fill = PatternFill("solid", fgColor="F8FBFD")
            if highlighted_column == column_number:
                cell.fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
                cell.font = Font(bold=True, color="000000")
            longest_value = max(longest_value, len(str(value)))
        sheet.row_dimensions[row_number].height = min(150, max(26, 14 * (1 + longest_value // 110)))
    sheet.freeze_panes = "A5"
    sheet.auto_filter.ref = f"A4:{get_column_letter(width)}{max(4, 4 + len(rows))}"
    for column_number, header in enumerate(headers, start=1):
        values = [str(header)] + [str(row[column_number - 1]) for row in rows]
        maximum_length = max(len(value.split("\n")[0]) for value in values)
        sheet.column_dimensions[get_column_letter(column_number)].width = min(65, max(13, maximum_length + 2))
    return sheet


def style_status_column(sheet: Any, header: str) -> None:
    header_index = {cell.value: cell.column for cell in sheet[4]}
    if header not in header_index:
        return
    column_number = header_index[header]
    for row_number in range(5, sheet.max_row + 1):
        cell = sheet.cell(row_number, column_number)
        value = cell_text(cell.value)
        if "ON HOLD" in value:
            cell.fill = PatternFill("solid", fgColor=PALE_AMBER)
        elif "IN REVIEW" in value:
            cell.fill = PatternFill("solid", fgColor=PALE_BLUE)
        elif "Covered" in value:
            cell.fill = PatternFill("solid", fgColor=PALE_GREEN)


def write_test_specification_sheet(
    workbook: Workbook,
    case_definitions: list[dict[str, Any]],
    vector_counts: dict[str, int],
) -> Any:
    sheet = workbook.create_sheet("Test Specification")
    sheet.sheet_properties.tabColor = HIGHLIGHT_YELLOW
    sheet.sheet_view.showGridLines = False
    sheet.merge_cells("B1:I1")
    title_cell = sheet["B1"]
    title_cell.value = "ICE Common SRS V1.4 EDR Minimum Coverage Test Specification"
    title_cell.fill = PatternFill("solid", fgColor=NAVY)
    title_cell.font = Font(bold=True, color=WHITE, size=14)
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    sheet.row_dimensions[1].height = 24
    sheet.merge_cells("B2:I2")
    subtitle_cell = sheet["B2"]
    subtitle_cell.value = "Test case names are highlighted yellow. Parameter Vectors contain every mandatory independent execution instance. ON HOLD cases require clarification before pass/fail execution."
    subtitle_cell.font = Font(italic=True, color="404040")
    subtitle_cell.alignment = Alignment(wrap_text=True, vertical="top")
    sheet.row_dimensions[2].height = 38
    headers = [
        "Test Case Name / Step No",
        "Test Step / Description",
        "Expected Observation",
        "Source Reference",
        "Priority",
        "Vector Count",
        "Execution Status",
        "Ambiguity / Notes",
    ]
    for column_number, header in enumerate(headers, start=2):
        header_cell = sheet.cell(4, column_number, header)
        header_cell.fill = PatternFill("solid", fgColor=NAVY)
        header_cell.font = Font(bold=True, color=WHITE)
        header_cell.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        apply_border(header_cell)
    sheet.row_dimensions[4].height = 36
    row_number = 5
    for case_definition in case_definitions:
        title_values = [
            f"{case_definition['id']} - {case_definition['name']}",
            f"Objective: {case_definition['objective']}",
            f"Scope: {case_definition['scope']}",
            case_definition["source"],
            case_definition["priority"],
            str(vector_counts[case_definition["id"]]),
            case_definition["status"],
            f"{case_definition['ambiguities']} | {case_definition['notes']}",
        ]
        for column_number, value in enumerate(title_values, start=2):
            cell = sheet.cell(row_number, column_number, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            apply_border(cell)
            cell.fill = PatternFill("solid", fgColor=PALE_YELLOW)
            cell.font = Font(bold=column_number == 2, color="000000")
        sheet.cell(row_number, 2).fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
        sheet.row_dimensions[row_number].height = 58
        row_number += 1

        pre_action_values = [
            "Pre-Action",
            case_definition["pre_action"],
            "Required preconditions are recorded and the execution boundary is understood.",
            case_definition["source"],
            case_definition["priority"],
            "",
            case_definition["status"],
            case_definition["ambiguities"],
        ]
        for column_number, value in enumerate(pre_action_values, start=2):
            cell = sheet.cell(row_number, column_number, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            apply_border(cell)
            cell.fill = PatternFill("solid", fgColor=PALE_BLUE)
        sheet.cell(row_number, 2).font = Font(bold=True)
        sheet.row_dimensions[row_number].height = 54
        row_number += 1

        for step_number, (action, expected_result) in enumerate(case_definition["steps"], start=1):
            step_values = [
                str(step_number),
                action,
                expected_result,
                case_definition["source"],
                case_definition["priority"],
                "",
                case_definition["status"],
                case_definition["ambiguities"],
            ]
            for column_number, value in enumerate(step_values, start=2):
                cell = sheet.cell(row_number, column_number, value)
                cell.alignment = Alignment(wrap_text=True, vertical="top")
                apply_border(cell)
                if row_number % 2:
                    cell.fill = PatternFill("solid", fgColor="F8FBFD")
            sheet.row_dimensions[row_number].height = 52
            row_number += 1

        post_action_values = [
            "Post-Action",
            case_definition["post_action"],
            "Evidence is retained and the approved test environment is restored without an unauthorized persistent operation.",
            case_definition["source"],
            case_definition["priority"],
            "",
            case_definition["status"],
            case_definition["ambiguities"],
        ]
        for column_number, value in enumerate(post_action_values, start=2):
            cell = sheet.cell(row_number, column_number, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            apply_border(cell)
            cell.fill = PatternFill("solid", fgColor=PALE_GREEN)
        sheet.cell(row_number, 2).font = Font(bold=True)
        sheet.row_dimensions[row_number].height = 45
        row_number += 2

    sheet.freeze_panes = "B5"
    sheet.column_dimensions["A"].width = 2
    column_widths = {"B": 34, "C": 55, "D": 55, "E": 42, "F": 10, "G": 12, "H": 15, "I": 55}
    for column_name, width in column_widths.items():
        sheet.column_dimensions[column_name].width = width
    return sheet


def build_catalogue_rows(case_definitions: list[dict[str, Any]], vector_counts: dict[str, int]) -> list[list[str]]:
    return [
        [
            case_definition["id"],
            case_definition["name"],
            case_definition["objective"],
            case_definition["scope"],
            case_definition["source"],
            case_definition["priority"],
            str(vector_counts[case_definition["id"]]),
            case_definition["status"],
            case_definition["ambiguities"],
            case_definition["notes"],
        ]
        for case_definition in case_definitions
    ]


def create_coverage_matrix_workbook(source_data: dict[str, Any], case_definitions: list[dict[str, Any]], parameter_vectors: list[dict[str, str]]) -> None:
    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    vector_counts = Counter(vector["case_id"] for vector in parameter_vectors)
    workbook = Workbook()
    workbook.remove(workbook.active)
    workbook.properties.title = "ICE Common SRS V1.4 EDR Minimum Coverage Test Specification"
    workbook.properties.subject = "Source-row-traceable offline EDR test-specification authoring package"
    workbook.properties.creator = "GitHub Copilot - offline generator"
    workbook.properties.description = "19 parameterized procedures and 112 execution vectors; not Codebeamer import-ready without approved traceability IDs."

    summary_sheet = prepare_table_sheet(
        workbook,
        "Minimum Suite Summary",
        "ICE Common SRS V1.4 EDR Minimum Coverage Test Specification",
        "A 19-procedure minimum suite with 112 independently executable parameter vectors. Yellow cells identify test case names throughout the specification.",
        ["Item", "Value"],
        build_summary_rows(case_definitions, parameter_vectors, source_data),
        PALE_GREEN,
    )
    summary_sheet.column_dimensions["A"].width = 34
    summary_sheet.column_dimensions["B"].width = 120

    write_test_specification_sheet(workbook, case_definitions, vector_counts)

    catalogue_sheet = prepare_table_sheet(
        workbook,
        "Test Case Catalogue",
        "Minimum Test Case Catalogue",
        "Exactly 19 parameterized test procedures. Test Case Name cells are bright-yellow highlighted for rapid identification.",
        ["Test Case ID", "Test Case Name", "Test Objective", "Scope Covered", "Source Reference", "Priority", "Mandatory Vector Count", "Execution Status", "Ambiguity IDs", "Notes"],
        build_catalogue_rows(case_definitions, vector_counts),
        HIGHLIGHT_YELLOW,
        "Test Case Name",
    )
    style_status_column(catalogue_sheet, "Execution Status")

    case_names = {case_definition["id"]: case_definition["name"] for case_definition in case_definitions}
    parameter_rows = [
        [
            vector["case_id"],
            vector["vector_id"],
            case_names[vector["case_id"]],
            vector["scenario"],
            vector["inputs"],
            vector["expected_result"],
            vector["source"],
            vector["status"],
            vector["notes"],
        ]
        for vector in parameter_vectors
    ]
    parameter_sheet = prepare_table_sheet(
        workbook,
        "Parameter Vectors",
        "Mandatory Parameter Vectors",
        "112 independently executable vectors. A parameterized test procedure is complete only when all of its mandatory vectors are executed or formally justified as deferred.",
        ["Test Case ID", "Parameter Vector ID", "Test Case Name", "Scenario", "Input / Condition", "Expected Result", "Source Evidence", "Vector Status", "Notes"],
        parameter_rows,
        PALE_BLUE,
        "Test Case Name",
    )
    style_status_column(parameter_sheet, "Vector Status")
    parameter_sheet.column_dimensions["A"].width = 23
    parameter_sheet.column_dimensions["B"].width = 27
    parameter_sheet.column_dimensions["C"].width = 42
    parameter_sheet.column_dimensions["D"].width = 40
    parameter_sheet.column_dimensions["E"].width = 70
    parameter_sheet.column_dimensions["F"].width = 95
    parameter_sheet.column_dimensions["G"].width = 52
    parameter_sheet.column_dimensions["H"].width = 16
    parameter_sheet.column_dimensions["I"].width = 55

    traceability_sheet = prepare_table_sheet(
        workbook,
        "Traceability",
        "Source-Row Traceability",
        "Internal keys are source-row anchors, not verified Codebeamer IDs. All test cases retain evidence limits explicitly.",
        ["Internal Requirement / Table ID", "Source S.No", "Topic", "Source Reference", "Covered Procedures", "Traceability Type", "Coverage Status", "Limit"],
        build_traceability_rows(case_definitions),
        PALE_GREEN,
    )
    style_status_column(traceability_sheet, "Coverage Status")

    coverage_sheet = prepare_table_sheet(
        workbook,
        "Coverage Matrix",
        "Minimum-Suite Scope Coverage",
        "Every requested scope family is represented. ON HOLD means the coverage design exists but a deterministic pass/fail oracle is unavailable.",
        ["Scope Family", "Behavior / Condition", "Procedure Coverage", "Mandatory Vectors", "Status", "Evidence Limit"],
        build_coverage_rows(vector_counts),
        PALE_BLUE,
    )
    style_status_column(coverage_sheet, "Status")

    ambiguity_sheet = prepare_table_sheet(
        workbook,
        "Ambiguity Gates",
        "Ambiguity and Clarification Gates",
        "No ON HOLD vector may be marked pass/fail until its required evidence is supplied and reviewed.",
        ["Ambiguity ID", "Topic", "Why the Evidence Is Insufficient / Conflicting", "Required Clarification", "Affected Minimum Procedures"],
        build_ambiguity_rows(),
        PALE_AMBER,
    )

    prioritization_rows = [
        ["P0", "Possible loss/corruption of crash data or completion/lock/storage integrity", "; ".join(case_definition["id"] for case_definition in case_definitions if case_definition["priority"] == "P0")],
        ["P1", "Lock/overwrite/completion association, CAN/diagnostic/variant correctness, race behavior", "; ".join(case_definition["id"] for case_definition in case_definitions if case_definition["priority"] == "P1")],
        ["P2", "No standalone procedure in this minimum source scope", "No source-backed P2-only split; CAN/diagnostic/variant risks remain P1 due data-integrity impact."],
        ["P3", "Long-duration robustness/endurance", "EDR-ICE-MIN-019"],
        ["Minimum regression execution", "Source-backed/partial-oracle procedures first", "EDR-ICE-MIN-001 through EDR-ICE-MIN-009; execute all 25 IN REVIEW vectors after approved interface setup."],
        ["Full scope execution", "All 19 procedures and 112 vectors after gap closure", "All ON HOLD vectors require architect/source closure before a pass/fail result."],
    ]
    prepare_table_sheet(
        workbook,
        "Prioritization",
        "Prioritization and Execution Order",
        "P0 procedures lead. The minimum regression subset is not a substitute for the 112-vector scope suite.",
        ["Priority / Suite", "Intent", "Procedure Coverage"],
        prioritization_rows,
        PALE_GREEN,
    )

    generator_rows = [
        ["Generator input factors", "Event count; classification; deployment/lock status; front/side source; T0 source; inter-event timing; CAN validity/value; power/reset/diagnostic timing; variant; initial EDR slots."],
        ["Source-backed invariants", "No-event data FF.. including reserve bytes; near crash record unlocked; no near-crash STS_CRASH/DOOR_UNLOCK; completion flags have stated post-time meanings; source-vector fields match selected row."],
        ["Review-only invariants", "Locked record unchanged unless clarified requirement permits it; no valid record mixes events; completed record persists across power cycle; counters/time pairs are consistent unless clarified policy states otherwise."],
        ["Sequence minimization", "On failure, shrink by removing events, simplifying event class/source, widening timing, removing CAN/power/diagnostic disturbances, and retaining the smallest reproducible prefix."],
        ["Pseudocode", "for seed in approved_seeds: sequence=generate(all_factors); establish_approved_baseline(); execute_only_when_authorized(sequence); observe(); assert_source_backed_invariants(); record_TBC_without_pass_fail(); if failure: shrink(sequence)."],
    ]
    prepare_table_sheet(
        workbook,
        "Automation Strategy",
        "Automation and Property-Based Campaign Strategy",
        "Design only. No automation command, ARIA call, or ECU operation is generated or run here.",
        ["Element", "Design"],
        generator_rows,
        PALE_BLUE,
    )

    workbook.save(OUTPUT_WORKBOOK)


def validate_design(case_definitions: list[dict[str, Any]], parameter_vectors: list[dict[str, str]]) -> dict[str, Any]:
    case_ids = [case_definition["id"] for case_definition in case_definitions]
    vector_ids = [vector["vector_id"] for vector in parameter_vectors]
    if len(case_definitions) != 19:
        raise ValueError(f"Minimum suite must contain 19 procedures, found {len(case_definitions)}.")
    if len(case_ids) != len(set(case_ids)):
        raise ValueError("Minimum suite has duplicate test-case IDs.")
    if len(parameter_vectors) != 112:
        raise ValueError(f"Minimum suite must contain 112 mandatory parameter vectors, found {len(parameter_vectors)}.")
    if len(vector_ids) != len(set(vector_ids)):
        raise ValueError("Minimum suite has duplicate parameter-vector IDs.")
    vector_counts = Counter(vector["case_id"] for vector in parameter_vectors)
    missing_vectors = [case_id for case_id in case_ids if vector_counts[case_id] == 0]
    if missing_vectors:
        raise ValueError(f"Minimum procedures with no parameter vectors: {missing_vectors}")
    required_case_counts = {
        "EDR-ICE-MIN-007": 3,
        "EDR-ICE-MIN-008": 8,
        "EDR-ICE-MIN-009": 8,
        "EDR-ICE-MIN-010": 11,
        "EDR-ICE-MIN-011": 10,
        "EDR-ICE-MIN-012": 23,
        "EDR-ICE-MIN-013": 12,
        "EDR-ICE-MIN-014": 5,
        "EDR-ICE-MIN-015": 5,
        "EDR-ICE-MIN-016": 8,
        "EDR-ICE-MIN-017": 8,
        "EDR-ICE-MIN-018": 4,
        "EDR-ICE-MIN-019": 1,
    }
    for case_id, expected_count in required_case_counts.items():
        if vector_counts[case_id] != expected_count:
            raise ValueError(f"{case_id} expected {expected_count} vectors, found {vector_counts[case_id]}.")
    vector_statuses = Counter(vector["status"] for vector in parameter_vectors)
    if vector_statuses != Counter({"IN REVIEW": 25, "ON HOLD": 87}):
        raise ValueError(f"Unexpected vector status distribution: {dict(vector_statuses)}")
    return {
        "procedure_count": len(case_definitions),
        "parameter_vector_count": len(parameter_vectors),
        "procedure_status_counts": dict(Counter(case_definition["status"] for case_definition in case_definitions)),
        "vector_status_counts": dict(vector_statuses),
        "vectors_by_procedure": dict(sorted(vector_counts.items())),
    }


def highlight_is_present(cell: Any) -> bool:
    return cell.fill.fill_type == "solid" and (cell.fill.fgColor.rgb or "").endswith(HIGHLIGHT_YELLOW)


def validate_coverage_matrix_workbook(path: Path, expected_design: dict[str, Any]) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Generated workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=False)
    required_sheets = [
        "Minimum Suite Summary",
        "Test Specification",
        "Test Case Catalogue",
        "Parameter Vectors",
        "Traceability",
        "Coverage Matrix",
        "Ambiguity Gates",
        "Prioritization",
        "Automation Strategy",
    ]
    missing_sheets = [sheet_name for sheet_name in required_sheets if sheet_name not in workbook.sheetnames]
    if missing_sheets:
        raise ValueError(f"Missing required workbook sheets: {missing_sheets}")

    catalogue = workbook["Test Case Catalogue"]
    catalogue_headers = [cell_text(cell.value) for cell in catalogue[4]]
    expected_catalogue_headers = ["Test Case ID", "Test Case Name", "Test Objective", "Scope Covered", "Source Reference", "Priority", "Mandatory Vector Count", "Execution Status", "Ambiguity IDs", "Notes"]
    if catalogue_headers != expected_catalogue_headers:
        raise ValueError("Test Case Catalogue headers are invalid.")
    catalogue_rows = [row for row in catalogue.iter_rows(min_row=5, values_only=False) if any(cell.value is not None and str(cell.value) != "" for cell in row)]
    if len(catalogue_rows) != expected_design["procedure_count"]:
        raise ValueError("Test Case Catalogue count does not match the minimum design.")
    highlighted_catalogue_names = sum(1 for row in catalogue_rows if highlight_is_present(row[1]))
    if highlighted_catalogue_names != expected_design["procedure_count"]:
        raise ValueError("Every Test Case Name in Test Case Catalogue must be yellow highlighted.")

    specification = workbook["Test Specification"]
    title_cells = [
        cell
        for cell in specification["B"]
        if isinstance(cell.value, str) and cell.value.startswith("EDR-ICE-MIN-") and " - " in cell.value
    ]
    if len(title_cells) != expected_design["procedure_count"]:
        raise ValueError("Test Specification does not contain one title row per minimum test case.")
    if sum(1 for cell in title_cells if highlight_is_present(cell)) != expected_design["procedure_count"]:
        raise ValueError("Every Test Specification test-case title must be yellow highlighted.")

    parameter_sheet = workbook["Parameter Vectors"]
    parameter_headers = [cell_text(cell.value) for cell in parameter_sheet[4]]
    expected_parameter_headers = ["Test Case ID", "Parameter Vector ID", "Test Case Name", "Scenario", "Input / Condition", "Expected Result", "Source Evidence", "Vector Status", "Notes"]
    if parameter_headers != expected_parameter_headers:
        raise ValueError("Parameter Vectors headers are invalid.")
    parameter_rows = [row for row in parameter_sheet.iter_rows(min_row=5, values_only=False) if any(cell.value is not None and str(cell.value) != "" for cell in row)]
    if len(parameter_rows) != expected_design["parameter_vector_count"]:
        raise ValueError("Parameter-vector count does not match the minimum design.")
    vector_ids = [cell_text(row[1].value) for row in parameter_rows]
    if len(vector_ids) != len(set(vector_ids)):
        raise ValueError("Parameter Vectors sheet contains duplicate IDs.")
    highlighted_parameter_names = sum(1 for row in parameter_rows if highlight_is_present(row[2]))
    if highlighted_parameter_names != expected_design["parameter_vector_count"]:
        raise ValueError("Every Parameter Vectors Test Case Name must be yellow highlighted.")
    observed_vector_statuses = Counter(cell_text(row[7].value) for row in parameter_rows)
    if dict(observed_vector_statuses) != expected_design["vector_status_counts"]:
        raise ValueError("Workbook vector-status distribution does not match the minimum design.")

    coverage_scope = {
        cell_text(row[0].value)
        for row in workbook["Coverage Matrix"].iter_rows(min_row=5, values_only=False)
        if row and row[0].value is not None
    }
    required_scope = {"No event", "Near crash", "Unconfirmed crash", "Completion states", "Three-event binary permutations", "Inter-event boundaries", "Fourth/fifth events", "Power interruption", "CAN and wake-up", "Diagnostics", "Variants", "Race conditions", "Event counts", "Counter limits", "Endurance/property-based"}
    if not required_scope.issubset(coverage_scope):
        raise ValueError("Coverage Matrix does not represent every minimum-suite scope family.")

    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "procedure_count": expected_design["procedure_count"],
        "parameter_vector_count": expected_design["parameter_vector_count"],
        "yellow_highlighted_catalogue_names": highlighted_catalogue_names,
        "yellow_highlighted_specification_names": len(title_cells),
        "yellow_highlighted_vector_names": highlighted_parameter_names,
        "procedure_status_counts": expected_design["procedure_status_counts"],
        "vector_status_counts": dict(observed_vector_statuses),
        "required_scope_present": True,
        "codebeamer_import_ready": False,
        "codebeamer_limit": SOURCE_ID_NOTICE,
    }


VEONEER_HEADERS = ["Test Case Name", "Step No", "Test Step", "Expected Observation"]
VEONEER_NAME_STEMS = {
    "EDR-ICE-MIN-001": "EDR_DefaultDID_NoEvent",
    "EDR-ICE-MIN-002": "EDR_Variant_DomesticLowNoSRSU",
    "EDR-ICE-MIN-003": "EDR_Variant_DomesticMidNoSRSU",
    "EDR-ICE-MIN-004": "EDR_NearCrash_UnlockedRecord",
    "EDR-ICE-MIN-005": "EDR_UnconfirmedCrash_FRSUZero",
    "EDR-ICE-MIN-006": "EDR_CompletionStatus_Timing",
    "EDR-ICE-MIN-007": "EDR_CompletionStatus_BatteryCutoff",
    "EDR-ICE-MIN-008": "EDR_SingleEvent_ThreeEventSequence",
    "EDR-ICE-MIN-009": "EDR_MultiEvent_ThreeEventSequence",
    "EDR-ICE-MIN-010": "EDR_Timing_InterEventBoundary",
    "EDR-ICE-MIN-011": "EDR_Storage_FourthFifthEvent",
    "EDR-ICE-MIN-012": "EDR_PowerInterruption_Atomicity",
    "EDR-ICE-MIN-013": "EDR_CANWakeup_DataQuality",
    "EDR-ICE-MIN-014": "EDR_Diagnostics_ReadConsistency",
    "EDR-ICE-MIN-015": "EDR_Variant_FrontSideApplicability",
    "EDR-ICE-MIN-016": "EDR_Race_ConcurrentOperatingMode",
    "EDR-ICE-MIN-017": "EDR_Sequence_ZeroToNEvents",
    "EDR-ICE-MIN-018": "EDR_Counters_MetamorphicConsistency",
    "EDR-ICE-MIN-019": "EDR_Endurance_PropertyBased",
}


def build_veoneer_test_cases(
    case_definitions: list[dict[str, Any]],
    parameter_vectors: list[dict[str, str]],
) -> list[dict[str, Any]]:
    """Materialize every mandatory vector as one independently executable Veoneer case."""
    definitions_by_id = {case_definition["id"]: case_definition for case_definition in case_definitions}
    test_cases: list[dict[str, Any]] = []
    for sequence_number, vector in enumerate(parameter_vectors, start=1):
        definition = definitions_by_id.get(vector["case_id"])
        if definition is None:
            raise ValueError(f"Parameter vector {vector['vector_id']} has no test-case definition.")
        name_stem = VEONEER_NAME_STEMS.get(vector["case_id"])
        if name_stem is None:
            raise ValueError(f"No Veoneer name stem is defined for {vector['case_id']}.")
        test_name = f"{name_stem}_{sequence_number:03d}"
        description = "\n".join(
            [
                f"S.No: {sequence_number}",
                f"Test Case ID: {vector['vector_id']}",
                f"Test Objective: {definition['objective']}",
                f"Scope: {definition['scope']}",
                f"Parameter Vector: {vector['scenario']}",
                f"Priority: {definition['priority']}",
                f"Source Reference: {vector['source']}",
                "Verifies: TBD (verified Codebeamer artifact ID and approval status are unavailable in EDR_Requirements; source-row traceability is retained).",
                f"Execution Status: {vector['status']}",
                f"Requirement Ambiguity: {definition['ambiguities']}",
                f"Notes: {definition['notes']} {vector['notes']}",
            ]
        )
        steps: list[list[str]] = [
            [
                "1",
                f"Pre Action: Set bench to normal condition using the approved fault-free project profile. {definition['pre_action']}",
                "System is in the approved normal state, no unintended faults are present, and required baseline evidence is retained.",
            ],
            [
                "2",
                f"Configure and document parameter vector {vector['vector_id']}: {vector['inputs']}",
                "The selected input sequence, configuration, timing reference, and measurement uncertainty are traceably recorded.",
            ],
        ]
        for step_number, (action, expected_result) in enumerate(definition["steps"], start=3):
            steps.append([str(step_number), action, expected_result])
        verification_step = len(steps) + 1
        steps.append(
            [
                str(verification_step),
                "Read applicable EDR data, CAN evidence, and diagnostic evidence only through the approved interface after the required source-defined or approved observation interval.",
                "Raw evidence is retained. No DID, DTC, response byte, NRC, or status byte absent from the supplied sources is accepted as a test oracle.",
            ]
        )
        comparison_step = len(steps) + 1
        steps.append(
            [
                str(comparison_step),
                f"Compare retained evidence with the selected vector result for {vector['vector_id']}.",
                vector["expected_result"],
            ]
        )
        post_action_step = len(steps) + 1
        steps.append(
            [
                str(post_action_step),
                f"Post Action: {definition['post_action']}",
                "Required evidence is retained and the approved test environment is restored. Do not clear crash-locked or persistent data without separate authorization.",
            ]
        )
        test_cases.append(
            {
                "Sno": sequence_number,
                "Test Case Name": test_name,
                "Test Case Description": description,
                "Verifies": ["TBD"],
                "Pre Action": definition["pre_action"],
                "Steps": steps,
                "Post Action": definition["post_action"],
            }
        )
    return test_cases


def style_veoneer_workbook(path: Path, test_cases: list[dict[str, Any]]) -> None:
    workbook = load_workbook(path)
    if workbook.sheetnames != ["EDR Test Spec"]:
        raise ValueError("The Veoneer test specification must have exactly one EDR Test Spec worksheet.")
    sheet = workbook["EDR Test Spec"]
    header_values = [cell_text(sheet.cell(1, column_number).value) for column_number in range(1, 5)]
    if header_values != VEONEER_HEADERS:
        raise ValueError("The Veoneer writer did not create the expected four-column header row.")
    test_names = {test_case["Test Case Name"] for test_case in test_cases}
    title_rows: list[int] = []
    for row_number in range(2, sheet.max_row + 1):
        title_value = cell_text(sheet.cell(row_number, 2).value)
        if title_value in test_names:
            title_rows.append(row_number)

    if len(title_rows) != len(test_cases):
        raise ValueError("Could not locate every Veoneer test-case title row for styling.")

    for column_number in range(1, 5):
        header_cell = sheet.cell(1, column_number)
        header_cell.fill = PatternFill("solid", fgColor=NAVY)
        header_cell.font = Font(bold=True, color=WHITE)
        header_cell.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        apply_border(header_cell)
    sheet.row_dimensions[1].height = 24

    for row_number in range(2, sheet.max_row + 1):
        step_number = cell_text(sheet.cell(row_number, 2).value)
        action = cell_text(sheet.cell(row_number, 3).value)
        for column_number in range(1, 5):
            cell = sheet.cell(row_number, column_number)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            apply_border(cell)
        if row_number in title_rows:
            sheet.cell(row_number, 2).fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
            sheet.cell(row_number, 2).font = Font(bold=True, color="000000")
            sheet.cell(row_number, 3).fill = PatternFill("solid", fgColor=PALE_YELLOW)
            sheet.cell(row_number, 3).font = Font(bold=True, color="000000")
            sheet.row_dimensions[row_number].height = 156
        elif action.startswith("Pre Action:"):
            for column_number in range(2, 5):
                sheet.cell(row_number, column_number).fill = PatternFill("solid", fgColor=PALE_BLUE)
            sheet.row_dimensions[row_number].height = 66
        elif action.startswith("Post Action:"):
            for column_number in range(2, 5):
                sheet.cell(row_number, column_number).fill = PatternFill("solid", fgColor=PALE_GREEN)
            sheet.row_dimensions[row_number].height = 60
        elif step_number.isdigit():
            sheet.row_dimensions[row_number].height = 58

    sheet.column_dimensions["A"].width = 18
    sheet.column_dimensions["B"].width = 42
    sheet.column_dimensions["C"].width = 92
    sheet.column_dimensions["D"].width = 100
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:D{sheet.max_row}"
    sheet.sheet_view.showGridLines = False
    sheet.sheet_properties.tabColor = HIGHLIGHT_YELLOW
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    workbook.save(path)
    workbook.close()


def create_workbook(source_data: dict[str, Any], case_definitions: list[dict[str, Any]], parameter_vectors: list[dict[str, str]]) -> None:
    del source_data
    test_cases = build_veoneer_test_cases(case_definitions, parameter_vectors)
    write_legacy_title_step_workbook(test_cases, OUTPUT_WORKBOOK, sheet_name="EDR Test Spec", overwrite=True)
    style_veoneer_workbook(OUTPUT_WORKBOOK, test_cases)


def validate_workbook(path: Path, expected_design: dict[str, Any]) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Generated workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=False)
    if workbook.sheetnames != ["EDR Test Spec"]:
        raise ValueError(f"Expected only the Veoneer EDR Test Spec sheet, found {workbook.sheetnames}.")
    sheet = workbook["EDR Test Spec"]
    headers = [cell_text(sheet.cell(1, column_number).value) for column_number in range(1, 5)]
    if headers != VEONEER_HEADERS:
        raise ValueError(f"Veoneer header mismatch: {headers}")

    parsed_cases = excel_to_testcase_dict(path, sheet_name="EDR Test Spec")
    if len(parsed_cases) != expected_design["parameter_vector_count"]:
        raise ValueError(
            f"Expected {expected_design['parameter_vector_count']} independently executable Veoneer cases, found {len(parsed_cases)}."
        )
    names = [case["Test Case Name"] for case in parsed_cases]
    if len(names) != len(set(names)):
        raise ValueError("Veoneer test-case names are not unique.")
    if any(re.fullmatch(r"EDR_[A-Za-z0-9_]+_[0-9]{3}", name) is None for name in names):
        raise ValueError("A Veoneer test-case name does not follow the EDR_<Feature>_<Scenario>_<number> convention.")
    if any("Verifies: TBD" not in case["Test Case Description"] for case in parsed_cases):
        raise ValueError("Every case must expose its missing verified Codebeamer traceability as Verifies: TBD.")
    if any("Source Reference:" not in case["Test Case Description"] for case in parsed_cases):
        raise ValueError("Every case must contain source-row traceability in its description.")
    if any("Test Case ID:" not in case["Test Case Description"] for case in parsed_cases):
        raise ValueError("Every case must identify its parameter-vector ID in its description.")
    if any(len(case["Steps"]) < 8 for case in parsed_cases):
        raise ValueError("Every Veoneer case must contain pre-action, setup, functional, verification, comparison, and post-action steps.")
    if any(not case["Steps"][0][1].startswith("Pre Action:") for case in parsed_cases):
        raise ValueError("Every Veoneer case must begin with a numbered Pre Action step.")
    if any(not case["Steps"][-1][1].startswith("Post Action:") for case in parsed_cases):
        raise ValueError("Every Veoneer case must end with a numbered Post Action step.")

    title_cells = [
        sheet.cell(row_number, 2)
        for row_number in range(2, sheet.max_row + 1)
        if cell_text(sheet.cell(row_number, 2).value) in set(names)
    ]
    if len(title_cells) != expected_design["parameter_vector_count"]:
        raise ValueError("Veoneer title-row count does not match the parameter-vector count.")
    highlighted_titles = sum(1 for cell in title_cells if highlight_is_present(cell))
    if highlighted_titles != expected_design["parameter_vector_count"]:
        raise ValueError("Every Veoneer test-case name in column B must be yellow highlighted.")

    description_statuses = Counter(
        "ON HOLD" if "Execution Status: ON HOLD" in case["Test Case Description"] else "IN REVIEW"
        for case in parsed_cases
    )
    if dict(description_statuses) != expected_design["vector_status_counts"]:
        raise ValueError("Veoneer case execution statuses do not match the source-vector design.")
    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "sheet_name": "EDR Test Spec",
        "veoneer_headers": headers,
        "independently_executable_test_case_count": len(parsed_cases),
        "yellow_highlighted_test_case_names": highlighted_titles,
        "steps_per_case_minimum": min(len(case["Steps"]) for case in parsed_cases),
        "execution_status_counts": dict(description_statuses),
        "source_row_traceability_present": True,
        "codebeamer_import_ready": False,
        "codebeamer_limit": SOURCE_ID_NOTICE,
    }


def generate() -> dict[str, Any]:
    source_data = inspect_source()
    case_definitions = build_case_definitions()
    parameter_vectors = build_parameter_vectors(source_data)
    design_validation = validate_design(case_definitions, parameter_vectors)
    create_workbook(source_data, case_definitions, parameter_vectors)
    workbook_validation = validate_workbook(OUTPUT_WORKBOOK, design_validation)
    report = {
        "document": "ICE Common SRS V1.4 EDR Minimum Coverage Test Specification",
        "source": {
            "path": str(SOURCE_WORKBOOK),
            "sha256": source_data["source_hash"],
            "primary_sheet": "EDR_Requirements",
            "verified_source_rows": sorted(source_data["verified_rows"].keys(), key=int),
            "source_vector_count": len(source_data["vectors"]),
        },
        "minimum_suite": design_validation,
        "workbook_validation": workbook_validation,
        "scope_statement": "The corrected primary workbook materializes all 112 mandatory vectors as individually executable Veoneer-format test cases, grouped by the 19 minimum procedure families.",
        "limitations": [
            "No verified Codebeamer artifact IDs or approval status are present in EDR_Requirements.",
            "M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156 is unavailable locally.",
            "UDS/DID access/packing, Event4+, locked-record policy, counter policy, NVM atomicity, timing equality/tolerance, and bench procedure evidence remain ambiguity gates.",
            "No bench or ECU operation was performed.",
        ],
    }
    OUTPUT_REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate the minimum-scope ICE Common EDR test specification.")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--generate", action="store_true", help="Re-verify source data, generate the workbook, and validate it.")
    action.add_argument("--validate", action="store_true", help="Validate the existing generated workbook only.")
    arguments = parser.parse_args()
    if arguments.generate:
        report = generate()
    else:
        source_data = inspect_source()
        case_definitions = build_case_definitions()
        parameter_vectors = build_parameter_vectors(source_data)
        report = validate_workbook(OUTPUT_WORKBOOK, validate_design(case_definitions, parameter_vectors))
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())