from __future__ import annotations

import contextlib
import io
import json
import shutil
import socket
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

import sys

sys.dont_write_bytecode = True  # imports shared_libraries/: no .pyc into a protected path (D-2026-08-29-11)
REPO_ROOT = Path(__file__).resolve().parents[1]
TOOLS_DIR = REPO_ROOT / "tools"
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import openpyxl  # noqa: E402
from openpyxl.workbook.defined_name import DefinedName  # noqa: E402

import aria_ctl  # noqa: E402
import build_rsu_workbook as rsu  # noqa: E402

SENSOR_XML = """<?xml version="1.0"?><Startup><Sensor name="T">
<RowName name="Range"><Nibble>D9</Nibble><Combo><Parm>240g:9</Parm><Parm>480g:A</Parm></Combo></RowName>
<RowName name="Serial Number"><Nibble>D21-D32</Nibble></RowName>
<RowName name="Select Mode"><Nibble>D33</Nibble></RowName></Sensor></Startup>"""


def marker_workbook(path: Path) -> None:
    """One-slot OR_Start sheet laid out like M314_RSU.xlsx (startup col A, config col B)."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "OR_Start"
    names = {"Value_Slot1_Start": "$A$2", "Value_Slot1_End": "$A$33", "RSU_Mode_Slot1": "$A$34",
             "Repetition_factor_Slot1": "$A$35", "Type_Slot1": "$A$36", "Present_Slot1": "$A$37",
             "Sensor_Status_Slot1": "$A$38", "Config_Start1": "$B$2", "Config_End1": "$B$27", "Config_Parmcount1": "$B$28"}
    for r in range(2, 34):
        ws.cell(r, 1, "0")
    for r, v in zip(range(34, 39), ("0", "16", "0", "1", "0")):
        ws.cell(r, 1, v)
    for r in range(2, 28):
        ws.cell(r, 2, "0")
    ws.cell(28, 2, "26")
    for name, ref in names.items():
        wb.defined_names[name] = DefinedName(name, attr_text=f"OR_Start!{ref}")
    wb.save(path)


class RsuWorkbookTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="rsu-tests-"))
        marker_workbook(self.tmp / "template.xlsx")
        (self.tmp / "XML").mkdir()
        (self.tmp / "XML" / "T_Sensor.xml").write_text(SENSOR_XML, encoding="utf-8")

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def build(self, slot: dict) -> int:
        desc = {"rsu": {"sheet_template": "template.xlsx", "sensors": [{"name": "T", "xml": "T_Sensor.xml"}], "slots": [slot]}}
        (self.tmp / "d.json").write_text(json.dumps(desc), encoding="utf-8")
        return rsu.main(["build", "--descriptor", str(self.tmp / "d.json"), "--out", str(self.tmp / "out.xlsx"),
                         "--config-root", str(self.tmp), "--xml-dir", str(self.tmp / "XML")])

    def test_build_fields_and_export_match_aria_line_rules(self) -> None:
        startup = ["6", "2", "0"] + ["1"] * 29
        code = self.build({"index": 1, "sensor": "T", "startup_params": startup, "config_params": ["1F4"] * 26,
                           "fields": {"Range": "480g", "Serial Number": "0123456789AB"}, "mode": "Async_8Bit_Mode"})
        self.assertEqual(code, 0)
        self.assertEqual(rsu.main(["export-rsux", str(self.tmp / "out.xlsx"), "--slot", "1", "--out-dir", str(self.tmp / "x")]), 0)
        lines = (self.tmp / "x" / "Slot1_Startup.rsux").read_text().split()
        self.assertEqual(len(lines), 37)                                  # 32 hex + mode, rep, type, present, status
        self.assertEqual(lines[8], "A")                                   # D9 = 480g
        self.assertEqual("".join(lines[20:32]), "0123456789AB")           # D21..D32
        self.assertEqual(lines[32:], ["3", "16", "0", "1", "0"])          # Async 8-bit = mode 3
        self.assertEqual(len((self.tmp / "x" / "Slot1_Config.rsux").read_text().split()), 26)

    def test_invalid_data_is_refused_before_writing(self) -> None:
        self.assertEqual(self.build({"index": 1, "startup_params": ["0"] * 31}), 1)      # 31 nibbles
        with self.assertRaises(ValueError):
            self.build({"index": 1, "sensor": "T", "fields": {"Serial Number": "123"}})   # needs 12 digits
        with self.assertRaises(ValueError):
            self.build({"index": 1, "sensor": "T", "fields": {"Select Mode": "1"}})       # D33 is a setting row


class AriaCtlTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="aria-ctl-tests-"))
        self.instances = self.tmp / "Shared" / "ActiveInstances"
        self.instances.mkdir(parents=True)
        (self.tmp / "520").mkdir()
        (self.tmp / "520" / "rts").write_text(json.dumps({"ActiveConfigurationPath": "old.json", "AsqEnabled": False}), encoding="utf-8")
        install = {"dir": self.tmp, "exe": self.tmp / "ARIA.exe", "version": "5.20.0.7"}
        patches = [mock.patch.object(aria_ctl, "ARIA_DATA", self.tmp), mock.patch.object(aria_ctl, "ACTIVE_INSTANCES", self.instances),
                   mock.patch.object(aria_ctl, "aria_pids", return_value=[]),
                   mock.patch.object(aria_ctl, "select_install", return_value=install)]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_stale_instance_is_the_file_of_a_dead_pid(self) -> None:
        (self.instances / "111").write_text('{"LocalApiHostPort": 5000}', encoding="utf-8")
        (self.instances / "222").write_text('{"LocalApiHostPort": 5001}', encoding="utf-8")
        with mock.patch.object(aria_ctl, "running_pids", return_value={222}):
            aria_ctl.main(["clean-stale", "--apply"])
        self.assertEqual(sorted(p.name for p in self.instances.iterdir()), ["222"])

    def test_use_config_checks_files_and_keeps_other_settings(self) -> None:
        proj = self.tmp / "proj"
        proj.mkdir()
        (proj / "AriaMain.json").write_text(json.dumps({"Configuration": {"Chassis": "ChassisConfig.json"}}), encoding="utf-8")
        self.assertEqual(aria_ctl.main(["use-config", str(proj / "AriaMain.json"), "--apply"]), 2)   # ChassisConfig missing
        (proj / "ChassisConfig.json").write_text('{"Configuration": {}}', encoding="utf-8")
        self.assertEqual(aria_ctl.main(["use-config", str(proj / "AriaMain.json"), "--apply"]), 0)
        rts = json.loads((self.tmp / "520" / "rts").read_text(encoding="utf-8"))
        self.assertEqual(rts["ActiveConfigurationPath"], str((proj / "AriaMain.json").resolve()))
        self.assertIs(rts["AsqEnabled"], False)
        self.assertEqual(len(list((self.tmp / "520").glob("rts.bak-*"))), 1)

    def test_api_reference_reads_category_and_name(self) -> None:
        src = self.tmp / "functions.py"
        src.write_text("class Api:\n  class Chassis:\n    def set_trigger() -> None:\n"
                       "      '''Pulse TRIGGER_MAIN.'''\n      Instance.api_request(AriaApiRequest(1, 'Chassis', 'SetTrigger', {}))\n",
                       encoding="utf-8")
        self.assertEqual(aria_ctl.apym_calls(src), [{"call": "Api.Chassis.set_trigger", "args": "", "returns": "None",
                                                     "aria": "Chassis/SetTrigger", "doc": "Pulse TRIGGER_MAIN."}])


ACCF = """<?xml version="1.0"?><CoreConfiguration Version="33"><Hardware><ChassisChannelProperties>
<CommunicationProperties><IsConnected>true</IsConnected></CommunicationProperties>
<LoadboxProperties FilesPath="Loadbox"><LoadboxFile>P.ldbx</LoadboxFile><SystemReset>true</SystemReset>
<ProfileFile>P_Profile.json</ProfileFile><LoadProfile>true</LoadProfile></LoadboxProperties></ChassisChannelProperties></Hardware>
<Periodics FilesPath="Periodics"><CanPeriodicsSwSimulatorProperties Name="CANFD"><Dut>SRS_FD</Dut><IsEnabled>true</IsEnabled>
<DefinitionsFile>CANFD.acpdf</DefinitionsFile></CanPeriodicsSwSimulatorProperties></Periodics></CoreConfiguration>"""
ACPDF = """<XmlAriaCorePeriodics Version="10.0"><Frames>
<CanFrameDefinition Name="SRS1_FD_10" Dlc="64" Id="316"><DatabaseSource>SRS_FD_OLD.dbc</DatabaseSource><Pdus>
<SignalPduDefinition Name="P"><Signals><SignalDefinition Name="SRS_PAB_WARN_STS"><StartBit>183</StartBit><BitLength>1</BitLength>
<Endian>Intel</Endian></SignalDefinition></Signals></SignalPduDefinition></Pdus></CanFrameDefinition>
<CanFrameDefinition Name="SRS_DIAG_RES" Dlc="64" Id="1848"><DatabaseSource>SRS_FD_OLD.dbc</DatabaseSource><Pdus>
<DiagnosticPduDefinition Name="Diag_Pdu"><StartBit>0</StartBit></DiagnosticPduDefinition></Pdus></CanFrameDefinition></Frames></XmlAriaCorePeriodics>"""
DBC = """BO_ 316 SRS1_FD_10: 64 SRS_FD
 SG_ SRS_PAB_WARN_STS : 208|2@1+ (1,0) [0|3] "" VCU
 SG_ STS_SEAT_ODS_PSGR m1 : 10|2@1+ (1,0) [0|3] "" VCU
BO_ 1848 SRS_DIAG_RES: 64 SRS_FD
 SG_ DIAG_SRS_RES_DATA : 7|512@0+ (1,0) [0|0] "" Tester
BO_ 3221225472 VECTOR__INDEPENDENT_SIG_MSG: 0 Vector__XXX
"""


class InputCheckTests(unittest.TestCase):
    setUp, tearDown = AriaCtlTests.setUp, AriaCtlTests.tearDown  # the same fake ARIA data folder, not its tests
    tmp: Path

    def make_project(self) -> Path:
        proj = self.tmp / "proj"
        for sub in ("AriaMain_accdata/Loadbox", "AriaMain_accdata/Periodics", "RSU"):
            (proj / sub).mkdir(parents=True)
        (proj / "AriaMain.json").write_text(json.dumps({"Configuration": {"Chassis": "ChassisConfig.json", "Sensors": "SensorsConfig.json"}}),
                                            encoding="utf-8")
        (proj / "ChassisConfig.json").write_text('{"Configuration": {}}', encoding="utf-8")
        (proj / "SensorsConfig.json").write_text(json.dumps({"RsuConfiguration": {"Path": "RSU\\P_RSU.xlsx", "RsuSensors": [{"Name": "SMA682"}]}}),
                                                 encoding="utf-8")
        (proj / "RSU" / "P_RSU.xlsx").write_bytes(b"workbook A")
        (proj / "AriaMain.accf").write_text(ACCF, encoding="utf-8")
        (proj / "AriaMain_accdata/Loadbox/P.ldbx").write_text('{"Version": 8, "Content": {"Cards": []}}', encoding="utf-8")
        (proj / "AriaMain_accdata/Loadbox/P_Profile.json").write_text('[{"Slot": 1}]', encoding="utf-8")
        (proj / "AriaMain_accdata/Periodics/CANFD.acpdf").write_text(ACPDF, encoding="utf-8")
        (self.tmp / "520" / "rts").write_text(json.dumps({"ActiveConfigurationPath": str(proj / "AriaMain.json")}), encoding="utf-8")
        return proj

    def test_dbc_import_compares_frames_signals_and_skips_diagnostic_pdus(self) -> None:
        (self.tmp / "SRS_FD_NEW.dbc").write_text(DBC, encoding="latin-1")
        dbc = aria_ctl.dbc_frames(self.tmp / "SRS_FD_NEW.dbc")
        self.assertEqual(sorted(dbc), ["SRS1_FD_10", "SRS_DIAG_RES"])                 # pseudo-frame dropped
        self.assertEqual(dbc["SRS1_FD_10"]["signals"]["STS_SEAT_ODS_PSGR"], (10, 2, "Intel"))  # multiplexed signal kept
        frames, sources = aria_ctl.acpdf_frames(self.make_project() / "AriaMain_accdata/Periodics/CANFD.acpdf")
        self.assertEqual(sources, {"SRS_FD_OLD.dbc"})
        diff = aria_ctl.compare_frames(frames, dbc)
        self.assertEqual(diff, ["SRS1_FD_10.SRS_PAB_WARN_STS: DBC start 208 length 2 Intel, ARIA start 183 length 1 Intel",
                                "SRS1_FD_10.STS_SEAT_ODS_PSGR is in the DBC but not in ARIA"])  # no noise from the diagnostic frame

    def test_dtc_records_of_a_read_dtc_answer(self) -> None:
        self.assertEqual(aria_ctl.dtc_records("0x59 0x02 0xCB"), [])                                   # fault free
        self.assertEqual(aria_ctl.dtc_records("0x59 0x02 0xCB 0x9A 0x12 0x34 0x0B 0xC1 0x00 0x16 0x08"),
                         [{"dtc": "0x9A1234", "status": "0x0B", "active": True}, {"dtc": "0xC10016", "status": "0x08", "active": False}])
        self.assertIsNone(aria_ctl.dtc_records("0x7F 0x19 0x22"))                                      # negative response

    def test_check_inputs_reports_what_differs_from_the_named_files(self) -> None:
        proj = self.make_project()
        (self.tmp / "SRS_FD_NEW.dbc").write_text(DBC, encoding="latin-1")
        (self.tmp / "copy_of_profile.json").write_text('[{"Slot": 1}]', encoding="utf-8")   # same content elsewhere: the same profile
        (self.tmp / "other_RSU.xlsx").write_bytes(b"workbook B")
        args = ["check-inputs", "--config", str(proj / "AriaMain.json"), "--profile", str(self.tmp / "copy_of_profile.json"),
                "--rsu", str(self.tmp / "other_RSU.xlsx"), "--dbc", str(self.tmp / "SRS_FD_NEW.dbc")]
        out = io.StringIO()
        with mock.patch.object(aria_ctl, "aria_processes", return_value=[]), contextlib.redirect_stdout(out):
            aria_ctl.main(args)
        status = {c["check"]: c["status"] for c in json.loads(out.getvalue())["checks"]}
        self.assertEqual(status, {"project": "ok", "loadbox profile": "ok", "RSU workbook": "problem",
                                  "DBC CANFD": "problem", "DBC CANFD content": "problem"})


class VersionHandlingTests(unittest.TestCase):
    def test_data_folder_follows_major_minor(self) -> None:
        self.assertEqual(aria_ctl.version_folder({"version": "5.22.1.3"}).name, "522")

    def test_handler_keys_and_api_level_from_the_level_constructors(self) -> None:
        dump = ("T LocalApiHost.Api.Levels.Level1 : System.Object\n  M .ctor(X core)\n    S Chassis\n    S SetTrigger\n"
                "  M Response SetTrigger(Request r)\n    S Power card not found.\n"
                "T LocalApiHost.Api.Levels.Level1+<>c : System.Object\n  M .ctor()\n    S noise\n"
                "T LocalApiHost.Api.Levels.Level2 : LocalApiHost.Api.Levels.Level1\n  M .ctor(X core)\n    S StoreItem\n")
        self.assertEqual(aria_ctl.handler_keys(dump), ({"Chassis", "SetTrigger", "StoreItem"}, 2))

    def test_rsu_mode_table_from_il(self) -> None:
        il = "\n".join(f"  IL_00{i:02X} {line}" for i, line in enumerate(
            ["ldc.i4.0", "callvirt RsuV1StartUpParameters::set_SyncAsync", "ldc.i4.s 10", "callvirt RsuV1StartUpParameters::set_BitMode",
             "ldc.i4.4", "callvirt RsuV1StartUpParameters::set_RSU_Mode", "ldc.i4.1", "callvirt RsuV1StartUpParameters::set_SyncAsync",
             "ldc.i4.8", "callvirt RsuV1StartUpParameters::set_BitMode", "ldc.i4.s 16", "callvirt RsuV1StartUpParameters::set_RSU_Mode"]))
        self.assertEqual(aria_ctl.rsu_mode_table(il), [(0, 10, 4), (1, 8, 16)])

    def test_unblocked_lists_missing_directions(self) -> None:
        exe = Path(r"C:\ARIA5.22\ARIA.exe")
        rules = [r"Outbound|True|C:\ARIA5.22\ARIA.exe", r"Inbound|False|C:\ARIA5.22\ARIA.exe"]
        self.assertEqual(aria_ctl.unblocked(rules, [exe]), [r"Inbound: C:\ARIA5.22\ARIA.exe"])


def fake_aria_520(server: socket.socket, served: list[int]) -> None:
    """Answer apym like ARIA 5.20: handshake levels 1-2 only (ConnectedClient.CreateApiLevelMap), then GetAriaVersion."""
    for _ in range(2):
        conn, _ = server.accept()
        with conn:
            msg = conn.recv(4096)
            served.append(msg[2])
            if msg[2] > 2:
                conn.sendall(b"\x05" + f"Api level {msg[2]} not supported. Use newer aria version.".encode())
                continue
            conn.sendall(bytes([1, 0xFA, 0xB1, 0x33, 0x70, 0xA1, 0x11]))
            req = json.loads(conn.recv(4096)[1:])
            conn.sendall(b"\x03" + json.dumps({"Id": req["Id"], "IsSuccess": True, "ErrorMessage": "", "Params": {"version": "5.20"}}).encode())
            conn.recv(4096)  # disconnect


class ApymLevelFallbackTests(unittest.TestCase):
    def test_newer_apym_connects_to_older_aria(self) -> None:
        try:
            aria_ctl.load_apym()
            from apym.connection import Instance
            from shared_libraries.apym_imports import init_instance
        except (ImportError, SystemExit):
            self.skipTest("apym not installed")
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(1)
        served: list[int] = []
        thread = threading.Thread(target=fake_aria_520, args=(server, served), daemon=True)
        thread.start()
        try:
            init_instance(Instance, server.getsockname()[1])
            self.assertEqual(Instance.AriaVersion, 520)
        finally:
            if Instance._Instance__aria_instance:
                Instance._Instance__aria_instance.deinitialize()
            Instance._Instance__aria_instance = None
        thread.join(5)
        server.close()
        self.assertEqual(served, list(range(Instance.LATEST_API_LEVEL, 1, -1)) or [Instance.LATEST_API_LEVEL])  # 3, 2 for apym 2.6.7


if __name__ == "__main__":
    unittest.main()
