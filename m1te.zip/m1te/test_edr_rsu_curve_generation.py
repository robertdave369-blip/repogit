from __future__ import annotations

import contextlib
import csv
import hashlib
import importlib.util
import io
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SKILL_DIR = REPO_ROOT / ".github" / "skills" / "edr-rsu-curve-generation"
RUNNER_PATH = SKILL_DIR / "scripts" / "edr_curve_runner.py"
SPEC = importlib.util.spec_from_file_location("edr_curve_runner", RUNNER_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {RUNNER_PATH}")
RUNNER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = RUNNER
SPEC.loader.exec_module(RUNNER)


def run(*argv: str) -> int:
    """Run the CLI quietly and return its exit code."""
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        return RUNNER.main(list(argv))


def tree_hashes(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(root.rglob("*.txt"))
    }


class EdrRsuCurveGenerationTests(unittest.TestCase):
    def setUp(self) -> None:
        # Short root: the engine's file names are ~80 characters and Windows stops at 260.
        self.temp_dir = Path(tempfile.mkdtemp(prefix="edrc-"))

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_vendored_engine_is_the_pinned_upstream_copy(self) -> None:
        digest = hashlib.sha256(RUNNER.ENGINE_PATH.read_bytes()).hexdigest()
        self.assertEqual(digest, RUNNER.ENGINE_SHA256)

    def test_u171_layout_uses_framework_response_numbering(self) -> None:
        rows = RUNNER.project_did_layout("U171")
        by_name = {row["PARAM_NAME"]: row for row in rows}
        self.assertEqual(len(rows), 26 + 26 + 4)
        # projects/U171/config/edr_config.py: DeltaVLong 223.., DeltaVLat 249..,
        # TimeMax 275/277 (2 bytes), Max 279/280. Spec byte = framework byte - 4.
        self.assertEqual(by_name["Record 1 - DeltaVLong at 0 mS"]["POS_IN_BYTES"], 223)
        self.assertEqual(by_name["Record 1 - DeltaVLong at 250 mS"]["POS_IN_BYTES"], 248)
        self.assertEqual(by_name["Record 1 - DeltaVLat at 0 mS"]["POS_IN_BYTES"], 249)
        self.assertEqual(by_name["Record 1 - TimeMaxDeltaVLgt"]["POS_IN_BYTES"], 275)
        self.assertEqual(by_name["Record 1 - TimeMaxDeltaVLgt"]["LEN_IN_BYTES"], 2)
        self.assertEqual(by_name["Record 1 - MaxDeltaVLat"]["POS_IN_BYTES"], 280)
        long_zero = by_name["Record 1 - DeltaVLong at 0 mS"]
        self.assertEqual((long_zero["OFFSET"], long_zero["RESOLUTION"]), (-100.0, 1.0))

    def test_project_without_an_element_list_is_refused(self) -> None:
        with self.assertRaisesRegex(RUNNER.RunnerError, "not a list"):
            RUNNER.project_did_layout("W616")

    def test_project_without_delta_v_scaling_is_refused(self) -> None:
        with self.assertRaisesRegex(RUNNER.RunnerError, "scaling_factor"):
            RUNNER.project_did_layout("W610")

    def test_seed_and_date_make_generation_byte_identical(self) -> None:
        first, second = self.temp_dir / "a", self.temp_dir / "b"
        for target in (first, second):
            self.assertEqual(run("generate", "--output", str(target), "--seed", "5", "--date", "2026-10-21"), 0)
        hashes = tree_hashes(first)
        self.assertEqual(hashes, tree_hashes(second))
        self.assertGreaterEqual(len(hashes), 5 * 2)
        sample = next(first.rglob("*Central_Acc_X_2k_21-Oct-2026.txt"))
        self.assertEqual(len(sample.read_text(encoding="ascii").split()), 600)

    def test_exported_parameters_round_trip_unchanged(self) -> None:
        config = self.temp_dir / "engine.json"
        self.assertEqual(run("export-config", "--output", str(config)), 0)
        plain, configured = self.temp_dir / "plain", self.temp_dir / "conf"
        self.assertEqual(run("generate", "--output", str(plain), "--date", "2026-10-21"), 0)
        self.assertEqual(run("generate", "--output", str(configured), "--date", "2026-10-21", "--config", str(config)), 0)
        self.assertEqual(tree_hashes(plain), tree_hashes(configured))

    def test_unknown_config_key_fails_instead_of_being_ignored(self) -> None:
        config = self.temp_dir / "bad.json"
        config.write_text(json.dumps({"sample_count": 1200}), encoding="utf-8")
        self.assertEqual(run("generate", "--output", str(self.temp_dir / "x"), "--config", str(config)), 2)

    def test_unknown_inversion_token_fails(self) -> None:
        code = run("multi-event", "--output", str(self.temp_dir / "m"), "--events", "front", "left",
                   "--delays-ms", "1000", "--invert", "foo", "-")
        self.assertEqual(code, 2)

    def _side_folder(self, root: Path, crash: str, inverted: bool) -> None:
        folder = root / f"{crash}_crash_test"
        folder.mkdir(parents=True)
        name = "T_LSB_Central_Acc_Y_2k_test.txt"
        samples = [100] * 40 + [0] * 560
        (folder / name).write_text("\n".join(map(str, samples)) + "\n", encoding="ascii")
        (folder / "profile.xml").write_text(
            "<CrashSimulationSensors><Sensor Type=\"GEN6_XY\" Enable=\"True\">"
            f"<Axis FilePath=\"X:\\elsewhere\\{name}\" IsInverted=\"{inverted}\" />"
            "</Sensor></CrashSimulationSensors>",
            encoding="utf-8",
        )

    def test_left_and_right_reaching_the_ecu_with_one_sign_fail_the_pair_rule(self) -> None:
        root = self.temp_dir / "same"
        self._side_folder(root, "left", inverted=True)
        self._side_folder(root, "right", inverted=True)
        out = self.temp_dir / "pol_same"
        self.assertEqual(run("polarity", "--input", str(root), "--output", str(out)), 1)
        with (out / "polarity_checks.csv").open(encoding="utf-8") as handle:
            checks = {row["check"]: row["status"] for row in csv.DictReader(handle)}
        self.assertEqual(checks["central_acc_y: left opposite to right"], "FAIL")

    def test_left_and_right_with_opposite_signs_pass_the_pair_rule(self) -> None:
        root = self.temp_dir / "opposite"
        self._side_folder(root, "left", inverted=True)
        self._side_folder(root, "right", inverted=False)
        self.assertEqual(run("polarity", "--input", str(root), "--output", str(self.temp_dir / "pol_ok")), 0)

    def test_did_compare_reports_a_report_side_sign_inversion(self) -> None:
        civ = self.temp_dir / "civ"
        self.assertEqual(run("change-in-velocity", "--output", str(civ), "--types", "front",
                             "--project", "U171", "--date", "2026-10-21"), 0)
        case_dir = next(civ.glob("front_change_in_velocity_*"))
        expected_csv = case_dir / "did_0455_expected_record_1.csv"
        with expected_csv.open(encoding="ascii") as handle:
            rows = list(csv.DictReader(handle))

        # An ECU response whose Delta-V carries the opposite sign of the curve frame.
        size = max(int(row["Position in Bytes"]) + 1 for row in rows)
        data = [0] * size
        data[0:3] = [0x62, 0x04, 0x55]
        for row in rows:
            position, value = int(row["Position in Bytes"]), float(row["Calculated Physical Value"])
            if "TimeMax" in row["Parameter"]:
                raw = int(round(value / 0.5))
                data[position - 1:position + 1] = [raw >> 8, raw & 0xFF]
            else:
                data[position - 1] = int(round(-value + 100))
        response = " ".join(f"{byte:02X}" for byte in data)

        out = self.temp_dir / "cmp"
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(io.StringIO()):
            code = RUNNER.main(["did-compare", "--curves", str(case_dir), "--project", "U171",
                                "--ecu-response", response, "--output", str(out)])
        self.assertEqual(code, 1)
        # Default report signs follow the AUTOSAR -> Part 563 turn: longitudinal +1, lateral -1.
        self.assertIn("report signs: longitudinal +1, lateral -1", buffer.getvalue())
        self.assertIn("polarity longitudinal: 0 non-zero field(s) match with sign +1, 26 with the opposite sign",
                      buffer.getvalue())
        self.assertIn("rerun with --report-sign-long -1", buffer.getvalue())

        code = run("did-compare", "--curves", str(case_dir), "--project", "U171", "--ecu-response", response,
                   "--report-sign-long", "-1", "--output", str(self.temp_dir / "cmp2"))
        self.assertEqual(code, 0)

    def _onboard_folder(self, root: Path, crash: str, channels: dict[str, list[int]],
                        inverted: bool = False) -> Path:
        folder = root / f"{crash}_crash_t"
        folder.mkdir(parents=True)
        axes = []
        for channel, samples in channels.items():
            name = f"T_LSB_{channel}_2k_t.txt"
            (folder / name).write_text("\n".join(map(str, samples)) + "\n", encoding="ascii")
            axes.append(f"<Axis FilePath=\"X:\\elsewhere\\{name}\" IsInverted=\"{inverted}\" />")
        (folder / "profile.xml").write_text(
            "<CrashSimulationSensors><Sensor Type=\"GEN6_XY\" Enable=\"True\">" + "".join(axes)
            + "</Sensor></CrashSimulationSensors>",
            encoding="utf-8",
        )
        return folder

    def test_onboard_signs_follow_the_autosar_vehicle_axis_by_default(self) -> None:
        # Rule R2: a rear impact pushes the vehicle forward, so onboard X must reach the ECU positive.
        # 'Rear Central_Acc_X' is the rear-crash naming of the onboard X channel.
        pulse = [0] * 20 + [100] * 40 + [0] * 540
        self._onboard_folder(self.temp_dir / "ok", "rear", {"Rear Central_Acc_X": pulse})
        self.assertEqual(run("polarity", "--input", str(self.temp_dir / "ok"), "--output", str(self.temp_dir / "p1")), 0)

        self._onboard_folder(self.temp_dir / "bad", "rear", {"Rear Central_Acc_X": pulse}, inverted=True)
        out = self.temp_dir / "p2"
        self.assertEqual(run("polarity", "--input", str(self.temp_dir / "bad"), "--output", str(out)), 1)
        with (out / "polarity_checks.csv").open(encoding="utf-8") as handle:
            checks = {row["check"]: row["status"] for row in csv.DictReader(handle)}
        self.assertEqual(checks["AUTOSAR onboard: rear/central_acc_x +"], "FAIL")

        # Only when the user names another convention is the AUTOSAR check switched off.
        self.assertEqual(run("polarity", "--input", str(self.temp_dir / "bad"), "--output", str(self.temp_dir / "p3"),
                             "--convention", "none"), 0)

    def test_end_of_event_uses_the_resultant_onboard_delta_v(self) -> None:
        # Rule R1: always-on algorithm; the event ends when the resultant onboard Delta-V over 20 ms
        # falls to 0.8 km/h (49 CFR 563.5). Onboard Y keeps the event alive after onboard X stops.
        x = [0] * 20 + [-300] * 40 + [0] * 540
        y = [0] * 20 + [-200] * 100 + [0] * 480
        folder = self._onboard_folder(self.temp_dir / "eoe", "front", {"Central_Acc_X": x, "Central_Acc_Y": y})
        out = self.temp_dir / "insp"
        self.assertEqual(run("inspect", "--input", str(folder), "--output", str(out)), 0)
        with (out / "t0_summary.csv").open(encoding="utf-8") as handle:
            row = next(csv.DictReader(handle))

        # Independent evaluation: 2 kHz, 40-sample window, sensor ranges 128 g and 64 g over 2047 LSB.
        per_g_sample = 9.80665 * 0.0005 * 3.6
        gx = [value * 128.0 / 2047 for value in x]
        gy = [value * 64.0 / 2047 for value in y]
        def window(values: list[float], index: int) -> float:
            return sum(values[max(0, index - 39):index + 1]) * per_g_sample
        t0 = int(row["t0_sample"])
        onset = next(i for i in range(t0, 600) if (window(gx, i) ** 2 + window(gy, i) ** 2) ** 0.5 > 0.8)
        expected_end = next(i for i in range(onset + 1, 600)
                            if (window(gx, i) ** 2 + window(gy, i) ** 2) ** 0.5 <= 0.8)

        self.assertEqual(int(row["end_of_event_sample"]), expected_end)
        self.assertGreater(int(row["end_of_event_sample"]), int(row["engine_single_axis_tend_sample"]))


if __name__ == "__main__":
    unittest.main()
