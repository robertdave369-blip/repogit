# Test Logbook

Use one Markdown file per month, named `YYYY-MM.md`. Append an entry on the day
that a test, fixture, generated artifact, validation result, backup, or cleanup
decision is created or changed.

```markdown
## YYYY-MM-DD - Short activity title

- What and why: <change or activity and its purpose>
- Paths: <repository-relative paths>
- Validation: <command and pass/fail result, or not run with reason>
- Retention: <keep/archive/delete rationale and review date if applicable>
```

Do not include credentials, ECU identifiers, customer-sensitive data, or raw
bench logs. Link to the controlled artifact location instead.