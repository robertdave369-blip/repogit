"""Create the V2 legacy-format EDR test specification with CAN-wakeup coverage.

The V2 workbook is a copy of the legacy specification. Its existing cases stay
unchanged and new CAN-wakeup cases are appended in the same seven-column Export
format. Generation is offline only and never operates a bench or ECU.
"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import copy
from datetime import date
import json
from pathlib import Path
from shutil import copy2
from typing import Any
from zipfile import ZipFile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from test_ice_common_edr_test_spec_design import inspect_source


ROOT = Path(__file__).resolve().parents[1]
LEGACY_SPECIFICATION = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "Legacy_EDR"
    / "Legacy_EDR_Spec_Covering Multievent_parallel_ignoff_batt_off_.xlsx"
)
VERSION_DIRECTORY = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design"
    / "03_Authoring_Versions"
    / "V2_Legacy_CAN_Wakeup_Review"
)
OUTPUT_WORKBOOK = VERSION_DIRECTORY / "EDR_Legacy_Structure_CAN_Wakeup_MultiEvent_v2.xlsx"
OUTPUT_REPORT = VERSION_DIRECTORY / "EDR_Legacy_Structure_CAN_Wakeup_MultiEvent_v2_validation.json"

EXPORT_HEADERS = [
    "Priority",
    "Name",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
]
LEGACY_GROUP_NAMES = {
    "SUBS_EDR_MULTI_EVENT",
    "SUBS_EDR_PARALLEL_EVENTS",
    "SUBS_EDR_UNCONFIRMED_EVENT",
    "SUBS_EDR_POWER_CUTOFF",
}
CAN_WAKEUP_GROUP_NAME = "SUBS_EDR_CAN_WAKEUP_EVENTS"
HIGHLIGHT_YELLOW = "FFF200"
NAVY = "1F4E78"
WHITE = "FFFFFF"
PALE_BLUE = "D9EAF7"
PALE_GREEN = "E2F0D9"
THIN_GRAY = Side(style="thin", color="B7B7B7")
PENDING = "Pending confirmation. Record the observed behavior and do not set pass or fail."


def event_code(value: Any) -> str:
    text = str(value).strip()
    if not text or text[0] not in {"0", "1"}:
        raise ValueError(f"Unexpected event vector value: {value!r}")
    return text[0]


def lines(*items: str) -> str:
    return "\n".join(item for item in items if item)


def lookup_multi_event(source_data: dict[str, Any], pattern: tuple[str, str, str]) -> dict[str, Any]:
    for item in source_data["vectors"]:
        source_pattern = tuple(event_code(item[f"event_{index}"]) for index in (1, 2, 3))
        if item["family"] == "Multi event" and source_pattern == pattern:
            return item
    raise ValueError(f"Multi-event source vector is unavailable for pattern {pattern}.")


def event_steps(crash_type: str) -> list[tuple[str, str]]:
    if crash_type == "Near Crash":
        return [
            ("Trigger Near Crash and check that no squibs are deployed.", "No squibs are deployed."),
            ("Check crash signals after Near Crash.", "DOOR_UNLOCK=0, STS_CRASH=0, CRASH_LOCATION=0 (Near), SCM_CNT=0, NEAR_CRASH=1."),
            ("Read DTC and check that no new DTC is active for Near Crash.", "No new DTC is active."),
        ]
    if crash_type == "Deployment (Front)":
        return [
            (
                "Trigger Front Crash and check Front Crash squib deployment: Driver Airbag, Passenger Airbag, Passenger PT, Driver PT, Driver Lap PT, Passenger Lap PT, and Driver Knee Airbag.",
                "All listed Front Crash squibs are deployed.",
            ),
            (
                "Read DTC and check Front Crash and Pretensioner Crash DTCs.",
                "Crash DTC 90 61 96 8B and Pretensioner Crash DTC 92 1A 00 8B are active.",
            ),
            (
                "Check crash signals after Front Crash.",
                "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=1 (Front), and SCM_CNT increments while STS_CRASH=1.",
            ),
        ]
    if crash_type == "Deployment (Right)":
        return [
            (
                "Trigger Right Crash and check Right Crash squib deployment: Right Side Airbag, Right Curtain Airbag, Right PT, and Right Lap PT.",
                "All listed Right Crash squibs are deployed.",
            ),
            (
                "Read DTC and check Right Side Crash and Pretensioner Crash DTCs.",
                "Side Crash DTC 92 01 00 8B and Pretensioner Crash DTC 92 1A 00 8B are active.",
            ),
            (
                "Check crash signals after Right Crash.",
                "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=3 (Right), and SCM_CNT increments while STS_CRASH=1.",
            ),
        ]
    if crash_type == "Deployment (Left)":
        return [
            (
                "Trigger Left Crash and check Left Crash squib deployment: Left Side Airbag, Left Curtain Airbag, Left PT, and Left Lap PT.",
                "All listed Left Crash squibs are deployed.",
            ),
            (
                "Read DTC and check Left Side Crash and Pretensioner Crash DTCs.",
                "Side Crash DTC 92 02 00 8B and Pretensioner Crash DTC 92 1B 00 8B are active.",
            ),
            (
                "Check crash signals after Left Crash.",
                "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=2 (Left), and SCM_CNT increments while STS_CRASH=1.",
            ),
        ]
    raise ValueError(f"Unsupported crash type: {crash_type}")


def e2_observation(data: dict[str, Any], first_type: str, second_type: str) -> str:
    first_lock = "0" if first_type == "Near Crash" else "1"
    second_lock = "0" if second_type == "Near Crash" else "1"
    return lines(
        f"EDR1 (End E2): {data['after_2_edr1']}",
        f"EDR2 (End E2): {data['after_2_edr2']}",
        f"MultiEvent# EDR1 (E2): {data['after_2_multi_1']}",
        f"MultiEvent# EDR2 (E2): {data['after_2_multi_2']}",
        f"TimeB/W EDR1 (E2): {data['after_2_time_1']}",
        f"TimeB/W EDR2 (E2): {data['after_2_time_2']}",
        f"Lifetime# EDR1 (E2): {data['after_2_lifetime_1']}",
        f"Lifetime# EDR2 (E2): {data['after_2_lifetime_2']}",
        f"Record Lock EDR1 (E2): {first_lock}",
        f"Record Lock EDR2 (E2): {second_lock}",
    )


def e3_observation(data: dict[str, Any]) -> str:
    return lines(
        f"EDR1 (End E3): {data['after_3_edr1']}",
        f"EDR2 (End E3): {data['after_3_edr2']}",
        f"MultiEvent# EDR1 (E3): {data['after_3_multi_1']}",
        f"MultiEvent# EDR2 (E3): {data['after_3_multi_2']}",
        f"TimeB/W EDR1 (E3): {data['after_3_time_1']}",
        f"TimeB/W EDR2 (E3): {data['after_3_time_2']}",
        f"Lifetime# EDR1 (E3): {data['after_3_lifetime_1']}",
        f"Lifetime# EDR2 (E3): {data['after_3_lifetime_2']}",
        f"Record Lock EDR1 (E3): {data['after_3_lock_1']}",
        f"Record Lock EDR2 (E3): {data['after_3_lock_2']}",
    )


def can_wakeup_pre_action() -> str:
    return lines(
        "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
        "2. Turn IGN OFF and wait until the ECU is ready for CAN wakeup.",
        "3. Send a valid CAN wakeup request and confirm the ECU wakes while IGN remains OFF.",
        "4. Keep CAN communication available until all EDR observations are complete.",
    )


def can_wakeup_post_action() -> str:
    return lines(
        "1. Retain the CAN and EDR evidence for the selected event sequence.",
        "2. Restore the approved normal condition.",
        "3. Do not clear locked EDR data or crash DTCs without separate approval.",
    )


def multi_event_case(
    sequence_number: int,
    suffix: str,
    crash_types: tuple[str, str, str],
    source_data: dict[str, Any],
) -> dict[str, Any]:
    pattern = tuple("0" if crash_type == "Near Crash" else "1" for crash_type in crash_types)
    data = lookup_multi_event(source_data, pattern)
    description = lines(
        "Simulate three events while the ECU is awake through CAN wakeup with IGN OFF.",
        f"Event 1: {crash_types[0]}",
        f"Event 2: {crash_types[1]}",
        f"Event 3: {crash_types[2]}",
        "Keep more than 500 ms and less than 5 s between consecutive events.",
        "Verify EDR data, lock status, crash signals, DTCs, and sensor recording after Event 2 and Event 3.",
    )
    steps: list[tuple[str, str]] = [
        ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
        ("Turn IGN OFF and perform valid CAN wakeup.", "The ECU wakes through CAN while IGN remains OFF and is ready for the selected event sequence."),
    ]
    for event_number, crash_type in enumerate(crash_types, start=1):
        steps.extend(event_steps(crash_type))
        if event_number == 2:
            steps.append(
                (
                    "Read EDR1 and EDR2 after Event 2 and check the recorded event and meta-data.",
                    e2_observation(data, crash_types[0], crash_types[1]),
                )
            )
    steps.extend(
        [
            (
                "Read EDR1 and EDR2 after Event 3 and check the recorded event and meta-data.",
                e3_observation(data),
            ),
            (
                "Read sensor data from EDR and EEPROM after Event 3.",
                "Recorded sensor data matches the applied event inputs for the retained EDR records.",
            ),
            (
                "Confirm CAN wakeup remains active until the EDR readout is complete.",
                "EDR data are read while the ECU remains awake through CAN with IGN OFF.",
            ),
        ]
    )
    return {
        "priority": "Normal",
        "name": f"SUBS_EDR_CANWakeup_MultiEvent_{suffix}",
        "description": description,
        "pre_action": can_wakeup_pre_action(),
        "post_action": can_wakeup_post_action(),
        "steps": steps,
        "expected_status": "IN REVIEW",
        "sequence_number": sequence_number,
    }


def parallel_event_case(
    sequence_number: int,
    suffix: str,
    first_crash: str,
    second_crash: str,
    winning_crash: str,
    crash_location: str,
    dtcs: str,
    squibs: str,
) -> dict[str, Any]:
    description = lines(
        "Simulate two parallel deployment events while the ECU is awake through CAN wakeup with IGN OFF.",
        f"Crash 1: {first_crash}",
        f"Crash 2: {second_crash}",
        "Trigger both crash inputs within 500 ms.",
        f"Verify {winning_crash} priority, both deployment actions, DTC storage, EDR meta-data, and CAN signals.",
    )
    steps = [
        ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
        ("Turn IGN OFF and perform valid CAN wakeup.", "The ECU wakes through CAN while IGN remains OFF and is ready for parallel crash input."),
        (f"Trigger {first_crash} and {second_crash} within 500 ms.", "Both crash signals are received within 500 ms."),
        ("Check EDR1 and EDR2 after the parallel event.", f"EDR1 records {winning_crash} as the higher-priority crash. EDR2 remains empty (FF)."),
        ("Check crash location in EDR.", f"Crash location is set to {crash_location}."),
        ("Check deployed squibs.", squibs),
        ("Read DTCs and check active crash DTCs.", dtcs),
        ("Check CAN signals.", f"DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION={crash_location}."),
        ("Check EDR event meta-data.", "TimeB/W=FF, MultiEvent=FF, Lifetime=1, Record Lock=1."),
        ("Read sensor data from EDR1 and EDR2.", "EDR1 sensor data match the applied crash inputs. EDR2 sensor data are FF."),
        ("Check EEPROM sensor data for EDR1 and EDR2.", "EEPROM sensor values for EDR1 match EDR1 sensor data. EDR2 sensor values are FF."),
    ]
    return {
        "priority": "Normal",
        "name": f"SUBS_EDR_CANWakeup_ParallelEvent_{suffix}",
        "description": description,
        "pre_action": can_wakeup_pre_action(),
        "post_action": can_wakeup_post_action(),
        "steps": steps,
        "expected_status": "IN REVIEW",
        "sequence_number": sequence_number,
    }


def build_appended_cases(source_data: dict[str, Any]) -> list[dict[str, Any]]:
    multi_sequences = [
        ("NearCrash_NearCrash_NearCrash", ("Near Crash", "Near Crash", "Near Crash")),
        ("NearCrash_NearCrash_DeploymentFront", ("Near Crash", "Near Crash", "Deployment (Front)")),
        ("NearCrash_DeploymentFront_NearCrash", ("Near Crash", "Deployment (Front)", "Near Crash")),
        ("NearCrash_DeploymentFront_DeploymentRight", ("Near Crash", "Deployment (Front)", "Deployment (Right)")),
        ("DeploymentFront_NearCrash_NearCrash", ("Deployment (Front)", "Near Crash", "Near Crash")),
        ("DeploymentFront_NearCrash_DeploymentRight", ("Deployment (Front)", "Near Crash", "Deployment (Right)")),
        ("DeploymentFront_DeploymentRight_NearCrash", ("Deployment (Front)", "Deployment (Right)", "Near Crash")),
        ("DeploymentFront_DeploymentRight_DeploymentLeft", ("Deployment (Front)", "Deployment (Right)", "Deployment (Left)")),
    ]
    cases = [
        multi_event_case(index, suffix, crash_types, source_data)
        for index, (suffix, crash_types) in enumerate(multi_sequences, start=1)
    ]
    cases.extend(
        [
            parallel_event_case(
                9,
                "FrontCrash_LeftCrash_Within500ms",
                "Front Crash",
                "Left Crash",
                "Front Crash",
                "1 (Front)",
                "Crash DTC 90 61 96 8B and Side Crash DTC 92 02 00 8B are active.",
                "All Front Crash squibs and all Left Crash squibs are deployed.",
            ),
            parallel_event_case(
                10,
                "RightCrash_LeftCrash_Within500ms",
                "Right Crash",
                "Left Crash",
                "Left Crash",
                "2 (Left)",
                "Side Crash DTC 92 02 00 8B and Side Crash DTC 92 01 00 8B are active.",
                "All Left Crash squibs and all Right Crash squibs are deployed.",
            ),
            parallel_event_case(
                11,
                "FrontCrash_RightCrash_Within500ms",
                "Front Crash",
                "Right Crash",
                "Front Crash",
                "1 (Front)",
                "Crash DTC 90 61 96 8B and Side Crash DTC 92 01 00 8B are active.",
                "All Front Crash squibs and all Right Crash squibs are deployed.",
            ),
            {
                "priority": "Normal",
                "name": "SUBS_EDR_CANWakeup_UnconfirmedCrash_OnlyXData",
                "description": lines(
                    "Simulate an unconfirmed crash while the ECU is awake through CAN wakeup with IGN OFF.",
                    "Crash type: Unconfirmed Crash.",
                    "Provide onboard longitudinal input only and set both front remote sensor values to zero.",
                    "Characterize EDR record, DTC, crash-signal, and sensor-data behavior under CAN wakeup.",
                ),
                "pre_action": can_wakeup_pre_action(),
                "post_action": can_wakeup_post_action(),
                "steps": [
                    ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
                    ("Turn IGN OFF and perform valid CAN wakeup.", "The ECU wakes through CAN while IGN remains OFF."),
                    ("Load only onboard longitudinal input and set both front remote sensor values to zero.", "Only longitudinal input is present and both front remote sensor values are zero."),
                    ("Trigger the unconfirmed-crash evaluation.", "The event is classified as Unconfirmed Crash."),
                    ("Read EDR data, DTCs, crash signals, and sensor data while CAN wakeup remains active.", PENDING),
                ],
                "expected_status": "ON HOLD",
                "sequence_number": 12,
            },
            {
                "priority": "Normal",
                "name": "SUBS_EDR_CANWakeup_MultiEvent_WakeupTiming",
                "description": lines(
                    "Characterize CAN wakeup timing around a multi-event sequence with IGN OFF.",
                    "Crash types: Near Crash, Deployment (Front), Deployment (Right).",
                    "Run three timing variants: CAN wakeup before Event 1, at Event 1, and after Event 1 before Event 2.",
                    "Record EDR allocation, crash signals, DTCs, and event meta-data for each variant.",
                ),
                "pre_action": lines(
                    "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
                    "2. Turn IGN OFF and prepare a synchronized timing measurement method.",
                    "3. Do not assign pass or fail until CAN wakeup timing behavior is confirmed.",
                ),
                "post_action": can_wakeup_post_action(),
                "steps": [
                    ("Select one wakeup timing variant: before Event 1, at Event 1, or after Event 1 before Event 2.", "The selected wakeup timing variant is recorded."),
                    ("Apply valid CAN wakeup at the selected timing point while IGN remains OFF.", "CAN wakeup timing is captured relative to Event 1."),
                    ("Apply Event 1 Near Crash, Event 2 Deployment (Front), and Event 3 Deployment (Right) with more than 500 ms and less than 5 s between consecutive events.", "All event timestamps and CAN wakeup timing are retained."),
                    ("Read EDR1, EDR2, crash signals, DTCs, and event meta-data after Event 2 and Event 3.", PENDING),
                    ("Retain the wakeup and event timing evidence, then restore the approved test condition.", "The result remains pending confirmation until the CAN wakeup timing behavior is defined."),
                ],
                "expected_status": "ON HOLD",
                "sequence_number": 13,
            },
        ]
    )
    return cases


def append_row(sheet: Any, values: list[Any], styles: list[Any], row_height: float) -> int:
    row_number = sheet.max_row + 1
    for column_number, value in enumerate(values, start=1):
        cell = sheet.cell(row_number, column_number, value)
        cell._style = copy(styles[column_number - 1])
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)
    sheet.row_dimensions[row_number].height = row_height
    return row_number


def append_cases(workbook: Any, cases: list[dict[str, Any]]) -> None:
    sheet = workbook["Export"]
    if [sheet.cell(1, column_number).value for column_number in range(1, 8)] != EXPORT_HEADERS:
        raise ValueError("The legacy Export sheet no longer has the expected seven-column structure.")
    group_styles = [copy(sheet.cell(2, column_number)._style) for column_number in range(1, 8)]
    primary_styles = [copy(sheet.cell(3, column_number)._style) for column_number in range(1, 8)]
    continuation_styles = [copy(sheet.cell(4, column_number)._style) for column_number in range(1, 8)]
    append_row(sheet, ["Normal", CAN_WAKEUP_GROUP_NAME, None, None, None, None, None], group_styles, 22)
    for case in cases:
        first_action, first_expected = case["steps"][0]
        title_row = append_row(
            sheet,
            [
                case["priority"],
                case["name"],
                case["description"],
                case["pre_action"],
                case["post_action"],
                first_action,
                first_expected,
            ],
            primary_styles,
            150,
        )
        title_cell = sheet.cell(title_row, 2)
        title_cell.fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
        title_cell.font = Font(bold=True, color="000000")
        for action, expected in case["steps"][1:]:
            continuation_row = append_row(sheet, [None, None, None, None, None, action, expected], continuation_styles, 56)
            if action.startswith("Turn IGN OFF"):
                for column_number in range(6, 8):
                    sheet.cell(continuation_row, column_number).fill = PatternFill("solid", fgColor=PALE_BLUE)
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:G{sheet.max_row}"
    sheet.sheet_view.showGridLines = False


def remove_comments_and_hyperlinks(workbook: Any) -> None:
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.comment is not None:
                    cell.comment = None
                if cell.hyperlink is not None:
                    cell.hyperlink = None


FORBIDDEN_VISIBLE_TEXT = (
    "edr_requirements",
    "ice_common_srs_v1.4_diag_re.xlsx",
    "legacy_edr_spec_covering",
    "common_edr_canc_0455_045b_u171_m314_v7_authoring.xlsx",
    "project_testcases",
    "docs\\",
    "c:\\",
    ".xlsx",
    ".csv",
    ".json",
)


def scan_for_visible_references(workbook: Any) -> list[str]:
    findings: list[str] = []
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and any(token in cell.value.lower() for token in FORBIDDEN_VISIBLE_TEXT):
                    findings.append(f"{sheet.title}!{cell.coordinate}")
                if cell.comment is not None:
                    findings.append(f"comment at {sheet.title}!{cell.coordinate}")
                if cell.hyperlink is not None:
                    findings.append(f"hyperlink at {sheet.title}!{cell.coordinate}")
    return findings


def scan_package_for_reference_residue(path: Path) -> list[str]:
    forbidden = (
        "edr_requirements",
        "ice_common_srs_v1.4_diag_re.xlsx",
        "legacy_edr_spec_covering",
        "common_edr_canc_0455_045b_u171_m314_v7_authoring.xlsx",
        "c:\\framework_ioem_py",
    )
    findings: list[str] = []
    with ZipFile(path) as archive:
        for member in archive.namelist():
            if member.endswith((".xml", ".rels")):
                content = archive.read(member).decode("utf-8", errors="ignore").lower()
                if any(token in content for token in forbidden):
                    findings.append(member)
    return findings


def legacy_values() -> list[tuple[Any, ...]]:
    workbook = load_workbook(LEGACY_SPECIFICATION, data_only=False, read_only=True)
    sheet = workbook["Export"]
    return [tuple(row) for row in sheet.iter_rows(values_only=True)]


def validate_workbook(path: Path, expected_cases: list[dict[str, Any]]) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"V2 workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=False)
    if workbook.sheetnames != ["Export", "ChoiceValues"]:
        raise ValueError(f"Unexpected V2 worksheet layout: {workbook.sheetnames}")
    sheet = workbook["Export"]
    headers = [sheet.cell(1, column_number).value for column_number in range(1, 8)]
    if headers != EXPORT_HEADERS:
        raise ValueError("V2 does not preserve the legacy Export headers.")
    baseline = legacy_values()
    copied_rows = [tuple(row) for row in sheet.iter_rows(min_row=1, max_row=len(baseline), values_only=True)]
    if copied_rows != baseline:
        raise ValueError("The copied legacy case rows changed before the appended V2 section.")
    appended_names = [case["name"] for case in expected_cases]
    observed_rows = {
        str(sheet.cell(row_number, 2).value): row_number
        for row_number in range(len(baseline) + 1, sheet.max_row + 1)
        if sheet.cell(row_number, 2).value is not None
    }
    if CAN_WAKEUP_GROUP_NAME not in observed_rows:
        raise ValueError("V2 CAN-wakeup group heading is missing.")
    if set(appended_names) != {name for name in observed_rows if name != CAN_WAKEUP_GROUP_NAME}:
        raise ValueError("V2 appended case names do not match the intended CAN-wakeup coverage set.")
    highlighted_names = 0
    for case_name in appended_names:
        row_number = observed_rows[case_name]
        name_cell = sheet.cell(row_number, 2)
        if name_cell.fill.fill_type == "solid" and (name_cell.fill.fgColor.rgb or "").endswith(HIGHLIGHT_YELLOW):
            highlighted_names += 1
        else:
            raise ValueError(f"V2 test case name is not yellow highlighted: {case_name}")
        if not sheet.cell(row_number, 3).value:
            raise ValueError(f"V2 test case description is missing: {case_name}")
        if not sheet.cell(row_number, 4).value or not sheet.cell(row_number, 5).value:
            raise ValueError(f"V2 pre/post actions are missing: {case_name}")
        step_count = 0
        current_row = row_number
        while current_row <= sheet.max_row:
            if current_row > row_number and sheet.cell(current_row, 2).value is not None:
                break
            if sheet.cell(current_row, 6).value is not None:
                step_count += 1
            current_row += 1
        if step_count < 5:
            raise ValueError(f"V2 test case has too few detailed steps: {case_name}")
    multi_event_names = [name for name in appended_names if "CANWakeup_MultiEvent_" in name and "WakeupTiming" not in name]
    if len(multi_event_names) != 8:
        raise ValueError("V2 must contain eight CAN-wakeup multi-event crash-type cases.")
    parallel_names = [name for name in appended_names if "CANWakeup_ParallelEvent_" in name]
    if len(parallel_names) != 3:
        raise ValueError("V2 must contain three CAN-wakeup parallel-event cases.")
    visible_findings = scan_for_visible_references(workbook)
    if visible_findings:
        raise ValueError(f"V2 has forbidden visible external references: {visible_findings[:10]}")
    package_findings = scan_package_for_reference_residue(path)
    if package_findings:
        raise ValueError(f"V2 package retains forbidden external-reference text: {package_findings}")
    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "primary_sheet": "Export",
        "legacy_rows_preserved": len(baseline),
        "appended_can_wakeup_case_count": len(appended_names),
        "can_wakeup_multi_event_case_count": len(multi_event_names),
        "can_wakeup_parallel_event_case_count": len(parallel_names),
        "can_wakeup_unconfirmed_case_present": "SUBS_EDR_CANWakeup_UnconfirmedCrash_OnlyXData" in appended_names,
        "can_wakeup_timing_case_present": "SUBS_EDR_CANWakeup_MultiEvent_WakeupTiming" in appended_names,
        "yellow_highlighted_appended_names": highlighted_names,
        "legacy_headers_preserved": True,
        "visible_external_references": 0,
        "package_reference_residue": 0,
    }


def generate() -> dict[str, Any]:
    if not LEGACY_SPECIFICATION.is_file():
        raise FileNotFoundError(f"Legacy specification is unavailable: {LEGACY_SPECIFICATION}")
    source_data = inspect_source()
    appended_cases = build_appended_cases(source_data)
    if len(appended_cases) != 13:
        raise ValueError(f"Expected 13 appended CAN-wakeup cases, found {len(appended_cases)}.")
    if len({case['name'] for case in appended_cases}) != len(appended_cases):
        raise ValueError("Appended CAN-wakeup case names must be unique.")
    VERSION_DIRECTORY.mkdir(parents=True, exist_ok=True)
    copy2(LEGACY_SPECIFICATION, OUTPUT_WORKBOOK)
    workbook = load_workbook(OUTPUT_WORKBOOK, data_only=False, read_only=False)
    append_cases(workbook, appended_cases)
    remove_comments_and_hyperlinks(workbook)
    workbook.properties.title = "EDR Legacy Structure CAN Wakeup Multi-Event Specification V2"
    workbook.properties.subject = "Standalone EDR CAN wakeup test cases"
    workbook.properties.creator = "EDR Test Team"
    workbook.properties.description = "V2 review copy with appended CAN wakeup multi-event coverage."
    workbook.save(OUTPUT_WORKBOOK)
    workbook.close()
    validation = validate_workbook(OUTPUT_WORKBOOK, appended_cases)
    report = {
        "version": "V2",
        "status": "Review",
        "format": "Copied legacy Export and ChoiceValues workbook structure; new cases appended in the same row format.",
        "legacy_crash_types_retained": ["Near Crash", "Deployment (Front)", "Deployment (Right)", "Deployment (Left)"],
        "appended_cases": validation["appended_can_wakeup_case_count"],
        "coverage": {
            "multi_event_sequences": validation["can_wakeup_multi_event_case_count"],
            "parallel_event_sequences": validation["can_wakeup_parallel_event_case_count"],
            "unconfirmed_crash": validation["can_wakeup_unconfirmed_case_present"],
            "wakeup_timing_race": validation["can_wakeup_timing_case_present"],
        },
        "status_counts": dict(Counter(case["expected_status"] for case in appended_cases)),
        "standalone_content": "No external workbook name, sheet name, file path, or script reference appears in the specification.",
        "validation": validation,
        "generation_date": date.today().isoformat(),
    }
    OUTPUT_REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate V2 CAN-wakeup additions in legacy EDR specification structure.")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--generate", action="store_true", help="Copy the legacy workbook and append V2 CAN-wakeup cases.")
    action.add_argument("--validate", action="store_true", help="Validate the V2 workbook without changing it.")
    arguments = parser.parse_args()
    if arguments.generate:
        report = generate()
    else:
        report = validate_workbook(OUTPUT_WORKBOOK, build_appended_cases(inspect_source()))
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())