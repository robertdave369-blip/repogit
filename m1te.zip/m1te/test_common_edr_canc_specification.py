"""Offline common EDR CAN-C specification generator and regression checks.

This module intentionally generates workbook artifacts only. It never opens an
ARIA session, transmits CAN traffic, triggers an EDR event, or touches an ECU.
"""

from __future__ import annotations

import argparse
import ast
import copy
import csv
from functools import lru_cache
import hashlib
import json
import math
import random
import re
import sys
import tempfile
import unittest
from collections import Counter
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import Path
from typing import Any, Iterable

import cantools
from cantools.database import load_file as load_dbc_file
import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.utils import get_column_letter, range_boundaries


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_AUTHORING_WORKBOOK = REPOSITORY_ROOT / "project_testcases" / "m310_m314_m110" / "EDR" / "canc_m314.xlsx"
DRBFM_WORKBOOK = REPOSITORY_ROOT / "docs" / "project_documents" / "DRBFM" / "EDR_Common_DRBFM" / "RstEdr_DRBFM.xlsx"
DRBFM_ANALYSIS_SHEET = "EDR 0455 045B Analysis"
U171_DBC = REPOSITORY_ROOT / "project_dbc" / "u171_dbc" / "U171_SRS_SVNID39216_20250917.dbc"
M314_FD_DBC = REPOSITORY_ROOT / "project_dbc" / "m314_dbc" / "SRS_FD_40777.dbc"
M314_HSCAN_DBC = REPOSITORY_ROOT / "project_dbc" / "m314_dbc" / "SRS_HSCAN_40250_22042026.dbc"
U171_DBC_JSON = U171_DBC.parent / f"{U171_DBC.stem}_json" / f"{U171_DBC.stem}_signals.json"
M314_FD_DBC_JSON = M314_FD_DBC.parent / f"{M314_FD_DBC.stem}_json" / f"{M314_FD_DBC.stem}_signals.json"
M314_HSCAN_DBC_JSON = M314_HSCAN_DBC.parent / f"{M314_HSCAN_DBC.stem}_json" / f"{M314_HSCAN_DBC.stem}_signals.json"
DBC_TO_JSON_CONVERTER = REPOSITORY_ROOT / ".github" / "skills" / "dbc-to-json" / "scripts" / "dbc_to_json.py"
U171_CANC_CONFIG = REPOSITORY_ROOT / "projects" / "U171" / "config" / "canc_config.py"
M314_CANC_CONFIG = REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "config" / "canc_config.py"
U171_VARIANT_CONFIG = REPOSITORY_ROOT / "projects" / "U171" / "config" / "variantcode_config.py"
M314_VARIANT_CONFIG = REPOSITORY_ROOT / "projects" / "M310_M314_M110" / "config" / "variantcode_config.py"
CODEBEAMER_TEMPLATE = REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "assets" / "veoneer_codebeamer_test_spec_template.cleaned.xlsx"
ONFAIL_POLICY_PATH = REPOSITORY_ROOT / "tests" / "artifacts" / "edr-onfail-policy" / "edr_onfail_policy.json"
DEFAULT_OUTPUT_DIRECTORY = REPOSITORY_ROOT / "project_testcases" / "ice_common_spec" / "EDR"
SPECIFICATION_VERSION = "v3"
FRONT_CRASH_DTC_EXPECTATION = "\n".join(
    (
        "DTC: ECU Locked Due to Front Crash",
        "DTC Code: 90 61 96 8B",
        "",
        "DTC: ECU Locked Due to Pretensioner Deployment",
        "DTC Code: 92 1A 00 8B",
    )
)
AUTHORING_HEADERS = (
    "ID",
    "Priority",
    "Name",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
    "Test Steps.Critical",
    "Test Steps.Id",
    "Test Parameters",
    "Verifies",
    "Status",
    "Type",
    "_Project",
    "Reviewer(s)",
    "_LatestResult",
    "_Original_Id",
    "Referenced Reviews",
    "_ScriptPath",
    "_TestType",
    "_VerificationMethod",
    "_TestTechnique",
)
APPLICABILITY_VALUES = ("ICE", "EV", "Both")
DRBFM_ANALYSIS_HEADERS = (
    "Diag Logical ID",
    "EDR Parameter name",
    "length in bytes",
    "Byte position",
    "Bit position",
    "Sampling Interval",
    "Data Samples per second",
    "Value description",
    "Resolution_CAN",
    "Offset_CAN",
    "Resolution_EDR",
    "Offset_EDR",
    "Not captured value",
    "Comments",
)

SKILL_SCRIPTS = REPOSITORY_ROOT / ".github" / "skills" / "veoneer-test-spec-generator" / "scripts"
if str(SKILL_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SKILL_SCRIPTS))

from models import TestCase, TestMethodology, TestSpecification, TestStep
from validation import validate_rendered_workbook, validate_specification, write_validation_report
from workbook_codec import inspect_template, render_specification
EXPLICIT_ELEMENT_ALIASES = {
    "vehiclespeedlongitudinalattimezero": ("vehspdlgtattimezero", "vehspdlgt", "vehiclespeed", "vehiclespeedesc12"),
    "vehiclespeedlongitudinal": ("vehspdlgt", "vehiclespeed", "vehiclespeedesc12"),
    "frontheadlampsts": ("stshighbeam", "stshighbeam"),
    "doorsopenstatus": ("stsdoor", "doorsopenstatus"),
    "breakpedalval": ("brakepedalvalue", "brkswitch", "brkpedal", "brkpedal1"),
    "acceleratorpedal": ("accped", "accped1", "rawaccpedalvalue"),
    "enginespeed": ("enginespeed", "engspd1", "motorspd", "vcumcumotorspeed"),
    "enginestate": ("enginestate", "stseng"),
    "absactiveieb": ("absactive", "absactiveieb"),
    "escactiveieb": ("escactive", "escactiveieb"),
    "steeringabsoluteangle": ("absoluteangle", "steeringabsoluteangle"),
    "tyrepressurefl": ("tyrepressurefl", "fltyrepressure"),
    "tyrepressurefr": ("tyrepressurefr", "frtyrepressure"),
    "tyrepressurerl": ("tyrepressurerl", "rltyrepressure"),
    "tyrepressurerr": ("tyrepressurerr", "rrtyrepressure"),
    "mastercylinderpressure": ("mastercylinderpressure",),
    "gear": ("gearactual",),
    "doorlockstatus": ("doorlockstatus", "stsdoorlatch", "stsdriverdoorlatch"),
    "yawrate": ("yawrate",),
    "xaxisangular": ("xaxisangular",),
    "yaxisangular": ("yaxisangular",),
    "lateralaccel": ("lateralaccel", "latteralaccel"),
    "longitudinalaccel": ("longaccel", "longitudinalaccel"),
    "zaxisaccel": ("zaxisaccel",),
    "tcsactiveieb": ("tcsactive", "tcsactiveieb"),
    "aebwarningmsg": ("aebwarningmsg",),
    "aebfctawarn": ("aebfctawarn",),
    "aeswarning": ("aeswarning",),
    "aessyssts": ("aessyssts",),
    "esasyssts": ("esasyssts",),
    "ldwlkawarning": ("ldwlkawarning",),
    "adasdesstrwhlanglecmd": ("adasdesstrwhlanglecmd",),
    "ldwlkasysstate": ("ldwlkasysstate",),
    "lkahandsoffdisplaywarning": ("lkahandsoffdisplaywarning",),
    "lcfsysstate": ("lcfsysstate",),
    "spasysstate": ("spasysstate",),
    "spalcfhandsoffwarning": ("spalcfhandsoffwarning",),
    "accsysstate": ("accsysstate",),
    "npsyssts": ("npsyssts",),
    "rmsmodestate": ("rmsmodestate",),
    "lcpathstate": ("lcpathstate",),
    "elkoncomingwarning": ("elkoncomingwarning",),
    "elksidewarning": ("elksidewarning",),
    "elkovertakingwarning": ("elkovertakingwarning",),
    "stshighbeam": ("stshighbeam",),
    "stslowbeam": ("stslowbeam",),
    "ststpmsled": ("ststpmsled",),
    "zonalbattvolt": ("zonalbattvolt",),
    "stsabs": ("stsabs",),
    "stsebd": ("stsebd",),
    "stsesc": ("stsesc",),
    "ststcs": ("ststcs",),
    "paddleshiftposition": ("paddleshiftposition",),
    "vcuignsts": ("vcuignsts",),
    "emergencybrakingreq": ("emergencybrakingreq",),
    "torquesplitratio": ("torquesplitratio",),
    "alertmessage": ("alertmessage",),
    "vcudrvadvmode": ("vcudrvadvmode",),
    "vcudrvadvmodests": ("vcudrvadvmodests",),
    "srsoperationmode": ("srsoperationmode",),
    "srsocssubseatclassification": ("srsocssubseatclassification",),
    "srsoccodsadult": ("srsoccodsadult",),
    "srsbklcnt": ("srsbklcnt",),
    "srsecallocccnt": ("srsecallocccnt",),
    "srsecalloccbklcnt": ("srsecalloccbklcnt",),
    "stscrash": ("stscrash",),
    "ctrlbrakelight": ("ctrlbrakelight",),
    "pibactive": ("pibactive",),
    "ecallpwmackcrash": ("ecallpwmsignalack",),
    "clutchstatus": ("clutchsts",),
}


@dataclass(frozen=True, slots=True)
class AuthoringStep:
    """One primary or continuation-row step in the authoring workbook."""

    action: str
    expected_result: str
    critical: bool = True


@dataclass(frozen=True, slots=True)
class AuthoringCase:
    """Case content for the reference-compatible authoring workbook."""

    name: str
    applicability: str
    description: str
    pre_action: str
    post_action: str
    steps: tuple[AuthoringStep, ...]
    priority: str = "High"
    status: str = "ON HOLD"
    project: str = "Common EDR"
    test_type: str = "Manual"
    verification_method: str = "Requirements-based test"
    test_technique: str = "Boundary Value Analysis"


@dataclass(frozen=True, slots=True)
class DrbfmElement:
    """One source-provenance-bearing row from the common EDR analysis sheet."""

    source_row: int
    logical_id: str | None
    parameter_name: str
    values: dict[str, Any]

    @property
    def normalized_name(self) -> str:
        return normalize_name(self.parameter_name)


def normalize_name(value: object) -> str:
    """Normalize engineering labels only for matching; retain raw source text separately."""
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


POLICY_SYSTEM_SENDER_ALIASES = {
    "eps": {"eps", "sas"},
    "ems": {"ems"},
    "esc": {"esc", "ieb"},
    "hmi": {"ic", "mbfm", "tcu", "hmi"},
    "mbfm": {"mbfm"},
    "hpcv": {"gw", "hpcv"},
}
POLICY_MODE_BY_FAULT_MODE = {
    "node_absent": "node_absent",
    "message_timeout": "message_timeout",
    "message_content": "message_content_failure",
    "signal_content": "signal_invalid",
    "signal_never_received": "signal_never_received",
    "variant_code_error": "variant_code_error",
}
POLICY_ONLY_FAULT_MODES = ("signal_never_received", "variant_code_error")


@dataclass(frozen=True, slots=True)
class OnFailDecision:
    """One fault reaction selected from an explicit route rule or the generic fallback."""

    fault_mode: str
    policy_mode: str
    reaction: str
    value: str | None
    applicable: bool
    source: str
    source_row: int | None
    special: dict[str, Any]
    reason: str = ""


@lru_cache(maxsize=1)
def load_onfail_policy(source_path: Path = ONFAIL_POLICY_PATH) -> dict[str, Any]:
    """Load the user-supplied normalized on-fail authority with basic integrity checks."""
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    policy = json.loads(source_path.read_text(encoding="utf-8"))
    if not isinstance(policy, dict) or not isinstance(policy.get("records"), list):
        raise ValueError(f"On-fail policy must contain a record list: {source_path}")
    seen_keys: set[tuple[str, str, str]] = set()
    for record in policy["records"]:
        if not isinstance(record, dict):
            raise ValueError(f"On-fail policy record is malformed: {record!r}")
        key = (
            normalize_name(record.get("system")),
            normalize_name(record.get("message")),
            normalize_name(record.get("signal")),
        )
        if not all(key):
            raise ValueError(f"On-fail policy record has an incomplete matching key: {record!r}")
        if key in seen_keys:
            raise ValueError(f"Duplicate on-fail policy matching key: {key}")
        seen_keys.add(key)
        if not isinstance(record.get("on_fail_applicable"), bool):
            raise ValueError(f"On-fail policy applicability is not boolean: {record!r}")
        faults = record.get("faults", {})
        if not isinstance(faults, dict):
            raise ValueError(f"On-fail policy faults must be an object: {record!r}")
    return policy


def find_onfail_policy_record(system: object, message: object, signal: object) -> dict[str, Any] | None:
    """Find one explicit user policy record by its normalized system/message/signal key."""
    key = (normalize_name(system), normalize_name(message), normalize_name(signal))
    for record in load_onfail_policy()["records"]:
        record_key = (
            normalize_name(record["system"]),
            normalize_name(record["message"]),
            normalize_name(record["signal"]),
        )
        if record_key == key:
            return record
    return None


def find_onfail_policy_record_for_dbc(metadata: dict[str, Any]) -> dict[str, Any] | None:
    """Match a policy record only when its logical system is compatible with DBC sender evidence."""
    message = metadata["message"]
    signal = metadata["signal"]
    actual_senders = {normalize_name(sender) for sender in metadata.get("senders", ())}
    candidates = []
    for record in load_onfail_policy()["records"]:
        if normalize_name(record["message"]) != normalize_name(message):
            continue
        if normalize_name(record["signal"]) != normalize_name(signal):
            continue
        policy_system = normalize_name(record["system"])
        allowed_senders = POLICY_SYSTEM_SENDER_ALIASES.get(policy_system, {policy_system})
        if not actual_senders or actual_senders.intersection(allowed_senders):
            candidates.append(record)
    if len(candidates) > 1:
        keys = [f"{record['system']}/{record['message']}/{record['signal']}" for record in candidates]
        raise ValueError(f"Ambiguous on-fail policy match for {message}/{signal}: {keys}")
    return candidates[0] if candidates else None


def onfail_decision(
    route: dict[str, Any],
    fault_mode: str,
    *,
    policy_mode: str | None = None,
) -> OnFailDecision:
    """Resolve explicit signal policy before the documented generic-majority fallback."""
    policy_mode = policy_mode or POLICY_MODE_BY_FAULT_MODE.get(fault_mode, fault_mode)
    record = route.get("onfail_policy")
    if isinstance(record, dict):
        source_row = record.get("source_row")
        if not record["on_fail_applicable"]:
            return OnFailDecision(
                fault_mode,
                policy_mode,
                "not_applicable",
                None,
                False,
                "explicit user-supplied policy",
                source_row if isinstance(source_row, int) else None,
                dict(record.get("special", {})),
                record.get("gateway_override", "Explicit source policy excludes on-fail cases."),
            )
        fault_rule = record.get("faults", {}).get(policy_mode)
        if not isinstance(fault_rule, dict):
            return OnFailDecision(
                fault_mode,
                policy_mode,
                "not_applicable",
                None,
                False,
                "explicit user-supplied policy",
                source_row if isinstance(source_row, int) else None,
                dict(record.get("special", {})),
                f"Explicit policy has no {policy_mode} rule for this signal.",
            )
        reaction = str(fault_rule.get("reaction", "unresolved"))
        value = fault_rule.get("value")
        return OnFailDecision(
            fault_mode,
            policy_mode,
            reaction,
            None if value is None else str(value),
            True,
            "explicit user-supplied policy",
            source_row if isinstance(source_row, int) else None,
            dict(record.get("special", {})),
            str(fault_rule.get("source_text", "")),
        )
    fallback = load_onfail_policy()["generic"].get(policy_mode)
    if not isinstance(fallback, dict):
        return OnFailDecision(
            fault_mode,
            policy_mode,
            "not_applicable",
            None,
            False,
            "no policy",
            None,
            {},
            f"No generic fallback is defined for {policy_mode}.",
        )
    return OnFailDecision(
        fault_mode,
        policy_mode,
        str(fallback.get("reaction", "unresolved")),
        None if fallback.get("value") is None else str(fallback["value"]),
        True,
        "generic-majority fallback",
        None,
        {},
        "No exact source row matched this route; expectation remains ON HOLD.",
    )


def onfail_exception_decision(route: dict[str, Any], exception_category: str) -> OnFailDecision:
    """Resolve the source response for a DBC invalid or reserved/out-of-range input."""
    policy_mode = "signal_invalid" if exception_category == "invalid" else "reserved_or_out_of_range"
    return onfail_decision(route, f"dbc_{exception_category}", policy_mode=policy_mode)


def sha256_file(path: Path) -> str:
    """Return a content hash for immutable engineering evidence."""
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _analysis_header_indexes(worksheet: Worksheet) -> tuple[int, dict[str, int]]:
    for row_number, row in enumerate(worksheet.iter_rows(values_only=True), start=1):
        headers = {
            str(value).strip(): column_index
            for column_index, value in enumerate(row)
            if value is not None and str(value).strip()
        }
        if set(DRBFM_ANALYSIS_HEADERS).issubset(headers):
            return row_number, headers
    raise ValueError(f"Required DRBFM analysis headers are missing from worksheet {worksheet.title!r}.")


def load_drbfm_analysis(source_path: Path = DRBFM_WORKBOOK) -> list[DrbfmElement]:
    """Read every analysis row by header name and preserve its exact worksheet row."""
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    workbook = openpyxl.load_workbook(source_path, read_only=True, data_only=False)
    try:
        if DRBFM_ANALYSIS_SHEET not in workbook.sheetnames:
            raise KeyError(f"Missing DRBFM analysis worksheet: {DRBFM_ANALYSIS_SHEET}")
        worksheet = workbook[DRBFM_ANALYSIS_SHEET]
        header_row, header_indexes = _analysis_header_indexes(worksheet)
        elements: list[DrbfmElement] = []
        for row_number, row in enumerate(worksheet.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1):
            parameter_name = row[header_indexes["EDR Parameter name"]]
            if parameter_name is None or not str(parameter_name).strip():
                continue
            values = {
                header: row[column_index] if column_index < len(row) else None
                for header, column_index in header_indexes.items()
            }
            logical_id = values["Diag Logical ID"]
            elements.append(
                DrbfmElement(
                    source_row=row_number,
                    logical_id=None if logical_id is None else str(logical_id).strip(),
                    parameter_name=str(parameter_name).strip(),
                    values=values,
                )
            )
        return elements
    finally:
        workbook.close()


def drbfm_workbook_manifest(source_path: Path = DRBFM_WORKBOOK) -> dict[str, Any]:
    """Verify full-sheet extraction coverage without modifying the controlled source."""
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    workbook = openpyxl.load_workbook(source_path, read_only=True, data_only=False)
    try:
        sheets = []
        for worksheet in workbook.worksheets:
            scanned_rows = 0
            non_empty_rows = 0
            for scanned_rows, values in enumerate(worksheet.iter_rows(values_only=True), start=1):
                if any(value is not None for value in values):
                    non_empty_rows += 1
            sheets.append(
                {
                    "name": worksheet.title,
                    "state": worksheet.sheet_state,
                    "declared_max_row": worksheet.max_row,
                    "declared_max_column": worksheet.max_column,
                    "scanned_rows": scanned_rows,
                    "non_empty_rows": non_empty_rows,
                }
            )
        return {
            "path": str(source_path),
            "sha256": sha256_file(source_path),
            "extractor": f"openpyxl {openpyxl.__version__}",
            "sheets": sheets,
        }
    finally:
        workbook.close()


VARIANT_SOURCES = {
    "U171": {
        "vehicle_class": "ICE",
        "project_key": "U171",
        "dbc_sources": (("CAN", U171_DBC),),
        "json_sources": (("CAN", U171_DBC_JSON),),
        "canc_config": U171_CANC_CONFIG,
        "variant_config": U171_VARIANT_CONFIG,
    },
    "M314": {
        "vehicle_class": "EV",
        "project_key": "M310_M314_M110",
        "dbc_sources": (("CAN-FD", M314_FD_DBC), ("HS-CAN", M314_HSCAN_DBC)),
        "json_sources": (("CAN-FD", M314_FD_DBC_JSON), ("HS-CAN", M314_HSCAN_DBC_JSON)),
        "canc_config": M314_CANC_CONFIG,
        "variant_config": M314_VARIANT_CONFIG,
    },
}


def _safe_ast_value(node: ast.AST, symbols: dict[str, Any]) -> Any:
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        if node.id not in symbols:
            raise ValueError(f"Unresolved configuration symbol: {node.id}")
        return symbols[node.id]
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        value = _safe_ast_value(node.operand, symbols)
        return value if isinstance(node.op, ast.UAdd) else -value
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        values = [_safe_ast_value(value, symbols) for value in node.elts]
        return tuple(values) if isinstance(node, ast.Tuple) else values
    if isinstance(node, ast.Dict):
        return {
            _safe_ast_value(key, symbols): _safe_ast_value(value, symbols)
            for key, value in zip(node.keys, node.values)
            if key is not None
        }
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "get":
        mapping = _safe_ast_value(node.func.value, symbols)
        arguments = [_safe_ast_value(argument, symbols) for argument in node.args]
        if not isinstance(mapping, dict) or not arguments:
            raise ValueError("Only dictionary get() calls are supported in static configuration extraction.")
        return mapping.get(*arguments)
    raise ValueError(f"Unsupported static configuration expression: {type(node).__name__}")


def load_static_config(path: Path) -> dict[str, Any]:
    """Read project constants without importing framework or bench-facing modules."""
    if not path.is_file():
        raise FileNotFoundError(path)
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    symbols: dict[str, Any] = {}
    for statement in tree.body:
        if not (
            isinstance(statement, ast.Assign)
            and len(statement.targets) == 1
            and isinstance(statement.targets[0], ast.Name)
        ):
            continue
        try:
            symbols[statement.targets[0].id] = _safe_ast_value(statement.value, symbols)
        except ValueError:
            continue
    return symbols


def _config_routes(symbols: dict[str, Any], project_key: str) -> list[dict[str, str]]:
    routes = []
    for symbol, definition in symbols.items():
        if not symbol.startswith("CAN_") or not isinstance(definition, dict):
            continue
        frame = definition.get("frame")
        signal = definition.get("signal")
        if not isinstance(frame, str) or not isinstance(signal, str):
            continue
        parameter = definition.get("EDR_Parameter")
        routes.append(
            {
                "symbol": symbol,
                "frame": frame,
                "signal": signal,
                "edr_parameter": "" if parameter is None else str(parameter),
                "fault_logic": definition.get("fault_logic") if isinstance(definition.get("fault_logic"), dict) else {},
                "default_value": definition.get("Default_Value"),
            }
        )

    def add_receive_map(mapping: Any, prefix: str) -> None:
        if not isinstance(mapping, dict):
            return
        for parameter, target in mapping.items():
            if not (
                isinstance(parameter, str)
                and isinstance(target, (list, tuple))
                and len(target) == 2
                and isinstance(target[0], str)
                and isinstance(target[1], str)
            ):
                continue
            routes.append(
                {
                    "symbol": f"{prefix}{parameter}",
                    "frame": target[0],
                    "signal": target[1],
                    "edr_parameter": parameter,
                }
            )

    receive_map = symbols.get("CAN_SIGNAL_Rx_MAP")
    if isinstance(receive_map, dict):
        add_receive_map(receive_map.get(project_key, receive_map), "RX_")
    add_receive_map(symbols.get("CAN_HSCAN_SIGNAL_Rx_MAP"), "HSRX_")
    return routes


def _message_configurations(symbols: dict[str, Any]) -> dict[str, dict[str, Any]]:
    configurations: dict[str, dict[str, Any]] = {}
    for configuration_name in ("CAN_TX_MESSAGE_CONFIG", "CAN_RX_MESSAGE_CONFIG"):
        values = symbols.get(configuration_name)
        if not isinstance(values, dict):
            continue
        for frame, configuration in values.items():
            if isinstance(frame, str) and isinstance(configuration, dict):
                configurations.setdefault(frame, configuration)
    return configurations


def _variant_enabled_nodes(source: dict[str, Any]) -> tuple[str, ...]:
    symbols = load_static_config(source["variant_config"])
    defaults = symbols.get("project_defaults", {})
    project_defaults = defaults.get(source["project_key"], {}) if isinstance(defaults, dict) else {}
    enabled_nodes = project_defaults.get("enabled_nodes", []) if isinstance(project_defaults, dict) else []
    return tuple(str(node) for node in enabled_nodes)


def _load_dbc_index(bus: str, source_path: Path) -> tuple[dict[tuple[str, str], dict[str, Any]], dict[str, Any]]:
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    database: Any = load_dbc_file(source_path)
    index: dict[tuple[str, str], dict[str, Any]] = {}
    for message in database.messages:
        for signal in message.signals:
            choices = tuple(sorted((int(raw), str(label)) for raw, label in (signal.choices or {}).items()))
            index[(message.name, signal.name)] = {
                "bus": bus,
                "source_path": str(source_path),
                "can_id": f"0x{message.frame_id:X}",
                "dlc": message.length,
                "message": message.name,
                "signal": signal.name,
                "senders": tuple(message.senders),
                "cycle_time_ms": message.cycle_time,
                "multiplexer_signal": signal.multiplexer_signal,
                "multiplexer_ids": tuple(signal.multiplexer_ids or ()),
                "start_bit": signal.start,
                "bit_length": signal.length,
                "byte_order": signal.byte_order,
                "signed": signal.is_signed,
                "factor": signal.scale,
                "offset": signal.offset,
                "minimum": signal.minimum,
                "maximum": signal.maximum,
                "unit": signal.unit,
                "choices": choices,
                "initial": None if signal.initial is None else str(signal.initial),
                "invalid": None if signal.invalid is None else str(signal.invalid),
            }
    return index, {
        "path": str(source_path),
        "sha256": sha256_file(source_path),
        "bus": bus,
        "message_count": len(database.messages),
        "parser": f"cantools {cantools.__version__}",
    }


def _json_choice_map(signal: dict[str, Any]) -> dict[int, str]:
    return {
        int(raw_value, 0): str(label)
        for raw_value, label in (signal.get("value_descriptions") or {}).items()
    }


def _load_json_dbc_index(
    bus: str,
    dbc_path: Path,
    json_path: Path,
    raw_index: dict[tuple[str, str], dict[str, Any]],
) -> tuple[dict[tuple[str, str], dict[str, Any]], dict[str, Any]]:
    """Validate and normalize the DBC-to-JSON skill output before using it for arrays."""
    if not json_path.is_file():
        raise FileNotFoundError(
            f"Validated JSON catalog is required for {dbc_path.name}; run {DBC_TO_JSON_CONVERTER.name} first: {json_path}"
        )
    messages = json.loads(json_path.read_text(encoding="utf-8"))
    if not isinstance(messages, list):
        raise ValueError(f"DBC JSON catalog must contain a message list: {json_path}")
    json_index: dict[tuple[str, str], dict[str, Any]] = {}
    json_messages: dict[str, dict[str, Any]] = {}
    for message in messages:
        if not isinstance(message, dict) or not isinstance(message.get("name"), str):
            raise ValueError(f"DBC JSON message is malformed: {json_path}")
        json_messages[message["name"]] = message
        for signal in message.get("signals") or []:
            if not isinstance(signal, dict) or not isinstance(signal.get("name"), str):
                raise ValueError(f"DBC JSON signal is malformed: {json_path} / {message['name']}")
            json_index[(message["name"], signal["name"])] = signal
    if set(json_index) != set(raw_index):
        missing = sorted(set(raw_index).difference(json_index))
        unexpected = sorted(set(json_index).difference(raw_index))
        raise ValueError(f"DBC/JSON signal catalog mismatch for {dbc_path.name}; missing={missing}, unexpected={unexpected}")

    normalized: dict[tuple[str, str], dict[str, Any]] = {}
    compared_signal_fields = {
        "start_bit": "start_bit",
        "length": "bit_length",
        "byte_order": "byte_order",
        "is_signed": "signed",
        "factor": "factor",
        "offset": "offset",
        "min": "minimum",
        "max": "maximum",
        "unit": "unit",
    }
    for key, raw_metadata in raw_index.items():
        json_signal = json_index[key]
        json_message = json_messages[key[0]]
        if int(str(json_message["frame_id"]), 0) != int(raw_metadata["can_id"], 0):
            raise ValueError(f"DBC/JSON frame ID mismatch for {dbc_path.name}: {key}")
        if json_message.get("length") != raw_metadata["dlc"]:
            raise ValueError(f"DBC/JSON DLC mismatch for {dbc_path.name}: {key}")
        if json_message.get("cycle_time") != raw_metadata["cycle_time_ms"]:
            raise ValueError(f"DBC/JSON cycle-time mismatch for {dbc_path.name}: {key}")
        for json_field, raw_field in compared_signal_fields.items():
            if json_signal.get(json_field) != raw_metadata[raw_field]:
                raise ValueError(
                    f"DBC/JSON signal metadata mismatch for {dbc_path.name}: {key} {json_field}="
                    f"{json_signal.get(json_field)!r} != {raw_metadata[raw_field]!r}"
                )
        raw_choices = {raw_value: label for raw_value, label in raw_metadata["choices"]}
        json_choices = _json_choice_map(json_signal)
        if json_choices != raw_choices:
            raise ValueError(f"DBC/JSON value-description mismatch for {dbc_path.name}: {key}")
        normalized_metadata = dict(raw_metadata)
        normalized_metadata.update(
            {
                "start_bit": json_signal["start_bit"],
                "bit_length": json_signal["length"],
                "byte_order": json_signal["byte_order"],
                "signed": json_signal["is_signed"],
                "factor": json_signal["factor"],
                "offset": json_signal["offset"],
                "minimum": json_signal["min"],
                "maximum": json_signal["max"],
                "unit": json_signal["unit"],
                "choices": tuple(sorted(json_choices.items())),
                "json_path": str(json_path),
                "json_sha256": sha256_file(json_path),
                "metadata_source": "validated DBC JSON",
            }
        )
        normalized[key] = normalized_metadata
    return normalized, {
        "json_path": str(json_path),
        "json_sha256": sha256_file(json_path),
        "json_message_count": len(messages),
        "json_signal_count": len(json_index),
        "converter_path": str(DBC_TO_JSON_CONVERTER),
        "converter_sha256": sha256_file(DBC_TO_JSON_CONVERTER),
        "metadata_source": "validated DBC JSON",
    }


def load_variant_context(variant: str) -> dict[str, Any]:
    """Load one variant's static config and DBC evidence without external side effects."""
    source = VARIANT_SOURCES[variant]
    symbols = load_static_config(source["canc_config"])
    signal_index: dict[tuple[str, str], dict[str, Any]] = {}
    dbc_manifest = []
    json_sources = dict(source["json_sources"])
    for bus, path in source["dbc_sources"]:
        raw_index, metadata = _load_dbc_index(bus, path)
        current_index, json_metadata = _load_json_dbc_index(bus, path, json_sources[bus], raw_index)
        collisions = set(signal_index).intersection(current_index)
        if collisions:
            raise ValueError(f"Duplicate DBC message/signal routes for {variant}: {sorted(collisions)}")
        signal_index.update(current_index)
        dbc_manifest.append({**metadata, **json_metadata})
    message_metadata = {}
    for metadata in signal_index.values():
        message_metadata.setdefault(metadata["message"], metadata)
    key_frames = symbols.get("KEY_TX_FRAMES", {})
    return {
        "variant": variant,
        "vehicle_class": source["vehicle_class"],
        "project_key": source["project_key"],
        "config_path": str(source["canc_config"]),
        "variant_config_path": str(source["variant_config"]),
        "enabled_nodes": _variant_enabled_nodes(source),
        "routes": _config_routes(symbols, source["project_key"]),
        "message_configurations": _message_configurations(symbols),
        "key_frames": {
            str(frame): bool(is_key)
            for frame, is_key in key_frames.items()
            if isinstance(frame, str)
        } if isinstance(key_frames, dict) else {},
        "message_metadata": message_metadata,
        "signal_index": signal_index,
        "dbc_manifest": dbc_manifest,
    }


def _element_aliases(element: DrbfmElement) -> set[str]:
    normalized = element.normalized_name
    return {normalized, *EXPLICIT_ELEMENT_ALIASES.get(normalized, ())}


def _as_dtc_codes(value: Any) -> tuple[str, ...]:
    if value is None or value == "":
        return ()
    if isinstance(value, dict):
        return tuple(sorted(str(code) for code in value.values() if code not in {None, ""}))
    if isinstance(value, (list, tuple, set)):
        return tuple(str(code) for code in value if code not in {None, ""})
    return (str(value),)


def _shared_dbc_sender(context: dict[str, Any], first_frame: object, second_frame: object) -> bool:
    messages = context.get("message_metadata", {})
    first = messages.get(first_frame) if isinstance(first_frame, str) else None
    second = messages.get(second_frame) if isinstance(second_frame, str) else None
    if first is None or second is None:
        return False
    first_senders = set(first.get("senders", ()))
    second_senders = set(second.get("senders", ()))
    return not first_senders and not second_senders or bool(first_senders.intersection(second_senders))


def _is_verified_key_frame(context: dict[str, Any], key_frame: object, carrying_frame: object) -> tuple[bool, str]:
    if not isinstance(key_frame, str):
        return False, "No key frame is configured."
    key_frames = context.get("key_frames", {})
    if key_frames.get(key_frame) is not True:
        return False, f"Configured key frame {key_frame} is not marked as key."
    messages = context.get("message_metadata", {})
    key_metadata = messages.get(key_frame)
    if key_metadata is None:
        return False, f"Configured key frame {key_frame} is absent from the selected DBC."
    if not key_metadata.get("senders", ()):
        return True, f"Configured key frame {key_frame}; DBC sender metadata is unavailable."
    if not _shared_dbc_sender(context, key_frame, carrying_frame):
        return False, f"Configured key frame {key_frame} has no verified DBC sender group with {carrying_frame}."
    peer_frames = [
        (int(str(candidate["can_id"]), 0), frame)
        for frame, candidate in messages.items()
        if _shared_dbc_sender(context, key_frame, frame)
    ]
    if not peer_frames:
        return False, f"No DBC peers are available to verify key frame {key_frame}."
    actual_key = min(peer_frames)[1]
    if actual_key != key_frame:
        return False, f"DBC arbitration selects {actual_key} rather than configured key frame {key_frame}."
    return True, f"DBC-verified key frame {key_frame}."


def _fault_source(
    message_configuration: dict[str, Any] | None,
    fault_logic: dict[str, Any] | None,
) -> dict[str, Any]:
    if isinstance(fault_logic, dict) and fault_logic:
        return fault_logic
    return message_configuration if isinstance(message_configuration, dict) else {}


def _route_fault_assessment(
    message_configuration: dict[str, Any] | None,
    signal: str,
    *,
    fault_logic: dict[str, Any] | None = None,
    context: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> tuple[dict[str, tuple[str, ...]], dict[str, str]]:
    """Return only fault modes whose DTC and structural prerequisites are both evidenced."""
    faults: dict[str, tuple[str, ...]] = {
        "node_absent": (),
        "message_timeout": (),
        "message_content": (),
        "signal_content": (),
    }
    eligibility = {mode: "No configuration-backed fault evidence." for mode in faults}
    source = _fault_source(message_configuration, fault_logic)
    if not source or context is None or metadata is None:
        return faults, eligibility

    carrying_frame = metadata["message"]
    node_codes = _as_dtc_codes(source.get("node_absent_dtc"))
    node_ok, node_reason = _is_verified_key_frame(context, source.get("key_message"), carrying_frame)
    eligibility["node_absent"] = node_reason
    if node_codes and node_ok:
        faults["node_absent"] = node_codes

    timeout_codes = _as_dtc_codes(source.get("message_timeout_dtc"))
    timeout_frame = source.get("non_key_timeout_frame")
    key_ok, key_reason = _is_verified_key_frame(context, source.get("key_message"), carrying_frame)
    if not key_ok:
        eligibility["message_timeout"] = f"Configured timeout key frame is not verified: {key_reason}"
    elif not isinstance(timeout_frame, str):
        eligibility["message_timeout"] = "No explicit non-key timeout frame is configured."
    elif context.get("key_frames", {}).get(timeout_frame) is True:
        eligibility["message_timeout"] = f"Timeout target {timeout_frame} is marked as a key frame."
    elif context.get("message_metadata", {}).get(timeout_frame) is None:
        eligibility["message_timeout"] = f"Timeout target {timeout_frame} is absent from the selected DBC."
    elif not _shared_dbc_sender(context, source.get("key_message"), timeout_frame):
        eligibility["message_timeout"] = f"Timeout target {timeout_frame} has no verified DBC sender group with the configured key frame."
    else:
        eligibility["message_timeout"] = f"Verified non-key timeout target {timeout_frame}."
        if timeout_codes:
            faults["message_timeout"] = timeout_codes

    content_map = source.get("message_content_failure_dtcs", {})
    if not isinstance(content_map, dict) and isinstance(message_configuration, dict):
        content_map = message_configuration.get("message_content_failure_dtcs", {})
    verified_content_codes = []
    if isinstance(content_map, dict):
        for integrity_signal, code in content_map.items():
            if (carrying_frame, str(integrity_signal)) in context["signal_index"] and code not in {None, ""}:
                verified_content_codes.extend(_as_dtc_codes(code))
    if verified_content_codes:
        faults["message_content"] = tuple(sorted(set(verified_content_codes)))
        eligibility["message_content"] = "Configured CRC/alive counter is present in the carrying DBC message."
    else:
        eligibility["message_content"] = "No configured CRC/alive counter is present in the carrying DBC message."

    direct_signal_codes = _as_dtc_codes(source.get("signal_content_failure_dtc"))
    if not direct_signal_codes:
        signal_map = source.get("signal_content_failure_dtcs", {})
        if not isinstance(signal_map, dict) and isinstance(message_configuration, dict):
            signal_map = message_configuration.get("signal_content_failure_dtcs", {})
        direct_signal_codes = _as_dtc_codes(signal_map.get(signal) if isinstance(signal_map, dict) else None)
    invalid_values, _, _ = _semantic_choice_sets(metadata)
    if direct_signal_codes and invalid_values:
        faults["signal_content"] = direct_signal_codes
        eligibility["signal_content"] = "Configured signal-content DTC and DBC invalid code are both present."
    elif not direct_signal_codes:
        eligibility["signal_content"] = "No signal-content DTC is configured for this signal."
    else:
        eligibility["signal_content"] = "The DBC provides no invalid code for this signal."
    return faults, eligibility


def _route_faults(
    message_configuration: dict[str, Any] | None,
    signal: str,
    *,
    fault_logic: dict[str, Any] | None = None,
    context: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, tuple[str, ...]]:
    return _route_fault_assessment(
        message_configuration,
        signal,
        fault_logic=fault_logic,
        context=context,
        metadata=metadata,
    )[0]


def _candidate_score(element: DrbfmElement, route: dict[str, str], aliases: set[str]) -> int:
    normalized = element.normalized_name
    fields = {
        "edr_parameter": _match_forms(route["edr_parameter"]),
        "signal": _match_forms(route["signal"]),
        "symbol": _match_forms(route["symbol"].removeprefix("CAN_")),
    }
    if normalized in fields["edr_parameter"]:
        return 100
    if normalized in fields["signal"]:
        return 95
    if normalized in fields["symbol"]:
        return 90
    if fields["edr_parameter"].intersection(aliases):
        return 80
    if fields["signal"].intersection(aliases):
        return 75
    if fields["symbol"].intersection(aliases):
        return 70
    return 0


def _match_forms(value: object) -> set[str]:
    normalized = normalize_name(value)
    return {normalized, re.sub(r"\d+$", "", normalized)} if normalized else set()


def _source_kind(dbc_metadata: dict[str, Any] | None) -> str:
    if dbc_metadata is None:
        return "Unresolved"
    frame = str(dbc_metadata["message"]).upper()
    senders = {sender.upper() for sender in dbc_metadata["senders"]}
    if frame.startswith("SRS") or "SRS" in senders:
        return "ECU-generated CAN"
    return "External CAN"


def resolve_element_route(element: DrbfmElement, context: dict[str, Any]) -> dict[str, Any]:
    """Resolve one element with evidence level instead of guessing across variants."""
    if "reserved" in element.normalized_name:
        return {
            "variant": context["variant"],
            "vehicle_class": context["vehicle_class"],
            "state": "Reserved EDR field",
            "basis": "DRBFM parameter name marks the field as reserved",
            "source_kind": "Reserved",
            "faults": _route_faults(None, ""),
            "fault_eligibility": {},
            "onfail_policy": None,
            "dbc": None,
            "alternative_dbc_routes": (),
            "config_symbol": None,
            "config_edr_parameter": None,
            "enabled_node": None,
            "enablement_evidence": "Not applicable",
        }
    aliases = _element_aliases(element)
    candidates: list[dict[str, Any]] = []
    for route in context["routes"]:
        score = _candidate_score(element, route, aliases)
        if score == 0:
            continue
        metadata = context["signal_index"].get((route["frame"], route["signal"]))
        candidates.append(
            {
                "score": score,
                "basis": "project configuration",
                "route": route,
                "dbc": metadata,
            }
        )
    for metadata in context["signal_index"].values():
        signal_name = normalize_name(metadata["signal"])
        if signal_name not in aliases:
            continue
        candidates.append(
            {
                "score": 50 if signal_name == element.normalized_name else 45,
                "basis": "DBC-only signal-name match",
                "route": None,
                "dbc": metadata,
            }
        )
    if not candidates:
        return {
            "variant": context["variant"],
            "vehicle_class": context["vehicle_class"],
            "state": "No verified CAN route",
            "basis": "No explicit configuration or DBC signal-name match",
            "source_kind": "Unresolved",
            "faults": _route_faults(None, ""),
            "fault_eligibility": {},
            "onfail_policy": None,
            "dbc": None,
            "alternative_dbc_routes": (),
            "config_symbol": None,
            "config_edr_parameter": None,
            "enabled_node": None,
            "enablement_evidence": "No route",
        }

    highest_score = max(candidate["score"] for candidate in candidates)
    top = [candidate for candidate in candidates if candidate["score"] == highest_score]
    distinct_routes = {
        (
            candidate["route"]["frame"] if candidate["route"] else candidate["dbc"]["message"],
            candidate["route"]["signal"] if candidate["route"] else candidate["dbc"]["signal"],
        )
        for candidate in top
    }
    alternative_dbc_routes: tuple[dict[str, Any], ...] = ()
    if len(distinct_routes) > 1:
        top_metadata = tuple(candidate["dbc"] for candidate in top if candidate["dbc"] is not None)
        signal_names = {metadata["signal"] for metadata in top_metadata}
        if len(signal_names) == 1 and top_metadata and all(_source_kind(metadata) == "ECU-generated CAN" for metadata in top_metadata):
            alternative_dbc_routes = top_metadata
        else:
            return {
                "variant": context["variant"],
                "vehicle_class": context["vehicle_class"],
                "state": "Ambiguous CAN route",
                "basis": "; ".join(f"{frame}/{signal}" for frame, signal in sorted(distinct_routes)),
                "source_kind": "Unresolved",
                "faults": _route_faults(None, ""),
                "fault_eligibility": {},
                "onfail_policy": None,
                "dbc": None,
                "alternative_dbc_routes": (),
                "config_symbol": None,
                "config_edr_parameter": None,
                "enabled_node": None,
                "enablement_evidence": "Ambiguous route",
            }

    selected = top[0]
    route = selected["route"]
    metadata = selected["dbc"]
    message_configuration = context["message_configurations"].get(route["frame"] if route else metadata["message"])
    key_node = message_configuration.get("key_node") if isinstance(message_configuration, dict) else None
    enabled_node = None if key_node in {None, ""} else str(key_node)
    if enabled_node is None:
        enablement_evidence = "No key-node configuration is defined for this route"
    elif enabled_node in context["enabled_nodes"]:
        enablement_evidence = f"Variant defaults explicitly list {enabled_node}"
    else:
        enablement_evidence = f"Variant defaults do not explicitly list configured node {enabled_node}"
    if route is None:
        state = "DBC-only CAN route"
    elif metadata is None:
        state = "Configured route absent from selected DBC"
    elif alternative_dbc_routes:
        state = "Applicable multi-bus CAN route"
    else:
        state = "Applicable CAN route"
    faults, fault_eligibility = _route_fault_assessment(
        message_configuration,
        route["signal"] if route else (metadata["signal"] if metadata is not None else ""),
        fault_logic=route.get("fault_logic") if route is not None else None,
        context=context,
        metadata=metadata,
    )
    return {
        "variant": context["variant"],
        "vehicle_class": context["vehicle_class"],
        "state": state,
        "basis": selected["basis"],
        "source_kind": _source_kind(metadata),
        "faults": faults,
        "fault_eligibility": fault_eligibility,
        "onfail_policy": find_onfail_policy_record_for_dbc(metadata) if metadata is not None else None,
        "dbc": metadata,
        "alternative_dbc_routes": alternative_dbc_routes,
        "config_symbol": None if route is None else route["symbol"],
        "config_edr_parameter": None if route is None else route["edr_parameter"],
        "enabled_node": enabled_node,
        "enablement_evidence": enablement_evidence,
    }


TIME_RANGE_PATTERN = re.compile(
    r"^\s*([+-]?\d+(?:\.\d+)?)\s*(ms|s)?\s+to\s+([+-]?\d+(?:\.\d+)?)\s*(ms|s)\s*$",
    flags=re.IGNORECASE,
)
TIME_POINT_PATTERN = re.compile(r"^\s*([+-]?\d+(?:\.\d+)?)\s*(ms|s)\s*$", flags=re.IGNORECASE)
NUMBER_PATTERN = re.compile(r"^[+-]?\d+(?:\.\d+)?$")


def _numeric_value(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value or "").strip()
    return float(text) if NUMBER_PATTERN.fullmatch(text) else None


def _seconds(value: str, unit: str | None) -> float:
    numeric = float(value)
    return numeric / 1000 if (unit or "s").casefold() == "ms" else numeric


def sampling_schedule(element: DrbfmElement) -> tuple[float, ...]:
    """Return the explicit recording grid; blank/T0 fields are single snapshots at T0."""
    interval = str(element.values.get("Sampling Interval") or "").strip()
    if not interval:
        return (0.0,)
    if interval.casefold() == "t0":
        return (0.0,)
    point = TIME_POINT_PATTERN.fullmatch(interval)
    if point:
        return (_seconds(point.group(1), point.group(2)),)
    range_match = TIME_RANGE_PATTERN.fullmatch(interval)
    sample_rate = _numeric_value(element.values.get("Data Samples per second"))
    if range_match is None or sample_rate is None or sample_rate <= 0:
        return ()
    start_unit = range_match.group(2) or range_match.group(4)
    start = _seconds(range_match.group(1), start_unit)
    end = _seconds(range_match.group(3), range_match.group(4))
    if end < start:
        return ()
    count = int(round((end - start) * sample_rate)) + 1
    return tuple(round(start + index / sample_rate, 9) for index in range(count))


def recording_model(element: DrbfmElement) -> str:
    """Classify a DRBFM row without treating a snapshot as a sampled history."""
    interval = str(element.values.get("Sampling Interval") or "").strip()
    if not interval or interval.casefold() == "t0":
        return "snapshot"
    if TIME_POINT_PATTERN.fullmatch(interval):
        return "single-point"
    if TIME_RANGE_PATTERN.fullmatch(interval) and (_numeric_value(element.values.get("Data Samples per second")) or 0) > 0:
        return "interval"
    return "unknown"


def _sample_period_seconds(element: DrbfmElement) -> float | None:
    schedule = sampling_schedule(element)
    if len(schedule) >= 2:
        return schedule[1] - schedule[0]
    rate = _numeric_value(element.values.get("Data Samples per second"))
    return None if rate is None or rate <= 0 else 1 / rate


def simulation_window(element: DrbfmElement, recording_time_s: float) -> tuple[float | None, float]:
    """Return the signal-drive window ending at the source recording time."""
    model = recording_model(element)
    if model == "snapshot":
        return (-0.5, 0.0)
    period = _sample_period_seconds(element)
    if period is None:
        return (None, recording_time_s)
    return (round(recording_time_s - period, 9), recording_time_s)


def _field_byte_length(element: DrbfmElement) -> int | None:
    value = element.values.get("length in bytes")
    if isinstance(value, int) and value > 0:
        return value
    if isinstance(value, float) and value.is_integer() and value > 0:
        return int(value)
    match = re.search(r"\d+", str(value or ""))
    return int(match.group()) if match else None


def _raw_hex(raw_value: int, bit_length: int) -> str:
    width = max(1, math.ceil(bit_length / 4))
    return f"0x{raw_value & ((1 << bit_length) - 1):0{width}X}"


def _semantic_choice_sets(metadata: dict[str, Any]) -> tuple[set[int], set[int], set[int]]:
    invalid, reserved, defaults = set(), set(), set()
    for raw_value, label in metadata["choices"]:
        normalized = str(label).casefold()
        if "invalid" in normalized:
            invalid.add(raw_value)
        if "reserved" in normalized:
            reserved.add(raw_value)
        if "default" in normalized:
            defaults.add(raw_value)
    return invalid, reserved, defaults


def _physical_value(raw_value: int, metadata: dict[str, Any]) -> float:
    return raw_value * float(metadata["factor"]) + float(metadata["offset"])


def _raw_bounds(metadata: dict[str, Any]) -> tuple[int, int]:
    bit_length = int(metadata["bit_length"])
    if metadata["signed"]:
        return -(1 << (bit_length - 1)), (1 << (bit_length - 1)) - 1
    return 0, (1 << bit_length) - 1


def _raw_for_physical(value: float, metadata: dict[str, Any]) -> int:
    return int(round((value - float(metadata["offset"])) / float(metadata["factor"])))


def dbc_valid_vectors(metadata: dict[str, Any]) -> list[dict[str, Any]]:
    """Provide bounded valid raw/physical values from the selected native DBC definition."""
    invalid, reserved, defaults = _semantic_choice_sets(metadata)
    choices = list(metadata["choices"])
    valid_choices = [(raw_value, label) for raw_value, label in choices if raw_value not in invalid and raw_value not in reserved]
    if choices and (len(valid_choices) > 1 or int(metadata["bit_length"]) <= 4):
        vectors = []
        for raw_value, label in valid_choices:
            vectors.append(
                {
                    "scenario": "default" if raw_value in defaults else "valid state",
                    "raw_integer": raw_value,
                    "raw_hex": _raw_hex(raw_value, int(metadata["bit_length"])),
                    "physical_value": _physical_value(raw_value, metadata),
                    "choice_label": label,
                }
            )
        return vectors

    minimum = metadata["minimum"]
    maximum = metadata["maximum"]
    if minimum is None or maximum is None:
        return []
    lower_bound, upper_bound = _raw_bounds(metadata)
    raw_minimum = max(lower_bound, _raw_for_physical(float(minimum), metadata))
    raw_maximum = min(upper_bound, _raw_for_physical(float(maximum), metadata))
    candidates = [
        ("minimum", raw_minimum),
        ("near minimum", raw_minimum + 1),
        ("midpoint", int(round((raw_minimum + raw_maximum) / 2))),
        ("near maximum", raw_maximum - 1),
        ("maximum", raw_maximum),
    ]
    vectors = []
    seen = set()
    for scenario, raw_value in candidates:
        if raw_value in seen or raw_value < raw_minimum or raw_value > raw_maximum:
            continue
        if raw_value in invalid or raw_value in reserved:
            continue
        seen.add(raw_value)
        vectors.append(
            {
                "scenario": scenario,
                "raw_integer": raw_value,
                "raw_hex": _raw_hex(raw_value, int(metadata["bit_length"])),
                "physical_value": _physical_value(raw_value, metadata),
                "choice_label": None,
            }
        )
    return vectors


def _physical_range_status(physical_value: float, metadata: dict[str, Any]) -> str:
    minimum = metadata.get("minimum")
    maximum = metadata.get("maximum")
    if minimum is None or maximum is None:
        return "RANGE_UNSPECIFIED"
    if float(minimum) <= physical_value <= float(maximum):
        return "IN_RANGE"
    return "OUT_OF_RANGE_REVIEW"


def _nominal_candidates(metadata: dict[str, Any]) -> list[dict[str, Any]]:
    """Select only DBC-valid values and prefer non-zero physical values for nominal recording."""
    valid = dbc_valid_vectors(metadata)
    in_range = [
        vector
        for vector in valid
        if _physical_range_status(float(vector["physical_value"]), metadata) == "IN_RANGE"
    ]
    non_zero = [vector for vector in in_range if not math.isclose(float(vector["physical_value"]), 0.0, abs_tol=1e-12)]
    if non_zero:
        return non_zero
    return in_range


def _is_binary_valid_domain(metadata: dict[str, Any]) -> bool:
    candidates = _nominal_candidates(metadata)
    raw_values = {int(vector["raw_integer"]) for vector in candidates}
    all_valid = {
        int(vector["raw_integer"])
        for vector in dbc_valid_vectors(metadata)
        if _physical_range_status(float(vector["physical_value"]), metadata) == "IN_RANGE"
    }
    return raw_values == {1} and all_valid == {0, 1}


def nominal_recording_values(element: DrbfmElement, metadata: dict[str, Any], variant: str, count: int) -> list[dict[str, Any]]:
    """Build a deterministic DBC-valid nominal sequence with non-zero preference."""
    candidates = _nominal_candidates(metadata)
    if not candidates:
        return []
    if _is_binary_valid_domain(metadata):
        one = next(vector for vector in candidates if int(vector["raw_integer"]) == 1)
        zero = next(
            vector
            for vector in dbc_valid_vectors(metadata)
            if int(vector["raw_integer"]) == 0 and _physical_range_status(float(vector["physical_value"]), metadata) == "IN_RANGE"
        )
        seed = int(hashlib.sha256(f"{variant}:{element.source_row}:{metadata['message']}:{metadata['signal']}".encode("ascii")).hexdigest()[:16], 16)
        generator = random.Random(seed)
        values = [dict(one) for _ in range(min(3, count))]
        for index in range(len(values), count):
            values.append(dict(one if generator.randrange(2) else zero))
        if count > 3 and all(int(vector["raw_integer"]) == 1 for vector in values[3:]):
            values[-1] = dict(zero)
        return values
    return [dict(candidates[index % len(candidates)]) for index in range(count)]


def nominal_recording_points(element: DrbfmElement, metadata: dict[str, Any], variant: str) -> list[dict[str, Any]]:
    """Materialize timestamped nominal input and expected-recorded points from valid JSON metadata."""
    schedule = sampling_schedule(element)
    values = nominal_recording_values(element, metadata, variant, len(schedule))
    has_non_zero_candidate = any(
        not math.isclose(float(vector["physical_value"]), 0.0, abs_tol=1e-12)
        for vector in _nominal_candidates(metadata)
    )
    nominal_value_status = "VALID_NON_ZERO" if has_non_zero_candidate else "NO_NON_ZERO_VALID_VALUE_REVIEW"
    points: list[dict[str, Any]] = []
    for recording_time_s, value in zip(schedule, values):
        simulation_start_s, simulation_end_s = simulation_window(element, recording_time_s)
        physical_value = float(value["physical_value"])
        points.append(
            {
                "recording_time_s": recording_time_s,
                "simulation_window_start_s": simulation_start_s,
                "simulation_window_end_s": simulation_end_s,
                "input_raw_hex": value["raw_hex"],
                "input_raw_integer": value["raw_integer"],
                "input_physical_value": physical_value,
                "expected_recorded_raw_hex": value["raw_hex"],
                "expected_recorded_raw_integer": value["raw_integer"],
                "expected_recorded_physical_value": physical_value,
                "fault_state": "normal",
                "physical_range_status": _physical_range_status(physical_value, metadata),
                "nominal_value_status": nominal_value_status,
                "choice_label": value.get("choice_label"),
            }
        )
    return points


def _policy_raw_integer(value: str | None, metadata: dict[str, Any]) -> int | None:
    if value is None or not re.fullmatch(r"0x[0-9a-f]+", value.strip(), flags=re.IGNORECASE):
        return None
    raw_value = int(value, 16)
    return raw_value if raw_value < (1 << int(metadata["bit_length"])) else None


def _policy_default_values(decision: OnFailDecision, metadata: dict[str, Any]) -> dict[str, Any]:
    raw_value = _policy_raw_integer(decision.value, metadata)
    if raw_value is None:
        return {
            "expected_recorded_raw_hex": decision.value or "ON HOLD",
            "expected_recorded_raw_integer": "ON HOLD",
            "expected_recorded_physical_value": "ON HOLD",
            "physical_range_status": "UNRESOLVED_POLICY_VALUE",
            "nominal_value_status": "ON_HOLD_POLICY_DEFAULT",
        }
    physical_value = _physical_value(raw_value, metadata)
    return {
        "expected_recorded_raw_hex": decision.value,
        "expected_recorded_raw_integer": raw_value,
        "expected_recorded_physical_value": physical_value,
        "physical_range_status": _physical_range_status(physical_value, metadata),
        "nominal_value_status": "POLICY_DEFAULT",
    }


def _policy_consumed_values(decision: OnFailDecision, metadata: dict[str, Any]) -> dict[str, Any] | None:
    raw_value = _policy_raw_integer(decision.value, metadata)
    if raw_value is None:
        return None
    physical_value = _physical_value(raw_value, metadata)
    raw_hex = _raw_hex(raw_value, int(metadata["bit_length"]))
    return {
        "input_raw_hex": raw_hex,
        "input_raw_integer": raw_value,
        "input_physical_value": physical_value,
        "expected_recorded_raw_hex": raw_hex,
        "expected_recorded_raw_integer": raw_value,
        "expected_recorded_physical_value": physical_value,
        "physical_range_status": _physical_range_status(physical_value, metadata),
        "nominal_value_status": "POLICY_CONSUMED_VALUE",
    }


def _exception_policy_values(
    vector: dict[str, Any],
    metadata: dict[str, Any],
    decision: OnFailDecision,
) -> dict[str, Any]:
    if decision.reaction == "consume":
        return {
            "expected_recorded_raw_hex": vector["raw_hex"],
            "expected_recorded_raw_integer": vector["raw_integer"],
            "expected_recorded_physical_value": vector["physical_value"],
            "physical_range_status": _physical_range_status(float(vector["physical_value"]), metadata),
            "nominal_value_status": "POLICY_CONSUMED_EXCEPTION",
        }
    if decision.reaction == "default":
        return _policy_default_values(decision, metadata)
    return {
        "expected_recorded_raw_hex": "ON HOLD",
        "expected_recorded_raw_integer": "ON HOLD",
        "expected_recorded_physical_value": "ON HOLD",
        "physical_range_status": "UNRESOLVED_POLICY_REACTION",
        "nominal_value_status": "ON_HOLD_POLICY_REACTION",
    }


def onfail_recording_points(
    element: DrbfmElement,
    metadata: dict[str, Any],
    variant: str,
    fault_scope: str,
    *,
    decision: OnFailDecision | None = None,
) -> list[dict[str, Any]]:
    """Apply an explicit on-fail reaction without inventing a fallback for ambiguous source data."""
    normal_points = nominal_recording_points(element, metadata, variant)
    if not normal_points:
        return []
    if decision is None:
        decision = onfail_decision({"onfail_policy": None}, "message_timeout")
    if decision.fault_mode == "message_timeout" and decision.special.get("message_timeout_values"):
        policy_values = [
            raw_value
            for value in decision.special["message_timeout_values"]
            if (raw_value := _policy_raw_integer(str(value), metadata)) is not None
        ]
        valid_values = {int(vector["raw_integer"]) for vector in dbc_valid_vectors(metadata)}
        policy_values = [raw_value for raw_value in policy_values if raw_value in valid_values]
        if policy_values:
            labels = dict(metadata["choices"])
            for index, point in enumerate(normal_points):
                raw_value = policy_values[index % len(policy_values)]
                physical_value = _physical_value(raw_value, metadata)
                point.update(
                    {
                        "input_raw_hex": _raw_hex(raw_value, int(metadata["bit_length"])),
                        "input_raw_integer": raw_value,
                        "input_physical_value": physical_value,
                        "expected_recorded_raw_hex": _raw_hex(raw_value, int(metadata["bit_length"])),
                        "expected_recorded_raw_integer": raw_value,
                        "expected_recorded_physical_value": physical_value,
                        "physical_range_status": _physical_range_status(physical_value, metadata),
                        "nominal_value_status": "POLICY_QUALIFICATION_VALUE",
                        "choice_label": labels.get(raw_value),
                    }
                )
    primed_point = normal_points[0]
    t0_point = next((point for point in normal_points if math.isclose(point["recording_time_s"], 0.0, abs_tol=1e-12)), primed_point)
    points: list[dict[str, Any]] = []
    for normal_point in normal_points:
        point = dict(normal_point)
        timestamp = float(point["recording_time_s"])
        if fault_scope == "full":
            fault_active = True
        elif fault_scope == "pre":
            fault_active = timestamp < 0
        elif fault_scope == "post":
            fault_active = timestamp > 0
        else:
            raise ValueError(f"Unsupported on-fail scope: {fault_scope}")

        if decision.reaction == "last_valid":
            if fault_scope == "full":
                expected_point = primed_point
            elif fault_scope == "pre":
                expected_point = primed_point if fault_active else normal_point
            else:
                expected_point = t0_point if timestamp >= 0 else normal_point
            for field in (
                "expected_recorded_raw_hex",
                "expected_recorded_raw_integer",
                "expected_recorded_physical_value",
                "physical_range_status",
                "nominal_value_status",
            ):
                point[field] = expected_point[field]
        elif decision.reaction == "default" and fault_active:
            point.update(_policy_default_values(decision, metadata))
        elif decision.reaction == "unresolved" and fault_active:
            point.update(
                {
                    "expected_recorded_raw_hex": "ON HOLD",
                    "expected_recorded_raw_integer": "ON HOLD",
                    "expected_recorded_physical_value": "ON HOLD",
                    "physical_range_status": "UNRESOLVED_POLICY_REACTION",
                    "nominal_value_status": "ON_HOLD_POLICY_REACTION",
                }
            )

        consumed_values = _policy_consumed_values(decision, metadata) if fault_active and decision.reaction == "consume" else None
        if consumed_values is not None:
            point.update(consumed_values)

        if fault_active and decision.reaction != "consume":
            point["input_raw_hex"] = "FAULT_ACTIVE"
            point["input_raw_integer"] = "FAULT_ACTIVE"
            point["input_physical_value"] = "FAULT_ACTIVE"
            point["fault_state"] = f"fault active; {decision.reaction} reaction ({decision.source})"
        elif fault_active:
            consumed_text = f" policy input {decision.value}" if consumed_values is not None else " live input"
            point["fault_state"] = f"fault active; consumed{consumed_text} ({decision.source})"
        elif fault_scope == "post" and math.isclose(timestamp, 0.0, abs_tol=1e-12):
            point["fault_state"] = f"T0 prime; {decision.reaction} post-crash behavior begins after T0"
        else:
            point["fault_state"] = "normal/recovered valid input"
        points.append(point)
    return points


def dbc_exception_vectors(metadata: dict[str, Any]) -> list[dict[str, Any]]:
    """Expose encodable DBC invalid/reserved codes without inventing their EDR reaction."""
    invalid, reserved, _ = _semantic_choice_sets(metadata)
    vectors = []
    labels = dict(metadata["choices"])
    for category, values in (("invalid", invalid), ("reserved", reserved)):
        for raw_value in sorted(values):
            vectors.append(
                {
                    "scenario": category,
                    "raw_integer": raw_value,
                    "raw_hex": _raw_hex(raw_value, int(metadata["bit_length"])),
                    "physical_value": _physical_value(raw_value, metadata),
                    "choice_label": labels.get(raw_value),
                }
            )
    lower_bound, upper_bound = _raw_bounds(metadata)
    for raw_value in (lower_bound, upper_bound):
        physical_value = _physical_value(raw_value, metadata)
        if metadata["minimum"] is None or metadata["maximum"] is None:
            continue
        if physical_value < float(metadata["minimum"]) or physical_value > float(metadata["maximum"]):
            if raw_value in invalid or raw_value in reserved:
                continue
            vectors.append(
                {
                    "scenario": "encodable out-of-range",
                    "raw_integer": raw_value,
                    "raw_hex": _raw_hex(raw_value, int(metadata["bit_length"])),
                    "physical_value": physical_value,
                    "choice_label": labels.get(raw_value),
                }
            )
    return vectors


def edr_encoding_assessment(element: DrbfmElement, metadata: dict[str, Any], raw_value: int) -> str:
    """State only source-supported CAN-to-EDR conversion claims for one raw value."""
    source_can_scale = _numeric_value(element.values.get("Resolution_CAN"))
    source_can_offset = _numeric_value(element.values.get("Offset_CAN"))
    source_edr_scale = _numeric_value(element.values.get("Resolution_EDR"))
    source_edr_offset = _numeric_value(element.values.get("Offset_EDR"))
    if (
        source_can_scale is None
        or source_can_offset is None
        or source_edr_scale is None
        or source_edr_offset is None
    ):
        return "ON HOLD: DRBFM conversion fields are incomplete."
    if not math.isclose(source_can_scale, float(metadata["factor"]), rel_tol=0, abs_tol=1e-12) or not math.isclose(
        source_can_offset,
        float(metadata["offset"]),
        rel_tol=0,
        abs_tol=1e-12,
    ):
        return "ON HOLD: selected DBC CAN factor/offset differs from the DRBFM CAN conversion."
    physical_value = _physical_value(raw_value, metadata)
    edr_raw = (physical_value - source_edr_offset) / source_edr_scale
    if not math.isclose(edr_raw, round(edr_raw), rel_tol=0, abs_tol=1e-9):
        return "ON HOLD: DRBFM EDR scaling does not encode this DBC physical value as an integer."
    if not math.isclose(source_edr_scale, float(metadata["factor"]), rel_tol=0, abs_tol=1e-12) or not math.isclose(
        source_edr_offset,
        float(metadata["offset"]),
        rel_tol=0,
        abs_tol=1e-12,
    ):
        return f"EDR converted raw candidate={int(round(edr_raw))}; byte packing remains ON HOLD."
    return f"Raw-compatible candidate={_raw_hex(int(round(edr_raw)), int(metadata['bit_length']))}; byte packing remains ON HOLD."


def element_applicability(routes: dict[str, dict[str, Any]]) -> str | None:
    u171_present = routes["U171"]["state"].startswith("Applicable") or routes["U171"]["state"] == "DBC-only CAN route"
    m314_present = routes["M314"]["state"].startswith("Applicable") or routes["M314"]["state"] == "DBC-only CAN route"
    if u171_present and m314_present:
        return "Both"
    if u171_present:
        return "ICE"
    if m314_present:
        return "EV"
    return None


@dataclass(frozen=True, slots=True)
class PlannedCase:
    """A common authoring case plus the target-specific instances it represents."""

    name: str
    applicability: str
    category: str
    status: str
    priority: str
    element: DrbfmElement
    variant_keys: tuple[str, ...]
    description: str
    pre_action: str
    post_action: str
    steps: tuple[AuthoringStep, ...]
    verification_method: str
    test_technique: str
    sequence: int = 0


def _route_is_present(route: dict[str, Any]) -> bool:
    return route["state"].startswith("Applicable") or route["state"] == "DBC-only CAN route"


def _route_summary(route: dict[str, Any]) -> str:
    metadata = route["dbc"]
    if metadata is None:
        return route["state"]
    summary = (
        f"{metadata['bus']} {metadata['message']}/{metadata['signal']} "
        f"({metadata['can_id']}, {metadata['cycle_time_ms']} ms, {metadata['bit_length']} bit, "
        f"{metadata['byte_order']}, signed={metadata['signed']}, factor={metadata['factor']}, "
        f"offset={metadata['offset']}, range={metadata['minimum']}..{metadata['maximum']} {metadata['unit']})"
    )
    alternatives = route["alternative_dbc_routes"]
    if alternatives:
        buses = ", ".join(f"{item['bus']}:{item['message']}/{item['signal']}" for item in alternatives)
        summary += f"; equivalent ECU-generated multi-bus routes: {buses}"
    return summary


def _fault_summary(route: dict[str, Any]) -> str:
    entries = []
    for fault_mode, codes in route["faults"].items():
        if codes:
            entries.append(f"{fault_mode}={'; '.join(codes)}")
    return ", ".join(entries) if entries else "No configuration-backed CAN fault mapping"


def _fault_eligibility_summary(route: dict[str, Any]) -> str:
    eligibility = route.get("fault_eligibility", {})
    if not eligibility:
        return "No fault eligibility was assessed."
    return "; ".join(f"{mode}: {reason}" for mode, reason in sorted(eligibility.items()))


def eligible_onfail_modes(route: dict[str, Any]) -> tuple[tuple[str, OnFailDecision], ...]:
    """Return fault families that are both structurally eligible and policy-applicable."""
    modes: list[tuple[str, OnFailDecision]] = []
    for fault_mode, codes in route["faults"].items():
        decision = onfail_decision(route, fault_mode)
        if codes and decision.applicable:
            modes.append((fault_mode, decision))
    record = route.get("onfail_policy")
    if isinstance(record, dict):
        for fault_mode in POLICY_ONLY_FAULT_MODES:
            decision = onfail_decision(route, fault_mode)
            if decision.applicable:
                modes.append((fault_mode, decision))
    return tuple(modes)


def onfail_scopes(element: DrbfmElement, fault_mode: str, decision: OnFailDecision) -> tuple[str, ...]:
    """SNR/VC and explicit special cases are full-only; interval faults otherwise retain full/pre/post coverage."""
    if fault_mode in POLICY_ONLY_FAULT_MODES or decision.special.get("full_only"):
        return ("full",)
    if recording_model(element) != "interval":
        return ("full",)
    if _window_timestamps(element, "pre") and _window_timestamps(element, "post"):
        return ("full", "pre", "post")
    return ("full",)


def _onfail_encoding_assessment(decision: OnFailDecision) -> str:
    if decision.reaction == "last_valid":
        behavior = "expected recorded value follows the policy last-valid behavior"
    elif decision.reaction == "default":
        behavior = f"fault-active samples use the policy default {decision.value or 'ON HOLD'}"
    elif decision.reaction == "consume":
        behavior = "expected recorded value consumes the live input array"
    else:
        behavior = "policy reaction is unresolved"
    return f"ON HOLD: {behavior}; source={decision.source}; EDR byte packing remains unresolved."


def _field_summary(element: DrbfmElement) -> str:
    byte_length = _field_byte_length(element)
    bytes_text = str(element.values.get("Byte position") or "Not specified")
    bits_text = str(element.values.get("Bit position") or "Not specified")
    length_text = f"{byte_length} byte(s)" if byte_length is not None else str(element.values.get("length in bytes") or "Not specified")
    return f"length={length_text}; byte position={bytes_text}; bit position={bits_text}"


def _case_slug(value: str) -> str:
    slug = re.sub(r"[^A-Z0-9]+", "_", value.upper()).strip("_")
    return slug[:64] or "UNNAMED"


def _record_scope_text() -> str:
    return "DID 0x0455 / Record 1 and DID 0x045B / Record 2 (user-directed common-row assumption; Record 2 byte layout remains unresolved)"


def build_route_matrix(elements: Iterable[DrbfmElement], contexts: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Build one fully provenance-bearing route record per DRBFM analysis row."""
    rows = []
    for element in elements:
        routes = {variant: resolve_element_route(element, context) for variant, context in contexts.items()}
        applicability = element_applicability(routes)
        reserved = element.normalized_name.startswith("reserved")
        if reserved:
            classification = "Reserved"
            coverage = "Static reserved-zero verification for both records."
        elif applicability is None:
            classification = "Unmapped / non-CAN evidence unavailable"
            coverage = "No CAN functional case until a project DBC/configuration route is supplied."
        elif all(route["source_kind"] == "ECU-generated CAN" for route in routes.values() if _route_is_present(route)):
            classification = "ECU-generated CAN"
            coverage = "Static review case only; no external CAN stimulus is assumed."
        else:
            classification = "External CAN"
            coverage = "Nominal common-record case plus only configuration-backed on-fail and input-exception cases."
        byte_length = _field_byte_length(element)
        default_encoding = "Not specified"
        if reserved and byte_length is not None:
            default_encoding = "0x" + "00" * byte_length
        rows.append(
            {
                "element": element,
                "source_row": element.source_row,
                "logical_id": element.logical_id or "",
                "parameter_name": element.parameter_name,
                "record_scope": _record_scope_text(),
                "field": _field_summary(element),
                "sampling_interval": element.values.get("Sampling Interval") or "Not specified",
                "sample_rate_hz": element.values.get("Data Samples per second") or "Not specified",
                "sample_count": len(sampling_schedule(element)) or "Not specified",
                "drbfm_can_resolution": element.values.get("Resolution_CAN") or "Not specified",
                "drbfm_can_offset": element.values.get("Offset_CAN") or "Not specified",
                "drbfm_edr_resolution": element.values.get("Resolution_EDR") or "Not specified",
                "drbfm_edr_offset": element.values.get("Offset_EDR") or "Not specified",
                "value_description": element.values.get("Value description") or "Not specified",
                "not_captured_value": element.values.get("Not captured value") or "Not specified",
                "comments": element.values.get("Comments") or "",
                "applicability": applicability or "Not classified",
                "classification": classification,
                "u171_state": routes["U171"]["state"],
                "u171_route": _route_summary(routes["U171"]),
                "u171_enablement": routes["U171"]["enablement_evidence"],
                "u171_faults": _fault_summary(routes["U171"]),
                "u171_fault_eligibility": _fault_eligibility_summary(routes["U171"]),
                "m314_state": routes["M314"]["state"],
                "m314_route": _route_summary(routes["M314"]),
                "m314_enablement": routes["M314"]["enablement_evidence"],
                "m314_faults": _fault_summary(routes["M314"]),
                "m314_fault_eligibility": _fault_eligibility_summary(routes["M314"]),
                "default_or_reserved_encoding": default_encoding,
                "coverage_decision": coverage,
                "routes": routes,
            }
        )
    return rows


def build_vector_rows(matrix: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Create JSON-backed nominal and on-fail vectors with input and expected-recorded arrays."""
    rows = []
    for matrix_row in matrix:
        element = matrix_row["element"]
        for variant in ("U171", "M314"):
            route = matrix_row["routes"][variant]
            metadata = route["dbc"]
            if not _route_is_present(route) or metadata is None:
                continue
            nominal_points = nominal_recording_points(element, metadata, variant)
            for sample_index, point in enumerate(nominal_points):
                rows.append(
                    {
                        "vector_key": f"{element.source_row}-{variant}-nominal",
                        "source_row": element.source_row,
                        "parameter_name": element.parameter_name,
                        "variant": variant,
                        "record_scope": _record_scope_text(),
                        "recording_model": recording_model(element),
                        "sample_index": sample_index,
                        "recording_time_s": point["recording_time_s"],
                        "simulation_window_start_s": point["simulation_window_start_s"],
                        "simulation_window_end_s": point["simulation_window_end_s"],
                        "timestamp_s": point["recording_time_s"],
                        "scenario": "nominal valid input",
                        "fault_state": point["fault_state"],
                        "input_raw_hex": point["input_raw_hex"],
                        "input_raw_integer": point["input_raw_integer"],
                        "input_physical_value": point["input_physical_value"],
                        "expected_recorded_raw_hex": point["expected_recorded_raw_hex"],
                        "expected_recorded_raw_integer": point["expected_recorded_raw_integer"],
                        "expected_recorded_physical_value": point["expected_recorded_physical_value"],
                        "physical_range_status": point["physical_range_status"],
                        "nominal_value_status": point["nominal_value_status"],
                        "can_raw_hex": point["input_raw_hex"],
                        "can_raw_integer": point["input_raw_integer"],
                        "factor": metadata["factor"],
                        "offset": metadata["offset"],
                        "physical_value": point["input_physical_value"],
                        "unit": metadata["unit"] or "",
                        "expected_edr_encoding": edr_encoding_assessment(element, metadata, int(point["expected_recorded_raw_integer"])),
                    }
                )
            for fault_mode, decision in eligible_onfail_modes(route):
                for fault_scope in onfail_scopes(element, fault_mode, decision):
                    for sample_index, point in enumerate(
                        onfail_recording_points(element, metadata, variant, fault_scope, decision=decision)
                    ):
                        rows.append(
                            {
                                "vector_key": f"{element.source_row}-{variant}-{fault_mode}-{fault_scope}",
                                "source_row": element.source_row,
                                "parameter_name": element.parameter_name,
                                "variant": variant,
                                "record_scope": _record_scope_text(),
                                "recording_model": recording_model(element),
                                "sample_index": sample_index,
                                "recording_time_s": point["recording_time_s"],
                                "simulation_window_start_s": point["simulation_window_start_s"],
                                "simulation_window_end_s": point["simulation_window_end_s"],
                                "timestamp_s": point["recording_time_s"],
                                "scenario": f"{fault_mode} {fault_scope}",
                                "fault_state": point["fault_state"],
                                "input_raw_hex": point["input_raw_hex"],
                                "input_raw_integer": point["input_raw_integer"],
                                "input_physical_value": point["input_physical_value"],
                                "expected_recorded_raw_hex": point["expected_recorded_raw_hex"],
                                "expected_recorded_raw_integer": point["expected_recorded_raw_integer"],
                                "expected_recorded_physical_value": point["expected_recorded_physical_value"],
                                "physical_range_status": point["physical_range_status"],
                                "nominal_value_status": point["nominal_value_status"],
                                "can_raw_hex": point["input_raw_hex"],
                                "can_raw_integer": point["input_raw_integer"],
                                "factor": metadata["factor"],
                                "offset": metadata["offset"],
                                "physical_value": point["input_physical_value"],
                                "unit": metadata["unit"] or "",
                                "expected_edr_encoding": _onfail_encoding_assessment(decision),
                            }
                        )
            for vector in dbc_exception_vectors(metadata):
                exception_decision = onfail_exception_decision(route, vector["scenario"])
                expected_values = _exception_policy_values(vector, metadata, exception_decision)
                rows.append(
                    {
                        "vector_key": f"{element.source_row}-{variant}-exception",
                        "source_row": element.source_row,
                        "parameter_name": element.parameter_name,
                        "variant": variant,
                        "record_scope": _record_scope_text(),
                        "recording_model": recording_model(element),
                        "sample_index": "Not applicable",
                        "recording_time_s": "Not applicable",
                        "simulation_window_start_s": "Not applicable",
                        "simulation_window_end_s": "Not applicable",
                        "timestamp_s": "Not applicable",
                        "scenario": vector["scenario"],
                        "fault_state": "exception input",
                        "input_raw_hex": vector["raw_hex"],
                        "input_raw_integer": vector["raw_integer"],
                        "input_physical_value": vector["physical_value"],
                        "expected_recorded_raw_hex": expected_values["expected_recorded_raw_hex"],
                        "expected_recorded_raw_integer": expected_values["expected_recorded_raw_integer"],
                        "expected_recorded_physical_value": expected_values["expected_recorded_physical_value"],
                        "physical_range_status": expected_values["physical_range_status"],
                        "nominal_value_status": expected_values["nominal_value_status"],
                        "can_raw_hex": vector["raw_hex"],
                        "can_raw_integer": vector["raw_integer"],
                        "factor": metadata["factor"],
                        "offset": metadata["offset"],
                        "physical_value": vector["physical_value"],
                        "unit": metadata["unit"] or "",
                        "expected_edr_encoding": _onfail_encoding_assessment(exception_decision),
                    }
                )
    return rows


def _route_conversion_ready(element: DrbfmElement, route: dict[str, Any]) -> bool:
    metadata = route["dbc"]
    if metadata is None:
        return False
    vectors = dbc_valid_vectors(metadata)
    if not vectors:
        return False
    return not edr_encoding_assessment(element, metadata, vectors[0]["raw_integer"]).startswith("ON HOLD")


def _nominal_case_status(element: DrbfmElement, routes: dict[str, dict[str, Any]]) -> str:
    present_routes = [route for route in routes.values() if _route_is_present(route)]
    return "IN REVIEW" if present_routes and all(_route_conversion_ready(element, route) for route in present_routes) else "ON HOLD"


def _format_number(value: Any) -> str:
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return f"{value:.6g}"
    return str(value)


def _format_time(timestamp: float) -> str:
    if math.isclose(timestamp, 0.0, abs_tol=1e-12):
        return "0.00"
    return f"{timestamp:+.2f}"


def _window_timestamps(element: DrbfmElement, timing_scope: str) -> tuple[float, ...]:
    schedule = sampling_schedule(element)
    if timing_scope == "pre":
        return tuple(timestamp for timestamp in schedule if timestamp < 0)
    if timing_scope == "post":
        return tuple(timestamp for timestamp in schedule if timestamp >= 0)
    return schedule


def _window_label(element: DrbfmElement, timing_scope: str) -> str:
    timestamps = _window_timestamps(element, timing_scope)
    if timing_scope == "pre":
        start = _format_time(timestamps[0]) if timestamps else "Not specified"
        return f"only in pre crash ({start}s to T0)"
    if timing_scope == "post":
        end = _format_time(timestamps[-1]) if timestamps else "Not specified"
        return f"only in post crash (T0 to {end}s)"
    if timestamps:
        return f"in full interval ({_format_time(timestamps[0])}s to {_format_time(timestamps[-1])}s)"
    return "at the source-defined recording point"


def _authoring_vector_points(
    element: DrbfmElement,
    route: dict[str, Any],
    timing_scope: str,
    *,
    fault_mode: str | None = None,
    fault_decision: OnFailDecision | None = None,
) -> list[dict[str, Any]]:
    metadata = route["dbc"]
    if metadata is None:
        return []
    if fault_mode is not None:
        decision = fault_decision or onfail_decision(route, fault_mode)
        return onfail_recording_points(element, metadata, route["variant"], timing_scope, decision=decision)
    return nominal_recording_points(element, metadata, route["variant"])


def _authoring_vector_signature(element: DrbfmElement, route: dict[str, Any]) -> tuple[Any, ...] | None:
    metadata = route["dbc"]
    if metadata is None:
        return None
    points = _authoring_vector_points(element, route, "full")
    return (
        metadata["bit_length"],
        metadata["signed"],
        metadata["factor"],
        metadata["offset"],
        metadata["unit"],
        tuple((point["expected_recorded_raw_integer"], point["expected_recorded_physical_value"]) for point in points),
    )


def _authoring_target_groups(element: DrbfmElement, routes: dict[str, dict[str, Any]]) -> list[tuple[str, tuple[str, ...]]]:
    present = tuple(variant for variant in ("U171", "M314") if _route_is_present(routes[variant]))
    if len(present) == 2:
        u171_signature = _authoring_vector_signature(element, routes["U171"])
        m314_signature = _authoring_vector_signature(element, routes["M314"])
        if u171_signature is not None and u171_signature == m314_signature:
            return [("Both", present)]
    return [(VARIANT_SOURCES[variant]["vehicle_class"], (variant,)) for variant in present]


def _target_label(variants: tuple[str, ...]) -> str:
    return " / ".join(variants)


REFERENCE_CASE_NAME_PATTERN = re.compile(r"^SUBS_EDR_Element_ID_(.+)_TestCase_(\d+)_(\d+)$")
REFERENCE_TOKEN_OVERRIDES = {
    "brakepedalvalue": "BRK_SWITCH",
    "brkpedal": "BRK_SWITCH",
    "enginespeed": "MOTOR_SPD",
    "steeringabsoluteangle": "ABSOLUTE_ANGLE",
    "vehicle_speed": "VehSpdLgt",
    "vehiclespeedesc12": "VehSpdLgt",
    "odometer": "Odometer",
}


@lru_cache(maxsize=1)
def _reference_naming_map() -> dict[str, tuple[str, int]]:
    """Extract the signal token and testcase group number from the supplied reference workbook."""
    workbook = openpyxl.load_workbook(REFERENCE_AUTHORING_WORKBOOK, read_only=True, data_only=False)
    try:
        worksheet = workbook.active
        if worksheet is None:
            raise RuntimeError("Reference workbook has no active worksheet.")
        headers = [cell.value for cell in worksheet[1]]
        name_column = headers.index("Name") + 1
        mapping: dict[str, tuple[str, int]] = {}
        for (value,) in worksheet.iter_rows(min_row=2, min_col=name_column, max_col=name_column, values_only=True):
            match = REFERENCE_CASE_NAME_PATTERN.fullmatch(str(value or ""))
            if match is None:
                continue
            token = match.group(1)
            group = int(match.group(2))
            mapping.setdefault(normalize_name(token), (token, group))
        return mapping
    finally:
        workbook.close()


def _reference_case_identity(element: DrbfmElement, route: dict[str, Any]) -> tuple[str, int]:
    """Resolve a CANC-style token/group pair, preferring the reference workbook over inferred names."""
    naming_map = _reference_naming_map()
    candidates = [
        str(route.get("config_edr_parameter") or ""),
        str(route.get("config_symbol") or "").removeprefix("CAN_"),
        str(route.get("dbc", {}).get("signal") if route.get("dbc") else ""),
        element.parameter_name,
    ]
    for candidate in candidates:
        normalized = normalize_name(candidate)
        token_override = REFERENCE_TOKEN_OVERRIDES.get(normalized)
        if token_override is not None:
            normalized = normalize_name(token_override)
        if normalized in naming_map:
            return naming_map[normalized]
    fallback_token = _case_slug(candidates[0] or element.parameter_name)
    try:
        fallback_group = int(str(element.logical_id or element.source_row))
    except ValueError:
        fallback_group = element.source_row
    return fallback_token, fallback_group


def _case_signal_token(element: DrbfmElement, route: dict[str, Any]) -> str:
    return _reference_case_identity(element, route)[0]


def _reference_case_name(
    element: DrbfmElement,
    route: dict[str, Any],
    applicability: str,
    sequence: int,
    *,
    identity: tuple[str, int] | None = None,
) -> str:
    token, group = identity or _reference_case_identity(element, route)
    return f"SUBS_EDR_Element_ID_{token}_TestCase_{group}_{sequence}"


def _unique_reference_case_identity(
    element: DrbfmElement,
    route: dict[str, Any],
    assigned_identities: dict[tuple[str, int], int],
) -> tuple[str, int]:
    """Retain legacy group IDs where possible while preventing cross-element testcase collisions."""
    token, group = _reference_case_identity(element, route)
    owner = assigned_identities.get((token, group))
    if owner in {None, element.source_row}:
        assigned_identities[(token, group)] = element.source_row
        return token, group
    try:
        group = int(str(element.logical_id or element.source_row))
    except ValueError:
        group = element.source_row
    while (token, group) in assigned_identities and assigned_identities[(token, group)] != element.source_row:
        group += 10000
    assigned_identities[(token, group)] = element.source_row
    return token, group


def _active_dtc_codes(route: dict[str, Any], fault_mode: str) -> str:
    formatted = []
    for code in route["faults"].get(fault_mode, ()):
        bytes_text = " ".join(part.replace("0x", "").upper() for part in str(code).split())
        formatted.append(f"{bytes_text} 0B")
    return "; ".join(formatted) or "No configured DTC code"


def _fault_dtc_label(fault_mode: str) -> str:
    return {
        "node_absent": "Node Absent DTC",
        "message_timeout": "Message Timeout DTC",
        "message_content": "Message Content Failure DTC",
        "signal_content": "Signal Content Failure DTC",
        "signal_never_received": "Signal Never Received DTC",
        "variant_code_error": "Variant Code Error DTC",
    }.get(fault_mode, _fault_mode_label(fault_mode) + " DTC")


def _dtc_qualification_expectation(route: dict[str, Any], fault_mode: str, decision: OnFailDecision) -> str:
    fault_codes = _active_dtc_codes(route, fault_mode)
    if fault_codes == "No configured DTC code":
        return f"DTC Qualifies: no configuration-backed CAN DTC is expected for {_fault_mode_label(fault_mode)}."
    timing = ""
    if decision.special.get("qualification_seconds"):
        timing = f" Maintain the fault for {decision.special['qualification_seconds']} s before reading the DTC."
    return f"DTC Qualifies: {_fault_dtc_label(fault_mode)}: {fault_codes}.{timing}"


def _crash_dtc_expectation(
    route: dict[str, Any],
    fault_mode: str | None = None,
    decision: OnFailDecision | None = None,
) -> str:
    """Render project-normative crash-lock DTCs before any applicable CAN fault DTC."""
    if fault_mode is None:
        return FRONT_CRASH_DTC_EXPECTATION
    resolved_decision = decision or onfail_decision(route, fault_mode)
    return f"{FRONT_CRASH_DTC_EXPECTATION}\n\n{_dtc_qualification_expectation(route, fault_mode, resolved_decision)}"


def _fault_action(fault_mode: str, timing_scope: str, decision: OnFailDecision | None = None) -> str:
    scope = ""
    if timing_scope == "pre":
        scope = " during Pre crash"
    elif timing_scope == "post":
        scope = " during Post crash"
    actions = {
        "node_absent": "Simulate Node Absent Fault by disabling associated Node",
        "message_timeout": "Simulate Message Time OUT Fault by disabling associated Message",
        "message_content": "Simulate Message Content Failure Fault using configured CRC/Alive Counter",
        "signal_content": "Simulate Signal Content Failure Fault using DBC-defined invalid signal value",
        "signal_never_received": "Simulate Signal Never Received condition using the approved variant-code procedure",
        "variant_code_error": "Simulate Variant Code Error using the approved variant-code procedure",
    }
    action = actions.get(fault_mode, f"Simulate {_fault_mode_label(fault_mode)} fault")
    if decision is not None and decision.special.get("message_timeout_values"):
        values = "/".join(str(value) for value in decision.special["message_timeout_values"])
        action += f" using source-qualified raw values {values}"
    return action + scope


def _format_simulation_window(start_s: float | None, end_s: float) -> str:
    if start_s is None:
        return f"recording point {_format_time(end_s)} s"
    if math.isclose(start_s, -0.5, abs_tol=1e-12) and math.isclose(end_s, 0.0, abs_tol=1e-12):
        return "T0 - 500 ms to T0"
    return f"{_format_time(start_s)} s to {_format_time(end_s)} s"


def _reference_pre_action(
    element: DrbfmElement,
    routes: dict[str, dict[str, Any]],
    variants: tuple[str, ...],
    applicability: str,
    timing_scope: str,
    *,
    fault_mode: str | None = None,
    fault_decision: OnFailDecision | None = None,
    exception_category: str | None = None,
) -> str:
    route = routes[variants[0]]
    metadata = route["dbc"]
    token = _case_signal_token(element, route)
    if metadata is None:
        return (
            "1. Establish the approved EDR feature configuration and confirm the selected variant is fault free.\n\n"
            f"2. No verified DBC route is available for {element.parameter_name}; retain this case ON HOLD until the source mapping is supplied."
        )
    target_mappings = "; ".join(f"{variant}: {_route_summary(routes[variant])}" for variant in variants)
    if exception_category is not None:
        exception_points = [point for point in dbc_exception_vectors(metadata) if point["scenario"] == exception_category]
        exception_decision = onfail_exception_decision(route, exception_category)
        expected_points = [_exception_policy_values(point, metadata, exception_decision) for point in exception_points]
        raw_hex = ", ".join(point["raw_hex"] for point in exception_points)
        raw_values = ", ".join(_format_number(point["raw_integer"]) for point in exception_points)
        physical_values = ", ".join(_format_number(point["physical_value"]) for point in exception_points)
        expected_raw_hex = ", ".join(str(point["expected_recorded_raw_hex"]) for point in expected_points)
        expected_physical_values = ", ".join(_format_number(point["expected_recorded_physical_value"]) for point in expected_points)
        range_statuses = sorted(
            {
                _physical_range_status(float(point["physical_value"]), metadata)
                for point in exception_points
            }
        )
        return "\n".join(
            (
                "1. Establish the approved EDR feature configuration and confirm the selected variant is fault free.",
                "",
                f"2. Simulate {token} CAN signal with DBC-defined {exception_category} values for {applicability} ({_target_label(variants)}):",
                f"Input raw CAN hex: [{raw_hex}]",
                f"Input raw CAN decimal: [{raw_values}]",
                f"Input physical {metadata['unit'] or 'value'}: [{physical_values}]",
                f"Expected recorded raw CAN hex: [{expected_raw_hex}]",
                f"Expected recorded physical {metadata['unit'] or 'value'}: [{expected_physical_values}]",
                f"Physical range review: {', '.join(range_statuses)}; DBC valid range={metadata['minimum']}..{metadata['maximum']} {metadata['unit'] or ''}.",
                f"Conversion: physical = raw * {metadata['factor']} + {metadata['offset']}.",
                f"Target mappings: {target_mappings}",
                f"On-fail policy: {exception_decision.reaction} ({exception_decision.source}).",
            )
        )
    decision = fault_decision or (onfail_decision(route, fault_mode) if fault_mode is not None else None)
    points = _authoring_vector_points(element, route, timing_scope, fault_mode=fault_mode, fault_decision=decision)
    input_raw_hex = ", ".join(str(point["input_raw_hex"]) for point in points)
    input_raw_values = ", ".join(_format_number(point["input_raw_integer"]) for point in points)
    input_physical_values = ", ".join(_format_number(point["input_physical_value"]) for point in points)
    expected_raw_hex = ", ".join(str(point["expected_recorded_raw_hex"]) for point in points)
    expected_raw_values = ", ".join(_format_number(point["expected_recorded_raw_integer"]) for point in points)
    expected_physical_values = ", ".join(_format_number(point["expected_recorded_physical_value"]) for point in points)
    recording_times = ", ".join(_format_time(float(point["recording_time_s"])) for point in points)
    drive_windows = ", ".join(
        _format_simulation_window(point["simulation_window_start_s"], float(point["simulation_window_end_s"]))
        for point in points
    )
    fault_states = ", ".join(str(point["fault_state"]) for point in points)
    range_statuses = sorted({str(point["physical_range_status"]) for point in points})
    nominal_statuses = sorted({str(point["nominal_value_status"]) for point in points})
    condition = "valid value range"
    if fault_mode is not None:
        condition = f"{_fault_mode_label(fault_mode)} {_window_label(element, timing_scope)}"
    policy_text = ()
    if decision is not None:
        source_row = f" source row {decision.source_row}" if decision.source_row is not None else ""
        policy_text = (f"On-fail policy: {decision.reaction} ({decision.source}{source_row}).",)
    return "\n".join(
        (
            "1. Establish the approved EDR feature configuration and confirm the selected variant is fault free.",
            "",
            f"2. Simulate {token} CAN signal with {condition} for {applicability} ({_target_label(variants)}):",
            f"Recording model: {recording_model(element)}.",
            f"Recording time [s] ({len(points)} values): [{recording_times}]",
            f"Simulation window: [{drive_windows}]",
            f"Input raw CAN hex: [{input_raw_hex}]",
            f"Input raw CAN decimal: [{input_raw_values}]",
            f"Input physical {metadata['unit'] or 'value'}: [{input_physical_values}]",
            f"Expected recorded raw CAN hex: [{expected_raw_hex}]",
            f"Expected recorded raw CAN decimal: [{expected_raw_values}]",
            f"Expected recorded physical {metadata['unit'] or 'value'}: [{expected_physical_values}]",
            f"Fault/input state: [{fault_states}]",
            f"Physical range review: {', '.join(range_statuses)}; DBC valid range={metadata['minimum']}..{metadata['maximum']} {metadata['unit'] or ''}.",
            f"Nominal value review: {', '.join(nominal_statuses)}.",
            f"Conversion: physical = raw * {metadata['factor']} + {metadata['offset']}.",
            f"Target mappings: {target_mappings}",
            f"Source: {DRBFM_ANALYSIS_SHEET}!{element.source_row}.",
            *policy_text,
        )
    )


def _onfail_recorded_expectation(
    element: DrbfmElement,
    route: dict[str, Any],
    timing_scope: str,
    *,
    fault_mode: str,
    fault_decision: OnFailDecision | None = None,
) -> str:
    """Summarize the policy-controlled expected array without inventing EDR byte packing."""
    metadata = route["dbc"]
    if metadata is None:
        return "ON HOLD: no DBC route is available for the expected-recorded array."
    decision = fault_decision or onfail_decision(route, fault_mode)
    points = onfail_recording_points(element, metadata, route["variant"], timing_scope, decision=decision)
    expected_raw = ", ".join(str(point["expected_recorded_raw_hex"]) for point in points)
    expected_physical = ", ".join(_format_number(point["expected_recorded_physical_value"]) for point in points)
    if decision.reaction == "last_valid" and timing_scope == "full":
        behavior = "The primed last valid value is expected across the full recording interval."
    elif decision.reaction == "last_valid" and timing_scope == "pre":
        behavior = "Negative-time samples retain the primed last valid value; T0 and post-crash samples use the recovered valid array."
    elif decision.reaction == "last_valid":
        behavior = "Pre-crash samples use the valid array; the T0 value is retained as the post-crash last valid value."
    elif decision.reaction == "default":
        behavior = f"Fault-active samples use source default {decision.value or 'ON HOLD'}; non-fault samples retain the valid array."
    elif decision.reaction == "consume":
        behavior = "The signal remains live, so each recording point consumes the corresponding valid input value."
    else:
        behavior = "The source reaction is unresolved, so exact expected recorded bytes remain ON HOLD."
    return (
        f"ON HOLD: {behavior} Expected recorded raw CAN hex: [{expected_raw}]. "
        f"Expected recorded physical {metadata['unit'] or 'value'}: [{expected_physical}]. "
        f"Policy source: {decision.source}; EDR byte packing remains unresolved."
    )


def _reference_steps(
    element: DrbfmElement,
    route: dict[str, Any],
    timing_scope: str,
    status: str,
    *,
    fault_mode: str | None = None,
    fault_decision: OnFailDecision | None = None,
    exception_category: str | None = None,
) -> tuple[AuthoringStep, ...]:
    token = _case_signal_token(element, route)
    steps = [AuthoringStep("Set bench to normal condition", "System is in normal state, no faults present.")]
    decision = fault_decision or (onfail_decision(route, fault_mode) if fault_mode is not None else None)
    if fault_mode is not None:
        steps.append(
            AuthoringStep(
                _fault_action(fault_mode, timing_scope, decision),
                "Fault remains active through the selected recording interval. Read DTC only after the recording interval and any source-defined qualification time.",
            )
        )
    elif exception_category is not None:
        exception_decision = onfail_exception_decision(route, exception_category)
        if exception_decision.reaction == "consume":
            exception_expectation = "The specified raw values are sent through the exact carrying CAN message and are consumed as the expected EDR values."
        elif exception_decision.reaction == "default":
            exception_expectation = f"The specified raw values are sent through the exact carrying CAN message; fault-active EDR values use source default {exception_decision.value or 'ON HOLD'}."
        else:
            exception_expectation = "The specified raw values are sent through the exact carrying CAN message. ON HOLD: the exact EDR response remains unresolved."
        steps.append(
            AuthoringStep(
                f"Simulate the DBC-defined {exception_category} raw values specified in step 2 of Pre Action.",
                exception_expectation,
            )
        )
    steps.append(
        AuthoringStep(
            "Simulate Valid Values as specified in step 2 of Pre Action",
            "Values simulated on CAN as mentioned in step 2 of Pre-Action.",
        )
    )
    crash_step_number = len(steps) + 1
    steps.append(
        AuthoringStep(
            "Simulate Front Crash and Read DTC",
            _crash_dtc_expectation(route, fault_mode, decision),
        )
    )
    if fault_mode is None and exception_category is None:
        record_expectation = (
            f"EDR records valid value as mentioned in step 2 of Pre Action for {token}."
            if status == "IN REVIEW"
            else f"ON HOLD: EDR records valid value as mentioned in step 2 of Pre Action for {token}; record byte packing or conversion remains unresolved."
        )
    elif fault_mode is not None:
        record_expectation = _onfail_recorded_expectation(
            element,
            route,
            timing_scope,
            fault_mode=fault_mode,
            fault_decision=decision,
        )
    else:
        record_expectation = f"ON HOLD: EDR records value as per exception scenario for {token}; the EDR response for this DBC exception is not source-defined."
    steps.extend(
        (
            AuthoringStep(f"Read EDR and observe bytes for {token} EDR Parameter", record_expectation),
            AuthoringStep(
                f"Repeat steps 2 till test step {crash_step_number} and read EDR2 and observe bytes for the {token} EDR Parameter.",
                record_expectation,
            ),
            AuthoringStep("Clear NVM and Clear DTC", "All DTCs and NVM data are cleared; system returns to normal state, only where permitted by the approved project procedure."),
        )
    )
    return tuple(steps)


def _case_description(
    element: DrbfmElement,
    applicability: str,
    category: str,
    routes: dict[str, dict[str, Any]],
    extra: str,
) -> str:
    return "\n".join(
        (
            f"EDR Element: {element.parameter_name}",
            f"DRBFM provenance: {DRBFM_ANALYSIS_SHEET}!{element.source_row}; logical ID={element.logical_id or 'not specified'}",
            f"DID / Record Scope: {_record_scope_text()}",
            f"Applicability: {applicability}",
            f"Case Category: {category}",
            f"EDR Field: {_field_summary(element)}",
            f"Recording Interval / Rate: {element.values.get('Sampling Interval') or 'Not specified'} / {element.values.get('Data Samples per second') or 'Not specified'}",
            f"U171 ICE: {_route_summary(routes['U171'])}",
            f"M314 EV: {_route_summary(routes['M314'])}",
            "Traceability: deferred by user request; no Codebeamer requirement ID is serialized.",
            extra,
        )
    )


def _case_post_action() -> str:
    """The reference workbook uses its explicit cleanup step instead of a post-action cell."""
    return ""


def _fault_mode_label(mode: str) -> str:
    return mode.replace("_", " ").title()


def _present_variant_keys(routes: dict[str, dict[str, Any]]) -> tuple[str, ...]:
    return tuple(variant for variant in ("U171", "M314") if _route_is_present(routes[variant]))


def build_case_plans(matrix: Iterable[dict[str, Any]]) -> list[PlannedCase]:
    """Create reference-style nominal/full/pre/post case families from source evidence."""
    plans: list[PlannedCase] = []
    assigned_identities: dict[tuple[str, int], int] = {}
    matrix_rows = list(matrix)
    for matrix_row in matrix_rows:
        element = matrix_row["element"]
        routes = matrix_row["routes"]
        if matrix_row["classification"] == "Reserved":
            continue

        if matrix_row["classification"] not in {"External CAN", "ECU-generated CAN"}:
            continue
        first_present_route = next((routes[variant] for variant in ("U171", "M314") if _route_is_present(routes[variant])), None)
        if first_present_route is None:
            continue
        identity = _unique_reference_case_identity(element, first_present_route, assigned_identities)
        next_sequence = 1
        for applicability, variants in _authoring_target_groups(element, routes):
            route = routes[variants[0]]
            metadata = route["dbc"]
            if metadata is None:
                continue
            sequence = next_sequence
            nominal_status = "IN REVIEW" if all(_route_conversion_ready(element, routes[variant]) for variant in variants) else "ON HOLD"
            plans.append(
                PlannedCase(
                    name=_reference_case_name(element, route, applicability, sequence, identity=identity),
                    applicability=applicability,
                    category="Nominal full interval" if len(_window_timestamps(element, "full")) > 1 else "Nominal static recording",
                    status=nominal_status,
                    priority="High",
                    element=element,
                    variant_keys=variants,
                    description=f"Verify nominal {element.parameter_name} recording in both EDR records for {applicability}.",
                    pre_action=_reference_pre_action(element, routes, variants, applicability, "full"),
                    post_action=_case_post_action(),
                    steps=_reference_steps(element, route, "full", nominal_status),
                    verification_method="Requirements-based test",
                    test_technique="Boundary Value Analysis",
                    sequence=sequence,
                )
            )
            sequence += 1

            for fault_variant in variants:
                fault_route = routes[fault_variant]
                if fault_route["source_kind"] != "External CAN":
                    continue
                fault_applicability = VARIANT_SOURCES[fault_variant]["vehicle_class"]
                fault_sequence = sequence
                for fault_mode, decision in eligible_onfail_modes(fault_route):
                    for timing_scope in onfail_scopes(element, fault_mode, decision):
                        plans.append(
                            PlannedCase(
                                name=_reference_case_name(element, fault_route, fault_applicability, fault_sequence, identity=identity),
                                applicability=fault_applicability,
                                category=f"{_fault_mode_label(fault_mode)} {_window_label(element, timing_scope)}",
                                status="ON HOLD",
                                priority="Highest",
                                element=element,
                                variant_keys=(fault_variant,),
                                description=(
                                    f"Verify {element.parameter_name} recording when {_fault_mode_label(fault_mode)} is applied "
                                    f"{_window_label(element, timing_scope)} for {fault_applicability} ({fault_variant})."
                                ),
                                pre_action=_reference_pre_action(
                                    element,
                                    routes,
                                    (fault_variant,),
                                    fault_applicability,
                                    timing_scope,
                                    fault_mode=fault_mode,
                                    fault_decision=decision,
                                ),
                                post_action=_case_post_action(),
                                steps=_reference_steps(
                                    element,
                                    fault_route,
                                    timing_scope,
                                    "ON HOLD",
                                    fault_mode=fault_mode,
                                    fault_decision=decision,
                                ),
                                verification_method="Fault Injection test",
                                test_technique="Fault Injection",
                                sequence=fault_sequence,
                            )
                        )
                        fault_sequence += 1

                exception_categories = sorted({point["scenario"] for point in dbc_exception_vectors(fault_route["dbc"])})
                for exception_category in exception_categories:
                    plans.append(
                        PlannedCase(
                            name=_reference_case_name(element, fault_route, fault_applicability, fault_sequence, identity=identity),
                            applicability=fault_applicability,
                            category=f"DBC {exception_category} input",
                            status="ON HOLD",
                            priority="High",
                            element=element,
                            variant_keys=(fault_variant,),
                            description=f"Verify {element.parameter_name} recording for DBC-defined {exception_category} values in {fault_applicability} ({fault_variant}).",
                            pre_action=_reference_pre_action(
                                element,
                                routes,
                                (fault_variant,),
                                fault_applicability,
                                "full",
                                exception_category=exception_category,
                            ),
                            post_action=_case_post_action(),
                            steps=_reference_steps(
                                element,
                                fault_route,
                                "full",
                                "ON HOLD",
                                exception_category=exception_category,
                            ),
                            verification_method="Fault Injection test",
                            test_technique="Boundary Value Analysis",
                            sequence=fault_sequence,
                        )
                    )
                    fault_sequence += 1
                sequence = max(sequence, fault_sequence)
            next_sequence = max(next_sequence, sequence)

    u171_not_configured = [
        row
        for row in matrix_rows
        if row["classification"] in {"External CAN", "ECU-generated CAN"}
        and row["u171_state"] in {"No verified CAN route", "Configured route absent from selected DBC"}
    ]
    reserved_rows = [row for row in matrix_rows if row["classification"] == "Reserved"]
    if u171_not_configured:
        checklist = "\n".join(
            f"- {row['parameter_name']}: {row['field']} -> 0x{'FF' * (_field_byte_length(row['element']) or 1)}"
            for row in u171_not_configured
        )
        aggregate_element = u171_not_configured[0]["element"]
        plans.append(
            PlannedCase(
                name="SUBS_EDR_Element_ID_U171_NOT_CONFIGURED_TestCase_9000_1",
                applicability="ICE",
                category="Aggregate U171 not-configured fields",
                status="ON HOLD",
                priority="Highest",
                element=aggregate_element,
                variant_keys=("U171",),
                description="Verify all DRBFM CAN allocations not configured for U171 record all ones in both EDR records.",
                pre_action=(
                    "1. Establish the approved U171 EDR feature configuration and confirm the target is fault free.\n\n"
                    "2. Verify the following U171 not-configured CAN allocations across DID 0x0455 and DID 0x045B. "
                    "User-directed expected values are all ones at the resolved field width:\n"
                    f"{checklist}"
                ),
                post_action=_case_post_action(),
                steps=(
                    AuthoringStep("Set bench to normal condition", "System is in normal state, no faults present."),
                    AuthoringStep("Simulate Front Crash and Read DTC", _crash_dtc_expectation({"faults": {}}, None)),
                    AuthoringStep("Read DID 0x0455 and inspect every U171 not-configured CAN allocation in the Pre-Action checklist.", "ON HOLD: each allocation records all ones at the resolved field width; Record 2 packing remains a documented assumption."),
                    AuthoringStep("Read DID 0x045B and inspect every U171 not-configured CAN allocation in the Pre-Action checklist.", "ON HOLD: each allocation records all ones at the resolved field width; Record 2 packing remains a documented assumption."),
                    AuthoringStep("Clear NVM and Clear DTC", "All DTCs and NVM data are cleared; system returns to normal state, only where permitted by the approved project procedure."),
                ),
                verification_method="Requirements-based test",
                test_technique="Equivalence Classes",
                sequence=1,
            )
        )
    if reserved_rows:
        checklist = "\n".join(
            f"- {row['parameter_name']}: {row['field']} -> 0x{'00' * (_field_byte_length(row['element']) or 1)}"
            for row in reserved_rows
        )
        aggregate_element = reserved_rows[0]["element"]
        plans.append(
            PlannedCase(
                name="SUBS_EDR_Element_ID_RESERVED_TestCase_9001_1",
                applicability="Both",
                category="Aggregate reserved-zero fields",
                status="IN REVIEW",
                priority="Highest",
                element=aggregate_element,
                variant_keys=("Common",),
                description="Verify every DRBFM reserved byte and bit records zero in both EDR records.",
                pre_action=(
                    "1. Establish the approved EDR feature configuration and confirm the target is fault free.\n\n"
                    "2. Verify the following reserved allocations across DID 0x0455 and DID 0x045B. Expected values are zero at the stated byte/bit width:\n"
                    f"{checklist}"
                ),
                post_action=_case_post_action(),
                steps=(
                    AuthoringStep("Set bench to normal condition", "System is in normal state, no faults present."),
                    AuthoringStep("Simulate Front Crash and Read DTC", _crash_dtc_expectation({"faults": {}}, None)),
                    AuthoringStep("Read DID 0x0455 and inspect all reserved allocations in the Pre-Action checklist.", "Every listed reserved byte/bit records zero at its stated field width."),
                    AuthoringStep("Read DID 0x045B and inspect all reserved allocations in the Pre-Action checklist.", "Every listed reserved byte/bit records zero at its stated field width; Record 2 packing remains a documented assumption."),
                    AuthoringStep("Clear NVM and Clear DTC", "All DTCs and NVM data are cleared; system returns to normal state, only where permitted by the approved project procedure."),
                ),
                verification_method="Requirements-based test",
                test_technique="Equivalence Classes",
                sequence=1,
            )
        )
    applicability_order = {"Both": 0, "ICE": 1, "EV": 2}
    return sorted(plans, key=lambda plan: (plan.element.source_row, applicability_order[plan.applicability], plan.sequence, plan.name))


def _as_authoring_case(plan: PlannedCase) -> AuthoringCase:
    return AuthoringCase(
        name=plan.name,
        applicability=plan.applicability,
        description=plan.description,
        pre_action=plan.pre_action,
        post_action=plan.post_action,
        steps=plan.steps,
        priority=plan.priority,
        status=plan.status,
        project="Common EDR",
        test_type="Manual",
        verification_method=plan.verification_method,
        test_technique=plan.test_technique,
    )


def _public_matrix_rows(matrix: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    private_keys = {"element", "routes"}
    return [{key: value for key, value in row.items() if key not in private_keys} for row in matrix]


def _onfail_policy_matrix_rows() -> list[dict[str, str]]:
    """Flatten the user policy into one provenance-bearing review row per fault reaction."""
    policy = load_onfail_policy()
    rows = []
    for record in policy["records"]:
        common = {
            "system": str(record["system"]),
            "message": str(record["message"]),
            "signal": str(record["signal"]),
            "source_row": str(record.get("source_row", "")),
            "on_fail_applicable": str(record["on_fail_applicable"]),
            "special": json.dumps(record.get("special", {}), ensure_ascii=True, sort_keys=True),
            "gateway_override": str(record.get("gateway_override", "")),
            "source": str(policy["source"]["name"]),
        }
        faults = record.get("faults", {})
        if not faults:
            rows.append({**common, "policy_mode": "", "reaction": "not_applicable", "value": "", "source_text": ""})
        for policy_mode, rule in faults.items():
            rows.append(
                {
                    **common,
                    "policy_mode": str(policy_mode),
                    "reaction": str(rule.get("reaction", "unresolved")),
                    "value": "" if rule.get("value") is None else str(rule["value"]),
                    "source_text": "" if rule.get("source_text") is None else str(rule["source_text"]),
                }
            )
    return rows


def _plan_matrix_rows(plans: Iterable[PlannedCase]) -> list[dict[str, str]]:
    return [
        {
            "test_case": plan.name,
            "applicability": plan.applicability,
            "category": plan.category,
            "status": plan.status,
            "target_variants": ", ".join(plan.variant_keys) or "Common static check",
            "source_row": str(plan.element.source_row),
            "parameter_name": plan.element.parameter_name,
            "record_scope": _record_scope_text(),
            "traceability": "Deferred by user request; Verifies intentionally blank.",
        }
        for plan in plans
    ]


def _aggregate_checklist_rows(matrix: Iterable[dict[str, Any]]) -> list[dict[str, str]]:
    """List every U171 not-configured and reserved allocation covered by the two aggregate cases."""
    rows = []
    for matrix_row in matrix:
        element = matrix_row["element"]
        width = _field_byte_length(element) or 1
        if (
            matrix_row["classification"] in {"External CAN", "ECU-generated CAN"}
            and matrix_row["u171_state"] in {"No verified CAN route", "Configured route absent from selected DBC"}
        ):
            rows.append(
                {
                    "Aggregate Case": "SUBS_EDR_Element_ID_U171_NOT_CONFIGURED_TestCase_9000_1",
                    "DID Scope": "0x0455 and 0x045B",
                    "DRBFM Row": str(element.source_row),
                    "Parameter": element.parameter_name,
                    "Byte/Bit Allocation": _field_summary(element),
                    "Expected Encoding": f"0x{'FF' * width}",
                    "Evidence": matrix_row["u171_state"],
                }
            )
        if matrix_row["classification"] == "Reserved":
            rows.append(
                {
                    "Aggregate Case": "SUBS_EDR_Element_ID_RESERVED_TestCase_9001_1",
                    "DID Scope": "0x0455 and 0x045B",
                    "DRBFM Row": str(element.source_row),
                    "Parameter": element.parameter_name,
                    "Byte/Bit Allocation": _field_summary(element),
                    "Expected Encoding": f"0x{'00' * width}",
                    "Evidence": "DRBFM Reserved",
                }
            )
    return rows


def _write_table_sheet(workbook: openpyxl.Workbook, title: str, rows: Iterable[dict[str, Any]]) -> None:
    materialized_rows = list(rows)
    if title in workbook.sheetnames:
        del workbook[title]
    worksheet = workbook.create_sheet(title)
    headers = list(materialized_rows[0]) if materialized_rows else ["Status"]
    worksheet.append(headers)
    for row in materialized_rows:
        worksheet.append([row.get(header, "") for header in headers])
    worksheet.freeze_panes = "A2"
    for cell in worksheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    for column_index, header in enumerate(headers, start=1):
        worksheet.column_dimensions[get_column_letter(column_index)].width = min(max(len(str(header)) + 2, 16), 60)
    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")


def _write_csv(destination: Path, rows: Iterable[dict[str, Any]]) -> None:
    materialized_rows = list(rows)
    if not materialized_rows:
        destination.write_text("\n", encoding="ascii")
        return
    with destination.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(materialized_rows[0]))
        writer.writeheader()
        writer.writerows(materialized_rows)


def validate_reference_authoring_output(output_path: Path, plans: Iterable[PlannedCase]) -> dict[str, Any]:
    """Validate the custom applicability column without applying the standard Codebeamer profile."""
    expected_names = [plan.name for plan in plans]
    workbook = openpyxl.load_workbook(output_path, data_only=False)
    try:
        worksheet = workbook.active
        if worksheet is None:
            raise RuntimeError("The authoring workbook has no active worksheet.")
        headers = tuple(cell.value for cell in worksheet[1])
        issues = []
        if headers[:4] != ("ID", "Priority", "Name", "Applicability"):
            issues.append("Primary workbook headers do not preserve the expected ID/Priority/Name/Applicability order.")
        names = []
        name_column = headers.index("Name") + 1
        applicability_column = headers.index("Applicability") + 1
        for row_number in range(2, worksheet.max_row + 1):
            name = worksheet.cell(row_number, name_column).value
            applicability = worksheet.cell(row_number, applicability_column).value
            if name not in {None, ""}:
                names.append(str(name))
                if applicability not in APPLICABILITY_VALUES:
                    issues.append(f"Primary row {row_number} has invalid applicability: {applicability!r}")
            elif applicability not in {None, ""}:
                issues.append(f"Continuation row {row_number} unexpectedly contains applicability: {applicability!r}")
        applicability_rules = [
            validation
            for validation in worksheet.data_validations.dataValidation
            if validation.formula1 == '"ICE,EV,Both"'
        ]
        if len(applicability_rules) != 1:
            issues.append("Applicability data validation was not preserved exactly once.")
        if names != expected_names:
            issues.append("Primary row names do not round-trip in the planned priority order.")
        return {
            "workbook_path": str(output_path),
            "test_case_count": len(names),
            "issues": issues,
            "summary": {"errors": len(issues), "warnings": 0},
        }
    finally:
        workbook.close()


def _allowed_technique(preferred: str, allowed_values: dict[str, list[str]]) -> str:
    available = allowed_values.get("_TestTechnique", [])
    if preferred in available:
        return preferred
    if not available:
        raise ValueError("Codebeamer template provides no test-technique values.")
    return available[0]


def build_codebeamer_cases(plans: Iterable[PlannedCase], allowed_values: dict[str, list[str]]) -> list[TestCase]:
    """Materialize target-specific Codebeamer rows while deliberately leaving Verifies blank."""
    cases: list[TestCase] = []
    for plan in plans:
        targets = plan.variant_keys or ("Common",)
        for variant in targets:
            target_name = plan.name if len(targets) == 1 else f"{plan.name}-{variant}"
            project = "Common EDR" if variant == "Common" else VARIANT_SOURCES[variant]["project_key"]
            description = plan.description + f"\nCodebeamer Target Variant: {variant}."
            cases.append(
                TestCase(
                    name=target_name,
                    description=description,
                    steps=[
                        TestStep(step.action, step.expected_result, step.critical, str(step_number))
                        for step_number, step in enumerate(plan.steps, start=1)
                    ],
                    methodology=TestMethodology(
                        primary_technique=_allowed_technique(plan.test_technique, allowed_values),
                        rationale="The test objective is derived from the DRBFM row, selected project DBC/configuration evidence, and visible source limitations.",
                    ),
                    requirement_ids=[],
                    pre_action=plan.pre_action,
                    post_action=plan.post_action,
                    priority=plan.priority,
                    status=plan.status,
                    item_type="Functional",
                    project=project,
                    latest_result="NOT YET TESTED",
                    test_type="Manual",
                    verification_method=plan.verification_method,
                    generation_notes=["Traceability deliberately deferred by user request; no requirement ID is serialized."],
                )
            )
    return cases


def _source_manifest(contexts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    onfail_policy = load_onfail_policy()
    return {
        "drbfm": drbfm_workbook_manifest(),
        "reference_authoring_workbook": {
            "path": str(REFERENCE_AUTHORING_WORKBOOK),
            "sha256": sha256_file(REFERENCE_AUTHORING_WORKBOOK),
            "inspection": inspect_reference_authoring_workbook(),
        },
        "codebeamer_template": {
            "path": str(CODEBEAMER_TEMPLATE),
            "sha256": sha256_file(CODEBEAMER_TEMPLATE),
            "inspection": inspect_template(CODEBEAMER_TEMPLATE).template_sha256,
        },
        "onfail_policy": {
            "path": str(ONFAIL_POLICY_PATH),
            "sha256": sha256_file(ONFAIL_POLICY_PATH),
            "source": onfail_policy["source"],
            "record_count": len(onfail_policy["records"]),
        },
        "variants": [
            {
                "variant": variant,
                "vehicle_class": context["vehicle_class"],
                "project_key": context["project_key"],
                "canc_config": {
                    "path": context["config_path"],
                    "sha256": sha256_file(Path(context["config_path"])),
                },
                "variant_config": {
                    "path": context["variant_config_path"],
                    "sha256": sha256_file(Path(context["variant_config_path"])),
                },
                "dbcs": context["dbc_manifest"],
            }
            for variant, context in contexts.items()
        ],
        "parsers": {
            "xlsx": f"openpyxl {openpyxl.__version__}",
            "dbc": f"cantools {cantools.__version__}",
            "rationale": "openpyxl preserves workbook structure and source rows; the DBC-to-JSON skill provides normalized array metadata after exact cantools raw-DBC validation; raw cantools metadata remains the fallback for fields the JSON schema omits.",
        },
    }


def _append_authoring_evidence_sheets(
    output_path: Path,
    matrix: list[dict[str, Any]],
    vectors: list[dict[str, Any]],
    plans: list[PlannedCase],
    source_manifest: dict[str, Any],
) -> None:
    workbook = openpyxl.load_workbook(output_path, data_only=False)
    try:
        _write_table_sheet(workbook, "Investigation Matrix", _public_matrix_rows(matrix))
        _write_table_sheet(workbook, "Test Vectors", vectors)
        _write_table_sheet(workbook, "Applicability Matrix", _plan_matrix_rows(plans))
        _write_table_sheet(workbook, "On-Fail Policy", _onfail_policy_matrix_rows())
        _write_table_sheet(workbook, "Aggregate Checks", _aggregate_checklist_rows(matrix))
        _write_table_sheet(
            workbook,
            "ON HOLD",
            [
                {
                    "test_case": plan.name,
                    "applicability": plan.applicability,
                    "category": plan.category,
                    "source_row": plan.element.source_row,
                    "parameter_name": plan.element.parameter_name,
                    "blocker": plan.description.splitlines()[-1],
                }
                for plan in plans
                if plan.status == "ON HOLD"
            ],
        )
        _write_table_sheet(
            workbook,
            "Source Evidence",
            (
                [
                    {
                        "source": "Common DRBFM",
                        "path": source_manifest["drbfm"]["path"],
                        "sha256": source_manifest["drbfm"]["sha256"],
                        "parser": source_manifest["drbfm"]["extractor"],
                    },
                    {
                        "source": "Reference authoring workbook",
                        "path": source_manifest["reference_authoring_workbook"]["path"],
                        "sha256": source_manifest["reference_authoring_workbook"]["sha256"],
                        "parser": "openpyxl contract inspection",
                    },
                    {
                        "source": "On-fail policy transcription",
                        "path": source_manifest["onfail_policy"]["path"],
                        "sha256": source_manifest["onfail_policy"]["sha256"],
                        "parser": source_manifest["onfail_policy"]["source"]["name"],
                    },
                ]
                + [
                    {
                        "source": f"{variant['variant']} {dbc['bus']} DBC",
                        "path": dbc["path"],
                        "sha256": dbc["sha256"],
                        "parser": dbc["parser"],
                    }
                    for variant in source_manifest["variants"]
                    for dbc in variant["dbcs"]
                ]
                + [
                    {
                        "source": f"{variant['variant']} {dbc['bus']} validated DBC JSON",
                        "path": dbc["json_path"],
                        "sha256": dbc["json_sha256"],
                        "parser": f"{dbc['metadata_source']}; converter={dbc['converter_path']}",
                    }
                    for variant in source_manifest["variants"]
                    for dbc in variant["dbcs"]
                ]
            ),
        )
        temporary_path = output_path.with_name(f"{output_path.stem}.supplemental.tmp{output_path.suffix}")
        workbook.save(temporary_path)
        temporary_path.replace(output_path)
    finally:
        workbook.close()


def _evidence_report(
    matrix: list[dict[str, Any]],
    vectors: list[dict[str, Any]],
    plans: list[PlannedCase],
    source_manifest: dict[str, Any],
    codebeamer_postflight: dict[str, Any],
) -> str:
    classifications = Counter(row["classification"] for row in matrix)
    applicability = Counter(row["applicability"] for row in matrix)
    statuses = Counter(plan.status for plan in plans)
    route_counts = {
        variant: Counter(row[f"{variant.casefold()}_state"] for row in matrix)
        for variant in ("U171", "M314")
    }
    return "\n".join(
        (
            "# Common EDR CAN 0x0455 / 0x045B Evidence And Blockers",
            "",
            "## Scope",
            "",
            "This is an offline authoring package only. It does not transmit CAN traffic, access an ECU, trigger an EDR event, create a fault, cycle ignition, or issue a diagnostic request.",
            "",
            "The package covers the 128 parameter rows in the requested DRBFM analysis sheet. Functional objectives are generated only where U171 and/or M314 DBC/configuration evidence exposes a CAN route. The common DRBFM rows are applied to both records by explicit user direction, not by an independently verified Record 2 field layout. Normal arrays are generated from validated DBC JSON metadata and checked against raw DBC metadata before use.",
            "",
            "## Source Evidence",
            "",
            f"- DRBFM source: `{source_manifest['drbfm']['path']}`",
            f"- DRBFM SHA-256: `{source_manifest['drbfm']['sha256']}`",
            f"- Workbook parser: `{source_manifest['parsers']['xlsx']}`; all {len(source_manifest['drbfm']['sheets'])} sheets were scanned.",
            f"- DBC parser: `{source_manifest['parsers']['dbc']}`; validated JSON catalogs are used for array generation.",
            f"- Validated DBC JSON catalogs: {', '.join(f'`{dbc["json_path"]}`' for variant in source_manifest['variants'] for dbc in variant['dbcs'])}.",
            f"- Reference authoring workbook SHA-256: `{source_manifest['reference_authoring_workbook']['sha256']}`.",
            f"- On-fail policy: `{source_manifest['onfail_policy']['path']}` (SHA-256 `{source_manifest['onfail_policy']['sha256']}`; {source_manifest['onfail_policy']['source']['original_workbook_status']}).",
            "",
            "## Coverage",
            "",
            f"- DRBFM rows: {len(matrix)}",
            f"- Vector rows: {len(vectors)}",
            f"- Common authoring cases: {len(plans)} ({statuses.get('IN REVIEW', 0)} IN REVIEW, {statuses.get('ON HOLD', 0)} ON HOLD)",
            f"- Classification counts: {dict(sorted(classifications.items()))}",
            f"- Applicability counts: {dict(sorted(applicability.items()))}",
            f"- U171 route states: {dict(sorted(route_counts['U171'].items()))}",
            f"- M314 route states: {dict(sorted(route_counts['M314'].items()))}",
            "",
            "## Decisions",
            "",
            "- U171 is represented as ICE and M314 as EV. M314's grouped project configuration identifies its default as an EV platform base configuration.",
            "- A `Both` case has separate U171 and M314 test-vector data. The Codebeamer export materializes target-specific rows where a common case has more than one target.",
            "- Every front-crash step includes the project-normative crash-lock DTCs `90 61 96 8B` and `92 1A 00 8B`. Configuration-backed active CAN fault DTCs are appended with status `0B` only in applicable on-fail cases.",
            "- Snapshot/no-interval parameters are stabilized from `T0 - 500 ms` through `T0`; they do not receive pre-crash or post-crash array cases.",
            "- Interval arrays include recording time, simulation window, input raw/physical values, expected-recorded raw/physical values, and DBC physical-range status. Any exception value outside the DBC range is explicitly flagged `OUT_OF_RANGE_REVIEW`.",
            "- Exact user-supplied per-signal policy takes precedence over generic behavior. Explicit defaults, consumed values, last-valid behavior, full-only scope, and no-onfail exclusions are rendered from the policy; generic fallback applies only when no explicit record matches.",
            "- Node-absent, message-timeout, message-content, and signal-content families are emitted only after configuration/DBC eligibility checks. Every resulting byte-packing assertion remains ON HOLD where source-owned EDR packing, qualification, or recovery evidence is absent.",
            "- Deconfigured/not-present default cases use all ones at the DRBFM allocation width only under the explicit user-directed policy. They remain ON HOLD until variant configuration and Record 2 packing are confirmed.",
            "- Reserved allocations use zero and never receive a functional CAN stimulus.",
            "- The `Aggregate Checks` sheet lists every U171 not-configured all-ones allocation and every reserved-zero allocation checked across both records.",
            "- Requirement IDs are deliberately omitted at the user's request. The Codebeamer `Verifies` column is blank, and validation warnings are expected.",
            "",
            "## Blockers",
            "",
            "1. Record 2 field locations, packing, and sampling are not supplied by the DRBFM source. Every exact Record 2 byte assertion is therefore an ON HOLD item despite the user-directed common-record assumption.",
            "2. Several DBC-to-EDR transformations differ across variants, including M314 accelerator/brake width and scaling, battery scaling, motor-speed semantics, and some inertial signals. The vector sheet records raw and physical values but does not invent stored payload bytes.",
            "3. The original onfail_edr_recording.xlsx is unavailable locally. The supplied normalized transcription is preserved as policy provenance, but unmatched or internally ambiguous routes remain ON HOLD.",
            "4. Bus-off is controller-level. It is not emitted as one parameter-specific case until bus/channel, DTC, recovery, and EDR impact are independently evidenced.",
            "5. Some DBC routes are present while the variant default node list does not explicitly list their key node. This is retained in the Investigation Matrix as an enablement-evidence gap, not silently converted into absence.",
            "",
            "## Regeneration",
            "",
            "Run the generator offline with `py -3.13 tests/test_common_edr_canc_specification.py --generate --output-directory <new-directory>`. Re-run the focused tests before accepting a new source revision. Do not execute generated procedures on a bench without a separate explicit authorization and source-ready fault/event procedure.",
            "",
            "## Validation",
            "",
            f"- Codebeamer renderer errors: {codebeamer_postflight['summary']['errors']}",
            f"- Codebeamer renderer warnings: {codebeamer_postflight['summary']['warnings']} (expected traceability-deferred warnings are included).",
            "- Live Codebeamer import acceptance: unverified.",
            "",
        )
    )


def generate_common_specification(
    output_directory: Path = DEFAULT_OUTPUT_DIRECTORY,
    *,
    overwrite: bool = False,
    version: str = SPECIFICATION_VERSION,
) -> dict[str, Any]:
    """Generate the dual-workbook common EDR specification and evidence package offline."""
    output_directory.mkdir(parents=True, exist_ok=True)
    stem = f"Common_EDR_CANC_0455_045B_U171_M314_{version}"
    authoring_path = output_directory / f"{stem}_authoring.xlsx"
    codebeamer_path = output_directory / f"{stem}_codebeamer.xlsx"
    matrix_path = output_directory / f"{stem}_investigation_matrix.csv"
    vectors_path = output_directory / f"{stem}_test_vectors.csv"
    applicability_path = output_directory / f"{stem}_applicability_matrix.csv"
    policy_matrix_path = output_directory / f"{stem}_onfail_policy_matrix.csv"
    evidence_path = output_directory / f"{stem}_evidence_and_blockers.md"
    handoff_path = output_directory / f"{stem}_evidence_handoff.json"
    validation_path = output_directory / f"{stem}_validation_report.json"
    destinations = (authoring_path, codebeamer_path, matrix_path, vectors_path, applicability_path, policy_matrix_path, evidence_path, handoff_path, validation_path)
    if not overwrite:
        existing = [path for path in destinations if path.exists()]
        if existing:
            raise FileExistsError(f"Refusing to overwrite generated artifacts: {existing}")

    elements = load_drbfm_analysis()
    contexts = {variant: load_variant_context(variant) for variant in ("U171", "M314")}
    matrix = build_route_matrix(elements, contexts)
    vectors = build_vector_rows(matrix)
    plans = build_case_plans(matrix)
    source_manifest = _source_manifest(contexts)

    render_reference_authoring_workbook(
        [_as_authoring_case(plan) for plan in plans],
        authoring_path,
        overwrite=True,
    )
    _append_authoring_evidence_sheets(authoring_path, matrix, vectors, plans, source_manifest)
    authoring_validation = validate_reference_authoring_output(authoring_path, plans)
    if authoring_validation["summary"]["errors"]:
        raise ValueError("Reference-compatible authoring workbook validation failed: " + "; ".join(authoring_validation["issues"]))

    template_inspection = inspect_template(CODEBEAMER_TEMPLATE)
    if template_inspection.issues:
        raise ValueError("Codebeamer template inspection failed: " + "; ".join(template_inspection.issues))
    codebeamer_cases = build_codebeamer_cases(plans, template_inspection.allowed_values)
    specification = TestSpecification(
        title="Common EDR CAN 0x0455 / 0x045B U171 ICE and M314 EV",
        test_cases=codebeamer_cases,
        source_paths=[
            str(DRBFM_WORKBOOK),
            str(U171_DBC),
            str(M314_FD_DBC),
            str(M314_HSCAN_DBC),
            str(U171_DBC_JSON),
            str(M314_FD_DBC_JSON),
            str(M314_HSCAN_DBC_JSON),
            str(U171_CANC_CONFIG),
            str(M314_CANC_CONFIG),
            str(ONFAIL_POLICY_PATH),
        ],
        assumptions=["DRBFM analysis rows are applied to both records by explicit user direction; the source does not independently establish the complete Record 2 layout."],
        coverage_gaps=["Requirement traceability is deferred by user request.", "Record 2 field packing is unavailable.", "EDR-specific fault fallback and qualification evidence is incomplete."],
    )
    preflight = validate_specification(specification, template_path=CODEBEAMER_TEMPLATE)
    preflight_errors = [issue for issue in preflight if issue.severity == "error"]
    if preflight_errors:
        raise ValueError("Codebeamer preflight failed: " + "; ".join(issue.message for issue in preflight_errors))
    codebeamer_generation = render_specification(
        specification,
        template_path=CODEBEAMER_TEMPLATE,
        destination_path=codebeamer_path,
        write_mode="replace_data",
        overwrite=True,
    )
    codebeamer_postflight = validate_rendered_workbook(codebeamer_path)
    if codebeamer_postflight["summary"]["errors"]:
        raise ValueError("Codebeamer rendered-workbook validation failed.")

    public_matrix = _public_matrix_rows(matrix)
    plan_matrix = _plan_matrix_rows(plans)
    _write_csv(matrix_path, public_matrix)
    _write_csv(vectors_path, vectors)
    _write_csv(applicability_path, plan_matrix)
    _write_csv(policy_matrix_path, _onfail_policy_matrix_rows())
    evidence_path.write_text(_evidence_report(matrix, vectors, plans, source_manifest, codebeamer_postflight), encoding="ascii")
    handoff = {
        "operation_id": f"common-edr-canc-u171-m314-{version}",
        "stage": "offline-specification-generation",
        "intent": "common EDR CAN test specification",
        "project": "U171 and M310_M314_M110",
        "variant": "U171 ICE and M314 EV",
        "safety_state": "offline",
        "confidence": {
            "level": "Medium",
            "rationale": "DBC route, scaling, and enumeration facts are native-parser backed; Record 2 layout, EDR packing, and many fault reactions remain unresolved.",
        },
        "sources": [
            {"path": source_manifest["drbfm"]["path"], "location": DRBFM_ANALYSIS_SHEET, "hash": source_manifest["drbfm"]["sha256"]},
            *[
                {"path": dbc["path"], "location": dbc["bus"], "hash": dbc["sha256"]}
                for variant in source_manifest["variants"]
                for dbc in variant["dbcs"]
            ],
            *[
                {"path": dbc["json_path"], "location": f"{dbc['bus']} validated JSON catalog", "hash": dbc["json_sha256"]}
                for variant in source_manifest["variants"]
                for dbc in variant["dbcs"]
            ],
            {
                "path": source_manifest["onfail_policy"]["path"],
                "location": source_manifest["onfail_policy"]["source"]["original_workbook_status"],
                "hash": source_manifest["onfail_policy"]["sha256"],
            },
        ],
        "facts": [
            f"The requested DRBFM analysis sheet contains {len(elements)} parameter rows.",
            f"The generated matrix contains {len(matrix)} rows and {len(vectors)} validated-JSON source-derived vector rows.",
            f"The authoring workbook contains {len(plans)} common case rows with ICE, EV, or Both applicability.",
            f"The on-fail policy contains {source_manifest['onfail_policy']['record_count']} explicit signal records.",
        ],
        "inferences": ["M314 is used as the EV evidence instance based on its variant configuration and EV-oriented DBC signals."],
        "assumptions": ["The DRBFM analysis rows apply to both 0x0455 and 0x045B by explicit user direction."],
        "contradictions": [
            "Record 2 field layout is not supplied by the DRBFM source.",
            "Several project DBC conversions differ from common DRBFM CAN/EDR conversion values.",
        ],
        "evidence_gaps": [
            "No approved requirement IDs are included by user direction.",
            "EDR-specific fault fallback values and qualification timing are incomplete.",
            source_manifest["onfail_policy"]["source"]["original_workbook_status"],
            "Bus-off EDR impact is not parameter-specific evidence.",
        ],
        "artifacts": [str(path) for path in destinations],
        "validation": [
            {"name": "reference authoring workbook", "errors": authoring_validation["summary"]["errors"]},
            {"name": "Codebeamer export", "errors": codebeamer_postflight["summary"]["errors"], "warnings": codebeamer_postflight["summary"]["warnings"]},
        ],
        "approval": None,
        "next_action": "Resolve Record 2 layout, field packing, on-fail timing, and approved traceability before bench execution.",
        "status": "needs_review",
    }
    handoff_path.write_text(json.dumps(handoff, ensure_ascii=True, indent=2) + "\n", encoding="ascii")
    write_validation_report(
        {
            "authoring_workbook": authoring_validation,
            "codebeamer_workbook": codebeamer_postflight,
            "codebeamer_generation": codebeamer_generation,
            "codebeamer_preflight": [
                {"severity": issue.severity, "code": issue.code, "message": issue.message, "location": issue.location}
                for issue in preflight
            ],
            "source_manifest": source_manifest,
            "counts": {
                "drbfm_rows": len(elements),
                "matrix_rows": len(matrix),
                "vector_rows": len(vectors),
                "common_cases": len(plans),
                "codebeamer_cases": len(codebeamer_cases),
            },
            "safety_state": "offline",
            "traceability": "deferred by user request; Verifies intentionally blank",
        },
        validation_path,
    )
    return {
        "authoring_workbook": authoring_path,
        "codebeamer_workbook": codebeamer_path,
        "investigation_matrix": matrix_path,
        "test_vectors": vectors_path,
        "applicability_matrix": applicability_path,
        "onfail_policy_matrix": policy_matrix_path,
        "evidence_report": evidence_path,
        "evidence_handoff": handoff_path,
        "validation_report": validation_path,
        "common_cases": len(plans),
        "codebeamer_cases": len(codebeamer_cases),
    }


def inspect_reference_authoring_workbook(reference_path: Path = REFERENCE_AUTHORING_WORKBOOK) -> dict[str, object]:
    """Inspect the supplied CANC workbook before cloning its authoring contract."""
    if not reference_path.is_file():
        raise FileNotFoundError(reference_path)
    workbook = openpyxl.load_workbook(reference_path, data_only=False)
    try:
        worksheet = workbook.active
        if worksheet is None:
            raise RuntimeError("The reference authoring workbook has no active worksheet.")
        headers = tuple("" if cell.value is None else str(cell.value) for cell in worksheet[1])
        if headers != AUTHORING_HEADERS:
            raise ValueError("Reference workbook headers do not match the observed CANC authoring contract.")
        validation_headers = []
        for validation in worksheet.data_validations.dataValidation:
            ranges = list(validation.sqref.ranges)
            if not ranges:
                continue
            column, _, _, _ = range_boundaries(str(ranges[0]))
            if column is None:
                continue
            validation_headers.append(headers[column - 1])
        return {
            "sheet_name": worksheet.title,
            "sheet_names": tuple(workbook.sheetnames),
            "headers": headers,
            "data_validation_headers": tuple(validation_headers),
            "row_count": worksheet.max_row,
            "column_count": worksheet.max_column,
        }
    finally:
        workbook.close()


def _capture_row_style(worksheet: Worksheet, row_number: int) -> tuple[list[Any], float | None]:
    cells = [copy.copy(worksheet.cell(row_number, column_index)._style) for column_index in range(1, worksheet.max_column + 1)]
    height = worksheet.row_dimensions[row_number].height
    return cells, height


def _apply_row_style(
    worksheet: Worksheet,
    row_number: int,
    snapshot: tuple[list[Any], float | None],
) -> None:
    styles, height = snapshot
    for column_index, style in enumerate(styles, start=1):
        worksheet.cell(row_number, column_index)._style = copy.copy(style)
    if height is not None:
        worksheet.row_dimensions[row_number].height = height


def _shift_column_dimensions(worksheet: Worksheet, insertion_column: int) -> None:
    original_dimensions = {
        column_index: copy.copy(worksheet.column_dimensions[get_column_letter(column_index)])
        for column_index in range(1, worksheet.max_column + 1)
        if get_column_letter(column_index) in worksheet.column_dimensions
    }
    for column_name in list(worksheet.column_dimensions):
        del worksheet.column_dimensions[column_name]
    for column_index, dimension in original_dimensions.items():
        destination_index = column_index + 1 if column_index >= insertion_column else column_index
        destination_column = get_column_letter(destination_index)
        dimension.index = destination_column
        worksheet.column_dimensions[destination_column] = dimension


def _capture_validation_specs(worksheet: Worksheet) -> list[tuple[str, DataValidation]]:
    headers = ["" if cell.value is None else str(cell.value) for cell in worksheet[1]]
    specifications: list[tuple[str, DataValidation]] = []
    for validation in worksheet.data_validations.dataValidation:
        ranges = list(validation.sqref.ranges)
        if not ranges:
            continue
        first_column, _, _, _ = range_boundaries(str(ranges[0]))
        if first_column is None:
            continue
        specifications.append((headers[first_column - 1], copy.copy(validation)))
    return specifications


def _restore_validation_specs(
    worksheet: Worksheet,
    specifications: Iterable[tuple[str, DataValidation]],
    final_row: int,
) -> None:
    worksheet.data_validations.dataValidation = []
    header_indexes = {
        str(cell.value): column_index
        for column_index, cell in enumerate(worksheet[1], start=1)
        if cell.value is not None
    }
    for header, validation in specifications:
        column_index = header_indexes.get(header)
        if column_index is None:
            raise ValueError(f"Reference validation header disappeared while rendering: {header}")
        restored = copy.copy(validation)
        column = get_column_letter(column_index)
        restored.sqref = f"{column}2:{column}{max(final_row, 2)}"
        worksheet.add_data_validation(restored)
    applicability_validation = DataValidation(type="list", formula1='"ICE,EV,Both"', allow_blank=True)
    worksheet.add_data_validation(applicability_validation)
    applicability_validation.add(f"D2:D{max(final_row, 2)}")


def _write_case_row(
    worksheet: Worksheet,
    row_number: int,
    case: AuthoringCase,
    step: AuthoringStep,
    step_number: int,
    *,
    primary: bool,
) -> None:
    header_indexes = {
        str(cell.value): column_index
        for column_index, cell in enumerate(worksheet[1], start=1)
        if cell.value is not None
    }
    if primary:
        values = {
            "Priority": case.priority,
            "Name": case.name,
            "Applicability": case.applicability,
            "Description": case.description,
            "Pre-Action": case.pre_action,
            "Post-Action": case.post_action,
            "Status": case.status,
            "Type": "Functional",
            "_Project": case.project,
            "_LatestResult": "NOT YET TESTED",
            "_TestType": case.test_type,
            "_VerificationMethod": case.verification_method,
            "_TestTechnique": case.test_technique,
        }
        for header, value in values.items():
            worksheet.cell(row_number, header_indexes[header], value=value)
    worksheet.cell(row_number, header_indexes["Test Steps.Action"], value=step.action)
    worksheet.cell(row_number, header_indexes["Test Steps.Expected result"], value=step.expected_result)
    worksheet.cell(row_number, header_indexes["Test Steps.Critical"], value=str(step.critical).lower())
    worksheet.cell(row_number, header_indexes["Test Steps.Id"], value=step_number)


def render_reference_authoring_workbook(
    cases: Iterable[AuthoringCase],
    destination_path: Path,
    *,
    reference_path: Path = REFERENCE_AUTHORING_WORKBOOK,
    overwrite: bool = False,
) -> dict[str, object]:
    """Clone the CANC workbook and render primary/continuation rows with applicability."""
    case_list = list(cases)
    if not case_list:
        raise ValueError("At least one authoring case is required.")
    if destination_path.exists() and not overwrite:
        raise FileExistsError(destination_path)
    for case in case_list:
        if case.applicability not in APPLICABILITY_VALUES:
            raise ValueError(f"Unsupported applicability for {case.name}: {case.applicability}")
        if not case.steps:
            raise ValueError(f"Authoring case has no steps: {case.name}")

    inspection = inspect_reference_authoring_workbook(reference_path)
    workbook = openpyxl.load_workbook(reference_path, data_only=False)
    try:
        worksheet_name = str(inspection["sheet_name"])
        worksheet = workbook[worksheet_name]
        validation_specs = _capture_validation_specs(worksheet)
        _shift_column_dimensions(worksheet, 4)
        worksheet.insert_cols(4)
        worksheet.cell(1, 4, value="Applicability")._style = copy.copy(worksheet.cell(1, 3)._style)
        worksheet.column_dimensions["D"].width = 14
        primary_style = _capture_row_style(worksheet, 3)
        continuation_style = _capture_row_style(worksheet, 4)
        worksheet.delete_rows(2, worksheet.max_row - 1)

        current_row = 2
        for case in case_list:
            for step_index, step in enumerate(case.steps, start=1):
                _apply_row_style(worksheet, current_row, primary_style if step_index == 1 else continuation_style)
                worksheet.cell(current_row, 4)._style = copy.copy(worksheet.cell(current_row, 3)._style)
                _write_case_row(
                    worksheet,
                    current_row,
                    case,
                    step,
                    step_index,
                    primary=step_index == 1,
                )
                current_row += 1

        _restore_validation_specs(worksheet, validation_specs, current_row - 1)
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path = destination_path.with_name(f"{destination_path.stem}.tmp{destination_path.suffix}")
        workbook.save(temporary_path)
        temporary_path.replace(destination_path)
    finally:
        workbook.close()
    return {
        "output_path": str(destination_path),
        "sheet_name": inspection["sheet_name"],
        "test_case_count": len(case_list),
        "written_rows": current_row - 2,
        "applicability_values": APPLICABILITY_VALUES,
    }


class ReferenceAuthoringWorkbookTests(unittest.TestCase):
    """Regression checks for the reference-compatible authoring workbook writer."""

    def test_reference_contract_and_applicability_round_trip(self) -> None:
        inspection = inspect_reference_authoring_workbook()
        self.assertEqual(inspection["sheet_name"], "Sheet1")
        self.assertEqual(inspection["headers"], AUTHORING_HEADERS)
        self.assertEqual(
            inspection["data_validation_headers"],
            ("ID", "Priority", "Test Steps.Critical", "Status", "Type", "_LatestResult", "_TestType", "_VerificationMethod"),
        )

        case = AuthoringCase(
            name="EDR-COMMON-BOTH-ODOMETER-NOMINAL-001",
            applicability="Both",
            description="Offline writer contract check for U171 ICE and M314 EV data sets.",
            pre_action="No bench action. Use offline source evidence only.",
            post_action="No bench action. Preserve generated evidence.",
            steps=(
                AuthoringStep("Review source mapping.", "The source mapping remains available for review."),
                AuthoringStep("Review stored encoding.", "The authoring continuation row retains no case-level applicability."),
            ),
        )
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "authoring.xlsx"
            result = render_reference_authoring_workbook([case], output)
            self.assertEqual(result["written_rows"], 2)
            workbook = openpyxl.load_workbook(output, data_only=False)
            try:
                worksheet = workbook.active
                if worksheet is None:
                    self.fail("Generated authoring workbook has no active worksheet.")
                headers = tuple(cell.value for cell in worksheet[1])
                self.assertEqual(headers[3], "Applicability")
                self.assertEqual(headers[:3], AUTHORING_HEADERS[:3])
                self.assertEqual(headers[4:], AUTHORING_HEADERS[3:])
                self.assertEqual(worksheet["C2"].value, case.name)
                self.assertEqual(worksheet["D2"].value, "Both")
                self.assertIsNone(worksheet["D3"].value)
                self.assertEqual(worksheet["F2"].value, case.pre_action)
                self.assertEqual(worksheet["G2"].value, case.post_action)
                self.assertEqual(worksheet["H2"].value, case.steps[0].action)
                self.assertEqual(worksheet["H3"].value, case.steps[1].action)
                applicability_rules = [
                    validation
                    for validation in worksheet.data_validations.dataValidation
                    if validation.formula1 == '"ICE,EV,Both"'
                ]
                self.assertEqual(len(applicability_rules), 1)
                self.assertIn("D2:D3", str(applicability_rules[0].sqref))
            finally:
                workbook.close()


class CommonEdrcancSpecificationTests(unittest.TestCase):
    """Offline evidence and generation checks for the common U171/M314 specification."""

    @staticmethod
    def _contexts() -> dict[str, dict[str, Any]]:
        return {variant: load_variant_context(variant) for variant in ("U171", "M314")}

    def test_drbfm_analysis_is_fully_extracted(self) -> None:
        elements = load_drbfm_analysis()
        manifest = drbfm_workbook_manifest()
        self.assertEqual(len(elements), 128)
        self.assertEqual(elements[0].parameter_name, "LifeTimeEventNb")
        self.assertEqual(elements[-1].parameter_name, "Clutch Status")
        self.assertEqual(len(manifest["sheets"]), 6)
        self.assertTrue(all(sheet["declared_max_row"] == sheet["scanned_rows"] for sheet in manifest["sheets"]))

    def test_onfail_policy_preserves_explicit_special_reactions(self) -> None:
        policy = load_onfail_policy()
        clutch = find_onfail_policy_record("EMS", "EMS3_10", "CLUTCH_STS")
        engine = find_onfail_policy_record("EMS", "EMS1_10", "STS_ENG")
        gateway = find_onfail_policy_record("HPC-V", "GW_HEARTBEAT", "BATT_VOLTAGE")
        self.assertEqual(policy["source"]["matching_key"], "system + message + signal")
        self.assertIsNotNone(clutch)
        self.assertIsNotNone(engine)
        self.assertIsNotNone(gateway)
        assert clutch is not None
        assert engine is not None
        assert gateway is not None
        self.assertEqual(clutch["faults"]["message_timeout"]["reaction"], "consume")
        self.assertEqual(engine["special"]["qualification_seconds"], 10)
        self.assertEqual(engine["special"]["message_timeout_values"], ["0x1", "0x5"])
        self.assertFalse(gateway["on_fail_applicable"])

    def test_onfail_decision_prefers_explicit_rules_and_suppresses_na(self) -> None:
        clutch = find_onfail_policy_record("EMS", "EMS3_10", "CLUTCH_STS")
        gateway = find_onfail_policy_record("HPC-V", "GW_HEARTBEAT", "BATT_VOLTAGE")
        explicit = onfail_decision({"onfail_policy": clutch}, "message_timeout")
        excluded = onfail_decision({"onfail_policy": gateway}, "node_absent")
        fallback = onfail_decision({"onfail_policy": None}, "message_timeout")
        self.assertEqual(explicit.reaction, "consume")
        self.assertEqual(explicit.source, "explicit user-supplied policy")
        self.assertFalse(excluded.applicable)
        self.assertEqual(excluded.reaction, "not_applicable")
        self.assertEqual(fallback.reaction, "last_valid")
        self.assertEqual(fallback.source, "generic-majority fallback")

    def test_onfail_exception_decision_uses_signal_specific_consume_rule(self) -> None:
        route = {
            "onfail_policy": find_onfail_policy_record("EMS", "EMS21_10", "BRK_PEDAL1"),
        }
        invalid = onfail_exception_decision(route, "invalid")
        reserved = onfail_exception_decision(route, "reserved")
        self.assertEqual(invalid.reaction, "consume")
        self.assertEqual(invalid.value, "0x3")
        self.assertEqual(reserved.reaction, "consume")
        self.assertEqual(reserved.value, "0x2")

    def test_onfail_recording_points_keep_default_and_consumed_behaviors_distinct(self) -> None:
        element = next(item for item in load_drbfm_analysis() if item.parameter_name == "Break Pedal Val")
        metadata = load_variant_context("U171")["signal_index"][("EMS21_10", "BRK_PEDAL1")]
        default_decision = OnFailDecision(
            "signal_never_received",
            "signal_never_received",
            "default",
            "0x0",
            True,
            "explicit user-supplied policy",
            10,
            {},
        )
        consume_decision = OnFailDecision(
            "message_timeout",
            "message_timeout",
            "consume",
            None,
            True,
            "explicit user-supplied policy",
            11,
            {},
        )
        default_points = onfail_recording_points(element, metadata, "U171", "full", decision=default_decision)
        consume_points = onfail_recording_points(element, metadata, "U171", "full", decision=consume_decision)
        self.assertTrue(all(point["expected_recorded_raw_hex"] == "0x0" for point in default_points))
        self.assertTrue(all(point["input_raw_hex"] == "FAULT_ACTIVE" for point in default_points))
        self.assertEqual(
            [point["expected_recorded_raw_integer"] for point in consume_points],
            [point["input_raw_integer"] for point in consume_points],
        )
        self.assertTrue(all("consumed live input" in point["fault_state"] for point in consume_points))

        invalid_decision = OnFailDecision(
            "signal_content",
            "signal_invalid",
            "consume",
            "0x3",
            True,
            "explicit user-supplied policy",
            10,
            {},
        )
        invalid_points = onfail_recording_points(element, metadata, "U171", "full", decision=invalid_decision)
        self.assertTrue(all(point["input_raw_hex"] == "0x3" for point in invalid_points))
        self.assertTrue(all(point["expected_recorded_raw_hex"] == "0x3" for point in invalid_points))

    def test_eligible_onfail_modes_apply_timeout_and_scope_gates(self) -> None:
        element = next(item for item in load_drbfm_analysis() if item.parameter_name == "Clutch Status")
        route = resolve_element_route(element, load_variant_context("U171"))
        modes = dict(eligible_onfail_modes(route))
        self.assertIn("message_timeout", modes)
        self.assertEqual(modes["message_timeout"].reaction, "consume")
        self.assertEqual(onfail_scopes(element, "message_timeout", modes["message_timeout"]), ("full", "pre", "post"))
        engine_decision = onfail_decision(
            {"onfail_policy": find_onfail_policy_record("EMS", "EMS1_10", "STS_ENG")},
            "message_timeout",
        )
        self.assertEqual(onfail_scopes(element, "signal_never_received", engine_decision), ("full",))
        self.assertEqual(onfail_scopes(element, "message_timeout", engine_decision), ("full",))

    def test_special_onfail_cases_preserve_clutch_and_engine_constraints(self) -> None:
        plans = build_case_plans(build_route_matrix(load_drbfm_analysis(), self._contexts()))
        clutch_timeout = next(
            plan
            for plan in plans
            if plan.element.parameter_name == "Clutch Status" and plan.category.startswith("Message Timeout in full")
        )
        clutch_observation = next(step.expected_result for step in clutch_timeout.steps if step.action.startswith("Read EDR and"))
        engine_timeouts = [
            plan
            for plan in plans
            if plan.element.parameter_name == "EngineState" and plan.category.startswith("Message Timeout")
        ]
        self.assertIn("On-fail policy: consume", clutch_timeout.pre_action)
        self.assertIn("consumes the corresponding valid input value", clutch_observation)
        self.assertEqual(len(engine_timeouts), 1)
        engine_timeout = engine_timeouts[0]
        engine_fault_action = engine_timeout.steps[1].action
        engine_dtc = next(step.expected_result for step in engine_timeout.steps if step.action == "Simulate Front Crash and Read DTC")
        self.assertIn("full interval", engine_timeout.category)
        self.assertNotIn("pre crash", engine_timeout.category)
        self.assertNotIn("post crash", engine_timeout.category)
        self.assertIn("0x1/0x5", engine_fault_action)
        self.assertIn("DTC Qualifies: Message Timeout DTC:", engine_dtc)
        self.assertIn("10 s", engine_dtc)

    def test_brake_exception_policy_consumes_dbc_invalid_and_reserved_codes(self) -> None:
        matrix = build_route_matrix(load_drbfm_analysis(), self._contexts())
        vectors = build_vector_rows(matrix)
        brake_vectors = [
            vector
            for vector in vectors
            if vector["parameter_name"] == "Break Pedal Val" and vector["variant"] == "U171"
        ]
        invalid = next(vector for vector in brake_vectors if vector["scenario"] == "invalid")
        reserved = next(vector for vector in brake_vectors if vector["scenario"] == "reserved")
        self.assertEqual((invalid["input_raw_hex"], invalid["expected_recorded_raw_hex"]), ("0x3", "0x3"))
        self.assertEqual((reserved["input_raw_hex"], reserved["expected_recorded_raw_hex"]), ("0x2", "0x2"))
        self.assertEqual(invalid["nominal_value_status"], "POLICY_CONSUMED_EXCEPTION")

    def test_u171_and_m314_dbc_routes_are_variant_specific(self) -> None:
        elements = {element.normalized_name: element for element in load_drbfm_analysis()}
        contexts = self._contexts()
        speed_u171 = resolve_element_route(elements["vehiclespeedlongitudinal"], contexts["U171"])
        speed_m314 = resolve_element_route(elements["vehiclespeedlongitudinal"], contexts["M314"])
        torque_u171 = resolve_element_route(elements["vcutrqcmd"], contexts["U171"])
        torque_m314 = resolve_element_route(elements["vcutrqcmd"], contexts["M314"])
        self.assertEqual(speed_u171["dbc"]["message"], "ESC12_10")
        self.assertEqual(speed_m314["dbc"]["message"], "IEB1_FD_10")
        self.assertEqual(torque_u171["state"], "No verified CAN route")
        self.assertEqual(torque_m314["dbc"]["message"], "VCU11_FD_10")
        self.assertEqual(contexts["U171"]["vehicle_class"], "ICE")
        self.assertEqual(contexts["M314"]["vehicle_class"], "EV")

    def test_validated_json_catalogs_are_used_for_array_metadata(self) -> None:
        contexts = self._contexts()
        for context in contexts.values():
            for catalog in context["dbc_manifest"]:
                self.assertEqual(catalog["metadata_source"], "validated DBC JSON")
                self.assertTrue(Path(catalog["json_path"]).is_file())
                self.assertGreater(catalog["json_message_count"], 0)
                self.assertGreater(catalog["json_signal_count"], 0)
        speed = resolve_element_route(
            next(element for element in load_drbfm_analysis() if element.parameter_name == "Vehicle Speed Longitudinal"),
            contexts["U171"],
        )
        self.assertEqual(speed["dbc"]["metadata_source"], "validated DBC JSON")

    def test_snapshot_and_valid_binary_arrays_follow_the_timing_rules(self) -> None:
        elements = {element.parameter_name: element for element in load_drbfm_analysis()}
        context = load_variant_context("U171")
        odometer = resolve_element_route(elements["Odometer"], context)
        brake = resolve_element_route(elements["Break Pedal Val"], context)
        self.assertEqual(recording_model(elements["Odometer"]), "snapshot")
        odometer_points = nominal_recording_points(elements["Odometer"], odometer["dbc"], "U171")
        self.assertEqual(len(odometer_points), 1)
        self.assertEqual(
            (odometer_points[0]["simulation_window_start_s"], odometer_points[0]["simulation_window_end_s"]),
            (-0.5, 0.0),
        )
        brake_points = nominal_recording_points(elements["Break Pedal Val"], brake["dbc"], "U171")
        brake_values = [point["input_raw_integer"] for point in brake_points]
        self.assertEqual(brake_values[:3], [1, 1, 1])
        self.assertTrue(set(brake_values).issubset({0, 1}))
        self.assertNotIn(2, brake_values)
        self.assertNotIn(3, brake_values)
        self.assertTrue(all(point["physical_range_status"] == "IN_RANGE" for point in brake_points))
        plans = build_case_plans(build_route_matrix(load_drbfm_analysis(), self._contexts()))
        odometer_plans = [plan for plan in plans if plan.element.parameter_name == "Odometer"]
        self.assertTrue(any("T0 - 500 ms to T0" in plan.pre_action for plan in odometer_plans))
        self.assertFalse(any("pre crash" in plan.category or "post crash" in plan.category for plan in odometer_plans))

    def test_full_time_grid_and_common_case_plans_are_derived(self) -> None:
        elements = load_drbfm_analysis()
        contexts = self._contexts()
        matrix = build_route_matrix(elements, contexts)
        vectors = build_vector_rows(matrix)
        plans = build_case_plans(matrix)
        speed = next(row for row in matrix if row["parameter_name"] == "Vehicle Speed Longitudinal")
        speed_vectors = [
            row
            for row in vectors
            if row["source_row"] == speed["source_row"]
            and row["variant"] == "U171"
            and row["scenario"] == "nominal valid input"
        ]
        speed_plans = [plan for plan in plans if plan.element.parameter_name == "Vehicle Speed Longitudinal"]
        torque_plans = [plan for plan in plans if plan.element.parameter_name == "VCU_TRQ_CMD"]
        self.assertEqual(speed["applicability"], "Both")
        self.assertEqual(len(speed_vectors), 17)
        self.assertEqual(speed_vectors[0]["timestamp_s"], -5.0)
        self.assertEqual(speed_vectors[-1]["timestamp_s"], 3.0)
        nominal_rows = [row for row in vectors if row["scenario"] == "nominal valid input"]
        self.assertFalse(any(row["physical_range_status"] == "OUT_OF_RANGE_REVIEW" for row in nominal_rows))
        self.assertTrue(any(plan.category == "Nominal full interval" for plan in speed_plans))
        self.assertEqual(speed_plans[0].name, "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_1")
        self.assertTrue(any("full interval" in plan.category for plan in speed_plans))
        self.assertTrue(any("pre crash" in plan.category for plan in speed_plans))
        self.assertTrue(any("post crash" in plan.category for plan in speed_plans))
        self.assertTrue(all("Input raw CAN hex:" in plan.pre_action for plan in speed_plans))
        self.assertTrue(all("Expected recorded raw CAN hex:" in plan.pre_action for plan in speed_plans))
        self.assertTrue(all("Physical" in plan.pre_action for plan in speed_plans))
        self.assertTrue(all(plan.post_action == "" for plan in speed_plans))
        self.assertTrue(all(len(plan.steps) in {6, 7} for plan in speed_plans))
        self.assertEqual(speed_plans[0].steps[1].action, "Simulate Valid Values as specified in step 2 of Pre Action")
        self.assertEqual(speed_plans[0].steps[3].action, "Read EDR and observe bytes for VehSpdLgt EDR Parameter")
        self.assertIn("read EDR2 and observe bytes for the VehSpdLgt EDR Parameter.", speed_plans[0].steps[4].action)
        speed_fault_plans = [plan for plan in speed_plans if plan.category != "Nominal full interval"]
        self.assertTrue(all(plan.applicability in {"ICE", "EV"} for plan in speed_fault_plans))
        self.assertTrue(any("U171: CAN ESC12_10" in plan.pre_action for plan in speed_plans if plan.applicability == "Both"))
        self.assertTrue(any("M314: CAN-FD IEB1_FD_10" in plan.pre_action for plan in speed_plans if plan.applicability == "Both"))
        crash_expectation = next(step.expected_result for step in speed_plans[0].steps if step.action == "Simulate Front Crash and Read DTC")
        self.assertIn("90 61 96 8B", crash_expectation)
        self.assertIn("92 1A 00 8B", crash_expectation)
        self.assertFalse(any(plan.category.startswith("Message Timeout") and plan.applicability == "ICE" for plan in speed_plans))
        never_received = next(plan for plan in speed_plans if plan.category.startswith("Signal Never Received") and plan.applicability == "ICE")
        never_received_observation = next(step.expected_result for step in never_received.steps if step.action.startswith("Read EDR and"))
        never_received_dtc = next(step.expected_result for step in never_received.steps if step.action == "Simulate Front Crash and Read DTC")
        self.assertIn("Expected recorded raw CAN hex: [0xFFFE", never_received_observation)
        self.assertIn("DTC Qualifies:", never_received_dtc)
        self.assertFalse(any("Candidate configured DTC" in step.expected_result for plan in plans for step in plan.steps))
        self.assertTrue(any(plan.applicability == "EV" and plan.category.startswith("Nominal") for plan in torque_plans))
        self.assertTrue(all(plan.applicability in APPLICABILITY_VALUES for plan in plans))
        self.assertEqual(len({plan.name for plan in plans}), len(plans))
        accelerator_plans = [plan for plan in plans if plan.element.parameter_name == "Accelerator Pedal"]
        self.assertEqual(accelerator_plans[0].name, "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_1")
        aggregates = {plan.name: plan for plan in plans if plan.name.startswith("SUBS_EDR_Element_ID_U171_NOT_CONFIGURED") or plan.name.startswith("SUBS_EDR_Element_ID_RESERVED")}
        self.assertEqual(set(aggregates), {"SUBS_EDR_Element_ID_U171_NOT_CONFIGURED_TestCase_9000_1", "SUBS_EDR_Element_ID_RESERVED_TestCase_9001_1"})
        self.assertIn("0x0455", aggregates["SUBS_EDR_Element_ID_U171_NOT_CONFIGURED_TestCase_9000_1"].pre_action)
        self.assertIn("0x045B", aggregates["SUBS_EDR_Element_ID_RESERVED_TestCase_9001_1"].pre_action)
        grouped_suffixes: dict[tuple[str, str], list[int]] = {}
        for plan in plans:
            match = REFERENCE_CASE_NAME_PATTERN.fullmatch(plan.name)
            self.assertIsNotNone(match)
            if match is None:
                continue
            grouped_suffixes.setdefault((match.group(1), match.group(2)), []).append(int(match.group(3)))
        self.assertTrue(all(sorted(suffixes) == list(range(1, len(suffixes) + 1)) for suffixes in grouped_suffixes.values()))

    def test_codebeamer_cases_defer_traceability_without_errors(self) -> None:
        contexts = self._contexts()
        plans = build_case_plans(build_route_matrix(load_drbfm_analysis(), contexts))[:5]
        inspection = inspect_template(CODEBEAMER_TEMPLATE)
        cases = build_codebeamer_cases(plans, inspection.allowed_values)
        specification = TestSpecification(title="Common EDR test slice", test_cases=cases)
        issues = validate_specification(specification, template_path=CODEBEAMER_TEMPLATE)
        self.assertFalse([issue for issue in issues if issue.severity == "error"])
        self.assertTrue(all(not case.requirement_ids for case in cases))
        self.assertEqual(sum(issue.code == "TRACEABILITY_UNRESOLVED" for issue in issues), len(cases))


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the offline common U171/M314 EDR CAN specification package.")
    parser.add_argument("--generate", action="store_true", help="Write the dual-workbook specification and evidence package.")
    parser.add_argument("--output-directory", type=Path, default=DEFAULT_OUTPUT_DIRECTORY, help="New artifact directory.")
    parser.add_argument("--overwrite", action="store_true", help="Allow replacing a previously generated artifact set.")
    parser.add_argument("--version", default=SPECIFICATION_VERSION, help="Generated artifact version suffix, for example v2.")
    arguments = parser.parse_args()
    if not arguments.generate:
        parser.error("Use --generate to write offline specification artifacts, or run without arguments to execute regression tests.")
    result = generate_common_specification(arguments.output_directory, overwrite=arguments.overwrite, version=arguments.version)
    print(json.dumps({key: str(value) if isinstance(value, Path) else value for key, value in result.items()}, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    if "--generate" in sys.argv:
        raise SystemExit(main())
    unittest.main(verbosity=2)