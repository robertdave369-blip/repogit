from __future__ import annotations

import secrets
import tempfile
import unittest
from pathlib import Path
from typing import Any

from tools.codebeamer.client import (
    CodebeamerClient,
    CodebeamerConflictError,
    CodebeamerConfig,
    CodebeamerScopeError,
)
from tools.codebeamer.operations import (
    apply_mutation_plan,
    build_mutation_plan,
    load_mutation_plan,
    write_mutation_plan,
)


class FakeResponse:
    """Minimal response fake used to exercise local mutation safeguards."""

    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload
        self.headers: dict[str, str] = {}

    def json(self) -> Any:
        return self._payload


class FakeSession:
    """Record requests without permitting live Codebeamer traffic."""

    def __init__(self, responses: list[FakeResponse]) -> None:
        self.auth: object | None = None
        self.headers: dict[str, str] = {}
        self.requests: list[dict[str, Any]] = []
        self.responses = responses

    def request(self, method: str, url: str, **kwargs: Any) -> FakeResponse:
        self.requests.append({"method": method, "url": url, **kwargs})
        if not self.responses:
            raise AssertionError("Unexpected HTTP request")
        return self.responses.pop(0)

    def close(self) -> None:
        pass


class CodebeamerMutationTests(unittest.TestCase):
    """Offline tests for approval-gated Codebeamer mutations."""

    def setUp(self) -> None:
        self.username = f"test-user-{secrets.token_hex(8)}"
        self.password = secrets.token_urlsafe(24)
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary_directory.cleanup)

    def _client(
        self,
        responses: list[FakeResponse],
    ) -> tuple[CodebeamerClient, FakeSession]:
        dotenv_path = Path(self.temporary_directory.name) / ".env"
        dotenv_path.write_text(
            "\n".join(
                (
                    "CODEBEAMER_URL=https://codebeamer.example.test/api/v3",
                    f"CODEBEAMER_USERNAME={self.username}",
                    f"CODEBEAMER_PASSWORD={self.password}",
                    "",
                )
            ),
            encoding="utf-8",
        )
        session = FakeSession(responses)
        return CodebeamerClient(CodebeamerConfig.from_dotenv(dotenv_path), session), session

    def test_mutation_methods_use_expected_routes(self) -> None:
        client, session = self._client(
            [
                FakeResponse(201, {"id": 101}),
                FakeResponse(200, {"id": 101}),
                FakeResponse(201, {"id": 12}),
                FakeResponse(200, {"id": 12}),
            ]
        )

        client.create_item(12, {"name": "New requirement"})
        client.update_item(101, {"id": 101, "name": "Updated requirement"})
        client.create_tracker(1, {"name": "Requirements", "keyName": "REQ"})
        client.update_tracker(12, {"id": 12, "name": "Updated tracker"})

        self.assertEqual(
            [(request["method"], request["url"]) for request in session.requests],
            [
                ("POST", "https://codebeamer.example.test/api/v3/trackers/12/items"),
                ("PUT", "https://codebeamer.example.test/api/v3/items/101"),
                ("POST", "https://codebeamer.example.test/api/v3/projects/1/trackers"),
                ("PUT", "https://codebeamer.example.test/api/v3/trackers/12"),
            ],
        )
        self.assertTrue(all(request["allow_redirects"] is False for request in session.requests))
        self.assertTrue(all(self.username not in request["url"] for request in session.requests))
        self.assertTrue(all(self.password not in request["url"] for request in session.requests))

    def test_plan_requires_exact_approval_and_rechecks_item(self) -> None:
        current_item = {"id": 101, "tracker": {"id": 12}, "name": "Before", "version": 3}
        client, session = self._client(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(200, current_item),
            ]
        )
        plan = build_mutation_plan(
            client,
            operation="update-item",
            project_id=1,
            tracker_id=12,
            item_id=101,
            payload={"id": 101, "name": "After"},
        )

        with self.assertRaises(CodebeamerScopeError):
            apply_mutation_plan(client, plan, approval_token="not-the-plan-id")
        self.assertEqual([request["method"] for request in session.requests], ["GET", "GET", "GET"])

        session.responses.extend(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(200, current_item),
                FakeResponse(200, {"id": 101}),
            ]
        )
        result = apply_mutation_plan(client, plan, approval_token=plan.plan_id)

        self.assertEqual(result.response["id"], 101)
        self.assertEqual(
            [request["method"] for request in session.requests],
            ["GET", "GET", "GET", "GET", "GET", "GET", "PUT"],
        )
        self.assertEqual(session.requests[-1]["json"], {"id": 101, "name": "After"})

    def test_apply_blocks_stale_item_before_write(self) -> None:
        client, session = self._client(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(200, {"id": 101, "tracker": {"id": 12}, "name": "Before"}),
            ]
        )
        plan = build_mutation_plan(
            client,
            operation="update-item",
            project_id=1,
            tracker_id=12,
            item_id=101,
            payload={"id": 101, "name": "After"},
        )
        session.responses.extend(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(200, {"id": 101, "tracker": {"id": 12}, "name": "Changed"}),
            ]
        )

        with self.assertRaises(CodebeamerConflictError):
            apply_mutation_plan(client, plan, approval_token=plan.plan_id)

        self.assertEqual(session.requests[-1]["method"], "GET")
        self.assertNotIn("PUT", [request["method"] for request in session.requests])

    def test_plan_rejects_configured_credentials_before_network_access(self) -> None:
        client, session = self._client([])

        with self.assertRaises(CodebeamerScopeError):
            build_mutation_plan(
                client,
                operation="create-item",
                project_id=1,
                tracker_id=12,
                item_id=None,
                payload={"name": self.password},
            )

        self.assertEqual(session.requests, [])

    def test_plan_round_trip_preserves_integrity(self) -> None:
        client, _ = self._client(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
            ]
        )
        plan = build_mutation_plan(
            client,
            operation="create-item",
            project_id=1,
            tracker_id=12,
            item_id=None,
            payload={"name": "New requirement"},
        )
        plan_path = write_mutation_plan(
            plan,
            Path(self.temporary_directory.name) / "plan.json",
        )

        self.assertEqual(load_mutation_plan(plan_path), plan)


if __name__ == "__main__":
    unittest.main()