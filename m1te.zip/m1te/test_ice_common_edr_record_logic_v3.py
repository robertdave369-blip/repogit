"""Create a prioritized V3 EDR specification in the legacy Export format.

V3 is a new review revision. It uses the target-record clarification for parallel,
single, and multi-event record handling and does not modify V1 or V2. Generation
is offline only and never connects to bench hardware or an ECU.
"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import copy
from datetime import date
import json
from pathlib import Path
from shutil import copy2
from typing import Any
from zipfile import ZipFile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from test_ice_common_edr_test_spec_design import inspect_source


ROOT = Path(__file__).resolve().parents[1]
LEGACY_TEMPLATE = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "Legacy_EDR"
    / "Legacy_EDR_Spec_Covering Multievent_parallel_ignoff_batt_off_.xlsx"
)
TARGET_RECORD_REFERENCE = Path(
    r"C:\Users\christy.paul\Downloads\edr_requirements\EDR_Record_Logic_Multi_and_Single_Events.md"
)
VERSION_DIRECTORY = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design"
    / "03_Authoring_Versions"
    / "V3_Prioritized_Record_Logic_Review"
)
OUTPUT_WORKBOOK = VERSION_DIRECTORY / "EDR_Prioritized_Record_Logic_CANWakeup_v3.xlsx"
OUTPUT_REPORT = VERSION_DIRECTORY / "EDR_Prioritized_Record_Logic_CANWakeup_v3_validation.json"

EXPORT_HEADERS = [
    "Priority",
    "Name",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
]
HIGHLIGHT_YELLOW = "FFF200"
PALE_BLUE = "D9EAF7"
PALE_GREEN = "E2F0D9"
NAVY = "1F4E78"
WHITE = "FFFFFF"
THIN_GRAY = Side(style="thin", color="B7B7B7")
PENDING = "Pending confirmation. Record the observed behavior and do not set pass or fail."


def lines(*items: str) -> str:
    return "\n".join(item for item in items if item)


def event_code(value: Any) -> str:
    text = str(value).strip()
    if not text or text[0] not in {"0", "1"}:
        raise ValueError(f"Unexpected event-vector value: {value!r}")
    return text[0]


def event_name(code: str, deployment_type: str = "Deployment Event") -> str:
    return "Near Crash" if code == "0" else deployment_type


def validate_target_reference() -> None:
    if not TARGET_RECORD_REFERENCE.is_file():
        raise FileNotFoundError(f"Target record-logic reference is unavailable: {TARGET_RECORD_REFERENCE}")
    text = TARGET_RECORD_REFERENCE.read_text(encoding="utf-8")
    anchors = (
        "500 ms < delta_t < 5000 ms",
        "delta_t <= 500 ms",
        "EDR2 is **not recorded**",
        "Front + Left Side",
        "Exactly 5000 ms",
        "200ms CompletionStatus",
    )
    missing = [anchor for anchor in anchors if anchor not in text]
    if missing:
        raise ValueError(f"Target record-logic reference is missing required anchors: {missing}")


def find_vector(source_data: dict[str, Any], family: str, pattern: tuple[str, str, str]) -> dict[str, Any]:
    for item in source_data["vectors"]:
        found_pattern = tuple(event_code(item[f"event_{index}"]) for index in (1, 2, 3))
        if item["family"] == family and found_pattern == pattern:
            return item
    raise ValueError(f"No {family} vector exists for event pattern {pattern}.")


def e2_result(data: dict[str, Any]) -> str:
    return lines(
        f"EDR1 (End E2): {data['after_2_edr1']}",
        f"EDR2 (End E2): {data['after_2_edr2']}",
        f"MultiEvent# EDR1 (E2): {data['after_2_multi_1']}",
        f"MultiEvent# EDR2 (E2): {data['after_2_multi_2']}",
        f"TimeB/W EDR1 (E2): {data['after_2_time_1']}",
        f"TimeB/W EDR2 (E2): {data['after_2_time_2']}",
        f"Lifetime# EDR1 (E2): {data['after_2_lifetime_1']}",
        f"Lifetime# EDR2 (E2): {data['after_2_lifetime_2']}",
        "Record Lock status at End E2: not evaluated because no End E2 lock requirement is defined.",
    )


def e3_result(data: dict[str, Any]) -> str:
    return lines(
        f"EDR1 (End E3): {data['after_3_edr1']}",
        f"EDR2 (End E3): {data['after_3_edr2']}",
        f"MultiEvent# EDR1 (E3): {data['after_3_multi_1']}",
        f"MultiEvent# EDR2 (E3): {data['after_3_multi_2']}",
        f"TimeB/W EDR1 (E3): {data['after_3_time_1']}",
        f"TimeB/W EDR2 (E3): {data['after_3_time_2']}",
        f"Lifetime# EDR1 (E3): {data['after_3_lifetime_1']}",
        f"Lifetime# EDR2 (E3): {data['after_3_lifetime_2']}",
        f"Record Lock EDR1 (E3): {data['after_3_lock_1']}",
        f"Record Lock EDR2 (E3): {data['after_3_lock_2']}",
    )


def event_steps(crash_type: str) -> list[tuple[str, str]]:
    if crash_type == "Near Crash":
        return [
            ("Trigger Near Crash and check that no squibs are deployed.", "No squibs are deployed."),
            ("Check crash signals after Near Crash.", "DOOR_UNLOCK=0, STS_CRASH=0, CRASH_LOCATION=0 (Near), SCM_CNT=0, NEAR_CRASH=1."),
            ("Read DTC and check that no new DTC is active for Near Crash.", "No new DTC is active."),
        ]
    if crash_type == "Deployment (Front)":
        return [
            (
                "Trigger Front Crash and check Front Crash squib deployment: Driver Airbag, Passenger Airbag, Passenger PT, Driver PT, Driver Lap PT, Passenger Lap PT, and Driver Knee Airbag.",
                "All listed Front Crash squibs are deployed.",
            ),
            ("Read DTC and check Front Crash and Pretensioner Crash DTCs.", "Crash DTC 90 61 96 8B and Pretensioner Crash DTC 92 1A 00 8B are active."),
            ("Check crash signals after Front Crash.", "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=1 (Front), and SCM_CNT increments while STS_CRASH=1."),
        ]
    if crash_type == "Deployment (Right)":
        return [
            (
                "Trigger Right Crash and check Right Crash squib deployment: Right Side Airbag, Right Curtain Airbag, Right PT, and Right Lap PT.",
                "All listed Right Crash squibs are deployed.",
            ),
            ("Read DTC and check Right Side Crash and Pretensioner Crash DTCs.", "Side Crash DTC 92 01 00 8B and Pretensioner Crash DTC 92 1A 00 8B are active."),
            ("Check crash signals after Right Crash.", "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=3 (Right), and SCM_CNT increments while STS_CRASH=1."),
        ]
    if crash_type == "Deployment (Left)":
        return [
            (
                "Trigger Left Crash and check Left Crash squib deployment: Left Side Airbag, Left Curtain Airbag, Left PT, and Left Lap PT.",
                "All listed Left Crash squibs are deployed.",
            ),
            ("Read DTC and check Left Side Crash and Pretensioner Crash DTCs.", "Side Crash DTC 92 02 00 8B and Pretensioner Crash DTC 92 1B 00 8B are active."),
            ("Check crash signals after Left Crash.", "DOOR_UNLOCK=1, STS_CRASH=1, CRASH_LOCATION=2 (Left), and SCM_CNT increments while STS_CRASH=1."),
        ]
    raise ValueError(f"Unsupported crash type: {crash_type}")


def make_case(
    priority: str,
    name: str,
    description: str,
    pre_action: str,
    post_action: str,
    steps: list[tuple[str, str]],
) -> dict[str, Any]:
    return {
        "priority": priority,
        "name": name,
        "description": description,
        "pre_action": pre_action,
        "post_action": post_action,
        "steps": steps,
    }


def normal_pre_action() -> str:
    return lines(
        "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
        "2. IGN ON and wait for proveout to complete unless the selected vector explicitly uses CAN wakeup with IGN OFF.",
        "3. Start the required EDR, CAN, sensor, and power evidence capture before the event input.",
    )


def normal_post_action() -> str:
    return lines(
        "1. Retain the EDR, CAN, sensor, diagnostic, and power evidence.",
        "2. Restore the approved normal condition.",
        "3. Do not clear locked EDR data or crash DTCs without separate approval.",
    )


def five_near_crash_case(final_type: str, final_delta: str, final_class: str, bit_mask: str) -> dict[str, Any]:
    name_suffix = {
        "Deployment (Front)": "DeploymentFront",
        "Deployment (Right)": "DeploymentRight",
        "Deployment (Left)": "DeploymentLeft",
    }[final_type]
    return make_case(
        "Highest",
        f"SUBS_EDR_MultiEvent_5NearCrash_{name_suffix}_{final_delta.replace(' ', '')}",
        lines(
            "Validate deployable-event retention and replacement priority after five recorded Near Crash events.",
            "Event 1 through Event 5: Near Crash at 1000 ms between consecutive Near Crash events.",
            f"Event 6: {final_type}, {final_delta} after Event 5 ({final_class}).",
            "The five Near Crash records are expected to remain unlocked when retained. The final deployment record is expected to be locked if it is stored.",
            "The selected EDR slot, replacement order, event numbers, and timing data after Event 4 and later are pending confirmation; record them without assigning pass or fail.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
            ("Trigger five Near Crash events with 1000 ms between consecutive events.", "No squibs are deployed for any Near Crash. For every retained Near Crash record, Record Lock status is 0 and crash/door-unlock notifications are not transmitted."),
            (f"Trigger {final_type} {final_delta} after Event 5.", f"The final event is classified as {final_class}. The selected deployment crash input is captured."),
            ("Check deployment actions, crash DTCs, and crash signals for the final event.", "The final deployment crash actions and notifications are captured using the approved crash-type procedure."),
            ("Read EDR1 and EDR2 repeatedly after the final event and retain full raw record data.", PENDING),
            ("Check Record 1 crash location/type when the final deployment is stored in Record 1.", f"The Record 1 crash location/type bit for {final_type} is {bit_mask}. Record selection and Record 2 applicability are pending confirmation."),
        ],
    )


def priority_sequence_case(
    name: str,
    crash_types: tuple[str, str, str],
    data: dict[str, Any],
    record1_mask: str,
) -> dict[str, Any]:
    description = lines(
        "Simulate three deployable/non-deployable events in the multi-event range.",
        f"Event 1: {crash_types[0]}",
        f"Event 2: {crash_types[1]}",
        f"Event 3: {crash_types[2]}",
        "Keep more than 500 ms and less than 5000 ms between consecutive events.",
        "Verify deployable-event retention, replacement, event numbering, TimeB/W, lifetime number, and record locking.",
    )
    steps: list[tuple[str, str]] = [
        ("Ensure system is fault free and EDR1 and EDR2 contain no data.", "System reports no faults and EDR1 and EDR2 are empty."),
        ("IGN ON and wait for proveout to complete.", "Proveout completes successfully."),
    ]
    for event_number, crash_type in enumerate(crash_types, start=1):
        steps.extend(event_steps(crash_type))
        if event_number == 2:
            steps.append(("Read EDR1 and EDR2 after Event 2 and check recorded data and meta-data.", e2_result(data)))
    steps.extend(
        [
            ("Read EDR1 and EDR2 after Event 3 and check recorded data and meta-data.", e3_result(data)),
            ("Check Record 1 crash location/type for the retained Record 1 event.", f"Record 1 crash location/type bit is {record1_mask}."),
            ("Read sensor data after Event 3.", "Recorded sensor data match the applied inputs for the retained records."),
        ]
    )
    return make_case("Highest", name, description, normal_pre_action(), normal_post_action(), steps)


def vector_text(label: str, data: dict[str, Any]) -> str:
    pattern = "/".join(event_code(data[f"event_{index}"]) for index in (1, 2, 3))
    return lines(
        f"{label} input {pattern}: Event 1={event_name(event_code(data['event_1']))}; Event 2={event_name(event_code(data['event_2']))}; Event 3={event_name(event_code(data['event_3']))}.",
        e2_result(data),
        e3_result(data),
    )


def build_cases(source_data: dict[str, Any]) -> list[tuple[str, list[dict[str, Any]]]]:
    multi_011 = find_vector(source_data, "Multi event", ("0", "1", "1"))
    multi_110 = find_vector(source_data, "Multi event", ("1", "1", "0"))
    multi_lock_vectors = [
        find_vector(source_data, "Multi event", pattern)
        for pattern in (("0", "0", "0"), ("0", "0", "1"), ("0", "1", "0"), ("1", "1", "1"))
    ]
    event_number_vectors = [item for item in source_data["vectors"] if item["family"] == "Single event"]
    event_number_vectors.extend(
        find_vector(source_data, "Multi event", pattern)
        for pattern in (("1", "0", "0"), ("1", "0", "1"))
    )

    retention_cases = [
        five_near_crash_case("Deployment (Front)", "501 ms", "Multi Event", "0x01"),
        five_near_crash_case("Deployment (Right)", "800 ms", "Multi Event", "0x04"),
        five_near_crash_case("Deployment (Left)", "4999 ms", "Multi Event", "0x02"),
        five_near_crash_case("Deployment (Front)", "5001 ms", "Single Event", "0x01"),
        priority_sequence_case(
            "SUBS_EDR_MultiEvent_NearCrash_DeploymentFront_DeploymentRight",
            ("Near Crash", "Deployment (Front)", "Deployment (Right)"),
            multi_011,
            "0x04",
        ),
        priority_sequence_case(
            "SUBS_EDR_MultiEvent_DeploymentFront_DeploymentRight_NearCrash",
            ("Deployment (Front)", "Deployment (Right)", "Near Crash"),
            multi_110,
            "0x01",
        ),
    ]

    battery_case = make_case(
        "Highest",
        "SUBS_EDR_BatteryDisconnect_CompletionStatus",
        lines(
            "Verify completion and data-validity behavior for a Front deployment with battery available and battery disconnect conditions.",
            "Vector A: battery is disconnected before completion of the initial 200 ms data period.",
            "Vector B: battery is disconnected after the initial 200 ms data period completes and before five seconds complete.",
            "Vector C: battery remains available through five seconds after T0.",
            "The value 0xFFFF is retained as a record field value where observed; no semantic meaning is assigned to it.",
        ),
        lines(
            "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
            "2. Use an approved synchronized T0 and power-control measurement method.",
            "3. Use Front deployment for every vector and start power and EDR evidence capture before T0.",
        ),
        lines(
            "1. Restore nominal power through the approved procedure.",
            "2. Read EDR data three times after initialization and retain all power and EDR evidence.",
            "3. Do not clear locked data without separate approval.",
        ),
        [
            ("Select Vector A, Vector B, or Vector C and record T0 and the power transition timing.", "The selected battery condition and measurement uncertainty are recorded."),
            ("Trigger Front Crash and verify the selected Front Crash deployment actions.", "Front Crash deployment is captured. Record 1 Front crash location/type bit is 0x01 when the Front event is stored in Record 1."),
            ("For Vector A, remove battery power before the initial 200 ms data period is completed.", "CompletionStatus=0, 200 ms CompletionStatus=0, and EDR data are not valid."),
            ("For Vector B, remove battery power after the initial 200 ms data period is completed and before five seconds are completed.", "CompletionStatus=0, 200 ms CompletionStatus=1, and EDR data are valid through 200 ms."),
            ("For Vector C, keep battery power available through five seconds after T0.", "CompletionStatus=1, 200 ms CompletionStatus is don't care, and EDR data are valid."),
            ("Read EDR data and completion status after recovery.", "The selected completion-status/data-validity combination is observed. Record write order, atomicity, and recovery behavior beyond this status table remain pending confirmation."),
        ],
    )

    independent_case = make_case(
        "High",
        "SUBS_EDR_IndependentEvent_RequirementValidation",
        lines(
            "Verify independent event behavior and the target Record 1 crash location/type bitfield.",
            "Run all vectors: no event; Domestic Low without side remote sensors with side event; Domestic Mid without side remote sensors with side event; Near Crash; Unconfirmed Crash; and supported Front, Left Side, Right Side, Rear, Understrike, Rollover, and Near crash location/type values.",
            "Record 1 crash location/type masks: Front=0x01, Left Side=0x02, Right Side=0x04, Rear=0x08, Understrike=0x10, Rollover=0x20, Near=0x40.",
            "Execute a physical crash-type vector only when it is supported by the selected configuration. Record 2 bitfield decoding is not evaluated in this case.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select an independent-event vector and establish its required configuration and input condition.", "The selected vector and configuration are recorded."),
            ("For the no-event vector, read EDR data three times without recording an event.", "Every EDR data byte, including reserved bytes, is FF and all three responses are identical."),
            ("For the Domestic Low or Mid without-side-sensor vector, apply the approved side-event input.", "No side-event EDR record is stored."),
            ("For the Near Crash vector, apply a non-deployment Near Crash input.", "A Near Crash record is stored with Record Lock status 0. DOOR_UNLOCK and STS_CRASH are not transmitted."),
            ("For the Unconfirmed Crash vector, provide onboard longitudinal input and set both front remote sensor values to zero.", "The event is classified as Unconfirmed Crash. Record, lock, notification, and delayed-confirmation behavior are pending confirmation."),
            ("For each supported crash-type vector, read the Record 1 crash location/type byte.", "The selected one-bit crash location/type mask matches the listed target mask. Do not apply the mask to an all-FF Record 2 response."),
        ],
    )

    event_number_case = make_case(
        "High",
        "SUBS_EDR_EventNumbering_SingleMulti",
        lines(
            "Verify event numbering, retained event identity, TimeB/W, lifetime number, and end-of-Event-3 record locking for the remaining non-duplicate matrix vectors.",
            "The priority cases already execute multi-event input 0/1/1 and 1/1/0. This case executes all eight single-event input combinations plus multi-event input 1/0/0 and 1/0/1.",
            "Single Event condition: more than 5000 ms between relevant events. Multi Event condition: more than 500 ms and less than 5000 ms between consecutive events.",
            "Selected vector expected results:\n" + "\n\n".join(
                vector_text(f"EVN-{index:02d}", item) for index, item in enumerate(event_number_vectors, start=1)
            ),
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one listed event-numbering vector and record the event types and measured timing class.", "The selected input vector and timing class are recorded."),
            ("Apply Event 1, Event 2, and Event 3 in the selected order.", "All event inputs and timestamps are retained."),
            ("Read EDR1 and EDR2 after Event 2.", "Retained event identity, MultiEvent number, TimeB/W, and lifetime number match the selected vector. End-of-Event-2 lock status is not evaluated."),
            ("Read EDR1 and EDR2 after Event 3.", "Retained event identity, MultiEvent number, TimeB/W, lifetime number, and Record Lock status match the selected vector."),
            ("Retain the raw and decoded EDR evidence for the selected vector.", "The literal TimeB/W field value is retained without assigning an unsupported semantic meaning to 0xFFFF."),
        ],
    )

    record_lock_case = make_case(
        "High",
        "SUBS_EDR_RecordLocking_Validation",
        lines(
            "Verify all End-of-Event-3 record-lock outcomes with minimal multi-event vectors.",
            "Run all vectors: 0/0/0 for lock 0/0; 0/0/1 for lock 1/0; 0/1/0 for lock 0/1; and 1/1/1 for lock 1/1.",
            "Every consecutive event separation is more than 500 ms and less than 5000 ms.",
            "Selected vector expected results:\n" + "\n\n".join(
                vector_text(f"LOCK-{index:02d}", item) for index, item in enumerate(multi_lock_vectors, start=1)
            ),
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one record-lock vector and record all three input event types.", "The selected lock vector is identified before execution."),
            ("Apply the three events with more than 500 ms and less than 5000 ms between consecutive events.", "All input timestamps are retained."),
            ("Read EDR1 and EDR2 after Event 3.", "The selected vector's retained events and Record Lock status values match exactly."),
            ("Repeat until all four lock combinations have been completed.", "Lock outcomes 0/0, 1/0, 0/1, and 1/1 are covered."),
            ("Compare the lock state with the retained event type for each record.", "Every retained Near Crash record has lock 0 and every retained Deployment Event record has lock 1."),
        ],
    )

    power_case = make_case(
        "High",
        "SUBS_EDR_PowerInterruption_AtomicityRecovery",
        lines(
            "Characterize EDR data integrity and recovery for power interruption during every significant recording phase.",
            "Run all phases: before T0; exactly at T0; T0+1 ms; T0+199 ms; T0+200 ms; T0+201 ms; before/during/after CompletionStatus update; pre-crash buffer freeze; record allocation; metadata write; payload write; CRC write; valid-marker update; lock-bit update; lifetime counter update; multi-event counter update; replacement/erase; EDR readout; shutdown preparation; second event; and fourth/fifth event.",
            "Run the approved power conditions across the phase set: hard battery disconnect, IGN OFF with battery retained, battery loss, ground interruption, brownout, slow ramp-down, fast drop, voltage oscillation, short/repeated interruptions, restoration during write, reverse IGN/battery order, and CAN-supply loss.",
            "Record atomicity, persistence, counter association, lock preservation, and next-event readiness. These outcomes are pending confirmation where no write/recovery definition exists.",
        ),
        lines(
            "1. Use only an approved power-control and event-trigger procedure.",
            "2. Record the selected power waveform, interruption phase, T0, event type, and existing EDR state.",
            "3. Do not perform a persistent or destructive operation without separate approval.",
        ),
        normal_post_action(),
        [
            ("Select one interruption phase and one power condition from the listed coverage set.", "The selected phase and power condition are recorded."),
            ("Establish the selected event and EDR recording state.", "The initial record state and event timestamp are captured."),
            ("Apply the selected interruption only through the approved procedure, then restore nominal power.", "The power waveform and interruption instant are retained."),
            ("Read EDR data three times after initialization. Where permitted, perform an approved recovery cycle and reread.", PENDING),
            ("Check for mixed metadata/payload, partial erase, incorrect lock/valid ordering, incorrect counters, and inability to record the next valid event.", PENDING),
        ],
    )

    corrupted_case = make_case(
        "High",
        "SUBS_EDR_CorruptedIncompleteData_Recovery",
        lines(
            "Characterize recovery from corrupted or incomplete EDR data without assuming an undocumented recovery result.",
            "Run all vectors: EDR1 integrity failure; EDR2 integrity failure; missing valid marker; interrupted payload; interrupted replacement/erase; and counter metadata inconsistent with payload.",
            "For every vector, retain raw EDR data before and after initialization and check that no valid record mixes content from different events.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one corrupted/incomplete-data vector and establish it only with an approved method.", "The selected integrity condition and initial record data are retained."),
            ("Initialize the ECU through the approved recovery procedure.", "Initialization state and reset evidence are retained."),
            ("Read EDR1 and EDR2 three times and compare raw and decoded data.", PENDING),
            ("Apply one subsequent valid event where separately authorized.", PENDING),
            ("Check record integrity, lock preservation, event association, and recovery of future recording.", PENDING),
        ],
    )

    extended_case = make_case(
        "Normal",
        "SUBS_EDR_ExtendedMultiEvent_Sequence",
        lines(
            "Exercise extended multi-event sequences beyond three events without duplicating the five-Near-Crash priority cases.",
            "Run all vectors: four-event mixed sequence; five-event mixed sequence; ten-event mixed sequence; configurable N-event sequence; repeated Near Crash stress sequence; and mixed Unconfirmed Crash/Near Crash/Deployment Event sequence.",
            "Use more than 500 ms and less than 5000 ms between events intended as multi events. Record all replacement, counter, lock, and diagnostic behavior as pending confirmation after the third event.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one extended-sequence vector and record its event count, crash types, timing, and initial records.", "The selected sequence is recorded before execution."),
            ("Apply the complete sequence while retaining every event timestamp and all CAN, EDR, and diagnostic evidence.", "All event inputs and observation points are retained."),
            ("Read EDR data after each selected checkpoint and after the final event.", PENDING),
            ("For an unexpected result, reduce the sequence to the smallest reproducible prefix.", "A minimal reproducible sequence is retained for review."),
            ("Record all record replacement, counter, lock, and diagnostic observations after the third event.", PENDING),
        ],
    )

    can_wakeup_case = make_case(
        "High",
        "SUBS_EDR_CANWakeup_MultiParallel_EventMatrix",
        lines(
            "Verify multi-event, parallel-event, and unconfirmed-crash behavior while the ECU is awake through valid CAN wakeup with IGN OFF.",
            "Multi-event vectors: 0/0/0 (Near/Near/Near); 0/0/1 (Near/Near/Front); 0/1/0 (Near/Front/Near); 0/1/1 (Near/Front/Right); 1/0/0 (Front/Near/Near); 1/0/1 (Front/Near/Right); 1/1/0 (Front/Right/Near); 1/1/1 (Front/Right/Left).",
            "For every multi-event vector, keep more than 500 ms and less than 5000 ms between consecutive events. End-of-Event-2 lock status is not evaluated.",
            "Parallel vectors within 500 ms: Front+Left (Record 1 type=0x03); Right+Left (Record 1 type=0x06); Front+Right (Record 1 type=0x05). EDR1 retains the first crash record and every raw EDR2 byte, including reserved bytes, is FF. Do not decode the all-FF EDR2 response as a crash-type bitfield.",
            "Additional vectors: Unconfirmed Crash with only onboard longitudinal input and both front remote sensor values zero; and CAN wakeup before Event 1, at Event 1, and after Event 1 before Event 2 for Near/Front/Right multi-event sequence.",
        ),
        lines(
            "1. Ensure the system is fault free and EDR1 and EDR2 contain no data.",
            "2. Turn IGN OFF and wait until the ECU is ready for CAN wakeup.",
            "3. Send valid CAN wakeup and confirm the ECU wakes while IGN remains OFF.",
            "4. Keep CAN communication available until EDR readout is complete.",
        ),
        normal_post_action(),
        [
            ("Select one CAN-wakeup vector and record the wakeup timing, crash type(s), event timing, and initial EDR state.", "The selected CAN-wakeup vector is recorded."),
            ("Apply valid CAN wakeup while IGN remains OFF.", "The ECU is awake through CAN wakeup and ready for the selected event sequence."),
            ("For a multi-event vector, apply the selected three events with more than 500 ms and less than 5000 ms between consecutive events.", "After Event 2 and Event 3, EDR1/EDR2 retained event data, MultiEvent number, TimeB/W, lifetime number, and End-of-Event-3 lock status match the selected multi-event matrix vector."),
            ("For a parallel vector, apply both deployment crashes within 500 ms and read full raw EDR1 and EDR2 responses.", "EDR1 retains the first crash record. Every raw EDR2 byte, including reserved bytes, is FF. Record 1 crash location/type bit is 0x03, 0x06, or 0x05 for the selected pair."),
            ("For the Unconfirmed Crash vector, apply onboard longitudinal input only and both front remote sensor values at zero.", "The event is classified as Unconfirmed Crash. Downstream record, lock, notification, and sensor-data behavior are pending confirmation."),
            ("For the wakeup-timing vector, run CAN wakeup before Event 1, at Event 1, and after Event 1 before Event 2.", PENDING),
            ("Read EDR, sensor data, crash signals, and diagnostic evidence while CAN wakeup remains active.", "All selected observations are retained without assuming an undocumented wakeup race outcome."),
        ],
    )

    can_quality_case = make_case(
        "Normal",
        "SUBS_EDR_CANDataQuality_OnFail",
        lines(
            "Characterize recorded CAN data quality and failure behavior for EDR events.",
            "Run all vectors: valid range; missing, delayed, jittered, wrong-cycle-time, duplicate, and out-of-order frames; rolling-counter error; CRC error; raw overflow; invalid enum; multiplexer error; timeout; stuck value; unavailable signal; fail-safe value; sample-point change; cross-signal consistency; bus-off/recovery; and CAN-supply loss.",
            "Before execution, confirm the selected signal, message, valid-value range, timing, failure reaction, and expected recorded representation. Do not convert an undocumented failure reaction into a pass/fail result.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one CAN data-quality vector and identify the exact signal, message, validity state, timing, and expected recorded representation.", "The selected communication condition is fully defined before execution."),
            ("Apply the selected CAN condition around the EDR event and capture CAN timestamps.", "CAN frames, signal values, validity state, and event timing are retained."),
            ("Read and decode EDR data after the required observation interval.", PENDING),
            ("Compare data value, scaling, range, age, failure reaction, and cross-signal consistency with the confirmed target behavior.", PENDING),
            ("Retain the CAN and EDR evidence and restore the approved normal condition.", "The selected CAN-data-quality observation is available for review without claiming an undocumented on-fail result."),
        ],
    )

    diagnostic_case = make_case(
        "Normal",
        "SUBS_EDR_DiagnosticConsistency_DataIntegrity",
        lines(
            "Characterize EDR diagnostic read consistency and data integrity.",
            "Run all vectors: read during capture; read during write or recovery; repeated and concurrent reads; reset during read; invalid data identifier/request length/access condition; and record association/endian/stale-data/mixed-record checks.",
            "Confirm the diagnostic request, access conditions, response layout, error behavior, and timing before execution. Do not assume an undocumented request or response byte.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one diagnostic vector and establish the required capture, write, reset, or concurrent-read state.", "The selected diagnostic and EDR state is recorded."),
            ("Send the confirmed diagnostic request sequence and capture raw request/response timing.", "Raw diagnostic evidence is retained."),
            ("Repeat or overlap requests as required by the selected vector.", PENDING),
            ("Check record association, response consistency, stale-data absence, and mixed-record absence.", PENDING),
            ("Retain the diagnostic and EDR evidence, then restore the approved normal condition.", "The observation is retained without assuming an undocumented diagnostic response or error code."),
        ],
    )

    timing_case = make_case(
        "Normal",
        "SUBS_EDR_TimingBoundary_ParallelMultiSingle",
        lines(
            "Verify timing classification boundaries after all higher-priority record-retention, power, locking, numbering, and robustness cases.",
            "Parallel vectors: 0 ms, 1 ms, and exactly 500 ms. EDR1 retains the first crash record and every raw EDR2 byte, including reserved bytes, is FF.",
            "Multi-event vectors: 501 ms, 800 ms, 801 ms, and 4999 ms. Use the multi-event allocation matrix and do not evaluate End-of-Event-2 lock status.",
            "Exactly 5000 ms is unclassified. Record behavior only; do not assign pass or fail.",
            "Single-event vector: 5001 ms. Use the single-event allocation matrix and do not evaluate End-of-Event-2 lock status.",
        ),
        normal_pre_action(),
        normal_post_action(),
        [
            ("Select one timing-boundary vector and record the timing measurement uncertainty.", "The selected separation and timing evidence are recorded."),
            ("Apply the selected two-event or three-event sequence at the exact timing boundary.", "Every event timestamp is retained."),
            ("For 0 ms, 1 ms, and 500 ms, read full raw EDR1 and EDR2 responses after the parallel pair.", "EDR1 retains the first crash record and every raw EDR2 byte, including reserved bytes, is FF."),
            ("For 501 ms, 800 ms, 801 ms, and 4999 ms, read EDR data using the multi-event observation matrix.", "The selected vector is classified as Multi Event. End-of-Event-2 record allocation fields match the multi-event matrix; End-of-Event-2 lock status is not evaluated."),
            ("For exactly 5000 ms, record the observed EDR behavior without assigning a pass or fail result.", PENDING),
            ("For 5001 ms, read EDR data using the single-event observation matrix.", "The selected vector is classified as Single Event. End-of-Event-2 record allocation fields match the single-event matrix; End-of-Event-2 lock status is not evaluated."),
        ],
    )

    return [
        ("SUBS_EDR_DEPLOYABLE_VS_NEAR_REPLACEMENT", retention_cases),
        ("SUBS_EDR_BATTERY_DISCONNECT", [battery_case]),
        ("SUBS_EDR_INDEPENDENT_EVENT_VALIDATION", [independent_case]),
        ("SUBS_EDR_EVENT_NUMBERING", [event_number_case]),
        ("SUBS_EDR_RECORD_LOCKING", [record_lock_case]),
        ("SUBS_EDR_POWER_INTERRUPTION", [power_case]),
        ("SUBS_EDR_CORRUPTED_INCOMPLETE_DATA", [corrupted_case]),
        ("SUBS_EDR_EXTENDED_MULTI_EVENT", [extended_case]),
        ("SUBS_EDR_REMAINING_ROBUSTNESS_NEGATIVE", [can_wakeup_case, can_quality_case, diagnostic_case]),
        ("SUBS_EDR_TIMING_BOUNDARIES", [timing_case]),
    ]


def apply_style(cell: Any) -> None:
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)


def append_row(sheet: Any, values: list[Any], styles: list[Any], height: float) -> int:
    row_number = sheet.max_row + 1
    for column_number, value in enumerate(values, start=1):
        cell = sheet.cell(row_number, column_number, value)
        cell._style = copy(styles[column_number - 1])
        apply_style(cell)
    sheet.row_dimensions[row_number].height = height
    return row_number


def write_export(workbook: Any, groups: list[tuple[str, list[dict[str, Any]]]]) -> list[str]:
    sheet = workbook["Export"]
    headers = [sheet.cell(1, column_number).value for column_number in range(1, 8)]
    if headers != EXPORT_HEADERS:
        raise ValueError("The legacy Export layout does not have the required seven headers.")
    group_styles = [copy(sheet.cell(2, column_number)._style) for column_number in range(1, 8)]
    primary_styles = [copy(sheet.cell(3, column_number)._style) for column_number in range(1, 8)]
    continuation_styles = [copy(sheet.cell(4, column_number)._style) for column_number in range(1, 8)]
    if sheet.max_row > 1:
        sheet.delete_rows(2, sheet.max_row - 1)

    ordered_names: list[str] = []
    for group_name, cases in groups:
        append_row(sheet, ["Normal", group_name, None, None, None, None, None], group_styles, 24)
        for case in cases:
            ordered_names.append(case["name"])
            first_action, first_expected = case["steps"][0]
            primary_row = append_row(
                sheet,
                [
                    case["priority"],
                    case["name"],
                    case["description"],
                    case["pre_action"],
                    case["post_action"],
                    first_action,
                    first_expected,
                ],
                primary_styles,
                min(460, max(135, 15 * (8 + len(case["description"]) // 180))),
            )
            name_cell = sheet.cell(primary_row, 2)
            name_cell.fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
            name_cell.font = Font(bold=True, color="000000")
            for action, expected in case["steps"][1:]:
                continuation_row = append_row(sheet, [None, None, None, None, None, action, expected], continuation_styles, 66)
                if action.startswith("Turn IGN OFF") or action.startswith("Apply valid CAN wakeup"):
                    for column_number in range(6, 8):
                        sheet.cell(continuation_row, column_number).fill = PatternFill("solid", fgColor=PALE_BLUE)
            sheet.row_dimensions[primary_row].height = min(460, max(145, 15 * (9 + len(case["description"]) // 165)))

    for column_number in range(1, 8):
        header = sheet.cell(1, column_number)
        header.fill = PatternFill("solid", fgColor=NAVY)
        header.font = Font(bold=True, color=WHITE)
        header.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        apply_style(header)
    sheet.row_dimensions[1].height = 26
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:G{sheet.max_row}"
    sheet.sheet_view.showGridLines = False
    return ordered_names


def remove_comments_and_hyperlinks(workbook: Any) -> None:
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.comment is not None:
                    cell.comment = None
                if cell.hyperlink is not None:
                    cell.hyperlink = None


FORBIDDEN_VISIBLE_TEXT = (
    "edr_requirements",
    "edr_record_logic_multi_and_single_events.md",
    "ice_common_srs_v1.4_diag_re.xlsx",
    "legacy_edr_spec_covering",
    "common_edr_canc_0455_045b_u171_m314_v7_authoring.xlsx",
    "project_testcases",
    "docs\\",
    "c:\\",
    ".xlsx",
    ".csv",
    ".json",
    ".md",
)


def visible_reference_findings(workbook: Any) -> list[str]:
    findings: list[str] = []
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and any(token in cell.value.lower() for token in FORBIDDEN_VISIBLE_TEXT):
                    findings.append(f"{sheet.title}!{cell.coordinate}")
                if cell.comment is not None:
                    findings.append(f"comment at {sheet.title}!{cell.coordinate}")
                if cell.hyperlink is not None:
                    findings.append(f"hyperlink at {sheet.title}!{cell.coordinate}")
    return findings


def package_reference_findings(path: Path) -> list[str]:
    forbidden = (
        "edr_requirements",
        "edr_record_logic_multi_and_single_events.md",
        "ice_common_srs_v1.4_diag_re.xlsx",
        "legacy_edr_spec_covering",
        "c:\\framework_ioem_py",
    )
    findings: list[str] = []
    with ZipFile(path) as archive:
        for member in archive.namelist():
            if member.endswith((".xml", ".rels")):
                content = archive.read(member).decode("utf-8", errors="ignore").lower()
                if any(token in content for token in forbidden):
                    findings.append(member)
    return findings


def expected_case_names(groups: list[tuple[str, list[dict[str, Any]]]]) -> list[str]:
    return [case["name"] for _, cases in groups for case in cases]


def validate_workbook(path: Path, groups: list[tuple[str, list[dict[str, Any]]]]) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"V3 workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=False)
    if workbook.sheetnames != ["Export", "ChoiceValues"]:
        raise ValueError(f"V3 must preserve the legacy two-sheet structure, found {workbook.sheetnames}")
    export = workbook["Export"]
    headers = [export.cell(1, column_number).value for column_number in range(1, 8)]
    if headers != EXPORT_HEADERS:
        raise ValueError("V3 Export headers differ from the legacy specification structure.")
    expected_groups = [group_name for group_name, _ in groups]
    observed_group_rows = [
        str(export.cell(row_number, 2).value)
        for row_number in range(2, export.max_row + 1)
        if export.cell(row_number, 2).value in expected_groups
    ]
    if observed_group_rows != expected_groups:
        raise ValueError(f"V3 group priority order is incorrect: {observed_group_rows}")
    expected_names = expected_case_names(groups)
    observed_case_rows = [
        row_number
        for row_number in range(2, export.max_row + 1)
        if isinstance(export.cell(row_number, 2).value, str) and export.cell(row_number, 2).value.startswith("SUBS_EDR_")
        and export.cell(row_number, 2).value not in expected_groups
    ]
    observed_names = [str(export.cell(row_number, 2).value) for row_number in observed_case_rows]
    if observed_names != expected_names:
        raise ValueError("V3 case order does not match the required priority ordering.")
    if len(observed_names) != 17:
        raise ValueError(f"Expected 17 optimized V3 authoring cases, found {len(observed_names)}.")
    highlighted_names = 0
    detailed_steps: dict[str, int] = {}
    for index, row_number in enumerate(observed_case_rows):
        name = observed_names[index]
        cell = export.cell(row_number, 2)
        if cell.fill.fill_type == "solid" and (cell.fill.fgColor.rgb or "").endswith(HIGHLIGHT_YELLOW):
            highlighted_names += 1
        else:
            raise ValueError(f"V3 case name is not yellow highlighted: {name}")
        if not export.cell(row_number, 3).value or not export.cell(row_number, 4).value or not export.cell(row_number, 5).value:
            raise ValueError(f"V3 case is missing description or pre/post action: {name}")
        next_case_row = observed_case_rows[index + 1] if index + 1 < len(observed_case_rows) else export.max_row + 1
        step_count = sum(
            1
            for candidate_row in range(row_number, next_case_row)
            if export.cell(candidate_row, 6).value not in (None, "")
        )
        detailed_steps[name] = step_count
        if step_count < 5:
            raise ValueError(f"V3 case has too few detailed steps: {name}")
    five_near_names = [name for name in observed_names if "5NearCrash" in name]
    if len(five_near_names) != 4:
        raise ValueError("V3 must contain exactly four five-Near-Crash final-deployment cases.")
    expected_five_near_fragments = ("DeploymentFront_501ms", "DeploymentRight_800ms", "DeploymentLeft_4999ms", "DeploymentFront_5001ms")
    if not all(any(fragment in name for name in five_near_names) for fragment in expected_five_near_fragments):
        raise ValueError("V3 five-Near-Crash cases do not cover the required crash types and timing classes.")
    can_wakeup_name = "SUBS_EDR_CANWakeup_MultiParallel_EventMatrix"
    if can_wakeup_name not in observed_names:
        raise ValueError("V3 CAN-wakeup multi/parallel coverage case is missing.")
    can_wakeup_row = export.cell(observed_case_rows[observed_names.index(can_wakeup_name)], 3).value
    for phrase in ("0x03", "0x06", "0x05", "every raw EDR2 byte", "more than 500 ms and less than 5000 ms"):
        if phrase not in str(can_wakeup_row):
            raise ValueError(f"V3 CAN-wakeup case is missing corrected target behavior: {phrase}")
    timing_name = "SUBS_EDR_TimingBoundary_ParallelMultiSingle"
    timing_row = export.cell(observed_case_rows[observed_names.index(timing_name)], 3).value
    for phrase in ("0 ms", "1 ms", "500 ms", "501 ms", "800 ms", "801 ms", "4999 ms", "5000 ms", "5001 ms"):
        if phrase not in str(timing_row):
            raise ValueError(f"V3 timing case is missing boundary {phrase}")
    reference_findings = visible_reference_findings(workbook)
    if reference_findings:
        raise ValueError(f"V3 contains external reference text: {reference_findings[:10]}")
    package_findings = package_reference_findings(path)
    if package_findings:
        raise ValueError(f"V3 package contains external reference residue: {package_findings}")
    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "primary_sheet": "Export",
        "legacy_headers_preserved": True,
        "prioritized_authoring_case_count": len(observed_names),
        "yellow_highlighted_case_names": highlighted_names,
        "five_near_crash_final_deployment_cases": five_near_names,
        "can_wakeup_multi_parallel_case_present": True,
        "timing_boundary_case_present": True,
        "minimum_detailed_steps": min(detailed_steps.values()),
        "visible_external_references": 0,
        "package_reference_residue": 0,
    }


def generate() -> dict[str, Any]:
    if not LEGACY_TEMPLATE.is_file():
        raise FileNotFoundError(f"Legacy template is unavailable: {LEGACY_TEMPLATE}")
    validate_target_reference()
    source_data = inspect_source()
    groups = build_cases(source_data)
    ordered_names = expected_case_names(groups)
    if len(ordered_names) != len(set(ordered_names)):
        raise ValueError("V3 authoring case names are not unique.")
    VERSION_DIRECTORY.mkdir(parents=True, exist_ok=True)
    copy2(LEGACY_TEMPLATE, OUTPUT_WORKBOOK)
    workbook = load_workbook(OUTPUT_WORKBOOK, data_only=False, read_only=False)
    written_names = write_export(workbook, groups)
    if written_names != ordered_names:
        raise ValueError("V3 writer changed the required case ordering.")
    remove_comments_and_hyperlinks(workbook)
    workbook.properties.title = "EDR Prioritized Record Logic and CAN Wakeup Specification V3"
    workbook.properties.subject = "Standalone prioritized EDR review specification"
    workbook.properties.creator = "EDR Test Team"
    workbook.properties.description = "V3 standalone legacy-format review specification."
    workbook.save(OUTPUT_WORKBOOK)
    workbook.close()
    validation = validate_workbook(OUTPUT_WORKBOOK, groups)
    report = {
        "version": "V3",
        "status": "Review",
        "format": "Legacy two-sheet Export and ChoiceValues structure with prioritized continuation-step rows.",
        "authoring_case_count": validation["prioritized_authoring_case_count"],
        "priority_order": [group_name for group_name, _ in groups],
        "five_near_crash_coverage": validation["five_near_crash_final_deployment_cases"],
        "target_rules_applied": [
            "Parallel: delta_t less than or equal to 500 ms; EDR1 retains first crash and full raw EDR2 is FF.",
            "Multi: delta_t strictly greater than 500 ms and strictly less than 5000 ms, including 501 through 800 ms.",
            "Single: delta_t strictly greater than 5000 ms.",
            "Exactly 5000 ms: characterization only, no pass/fail oracle.",
            "End-of-Event-2 lock status is not asserted.",
            "Record 1 crash location/type bit masks are applied only where defined.",
        ],
        "standalone_content": "No external workbook, requirement sheet, file path, or script reference is written into the specification.",
        "validation": validation,
        "generation_date": date.today().isoformat(),
    }
    OUTPUT_REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate the prioritized V3 legacy-format EDR test specification.")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--generate", action="store_true", help="Create the V3 review workbook.")
    action.add_argument("--validate", action="store_true", help="Validate the existing V3 review workbook.")
    arguments = parser.parse_args()
    validate_target_reference()
    source_data = inspect_source()
    groups = build_cases(source_data)
    report = generate() if arguments.generate else validate_workbook(OUTPUT_WORKBOOK, groups)
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())