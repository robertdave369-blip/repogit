from __future__ import annotations

import functools
import importlib.util
from pathlib import Path
import re
import sys
import unittest
from types import ModuleType


REPO_ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = REPO_ROOT / "shared_libraries" / "crash_configuration.py"
RUNNER_PATH = REPO_ROOT / ".github" / "skills" / "edr-rsu-curve-generation" / "scripts" / "edr_curve_runner.py"


def load(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


CRASH_CONFIGURATION = load("crash_configuration", MODULE_PATH)
RUNNER = load("edr_curve_runner", RUNNER_PATH)

# Onboard sign at the ECU input (curve sign x inversion) per framework rule R2 (AUTOSAR axis).
R2_ONBOARD_SIGN = {"front": ("X", -1), "rear": ("X", 1), "left": ("Y", -1), "right": ("Y", 1), "near": ("X", -1)}
# Not regenerated: a copy of the right crash kept until underbody curves are delivered.
PLACEHOLDER_KEYS = {("M310_M314_M110", "understrike")}
# Open: W610 has recordings but no confirmed inversions; W616 has no RSU map.
EMPTY_PROJECTS = {"W610", "W616"}
SAMPLE_MS = 0.5
EVENT_SAMPLES = 600


@functools.lru_cache(maxsize=None)
def curve(path: str) -> tuple[float, ...]:
    return tuple(float(line) for line in Path(path).read_text().splitlines() if line.strip())


def merged_set(key: str) -> tuple[tuple[str, ...], tuple[int, ...]] | None:
    return CRASH_CONFIGURATION.MULTI_EVENT_SETS.get(CRASH_CONFIGURATION.MULTI_EVENT_ALIASES.get(key, key))


def merged_folder(key: str) -> Path:
    return Path(CRASH_CONFIGURATION.MULTI_EVENT_TEST_DATA_DIR) / f"multi_crash_{key}"


def merged_t0s(folder: Path) -> list[int]:
    summary = (folder / "multi_event_summary.txt").read_text()
    return [int(t0) for t0 in re.findall(r"merged T0 sample (\d+)", summary)]


def onboard(entry: dict, axis: str) -> tuple[tuple[float, ...], int]:
    for path, inverted in entry["SPI"]:
        if f"Central_Acc_{axis}" in Path(path).name:
            return curve(path), -1 if inverted else 1
    raise AssertionError(f"no onboard {axis} curve in {entry['SPI']}")


def sign(values) -> int:
    total = sum(values)
    return (total > 0) - (total < 0)


class CrashConfigurationTests(unittest.TestCase):
    def configured(self):
        for project, table in CRASH_CONFIGURATION.PROJECT_CRASH_CURVE_CONFIGS.items():
            for key, entry in table.items():
                if (project, key) not in PLACEHOLDER_KEYS:
                    yield project, key, entry

    def test_every_channel_loads_a_numeric_curve_of_one_length(self) -> None:
        for project, key, entry in self.configured():
            specs = list(entry["RSU"].items()) + list(enumerate(entry["SPI"]))
            lengths = set()
            for channel, (path, _) in specs:
                with self.subTest(project=project, crash=key, channel=channel):
                    self.assertTrue(path and Path(path).is_file(), f"{path}")
                    self.assertTrue(curve(path))
                    lengths.add(len(curve(path)))
            with self.subTest(project=project, crash=key, part="SPI and lengths"):
                self.assertEqual(len(entry["SPI"]), 4)
                self.assertEqual(len(lengths), 1, lengths)

    def test_onboard_signs_follow_r2(self) -> None:
        for project, key, entry in self.configured():
            if key in R2_ONBOARD_SIGN:
                events = [(key, 0, None)]
            elif (merged := merged_set(key)) is not None:
                crashes = merged[0]
                t0s = merged_t0s(Path(entry["SPI"][0][0]).parent)
                self.assertEqual(len(t0s), len(crashes))
                events = [(crash, t0, t0 + EVENT_SAMPLES) for crash, t0 in zip(crashes, t0s)]
            else:
                self.fail(f"{project}/{key}: no R2 expectation")
            for crash, start, end in events:
                axis, expected = R2_ONBOARD_SIGN[crash]
                samples, factor = onboard(entry, axis)
                with self.subTest(project=project, crash=key, event=crash, t0=start):
                    self.assertEqual(sign(samples[start:end]) * factor, expected)

    def test_curves_are_positive_except_opposite_events_on_one_axis(self) -> None:
        # The user's rule: curves are positive; only a merged set holding both directions on an
        # onboard axis carries the later direction negated on that axis.
        folders = {Path(entry["SPI"][0][0]).parent: merged_set(key) for _, key, entry in self.configured()}
        for folder, merged in folders.items():
            directions = {R2_ONBOARD_SIGN[event] for event in (merged[0] if merged else ())}
            for path in folder.glob("*.txt"):
                if "summary" in path.name:
                    continue
                axis = next((axis for axis in "XY" if f"Central_Acc_{axis}" in path.name), None)
                may_be_negative = axis is not None and {(axis, -1), (axis, 1)} <= directions
                with self.subTest(folder=folder.name, curve=path.name):
                    if not may_be_negative:
                        self.assertGreaterEqual(min(curve(str(path))), 0)

    def test_merged_sets_have_their_event_class(self) -> None:
        engine = RUNNER.load_engine()
        for key, (events, delays) in CRASH_CONFIGURATION.MULTI_EVENT_SETS.items():
            folder = merged_folder(key)
            summary = (folder / "multi_event_summary.txt").read_text()
            t0s = merged_t0s(folder)
            gaps_ms = [(after - before) * SAMPLE_MS for before, after in zip(t0s, t0s[1:])]
            length = len(curve(str(folder / "Sensor_With_0_values.txt")))
            # Synthetic events hold their acceleration to the last sample (analysis F8), so an event
            # still running there ends after the curve: count that as the curve's length.
            ends = [RUNNER.always_on_end_of_event(engine, folder, t0)["end_of_event_sample"] or length
                    for t0 in t0s[:-1]]
            kind = key.split("_")[0]
            with self.subTest(merged=key):
                self.assertIn(f"Event Sequence: {' -> '.join(events)}", summary)
                self.assertEqual(gaps_ms, list(delays))
                if kind == "parallel":
                    # The next T0 falls while the first event still runs (before its end of event).
                    self.assertLess(t0s[1], ends[0])
                    self.assertLessEqual(gaps_ms[0], 500)
                elif kind == "concatenated":
                    # After the first event's end, inside its 5 s capture window, below both
                    # multi-event lower limits (500 ms record-allocation rule, 800 ms KB 2.7).
                    self.assertLess(ends[0], t0s[1])
                    self.assertLessEqual(gaps_ms[0], 500)
                else:
                    self.assertTrue(all(end < t0 for end, t0 in zip(ends, t0s[1:])), (ends, t0s))
                    if kind == "multi":
                        self.assertTrue(all(800 < gap < 5000 for gap in gaps_ms), gaps_ms)
                    elif kind == "single":
                        self.assertTrue(all(gap > 5000 for gap in gaps_ms), gaps_ms)
                    else:
                        self.assertEqual(kind, "boundary")
                        self.assertEqual(f"{gaps_ms[0]:g}ms", key.rsplit("_", 1)[1])

    def test_every_filled_project_has_every_merged_set(self) -> None:
        names = set(CRASH_CONFIGURATION.MULTI_EVENT_SETS) | set(CRASH_CONFIGURATION.MULTI_EVENT_ALIASES)
        for project, table in CRASH_CONFIGURATION.PROJECT_CRASH_CURVE_CONFIGS.items():
            with self.subTest(project=project):
                if project in EMPTY_PROJECTS:
                    self.assertEqual(table, {})
                else:
                    self.assertLessEqual(names, set(table))

    def test_m310_m314_m110_crash_keys_and_channels(self) -> None:
        config = CRASH_CONFIGURATION.get_project_crash_curve_config("M310_M314_M110")
        self.assertEqual(
            set(config),
            {"front", "left", "right", "rear", "near", "understrike"}
            | set(CRASH_CONFIGURATION.MULTI_EVENT_SETS) | set(CRASH_CONFIGURATION.MULTI_EVENT_ALIASES),
        )
        for key, entry in config.items():
            with self.subTest(crash=key):
                self.assertEqual(list(entry["RSU"]), [f"RSU_CH{index}" for index in range(1, 22)])


if __name__ == "__main__":
    unittest.main()
