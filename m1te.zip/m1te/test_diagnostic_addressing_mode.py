from types import SimpleNamespace

from shared_libraries import jscript_translation


def test_set_diagnostic_addressing_mode_uses_selected_bus(monkeypatch):
    calls = []

    class Uds:
        @staticmethod
        def change_can_request_id(channel_id, request_id):
            calls.append(("request", channel_id, request_id))
            return True

        @staticmethod
        def change_can_response_id(channel_id, response_id):
            calls.append(("response", channel_id, response_id))
            return True

    configuration = SimpleNamespace(
        get_uds_channel_id=lambda channel_name: {
            "CANFD": "canfd-uds-id",
            "HSCAN": "hscan-uds-id",
        }[channel_name]
    )
    api = SimpleNamespace(
        Configuration=configuration,
        Diagnostics=SimpleNamespace(Uds=Uds()),
    )
    monkeypatch.setattr(jscript_translation, "Api", api)
    monkeypatch.setattr(jscript_translation, "diagChannels", ["CANFD", "HSCAN"])
    monkeypatch.setattr(jscript_translation, "_runtime_initialized", True)

    result = jscript_translation.CAN.SetDiagnosticAdressingMode(
        "HSCAN", 0x7F1, 0x7F9
    )

    assert result == "Addressing ID changed to 2033 and response ID change to 2041"
    assert calls == [
        ("request", "hscan-uds-id", 0x7F1),
        ("response", "hscan-uds-id", 0x7F9),
    ]


def test_set_diagnostic_addressing_mode_accepts_legacy_channel_id(monkeypatch):
    calls = []

    class Uds:
        @staticmethod
        def change_can_request_id(channel_id, request_id):
            calls.append(("request", channel_id, request_id))
            return True

        @staticmethod
        def change_can_response_id(channel_id, response_id):
            calls.append(("response", channel_id, response_id))
            return True

    api = SimpleNamespace(
        Diagnostics=SimpleNamespace(Uds=Uds()),
    )
    monkeypatch.setattr(jscript_translation, "Api", api)
    monkeypatch.setattr(jscript_translation, "_runtime_initialized", True)

    jscript_translation.CAN.SetDiagnosticAdressingMode(2, 0x7F1, 0x7F9)

    assert calls == [
        ("request", 2, 0x7F1),
        ("response", 2, 0x7F9),
    ]