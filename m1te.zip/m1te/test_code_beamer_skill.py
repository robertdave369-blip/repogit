from __future__ import annotations

import importlib
import secrets
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any, cast

SKILL_SCRIPTS = (
    Path(__file__).resolve().parents[1]
    / ".github"
    / "skills"
    / "code-beamer"
    / "scripts"
)
sys.path.insert(0, str(SKILL_SCRIPTS))

_client_module = cast(Any, importlib.import_module("codebeamer_client"))
_operations_module = cast(Any, importlib.import_module("codebeamer_operations"))
_cli_module = cast(Any, importlib.import_module("codebeamer_cli"))
_report_module = cast(Any, importlib.import_module("render_tracker_report"))

CodebeamerClient = _client_module.CodebeamerClient
CodebeamerConfig = _client_module.CodebeamerConfig
CodebeamerConflictError = _client_module.CodebeamerConflictError
CodebeamerScopeError = _client_module.CodebeamerScopeError
apply_mutation_plan = _operations_module.apply_mutation_plan
build_mutation_plan = _operations_module.build_mutation_plan
load_mutation_plan = _operations_module.load_mutation_plan
write_mutation_plan = _operations_module.write_mutation_plan
build_argument_parser = _cli_module.build_argument_parser
render_tracker_report = _report_module.render_tracker_report


class FakeResponse:
    """Minimal response fake used to exercise local mutation safeguards."""

    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload
        self.headers: dict[str, str] = {}

    def json(self) -> Any:
        return self._payload


class FakeSession:
    """Record requests without allowing any live Codebeamer traffic."""

    def __init__(self, responses: list[FakeResponse]) -> None:
        self.auth: object | None = None
        self.headers: dict[str, str] = {}
        self.requests: list[dict[str, Any]] = []
        self.responses = responses

    def request(self, method: str, url: str, **kwargs: Any) -> FakeResponse:
        self.requests.append({"method": method, "url": url, **kwargs})
        if not self.responses:
            raise AssertionError("Unexpected HTTP request")
        return self.responses.pop(0)

    def close(self) -> None:
        pass


class CodebeamerSkillTests(unittest.TestCase):
    """Offline validation for the self-contained code-beamer skill."""

    def setUp(self) -> None:
        self.username = f"test-user-{secrets.token_hex(8)}"
        self.password = secrets.token_urlsafe(24)
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary_directory.cleanup)

    def _client(
        self,
        responses: list[FakeResponse],
    ) -> tuple[Any, FakeSession]:
        dotenv_path = Path(self.temporary_directory.name) / ".env"
        dotenv_path.write_text(
            "\n".join(
                (
                    "CODEBEAMER_URL=https://codebeamer.example.test/api/v3",
                    f"CODEBEAMER_USERNAME={self.username}",
                    f"CODEBEAMER_PASSWORD={self.password}",
                    "",
                )
            ),
            encoding="utf-8",
        )
        session = FakeSession(responses)
        config = CodebeamerConfig.from_dotenv(dotenv_path)
        return CodebeamerClient(config, session), session

    def test_mutation_methods_use_verified_routes(self) -> None:
        client, session = self._client(
            [
                FakeResponse(201, {"id": 101}),
                FakeResponse(200, {"id": 101}),
                FakeResponse(201, {"id": 12}),
                FakeResponse(200, {"id": 12}),
            ]
        )

        client.create_item(12, {"name": "New requirement"})
        client.update_item(101, {"id": 101, "name": "Updated requirement"})
        client.create_tracker(1, {"name": "Requirements", "keyName": "REQ"})
        client.update_tracker(12, {"id": 12, "name": "Updated tracker"})

        self.assertEqual(
            [(request["method"], request["url"]) for request in session.requests],
            [
                ("POST", "https://codebeamer.example.test/api/v3/trackers/12/items"),
                ("PUT", "https://codebeamer.example.test/api/v3/items/101"),
                ("POST", "https://codebeamer.example.test/api/v3/projects/1/trackers"),
                ("PUT", "https://codebeamer.example.test/api/v3/trackers/12"),
            ],
        )
        self.assertTrue(
            all(request["allow_redirects"] is False for request in session.requests)
        )
        self.assertTrue(
            all(self.username not in request["url"] for request in session.requests)
        )
        self.assertTrue(
            all(self.password not in request["url"] for request in session.requests)
        )

    def test_list_tracker_items_supports_codebeamer_item_refs(self) -> None:
        client, session = self._client(
            [
                FakeResponse(
                    200,
                    {"itemRefs": [{"id": 101}, {"id": 102}], "hasMore": False},
                )
            ]
        )

        items = client.list_tracker_items(12)

        self.assertEqual([item["id"] for item in items], [101, 102])
        self.assertEqual(session.requests[0]["method"], "GET")

    def test_list_tracker_item_details_verifies_returned_ownership(self) -> None:
        client, session = self._client(
            [
                FakeResponse(
                    200,
                    {"itemRefs": [{"id": 101}], "hasMore": False},
                ),
                FakeResponse(
                    200,
                    {
                        "id": 101,
                        "name": "Requirement",
                        "tracker": {"id": 12},
                        "status": {"name": "In_Review"},
                    },
                ),
            ]
        )

        items = client.list_tracker_item_details(12)

        self.assertEqual(items[0]["status"]["name"], "In_Review")
        self.assertEqual(
            [request["url"] for request in session.requests],
            [
                "https://codebeamer.example.test/api/v3/trackers/12/items",
                "https://codebeamer.example.test/api/v3/items/101",
            ],
        )

    def test_plan_requires_exact_approval_and_rechecks_item(self) -> None:
        current_item = {
            "id": 101,
            "tracker": {"id": 12},
            "name": "Before",
            "version": 3,
        }
        client, session = self._client(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(200, current_item),
            ]
        )
        plan = build_mutation_plan(
            client,
            operation="update-item",
            project_id=1,
            tracker_id=12,
            item_id=101,
            payload={"id": 101, "name": "After"},
        )

        with self.assertRaises(CodebeamerScopeError):
            apply_mutation_plan(client, plan, approval_token="not-the-plan-id")
        self.assertEqual(
            [request["method"] for request in session.requests],
            ["GET", "GET", "GET"],
        )

        session.responses.extend(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(200, current_item),
                FakeResponse(200, {"id": 101}),
            ]
        )
        result = apply_mutation_plan(client, plan, approval_token=plan.plan_id)

        self.assertEqual(result.response["id"], 101)
        self.assertEqual(
            [request["method"] for request in session.requests],
            ["GET", "GET", "GET", "GET", "GET", "GET", "PUT"],
        )
        self.assertEqual(session.requests[-1]["json"], {"id": 101, "name": "After"})

    def test_apply_blocks_stale_item_before_write(self) -> None:
        client, session = self._client(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(
                    200,
                    {"id": 101, "tracker": {"id": 12}, "name": "Before"},
                ),
            ]
        )
        plan = build_mutation_plan(
            client,
            operation="update-item",
            project_id=1,
            tracker_id=12,
            item_id=101,
            payload={"id": 101, "name": "After"},
        )
        session.responses.extend(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
                FakeResponse(
                    200,
                    {"id": 101, "tracker": {"id": 12}, "name": "Changed"},
                ),
            ]
        )

        with self.assertRaises(CodebeamerConflictError):
            apply_mutation_plan(client, plan, approval_token=plan.plan_id)

        self.assertEqual(session.requests[-1]["method"], "GET")
        self.assertNotIn("PUT", [request["method"] for request in session.requests])

    def test_plan_rejects_credentials_before_network_access(self) -> None:
        client, session = self._client([])

        with self.assertRaises(CodebeamerScopeError):
            build_mutation_plan(
                client,
                operation="create-item",
                project_id=1,
                tracker_id=12,
                item_id=None,
                payload={"name": self.password},
            )

        self.assertEqual(session.requests, [])

    def test_plan_round_trip_preserves_integrity(self) -> None:
        client, _ = self._client(
            [
                FakeResponse(200, [{"id": 1}]),
                FakeResponse(200, [{"id": 12}]),
            ]
        )
        plan = build_mutation_plan(
            client,
            operation="create-item",
            project_id=1,
            tracker_id=12,
            item_id=None,
            payload={"name": "New requirement"},
        )
        plan_path = write_mutation_plan(
            plan,
            Path(self.temporary_directory.name) / "plan.json",
        )

        self.assertEqual(load_mutation_plan(plan_path), plan)

    def test_tracker_report_preserves_ids_and_falls_back_to_description(self) -> None:
        report = render_tracker_report(
            [
                {"id": 102, "name": "Sensor status at 0 Sec"},
                {
                    "id": 101,
                    "description": (
                        "EDR~_CONFIG shall run every "
                        "%%(color:rgb(30, 30, 30);font-style:normal;)500usec%!."
                    ),
                },
            ],
            tracker_id=12,
            tracker_name="EDR Requirements",
        )

        self.assertIn("- Matching requirements: 2", report)
        self.assertIn("- `101`: EDR_CONFIG shall run every 500usec.", report)
        self.assertIn("- `102`: Sensor status at 0 Sec", report)

    def test_apply_command_requires_explicit_apply_flag(self) -> None:
        parser = build_argument_parser()

        with self.assertRaises(SystemExit):
            parser.parse_args(
                [
                    "apply-mutation",
                    "--plan-file",
                    "reviewed-plan.json",
                    "--approve",
                    "plan-id",
                ]
            )

        args = parser.parse_args(
            [
                "apply-mutation",
                "--plan-file",
                "reviewed-plan.json",
                "--approve",
                "plan-id",
                "--apply",
            ]
        )

        self.assertTrue(args.apply)

    def test_skill_scripts_do_not_import_tools_codebeamer(self) -> None:
        script_sources = "\n".join(
            path.read_text(encoding="utf-8")
            for path in SKILL_SCRIPTS.glob("*.py")
        )

        self.assertNotIn("tools.codebeamer", script_sources)


if __name__ == "__main__":
    unittest.main()