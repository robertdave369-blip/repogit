"""Checks of the IMU / GEN6 SPI curves in crash_data/m310_m314_m110/spi_curves.

Every file is read the way ARIA 5.20 reads it (AriaCore SpiDataProvider.ReadSpiData: a line with
':' is a blended sample "<value>#SPI_<sensor>:<hex word>", any other line an Int32), its blended
samples are grouped into the injection windows SpiFunction.SendErrorData sends (a run of equal
words), and every raw word is decoded against the frame of its sensor. The word builder must also
reproduce the fault words of the bench's W610 SC3 2S EVTs.
"""
from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT.parent))
sys.path.insert(0, str(REPO_ROOT / "tools"))
os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "M310_M314_M110")

import build_imu_spi_curves as tool  # noqa: E402
from Framework_IOEM_Py.projects.M310_M314_M110.config import canc_config, imu_config  # noqa: E402

CURVE_DIR = Path(imu_config.IMU_SPI_CURVE_DIR)
SENSORS = imu_config.IMU_SPI_SENSORS
FAULTS = imu_config.IMU_SPI_FAULT_CURVES

# Fault words of the bench EVTs (C:\AriaConfigFiles_Generic\AriaConfigFiles\Config_folder\SPI\XLS,
# read 2026-10-24): EVT_Panasonic_Drive_<CH>_SM / _SADR_extended, EVT_GEN6.1_Main_SPI_ACUX / _ACUY,
# EVT_GEN6.1_Main_Internal_CCE_ACUX / _IE_ACUX.
BENCH_WORDS = {
    ("Panasonic", "sev", 1): 0x00006084, ("Panasonic", "sev", 2): 0x00006286, ("Panasonic", "sev", 3): 0x00006480,
    ("Panasonic", "sev", 4): 0x00006682, ("Panasonic", "sev", 5): 0x0000688C, ("Panasonic", "sev", 6): 0x00006A8E,
    ("Panasonic", "address", 1): 0x0000A28A, ("Panasonic", "address", 2): 0x0000A48C,
    ("Panasonic", "address", 3): 0x0000A088, ("Panasonic", "address", 4): 0x0000AA82,
    ("Panasonic", "address", 5): 0x0000A68E, ("Panasonic", "address", 6): 0x0000A880,
    ("GEN6_XY", "spi", 3): 0xAC00030D, ("GEN6_XY", "spi", 1): 0x8C00030F,
    ("GEN6_XY", "cce", 3): 0xAC00000B, ("GEN6_XY", "ie", 3): 0xAC000109,
}
PANASONIC_SADR = {1: 0x0, 2: 0x2, 3: 0x4, 4: 0x6, 5: 0x8, 6: 0xA, 7: 0xC}   # EWTS5G channel addresses


def int32(text: str) -> int:
    """Int32.Parse with NumberStyles.Integer (leading/trailing white space, leading sign)."""
    value = int(text.strip())
    assert -2**31 <= value < 2**31, text
    return value


def read_spi_data(path: Path, function: str) -> tuple[list[int], list[tuple[int, int]]]:
    """(crash values, [(line index, blended word)]) as ReadSpiData builds them."""
    values, blended = [], []
    for index, line in enumerate(path.read_text(encoding="ascii").replace("\r\n", "\n").split("\n")[:-1]):
        if ":" in line.upper():
            tag = line[line.index("#") + 1:]
            tag = tag[:tag.index(":")].replace("SPI_", "")
            assert tag.lower() in function.lower(), f"{path.name}: blended for {tag}, not {function}"
            values.append(int32(line[:line.index("#")]))
            word = int(line[line.index(":") + 1:].strip(), 16)
            assert 0 <= word <= 0xFFFFFFFF, line
            blended.append((index, word))
        else:
            values.append(int32(line))
    return values, blended


def windows(blended: list[tuple[int, int]]) -> list[tuple[int, int, int]]:
    """(start index, end index, word) per injection window: SendErrorData starts a window at a
    non-zero word and ends it where the next word differs or the list ends."""
    out, start = [], None
    for position, (index, word) in enumerate(blended):
        if not word:
            continue
        if start is None:
            start = index
        if position + 1 == len(blended) or blended[position + 1][1] != word:
            out.append((start, index, word))
            start = None
    return out


def crc_ok(sensor: str, word: int) -> bool:
    frame = SENSORS[sensor]["frame"]
    return (word & ((1 << frame["crc_bits"]) - 1)) == tool.frame_crc(word, frame)


class ImuSpiCurveTests(unittest.TestCase):
    def test_files_match_the_generator(self):
        files = tool.build()
        for name, (content, _) in files.items():
            path = CURVE_DIR / name
            self.assertTrue(path.is_file(), f"{name} missing: run tools/build_imu_spi_curves.py")
            # core.autocrlf may give a checked-out file CRLF endings; ARIA reads either.
            self.assertEqual(path.read_text(encoding="ascii").replace("\r\n", "\n"), content,
                             f"{name} differs from the generator")
        self.assertEqual(sorted(p.name for p in CURVE_DIR.glob("*.txt")), sorted(files))

    def test_word_builder_reproduces_the_bench_evts(self):
        for (sensor, family, axis), word in BENCH_WORDS.items():
            self.assertEqual(tool.fault_word(sensor, axis, FAULTS[sensor][family]), word, (sensor, family, axis))
        # The out-of-range frame the card builds for +31000 on accel X (EVT ..._ACC1_OOR_extended).
        frame = SENSORS["Panasonic"]["frame"]
        self.assertEqual(tool.with_crc((31000 << 16) | SENSORS["Panasonic"]["axis_word"][4], frame), 0x7918A689)

    def test_axis_words_and_status_words_carry_a_valid_crc(self):
        for sensor, spec in SENSORS.items():
            for axis, word in spec["axis_word"].items():
                self.assertTrue(crc_ok(sensor, word), f"{sensor} axis {axis} {word:08X}")
        status = imu_config.IMU_SPI_STATUS_FAULT
        self.assertTrue(crc_ok("Panasonic", status["normal_word"]))
        for axis, word in status["fault_word"].items():
            self.assertTrue(crc_ok("Panasonic", word), f"status axis {axis} {word:08X}")
            self.assertEqual(word & 0xFFF0, status["normal_word"] & 0xFFF0)
            self.assertEqual(bin((word >> 16) ^ (status["normal_word"] >> 16)).count("1"), 1,
                             f"status axis {axis}: exactly one status bit set")

    def test_fault_curves_decode_as_their_recipe(self):
        for sensor, families in FAULTS.items():
            function = SENSORS[sensor]["function"]
            for family, recipe in families.items():
                fault = tool.samples(recipe["fault_ms"])
                total = fault + tool.samples(recipe["valid_ms"])
                rest, rest_blended = read_spi_data(CURVE_DIR / tool.rest_name(sensor, total), function)
                self.assertEqual((len(rest), set(rest), rest_blended), (total, {0}, []))
                for axis in recipe["axes"]:
                    name = tool.fault_name(sensor, family, axis)
                    values, blended = read_spi_data(CURVE_DIR / name, function)
                    self.assertEqual(len(values), total, name)
                    if "value" in recipe:
                        self.assertEqual((values[:fault], blended), ([recipe["value"]] * fault, []), name)
                        self.assertEqual(set(values[fault:]), {0}, name)
                        continue
                    self.assertEqual(set(values), {0}, name)
                    (start, end, word), = windows(blended)
                    self.assertEqual((start, end), (0, fault - 1), name)
                    own = SENSORS[sensor]["axis_word"][axis]
                    if sensor == "Panasonic":
                        source = recipe.get("source_axis", {}).get(axis, axis)
                        self.assertEqual((word >> 8) & 0xF, PANASONIC_SADR[source], f"{name}: SADR")
                        self.assertEqual((word >> 12) & 3, 0b10, f"{name}: fixed bits")
                        self.assertEqual((word >> 16) & 0xFFFF, 0, f"{name}: data")
                        self.assertEqual((word >> 14) & 3, 0b01 if family == "sev" else 0b10, f"{name}: error flag")
                    else:
                        source = recipe.get("source_axis", {}).get(axis, axis)
                        self.assertEqual((word >> 28) & 7, (SENSORS[sensor]["axis_word"][source] >> 28) & 7, name)
                        self.assertEqual((word >> 14) & 0xFFF, 0, f"{name}: data")
                        self.assertEqual((word >> 27) & 1, 1 if family in ("spi", "cce", "ie") else 0, f"{name}: b27")
                        self.assertEqual((word >> 8) & 3, {"spi": 3, "ie": 1}.get(family, 0), f"{name}: SF1/SF0")
                    self.assertEqual(crc_ok(sensor, word), family != "crc", f"{name}: CRC")
                    if family == "crc":
                        self.assertEqual(word & ~0xF, own & ~0xF, f"{name}: only the CRC differs")

    def test_step_curves_hold_the_can_c_stimulus(self):
        step = imu_config.IMU_SPI_STEP_CURVE
        count, rest = tool.samples(step["step_ms"]), tool.samples(step["rest_ms"])
        rest_file = CURVE_DIR / tool.rest_name("Panasonic", count + rest)
        self.assertTrue(rest_file.is_file())
        for key, stimulus in canc_config.CANC_IMU_SPI_STIMULUS.items():
            counts = round(stimulus * canc_config.CANC_IMU_SPI_COUNTS_PER_UNIT[key])
            name = tool.step_name(canc_config.CANC_IMU_SPI_AXIS[key], counts)
            values, blended = read_spi_data(CURVE_DIR / name, "Panasonic")
            self.assertEqual((values, blended), ([counts] * count + [0] * rest, []), name)

    def test_rsu_zero_curve(self):
        lines = (CURVE_DIR / imu_config.IMU_SPI_RSU_ZERO_CURVE).read_text(encoding="ascii").splitlines()
        self.assertEqual(lines, ["0"] * imu_config.IMU_SPI_RSU_ZERO_SAMPLES)


if __name__ == "__main__":
    unittest.main()
