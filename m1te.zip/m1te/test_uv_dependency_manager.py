from __future__ import annotations

import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / ".github" / "skills" / "uv-package-manager" / "scripts" / "uv_dependency_manager.py"
SPEC = importlib.util.spec_from_file_location("uv_dependency_manager", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
UV_MANAGER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = UV_MANAGER
SPEC.loader.exec_module(UV_MANAGER)


class UVPackageManagerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="uv-manager-tests-"))
        self.state_dir = self.temp_dir / "dependency_management"

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _manager(self) -> Any:
        return UV_MANAGER.UVPackageManagerSkill(self.temp_dir, state_dir=self.state_dir, uv_executable="uv")

    def test_inventory_writes_lifecycle_artifacts_for_unmanaged_workspace(self) -> None:
        manager = self._manager()

        inventory = manager.inventory(["pymupdf", "pdfplumber"])

        self.assertFalse(inventory["readiness"]["managed"])
        self.assertIn("pyproject.toml is absent", inventory["readiness"]["reason"])
        self.assertEqual([package["package"] for package in inventory["packages"]], ["pymupdf", "pdfplumber"])
        self.assertTrue((self.state_dir / "dependency_inventory.json").is_file())
        self.assertTrue((self.state_dir / "compatibility_matrix.json").is_file())
        self.assertTrue((self.state_dir / "audit_trail.jsonl").is_file())

    def test_unmanaged_workspace_blocks_lock_integrity_and_sandbox_upgrade(self) -> None:
        manager = self._manager()

        integrity = manager.validate_lockfile_integrity()
        simulation = manager.simulate_upgrade("pdfplumber")
        production = manager.upgrade_safe_packages(["pdfplumber"], approve_production=True)

        self.assertEqual(integrity["status"], "blocked")
        self.assertEqual(simulation["status"], "blocked")
        self.assertEqual(production["status"], "blocked")

    def test_production_mutation_requires_structured_approval_provenance(self) -> None:
        manager = self._manager()

        result = manager.upgrade_safe_packages(["pdfplumber"], approve_production=True)

        self.assertEqual(result["status"], "blocked")
        self.assertIn("approval-file", result["reason"])

    def test_approval_validation_checks_scope_and_required_metadata(self) -> None:
        manager = self._manager()
        approval_file = self.temp_dir / "approval.json"
        approval_file.write_text(
            json.dumps(
                {
                    "request_id": "CHG-1",
                    "requester": "tester",
                    "reason": "Validate package upgrade",
                    "risk_class": "low",
                    "approved_by": "reviewer",
                    "approved_at": "2026-08-11T00:00:00Z",
                    "status": "approved",
                    "operations": ["upgrade_package"],
                    "packages": ["pdfplumber"],
                    "validation_evidence": ["tests/dependency_management/sandbox_validation.json"],
                }
            ),
            encoding="utf-8",
        )

        valid = manager._validate_approval(approval_file, operation="upgrade_package", packages=["pdfplumber"])
        invalid_scope = manager._validate_approval(approval_file, operation="upgrade_package", packages=["pandas"])

        self.assertTrue(valid["valid"])
        self.assertEqual(valid["metadata"]["request_id"], "CHG-1")
        self.assertFalse(invalid_scope["valid"])
        self.assertIn("does not cover", invalid_scope["reason"])

    def test_default_state_is_created_under_tests(self) -> None:
        manager = UV_MANAGER.UVPackageManagerSkill(self.temp_dir, uv_executable="uv")

        self.assertTrue(manager.state_dir.samefile(self.temp_dir / "tests" / "dependency_management"))
        self.assertTrue((manager.state_dir / "dependency_policy.json").is_file())
        self.assertTrue((manager.state_dir / "approval_template.json").is_file())
        approval_template = json.loads((manager.state_dir / "approval_template.json").read_text(encoding="utf-8"))
        self.assertEqual(approval_template["status"], "draft")

    def test_offline_monitor_does_not_report_risk_without_candidate_releases(self) -> None:
        manager = self._manager()

        monitor = manager.monitor(packages=["pymupdf"], online=False)

        self.assertEqual(monitor["notification_summary"]["updates_available"], 0)
        self.assertEqual(monitor["notification_summary"]["high_risk_updates"], 0)
        self.assertEqual(monitor["updates"]["packages"][0]["risk_level"], "none")
        self.assertTrue((self.state_dir / "notification_summary.json").is_file())

    def test_risk_assessment_rejects_python_incompatible_upgrade(self) -> None:
        manager = self._manager()
        package_record = {
            "package": "example-package",
            "installed_version": "1.2.3",
            "criticality": "standard",
        }
        release = {
            "latest_version": "2.0.0",
            "requires_python": ">=99",
            "release_date": "2026-08-11T00:00:00Z",
        }
        notes = {"analysis": manager.analyze_release_notes("Breaking change: old parser removed."), "available": True}
        security = {"checked": True, "highest_severity": None, "advisories": []}

        assessment = manager._assess_upgrade(package_record, release, notes, security)

        self.assertFalse(assessment["python_compatibility"]["upgrade_allowed"])
        self.assertEqual(assessment["upgrade_type"], "major")
        self.assertEqual(assessment["risk_level"], "critical")
        self.assertEqual(assessment["recommendation"], "avoid_upgrade")

    def test_backup_restore_preserves_lockfile(self) -> None:
        (self.temp_dir / "pyproject.toml").write_text("[project]\nname = 'test-project'\nversion = '0.1.0'\n", encoding="utf-8")
        lockfile = self.temp_dir / "uv.lock"
        lockfile.write_text("version = 1\n", encoding="utf-8")
        manager = self._manager()

        backup = manager._backup_current_state("test_upgrade")
        lockfile.write_text("version = 2\n", encoding="utf-8")
        restore = manager._restore_backup(backup, synchronize=False)

        self.assertEqual(restore["status"], "successful")
        self.assertEqual(lockfile.read_text(encoding="utf-8"), "version = 1\n")
        self.assertTrue((self.state_dir / "backups" / backup["id"] / "manifest.json").is_file())

    def test_release_notes_analysis_flags_breaking_deprecation_and_security(self) -> None:
        analysis = UV_MANAGER.UVPackageManagerSkill.analyze_release_notes(
            "Breaking change: old_parser() was removed.\nDeprecated: legacy_reader().\nSecurity fix for CVE-2026-0001."
        )

        self.assertTrue(analysis["breaking_changes_detected"])
        self.assertTrue(analysis["deprecated_features"])
        self.assertTrue(analysis["security_fix_lines"])

    def test_schedule_status_marks_first_monitor_run_due(self) -> None:
        manager = self._manager()

        schedule = manager.schedule_status()

        self.assertTrue(schedule["schedules"]["patch"]["due"])
        self.assertTrue(schedule["schedules"]["minor"]["due"])
        self.assertFalse(schedule["schedules"]["major"]["automatic"])
        self.assertTrue((self.state_dir / "schedule_status.json").is_file())

    def test_deprecated_api_scan_reports_source_usage(self) -> None:
        source_file = self.temp_dir / "consumer.py"
        source_file.write_text("legacy_reader()\n", encoding="utf-8")
        release_notes = self.temp_dir / "notes.md"
        release_notes.write_text("Deprecated: legacy_reader() will be removed.\n", encoding="utf-8")
        manager = self._manager()

        report = manager.scan_deprecated_api_usage(release_notes_path=release_notes)

        self.assertEqual(report["status"], "completed")
        self.assertEqual(report["deprecated_apis"], ["legacy_reader"])
        self.assertEqual(report["findings"][0]["path"], "consumer.py")
        self.assertTrue(report["requires_manual_review"])

    def test_framework_skill_import_checks_use_configured_environment(self) -> None:
        manager = self._manager()
        manager.policy["skill_import_checks"] = [{"skill": "test-skill", "modules": ["json", "tomllib"]}]

        report = manager.validate_skill_compatibility(self.temp_dir)

        self.assertEqual(report["status"], "passed")
        self.assertEqual([item["module"] for item in report["checks"]], ["json", "tomllib"])
        self.assertTrue((self.state_dir / "skill_compatibility.json").is_file())

    def test_failed_skill_import_sets_package_health_to_zero(self) -> None:
        manager = self._manager()
        updates = {
            "packages": [
                {
                    "package": "pandas",
                    "installed_version": "1.0.0",
                    "update_available": False,
                    "upgrade_type": "none",
                    "security": {"checked": True, "highest_severity": None},
                    "python_compatibility": {"upgrade_allowed": True, "status": "compatible"},
                    "recommendation": "wait",
                }
            ]
        }
        skill_compatibility = {
            "checks": [
                {"module": "pandas", "result": {"succeeded": False}}
            ]
        }

        report = manager.generate_health_report(updates, skill_compatibility)

        self.assertEqual(report["packages"][0]["health_score"], 0)
        self.assertEqual(report["packages"][0]["framework_import_integrity"], "failed")


if __name__ == "__main__":
    unittest.main()