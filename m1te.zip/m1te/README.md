# Test Workspace

`tests/` contains offline framework tests, their controlled fixtures, and the
evidence needed to validate generated test artifacts. It is not the location
for bench execution output, customer source documents, or project module
scripts.

## Where New Files Belong

| Content | Location | Naming and record |
| --- | --- | --- |
| Standalone automated test | `tests/test_<feature>.py` | State its purpose in the module docstring or test class name. |
| Test with supporting files | `tests/<feature>/` | Add `README.md` describing the feature, inputs, expected output, and source provenance. |
| Generated validation/dependency artifact | `tests/dependency_management/` | Add or update the owning feature README and logbook entry. |
| Test-generated evidence | `tests/<feature>/artifacts/YYYY-MM-DD_<purpose>/` | Include `README.md` with command, inputs, result, and retention decision. |
| Historical immutable material | `tests/backups/YYYY-MM-DD_<purpose>/` | Include `README.md` with origin, reason retained, and restore/use constraints. |

Generated executable test files remain directly under `tests/` and use the
`test_<feature>.py` naming pattern, as required by the repository policy.
Existing project module scripts and configuration-controlled runtime
`test_results/` and `test_logs/` paths are not relocated by this policy.

## Artifact Metadata

Every new non-source artifact folder needs a `README.md` containing: purpose,
owner or generating tool, input/source paths, creation date, validation status,
and retention or deletion rationale. Use clear names such as
`2026-09-13_u171-edr-review`, never ambiguous names such as `new`, `final`, or
`copy`.

Do not retain Excel lock files (`~$*`), interpreter caches (`__pycache__/`), or
accidental duplicate names (`* (2).*`). The audit reports them first; delete or
archive only after confirming the duplicate has no distinct content.

## Logbook

Append a concise dated entry to `tests/logbook/YYYY-MM.md` whenever tests,
generated artifacts, or test backups are added, validated, archived, or
removed. The format and an active monthly file are in
`tests/logbook/README.md`.

Run the offline audit from the repository root:

```powershell
py -3.13 tools/audit_test_tool_artifacts.py
```

It writes catalogues to `tests/ARTIFACT_CATALOG.md` and
`tools/ARTIFACT_CATALOG.md`, and returns a non-zero exit code only for hygiene
findings. It never moves, deletes, or changes framework artifacts.