from __future__ import annotations

import json
import secrets
import ssl
import tempfile
import unittest
from datetime import date
from pathlib import Path
from typing import Any, cast

from tools.codebeamer.client import (
    CodebeamerClient,
    CodebeamerConfig,
    CodebeamerConfigurationError,
    CodebeamerResponseError,
    _SystemTrustAdapter,
)
from tools.codebeamer.planner import (
    TrackerScope,
    build_traceability,
    collect_daily_plan,
    snapshot_to_dict,
    write_daily_plan,
)


class FakeResponse:
    """Minimal response fake used to validate offline REST behavior."""

    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload

    def json(self) -> Any:
        """Return the JSON payload configured by the test."""
        return self._payload


class FakeSession:
    """Record outgoing requests without allowing any real HTTP traffic."""

    def __init__(self, responses: list[FakeResponse]) -> None:
        self.auth: object | None = None
        self.headers: dict[str, str] = {}
        self.requests: list[dict[str, Any]] = []
        self._responses = responses
        self.closed = False

    def request(self, method: str, url: str, **kwargs: Any) -> FakeResponse:
        """Record one request and return its preconfigured fake response."""
        self.requests.append({"method": method, "url": url, **kwargs})
        if not self._responses:
            raise AssertionError("Unexpected HTTP request")
        return self._responses.pop(0)

    def close(self) -> None:
        """Mirror the requests session close contract."""
        self.closed = True


class CodebeamerToolTests(unittest.TestCase):
    """Offline tests for the read-only Codebeamer integration."""

    def setUp(self) -> None:
        """Generate ephemeral credentials so no secret is committed to the test source."""
        self.username = f"test-user-{secrets.token_hex(8)}"
        self.password = secrets.token_urlsafe(24)

    def _write_dotenv(self, directory: Path, url: str) -> Path:
        """Write the test-only credentials to a temporary dotenv file."""
        dotenv_path = directory / ".env"
        dotenv_path.write_text(
            "\n".join(
                (
                    f"CODEBEAMER_URL={url}",
                    f"CODEBEAMER_USERNAME={self.username}",
                    f"CODEBEAMER_PASSWORD={self.password}",
                    "",
                )
            ),
            encoding="utf-8",
        )
        return dotenv_path

    def _client(
        self,
        responses: list[FakeResponse],
        directory: Path,
    ) -> tuple[CodebeamerClient, FakeSession]:
        """Build a client with a fake HTTP session and temporary dotenv file."""
        dotenv_path = self._write_dotenv(directory, "https://codebeamer.example.test")
        config = CodebeamerConfig.from_dotenv(dotenv_path)
        session = FakeSession(responses)
        return CodebeamerClient(config, session=session), session

    def test_config_reads_dotenv_and_redacts_credentials(self) -> None:
        """Credentials remain absent from client representation, URLs, and display text."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            directory = Path(temporary_directory)
            client, session = self._client([FakeResponse(200, [])], directory)
            projects = client.list_projects()

        self.assertEqual(projects, [])
        self.assertEqual(session.requests[0]["method"], "GET")
        self.assertNotIn(self.username, session.requests[0]["url"])
        self.assertNotIn(self.password, session.requests[0]["url"])
        self.assertNotIn(self.username, repr(client._config))
        self.assertNotIn(self.password, repr(client._config))
        redacted = client.redact(f"{self.username} {self.password}")
        self.assertNotIn(self.username, redacted)
        self.assertNotIn(self.password, redacted)
        self.assertIn("[REDACTED]", redacted)

    def test_config_rejects_credentials_embedded_in_url(self) -> None:
        """Connection secrets must be supplied only through dotenv variables."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            dotenv_path = self._write_dotenv(
                Path(temporary_directory),
                f"https://{self.username}:{self.password}@codebeamer.example.test",
            )
            with self.assertRaises(CodebeamerConfigurationError):
                CodebeamerConfig.from_dotenv(dotenv_path)

    def test_connection_validation_requires_projects_collection(self) -> None:
        """A 200 response is not considered valid until its JSON shape is recognized."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            client, _ = self._client(
                [FakeResponse(200, {"unexpected": []})],
                Path(temporary_directory),
            )
            with self.assertRaises(CodebeamerResponseError):
                client.validate_connection()

    def test_default_client_uses_verified_system_tls_context(self) -> None:
        """The default HTTPS adapter keeps certificate and hostname verification enabled."""
        with tempfile.TemporaryDirectory() as temporary_directory:
            dotenv_path = self._write_dotenv(
                Path(temporary_directory),
                "https://codebeamer.example.test",
            )
            client = CodebeamerClient(CodebeamerConfig.from_dotenv(dotenv_path))
            try:
                session = cast(Any, client._session)
                adapter = session.get_adapter("https://codebeamer.example.test")
                self.assertIsInstance(adapter, _SystemTrustAdapter)
                context = cast(_SystemTrustAdapter, adapter)._ssl_context
            finally:
                client.close()

        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)

    def test_tracker_pagination_is_read_only_and_complete(self) -> None:
        """All pages are collected through GET requests with increasing page numbers."""
        responses = [
            FakeResponse(200, {"items": [{"id": 101}], "hasMore": True}),
            FakeResponse(200, {"items": [{"id": 102}], "hasMore": False}),
        ]
        with tempfile.TemporaryDirectory() as temporary_directory:
            client, session = self._client(responses, Path(temporary_directory))
            items = client.list_tracker_items(42, page_size=1)

        self.assertEqual([item["id"] for item in items], [101, 102])
        self.assertEqual(
            [request["method"] for request in session.requests], ["GET", "GET"]
        )
        self.assertEqual(session.requests[0]["params"], {"page": 1, "pageSize": 1})
        self.assertEqual(session.requests[1]["params"], {"page": 2, "pageSize": 1})

    def test_traceability_uses_explicit_links_only(self) -> None:
        """Only declared Codebeamer relation data creates coverage evidence."""
        traceability = build_traceability(
            [{"id": 1001}, {"id": 1002}],
            [
                {
                    "id": 2001,
                    "fields": [
                        {
                            "name": "Verifies",
                            "value": "[ISSUE:1001]-null",
                        }
                    ],
                }
            ],
        )

        self.assertTrue(traceability.evidence_available)
        self.assertEqual(traceability.requirement_to_test_cases["1001"], ("2001",))
        self.assertEqual(traceability.requirement_to_test_cases["1002"], ())

    def test_daily_plan_redacts_identity_and_writes_dated_artifacts(self) -> None:
        """Task filtering and generated plans never persist the configured identity."""
        responses = [
            FakeResponse(
                200,
                {
                    "trackers": [
                        {"id": 11},
                        {"id": 12},
                        {"id": 13},
                    ]
                },
            ),
            FakeResponse(
                200,
                {
                    "items": [
                        {"id": 1001, "name": "Requirement with test"},
                        {"id": 1002, "name": "Requirement without test"},
                    ]
                },
            ),
            FakeResponse(
                200,
                {
                    "items": [
                        {
                            "id": 2001,
                            "name": "Verification test",
                            "fields": [
                                {
                                    "name": "Verifies",
                                    "value": "[ISSUE:1001]-null",
                                }
                            ],
                        }
                    ]
                },
            ),
            FakeResponse(
                200,
                {
                    "items": [
                        {
                            "id": 3001,
                            "name": "Review coverage evidence",
                            "description": f"Coordinate with {self.username}",
                            "assignedTo": self.username,
                            "dueDate": "2026-09-08",
                            "status": "Open",
                            "priority": "High",
                        },
                        {
                            "id": 3002,
                            "name": "Other engineer task",
                            "assignedTo": "other-engineer",
                            "status": "Open",
                        },
                        {
                            "id": 3003,
                            "name": "Completed task",
                            "assignedTo": self.username,
                            "status": "Closed",
                        },
                    ]
                },
            ),
        ]

        with tempfile.TemporaryDirectory() as temporary_directory:
            directory = Path(temporary_directory)
            client, _ = self._client(responses, directory)
            snapshot = collect_daily_plan(
                client,
                TrackerScope(
                    project_id=1,
                    requirements_tracker_id=11,
                    test_cases_tracker_id=12,
                    tasks_tracker_id=13,
                ),
                plan_date=date(2026, 9, 8),
            )
            plan_path, snapshot_path = write_daily_plan(snapshot, directory)
            plan_text = plan_path.read_text(encoding="utf-8")
            json_text = snapshot_path.read_text(encoding="utf-8")

        self.assertEqual([task.item_id for task in snapshot.tasks], ["3001"])
        self.assertIn("Requirement without test", plan_text)
        self.assertIn("[REDACTED]", plan_text)
        self.assertNotIn(self.username, plan_text)
        self.assertNotIn(self.username, json_text)
        self.assertNotIn(self.password, json_text)
        serialized = json.dumps(snapshot_to_dict(snapshot))
        self.assertNotIn(self.username, serialized)
        self.assertNotIn(self.password, serialized)


if __name__ == "__main__":
    unittest.main()
