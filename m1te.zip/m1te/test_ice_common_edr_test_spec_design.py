"""Generate and validate the ICE Common EDR engineering-review test matrix.

This tool is deliberately offline. It reads the supplied requirement workbook and
writes a review package only; it does not import to Codebeamer or access ARIA,
an ECU, power equipment, diagnostics, or any other bench interface.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import date
from hashlib import sha256
import json
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parents[1]
SOURCE_WORKBOOK = ROOT / "docs" / "project_documents" / "Common Diag Spec" / "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx"
OUTPUT_DIRECTORY = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design"
    / "01_Design_Matrix"
)
OUTPUT_WORKBOOK = OUTPUT_DIRECTORY / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design_Matrix.xlsx"
OUTPUT_REPORT = OUTPUT_DIRECTORY / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design_Validation.json"

SOURCE_NAME = "ICE_COMMON_SRS_V1.4_DIAG_RE.xlsx"
SOURCE_TRACEABILITY_NOTICE = (
    "Source-row traceability only: EDR_Requirements has no verified Codebeamer artifact ID or approval-status field."
)
TBC = "TBC: requirement clarification required."
ON_HOLD = "ON HOLD: TBC: requirement clarification required; do not record a pass/fail verdict."

NAVY = "1F4E78"
BLUE = "D9EAF7"
GREEN = "E2F0D9"
AMBER = "FFF2CC"
RED = "FCE4D6"
GRAY = "E7E6E6"
WHITE = "FFFFFF"
THIN_GRAY = Side(style="thin", color="B7B7B7")


TEST_HEADERS = [
    "Test Case ID",
    "Source Requirement Reference",
    "Requirement ID Status",
    "Test Objective",
    "Test Category",
    "Priority",
    "ASIL / Safety Relevance",
    "ECU Variant",
    "Initial EDR1 State",
    "Initial EDR2 State",
    "Preconditions",
    "Input Event Sequence",
    "Event Type",
    "T0 Source",
    "Timing Between Events",
    "CAN Conditions",
    "Power Conditions",
    "Diagnostic Conditions",
    "Detailed Test Steps",
    "Expected EDR1 Content",
    "Expected EDR2 Content",
    "Expected MultiEventNumber",
    "Expected TimeBetweenEvents",
    "Expected LifetimeEventNumber",
    "Expected RecordLockStatus",
    "Expected CompletionStatus",
    "Expected 200msCompletionStatus",
    "Expected STS_CRASH",
    "Expected DOOR_UNLOCK",
    "Expected UDS or DID Response",
    "Persistence Check After Power Cycle",
    "Pass / Fail Criteria",
    "Required Measurement Accuracy",
    "Requirement Ambiguity ID",
    "Defect Type Targeted",
    "Automation Feasibility",
    "Execution Status",
    "Notes",
]


REQUIREMENTS = [
    {
        "key": "ICE-EDR-R01",
        "source_row": 5,
        "serial": "1",
        "topic": "EDR Default",
        "statement": "When no EDR event is recorded, EDR DID responses shall contain FF.. for all bytes, including reserved bytes.",
        "conditions": "No EDR event is recorded.",
        "observable": "Every returned EDR-DID byte, including reserve bytes, is FF..",
        "confidence": "Very High",
    },
    {
        "key": "ICE-EDR-R02",
        "source_row": 6,
        "serial": "2",
        "topic": "ECU variant without SRSU",
        "statement": "Low and Mid domestic variants without SRSU shall not record side events; door unlock and other features are governed by their own requirements.",
        "conditions": "Domestic Low or Mid variant without SRSU; side event.",
        "observable": "No side-event EDR recording.",
        "confidence": "Very High",
    },
    {
        "key": "ICE-EDR-R03",
        "source_row": 7,
        "serial": "3",
        "topic": "CAN signals",
        "statement": "Applicable EDR CAN signals are stored according to M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156, including resolution, ranges, and on-fail behavior.",
        "conditions": "Applicable EDR CAN signals are available or invalid according to the named matrix.",
        "observable": "Stored values comply with the named communication matrix.",
        "confidence": "High",
    },
    {
        "key": "ICE-EDR-R04",
        "source_row": 8,
        "serial": "4",
        "topic": "Near Crash",
        "statement": "A non-deployment near crash records EDR data but does not lock the record; STS_CRASH and DOOR_UNLOCK are not sent on CAN.",
        "conditions": "Crash threshold is not deployable.",
        "observable": "EDR record exists and is unlocked; STS_CRASH and DOOR_UNLOCK are not transmitted.",
        "confidence": "Very High",
    },
    {
        "key": "ICE-EDR-R05",
        "source_row": 9,
        "serial": "5",
        "topic": "CompletionStatus",
        "statement": "CompletionStatus is updated to 1 after five seconds from T0 when battery is available.",
        "conditions": "Battery remains available after T0.",
        "observable": "CompletionStatus becomes 1 after five seconds from T0.",
        "confidence": "Very High",
    },
    {
        "key": "ICE-EDR-R06",
        "source_row": 10,
        "serial": "6",
        "topic": "200ms CompletionStatus",
        "statement": "200ms CompletionStatus is updated to 1 after 200 ms; when set, EDR data for 200 ms from T0 are valid.",
        "conditions": "Event has reached the 200 ms point.",
        "observable": "200msCompletionStatus is 1 and the T0 through 200 ms dataset is valid.",
        "confidence": "Very High",
    },
    {
        "key": "ICE-EDR-R07",
        "source_row": 11,
        "serial": "7",
        "topic": "Unconfirmed Crash",
        "statement": "Onboard longitudinal input present with both FRSU values equal to 0 is an unconfirmed crash.",
        "conditions": "Onboard longitudinal input present; FRSU1=0; FRSU2=0.",
        "observable": "Event is classified as unconfirmed crash.",
        "confidence": "Very High",
    },
]


def source_reference(row: int, serial: str | None = None, cell: str = "E") -> str:
    suffix = f" | S.No {serial}" if serial else ""
    return f"{SOURCE_NAME} | EDR_Requirements!{cell}{row}{suffix}"


def cell_text(value: Any) -> str:
    return "" if value is None else str(value).replace("\r\n", "\n").replace("\r", "\n").strip()


def compact_text(value: Any) -> str:
    return " ".join(cell_text(value).split())


def file_hash(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_row_values(sheet: Any, row_number: int, start_column: int = 2, end_column: int = 22) -> list[Any]:
    return list(
        next(
            sheet.iter_rows(
                min_row=row_number,
                max_row=row_number,
                min_col=start_column,
                max_col=end_column,
                values_only=True,
            )
        )
    )


def inspect_source() -> dict[str, Any]:
    """Verify every primary fact used by this design against the read-only source."""
    if not SOURCE_WORKBOOK.is_file():
        raise FileNotFoundError(f"Requirement source is unavailable: {SOURCE_WORKBOOK}")

    workbook = load_workbook(SOURCE_WORKBOOK, data_only=True, read_only=True)
    if "EDR_Requirements" not in workbook.sheetnames:
        raise ValueError("Required source sheet EDR_Requirements is unavailable.")

    sheet = workbook["EDR_Requirements"]
    expected_fragments = {
        5: ("FF..", "reserve bytes"),
        6: ("Low/Mid", "No EDR recording for side events"),
        7: ("M&M_W501_IVN_Communication_Matrix_SRS", "Resolution and ranges"),
        8: ("not lock", "STS_CRASH", "DOOR_UNLOCK"),
        9: ("5 seconds", "T0"),
        10: ("200 mseconds", "200ms"),
        11: ("longitudinal", "FRSUs"),
        32: ("Multi Event Scenarios", ">500ms", "<5sec"),
        53: ("EDR data not valid", "Battery cutoff"),
        54: ("EDR data valid upto 200ms",),
        55: ("EDR data valid", "no Battery cut off"),
    }
    verified_rows: dict[str, str] = {}
    for row_number, fragments in expected_fragments.items():
        joined = " | ".join(cell_text(value) for value in source_row_values(sheet, row_number))
        missing = [fragment for fragment in fragments if fragment.lower() not in joined.lower()]
        if missing:
            raise ValueError(
                f"Source row {row_number} no longer contains expected design anchors: {', '.join(missing)}"
            )
        verified_rows[str(row_number)] = joined

    vectors: list[dict[str, Any]] = []
    for family, rows, timing in (
        ("Single event", range(23, 31), "Source table: time between events more than 5 s."),
        ("Multi event", range(42, 50), "Source table: time between events >500 ms and <5 s."),
    ):
        for row_number in rows:
            values = source_row_values(sheet, row_number)
            if not all(values[index] is not None for index in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)):
                raise ValueError(f"Source vector row {row_number} is incomplete.")
            vectors.append(
                {
                    "family": family,
                    "source_row": row_number,
                    "timing": timing,
                    "event_1": compact_text(values[0]),
                    "event_2": compact_text(values[1]),
                    "event_3": compact_text(values[2]),
                    "after_2_edr1": compact_text(values[3]),
                    "after_2_edr2": compact_text(values[4]),
                    "after_2_multi_1": compact_text(values[5]),
                    "after_2_multi_2": compact_text(values[6]),
                    "after_2_time_1": compact_text(values[7]),
                    "after_2_time_2": compact_text(values[8]),
                    "after_2_lifetime_1": compact_text(values[9]),
                    "after_2_lifetime_2": compact_text(values[10]),
                    "after_3_edr1": compact_text(values[11]),
                    "after_3_edr2": compact_text(values[12]),
                    "after_3_multi_1": compact_text(values[13]),
                    "after_3_multi_2": compact_text(values[14]),
                    "after_3_time_1": compact_text(values[15]),
                    "after_3_time_2": compact_text(values[16]),
                    "after_3_lifetime_1": compact_text(values[17]),
                    "after_3_lifetime_2": compact_text(values[18]),
                    "after_3_lock_1": compact_text(values[19]),
                    "after_3_lock_2": compact_text(values[20]),
                }
            )

    sheet_inventory = [
        {
            "sheet": item.title,
            "dimension": item.calculate_dimension(),
            "max_row": item.max_row,
            "max_column": item.max_column,
        }
        for item in workbook.worksheets
    ]
    return {
        "source_hash": file_hash(SOURCE_WORKBOOK),
        "source_sheet_count": len(workbook.sheetnames),
        "edr_sheet_dimension": sheet.calculate_dimension(),
        "edr_sheet_rows": sheet.max_row,
        "verified_rows": verified_rows,
        "vectors": vectors,
        "sheet_inventory": sheet_inventory,
    }


def event_label(value: str) -> str:
    return "Near Crash" if value.startswith("0") else "Deployment Event"


def test_case(
    case_id: str,
    source: str,
    objective: str,
    category: str,
    priority: str,
    status: str,
    ambiguity: str = "",
    notes: str = "",
    values: dict[str, str] | None = None,
) -> dict[str, str]:
    row = {header: "" for header in TEST_HEADERS}
    row.update(
        {
            "Test Case ID": case_id,
            "Source Requirement Reference": source,
            "Requirement ID Status": SOURCE_TRACEABILITY_NOTICE,
            "Test Objective": objective,
            "Test Category": category,
            "Priority": priority,
            "ASIL / Safety Relevance": "Safety relevance not supplied in EDR_Requirements; assess in project safety case.",
            "ECU Variant": "See case-specific variant.",
            "Initial EDR1 State": "TBC: source does not define a reset/clear baseline.",
            "Initial EDR2 State": "TBC: source does not define a reset/clear baseline.",
            "Preconditions": "Use an approved offline/bench procedure only after unresolved source gaps are closed.",
            "Input Event Sequence": "See detailed test steps.",
            "Event Type": "See input sequence.",
            "T0 Source": "TBC: EDR_Requirements refers to T0 but does not define the timestamp source.",
            "Timing Between Events": "Not applicable.",
            "CAN Conditions": "Nominal CAN unless this case defines a CAN condition.",
            "Power Conditions": "Nominal power unless this case defines a power condition.",
            "Diagnostic Conditions": "Read applicable EDR DID(s) using the approved diagnostic specification; DID access contract is not supplied here.",
            "Detailed Test Steps": "1. Establish the stated preconditions. 2. Apply the stated stimulus. 3. Capture required EDR, CAN, power, and diagnostic evidence. 4. Compare only to source-backed expected results. 5. Restore the approved test environment.",
            "Expected EDR1 Content": "Not applicable.",
            "Expected EDR2 Content": "Not applicable.",
            "Expected MultiEventNumber": "Not applicable.",
            "Expected TimeBetweenEvents": "Not applicable.",
            "Expected LifetimeEventNumber": "Not applicable.",
            "Expected RecordLockStatus": "Not applicable.",
            "Expected CompletionStatus": "Not applicable.",
            "Expected 200msCompletionStatus": "Not applicable.",
            "Expected STS_CRASH": "Not applicable.",
            "Expected DOOR_UNLOCK": "Not applicable.",
            "Expected UDS or DID Response": "Not applicable.",
            "Persistence Check After Power Cycle": "Not applicable.",
            "Pass / Fail Criteria": "Pass only when the stated source-backed observation is met and all required evidence is retained.",
            "Required Measurement Accuracy": "TBC: source does not provide measurement accuracy or scheduler tolerance.",
            "Requirement Ambiguity ID": ambiguity,
            "Defect Type Targeted": "Requirement implementation deviation.",
            "Automation Feasibility": "Semi-automatic after approved stimulus, measurement, and diagnostic interfaces are available.",
            "Execution Status": status,
            "Notes": notes,
        }
    )
    if values:
        for key, value in values.items():
            if key not in row:
                raise KeyError(f"Unknown test-matrix field: {key}")
            row[key] = value
    return row


def tbc_case(
    case_id: str,
    source: str,
    objective: str,
    category: str,
    priority: str,
    ambiguity: str,
    notes: str,
    values: dict[str, str] | None = None,
) -> dict[str, str]:
    deferred = {
        "Expected EDR1 Content": TBC,
        "Expected EDR2 Content": TBC,
        "Expected MultiEventNumber": TBC,
        "Expected TimeBetweenEvents": TBC,
        "Expected LifetimeEventNumber": TBC,
        "Expected RecordLockStatus": TBC,
        "Expected CompletionStatus": TBC,
        "Expected 200msCompletionStatus": TBC,
        "Expected STS_CRASH": TBC,
        "Expected DOOR_UNLOCK": TBC,
        "Expected UDS or DID Response": TBC,
        "Persistence Check After Power Cycle": TBC,
        "Pass / Fail Criteria": ON_HOLD,
        "Execution Status": "ON HOLD",
    }
    if values:
        deferred.update(values)
    return test_case(
        case_id,
        source,
        objective,
        category,
        priority,
        "ON HOLD",
        ambiguity,
        notes,
        deferred,
    )


def build_source_rule_cases() -> list[dict[str, str]]:
    return [
        test_case(
            "EDR-ICE-R01-DEFAULT-001",
            source_reference(5, "1"),
            "Verify the no-event EDR DID default response, including reserved bytes.",
            "Diagnostic / default data integrity",
            "P1",
            "IN REVIEW",
            "AMB-001; AMB-010",
            "The source gives FF.. but does not identify individual EDR DIDs, response lengths, sessions, or byte offsets.",
            {
                "ECU Variant": "All variants where EDR is implemented.",
                "Initial EDR1 State": "No EDR event recorded.",
                "Initial EDR2 State": "No EDR event recorded.",
                "Preconditions": "No EDR event has been recorded; diagnostic session/access procedure is approved.",
                "Input Event Sequence": "No event.",
                "Event Type": "None.",
                "CAN Conditions": "No crash-related CAN notification is stimulated.",
                "Detailed Test Steps": "1. Establish a no-event EDR state using the architect-approved baseline procedure. 2. Read every implemented EDR DID. 3. Retain raw responses and map every byte, including reserved bytes. 4. Repeat the reads to detect stale response data.",
                "Expected EDR1 Content": "No event record; data response bytes are FF.. including reserved bytes.",
                "Expected EDR2 Content": "No event record; data response bytes are FF.. including reserved bytes.",
                "Expected UDS or DID Response": "For each applicable EDR DID, every returned data byte, including reserved bytes, is FF...",
                "Pass / Fail Criteria": "Pass when every returned EDR DID byte, including reserved bytes, is FF..; fail for any zero, stale, mixed, or non-FF byte.",
                "Defect Type Targeted": "Default initialization, stale NVM leakage, reserved-byte initialization.",
            },
        ),
        test_case(
            "EDR-ICE-R02-LOW-NOSRSU-SIDE-001",
            source_reference(6, "2"),
            "Verify that a Domestic Low variant without SRSU does not record a side event in EDR.",
            "Variant applicability / negative",
            "P1",
            "IN REVIEW",
            "AMB-013",
            "The source directs door-unlock and other features to separate requirements that were not supplied for this design.",
            {
                "ECU Variant": "Domestic Low without SRSU.",
                "Input Event Sequence": "Inject one side-event stimulus using an approved project event procedure.",
                "Event Type": "Side event.",
                "Detailed Test Steps": "1. Confirm Domestic Low variant coding without SRSU using an approved read-only configuration check. 2. Apply a side-event stimulus. 3. Read all applicable EDR DIDs after the approved observation interval. 4. Compare to the no-side-recording requirement. 5. Separately capture unrelated outputs for later tracing to their own requirements.",
                "Expected EDR1 Content": "No side-event EDR record.",
                "Expected EDR2 Content": "No side-event EDR record.",
                "Expected UDS or DID Response": "No side-event data are present in applicable EDR DID responses.",
                "Pass / Fail Criteria": "Pass when no side event is recorded in EDR; do not judge door-unlock or other features from this source row.",
                "Defect Type Targeted": "Variant leakage causing prohibited side-event storage.",
            },
        ),
        test_case(
            "EDR-ICE-R02-MID-NOSRSU-SIDE-002",
            source_reference(6, "2"),
            "Verify that a Domestic Mid variant without SRSU does not record a side event in EDR.",
            "Variant applicability / negative",
            "P1",
            "IN REVIEW",
            "AMB-013",
            "Separate Low and Mid execution is retained because the source names both variants but gives no shared coding evidence.",
            {
                "ECU Variant": "Domestic Mid without SRSU.",
                "Input Event Sequence": "Inject one side-event stimulus using an approved project event procedure.",
                "Event Type": "Side event.",
                "Detailed Test Steps": "1. Confirm Domestic Mid variant coding without SRSU. 2. Apply a side-event stimulus. 3. Read all applicable EDR DIDs after the approved observation interval. 4. Compare only to the no-side-recording source rule.",
                "Expected EDR1 Content": "No side-event EDR record.",
                "Expected EDR2 Content": "No side-event EDR record.",
                "Expected UDS or DID Response": "No side-event data are present in applicable EDR DID responses.",
                "Pass / Fail Criteria": "Pass when no side event is recorded in EDR; unrelated features need separate source requirements.",
                "Defect Type Targeted": "Variant leakage causing prohibited side-event storage.",
            },
        ),
        tbc_case(
            "EDR-ICE-R03-CAN-CONTRACT-001",
            source_reference(7, "3"),
            "Verify raw value, physical value, scaling, range, data age, and on-fail storage for every applicable EDR CAN signal.",
            "CAN data quality / data integrity",
            "P1",
            "AMB-002; AMB-009",
            "The named M&M_W501_IVN communication matrix is not available in the workspace; no signal inventory, DBC, packing, sample time, or on-fail rule can be asserted.",
            {
                "ECU Variant": "Target variant TBC.",
                "Input Event Sequence": "One event per applicable signal-vector row after the named communication matrix is supplied.",
                "Event Type": "TBC by matrix applicability.",
                "CAN Conditions": "Nominal, missing, delayed, invalid, fail-safe, minimum, maximum, overflow, duplicate, and out-of-order frames per supplied matrix.",
                "Detailed Test Steps": "1. Obtain the released W501 matrix and target DBC. 2. Derive one traceable vector per applicable signal and failure mode. 3. Stimulate values around every EDR sample point. 4. Compare stored raw and physical representations to the approved packing rule.",
                "Defect Type Targeted": "Stale/misaligned CAN storage, scaling, range, fail-safe, endian, and sample-age defects.",
                "Automation Feasibility": "Automatic only after a verified DBC, signal simulation interface, and EDR packing decoder are supplied.",
            },
        ),
        test_case(
            "EDR-ICE-R04-NEAR-CRASH-001",
            source_reference(8, "4"),
            "Verify near-crash recording, unlocked record state, and suppressed STS_CRASH and DOOR_UNLOCK transmission.",
            "Event classification / CAN output",
            "P0",
            "IN REVIEW",
            "AMB-010; AMB-011",
            "The source does not identify the record slot, EDR DID, capture completion interval, T0 source, or diagnostic observation timing.",
            {
                "ECU Variant": "All variants where near-crash EDR behavior is enabled.",
                "Input Event Sequence": "One non-deployment near crash.",
                "Event Type": "Near Crash.",
                "CAN Conditions": "Capture STS_CRASH and DOOR_UNLOCK throughout the event and recording observation window.",
                "Detailed Test Steps": "1. Establish the approved event-ready state. 2. Apply a crash stimulus below the deployable threshold. 3. Capture CAN traffic through the completed observation window. 4. Read applicable EDR data. 5. Identify the record lock state using the approved decoder.",
                "Expected EDR1 Content": "A near-crash EDR record is present in a source-defined location; exact slot/DID is not stated.",
                "Expected EDR2 Content": "A near-crash EDR record is present in a source-defined location; exact slot/DID is not stated.",
                "Expected RecordLockStatus": "0 / record not locked for the near-crash record.",
                "Expected STS_CRASH": "Not transmitted for the near crash.",
                "Expected DOOR_UNLOCK": "Not transmitted for the near crash.",
                "Expected UDS or DID Response": "Contains the near-crash record at the architect-confirmed EDR DID/slot.",
                "Pass / Fail Criteria": "Pass when an EDR record is created, its lock state is 0, and neither STS_CRASH nor DOOR_UNLOCK is transmitted for the near crash.",
                "Defect Type Targeted": "Near-crash suppression/locking error; false post-crash CAN notification.",
            },
        ),
        test_case(
            "EDR-ICE-R05-COMPLETE-AFTER-5S-001",
            source_reference(9, "5"),
            "Verify CompletionStatus becomes 1 after five seconds from T0 when battery remains available.",
            "Timing / completion state",
            "P0",
            "IN REVIEW",
            "AMB-003; AMB-007",
            "The source does not define T0 timestamp ownership, scheduler tolerance, exact boundary comparison, durable-write order, or data set covered by CompletionStatus.",
            {
                "Input Event Sequence": "One EDR-recording event with battery available for more than five seconds after T0.",
                "Event Type": "Any source-applicable EDR event.",
                "Power Conditions": "Battery remains available through the approved post-T0 observation time.",
                "Detailed Test Steps": "1. Capture the project-approved T0 reference. 2. Trigger one EDR-recording event. 3. Observe CompletionStatus at an architect-approved time after T0+5 s. 4. Preserve timestamps and the decoded EDR response.",
                "Expected CompletionStatus": "1 after five seconds from T0 when battery is available.",
                "Pass / Fail Criteria": "Pass when CompletionStatus is 1 at the approved observation time after T0+5 s with battery available; boundary/tolerance behavior remains separately TBC.",
                "Defect Type Targeted": "Missing or premature five-second completion state.",
            },
        ),
        tbc_case(
            "EDR-ICE-R05-5S-BOUNDARY-002",
            source_reference(9, "5"),
            "Characterize CompletionStatus one scheduler tick before, on, and after 5.000 s from T0.",
            "Timing boundary / scheduler",
            "P0",
            "AMB-003; AMB-007",
            "No scheduler period, timestamp reference, tolerance, or exact-at-boundary comparison is supplied.",
            {
                "Input Event Sequence": "One EDR-recording event; observe at 4.999 s, 5.000 s, 5.001 s and tick-relative points after T0.",
                "Event Type": "Any source-applicable EDR event.",
                "Timing Between Events": "4.999 s / 5.000 s / 5.001 s after T0; tick-relative values TBC.",
                "Detailed Test Steps": "1. Instrument the approved T0 source. 2. Trigger an EDR event. 3. Sample CompletionStatus at the timing matrix points. 4. Compare after an architect-defined tolerance is issued.",
                "Defect Type Targeted": "Off-by-one time comparison; millisecond-to-tick conversion error.",
            },
        ),
        test_case(
            "EDR-ICE-R06-200MS-COMPLETE-001",
            source_reference(10, "6"),
            "Verify 200msCompletionStatus becomes 1 after 200 ms and denotes valid data from T0 through 200 ms.",
            "Timing / battery-cutoff completion",
            "P0",
            "IN REVIEW",
            "AMB-003; AMB-007",
            "The source omits sample list, packetization, durable-write evidence, T0 ownership, and scheduler tolerance.",
            {
                "Input Event Sequence": "One EDR-recording event; observe after T0+200 ms.",
                "Event Type": "Any source-applicable EDR event.",
                "Power Conditions": "Battery-cutoff applicability must be established by the project test procedure.",
                "Detailed Test Steps": "1. Capture T0 using the approved project reference. 2. Trigger an EDR event. 3. Observe 200msCompletionStatus after the approved T0+200 ms observation point. 4. Decode the source-defined data range representing T0 through 200 ms.",
                "Expected 200msCompletionStatus": "1 after 200 ms.",
                "Pass / Fail Criteria": "Pass when 200msCompletionStatus is 1 after the approved post-200 ms observation time and the approved T0-through-200 ms data set is available; exact contents await the DID/packing source.",
                "Defect Type Targeted": "Premature/missing 200 ms status; false data-valid claim.",
            },
        ),
        tbc_case(
            "EDR-ICE-R06-200MS-BOUNDARY-002",
            source_reference(10, "6"),
            "Characterize 200msCompletionStatus at 199 ms, 200 ms, 201 ms and scheduler-tick-relative points.",
            "Timing boundary / scheduler",
            "P0",
            "AMB-003; AMB-007",
            "No exact-at-boundary comparator, task period, or timing tolerance is supplied.",
            {
                "Input Event Sequence": "One EDR-recording event; observe at T0+199 ms, +200 ms, +201 ms and tick-relative points.",
                "Event Type": "Any source-applicable EDR event.",
                "Timing Between Events": "199 ms / 200 ms / 201 ms after T0; tick-relative values TBC.",
                "Detailed Test Steps": "1. Instrument the approved T0 source. 2. Trigger the event. 3. Read/observe the decoded 200msCompletionStatus at every timing point. 4. Compare only after the timing tolerance is approved.",
                "Defect Type Targeted": "Off-by-one time comparison; incomplete 200 ms data flagged valid.",
            },
        ),
        test_case(
            "EDR-ICE-R07-UNCONFIRMED-001",
            source_reference(11, "7"),
            "Verify classification as unconfirmed crash when the onboard longitudinal signal is present and both FRSU values are zero.",
            "Event classification / decision table",
            "P1",
            "IN REVIEW",
            "AMB-011",
            "The source does not specify EDR recording, locking, CAN output, or delayed-confirmation behavior for an unconfirmed crash.",
            {
                "Input Event Sequence": "Onboard longitudinal input present; FRSU1=0; FRSU2=0.",
                "Event Type": "Unconfirmed Crash.",
                "Detailed Test Steps": "1. Apply valid onboard longitudinal input. 2. Set both FRSU values to 0 under the approved sensor interface procedure. 3. Trigger the classification evaluation. 4. Capture the approved classification observable.",
                "Expected EDR1 Content": "TBC: recording behavior is not stated for unconfirmed crash.",
                "Expected EDR2 Content": "TBC: recording behavior is not stated for unconfirmed crash.",
                "Expected RecordLockStatus": "TBC: locking behavior is not stated for unconfirmed crash.",
                "Expected STS_CRASH": "TBC: CAN-output behavior is not stated for unconfirmed crash.",
                "Expected DOOR_UNLOCK": "TBC: CAN-output behavior is not stated for unconfirmed crash.",
                "Pass / Fail Criteria": "Pass when the architect-approved classification observable reports Unconfirmed Crash for the stated input combination; do not judge unstated EDR/CAN outcomes.",
                "Defect Type Targeted": "Incorrect use of stale/non-zero FRSU data; incorrect event classification.",
            },
        ),
    ]


def build_completion_cases() -> list[dict[str, str]]:
    completion_vectors = [
        ("EDR-ICE-COMP-00-00-001", 53, "0", "0", "EDR data not valid", "Applicable for battery-cutoff crash."),
        ("EDR-ICE-COMP-00-01-002", 54, "0", "1", "EDR data valid up to 200 ms", "Source does not define the data element list or durable-write boundary."),
        ("EDR-ICE-COMP-01-DC-003", 55, "1", "don't care", "EDR data valid", "Applicable for no battery-cutoff crash; 200msCompletionStatus is don't care."),
    ]
    cases: list[dict[str, str]] = []
    for case_id, row_number, completion, completion_200, data_validity, note in completion_vectors:
        cases.append(
            test_case(
                case_id,
                f"{SOURCE_NAME} | EDR_Requirements!B{row_number}:E{row_number} | CompletionStatus table",
                f"Verify source-defined data-validity meaning for CompletionStatus={completion} and 200msCompletionStatus={completion_200}.",
                "Completion-state decision table",
                "P0",
                "IN REVIEW",
                "AMB-007",
                note,
                {
                    "Input Event Sequence": "One event with power profile required to reach the stated completion-state combination.",
                    "Event Type": "Any source-applicable EDR event.",
                    "Power Conditions": "Use an architect-approved battery-cutoff or no-cutoff profile; electrical thresholds are not supplied.",
                    "Detailed Test Steps": "1. Establish the power/event profile that produces the stated status pair. 2. Read decoded completion flags and the applicable EDR data. 3. Compare the data-validity outcome to the source table.",
                    "Expected CompletionStatus": completion,
                    "Expected 200msCompletionStatus": completion_200,
                    "Expected UDS or DID Response": f"Decoded completion-state meaning: {data_validity}.",
                    "Pass / Fail Criteria": f"Pass when CompletionStatus={completion}, 200msCompletionStatus={completion_200}, and the observed validity claim is '{data_validity}'.",
                    "Defect Type Targeted": "Incorrect battery-cutoff completion interpretation; false data-valid result.",
                },
            )
        )
    return cases


def build_vector_cases(vectors: list[dict[str, Any]]) -> list[dict[str, str]]:
    cases: list[dict[str, str]] = []
    family_counts: Counter[str] = Counter()
    for vector in vectors:
        family_counts[vector["family"]] += 1
        prefix = "SGL" if vector["family"] == "Single event" else "MLT"
        case_id = f"EDR-ICE-VEC-{prefix}-{family_counts[vector['family']]:02d}"
        events = [event_label(vector[f"event_{index}"]) for index in range(1, 4)]
        source = (
            f"{SOURCE_NAME} | EDR_Requirements!B{vector['source_row']}:V{vector['source_row']} | "
            f"{vector['family']} source vector"
        )
        cases.append(
            test_case(
                case_id,
                source,
                f"Verify the supplied {vector['family'].lower()} three-event EDR1/EDR2 retention and metadata vector.",
                "Sequence / source-vector retention",
                "P0",
                "IN REVIEW",
                "AMB-003; AMB-004; AMB-005; AMB-006; AMB-010",
                "The source table defines three-event outcomes, but not formal slot-allocation rules, initial reset state, T0 reference, DID access, or counter behavior for discarded inputs.",
                {
                    "ECU Variant": "Mahindra label shown by the source vector table; exact target variant is not stated.",
                    "Initial EDR1 State": "Assumption A-001 for review: table represents a clean baseline before Event 1; source does not state the reset method.",
                    "Initial EDR2 State": "Assumption A-001 for review: table represents a clean baseline before Event 1; source does not state the reset method.",
                    "Preconditions": "Obtain architect-approved clean baseline and decoder for the table fields before execution.",
                    "Input Event Sequence": f"Event1={events[0]}; Event2={events[1]}; Event3={events[2]}.",
                    "Event Type": "Three-event Near Crash / Deployment permutation.",
                    "Timing Between Events": vector["timing"],
                    "Detailed Test Steps": "1. Establish the approved source-vector baseline. 2. Apply Event 1, Event 2, and Event 3 at the source-table timing class. 3. Capture EDR1/EDR2 immediately after Event 2. 4. Capture EDR1/EDR2 immediately after Event 3. 5. Decode retention, multi-event number, time-between-events, lifetime number, and lock status.",
                    "Expected EDR1 Content": f"After Event 2: {vector['after_2_edr1']}; after Event 3: {vector['after_3_edr1']}.",
                    "Expected EDR2 Content": f"After Event 2: {vector['after_2_edr2']}; after Event 3: {vector['after_3_edr2']}.",
                    "Expected MultiEventNumber": f"After Event 2 EDR1/EDR2: {vector['after_2_multi_1']} / {vector['after_2_multi_2']}; after Event 3 EDR1/EDR2: {vector['after_3_multi_1']} / {vector['after_3_multi_2']}.",
                    "Expected TimeBetweenEvents": f"After Event 2 EDR1/EDR2: {vector['after_2_time_1']} / {vector['after_2_time_2']}; after Event 3 EDR1/EDR2: {vector['after_3_time_1']} / {vector['after_3_time_2']}.",
                    "Expected LifetimeEventNumber": f"After Event 2 EDR1/EDR2: {vector['after_2_lifetime_1']} / {vector['after_2_lifetime_2']}; after Event 3 EDR1/EDR2: {vector['after_3_lifetime_1']} / {vector['after_3_lifetime_2']}.",
                    "Expected RecordLockStatus": f"After Event 3 EDR1/EDR2: {vector['after_3_lock_1']} / {vector['after_3_lock_2']}.",
                    "Expected CompletionStatus": "Not stated by the source vector.",
                    "Expected 200msCompletionStatus": "Not stated by the source vector.",
                    "Expected STS_CRASH": "For every near-crash input, STS_CRASH is not transmitted (ICE-EDR-R04). Deployment behavior is not stated in the vector table.",
                    "Expected DOOR_UNLOCK": "For every near-crash input, DOOR_UNLOCK is not transmitted (ICE-EDR-R04). Deployment behavior is not stated in the vector table.",
                    "Expected UDS or DID Response": "Decoded applicable EDR response matches the source-table fields; DID request/response syntax is TBC.",
                    "Persistence Check After Power Cycle": "TBC: vector table does not state persistence procedure; retain evidence for later NVM verification.",
                    "Pass / Fail Criteria": "Pass when the decoded fields after Event 2 and Event 3 exactly match the cited source-vector row. Do not infer fourth-event policy from this result.",
                    "Defect Type Targeted": "Wrong slot selection, lock association, multi-event/lifetime association, or time-between-events association.",
                },
            )
        )
    return cases


def build_timing_cases() -> list[dict[str, str]]:
    timing_cases = [
        (
            "EDR-ICE-TIM-OVERLAP-001",
            "0 ms and 1 ms event separation",
            "Characterize simultaneous/near-simultaneous event handling at 0 ms and 1 ms separation.",
            "0 ms / 1 ms",
            "Parallel event, merge, reject, and counter behavior are not defined.",
        ),
        (
            "EDR-ICE-TIM-300MS-002",
            "299 ms, 300 ms, and 301 ms event separation",
            "Characterize event classification and slot handling around the 300 ms test-design boundary.",
            "299 ms / 300 ms / 301 ms",
            "No source behavior is given at these values.",
        ),
        (
            "EDR-ICE-TIM-MULTI-003",
            "499 ms, 500 ms, and 501 ms event separation",
            "Resolve event classification and metadata behavior around the source's >500 ms multi-event threshold.",
            "499 ms / 500 ms / 501 ms",
            "The source defines >500 ms and <5 s only; exact 500 ms and timestamp reference are not defined.",
        ),
        (
            "EDR-ICE-TIM-SINGLE-004",
            "4.999 s, 5.000 s, and 5.001 s event separation",
            "Resolve event classification and metadata behavior around the source's <5 s multi-event and >5 s single-event boundaries.",
            "4.999 s / 5.000 s / 5.001 s",
            "The source leaves exactly 5.000 s undefined and does not define the time measurement reference.",
        ),
        (
            "EDR-ICE-TIM-SCHEDULER-005",
            "Scheduler-tick and tolerance sweep",
            "Characterize one tick before, on, and after each 200 ms, 500 ms, and 5 s boundary using approved measurement accuracy.",
            "Tick-relative values and min/max tolerance",
            "No scheduler period or tolerance is provided.",
        ),
    ]
    cases: list[dict[str, str]] = []
    for case_id, title, objective, timing, notes in timing_cases:
        cases.append(
            tbc_case(
                case_id,
                f"{SOURCE_NAME} | EDR_Requirements!B13:V49 | timing-class tables",
                objective,
                "Timing boundary / state transition",
                "P0",
                "AMB-003",
                notes,
                {
                    "Input Event Sequence": f"Two events separated by {timing}.",
                    "Event Type": "Near Crash and Deployment permutations selected by pairwise vector.",
                    "Timing Between Events": timing,
                    "Detailed Test Steps": "1. Capture the approved timing reference. 2. Apply the two-event permutation at every listed boundary. 3. Decode EDR1/EDR2, counters, time-between-events, lock status, and CAN outputs. 4. Compare only to a clarified boundary rule.",
                    "Defect Type Targeted": "Off-by-one threshold, timing reference, tick conversion, and event-merge defects.",
                },
            )
        )
    return cases


def build_overwrite_cases() -> list[dict[str, str]]:
    scenarios = [
        ("EDR-ICE-OVR-OLDEST-001", "Fourth event with both records unlocked", "Replace the oldest unlocked record."),
        ("EDR-ICE-OVR-NEWEST-002", "Fourth event with both records unlocked", "Replace the newest unlocked record."),
        ("EDR-ICE-OVR-PRIORITY-003", "Fourth event with both records unlocked", "Replace the lowest-priority unlocked record."),
        ("EDR-ICE-OVR-REJECT-004", "Fourth event with both records unlocked", "Reject the incoming event and preserve both records."),
        ("EDR-ICE-OVR-OVERFLOW-005", "Fourth event with both records unlocked", "Store only metadata or an overflow indication; preserve existing records."),
        ("EDR-ICE-OVR-ONELOCK-DEPLOY-006", "Fourth deployment with EDR1 locked and EDR2 unlocked", "Select/reject behavior and counter association."),
        ("EDR-ICE-OVR-ONELOCK-NEAR-007", "Fourth near crash with EDR1 locked and EDR2 unlocked", "Select/reject behavior and near-crash replacement priority."),
        ("EDR-ICE-OVR-BOTHLOCK-DEPLOY-008", "Fourth deployment with both records locked", "Confirm preservation, rejection, overflow, or an explicit permitted overwrite policy."),
        ("EDR-ICE-OVR-BOTHLOCK-NEAR-009", "Fourth near crash with both records locked", "Confirm preservation, rejection, or other defined behavior."),
        ("EDR-ICE-OVR-INCOMPLETE-010", "Incoming event with one complete and one CRC-invalid/incomplete record", "Confirm recovery, selected slot, diagnostics, and no mixed record data."),
    ]
    cases: list[dict[str, str]] = []
    for case_id, sequence, interpretation in scenarios:
        cases.append(
            tbc_case(
                case_id,
                f"{SOURCE_NAME} | EDR_Requirements!B23:V49 | source tables stop at Event 3",
                f"Provisional fourth/fifth-event test for credible interpretation: {interpretation}",
                "Storage-full / overwrite decision table",
                "P0",
                "AMB-004; AMB-005; AMB-006; AMB-008",
                "Each row is a provisional test case, not an approved expected behavior. The architect must select exactly one supported policy per applicable state.",
                {
                    "Input Event Sequence": sequence,
                    "Event Type": "Near Crash and/or Deployment Event as stated by the scenario.",
                    "Initial EDR1 State": "Scenario-defined; record age, lifetime number, lock state, completion state, and validity must be controlled.",
                    "Initial EDR2 State": "Scenario-defined; record age, lifetime number, lock state, completion state, and validity must be controlled.",
                    "Timing Between Events": "TBC: select clarified single/multi-event relation.",
                    "Detailed Test Steps": "1. Establish the stated two-slot storage state by an architect-approved procedure. 2. Apply the incoming fourth/fifth event. 3. Read EDR1/EDR2 and relevant diagnostic data three times. 4. Power cycle only under an approved procedure and reread. 5. Compare to the architect-selected replacement policy.",
                    "Expected EDR1 Content": f"{TBC} Provisional interpretation: {interpretation}",
                    "Expected EDR2 Content": f"{TBC} Provisional interpretation: {interpretation}",
                    "Expected MultiEventNumber": f"{TBC} Provisional interpretation: {interpretation}",
                    "Expected TimeBetweenEvents": f"{TBC} Provisional interpretation: {interpretation}",
                    "Expected LifetimeEventNumber": f"{TBC} Provisional interpretation: {interpretation}",
                    "Expected RecordLockStatus": f"{TBC} Provisional interpretation: {interpretation}",
                    "Defect Type Targeted": "Locked-record overwrite, wrong unlocked-slot selection, counter association, incomplete-record recovery, and storage-full corruption.",
                },
            )
        )
    return cases


POWER_PHASES = [
    ("PWR-P01", "Before T0"),
    ("PWR-P02", "Exactly at T0"),
    ("PWR-P03", "T0 + 1 ms"),
    ("PWR-P04", "T0 + 199 ms"),
    ("PWR-P05", "T0 + 200 ms"),
    ("PWR-P06", "T0 + 201 ms"),
    ("PWR-P07", "Immediately before CompletionStatus update"),
    ("PWR-P08", "During CompletionStatus update"),
    ("PWR-P09", "Immediately after CompletionStatus update"),
    ("PWR-P10", "During pre-crash-buffer freeze"),
    ("PWR-P11", "During record allocation"),
    ("PWR-P12", "During metadata write"),
    ("PWR-P13", "During payload write"),
    ("PWR-P14", "During CRC write"),
    ("PWR-P15", "During valid-marker update"),
    ("PWR-P16", "During lock-bit update"),
    ("PWR-P17", "During lifetime-counter update"),
    ("PWR-P18", "During multi-event-counter update"),
    ("PWR-P19", "During record replacement or erase"),
    ("PWR-P20", "During UDS/DID readout"),
    ("PWR-P21", "During shutdown preparation"),
    ("PWR-P22", "During a second event"),
    ("PWR-P23", "During a fourth or fifth event"),
]

POWER_MODES = [
    ("PWR-M01", "Hard battery disconnect"),
    ("PWR-M02", "KL15 off with KL30 retained"),
    ("PWR-M03", "KL30 loss with KL15 variation"),
    ("PWR-M04", "Ground interruption"),
    ("PWR-M05", "Brownout"),
    ("PWR-M06", "Slow voltage ramp down"),
    ("PWR-M07", "Fast voltage drop"),
    ("PWR-M08", "Voltage oscillation around reset threshold"),
    ("PWR-M09", "Short interruption"),
    ("PWR-M10", "Repeated interruptions"),
    ("PWR-M11", "Power restored during write"),
    ("PWR-M12", "Reverse KL15/KL30 removal order"),
    ("PWR-M13", "Loss of CAN supply while ECU supply remains"),
]


def build_power_cases() -> list[dict[str, str]]:
    cases: list[dict[str, str]] = []
    for index, (phase_id, phase) in enumerate(POWER_PHASES, start=1):
        cases.append(
            tbc_case(
                f"EDR-ICE-PWR-{index:02d}",
                f"{SOURCE_NAME} | EDR_Requirements!B9:E10, B53:E57 | completion/battery-cutoff information only",
                f"Characterize EDR atomicity, persistence, status flags, and next-event recovery for a power interruption {phase.lower()}.",
                "Power interruption / NVM robustness",
                "P0",
                "AMB-007; AMB-008; AMB-010",
                "The source gives completion-state meanings but no NVM layout, write order, electrical limits, energy-reserve capability, valid marker, CRC, diagnostic access, or recovery oracle.",
                {
                    "Input Event Sequence": "One deployment and one near-crash sequence selected from the power matrix; include a fourth/fifth-event sequence where applicable.",
                    "Event Type": "Deployment Event and Near Crash parameter sweep.",
                    "T0 Source": "Capture the project-approved T0 source before arming any approved power-interruption procedure.",
                    "Power Conditions": f"Phase {phase_id}: {phase}. Sweep approved power modes PWR-M01 through PWR-M13 from the Power Interruption Matrix.",
                    "Diagnostic Conditions": "After restoration, initialize ECU, read all applicable EDR DIDs three times, perform an approved ignition cycle, then read again. DID request/response details are TBC.",
                    "Detailed Test Steps": "1. Select the matrix power mode and phase. 2. Establish a controlled EDR event/state. 3. Apply interruption only with an approved bench procedure. 4. Restore nominal power and wait for ECU initialization. 5. Read EDR data three times, perform an approved ignition cycle, and reread. 6. Inspect for atomicity, CRC/validity/lock consistency, persistence, and ability to record the next valid event.",
                    "Defect Type Targeted": "Mixed metadata/payload, partial erase, early valid marker, lock-after-valid ordering, lost/double counters, reset corruption, and unrecoverable storage state.",
                    "Automation Feasibility": "Semi-automatic after an approved power-control/trigger interface and source-backed NVM oracle are available; no bench operation is authorized by this design.",
                },
            )
        )
    return cases


CAN_SCENARIOS = [
    ("EDR-ICE-CAN-NOMINAL-001", "Nominal signal storage", "Nominal values across source-defined resolution, range, and sampling grid."),
    ("EDR-ICE-CAN-WAKE-002", "CAN wake-up timing", "Asleep with valid wake-up; wake immediately before, at, and after T0; repeated wake/sleep; wake chatter; wrong wake frame; partial network wake."),
    ("EDR-ICE-CAN-CRASHWAKE-003", "Crash wake-up without CAN", "Crash wake-up with no CAN data present."),
    ("EDR-ICE-CAN-AGE-004", "Data age and frame timing", "Missing, delayed, jittered, and wrong-cycle-time frames."),
    ("EDR-ICE-CAN-ORDER-005", "Frame ordering", "Duplicate and out-of-order frames around every EDR sample point."),
    ("EDR-ICE-CAN-INTEGRITY-006", "Frame/data integrity", "Rolling-counter error, CRC error, raw overflow, invalid enum, and multiplexer error."),
    ("EDR-ICE-CAN-FAILSAFE-007", "Signal availability and fail-safe", "Timeout, stuck-at, signal unavailable, and source-defined fail-safe behavior."),
    ("EDR-ICE-CAN-EDGE-008", "Sample-point edge", "Signal change immediately before, at, and after every source-defined EDR sample point."),
    ("EDR-ICE-CAN-CROSS-009", "Cross-signal consistency", "Vehicle speed/wheel speed, brake/deceleration, steering/lateral acceleration, deployment/time, crash/classification, validity/substitute value."),
    ("EDR-ICE-CAN-BUSOFF-010", "Bus-off and recovery", "Bus-off before event, at T0, during event, and recovery during recording."),
    ("EDR-ICE-CAN-DBC-011", "DBC representation", "Endian, bit-position, scaling, offset, unit, resolution, range, clamp, and source-to-EDR packing check."),
    ("EDR-ICE-CAN-LOSS-012", "CAN supply loss", "CAN supply loss while ECU supply remains present."),
]


def build_can_cases() -> list[dict[str, str]]:
    cases: list[dict[str, str]] = []
    for case_id, title, scenario in CAN_SCENARIOS:
        cases.append(
            tbc_case(
                case_id,
                source_reference(7, "3"),
                f"Verify EDR behavior for {title.lower()}: {scenario}",
                "CAN wake-up / data quality / fault injection",
                "P1",
                "AMB-002; AMB-009; AMB-010",
                "The required W501 matrix, DBC, node ownership, sample timestamps, on-fail mapping, and EDR byte-packing rules are unavailable.",
                {
                    "ECU Variant": "Target variant TBC.",
                    "Input Event Sequence": "One source-applicable event per CAN vector after communication evidence is supplied.",
                    "Event Type": "TBC by released matrix.",
                    "CAN Conditions": scenario,
                    "Detailed Test Steps": "1. Obtain the released W501 matrix, DBC, CAN wake-up rules, and source-to-EDR packing decoder. 2. Apply the specified CAN condition around source-defined EDR samples. 3. Trigger the target event. 4. Compare raw and physical stored values, validity, age, and timestamps to the approved oracle.",
                    "Defect Type Targeted": "False CAN validity, stale/misaligned sample, invalid-to-physical confusion, on-fail error, wake-up race, and packing defect.",
                    "Automation Feasibility": "Automatic after verified CAN simulation, DBC, wake-up, and EDR decoder artifacts are supplied.",
                },
            )
        )
    return cases


DIAGNOSTIC_SCENARIOS = [
    ("EDR-ICE-DIA-CAPTURE-001", "Read during event capture", "Read EDR data while event capture is active."),
    ("EDR-ICE-DIA-NVM-002", "Read during NVM activity", "Read during record write, interrupted write, and after reset."),
    ("EDR-ICE-DIA-CONCURRENT-003", "Concurrent/repeated reads", "Repeated reads, concurrent requests, and ECU reset during read."),
    ("EDR-ICE-DIA-NEGATIVE-004", "Negative diagnostics", "Unsupported DID, incorrect request length, session/security gating, and diagnostic timeout."),
    ("EDR-ICE-DIA-ASSOCIATION-005", "Data association", "Endianness, EDR1/EDR2 association, counters, lock bits, stale-byte leakage, and record mixing."),
]


def build_diagnostic_cases() -> list[dict[str, str]]:
    cases: list[dict[str, str]] = []
    for case_id, title, scenario in DIAGNOSTIC_SCENARIOS:
        cases.append(
            tbc_case(
                case_id,
                f"{SOURCE_NAME} | EDR_Requirements!E5 | generic EDR DID wording only",
                f"Verify diagnostic EDR behavior for {title.lower()}: {scenario}",
                "Diagnostics / data integrity",
                "P1",
                "AMB-001; AMB-008; AMB-010",
                "The source does not identify EDR DID numbers, UDS sessions, security, response length, response packing, NRCs, or read-while-recording policy.",
                {
                    "Diagnostic Conditions": scenario,
                    "Detailed Test Steps": "1. Obtain the released UDS/EDR-DID specification. 2. Establish the stated recording/diagnostic race condition. 3. Send the approved diagnostic request(s). 4. Capture timing and raw responses. 5. Compare to the released DID/UDS oracle without accepting mixed or stale data.",
                    "Defect Type Targeted": "Read/record interference, stale/mixed response, wrong association, incorrect gating, and inconsistent repeated read.",
                    "Automation Feasibility": "Automatic after approved UDS request/response definitions and a diagnostic transport are supplied.",
                },
            )
        )
    return cases


VARIANT_SCENARIOS = [
    ("EDR-ICE-VAR-HIGH-001", "High variant with SRSU", "Confirm applicable side-event and front-event behavior against its own released requirements."),
    ("EDR-ICE-VAR-DOMESTIC-002", "Domestic configuration", "Compare configured Domestic behavior with source applicability; coding evidence is required."),
    ("EDR-ICE-VAR-CODING-003", "Variant coding change", "Change coding before and after an event only under an approved procedure; check pre-existing data interpretation."),
    ("EDR-ICE-VAR-CORRUPT-004", "Invalid/corrupt variant coding", "Characterize EDR behavior, safety reaction, and recovery after a controlled coding-validity condition."),
    ("EDR-ICE-VAR-FRONT-005", "Front event across variants", "Verify that side-event suppression does not suppress applicable front-event behavior."),
]


def build_variant_cases() -> list[dict[str, str]]:
    cases: list[dict[str, str]] = []
    for case_id, title, scenario in VARIANT_SCENARIOS:
        cases.append(
            tbc_case(
                case_id,
                f"{SOURCE_NAME} | EDR_Requirements!E6 | only Low/Mid Domestic without-SRSU side-event rule is specified",
                f"Provisional variant-coverage test: {title}.",
                "Variant applicability / robustness",
                "P1",
                "AMB-013; AMB-014",
                "The primary EDR sheet does not provide variant-code maps, High/market applicability, coding validity behavior, or front-event expectations.",
                {
                    "ECU Variant": title,
                    "Input Event Sequence": scenario,
                    "Event Type": "Side and/or front event as stated by the scenario.",
                    "Detailed Test Steps": "1. Obtain released target-variant coding and feature configuration evidence. 2. Establish the variant state through an approved procedure. 3. Apply the stated event. 4. Compare EDR and unrelated outputs to their released, variant-specific requirements.",
                    "Defect Type Targeted": "Variant implementation leakage; invalid coding recovery; unintended front-event suppression.",
                },
            )
        )
    return cases


ROBUSTNESS_SCENARIOS = [
    ("EDR-ICE-ROB-NEAR-001", "Repeated near crashes", "Repeated near crashes, including overlapping/discarded events, before a later deployment."),
    ("EDR-ICE-ROB-UNCONF-002", "Repeated unconfirmed crashes", "Repeated unconfirmed events with FRSU timing variations."),
    ("EDR-ICE-ROB-DEPLOY-003", "Repeated deployments", "Repeated deployment events through 2, 3, 4, 5, 10, and N event counts."),
    ("EDR-ICE-ROB-SEQUENCE-004", "Property-based sequence campaign", "Randomized 0, 1, 2, 3, 4, 5, 10, and N-event sequences with shrinking."),
    ("EDR-ICE-ROB-POST-005", "Event during post-crash collection", "Second event during first event's 200 ms/five-second collection state."),
    ("EDR-ICE-ROB-WRITE-006", "Event during NVM activity", "Second event during allocation, write, replacement, or erase."),
    ("EDR-ICE-ROB-READ-007", "Event during diagnostic read", "Event begins while a diagnostic client is reading EDR data."),
    ("EDR-ICE-ROB-MODE-008", "Operating-mode races", "Event during shutdown, startup, CAN wake-up, crash wake-up, and immediately after watchdog reset."),
    ("EDR-ICE-ROB-COUNTER-009", "Counter limits", "Lifetime and multi-event counters at normal, maximum-1, maximum, saturation, and rollover states."),
    ("EDR-ICE-ROB-ENDURANCE-010", "Long-duration endurance", "Repeated valid/invalid sequences, power recoveries, and diagnostic reads with periodic evidence snapshots."),
]


def build_robustness_cases() -> list[dict[str, str]]:
    cases: list[dict[str, str]] = []
    for case_id, title, scenario in ROBUSTNESS_SCENARIOS:
        cases.append(
            tbc_case(
                case_id,
                f"{SOURCE_NAME} | EDR_Requirements!B5:V57 | coverage extension beyond supplied three-event examples",
                f"Provisional robustness campaign: {title}.",
                "Robustness / stress / sequence testing",
                "P3" if "Endurance" in title else "P1",
                "AMB-004; AMB-005; AMB-006; AMB-007; AMB-008; AMB-011",
                "The source does not define resource limits, concurrent-event arbitration, NVM state machine, counter limit policy, reset recovery, or endurance acceptance criteria.",
                {
                    "Input Event Sequence": scenario,
                    "Event Type": "Near Crash, Unconfirmed Crash, and Deployment Event parameter sweep.",
                    "Detailed Test Steps": "1. Obtain an approved state/counter/overwrite/NVM oracle. 2. Generate or select the stated sequence. 3. Capture all event timestamps, EDR snapshots, CAN outputs, power/reset history, and diagnostic reads. 4. Minimize any failing randomized sequence to the smallest reproducible prefix.",
                    "Defect Type Targeted": "State-machine exhaustion, race condition, counter rollover, corruption, non-determinism, and unbounded resource use.",
                    "Automation Feasibility": "Automatic only after approved event injection, power/reset orchestration, DID decoding, and oracle definitions are supplied.",
                },
            )
        )
    return cases


def build_cases(source_data: dict[str, Any]) -> list[dict[str, str]]:
    cases = []
    cases.extend(build_source_rule_cases())
    cases.extend(build_completion_cases())
    cases.extend(build_vector_cases(source_data["vectors"]))
    cases.extend(build_timing_cases())
    cases.extend(build_overwrite_cases())
    cases.extend(build_power_cases())
    cases.extend(build_can_cases())
    cases.extend(build_diagnostic_cases())
    cases.extend(build_variant_cases())
    cases.extend(build_robustness_cases())
    priority_order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
    cases.sort(key=lambda row: (priority_order[row["Priority"]], row["Test Case ID"]))
    identifiers = [row["Test Case ID"] for row in cases]
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("Generated test-case IDs are not unique.")
    return cases


def make_rows(items: list[dict[str, Any]], headers: list[str]) -> list[list[str]]:
    return [[str(item.get(header, "")) for header in headers] for item in items]


def add_title(sheet: Any, title: str, subtitle: str, width: int) -> None:
    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=width)
    sheet.cell(1, 1, title)
    sheet.cell(1, 1).font = Font(bold=True, color=WHITE, size=14)
    sheet.cell(1, 1).fill = PatternFill("solid", fgColor=NAVY)
    sheet.cell(1, 1).alignment = Alignment(horizontal="left", vertical="center")
    sheet.row_dimensions[1].height = 24
    sheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=width)
    sheet.cell(2, 1, subtitle)
    sheet.cell(2, 1).font = Font(italic=True, color="404040")
    sheet.cell(2, 1).alignment = Alignment(wrap_text=True, vertical="top")
    sheet.row_dimensions[2].height = 38


def write_table(
    workbook: Workbook,
    sheet_name: str,
    title: str,
    subtitle: str,
    headers: list[str],
    rows: list[list[str]],
    tab_color: str = BLUE,
) -> Any:
    sheet = workbook.create_sheet(sheet_name)
    sheet.sheet_properties.tabColor = tab_color
    add_title(sheet, title, subtitle, len(headers))
    header_row = 4
    for column_number, header in enumerate(headers, start=1):
        cell = sheet.cell(header_row, column_number, header)
        cell.font = Font(bold=True, color=WHITE)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)
    sheet.row_dimensions[header_row].height = 34
    for row_number, values in enumerate(rows, start=header_row + 1):
        maximum_length = 0
        for column_number, value in enumerate(values, start=1):
            cell = sheet.cell(row_number, column_number, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)
            if row_number % 2:
                cell.fill = PatternFill("solid", fgColor="F8FBFD")
            maximum_length = max(maximum_length, len(str(value)))
        sheet.row_dimensions[row_number].height = min(180, max(28, 14 * (1 + maximum_length // 120)))
    sheet.freeze_panes = "A5"
    sheet.auto_filter.ref = f"A4:{get_column_letter(len(headers))}{max(4, header_row + len(rows))}"
    for column_number in range(1, len(headers) + 1):
        values = [str(headers[column_number - 1])] + [str(row[column_number - 1]) for row in rows]
        longest = max(len(value.split("\n")[0]) for value in values)
        sheet.column_dimensions[get_column_letter(column_number)].width = min(55, max(13, longest + 2))
    return sheet


def shade_status_cells(sheet: Any, header: str) -> None:
    headers = {cell.value: cell.column for cell in sheet[4]}
    if header not in headers:
        return
    column = headers[header]
    for row_number in range(5, sheet.max_row + 1):
        cell = sheet.cell(row_number, column)
        value = str(cell.value or "")
        if "ON HOLD" in value or value == "ON HOLD":
            cell.fill = PatternFill("solid", fgColor=AMBER)
        elif "IN REVIEW" in value:
            cell.fill = PatternFill("solid", fgColor=BLUE)
        elif "READY" in value or "Covered" in value:
            cell.fill = PatternFill("solid", fgColor=GREEN)


def build_document_control(source_data: dict[str, Any], cases: list[dict[str, str]]) -> list[list[str]]:
    status_count = Counter(case["Execution Status"] for case in cases)
    return [
        ["Document title", "ICE Common SRS V1.4 EDR Test-Spec Design Matrix"],
        ["Purpose", "Offline engineering-review test design, coverage matrix, ambiguity register, and residual-risk register for the EDR_Requirements sheet."],
        ["Output class", "Internal engineering-review workbook. It is not an import-ready Codebeamer/Veoneer export."],
        ["Source authority", f"{SOURCE_NAME} / EDR_Requirements is the primary source for behavioral rows used in this design."],
        ["Source SHA-256", source_data["source_hash"]],
        ["Source parser", "openpyxl read-only, data_only=True; full workbook was initially extracted offline and source rows used here are re-verified during generation."],
        ["Source workbook inventory", f"{source_data['source_sheet_count']} sheets; EDR_Requirements dimension {source_data['edr_sheet_dimension']} ({source_data['edr_sheet_rows']} rows)."],
        ["Traceability limitation", SOURCE_TRACEABILITY_NOTICE],
        ["DBC/communication limitation", "M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156 is referenced by the source but unavailable locally; CAN byte-level oracles are ON HOLD."],
        ["Bench safety", "This package does not operate bench hardware. Execution requires separate explicit authorization and approved procedures."],
        ["Test-design state", f"{len(cases)} logical test cases: {status_count.get('IN REVIEW', 0)} source-backed/partial-oracle review cases and {status_count.get('ON HOLD', 0)} TBC cases."],
        ["Generated on", date.today().isoformat()],
        ["Review gate", "Do not mark an ON HOLD case pass/fail until its ambiguity is resolved with source evidence and a test oracle is approved."],
    ]


def build_requirement_rows(cases: list[dict[str, str]]) -> list[list[str]]:
    rows: list[list[str]] = []
    for requirement in REQUIREMENTS:
        ref = source_reference(requirement["source_row"], requirement["serial"])
        matching = [case["Test Case ID"] for case in cases if ref in case["Source Requirement Reference"]]
        rows.append(
            [
                requirement["key"],
                requirement["serial"],
                requirement["topic"],
                ref,
                requirement["statement"],
                requirement["conditions"],
                requirement["observable"],
                SOURCE_TRACEABILITY_NOTICE,
                "; ".join(matching),
                requirement["confidence"],
                "Covered by source-backed or partial-oracle design cases; see ambiguity register for limits.",
            ]
        )
    rows.extend(
        [
            [
                "ICE-EDR-VEC-SINGLE",
                "Table",
                "Single-event source vectors",
                f"{SOURCE_NAME} | EDR_Requirements!B23:V30",
                "Eight three-event Near Crash/Deployment permutations with time between events more than 5 s.",
                "Three input events in supplied source vector.",
                "EDR1/EDR2 retained event, multi-event number, time-between-events, lifetime number, and lock status after Event 2/Event 3.",
                SOURCE_TRACEABILITY_NOTICE,
                "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-VEC-SGL" in case["Test Case ID"]),
                "High",
                "Three-event behavior only; not a fourth/fifth-event replacement requirement.",
            ],
            [
                "ICE-EDR-VEC-MULTI",
                "Table",
                "Multi-event source vectors",
                f"{SOURCE_NAME} | EDR_Requirements!B42:V49",
                "Eight three-event Near Crash/Deployment permutations with time between events >500 ms and <5 s.",
                "Three input events in supplied source vector.",
                "EDR1/EDR2 retained event, multi-event number, time-between-events, lifetime number, and lock status after Event 2/Event 3.",
                SOURCE_TRACEABILITY_NOTICE,
                "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-VEC-MLT" in case["Test Case ID"]),
                "High",
                "Exact 500 ms/5.000 s behavior and timing reference are unresolved.",
            ],
            [
                "ICE-EDR-COMP-TABLE",
                "Table",
                "Completion-status decision table",
                f"{SOURCE_NAME} | EDR_Requirements!B53:E55",
                "Three data-validity outcomes for CompletionStatus and 200msCompletionStatus.",
                "Battery cutoff/no cutoff as described by source table.",
                "Invalid data at 0/0, valid through 200 ms at 0/1, valid data at 1/don't care.",
                SOURCE_TRACEABILITY_NOTICE,
                "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-COMP-" in case["Test Case ID"]),
                "Very High",
                "Dataset contents and durable-write boundary remain TBC.",
            ],
        ]
    )
    return rows


def build_vector_rows(vectors: list[dict[str, Any]], cases: list[dict[str, str]]) -> list[list[str]]:
    rows: list[list[str]] = []
    family_counts: Counter[str] = Counter()
    for vector in vectors:
        family_counts[vector["family"]] += 1
        prefix = "SGL" if vector["family"] == "Single event" else "MLT"
        case_id = f"EDR-ICE-VEC-{prefix}-{family_counts[vector['family']]:02d}"
        rows.append(
            [
                case_id,
                vector["family"],
                f"EDR_Requirements!B{vector['source_row']}:V{vector['source_row']}",
                vector["event_1"],
                vector["event_2"],
                vector["event_3"],
                vector["after_2_edr1"],
                vector["after_2_edr2"],
                f"{vector['after_2_multi_1']} / {vector['after_2_multi_2']}",
                f"{vector['after_2_time_1']} / {vector['after_2_time_2']}",
                f"{vector['after_2_lifetime_1']} / {vector['after_2_lifetime_2']}",
                vector["after_3_edr1"],
                vector["after_3_edr2"],
                f"{vector['after_3_multi_1']} / {vector['after_3_multi_2']}",
                f"{vector['after_3_time_1']} / {vector['after_3_time_2']}",
                f"{vector['after_3_lifetime_1']} / {vector['after_3_lifetime_2']}",
                f"{vector['after_3_lock_1']} / {vector['after_3_lock_2']}",
                vector["timing"],
            ]
        )
    return rows


def build_event_count_rows() -> list[list[str]]:
    return [
        ["0", "No EDR event", "EDR-ICE-R01-DEFAULT-001", "Source-backed default FF.. rule.", "IN REVIEW"],
        ["1", "Near crash / unconfirmed crash / event with completion checks", "EDR-ICE-R04-NEAR-CRASH-001; EDR-ICE-R05-COMPLETE-AFTER-5S-001; EDR-ICE-R06-200MS-COMPLETE-001; EDR-ICE-R07-UNCONFIRMED-001", "Source-backed partial behavior; event type/persistence detail varies.", "IN REVIEW"],
        ["2", "Interim Event 2 observation in every supplied source vector", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "Source table supplies EDR1/EDR2 and metadata after Event 2.", "IN REVIEW"],
        ["3", "All Near Crash/Deployment binary permutations", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "Sixteen source-table vectors cover three-event binary permutations under two timing classes.", "IN REVIEW"],
        ["4", "Storage-full/replacement policy", "EDR-ICE-OVR-OLDEST-001..EDR-ICE-OVR-INCOMPLETE-010", "Source stops at Event 3; all fourth-event outcomes are provisional.", "ON HOLD"],
        ["5", "Fifth-event/recovery policy", "EDR-ICE-OVR-OLDEST-001..EDR-ICE-OVR-INCOMPLETE-010; EDR-ICE-ROB-SEQUENCE-004", "Source stops at Event 3; all fifth-event outcomes are provisional.", "ON HOLD"],
        ["10", "Stress sequence", "EDR-ICE-ROB-DEPLOY-003; EDR-ICE-ROB-SEQUENCE-004", "Counter/storage/exhaustion oracle unavailable.", "ON HOLD"],
        ["N", "Configurable property-based campaign", "EDR-ICE-ROB-SEQUENCE-004; EDR-ICE-ROB-ENDURANCE-010", "N limit, replacement, counter, and resource policy unavailable.", "ON HOLD"],
    ]


def build_lock_rows() -> list[list[str]]:
    rows = [
        ["Both records empty", "First event placement", "EDR-ICE-VEC-SGL-01; EDR-ICE-VEC-MLT-01", "Source table implies a baseline but does not state initialization/slot-allocation policy.", "IN REVIEW"],
        ["EDR1 unlocked / EDR2 empty", "Incoming deployment or near crash", "EDR-ICE-OVR-ONELOCK-DEPLOY-006; EDR-ICE-OVR-ONELOCK-NEAR-007", TBC, "ON HOLD"],
        ["EDR1 locked / EDR2 empty", "Incoming deployment or near crash", "EDR-ICE-OVR-ONELOCK-DEPLOY-006; EDR-ICE-OVR-ONELOCK-NEAR-007", TBC, "ON HOLD"],
        ["Both unlocked", "Fourth event", "EDR-ICE-OVR-OLDEST-001..EDR-ICE-OVR-OVERFLOW-005", "Five credible policy interpretations are separately represented.", "ON HOLD"],
        ["EDR1 locked / EDR2 unlocked", "Fourth event", "EDR-ICE-OVR-ONELOCK-DEPLOY-006; EDR-ICE-OVR-ONELOCK-NEAR-007", TBC, "ON HOLD"],
        ["EDR1 unlocked / EDR2 locked", "Fourth event", "EDR-ICE-OVR-ONELOCK-DEPLOY-006; EDR-ICE-OVR-ONELOCK-NEAR-007", TBC, "ON HOLD"],
        ["Both locked", "Fourth/fifth event", "EDR-ICE-OVR-BOTHLOCK-DEPLOY-008; EDR-ICE-OVR-BOTHLOCK-NEAR-009", "Source table retains two locked first events for one Event 3 vector but does not formally define rejection/overflow/counter behavior.", "ON HOLD"],
        ["One complete / one incomplete or CRC-invalid", "Incoming event", "EDR-ICE-OVR-INCOMPLETE-010; EDR-ICE-PWR-12..23", TBC, "ON HOLD"],
        ["Counter normal / max-1 / max / rollover", "Incoming event", "EDR-ICE-ROB-COUNTER-009", TBC, "ON HOLD"],
    ]
    return rows


def build_timing_rows() -> list[list[str]]:
    return [
        ["0 ms", "Parallel/overlap relation", "EDR-ICE-TIM-OVERLAP-001", TBC, "ON HOLD"],
        ["1 ms", "Near-simultaneous relation", "EDR-ICE-TIM-OVERLAP-001", TBC, "ON HOLD"],
        ["199 ms", "200 ms completion boundary", "EDR-ICE-R06-200MS-BOUNDARY-002", TBC, "ON HOLD"],
        ["200 ms", "200 ms completion boundary", "EDR-ICE-R06-200MS-COMPLETE-001; EDR-ICE-R06-200MS-BOUNDARY-002", "Status becomes 1 after 200 ms; exact boundary/tolerance is TBC.", "IN REVIEW / ON HOLD"],
        ["201 ms", "200 ms completion boundary", "EDR-ICE-R06-200MS-BOUNDARY-002", TBC, "ON HOLD"],
        ["299 ms", "Intermediate relation", "EDR-ICE-TIM-300MS-002", TBC, "ON HOLD"],
        ["300 ms", "Intermediate relation", "EDR-ICE-TIM-300MS-002", TBC, "ON HOLD"],
        ["301 ms", "Intermediate relation", "EDR-ICE-TIM-300MS-002", TBC, "ON HOLD"],
        ["499 ms", "Before >500 ms multi-event threshold", "EDR-ICE-TIM-MULTI-003", TBC, "ON HOLD"],
        ["500 ms", "Exact >500 ms multi-event threshold", "EDR-ICE-TIM-MULTI-003", TBC, "ON HOLD"],
        ["501 ms", "After >500 ms multi-event threshold", "EDR-ICE-TIM-MULTI-003", "Source gives >500 ms and <5 s but not time reference or samples at 501 ms.", "ON HOLD"],
        ["4.999 s", "Before 5 s timing class", "EDR-ICE-TIM-SINGLE-004", "Source table labels multi-event <5 s but not exact timestamp reference.", "ON HOLD"],
        ["5.000 s", "Exact 5 s timing class / CompletionStatus threshold", "EDR-ICE-TIM-SINGLE-004; EDR-ICE-R05-5S-BOUNDARY-002", TBC, "ON HOLD"],
        ["5.001 s", "After 5 s timing class / CompletionStatus observation", "EDR-ICE-TIM-SINGLE-004; EDR-ICE-R05-COMPLETE-AFTER-5S-001", "Source says >5 s single event and CompletionStatus after 5 s; tolerance/time reference TBC.", "IN REVIEW / ON HOLD"],
        ["Tick/tolerance", "One tick before/on/after; min/max tolerance; oscillation", "EDR-ICE-TIM-SCHEDULER-005", TBC, "ON HOLD"],
    ]


def build_power_rows() -> list[list[str]]:
    return [
        [phase_id, phase, f"EDR-ICE-PWR-{index:02d}", "PWR-M01..PWR-M13", "ON HOLD: source lacks NVM/write/power/recovery oracle."]
        for index, (phase_id, phase) in enumerate(POWER_PHASES, start=1)
    ]


def build_can_rows() -> list[list[str]]:
    return [
        [case_id, title, scenario, "AMB-002; AMB-009; AMB-010", "ON HOLD"]
        for case_id, title, scenario in CAN_SCENARIOS
    ]


def build_variant_rows() -> list[list[str]]:
    return [
        ["Domestic Low without SRSU", "Side event", "EDR-ICE-R02-LOW-NOSRSU-SIDE-001", "No EDR side-event record.", "IN REVIEW"],
        ["Domestic Mid without SRSU", "Side event", "EDR-ICE-R02-MID-NOSRSU-SIDE-002", "No EDR side-event record.", "IN REVIEW"],
        ["High with SRSU", "Side/front event", "EDR-ICE-VAR-HIGH-001", TBC, "ON HOLD"],
        ["Domestic configuration", "Variant/coding cross-check", "EDR-ICE-VAR-DOMESTIC-002", TBC, "ON HOLD"],
        ["Coding changed before/after event", "Persistence/applicability", "EDR-ICE-VAR-CODING-003", TBC, "ON HOLD"],
        ["Invalid/corrupt coding", "Fault/recovery", "EDR-ICE-VAR-CORRUPT-004", TBC, "ON HOLD"],
        ["All applicable variants", "Front event", "EDR-ICE-VAR-FRONT-005", TBC, "ON HOLD"],
    ]


def build_state_rows() -> list[list[str]]:
    states = [
        ["SM-01", "Empty", "Start pre-crash collection", "Capturing pre-crash data", "Test model only; EDR_Requirements does not define this transition.", "EDR-ICE-ROB-MODE-008", "ON HOLD"],
        ["SM-02", "Capturing pre-crash data", "Event trigger/T0", "Event started", "T0 exists in source wording but source does not define origin/transition.", "EDR-ICE-R05-COMPLETE-AFTER-5S-001; EDR-ICE-R06-200MS-COMPLETE-001", "IN REVIEW / ON HOLD"],
        ["SM-03", "Event started", "Below deployable threshold", "Near-crash active", "Source says near crash records, does not lock, and suppresses two CAN outputs.", "EDR-ICE-R04-NEAR-CRASH-001", "IN REVIEW"],
        ["SM-04", "Event started", "Onboard longitudinal present; both FRSUs=0", "Unconfirmed crash active", "Source classification only; resulting state behavior is unspecified.", "EDR-ICE-R07-UNCONFIRMED-001", "IN REVIEW"],
        ["SM-05", "Event started", "Deployment decision", "Deployment decision received", "Deployment record lock behavior is shown by examples but formal transition definition is absent.", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "IN REVIEW"],
        ["SM-06", "Event started", "200 ms after T0", "200 ms data complete", "Source gives status/data-valid meaning; timing tolerance/durability are unspecified.", "EDR-ICE-R06-200MS-COMPLETE-001", "IN REVIEW"],
        ["SM-07", "Event started", "Five seconds after T0 with battery", "Five-second data complete", "Source gives CompletionStatus=1; timing tolerance/durability are unspecified.", "EDR-ICE-R05-COMPLETE-AFTER-5S-001", "IN REVIEW"],
        ["SM-08", "Event/data complete", "Persist request", "NVM write pending", "Test-model state; source NVM protocol unavailable.", "EDR-ICE-PWR-11..19", "ON HOLD"],
        ["SM-09", "NVM write pending", "Write begins", "NVM write active", "Test-model state; source NVM protocol unavailable.", "EDR-ICE-PWR-12..19", "ON HOLD"],
        ["SM-10", "NVM write active", "Near-crash write succeeds", "Record valid and unlocked", "Near-crash unlocked is source-backed; write success criteria are not.", "EDR-ICE-R04-NEAR-CRASH-001", "IN REVIEW"],
        ["SM-11", "NVM write active", "Deployment write succeeds", "Record valid and locked", "Source tables show lock=1 for retained deployment entries; formal write-order behavior unavailable.", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "IN REVIEW"],
        ["SM-12", "Any active state", "Power loss/reset", "Power-fail recovery", "Source completion table only; recovery/atomicity behavior unavailable.", "EDR-ICE-PWR-01..23", "ON HOLD"],
        ["SM-13", "Record state", "Diagnostic request", "Diagnostic read", "Source gives generic EDR DID default only; read policy unavailable.", "EDR-ICE-DIA-CAPTURE-001..EDR-ICE-DIA-ASSOCIATION-005", "ON HOLD"],
        ["SM-14", "Run", "Sleep request", "Sleep", "Test-model state; source sleep policy unavailable.", "EDR-ICE-ROB-MODE-008", "ON HOLD"],
        ["SM-15", "Sleep", "Valid CAN wake-up", "CAN wake-up", "Test-model state; source wake-up rule unavailable.", "EDR-ICE-CAN-WAKE-002", "ON HOLD"],
        ["SM-16", "Sleep", "Crash input", "Crash wake-up", "Test-model state; source wake-up rule unavailable.", "EDR-ICE-CAN-CRASHWAKE-003; EDR-ICE-ROB-MODE-008", "ON HOLD"],
        ["SM-17", "Any active state", "Watchdog/reset", "Reset or watchdog recovery", "Test-model state; source recovery rule unavailable.", "EDR-ICE-ROB-MODE-008", "ON HOLD"],
        ["SM-18", "Two records occupied", "Incoming fourth/fifth event", "Storage full / both records locked", "Source examples stop at Event 3; all policy outcomes require clarification.", "EDR-ICE-OVR-OLDEST-001..EDR-ICE-OVR-INCOMPLETE-010", "ON HOLD"],
        ["SM-19", "Valid locked record", "Incoming event", "Overwrite locked record", "Illegal review hypothesis unless an explicit requirement permits it; not an approved oracle.", "EDR-ICE-OVR-BOTHLOCK-DEPLOY-008; EDR-ICE-OVR-BOTHLOCK-NEAR-009", "ON HOLD"],
        ["SM-20", "200msCompletionStatus=1", "Mandatory 200 ms data absent", "Data marked valid", "Illegal review hypothesis from source wording; exact mandatory data set is unavailable.", "EDR-ICE-R06-200MS-BOUNDARY-002", "ON HOLD"],
    ]
    return states


def build_data_element_rows() -> list[list[str]]:
    return [
        ["No-event/reserved bytes", "FF.. including reserve bytes", source_reference(5, "1"), "EDR-ICE-R01-DEFAULT-001", "IN REVIEW"],
        ["EDR1 actual event data", "Source vector event retention after Event 2/Event 3", f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "IN REVIEW"],
        ["EDR2 actual event data", "Source vector event retention after Event 2/Event 3", f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "IN REVIEW"],
        ["MultiEventNumber", "Source vector values after Event 2/Event 3", f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "IN REVIEW"],
        ["TimeBetweenEvents", "Source vector values after Event 2/Event 3", f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08; EDR-ICE-TIM-MULTI-003; EDR-ICE-TIM-SINGLE-004", "IN REVIEW / ON HOLD"],
        ["LifetimeEventNumber", "Source vector values after Event 2/Event 3", f"{SOURCE_NAME} | EDR_Requirements!B23:V30; B42:V49", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08; EDR-ICE-ROB-COUNTER-009", "IN REVIEW / ON HOLD"],
        ["RecordLockStatus", "0=not locked / 1=locked per table legend", f"{SOURCE_NAME} | EDR_Requirements!U19:V20 and source vectors", "EDR-ICE-R04-NEAR-CRASH-001; EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "IN REVIEW"],
        ["CompletionStatus", "1 after 5 s with battery; source completion table", f"{SOURCE_NAME} | EDR_Requirements!E9; B53:E55", "EDR-ICE-R05-COMPLETE-AFTER-5S-001; EDR-ICE-COMP-00-00-001..003", "IN REVIEW"],
        ["200msCompletionStatus", "1 after 200 ms; source completion table", f"{SOURCE_NAME} | EDR_Requirements!E10; B53:E55", "EDR-ICE-R06-200MS-COMPLETE-001; EDR-ICE-COMP-00-00-001..003", "IN REVIEW"],
        ["STS_CRASH", "Not transmitted for near crash", source_reference(8, "4"), "EDR-ICE-R04-NEAR-CRASH-001; source-vector cases with near-crash input", "IN REVIEW"],
        ["DOOR_UNLOCK", "Not transmitted for near crash", source_reference(8, "4"), "EDR-ICE-R04-NEAR-CRASH-001; source-vector cases with near-crash input", "IN REVIEW"],
        ["CAN signal raw/physical/scaling/on-fail", "Named W501 matrix", source_reference(7, "3"), "EDR-ICE-CAN-NOMINAL-001..EDR-ICE-CAN-LOSS-012", "ON HOLD"],
        ["UDS/DID length/session/security/NRC", "Not supplied", "Evidence unavailable in provided EDR source", "EDR-ICE-DIA-CAPTURE-001..EDR-ICE-DIA-ASSOCIATION-005", "ON HOLD"],
    ]


def build_ambiguity_rows() -> list[list[str]]:
    return [
        ["AMB-001", "Traceability and DID identity", "EDR_Requirements has S.No/Topic/Requirements only; no Codebeamer artifact IDs, approval status, DID IDs, response length, session, or security data.", "Cannot create import-ready Veoneer/Codebeamer traceability or raw diagnostic oracles.", "Provide the approved target-variant EDR tracker and released UDS/DID specification with IDs, approval status, request/response format, and field offsets.", "EDR-ICE-R01-DEFAULT-001; EDR-ICE-DIA-CAPTURE-001..005", "ON HOLD for import/UDS-specific oracle"],
        ["AMB-002", "Referenced W501 matrix unavailable", "R03 names M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156, but the file is not available in the workspace.", "CAN signal, range, scaling, on-fail, sample-age, and byte-packing checks cannot be asserted.", "Provide the released W501 matrix, target DBC, CAN wake-up specification, and source-to-EDR packing definition.", "EDR-ICE-R03-CAN-CONTRACT-001; EDR-ICE-CAN-NOMINAL-001..012", "ON HOLD"],
        ["AMB-003", "Timing boundaries and timestamp reference", "Source says multi-event >500 ms and <5 s, single-event >5 s, CompletionStatus after 5 s, and 200msCompletionStatus after 200 ms; it does not define equality, time reference, scheduler tick, or tolerance.", "Off-by-one/tick conversion defects can be wrongly accepted or rejected.", "Define whether timing is T0-to-T0, end-to-start, or another reference; define exact 500 ms/5.000 s behavior, task period, and allowable tolerance.", "EDR-ICE-TIM-OVERLAP-001..SCHEDULER-005; EDR-ICE-R05-5S-BOUNDARY-002; EDR-ICE-R06-200MS-BOUNDARY-002", "ON HOLD"],
        ["AMB-004", "Fourth/fifth-event behavior", "Source tables stop after Event 3 with two physical records.", "Potential loss/corruption of deployment data or unbounded storage behavior.", "For Event 4, 5, 10, and N, specify selected slot, reject/overflow behavior, persistence, diagnostics, and counter updates for every lock-state combination.", "EDR-ICE-OVR-OLDEST-001..INCOMPLETE-010; EDR-ICE-ROB-SEQUENCE-004", "ON HOLD"],
        ["AMB-005", "Unlocked record replacement priority", "Examples show outcomes for only three events but do not define oldest/newest/priority policy among multiple unlocked records.", "Wrong record replacement may discard useful evidence.", "State the deterministic priority order when one or both records are unlocked, including tie-breakers using age/lifetime/multi-event/completion state.", "EDR-ICE-OVR-OLDEST-001..OVERFLOW-005", "ON HOLD"],
        ["AMB-006", "Locked records and counters", "Examples show retained locked records but do not state whether a locked record can ever be overwritten, whether discarded events increment counters, or rollover/saturation behavior.", "Loss of locked crash data and wrong legal/event history.", "Define lock commit instant; overwrite permission; LifetimeEventNumber and MultiEventNumber increment, saturation, rollover, and discarded/incomplete-event rules.", "EDR-ICE-OVR-BOTHLOCK-DEPLOY-008; EDR-ICE-OVR-BOTHLOCK-NEAR-009; EDR-ICE-ROB-COUNTER-009", "ON HOLD"],
        ["AMB-007", "Completion semantics and durability", "Source gives status bit meanings but not exact 200 ms data list, durable-write timing, or behavior if a second event begins before five seconds complete.", "A status bit could claim data validity before data are durably stored.", "Specify data elements/timestamps covered by each completion flag, write durability criterion, flag order, and concurrent-event behavior.", "EDR-ICE-R05-COMPLETE-AFTER-5S-001; EDR-ICE-R06-200MS-COMPLETE-001; EDR-ICE-COMP-00-00-001..003", "IN REVIEW / ON HOLD"],
        ["AMB-008", "NVM atomicity/recovery", "No NVM layout, CRC/valid marker, write ordering, erase/replacement sequence, energy reserve, reset, or power threshold information is supplied.", "Partial writes may create mixed records, corruption, or locked-data loss.", "Provide NVM record format, CRC/marker/lock/counter write order, power-fail recovery state machine, and electrical timing limits.", "EDR-ICE-PWR-01..23; EDR-ICE-OVR-INCOMPLETE-010", "ON HOLD"],
        ["AMB-009", "CAN sample age and packing", "R03 references the missing W501 matrix but does not define data age, sampling instants, raw-to-physical transform, substitute values, or EDR byte packing.", "Stale/misaligned CAN data can appear valid and hide a safety-relevant defect.", "Provide per-signal source message, signal, scaling, valid/invalid encoding, on-fail reaction, sample schedule, and EDR mapping.", "EDR-ICE-CAN-NOMINAL-001..DBC-011", "ON HOLD"],
        ["AMB-010", "Diagnostic read contract", "No source DID list, service/session/security behavior, response length, reserved offsets, NRCs, or read-while-recording policy is provided.", "Diagnostic test cannot make deterministic raw-frame pass/fail assertions.", "Provide approved UDS/EDR-DID specification, decoding, session/security access, read availability, concurrency behavior, and unsupported-request requirements.", "EDR-ICE-R01-DEFAULT-001; EDR-ICE-DIA-CAPTURE-001..005", "ON HOLD"],
        ["AMB-011", "Unconfirmed crash and T0", "R07 gives a classifier input but not recording/lock/transmit/confirmation behavior; all timing rules refer to undefined T0.", "Incorrect classification can cause false lock/notification or lost evidence.", "Define T0 source and event-start rule; define unconfirmed crash record, lock, CAN, delayed confirmation, and power-loss behavior.", "EDR-ICE-R07-UNCONFIRMED-001; EDR-ICE-ROB-UNCONF-002", "IN REVIEW / ON HOLD"],
        ["AMB-012", "Reserved-byte default conflict", "EDR_Requirements!E5 requires FF.. including reserve bytes, while supplemental EDR_0455_045B layout note states reserved bits default/deconfigured to 0.", "Default diagnostic data can be interpreted incorrectly and tests can falsely pass.", "Resolve scope/precedence: are these different DIDs/states, or is one rule obsolete? Provide byte/bit-level mapping.", "EDR-ICE-R01-DEFAULT-001", "IN REVIEW"],
        ["AMB-013", "Variant scope beyond no-SRSU side storage", "R02 provides only Low/Mid Domestic without-SRSU no-side-recording behavior and delegates door unlock/other features to separate requirements.", "Variant tests may assert behavior from the wrong variant or suppress unrelated features.", "Provide approved variant-code maps and separate requirements for High/SRSU, markets, door unlock, and front-event behavior.", "EDR-ICE-R02-LOW-NOSRSU-SIDE-001; EDR-ICE-R02-MID-NOSRSU-SIDE-002; EDR-ICE-VAR-*. ", "IN REVIEW / ON HOLD"],
        ["AMB-014", "Execution environment/instrumentation", "The source has no approved bench configuration, stimulus interface, measurement accuracy, or baseline/reset procedure.", "A test may be unrepeatable or affect an ECU/NVM state without an approved controlled procedure.", "Provide project/variant, fault-free bench profile, non-destructive event/stimulus method, measurement accuracy, and reset/cleanup constraints.", "All cases", "ON HOLD for execution"],
    ]


def build_risk_rows() -> list[list[str]]:
    return [
        ["RR-001", "P0", "Locked deployment data lost or overwritten by Event 4/5", "AMB-004; AMB-005; AMB-006", "EDR-ICE-OVR-BOTHLOCK-DEPLOY-008; EDR-ICE-OVR-ONELOCK-DEPLOY-006", "High", "No source replacement policy; cannot close without architect decision."],
        ["RR-002", "P0", "Power loss produces mixed metadata/payload or false-valid record", "AMB-007; AMB-008", "EDR-ICE-PWR-01..23", "High", "No NVM atomicity/recovery evidence."],
        ["RR-003", "P0", "200 ms / five-second status flags claim unavailable data", "AMB-003; AMB-007", "EDR-ICE-R05-COMPLETE-AFTER-5S-001; EDR-ICE-R06-200MS-COMPLETE-001", "High", "Dataset/durability/tolerance incomplete."],
        ["RR-004", "P1", "Source-table retention field is attached to wrong record", "AMB-010", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08; EDR-ICE-DIA-ASSOCIATION-005", "Medium", "Raw DID layout/association is unavailable."],
        ["RR-005", "P1", "Near crash locks record or emits STS_CRASH/DOOR_UNLOCK", "AMB-010; AMB-011", "EDR-ICE-R04-NEAR-CRASH-001", "Medium", "Core source rule exists, but interfaces/observation period lack detail."],
        ["RR-006", "P1", "Low/Mid no-SRSU variant records side event", "AMB-013", "EDR-ICE-R02-LOW-NOSRSU-SIDE-001; EDR-ICE-R02-MID-NOSRSU-SIDE-002", "Medium", "Variant coding and EDR evidence interface unavailable."],
        ["RR-007", "P1", "CAN data are stale, invalid, or mispacked but marked valid", "AMB-002; AMB-009", "EDR-ICE-CAN-NOMINAL-001..012", "High", "Required communication matrix/packing contract unavailable."],
        ["RR-008", "P1", "Diagnostic read interferes with recording or exposes mixed EDR1/EDR2 data", "AMB-001; AMB-008; AMB-010", "EDR-ICE-DIA-CAPTURE-001..005", "High", "DID/UDS and concurrency policy unavailable."],
        ["RR-009", "P2", "Counter rollover/saturation or discarded event increments are wrong", "AMB-006", "EDR-ICE-ROB-COUNTER-009", "High", "Counter limit policy not supplied."],
        ["RR-010", "P3", "Repeated/overlap sequences exhaust state machine or produce non-determinism", "AMB-004; AMB-008; AMB-011", "EDR-ICE-ROB-NEAR-001..ENDURANCE-010", "Medium", "Resource/concurrency specification unavailable."],
    ]


def build_technique_rows() -> list[list[str]]:
    return [
        ["Equivalence partitioning", "Near crash, unconfirmed crash, deployment; Low/Mid no-SRSU; no-event", "Classification/variant leakage", "EDR-ICE-R01-DEFAULT-001; R02-*; R04-*; R07-*"],
        ["Boundary-value analysis", "0/1/199/200/201/299/300/301/499/500/501 ms; 4.999/5.000/5.001 s; counter limits", "Off-by-one/tick conversion", "EDR-ICE-R05-5S-BOUNDARY-002; R06-200MS-BOUNDARY-002; TIM-*; ROB-COUNTER-009"],
        ["State-transition testing", "Capture, event, completion, NVM, diagnostic, sleep/wake/reset/storage-full states", "Illegal/race transitions", "State Model sheet; EDR-ICE-ROB-MODE-008; PWR-*"],
        ["Decision-table testing", "Completion flags; 16 source vectors; lock/replacement hypotheses", "Wrong allocation/flag association", "EDR-ICE-COMP-*; VEC-*; OVR-*"],
        ["Cause-effect analysis", "Power/reset/CAN/diagnostic conditions versus EDR integrity", "Mixed-record/root-cause isolation", "EDR-ICE-PWR-*; CAN-*; DIA-*"],
        ["Pairwise/covering-array", "Event type x lock state x timing class x CAN validity x power mode x variant", "Interaction defects without combinatorial explosion", "EDR-ICE-ROB-SEQUENCE-004; Power Interruption Matrix"],
        ["Sequence testing", "0/1/2/3/4/5/10/N events", "Replacement, persistence, counter defects", "Event Count Coverage; EDR-ICE-ROB-*"],
        ["Error guessing", "Lock-after-valid, early valid marker, pointer swap, partial erase, stale CAN", "Known implementation risk patterns", "EDR-ICE-PWR-*; OVR-*; CAN-*"],
        ["Fault injection", "Power loss, reset, CAN integrity/timeout/bus-off", "Recovery and atomicity defects", "EDR-ICE-PWR-*; CAN-*; ROB-MODE-008"],
        ["Robustness/endurance", "Repeated near/unconfirmed/deployment events and diagnostic reads", "Resource exhaustion/non-determinism", "EDR-ICE-ROB-NEAR-001..ENDURANCE-010"],
        ["Metamorphic testing", "Equivalent reordered/non-impacting CAN frames and repeated diagnostic reads", "Unexpected sensitivity/stale state", "EDR-ICE-CAN-ORDER-005; DIA-CONCURRENT-003"],
        ["Cross-signal consistency", "Speed/wheel speed; brake/deceleration; steering/lateral acceleration; crash/deployment", "Incorrectly aligned source data", "EDR-ICE-CAN-CROSS-009"],
        ["Randomized/property-based generation", "Configurable event/power/CAN/diagnostic/variant sequences with shrinking", "Rare interaction and minimal reproducer", "EDR-ICE-ROB-SEQUENCE-004"],
    ]


def build_priority_rows(cases: list[dict[str, str]]) -> list[list[str]]:
    preferred_ids = [
        "EDR-ICE-R01-DEFAULT-001",
        "EDR-ICE-R04-NEAR-CRASH-001",
        "EDR-ICE-R05-COMPLETE-AFTER-5S-001",
        "EDR-ICE-R06-200MS-COMPLETE-001",
        "EDR-ICE-COMP-00-01-002",
        "EDR-ICE-VEC-SGL-08",
        "EDR-ICE-VEC-SGL-06",
        "EDR-ICE-VEC-MLT-08",
        "EDR-ICE-VEC-MLT-06",
        "EDR-ICE-TIM-MULTI-003",
        "EDR-ICE-TIM-SINGLE-004",
        "EDR-ICE-OVR-ONELOCK-DEPLOY-006",
        "EDR-ICE-OVR-BOTHLOCK-DEPLOY-008",
        "EDR-ICE-OVR-INCOMPLETE-010",
        "EDR-ICE-PWR-02",
        "EDR-ICE-PWR-13",
        "EDR-ICE-PWR-15",
        "EDR-ICE-PWR-16",
        "EDR-ICE-PWR-19",
        "EDR-ICE-PWR-22",
        "EDR-ICE-CAN-EDGE-008",
        "EDR-ICE-CAN-FAILSAFE-007",
        "EDR-ICE-DIA-ASSOCIATION-005",
        "EDR-ICE-R02-LOW-NOSRSU-SIDE-001",
        "EDR-ICE-ROB-SEQUENCE-004",
    ]
    available = {case["Test Case ID"]: case for case in cases}
    rows: list[list[str]] = []
    for rank, case_id in enumerate(preferred_ids, start=1):
        case = available[case_id]
        prerequisite = "Source-backed partial oracle" if case["Execution Status"] == "IN REVIEW" else "Architecture/source clarification required before execution verdict"
        rows.append([str(rank), case_id, case["Priority"], case["Test Objective"], prerequisite])
    rows.extend(
        [
            ["Minimum regression suite", "EDR-ICE-R01-DEFAULT-001; EDR-ICE-R04-NEAR-CRASH-001; EDR-ICE-R05-COMPLETE-AFTER-5S-001; EDR-ICE-R06-200MS-COMPLETE-001; EDR-ICE-COMP-00-00-001..003; EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08; EDR-ICE-R02-LOW-NOSRSU-SIDE-001; EDR-ICE-R02-MID-NOSRSU-SIDE-002", "P0/P1", "Run source-backed cases first after approved execution setup.", "No case is evidence of bench execution; complete source gap closure is still required for interfaces."],
            ["Full qualification suite", "All Test Matrix rows plus all listed parameter vectors after ambiguity closure", "P0-P3", "Covers nominal, negative, boundary, power-loss, CAN, wake-up, diagnostic, variant, persistence, robustness, and endurance design intent.", "Requires W501/DBC, UDS/DID, NVM, timing, variant, and bench evidence."],
            ["Long-duration endurance suite", "EDR-ICE-ROB-ENDURANCE-010; EDR-ICE-ROB-SEQUENCE-004; EDR-ICE-ROB-NEAR-001..DEPLOY-003", "P3", "Repeated sequence/power/diagnostic campaign with periodic consistency snapshots and minimized reproducers.", "Requires approved endurance criteria and non-destructive execution controls."],
        ]
    )
    return rows


def build_automation_rows() -> list[list[str]]:
    pseudocode = (
        "for seed in campaign_seeds:\n"
        "  sequence = generate(event_count in {0,1,2,3,4,5,10,N}, event_class, source, lock_state, delta_t, can_quality, power_phase, reset_phase, diagnostic_phase, variant)\n"
        "  establish_approved_baseline(sequence.initial_slots, sequence.variant)\n"
        "  capture_t0_and_all_interfaces()\n"
        "  execute_sequence_only_when_authorized(sequence)\n"
        "  observations = read_edr_and_diagnostics_repeatedly()\n"
        "  assert_source_backed_invariants(observations)\n"
        "  record_tbc_observations_without_pass_fail(observations)\n"
        "  if failure: shrink_to_smallest_reproducible_prefix(sequence)"
    )
    return [
        ["Property-based generator pseudocode", pseudocode, "EDR-ICE-ROB-SEQUENCE-004", "Uses only approved interfaces; no bench operation is invoked by this workbook."],
        ["Source-backed invariant", "No-event EDR response has FF.. in all bytes including reserve bytes.", "EDR-ICE-R01-DEFAULT-001", "Source-backed."],
        ["Source-backed invariant", "Near crash records but does not lock; STS_CRASH and DOOR_UNLOCK are not sent for near crash.", "EDR-ICE-R04-NEAR-CRASH-001", "Source-backed."],
        ["Source-backed invariant", "CompletionStatus becomes 1 after five seconds from T0 when battery is available.", "EDR-ICE-R05-COMPLETE-AFTER-5S-001", "Exact timing tolerance is TBC."],
        ["Source-backed invariant", "200msCompletionStatus becomes 1 after 200 ms; when set, data from T0 through 200 ms are valid.", "EDR-ICE-R06-200MS-COMPLETE-001", "Dataset/durability detail is TBC."],
        ["Review invariant", "A locked record is never modified unless a clarified requirement explicitly permits it.", "EDR-ICE-OVR-BOTHLOCK-DEPLOY-008", "Test-design invariant only; source policy unavailable."],
        ["Review invariant", "A completed valid record remains identical across power cycles and contains no mixed event content.", "EDR-ICE-PWR-01..23", "Test-design invariant only; NVM protocol unavailable."],
        ["Review invariant", "Counters are monotonic unless clarified rollover/saturation behavior applies; TimeBetweenEvents maps to the correct T0 pair.", "EDR-ICE-ROB-COUNTER-009; EDR-ICE-TIM-*", "Test-design invariant only; counter/time reference policy unavailable."],
        ["Recommended instrumentation", "Approved non-destructive event injector; synchronized T0 timebase; CAN/FD capture with DBC decoder; diagnostic trace; programmable power monitor/controller; ECU reset indication; EDR DID decoder; immutable raw-evidence store.", "All execution cases", "Exact hardware/channel configuration is project-specific and unavailable."],
    ]


def build_glossary_rows() -> list[list[str]]:
    return [
        ["Event", "An EDR-related input occurrence represented by the source as a Near Crash (0) or Deployment Event (1) in the source vectors.", f"{SOURCE_NAME} | EDR_Requirements!B19:B20; B38:B39", "Source-backed for the two vector labels; broader definition is unavailable."],
        ["T0", "Reference used by the source for the five-second and 200 ms completion statements.", f"{SOURCE_NAME} | EDR_Requirements!E9:E10", "Timestamp source and event-start definition are TBC (AMB-003; AMB-011)."],
        ["Near Crash", "Crash does not meet deployable threshold; EDR records but does not lock; STS_CRASH and DOOR_UNLOCK are not sent.", source_reference(8, "4"), "Source-backed."],
        ["Deployment Event", "Source-vector event code 1. The primary EDR narrative sheet does not otherwise define deployment processing.", f"{SOURCE_NAME} | EDR_Requirements!B20; B39", "Lock behavior is shown in source vectors but formal deployment trigger/transition is TBC."],
        ["Unconfirmed Crash", "Onboard longitudinal signal present while both FRSU values are 0.", source_reference(11, "7"), "Classification only; recording/lock/CAN behavior is TBC."],
        ["Single Event", "Source-table timing class with time between events more than 5 s.", f"{SOURCE_NAME} | EDR_Requirements!B13; B23:V30", "Exact 5.000 s and timing reference are TBC."],
        ["Parallel Event", "Test-design term for overlapping/simultaneous event starts at 0 ms or 1 ms separation.", "Test design only", "No source definition; behavior is TBC."],
        ["Multi-Event", "Source-table timing class with time between events >500 ms and <5 s.", f"{SOURCE_NAME} | EDR_Requirements!B32; B42:V49", "Exact 500 ms/5.000 s and timing reference are TBC."],
        ["Locked Record", "Source table legend: lock value 1 means record locked; source vectors associate it with retained deployment entries.", f"{SOURCE_NAME} | EDR_Requirements!U19:V20; B23:V30; B42:V49", "Commit moment and permitted overwrite behavior are TBC."],
        ["CompletionStatus", "Updated as 1 after five seconds from T0 if battery is available; source completion table gives validity combinations.", f"{SOURCE_NAME} | EDR_Requirements!E9; B53:E55", "Exact tolerance, durable-write point, and data set are TBC."],
        ["200msCompletionStatus", "Updated as 1 after 200 ms; when set, data for 200 ms from T0 are valid.", f"{SOURCE_NAME} | EDR_Requirements!E10; B53:E55", "Exact data elements/tolerance/durability are TBC."],
    ]


def build_failure_hypothesis_rows() -> list[list[str]]:
    return [
        ["Default / diagnostic data", "Reserved bytes not FF..; stale bytes from prior record; EDR1/EDR2 response mixture.", "EDR-ICE-R01-DEFAULT-001; EDR-ICE-DIA-ASSOCIATION-005", "Source-backed default rule; DID layout/access is TBC."],
        ["Near-crash behavior", "Record locks unexpectedly; STS_CRASH or DOOR_UNLOCK transmitted; later deployment blocked by retained near crash.", "EDR-ICE-R04-NEAR-CRASH-001; EDR-ICE-ROB-NEAR-001", "First two observations source-backed; replacement policy is TBC."],
        ["Completion timing", "Off-by-one 200 ms/five-second comparison; tick conversion error; status set before durable data.", "EDR-ICE-R05-*; EDR-ICE-R06-*; EDR-ICE-COMP-*", "Status timing meaning source-backed; tolerance/durability are TBC."],
        ["Source-vector allocation", "EDR1/EDR2 pointer swap; wrong retained event; wrong MultiEventNumber/LifetimeEventNumber/lock association.", "EDR-ICE-VEC-SGL-01..08; EDR-ICE-VEC-MLT-01..08", "Three-event field outcomes source-backed."],
        ["Fourth/fifth event", "Incoming event overwrites locked record; eligible unlocked record not replaced; wrong replacement selection; both-lock corruption.", "EDR-ICE-OVR-OLDEST-001..EDR-ICE-OVR-INCOMPLETE-010", "All oracles provisional until storage policy is supplied."],
        ["Power interruption", "Partial erase; valid marker before payload; lock written after valid; mixed old/new metadata; lost/double counters; reset corruption.", "EDR-ICE-PWR-01..23", "Completion-state meanings source-backed; NVM process is TBC."],
        ["CAN quality / wake-up", "Stale data marked valid; timeout treated as physical value; post-wake first frame used before validation; endian/packing error.", "EDR-ICE-CAN-NOMINAL-001..EDR-ICE-CAN-LOSS-012", "W501/DBC/on-fail/packing evidence unavailable."],
        ["Unconfirmed crash", "Stale FRSU values cause false confirmation; asynchronous inputs use wrong decision cycle; incorrect record/output behavior.", "EDR-ICE-R07-UNCONFIRMED-001; EDR-ICE-ROB-UNCONF-002", "Classification condition source-backed; downstream behavior TBC."],
        ["Variant applicability", "Without-SRSU variant records a side event; filtering suppresses unrelated/front behavior; coding state leaks across event.", "EDR-ICE-R02-LOW-NOSRSU-SIDE-001; EDR-ICE-R02-MID-NOSRSU-SIDE-002; EDR-ICE-VAR-*", "No-SRSU side suppression source-backed; broader variant behavior TBC."],
        ["Diagnostic concurrency", "Diagnostic read changes recording behavior; response has mixed records; unsupported request produces wrong behavior.", "EDR-ICE-DIA-CAPTURE-001..EDR-ICE-DIA-ASSOCIATION-005", "UDS/DID contract unavailable."],
        ["Stress / endurance", "Repeated near crashes exhaust state machines; sequence order changes result; counter rollover corrupts storage; watchdog recovery loses record.", "EDR-ICE-ROB-NEAR-001..EDR-ICE-ROB-ENDURANCE-010", "Limits and expected recovery are TBC."],
    ]


def create_workbook(source_data: dict[str, Any], cases: list[dict[str, str]]) -> None:
    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    workbook.remove(workbook.active)
    workbook.properties.title = "ICE Common SRS V1.4 EDR Test-Spec Design Matrix"
    workbook.properties.subject = "Offline source-traceable EDR test design"
    workbook.properties.creator = "GitHub Copilot - offline generator"
    workbook.properties.description = "Engineering-review matrix; not Codebeamer import-ready without approved artifact IDs."

    document_sheet = write_table(
        workbook,
        "Document Control",
        "ICE Common SRS V1.4 EDR Test-Spec Design Matrix",
        "Source-backed internal review package. No ECU/bench interaction occurs during generation.",
        ["Control Item", "Value"],
        build_document_control(source_data, cases),
        GREEN,
    )
    document_sheet.column_dimensions["A"].width = 30
    document_sheet.column_dimensions["B"].width = 110

    source_rows = [
        [
            "Primary behavioral source",
            SOURCE_NAME,
            "EDR_Requirements",
            "B2:V57",
            "Rows 5-11, 23-30, 42-49, and 53-55 used for source-backed behavioral evidence.",
            source_data["source_hash"],
            "Very High",
        ],
        [
            "Supplemental layout observation",
            SOURCE_NAME,
            "EDR_0455_045B",
            "Source sheet exists; not used as primary behavioral authority.",
            "Reserved-byte default conflict logged as AMB-012; byte-level DID behavior remains unapproved.",
            source_data["source_hash"],
            "Medium",
        ],
        [
            "Referenced but unavailable source",
            "M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156",
            "N/A",
            "Not found in workspace.",
            "CAN/DBC/raw/physical/on-fail test oracles are ON HOLD.",
            "Evidence unavailable.",
            "High",
        ],
        [
            "Observed Veoneer template",
            ".github/skills/veoneer-test-spec-generator/assets/veoneer_codebeamer_test_spec_template.cleaned.xlsx",
            "Export / ChoiceValues",
            "Observed template profile.",
            "Not used as an import export because no verified Codebeamer IDs/statuses are present in EDR_Requirements.",
            "Local asset; template profile verified separately.",
            "High",
        ],
    ]
    write_table(
        workbook,
        "Source Register",
        "Source Register",
        "Provenance, authority, and evidence gaps. All source requirements remain read-only.",
        ["Source Class", "Path / Identifier", "Sheet", "Scope", "Use / Limitation", "Evidence Identity", "Confidence"],
        source_rows,
        BLUE,
    )

    requirements_sheet = write_table(
        workbook,
        "Requirements",
        "Normalized Requirement List",
        "Internal keys are source-row anchors, not Codebeamer artifact IDs.",
        ["Internal Key", "Source S.No", "Topic", "Source Reference", "Normalized Requirement", "Conditions / Trigger", "Source-backed Observable", "Traceability Status", "Design Case Coverage", "Confidence", "Limit / Gap"],
        build_requirement_rows(cases),
        GREEN,
    )
    shade_status_cells(requirements_sheet, "Limit / Gap")

    write_table(
        workbook,
        "Glossary",
        "EDR Glossary",
        "Definitions distinguish source-backed meanings from test-design terms and unresolved terminology.",
        ["Term", "Definition", "Evidence", "Limit / Clarification"],
        build_glossary_rows(),
        BLUE,
    )

    matrix_sheet = write_table(
        workbook,
        "Test Matrix",
        "Detailed EDR Test Matrix",
        "One row per logical test case. Parameter matrices define independently executable vectors where a full Cartesian expansion would be redundant. ON HOLD entries are not pass/fail test oracles.",
        TEST_HEADERS,
        make_rows(cases, TEST_HEADERS),
        BLUE,
    )
    matrix_sheet.sheet_view.showGridLines = False
    shade_status_cells(matrix_sheet, "Execution Status")
    for column in (1, 2, 3, 4, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 34, 35, 38):
        matrix_sheet.column_dimensions[get_column_letter(column)].width = 42
    matrix_sheet.column_dimensions[get_column_letter(1)].width = 29
    matrix_sheet.column_dimensions[get_column_letter(6)].width = 10
    matrix_sheet.column_dimensions[get_column_letter(37)].width = 16

    vector_sheet = write_table(
        workbook,
        "Source Vector Matrix",
        "Source-Defined Three-Event Vectors",
        "Values are transcribed at generation time from EDR_Requirements. The source tables establish Event 1-3 outcomes only.",
        ["Test Case ID", "Family", "Source Row", "Event 1", "Event 2", "Event 3", "After E2 EDR1", "After E2 EDR2", "After E2 Multi EDR1/2", "After E2 Time EDR1/2", "After E2 Lifetime EDR1/2", "After E3 EDR1", "After E3 EDR2", "After E3 Multi EDR1/2", "After E3 Time EDR1/2", "After E3 Lifetime EDR1/2", "After E3 Lock EDR1/2", "Timing Class"],
        build_vector_rows(source_data["vectors"], cases),
        GREEN,
    )
    vector_sheet.freeze_panes = "A5"

    write_table(
        workbook,
        "Completion Matrix",
        "Completion-Status Decision Matrix",
        "Derived from EDR_Requirements completion-state table; no dataset packing or durable-write rule is assumed.",
        ["Test Case ID", "Source Row", "CompletionStatus", "200msCompletionStatus", "Source-Stated Data Validity", "Applicability / Limitation"],
        [
            ["EDR-ICE-COMP-00-00-001", "EDR_Requirements!B53:E53", "0", "0", "EDR data not valid", "Applicable for battery-cutoff crash."],
            ["EDR-ICE-COMP-00-01-002", "EDR_Requirements!B54:E54", "0", "1", "EDR data valid up to 200 ms", "Exact data elements, sample grid, and durability are TBC."],
            ["EDR-ICE-COMP-01-DC-003", "EDR_Requirements!B55:E55", "1", "don't care", "EDR data valid", "Applicable for no battery-cutoff crash."],
        ],
        GREEN,
    )

    write_table(
        workbook,
        "Traceability",
        "Requirement-to-Test-Case Traceability",
        "All references are source rows/sections because no verified Codebeamer IDs or approval state were present in the primary source sheet.",
        ["Requirement / Source Table", "Source Reference", "Test Cases", "Coverage Status", "Uncovered / Limited Behavior"],
        [
            [requirement["key"], source_reference(requirement["source_row"], requirement["serial"]), "; ".join(case["Test Case ID"] for case in cases if source_reference(requirement["source_row"], requirement["serial"]) in case["Source Requirement Reference"]), "Covered", "See Ambiguity Register for unknown interface/timing/NVM detail."]
            for requirement in REQUIREMENTS
        ]
        + [
            ["ICE-EDR-VEC-SINGLE", f"{SOURCE_NAME} | EDR_Requirements!B23:V30", "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-VEC-SGL" in case["Test Case ID"]), "Covered", "No Event 4+ policy."],
            ["ICE-EDR-VEC-MULTI", f"{SOURCE_NAME} | EDR_Requirements!B42:V49", "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-VEC-MLT" in case["Test Case ID"]), "Covered", "Exact 500 ms / 5 s time behavior unresolved."],
            ["ICE-EDR-COMP-TABLE", f"{SOURCE_NAME} | EDR_Requirements!B53:E55", "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-COMP" in case["Test Case ID"]), "Covered", "Data list/durability unavailable."],
            ["CAN / DBC contract", source_reference(7, "3"), "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-CAN" in case["Test Case ID"]), "ON HOLD", "W501 matrix/DBC/packing unavailable."],
            ["UDS / DID contract", "Evidence unavailable in primary EDR source", "; ".join(case["Test Case ID"] for case in cases if "EDR-ICE-DIA" in case["Test Case ID"]), "ON HOLD", "DID/session/security/NRC/read policy unavailable."],
        ],
        GREEN,
    )

    write_table(
        workbook,
        "Event Count Coverage",
        "Event-Count Coverage Matrix",
        "0, 1, 2, 3, 4, 5, 10, and N-event coverage. Event 4+ cases are retained as provisional design until storage policy is supplied.",
        ["Event Count", "Scenario", "Covered Test Cases", "Evidence / Coverage Limit", "Status"],
        build_event_count_rows(),
        BLUE,
    )

    write_table(
        workbook,
        "Lock Overwrite Matrix",
        "Lock-State and Overwrite Matrix",
        "Source tables inform three-event outcomes only. All fourth/fifth-event policy rows are provisional.",
        ["Initial Storage State", "Incoming Condition", "Test Cases", "Expected Behavior / Limit", "Status"],
        build_lock_rows(),
        AMBER,
    )

    write_table(
        workbook,
        "Timing Boundaries",
        "Timing-Boundary Matrix",
        "All requested boundary points are planned. Only stated source conditions are accepted as source-backed; equality/tolerance is explicitly TBC.",
        ["Boundary", "Behavior Under Test", "Test Case", "Expected Rule / Limit", "Status"],
        build_timing_rows(),
        AMBER,
    )

    power_sheet = write_table(
        workbook,
        "Power Interruption Matrix",
        "Power-Interruption Coverage Matrix",
        "Every requested interruption phase is a logical test case. Power modes are a parameter vector set; voltage/current/timing and NVM oracle remain TBC.",
        ["Phase ID", "Interruption Phase", "Test Case ID", "Power Mode Vectors", "Status / Limitation"],
        build_power_rows(),
        AMBER,
    )
    power_sheet.append([])
    start = power_sheet.max_row + 2
    power_sheet.cell(start, 1, "Power Mode Vectors")
    power_sheet.cell(start, 1).font = Font(bold=True, color=WHITE)
    power_sheet.cell(start, 1).fill = PatternFill("solid", fgColor=NAVY)
    for col, header in enumerate(["Power Mode ID", "Power Mode"], start=1):
        cell = power_sheet.cell(start + 1, col, header)
        cell.font = Font(bold=True, color=WHITE)
        cell.fill = PatternFill("solid", fgColor=NAVY)
    for row, (mode_id, mode) in enumerate(POWER_MODES, start=start + 2):
        power_sheet.cell(row, 1, mode_id)
        power_sheet.cell(row, 2, mode)
        for col in (1, 2):
            power_sheet.cell(row, col).border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)
            power_sheet.cell(row, col).alignment = Alignment(wrap_text=True, vertical="top")

    write_table(
        workbook,
        "CAN Fault Matrix",
        "CAN Wake-up and Data-Quality Coverage",
        "Design coverage only until the named W501 matrix/DBC, valid values, and EDR packing rules are available.",
        ["Test Case ID", "Test Family", "Covered Conditions", "Blocking Ambiguities", "Status"],
        build_can_rows(),
        AMBER,
    )

    write_table(
        workbook,
        "Variant Matrix",
        "Variant-Applicability Matrix",
        "The Low/Mid Domestic no-SRSU side-event requirement is source-backed. All other variant behavior is explicitly deferred.",
        ["Variant / Configuration", "Stimulus", "Test Case", "Expected Behavior / Limit", "Status"],
        build_variant_rows(),
        BLUE,
    )

    write_table(
        workbook,
        "State Model",
        "EDR Analytical State Model",
        "This is a test-design state model, not an implementation claim. Source-backed transitions are distinguished from TBC model transitions and illegal review hypotheses.",
        ["State / Transition ID", "From State", "Trigger", "To State", "Evidence / Interpretation", "Test Coverage", "Status"],
        build_state_rows(),
        AMBER,
    )

    write_table(
        workbook,
        "Data Element Matrix",
        "Data-Element and DBC-Signal Coverage",
        "DID/byte offsets and CAN details are not inferred. Source-table values are retained separately from unavailable field packing.",
        ["Data Element", "Expected Behavior", "Source Reference", "Test Coverage", "Status"],
        build_data_element_rows(),
        GREEN,
    )

    write_table(
        workbook,
        "Ambiguity Register",
        "Ambiguity and Clarification Register",
        "Each unresolved area has an ID, evidence, risk, exact architect question, and provisional test-case coverage.",
        ["Ambiguity ID", "Topic", "Why Evidence Is Insufficient / Conflicting", "Safety or Data-Integrity Risk", "Exact Clarification Question", "Provisional Test Cases", "Disposition"],
        build_ambiguity_rows(),
        AMBER,
    )

    write_table(
        workbook,
        "Residual Risk",
        "Residual-Risk Register",
        "Risks remain open until their ambiguity has source-backed closure and the corresponding test obtains a deterministic oracle.",
        ["Risk ID", "Priority", "Residual Risk", "Related Ambiguity", "Mitigating Test Cases", "Residual Risk Level", "Closure Condition"],
        build_risk_rows(),
        RED,
    )

    write_table(
        workbook,
        "Test Techniques",
        "Test-Design Technique Coverage",
        "Each technique is tied to a defect class and concrete case families; this prevents test-count expansion without added defect yield.",
        ["Technique", "Applied To", "Defect Classes Targeted", "Test Case Coverage"],
        build_technique_rows(),
        BLUE,
    )

    write_table(
        workbook,
        "Failure Hypotheses",
        "Failure Hypotheses by Test Family",
        "Defect hypotheses guide high-yield test selection. A hypothesis is not an implementation claim or a source-approved expected result.",
        ["Test Family", "Failure Hypotheses", "Test Coverage", "Evidence / Limitation"],
        build_failure_hypothesis_rows(),
        RED,
    )

    write_table(
        workbook,
        "Prioritization",
        "Top 25 and Suite Prioritization",
        "P0 addresses possible loss/corruption of crash data; P1 lock/overwrite/completion/association; P2 CAN/diagnostic/variant; P3 robustness/endurance.",
        ["Rank / Suite", "Test Case ID(s)", "Priority", "Why It Is High Yield", "Prerequisite"],
        build_priority_rows(cases),
        GREEN,
    )

    write_table(
        workbook,
        "Automation Strategy",
        "Automation, Property-Based Generation, and Instrumentation",
        "Pseudocode and invariants are design-only. Source-backed and review-only invariants are explicitly distinguished.",
        ["Element", "Design", "Coverage", "Limit / Note"],
        build_automation_rows(),
        BLUE,
    )

    workbook.save(OUTPUT_WORKBOOK)


def validate_workbook(path: Path, expected_case_count: int | None = None) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Generated workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=True)
    required_sheets = [
        "Document Control",
        "Source Register",
        "Requirements",
        "Glossary",
        "Test Matrix",
        "Source Vector Matrix",
        "Completion Matrix",
        "Traceability",
        "Event Count Coverage",
        "Lock Overwrite Matrix",
        "Timing Boundaries",
        "Power Interruption Matrix",
        "CAN Fault Matrix",
        "Variant Matrix",
        "State Model",
        "Data Element Matrix",
        "Ambiguity Register",
        "Residual Risk",
        "Test Techniques",
        "Failure Hypotheses",
        "Prioritization",
        "Automation Strategy",
    ]
    missing_sheets = [name for name in required_sheets if name not in workbook.sheetnames]
    if missing_sheets:
        raise ValueError(f"Generated workbook is missing sheets: {missing_sheets}")
    matrix = workbook["Test Matrix"]
    observed_headers = [cell_text(cell.value) for cell in next(matrix.iter_rows(min_row=4, max_row=4, values_only=False))]
    if observed_headers != TEST_HEADERS:
        raise ValueError("Test Matrix headers do not match the intended review contract.")
    identifiers: list[str] = []
    status_values: list[str] = []
    for values in matrix.iter_rows(min_row=5, values_only=True):
        if not any(value is not None and str(value) != "" for value in values):
            continue
        identifiers.append(cell_text(values[0]))
        status_values.append(cell_text(values[36]))
    if not identifiers:
        raise ValueError("Test Matrix contains no test cases.")
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("Test Matrix contains duplicate test-case IDs.")
    if expected_case_count is not None and len(identifiers) != expected_case_count:
        raise ValueError(f"Expected {expected_case_count} test cases but found {len(identifiers)}.")
    if not any(value == "ON HOLD" for value in status_values):
        raise ValueError("Expected explicit ON HOLD cases for unresolved source gaps.")
    if not any(value == "IN REVIEW" for value in status_values):
        raise ValueError("Expected source-backed IN REVIEW cases.")
    vector_matrix = workbook["Source Vector Matrix"]
    vector_count = sum(
        1
        for values in vector_matrix.iter_rows(min_row=5, values_only=True)
        if any(value is not None and str(value) != "" for value in values)
    )
    if vector_count != 16:
        raise ValueError(f"Expected 16 source-vector rows but found {vector_count}.")
    event_counts = {
        cell_text(values[0])
        for values in workbook["Event Count Coverage"].iter_rows(min_row=5, values_only=True)
        if values and values[0] is not None
    }
    if event_counts != {"0", "1", "2", "3", "4", "5", "10", "N"}:
        raise ValueError(f"Event-count coverage is incomplete: {event_counts}")
    timing_values = {
        cell_text(values[0])
        for values in workbook["Timing Boundaries"].iter_rows(min_row=5, values_only=True)
        if values and values[0] is not None
    }
    required_boundaries = {"0 ms", "1 ms", "199 ms", "200 ms", "201 ms", "299 ms", "300 ms", "301 ms", "499 ms", "500 ms", "501 ms", "4.999 s", "5.000 s", "5.001 s", "Tick/tolerance"}
    if not required_boundaries.issubset(timing_values):
        raise ValueError("Timing-boundary coverage is incomplete.")
    power_phase_count = sum(
        1
        for values in workbook["Power Interruption Matrix"].iter_rows(min_row=5, max_row=27, values_only=True)
        if values and cell_text(values[0]).startswith("PWR-P")
    )
    if power_phase_count != len(POWER_PHASES):
        raise ValueError(f"Expected {len(POWER_PHASES)} power-interruption phases but found {power_phase_count}.")
    ambiguity_ids = {
        cell_text(values[0])
        for values in workbook["Ambiguity Register"].iter_rows(min_row=5, values_only=True)
        if values and values[0] is not None
    }
    expected_ambiguities = {f"AMB-{index:03d}" for index in range(1, 15)}
    if not expected_ambiguities.issubset(ambiguity_ids):
        raise ValueError("Ambiguity register is incomplete.")
    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "test_case_count": len(identifiers),
        "unique_test_case_ids": len(set(identifiers)),
        "status_counts": dict(Counter(status_values)),
        "source_vector_count": vector_count,
        "event_count_coverage": sorted(event_counts, key=lambda value: (value == "N", int(value) if value.isdigit() else 999)),
        "power_interruption_phase_count": power_phase_count,
        "ambiguity_count": len(ambiguity_ids),
        "required_sheets_present": True,
        "test_matrix_headers_valid": True,
        "live_codebeamer_import_acceptance": "unverified; no approved importer round trip or source artifact IDs were supplied.",
    }


def generate() -> dict[str, Any]:
    source_data = inspect_source()
    cases = build_cases(source_data)
    create_workbook(source_data, cases)
    validation = validate_workbook(OUTPUT_WORKBOOK, expected_case_count=len(cases))
    report = {
        "document": "ICE Common SRS V1.4 EDR Test-Spec Design Matrix",
        "source": {
            "path": str(SOURCE_WORKBOOK),
            "sha256": source_data["source_hash"],
            "sheet_count": source_data["source_sheet_count"],
            "primary_sheet": "EDR_Requirements",
            "verified_source_rows": sorted(source_data["verified_rows"].keys(), key=int),
            "source_vector_count": len(source_data["vectors"]),
        },
        "traceability": {
            "status": SOURCE_TRACEABILITY_NOTICE,
            "codebeamer_export_ready": False,
            "reason": "No verified Codebeamer artifact IDs/approval statuses were present in EDR_Requirements.",
        },
        "generation": validation,
        "limitations": [
            "M&M_W501_IVN_Communication_Matrix_SRS_V1.25_26156 is unavailable locally.",
            "UDS/DID identity, access, packing, session, security, and NRC sources are unavailable in the supplied EDR sheet.",
            "Fourth/fifth-event replacement, locked-record behavior, counter rollover, NVM atomicity, and timing equality/tolerance require clarification.",
            "No bench/ECU operation was performed.",
        ],
    }
    OUTPUT_REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate the offline ICE Common EDR test-design workbook.")
    command = parser.add_mutually_exclusive_group(required=True)
    command.add_argument("--generate", action="store_true", help="Generate workbook and validation report from the read-only source workbook.")
    command.add_argument("--validate", action="store_true", help="Validate the existing generated workbook only.")
    arguments = parser.parse_args()
    if arguments.generate:
        report = generate()
    else:
        report = validate_workbook(OUTPUT_WORKBOOK)
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())