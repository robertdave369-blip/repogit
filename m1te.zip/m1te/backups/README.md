# Archived Test Backups

This folder retains immutable, date-named restoration snapshots created before
controlled test or specification changes. Nested directories preserve their
original source hierarchy and are documented by the backup manifest and the
top-level migration or change report; do not add README files throughout an
archived snapshot because that would alter the preserved backup content.

Before restoring or deleting a backup, verify its manifest and hashes, record
the decision in `tests/logbook/YYYY-MM.md`, and preserve original customer
source material outside this folder.