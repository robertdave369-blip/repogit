from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

import sys


REPO_ROOT = Path(__file__).resolve().parents[1]
TOOLS_DIR = REPO_ROOT / "tools"
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import aria_config_assistant as aca  # noqa: E402


@unittest.skipIf(aca.openpyxl is None, "openpyxl is required for workbook tests")
class AriaConfigAssistantTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="aria-assistant-tests-"))

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def write_json(self, path: Path, payload: object) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def write_text(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def create_workbook(self, path: Path, rows: list[list[object]], sheet_name: str = "Sheet1") -> None:
        workbook = aca.openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = sheet_name
        for row in rows:
            sheet.append(row)
        path.parent.mkdir(parents=True, exist_ok=True)
        workbook.save(path)

    def create_minimal_bundle(self, root: Path) -> dict[str, object]:
        files = aca.load_template_files("minimal-json-bundle")
        for name, payload in files.items():
            self.write_json(root / name, payload)

        self.write_text(root / "SymbolFile.sym", "SYMBOL")
        self.write_text(root / "Mnemonics.xml", "<Mnemonics/>")
        self.write_text(root / "LINConfig.xml", "<ConfigurationLIN><BaudRate>19200</BaudRate></ConfigurationLIN>")
        self.write_text(root / "Periodic_CAN_Channel_1.xml", "<ConfigurationPeriodic><Frames/></ConfigurationPeriodic>")
        self.write_text(root / "DTCList.xml", "<ConfigurationDTC><GeneralConfigCodes/></ConfigurationDTC>")
        self.write_text(root / "Services.xml", "<ConfigurationServices><Services/></ConfigurationServices>")
        self.write_text(root / "error_definition_ProjectName_Pxx.xlsm", "placeholder")

        (root / "Config_folder").mkdir(parents=True, exist_ok=True)
        (root / "Filter_folder").mkdir(parents=True, exist_ok=True)
        (root / "Crash_Data").mkdir(parents=True, exist_ok=True)
        (root / "Scripts").mkdir(parents=True, exist_ok=True)
        (root / "Results").mkdir(parents=True, exist_ok=True)
        (root / "Config_folder" / "RSU" / "XLS").mkdir(parents=True, exist_ok=True)
        (root / "Config_folder" / "SPI" / "XLS").mkdir(parents=True, exist_ok=True)
        (root / "Config_folder" / "RSU" / "XML").mkdir(parents=True, exist_ok=True)

        self.write_text(root / "Config_folder" / "RSU" / "XML" / "Config.xml", "<Config/>")
        self.write_text(root / "Config_folder" / "RSU" / "XML" / "OROYA_Sensor.xml", "<Startup><Sensor name='OROYA'/></Startup>")
        self.write_text(root / "Config_folder" / "RSU" / "XML" / "SMB482_Sensor.xml", "<Startup><Sensor name='SMB482'/></Startup>")
        return files

    def test_inspect_harness_workbook_extracts_mapping(self) -> None:
        workbook_path = self.temp_dir / "ARIA_Harness.xlsx"
        self.create_workbook(
            workbook_path,
            [
                ["Slot", "Card Type SC2", "Card Type", "CH", "ZIF PIN Feed", "ZIF PIN Rtrn", "Master ECU Pin"],
                [1, "Loop", "Loop", 1, "A1", "A2", "C1-1(F), C1-2(R)"],
                [1, "Loop", "Loop", 2, "A3", "A4", "C1-3(F), C1-4(R)"],
                [28, "RSU", "RSU", 1, "L9", "L0", "C2-57/C2-39"],
            ],
            sheet_name="ARIA_Generic",
        )

        result = aca.inspect_workbook(workbook_path)

        self.assertEqual(result["workbook_type"], "harness_mapping")
        self.assertEqual(result["slot_count"], 2)
        self.assertEqual(result["mapping_row_count"], 3)
        self.assertEqual(result["mapping_rows"][0]["zif_pin_feed"], "A1")

    def test_infer_project_key_prefers_stronger_package_signals(self) -> None:
        package_root = self.temp_dir / "package"
        (package_root / "Config_folder" / "RSU" / "XLS" / "M314").mkdir(parents=True, exist_ok=True)
        source_values = [
            r"..\..\Framework_W616_Krishna\TestManager",
            r"C:\AriaConfigFiles_M314\AriaConfigFiles\AriaMain_accdata\Faults\Fault_Monitor_M314\FltMonr_Configurator_SC3 4.xlsm",
            r"Config_folder\RSU\XLS\M314\M314_RSU.xlsx",
        ]
        project_key = aca.infer_project_key(
            None,
            bundle_root=self.temp_dir,
            source_values=source_values,
            package_root=package_root,
            og_root=None,
        )
        self.assertEqual(project_key, "M314")

    def test_validate_bundle_accepts_complete_minimal_bundle(self) -> None:
        bundle_root = self.temp_dir / "bundle"
        self.create_minimal_bundle(bundle_root)

        result = aca.validate_bundle(bundle_root, project_key="TEST")

        self.assertEqual(result["summary"]["errors"], 0)
        self.assertEqual(result["summary"]["warnings"], 0)

    def test_diff_dbc_reports_changes_and_impacts(self) -> None:
        old_dbc = self.temp_dir / "old.dbc"
        new_dbc = self.temp_dir / "new.dbc"
        impact_root = self.temp_dir / "impact"

        self.write_text(
            old_dbc,
            "\n".join(
                [
                    "BO_ 100 MSG_A: 8 ECU",
                    " SG_ SPEED : 0|8@1+ (1,0) [0|255] \"kmh\" ECU",
                ]
            ),
        )
        self.write_text(
            new_dbc,
            "\n".join(
                [
                    "BO_ 100 MSG_A: 8 ECU",
                    " SG_ RPM : 0|16@1+ (1,0) [0|65535] \"rpm\" ECU",
                    "BO_ 200 MSG_B: 8 ECU",
                    " SG_ DOOR_UNLOCK : 0|1@1+ (1,0) [0|1] \"\" ECU",
                ]
            ),
        )
        self.write_text(impact_root / "Periodic.xml", "<Signal>DOOR_UNLOCK</Signal>")

        result = aca.diff_dbc(old_dbc, new_dbc, search_roots=[impact_root])

        self.assertIn("MSG_B", result["added_messages"])
        self.assertIn("SPEED", result["removed_signals"])
        self.assertIn("DOOR_UNLOCK", result["added_signals"])
        self.assertEqual(result["summary"]["impact_matches"], 1)

    def test_summarize_ldbx_handles_object_payload(self) -> None:
        ldbx_path = self.temp_dir / "sample.ldbx"
        self.write_text(ldbx_path, '{"Content": {"unexpected": true}}')

        result = aca.summarize_ldbx(ldbx_path)

        self.assertEqual(result["slot_count"], 0)
        self.assertIn("warning", result)

    def test_coerce_jsonable_stringifies_unknown_objects(self) -> None:
        class Dummy:
            def __str__(self) -> str:
                return "dummy-object"

        self.assertEqual(aca.coerce_jsonable(Dummy()), "dummy-object")

    def test_generate_project_bundle_updates_ids_and_copies_assets(self) -> None:
        source_root = self.temp_dir / "source"
        self.create_minimal_bundle(source_root)

        self.create_workbook(
            source_root / "Config_folder" / "RSU" / "XLS" / "M314" / "M314_RSU.xlsx",
            [
                ["RSU Configuration", None, "RSU Startup"],
                ["1F4", None, "6"],
            ],
            sheet_name="OR_Start",
        )
        self.write_text(source_root / "AriaMain_accdata" / "Loadbox" / "M314.ldbx", '[{"CardType":"RsuCardV1","Slot":28,"Channels":[{"ChannelIndex":1,"Functions":[{"FunctionId":0,"Status":"INHERENT"}]}]}]')
        self.write_text(source_root / "AriaMain_accdata" / "Loadbox" / "M314_LoadBox_Profile.json", '{"Version":1}')
        self.write_text(source_root / "DBC" / "M314" / "SRS_FD.dbc", "BO_ 100 MSG_A: 8 ECU")

        workspace_config = self.temp_dir / "workspace" / "config"
        self.write_text(
            workspace_config / "project_config.py",
            "\n".join(
                [
                    'PROJECT_NAME = "M314"',
                    "CAN_BAUD_RATE = 1000000",
                    "CAN_FD_ENABLED = True",
                    "DIAG_TX_ID = 0x780",
                    "DIAG_FUNCTIONAL_ID = 0x7DF",
                    "DIAG_RX_ID = 0x781",
                ]
            ),
        )

        output_dir = self.temp_dir / "generated"
        result = aca.generate_project_bundle(
            "M314",
            output_dir,
            source_root=source_root,
            og_root=None,
            workspace_config_dir=workspace_config,
            customer="M314",
            copy_files=True,
            copy_support_directories=True,
            root_alias="AriaMain_<Project>.json",
            validate_after_write=True,
            base_project=None,
        )

        generated_can = json.loads((output_dir / "CanConfig.json").read_text(encoding="utf-8"))
        primary_diag = generated_can["CanChannelConfig"][0]["DiagProperties"]

        self.assertTrue((output_dir / "AriaMain_M314.json").exists())
        self.assertTrue((output_dir / "artifact-manifest.json").exists())
        self.assertTrue((output_dir / "validation-report.json").exists())
        self.assertEqual(primary_diag["PhysicalRequestID"], "0x780")
        self.assertEqual(primary_diag["FunctionalRequestID"], "0x7DF")
        self.assertEqual(primary_diag["ResponseID"], "0x781")
        self.assertEqual(result["validation"]["summary"]["errors"], 0)


if __name__ == "__main__":
    unittest.main()
