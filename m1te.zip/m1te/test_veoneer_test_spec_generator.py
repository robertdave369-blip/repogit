"""Offline regression tests for the Veoneer test-specification skill."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any, cast

import openpyxl
from openpyxl.styles import Alignment, PatternFill


SKILL_SCRIPTS = (
    Path(__file__).resolve().parents[1]
    / ".github"
    / "skills"
    / "veoneer-test-spec-generator"
    / "scripts"
)
if str(SKILL_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SKILL_SCRIPTS))

from generator import generate_specification
from legacy_export import (
    LEGACY_EXPORT_HEADERS,
    LEGACY_TEMPLATE_HEADERS,
    inspect_legacy_export_template,
    render_legacy_export_specification,
    validate_legacy_export_specification,
    validate_legacy_export_workbook,
)
from legacy_adapters import excel_to_testcase_dict, write_legacy_title_step_workbook
from methodology import select_methodology
from models import Requirement, SourceProvenance
from requirement_parser import parse_docx, parse_excel, parse_inline_requirements, parse_pdf
from sanitize import sanitize_text
from validation import validate_rendered_workbook, validate_specification
from workbook_codec import inspect_template, load_profile, read_export_cases, render_specification


class VeoneerTestSpecGeneratorTests(unittest.TestCase):
    """Exercise deterministic skill behavior without an ARIA bench or Codebeamer connection."""

    def _build_template(self, destination: Path) -> None:
        profile = load_profile()
        workbook = openpyxl.Workbook()
        export = workbook.active
        if export is None or not hasattr(export, "append"):
            self.fail("openpyxl did not create a writable worksheet.")
        export = cast(Any, export)
        export.title = "Export"
        export.append(profile["workbook"]["header_order"])
        export.append([None] * len(profile["workbook"]["header_order"]))
        export.append([None] * len(profile["workbook"]["header_order"]))
        choices = workbook.create_sheet("ChoiceValues")
        choices.sheet_state = "hidden"
        techniques = [
            "Equivalence Classes",
            "Boundary Value Analysis",
            "Fault Injection",
            "State Transition Testing",
            "Decision Table Testing",
        ]
        for row_number, technique in enumerate(techniques, start=1):
            choices.cell(row=row_number, column=1, value=technique)
        workbook.save(destination)
        workbook.close()

    def _approved_requirement(self) -> Requirement:
        return Requirement(
            identifier="31300826",
            title="Status timeout",
            text="The controller shall report the requested status within 100 ms.",
            status="Approved",
            provenance=SourceProvenance(
                source_path="test-requirements.json",
                source_type="json",
                location="item 1",
                raw_status="Approved",
            ),
        )

    def _build_legacy_export_template(self, destination: Path) -> None:
        workbook = openpyxl.Workbook()
        export = workbook.active
        if export is None or not hasattr(export, "append"):
            self.fail("openpyxl did not create a writable worksheet.")
        export = cast(Any, export)
        export.title = "Export"
        export.append(LEGACY_TEMPLATE_HEADERS)
        export.append(["Normal", "EXISTING_GROUP", None, None, None, None, None])
        export.append(["High", "Existing_Case", "Existing description", "Existing setup", "Existing cleanup", "Existing action", "Existing result"])
        export.append([None, None, None, None, None, "Existing continuation", "Existing continuation result"])
        for row in export.iter_rows():
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="top")
        export.cell(3, 2).fill = PatternFill("solid", fgColor="FFF200")
        export.auto_filter.ref = "A1:G4"
        choices = workbook.create_sheet("ChoiceValues")
        choices.sheet_state = "hidden"
        choices["A1"] = "Retained choice value"
        workbook.save(destination)
        workbook.close()

    def test_sanitization_preserves_engineering_tokens_and_struck_content(self) -> None:
        normal = sanitize_text("%%(color:red;)<span>CAN-FD 62.5%</span>%! [ISSUE:31300826]-null ~-")
        self.assertIn("CAN-FD 62.5%", normal.text)
        self.assertIn("[ISSUE:31300826]-null", normal.text)
        self.assertIn("-", normal.text)
        struck = sanitize_text("%%(text-decoration:line-through;)obsolete behavior%!")
        self.assertEqual(struck.text, "[STRUCK: obsolete behavior]")

    def test_excel_parser_reads_all_sheets_and_preserves_provenance(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "requirements.xlsx"
            workbook = openpyxl.Workbook()
            requirements = workbook.active
            if requirements is None or not hasattr(requirements, "append"):
                self.fail("openpyxl did not create a writable worksheet.")
            requirements = cast(Any, requirements)
            requirements.title = "Requirements"
            requirements.append(["ID", "Summary", "Description", "_ReqStatus", "_Projects"])
            requirements.append(["31300826", "Status", "The status shall be available.", "Approved", "Demo"])
            notes = workbook.create_sheet("Notes")
            notes.append(["Free text"])
            notes.append(["Not a requirement table"])
            workbook.save(source)
            workbook.close()

            parsed, report = parse_excel(source)
            self.assertEqual(len(parsed), 1)
            self.assertEqual(parsed[0].identifier, "31300826")
            self.assertEqual(parsed[0].provenance.location, "Requirements!2")
            self.assertEqual(len(report.sheet_stats), 2)
            self.assertEqual(report.sheet_stats[1]["warning"], "requirement_header_unavailable")

    def test_docx_and_pdf_parsers_preserve_source_locations(self) -> None:
        try:
            import fitz
            from docx import Document
        except ImportError:
            self.skipTest("Optional DOCX/PDF parser dependencies are not installed.")
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory)
            docx_path = workspace / "requirements.docx"
            document = Document()
            document.add_paragraph("90000001: The fixture shall report status.")
            document.save(docx_path)
            docx_records, _ = parse_docx(docx_path)
            self.assertEqual(docx_records[0].provenance.location, "paragraph 1")

            pdf_path = workspace / "requirements.pdf"
            pdf = fitz.open()
            page = pdf.new_page()
            page.insert_text((72, 72), "90000002: The fixture shall preserve the stated value.")
            pdf.save(pdf_path)
            pdf.close()
            pdf_records, _ = parse_pdf(pdf_path)
            self.assertEqual(pdf_records[0].provenance.location, "page 1 paragraph 1")

    def test_legacy_adapter_round_trip(self) -> None:
        test_cases = [
            {
                "Sno": 1,
                "Test Case Name": "Status_Nominal",
                "Test Case Description": "Verify nominal status behavior.",
                "Steps": [
                    ["1", "Establish normal state", "System is ready"],
                    ["2", "Request status", "Status is reported"],
                ],
            }
        ]
        with tempfile.TemporaryDirectory() as directory:
            workbook_path = Path(directory) / "legacy.xlsx"
            write_legacy_title_step_workbook(test_cases, workbook_path)
            parsed = excel_to_testcase_dict(workbook_path)
            self.assertEqual(parsed, test_cases)

    def test_response_timeout_uses_boundary_not_fault_methodology(self) -> None:
        requirement = self._approved_requirement()
        methodology = select_methodology(
            requirement,
            allowed_techniques=["Boundary Value Analysis", "Fault Injection"],
        )
        self.assertEqual(methodology.primary_technique, "Boundary Value Analysis")

    def test_comma_separated_requirement_ids_are_retained(self) -> None:
        requirements = parse_inline_requirements(
            ["31300826, 31307791: The controller shall report the requested status within 100 ms."]
        )
        self.assertEqual(requirements[0].identifier, "31300826, 31307791")
        generation = generate_specification(requirements, title="Multi-ID specification")
        self.assertEqual(generation.specification.test_cases[0].requirement_ids, ["31300826", "31307791"])

    def test_template_render_round_trip_and_traceability_format(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            template = Path(directory) / "template.xlsx"
            output = Path(directory) / "generated.xlsx"
            self._build_template(template)
            inspection = inspect_template(template)
            self.assertEqual(inspection.issues, [])
            generation = generate_specification(
                [self._approved_requirement()],
                title="Generated specification",
                allowed_techniques=inspection.allowed_values["_TestTechnique"],
            )
            self.assertEqual(len(generation.specification.test_cases), 2)
            preflight = validate_specification(generation.specification, template_path=template)
            self.assertEqual([issue for issue in preflight if issue.severity == "error"], [])
            render_specification(
                generation.specification,
                template_path=template,
                destination_path=output,
                write_mode="replace_data",
            )
            postflight = validate_rendered_workbook(output)
            self.assertEqual(postflight["summary"]["errors"], 0)
            cases = read_export_cases(output)
            self.assertEqual(len(cases), 2)
            self.assertEqual(cases[0]["fields"]["Verifies"], "[ISSUE:31300826] - null")
            self.assertEqual(len(cases[0]["steps"]), 3)

    def test_legacy_export_renderer_preserves_reviewed_v3_contract(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            template = Path(directory) / "legacy-template.xlsx"
            output = Path(directory) / "legacy-generated.xlsx"
            self._build_legacy_export_template(template)
            inspection = inspect_legacy_export_template(template)
            self.assertEqual(inspection.issues, [])
            requirement = self._approved_requirement()
            requirement.identifier = "31300826, 31307791"
            generation = generate_specification([requirement], title="Legacy generated specification")
            preflight = validate_legacy_export_specification(generation.specification)
            self.assertEqual([issue for issue in preflight if issue.severity == "error"], [])
            render_legacy_export_specification(
                generation.specification,
                template_path=template,
                destination_path=output,
                group_name="GENERATED_STATUS_TESTS",
            )
            postflight = validate_legacy_export_workbook(
                output,
                expected_case_names=[test_case.name for test_case in generation.specification.test_cases],
            )
            self.assertEqual(postflight["summary"]["errors"], 0)
            self.assertEqual(postflight["group_names"], ["GENERATED_STATUS_TESTS"])
            workbook = openpyxl.load_workbook(output, data_only=False)
            try:
                export = workbook["Export"]
                self.assertEqual([cell.value for cell in export[1]], list(LEGACY_EXPORT_HEADERS))
                self.assertIsNone(export.cell(3, 1).value)
                self.assertTrue(str(export.cell(3, 4).value).startswith("Objective:"))
                self.assertEqual(export.cell(3, 11).value, "[ISSUE:31300826] - null,[ISSUE:31307791] - null")
                self.assertTrue(str(export.cell(3, 3).fill.fgColor.rgb).upper().endswith("FFF200"))
                self.assertTrue(all(export.cell(4, column_number).value is None for column_number in (*range(1, 7), *range(10, 23))))
                self.assertEqual(workbook["ChoiceValues"].sheet_state, "hidden")
            finally:
                workbook.close()
            provided_id_output = Path(directory) / "legacy-provided-id.xlsx"
            generation.specification.test_cases[0].artifact_id = 99000001
            render_legacy_export_specification(
                generation.specification,
                template_path=template,
                destination_path=provided_id_output,
                group_name="GENERATED_STATUS_TESTS",
            )
            provided_id_postflight = validate_legacy_export_workbook(
                provided_id_output,
                expected_test_cases=generation.specification.test_cases,
            )
            self.assertEqual(provided_id_postflight["summary"]["errors"], 0)
            workbook = openpyxl.load_workbook(provided_id_output, data_only=False)
            try:
                self.assertEqual(workbook["Export"].cell(3, 1).value, 99000001)
                self.assertEqual(
                    workbook["Export"].cell(3, 11).value,
                    "[ISSUE:31300826] - null,[ISSUE:31307791] - null",
                )
            finally:
                workbook.close()
            append_output = Path(directory) / "legacy-appended.xlsx"
            render_legacy_export_specification(
                generation.specification,
                template_path=template,
                destination_path=append_output,
                group_name="GENERATED_STATUS_TESTS",
                write_mode="append",
            )
            append_postflight = validate_legacy_export_workbook(
                append_output,
                expected_case_names=[test_case.name for test_case in generation.specification.test_cases],
                expected_case_mode="suffix",
            )
            self.assertEqual(append_postflight["summary"]["errors"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)