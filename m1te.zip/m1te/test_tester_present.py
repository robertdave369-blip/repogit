from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Callable, cast
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = REPO_ROOT / "shared_libraries" / "core_functions.py"
TesterPresent = Callable[..., str]


class _FakeCan:
    def __init__(self) -> None:
        self.calls: list[tuple[object, ...]] = []
        self.periodic_frame_result: str | None = None
        self.cycle_time_result: str | None = None

    def SetPeriodicFrame(
        self,
        channel: str | None,
        frame_name: str,
        frame_id: int,
        periodicity: int,
        payload: list[int],
        is_fd: bool,
    ) -> str | None:
        self.calls.append(
            ("set_periodic_frame", channel, frame_name, frame_id, periodicity, payload, is_fd)
        )
        return self.periodic_frame_result

    def SetFrameCycleTime(self, channel: str | None, frame_name: str, periodicity: int) -> str:
        self.calls.append(("set_cycle_time", channel, frame_name, periodicity))
        if self.cycle_time_result is not None:
            return self.cycle_time_result
        return f"Frame {frame_name} cycle time set to {periodicity}"

    def PeriodicEnableFrame(self, channel: str | None, frame_name: str) -> str:
        self.calls.append(("enable", channel, frame_name))
        return f"Simulation Started on {frame_name}"

    def PeriodicDisableFrame(self, channel: str | None, frame_name: str) -> str:
        self.calls.append(("disable", channel, frame_name))
        return f"Simulation Stopped on {frame_name}"


def _load_tester_present() -> tuple[TesterPresent, dict[str, Any]]:
    source = MODULE_PATH.read_text(encoding="utf-8")
    module = ast.parse(source, filename=str(MODULE_PATH))
    function_node = next(
        node
        for node in module.body
        if isinstance(node, ast.FunctionDef) and node.name == "tester_present"
    )
    isolated_module = ast.Module(body=[function_node], type_ignores=[])
    ast.fix_missing_locations(isolated_module)
    namespace: dict[str, Any] = {}
    exec(compile(isolated_module, str(MODULE_PATH), "exec"), namespace)
    return cast(TesterPresent, namespace["tester_present"]), namespace


class TesterPresentTests(unittest.TestCase):
    def _function_with_fake_can(self) -> tuple[TesterPresent, _FakeCan]:
        function, namespace = _load_tester_present()
        fake_can = _FakeCan()
        namespace["CAN"] = fake_can
        return function, fake_can

    def test_start_sets_periodicity_before_enabling_frame(self) -> None:
        function, fake_can = self._function_with_fake_can()

        result = function(
            "VEH DIAG Simulation",
            1000,
            "start",
            frame_name="SRS_DIAG_REQ",
            frame_id=0x730,
        )

        self.assertEqual(result, "Simulation Started on SRS_DIAG_REQ")
        self.assertEqual(
            fake_can.calls,
            [
                (
                    "set_periodic_frame",
                    "VEH DIAG Simulation",
                    "SRS_DIAG_REQ",
                    0x730,
                    1000,
                    [0x02, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
                    False,
                ),
                ("set_cycle_time", "VEH DIAG Simulation", "SRS_DIAG_REQ", 1000),
                ("enable", "VEH DIAG Simulation", "SRS_DIAG_REQ"),
            ],
        )

    def test_omitted_channel_delegates_resolution_to_can_wrapper(self) -> None:
        function, fake_can = self._function_with_fake_can()

        result = function(
            periodicity=1000,
            action="start",
            frame_name="SRS_DIAG_REQ",
            frame_id=0x730,
        )

        self.assertEqual(result, "Simulation Started on SRS_DIAG_REQ")
        self.assertEqual(
            fake_can.calls,
            [
                (
                    "set_periodic_frame",
                    None,
                    "SRS_DIAG_REQ",
                    0x730,
                    1000,
                    [0x02, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
                    False,
                ),
                ("set_cycle_time", None, "SRS_DIAG_REQ", 1000),
                ("enable", None, "SRS_DIAG_REQ"),
            ],
        )

    def test_stop_disables_frame_without_changing_periodicity(self) -> None:
        function, fake_can = self._function_with_fake_can()

        result = function("VEH DIAG Simulation", None, "stop", frame_name="SRS_DIAG_REQ")

        self.assertEqual(result, "Simulation Stopped on SRS_DIAG_REQ")
        self.assertEqual(
            fake_can.calls,
            [("disable", "VEH DIAG Simulation", "SRS_DIAG_REQ")],
        )

    def test_start_does_not_update_or_enable_when_frame_setup_fails(self) -> None:
        function, fake_can = self._function_with_fake_can()
        fake_can.periodic_frame_result = "simulation channel not found"

        result = function(
            "VEH DIAG Simulation",
            1000,
            "start",
            frame_name="SRS_DIAG_REQ",
            frame_id=0x730,
        )

        self.assertEqual(result, "simulation channel not found")
        self.assertEqual(
            fake_can.calls,
            [
                (
                    "set_periodic_frame",
                    "VEH DIAG Simulation",
                    "SRS_DIAG_REQ",
                    0x730,
                    1000,
                    [0x02, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
                    False,
                )
            ],
        )

    def test_start_does_not_enable_when_cycle_time_update_fails(self) -> None:
        function, fake_can = self._function_with_fake_can()
        fake_can.cycle_time_result = "simulation frame not found"

        result = function(
            "VEH DIAG Simulation",
            1000,
            "start",
            frame_name="SRS_DIAG_REQ",
            frame_id=0x730,
        )

        self.assertEqual(result, "simulation frame not found")
        self.assertEqual(
            fake_can.calls,
            [
                (
                    "set_periodic_frame",
                    "VEH DIAG Simulation",
                    "SRS_DIAG_REQ",
                    0x730,
                    1000,
                    [0x02, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
                    False,
                ),
                ("set_cycle_time", "VEH DIAG Simulation", "SRS_DIAG_REQ", 1000),
            ],
        )

    def test_start_requires_positive_integer_periodicity(self) -> None:
        function, fake_can = self._function_with_fake_can()

        with self.assertRaisesRegex(ValueError, "positive integer"):
            function(
                "VEH DIAG Simulation",
                None,
                "start",
                frame_name="SRS_DIAG_REQ",
                frame_id=0x730,
            )

        self.assertEqual(fake_can.calls, [])

    def test_function_is_exported(self) -> None:
        module = ast.parse(MODULE_PATH.read_text(encoding="utf-8"), filename=str(MODULE_PATH))
        exported_symbols = next(
            ast.literal_eval(node.value)
            for node in module.body
            if isinstance(node, ast.Assign)
            and any(
                isinstance(target, ast.Name) and target.id == "__all__"
                for target in node.targets
            )
        )

        self.assertIn("tester_present", exported_symbols)


if __name__ == "__main__":
    unittest.main()