from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

import openpyxl


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / ".github" / "skills" / "clean-exported-web-text-images-and-symbols" / "scripts" / "preview_clean_export.py"
SPEC = importlib.util.spec_from_file_location("excel_cleanup_preview", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
CLEANUP_PREVIEW = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = CLEANUP_PREVIEW
SPEC.loader.exec_module(CLEANUP_PREVIEW)


class ExcelCleanupPreviewTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="excel-cleanup-preview-"))
        self.workbook_path = self.temp_dir / "export.xlsx"
        workbook = openpyxl.Workbook()
        worksheet = workbook.active
        worksheet.title = "Export"
        worksheet["A1"] = "Prefix) Value-%\\~"
        worksheet["A2"] = "[!image!] Hello"
        worksheet["A3"] = "REQ-123456 50%"
        worksheet["A4"] = "=1-2"
        worksheet["A5"] = "Suffix)"
        workbook.create_sheet("Other")["A1"] = "Other) Sheet-Value"
        workbook.save(self.workbook_path)
        workbook.close()

    def tearDown(self) -> None:
        for path in self.temp_dir.rglob("*"):
            if path.is_file():
                path.unlink()
        for path in sorted((path for path in self.temp_dir.rglob("*") if path.is_dir()), reverse=True):
            path.rmdir()
        self.temp_dir.rmdir()

    def test_preview_matches_macro_transformations_without_modifying_source(self) -> None:
        before = self.workbook_path.read_bytes()

        report = CLEANUP_PREVIEW.preview_workbook(self.workbook_path, sheets=["Export"], max_changes=0)

        changes = {item["cell"]: item for item in report["changes"]}
        self.assertEqual(changes["A1"]["proposed"], "Value")
        self.assertEqual(changes["A2"]["proposed"], "Hello")
        self.assertEqual(changes["A3"]["proposed"], "REQ123456 50")
        self.assertEqual(changes["A4"]["proposed"], "=12")
        self.assertNotIn("A5", changes)
        self.assertIn("formula_cell", changes["A4"]["risk_flags"])
        self.assertIn("possible_requirement_or_tracker_id", changes["A3"]["risk_flags"])
        self.assertIn("percent_or_percentage", changes["A3"]["risk_flags"])
        self.assertEqual(before, self.workbook_path.read_bytes())
        self.assertFalse(report["source_modified"])

    def test_preview_requires_explicit_sheet_scope(self) -> None:
        with self.assertRaises(ValueError):
            CLEANUP_PREVIEW.preview_workbook(self.workbook_path, sheets=[])

    def test_preview_can_limit_reported_changes(self) -> None:
        report = CLEANUP_PREVIEW.preview_workbook(self.workbook_path, sheets=["Export"], max_changes=1)

        self.assertEqual(len(report["changes"]), 1)
        self.assertTrue(report["changes_truncated"])
        self.assertGreater(report["changed_cells_total"], 1)


if __name__ == "__main__":
    unittest.main()