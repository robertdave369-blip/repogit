from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
TOOLS_DIR = Path(__file__).resolve().parents[1] / "tools"
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import openpyxl  # noqa: E402

import report_review as rr  # noqa: E402
import spec_trace as st  # noqa: E402

REQS = {"requirements": [
    {"ID": "900101", "Summary": "Squib loop open detection", "_ReqStatus": "Approved",
     "Description": "The ACU shall set DTC 0x9A1234 with status 0x0B within 500 ms when squib LOOP1 resistance is open."},
    {"ID": "900102", "Summary": "Undervoltage warning", "_ReqStatus": "Approved",
     "Description": "The ACU shall set DTC 0xC10016 when BATT voltage stays below 9.0 V for 1000 ms."},
    {"ID": "900104", "Summary": "Lamp on at crash", "_ReqStatus": "Approved",
     "Description": "The ACU shall switch AIRBAG_LAMP on within 100 ms of a crash event."},
    {"ID": "900105", "Summary": "Crash frame", "_ReqStatus": "Draft",
     "Description": "The ACU shall send STS_CRASH = 1 on SRS1_20 within 10 ms of a deployment."}]}
CASES = {"title": "t", "test_cases": [
    {"name": "Squib LOOP1 open fault qualification", "description": "DTC 0x9A1234 for LOOP1 open", "priority": "High",
     "verifies": ["900101"], "steps": [{"action": "Set LOOP1 OPEN", "expected": "DTC 0x9A1234 status 0x0B within 500 ms", "critical": True}]},
    {"name": "BATT undervoltage DTC", "description": "BATT below 9.0 V for 1000 ms gives DTC 0xC10016", "priority": "Normal",
     "verifies": ["900102"], "steps": [{"action": "Set BATT 8.5 V for 1200 ms", "expected": "DTC 0xC10016 set"}]}]}
HTML = """<!--genv:1-->
<table><tr><td>#Test Case ID:</td><td>900101</td><td>#Test Case Description:</td><td>Squib LOOP1 open</td></tr></table>
<tr id="n-1" class="l1 visible -failed  group header"><td>1</td><td>0.1s</td><td>Read DTC</td><td>1.0s</td><td>FAILED</td></tr>
<tr id="n-1-1" class="l2 n-1d -failed  step "><td>1.1</td><td>0.2s</td><td>DTC 0x9A1234 status</td><td>0x0B</td><td>0x08</td><td></td></tr>
<tr id="n-1-2" class="l2 n-1d -failed  step header"><td>1.2</td><td>0.9s</td><td>Read log</td><td>frame 0x13C</td><td></td><td>0.1s</td><td>FAILED</td></tr>
<tr class="l3 n-1-2d -failed  content"><td>Traceback (most recent call last): File "x.py", line 1 ValueError: Failed to decode log data</td></tr>
<!--FAILED-->"""
XML = """<?xml version="1.0" encoding="iso-8859-1"?>
<!--
Test case ID: C:\\scripts\\Lamp.ts
Result Test:PASSED
Requirement under test:
Description of the requirement:
-->
<Results IsFinished="No"><Action Name="Lamp"><Expected>ON</Expected><Obtained>ON</Obtained><Result>Passed</Result></Action></Results>"""


class SpecTraceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="spec-trace-"))
        (self.tmp / "reqs.json").write_text(json.dumps(REQS), encoding="utf-8")
        (self.tmp / "cases.json").write_text(json.dumps(CASES), encoding="utf-8")

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_render_then_trace_finds_missing_trace_and_untested_requirement(self) -> None:
        self.assertEqual(st.main(["render", "--cases", str(self.tmp / "cases.json"), "--out", str(self.tmp / "spec.xlsx")]), 0)
        wb = openpyxl.load_workbook(self.tmp / "spec.xlsx")
        ws = wb["Export"]
        head = [c.value for c in ws[1]]
        verifies = [ws.cell(r, head.index("Verifies") + 1).value for r in range(2, ws.max_row + 1) if ws.cell(r, head.index("Name") + 1).value]
        self.assertEqual(verifies, ["[ISSUE:900101] - null", "[ISSUE:900102] - null"])
        for r in range(2, ws.max_row + 1):
            if "BATT" in str(ws.cell(r, head.index("Name") + 1).value):
                ws.cell(r, head.index("Verifies") + 1).value = None
        wb.save(self.tmp / "broken.xlsx")
        st.main(["trace", "--spec", str(self.tmp / "broken.xlsx"), "--req", str(self.tmp / "reqs.json"), "--out", str(self.tmp / "out")])
        found = {(f["category"], f.get("proposed") or f.get("current")) for f in json.loads((self.tmp / "out/findings_trace.json").read_text(encoding="utf-8"))}
        self.assertIn(("MISSING_TRACE", "[ISSUE:900102] - null"), found)
        self.assertIn(("UNTESTED_REQ", "write a test case"), found)
        self.assertIn(("UNAPPROVED_REQ", "design once approved"), found)   # the Draft one stays visible
        traced = openpyxl.load_workbook(self.tmp / "out/broken_traced.xlsx")
        self.assertIn("Coverage", traced.sheetnames)
        tws = traced["Export"]
        self.assertEqual([c.value for c in tws[1]][-3:], ["Proposed Verifies", "Trace basis", "Trace confidence"])
        batt_row = next(r for r in range(2, tws.max_row + 1) if "BATT" in str(tws.cell(r, head.index("Name") + 1).value))
        st.main(["apply", "--traced", str(self.tmp / "out/broken_traced.xlsx"), "--rows", str(batt_row)])
        fixed = openpyxl.load_workbook(self.tmp / "out/broken_corrected.xlsx")["Export"]
        self.assertEqual(fixed.cell(batt_row, head.index("Verifies") + 1).value, "[ISSUE:900102] - null")
        squib_row = next(r for r in range(2, tws.max_row + 1) if "Squib" in str(tws.cell(r, head.index("Name") + 1).value))
        tws.cell(squib_row, tws.max_column - 2).value = "[ISSUE:900104] - null"   # a proposal over an existing link
        traced.save(self.tmp / "out/broken_traced.xlsx")
        with self.assertRaises(SystemExit):                                     # needs --replace
            st.main(["apply", "--traced", str(self.tmp / "out/broken_traced.xlsx"), "--rows", str(squib_row)])

    def test_render_rejects_values_outside_the_template(self) -> None:
        bad = dict(CASES, test_cases=[dict(CASES["test_cases"][0], priority="Medium")])
        (self.tmp / "bad.json").write_text(json.dumps(bad), encoding="utf-8")
        self.assertEqual(st.main(["render", "--cases", str(self.tmp / "bad.json"), "--out", str(self.tmp / "x.xlsx")]), 1)
        self.assertFalse((self.tmp / "x.xlsx").exists())


class ReportReviewTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="report-review-"))

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_html_and_xml_results_with_their_logs(self) -> None:
        (self.tmp / "Squib_LOOP1_20261026_101500.html").write_text(HTML, encoding="utf-8")
        (self.tmp / "Squib_LOOP1_20261026_101500.txt").write_text("RX_MSG, c=1, t=1.0, id=0730, l=8, 03 19 02 0B", encoding="utf-8")
        (self.tmp / "Lamp.xml").write_text(XML, encoding="iso-8859-1")
        out = self.tmp / "results.json"
        rr.main(["scan", str(self.tmp), "--out", str(out)])
        recs = {Path(r["file"]).name: r for r in json.loads(out.read_text(encoding="utf-8"))}
        html_rec = recs["Squib_LOOP1_20261026_101500.html"]
        self.assertEqual((html_rec["verdict"], html_rec["fields"]["Test Case ID"]), ("FAILED", "900101"))
        self.assertEqual(html_rec["steps"][0]["obtained"], "0x08")
        self.assertEqual([g["name"] for g in html_rec["groups"]], ["Read DTC"])   # a "step header" is a step, not a group
        self.assertEqual((html_rec["steps"][1]["n"], html_rec["steps"][1]["result"]), ("1.2", "FAILED"))
        self.assertIn("ValueError: Failed to decode", html_rec["messages"][0])
        self.assertTrue(html_rec["log"].endswith(".txt"))
        xml_rec = recs["Lamp.xml"]
        self.assertEqual(xml_rec["fields"]["Requirement"], "")  # an empty header field must not swallow the next line
        flagged = " ".join(xml_rec["flags"])
        for expected in ("IsFinished=No", "without signature", "no CAN log"):
            self.assertIn(expected, flagged)


if __name__ == "__main__":
    unittest.main()
