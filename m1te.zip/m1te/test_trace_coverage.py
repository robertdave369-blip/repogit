from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

import openpyxl

sys.dont_write_bytecode = True
TOOLS_DIR = Path(__file__).resolve().parents[1] / "tools"
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import trace_coverage as tc  # noqa: E402


def workbook(path: Path, header: list[str], data: list[list]) -> Path:
    wb = openpyxl.Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = "Export"
    ws.append(header)
    for row in data:
        ws.append(row)
    wb.save(path)
    return path


class TraceCoverageTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp())
        self.req = workbook(self.tmp / "req.xlsx", ["ID", "Summary", "_ReqStatus", "Type"], [
            [100, "Chapter", "n/a", "Heading"],
            [101, "Speed IGN ON", "Approved", "Functional Requirement"],
            [102, "Speed timeout", "Approved", "Functional Requirement"],
            [103, "Old rule", "Obsolete", "Functional Requirement"],
            [104, "Twin", "Approved", "Functional Requirement"],
            [105, "Twin", "Approved", "Functional Requirement"],
            [106, "Uncovered", "Approved", "Functional Requirement"],
        ])
        self.spec = workbook(self.tmp / "spec.xlsx",
                             ["ID", "Name", "Verifies", "Status", "Type", "_ScriptPath", "_LatestResult"], [
            [1, "Folder", None, "n/a", "Folder", None, None],
            [2, "By ID", "[ISSUE:101] - null,[ISSUE:999] - null", "APPROVED", None, "tools/trace_coverage.py", "PASSED"],
            [3, "By name", "Speed timeout,Speed timeout", "APPROVED", None, "no/such/script.py", None],
            [4, "Weak", "Twin,Nobody,103", "APPROVED", None, None, None],
            [5, "Unlinked", None, "APPROVED", None, None, None],
        ])

    def test_links_coverage_and_gaps(self) -> None:
        r = tc.analyse([self.req], [self.spec])
        links = r["links"]
        self.assertEqual(links["id_resolved"], 2)          # 101 and bare 103
        self.assertEqual(links["id_unknown"], 1)           # 999
        self.assertEqual(links["name_resolved"], 1)        # "Speed timeout", listed twice, counted once
        self.assertEqual(links["name_ambiguous"], 1)       # "Twin" -> 104 and 105
        self.assertEqual(links["name_unresolved"], 1)      # "Nobody"
        self.assertEqual(links["to_not_approved"], 1)      # 103 is Obsolete
        self.assertEqual(len(r["tests"]), 4)               # folder row skipped
        self.assertEqual([t["id"] for t in r["tests"] if not t["has_links"]], ["5"])
        self.assertEqual(len(r["functional"]), 6)          # heading excluded
        self.assertEqual(sorted(x["id"] for x in r["uncovered"]), ["104", "105", "106"])
        by_id = {t["id"]: t for t in r["tests"]}
        self.assertTrue(by_id["2"]["script_exists"])
        self.assertFalse(by_id["3"]["script_exists"])

    def test_duplicate_exports_counted_once(self) -> None:
        r = tc.analyse([self.req, self.req], [self.spec, self.spec])
        self.assertEqual(r["duplicates"], 7)
        self.assertEqual(len(r["requirements"]), 7)
        self.assertEqual(r["test_duplicates"], 4)
        self.assertEqual(len(r["tests"]), 4)
        self.assertEqual(r["links"]["id_resolved"], 2)     # links of a repeated test case are not counted twice
        self.assertEqual(r["requirements"]["101"]["tests"], ["2"])

    def test_write_outputs(self) -> None:
        out = self.tmp / "out"
        tc.write(tc.analyse([self.req], [self.spec]), out)
        # Approved functional: 101, 102, 104, 105, 106; verified: 101 (by ID) and 102 (by name).
        self.assertIn("verified by at least one test case: 2 of 5 (1 through an ID link",
                      (out / "coverage_summary.md").read_text(encoding="utf-8"))
        self.assertEqual(len((out / "test_links.csv").read_text(encoding="utf-8").splitlines()), 5)


if __name__ == "__main__":
    unittest.main()
