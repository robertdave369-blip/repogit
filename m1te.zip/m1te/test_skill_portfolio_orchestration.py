from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / ".github" / "skills" / "skill-portfolio-orchestration" / "scripts" / "validate_portfolio.py"
SPEC = importlib.util.spec_from_file_location("skill_portfolio_validator", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
PORTFOLIO = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = PORTFOLIO
SPEC.loader.exec_module(PORTFOLIO)


def valid_envelope() -> dict[str, object]:
    return {
        "operation_id": "operation-1",
        "stage": "requirements-analysis",
        "intent": "requirements-safety-automation",
        "project": "M310_M314_M110",
        "safety_state": "offline",
        "confidence": {"level": "High", "rationale": "Source and validation are available."},
        "facts": ["An approved requirement source was supplied."],
        "inferences": [],
        "assumptions": [],
        "contradictions": [],
        "evidence_gaps": [],
        "artifacts": ["requirements.json"],
        "status": "completed",
    }


class SkillPortfolioOrchestrationTests(unittest.TestCase):
    def test_registry_covers_all_domain_skills_and_workflows(self) -> None:
        report = PORTFOLIO.validate_registry()

        self.assertEqual(report["status"], "passed")
        self.assertEqual(report["skill_count"], 12)
        self.assertEqual(report["workflow_count"], 6)
        self.assertEqual(report["output_location_policy"]["status"], "passed")

    def test_output_location_policy_routes_tests_and_processed_documents(self) -> None:
        policy_path = REPO_ROOT / ".github" / "skills" / "skill-portfolio-orchestration" / "assets" / "output-location-policy.json"

        report = PORTFOLIO.validate_output_location_policy(policy_path)

        self.assertEqual(report["status"], "passed")

    def test_valid_offline_envelope_passes(self) -> None:
        report = PORTFOLIO.validate_envelope(valid_envelope())

        self.assertEqual(report["status"], "passed")

    def test_authorized_bench_requires_approval_metadata(self) -> None:
        envelope = valid_envelope()
        envelope["safety_state"] = "authorized_bench"

        report = PORTFOLIO.validate_envelope(envelope)

        self.assertEqual(report["status"], "failed")
        self.assertIn("authorized_bench envelopes require approval metadata.", report["errors"])

    def test_cli_validates_envelope_file(self) -> None:
        with tempfile.TemporaryDirectory(prefix="skill-envelope-") as temporary_dir:
            path = Path(temporary_dir) / "envelope.json"
            path.write_text(json.dumps(valid_envelope()), encoding="utf-8")
            report = PORTFOLIO.validate_envelope(json.loads(path.read_text(encoding="utf-8")))

        self.assertEqual(report["status"], "passed")


if __name__ == "__main__":
    unittest.main()