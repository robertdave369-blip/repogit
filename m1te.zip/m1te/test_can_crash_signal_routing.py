"""Offline tests for project-configured crash CAN signal routing."""

from __future__ import annotations

import importlib
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "U171")

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT.parent))

from shared_libraries import core_functions


PROJECTS = (
    "M310_M314_M110",
    "U171",
    "UPP_EV",
    "W610",
    "Z121",
)


class _RecordingCan:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, str]] = []

    def GetSignalFromFrame(self, channel: str, frame: str, signal: str) -> str:
        self.calls.append((channel, frame, signal))
        return f"{channel}:{frame}:{signal}"


class CrashSignalRoutingTests(unittest.TestCase):
    def test_reads_primary_and_hscan_signals_from_configured_channels(self) -> None:
        fake_can = _RecordingCan()
        symbols = {
            "CAN_SIGNAL_Rx_MAP": {
                "DEMO": {"fd_status": ("FD_FRAME", "FD_SIGNAL")}
            },
            "CAN_CRASH_FRAME_CHANNEL_MAP": {
                "DEMO": {
                    "FD_FRAME": "configured_fd",
                    "HS_FRAME": "configured_hs",
                }
            },
            "CAN_HSCAN_SIGNAL_Rx_MAP": {
                "hs_status": ("HS_FRAME", "HS_SIGNAL")
            },
        }

        def get_required_symbol(module_name, symbol_name, *, project=None):
            self.assertEqual((module_name, symbol_name, project), ("project_config", "ACTIVE_CAN_VARIANT", "DEMO_PROJECT"))
            return "DEMO"

        def get_optional_symbol(symbol_name, _module_candidates, default=None, *, project=None):
            self.assertEqual(project, "DEMO_PROJECT")
            return symbols.get(symbol_name, default)

        with (
            patch.object(core_functions, "CAN", fake_can),
            patch.object(core_functions, "_detect_active_project", return_value="DEMO_PROJECT"),
            patch.object(core_functions, "_get_project_config_symbol", side_effect=get_required_symbol),
            patch.object(core_functions, "_get_optional_project_config_symbol", side_effect=get_optional_symbol),
        ):
            result = core_functions.CAN_Signal_Info_during_crash()

        self.assertEqual(
            fake_can.calls,
            [
                ("configured_fd", "FD_FRAME", "FD_SIGNAL"),
                ("configured_hs", "HS_FRAME", "HS_SIGNAL"),
            ],
        )
        self.assertEqual(result["fd_status"], "configured_fd:FD_FRAME:FD_SIGNAL")
        self.assertEqual(result["hs_status"], "configured_hs:HS_FRAME:HS_SIGNAL")

    def test_rejects_a_frame_without_a_configured_channel(self) -> None:
        symbols = {
            "CAN_SIGNAL_Rx_MAP": {"DEMO": {"status": ("UNKNOWN_FRAME", "STATUS")}},
            "CAN_CRASH_FRAME_CHANNEL_MAP": {"DEMO": {}},
            "CAN_HSCAN_SIGNAL_Rx_MAP": {},
        }

        def get_optional_symbol(symbol_name, _module_candidates, default=None, *, project=None):
            return symbols.get(symbol_name, default)

        with (
            patch.object(core_functions, "_detect_active_project", return_value="DEMO_PROJECT"),
            patch.object(core_functions, "_get_project_config_symbol", return_value="DEMO"),
            patch.object(core_functions, "_get_optional_project_config_symbol", side_effect=get_optional_symbol),
        ):
            with self.assertRaisesRegex(ValueError, "frame='UNKNOWN_FRAME'"):
                core_functions.CAN_Signal_Info_during_crash()

    def test_project_routes_cover_every_configured_crash_frame(self) -> None:
        for project in PROJECTS:
            with self.subTest(project=project):
                config = importlib.import_module(
                    f"Framework_IOEM_Py.projects.{project}.config.canc_config"
                )
                routes_by_variant = config.CAN_CRASH_FRAME_CHANNEL_MAP
                signal_maps = config.CAN_SIGNAL_Rx_MAP

                for variant, signal_map in signal_maps.items():
                    with self.subTest(project=project, variant=variant):
                        self.assertIn(variant, routes_by_variant)
                        routes = routes_by_variant[variant]
                        for frame, _signal in signal_map.values():
                            self.assertIsInstance(routes.get(frame), str)
                            self.assertTrue(routes[frame].strip())

                hscan_mapping = getattr(config, "CAN_HSCAN_SIGNAL_Rx_MAP", {})
                if hscan_mapping:
                    active_variant = importlib.import_module(
                        f"Framework_IOEM_Py.projects.{project}.config.project_config"
                    ).ACTIVE_CAN_VARIANT
                    routes = routes_by_variant[active_variant]
                    for frame, _signal in hscan_mapping.values():
                        self.assertIsInstance(routes.get(frame), str)
                        self.assertTrue(routes[frame].strip())


if __name__ == "__main__":
    unittest.main()