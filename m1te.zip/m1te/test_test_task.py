from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

sys.dont_write_bytecode = True
TOOLS_DIR = Path(__file__).resolve().parents[1] / "tools"
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import test_task as tt  # noqa: E402

FAILING_SCRIPT = '''import sys
from pathlib import Path
report = Path(sys.argv[0]).with_suffix(".html")
log = Path(sys.argv[0]).with_suffix(".txt")
report.write_text("<!--genv:1-->\\n<tr id=\\"n-1\\" class=\\"l1 -failed  step \\"><td>Read DTC 0x9A1234</td><td>expected 0B got 08</td></tr>\\n<!--FAILED-->")
log.write_text("RX_MSG ...")
print(f"[create_report_and_logging] project=P1, report={report}, log={log}, channel_names=None")
tc_id = "Squib loop open fault"
'''
CRASHING_SCRIPT = 'tc_id = "Power supply undervoltage"\nconfig = {}\nprint(config["UV_LEVEL"])\nset_trigger()\n'


class CampaignFlowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.repo = Path(tempfile.mkdtemp(prefix="tt-repo-"))
        scripts = self.repo / "projects" / "P1" / "modules" / "SQUIBS" / "scripts"
        scripts.mkdir(parents=True)
        (scripts / "Squib_Loop_Open_Fault.py").write_text(FAILING_SCRIPT, encoding="utf-8")
        (scripts / "Power_UV.py").write_text(CRASHING_SCRIPT, encoding="utf-8")
        (self.repo / "projects" / "P1" / "config").mkdir()
        (self.repo / "projects" / "P1" / "config" / "power_config.py").write_text("UV = 1\n", encoding="utf-8")
        subprocess.run(["git", "init", "-q"], cwd=self.repo, check=True)
        subprocess.run(["git", "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-q", "--allow-empty", "-m", "root"], cwd=self.repo, check=True)
        self.keep_awake = mock.patch.object(tt, "keep_awake").start()
        self.addCleanup(mock.patch.stopall)
        patches = [mock.patch.object(tt, "REPO", self.repo), mock.patch.object(tt, "CAMPAIGNS", self.repo / "test_campaigns"),
                   mock.patch.object(tt, "preflight", return_value=[]),
                   mock.patch.object(tt, "input_check", return_value={"checks": [], "problems": []}),
                   mock.patch.object(tt, "fault_check", return_value={"fault_free": True, "dtcs": [], "problems": []})]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self) -> None:
        shutil.rmtree(self.repo, ignore_errors=True)

    def test_full_flow(self) -> None:
        self.assertEqual(tt.main(["init", "--project", "P1", "--task", "TASK-42 squib faults", "--cb-tc", "1001,1002"]), 0)
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        index = {"1001": {"name": "Squib loop open fault", "tracker": "Test Cases", "related": ["900"], "status": "Accepted", "via": "requested"},
                 "1002": {"name": "Power supply undervoltage", "tracker": "Test Cases", "related": [], "status": "Accepted", "via": "requested"}}
        tt.save(camp / "inputs/cb/index.json", index)

        tt.main(["map", str(camp)])
        smap = tt.load(camp / "analysis/script_map.json")
        self.assertTrue(smap["1001"]["candidates"][0]["script"].endswith("Squib_Loop_Open_Fault.py"))
        self.assertFalse(smap["1001"]["confirmed"])                       # name overlap alone is not confirmed
        for tc, name in (("1001", "Squib_Loop_Open_Fault.py"), ("1002", "Power_UV.py")):
            tt.main(["map", str(camp), "--set", f"{tc}=projects/P1/modules/SQUIBS/scripts/{name}"])

        tt.main(["risk", str(camp)])
        self.assertIn("crash trigger / deployment", tt.load(camp / "analysis/risk.json")["1002"]["risks"])

        self.assertEqual(tt.main(["run", str(camp)]), 0)                   # plan only without --apply
        self.assertFalse((camp / "runs" / "1").exists())
        self.assertEqual(tt.main(["run", str(camp), "--apply", "--timeout", "60"]), 0)
        results = {r["tc"]: r for r in tt.load(camp / "runs/1/results.json")}
        self.assertEqual((results["1001"]["status"], results["1002"]["status"]), ("FAILED", "ERROR"))

        tt.main(["collect", str(camp)])
        names = sorted(p.name for p in (camp / "package").iterdir())
        self.assertIn("Squib_loop_open_fault.html", names)                 # named after the test case, not the script
        self.assertIn("Squib_loop_open_fault.txt", names)
        self.assertIn("Power_supply_undervoltage.console.txt", names)

        tt.main(["triage-scan", str(camp)])
        hints = {t["tc"]: t for t in tt.load(camp / "triage/attempt1.json")}
        self.assertEqual(hints["1002"]["hint"], "SCRIPT")
        self.assertIn("KeyError", " ".join(hints["1002"]["exceptions"]))
        self.assertTrue(hints["1001"]["hint"].startswith("NEEDS_ANALYSIS"))
        self.assertIn("expected 0B got 08", " ".join(hints["1001"]["failed_steps"]))

        tt.save(camp / "decisions.json", [{"tc": "1001", "category": "ECU_DEFECT", "confidence": "Medium", "summary": "DTC status 08"},
                                          {"tc": "1002", "category": "SCRIPT", "confidence": "High", "summary": "UV_LEVEL missing"}])
        self.assertEqual(tt.main(["bugs", str(camp)]), 0)
        tt.save(camp / "decisions.json", [{"tc": "1001", "category": "MAYBE", "confidence": "High"}])
        with self.assertRaises(SystemExit):
            tt.main(["bugs", str(camp)])

        script = "projects/P1/modules/SQUIBS/scripts/Power_UV.py"
        self.assertEqual(tt.main(["backup-script", str(camp), script, "--reason", "UV level from config"]), 0)
        self.assertEqual(tt.main(["backup-script", str(camp), script, "--reason", "UV level from config", "--apply"]), 0)
        log = subprocess.run(["git", "log", "--oneline", "--", script], cwd=self.repo, capture_output=True, text=True).stdout
        self.assertIn("before correction", log)
        self.assertEqual(len(list((self.repo / "projects/P1/modules/SQUIBS/scripts").glob("Power_UV.py.bak-*"))), 1)
        with self.assertRaises(SystemExit):                                # config is not a test script
            tt.main(["backup-script", str(camp), "projects/P1/config/power_config.py", "--reason", "x", "--apply"])
        tt.save(self.repo / "projects/P1/modules/SQUIBS/scripts/generated_script_list.json", ["Squib_Loop_Open_Fault.py"])
        squib = "projects/P1/modules/SQUIBS/scripts/Squib_Loop_Open_Fault.py"
        with self.assertRaises(SystemExit):                                # generator-owned: fix the generator
            tt.main(["backup-script", str(camp), squib, "--reason", "x", "--apply"])
        self.assertEqual(tt.main(["backup-script", str(camp), squib, "--reason", "x", "--generated-ok"]), 0)

        with self.assertRaises(SystemExit):                                # no name/dest from the user
            tt.main(["zip", str(camp)])
        self.assertEqual(tt.main(["zip", str(camp), "--name", "P1_TASK-42_logs", "--dest", str(self.repo / "out")]), 0)
        with zipfile.ZipFile(self.repo / "out" / "P1_TASK-42_logs.zip") as z:
            self.assertIn("Squib_loop_open_fault.html", z.namelist())
        with self.assertRaises(SystemExit):                                # PTC target incomplete
            tt.main(["ptc-request", str(camp), "--source-root", str(self.repo / "stage")])


class ExcelReviewLoopTests(CampaignFlowTests):
    def test_full_flow(self) -> None:  # covered above; this class only adds the workbook loop
        pass

    def test_workbook_edit_shows_up_in_diff_only(self) -> None:
        import openpyxl
        tt.main(["init", "--project", "P1", "--task", "T-7"])
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        item = {"name": "Squib loop open fault", "status": {"name": "Accepted"}, "tracker": {"id": 55, "name": "Test Cases"},
                "description": "Open loop 1", "customFields": [{"name": "Pre-Action", "value": "BATT ON"},
                                                               {"name": "Test Steps", "values": [["Open LOOP1", "DTC active 0B"]]}]}
        tt.save(camp / "inputs/cb/1001.json", {"item": item, "relations": {}})
        tt.save(camp / "inputs/cb/index.json", {"1001": {"name": item["name"], "tracker": "Test Cases", "related": [], "via": "requested", "status": "Accepted"}})
        self.assertEqual(tt.main(["tc-workbook", str(camp)]), 0)
        book = next((camp / "testcases").glob("*_testcases.xlsx"))
        wb = openpyxl.load_workbook(book)
        ws = wb["TestCases"]
        head = [c.value for c in ws[1]]
        self.assertEqual(ws.cell(2, head.index("Test Steps") + 1).value, "Open LOOP1 | DTC active 0B")
        ws.cell(2, head.index("Test Steps") + 1).value = "Open LOOP1 | DTC active 0B within 1 s"
        ws.cell(2, head.index("Review notes") + 1).value = "timing from requirement 900"
        wb.save(book)
        tt.main(["tc-diff", str(camp)])
        changes = tt.load(camp / "testcases/changes.json")
        self.assertEqual(list(changes["1001"]["fields"]), ["Test Steps"])  # notes are not a Codebeamer change
        self.assertIn("within 1 s", (camp / "testcases/changes.md").read_text(encoding="utf-8"))

    def test_manager_test_case_without_codebeamer_item(self) -> None:
        import openpyxl
        tt.main(["init", "--project", "P1", "--task", "T-8", "--task-source", "manager"])
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        tt.main(["add-tc", str(camp), "--id", "M1", "--name", "Power supply undervoltage", "--requirements", "900"])
        self.assertEqual(tt.main(["tc-workbook", str(camp)]), 0)
        ws = openpyxl.load_workbook(next((camp / "testcases").glob("*_testcases.xlsx")))["TestCases"]
        self.assertEqual((ws.cell(2, 1).value, ws.cell(2, 2).value), ("M1", "Power supply undervoltage"))
        tt.main(["map", str(camp)])
        self.assertTrue(tt.load(camp / "analysis/script_map.json")["M1"]["candidates"][0]["script"].endswith("Power_UV.py"))


class PlanAndIntakeTests(CampaignFlowTests):
    def test_full_flow(self) -> None:
        pass

    def test_intake_gaps_notes_and_g2_plan(self) -> None:
        note = self.repo / "mgr.txt"
        note.write_text("Run F010 test cases 1 and 2 today.", encoding="utf-8")
        cfg = self.repo / "AriaMain.json"
        cfg.write_text("{}", encoding="utf-8")
        tt.main(["init", "--project", "P1", "--task", "T-9", "--task-source", "manager",
                 "--manager-file", str(note), "--aria-config", str(cfg)])
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        self.assertEqual((camp / "inputs/manager_task.md").read_text(encoding="utf-8"), "Run F010 test cases 1 and 2 today.")
        self.assertEqual(tt.load(camp / "manifest.json")["gaps"], ["no OEM L10 spec", "no ECU source review"])
        tt.main(["note", str(camp), "--text", "manager numbering unclear", "--gap"])
        self.assertIn("manager numbering unclear", (camp / "issues.md").read_text(encoding="utf-8"))
        tt.main(["add-tc", str(camp), "--id", "M1", "--name", "Squib loop open fault"])
        tt.main(["map", str(camp), "--set", "M1=projects/P1/modules/SQUIBS/scripts/Squib_Loop_Open_Fault.py"])
        status = {"selected_install": {"dir": "C:\\ARIA5.20", "version": "5.20.0.7"}, "aria_processes": [],
                  "active_instances": [{"pid": 1, "alive": False}, {"pid": 2, "alive": False}],
                  "active_configuration": {"path": str(self.repo / "Other.json"), "use_chassis": True}, "network_unblocked": []}
        checks = {"checks": [{"check": "project", "status": "problem", "detail": "ARIA's active project is Other.json; expected AriaMain.json"}],
                  "problems": ["project: ARIA's active project is Other.json; expected AriaMain.json"]}
        with mock.patch.object(tt, "bench_status", return_value=status), mock.patch.object(tt, "input_check", return_value=checks):
            tt.main(["plan", str(camp)])
        plan = (camp / "analysis/g2_plan.md").read_text(encoding="utf-8")
        for expected in ("Squib_Loop_Open_Fault.py", "ARIA is not running", "2 ActiveInstances files", "expected AriaMain.json",
                         "Fault-free check", "manager numbering unclear"):
            self.assertIn(expected, plan)

    def test_run_stops_on_bench_check_problems_unless_the_user_accepts_them(self) -> None:
        dbc = self.repo / "P1.dbc"
        dbc.write_text("BO_ 1 F: 8 ECU\n", encoding="utf-8")
        with self.assertRaises(SystemExit):                                  # a named file must exist
            tt.main(["init", "--project", "P1", "--task", "T-10", "--dbc", str(self.repo / "missing.dbc")])
        tt.main(["init", "--project", "P1", "--task", "T-10", "--dbc", str(dbc)])
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        self.assertEqual(tt.load(camp / "manifest.json")["bench_inputs"]["dbc"], [str(dbc.resolve())])
        dtc = {"fault_free": False, "dtcs": [{"dtc": "0x9A1234", "status": "0x0B", "active": True}],
               "problems": ["bench not fault free: 0x9A1234 status 0x0B (active)"]}
        with mock.patch.object(tt, "fault_check", return_value=dtc):
            self.assertEqual(tt.main(["run", str(camp), "--apply"]), 2)
            self.assertFalse((camp / "runs" / "1").exists())                # nothing ran
            self.assertEqual(tt.main(["run", str(camp), "--apply", "--accept-bench", "user: 9A1234 is known, go on"]), 0)
        self.assertEqual(tt.load(camp / "runs/1/bench_check.json")["accepted_by_user"], "user: 9A1234 is known, go on")
        self.assertEqual(tt.load(camp / "manifest.json")["attempts"][0]["bench_problems_accepted"]["problems"], dtc["problems"])

    def test_aria_ctl_answer_is_the_last_json_object(self) -> None:
        for stdout in ('noise from the framework\n{"fault_free": true}\n', '{\n  "checks": [],\n  "problems": []\n}\n'):
            with mock.patch.object(tt.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, stdout, "")):
                self.assertIn(tt.aria_ctl({}, "x"), ({"fault_free": True}, {"checks": [], "problems": []}))
        with mock.patch.object(tt.subprocess, "run", return_value=subprocess.CompletedProcess([], 1, "Traceback", "boom")):
            self.assertIn("error", tt.aria_ctl({}, "read-dtc"))

    def test_number_aware_names_and_risk_patterns(self) -> None:
        name = tt.tokens("F010 ACTIVATE CRASH test case 1")
        one, two = tt.tokens("F010_IOControl_Testcase1"), tt.tokens("F010_IOControl_Testcase2")
        self.assertGreater(len(name & one), len(name & two))
        line = "Internal_Security_Access(0x01); Clear_DTC_Info(); CAN.SendDiag(IOC_REQ_2F_F0_10_03_01)"
        hits = {k for k, rx in tt.RISKS.items() if __import__("re").search(rx, line)}
        self.assertTrue({"security access", "dtc memory cleared", "io-control override (outputs forced)"} <= hits)


class ReviewPipelineTests(CampaignFlowTests):
    def test_full_flow(self) -> None:
        pass

    def test_review_task_holds_keep_awake_and_renders_validated_findings(self) -> None:
        import openpyxl
        tt.main(["init", "--project", "NEW_OEM_X", "--task", "SRS review", "--pipeline", "req-review"])  # no bench project needed
        camp = next((self.repo / "test_campaigns" / "NEW_OEM_X").iterdir())
        self.assertEqual(tt.load(camp / "manifest.json")["pipeline"], "req-review")
        self.keep_awake.assert_called_with("start", camp, 12)
        finding = {"id": "900101", "requirement": "LOOP1 open DTC", "source_reference": "L10 SRS 4.2.1", "category": "CORRECTNESS",
                   "severity": "High", "finding": "500 ms in CB, 300 ms in L10", "written": "within 500 ms", "source_says": "within 300 ms",
                   "proposed_wording": "within 300 ms", "confidence": "High", "evidence": ["L10 p.42"], "status": "to review"}
        tt.save(camp / "analysis/findings_requirement-review.json", [dict(finding, severity="Low", id="2"), finding])
        self.assertEqual(tt.main(["findings", str(camp), "--kind", "requirement-review"]), 0)
        ws = openpyxl.load_workbook(next((camp / "review").glob("*.xlsx")))["Findings"]
        self.assertEqual((ws.cell(2, 1).value, ws.cell(2, 5).value), ("900101", "High"))      # sorted by severity
        tt.save(camp / "analysis/findings_requirement-review.json", [dict(finding, category="OPINION")])
        with self.assertRaises(SystemExit):
            tt.main(["findings", str(camp), "--kind", "requirement-review"])
        tt.main(["finish", str(camp)])
        self.keep_awake.assert_called_with("stop", camp)
        self.assertIn("finished", tt.load(camp / "manifest.json"))

    def test_test_case_review_sheet_and_verifies_column_from_codebeamer(self) -> None:
        import openpyxl
        tt.main(["init", "--project", "P1", "--task", "CANC spec review", "--pipeline", "tc-review"])
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        item = {"name": "Squib LOOP1 open", "customFields": [{"name": "Verifies", "values": [{"id": 900101, "name": "LOOP1 open DTC"}]},
                                                              {"name": "Priority", "values": [{"id": 3, "name": "High"}]}]}
        tt.save(camp / "inputs/cb/1001.json", {"item": item, "relations": {}})
        tt.save(camp / "inputs/cb/index.json", {"1001": {"name": "Squib LOOP1 open", "tracker": "Test Cases", "related": []}})
        tt.main(["tc-workbook", str(camp)])
        ws = openpyxl.load_workbook(next((camp / "testcases").glob("*_testcases.xlsx")))["TestCases"]
        row = dict(zip([c.value for c in ws[1]], [c.value for c in ws[2]]))
        self.assertEqual((row["Verifies"], row["Priority"]), ("[ISSUE:900101] - null", "High"))  # traceable; other fields by name
        finding = {"test_case": "Squib LOOP1 open", "row": 2, "requirement": "900101", "category": "EXPECTED_RESULT", "severity": "High",
                   "finding": "status 0x08 expected, a CAN-type active fault reports 0x0B", "evidence": ["agent_sc3 §16.3"],
                   "impact": "a correct ECU fails", "current": "DTC status 0x08", "proposed": "DTC status 0x0B",
                   "additional_tests": "", "confidence": "High", "status": "to review"}
        tt.save(camp / "analysis/findings_tc-review.json", [finding, dict(finding, category="COVERAGE_GAP", severity="Medium")])
        self.assertEqual(tt.main(["findings", str(camp), "--kind", "tc-review"]), 0)
        sheet = openpyxl.load_workbook(next((camp / "review").glob("*_tc-review.xlsx")))["Findings"]
        self.assertEqual([c.value for c in sheet[1]][:4], ["Test case", "Row", "Requirement", "Category"])
        tt.save(camp / "analysis/findings_tc-review.json", [dict(finding, category="CORRECTNESS")])   # a requirement-review category
        with self.assertRaises(SystemExit):
            tt.main(["findings", str(camp), "--kind", "tc-review"])

    def test_tracker_fetch_requests_every_item(self) -> None:
        tt.main(["init", "--project", "P1", "--task", "T-10", "--pipeline", "req-review"])
        camp = next((self.repo / "test_campaigns" / "P1").iterdir())
        calls = []

        def fake_cb(*args):
            calls.append(args)
            if args[0] == "list-item-details":
                return [{"id": 11}, {"id": 12}]
            if args[0] == "get-item":
                return {"id": int(args[2]), "name": f"Req {args[2]}", "status": {"name": "Approved"}, "tracker": {"id": 5, "name": "SRS"}}
            return {}
        with mock.patch.object(tt, "cb", side_effect=fake_cb):
            tt.main(["cb-fetch", str(camp), "--tracker", "5", "--status", "Approved"])
        self.assertEqual(calls[0], ("list-item-details", "--tracker-id", "5", "--status", "Approved"))
        self.assertEqual(sorted(tt.load(camp / "inputs/cb/index.json")), ["11", "12"])


class AutoInstallTests(unittest.TestCase):
    def test_missing_module_installs_requirements_once_then_retries(self) -> None:
        missing = subprocess.CompletedProcess([], 1, "", "ModuleNotFoundError: No module named 'dotenv'")
        ok = subprocess.CompletedProcess([], 0, '{"id": 5}', "")
        with mock.patch.object(tt.subprocess, "run", side_effect=[missing, ok]) as run, \
             mock.patch.object(tt, "pip_install") as pip:
            self.assertEqual(tt.cb("get-item", "--item-id", "5"), {"id": 5})
        pip.assert_called_once_with("-r", str(tt.CB_REQUIREMENTS))
        self.assertEqual(run.call_count, 2)

    def test_other_failures_are_not_retried(self) -> None:
        denied = subprocess.CompletedProcess([], 1, "", "401 Unauthorized")
        with mock.patch.object(tt.subprocess, "run", return_value=denied), mock.patch.object(tt, "pip_install") as pip:
            with self.assertRaises(SystemExit):
                tt.cb("get-item", "--item-id", "5")
        pip.assert_not_called()


class RelationParsingTests(unittest.TestCase):
    def test_related_ids_walks_any_reference_shape(self) -> None:
        rel = {"downstreamReferences": [{"itemRevision": {"id": 7, "version": 2}, "type": "DownstreamTrackerItemReference"}],
               "outgoingAssociations": [{"target": {"id": 8}}], "self": {"item": {"id": 5}}}
        self.assertEqual(tt.related_ids(rel, "5"), ["7", "8"])


if __name__ == "__main__":
    unittest.main()
