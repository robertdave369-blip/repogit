"""Create the standalone V1 EDR authoring workbook.

The workbook is built from the approved local authoring layout, but all visible
test content is intentionally self-contained. No requirement workbook, sheet,
or external file reference is written into the specification.

Generation is offline only. This module never connects to an ECU, ARIA, a CAN
interface, power equipment, diagnostic hardware, or any other bench resource.
"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import copy
from datetime import date
import json
from pathlib import Path
import re
from shutil import copy2
import sys
from typing import Any
from zipfile import ZipFile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from test_ice_common_edr_test_spec_design import inspect_source


ROOT = Path(__file__).resolve().parents[1]
REFERENCE_LAYOUT = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "Common_EDR_CANC_0455_045B_U171_M314_v7_authoring.xlsx"
)
VERSION_ROOT = (
    ROOT
    / "project_testcases"
    / "ice_common_spec"
    / "EDR"
    / "ICE_COMMON_SRS_V1_4_EDR_Test_Spec_Design"
    / "03_Authoring_Versions"
)
VERSION_DIRECTORY = VERSION_ROOT / "V1_Initial_Review"
OUTPUT_WORKBOOK = VERSION_DIRECTORY / "EDR_Minimum_Coverage_Authoring_v1.xlsx"
OUTPUT_REPORT = VERSION_DIRECTORY / "EDR_Minimum_Coverage_Authoring_v1_validation.json"

AUTHORING_HEADERS = [
    "ID",
    "Priority",
    "Name",
    "Applicability",
    "Description",
    "Pre-Action",
    "Post-Action",
    "Test Steps.Action",
    "Test Steps.Expected result",
    "Test Steps.Critical",
    "Test Steps.Id",
    "Test Parameters",
    "Verifies",
    "Status",
    "Type",
    "_Project",
    "Reviewer(s)",
    "_LatestResult",
    "_Original_Id",
    "Referenced Reviews",
    "_ScriptPath",
    "_TestType",
    "_VerificationMethod",
    "_TestTechnique",
]

HIGHLIGHT_YELLOW = "FFF200"
PALE_YELLOW = "FFF9D9"
PALE_BLUE = "D9EAF7"
PALE_GREEN = "E2F0D9"
PALE_AMBER = "FFF2CC"
NAVY = "1F4E78"
WHITE = "FFFFFF"
THIN_GRAY = Side(style="thin", color="B7B7B7")
PENDING = "Pending confirmation. Record the observed behavior and do not set pass or fail."


def make_case(
    case_id: str,
    name: str,
    description: str,
    applicability: str,
    priority: str,
    status: str,
    pre_action: str,
    post_action: str,
    setup_action: str,
    trigger_action: str,
    verify_action: str,
    expected_result: str,
    method: str,
    technique: str,
    note: str,
) -> dict[str, str]:
    return {
        "id": case_id,
        "name": name,
        "description": description,
        "applicability": applicability,
        "priority": priority,
        "status": status,
        "pre_action": pre_action,
        "post_action": post_action,
        "setup_action": setup_action,
        "trigger_action": trigger_action,
        "verify_action": verify_action,
        "expected_result": expected_result,
        "method": method,
        "technique": technique,
        "note": note,
    }


def build_cases() -> list[dict[str, str]]:
    normal_pre_action = "Set the bench to normal condition and confirm that the EDR function is ready for the selected test vector."
    normal_post_action = "Restore the bench to normal condition and retain the test evidence. Do not clear a locked record without separate approval."
    return [
        make_case(
            "V1-001",
            "SUBS_EDR_DefaultData_NoEvent_TestCase_001",
            "Verify that EDR data are initialized when no event has been recorded.",
            "Both",
            "High",
            "IN REVIEW",
            normal_pre_action,
            normal_post_action,
            "Select the no-event vector and confirm that no EDR event is stored.",
            "Read each implemented EDR data record three times without creating an event.",
            "Compare every returned data byte, including reserved bytes, across the three reads.",
            "All returned EDR data bytes, including reserved bytes, are FF. All three reads are identical.",
            "Requirements-based test",
            "Equivalence Classes",
            "Diagnostic request details are confirmed before execution; the expected data content is defined here.",
        ),
        make_case(
            "V1-002",
            "SUBS_EDR_SideEvent_WithoutSRSU_TestCase_002",
            "Verify that Domestic Low and Mid configurations without side remote sensors do not store a side event.",
            "Both",
            "High",
            "IN REVIEW",
            normal_pre_action,
            normal_post_action,
            "Select the Low or Mid without-side-sensor vector and confirm the selected configuration.",
            "Apply the approved non-destructive side-event input for the selected configuration.",
            "Read the EDR data after the required observation interval.",
            "No side-event data record is stored for the selected Low or Mid configuration without side remote sensors.",
            "Requirements-based test",
            "Equivalence Classes",
            "This case covers both Low and Mid vectors because their required EDR behavior is identical.",
        ),
        make_case(
            "V1-003",
            "SUBS_EDR_NearCrash_Unlocked_TestCase_003",
            "Verify near-crash recording, unlocked record status, and suppression of crash and door-unlock notifications.",
            "Both",
            "Highest",
            "IN REVIEW",
            "Set the bench to normal condition. Start synchronized EDR and CAN evidence capture before the near-crash input.",
            normal_post_action,
            "Select the near-crash vector and confirm that the input is below the deployable threshold.",
            "Apply the approved non-deployment near-crash input.",
            "Read the EDR record and review the captured CAN traffic for crash and door-unlock notifications.",
            "A near-crash record is stored. Its lock status is 0. Crash status and door-unlock notifications are not transmitted.",
            "Requirements-based test",
            "Equivalence Classes",
            "Record location and diagnostic access details are confirmed before execution.",
        ),
        make_case(
            "V1-004",
            "SUBS_EDR_UnconfirmedCrash_TestCase_004",
            "Verify unconfirmed-crash classification when the onboard longitudinal input is present and both front remote sensor values are zero.",
            "Both",
            "High",
            "IN REVIEW",
            normal_pre_action,
            normal_post_action,
            "Select the unconfirmed-crash vector. Set valid onboard longitudinal input and set both front remote sensor values to zero.",
            "Run the event-classification evaluation.",
            "Capture the available event-classification result and retain the input evidence around the decision point.",
            "The event is classified as Unconfirmed Crash. Record, lock, notification, and delayed-confirmation behavior are pending confirmation.",
            "Requirements-based test",
            "Equivalence Classes",
            "This test verifies the stated classification rule only.",
        ),
        make_case(
            "V1-005",
            "SUBS_EDR_CompletionStatus_TestCase_005",
            "Verify completion timing and data-validity states for normal power and battery-cutoff event handling.",
            "Both",
            "Highest",
            "IN REVIEW",
            "Set the bench to normal condition. Prepare a synchronized T0 timebase and the approved event/power condition for the selected vector.",
            normal_post_action,
            "Select one completion vector: timing observation, incomplete data, data valid through 200 ms, or complete data.",
            "Apply the selected event and power condition while recording T0 and the completion-status observations.",
            "Read the completion flags and EDR data at the defined observation points.",
            "After 200 ms, the 200 ms completion flag becomes 1. After five seconds with battery available, CompletionStatus becomes 1. For status 0/0, data are not valid; for 0/1, data are valid through 200 ms; for 1/don't care, data are valid.",
            "Requirements-based test",
            "Boundary Value Analysis",
            "Exact equality at the timing boundaries, timing tolerance, durable-write criteria, and power profiles are pending confirmation.",
        ),
        make_case(
            "V1-006",
            "SUBS_EDR_ThreeEventSequence_TestCase_006",
            "Verify all defined three-event Near Crash and Deployment Event sequences for single-event and multi-event timing classes.",
            "Both",
            "Highest",
            "IN REVIEW",
            "Set the bench to normal condition. Establish the approved clean EDR baseline and select a three-event vector.",
            normal_post_action,
            "Select one of the sixteen three-event vectors. Record Event 1, Event 2, Event 3, and the selected timing class.",
            "Apply the three events in the selected order and timing class.",
            "Read EDR1 and EDR2 after Event 2 and after Event 3. Decode retained event data, MultiEventNumber, TimeBetweenEvents, LifetimeEventNumber, and RecordLockStatus.",
            "The EDR1/EDR2 records and all listed fields match the selected vector exactly.",
            "Requirements-based test",
            "Equivalence Classes",
            "The sixteen vectors retain all binary Near Crash/Deployment permutations while avoiding duplicate authoring cases.",
        ),
        make_case(
            "V1-007",
            "SUBS_EDR_InterEventBoundary_TestCase_007",
            "Characterize inter-event behavior at every required timing boundary.",
            "Both",
            "Highest",
            "ON HOLD",
            "Set the bench to normal condition. Do not assign pass or fail until the timing reference, equality behavior, scheduler tick, and tolerance are confirmed.",
            normal_post_action,
            "Select one timing-boundary vector and prepare an approved timing measurement method.",
            "Apply the selected two-event sequence at the exact boundary separation.",
            "Read EDR allocation, event counters, timing data, and lock status. Record observed behavior.",
            PENDING,
            "Requirements-based test",
            "Boundary Value Analysis",
            "The vectors cover 0 ms, 1 ms, 299 ms, 300 ms, 301 ms, 499 ms, 500 ms, 501 ms, 4.999 s, 5.000 s, and 5.001 s.",
        ),
        make_case(
            "V1-008",
            "SUBS_EDR_FourthFifthEventStorage_TestCase_008",
            "Characterize storage selection and protection when a fourth or fifth event arrives with occupied EDR records.",
            "Both",
            "Highest",
            "ON HOLD",
            "Set the bench to normal condition. Do not assign pass or fail until record replacement, locked-record, counter, and recovery behavior are confirmed.",
            normal_post_action,
            "Select one occupied-record vector and establish the required record age, lock, completion, and validity state.",
            "Apply the selected fourth or fifth Near Crash or Deployment Event.",
            "Read EDR1, EDR2, and related diagnostic data repeatedly. If permitted, repeat after an approved recovery cycle.",
            PENDING,
            "Requirements-based test",
            "Equivalence Classes",
            "Alternative behaviors are held separately: replace oldest unlocked, replace newest unlocked, replace lowest-priority unlocked, reject, or store overflow information only.",
        ),
        make_case(
            "V1-009",
            "SUBS_EDR_PowerInterruptionRecovery_TestCase_009",
            "Verify EDR integrity and recovery for every required power-interruption phase and power condition.",
            "Both",
            "Highest",
            "ON HOLD",
            "Set the bench to normal condition. Use only an approved power-control and event-trigger procedure. Do not perform a persistent or destructive action without separate authorization.",
            "Restore nominal power, wait for approved initialization, retain all evidence, and do not clear locked data without separate approval.",
            "Select one power-interruption vector. Record the event state, interruption phase, power mode, T0, and power waveform.",
            "Apply the selected interruption only through the approved procedure, then restore nominal power.",
            "Read EDR data three times, perform an approved recovery cycle when permitted, reread, and check whether the next valid event can be recorded.",
            PENDING,
            "Fault Injection test",
            "Fault Injection",
            "Every named interruption phase and every named power mode is included at least once. Data atomicity, write ordering, and recovery criteria are pending confirmation.",
        ),
        make_case(
            "V1-010",
            "SUBS_EDR_CANWakeupDataQuality_TestCase_010",
            "Verify CAN wake-up and recorded-data quality for nominal, timing, validity, integrity, and recovery conditions.",
            "Both",
            "High",
            "ON HOLD",
            "Set the bench to normal condition. Confirm the exact signal, message, valid-value range, timing, and expected recorded representation before execution.",
            normal_post_action,
            "Select one CAN data-quality or wake-up vector and prepare synchronized CAN and EDR capture.",
            "Apply the selected CAN condition around the selected EDR event.",
            "Read and decode EDR data. Compare signal value, data age, validity, and cross-signal behavior.",
            PENDING,
            "Fault Injection test",
            "Fault Injection",
            "The vectors cover wake-up, missing/delayed/jittered frames, duplicate/out-of-order frames, integrity faults, on-fail behavior, sample edges, cross-signal checks, bus-off, representation, and CAN-supply loss.",
        ),
        make_case(
            "V1-011",
            "SUBS_EDR_DiagnosticReadConsistency_TestCase_011",
            "Verify diagnostic read consistency and data integrity during capture, write, reset, repeated read, invalid request, and record association conditions.",
            "Both",
            "High",
            "ON HOLD",
            "Set the bench to normal condition. Confirm the diagnostic request, access conditions, response format, and expected negative responses before execution.",
            normal_post_action,
            "Select one diagnostic-read vector and establish the required EDR capture, write, reset, or concurrent-read state.",
            "Send the selected diagnostic request sequence and capture raw request/response timing.",
            "Compare repeated responses, record association, stale-data absence, access behavior, and negative-response behavior.",
            PENDING,
            "Fault Injection test",
            "Fault Injection",
            "No diagnostic request byte, response byte, or negative-response code is assumed in this specification.",
        ),
        make_case(
            "V1-012",
            "SUBS_EDR_VariantApplicability_TestCase_012",
            "Characterize High configuration, configuration change, invalid configuration, and front/side event applicability without duplicating the Low/Mid side-event tests.",
            "Both",
            "High",
            "ON HOLD",
            "Set the bench to normal condition. Confirm the selected configuration and safe configuration-control method before execution.",
            "Restore the approved configuration only through an authorized procedure and retain the configuration evidence.",
            "Select one configuration/applicability vector.",
            "Establish the selected configuration by the approved method, then apply the selected front or side event.",
            "Read EDR data and capture related outputs without judging any behavior that has not been confirmed.",
            PENDING,
            "Requirements-based test",
            "Equivalence Classes",
            "The separate Low and Mid without-side-sensor vectors are already covered by V1-002.",
        ),
        make_case(
            "V1-013",
            "SUBS_EDR_ConcurrentEventMode_TestCase_013",
            "Characterize races between EDR events and active capture, writing, diagnostic, startup, shutdown, wake-up, and reset conditions.",
            "Both",
            "High",
            "ON HOLD",
            "Set the bench to normal condition. Do not assign pass or fail until state transitions, concurrency handling, wake-up, and reset behavior are confirmed.",
            normal_post_action,
            "Select one concurrent-event or operating-mode vector and record the initial state and timing reference.",
            "Apply the second event or mode transition at the selected concurrency point.",
            "Capture EDR allocation, completion flags, CAN outputs, reset state, and diagnostic observations.",
            PENDING,
            "Fault Injection test",
            "Fault Injection",
            "The vectors cover overlap with the first 200 ms, five-second collection, writing, diagnostic read, startup/shutdown, CAN wake-up, crash wake-up, and watchdog reset.",
        ),
        make_case(
            "V1-014",
            "SUBS_EDR_RobustnessEndurance_TestCase_014",
            "Cover event count, counter limits, sequence variation, and long-duration endurance using one controlled robustness procedure.",
            "Both",
            "High",
            "ON HOLD",
            "Set the bench to normal condition. Approve the campaign limit, event budget, evidence retention, and non-destructive safeguards before execution.",
            "Stop at the approved campaign limit, retain the generated vector and evidence, and restore the approved safe condition.",
            "Select one event-count, counter-limit, or endurance vector. Record the input sequence and any reproducibility seed.",
            "Apply the selected sequence while retaining event order, timing, CAN state, power/reset state, and diagnostic observations.",
            "For every unexpected result, reduce the sequence to the smallest reproducible prefix and retain the full evidence set.",
            PENDING,
            "Fault Injection test",
            "Fault Injection",
            "This combines event counts 0, 1, 2, 3, 4, 5, 10, and N with counter limits and endurance. It prevents three overlapping campaign cases.",
        ),
    ]


def event_label(value: str) -> str:
    return "Near Crash" if value.startswith("0") else "Deployment Event"


def vector(
    case_id: str,
    vector_id: str,
    scenario: str,
    condition: str,
    expected: str,
    status: str,
    note: str,
) -> dict[str, str]:
    return {
        "case_id": case_id,
        "vector_id": vector_id,
        "scenario": scenario,
        "condition": condition,
        "expected": expected,
        "status": status,
        "note": note,
    }


def three_event_expected(data: dict[str, Any]) -> str:
    return (
        f"After Event 2: EDR1={data['after_2_edr1']}; EDR2={data['after_2_edr2']}; "
        f"MultiEventNumber={data['after_2_multi_1']}/{data['after_2_multi_2']}; "
        f"TimeBetweenEvents={data['after_2_time_1']}/{data['after_2_time_2']}; "
        f"LifetimeEventNumber={data['after_2_lifetime_1']}/{data['after_2_lifetime_2']}. "
        f"After Event 3: EDR1={data['after_3_edr1']}; EDR2={data['after_3_edr2']}; "
        f"MultiEventNumber={data['after_3_multi_1']}/{data['after_3_multi_2']}; "
        f"TimeBetweenEvents={data['after_3_time_1']}/{data['after_3_time_2']}; "
        f"LifetimeEventNumber={data['after_3_lifetime_1']}/{data['after_3_lifetime_2']}; "
        f"RecordLockStatus={data['after_3_lock_1']}/{data['after_3_lock_2']}."
    )


def build_vectors(source_data: dict[str, Any]) -> list[dict[str, str]]:
    vectors = [
        vector("V1-001", "V1-001-01", "No EDR event", "No EDR event is stored. Read EDR data three times.", "All returned EDR data bytes, including reserved bytes, are FF. All three reads are identical.", "IN REVIEW", "Confirm diagnostic access details before execution."),
        vector("V1-002", "V1-002-01", "Domestic Low without side remote sensors", "Apply a side-event input with the selected Domestic Low configuration.", "No side-event data record is stored.", "IN REVIEW", "Do not judge unrelated functions in this vector."),
        vector("V1-002", "V1-002-02", "Domestic Mid without side remote sensors", "Apply a side-event input with the selected Domestic Mid configuration.", "No side-event data record is stored.", "IN REVIEW", "Do not judge unrelated functions in this vector."),
        vector("V1-003", "V1-003-01", "Near Crash", "Apply one non-deployment near-crash input and capture EDR and CAN outputs.", "A near-crash record is stored with lock status 0. Crash status and door-unlock notifications are not transmitted.", "IN REVIEW", "Record location and diagnostic access details are confirmed before execution."),
        vector("V1-004", "V1-004-01", "Unconfirmed Crash", "Onboard longitudinal input is present. Both front remote sensor values are zero.", "The event is classified as Unconfirmed Crash. All downstream behavior is pending confirmation.", "IN REVIEW", "Only the classification rule is verified."),
        vector("V1-005", "V1-005-01", "Completion timing", "One EDR event with battery available. Observe at 199 ms, 200 ms, 201 ms, 4.999 s, 5.000 s, and 5.001 s after T0.", "The 200 ms completion flag becomes 1 after 200 ms. CompletionStatus becomes 1 after five seconds with battery available. Exact boundary behavior is pending confirmation.", "IN REVIEW", "Record timestamp uncertainty and do not make an equality pass/fail decision before confirmation."),
        vector("V1-005", "V1-005-02", "Completion state 0 / 0", "Apply an approved battery-cutoff event condition that produces CompletionStatus=0 and 200 ms completion flag=0.", "EDR data are not valid.", "IN REVIEW", "The exact power profile and durable-write check are pending confirmation."),
        vector("V1-005", "V1-005-03", "Completion state 0 / 1", "Apply an approved battery-cutoff event condition that produces CompletionStatus=0 and 200 ms completion flag=1.", "EDR data are valid through 200 ms.", "IN REVIEW", "The exact 200 ms data content and durable-write check are pending confirmation."),
        vector("V1-005", "V1-005-04", "Completion state 1 / don't care", "Apply an approved no-battery-cutoff event condition that produces CompletionStatus=1.", "EDR data are valid. The 200 ms completion flag is don't care.", "IN REVIEW", "The exact data content and durable-write check are pending confirmation."),
    ]

    family_counts: Counter[str] = Counter()
    for item in source_data["vectors"]:
        family = item["family"]
        family_counts[family] += 1
        vector_number = family_counts[family]
        prefix = "S" if family == "Single event" else "M"
        timing = "Events are separated by more than 5 s." if family == "Single event" else "Events are separated by more than 500 ms and less than 5 s."
        vectors.append(
            vector(
                "V1-006",
                f"V1-006-{prefix}{vector_number:02d}",
                f"{family} sequence {vector_number:02d}",
                f"Event 1={event_label(item['event_1'])}; Event 2={event_label(item['event_2'])}; Event 3={event_label(item['event_3'])}. {timing}",
                three_event_expected(item),
                "IN REVIEW",
                "Execute all sixteen vectors; the expected EDR1/EDR2 values are written here for direct review.",
            )
        )

    timing_vectors = [
        ("01", "0 ms", "Parallel or overlapping event relation"),
        ("02", "1 ms", "Near-simultaneous event relation"),
        ("03", "299 ms", "Intermediate timing relation"),
        ("04", "300 ms", "Intermediate timing relation"),
        ("05", "301 ms", "Intermediate timing relation"),
        ("06", "499 ms", "Before multi-event threshold"),
        ("07", "500 ms", "Exact multi-event threshold"),
        ("08", "501 ms", "After multi-event threshold"),
        ("09", "4.999 s", "Before single-event boundary"),
        ("10", "5.000 s", "Exact single-event boundary"),
        ("11", "5.001 s", "After single-event boundary"),
    ]
    for suffix, boundary, scenario in timing_vectors:
        vectors.append(vector("V1-007", f"V1-007-{suffix}", scenario, f"Apply a two-event Near Crash/Deployment Event pair with {boundary} separation.", PENDING, "ON HOLD", "Timing reference, equality behavior, scheduler tick, and tolerance are pending confirmation."))

    storage_vectors = [
        ("01", "Both records unlocked; incoming fourth Deployment Event", "Replace the oldest unlocked record."),
        ("02", "Both records unlocked; incoming fourth Deployment Event", "Replace the newest unlocked record."),
        ("03", "Both records unlocked; incoming fourth Deployment Event", "Replace the lowest-priority unlocked record."),
        ("04", "Both records unlocked; incoming fourth Deployment Event", "Reject the incoming event and preserve both records."),
        ("05", "Both records unlocked; incoming fourth Deployment Event", "Preserve both records and store only overflow information."),
        ("06", "EDR1 locked; EDR2 unlocked; incoming fourth Deployment Event", "Select/reject behavior and counter update are pending confirmation."),
        ("07", "EDR1 unlocked; EDR2 locked; incoming fourth Deployment Event", "Select/reject behavior and counter update are pending confirmation."),
        ("08", "Both records locked; incoming fourth Deployment Event", "Locked-record protection and incoming-event handling are pending confirmation."),
        ("09", "Both records locked; incoming fourth Near Crash", "Locked-record protection and incoming-event handling are pending confirmation."),
        ("10", "One complete record and one incomplete or CRC-invalid record; incoming fifth Deployment Event", "Recovery, selection, and data-integrity behavior are pending confirmation."),
    ]
    for suffix, condition, expected in storage_vectors:
        vectors.append(vector("V1-008", f"V1-008-{suffix}", "Fourth/Fifth Event Storage", condition, f"{PENDING} Alternative review outcome: {expected}", "ON HOLD", "No storage replacement policy is assumed."))

    power_phases = [
        "Before T0", "Exactly at T0", "T0 + 1 ms", "T0 + 199 ms", "T0 + 200 ms", "T0 + 201 ms",
        "Immediately before CompletionStatus update", "During CompletionStatus update", "Immediately after CompletionStatus update",
        "During pre-crash buffer freeze", "During record allocation", "During metadata write", "During payload write",
        "During CRC write", "During valid-marker update", "During lock-bit update", "During lifetime-counter update",
        "During multi-event-counter update", "During record replacement or erase", "During EDR readout", "During shutdown preparation",
        "During a second event", "During a fourth or fifth event",
    ]
    power_modes = [
        "Hard battery disconnect", "KL15 off with KL30 retained", "KL30 loss with KL15 variation", "Ground interruption",
        "Brownout", "Slow voltage ramp down", "Fast voltage drop", "Voltage oscillation around reset threshold",
        "Short power interruption", "Repeated power interruptions", "Power restored during write", "Reverse KL15/KL30 removal order",
        "Loss of CAN supply while ECU supply remains present", "Hard battery disconnect", "Hard battery disconnect",
        "Hard battery disconnect", "Hard battery disconnect", "Hard battery disconnect", "KL30 loss with KL15 variation",
        "KL15 off with KL30 retained", "Brownout", "Hard battery disconnect", "Hard battery disconnect",
    ]
    for sequence_number, (phase, mode) in enumerate(zip(power_phases, power_modes, strict=True), start=1):
        vectors.append(vector("V1-009", f"V1-009-{sequence_number:02d}", f"Power interruption at {phase}", f"Power mode={mode}; interruption phase={phase}; repeat for Near Crash and Deployment Event where permitted.", PENDING, "ON HOLD", "Each phase and power mode is covered at least once. Atomicity and recovery rules are pending confirmation."))

    can_vectors = [
        ("01", "Nominal data storage", "Use valid values across the confirmed range and sample grid."),
        ("02", "CAN wake-up timing", "Wake before, at, and after T0; include repeated wake/sleep, chatter, wrong wake frame, and partial wake-up."),
        ("03", "Crash wake-up without CAN", "Create crash wake-up with no CAN data available."),
        ("04", "Data age and frame timing", "Use missing, delayed, jittered, and wrong-cycle-time frames."),
        ("05", "Frame ordering", "Use duplicate and out-of-order frames around sample points."),
        ("06", "Frame/data integrity", "Use rolling-counter error, CRC error, raw overflow, invalid enum, and multiplexer error."),
        ("07", "Signal availability and fail-safe", "Use timeout, stuck-at value, unavailable signal, and confirmed fail-safe reaction."),
        ("08", "Sample-point edge", "Change signal immediately before, at, and after each confirmed sample point."),
        ("09", "Cross-signal consistency", "Compare speed/wheel speed, brake/deceleration, steering/lateral acceleration, deployment/time, and crash/classification."),
        ("10", "Bus-off and recovery", "Create bus-off before event, at T0, during event, and recovery during recording."),
        ("11", "Recorded data representation", "Check endian, bit position, scaling, offset, unit, resolution, range, clamp, and packing."),
        ("12", "CAN supply loss", "Remove CAN supply while ECU supply remains present."),
    ]
    for suffix, scenario, condition in can_vectors:
        vectors.append(vector("V1-010", f"V1-010-{suffix}", scenario, condition, PENDING, "ON HOLD", "Confirm the exact signal, frame, range, timing, failure reaction, and recorded representation before execution."))

    diagnostic_vectors = [
        ("01", "Read during event capture", "Read EDR data while event capture is active."),
        ("02", "Read during write activity", "Read during record write, interrupted write, and after reset."),
        ("03", "Repeated and concurrent reads", "Use repeated reads, concurrent requests, and reset during read."),
        ("04", "Invalid diagnostic requests", "Use unsupported data identifier, incorrect request length, access gating, and timeout."),
        ("05", "Data association", "Check endian, EDR1/EDR2 association, counters, lock bits, stale data, and record mixing."),
    ]
    for suffix, scenario, condition in diagnostic_vectors:
        vectors.append(vector("V1-011", f"V1-011-{suffix}", scenario, condition, PENDING, "ON HOLD", "Confirm diagnostic request/response, access, timing, and error behavior before execution."))

    variant_vectors = [
        ("01", "High configuration with side remote sensors", "Check side and front behavior for the selected configuration."),
        ("02", "Domestic configuration", "Confirm event applicability for the selected Domestic configuration."),
        ("03", "Configuration changed before/after event", "Check interpretation of existing records and a new event after configuration change."),
        ("04", "Invalid or corrupted configuration", "Check EDR behavior, safety reaction, and recovery."),
        ("05", "Front event across configurations", "Check that side-event filtering does not suppress applicable front-event behavior."),
    ]
    for suffix, scenario, condition in variant_vectors:
        vectors.append(vector("V1-012", f"V1-012-{suffix}", scenario, condition, PENDING, "ON HOLD", "Only the Low/Mid without-side-sensor side-event behavior is confirmed in this version."))

    race_vectors = [
        ("01", "Second event during first 0-200 ms collection", "First event remains inside the initial 200 ms collection period."),
        ("02", "Second event during first 200 ms-to-5 s collection", "First event has not reached complete five-second status."),
        ("03", "Second event during allocation/write", "Allocation, write, replacement, or erase is active."),
        ("04", "Event during diagnostic read", "An EDR client is reading while the event begins."),
        ("05", "Event during startup/shutdown", "Apply separately during startup and shutdown."),
        ("06", "Event during CAN wake-up", "Event begins while CAN wake-up occurs."),
        ("07", "Event during crash wake-up", "Event begins while crash wake-up occurs."),
        ("08", "Event after watchdog reset", "Event begins immediately after reset recovery."),
    ]
    for suffix, scenario, condition in race_vectors:
        vectors.append(vector("V1-013", f"V1-013-{suffix}", scenario, condition, PENDING, "ON HOLD", "State transitions and concurrency handling are pending confirmation."))

    robustness_vectors = [
        ("01", "0 events", "No event; repeat default-data and read-consistency observation."),
        ("02", "1 event", "One Near Crash; record/unlock/notification-suppression path."),
        ("03", "2 events", "Two Unconfirmed Crash input sequences with front remote sensor timing variation."),
        ("04", "3 events", "Three Deployment Events; compare defined three-event behavior when applicable."),
        ("05", "4 events", "Mixed Near Crash and Deployment Event sequence with front followed by side."),
        ("06", "5 events", "Mixed Near Crash, Unconfirmed Crash, and Deployment Event sequence with side followed by front."),
        ("07", "10 events", "Repeated Near Crash, Unconfirmed Crash, and Deployment Event stress sequence with overlaps."),
        ("08", "N events", "Configurable randomized sequence varying classification, source, lock, timing, CAN, power, reset, diagnostics, configuration, and initial records."),
        ("09", "Counter normal", "Incoming event from a normal observed counter value."),
        ("10", "Counter maximum minus one", "Incoming event with the relevant counter at maximum minus one."),
        ("11", "Counter maximum", "Incoming event with the relevant counter at maximum."),
        ("12", "Counter rollover or saturation", "Incoming event requiring rollover or saturation handling."),
        ("13", "Long-duration campaign", "Approved bounded campaign with reproducible seeds and non-destructive limits."),
    ]
    for suffix, scenario, condition in robustness_vectors:
        vectors.append(vector("V1-014", f"V1-014-{suffix}", scenario, condition, PENDING, "ON HOLD", "Event4+, counter behavior, endurance limits, and campaign acceptance criteria are pending confirmation."))
    return vectors


def check_design(cases: list[dict[str, str]], vectors: list[dict[str, str]]) -> dict[str, Any]:
    case_ids = [case["id"] for case in cases]
    vector_ids = [item["vector_id"] for item in vectors]
    if len(cases) != 14:
        raise ValueError(f"Expected 14 optimized authoring cases, found {len(cases)}.")
    if len(case_ids) != len(set(case_ids)):
        raise ValueError("Duplicate authoring case IDs were generated.")
    if len(vectors) != 112:
        raise ValueError(f"Expected 112 execution vectors, found {len(vectors)}.")
    if len(vector_ids) != len(set(vector_ids)):
        raise ValueError("Duplicate vector IDs were generated.")
    vectors_by_case = Counter(item["case_id"] for item in vectors)
    expected_counts = {
        "V1-001": 1, "V1-002": 2, "V1-003": 1, "V1-004": 1, "V1-005": 4, "V1-006": 16,
        "V1-007": 11, "V1-008": 10, "V1-009": 23, "V1-010": 12, "V1-011": 5, "V1-012": 5,
        "V1-013": 8, "V1-014": 13,
    }
    if dict(vectors_by_case) != expected_counts:
        raise ValueError(f"Unexpected vector allocation: {dict(vectors_by_case)}")
    status_counts = Counter(item["status"] for item in vectors)
    if status_counts != Counter({"IN REVIEW": 25, "ON HOLD": 87}):
        raise ValueError(f"Unexpected vector status distribution: {dict(status_counts)}")
    return {
        "authoring_case_count": len(cases),
        "execution_vector_count": len(vectors),
        "authoring_status_counts": dict(Counter(case["status"] for case in cases)),
        "vector_status_counts": dict(status_counts),
        "vectors_by_case": dict(vectors_by_case),
    }


def copy_row_style(target: Any, template_styles: list[Any]) -> None:
    for column_number, style in enumerate(template_styles, start=1):
        target.cell(target.max_row + 1, column_number)._style = copy(style)


def apply_common_cell_style(cell: Any) -> None:
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    cell.border = Border(top=THIN_GRAY, bottom=THIN_GRAY, left=THIN_GRAY, right=THIN_GRAY)


def write_authoring_sheet(workbook: Any, cases: list[dict[str, str]], vectors: list[dict[str, str]]) -> None:
    sheet = workbook["Sheet1"]
    header_values = [sheet.cell(1, column_number).value for column_number in range(1, len(AUTHORING_HEADERS) + 1)]
    if header_values != AUTHORING_HEADERS:
        raise ValueError("The copied authoring layout does not contain the expected primary headers.")
    case_styles = [copy(sheet.cell(2, column_number)._style) for column_number in range(1, len(AUTHORING_HEADERS) + 1)]
    continuation_styles = [copy(sheet.cell(3, column_number)._style) for column_number in range(1, len(AUTHORING_HEADERS) + 1)]
    if sheet.max_row > 1:
        sheet.delete_rows(2, sheet.max_row - 1)
    vectors_by_case: dict[str, list[dict[str, str]]] = {}
    for item in vectors:
        vectors_by_case.setdefault(item["case_id"], []).append(item)

    row_number = 2
    for case in cases:
        case_vectors = vectors_by_case[case["id"]]
        parameters = "Execute every vector below:\n" + "\n".join(
            f"{item['vector_id']}: {item['scenario']}" for item in case_vectors
        )
        description = (
            f"{case['description']}\n\n"
            f"Coverage: {len(case_vectors)} defined execution vector(s).\n"
            f"Review note: {case['note']}"
        )
        primary_values = [
            None,
            case["priority"],
            case["name"],
            case["applicability"],
            description,
            case["pre_action"],
            case["post_action"],
            "Set bench to normal condition.",
            "System is in the approved normal state with no unintended fault condition.",
            "true",
            1,
            parameters,
            None,
            case["status"],
            "Functional",
            "Common EDR",
            None,
            "NOT YET TESTED",
            None,
            None,
            None,
            "Manual",
            case["method"],
            case["technique"],
        ]
        for column_number, value in enumerate(primary_values, start=1):
            cell = sheet.cell(row_number, column_number, value)
            cell._style = copy(case_styles[column_number - 1])
            apply_common_cell_style(cell)
        sheet.cell(row_number, 3).fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
        sheet.cell(row_number, 3).font = Font(bold=True, color="000000")
        sheet.row_dimensions[row_number].height = min(360, max(120, 15 * (7 + len(case_vectors))))

        step_rows = [
            ("Configure the selected test vector.", "The selected condition, inputs, timing, and required measurement evidence are recorded."),
            (case["setup_action"], "The selected precondition is established."),
            (case["trigger_action"], "The selected event, fault, read, or state transition is applied and captured."),
            (case["verify_action"], case["expected_result"]),
            ("Read the required EDR, CAN, and diagnostic observations using the approved interface and retain the raw evidence.", "The result can be reviewed against the selected vector without relying on an external document."),
            ("Compare the observed result with the selected vector and record the result or the pending confirmation.", case["expected_result"]),
            ("Restore the approved test condition and retain all evidence.", "The approved test condition is restored. Locked or persistent information is not cleared without separate approval."),
        ]
        for step_id, (action, expected) in enumerate(step_rows, start=2):
            row_number += 1
            for column_number, style in enumerate(continuation_styles, start=1):
                cell = sheet.cell(row_number, column_number)
                cell._style = copy(style)
                apply_common_cell_style(cell)
            sheet.cell(row_number, 8, action)
            sheet.cell(row_number, 9, expected)
            sheet.cell(row_number, 10, "true")
            sheet.cell(row_number, 11, step_id)
            if step_id == len(step_rows) + 1:
                for column_number in range(8, 12):
                    sheet.cell(row_number, column_number).fill = PatternFill("solid", fgColor=PALE_GREEN)
            sheet.row_dimensions[row_number].height = 60
        row_number += 1

    for column_number in range(1, len(AUTHORING_HEADERS) + 1):
        header = sheet.cell(1, column_number)
        apply_common_cell_style(header)
        header.fill = PatternFill("solid", fgColor=NAVY)
        header.font = Font(bold=True, color=WHITE)
        header.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
    sheet.row_dimensions[1].height = 28
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:X{sheet.max_row}"
    sheet.sheet_view.showGridLines = False
    sheet.sheet_properties.tabColor = HIGHLIGHT_YELLOW


def reset_support_sheets(workbook: Any) -> None:
    for worksheet in list(workbook.worksheets):
        if worksheet.title != "Sheet1":
            workbook.remove(worksheet)
    for title in [
        "Coverage Matrix",
        "Test Vectors",
        "Applicability Matrix",
        "Data Quality Matrix",
        "Timing Matrix",
        "Completion Matrix",
        "Open Items",
        "Version History",
    ]:
        workbook.create_sheet(title)
    workbook.defined_names.clear()
    workbook._external_links = []


def write_table(
    sheet: Any,
    headers: list[str],
    rows: list[list[str]],
    widths: list[int] | None = None,
    highlight_column: int | None = None,
) -> None:
    for column_number, header in enumerate(headers, start=1):
        cell = sheet.cell(1, column_number, header)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(bold=True, color=WHITE)
        cell.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
        apply_common_cell_style(cell)
    sheet.row_dimensions[1].height = 28
    for row_number, values in enumerate(rows, start=2):
        maximum_length = 0
        for column_number, value in enumerate(values, start=1):
            cell = sheet.cell(row_number, column_number, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            apply_common_cell_style(cell)
            if row_number % 2 == 0:
                cell.fill = PatternFill("solid", fgColor="F8FBFD")
            if highlight_column == column_number:
                cell.fill = PatternFill("solid", fgColor=HIGHLIGHT_YELLOW)
                cell.font = Font(bold=True, color="000000")
            maximum_length = max(maximum_length, len(str(value)))
        sheet.row_dimensions[row_number].height = min(150, max(28, 14 * (1 + maximum_length // 110)))
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{max(1, len(rows) + 1)}"
    sheet.sheet_view.showGridLines = False
    for column_number, header in enumerate(headers, start=1):
        width = widths[column_number - 1] if widths else min(60, max(14, len(header) + 2))
        sheet.column_dimensions[get_column_letter(column_number)].width = width


def write_support_sheets(workbook: Any, cases: list[dict[str, str]], vectors: list[dict[str, str]]) -> None:
    cases_by_id = {case["id"]: case for case in cases}
    vector_counts = Counter(item["case_id"] for item in vectors)
    coverage_rows = [
        [
            case["id"], case["name"], case["description"], str(vector_counts[case["id"]]),
            case["priority"], case["status"], case["note"],
        ]
        for case in cases
    ]
    write_table(
        workbook["Coverage Matrix"],
        ["Case ID", "Test Case Name", "Coverage", "Vector Count", "Priority", "Status", "Review Note"],
        coverage_rows,
        [14, 48, 78, 14, 12, 16, 80],
        highlight_column=2,
    )

    vector_rows = [
        [
            item["case_id"], item["vector_id"], cases_by_id[item["case_id"]]["name"], item["scenario"],
            item["condition"], item["expected"], item["status"], item["note"],
        ]
        for item in vectors
    ]
    write_table(
        workbook["Test Vectors"],
        ["Case ID", "Vector ID", "Test Case Name", "Scenario", "Input / Condition", "Expected Observation", "Status", "Review Note"],
        vector_rows,
        [14, 16, 48, 42, 75, 105, 16, 72],
        highlight_column=3,
    )

    applicability_rows = [
        [case["id"], case["name"], case["applicability"], str(vector_counts[case["id"]]), case["status"], "All listed vectors must be reviewed before the procedure is complete."]
        for case in cases
    ]
    write_table(
        workbook["Applicability Matrix"],
        ["Case ID", "Test Case Name", "Applicability", "Vector Count", "Status", "Completion Rule"],
        applicability_rows,
        [14, 48, 16, 14, 16, 78],
        highlight_column=2,
    )

    data_quality_rows = [
        ["Data validity", "Valid value, unavailable value, stuck value, raw overflow, invalid enum, multiplexer error", "V1-010", "Pending confirmation before pass/fail."],
        ["Frame timing", "Missing, delayed, jittered, wrong cycle time, duplicate, out-of-order", "V1-010", "Pending confirmation before pass/fail."],
        ["Wake-up", "Wake before T0, at T0, after T0, chatter, wrong wake frame, partial wake-up", "V1-010", "Pending confirmation before pass/fail."],
        ["Integrity", "Rolling counter, CRC, bus-off, recovery, CAN supply loss", "V1-010", "Pending confirmation before pass/fail."],
        ["Cross-signal", "Speed/wheel speed, brake/deceleration, steering/lateral acceleration, deployment/time, crash/classification", "V1-010", "Pending confirmation before pass/fail."],
    ]
    write_table(
        workbook["Data Quality Matrix"],
        ["Area", "Conditions Covered", "Case ID", "Result Rule"],
        data_quality_rows,
        [20, 100, 14, 55],
    )

    timing_rows = [
        ["Completion", "199 ms / 200 ms / 201 ms", "V1-005", "Observe status transitions; exact boundary and tolerance pending confirmation."],
        ["Completion", "4.999 s / 5.000 s / 5.001 s", "V1-005", "Observe status transitions; exact boundary and tolerance pending confirmation."],
        ["Inter-event", "0 ms / 1 ms", "V1-007", PENDING],
        ["Inter-event", "299 ms / 300 ms / 301 ms", "V1-007", PENDING],
        ["Inter-event", "499 ms / 500 ms / 501 ms", "V1-007", PENDING],
        ["Inter-event", "4.999 s / 5.000 s / 5.001 s", "V1-007", PENDING],
    ]
    write_table(
        workbook["Timing Matrix"],
        ["Timing Area", "Boundary Values", "Case ID", "Expected Observation"],
        timing_rows,
        [20, 45, 14, 95],
    )

    completion_rows = [
        ["0", "0", "EDR data are not valid.", "V1-005-02"],
        ["0", "1", "EDR data are valid through 200 ms.", "V1-005-03"],
        ["1", "Don't care", "EDR data are valid.", "V1-005-04"],
        ["After 200 ms", "1", "The 200 ms completion flag becomes 1 after 200 ms.", "V1-005-01"],
        ["After five seconds with battery available", "Not applicable", "CompletionStatus becomes 1.", "V1-005-01"],
    ]
    write_table(
        workbook["Completion Matrix"],
        ["CompletionStatus", "200 ms Completion Flag", "Expected Observation", "Vector ID"],
        completion_rows,
        [35, 30, 85, 16],
    )

    open_items_rows = [
        ["OI-001", "Diagnostic access", "Confirm the data identifiers, access conditions, request/response content, error responses, and read-during-recording behavior.", "V1-001; V1-003; V1-006; V1-011"],
        ["OI-002", "CAN data recording", "Confirm signal names, value range, timing, validity reaction, sample age, and recorded representation.", "V1-010"],
        ["OI-003", "Timing boundaries", "Confirm T0 reference, exact 500 ms and five-second behavior, scheduler tick, and timing tolerance.", "V1-005; V1-006; V1-007"],
        ["OI-004", "Fourth and later events", "Confirm record replacement, locked-record protection, overflow/rejection, counters, and persistence.", "V1-008; V1-014"],
        ["OI-005", "Power interruption", "Confirm record write order, data atomicity, recovery, and allowed power-control procedure.", "V1-005; V1-009"],
        ["OI-006", "Unconfirmed Crash", "Confirm record, lock, notification, and delayed-confirmation behavior.", "V1-004; V1-013; V1-014"],
        ["OI-007", "Configuration scope", "Confirm High configuration, configuration changes, invalid configuration behavior, and front-event applicability.", "V1-012"],
        ["OI-008", "Campaign limits", "Confirm allowed event count, counter limit behavior, endurance duration, and safe execution constraints.", "V1-014"],
    ]
    write_table(
        workbook["Open Items"],
        ["Open Item", "Topic", "Confirmation Needed", "Affected Cases"],
        open_items_rows,
        [14, 28, 110, 44],
    )

    version_rows = [
        ["V1", date.today().isoformat(), "Initial Review", "Initial standalone authoring copy. Optimized from 19 procedure families to 14 authoring cases while preserving 112 execution vectors.", "Review pending"],
        ["V2", "Reserved", "Future Review", "Create only after review comments are received. Preserve V1 unchanged.", "Not started"],
    ]
    write_table(
        workbook["Version History"],
        ["Version", "Date", "Status", "Change Summary", "Review State"],
        version_rows,
        [14, 16, 22, 110, 24],
    )


def remove_visible_references(workbook: Any) -> None:
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.comment is not None:
                    cell.comment = None
                if cell.hyperlink is not None:
                    cell.hyperlink = None


FORBIDDEN_VISIBLE_TEXT = (
    "edr_requirements",
    "ice_common_srs_v1.4_diag_re.xlsx",
    "common_edr_canc_0455_045b_u171_m314_v7_authoring.xlsx",
    "project_testcases",
    "docs\\",
    "c:\\",
    ".xlsx",
    ".csv",
    ".json",
)


def scan_for_visible_references(path: Path) -> list[str]:
    workbook = load_workbook(path, data_only=False, read_only=False)
    findings: list[str] = []
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                value = cell.value
                if isinstance(value, str):
                    normalized = value.lower()
                    if any(token in normalized for token in FORBIDDEN_VISIBLE_TEXT):
                        findings.append(f"{sheet.title}!{cell.coordinate}")
                if cell.comment is not None:
                    findings.append(f"comment at {sheet.title}!{cell.coordinate}")
                if cell.hyperlink is not None:
                    findings.append(f"hyperlink at {sheet.title}!{cell.coordinate}")
    return findings


def scan_package_for_reference_residue(path: Path) -> list[str]:
    forbidden = ("edr_requirements", "ice_common_srs_v1.4_diag_re.xlsx", "common_edr_canc_0455_045b_u171_m314_v7_authoring.xlsx", "c:\\framework_ioem_py")
    findings: list[str] = []
    with ZipFile(path) as package:
        for member in package.namelist():
            if not member.endswith((".xml", ".rels")):
                continue
            text = package.read(member).decode("utf-8", errors="ignore").lower()
            if any(token in text for token in forbidden):
                findings.append(member)
    return findings


def validate_workbook(path: Path, expected_design: dict[str, Any]) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Generated authoring workbook is missing: {path}")
    workbook = load_workbook(path, data_only=False, read_only=False)
    expected_sheets = [
        "Sheet1", "Coverage Matrix", "Test Vectors", "Applicability Matrix", "Data Quality Matrix",
        "Timing Matrix", "Completion Matrix", "Open Items", "Version History",
    ]
    if workbook.sheetnames != expected_sheets:
        raise ValueError(f"Unexpected workbook sheet order: {workbook.sheetnames}")
    primary = workbook["Sheet1"]
    headers = [primary.cell(1, column_number).value for column_number in range(1, len(AUTHORING_HEADERS) + 1)]
    if headers != AUTHORING_HEADERS:
        raise ValueError("The V1 authoring sheet no longer matches the cited authoring format.")
    primary_rows = []
    for row_number in range(2, primary.max_row + 1):
        name = primary.cell(row_number, 3).value
        if isinstance(name, str) and name.startswith("SUBS_EDR_"):
            primary_rows.append(row_number)
    if len(primary_rows) != expected_design["authoring_case_count"]:
        raise ValueError(f"Expected {expected_design['authoring_case_count']} authoring rows, found {len(primary_rows)}.")
    if sum(
        1
        for row_number in primary_rows
        if primary.cell(row_number, 3).fill.fill_type == "solid"
        and (primary.cell(row_number, 3).fill.fgColor.rgb or "").endswith(HIGHLIGHT_YELLOW)
    ) != expected_design["authoring_case_count"]:
        raise ValueError("Every V1 test-case name must be yellow highlighted.")
    if any(primary.cell(row_number, 13).value not in (None, "") for row_number in primary_rows):
        raise ValueError("The authoring workbook must not contain requirement references in Verifies.")
    if any(primary.cell(row_number, 21).value not in (None, "") for row_number in primary_rows):
        raise ValueError("The authoring workbook must not contain script/file references.")

    vector_sheet = workbook["Test Vectors"]
    vector_rows = [row for row in vector_sheet.iter_rows(min_row=2, values_only=True) if any(value not in (None, "") for value in row)]
    if len(vector_rows) != expected_design["execution_vector_count"]:
        raise ValueError(f"Expected {expected_design['execution_vector_count']} vectors, found {len(vector_rows)}.")
    vector_ids = [str(row[1]) for row in vector_rows]
    if len(vector_ids) != len(set(vector_ids)):
        raise ValueError("Test Vectors contains duplicate IDs.")
    if sum(
        1
        for row_number in range(2, vector_sheet.max_row + 1)
        if vector_sheet.cell(row_number, 3).value is not None
        and vector_sheet.cell(row_number, 3).fill.fill_type == "solid"
        and (vector_sheet.cell(row_number, 3).fill.fgColor.rgb or "").endswith(HIGHLIGHT_YELLOW)
    ) != expected_design["execution_vector_count"]:
        raise ValueError("Every vector Test Case Name must be yellow highlighted.")

    visible_findings = scan_for_visible_references(path)
    if visible_findings:
        raise ValueError(f"Visible external reference(s) found in the specification: {visible_findings[:10]}")
    package_findings = scan_package_for_reference_residue(path)
    if package_findings:
        raise ValueError(f"External reference residue found in workbook package: {package_findings}")
    return {
        "workbook": str(path),
        "sheet_count": len(workbook.sheetnames),
        "primary_sheet": "Sheet1",
        "primary_headers": headers,
        "optimized_authoring_case_count": len(primary_rows),
        "execution_vector_count": len(vector_rows),
        "yellow_highlighted_primary_names": len(primary_rows),
        "yellow_highlighted_vector_names": len(vector_rows),
        "verifies_column_blank": True,
        "script_path_column_blank": True,
        "visible_external_references": 0,
        "package_reference_residue": 0,
    }


def generate() -> dict[str, Any]:
    if not REFERENCE_LAYOUT.is_file():
        raise FileNotFoundError(f"The authoring-layout template is unavailable: {REFERENCE_LAYOUT}")
    source_data = inspect_source()
    cases = build_cases()
    vectors = build_vectors(source_data)
    design = check_design(cases, vectors)
    VERSION_DIRECTORY.mkdir(parents=True, exist_ok=True)
    copy2(REFERENCE_LAYOUT, OUTPUT_WORKBOOK)
    workbook = load_workbook(OUTPUT_WORKBOOK, data_only=False, read_only=False)
    write_authoring_sheet(workbook, cases, vectors)
    reset_support_sheets(workbook)
    write_support_sheets(workbook, cases, vectors)
    remove_visible_references(workbook)
    workbook.properties.title = "EDR Minimum Coverage Authoring Specification"
    workbook.properties.subject = "Standalone optimized EDR authoring test cases"
    workbook.properties.creator = "EDR Test Team"
    workbook.properties.description = "Version V1. Self-contained authoring specification with no external reference text."
    workbook.save(OUTPUT_WORKBOOK)
    workbook.close()
    validation = validate_workbook(OUTPUT_WORKBOOK, design)
    report = {
        "version": "V1",
        "status": "Initial Review",
        "authoring_case_count": design["authoring_case_count"],
        "execution_vector_count": design["execution_vector_count"],
        "authoring_status_counts": design["authoring_status_counts"],
        "vector_status_counts": design["vector_status_counts"],
        "optimization": "Nineteen previous procedure families are combined into fourteen authoring cases while retaining all 112 execution vectors.",
        "format": "Copied authoring layout with the primary 24-column authoring contract and continuation-step rows.",
        "standalone_content": "No requirement workbook name, requirement sheet name, external file path, script path, or file reference is written into the workbook.",
        "validation": validation,
        "generation_date": date.today().isoformat(),
    }
    OUTPUT_REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate or validate the V1 standalone EDR authoring workbook.")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--generate", action="store_true", help="Create or replace the V1 authoring workbook from the copied layout.")
    action.add_argument("--validate", action="store_true", help="Validate the existing V1 authoring workbook.")
    arguments = parser.parse_args()
    if arguments.generate:
        report = generate()
    else:
        source_data = inspect_source()
        report = validate_workbook(OUTPUT_WORKBOOK, check_design(build_cases(), build_vectors(source_data)))
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())