from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "tools" / "query_compact_memory_graph.py"
SPEC = importlib.util.spec_from_file_location("compact_memory_query", SCRIPT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"Unable to load {SCRIPT_PATH}")
MEMORY_QUERY = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MEMORY_QUERY
SPEC.loader.exec_module(MEMORY_QUERY)


class CompactMemoryQueryTests(unittest.TestCase):
    def test_query_returns_compact_results_and_source_references(self) -> None:
        graph = {
            "repository": {"name": "Demo"},
            "files": [
                {
                    "id": "file:shared_libraries/can.py",
                    "path": "shared_libraries/can.py",
                    "purpose": "Shared CAN diagnostic routing component.",
                    "module": "module:shared-libraries",
                    "priority": "high",
                    "exports": ["CanRoute"],
                    "depends_on": ["config"],
                    "symbols": [{"name": "CanRoute", "kind": "class", "location": "L10"}],
                    "relationships": [{"target": "config", "relation": "imports"}],
                    "source_reference": {"path": "shared_libraries/can.py", "location": "L1"},
                },
                {
                    "id": "file:tools/export.py",
                    "path": "tools/export.py",
                    "purpose": "Offline export utility.",
                    "module": "module:tools",
                    "priority": "medium",
                    "exports": ["export"],
                    "depends_on": [],
                    "symbols": [{"name": "export", "kind": "function", "location": "L3"}],
                    "relationships": [],
                    "source_reference": {"path": "tools/export.py", "location": "L1"},
                },
            ],
            "modules": [
                {"id": "module:shared-libraries", "source_paths": ["shared_libraries/can.py"]},
                {"id": "module:tools", "source_paths": ["tools/export.py"]},
            ],
            "graph": {
                "nodes": [
                    {"id": "file:shared_libraries/can.py", "label": "shared_libraries/can.py", "type": "file"},
                    {"id": "external:config", "label": "config", "type": "external_symbol"},
                ],
                "edges": [
                    {"source": "file:shared_libraries/can.py", "target": "external:config", "relation": "imports", "confidence": "EXTRACTED", "source_location": "L1"}
                ],
            },
        }
        with tempfile.TemporaryDirectory(prefix="compact-memory-query-") as temporary_dir:
            path = Path(temporary_dir) / "memory-graph.json"
            path.write_text(json.dumps(graph), encoding="utf-8")
            result = MEMORY_QUERY.query_memory_graph(path, "CAN route", limit=3, depth=1)

        self.assertFalse(result["raw_code_returned"])
        self.assertEqual(result["matches"][0]["path"], "shared_libraries/can.py")
        self.assertEqual(result["matches"][0]["symbols"][0]["name"], "CanRoute")
        self.assertIn({"path": "shared_libraries/can.py", "location": "L1"}, result["recommended_source_references"])
        self.assertTrue(any(node["label"] == "config" for node in result["related_nodes"]))