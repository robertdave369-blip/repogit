"""Regression coverage for the reusable automotive CAN log-analysis skill utility."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest


SCRIPT_PATH = (
    Path(__file__).resolve().parents[1]
    / ".github"
    / "skills"
    / "automotive-can-log-analysis"
    / "scripts"
    / "can_log_analyzer.py"
)
SPEC = importlib.util.spec_from_file_location("automotive_can_log_analyzer", SCRIPT_PATH)
assert SPEC is not None and SPEC.loader is not None
TOOL = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = TOOL
SPEC.loader.exec_module(TOOL)


def write_log(tmp_path: Path, name: str, content: str) -> Path:
    """Create a temporary text log using the same UTF-8 encoding as supported inputs."""

    log_file = tmp_path / name
    log_file.write_text(content.strip() + "\n", encoding="utf-8")
    return log_file


def test_parse_supported_text_log_layouts(tmp_path: Path) -> None:
    log_file = write_log(
        tmp_path,
        "mixed.log",
        """
        1.000000 2 738 Rx d 8 10 0A 62 04 55 AA BB CC
        3172.051055 Can   2  RX  l=8,  id=000002C0, 00 00 00 00 01 01 A0 68
        TX_MSG, c=2, t=12982871.09500, id=0114, l=5, 00 00 00 00 05
        2555.998347 2 Rx 738 15 59 02 CB 92 18 11 08 92 37 13 08 92 36 11 8B
        """,
    )

    messages = TOOL.parse_text_log(log_file)

    assert [message.source_format for message in messages] == [
        "vector-asc",
        "aria-can",
        "aria-message",
        "diagnostic-export",
    ]
    assert messages[1].can_id == 0x2C0
    assert messages[1].direction == "Rx"
    assert messages[2].can_id == 0x114
    assert messages[2].dlc == 5
    assert messages[3].dlc == 15
    assert messages[3].data[:3] == (0x59, 0x02, 0xCB)


def test_extract_edr_accepts_isotp_and_direct_uds_rows() -> None:
    messages = [
        TOOL.CanMessage(
            timestamp=1.0,
            channel=2,
            can_id=0x738,
            direction="Rx",
            dlc=8,
            data=(0x10, 0x0A, 0x62, 0x04, 0x55, 0xAA, 0xBB, 0xCC),
            line_num=1,
            source_format="vector-asc",
        ),
        TOOL.CanMessage(
            timestamp=1.01,
            channel=2,
            can_id=0x738,
            direction="Rx",
            dlc=8,
            data=(0x21, 0xDD, 0xEE, 0xFF, 0x11, 0x00, 0x00, 0x00),
            line_num=2,
            source_format="vector-asc",
        ),
        TOOL.CanMessage(
            timestamp=2.0,
            channel=2,
            can_id=0x738,
            direction="Rx",
            dlc=6,
            data=(0x62, 0x04, 0x55, 0x12, 0x34, 0x56),
            line_num=3,
            source_format="diagnostic-export",
        ),
    ]

    payloads = TOOL.extract_diagnostic_payloads(messages, 0x738)
    edr_responses = TOOL.filter_edr_responses(payloads, 0x0455)

    assert len(edr_responses) == 2
    assert edr_responses[0].data == (0x62, 0x04, 0x55, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x11)
    assert edr_responses[0].frame_count == 2
    assert edr_responses[1].data == (0x62, 0x04, 0x55, 0x12, 0x34, 0x56)
    assert edr_responses[1].frame_count == 1


def test_extract_generic_did_and_render_payload_report(tmp_path: Path) -> None:
    response = TOOL.DiagnosticPayload(
        timestamp=2.0,
        data=(0x62, 0xF1, 0x90, 0x31, 0x32, 0x33),
        frame_count=1,
        source_line=7,
        source_format="diagnostic-export",
    )

    did_responses = TOOL.filter_did_responses([response], 0xF190)
    report = TOOL.render_did_report(tmp_path / "capture.log", 0x738, 0xF190, did_responses)

    assert did_responses == [response]
    assert "DID: 0xF190" in report
    assert "DID bytes (without 62 F1 90): 31 32 33" in report


def test_search_reports_pattern_byte_offset() -> None:
    message = TOOL.CanMessage(
        timestamp=3172.051055,
        channel=2,
        can_id=0x2C0,
        direction="Rx",
        dlc=8,
        data=(0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0xA0, 0x68),
        line_num=1,
        source_format="aria-can",
    )

    results = TOOL.search_messages(
        [message],
        can_id=0x2C0,
        byte_pattern=TOOL.parse_byte_pattern("01 ?? A0"),
        byte_offset=4,
    )

    assert results == [(message, [4])]


def test_export_frames_cli_writes_only_the_selected_can_id(tmp_path: Path) -> None:
    source = write_log(
        tmp_path,
        "capture.log",
        """
        RX_MSG, c=2, t=1.00000, id=02C0, l=8, 00 00 00 00 01 01 A0 68
        TX_MSG, c=2, t=1.00500, id=0114, l=5, 00 00 00 00 05
        RX_MSG, c=2, t=1.02000, id=02C0, l=8, 00 00 00 00 01 01 B0 A5
        """,
    )
    output = tmp_path / "selected.csv"

    exit_code = TOOL.main(["export-frames", str(source), str(output), "--can-id", "0x2C0"])

    exported = TOOL.load_messages(output)
    assert exit_code == 0
    assert [message.can_id for message in exported] == [0x2C0, 0x2C0]


def test_timing_cli_reports_interframe_and_cross_id_differences(tmp_path: Path) -> None:
    source = write_log(
        tmp_path,
        "timing.log",
        """
        RX_MSG, c=2, t=1.00000, id=02C0, l=1, 00
        TX_MSG, c=2, t=1.00500, id=0114, l=1, 00
        RX_MSG, c=2, t=1.02000, id=02C0, l=1, 00
        TX_MSG, c=2, t=1.02700, id=0114, l=1, 00
        RX_MSG, c=2, t=1.04000, id=02C0, l=1, 00
        """,
    )
    report_file = tmp_path / "timing.txt"

    exit_code = TOOL.main(
        [
            "timing",
            str(source),
            "--can-id",
            "0x2C0",
            "--compare-id",
            "0x114",
            "--expected-period-ms",
            "20",
            "--output",
            str(report_file),
        ]
    )

    assert exit_code == 0
    report = report_file.read_text(encoding="utf-8")
    assert "Primary intervals for 0x2C0: count=2" in report
    assert "Mean: 20.000 ms" in report
    assert "Cross-ID pairs: 2 of 3 primary frame(s)" in report
    assert "Cross-ID delta (0x114 - 0x2C0): count=2" in report
    assert "Mean: 6.000 ms" in report


def test_timing_report_marks_non_forward_timestamp_transitions(tmp_path: Path) -> None:
    messages = [
        TOOL.CanMessage(1.000, 2, 0x2C0, "Rx", 1, (0x00,), 1, "aria-message"),
        TOOL.CanMessage(1.020, 2, 0x2C0, "Rx", 1, (0x00,), 2, "aria-message"),
        TOOL.CanMessage(0.010, 2, 0x2C0, "Rx", 1, (0x00,), 3, "aria-message"),
    ]

    report = TOOL.render_timing_report(
        tmp_path / "reset.log",
        messages,
        0x2C0,
        None,
        "next",
        None,
        10,
    )

    assert "Capture timestamp segments: 2" in report
    assert "Non-forward primary transitions: 1" in report
    assert "= -1010.000 ms [non-forward/reset]" in report


def test_isotp_cli_reports_flow_control_fields_and_timing(tmp_path: Path) -> None:
    source = write_log(
        tmp_path,
        "transport.log",
        """
        RX_MSG, c=2, t=1.00000, id=0738, l=8, 10 0A 62 F1 90 31 32 33
        TX_MSG, c=2, t=1.00500, id=0730, l=8, 30 00 0A 00 00 00 00 00
        RX_MSG, c=2, t=1.00600, id=0738, l=8, 21 34 35 36 37 38 39 30
        """,
    )
    report_file = tmp_path / "transport.txt"

    exit_code = TOOL.main(
        [
            "isotp",
            str(source),
            "--data-id",
            "0x738",
            "--flow-control-id",
            "0x730",
            "--output",
            str(report_file),
        ]
    )

    assert exit_code == 0
    report = report_file.read_text(encoding="utf-8")
    assert "First Frame" in report
    assert "Consecutive Frame" in report
    assert "flow status=Continue To Send; block size=0; STmin=10 ms" in report
    assert "Pairs: 1 of 1 first frame(s)" in report
    assert "Mean: 5.000 ms" in report


def test_conversion_round_trip_preserves_normalized_messages(tmp_path: Path) -> None:
    source = write_log(
        tmp_path,
        "source.txt",
        "RX_MSG, c=2, t=12.50000, id=02C0, l=8, 00 00 00 00 01 01 A0 68",
    )
    messages = TOOL.load_messages(source)
    asc_output = tmp_path / "converted.asc"
    json_output = tmp_path / "converted.json"

    TOOL.convert_messages(messages, asc_output, "asc")
    TOOL.convert_messages(messages, json_output, "json")

    asc_messages = TOOL.load_messages(asc_output)
    json_messages = TOOL.load_messages(json_output)
    assert asc_messages[0].can_id == 0x2C0
    assert asc_messages[0].data == messages[0].data
    assert json_messages == messages


def test_extract_edr_cli_writes_default_report(tmp_path: Path) -> None:
    source = write_log(
        tmp_path,
        "capture.log",
        "RX_MSG, c=2, t=12.50000, id=0738, l=6, 62 04 55 12 34 56",
    )

    exit_code = TOOL.main(["extract-edr", str(source)])
    report_file = tmp_path / "capture_did_0455_edr_report.txt"

    assert exit_code == 0
    assert report_file.is_file()
    report = report_file.read_text(encoding="utf-8")
    assert "EDR responses found: 1" in report
    assert "EDR bytes (without 62 04 55): 12 34 56" in report


def test_extract_did_cli_writes_generic_did_report(tmp_path: Path) -> None:
    source = write_log(
        tmp_path,
        "capture.log",
        "RX_MSG, c=2, t=12.50000, id=0738, l=6, 62 F1 90 31 32 33",
    )

    exit_code = TOOL.main(["extract-did", str(source), "--response-id", "0x738", "--did", "0xF190"])
    report_file = tmp_path / "capture_did_F190_report.txt"

    assert exit_code == 0
    assert report_file.is_file()
    report = report_file.read_text(encoding="utf-8")
    assert "DID responses found: 1" in report
    assert "DID bytes (without 62 F1 90): 31 32 33" in report


def test_decode_did_cli_reports_dbc_value_and_response_byte_position(tmp_path: Path) -> None:
    pytest.importorskip("cantools")
    source = write_log(
        tmp_path,
        "capture.log",
        "RX_MSG, c=2, t=12.50000, id=0738, l=5, 62 F1 90 A0 68",
    )
    dbc_file = tmp_path / "did_layout.dbc"
    dbc_file.write_text(
        """VERSION ""

NS_ :
    NS_DESC_
BS_:
BU_: Vector__XXX
BO_ 1 DID_Layout: 2 Vector__XXX
 SG_ Counter : 4|4@1+ (1,0) [0|15] "" Vector__XXX
""",
        encoding="utf-8",
    )
    report_file = tmp_path / "did_decode.txt"

    exit_code = TOOL.main(
        [
            "decode-did",
            str(source),
            "--response-id",
            "0x738",
            "--did",
            "0xF190",
            "--dbc",
            str(dbc_file),
            "--dbc-message",
            "DID_Layout",
            "--output",
            str(report_file),
        ]
    )

    assert exit_code == 0
    report = report_file.read_text(encoding="utf-8")
    assert "Counter: physical=10; raw=10" in report
    assert "DID payload byte 0=0xA0 (diagnostic byte 3)" in report


def test_blf_conversion_to_asc(tmp_path: Path) -> None:
    can = pytest.importorskip("can")
    blf_file = tmp_path / "capture.blf"
    with can.BLFWriter(str(blf_file)) as writer:
        writer.on_message_received(
            can.Message(
                timestamp=12.5,
                arbitration_id=0x2C0,
                data=[0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0xA0, 0x68],
                is_extended_id=False,
                is_rx=True,
                channel=2,
            )
        )

    asc_file = tmp_path / "capture.asc"
    TOOL.convert_messages(TOOL.load_messages(blf_file), asc_file, "asc")
    asc_messages = TOOL.load_messages(asc_file)

    assert len(asc_messages) == 1
    assert asc_messages[0].can_id == 0x2C0
    assert asc_messages[0].direction == "Rx"
    assert asc_messages[0].data == (0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0xA0, 0x68)


def test_dbc_decode_includes_signal_value_and_byte_position(tmp_path: Path) -> None:
    pytest.importorskip("cantools")
    dbc_file = tmp_path / "sample.dbc"
    dbc_file.write_text(
        """VERSION ""

NS_ :
    NS_DESC_
BS_:
BU_: Vector__XXX
BO_ 704 Vehicle_Status: 8 Vector__XXX
 SG_ Counter : 52|4@1+ (1,0) [0|15] "" Vector__XXX
""",
        encoding="utf-8",
    )
    message = TOOL.CanMessage(
        timestamp=1.0,
        channel=2,
        can_id=0x2C0,
        direction="Rx",
        dlc=8,
        data=(0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0xA0, 0x68),
        line_num=1,
        source_format="aria-can",
    )

    report = TOOL.decode_with_dbc([message], dbc_file, max_frames=1)

    assert "DBC message: Vehicle_Status" in report
    assert "Counter: physical=10; raw=10" in report
    assert "start bit 52, length 4 bits, Intel/little-endian" in report
    assert "byte 6=0xA0" in report