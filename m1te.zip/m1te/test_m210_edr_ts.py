"""Offline checks of the M210 EDR ARIA scripts (projects/M210/modules/EDR_CANC/script_ts).

The scripts' own functions are compiled with the JScript .NET compiler and run on plain data (no ARIA
type, no bench): their record decoding against the framework's edr_sample_records /
decodeParameterValues, the expected CAN-C record values of every case against a reference built from
the combined EDR CAN-C scripts' rules, the fault and sample timing of the recording schedule, the fault
DTCs, and the multi-event record allocation against the EV specification's event tables.

    py -3.14 tests/test_m210_edr_ts.py
"""

from __future__ import annotations

import os
import random
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = REPO_ROOT / "projects" / "M210" / "modules" / "EDR_CANC" / "script_ts"
JSC = Path(r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\jsc.exe")
COMMON_DOC = REPO_ROOT / "docs" / "project_documents" / "EDR_Spec Common" / "EDR_COMMON_PARAMETERS.md"
os.environ.setdefault("IOEM_FRAMEWORK_PROJECT", "M210")
sys.path.insert(0, str(REPO_ROOT.parent))
sys.path.insert(0, str(REPO_ROOT / "tools"))

import build_m210_edr_ts as BUILD  # noqa: E402

PARAMETER_CASES = [
    ("NOMINAL", "Nominal", None, "full", "nominal", True),
    ("OUT_OF_RANGE", "OOR", None, "full", "oor", False),
    ("RESERVED", "Reserved", None, "full", "reserved", False),
]
HARNESS = r"""
var HARNESS_OUT = "@@OUT@@";
var harnessLines = [];
function hout(line) {
    harnessLines.push(line);
}
initData();
var recordLines = System.IO.File.ReadAllLines("@@RECORDS@@");
for (var r = 0; r < recordLines.length; r++) {
    var bytes = parseHexBytes(String(recordLines[r]));
    for (var e = 0; e < ELEMENTS.length; e++) {
        var samples = decodeElement(ELEMENTS[e], bytes);
        var raws = [];
        for (var s = 0; s < samples.length; s++) {
            raws.push(String(samples[s].raw));
        }
        hout("D|" + r + "|" + ELEMENTS[e].name + "|" + raws.join(","));
    }
}
var harnessCases = CASES.concat([@@EXTRA_CASES@@]);
for (var c = 0; c < harnessCases.length; c++) {
    var caseDef = harnessCases[c];
    var applying = applyingSeries(caseDef);
    var fault = buildFault(caseDef, applying);
    var dtcs = [];
    for (var d = 0; d < fault.dtcs.length; d++) {
        dtcs.push(fault.dtcs[d].code + "/" + fault.dtcs[d].status);
    }
    dtcs.sort();
    hout("F|" + caseDef.id + "|" + fault.stopped.slice(0).sort().join(",") + "|" + fault.broken.slice(0).sort().join(",") + "|" +
        fault.nodes.slice(0).sort().join(",") + "|" + dtcs.join(",") + "|" + fault.qualifyMs + "|" + crashCount(caseDef, applying));
    for (var crash = 0; crash < 2; crash++) {
        var plans = crashPlans(caseDef, crash, applying, fault);
        for (var p = 0; p < plans.length; p++) {
            plans[p].primed = plans[p].values[0];
        }
        var byId = plansBySeries(plans);
        for (p = 0; p < plans.length; p++) {
            var plan = plans[p];
            var count = plan.item.follows !== null ? 1 : plan.values.length;
            for (var index = 0; index < count; index++) {
                var accepted = acceptedRaws(plan, expectedCanRaw(plan, index, fault, byId)).raws;
                accepted.sort(function (a, b) { return a - b; });
                var driven = plan.item.follows !== null ? "" : String(drivenRaw(plan, index, fault));
                hout("E|" + caseDef.id + "|" + crash + "|" + plan.item.series + "|" + index + "|" + accepted.join(",") + "|" +
                    (sampleInFault(plan, index, fault, byId) ? 1 : 0) + "|" + driven);
            }
        }
        if (crash === 0) {
            var schedule = buildSchedule(plans, fault);
            for (var v = 0; v < schedule.events.length; v++) {
                var ev = schedule.events[v];
                hout("S|" + caseDef.id + "|" + ev.at + "|" + ev.kind + "|" + (ev.plan === undefined ? "" : ev.plan.item.series) + "|" +
                    (ev.index === undefined ? "" : ev.index));
            }
        }
    }
}
System.IO.File.WriteAllText(HARNESS_OUT, harnessLines.join("\r\n"));
"""
PROLOGUE = """import System;
import System.Threading;
var CAN = null;
var PS = null;
var RSU = null;
var SPI = null;
var ARIA = null;
var RESULT = null;
var TestStatus = { Passed: 1, Failed: 0 };
"""


def run_harness(records: list[list[int]]) -> list[str]:
    script = (SCRIPTS / "M210_EDR_CANC_Faults.ts").read_text(encoding="ascii").replace("\r\n", "\n")
    body = script.rstrip()
    if not body.endswith("main();"):
        raise AssertionError("the faults script no longer ends with main();")
    body = body[: -len("main();")]
    extra = ", ".join('{ id: "%s", title: "%s", tag: "%s", mode: null, scope: "%s", valueSet: "%s", wake: "", cycleSnapshots: %s }'
                      % (cid, cid, tag, scope, value_set, "true" if cycle else "false")
                      for cid, tag, _, scope, value_set, cycle in PARAMETER_CASES)
    with tempfile.TemporaryDirectory() as work:
        work_path = Path(work)
        records_path = work_path / "records.txt"
        out_path = work_path / "out.txt"
        records_path.write_text("\n".join(" ".join(f"{b:02X}" for b in rec) for rec in records), encoding="ascii")
        harness = HARNESS.replace("@@OUT@@", str(out_path).replace("\\", "\\\\")).replace(
            "@@RECORDS@@", str(records_path).replace("\\", "\\\\")).replace("@@EXTRA_CASES@@", extra)
        (work_path / "harness.js").write_text(PROLOGUE + body + harness, encoding="ascii")
        compiled = subprocess.run([str(JSC), "/nologo", "/fast+", "/out:" + str(work_path / "harness.exe"), str(work_path / "harness.js")],
                                  capture_output=True, text=True, cwd=work)
        if compiled.returncode != 0:
            raise AssertionError("harness does not compile:\n" + compiled.stdout[-3000:])
        ran = subprocess.run([str(work_path / "harness.exe")], capture_output=True, text=True, cwd=work, timeout=600)
        if ran.returncode != 0:
            raise AssertionError("harness failed:\n" + (ran.stdout + ran.stderr)[-3000:])
        return out_path.read_text(encoding="utf-8").splitlines()


def raw_signed(raw: int, bits: int) -> int:
    raw &= (1 << bits) - 1
    return raw - (1 << bits) if raw >= 1 << (bits - 1) else raw


class Reference:
    """Expected record values per the combined EDR CAN-C scripts' rules (Python side)."""

    REACTION = {"node_absent": "last_valid", "message_timeout": "last_valid", "message_content": "last_valid",
                "signal_content": "consume", "signal_never_received": "default", "variant_code_error": "default",
                "under_voltage": "last_valid", "over_voltage": "last_valid"}

    def __init__(self, context: dict):
        self.series = context["series"]
        self.elements = {e["name"]: e for e in context["elements"]}
        self.frames = context["frames"]

    def case_fault(self, tag, mode):
        applying = [s for s in self.series if tag in s["tags"]]
        driven = [s for s in applying if s["follows"] is None]
        fault = {"stopped": set(), "broken": set(), "consuming": set(), "nodes": set()}
        if mode == "node_absent":
            fault["stopped"] = {s["keyFrame"] for s in driven if s["keyFrame"]}
        elif mode == "message_timeout":
            fault["stopped"] = {s["timeoutFrame"] for s in driven if s["timeoutFrame"]}
        elif mode == "message_content":
            fault["broken"] = {s["frame"] for s in driven if s["crc"]}
        elif mode == "signal_content":
            fault["consuming"] = {s["series"] for s in driven if s["invalid"]}
        elif mode == "signal_never_received":
            fault["nodes"] = {s["node"] for s in driven if s["node"]}
        elif mode == "variant_code_error":
            fault["nodes"] = {"VARIANT_STATUS"}
        return [s["series"] for s in applying], fault

    def affected(self, item, mode, fault):
        if mode is None:
            return False
        if mode == "node_absent":
            return item["keyFrame"] in fault["stopped"]
        if mode == "message_timeout":
            return item["frame"] in fault["stopped"]
        if mode == "message_content":
            return item["frame"] in fault["broken"]
        if mode == "signal_content":
            return item["series"] in fault["consuming"]
        if mode == "signal_never_received":
            return item["node"] in fault["nodes"]
        if mode == "variant_code_error":
            return bool(item["keyFrame"])
        return True

    def plans(self, case, crash):
        cid, tag, mode, scope, value_set, _ = case
        applying, fault = self.case_fault(tag, mode)
        plans = {}
        for item in self.series:
            element = self.elements[item["element"]]
            samples = element["samples"]
            codes = None
            if value_set == "oor" and item["series"] in applying and item["oor"]:
                codes = item["oor"]
            elif value_set == "reserved" and item["series"] in applying and item["reserved"]:
                codes = item["reserved"]
            if codes:
                values = [codes[crash % len(codes)]] * samples
            elif samples == 1:
                values = [item["values"][crash % len(item["values"])]]
            else:
                values = list(item["values"])
            t0 = round(-element["startS"] / element["stepS"]) if element["startS"] is not None else 0
            plans[item["series"]] = {"item": item, "element": element, "values": values, "t0": t0,
                                     "affected": self.affected(item, mode, fault)}
        return plans, mode, scope

    @staticmethod
    def in_fault(plan, index, scope):
        if not plan["affected"]:
            return False
        if scope == "pre":
            return index < plan["t0"]
        if scope == "post":
            return index > plan["t0"]
        return True

    def expected_can(self, plans, plan, index, mode, scope):
        item = plan["item"]
        if item["follows"] is not None:
            leader = plans[item["follows"]]
            return self.expected_can(plans, leader, leader["t0"], mode, scope)
        value = plan["values"][index]
        if not self.in_fault(plan, index, scope):
            return value
        reaction = self.REACTION[mode]
        if reaction == "consume":
            return item["invalid"][0]
        if reaction == "default":
            required = item["snr"] if mode == "signal_never_received" else item["vc"]
            if required:
                return required[0] if len(required) == 1 else frozenset(required)
            return item["defaultRaw"]
        return plan["values"][plan["t0"]] if scope == "post" else plan["values"][0]

    def accepted(self, plan, can_raw):
        item, element = plan["item"], plan["element"]
        bits = element["samplesBits"]

        def convert(code):
            if code in item["invalid"] or code in item["reserved"]:
                return (raw_signed(code, bits) if element["signed"] else code), True
            precise = ((code * item["factor"] + item["offset"]) - element["offset"]) / element["scale"]
            rounded = int(round(precise))
            return (raw_signed(rounded, bits) if element["signed"] else rounded), abs(precise - rounded) < 1e-6

        if isinstance(can_raw, frozenset):
            return sorted(convert(code)[0] for code in can_raw)
        raw, exact = convert(can_raw)
        return sorted([raw] if exact else [raw - 1, raw, raw + 1])


def common_event_tables() -> dict:
    """The single and multi event tables of the EV specification: inputs -> (records after event 3)."""
    text = COMMON_DOC.read_text(encoding="utf-8")
    tables = {}
    for title, kind in (("Single Event Scenarios", "single"), ("Multi Event Scenarios", "multi")):
        block = text.split(title, 1)[1].split("\n\n", 2)[1]
        for line in block.splitlines()[2:]:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) < 12:
                continue
            inputs = tuple(int(c[0]) for c in cells[0:3])
            edr = [c.strip() for c in cells[7].split("/")]
            tables[(kind, inputs)] = {"records": [int(re.sub(r"\D", "", e)) for e in edr],
                                      "men": [int(x) for x in cells[8].split("/")],
                                      "len": [int(x) for x in cells[10].split("/")],
                                      "lock": [int(x) for x in cells[11].split("/")],
                                      "tbe": [x.strip() for x in cells[9].split("/")]}
    return tables


class M210EdrTsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as work:
            cls.context, _ = BUILD.build_context(Path(work))
        rng = random.Random(20261026)
        length = cls.context["record_length"]
        records = [[0x62, 0x04, 0x55] + [rng.randrange(256) for _ in range(length - 3)] for _ in range(200)]
        records.append([0x62, 0x04, 0x55] + [0x00] * (length - 3))
        records.append([0x62, 0x04, 0x55] + [0xFF] * (length - 3))
        cls.records = records
        cls.lines = run_harness(records) if JSC.exists() else None

    def setUp(self):
        if self.lines is None:
            self.skipTest("jsc.exe not found")

    def test_generated_scripts_are_up_to_date(self):
        completed = subprocess.run([sys.executable, str(REPO_ROOT / "tools" / "build_m210_edr_ts.py"), "--check"],
                                   capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)

    def test_decoding_matches_the_framework(self):
        from Framework_IOEM_Py.shared_libraries import edr_decoding_functions as decoder
        read_config = decoder._get_read_config()
        definitions = {p["name"]: p for p in decoder.get_edr_parameters()}
        got = {}
        for line in self.lines:
            if line.startswith("D|"):
                _, index, name, raws = line.split("|")
                got[(int(index), name)] = [int(x) for x in raws.split(",")] if raws else []
        checked = 0
        for index, record in enumerate(self.records):
            data = [f"{b:02X}" for b in record]
            for name, parameter in definitions.items():
                if parameter["type"] == "custom_bits":
                    values = decoder._extract_parameter_values(data, parameter, read_config)
                    expected = [int(v) for v in decoder.decodeParameterValues(name, values, parameter)]
                else:
                    expected = [s["raw"] for s in decoder.edr_sample_records(name, data)]
                self.assertEqual(got[(index, name)], expected, f"record {index}, {name}")
                checked += 1
        self.assertGreater(checked, 30000)

    def test_expected_record_values_match_the_reference(self):
        reference = Reference(self.context)
        cases = [(c[0], c[1], c[2], c[3], "nominal", False) for c in BUILD.FAULT_CASES] + PARAMETER_CASES
        got = {}
        for line in self.lines:
            if line.startswith("E|"):
                _, cid, crash, series, index, accepted, faulted, driven = line.split("|")
                got[(cid, int(crash), int(series), int(index))] = ([int(x) for x in accepted.split(",")], faulted == "1", driven)
        compared = 0
        for case in cases:
            for crash in (0, 1):
                plans, mode, scope = reference.plans(case, crash)
                for series, plan in plans.items():
                    count = 1 if plan["item"]["follows"] is not None else len(plan["values"])
                    for index in range(count):
                        expected = reference.accepted(plan, reference.expected_can(plans, plan, index, mode, scope))
                        leader = plans[plan["item"]["follows"]] if plan["item"]["follows"] is not None else None
                        faulted = (reference.in_fault(leader, leader["t0"], scope) if leader else reference.in_fault(plan, index, scope))
                        key = (case[0], crash, series, index)
                        self.assertIn(key, got)
                        self.assertEqual(got[key][0], expected, f"{key}: accepted record raws")
                        self.assertEqual(got[key][1], faulted, f"{key}: fault flag")
                        if leader is None and mode is not None and Reference.REACTION[mode] == "consume" and faulted:
                            self.assertEqual(got[key][2], str(plan["item"]["invalid"][0]), f"{key}: driven invalid code")
                        compared += 1
        self.assertGreater(compared, 20000)

    def test_fault_dtcs_match_the_reference(self):
        reference = Reference(self.context)
        status = self.context["dtc_status"]
        got = {}
        for line in self.lines:
            if line.startswith("F|"):
                parts = line.split("|")
                got[parts[1]] = parts[2:]
        for cid, tag, mode, scope, _ in BUILD.FAULT_CASES:
            applying, fault = reference.case_fault(tag, mode)
            code_status = status["healed"] if scope == "pre" else status["activeLampOff"]
            expected, qualify = set(), 0
            thresholds = self.context["qualify"]
            for item in self.series_by_id().values():
                if item["series"] not in applying:
                    continue
                code, frame = "", ""
                if mode == "node_absent" and item["keyFrame"] in fault["stopped"]:
                    code, frame = item["dtc"]["na"], item["keyFrame"]
                elif mode == "message_timeout" and item["timeoutFrame"] in fault["stopped"]:
                    code, frame = item["dtc"]["mto"], item["timeoutFrame"]
                elif mode == "message_content" and item["frame"] in fault["broken"]:
                    code, frame = item["dtc"]["mcf"], item["frame"]
                elif mode == "signal_content" and item["series"] in fault["consuming"]:
                    code, frame = item["dtc"]["scf"], item["frame"]
                if code:
                    expected.add(f"{code}/{code_status}")
                    qualify = max(qualify, thresholds[mode] * self.context["frames"][frame]["period"])
            if mode == "variant_code_error":
                expected.add(f"{BUILD.dtc_text(BUILD.CC.Variant_Code_DTC)}/{status['active']}")
            if mode == "under_voltage":
                expected.add(f"{BUILD.dtc_text(BUILD.CC.Under_Voltage)}/{status['historic']}")
            if mode == "over_voltage":
                expected.add(f"{BUILD.dtc_text(BUILD.CC.Over_Voltage)}/{status['historic']}")
            stopped, broken, nodes, dtcs, qualify_ms, crashes = got[cid]
            self.assertEqual(set(dtcs.split(",")) - {""}, expected, f"{cid}: DTCs")
            self.assertEqual(int(qualify_ms), qualify, f"{cid}: qualification time")
            self.assertEqual(set(stopped.split(",")) - {""}, fault["stopped"], f"{cid}: frames stopped")
            self.assertEqual(set(broken.split(",")) - {""}, fault["broken"], f"{cid}: CRC held")
            self.assertEqual(set(nodes.split(",")) - {""}, fault["nodes"], f"{cid}: variant code nodes")
            self.assertEqual(int(crashes), 2, f"{cid}: one record pair")

    def series_by_id(self):
        return {s["series"]: s for s in self.context["series"]}

    def test_schedule_puts_every_sample_and_fault_at_its_instant(self):
        reference = Reference(self.context)
        events = {}
        for line in self.lines:
            if line.startswith("S|"):
                _, cid, at, kind, series, index = line.split("|")
                events.setdefault(cid, []).append((float(at), kind, int(series) if series else None, int(index) if index else None))
        restart = max(BUILD.CANC.NM_RESTART_DELAY_AFTER_UNDER_VOLTAGE_MS, BUILD.CANC.NM_RESTART_DELAY_AFTER_OVER_VOLTAGE_MS)
        cases = [(c[0], c[1], c[2], c[3], "nominal", False) for c in BUILD.FAULT_CASES] + PARAMETER_CASES
        for case in cases:
            cid, mode, scope = case[0], case[2], case[3]
            plans, _, _ = reference.plans(case, 0)
            schedule = events[cid]
            self.assertEqual([e for e in schedule if e[1] == "trigger"][0][0], -BUILD.RSU.RSU_T0_OFFSETS["front"], cid)
            times = [e[0] for e in schedule]
            self.assertEqual(times, sorted(times), f"{cid}: events in time order")
            on = [e[0] for e in schedule if e[1] == "faultOn"]
            off = [e[0] for e in schedule if e[1] == "heal"]
            supply = mode in ("under_voltage", "over_voltage")
            for series, plan in plans.items():
                element = plan["element"]
                if plan["item"]["follows"] is not None or element["startS"] is None:
                    continue
                step = element["stepS"] * 1000
                changes = {e[3]: e[0] for e in schedule if e[1] == "value" and e[2] == series}
                self.assertEqual(sorted(changes), list(range(1, len(plan["values"]))), f"{cid} series {series}: one change per sample")
                for index in range(len(plan["values"])):
                    instant = element["startS"] * 1000 + index * step
                    if index:
                        self.assertAlmostEqual(instant - changes[index], step / 2, msg=f"{cid} series {series} sample {index}")
                    if mode is None or not plan["affected"] or mode in ("signal_content", "signal_never_received", "variant_code_error"):
                        continue
                    start = on[0] if on else float("inf")
                    end = off[0] + (restart if supply else 0) if off else float("inf")
                    self.assertEqual(start < instant < end, reference.in_fault(plan, index, scope),
                                     f"{cid} series {series} sample {index} at {instant} ms: fault window {start}..{end}")

    def test_multi_event_allocation_matches_the_specification(self):
        tables = common_event_tables()
        self.assertEqual(len(tables), 16)
        tests = {t["setKey"]: t for t in self.context["multi_tests"]}
        for (kind, inputs), row in tables.items():
            events = ["front" if inputs[0] else "near", "left" if inputs[1] else "near", "right" if inputs[2] else "near"]
            test = tests[f"{kind}_{'_'.join(events)}"]
            for slot in (0, 1):
                record = test["records"][slot]
                self.assertEqual(record["eventNo"], row["records"][slot], f"{kind} {inputs} record {slot + 1}: event")
                self.assertEqual(record["men"], row["men"][slot], f"{kind} {inputs} record {slot + 1}: MultiEventNumber")
                self.assertEqual(record["len"], row["len"][slot], f"{kind} {inputs} record {slot + 1}: LifeTimeEventNb")
                self.assertEqual(record["lock"], row["lock"][slot], f"{kind} {inputs} record {slot + 1}: lock")
                self.assertEqual(record["tbeMs"] is None, row["tbe"][slot] == "0xFFFF", f"{kind} {inputs} record {slot + 1}: TBE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
